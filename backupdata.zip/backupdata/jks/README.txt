This folder should contain Java keystores
