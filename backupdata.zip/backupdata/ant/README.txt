This folder should contain pre-and-post processing ant scripts
