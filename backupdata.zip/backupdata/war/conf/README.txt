This folder should contain web application deployment descriptors such as web.xml
