/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PWiQueryGroupJoinVO.java
 * @Creation date: 18-Aug-2014
 * @version 1.0
  * @author : Tech Mahindra
 */
package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : PWiQueryGroupVO - Query group object.
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
// TODO REPLACE WITH PWiGroupQueryVO???
public class PWiQueryGroupJoinVO extends PWiBaseVO implements Serializable {
	public static final String QRY_GRP_SEQ_ID = "QRY_GRP_SEQ_ID";
	public static final String QRY_GRP_NM = "QRY_GRP_NM";
	public static final String QRY_GRP_DESC = "QRY_GRP_DESC";
	public static final String QRY_SEQ_ID = "QRY_SEQ_ID";

	private static final long serialVersionUID = 1L;

	private Integer groupId;
	private String displayNm;
	private String description;
	private Collection<PWiQueryNoXmlVO> queries = new ArrayList<PWiQueryNoXmlVO>();

	public PWiQueryGroupJoinVO() {
	}

	public PWiQueryGroupJoinVO(Integer qryGrpSeqId) {
		this.groupId = qryGrpSeqId;
	}

	public PWiQueryGroupJoinVO(Integer groupId, String displayNm, Date crtnDt,
			String crtdBy, Date lstUpdtDt, String lstUpdtdBy) {
		super(crtnDt, crtdBy, lstUpdtDt, lstUpdtdBy);
		this.groupId = groupId;
		this.displayNm = displayNm;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public String getdisplayNm() {
		return displayNm;
	}

	public void setdisplayNm(String displayNmLcl) {
		this.displayNm = displayNmLcl;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Collection<PWiQueryNoXmlVO> getQueries() {
		return queries;
	}

	public void setQueries(Collection<PWiQueryNoXmlVO> queries) {
		this.queries = queries;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (groupId != null ? groupId.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object instanceof PWiQueryGroupJoinVO) {
			PWiQueryGroupJoinVO other = (PWiQueryGroupJoinVO) object;
			if (this.groupId != null && other.groupId != null) {
				return this.groupId.equals(other.groupId);
			}
		}
		return false;
	}

	@Override
	public String toString() {
		return "com.geinfra.geaviation.pwi.model.PWiQueryGroup[qryGrpSeqId="
				+ groupId + "]";
	}

}
