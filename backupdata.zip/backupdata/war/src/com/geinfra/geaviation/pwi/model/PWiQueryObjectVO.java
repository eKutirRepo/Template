/*
//  @ Project : PWi
//  @ File Name : PWiUserCustomQueryVO.java
//  @ Date : 5/14/2010
//  @ Author : nisverma
 */
package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Data access object for the query object table relation.
 * 
 * Revision Log Jan 20, 2012 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiQueryObjectVO extends PWiBaseVO implements Serializable {
	private static final long serialVersionUID = 1L;

	private PWiObjectTypeVO objectType;
	private PWiQueryNoXmlVO query;

	public PWiObjectTypeVO getObjectType() {
		return objectType;
	}

	public void setObjectType(PWiObjectTypeVO objectType) {
		this.objectType = objectType;
	}

	public PWiQueryNoXmlVO getQuery() {
		return query;
	}

	public void setQuery(PWiQueryNoXmlVO query) {
		this.query = query;
	}
}
