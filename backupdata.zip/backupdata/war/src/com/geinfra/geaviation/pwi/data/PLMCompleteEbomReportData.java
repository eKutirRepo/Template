/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCompleteEbomReportData.java
 * @Creation date: 06-Apr-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMCompleteEbomReportData {

	private String selectedProjectName;
	private String selectedTopPartName;
	private String selectedProjectNameHeader;
	private String selectedTopPartNameHeader;
	private String level;
	private String name;
	private String type;
	private String rev;
	private String policy;
	private String findNum;
	private String refDesignator;
	private String componentLocation;
	private String description;
	private String state;
	private String quantity;
	private String unitOfMeasure;
	private String usage;
	private String partFamily;
	private String topPartName;
	
	
	/**
	 * @return the selectedProjectNameHeader
	 */
	public String getSelectedProjectNameHeader() {
		return selectedProjectNameHeader;
	}
	/**
	 * @param selectedProjectNameHeader the selectedProjectNameHeader to set
	 */
	public void setSelectedProjectNameHeader(String selectedProjectNameHeader) {
		this.selectedProjectNameHeader = selectedProjectNameHeader;
	}
	/**
	 * @return the selectedTopPartNameHeader
	 */
	public String getSelectedTopPartNameHeader() {
		return selectedTopPartNameHeader;
	}
	/**
	 * @param selectedTopPartNameHeader the selectedTopPartNameHeader to set
	 */
	public void setSelectedTopPartNameHeader(String selectedTopPartNameHeader) {
		this.selectedTopPartNameHeader = selectedTopPartNameHeader;
	}
	/**
	 * @return the selectedProjectName
	 */
	public String getSelectedProjectName() {
		return selectedProjectName;
	}
	/**
	 * @param selectedProjectName the selectedProjectName to set
	 */
	public void setSelectedProjectName(String selectedProjectName) {
		this.selectedProjectName = selectedProjectName;
	}
	/**
	 * @return the selectedTopPartName
	 */
	public String getSelectedTopPartName() {
		return selectedTopPartName;
	}
	/**
	 * @param selectedTopPartName the selectedTopPartName to set
	 */
	public void setSelectedTopPartName(String selectedTopPartName) {
		this.selectedTopPartName = selectedTopPartName;
	}
	
	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}
	/**
	 * @return the findNum
	 */
	public String getFindNum() {
		return findNum;
	}
	/**
	 * @param findNum the findNum to set
	 */
	public void setFindNum(String findNum) {
		this.findNum = findNum;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the rev
	 */
	public String getRev() {
		return rev;
	}
	/**
	 * @param rev the rev to set
	 */
	public void setRev(String rev) {
		this.rev = rev;
	}
	/**
	 * @return the policy
	 */
	public String getPolicy() {
		return policy;
	}
	/**
	 * @param policy the policy to set
	 */
	public void setPolicy(String policy) {
		this.policy = policy;
	}
	/**
	 * @return the refDesignator
	 */
	public String getRefDesignator() {
		return refDesignator;
	}
	/**
	 * @param refDesignator the refDesignator to set
	 */
	public void setRefDesignator(String refDesignator) {
		this.refDesignator = refDesignator;
	}
	/**
	 * @return the componentLocation
	 */
	public String getComponentLocation() {
		return componentLocation;
	}
	/**
	 * @param componentLocation the componentLocation to set
	 */
	public void setComponentLocation(String componentLocation) {
		this.componentLocation = componentLocation;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the quantity
	 */
	public String getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return the unitOfMeasure
	 */
	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}
	/**
	 * @param unitOfMeasure the unitOfMeasure to set
	 */
	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}
	/**
	 * @return the usage
	 */
	public String getUsage() {
		return usage;
	}
	/**
	 * @param usage the usage to set
	 */
	public void setUsage(String usage) {
		this.usage = usage;
	}
	/**
	 * @return the partFamily
	 */
	public String getPartFamily() {
		return partFamily;
	}
	/**
	 * @param partFamily the partFamily to set
	 */
	public void setPartFamily(String partFamily) {
		this.partFamily = partFamily;
	}
	/**
	 * @return the topPartName
	 */
	public String getTopPartName() {
		return topPartName;
	}
	/**
	 * @param topPartName the topPartName to set
	 */
	public void setTopPartName(String topPartName) {
		this.topPartName = topPartName;
	}
	
	
	
}
