/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMDlvrblDiscusnData.java
 * @Creation date: 11-Sept-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMDlvrblDiscusnData {

	
	// PROPERTIES *************************************************************
	
	public PLMMessageData discussion;
	public PLMTaskDlvrblData task_deliverable;

	
	// CONSTRUCTOR ************************************************************

	/**
	 * Creates a new instance of the class BomDeliverable
	 * 
	 */
	public PLMDlvrblDiscusnData (PLMTaskDlvrblData task_deliverable, PLMMessageData discussion) {  
		this.task_deliverable = task_deliverable;		
		this.discussion = discussion;
	}
	
	// ACCESSOR METHODS *******************************************************

	public PLMTaskDlvrblData getTask_deliverable() {
		return task_deliverable;
	}

	public void setTask_deliverable(PLMTaskDlvrblData task_deliverable) {
		this.task_deliverable = task_deliverable;
	}

	public PLMMessageData getDiscussion() {
		return discussion;
	}

	public void setDiscussion(PLMMessageData discussion) {
		this.discussion = discussion;
	}

	// OVERRIDEN METHODS ******************************************************
	/**
	 * Returns the BomDeliverable information as a String
	 * 
	 * @return type (String) 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer strBomDeliverable = new StringBuffer();
		
		strBomDeliverable
			.append(task_deliverable.toString()).append(" ")
			.append(discussion.toString());
		
		return strBomDeliverable.toString();
	}
	
}
