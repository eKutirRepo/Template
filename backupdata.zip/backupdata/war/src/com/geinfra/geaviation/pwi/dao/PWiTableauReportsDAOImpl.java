/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PWiTableauReportsDAOImpl.java
 * @Creation date: 16-April-2016
 * @version 1.0
 * @author : Karunesh. S
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.PWiTableauReportsVO;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.QueryConstants;
import com.geinfra.geaviation.pwi.util.QueryLoader;

public class PWiTableauReportsDAOImpl extends SimpleJdbcDaoSupport implements PWiTableauReportsDAOIfc {
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
		 
	}
	/*
	 * Fetch tableau reports for particular user
	 * */
	@Override
	public List<PWiTableauReportsVO> getTableauReports(Integer id)
			throws PLMCommonException, PWiException {
		String fetchQuery = QueryLoader.getQuery(QueryConstants.PWi_TABLEAU_FETCH);
		
		try {
			PreparedStatementSetter pss = new tableauReportFetchSetter(id);

			ParameterizedRowMapper<PWiTableauReportsVO> mapper = new GetTableauReportsParameterizedRowMapper();

			@SuppressWarnings("unchecked")
			List<PWiTableauReportsVO> result = (List<PWiTableauReportsVO>) getJdbcTemplate()
					.query(fetchQuery, pss, mapper);
			
			return result;
			
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}
	/*
	 * Fetch all tableau reports
	 * */
	@Override
	public List<PWiTableauReportsVO> getAllTableauReports(Integer id)
			throws PLMCommonException, PWiException {
		String fetchQuery = QueryLoader.getQuery(QueryConstants.PWi_TABLEAU_FETCH_ALL);
		
		try {
			PreparedStatementSetter pss = new tableauReportFetchSetter(id);
			
			ParameterizedRowMapper<PWiTableauReportsVO> mapper = new GetAllTableauReportsParameterizedRowMapper();

			@SuppressWarnings("unchecked")
			List<PWiTableauReportsVO> result = (List<PWiTableauReportsVO>) getJdbcTemplate()
					.query(fetchQuery, pss, mapper);
			
			return result;
			
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}
	/*
	 * Create tableau reports
	 * */
	@Override
	public String createTableauConf(String name, String description,
			String confServer, String confReportName, String params, String site)
			throws PLMCommonException, PWiException {
		String createQuery = QueryLoader.getQuery(QueryConstants.PWi_TABLEAU_CREATE);
		
		try {
			PreparedStatementSetter pss = new tableauReportCreateSetter(name, description, confServer, confReportName, params, site);

			getJdbcTemplate().update(createQuery, pss);
			
			return "tableauReports";
			
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}
	
	/*
	 * Create tableau reports
	 * */
	@Override
	public String editTableauConf(String name, String description,
			String confServer, String confReportName, Integer id)
			throws PLMCommonException, PWiException {
		String createQuery = QueryLoader.getQuery(QueryConstants.PWi_TABLEAU_UPDATE);
		
		try {
			PreparedStatementSetter pss = new tableauReportUpdateSetter(name, description, confServer, confReportName, id);

			getJdbcTemplate().update(createQuery, pss);
			
			return "tableauReports";
			
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}
	
	/*
	 * Create tableau report mapping
	 * */
	@Override
	public String createTableauMapping(Integer userId, Integer reportId)
			throws PLMCommonException, PWiException {
		String createMapQuery = QueryLoader.getQuery(QueryConstants.PWi_TABLEAU_CREATE_MAP);
		
		try {
			PreparedStatementSetter pss = new tableauReportMapSetter(userId, reportId);

			getJdbcTemplate().update(createMapQuery, pss);
			
			return "tableauReports";
			
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}
	
	/*
	 * Delete tableau report conf
	 * */
	@Override
	public String deleteTableauConf(Integer id)
			throws PLMCommonException, PWiException {
		String deleteConfQuery = QueryLoader.getQuery(QueryConstants.PWi_TABLEAU_DELETE);
		
		try {
			PreparedStatementSetter pss = new tableauReportDeleteSetter(id);

			getJdbcTemplate().update(deleteConfQuery, pss);
			
			return "tableauReports";
			
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}
	
	/*
	 * Delete tableau report mapping
	 * */
	@Override
	public String deleteTableauMapping(Integer id)
			throws PLMCommonException, PWiException {
		String deleteMapQuery = QueryLoader.getQuery(QueryConstants.PWi_TABLEAU_DELETE_MAP);
		
		try {
			PreparedStatementSetter pss = new tableauReportDeleteSetter(id);

			getJdbcTemplate().update(deleteMapQuery, pss);
			
			return "tableauReports";
			
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}
	
	/*
	 * Tableau reports pss setters
	 * */
	
	private static class tableauReportFetchSetter implements
		PreparedStatementSetter {
		private Integer id;
		
		public tableauReportFetchSetter(Integer id) {
			this.id = id;
		}
		
		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setInt(1, this.id);
		}
	}
	
	private static class tableauReportCreateSetter implements
		PreparedStatementSetter {
		private String name;
		private String description;
		private String confServer;
		private String confReportName;
		private String params;
		private String site;
		
		public tableauReportCreateSetter(String name, String description, String confServer, String confReportName, String params, String site) {
			this.name = name;
			this.description = description;
			this.confServer = confServer;
			this.confReportName = confReportName;
			this.params = params;
			this.site = site;
		}
		
		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setString(1, this.name);
			ps.setString(2, this.description);
			ps.setString(3, this.confServer);
			ps.setString(4, this.confReportName);
			ps.setString(5, this.params);
			ps.setString(6, this.site);
		}
	}
	
	private static class tableauReportUpdateSetter implements
		PreparedStatementSetter {
		private String name;
		private String description;
		private String confServer;
		private String confReportName;
		private Integer id;
		
		public tableauReportUpdateSetter(String name, String description, String confServer, String confReportName, Integer id) {
			this.name = name;
			this.description = description;
			this.confServer = confServer;
			this.confReportName = confReportName;
			this.id = id;
		}
		
		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setString(1, this.name);
			ps.setString(2, this.description);
			ps.setString(3, this.confServer);
			ps.setString(4, this.confReportName);
			ps.setInt(5, this.id);
		}
	}
	
	private static class tableauReportMapSetter implements
		PreparedStatementSetter {
		private Integer userId;
		private Integer reportId;
		
		public tableauReportMapSetter(Integer userId, Integer reportId) {
			this.userId = userId;
			this.reportId = reportId;
		}
		
		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setInt(1, this.userId);
			ps.setInt(2, this.reportId);
		}
	}
	
	private static class tableauReportDeleteSetter implements
		PreparedStatementSetter {
		private Integer id;
		
		public tableauReportDeleteSetter(Integer id) {
			this.id = id;
		}
		
		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setInt(1, this.id);
		}
	}
	
	private static class GetTableauReportsParameterizedRowMapper implements
		ParameterizedRowMapper<PWiTableauReportsVO> {
		public PWiTableauReportsVO mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PWiTableauReportsVO pwitableaureportsvo 
				= new PWiTableauReportsVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getInt(8));
			
			return pwitableaureportsvo;
		}
	}
	
	private static class GetAllTableauReportsParameterizedRowMapper implements
		ParameterizedRowMapper<PWiTableauReportsVO> {
		public PWiTableauReportsVO mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PWiTableauReportsVO pwitableaureportsvo 
				= new PWiTableauReportsVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7));
			
			return pwitableaureportsvo;
		}
	}

}
