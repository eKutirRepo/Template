/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCFCRPRSRptMB.java
 * @Creation date: 30-July-2015
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.common.usermodel.Hyperlink;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFCreationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFHyperlink;

import com.geinfra.geaviation.pwi.data.PLMCFCRPRSRptData;
import com.geinfra.geaviation.pwi.service.PLMCFCRPRSRptServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMCFCRPRSRptMB {
	/**
	 * Holds the Logger.
	 */
	private static final Logger LOG = Logger.getLogger(PLMCFCRPRSRptMB.class);
	/**
	 *  Holds the plmCFCRPRSRptService
	 */
	private PLMCFCRPRSRptServiceIfc plmCFCRPRSRptService = null;
	/**
	 *  Holds the alertMsgCFCRS
	 */
	private String alertMsgCFCRS;
	/**
	 *  Holds the contract1
	 */
	private String contract1;
	/**
	 *  Holds the contract2
	 */
	private String contract2;
	/**
	 *  Holds the contract3
	 */
	private String contract3;
	/**
	 *  Holds the minFlag
	 */
	private boolean minFlag;
	/**
	 *  Holds the optFlag
	 */
	private boolean optFlag;
	/**
	 * Holds the selCstGrpList1
	 */
	private List<String> selCstGrpList1 = new ArrayList<String>();
	/**
	 * Holds the selCstGrpList2
	 */
	private List<String> selCstGrpList2 = new ArrayList<String>();
	/**
	 * Holds the selCstGrpList3
	 */
	private List<String> selCstGrpList3 = new ArrayList<String>();
	/**
	 * Holds the cstGrpList1
	 */
	private List<SelectItem> cstGrpList1 = new ArrayList<SelectItem>();
	/**
	 * Holds the cstGrpList2
	 */
	private List<SelectItem> cstGrpList2 = new ArrayList<SelectItem>();
	/**
	 * Holds the cstGrpList3
	 */
	private List<SelectItem> cstGrpList3 = new ArrayList<SelectItem>();
	/**
	 * Holds the selPcName1
	 */
	private String selPcName1;
	/**
	 * Holds the selPcName2
	 */
	private String selPcName2;
	/**
	 * Holds the selPcName3
	 */
	private String selPcName3;
	
	/**
	 * Holds the pcDesc1
	 */
	private String pcDesc1;
	/**
	 * Holds the pcDesc2
	 */
	private String pcDesc2;
	/**
	 * Holds the pcDesc3
	 */
	private String pcDesc3;
	/**
	 * Holds the pcInfoList1
	 */
	private List<SelectItem> pcInfoList1 = new ArrayList<SelectItem>();
	/**
	 * Holds the pcInfoList2
	 */
	private List<SelectItem> pcInfoList2 = new ArrayList<SelectItem>();
	/**
	 * Holds the pcInfoList3
	 */
	private List<SelectItem> pcInfoList3 = new ArrayList<SelectItem>();
	/**
	 * Holds the cfDataList
	 */
	private List <PLMCFCRPRSRptData> cfDataList = new ArrayList<PLMCFCRPRSRptData>();
	/**
	 * Holds the crDataList
	 */
	private List <PLMCFCRPRSRptData> crDataList = new ArrayList<PLMCFCRPRSRptData>();
	/**
	 * Holds the prsDataList
	 */
	private List <PLMCFCRPRSRptData> prsDataList = new ArrayList<PLMCFCRPRSRptData>();
	/**
	 * Holds the commonMB
	 */
	private PLMCommonMB commonMB = null;
	
	private boolean cfTabFlag;
	
	private boolean crTabFlag;
	
	private boolean prsTabFlag;
	 
    /**
	  * Holds the resourceBundle
	  */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");

	/**
	 */
	/**
	 * This method is Load home page of CF CR PRS
	 * 
	 *@return String
	 */
	public String loadResetCFCRPRSPage(){
		String fwdFlag="cfcrprsSearch";
		contract1="";
		contract2="";
		contract3="";
		minFlag=false;
		optFlag=false;
		alertMsgCFCRS="";
		try {
			commonMB.insertCannedRptRecordHitInfo("CF/CR/PRS Comparison Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		//creating / clearing lists for Cost Groups
		if (PLMUtils.isEmptyList(cstGrpList1)) {
			cstGrpList1 = new ArrayList<SelectItem>();
		} else {
			cstGrpList1.clear();
		}
		if (PLMUtils.isEmptyList(cstGrpList2)) {
			cstGrpList2 = new ArrayList<SelectItem>();
		} else {
			cstGrpList2.clear();
		}
		if (PLMUtils.isEmptyList(cstGrpList3)) {
			cstGrpList3 = new ArrayList<SelectItem>();
		} else {
			cstGrpList3.clear();
		}
		
		//creating / clearing lists for PCs
		if (PLMUtils.isEmptyList(pcInfoList1)) {
			pcInfoList1 = new ArrayList<SelectItem>();
		} else {
			pcInfoList1.clear();
		}
		if (PLMUtils.isEmptyList(pcInfoList2)) {
			pcInfoList2 = new ArrayList<SelectItem>();
		} else {
			pcInfoList2.clear();
		}
		if (PLMUtils.isEmptyList(pcInfoList3)) {
			pcInfoList3 = new ArrayList<SelectItem>();
		} else {
			pcInfoList3.clear();
		}
		
		pcDesc1="";
		pcDesc2="";
		pcDesc3="";

		//creating / clearing lists for Report tabs
		if (PLMUtils.isEmptyList(cfDataList)) {
			cfDataList = new ArrayList<PLMCFCRPRSRptData>();
		} else {
			cfDataList.clear();
		}
		if (PLMUtils.isEmptyList(crDataList)) {
			crDataList = new ArrayList<PLMCFCRPRSRptData>();
		} else {
			crDataList.clear();
		}
		if (PLMUtils.isEmptyList(prsDataList)) {
			prsDataList = new ArrayList<PLMCFCRPRSRptData>();
		} else {
			prsDataList.clear();
		}

		//creating / clearing lists for Selected Cost Groups
		if (PLMUtils.isEmptyList(selCstGrpList1)) {
			selCstGrpList1 = new ArrayList<String>();
		} else {
			selCstGrpList1.clear();
		}
		if (PLMUtils.isEmptyList(selCstGrpList2)) {
			selCstGrpList2 = new ArrayList<String>();
		} else {
			selCstGrpList2.clear();
		}
		if (PLMUtils.isEmptyList(selCstGrpList3)) {
			selCstGrpList3 = new ArrayList<String>();
		} else {
			selCstGrpList3.clear();
		}
		
		return fwdFlag;
	}
	
	/**
	 * This method is used for validating contract number
	 * 
	 * @return String
	 */
	public String validationForContracts(){
		alertMsgCFCRS = "";
		if (PLMUtils.isEmpty(contract1)|| PLMUtils.isEmpty(contract2)) {
			alertMsgCFCRS = "Please provide values for Contract#1 and Contract#2.";
		} 
		if (!PLMUtils.checkForSpecialChars(contract1)) {
			alertMsgCFCRS = "Contract#1 should not contain special characters.\n";
		} 
		if (!PLMUtils.checkForSpecialChars(contract2)){
			alertMsgCFCRS = alertMsgCFCRS+"Contract#2 should not contain special characters.\n";
		}
		if (!PLMUtils.checkForSpecialChars(contract3)) {
			alertMsgCFCRS = alertMsgCFCRS+"Contract#3 should not contain special characters.\n";
		}
		return alertMsgCFCRS;
	}
	/**
	 * This method is used retrieve Cost group
	 * 
	 *@return String
	 * @throws PLMCommonException 
	 */
	public String getCostGroups() throws PLMCommonException{
		LOG.info("Entering into getCostGroups");
		String fwdFlag="cfcrprsSearch";
		alertMsgCFCRS="";
		alertMsgCFCRS = validationForContracts();
		List<String> contractList =new ArrayList<String>();
		cstGrpList1 = new ArrayList<SelectItem>();
		cstGrpList2 = new ArrayList<SelectItem>();
		cstGrpList3 = new ArrayList<SelectItem>();
		 try{
			 if(PLMUtils.isEmpty(alertMsgCFCRS)){
				 contractList.add(contract1);
				 contractList.add(contract2);
				  if(!PLMUtils.isEmpty(contract3)){
					contractList.add(contract3);
				  } 
				  alertMsgCFCRS= plmCFCRPRSRptService.validateContracts(contractList);
				  if(PLMUtils.isEmpty(alertMsgCFCRS)){
					  LOG.info("Contracts Valid");
					  minFlag=true;
					  List<String> cstGrpList = plmCFCRPRSRptService.fetchCstGrpData();
					   if(!PLMUtils.isEmpty(contract3)){
						  optFlag=true;
					   }
					   for (int i = 0; i < cstGrpList.size(); i++) {
							cstGrpList1.add(new SelectItem(cstGrpList.get(i), cstGrpList.get(i)));
							cstGrpList2.add(new SelectItem(cstGrpList.get(i), cstGrpList.get(i)));
							if(optFlag){
							 cstGrpList3.add(new SelectItem(cstGrpList.get(i), cstGrpList.get(i)));
							}
						}
				  }else{
					  minFlag=false;
					  return alertMsgCFCRS;
				  }
			  }	 
		 }catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@generateCRReport: ", exception);
				PLMUtils.setCommonException(exception.getMessage(), commonMB,
						"cfcrprsSearch", "CF/CR/PRS Comparison Report");
				throw exception;
			} 
		 LOG.info("Exiting into getCostGroups");
		return fwdFlag;
	}
	
	/**
	 * This method is used to get Product Configuration for contract 1
	 * 
	 * @param event
	 */
	public void fetchPrdouctConf1(ActionEvent event){
		LOG.info("Entering fetchPrdouctConf1 method");
		try{
			selPcName1="";
			 List <PLMCFCRPRSRptData> pcInfoList = new ArrayList<PLMCFCRPRSRptData>();
			  pcInfoList1 = new ArrayList<SelectItem>();
			  pcInfoList = plmCFCRPRSRptService.fetchPCInfo(contract1,selCstGrpList1);
			  
			   for(int i=0;i<pcInfoList.size();i++){
				   pcInfoList1.add(new SelectItem(pcInfoList.get(i).getPrdtConfigNm(), 
						    pcInfoList.get(i).getPrdtConfigNm()+" "+pcInfoList.get(i).getPrdtConfigDesc()));
				}
			
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting fetchPrdouctConf1 method");
	}
	/**
	 * This method is used to get Product Configuration for contract 2
	 * 
	 * @param event
	 */
	public void fetchPrdouctConf2(ActionEvent event){
		LOG.info("Entering fetchPrdouctConf2 method");
		try{
			selPcName2="";
			 List <PLMCFCRPRSRptData> pcInfoList = new ArrayList<PLMCFCRPRSRptData>();
			  pcInfoList2 = new ArrayList<SelectItem>();
			  pcInfoList = plmCFCRPRSRptService.fetchPCInfo(contract2,selCstGrpList2);
			  
			   for(int i=0;i<pcInfoList.size();i++){
				   pcInfoList2.add(new SelectItem(pcInfoList.get(i).getPrdtConfigNm(), 
						    pcInfoList.get(i).getPrdtConfigNm()+" "+pcInfoList.get(i).getPrdtConfigDesc()));
				}
			
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting fetchPrdouctConf2 method");
	}
	/**
	 * This method is used to get Product Configuration for contract 3
	 * 
	 * @param event
	 */
	public void fetchPrdouctConf3(ActionEvent event){
		LOG.info("Entering fetchPrdouctConf3 method");
		try{
			selPcName3="";
			 List <PLMCFCRPRSRptData> pcInfoList = new ArrayList<PLMCFCRPRSRptData>();
			  pcInfoList3 = new ArrayList<SelectItem>();
			  pcInfoList = plmCFCRPRSRptService.fetchPCInfo(contract3,selCstGrpList3);
			  
			   for(int i=0;i<pcInfoList.size();i++){
				   pcInfoList3.add(new SelectItem(pcInfoList.get(i).getPrdtConfigNm(), 
				   pcInfoList.get(i).getPrdtConfigNm()+" "+pcInfoList.get(i).getPrdtConfigDesc()));
				}
			
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting fetchPrdouctConf3 method");
	}
	
	/**
	 * This method is used for validating Final Report
	 * 
	 * @return String
	 */
	public String validationForFinalReport(){
		alertMsgCFCRS = "";
		if (PLMUtils.isEmpty(contract1)|| PLMUtils.isEmpty(contract2)) {
			alertMsgCFCRS = "Please provide values for Contract#1 and Contract#2.";
			return alertMsgCFCRS;
		}
		
		if(PLMUtils.isEmptyList(selCstGrpList1)){
			alertMsgCFCRS = "Please Select Cost group under Contract # 1";
			return alertMsgCFCRS;
		}
		
		if (PLMUtils.isEmptyList(selCstGrpList2)) {
			alertMsgCFCRS = "Please Select Cost group under Contract # 2.";
			return alertMsgCFCRS;
		}
		
		if (optFlag && PLMUtils.isEmptyList(selCstGrpList3)) {
			alertMsgCFCRS = "Please Select Cost group under Contract # 3.";
			return alertMsgCFCRS;
		}
		
		if(PLMUtils.isEmpty(selPcName1)){
			alertMsgCFCRS = "Please Select Product Configuration under Contract # 1.";
			return alertMsgCFCRS;
		}
		
		if (PLMUtils.isEmpty(selPcName2)) {
			alertMsgCFCRS = "Please Select Product Configuration under Contract # 2.";
			return alertMsgCFCRS;
		}
		
		if (optFlag && PLMUtils.isEmpty(selPcName3)) {
			alertMsgCFCRS = "Please Select Product Configuration under Contract # 3.";
			return alertMsgCFCRS;
		}
		
		if(!PLMUtils.isEmpty(selPcName1) && !PLMUtils.isEmpty(selPcName2) && selPcName1.equalsIgnoreCase(selPcName2)){
			alertMsgCFCRS = "Please select different Product Configuration Under Contracts # 1 & 2.";
			return alertMsgCFCRS;
			
		}
		
		if(optFlag && !PLMUtils.isEmpty(selPcName3)) {
			if (selPcName3.equalsIgnoreCase(selPcName1)) {
				alertMsgCFCRS = "Please select different Product Configuration Under Contracts # 1 & 3.";
				return alertMsgCFCRS;
			} 
			if (selPcName3.equalsIgnoreCase(selPcName2)) {
				alertMsgCFCRS = "Please select different Product Configuration Under Contracts # 2 & 3.";
				return alertMsgCFCRS;
			}
		}
		return alertMsgCFCRS;
	}
	
	/**
	 * This method is used for CF Report Generation
	 * 
	 * @return String
	 */
	public String generateCFReport() throws PLMCommonException {

		LOG.info("Entering in to generateCFReport");
		alertMsgCFCRS = "";
		String fwdFlag = "";
		alertMsgCFCRS = validationForFinalReport();
		List<String> contractList = new ArrayList<String>();
		List<String> pcList = new ArrayList<String>();
		if (!PLMUtils.isEmptyList(crDataList)) {
			crDataList.clear();
		} else {
			crDataList = new ArrayList<PLMCFCRPRSRptData>();
		}
		if (!PLMUtils.isEmptyList(prsDataList)) {
			prsDataList.clear();
		} else {
			prsDataList = new ArrayList<PLMCFCRPRSRptData>();
		}
		try {
			//if (PLMUtils.isEmptyList(cfDataList)) {
				if (PLMUtils.isEmpty(alertMsgCFCRS)) {
					contractList.add(contract1);
					contractList.add(contract2);

					if (!PLMUtils.isEmpty(contract3)) {
						contractList.add(contract3);
					}

					pcList.add(selPcName1);
					pcList.add(selPcName2);

					for (int i = 0; i < pcInfoList1.size(); i++) {
						if (selPcName1.equalsIgnoreCase(pcInfoList1.get(i).getValue().toString())) {
							pcDesc1 = (String) ((SelectItem) pcInfoList1.get(i)).getLabel();
							break;
						}
					}

					for (int i = 0; i < pcInfoList2.size(); i++) {
						if (selPcName2.equalsIgnoreCase(pcInfoList2.get(i).getValue().toString())) {
							pcDesc2 = (String) ((SelectItem) pcInfoList2.get(i)).getLabel();
							break;
						}
					}

					if (!PLMUtils.isEmpty(selPcName3)) {
						pcList.add(selPcName3);
						for (int i = 0; i < pcInfoList3.size(); i++) {
							if (selPcName3.equalsIgnoreCase(pcInfoList3.get(i).getValue().toString())) {
								pcDesc3 = (String) ((SelectItem) pcInfoList3.get(i)).getLabel();
								break;
							}
						}
					}

					cfDataList = plmCFCRPRSRptService.getCFReportData(contract1, contract2, contract3, selPcName1, selPcName2, selPcName3);
					cfTabFlag = true;
					crTabFlag = false;
					prsTabFlag = false;
					fwdFlag = "cfcrprsReport";
				}else {
					cfTabFlag = false;
					crTabFlag = false;
					prsTabFlag = false;
					fwdFlag = "cfcrprsSearch";
				}
			/*} else {
				cfTabFlag = true;
				crTabFlag = false;
				prsTabFlag = false;
				fwdFlag = "cfcrprsReport";
			}*/

		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@generateCFReport: ", exception);
			PLMUtils.setCommonException(exception.getMessage(), commonMB, "cfcrprsSearch", "CF/CR/PRS Comparison Report");
			throw exception;
		}
		LOG.info("Exiting in to generateCFReport");
		return fwdFlag;
	}
	
	/**
	 * This method is used for CF Report Generation
	 * 
	 * @return String
	 */
	public String generateCFReportTab() throws PLMCommonException {

		LOG.info("Entering in to generateCFReport");
		alertMsgCFCRS = "";
		String fwdFlag = "";
		alertMsgCFCRS = validationForFinalReport();
		List<String> contractList = new ArrayList<String>();
		List<String> pcList = new ArrayList<String>();
		try {
			if (PLMUtils.isEmptyList(cfDataList)) {
				if (PLMUtils.isEmpty(alertMsgCFCRS)) {
					contractList.add(contract1);
					contractList.add(contract2);

					if (!PLMUtils.isEmpty(contract3)) {
						contractList.add(contract3);
					}

					pcList.add(selPcName1);
					pcList.add(selPcName2);

					for (int i = 0; i < pcInfoList1.size(); i++) {
						if (selPcName1.equalsIgnoreCase(pcInfoList1.get(i).getValue().toString())) {
							pcDesc1 = (String) ((SelectItem) pcInfoList1.get(i)).getLabel();
							break;
						}
					}

					for (int i = 0; i < pcInfoList2.size(); i++) {
						if (selPcName2.equalsIgnoreCase(pcInfoList2.get(i).getValue().toString())) {
							pcDesc2 = (String) ((SelectItem) pcInfoList2.get(i)).getLabel();
							break;
						}
					}

					if (!PLMUtils.isEmpty(selPcName3)) {
						pcList.add(selPcName3);
						for (int i = 0; i < pcInfoList3.size(); i++) {
							if (selPcName3.equalsIgnoreCase(pcInfoList3.get(i).getValue().toString())) {
								pcDesc3 = (String) ((SelectItem) pcInfoList3.get(i)).getLabel();
								break;
							}
						}
					}

					cfDataList = plmCFCRPRSRptService.getCFReportData(contract1, contract2, contract3, selPcName1, selPcName2, selPcName3);
					cfTabFlag = true;
					crTabFlag = false;
					prsTabFlag = false;
					fwdFlag = "cfcrprsReport";
				}else {
					cfTabFlag = false;
					fwdFlag = "cfcrprsSearch";
				}
			} else {
				cfTabFlag = true;
				crTabFlag = false;
				prsTabFlag = false;
				fwdFlag = "cfcrprsReport";
			}

		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@generateCFReport: ", exception);
			PLMUtils.setCommonException(exception.getMessage(), commonMB, "cfcrprsSearch", "CF/CR/PRS Comparison Report");
			throw exception;
		}
		LOG.info("Exiting in to generateCFReport");
		return fwdFlag;
	}
	
	 private XSSFFont headerFont(SXSSFWorkbook wb, int size){
			XSSFFont font = (XSSFFont) wb.createFont();
			font.setFontName(PLMConstants.EXCEL_FONT_NAME);
			font.setFontHeightInPoints((short)size);
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			return font;
		}
		
		private XSSFFont normalFont(SXSSFWorkbook wb, int size){
			XSSFFont font = (XSSFFont) wb.createFont();
			font.setFontName(PLMConstants.EXCEL_FONT_NAME);
			font.setFontHeightInPoints((short)size);
			return font;
		}
		
		private XSSFCellStyle headerCell(SXSSFWorkbook wb, XSSFFont font, short bgcolor, boolean wrap){
			XSSFCellStyle hCell = normalCell(wb, font, XSSFCellStyle.SOLID_FOREGROUND, wrap);
			//FONT
			hCell.setFont(font);
			
			//HORIZONTAL ALIGNMENT
			hCell.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			
			//COLOR
			hCell.setFillForegroundColor(bgcolor);
			return hCell;
		}
		
		private XSSFCellStyle normalCell(SXSSFWorkbook wb, XSSFFont font, short fillPattern, boolean wrap){
			// Cell Style
			XSSFCellStyle cellStyle = (XSSFCellStyle)wb.createCellStyle();
			
			//Set Font
			cellStyle.setFont(font);
			//WRAP TEXT
			cellStyle.setWrapText(wrap);
			
			//VERTICAL ALIGNMENT
			cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			
			//BORDERS
			cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			
			//FILL PATTERN
			cellStyle.setFillPattern(fillPattern);
			return cellStyle;
		}
		
		/**
		 * This method is used for Bordering Cell in XLS
		 * 
		 * @return StringBuffer
		 */
		private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
			style.setBorderTop(XSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			style.setBorderRight(XSSFCellStyle.BORDER_THIN);
			return style;
		}
	
		/**
		 * This method is used for download Excel sheet for CF report
		 * 
		 */
		public void downloadCFReport() throws PLMCommonException {
			LOG.info("Entering downloadCFReport Method");
			FacesContext facesContext = FacesContext.getCurrentInstance();
		  	try {
				HttpServletResponse response = 
					(HttpServletResponse)facesContext.getExternalContext().getResponse();
				
				response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
				
				response.setHeader("Content-disposition", 
						"attachment; filename="+"CF Compare.xlsx");
				
				OutputStream outputStream = response.getOutputStream();
				
				SXSSFWorkbook workbook = new SXSSFWorkbook();
				
				XSSFFont font = headerFont(workbook, 10);
				
				// Header Style
				XSSFCellStyle headerStyle = headerCell(workbook, font, HSSFColor.PALE_BLUE.index, true);

				XSSFFont cellfont = normalFont(workbook, 10);
				// Cell Style
				XSSFCellStyle cellStyle = normalCell(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
				
				// cell hyper link
				XSSFCreationHelper helper= (XSSFCreationHelper) workbook.getCreationHelper();
				
			    XSSFFont underLinedFont = (XSSFFont) workbook.createFont();
		        underLinedFont.setUnderline(HSSFFont.U_SINGLE);
		        underLinedFont.setColor(IndexedColors.BLUE.getIndex());
				XSSFCellStyle hyperLinkStyle = (XSSFCellStyle) workbook.createCellStyle();				
				hyperLinkStyle = setBorderStyle(hyperLinkStyle);
				hyperLinkStyle.setFont(underLinedFont);
				
				SXSSFSheet sheet = (SXSSFSheet) workbook.createSheet("CF Compare");
				
				int rowcount = 0;
				
				SXSSFCell cell=null;
			    
			    SXSSFRow row = (SXSSFRow) sheet.createRow(rowcount);
	            	
			    String[] columns = {"Level","CF Display Name","CF Name","Feature Type"};
				
	        	for ( int i = 0 ; i < columns.length; i++ ) {
					cell = (SXSSFCell)row.createCell(i);
					cell. setCellValue(columns[i]);
					cell.setCellStyle(headerStyle);
				}
	             
	        	 cell = (SXSSFCell) row.createCell(4);
					 cell.setCellStyle(headerStyle);
					 String contractPC1 =contract1 +"\n"+selPcName1;
					 cell.setCellValue(contractPC1);
					 
					 cell = (SXSSFCell) row.createCell(5);
					 cell.setCellStyle(headerStyle);
					 String contractPC2 =contract2 +"\n"+selPcName2;
					 cell.setCellValue(contractPC2);
					 
					  if(optFlag){
						cell = (SXSSFCell) row.createCell(6);
		 				cell.setCellStyle(headerStyle);
		 				String contractPC3 =contract3 +"\n"+selPcName3;
		 				cell.setCellValue(contractPC3); 
					 }
	        	
					for(int i=0;i<cfDataList.size();i++){
					
						PLMCFCRPRSRptData dataObj = (PLMCFCRPRSRptData) cfDataList.get(i);
						
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(dataObj.getLevel());
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(dataObj.getDisplayNm());
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
						
						if(!PLMUtils.isEmpty(dataObj.getCfoId())){
							cell.setCellStyle(hyperLinkStyle);
							XSSFHyperlink url_link = helper.createHyperlink(Hyperlink.LINK_URL);
							url_link.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getCfoId());
							cell.setHyperlink(url_link);
							cell.setCellValue(dataObj.getCfoName());
						}else{
							cell.setCellStyle(cellStyle);
							 cell.setCellValue("");
						}
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(dataObj.getFeatureType());
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FOUR);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(dataObj.getPc1());
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FIVE);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(dataObj.getPc2());
						
						if(optFlag){
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_SIX);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(dataObj.getPc3());
						}
			  	   }
				
	             	row = (SXSSFRow) sheet.createRow(++rowcount);
	             	row = (SXSSFRow) sheet.createRow(++rowcount);
	             	
	             	
				    XSSFCellStyle ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
				    ftrStyle.setFont(font);
				    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
				    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
				    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
				    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
				    cell.setCellStyle(ftrStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_TWO));

					sheet.setColumnWidth(0,10*256);
					sheet.setColumnWidth(1,35*256);
					sheet.setColumnWidth(2,15*256);
					sheet.setColumnWidth(3,15*256);
					sheet.setColumnWidth(4,15*256);
					sheet.setColumnWidth(5,15*256);
					if(optFlag){
					 sheet.setColumnWidth(6,15*256);
					}
					sheet.createFreezePane( 0, 1 );
				
	            workbook.write(outputStream);
				
				outputStream.flush();
				
				outputStream.close();
				
			} catch (IOException ioex) {
				ioex.printStackTrace();
			} finally {
				facesContext.responseComplete();
		  	}
			LOG.info("Exiting downloadCFReport Method");
		} 	
	/**
	 * This method is used for CR Report Generation
	 * 
	 * @return String
	 */
	public void generateCRReport() throws PLMCommonException {

		LOG.info("Entering in to generateCRReport");
		try {
			if (PLMUtils.isEmptyList(crDataList)) {
				List<String> contractList = new ArrayList<String>();
				contractList.add(contract1);
				contractList.add(contract2);
				if (!PLMUtils.isEmpty(contract3)) {
					contractList.add(contract3);
				}
				crDataList =
								plmCFCRPRSRptService.getCRReportData(contractList, contract1, contract2, contract3, selCstGrpList1, selCstGrpList2,
												selCstGrpList3);
			}
			cfTabFlag = false;
			crTabFlag = true;
			prsTabFlag = false;
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@generateCRReport: ", exception);
			PLMUtils.setCommonException(exception.getMessage(), commonMB, "cfcrprsSearch", "CF/CR/PRS Comparison Report");
			throw exception;
		}
		LOG.info("Exiting in to generateCRReport");
	}
	/**
	 * This method is used for download Excel sheet for CR report
	 * 
	 */
	public void downloadCRReport() throws PLMCommonException {
		LOG.info("Entering downloadCRReport Method");
		FacesContext facesContext = FacesContext.getCurrentInstance();
	  	try {
			HttpServletResponse response = 
				(HttpServletResponse)facesContext.getExternalContext().getResponse();
			
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			
			response.setHeader("Content-disposition", 
					"attachment; filename="+"CR Compare.xlsx");
			
			OutputStream outputStream = response.getOutputStream();
			
			SXSSFWorkbook workbook = new SXSSFWorkbook();
			
			XSSFFont font = headerFont(workbook, 10);
			
			// Header Style
			XSSFCellStyle headerStyle = headerCell(workbook, font, HSSFColor.PALE_BLUE.index, true);

			XSSFFont cellfont = normalFont(workbook, 10);
			// Cell Style
			XSSFCellStyle cellStyle = normalCell(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
			
			// cell hyper link
			XSSFCreationHelper helper= (XSSFCreationHelper) workbook.getCreationHelper();
			
		    XSSFFont underLinedFont = (XSSFFont) workbook.createFont();
	        underLinedFont.setUnderline(HSSFFont.U_SINGLE);
	        underLinedFont.setColor(IndexedColors.BLUE.getIndex());
			XSSFCellStyle hyperLinkStyle = (XSSFCellStyle) workbook.createCellStyle();				
			hyperLinkStyle = setBorderStyle(hyperLinkStyle);
			hyperLinkStyle.setFont(underLinedFont);
			
			SXSSFSheet sheet = (SXSSFSheet) workbook.createSheet("CR Compare");
			
			int rowcount = 0;
			
			SXSSFCell cell=null;
		    
		    SXSSFRow row = (SXSSFRow) sheet.createRow(rowcount);
            	
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(contract1);
			cell.setCellStyle(headerStyle);
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
			cell.setCellStyle(headerStyle);
			sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ONE,PLMConstants.EXCEL_COL_EIGHT));
			cell.setCellStyle(headerStyle);
		
			
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
			cell.setCellValue(contract2);
			cell.setCellStyle(headerStyle);
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
			cell.setCellStyle(headerStyle);
			sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_NINE,PLMConstants.EXCEL_COL_SIXTEEN));
			cell.setCellStyle(headerStyle);
			
			if(optFlag){
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
			cell.setCellValue(contract3);
			cell.setCellStyle(headerStyle);
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWENTYFOUR);
			cell.setCellStyle(headerStyle);
			sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_SEVENTEEN,PLMConstants.EXCEL_COL_TWENTYFOUR));
			cell.setCellStyle(headerStyle);
			}
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
			cell.setCellStyle(headerStyle);
		
			if(optFlag){
				String[] colNames1 = {"MLI","LF Name","LF Rev","LF Desc","CR Name","CR Title","CO Name","PC Name","Cost Group",
					"LF Name","LF Rev","LF Desc","CR Name","CR Title","CO Name","PC Name","Cost Group",
					"LF Name","LF Rev","LF Desc","CR Name","CR Title","CO Name","PC Name","Cost Group"};
				for ( int i = 0 ; i < colNames1.length; i++ ) {
					cell = (SXSSFCell) row.createCell(i);
					cell. setCellValue(colNames1[i]);
					cell.setCellStyle(headerStyle);
					headerStyle = (XSSFCellStyle) cell.getCellStyle();
					cell.setCellStyle(headerStyle);
				}
				
			}else{
				String[] colNames2 = {"MLI","LF Name","LF Rev","LF Desc","CR Name","CR Title","CO Name","PC Name","Cost Group",
							"LF Name","LF Rev","LF Desc","CR Name","CR Title","CO Name","PC Name","Cost Group"};
				for ( int i = 0 ; i < colNames2.length; i++ ) {
					cell = (SXSSFCell) row.createCell(i);
					cell. setCellValue(colNames2[i]);
					cell.setCellStyle(headerStyle);
					headerStyle = (XSSFCellStyle) cell.getCellStyle();
					cell.setCellStyle(headerStyle);
				}
			}
		   

			for(int i = 0; i < crDataList.size(); i++) {
				PLMCFCRPRSRptData	 dataObj = (PLMCFCRPRSRptData)crDataList.get(i);
				row =  (SXSSFRow) sheet.createRow(++rowcount);
				
				cell =   (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getMli());
				
				cell =   (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getLfName1());
				
				cell =   (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getLfRev1());
				
				cell =   (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getLfDesc1());
				
				
				cell =   (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FOUR);
				if(!PLMUtils.isEmpty(dataObj.getCrId1())){
					cell.setCellStyle(hyperLinkStyle);
					XSSFHyperlink url_link1 = helper.createHyperlink(Hyperlink.LINK_URL);
					url_link1.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getCrId1());
					cell.setHyperlink(url_link1);
					cell.setCellValue(dataObj.getCrNm1());
				}else{
					cell.setCellStyle(cellStyle);
					cell.setCellValue("");
				}
				
				cell =  (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getCrTitile1());
				
				cell =  (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
				if(!PLMUtils.isEmpty(dataObj.getCoId1())){
					cell.setCellStyle(hyperLinkStyle);
					XSSFHyperlink url_link2 = helper.createHyperlink(Hyperlink.LINK_URL);
					url_link2.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getCoId1());
					cell.setHyperlink(url_link2);
					cell.setCellValue(dataObj.getCoNm1());
				}else{
					  cell.setCellStyle(cellStyle);
					  cell.setCellValue("");
				}
				
				cell =   (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_SEVEN);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getPcName1());
				
				cell =   (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_EIGHT);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getCostGrp1());
				
				
				cell =   (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_NINE);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getLfName2());
				
				
				cell =  (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TEN);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getLfRev2());
				
				cell =   (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getLfDesc2());
				
				
				cell =   (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWELVE);
				if(!PLMUtils.isEmpty(dataObj.getCrId2())){
					cell.setCellStyle(hyperLinkStyle);
					XSSFHyperlink url_link3 = helper.createHyperlink(Hyperlink.LINK_URL);
					url_link3.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getCrId2());
					cell.setHyperlink(url_link3);
					cell.setCellValue(dataObj.getCrNm2());
				}else{
					  cell.setCellStyle(cellStyle);
					  cell.setCellValue("");
				}

				cell =  (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getCrTitile2());
				
				cell =   (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
				if(!PLMUtils.isEmpty(dataObj.getCoId2())){
					cell.setCellStyle(hyperLinkStyle);
					XSSFHyperlink url_link4 = helper.createHyperlink(Hyperlink.LINK_URL);
					url_link4.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getCoId2());
					cell.setHyperlink(url_link4);
					cell.setCellValue(dataObj.getCoNm2());
				}else{
					  cell.setCellStyle(cellStyle);
					  cell.setCellValue("");
				}

				cell =  (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getPcName2());
				
				cell =   (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getCostGrp2());
				
				
				if(optFlag){
					
					cell =   (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getLfName3());
					
					
					cell =   (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_EIGHTEEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getLfRev3());
					
					cell =   (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_NINETEEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getLfDesc3());
					
					
					cell =   (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTY);
					if(!PLMUtils.isEmpty(dataObj.getCrId3())){
						cell.setCellStyle(hyperLinkStyle);
						XSSFHyperlink url_link5 = helper.createHyperlink(Hyperlink.LINK_URL);
						url_link5.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getCrId3());
						cell.setHyperlink(url_link5);
						cell.setCellValue(dataObj.getCrNm3());
					}else{
						cell.setCellStyle(cellStyle);
						 cell.setCellValue("");
					}
					
					cell =   (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYONE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getCrTitile3());
					
					cell =   (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYTWO);
					if(!PLMUtils.isEmpty(dataObj.getCoId3())){
						cell.setCellStyle(hyperLinkStyle);
						XSSFHyperlink url_link6 = helper.createHyperlink(Hyperlink.LINK_URL);
						url_link6.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getCoId3());
						cell.setHyperlink(url_link6);
						cell.setCellValue(dataObj.getCoNm3());
					}else{
						 cell.setCellStyle(cellStyle);
						 cell.setCellValue("");
					}
				
					cell =   (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWENTYTHREE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getPcName3());
					
					cell =   (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWENTYFOUR);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getCostGrp3());							
				}
				
			}
             	row = (SXSSFRow) sheet.createRow(++rowcount);
             	row = (SXSSFRow) sheet.createRow(++rowcount);
             	
             	
			    XSSFCellStyle ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
			    ftrStyle.setFont(font);
			    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
			    cell.setCellStyle(ftrStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_TWO));

				sheet.setColumnWidth(0,10*256);
				sheet.setColumnWidth(1,15*256);
				sheet.setColumnWidth(2,15*256);
				sheet.setColumnWidth(3,35*256);
				sheet.setColumnWidth(4,15*256);
				sheet.setColumnWidth(5,35*256);
				sheet.setColumnWidth(6,15*256);
				sheet.setColumnWidth(7,15*256);
				sheet.setColumnWidth(8,15*256);
				sheet.setColumnWidth(9,15*256);
				sheet.setColumnWidth(10,15*256);
				sheet.setColumnWidth(11,35*256);
				sheet.setColumnWidth(12,15*256);
				sheet.setColumnWidth(13,35*256);
				sheet.setColumnWidth(14,15*256);
				sheet.setColumnWidth(15,15*256);
				sheet.setColumnWidth(16,15*256);
				
				if(optFlag){
				 sheet.setColumnWidth(17,15*256);
				 sheet.setColumnWidth(18,15*256);
				 sheet.setColumnWidth(19,35*256);
				 sheet.setColumnWidth(20,15*256);
				 sheet.setColumnWidth(21,35*256);
				 sheet.setColumnWidth(22,15*256);
				 sheet.setColumnWidth(23,15*256);
				 sheet.setColumnWidth(24,15*256);
				}

			sheet.createFreezePane( 0, 2 );
            workbook.write(outputStream);
			
			outputStream.flush();
			
			outputStream.close();
			
		} catch (IOException ioex) {
			ioex.printStackTrace();
		} finally {
			facesContext.responseComplete();
	  	}
			LOG.info("Exiting downloadCRReport Method");
		
	} 	
	
	/**
	 * This method is used for PRS Report Generation
	 * 
	 * @return String
	 */
	public void generatePRSReport() throws PLMCommonException {

		LOG.info("Entering in to generatePRSReport");
		try {
			if (PLMUtils.isEmptyList(prsDataList)) {
				List<String> contractList = new ArrayList<String>();
				contractList.add(contract1);
				contractList.add(contract2);
				if (!PLMUtils.isEmpty(contract3)) {
					contractList.add(contract3);
				}
				prsDataList = plmCFCRPRSRptService.getPRSData(contractList, contract1, contract2, contract3);
			}
			cfTabFlag = false;
			crTabFlag = false;
			prsTabFlag = true;
			
			HttpServletRequest httpRequest = (HttpServletRequest) FacesContext
							.getCurrentInstance().getExternalContext().getRequest();
					
			PLMCntSmryOnScrnMB plmCntSmryOnScrnMB = (PLMCntSmryOnScrnMB) httpRequest.getSession()
							.getAttribute("plmCntSmryOnScrnMB");
			
			plmCntSmryOnScrnMB.setPrsRecFlag(false);
			plmCntSmryOnScrnMB.getPrsRecList().clear();
			
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@generateCRReport: ", exception);
			PLMUtils.setCommonException(exception.getMessage(), commonMB, "cfcrprsSearch", "CF/CR/PRS Comparison Report");
			throw exception;
		}
		LOG.info("Exiting in to generatePRSReport");
	}
	
	/**
	 * This method is used for download Excel sheet for PRS report
	 * 
	 */
	public void downloadPRSReport() throws PLMCommonException {
		LOG.info("Entering downloadPRSReport Method");
		FacesContext facesContext = FacesContext.getCurrentInstance();
	  	try {
			HttpServletResponse response = 
				(HttpServletResponse)facesContext.getExternalContext().getResponse();
			
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			
			response.setHeader("Content-disposition", 
					"attachment; filename="+"PRS Compare.xlsx");
			
			OutputStream outputStream = response.getOutputStream();
			
			SXSSFWorkbook workbook = new SXSSFWorkbook();
			
			XSSFFont font = headerFont(workbook, 10);
			
			// Header Style
			XSSFCellStyle headerStyle = headerCell(workbook, font, HSSFColor.PALE_BLUE.index, true);

			XSSFFont cellfont = normalFont(workbook, 10);
			// Cell Style
			XSSFCellStyle cellStyle = normalCell(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
			
			// cell hyper link
			XSSFCreationHelper helper= (XSSFCreationHelper) workbook.getCreationHelper();
			
		    XSSFFont underLinedFont = (XSSFFont) workbook.createFont();
	        underLinedFont.setUnderline(HSSFFont.U_SINGLE);
	        underLinedFont.setColor(IndexedColors.BLUE.getIndex());
			XSSFCellStyle hyperLinkStyle = (XSSFCellStyle) workbook.createCellStyle();				
			hyperLinkStyle = setBorderStyle(hyperLinkStyle);
			hyperLinkStyle.setFont(underLinedFont);
			
			SXSSFSheet sheet = (SXSSFSheet) workbook.createSheet("PRS Compare");
			
			int rowcount = 0;
			
			SXSSFCell cell=null;
		    
		    SXSSFRow row = (SXSSFRow) sheet.createRow(rowcount);
            	
			
        	   cell = (SXSSFCell) row.createCell(0);
				 cell.setCellStyle(headerStyle);
				 cell.setCellValue(contract1);
				 
				 cell = (SXSSFCell) row.createCell(1);
				 cell.setCellStyle(headerStyle);
				 cell.setCellValue(contract2);
				 
				  if(optFlag){
					cell = (SXSSFCell) row.createCell(2);
	 				cell.setCellStyle(headerStyle);
	 				cell.setCellValue(contract3); 
				 }
        	
				for(int i=0;i<prsDataList.size();i++){
				
					PLMCFCRPRSRptData dataObj = (PLMCFCRPRSRptData) prsDataList.get(i);
					
					row = (SXSSFRow) sheet.createRow(++rowcount);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
					if(!PLMUtils.isEmpty(dataObj.getPrsId1())){
						cell.setCellStyle(hyperLinkStyle);
						XSSFHyperlink url_link1 = helper.createHyperlink(Hyperlink.LINK_URL);
						url_link1.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getPrsId1());
						cell.setHyperlink(url_link1);
						cell.setCellValue(dataObj.getPrsName1());
					}else{
						cell.setCellStyle(cellStyle);
						 cell.setCellValue("");
					}
					
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
					if(!PLMUtils.isEmpty(dataObj.getPrsId2())){
						cell.setCellStyle(hyperLinkStyle);
						XSSFHyperlink url_link2 = helper.createHyperlink(Hyperlink.LINK_URL);
						url_link2.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getPrsId2());
						cell.setHyperlink(url_link2);
						cell.setCellValue(dataObj.getPrsName2());
					}else{
						cell.setCellStyle(cellStyle);
						 cell.setCellValue("");
					}
					
					if(optFlag){
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
						if(!PLMUtils.isEmpty(dataObj.getPrsId3())){
							cell.setCellStyle(hyperLinkStyle);
							XSSFHyperlink url_link3 = helper.createHyperlink(Hyperlink.LINK_URL);
							url_link3.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getPrsId3());
							cell.setHyperlink(url_link3);
							cell.setCellValue(dataObj.getPrsName3());
						}else{
							cell.setCellStyle(cellStyle);
							 cell.setCellValue("");
						}
					}
		  	   }
			
             	row = (SXSSFRow) sheet.createRow(++rowcount);
             	row = (SXSSFRow) sheet.createRow(++rowcount);
             	
			    XSSFCellStyle ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
			    ftrStyle.setFont(font);
			    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
			    cell.setCellStyle(ftrStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_TWO));

				sheet.setColumnWidth(0,15*256);
				sheet.setColumnWidth(1,15*256);
				if(optFlag){
				 sheet.setColumnWidth(2,15*256);
				}
			
            workbook.write(outputStream);
			
			outputStream.flush();
			
			outputStream.close();
			
		} catch (IOException ioex) {
			ioex.printStackTrace();
		} finally {
			facesContext.responseComplete();
	  	}
	  	LOG.info("Exiting downloadPRSReport Method");
	} 	
	/**
	 * @return the plmCFCRPRSRptService
	 */
	public PLMCFCRPRSRptServiceIfc getPlmCFCRPRSRptService() {
		return plmCFCRPRSRptService;
	}
	/**
	 * @param plmCFCRPRSRptService the plmCFCRPRSRptService to set
	 */
	public void setPlmCFCRPRSRptService(PLMCFCRPRSRptServiceIfc plmCFCRPRSRptService) {
		this.plmCFCRPRSRptService = plmCFCRPRSRptService;
	}
	/**
	 * @return the alertMsgCFCRS
	 */
	public String getAlertMsgCFCRS() {
		return alertMsgCFCRS;
	}
	/**
	 * @param alertMsgCFCRS the alertMsgCFCRS to set
	 */
	public void setAlertMsgCFCRS(String alertMsgCFCRS) {
		this.alertMsgCFCRS = alertMsgCFCRS;
	}
	/**
	 * @return the contract1
	 */
	public String getContract1() {
		return contract1;
	}
	/**
	 * @param contract1 the contract1 to set
	 */
	public void setContract1(String contract1) {
		this.contract1 = contract1;
	}

	/**
	 * @return the contract2
	 */
	public String getContract2() {
		return contract2;
	}
	/**
	 * @param contract2 the contract2 to set
	 */
	public void setContract2(String contract2) {
		this.contract2 = contract2;
	}
	/**
	 * @return the contract3
	 */
	public String getContract3() {
		return contract3;
	}
	/**
	 * @param contract3 the contract3 to set
	 */
	public void setContract3(String contract3) {
		this.contract3 = contract3;
	}
	/**
	 * @return the minFlag
	 */
	public boolean isMinFlag() {
		return minFlag;
	}
	/**
	 * @param minFlag the minFlag to set
	 */
	public void setMinFlag(boolean minFlag) {
		this.minFlag = minFlag;
	}
	/**
	 * @return the optFlag
	 */
	public boolean isOptFlag() {
		return optFlag;
	}
	/**
	 * @param optFlag the optFlag to set
	 */
	public void setOptFlag(boolean optFlag) {
		this.optFlag = optFlag;
	}

	/**
	 * @return the selCstGrpList1
	 */
	public List<String> getSelCstGrpList1() {
		return selCstGrpList1;
	}

	/**
	 * @param selCstGrpList1 the selCstGrpList1 to set
	 */
	public void setSelCstGrpList1(List<String> selCstGrpList1) {
		this.selCstGrpList1 = selCstGrpList1;
	}

	/**
	 * @return the selCstGrpList2
	 */
	public List<String> getSelCstGrpList2() {
		return selCstGrpList2;
	}

	/**
	 * @param selCstGrpList2 the selCstGrpList2 to set
	 */
	public void setSelCstGrpList2(List<String> selCstGrpList2) {
		this.selCstGrpList2 = selCstGrpList2;
	}

	/**
	 * @return the selCstGrpList3
	 */
	public List<String> getSelCstGrpList3() {
		return selCstGrpList3;
	}

	/**
	 * @param selCstGrpList3 the selCstGrpList3 to set
	 */
	public void setSelCstGrpList3(List<String> selCstGrpList3) {
		this.selCstGrpList3 = selCstGrpList3;
	}

	/**
	 * @return the cstGrpList1
	 */
	public List<SelectItem> getCstGrpList1() {
		return cstGrpList1;
	}

	/**
	 * @param cstGrpList1 the cstGrpList1 to set
	 */
	public void setCstGrpList1(List<SelectItem> cstGrpList1) {
		this.cstGrpList1 = cstGrpList1;
	}

	/**
	 * @return the cstGrpList2
	 */
	public List<SelectItem> getCstGrpList2() {
		return cstGrpList2;
	}

	/**
	 * @param cstGrpList2 the cstGrpList2 to set
	 */
	public void setCstGrpList2(List<SelectItem> cstGrpList2) {
		this.cstGrpList2 = cstGrpList2;
	}

	/**
	 * @return the cstGrpList3
	 */
	public List<SelectItem> getCstGrpList3() {
		return cstGrpList3;
	}

	/**
	 * @param cstGrpList3 the cstGrpList3 to set
	 */
	public void setCstGrpList3(List<SelectItem> cstGrpList3) {
		this.cstGrpList3 = cstGrpList3;
	}

	/**
	 * @return the selPcName1
	 */
	public String getSelPcName1() {
		return selPcName1;
	}

	/**
	 * @param selPcName1 the selPcName1 to set
	 */
	public void setSelPcName1(String selPcName1) {
		this.selPcName1 = selPcName1;
	}

	/**
	 * @return the selPcName2
	 */
	public String getSelPcName2() {
		return selPcName2;
	}

	/**
	 * @param selPcName2 the selPcName2 to set
	 */
	public void setSelPcName2(String selPcName2) {
		this.selPcName2 = selPcName2;
	}

	/**
	 * @return the selPcName3
	 */
	public String getSelPcName3() {
		return selPcName3;
	}

	/**
	 * @param selPcName3 the selPcName3 to set
	 */
	public void setSelPcName3(String selPcName3) {
		this.selPcName3 = selPcName3;
	}

	/**
	 * @return the pcDesc1
	 */
	public String getPcDesc1() {
		return pcDesc1;
	}

	/**
	 * @param pcDesc1 the pcDesc1 to set
	 */
	public void setPcDesc1(String pcDesc1) {
		this.pcDesc1 = pcDesc1;
	}

	/**
	 * @return the pcDesc2
	 */
	public String getPcDesc2() {
		return pcDesc2;
	}

	/**
	 * @param pcDesc2 the pcDesc2 to set
	 */
	public void setPcDesc2(String pcDesc2) {
		this.pcDesc2 = pcDesc2;
	}

	/**
	 * @return the pcDesc3
	 */
	public String getPcDesc3() {
		return pcDesc3;
	}

	/**
	 * @param pcDesc3 the pcDesc3 to set
	 */
	public void setPcDesc3(String pcDesc3) {
		this.pcDesc3 = pcDesc3;
	}

	/**
	 * @return the pcInfoList1
	 */
	public List<SelectItem> getPcInfoList1() {
		return pcInfoList1;
	}

	/**
	 * @param pcInfoList1 the pcInfoList1 to set
	 */
	public void setPcInfoList1(List<SelectItem> pcInfoList1) {
		this.pcInfoList1 = pcInfoList1;
	}

	/**
	 * @return the pcInfoList2
	 */
	public List<SelectItem> getPcInfoList2() {
		return pcInfoList2;
	}

	/**
	 * @param pcInfoList2 the pcInfoList2 to set
	 */
	public void setPcInfoList2(List<SelectItem> pcInfoList2) {
		this.pcInfoList2 = pcInfoList2;
	}

	/**
	 * @return the pcInfoList3
	 */
	public List<SelectItem> getPcInfoList3() {
		return pcInfoList3;
	}

	/**
	 * @param pcInfoList3 the pcInfoList3 to set
	 */
	public void setPcInfoList3(List<SelectItem> pcInfoList3) {
		this.pcInfoList3 = pcInfoList3;
	}

	/**
	 * @return the cfDataList
	 */
	public List<PLMCFCRPRSRptData> getCfDataList() {
		return cfDataList;
	}

	/**
	 * @param cfDataList the cfDataList to set
	 */
	public void setCfDataList(List<PLMCFCRPRSRptData> cfDataList) {
		this.cfDataList = cfDataList;
	}
	/**
	 * @return the crDataList
	 */
	public List<PLMCFCRPRSRptData> getCrDataList() {
		return crDataList;
	}

	/**
	 * @param cfDataList the cfDataList to set
	 */
	public void setCrDataList(List<PLMCFCRPRSRptData> crDataList) {
		this.crDataList = crDataList;
	}

	/**
	 * @return the prsDataList
	 */
	public List<PLMCFCRPRSRptData> getPrsDataList() {
		return prsDataList;
	}

	/**
	 * @param prsDataList the prsDataList to set
	 */
	public void setPrsDataList(List<PLMCFCRPRSRptData> prsDataList) {
		this.prsDataList = prsDataList;
	}
	/**
	 * @return the cfTabFlag
	 */
	public boolean isCfTabFlag() {
		return cfTabFlag;
	}
	/**
	 * @param cfTabFlag the cfTabFlag to set
	 */
	public void setCfTabFlag(boolean cfTabFlag) {
		this.cfTabFlag = cfTabFlag;
	}
	/**
	 * @return the crTabFlag
	 */
	public boolean isCrTabFlag() {
		return crTabFlag;
	}
	/**
	 * @param crTabFlag the crTabFlag to set
	 */
	public void setCrTabFlag(boolean crTabFlag) {
		this.crTabFlag = crTabFlag;
	}
	/**
	 * @return the prsTabFlag
	 */
	public boolean isPrsTabFlag() {
		return prsTabFlag;
	}
	/**
	 * @param prsTabFlag the prsTabFlag to set
	 */
	public void setPrsTabFlag(boolean prsTabFlag) {
		this.prsTabFlag = prsTabFlag;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB
	 *            the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
}
