 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMPddrMB.java
 * @Creation date: 22-May-2014
 * @version 3.0.0
 * @author : Tech Mahindra (PLMR Team) 
 */

package com.geinfra.geaviation.pwi.bean;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;
import java.util.Set;

import javax.faces.application.FacesMessage;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.context.FacesContext;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.richfaces.component.UITree;
import org.richfaces.component.html.HtmlTree;
import org.richfaces.event.NodeExpandedEvent;
import org.richfaces.event.NodeSelectedEvent;
import org.richfaces.model.TreeNode;
import org.richfaces.model.TreeNodeImpl;
import org.richfaces.model.TreeRowKey;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.data.PLMPddrData;
import com.geinfra.geaviation.pwi.data.PLMPddrSearchData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMPddrServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

/**
 * PLMPddrMB is the managed bean class used for Fetch/Load SBoM and Add/Update
 * SBoM.
 */
public class PLMPddrMB  {
	/**
	 * Holds the Logger
	 */
	private static final Logger LOG = Logger.getLogger(PLMPddrMB.class);
	
	/**
	 * Holds the pddrData
	 */
	private PLMPddrData pddrData = null;
	
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	
	/**
	 * The List<String> searchResults.
	 */
	private List<String> searchResults = new ArrayList<String>();
	/**
	 * The List<PLMPddrSearchData> searchResults.
	 */
	private List<PLMPddrSearchData> searchExpResults = new ArrayList<PLMPddrSearchData>();
	/**
	 * The boolean partChildTable
	 */
	private boolean partChildTable;
	/**
	 * The List<PLMPddrData> sbomData
	 */
	private List<PLMPddrData> sbomData = new ArrayList<PLMPddrData>();
	
	/**
	 * The List<ICMSBoMAddIemData> Header Data
	 */
	private PLMPddrSearchData sbomHeaderData = new PLMPddrSearchData();
	/**
	 * The String searchString.
	 */
	private String searchString;
	/**
	 * The String searchString.
	 */
	private String searchSerialString;
	/**
	 * The String alertMsg.
	 */
	private String alertMsgPddr;
	/**
	 * The String resultHeader.
	 */
	private boolean resultHeader;
	/**
	 * The String mplNumber.
	 */
	private String mplNumber;
	/**
	 * The String resultCount.
	 */
	private int resultCount;
	/**
	 * The String toGetPopup.
	 */
	private int toGetPopup;
	/**
	 * The String prdStcres.
	 */
	private int prdStcres;
	/**
	 * The String treeLoad.
	 */
	private int treeLoad;
	/**
	 * The String selectedMPLNo.
	 */
	private String selectedMPLNo;
	/**
	 * The PLMPddrServiceIfc PLMPddrServiceIfc.
	 */
	private PLMPddrServiceIfc plmPddrServiceIfc = null;
	/**
	 * The PLMPddrData addItem.
	 */
	private PLMPddrData addItem = new PLMPddrData();
	/**
	 * The boolean publisEnable.
	 */
	private boolean publisEnable;

	/**
	 * The String confirmAlertMsg.
	 */
	private String confirmAlertMsg;
	/**
	 * The String saveSuccessMsg.
	 */
	private String saveSuccessMsg;
	/**
	 * The String selectedPF.
	 */
	private String selectedPF;
	/**
	 * The boolean read.
	 */
	private boolean read;
	/**
	 * The boolean write.	 */
	private boolean write;
	/**
	 * The int scrollerPage.
	 */
	private int scrollerPage;
	/**
	 * Holds the selectedNodeChildren
	 */
	private List<PLMPddrData> selectedNodeChildren = new ArrayList<PLMPddrData>();
	/**
	 * Holds the nodeTitle
	 */
	private String nodeTitle;
	/**
	 * Holds the htmlTree
	 */
	private HtmlTree htmlTree = new HtmlTree();
	/**
	 * Holds the rootNode
	 */
	private TreeNode<PLMPddrData> rootNode;
	/**
	 * Holds the currentNode
	 */
	private TreeNode<PLMPddrData> currentNode;
	/**
	 * Holds the isCollapse
	 */
	private boolean isCollapse;
	/**
	 * Holds the panelGrid
	 */
	private HtmlPanelGrid panelGrid;
	/**
	 * Holds the showDetails
	 */
	private boolean showDetails;
	/**
	 * Holds the gettingDetails
	 */
	private boolean gettingDetails;
	/**
	 * Holds the showNewAdd
	 */
	private boolean showNewAdd;
	/**
	 * Holds the showAddButton
	 */
	private boolean showAddButton;
	/**
	 * Holds the showSBOMExplorerUpdate
	 */
	private boolean showSBOMExplorerUpdate;
	/**
	 * Holds the selectedLevel
	 */
	private int selectedLevel;
	/**
	 * Holds the selectedId
	 */
	private int selectedId;
	/**
	 * Holds the topLevelItem
	 */
	private String topLevelItem;
	/**
	 * Holds the parentItem
	 */
	private String parentItem;
	@SuppressWarnings("unchecked")
	/**
	 * Holds the selectedNode
	 */
	private TreeNode selectedNode;
	/**
	 * Holds the fromSBoMId
	 */
	private String fromSBoMId;
	/**
	 * Holds the srcType
	 */
	private String srcType;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_15;
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the itemFilterEffStDT
	 */
	private Date itemFilterEffStDT;
	/**
	 * Holds the prefixFilter
	 */
	private String prefixFilter;
	/**
	 * Holds the partNumberFilter
	 */
	private String partNumberFilter;
	/**
	 * Holds the ecnFilter
	 */
	private String ecnFilter;
	/**
	 * Holds the filterString
	 */
	private int filterString = PLMConstants.N_0;
    /**
	 * The ThreadPoolTaskExecutor taskExecutor.
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	
	/**
	 * The boolean exportFlag.
	 */
	private boolean exportFlag;
	/**
	 * Holds the secondLevelFilteredNodes
	 */
	private Map<String,String> secondLevelFilteredNodes = new HashMap<String,String>();
	
	/**
	 * The boolean buttonFlag
	 */
	private boolean buttonFlag;
	//private Map<String,List<String>> folderMap = null; 
	
	/**
	 * Holds user information
	 */
	private PLMPwiUserData userDetails = null;
	
	/*private PLMLoginData userDataObj = (PLMLoginData) PLMUtils
	.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA);*/

	/**
	 * This is method is used for exploreSbom
	 * 
	 * @return string
	 */
	public String exploreSbom() {
		LOG.info("exploreSbom");
		resetMB();
		searchString = null;
		searchSerialString = null;
		read = false;
		write = false;
		showDetails = false;
		showNewAdd = false;
		showAddButton = false;
		showSBOMExplorerUpdate = false;
		gettingDetails = false;
		searchItemsExplore();
		return "exploresbom";
	}

	/**
	 * This is method is used for resetMB
	 * 
	 */
	private void resetMB() {
		htmlTree = null;
		rootNode = null;
		searchResults.clear();
		searchExpResults.clear();
		sbomData.clear();
		partChildTable = false;
		selectedMPLNo = PLMConstants.EMPTY_STRING;
		alertMsgPddr = PLMConstants.EMPTY_STRING;
		alertMessage = PLMConstants.EMPTY_STRING;
		saveSuccessMsg = PLMConstants.EMPTY_STRING;
		confirmAlertMsg = PLMConstants.EMPTY_STRING;
		setSelectedPF(null);
		resultCount = 0;
		nodeTitle = null;
		selectedId = 0;
		selectedLevel = 0;
		toGetPopup = 0;
		prdStcres = 0;
		treeLoad = 0;
		fromSBoMId = "";
		buttonFlag = true;
		setPFDetails();
	}
	/**
	 * This is method is used for setPFDetails
	 * 
	 */
	private void setPFDetails() {
		LOG.info("setPFDetails");
		addItem = new PLMPddrData();
		addItem.setPartFamily("-");
		addItem.setPartDesc("-");
		addItem.setPartState("-");
		addItem.setPartOwnerSso("-");
		addItem.setPartOwnerName("-");
		addItem.setPartBaseNum("-");
		addItem.setPartRDO("-");
		addItem.setPartSrcOrgDate("-");
		addItem.setPartSrcModDate("-");
		addItem.setPartEEDWUpdateDate("-");
	}
	/**
	 * This is method is used for searchItemsExplore
	 * 
	 * @return string
	 */
	public String searchItemsExplore() {
		String returnStr = PLMConstants.EMPTY_STRING;
		try {
			commonMB.insertCannedRptRecordHitInfo("Part Family Explorer");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			LOG.info("Entering searchItemsExplore() method----PLMPddrMB---");
			scrollerPage = PLMConstants.N_1;
			resetMB();
			showDetails = false;
			showNewAdd = false;
			showAddButton = false;
			showSBOMExplorerUpdate = false;
			resultHeader = false;
			resultCount = 0;
			toGetPopup = 0;
			prdStcres = 0;
			treeLoad = 0;
				alertMsgPddr = PLMConstants.NOO;
				alertMessage = PLMConstants.EMPTY_STRING;
				searchExpResults = plmPddrServiceIfc.searchItemExplorer();
				if (searchExpResults != null && searchExpResults.size() > 0) {
					LOG.info("Records Found " + searchExpResults.size());
					exportFlag = true;
					resultHeader = true;
					resultCount = searchExpResults.size();
					if (resultCount == 1) {
						if (!"NOT-AVAILABLE".equals(searchExpResults.get(0)
								.getMplMLnumberHD())) {
							selectedMPLNo = searchExpResults.get(0)
							.getLibraryName();
							checkProductStruct();
						} else {
							toGetPopup = 4;
							resultHeader = false;
							exportFlag = false;
						}
					} else {
						toGetPopup = 2;
					}
				} else {
					LOG.info("No Records Found");
					toGetPopup = 3;
					resultHeader = false;
					exportFlag = false;
				}
				returnStr = "exploresbom";
		} catch (PLMCommonException ce) {
			
			LOG.log(Level.ERROR, "searchItemsExplore" + ce.getMessage());
			returnStr = PLMConstants.ERROR;
		} catch (Exception ce) {
			
			LOG.log(Level.ERROR, "searchItemsExplore" + ce.getMessage());
			returnStr = PLMConstants.ERROR;
		}
		LOG.info("Exiting searchItemsExplore() method----PLMPddrMB---");
		return returnStr;
	}

	/**
	 * This is method is used for checkProductStruct
	 * 
	 * @return string
	 */
	public String checkProductStruct() {
		String returnStr = PLMConstants.EMPTY_STRING;
		LOG.info("Entering checkProductStruct() method----PLMPddrMB---");
		try {
			scrollerPage = PLMConstants.N_1;
			toGetPopup = 0;
			prdStcres = 0;
			treeLoad = 0;
			sbomData.clear();
			alertMsgPddr = PLMConstants.EMPTY_STRING;
			searchResults.clear();
			searchResults.add(selectedMPLNo);
			prdStcres = 2;
			treeLoad = 11;
		} catch (Exception ce) {
			LOG.log(Level.ERROR, "checkProductStruct" + ce.getMessage());
			returnStr = PLMConstants.ERROR;
		}
		LOG.info("Exiting checkProductStruct() method----PLMPddrMB---");
		return returnStr;
	}

	/**
	 * This is method is used for getItemDetailsExplore
	 * 
	 * @return string
	 */
	public String getItemDetailsExplore() {
		String returnStr = PLMConstants.EMPTY_STRING;
		try {
			LOG.info("Entering getItemDetailsExplore() method----PLMPddrMB---");
			scrollerPage = PLMConstants.N_1;
			toGetPopup = 0;
			prdStcres = 0;
			treeLoad = 0;
			sbomData.clear();
			prefixFilter = null;
			partNumberFilter = null; 
			ecnFilter = null; 
			itemFilterEffStDT = null;
			alertMsgPddr = PLMConstants.EMPTY_STRING;
			if (selectedMPLNo != null
					&& !PLMConstants.EMPTY_STRING
							.equalsIgnoreCase(selectedMPLNo.trim())) {
					partChildTable = true;
					loadTree();
					prdStcres = 2;
			} else {
				partChildTable = false;
			}

		} catch (Exception ce) {
			LOG.log(Level.ERROR, "getItemDetailsExplore" + ce.getMessage());
			returnStr = PLMConstants.ERROR;
		}
		LOG.info("Exiting getItemDetailsExplore() method----PLMPddrMB---");
		return returnStr;
	}
	/**
	 * This is method is used for refreshSearch
	 * 
	 * @return string
	 */
	public String refreshSearch() {
        String returnStr = PLMConstants.EMPTY_STRING;
		return returnStr;
	}

	/**
	 * This is method is used for treeNodeExpand
	 * 
	 */
	public void treeNodeExpand() {
		LOG.info(" ***** INSIDE treeNodeExpand METHOD ***** ");
		isCollapse = true;
	}

	/**
	 * collapse tree
	 */
	public void treeNodeCollapse() {
		LOG.info(" **** INSIDE treeNodeCollapse METHOD ***** ");
		isCollapse = false;
	}

	/**
	 * load tree
	 */
	@SuppressWarnings("unchecked")
	public void loadTree() {
		try {
			LOG.info("Entering loadTree() method----PLMPddrMB---");
			LOG.info("Tree will load");
			filterString = PLMConstants.N_0;
			fromSBoMId = "";
			toGetPopup = 0;
			treeLoad = 0;
			TreeNode mainNode = null;
			PLMPddrData treeNodeData = null;
			PLMPddrData navigatorData = null;
			Iterator itr = null;
			Object dataObject = null;
			PLMPddrData tempTreeNodeData = null;
			Iterator itr1 = null;

			panelGrid = new HtmlPanelGrid();
			panelGrid.setColumns(0);

			rootNode = new TreeNodeImpl();
			htmlTree.setData(null);
			htmlTree.setIgnoreDupResponses(true);
			htmlTree.setValue(new TreeNodeImpl());
			List childrenList = null;
			nodeTitle = "";
			/* adding top level parent */
			PLMPddrData parentData = null;
			List<PLMPddrData> parentNodes = new ArrayList<PLMPddrData>();
//			parentNodes = new ArrayList<PLMPddrData>();

			for (String data : searchResults) {
				parentData = new PLMPddrData();
				parentData.setParentItem(data);
				parentData.setLevel(1);
				parentData.setChildInd(PLMConstants.YES);
				parentData.setTopLevelParentItem(data);
				parentData.setDescription("");
				parentNodes.add(parentData);
			}
			/* added */
			/* parentNodes.add(parentData); */
			HashMap childrenMap = plmPddrServiceIfc.getChildForParent(
					searchResults, "1");
			if (parentNodes != null) {
				itr = parentNodes.iterator();
				while (itr.hasNext()) {
					treeNodeData = new PLMPddrData();
					mainNode = new TreeNodeImpl();
					navigatorData = (PLMPddrData) itr.next();
					if (navigatorData != null) {
						PLMUtils.copyProperties(navigatorData, treeNodeData);
						treeNodeData.setType("node");
						mainNode.setData(treeNodeData);
					}
					childrenList = (List) childrenMap.get(treeNodeData
							.getParentItem());
					if (!PLMUtils.isEmptyList(childrenList)) {
						itr1 = childrenList.iterator();
						while (itr1.hasNext()) {
							dataObject = itr1.next();
							tempTreeNodeData = (PLMPddrData) ((TreeNode) dataObject)
									.getData();
							tempTreeNodeData.setType("node");
							mainNode.addChild(tempTreeNodeData.getParentItem(),
									(TreeNode) dataObject);
						}
					}
					rootNode.addChild(treeNodeData.getParentItem(), mainNode);
				}
				htmlTree.setValue(rootNode);
				setTheTreeForView();
				currentNode = rootNode;
				collapseOtherTree(htmlTree, mainNode);
				expandLevelOne(searchResults);
			}
		} catch (PLMCommonException e) {
			LOG.log(Level.ERROR, "Exception[loadTree]:" + e.getMessage());
		} catch (Exception e) {
			LOG.log(Level.ERROR, "Exception[loadTree]:" + e.getMessage());
		}
		LOG.info("Exiting loadTree() method----PLMPddrMB---");
	}
	
	/**
	 * expandLevelOne
	 * 
	 * @param nodeId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public TreeNode expandLevelOne(List<String> nodeId) {
		LOG.info(" *************** INSIDE expandLevelOne METHOD ******************* ");
		TreeNode mainTreeNode = null;
		Iterator mainNodeItr = null;
		Entry abc = null;
		TreeNode childNode = null;
		TreeRowKey treeRowKey = null;
		int level = 1;
		String nodeStr = null;
		try {
			mainTreeNode = currentNode;
			if (currentNode != null) {
				mainNodeItr = mainTreeNode.getChildren();
				while (mainNodeItr.hasNext()) {
					abc = (Entry) mainNodeItr.next();
					childNode = (TreeNodeImpl) abc.getValue();
					treeRowKey = (TreeRowKey) htmlTree
							.getTreeNodeRowKey(childNode);
					nodeStr = treeRowKey.toString();
					for (String data : nodeId) {
						if (data.equals(extractLastNodeId(nodeStr))) {
							currentNode = childNode;
							generateTreeNodeChildren(currentNode, false,
									level + 1, data);
							// collapseOtherTreeFrmExtrnl(currentNode);
							expandNode(treeRowKey);
							return childNode;
						}
					}
				}
			}
		} catch (PLMCommonException eobj) {
			LOG.error("ICMMessage[expandLevelOne]:" + eobj.getMessage());
		} catch (Exception eobj) {
			LOG.error("Exception[expandLevelOne]:" + eobj.getMessage());
		}
		return null;
	}

	/**
	 * setTheTreeForView
	 * 
	 * @return int
	 */
	@SuppressWarnings("unchecked")
	public int setTheTreeForView() {
		LOG.info(" --> Set the Tree for view Starts<-- ");
		TreeNode tempNode = null;
		tempNode = new TreeNodeImpl();
		int size = 0;
		Iterator abc = null;
		abc = rootNode.getChildren();
		while (abc.hasNext()) {
			size++;
			Entry ax = (Entry) abc.next();
			TreeNode childNode = (TreeNodeImpl) ax.getValue();
			PLMPddrData nodeData = (PLMPddrData) childNode.getData();
			tempNode.addChild(nodeData.getParentItem(), childNode);
		}
		htmlTree.setValue(tempNode);
		LOG.info(" $$$ Count: " + size);
		LOG.info(" --> Set the Tree for view Ends <-- ");

		return size;
	}
	
	/**
	 * updateTreeHighlight
	 * 
	 */
	@SuppressWarnings("unchecked")
	public void updateTreeHighlight(TreeNode node) {
		Iterator abc = null;
		abc = node.getChildren();
		while (abc.hasNext()) {			
			Entry ax = (Entry) abc.next();
			TreeNode childNode = (TreeNodeImpl) ax.getValue();
			((PLMPddrData)childNode.getData()).setNodeHighlightFlag(false);
			updateTreeHighlight(childNode);
		}
	}

	/**
	 * changeNode
	 * 
	 * @param event
	 */
	@SuppressWarnings("unchecked")
	public void changeNode(NodeExpandedEvent event) {
		LOG.info(" ---> changeNode(NodeExpandedEvent) Starts <--- ");
		UITree tree = null;
		TreeNode<PLMPddrData> treeNodeInner = null;
		PLMPddrData treeDataObj = null;
		String currentExpandedFolderId = "";
		String topLevelItemInner = "";
		alertMessage = PLMConstants.EMPTY_STRING;
		alertMsgPddr = PLMConstants.EMPTY_STRING;
		try {
			tree = (UITree) event.getComponent();
			treeNodeInner = tree.getTreeNode();
			if (treeNodeInner != null) {
				treeDataObj = treeNodeInner.getData();
				if (treeDataObj != null) {
					currentExpandedFolderId = treeDataObj.getParentItem();
					topLevelItemInner = treeDataObj.getTopLevelParentItem();
					fromSBoMId = treeDataObj.getSbomID() + "";
				}
			}
			TreeRowKey treeRowKey = null;
			treeRowKey = (TreeRowKey) htmlTree
			.getTreeNodeRowKey(tree.getTreeNode());
			LOG.info("currentExpandedFolderId  " + currentExpandedFolderId);
			LOG.info("topLevelItem  " + topLevelItemInner);
			collapseOtherTree(htmlTree, tree.getTreeNode());
			if (treeDataObj != null) {
				addNodeWithChildrenToGivenNode(treeNodeInner,
						currentExpandedFolderId, topLevelItemInner);
			}
			expandNode(treeRowKey);
		} catch (Exception eobj) {
			eobj.printStackTrace();
			LOG.error("Exception[changeNode]:" + eobj.getMessage());
		}
		LOG.info(" ---> changeNode(NodeExpandedEvent) Ends <--- ");
	}

	/**
	 * 
	 * addNodeWithChildrenToGivenNode
	 * 
	 * @param givenNode
	 * @param currentNodeParam
	 * @param topLevelItemParam
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public void addNodeWithChildrenToGivenNode(TreeNode<PLMPddrData> givenNode,
			String currentNodeParam, String topLevelItemParam) throws Exception {
		LOG.info(" --> addNodeWithChildrenToGivenNode METHOD Starts <--");
		PLMPddrData navigData = null;
		PLMPddrData givenTreeNodeData = null;
		Entry entry = null;
		@SuppressWarnings("unused")
		TreeNode childNode = null;
		List<PLMPddrData> navigList = null;
		HashMap childrenMap = null;
		List childrenList = null;
		Map<String, PLMPddrData> childSeqs = null;
		Set<String> allSeqs = null;
		Set<String> moreFolderSeqs = null;
		navigData = new PLMPddrData();
		childSeqs = new LinkedHashMap<String, PLMPddrData>();
		moreFolderSeqs = new HashSet<String>();
		//String effectivityDate = null;
		int level = 0;

		if (givenNode != null) {
			givenTreeNodeData = givenNode.getData();

			if (givenTreeNodeData != null) {
				level = givenTreeNodeData.getLevel();
				givenNode.setData(givenTreeNodeData);
				PLMUtils.copyProperties(givenTreeNodeData, navigData);
			}

			allSeqs = new HashSet<String>();
			navigList = new ArrayList<PLMPddrData>();

			navigList.add(navigData);
			int levl = navigData.getLevel();
			LOG.info("levl------->" + levl);
			String clickedNode = navigData.getParentItem();
			LOG.info("clickedNode------->" + clickedNode);
			//String nodeTitle = navigData.getParentItem();
			LOG.info("nodeTitle------->" + navigData.getParentItem());
			int levelNodeClick = navigData.getLevel();
			LOG.info("levelNodeClick------->" + levelNodeClick);
			Iterator childItr = givenNode.getChildren();
			while (childItr.hasNext()) {
				entry = (Entry) childItr.next();
				TreeNode tttNode = (TreeNode) entry.getValue();
				PLMPddrData tttNodeData = (PLMPddrData) tttNode.getData();
				PLMPddrData tempNavData = new PLMPddrData();
				PLMUtils.copyProperties(tttNodeData, tempNavData);
				childSeqs.put(tttNodeData.getParentItem(), tempNavData);
				moreFolderSeqs.add(tttNodeData.getParentItem());
				
			}
			/**
			 * Get the siblings of the clicked node or the children of parent of
			 * clicked node
			 */
			LOG.info("---> Get Children for Clicked Node folders Starts <---");
			
			if ((filterString == PLMConstants.N_0)|| (filterString == PLMConstants.N_1))
			{
			childrenMap = plmPddrServiceIfc.getChildForParentList(
					topLevelItemParam, navigList, level);
			LOG.info("---> Get Children for Clicked Node folders Ends <---");
			LOG.info("isCollpase >>  " + isCollapse);
			if (isCollapse) {
				childrenList = (List) childrenMap
						.get(navigData.getParentItem());
				if (childrenList == null) {
					childrenList = new ArrayList();
				}
				List<PLMPddrData> childrenNavList = new ArrayList<PLMPddrData>();

				Iterator childNodeItr = childrenList.iterator();
				while (childNodeItr.hasNext()) {
					Object dataObject = childNodeItr.next();
					PLMPddrData tempTreeNodeData = null;
					tempTreeNodeData = (PLMPddrData) ((TreeNode) dataObject)
							.getData();

					PLMPddrData navigatorDataObj = new PLMPddrData();
					PLMUtils.copyProperties(tempTreeNodeData, navigatorDataObj);
					childrenNavList.add(navigatorDataObj);
					allSeqs.add(navigatorDataObj.getParentItem());
				}
				/** Add the children to the given node */
				List<PLMPddrData> navigatorList = new ArrayList<PLMPddrData>();
				Map<String, TreeRowKey> nodesAndRowKeys = null;
				nodesAndRowKeys = new HashMap<String, TreeRowKey>();
				List<String> dBChildsList = new ArrayList<String>();
				if (childrenList != null && childrenList.size() > 0) {
					childNodeItr = childrenList.iterator();
					while (childNodeItr.hasNext()) {
						Object dataObject = childNodeItr.next();
						PLMPddrData tempTreeNodeData = null;
						tempTreeNodeData = (PLMPddrData) ((TreeNode) dataObject)
								.getData();

						dBChildsList.add(tempTreeNodeData.getParentItem());

						PLMPddrData navigatorDataObj = new PLMPddrData();
						if (childSeqs.containsKey(tempTreeNodeData
								.getParentItem())) {
							navigatorDataObj = childSeqs.get(tempTreeNodeData
									.getParentItem());
						} else {
							PLMUtils.copyProperties(tempTreeNodeData,
									navigatorDataObj);
							tempTreeNodeData.setType("node");
							givenNode.addChild(
									tempTreeNodeData.getParentItem(),
									(TreeNode) dataObject);

						}
						TreeNode tempNode = givenNode.getChild(tempTreeNodeData
								.getParentItem());
						nodesAndRowKeys.put(tempTreeNodeData.getParentItem(),
								(TreeRowKey) htmlTree
										.getTreeNodeRowKey(tempNode));

						navigatorList.add(navigatorDataObj);

					}
				}

				/*
				 * Removing the nodes which doesnt exist in the database, but
				 * existing in the tree
				 */
				if (childSeqs != null && childSeqs.size() > 0) {
					Set childSeqsList = childSeqs.keySet();
					
					if (childSeqsList != null && childSeqsList.size() > 0) {
						childSeqsList.removeAll(dBChildsList);
						Iterator<String> childListItr = childSeqsList
								.iterator();
						while (childListItr.hasNext()) {
							String id = childListItr.next();
							givenNode.removeChild(id);
						}
					}
				}

				/**
				 * Get the children of the siblings, to show expand/collapse
				 * icon
				 */
				LOG
						.info("---> Get Children for Clicked Node, Sub folders Starts <---");
				childrenMap = plmPddrServiceIfc.getChildForParentList(
						topLevelItemParam, navigatorList, level + 1);

				LOG
						.info("---> Get Children for Clicked Node, Sub folders Ends <---");
				Iterator childrenMapItr = childrenMap.entrySet().iterator();
				LOG.info("More folder seqs: " + moreFolderSeqs);
				while (childrenMapItr.hasNext()) {
					Entry subChldSqId = (Entry) childrenMapItr.next();
					String subChildSeqId = (String) subChldSqId.getKey();
					//String subChildSeqId = (String) childrenMapItr.next();
					List subChildList = (List) childrenMap.get(subChildSeqId);
					if (subChildList != null
							&& subChildList.size() > 0
							&& (isCollapse || !moreFolderSeqs
									.contains(subChildSeqId))) {
						childNodeItr = subChildList.iterator();
						while (childNodeItr.hasNext()) {
							Object dataObject = childNodeItr.next();
							PLMPddrData tempTreeNodeData = (PLMPddrData) ((TreeNode) dataObject)
									.getData();
							tempTreeNodeData.setType("node");
							TreeRowKey treeRowKey = nodesAndRowKeys
									.get(subChildSeqId);
							TreeNode subNode1 = htmlTree
									.getModelTreeNode(treeRowKey);
							// Check if this node also exists
							TreeNode subNode11 = subNode1
									.getChild(tempTreeNodeData.getParentItem());
							if (subNode11 == null
									|| subNode11.getData() == null) {
								subNode1
										.addChild(tempTreeNodeData
												.getParentItem(),
												(TreeNode) dataObject);
							} else {
								@SuppressWarnings("unused")
								PLMPddrData subNodeData = (PLMPddrData) subNode11
										.getData();
								LOG.info("Code Review  " + subNodeData.toString());
							}
						}
					}
				}
			}

		  }
		}
		LOG.info(" --> addNodeWithChildrenToGivenNode METHOD Ends <--");
	}

	/**
	 * 
	 * processSelection
	 * 
	 * @param event
	 */
	@SuppressWarnings("unchecked")
	public void processSelection(NodeSelectedEvent event) {
		try {
			HtmlTree tree = (HtmlTree) event.getComponent();
			if (tree != null && tree.getRowKey() != null) {
				selectedNode = tree.getModelTreeNode(tree.getRowKey());
				if (selectedNode != null) {
					selectedNodeChildren.clear();
					if (selectedNode.isLeaf()) {
						selectedNodeChildren.add((PLMPddrData) selectedNode
								.getData());
					} else {
						Iterator<Map.Entry<PLMPddrData, TreeNode>> it = selectedNode
								.getChildren();
						while (it != null && it.hasNext()) {
							Map.Entry<PLMPddrData, TreeNode> entry = it.next();
							selectedNodeChildren.add((PLMPddrData) entry
									.getValue().getData());
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error("Exception[changeNode]:" + e.getMessage());
		}
	}

	/**
	 * TreeNode
	 * 
	 * @return TreeNode
	 */
	@SuppressWarnings("unchecked")
	public TreeNode getTreeNode() {
		if (rootNode == null) {
			loadTree();
		}
		return rootNode;
	}

	/**
	 * Used for getDetails
	 * 
	 * @return String
	 */
	@SuppressWarnings("unchecked")
	public String getDetails() {
		LOG.info("Entering getDetails() method----PLMPddrMB---");
		buttonFlag = false;
		String returnStr = PLMConstants.EMPTY_STRING;
		toGetPopup = 0;
		//int count = 0;
		if (filterString==PLMConstants.N_1)
		alertMessage = PLMConstants.EMPTY_STRING;
		alertMsgPddr = PLMConstants.EMPTY_STRING;
		updateTreeHighlight(rootNode);
		try {
			String nodeTitleP = null;
			gettingDetails = false;
			String selectedIdP = null;
			int selectedLevelP = 0;
			String topLevelItemP = null;
			if (!PLMUtils.isEmpty(PLMUtils.getRequestParameter("parentName"))) {
				nodeTitleP = PLMUtils.getRequestParameter("parentName");
				selectedLevelP = Integer.parseInt(PLMUtils
						.getRequestParameter("selLevel"));
				topLevelItemP = PLMUtils.getRequestParameter("topLevelItem");
				selectedIdP = PLMUtils.getRequestParameter("selectedID");
			}
			nodeTitle = nodeTitleP;
			selectedLevel = selectedLevelP;
			LOG.info("Selected node : :::" + nodeTitleP);
			LOG.info("Selected id : :::" + selectedIdP);
			LOG.info("Selected node Level : :::" + selectedLevelP);
			LOG.info("Selected Immediate Parent : :::" + topLevelItemP);
			fromSBoMId = selectedIdP + "";
			setSelectedPF(nodeTitleP);
			addItem = plmPddrServiceIfc.getPFDetails(nodeTitleP);
			if(addItem == null){
				alertMsgPddr = "No part details found for the selected part family";
				FacesContext.getCurrentInstance().addMessage("INFO", new FacesMessage(alertMsgPddr));
			}
		} catch (Exception ce) {
			LOG.log(Level.ERROR, "getDetails" + ce);
			returnStr = PLMConstants.ERROR;
		}
		LOG.info("Exiting getDetails() method----PLMPddrMB---");
		return returnStr;
	}
	
//	
	/**
	 * expandNode
	 * 
	 * @param treeRowKey
	 */
	@SuppressWarnings("unchecked")
	public void expandNode(TreeRowKey treeRowKey) {
		try {
			if (treeRowKey != null) {
				htmlTree.queueNodeExpand(treeRowKey);
			}
		} catch (Exception eobj) {
			LOG.error("In expandNode:" + eobj.getMessage());
		}
	}

	/**
	 * extractLastNodeId
	 * 
	 * @param nodeId
	 * @return String
	 */
	public String extractLastNodeId(String nodeId) {
		String nodeIdNew = "";
		if (nodeId != null && nodeId.length() > 0) {
			nodeIdNew = nodeId.substring(nodeId.lastIndexOf(':') + 1);
		}
		return nodeIdNew;
	}

	/**
	 * extractNodeId
	 * 
	 * @param nodeId
	 * @return String
	 */
	public String extractNodeId(String nodeId) {
		String nodeIdNew = "";
		if (nodeId != null && nodeId.length() > 0) {
			nodeIdNew = nodeId.substring(nodeId.lastIndexOf(':') + 1, nodeId
					.length());
		}
		return nodeIdNew;
	}

	/**
	 * generateTreeNodeChildren
	 * 
	 * @param treeNodeParam
	 * @param isFromTree
	 * @param level
	 * @param item
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public void generateTreeNodeChildren(TreeNode treeNodeParam,
			boolean isFromTree, int level, String item) throws Exception {
		LOG
				.info(" *************** INSIDE generateTreeNodeChildren METHOD ******************* ");
		List childrenList = null;
		String nodeId = null;
		TreeNode childNode = null;
		PLMPddrData navigData = null;
		List<PLMPddrData> navigList = null;
		List<PLMPddrData> remTrNdDta = null;
		Iterator mainNodeItr = null;
		Iterator childNodeItr = null;

		TreeRowKey treeRowKey = null;
		PLMPddrData treeNodeData = null;
		

		Object dataObject = null;
		PLMPddrData tempTreeNodeData = null;

		Entry abc = null;

		if (treeNodeParam != null) {
			mainNodeItr = treeNodeParam.getChildren();
			navigList = new ArrayList<PLMPddrData>();
			remTrNdDta = new ArrayList<PLMPddrData>();
			while (mainNodeItr.hasNext()) {

				abc = (Entry) mainNodeItr.next();
				childNode = (TreeNodeImpl) abc.getValue();
				//treeRowKey = (TreeRowKey) htmlTree.getTreeNodeRowKey(childNode);
				treeNodeData = (PLMPddrData) childNode.getData();
				navigData = new PLMPddrData();
				if (treeNodeData == null) {
					treeNodeData = new PLMPddrData();
				}
				PLMUtils.copyProperties(treeNodeData, navigData);
				navigList.add(navigData);

			}

			HashMap childrenMap = plmPddrServiceIfc.getChildForParentList(item,
					navigList, level);

			mainNodeItr = treeNodeParam.getChildren();
			while (mainNodeItr.hasNext()) {
				abc = (Entry) mainNodeItr.next();
				childNode = (TreeNodeImpl) abc.getValue();
				treeRowKey = (TreeRowKey) htmlTree.getTreeNodeRowKey(childNode);
				treeNodeData = (PLMPddrData) childNode.getData();
				navigData = new PLMPddrData();
				if (treeNodeData == null) {
					treeNodeData = new PLMPddrData();
				}
				PLMUtils.copyProperties(treeNodeData, navigData);
				navigList = new ArrayList<PLMPddrData>();
				navigList.add(navigData);

				nodeId = treeRowKey.toString();
				childrenList = (List) childrenMap.get(extractNodeId(nodeId));
				if (childrenList != null && childrenList.size() > 0) {
					childNodeItr = childrenList.iterator();
					while (childNodeItr.hasNext()) {
						dataObject = childNodeItr.next();
						tempTreeNodeData = (PLMPddrData) ((TreeNode) dataObject)
								.getData();
						tempTreeNodeData.setType("node");
						childNode.addChild(tempTreeNodeData.getParentItem(),
								(TreeNode) dataObject);
					}
				}

			}

			if (remTrNdDta != null && remTrNdDta.size() > 0) {
				Iterator<PLMPddrData> remTrNdItr = remTrNdDta.iterator();
				while (remTrNdItr.hasNext()) {
					PLMPddrData trNdDta = remTrNdItr.next();
					treeNodeParam.removeChild(trNdDta.getParentItem());
				}
				if (!treeNodeParam.getChildren().hasNext() && isFromTree) {
					TreeRowKey treeRowKeyNew = (TreeRowKey) htmlTree
							.getTreeNodeRowKey(treeNodeParam);
					htmlTree.queueNodeCollapse(treeRowKeyNew);
				}
			}
		}
	}
	
	/**
	 * collapseOtherTreeFilter
	 * 
	 * @param tree
	 * @param uinode
	 */
	
	@SuppressWarnings( { "unchecked", "unused" })
	public void collapseOtherTreeFilter(UITree tree, TreeNode uinode) {
		try {
			
			Iterator childCurrent = uinode.getChildren();
			while (childCurrent.hasNext()) {
				Entry ax = (Entry) childCurrent.next();
				TreeNode childNode = (TreeNodeImpl) ax.getValue();
				PLMPddrData tempData = (PLMPddrData)childNode.getData();				
				if(!secondLevelFilteredNodes.containsKey(tempData.getParentItem())){
					collapseSubNodes(childNode);
				}
			}
			
		} catch (Exception eobj) {
			LOG.error("Exception[collapseOtherTree]:" + eobj.getMessage());
		}
	}

	/**
	 * collapseOtherTree
	 * 
	 * @param tree
	 * @param uinode
	 */
	@SuppressWarnings( { "unchecked", "unused" })
	public void collapseOtherTree(UITree tree, TreeNode uinode) {
		try {
			TreeRowKey parentRowKey = (TreeRowKey) tree
					.getTreeNodeRowKey(uinode);
			while (parentRowKey.getParentKey() != null
					&& parentRowKey.getParentKey().toString().length() > 0) {
				parentRowKey = parentRowKey.getParentKey();
			}
			String myRoot = parentRowKey.toString();

			Iterator childCurrent = uinode.getChildren();
			while (childCurrent.hasNext()) {
				Entry ax = (Entry) childCurrent.next();
				TreeNode childNode = (TreeNodeImpl) ax.getValue();
				collapseSubNodes(childNode);
			}

			Iterator abc = rootNode.getChildren();
			while (abc.hasNext()) {
				Entry ax = (Entry) abc.next();
				TreeNode childNode = (TreeNodeImpl) ax.getValue();
				collapseSubNode(myRoot, childNode);

			}
		} catch (IOException eobj) {
			LOG.error("ICMMSG[collapseOtherTree]:" + eobj.getMessage());
		} catch (Exception eobj) {
			LOG.error("Exception[collapseOtherTree]:" + eobj.getMessage());
		}
	}

	/**
	 * collapseSubNode
	 * 
	 * @param myRoot
	 * @param childNode
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	private void collapseSubNode(String myRoot, TreeNode childNode)
			throws IOException {
		TreeRowKey treeRowKey = (TreeRowKey) htmlTree
				.getTreeNodeRowKey(childNode);
		String rowKeyStrLp = treeRowKey.toString();
		String myRootLp;
		if (rowKeyStrLp.indexOf(':') != PLMConstants.N_NEG_1) {
			myRootLp = rowKeyStrLp.substring(0, rowKeyStrLp.indexOf(':'));
		} else {
			myRootLp = rowKeyStrLp;
		}
		if (!myRootLp.equals(myRoot)) {
			htmlTree.queueNodeCollapse(treeRowKey);
		}
		if (childNode.getChildren() != null) {
			Iterator childItr = childNode.getChildren();
			while (childItr.hasNext()) {
				Entry axt = (Entry) childItr.next();
				TreeNode childSubNode = (TreeNodeImpl) axt.getValue();
				collapseSubNode(myRoot, childSubNode);
			}
		}
	}

	/**
	 * collapseSubNodes
	 * 
	 * @param childNode
	 */
	@SuppressWarnings("unchecked")
	private void collapseSubNodes(TreeNode childNode) {
		try {
			if (htmlTree.getValue() != null) {
				TreeRowKey treeRowKey = (TreeRowKey) htmlTree
						.getTreeNodeRowKey(childNode);
				htmlTree.queueNodeCollapse(treeRowKey);
				if (childNode.getChildren() != null) {
					Iterator childItr = childNode.getChildren();
					while (childItr.hasNext()) {
						Entry axt = (Entry) childItr.next();
						TreeNode childSubNode = (TreeNodeImpl) axt.getValue();
						collapseSubNodes(childSubNode);
					}
				}
			}
		} catch (Exception eobj) {
			LOG.info("In collapseSubNodes methods" + eobj.getMessage());
		}
	}
	
	
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	
	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendPddrReportThroughMail();
		}
	}
	
	/**
	 * This method is used for Loading PDDR Page
	 * 
	 * @return String
	 */
	public String loadPddrPage() {
		LOG.info("Entering loadPddrPage Method");
		try {	
			pddrData = new PLMPddrData();
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@loadPddrPage:", exception);
		}
		LOG.info("Exiting loadPddrPage Method");
		return "pddrSearch";
	}
	
	/**
	 * This method is used for Validating PDDR User Input
	 * 
	 * @return String
	 */
    public String validatePddrInput() {       
        LOG.info("Entering validatePddrInput Method");
        int pfCount = addItem.getPartCount();
        LOG.info("pfCount----validatePddrInput---"+pfCount);
        if(PLMUtils.isEmpty(selectedPF)){
              alertMessage = PLMConstants.PDDR_SEARCH_CRITERIA;
        } else if(pfCount != 0 && pfCount > Integer.parseInt(PLMUtils.getMessage(PLMConstants.PDDR_PART_LIMIT))){
              alertMessage = PLMConstants.PDDR_PART_COUNT;
        } else if (pfCount == 0) {
        	  alertMessage = PLMConstants.PDDR_ZERO_PART_COUNT;
        }
        LOG.info("Exiting validatePddrInput Method");
        return alertMessage;
  }

	
	/**
	 * This method is used for Resetting the User input
	 * 
	 * @return String
	 */
	
	public String resetData() {
		LOG.info("Entering Reset Method");
		String fwdflag = "";
		if (selectedPF != null)
			setSelectedPF(null);
		LOG.info("Exiting Reset Method");
		return fwdflag;
	}
	
	/**
	 * This method is used for Generating PDDR Report
	 * 
	 * @return String
	 */
	public String getPddrReport() {
		LOG.info("Entering getPddrReport() method----PLMPddrMB---");
		String fwdflag = "";
		//pddrData.setPartFamilyName("ELECTRICAL");
		 alertMessage=PLMConstants.EMPTY;
		String vldtMsg = validatePddrInput();
		if (PLMUtils.isEmpty(vldtMsg)) {
			try {
				userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
				taskExecutor.execute(new MailThread());
			 } catch (Exception exception) {
				LOG.log(Level.ERROR, "Exception@getPddrReport: ", exception);
				fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"pddrSearch","PFDDR Report");
			}
		}
		LOG.info("Exiting getPddrReport Method");
		return fwdflag;
	}
	
	/**
	 * 
	 */
	public void sendPddrReportThroughMail() {
    	/**Name of excel file that we are going to create**/
		LOG.info("Entering sendPddrReportThroughMail Method--part family--" + selectedPF);
		alertMessage = PLMConstants.PDDR_MAIL_ALERT_MSG;		
		String pfName = selectedPF;
		String from = PLMConstants.PDDR_MAIL_FROM;
		
		String to = userDetails.getUserEmailId();
		LOG.info("To Email Id>>>>>>>>>>>>> " + to);
		String sso = userDetails.getUserSSO();
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		
		LOG.info("ToAddressee Name>>>>>>>>>>>>> " + toAddressee);
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.PDDR_MAIL_SUBJECT + pfName;
		StringBuffer mailBody = null;
		String filePathZip = null;
		String mailFilePathZip = null;
		List<String> filePathXlsLst = null;
		List<String> allFilePathZipLst = new ArrayList<String>();
		Map<String,List<String>> finalFolderMap = new HashMap<String,List<String>>();
		String folderPath = null;
		Map<String, Object> varMap = new HashMap<String, Object>(); 
		//Map<String, List<String>> zipFilesMap = new LinkedHashMap<String, List<String>>();
		
		try {
			PLMPddrData tempData = plmPddrServiceIfc.getPddrReport(pfName, sso);
			//LOG.info("pddrResultList size >>>>>>>> " + pddrResultList.size());
			if(null != tempData){
				mailBody = new StringBuffer().append(toAddressee)
				.append(PLMConstants.PDDR_MAIL_CONTENT)
				.append(pfName)
				.append(".")
				.append(PLMConstants.PDDR_MAIL_SIGNATURE)
				.append(PLMConstants.PDDR_MAIL_FOOTER);
				filePathZip = tempData.getFilePathZip();
				filePathXlsLst = tempData.getFilePathXls();
				folderPath = tempData.getFolderPath();
				
				finalFolderMap.put(folderPath,filePathXlsLst);
				
				
				Map<String, List<String>> zipFilesMap = generateZipFilesMap(filePathZip, folderPath, filePathXlsLst, tempData.getCompressedFilesWithSize());
				if(zipFilesMap.size() > 0){
					LOG.info("Zip files generation start ^^^^^^^^^^^^^^^^^^^^^^^");
					for (Map.Entry<String, List<String>> entry : zipFilesMap.entrySet()) {
						try {
							PLMUtils.generateZipFile(entry.getValue(), entry.getKey(), false);
							allFilePathZipLst.add(entry.getKey());
						} catch (IOException e) {					
							LOG.log(Level.ERROR, "Exception@generateZipFile: ", e);
						}
					}
					LOG.info("Zip files generation completed ^^^^^^^^^^^^^^^^^^^^^^^");
				}else{
					//Will enter in to else condition when zip file size is less than PDDR_SIZE_LIMIT
					allFilePathZipLst.add(filePathZip);
				}				
				
				for (int i = 0; i < allFilePathZipLst.size(); i++) {
					mailFilePathZip = allFilePathZipLst.get(i);
					subject = PLMConstants.PDDR_MAIL_SUBJECT + pfName;					
					if (allFilePathZipLst.size() > PLMConstants.N_1) {
						subject += " - " + (i + 1);
					}
					LOG.info("Subject =========== "+subject+" filePathZip = "+mailFilePathZip);	
					PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), mailFilePathZip);
				}
				
				//Below logic is added to delete huge zip file from NAS
				if(zipFilesMap.size() > 0){
					allFilePathZipLst.add(filePathZip);
				}
				LOG.info("Mail sent successfully.");
			} else {
				mailBody = new StringBuffer().append(toAddressee)
				.append(PLMConstants.PDDR_MAIL_ERROR_CONTENT)
				.append(pfName)
				.append(".")
				.append(PLMConstants.PDDR_MAIL_SIGNATURE)
				.append(PLMConstants.PDDR_MAIL_FOOTER);
				PLMUtils.sendMail(from, to, subject, mailBody.toString());
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendPddrReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.PDDR_MAIL_SIGNATURE);
		/*} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendPddrReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.PDDR_MAIL_SIGNATURE);
		*/} finally {
			LOG.info("Enter to delete file inside finally block ^^^^^^^^^^^^^^^^^^^");
			varMap.clear();
			if(allFilePathZipLst != null){
				PLMUtils.deleteFiles(allFilePathZipLst, finalFolderMap);
				LOG.info("Exiting from delete inside finally block ^^^^^^^^^^^^^^^^^^^");
			}
		}
		LOG.info("Exiting sendPddrReportThroughMail Method");
    }
	
	/**
	 * generateZipFilesMap
	 * 
	 * @param filePathZip
	 * @param folderPath
	 * @param filePathXlsLst
	 * @param compressedFilesWithSize
	 * @return zipFilesMap
	 */
	public Map<String, List<String>> generateZipFilesMap(String filePathZip, String folderPath, List<String> filePathXlsLst, Map<String,Double> compressedFilesWithSize){		
		LOG.info("Entering generateZipFilesMap ^^^^^^^^^^^^^^^^^^^");
		int zipSizeLimit = Integer.parseInt(PLMUtils.getMessage(PLMConstants.PDDR_SIZE_LIMIT));
		int zipCount = 1;
		double newZipSize = 0;
		double currentZipSize = 0;
		double zipSize = 0;
		zipSize = PLMUtils.getZipFileSize(filePathZip);
		String currentFile;
		String folderPathNew;
		String filePathZipNew;
		Map<String, List<String>> zipFilesMap = new LinkedHashMap<String, List<String>>();
		List<String> filesList;
		
		LOG.info("zipSize = "+zipSize+" zipSizeLimit = "+zipSizeLimit);
		if (zipSize > zipSizeLimit) {
			zipFilesMap = new LinkedHashMap<String, List<String>>();
			filesList = new ArrayList<String>();
			folderPathNew = folderPath + "_" + zipCount;
			filePathZipNew = folderPathNew + ".zip";
			for (String xlsFileName : filePathXlsLst) {
				currentFile = xlsFileName;
				currentZipSize = compressedFilesWithSize.get(xlsFileName);
				newZipSize += currentZipSize;
				if(newZipSize > zipSizeLimit){
					
					filesList.remove(currentFile);
					zipFilesMap.put(filePathZipNew,filesList);
					
					filesList = new ArrayList<String>();
					filesList.add(currentFile);
					
					newZipSize = currentZipSize;
					zipCount++;
					folderPathNew = folderPath + "_" + zipCount;
					filePathZipNew = folderPathNew + ".zip";
				}else{
					filesList.add(currentFile);
				}
				
			}	
			if(zipFilesMap.get(filePathZipNew) == null){
				if(filesList.size() > 0){
					zipFilesMap.put(filePathZipNew,filesList);
				}
			}
			LOG.info("in generateZipFilesMap zipFilesMap = "+zipFilesMap);
		}
		LOG.info("Exiting generateZipFilesMap ^^^^^^^^^^^^^^^^^^^");
		return zipFilesMap;
	}    
	
	
	/**
	 * getZipFileSize
	 * 
	 * @param filePathXlsLst
	 * @return
	 */
	public long getZipFileSize(String filePathZip) {
		 File fObj = null;
		 long sizeInBytes = 0;
		 long sizeInMb = 0;
		 long totSize = 0;
		 LOG.info("Inside getZipFileSize method filePathZipNew " + filePathZip);
		 // Get Size of files
		 //for (int i = 0; i < filePathXlsLst.size(); i++) {
			fObj = new File(filePathZip);
			
			// Get the number of bytes in the file
			sizeInBytes = fObj.length();
			//transform in MB
			sizeInMb = sizeInBytes / (1024 * 1024);
			// Size of all files 
			totSize += sizeInMb;
		 //}
		 LOG.info("Total file size in MB >>>>>>>> " + totSize);
		 
		 return totSize;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return the selectedMPLNo
	 */
	public String getSelectedMPLNo() {
		return selectedMPLNo;
	}

	/**
	 * @return the addItem
	 */
	public PLMPddrData getAddItem() {
		return addItem;
	}

	/**
	 * @param addItemP
	 *            the addItem to set
	 */
	public void setAddItem(PLMPddrData addItemP) {
		this.addItem = addItemP;
	}

	/**
	 * @param selectedMPLNoP
	 *            the selectedMPLNo to set
	 */
	public void setSelectedMPLNo(String selectedMPLNoP) {
		this.selectedMPLNo = selectedMPLNoP;
	}

	/**
	 * @return the resultCount
	 */
	public int getResultCount() {
		return resultCount;
	}

	/**
	 * @param resultCountP
	 *            the resultCount to set
	 */
	public void setResultCount(int resultCountP) {
		this.resultCount = resultCountP;
	}

	/**
	 * @return the toGetPopup
	 */
	public int getToGetPopup() {
		return toGetPopup;
	}

	/**
	 * @param toGetPopup
	 *            the toGetPopup to set
	 */
	public void setToGetPopup(int toGetPopupP) {
		this.toGetPopup = toGetPopupP;
	}

	/**
	 * @return the mplNumber
	 */
	public String getMplNumber() {
		return mplNumber;
	}

	/**
	 * @param mplNumberP
	 *            the mplNumber to set
	 */
	public void setMplNumber(String mplNumberP) {
		this.mplNumber = mplNumberP;
	}

	/**
	 * @return the resultHeader
	 */
	public boolean isResultHeader() {
		return resultHeader;
	}

	/**
	 * @param resultHeaderP
	 *            the resultHeader to set
	 */
	public void setResultHeader(boolean resultHeaderP) {
		this.resultHeader = resultHeaderP;
	}

	/**
	 * @return the alertMsgPddr
	 */
	public String getAlertMsgPddr() {
		String alert = alertMsgPddr;
		alertMsgPddr = PLMConstants.EMPTY_STRING;
		return alert;
	}

	/**
	 * @param stralertMsgPddr
	 *            the alertMsgPddr to set
	 */
	public void setAlertMsgPddr(String strAlertMsgPddr) {
		this.alertMsgPddr = strAlertMsgPddr;
	}

	/**
	 * @return the searchString
	 */
	public String getSearchString() {
		return searchString;
	}

	/**
	 * @param searchStringP
	 *            the searchString to set
	 */
	public void setSearchString(String searchStringP) {
		this.searchString = searchStringP;
	}

	/**
	 * @return the sbomData
	 */
	public List<PLMPddrData> getSbomData() {
		return sbomData;
	}

	/**
	 * @param sbomDataP
	 *            the sbomData to set
	 */
	public void setSbomData(List<PLMPddrData> sbomDataP) {
		this.sbomData = sbomDataP;
	}

	/**
	 * @return the searchResults
	 */
	public List<String> getSearchResults() {
		return searchResults;
	}

	/**
	 * @param searchResultsP
	 *            the searchResults to set
	 */
	public void setSearchResults(List<String> searchResultsP) {
		this.searchResults = searchResultsP;
	}

	/**
	 * @return the partChildTable
	 */
	public boolean isPartChildTable() {
		return partChildTable;
	}

	/**
	 * @param partChildTableP
	 *            the partChildTable to set
	 */
	public void setPartChildTable(boolean partChildTableP) {
		this.partChildTable = partChildTableP;
	}

	/**
	 * @return the publisEnable
	 */
	public boolean isPublisEnable() {
		return publisEnable;
	}

	/**
	 * @param publisEnableP
	 *            the publisEnable to set
	 */
	public void setPublisEnable(boolean publisEnableP) {
		this.publisEnable = publisEnableP;
	}

	/**
	 * @return confirmAlertMsg
	 */
	public String getConfirmAlertMsg() {
		return confirmAlertMsg;
	}

	/**
	 * @param strConfirmAlertMsg
	 */
	public void setConfirmAlertMsg(String strConfirmAlertMsg) {
		this.confirmAlertMsg = strConfirmAlertMsg;
	}

	/**
	 * @return saveSuccessMsg
	 */
	public String getSaveSuccessMsg() {
		return saveSuccessMsg;
	}

	/**
	 * @param saveSuccessMsg
	 */
	public void setSaveSuccessMsg(String strSaveSuccessMsg) {
		this.saveSuccessMsg = strSaveSuccessMsg;
	}

	/**
	 * @return the read
	 */
	public boolean isRead() {
		return read;
	}

	/**
	 * @param read
	 *            the read to set
	 */
	public void setRead(boolean readP) {
		this.read = readP;
	}

	/**
	 * @return the write
	 */
	public boolean isWrite() {
		return write;
	}

	/**
	 * @param write
	 *            the write to set
	 */
	public void setWrite(boolean writeP) {
		this.write = writeP;
	}

	/**
	 * @return the scrollerPage
	 */
	public int getScrollerPage() {
		return scrollerPage;
	}

	/**
	 * @param scrollerPage
	 *            the scrollerPage to set
	 */
	public void setScrollerPage(int scrollerPageP) {
		this.scrollerPage = scrollerPageP;
	}

	/**
	 * @return the panelGrid
	 */
	public HtmlPanelGrid getPanelGrid() {
		return panelGrid;
	}

	/**
	 * @param panelGrid
	 *            the panelGrid to set
	 */
	public void setPanelGrid(HtmlPanelGrid panelGridP) {
		this.panelGrid = panelGridP;
	}

	/**
	 * @return the isCollapse
	 */
	public boolean isCollapse() {
		return isCollapse;
	}

	/**
	 * @param isCollapse
	 *            the isCollapse to set
	 */
	public void setCollapse(boolean isCollapseP) {
		this.isCollapse = isCollapseP;
	}

	/**
	 * @return
	 */
	public String getNodeTitle() {
		return nodeTitle;
	}

	/**
	 * @param nodeTitle
	 */
	public void setNodeTitle(String nodeTitleP) {
		this.nodeTitle = nodeTitleP;
	}

	/**
	 * @return the htmlTree
	 */
	public HtmlTree getHtmlTree() {
		return htmlTree;
	}

	/**
	 * @param htmlTree
	 *            the htmlTree to set
	 */
	public void setHtmlTree(HtmlTree htmlTreeP) {
		this.htmlTree = htmlTreeP;
	}

	/**
	 * @param tree
	 * @return
	 */
	public Boolean collapseTree(UITree tree) {
		return false;
	}

	/**
	 * @return the parentItem
	 */
	public String getParentItem() {
		return parentItem;
	}

	/**
	 * @param parentItem
	 *            the parentItem to set
	 */
	public void setParentItem(String parentItemP) {
		this.parentItem = parentItemP;
	}

	/**
	 * @return the showAdmin
	 */
	public boolean getShowSBOMExplorerUpdate() {
		return showSBOMExplorerUpdate;
	}

	/**
	 * @param showSBOMExplorerUpdate
	 *            the showAdmin to set
	 */
	public void setShowSBOMExplorerUpdate(boolean showSBOMExplorerUpdateP) {
		this.showSBOMExplorerUpdate = showSBOMExplorerUpdateP;
	}

	/**
	 * @return the showAddButton
	 */
	public boolean isShowAddButton() {
		return showAddButton;
	}

	/**
	 * @param showAddButton
	 *            the showAddButton to set
	 */
	public void setShowAddButton(boolean showAddButtonP) {
		this.showAddButton = showAddButtonP;
	}

	/**
	 * @return the showNewAdd
	 */
	public boolean isShowNewAdd() {
		return showNewAdd;
	}

	/**
	 * @param showNewAdd
	 *            the showNewAdd to set
	 */
	public void setShowNewAdd(boolean showNewAddP) {
		this.showNewAdd = showNewAddP;
	}

	/**
	 * @return the showDetails
	 */
	public boolean isShowDetails() {
		return showDetails;
	}

	/**
	 * @param showDetails
	 *            the showDetails to set
	 */
	public void setShowDetails(boolean showDetailsP) {
		this.showDetails = showDetailsP;
	}

	/**
	 * @return the topLevelItem
	 */
	public String getTopLevelItem() {
		return topLevelItem;
	}

	/**
	 * @param topLevelItem
	 *            the topLevelItem to set
	 */
	public void setTopLevelItem(String topLevelItemP) {
		this.topLevelItem = topLevelItemP;
	}

	/**
	 * @return the selectedLevel
	 */
	public int getSelectedLevel() {
		return selectedLevel;
	}

	/**
	 * @param selectedLevel
	 *            the selectedLevel to set
	 */
	public void setSelectedLevel(int selectedLevelP) {
		this.selectedLevel = selectedLevelP;
	}

	/**
	 * @return the selectedId
	 */
	public int getSelectedId() {
		return selectedId;
	}

	/**
	 * @param selectedId
	 *            the selectedId to set
	 */
	public void setSelectedId(int selectedIdP) {
		this.selectedId = selectedIdP;
	}

	/**
	 * @return the fromSBoMId
	 */
	public String getFromSBoMId() {
		return fromSBoMId;
	}

	/**
	 * @param fromSBoMId
	 *            the fromSBoMId to set
	 */
	public void setFromSBoMId(String fromSBoMIdP) {
		this.fromSBoMId = fromSBoMIdP;
	}

	/**
	 * @return the gettingDetails
	 */
	public boolean isGettingDetails() {
		return gettingDetails;
	}

	/**
	 * @param gettingDetails
	 *            the gettingDetails to set
	 */
	public void setGettingDetails(boolean gettingDetailsP) {
		this.gettingDetails = gettingDetailsP;
	}

	/**
	 * @return the sbomHeaderData
	 */
	public PLMPddrSearchData getSbomHeaderData() {
		return sbomHeaderData;
	}

	/**
	 * @param sbomHeaderData
	 *            the sbomHeaderData to set
	 */
	public void setSbomHeaderData(PLMPddrSearchData sbomHeaderDataP) {
		this.sbomHeaderData = sbomHeaderDataP;
	}

	/**
	 * @return the searchSerialString
	 */
	public String getSearchSerialString() {
		return searchSerialString;
	}

	/**
	 * @param searchSerialString
	 *            the searchSerialString to set
	 */
	public void setSearchSerialString(String searchSerialStringP) {
		this.searchSerialString = searchSerialStringP;
	}

	/**
	 * @return the searchExpResults
	 */
	public List<PLMPddrSearchData> getSearchExpResults() {
		return searchExpResults;
	}

	/**
	 * @param searchExpResults
	 *            the searchExpResults to set
	 */
	public void setSearchExpResults(List<PLMPddrSearchData> searchExpResultsP) {
		this.searchExpResults = searchExpResultsP;
	}

	/**
	 * @return the prdStcres
	 */
	public int getPrdStcres() {
		return prdStcres;
	}

	/**
	 * @param prdStcres
	 *            the prdStcres to set
	 */
	public void setPrdStcres(int prdStcresP) {
		this.prdStcres = prdStcresP;
	}

	/**
	 * @return the treeLoad
	 */
	public int getTreeLoad() {
		return treeLoad;
	}

	/**
	 * @param treeLoad
	 *            the treeLoad to set
	 */
	public void setTreeLoad(int treeLoadP) {
		this.treeLoad = treeLoadP;
	}

	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @param recordCounts
	 *            the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		LOG.info("::::::::::::::::::" + recordCounts);
		PLMUtils.getServletSession(true).setAttribute("RecDropDown",
				recordCounts);
		this.recordCounts = recordCounts;
	}

	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount
	 *            the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/**
	 * @return the srcType
	 */
	public String getSrcType() {
		return srcType;
	}

	/**
	 * @param srcType
	 *            the srcType to set
	 */
	public void setSrcType(String srcType) {
		this.srcType = srcType;
	}
	/**
	 * @return the temp
	 */
	public java.util.Date getItemFilterEffStDT() {
		java.util.Date temp = itemFilterEffStDT;
		return temp;
	}
	/**
	 * @param itemFilterEffStDT
	 *            the temp to set
	 */
	public void setItemFilterEffStDT(java.util.Date itemFilterEffStDT) {
		java.util.Date temp = itemFilterEffStDT;
		this.itemFilterEffStDT = temp;
	}
	/**
	 * @return the prefixFilter
	 */
	public String getPrefixFilter() {
		return prefixFilter;
	}
	/**
	 * @param prefixFilter
	 *            the prefixFilter to set
	 */
	public void setPrefixFilter(String prefixFilter) {
		this.prefixFilter = prefixFilter;
	}
	/**
	 * @return the partNumberFilter
	 */
	public String getPartNumberFilter() {
		return partNumberFilter;
	}
	/**
	 * @param partNumberFilter
	 *            the partNumberFilter to set
	 */
	public void setPartNumberFilter(String partNumberFilter) {
		this.partNumberFilter = partNumberFilter;
	}
	/**
	 * @return the ecnFilter
	 */
	public String getEcnFilter() {
		return ecnFilter;
	}
	/**
	 * @param ecnFilter
	 *            the ecnFilter to set
	 */
	public void setEcnFilter(String ecnFilter) {
		this.ecnFilter = ecnFilter;
	}
	
	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}
	/**
	 * @param taskExecutor
	 *            the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}
	/**
	 * @return the exportFlag
	 */
	public boolean isExportFlag() {
		return exportFlag;
	}
	/**
	 * @param exportFlag
	 *            the exportFlag to set
	 */
	public void setExportFlag(boolean exportFlag) {
		this.exportFlag = exportFlag;
	}
	/**
	 * @return the plmPddrServiceIfc
	 */
	public PLMPddrServiceIfc getPlmPddrServiceIfc() {
		return plmPddrServiceIfc;
	}
	/**
	 * @param plmPddrServiceIfc
	 *            the plmPddrServiceIfc to set
	 */
	public void setPlmPddrServiceIfc(PLMPddrServiceIfc plmPddrServiceIfc) {
		this.plmPddrServiceIfc = plmPddrServiceIfc;
	}
	/**
	 * @return the pddrData
	 */
	public PLMPddrData getPddrData() {
		return pddrData;
	}
	/**
	 * @param pddrData
	 *            the pddrData to set
	 */
	public void setPddrData(PLMPddrData pddrData) {
		this.pddrData = pddrData;
	}
	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}
	/**
	 * @param alertMessage
	 *            the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}
	/**
	 * @return the selectedPF
	 */
	public String getSelectedPF() {
		return selectedPF;
	}
	/**
	 * @param selectedPF
	 *            the selectedPF to set
	 */
	public void setSelectedPF(String selectedPF) {
		this.selectedPF = selectedPF;
	}
	/**
	 * @return the buttonFlag
	 */
	public boolean isButtonFlag() {
		return buttonFlag;
	}
	/**
	 * @param buttonFlag
	 *            the buttonFlag to set
	 */
	public void setButtonFlag(boolean buttonFlag) {
		this.buttonFlag = buttonFlag;
	}

	
}