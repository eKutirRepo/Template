package com.geinfra.geaviation.pwi.service.helpers;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.model.TemplateVO;
import com.geinfra.geaviation.pwi.service.vo.ExecutionMode;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.query.SqlQueryType;

/**
*
* Project      : Product Lifecycle Management Intelligence
* Date Written : September 23, 2011
* Security     : GE Confidential
* Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
* Copyright(C) 2013 GE All rights reserved
*
* Description :
*
* Revision Log September 23, 2011 | v1.0.
* --------------------------------------------------------------
*/
public class ExecutionOutputModelConfig {
	private static final Logger LOGGER = Logger
			.getLogger(ExecutionOutputModelConfig.class);
	private List<ExecutionOutputTuple> available;
	private Map<ExecutionMode, ExecutionOutputTuple> defaults;
	private ExecutionOutputTuple initial;

	public ExecutionOutputModelConfig(QueryType queryType,
			List<TemplateVO> templates, ExecutionOutputTuple eventTuple,
			boolean batchDisabled) {
		// find out if this is a tabbed pipeline query
		boolean tabbed = false;
		try {
			// if any of the pipelines is tabbed, this query is tabbed
			for (SqlQueryType pipeline : queryType.getQuerydefinition()
					.getQuerytemplate().getPipelineSQL().getSqlQuery()) {
				if ("tabbed".equals(pipeline.getType())) {
					tabbed = true;
				}
			}
		} catch (NullPointerException npe) {
			// We don't care about a NullPointerException; it most likely
			// indicates that this is not a pipeline query, so nothing to
			// do here.  We could check for null at each step between QueryType
			// and SqlQueryType; however, that would require importing each type
			// type, so it looks a bit cleaner to simply catch the exception and
			// move on.
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Obviously not a tabbed pipeline.", npe);
			}
		}
		
		// get default config, and query-specific config if available
		ExecutionOutputConfig defaultConfig = ExecutionOutputModelUtil
				.getInstance().getDefaultConfig(templates, batchDisabled, tabbed);
		ExecutionOutputConfig queryConfig = ExecutionOutputModelUtil
				.getInstance().getQueryConfig(queryType, templates);

		// get the query-specific config if available; else, the default
		ExecutionOutputConfig config = ExecutionOutputModelUtil.getInstance()
				.getExecutionOutputConfig(defaultConfig, queryConfig);

		available = ExecutionOutputModelUtil.getInstance().getAvailable(config);
		defaults = ExecutionOutputModelUtil.getInstance().getDefaults(config);
		initial = ExecutionOutputModelUtil.getInstance().getInitial(config, eventTuple);
	}

	public List<ExecutionOutputTuple> getAvailable() {
		return available;
	}

	public Map<ExecutionMode, ExecutionOutputTuple> getDefaults() {
		return defaults;
	}

	public ExecutionOutputTuple getInitial() {
		return initial;
	}
}
