/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMIssuesReportMB.java
 * @Creation date: 18-June-2010
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.data.PLMIssuesReportData;
import com.geinfra.geaviation.pwi.service.PLMkpiReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

/**
 * PLMIssuesReportMB is the managed bean class .
 */
public class PLMIssuesReportMB{

	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMIssuesReportMB.class);
	/**
	 * Holds the PLMIssuesReportService
	 */
	
	private PLMCommonMB commonMB=null;

	private PLMkpiReportServiceIfc plmIssuesService = null;
	/**
	 * Holds the searchResultList
	 */
	private List<PLMIssuesReportData> searchResultList;

	/**
	 * Holds the searchIssueDetailsResultList
	 */
	private List<PLMIssuesReportData> searchIssueDetailsResultList;
	/**
	 * Holds the searchDetails
	 */
	private PLMIssuesReportData searchDetails = new PLMIssuesReportData();
	/**
	 * Holds the count
	 */
	private int count;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the totalRecCountMsg
	 */
	private String totalRecCountMsg;
	/**
	 * Holds the fieldName
	 */
	private String fieldName;
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the selectedissues
	 */
	private String selectedissues = "";
	/**
	 * Holds the issuesstate
	 */
	private List<SelectItem> issuesstate;
	/**
	 * Holds the issuespriority
	 */
	private List<SelectItem> issuespriority;
	/**
	 * Holds the issuesintpriority
	 */
	private List<SelectItem> issuesintpriority;
	/**
	 * Holds the issuesprobtype
	 */
	private List<SelectItem> issuesprobtype;
	/**
	 * Holds the Drop Down Values
	 */
	private List<SelectItem> issuescategory;
	/**
	 * Holds the issuesclassification
	 */
	private List<SelectItem> issuesclassification;
	/**
	 * Holds the issuesSourceSystem
	 */
	private List<SelectItem> issuesSourceSystem;
	/**
	 * Holds the issuetotalRecCountMsgs
	 */
	private String issuetotalRecCountMsg;
	/**
	 * Holds the issuerecordCounts
	 */
	private int issuerecordCounts = PLMConstants.N_100;
	/**
	 * Holds the issuetotalRecCount
	 */
	private int issuetotalRecCount;
	
	private String reportName;
	
	/**
	 * This method is used for getIssuesData
	 * 
	 * @return String
	 */
	public String getIssuesData() {
		LOG.info("Entering getIssuesData method");
		String fwdFlag = "";
		totalRecCount = 0;
		if (PLMUtils.isEmpty(searchDetails.getName())
				&& PLMUtils.isEmptyList(searchDetails.getStateList())
				&& PLMUtils.isEmpty(searchDetails.getOwner())
				&& PLMUtils.isEmpty(searchDetails.getCo_owner())
				&& PLMUtils.isEmpty(searchDetails.getOrig_nator())
				&& PLMUtils.isEmptyList(searchDetails.getPriorityList())
				&& PLMUtils.isEmptyList(searchDetails.getInt_priorityList())
				&& PLMUtils.isEmptyList(searchDetails.getCatgList())
				&& PLMUtils.isEmptyList(searchDetails.getClas_ficationList())
				&& PLMUtils.isEmpty(searchDetails.getResp_Org())
				&& PLMUtils.isEmptyList(searchDetails.getProblem_typeList())
				&& PLMUtils.isEmptyList(searchDetails.getSource_sysList())
				&& PLMUtils.isEmptyDate(searchDetails.getOrig_date_from())
				&& PLMUtils.isEmptyDate(searchDetails.getOrig_date_to())
				&& PLMUtils.isEmptyDate(searchDetails.getEstim_date_from())
				&& PLMUtils.isEmptyDate(searchDetails.getEstim_date_to())
				&& PLMUtils.isEmptyDate(searchDetails.getAct_date_from())
				&& PLMUtils.isEmptyDate(searchDetails.getAct_date_to())
				&& PLMUtils.isEmpty(searchDetails.getUnitSerialNum())) {
				alertMessage = PLMConstants.ANY_SRCH_CRIT;
			} else {
				String ownerWithOutAsterisk = null;
				String coOwnerWithOutAsterisk = null;
				String originatorWithOutAsterisk = null;
				
				if (!PLMUtils.isEmpty(searchDetails.getOwner())) {
					ownerWithOutAsterisk = PLMUtils.removeAsteriskAndSpaceFromSSOFields(searchDetails.getOwner());
				}
				if (!PLMUtils.isEmpty(searchDetails.getCo_owner())) {
					coOwnerWithOutAsterisk = PLMUtils.removeAsteriskAndSpaceFromSSOFields(searchDetails.getCo_owner());
				}
				if (!PLMUtils.isEmpty(searchDetails.getOrig_nator())) {
					originatorWithOutAsterisk = PLMUtils.removeAsteriskAndSpaceFromSSOFields(searchDetails.getOrig_nator());
				}
					
				if (!PLMUtils.checkForSpecialChars(searchDetails.getName())) {
					alertMessage = alertMessage + PLMConstants.IssueName_ValMsg;
					fwdFlag = "issues";
				}
				if (!PLMUtils.checkForSpecialChars(searchDetails.getOwner())) {
					alertMessage = alertMessage + PLMConstants.IssueOwner_ValMsg;
					fwdFlag = "issues";
				}
				else if(PLMUtils.isInteger(ownerWithOutAsterisk))
				{
					if(ownerWithOutAsterisk.length() != 9)
					alertMessage = alertMessage + PLMConstants.IssueOwner_Digt_ValMsg;
					fwdFlag = "issues";
				}
				if (!PLMUtils.checkForSpecialChars(searchDetails.getCo_owner())) {
					alertMessage = alertMessage + PLMConstants.IssueCo_owner_ValMsg;
					fwdFlag = "issues";
				}
				else if(PLMUtils.isInteger(coOwnerWithOutAsterisk))
				{
					if(coOwnerWithOutAsterisk.length() != 9)
					alertMessage = alertMessage + PLMConstants.IssueCo_owner_Digt_ValMsg;
					fwdFlag = "issues";
				}
				if (!PLMUtils.checkForSpecialChars(searchDetails.getOrig_nator())) {
					alertMessage = alertMessage
							+ PLMConstants.IssueOrig_nator_ValMsg;
					fwdFlag = "issues";
				}
				else if(PLMUtils.isInteger(originatorWithOutAsterisk))
				{
					if(originatorWithOutAsterisk.length() != 9)
					alertMessage = alertMessage + PLMConstants.IssueOrig_nator_Digt_ValMsg;
					fwdFlag = "issues";
				}
				
				if (!PLMUtils.checkForSpecialChars(searchDetails.getResp_Org())) {
					alertMessage = alertMessage + PLMConstants.IssueRes_org_ValMsg;
					fwdFlag = "issues";
				}
				if (PLMUtils.checkForNullOfTwoDates(searchDetails.getOrig_date_from(), searchDetails.getOrig_date_to())) {
					alertMessage = alertMessage + PLMConstants.Dates_NullCheck_Msg;
				} else if (PLMUtils.checkForFromAndToDate(searchDetails.getOrig_date_from(), searchDetails.getOrig_date_to())) {
					alertMessage = alertMessage + PLMConstants.Date_ValMsg;
					fwdFlag = "issues";
				}
				if (PLMUtils.checkForNullOfTwoDates(searchDetails.getEstim_date_from(), searchDetails.getEstim_date_to())) {
					alertMessage = alertMessage + PLMConstants.Dates_NullCheck_Msg;
				} else if (PLMUtils.checkForFromAndToDate(searchDetails.getEstim_date_from(), searchDetails.getEstim_date_to())) {
					alertMessage = alertMessage + PLMConstants.Date_ValMsg;
					fwdFlag = "issues";
				}
				if (PLMUtils.checkForNullOfTwoDates(searchDetails.getAct_date_from(), searchDetails.getAct_date_to())) {
					alertMessage = alertMessage + PLMConstants.Dates_NullCheck_Msg;
				} else if (PLMUtils.checkForFromAndToDate(searchDetails.getAct_date_from(), searchDetails.getAct_date_to())) {
					alertMessage = alertMessage + PLMConstants.Date_ValMsg;
					fwdFlag = "issues";
				}
	
			}
		if (PLMUtils.isEmpty(alertMessage)) {
			try {
				searchResultList = plmIssuesService
						.getIssuesData(searchDetails);
				if (searchResultList != null) {
					totalRecCount = searchResultList.size();
				} else {
					totalRecCount = 0;
				}
				totalRecCountMsg = "Total Results Count : " + totalRecCount;
				LOG.info("totalRecCount::::::::::::::::::" + totalRecCount);
				if (totalRecCount == 0) {
					fwdFlag = "invalidIssuesReport";
				} else {					
						recordCounts = PLMConstants.N_100;		
						reportName = "issueHdrRpt";
						fwdFlag = "issueSearchReport";
				}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getIssuesData: ", exception);
				fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"issues","Issue Search");
			} 
		}
		LOG.info("Exiting getIssuesData method");
		return fwdFlag;
	}
	
	/**
	 * This method is used for getDropDownvalueissues
	 * 
	 * @return String
	 */
	public String getDropDownvalueissues() {
		String fwdFlag = "";
		alertMessage= "";
		try {
			commonMB.insertCannedRptRecordHitInfo("Issue Search");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			Map<String, List<SelectItem>> dropdownlist = plmIssuesService.getDropDownvalueissues();

			issuesstate = (List<SelectItem>) dropdownlist.get("issuesstate");

			issuespriority = (List<SelectItem>) dropdownlist.get("issuespri");

			issuesintpriority = (List<SelectItem>) dropdownlist
					.get("issuesintpri");
			issuesprobtype = (List<SelectItem>) dropdownlist
			.get("issuesproblemtype");
			
			issuescategory = (List<SelectItem>) dropdownlist
			.get("issuescategory");
			
			issuesclassification = (List<SelectItem>) dropdownlist
			.get("issuesclassification");
			
			issuesSourceSystem = (List<SelectItem>) dropdownlist
			.get("issuesSourceSystem");
			resetIssuesSearchData();
			fwdFlag = "issues";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getDropDownvalueissues: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Issue Search");
		} 
		
		/*try {
			commonMB.getPLMDateStamp(PLMConstants.ISSUE_TABLE);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPLMDateStamp: ", exception);
		} */
		return fwdFlag;
	}

	/**
	 * This method is used for getIssuesDetailedReport
	 * 
	 * @return String
	 */
	public String getIssuesDetailedReport() {
		String fwdFlag = "";
		try {
			List<String> issuesValuesList = new ArrayList<String>();
    			
			if(selectedissues != null) {
        		StringTokenizer strTok = new StringTokenizer(selectedissues, ",");
        			while (strTok.hasMoreTokens()) {
        				issuesValuesList.add(strTok.nextToken());
				 }
			 }	
			 
			searchIssueDetailsResultList = plmIssuesService 
					.getIssuesDetailedReport(issuesValuesList,searchDetails);
			if (searchIssueDetailsResultList != null) {
				issuetotalRecCount = searchIssueDetailsResultList.size();
			} else {
				issuetotalRecCount = 0;
			}
			issuetotalRecCountMsg = "Total Issue Results Count : "
					+ issuetotalRecCount;
			LOG.info("Issue totalRecCount::::::::::::::::::"
					+ issuetotalRecCount);
			if (issuetotalRecCount == 0) {

				fwdFlag = "invalidIssuesDetails";
			} else {				
					issuerecordCounts = PLMConstants.N_100;		
					reportName = "issueDetails";
					fwdFlag = "issuessearchdetails";				
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getIssuesDetailedReport: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"issueSearchReport","Issue Search");
		} 
		return fwdFlag;
	}

	/**
	 * This method is used for resetIssuesSearchData
	 * 
	 * @return String
	 */
	public String resetIssuesSearchData() {
		String fwdFlag = "issues";
		LOG.info("Entering resetIssuesSearchData method");
		searchDetails.setUnitSerialNum("");
		searchDetails.setName("");
		searchDetails.setStateList(null);
		searchDetails.setOrig_nator("");
		searchDetails.setOwner("");
		searchDetails.setCo_owner("");
		searchDetails.setPriorityList(null);
		searchDetails.setInt_priorityList(null);
		searchDetails.setCatgList(null);
		searchDetails.setClas_ficationList(null);
		searchDetails.setResp_Org("");
		searchDetails.setOrig_date_from(null);
		searchDetails.setOrig_date_to(null);
		searchDetails.setEstim_date_from(null);
		searchDetails.setEstim_date_to(null);
		searchDetails.setAct_date_from(null);
		searchDetails.setAct_date_to(null);
		searchDetails.setProblem_typeList(null);
		searchDetails.setSource_sysList(null);
		LOG.info("Exiting resetIssuesSearchData method");
		return fwdFlag;
	}

	/**
	 * @param value
	 *            .
	 * @return String
	 */
	public String getTrimValue(String value) {
		String retStr = null;
		if (!PLMUtils.isEmpty(value)) {
			retStr = value.trim();
		}
		return retStr;

	}
	
	/**
	 *  This method is used download Excel for Issue Report Header and Detail Pages
	 */
	public void downloadIssueExcel() throws PLMCommonException {

		LOG.info("Entering downloadIssueExcel Method");

		String reportNm = reportName;
		String fileName;
		LOG.info("reportName>>> " + reportNm);

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		PLMXlsxRptColumn[] critcolumns =
						new PLMXlsxRptColumn[] {
						new PLMXlsxRptColumn("unitSerialNum", "Serial Number",FormatType.TEXT),
								new PLMXlsxRptColumn("name", "Name", FormatType.TEXT), 
								new PLMXlsxRptColumn("stateExcel", "State", FormatType.TEXT),
								new PLMXlsxRptColumn("owner", "Owner", FormatType.TEXT),
								new PLMXlsxRptColumn("co_owner", "Co Owner", FormatType.TEXT),
								new PLMXlsxRptColumn("orig_nator", "Orignator", FormatType.TEXT),
								new PLMXlsxRptColumn("resp_Org", "Responsible Organization", FormatType.TEXT),
								new PLMXlsxRptColumn("orig_date_from_excel", "Originated From Date", FormatType.TEXT),
								new PLMXlsxRptColumn("orig_date_to_excel", "Originated To Date", FormatType.TEXT),
								new PLMXlsxRptColumn("estim_date_from_excel", "Estimated Finish From", FormatType.TEXT),
								new PLMXlsxRptColumn("estim_date_to_excel", "Estimated Finish To", FormatType.TEXT),
								new PLMXlsxRptColumn("act_date_from_excel", "Actual Finish From", FormatType.TEXT),
								new PLMXlsxRptColumn("act_date_to_excel", "Actual Finish To", FormatType.TEXT),
								new PLMXlsxRptColumn("source_sysExcel", "Source System", FormatType.TEXT),
								new PLMXlsxRptColumn("priorityExcel", "Priority", FormatType.TEXT),
								new PLMXlsxRptColumn("int_priorityExcel", "Internal Priority", FormatType.TEXT),
								new PLMXlsxRptColumn("catgExcel", "Category", FormatType.TEXT),
								new PLMXlsxRptColumn("clas_ficationExcel", "Classification", FormatType.TEXT),
								new PLMXlsxRptColumn("problem_typeExcel", "Problem Type", FormatType.TEXT)

						};
		
		if (reportNm.equals("issueHdrRpt")) {

			fileName = "Issue Report";
			LOG.info("fileName>>> " + fileName);
			PLMXlsxRptColumn[] reportColumns =
							new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("name", "Name", FormatType.TEXT, null, null, 25),
									new PLMXlsxRptColumn("desc", "Description", FormatType.TEXT, null, null, 35),
									new PLMXlsxRptColumn("state", "State", FormatType.TEXT), 
									new PLMXlsxRptColumn("owner", "Owner SSO", FormatType.TEXT),
									new PLMXlsxRptColumn("ownerName", "Owner Name", FormatType.TEXT, null, null, 20),
									new PLMXlsxRptColumn("orig_nator", "Orig. SSO", FormatType.TEXT),
									new PLMXlsxRptColumn("originatorName", "Orig. Name", FormatType.TEXT, null, null, 20),
									new PLMXlsxRptColumn("orig_date_from", "Originated Date", FormatType.DATE, null, null, 10),
									new PLMXlsxRptColumn("estim_date_from", "Est. Finish", FormatType.DATE, null, null, 10),
									new PLMXlsxRptColumn("act_date_from", "Act. Finish", FormatType.DATE, null, null, 10),
									new PLMXlsxRptColumn("priority", "Priority", FormatType.TEXT, null, null, 10),
									new PLMXlsxRptColumn("int_priority", "Internal Priority", FormatType.TEXT),
									new PLMXlsxRptColumn("catg", "Category", FormatType.TEXT, null, null, 20),
									new PLMXlsxRptColumn("clas_fication", "Classification", FormatType.TEXT, null, null, 20),
									new PLMXlsxRptColumn("problem_type", "Problem Type", FormatType.TEXT),
									new PLMXlsxRptColumn("resp_Org", "Resp. Organization", FormatType.TEXT),
									new PLMXlsxRptColumn("source_sys", "Source System", FormatType.TEXT, null, null, 20),
									new PLMXlsxRptColumn("lastStateChange", "Last State Change", FormatType.DATE),
									new PLMXlsxRptColumn("actionTaken", "Action Taken", FormatType.TEXT),
									new PLMXlsxRptColumn("reportdObjNmStr", "Reported Against", FormatType.TEXT)
	
							};
	
			excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, searchDetails);
			
		} else {

			fileName = "Issue Details";
			LOG.info("fileName>>> " + fileName);
			PLMXlsxRptColumn[] reportColumns =
							new PLMXlsxRptColumn[] {

							new PLMXlsxRptColumn("name", "Name", FormatType.TEXT, null, null, 25), 
									new PLMXlsxRptColumn("desc", "Description", FormatType.TEXT, null, null, 35),
									new PLMXlsxRptColumn("contractName", "Contract Name", FormatType.TEXT),
									new PLMXlsxRptColumn("documentName", "Document Name", FormatType.TEXT),
									new PLMXlsxRptColumn("partName", "Part Name", FormatType.TEXT, null, null, 25),
									new PLMXlsxRptColumn("hardWareBldNm", "Hardware Build Name", FormatType.TEXT),
									new PLMXlsxRptColumn("unitSerialNum", "Unit Serial Number", FormatType.TEXT, null, null, 10),
									new PLMXlsxRptColumn("projectName", "Project Name", FormatType.TEXT),
									new PLMXlsxRptColumn("resolvedToNm", "Resolved By Name", FormatType.TEXT),
									new PLMXlsxRptColumn("state", "State", FormatType.TEXT), 
									new PLMXlsxRptColumn("owner", "Owner SSO", FormatType.TEXT),
									new PLMXlsxRptColumn("ownerName", "Owner Name", FormatType.TEXT, null, null, 20),
									new PLMXlsxRptColumn("co_owner", "Co-Owner SSO", FormatType.TEXT),
									new PLMXlsxRptColumn("coOwnerName", "Co-Owner Name", FormatType.TEXT, null, null, 20),
									new PLMXlsxRptColumn("orig_nator", "Orig. SSO", FormatType.TEXT),
									new PLMXlsxRptColumn("originatorName", "Orig. Name", FormatType.TEXT, null, null, 20),
									new PLMXlsxRptColumn("orig_date_from", "Originated Date", FormatType.DATE, null, null, 10),
									new PLMXlsxRptColumn("estim_date_from", "Est. Finish", FormatType.DATE, null, null, 10),
									new PLMXlsxRptColumn("act_date_from", "Act. Finish", FormatType.DATE, null, null, 10),
									new PLMXlsxRptColumn("cycle_time", "Cycle Time", FormatType.TEXT, null, null, 8),
									new PLMXlsxRptColumn("priority", "Priority", FormatType.TEXT, null, null, 10),
									new PLMXlsxRptColumn("int_priority", "Internal Priority", FormatType.TEXT),
									new PLMXlsxRptColumn("catg", "Category", FormatType.TEXT),
									new PLMXlsxRptColumn("clas_fication", "Classification", FormatType.TEXT),
									new PLMXlsxRptColumn("problem_type", "Problem Type", FormatType.TEXT),
									new PLMXlsxRptColumn("source_sys", "Source System", FormatType.TEXT),
									new PLMXlsxRptColumn("resp_Org", "Resp. Organization", FormatType.TEXT)

							};

			excelUtil.export(searchIssueDetailsResultList, reportColumns, fileName, fileName, true, critcolumns, searchDetails);
		}
		LOG.info("Exiting downloadIssueExcel Method");
	}
	
	public void downloadIssueCSV() throws PLMCommonException{

		LOG.info("Entering downloadIssueCSV Method");
		
		String reportNm = reportName;
		String fileName;
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		LOG.info("reportName>>> " + reportNm);

		PLMCsvRptUtil excelUtil = new PLMCsvRptUtil();
		
		if (reportNm.equals("issueHdrRpt")) {

			fileName = "Issue Report";
			LOG.info("fileName>>> " + fileName);
			PLMCsvRptColumn[] reportColumns =
							new PLMCsvRptColumn[] {new PLMCsvRptColumn("name", "Name", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("desc", "Description", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("state", "State", FormatTypeCsv.TEXT), 
									new PLMCsvRptColumn("owner", "Owner SSO", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("ownerName", "Owner Name", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("orig_nator", "Orig. SSO", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("originatorName", "Orig. Name", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("orig_date_from", "Originated Date", FormatTypeCsv.DATE),
									new PLMCsvRptColumn("estim_date_from", "Est. Finish", FormatTypeCsv.DATE),
									new PLMCsvRptColumn("act_date_from", "Act. Finish", FormatTypeCsv.DATE),
									new PLMCsvRptColumn("priority", "Priority", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("int_priority", "Internal Priority", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("catg", "Category", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("clas_fication", "Classification", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("problem_type", "Problem Type", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("resp_Org", "Resp. Organization", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("source_sys", "Source System", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("lastStateChange", "Last State Change", FormatTypeCsv.DATE),
									new PLMCsvRptColumn("actionTaken", "Action Taken", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("reportdObjNmStr", "Reported Against", FormatTypeCsv.TEXT)
	
							};
	
	
			excelUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, null, ",");
			
		} else {

			fileName = "Issue Details";
			LOG.info("fileName>>> " + fileName);
			PLMCsvRptColumn[] reportColumns =
							new PLMCsvRptColumn[] {

							new PLMCsvRptColumn("name", "Name", FormatTypeCsv.TEXT), new PLMCsvRptColumn("desc", "Description", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("contractName", "Contract Name", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("documentName", "Document Name", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("partName", "Part Name", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("hardWareBldNm", "Hardware Build Name", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("unitSerialNum", "Unit Serial Number", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("projectName", "Project Name", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("resolvedToNm", "Resolved By Name", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("state", "State", FormatTypeCsv.TEXT), 
									new PLMCsvRptColumn("owner", "Owner SSO", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("ownerName", "Owner Name", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("co_owner", "Co-Owner SSO", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("coOwnerName", "Co-Owner Name", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("orig_nator", "Orig. SSO", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("originatorName", "Orig. Name", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("orig_date_from", "Originated Date", FormatTypeCsv.DATE),
									new PLMCsvRptColumn("estim_date_from", "Est. Finish", FormatTypeCsv.DATE),
									new PLMCsvRptColumn("act_date_from", "Act. Finish", FormatTypeCsv.DATE),
									new PLMCsvRptColumn("cycle_time", "Cycle Time", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("priority", "Priority", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("int_priority", "Internal Priority", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("catg", "Category", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("clas_fication", "Classification", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("problem_type", "Problem Type", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("source_sys", "Source System", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("resp_Org", "Resp. Organization", FormatTypeCsv.TEXT)


							};

			excelUtil.exportCsv(searchIssueDetailsResultList, reportColumns, fileName, dateFormat, false, null, null, ",");
		}

		LOG.info("Exiting downloadIssueCSV Method");
	}
	
	public String backtoIssuesReport(){
		LOG.info("-----back To Issue Report---");
		reportName="issueHdrRpt";
	 return "backtoissuesearchreport";
	}
	
	/**
	 * @param recordCounts the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		PLMUtils.getServletSession(true).setAttribute("RecDropDown",recordCounts);
		this.recordCounts = recordCounts;
	}

	/**
	 * @return the searchResultList
	 */
	public List<PLMIssuesReportData> getSearchResultList() {
		return searchResultList;
	}

	/**
	 * @param searchResultList
	 *            the searchResultList to set
	 */
	public void setSearchResultList(List<PLMIssuesReportData> searchResultList) {
		this.searchResultList = searchResultList;
	}

	/**
	 * @return the searchDetails
	 */
	public PLMIssuesReportData getSearchDetails() {
		return searchDetails;
	}

	/**
	 * @param searchDetails
	 *            the searchDetails to set
	 */
	public void setSearchDetails(PLMIssuesReportData searchDetails) {
		this.searchDetails = searchDetails;
	}

	/**
	 * @return the count
	 */
	public int getCount() {
		return count;
	}

	/**
	 * @param count
	 *            the count to set
	 */
	public void setCount(int count) {
		this.count = count;
	}

	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount
	 *            the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/**
	 * @return the totalRecCountMsg
	 */
	public String getTotalRecCountMsg() {
		return totalRecCountMsg;
	}

	/**
	 * @param totalRecCountMsg
	 *            the totalRecCountMsg to set
	 */
	public void setTotalRecCountMsg(String totalRecCountMsg) {
		this.totalRecCountMsg = totalRecCountMsg;
	}

	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * @param fieldName
	 *            the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage
	 *            the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}
	/**
	 * @return the plmIssuesService
	 */
	public PLMkpiReportServiceIfc getPlmIssuesService() {
		return plmIssuesService;
	}
	/**
	 * @param plmIssuesService the plmIssuesService to set
	 */
	public void setPlmIssuesService(PLMkpiReportServiceIfc plmIssuesService) {
		this.plmIssuesService = plmIssuesService;
	}

	/**
	 * @return the issuesstate
	 */
	public List<SelectItem> getIssuesstate() {
		return issuesstate;
	}

	/**
	 * @param issuesstate
	 *            the issuesstate to set
	 */
	public void setIssuesstate(List<SelectItem> issuesstate) {
		this.issuesstate = issuesstate;
	}

	/**
	 * @return the issuespriority
	 */
	public List<SelectItem> getIssuespriority() {
		return issuespriority;
	}

	/**
	 * @param issuespriority
	 *            the issuespriority to set
	 */
	public void setIssuespriority(List<SelectItem> issuespriority) {
		this.issuespriority = issuespriority;
	}

	/**
	 * @return the issuesintpriority
	 */
	public List<SelectItem> getIssuesintpriority() {
		return issuesintpriority;
	}

	/**
	 * @param issuesintpriority
	 *            the issuesintpriority to set
	 */
	public void setIssuesintpriority(List<SelectItem> issuesintpriority) {
		this.issuesintpriority = issuesintpriority;
	}
	
	

	/**
	 * @return the issuesprobtype
	 */
	public List<SelectItem> getIssuesprobtype() {
		return issuesprobtype;
	}

	/**
	 * @param issuesprobtype the issuesprobtype to set
	 */
	public void setIssuesprobtype(List<SelectItem> issuesprobtype) {
		this.issuesprobtype = issuesprobtype;
	}

	/**
	 * @return the issuescategory
	 */
	public List<SelectItem> getIssuescategory() {
		return issuescategory;
	}

	/**
	 * @param issuescategory the issuescategory to set
	 */
	public void setIssuescategory(List<SelectItem> issuescategory) {
		this.issuescategory = issuescategory;
	}

	/**
	 * @return the issuesclassification
	 */
	public List<SelectItem> getIssuesclassification() {
		return issuesclassification;
	}

	/**
	 * @param issuesclassification the issuesclassification to set
	 */
	public void setIssuesclassification(List<SelectItem> issuesclassification) {
		this.issuesclassification = issuesclassification;
	}

	/**
	 * @return the selectedissues
	 */
	public String getSelectedissues() {
		return selectedissues;
	}

	/**
	 * @param selectedissues
	 *            the selectedissues to set
	 */
	public void setSelectedissues(String selectedissues) {
		this.selectedissues = selectedissues;
	}

	/**
	 * @return the issuetotalRecCountMsg
	 */
	public String getIssuetotalRecCountMsg() {
		return issuetotalRecCountMsg;
	}

	/**
	 * @param issuetotalRecCountMsg
	 *            the issuetotalRecCountMsg to set
	 */
	public void setIssuetotalRecCountMsg(String issuetotalRecCountMsg) {
		this.issuetotalRecCountMsg = issuetotalRecCountMsg;
	}

	/**
	 * @return the issuerecordCounts
	 */
	public int getIssuerecordCounts() {
		return issuerecordCounts;
	}

	/**
	 * @param issuerecordCounts
	 *            the issuerecordCounts to set
	 */
	public void setIssuerecordCounts(int issuerecordCounts) {
		this.issuerecordCounts = issuerecordCounts;
	}

	/**
	 * @return the issuetotalRecCount
	 */
	public int getIssuetotalRecCount() {
		return issuetotalRecCount;
	}

	/**
	 * @param issuetotalRecCount
	 *            the issuetotalRecCount to set
	 */
	public void setIssuetotalRecCount(int issuetotalRecCount) {
		this.issuetotalRecCount = issuetotalRecCount;
	}

	/**
	 * @return the searchIssueDetailsResultList
	 */
	public List<PLMIssuesReportData> getSearchIssueDetailsResultList() {
		return searchIssueDetailsResultList;
	}

	/**
	 * @param searchIssueDetailsResultList
	 *            the searchIssueDetailsResultList to set
	 */
	public void setSearchIssueDetailsResultList(
			List<PLMIssuesReportData> searchIssueDetailsResultList) {
		this.searchIssueDetailsResultList = searchIssueDetailsResultList;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the issuesSourceSystem
	 */
	public List<SelectItem> getIssuesSourceSystem() {
		return issuesSourceSystem;
	}

	/**
	 * @param issuesSourceSystem the issuesSourceSystem to set
	 */
	public void setIssuesSourceSystem(List<SelectItem> issuesSourceSystem) {
		this.issuesSourceSystem = issuesSourceSystem;
	}

	
	/**
	 * @return the reportName
	 */
	public String getReportName() {
		return reportName;
	}

	
	/**
	 * @param reportName the reportName to set
	 */
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	
	
}