package com.geinfra.geaviation.pwi.context;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.geinfra.geaviation.pwi.bean.util.RptTypeRelMetaDataUtil;
import com.geinfra.geaviation.pwi.common.PWiException;

/**
 * Project : Product Lifecycle Management Date Written : Security : GE
 * Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : Loads the PWi application context.
 * 
 * Revision Log --------------------------------------------------------------
 */
public class PWiApplicationContextLoaderListener implements
		ServletContextListener {

	public void contextInitialized(ServletContextEvent event) {
		ServletContext servletContext = event.getServletContext();
		try {
			RptTypeRelMetaDataUtil.populateTypeRelData();
		} catch (PWiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		servletContext.setAttribute(PWiApplicationContext.ATTRIBUTE_NAME,
				new PWiApplicationContext());
	}
	
	public void contextDestroyed(ServletContextEvent event) {
		// nothing to do
	}
}
