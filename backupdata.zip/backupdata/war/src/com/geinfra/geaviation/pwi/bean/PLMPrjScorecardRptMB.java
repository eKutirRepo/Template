/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMPrjScorecardRptMB.java
 * @Creation date: 09-August-2017
 * @version 1.0
 * @author : Tech Mahindra (PWi Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TreeMap;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMCFQLCompareData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMCFQLCompareServiceIfc;
import com.geinfra.geaviation.pwi.service.PLMCommonReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMPrjScorecardRptMB {

	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMPrjScorecardRptMB.class);
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds user information
	 */
	private PLMPwiUserData userDetails = null;

	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	/**
	 * Holds the resourceBundle
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the PLMEBomToMBomServiceIfc
	 */
	private PLMCFQLCompareServiceIfc plmCFQLCompareService  = null;
	/**
	 * Holds the plmCommonReportService
	 */
	private PLMCommonReportServiceIfc plmCommonReportService  = null;
	/**
	 * Holds the inputPCList
	 */
	private List<String> inputPCList=new ArrayList<String>();
	/**
	   *  Holds the inputPCCount
	   */
	 private int inputPCCount = 0;
	 /**
	 * chapterFlag.
	 */
	private boolean chapterFlag;
	 /**
	 * sequenceNum.
	 */
	private boolean sequenceNum;
	 /**
	 * subType.
	 */
	private boolean subType;
	 /**
	 * defaultType.
	 */
	private boolean defaultType;
	/**
	 * pcName1.
	 */
	private String pcName1;
	/**
	 * pcName2.
	 */
	private String pcName2;
	/**
	 * pcName3.
	 */
	private String pcName3;
	/**
	 * pcName4.
	 */
	private String pcName4;
	/**
	 * pcName5.
	 */
	private String pcName5;
	/**
	 * pcName6.
	 */
	private String pcName6;
	/**
	 * pcName7.
	 */
	private String pcName7;
	/**
	 * pcName8.
	 */
	private String pcName8;
	/**
	 * pcName9.
	 */
	private String pcName9;
	/**
	 * pcName10.
	 */
	private String pcName10;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;
	 /**
	 * This method is used for Loading Project Scorecard Home Page
	 * @return String
	 */
	public String loadPrjScorecardHome() {
		LOG.info("Entering loadPrjScorecardHome Method");
		alertMessage = "";
		inputPCList =new ArrayList<String>();
		chapterFlag = true;
		sequenceNum = true;
		subType = true;
		defaultType = true;
		recordCounts = PLMConstants.N_100;
		pcName1 = "";
		pcName2 = "";
		pcName3 = "";
		pcName4 = "";
		pcName5 = "";
		pcName6 = "";
		pcName7 = "";
		pcName8 = "";
		pcName9 = "";
		pcName10 = "";
		try {
			commonMB.insertCannedRptRecordHitInfo("Project Scorecard Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		LOG.info("Exiting loadPrjScorecardHome Method");
		return "prjScorecardSrch";
	}
	
	/**
	 * This method is used for Email Generating Project Scorecard Report
	 * @return String
	 * @throws PLMCommonException 
	 * @throws PWiException 
	 */
	public String generateEmailRpt() throws PWiException {
		LOG.info("Entering generateEmailRpt Method");
		alertMessage = "";
		alertMessage = validatePCInput();
		String fwdFlag="prjScorecardSrch";
		userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		List<String> pcList = new ArrayList<String>();
		try {
			if(PLMUtils.isEmpty(alertMessage)) {
				pcList.addAll(inputPCList);
				String invalidMessage = plmCFQLCompareService.getValidPCName(pcList);
				if(PLMUtils.isEmpty(invalidMessage)){
					alertMessage =  PLMConstants.PRJSC_MAIL_ALERT_MSG;
					taskExecutor.execute(new MailThread());
				}else{
					alertMessage =invalidMessage;
				}
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@generateEmailRpt: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"prjScorecardSrch","Project Scorecard");
		}
		LOG.info("Exiting generateEmailRpt Method");
		return fwdFlag;
	}
	
	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendRptMail();
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return void
	 */
	public void sendRptMail() {
		LOG.info("Entering sendRptMail Method");
		String from = PLMConstants.OMM_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.PRJSC_SUBJECT;
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("PRJSC_RPT") +  uniqTime + ".xlsx";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("PRJSC_RPT") +  uniqTime + ".zip";
		TreeMap <Integer,Object> cfQlCompareTreeMap = new TreeMap<Integer,Object>();
		List<String> inputPCListFinalLcl =inputPCList;
		boolean subtypeLcl=subType;
		boolean defaultTypeLcl =defaultType;
		boolean sequenceNmLcl= sequenceNum;
		boolean chapterFlagLcl =chapterFlag;
		try {
			cfQlCompareTreeMap = plmCFQLCompareService.getPrjScorecardData(inputPCListFinalLcl);
			List<String> marketNameListLcl = (List<String>) cfQlCompareTreeMap.get(0);
			List<PLMCFQLCompareData> prjSCListLcl = (List<PLMCFQLCompareData>) cfQlCompareTreeMap.get(1);
			StringBuffer mailBody = new StringBuffer().append(toAddressee);
			if(PLMUtils.isEmptyList(prjSCListLcl)){
				mailBody.append(PLMConstants.PRJSC_MAIL_CONTENT_NO_RECORD)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				PLMUtils.sendMail(from, to, subject, mailBody.toString());
			} else {
				mailBody.append(PLMConstants.PRJSC_MAIL_CONTENT)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				saveRptXLSFile(marketNameListLcl,prjSCListLcl,subtypeLcl,defaultTypeLcl,sequenceNmLcl,chapterFlagLcl,fileDir,filePathXls);
				PLMUtils.generateZipFile(filePathXls,filePathZip);
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} finally {
			PLMUtils.deleteFiles(filePathXls,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendRptMail Method");
	}
	
	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return void
	 */
	public void saveRptXLSFile(List<String> marketNameListLcl,List<PLMCFQLCompareData> prjSCListLcl,
			boolean subtypeLcl,boolean defaultTypeLcl,boolean sequenceNmLcl,boolean chapterFlagLcl,String fileDir,String filePathXls) throws IOException {
		LOG.info("Entering saveRptXLSFile Method");
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXls);
				XSSFWorkbook workbook = new XSSFWorkbook();
				
				XSSFFont font = headerFont(workbook, 10);
				
				// Header Style
				XSSFCellStyle headerStyle = headerCell(workbook, font, HSSFColor.PALE_BLUE.index, true);

				
				// Header Style
				XSSFCellStyle dateheaderStyle = dateStyleheaderCell(workbook, font, HSSFColor.WHITE.index, true);

				XSSFFont cellfont = normalFont(workbook, 10);
				// Cell Style
				XSSFCellStyle cellStyle = normalCell(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
				XSSFCellStyle cellStyleLeft = normalCellLeft(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
				XSSFCellStyle cellStyleRight = normalCellRight(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
				
				XSSFCellStyle cellStyleGreen = headerCell(workbook, font, HSSFColor.GREEN.index, true);
				XSSFCellStyle cellStyleRed = headerCell(workbook, font, HSSFColor.RED.index, true);
				
				XSSFCellStyle cellStyleCF = ((XSSFWorkbook) workbook).createCellStyle();
				cellStyleCF.setAlignment(CellStyle.ALIGN_CENTER);
				cellStyleCF.setFillForegroundColor(new XSSFColor(new java.awt.Color(242, 220, 219)));
				cellStyleCF.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
				cellStyleCF.setFont(font);
				
				XSSFCellStyle cellStyleCFLeft = ((XSSFWorkbook) workbook).createCellStyle();
				cellStyleCFLeft.setAlignment(CellStyle.ALIGN_LEFT);
				cellStyleCFLeft.setFillForegroundColor(new XSSFColor(new java.awt.Color(242, 220, 219)));
				cellStyleCFLeft.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
				cellStyleCFLeft.setFont(font);
				
				XSSFCellStyle cellStyleCFRight = ((XSSFWorkbook) workbook).createCellStyle();
				cellStyleCFRight.setAlignment(CellStyle.ALIGN_RIGHT);
				cellStyleCFRight.setFillForegroundColor(new XSSFColor(new java.awt.Color(242, 220, 219)));
				cellStyleCFRight.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
				cellStyleCFRight.setFont(font);

				XSSFSheet sheet =  (XSSFSheet) workbook.createSheet("Project Scorecard");
				int rowcount = 0;
				XSSFCell cell=null;
				XSSFRow row = (XSSFRow) sheet.createRow(rowcount);	
			   cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell. setCellValue(commonMB.getDateStampEtl());
				cell.setCellStyle(dateheaderStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,0,2));
				for(int j = 0 ;j < marketNameListLcl.size(); j++ ) {   
					row = (XSSFRow) sheet.createRow(++rowcount);
					int mergeVal=1;
					if(j>0){
					row = (XSSFRow) sheet.createRow(++rowcount);
					mergeVal = row.getRowNum();
					}
				
				cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell. setCellValue("Level");
				cell.setCellStyle(headerStyle);
				
				cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell. setCellValue("Display Name");
				cell.setCellStyle(headerStyle);
				
				cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
				cell. setCellValue("MF Option Name");
				cell.setCellStyle(headerStyle);

				cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
				cell. setCellValue("Rev");
				cell.setCellStyle(headerStyle);
				
				cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_FOUR);
				cell. setCellValue("Pegasus Code");
				cell.setCellStyle(headerStyle);
				
				int colHdrIncrSt=0;
				int colHdrIncrEd=0;
				
				if(chapterFlagLcl && sequenceNmLcl &&  subtypeLcl && defaultTypeLcl){
					 colHdrIncrSt=5;
					 colHdrIncrEd=11;
				}else if((chapterFlagLcl) && ((!sequenceNmLcl &&  subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl))){
					 colHdrIncrSt=5;
					 colHdrIncrEd=10;
				}else if((chapterFlagLcl) && ((sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl))){
					 colHdrIncrSt=5;
					 colHdrIncrEd=9;
				}else if(chapterFlagLcl && !sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl){
					 colHdrIncrSt=5;
					 colHdrIncrEd=8;
				}else if(!chapterFlagLcl && sequenceNmLcl &&  subtypeLcl && defaultTypeLcl){
					 colHdrIncrSt=5;
					 colHdrIncrEd=8;
				}else if((!chapterFlagLcl) && ((!sequenceNmLcl &&  subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl))){
					 colHdrIncrSt=5;
					 colHdrIncrEd=7;
				}else if((!chapterFlagLcl) && ((sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl))){
					 colHdrIncrSt=5;
					 colHdrIncrEd=6;
				}
		
					if(chapterFlagLcl && sequenceNmLcl &&  subtypeLcl && defaultTypeLcl){
						cell = (XSSFCell) row.createCell(colHdrIncrSt);
						cell.setCellValue(marketNameListLcl.get(j));
						cell.setCellStyle(headerStyle);
						cell = (XSSFCell) row.createCell(colHdrIncrEd);
						cell.setCellStyle(headerStyle);
						sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,colHdrIncrSt,colHdrIncrEd));
						cell.setCellStyle(headerStyle);
						colHdrIncrSt =colHdrIncrSt+7;
						colHdrIncrEd =colHdrIncrEd+7;
					}else if((chapterFlagLcl) && ((!sequenceNmLcl &&  subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl))){
						cell = (XSSFCell) row.createCell(colHdrIncrSt);
						cell.setCellValue(marketNameListLcl.get(j));
						cell.setCellStyle(headerStyle);
						cell = (XSSFCell) row.createCell(colHdrIncrEd);
						cell.setCellStyle(headerStyle);
						sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,colHdrIncrSt,colHdrIncrEd));
						cell.setCellStyle(headerStyle);
						colHdrIncrSt =colHdrIncrSt+6;
						colHdrIncrEd =colHdrIncrEd+6;
					}else if((chapterFlagLcl) && ((sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl))){
						cell = (XSSFCell) row.createCell(colHdrIncrSt);
						cell.setCellValue(marketNameListLcl.get(j));
						cell.setCellStyle(headerStyle);
						cell = (XSSFCell) row.createCell(colHdrIncrEd);
						cell.setCellStyle(headerStyle);
						sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,colHdrIncrSt,colHdrIncrEd));
						cell.setCellStyle(headerStyle);
						colHdrIncrSt =colHdrIncrSt+5;
						colHdrIncrEd =colHdrIncrEd+5;
					}else if(chapterFlagLcl && !sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl){
						cell = (XSSFCell) row.createCell(colHdrIncrSt);
						cell.setCellValue(marketNameListLcl.get(j));
						cell.setCellStyle(headerStyle);
						cell = (XSSFCell) row.createCell(colHdrIncrEd);
						cell.setCellStyle(headerStyle);
						sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,colHdrIncrSt,colHdrIncrEd));
						cell.setCellStyle(headerStyle);
						colHdrIncrSt =colHdrIncrSt+4;
						colHdrIncrEd =colHdrIncrEd+4;
					}else if(!chapterFlagLcl && sequenceNmLcl &&  subtypeLcl && defaultTypeLcl){
						cell = (XSSFCell) row.createCell(colHdrIncrSt);
						cell.setCellValue(marketNameListLcl.get(j));
						cell.setCellStyle(headerStyle);
						cell = (XSSFCell) row.createCell(colHdrIncrEd);
						cell.setCellStyle(headerStyle);
						sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,colHdrIncrSt,colHdrIncrEd));
						cell.setCellStyle(headerStyle);
						colHdrIncrSt =colHdrIncrSt+4;
						colHdrIncrEd =colHdrIncrEd+4;
					}else if((!chapterFlagLcl) && ((!sequenceNmLcl &&  subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl))){
						cell = (XSSFCell) row.createCell(colHdrIncrSt);
						cell.setCellValue(marketNameListLcl.get(j));
						cell.setCellStyle(headerStyle);
						cell = (XSSFCell) row.createCell(colHdrIncrEd);
						cell.setCellStyle(headerStyle);
						sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,colHdrIncrSt,colHdrIncrEd));
						cell.setCellStyle(headerStyle);
						colHdrIncrSt =colHdrIncrSt+3;
						colHdrIncrEd =colHdrIncrEd+3;
					}else if((!chapterFlagLcl) && ((sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl))){
						cell = (XSSFCell) row.createCell(colHdrIncrSt);
						cell.setCellValue(marketNameListLcl.get(j));
						cell.setCellStyle(headerStyle);
						cell = (XSSFCell) row.createCell(colHdrIncrEd);
						cell.setCellStyle(headerStyle);
						sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,colHdrIncrSt,colHdrIncrEd));
						cell.setCellStyle(headerStyle);
						colHdrIncrSt =colHdrIncrSt+2;
						colHdrIncrEd =colHdrIncrEd+2;
					}

				row = (XSSFRow) sheet.createRow(++rowcount);
				
				int colHdrTypeIncr=5;
			
					
					if(chapterFlagLcl){
						cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
						cell. setCellValue("Display Name Chapter");
						cell.setCellStyle(headerStyle);
						
						cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
						cell. setCellValue("MF Chapter");
						cell.setCellStyle(headerStyle);
	
						cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
						cell. setCellValue("Rev. Chapter");
						cell.setCellStyle(headerStyle);
				    }
					
					if(subtypeLcl){
						cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
						cell. setCellValue("Option Subtype");
						cell.setCellStyle(headerStyle);
					}
					
					if(defaultTypeLcl){
						cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
						cell. setCellValue("Default Selection");
						cell.setCellStyle(headerStyle);
					}

					if(sequenceNmLcl){
						cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
						cell. setCellValue("Sequence Number");
						cell.setCellStyle(headerStyle);
					}
					
					cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
					cell. setCellValue("Available");
					cell.setCellStyle(headerStyle);
					
					
			
				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellStyle(headerStyle);
				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellStyle(headerStyle);
				sheet.addMergedRegion(new CellRangeAddress(mergeVal,mergeVal+1,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ZERO));
				cell.setCellStyle(headerStyle);
			
				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellStyle(headerStyle);
				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellStyle(headerStyle);
				sheet.addMergedRegion(new CellRangeAddress(mergeVal,mergeVal+1,PLMConstants.EXCEL_COL_ONE,PLMConstants.EXCEL_COL_ONE));
				cell.setCellStyle(headerStyle);

				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
				cell.setCellStyle(headerStyle);
				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
				cell.setCellStyle(headerStyle);
				sheet.addMergedRegion(new CellRangeAddress(mergeVal,mergeVal+1,PLMConstants.EXCEL_COL_TWO,PLMConstants.EXCEL_COL_TWO));
				cell.setCellStyle(headerStyle);

				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
				cell.setCellStyle(headerStyle);
				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
				cell.setCellStyle(headerStyle);
				sheet.addMergedRegion(new CellRangeAddress(mergeVal,mergeVal+1,PLMConstants.EXCEL_COL_THREE,PLMConstants.EXCEL_COL_THREE));
				cell.setCellStyle(headerStyle);
				
				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
				cell.setCellStyle(headerStyle);
				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
				cell.setCellStyle(headerStyle);
				sheet.addMergedRegion(new CellRangeAddress(mergeVal,mergeVal+1,PLMConstants.EXCEL_COL_FOUR,PLMConstants.EXCEL_COL_FOUR));
				cell.setCellStyle(headerStyle);
				
				int colnum = colHdrTypeIncr;
				for (int a = 0; a < inputPCList.size(); a++) {
					cell = (XSSFCell)row.createCell(colnum + a);
					cell. setCellValue(inputPCList.get(a) + " Current Selection");
					cell.setCellStyle(headerStyle);
					cell = (XSSFCell)row.createCell(colnum + a + 1);
					cell. setCellValue("CR# from " + inputPCList.get(a));
					cell.setCellStyle(headerStyle);
					colnum++;
				}
			
				int colIncr=0;
				for (int i=0;i<prjSCListLcl.size();i++) {
					
					colIncr=5;
					PLMCFQLCompareData	 dataObj = (PLMCFQLCompareData)prjSCListLcl.get(i);
					
					String marketingName=dataObj.getHpMarketingNm()  + " " + dataObj.getHwPrdctNm();
					
					String marketingListName=marketNameListLcl.get(j);
					
					
					if(marketingName.equalsIgnoreCase(marketingListName)){
						
						row = (XSSFRow) sheet.createRow(++rowcount);
						if ("2".equalsIgnoreCase(dataObj.getLevel())) {
							cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
							cell.setCellStyle(cellStyleCFRight);
							cell.setCellValue(dataObj.getLevel());
							
							cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellStyle(cellStyleCFLeft);
							cell.setCellValue(dataObj.getDisplayNm());
							
							cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
							cell.setCellStyle(cellStyleCFLeft);
							cell.setCellValue(dataObj.getConfOption());
			
							cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
							cell.setCellStyle(cellStyleCF);
							cell.setCellValue(dataObj.getRev());
			
							cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
							cell.setCellStyle(cellStyleCFLeft);
							cell.setCellValue(dataObj.getPegasusCode());
			
							//for ( int j = 0 ; j < dataObj.getTypeList().size(); j++ ) {
								
								if(chapterFlagLcl){
								cell = (XSSFCell) row.createCell(colIncr++);
								cell.setCellStyle(cellStyleCFLeft);
								cell.setCellValue(dataObj.getChDisplayNm());
			
								cell = (XSSFCell) row.createCell(colIncr++);
								cell.setCellStyle(cellStyleCFLeft);
								cell.setCellValue(dataObj.getMfChapter());
			
								cell = (XSSFCell) row.createCell(colIncr++);
								cell.setCellStyle(cellStyleCFLeft);
								cell.setCellValue(dataObj.getRevChapter());
								}
								
								if(subtypeLcl){
									cell = (XSSFCell) row.createCell(colIncr++);
									cell.setCellStyle(cellStyleCFLeft);
									cell.setCellValue(dataObj.getSubType());
								}
								
								if(defaultTypeLcl){
									cell = (XSSFCell) row.createCell(colIncr++);
									cell.setCellStyle(cellStyleCFLeft);
									cell.setCellValue(dataObj.getDefaultType());
								}
			
								if(sequenceNmLcl){
									cell = (XSSFCell) row.createCell(colIncr++);
									cell.setCellStyle(cellStyleCFRight);
									cell.setCellValue(dataObj.getSequenceNum());
								}
								
								cell = (XSSFCell) row.createCell(colIncr++);
								cell.setCellValue("");
				                if (dataObj.isAvailable()) {
				                	cell.setCellStyle(cellStyleGreen);
				                } else {
				                	cell.setCellStyle(cellStyleRed);
				                }
							//}
						} else if ("3".equalsIgnoreCase(dataObj.getLevel())) {
							cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
							cell.setCellStyle(cellStyleRight);
							cell.setCellValue(dataObj.getLevel());
							
							cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellStyle(cellStyleLeft);
							cell.setCellValue(dataObj.getDisplayNm());
							
							cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
							cell.setCellStyle(cellStyleLeft);
							cell.setCellValue(dataObj.getConfOption());

							cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
							cell.setCellStyle(cellStyle);
							cell.setCellValue(dataObj.getRev());

							cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
							cell.setCellStyle(cellStyleLeft);
							cell.setCellValue(dataObj.getPegasusCode());

							if(chapterFlagLcl){
							cell = (XSSFCell) row.createCell(colIncr++);
							cell.setCellStyle(cellStyleLeft);
							cell.setCellValue(dataObj.getChDisplayNm());

							cell = (XSSFCell) row.createCell(colIncr++);
							cell.setCellStyle(cellStyleLeft);
							cell.setCellValue(dataObj.getMfChapter());

							cell = (XSSFCell) row.createCell(colIncr++);
							cell.setCellStyle(cellStyleLeft);
							cell.setCellValue(dataObj.getRevChapter());
							}
							
							if(subtypeLcl){
								cell = (XSSFCell) row.createCell(colIncr++);
								cell.setCellStyle(cellStyleLeft);
								cell.setCellValue(dataObj.getSubType());
							}
							
							if(defaultTypeLcl){
								cell = (XSSFCell) row.createCell(colIncr++);
								cell.setCellStyle(cellStyleLeft);
								cell.setCellValue(dataObj.getDefaultType());
							}

							if(sequenceNmLcl){
								cell = (XSSFCell) row.createCell(colIncr++);
								cell.setCellStyle(cellStyleRight);
								cell.setCellValue(dataObj.getSequenceNum());
							}
							
							cell = (XSSFCell) row.createCell(colIncr++);
							cell.setCellValue("");
			                if (dataObj.isAvailable()) {
			                	cell.setCellStyle(cellStyleGreen);
			                } else {
			                	cell.setCellStyle(cellStyleRed);
			                }
			                
			                String[] pcArray = dataObj.getPcChkList();
			                String[] crArray = dataObj.getCrValList();
			                for (int a = 0; a < pcArray.length; a++) {
			                	cell = (XSSFCell) row.createCell(colIncr++);
								cell.setCellStyle(cellStyle);
								cell.setCellValue(pcArray[a]);
								
								cell = (XSSFCell) row.createCell(colIncr++);
								cell.setCellStyle(cellStyle);
								cell.setCellValue(crArray[a]);
			                }
						}
					}
				
					
					
					
				}
				
				}
				
				
				row = (XSSFRow) sheet.createRow(++rowcount);
				row = (XSSFRow) sheet.createRow(++rowcount);
				
			    XSSFCellStyle ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
			    ftrStyle.setFont(font);
			    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			    cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
			    cell.setCellStyle(ftrStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_THREE));
				
				sheet.createFreezePane( 0, 3 );
				sheet.setColumnWidth(1, 8000);
				sheet.setColumnWidth(2, 4500);
				sheet.setColumnWidth(4, 4000);
				
				int colStart = 0;
				int colEnd = 0;
				
				if(chapterFlagLcl && sequenceNmLcl &&  subtypeLcl && defaultTypeLcl){
					colStart = 5;
					colEnd = 10;
					for ( int j = 0 ;j < marketNameListLcl.size(); j++ ) {
						sheet.groupColumn(colStart, colEnd);
						sheet.setColumnGroupCollapsed(colStart, false);
						colStart = colStart + 7;
						colEnd = colEnd + 7;
					}
				}else if((chapterFlagLcl) && ((!sequenceNmLcl &&  subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl))){
					colStart = 5;
					colEnd = 9;
					for ( int j = 0 ;j < marketNameListLcl.size(); j++ ) {
						sheet.groupColumn(colStart, colEnd);
						sheet.setColumnGroupCollapsed(colStart, false);
						colStart = colStart + 6;
						colEnd = colEnd + 6;
					}
				}else if((chapterFlagLcl) && ((sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl))){
					colStart = 5;
					colEnd = 8;
					for ( int j = 0 ;j < marketNameListLcl.size(); j++ ) {
						sheet.groupColumn(colStart, colEnd);
						sheet.setColumnGroupCollapsed(colStart, false);
						colStart = colStart + 5;
						colEnd = colEnd + 5;
					}
				}else if(chapterFlagLcl && !sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl){
					colStart = 5;
					colEnd = 7;
					for ( int j = 0 ;j < marketNameListLcl.size(); j++ ) {
						sheet.groupColumn(colStart, colEnd);
						sheet.setColumnGroupCollapsed(colStart, false);
						colStart = colStart + 4;
						colEnd = colEnd + 4;
					}
				}else if(!chapterFlagLcl && sequenceNmLcl &&  subtypeLcl && defaultTypeLcl){
					colStart = 5;
					colEnd = 7;
					for ( int j = 0 ;j < marketNameListLcl.size(); j++ ) {
						sheet.groupColumn(colStart, colEnd);
						sheet.setColumnGroupCollapsed(colStart, false);
						colStart = colStart + 4;
						colEnd = colEnd + 4;
					}
				}else if((!chapterFlagLcl) && ((!sequenceNmLcl &&  subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl))){
					colStart = 5;
					colEnd = 6;
					for ( int j = 0 ;j < marketNameListLcl.size(); j++ ) {
						sheet.groupColumn(colStart, colEnd);
						sheet.setColumnGroupCollapsed(colStart, false);
						colStart = colStart + 3;
						colEnd = colEnd + 3;
					}
				}else if((!chapterFlagLcl) && ((sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl))){
					colStart = 5;
					colEnd = 5;
					for ( int j = 0 ;j < marketNameListLcl.size(); j++ ) {
						sheet.groupColumn(colStart, colEnd);
						sheet.setColumnGroupCollapsed(colStart, false);
						colStart = colStart + 2;
						colEnd = colEnd + 2;
					}
				}
				sheet.setZoom(85);
				workbook.write(fileOut);
				fileOut.close();
		  }	
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveRptXLSFile: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveRptXLSFile: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveRptXLSFile: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveRptXLSFile Method");
	}

	private XSSFFont headerFont(XSSFWorkbook wb, int size){
		XSSFFont font = (XSSFFont) wb.createFont();
		font.setFontName(PLMConstants.EXCEL_FONT_NAME_CALIBRI);
		font.setFontHeightInPoints((short)size);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		return font;
	}
	
	private XSSFFont normalFont(XSSFWorkbook wb, int size){
		XSSFFont font = (XSSFFont) wb.createFont();
		font.setFontName(PLMConstants.EXCEL_FONT_NAME_CALIBRI);
		font.setFontHeightInPoints((short)size);
		return font;
	}
	
	private XSSFCellStyle headerCell(XSSFWorkbook wb, XSSFFont font, short bgcolor, boolean wrap){
		XSSFCellStyle hCell = normalCell(wb, font, XSSFCellStyle.SOLID_FOREGROUND, wrap);
		//FONT
		hCell.setFont(font);
		//WRAP TEXT
		hCell.setWrapText(wrap);
		
		//HORIZONTAL ALIGNMENT
		hCell.setAlignment(XSSFCellStyle.ALIGN_CENTER);
		
		//COLOR
		hCell.setFillForegroundColor(bgcolor);
		return hCell;
	}
	
	
	private XSSFCellStyle dateStyleheaderCell(XSSFWorkbook wb, XSSFFont font, short bgcolor, boolean wrap){
		XSSFCellStyle hCell = normalCellLeft(wb, font, XSSFCellStyle.NO_FILL, wrap);
		//FONT
		hCell.setFont(font);
		
		//HORIZONTAL ALIGNMENT
		hCell.setAlignment(XSSFCellStyle.ALIGN_LEFT);
		
		//COLOR
		//hCell.setFillForegroundColor(bgcolor);
		return hCell;
	}
	
	private XSSFCellStyle normalCell(XSSFWorkbook wb, XSSFFont font, short fillPattern, boolean wrap){
		// Cell Style
		XSSFCellStyle cellStyle = (XSSFCellStyle)wb.createCellStyle();
		
		//Set Font
		cellStyle.setFont(font);
		//WRAP TEXT
		//cellStyle.setWrapText(wrap);
		
		//VERTICAL ALIGNMENT
		cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
		
		//BORDERS
		cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		
		//FILL PATTERN
		cellStyle.setFillPattern(fillPattern);
		return cellStyle;
	}
	private XSSFCellStyle normalCellLeft(XSSFWorkbook wb, XSSFFont font, short fillPattern, boolean wrap){
		// Cell Style
		XSSFCellStyle cellStyle = (XSSFCellStyle)wb.createCellStyle();
		
		//Set Font
		cellStyle.setFont(font);
		//WRAP TEXT
		//cellStyle.setWrapText(wrap);
		
		//VERTICAL ALIGNMENT
		cellStyle.setAlignment(XSSFCellStyle.ALIGN_LEFT);
		
		//BORDERS
		cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		
		//FILL PATTERN
		cellStyle.setFillPattern(fillPattern);
		return cellStyle;
	}
	
	private XSSFCellStyle normalCellRight(XSSFWorkbook wb, XSSFFont font, short fillPattern, boolean wrap){
		// Cell Style
		XSSFCellStyle cellStyle = (XSSFCellStyle)wb.createCellStyle();
		
		//Set Font
		cellStyle.setFont(font);
		//WRAP TEXT
		//cellStyle.setWrapText(wrap);
		
		//VERTICAL ALIGNMENT
		cellStyle.setAlignment(XSSFCellStyle.ALIGN_RIGHT);
		
		//BORDERS
		cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		
		//FILL PATTERN
		cellStyle.setFillPattern(fillPattern);
		return cellStyle;
	}
	/**
	 * @return
	 */
	public String validatePCInput() {
		LOG.info("Entering validatePCInput Method");
		String alertMsg = "";
		boolean invalidFlag = false;
		if (PLMUtils.isEmpty(pcName1)  && PLMUtils.isEmpty(pcName2) && PLMUtils.isEmpty(pcName3)
				&& PLMUtils.isEmpty(pcName4) && PLMUtils.isEmpty(pcName5) && PLMUtils.isEmpty(pcName6)
				 && PLMUtils.isEmpty(pcName7) && PLMUtils.isEmpty(pcName8) && PLMUtils.isEmpty(pcName9)
				 && PLMUtils.isEmpty(pcName10)) {
			alertMsg = PLMConstants.PRJSC_SEARCH_CRITERIA_OPT;
			invalidFlag = true;
		} 
		
		if (!invalidFlag) {
		if (!PLMUtils.checkForSpecialChars(pcName1)  || !PLMUtils.checkForSpecialChars(pcName2) || !PLMUtils.checkForSpecialChars(pcName3)
				|| !PLMUtils.checkForSpecialChars(pcName4) || !PLMUtils.checkForSpecialChars(pcName5) || !PLMUtils.checkForSpecialChars(pcName6)
				|| !PLMUtils.checkForSpecialChars(pcName7) || !PLMUtils.checkForSpecialChars(pcName8) || !PLMUtils.checkForSpecialChars(pcName9)
				|| !PLMUtils.checkForSpecialChars(pcName10)) {
			alertMsg = PLMConstants.PRJSC_SPLCHAR_CRITERIA;
			invalidFlag = true;
		}}
		
		if (!invalidFlag) {
			Set<String> pcNmSet =new HashSet<String>();
			inputPCList = new ArrayList<String>();
			int matchCount =0;
			  if(!PLMUtils.isEmpty(pcName1)){
				  pcNmSet.add(pcName1);
				  inputPCList.add(pcName1);
				  matchCount++;
			  }
			  if(!PLMUtils.isEmpty(pcName2)){
				  pcNmSet.add(pcName2);
				  inputPCList.add(pcName2);
				  matchCount++;
			  }
			  if(!PLMUtils.isEmpty(pcName3)){
				  pcNmSet.add(pcName3);
				  inputPCList.add(pcName3);
				  matchCount++;
			  }
			  if(!PLMUtils.isEmpty(pcName4)){
				  pcNmSet.add(pcName4);
				  inputPCList.add(pcName4);
				  matchCount++;
			  }
			  if(!PLMUtils.isEmpty(pcName5)){
				  pcNmSet.add(pcName5);
				  inputPCList.add(pcName5);
				  matchCount++;
			  }
			  if(!PLMUtils.isEmpty(pcName6)){
				  pcNmSet.add(pcName6);
				  inputPCList.add(pcName6);
				  matchCount++;
			  }
			  if(!PLMUtils.isEmpty(pcName7)){
				  pcNmSet.add(pcName7);
				  inputPCList.add(pcName7);
				  matchCount++;
			  }
			  if(!PLMUtils.isEmpty(pcName8)){
				  pcNmSet.add(pcName8);
				  inputPCList.add(pcName8);
				  matchCount++;
			  }
			  if(!PLMUtils.isEmpty(pcName9)){
				  pcNmSet.add(pcName9);
				  inputPCList.add(pcName9);
				  matchCount++;
			  }
			  if(!PLMUtils.isEmpty(pcName10)){
				  pcNmSet.add(pcName10);
				  inputPCList.add(pcName10);
				  matchCount++;
			  }
			  
			  if(matchCount !=pcNmSet.size()){
				  invalidFlag=true;
				  alertMsg = PLMConstants.PRJSC_SAME_CRITERIA;
			  }
		}
		
		if(!invalidFlag){
			if(!chapterFlag && !sequenceNum &&  !subType && !defaultType){
			 alertMsg = PLMConstants.PRJSC_CHECKBOX_CRITERIA;
			}
		}
		return alertMsg;
	}
	
	
	/**
	 * @return
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return
	 */
	public PLMPwiUserData getUserDetails() {
		return userDetails;
	}

	/**
	 * @param userDetails
	 */
	public void setUserDetails(PLMPwiUserData userDetails) {
		this.userDetails = userDetails;
	}

	/**
	 * @return
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return
	 */
	public PLMCFQLCompareServiceIfc getPlmCFQLCompareService() {
		return plmCFQLCompareService;
	}

	/**
	 * @param plmCFQLCompareService
	 */
	public void setPlmCFQLCompareService(
			PLMCFQLCompareServiceIfc plmCFQLCompareService) {
		this.plmCFQLCompareService = plmCFQLCompareService;
	}

	/**
	 * @return
	 */
	public PLMCommonReportServiceIfc getPlmCommonReportService() {
		return plmCommonReportService;
	}

	/**
	 * @param plmCommonReportService
	 */
	public void setPlmCommonReportService(
			PLMCommonReportServiceIfc plmCommonReportService) {
		this.plmCommonReportService = plmCommonReportService;
	}

	/**
	 * @return
	 */
	public List<String> getInputPCList() {
		return inputPCList;
	}

	/**
	 * @param inputPCList
	 */
	public void setInputPCList(List<String> inputPCList) {
		this.inputPCList = inputPCList;
	}

	/**
	 * @return
	 */
	public int getInputPCCount() {
		return inputPCCount;
	}

	/**
	 * @param inputPCCount
	 */
	public void setInputPCCount(int inputPCCount) {
		this.inputPCCount = inputPCCount;
	}

	/**
	 * @return
	 */
	public boolean isChapterFlag() {
		return chapterFlag;
	}

	/**
	 * @param chapterFlag
	 */
	public void setChapterFlag(boolean chapterFlag) {
		this.chapterFlag = chapterFlag;
	}

	/**
	 * @return
	 */
	public boolean isSequenceNum() {
		return sequenceNum;
	}

	/**
	 * @param sequenceNum
	 */
	public void setSequenceNum(boolean sequenceNum) {
		this.sequenceNum = sequenceNum;
	}

	/**
	 * @return
	 */
	public boolean isSubType() {
		return subType;
	}

	/**
	 * @param subType
	 */
	public void setSubType(boolean subType) {
		this.subType = subType;
	}

	/**
	 * @return
	 */
	public boolean isDefaultType() {
		return defaultType;
	}

	/**
	 * @param defaultType
	 */
	public void setDefaultType(boolean defaultType) {
		this.defaultType = defaultType;
	}

	/**
	 * @return
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @param recordCounts
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}

	/**
	 * @return
	 */
	public String getPcName1() {
		return pcName1;
	}

	/**
	 * @param pcName1
	 */
	public void setPcName1(String pcName1) {
		this.pcName1 = pcName1;
	}

	/**
	 * @return
	 */
	public String getPcName2() {
		return pcName2;
	}

	/**
	 * @param pcName2
	 */
	public void setPcName2(String pcName2) {
		this.pcName2 = pcName2;
	}

	/**
	 * @return
	 */
	public String getPcName3() {
		return pcName3;
	}

	/**
	 * @param pcName3
	 */
	public void setPcName3(String pcName3) {
		this.pcName3 = pcName3;
	}

	/**
	 * @return
	 */
	public String getPcName4() {
		return pcName4;
	}

	/**
	 * @param pcName4
	 */
	public void setPcName4(String pcName4) {
		this.pcName4 = pcName4;
	}

	/**
	 * @return
	 */
	public String getPcName5() {
		return pcName5;
	}

	/**
	 * @param pcName5
	 */
	public void setPcName5(String pcName5) {
		this.pcName5 = pcName5;
	}

	/**
	 * @return
	 */
	public String getPcName6() {
		return pcName6;
	}

	/**
	 * @param pcName6
	 */
	public void setPcName6(String pcName6) {
		this.pcName6 = pcName6;
	}

	/**
	 * @return
	 */
	public String getPcName7() {
		return pcName7;
	}

	/**
	 * @param pcName7
	 */
	public void setPcName7(String pcName7) {
		this.pcName7 = pcName7;
	}

	/**
	 * @return
	 */
	public String getPcName8() {
		return pcName8;
	}

	/**
	 * @param pcName8
	 */
	public void setPcName8(String pcName8) {
		this.pcName8 = pcName8;
	}

	/**
	 * @return
	 */
	public String getPcName9() {
		return pcName9;
	}

	/**
	 * @param pcName9
	 */
	public void setPcName9(String pcName9) {
		this.pcName9 = pcName9;
	}

	/**
	 * @return
	 */
	public String getPcName10() {
		return pcName10;
	}

	/**
	 * @param pcName10
	 */
	public void setPcName10(String pcName10) {
		this.pcName10 = pcName10;
	}
}
