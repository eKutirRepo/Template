/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMPRSData.java
 * @Creation date: 11-Sept-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.LinkedHashMap;
import java.util.Map;

public class PLMPRSData {
	
	// PROPERTIES *************************************************************

	private int level = 0;
	
	/**
	 * GEEDW_PLM_ODS_BULK_V.CDR_ODS_T_PRDT_RQMNT_SPEC.ID
	 */
	private String id="";
	
	private String fromName = "";
	
	private int sequence_order = 0;
		
	/**
	 * GEEDW_PLM_ODS_BULK_V.CDR_ODS_T_PRDT_RQMNT_SPEC.NM
	 */
	private String name="";
	
	/**
	 * GEEDW_PLM_ODS_BULK_V.CDR_ODS_T_PRDT_RQMNT_SPEC.REVISION
	 */
	private String revision="";

	private String relationship_type = "";
	
	private String state = "";
	
	private String type = "";
	
	/**
	 * GEEDW_PLM_ODS_BULK_V.CDR_ODS_T_PRDT_RQMNT_SPEC.TITLE_COL
	 */
	private String title="";
	
	/**
	 * GEEDW_PLM_ODS_BULK_V.CDR_ODS_T_PRDT_RQMNT_SPEC.DESCRIPTION
	 */
	private String description;

	private String priority = "";

	public Map<String, PLMPRSData> sons = new LinkedHashMap<String, PLMPRSData>();
	
	private String rowColor = "whiteColor";
	
	// CONTRUCTOR *************************************************************

	public PLMPRSData(){};
	
	/**
	 * Creates a new instance of the class PRS
	 * 
	 * @param projectName(String)
	 */
	public PLMPRSData(
				String id, String fromName, int sequence_order, String name, String revision, 
				String relationship_type, String state, String type,
				String title, String description, String priority
				) {

		this.id = id;
		this.fromName = fromName;
		this.sequence_order = sequence_order;
		this.name = name;
		this.revision = revision;
		this.relationship_type = relationship_type;
		this.state = state;
		this.type = type;
		this.title = (title != null)? title : "";
		this.description = (description != null)? description : "";
		this.priority = priority;
	}

	// ACCESSOR METHODS *******************************************************
	
	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFromName() {
		return fromName;
	}

	public void setFromName(String fromName) {
		this.fromName = fromName;
	}

	public int getSequence_order() {
		return sequence_order;
	}

	public void setSequence_order(int sequence_order) {
		this.sequence_order = sequence_order;
	}	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRevision() {
		return revision;
	}

	public void setRevision(String revision) {
		this.revision = revision;
	}

	public String getRelationship_type() {
		return relationship_type;
	}

	public void setRelationship_type(String relationship_type) {
		this.relationship_type = relationship_type;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public Map<String, PLMPRSData> getSons() {
		return sons;
	}


	public void setSons(Map<String, PLMPRSData> sons) {
		this.sons = sons;
	}

	
	public String getRowColor() {
		return rowColor;
	}

	public void setRowColor(String rowColor) {
		this.rowColor = rowColor;
	}

	
	// OVERRIDEN METHODS ******************************************************
	/** 
	 * Returns the PRS information as a string
	 * 
	 * @return strPRS (String)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer strPRS = new StringBuffer();
		
		strPRS
			.append(id).append(", ")
			.append(fromName).append(", ")
			.append(sequence_order).append(", ")
			.append(name).append(", ")
			.append(revision).append(", ")
			.append(relationship_type).append(", ")
			.append(state).append(", ")
			.append(type).append(", ")
			.append(title).append(", ")
			.append(description).append(", ")
			.append(priority);
		
		return strPRS.toString();
	}
	
}
