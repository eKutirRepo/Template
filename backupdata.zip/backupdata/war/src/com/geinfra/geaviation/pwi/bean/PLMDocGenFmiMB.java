/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMDocGenFmiMB.java
 * @Creation date: 15-June-2011
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team) 
 */

package com.geinfra.geaviation.pwi.bean;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.faces.model.SelectItem;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.ajax4jsf.component.html.HtmlAjaxCommandButton;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.richfaces.component.UIDataTable;
import org.richfaces.event.UploadEvent;
import org.richfaces.model.UploadItem;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMBomSalesData;
import com.geinfra.geaviation.pwi.data.PLMDocGenFmiData;
import com.geinfra.geaviation.pwi.data.PLMFmiAppReportData;
import com.geinfra.geaviation.pwi.data.PLMFmiTemplateData;
import com.geinfra.geaviation.pwi.data.PLMFmiTextData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMDocGenServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;
import com.geinfra.geaviation.pwi.util.SpreadsheetWriter;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

/**
 * PLMDocGenFmiMB is the managed bean class for DGT.
 */

public class PLMDocGenFmiMB {
	/**
	 * Holds the Logger object
	 */
	private static final Logger LOG = Logger.getLogger(PLMDocGenFmiMB.class);
	/**
	 * Holds the plmDocGenService
	 */
	private PLMDocGenServiceIfc plmDocGenService = null;
	
	/**
	 * Holds the searchResultList
	 */
	private List<PLMDocGenFmiData> searchResultList;
	/**
	 * Holds the fmitextdata list
	 */
	private List<PLMFmiTextData> textDataList = new ArrayList<PLMFmiTextData>();
	/**
	 * Holds user details
	 */
	private PLMPwiUserData userDetails;
	/**
	 * Holds the tempTextData
	 */
	private PLMFmiTextData tempTextData = new PLMFmiTextData();
	/**
	 * Holds the fmidetails
	 */
	private PLMDocGenFmiData fmidetails = new PLMDocGenFmiData();
	/**
	 * Holds the templateData
	 */
	private PLMFmiTemplateData templateData = new PLMFmiTemplateData();
	/**
	 * Holds the textData
	 */
	private PLMFmiTextData textData = new PLMFmiTextData();
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds the alertMessage
	 */
	private String contractnumber="";
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the returnmsg
	 */
	private String returnmsg;
	/**
	 * Holds the fileexists
	 */
	private String fileexists;
	/**
	 * Holds the partNumber
	 */
	private String partNumber;
	/**
	 * Holds the contractNo
	 */
	private String contractNo;
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor=null;
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the salesCellStyle
	 */
	private HSSFCellStyle salesCellStyle = null;
	/**
	 * Holds the bomCellStyle
	 */
	private HSSFCellStyle bomCellStyle = null;
	/**
	 * Holds the DATE_FORMAT_PROC
	 */
	private final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
	
	
	/**
	 * Holds the partsCount
	 */
	private int partsCount;
	/**
	 * Holds the mltplPartsForCntrct
	 */
	private String mltplPartsForCntrctMsg;
	/**
	 * Holds the partsForContractList
	 */
	private List<PLMBomSalesData> partsForContractList;
	/**
	 * Holds the partsForProjectList
	 */
	private List<PLMBomSalesData> partsForProjectList;
	/**
	 * Holds the partsForProjectList1
	 */
	private List<PLMBomSalesData> partsForProjectList1;
	
	/**
	 * Holds the projectNo
	 */
	private String projectNo;

	/**
	 * Holds the mltplPartsForProject
	 */
	private String mltplPartsForProjectMsg;
	
	/**
	 * Holds the mbomCellStyle
	 */
	HSSFCellStyle mbomCellStyle = null;
	/**
	 * Holds the msalesCellStyle
	 */
	HSSFCellStyle msalesCellStyle = null;
	/**
	 * Holds the projectnumber
	 */
	private String projectnumber;
	/**
	 * Holds the alertMsg
	 */
	private String alertMsg;
	/**
	 * Holds the level
	 */
	private String level;
	/**
	 * Holds the levelList
	 */
	private List<SelectItem> levelList;
	
	//newly Added for FMI Manage text
	private Map<String, List<SelectItem>> dropdownValMap;
	private List<SelectItem> requirementList;
	 private List<String> selRequirment = new ArrayList<String>();
	 private List<String> tempselection;
	 private List<SelectItem> ceiNameList;
	 private List<String> selCei = new ArrayList<String>();
	 private List<SelectItem> mliNameList;
	 private List<String> selMli = new ArrayList<String>();
	 private boolean mliFlag;
	 private boolean ceiFlag;
	 private List<PLMFmiTemplateData> reqCeiNamesList;
	 private List<PLMFmiTemplateData> reqCeiMliNamesList;
	 private int totalRecCount;
	 private int recordCount = PLMConstants.N_10;
	 private String fmiId;
	 private String reqId;
	 private String selReqName;
	 private String selectCeiName;
	 private List<PLMFmiTemplateData> selRequiremntList;
	 private List<PLMFmiTemplateData> fmiMngTextDataList = new ArrayList<PLMFmiTemplateData>();
	 
	 private List<PLMFmiTemplateData> errorDataList;
	 
	 private String selCeiName;
    private List<SelectItem> selCeiNameList;
    private String selMliName;
    private List<SelectItem> selMliNameList;
		
	private String reqSeqId;
	
	private int totalSelRequireCnt = 0;
	private int totalSelRequireCeiCnt = 0;
	private int totalSelRequireCeiMliCnt;// = 0;
	
	/**
	 * Holds the catListDatas
	 */
	private List<SelectItem> fmiAppRequirmentList = new ArrayList<SelectItem>();
	
	/**
	 * Holds the sevListData
	 */
	private List<SelectItem> fmiAppframeTypeList = new ArrayList<SelectItem>();
	
	/**
	 * Holds the catListDatas
	 */
	private List<String> selfmiAppRequirment = new ArrayList<String>();
	
	/**
	 * Holds the sevListData
	 */
	private List<String> selfmiAppFrame = new ArrayList<String>();
	
	/**
	 * Holds the fmiappReportList
	 */
	private	List <PLMFmiAppReportData> fmiappReportList= new ArrayList <PLMFmiAppReportData>();
	
	/**
	 * Holds the allOpenReq
	 */
	private boolean allOpenReq;
	
	/**
	 * Holds the allOpenFrame
	 */
	private boolean allOpenFrame;
	
	/**
	 *  Holds the totalRecordFmiAptMsg
	 */
	private String totalRecordFmiAptMsg;
	

	/*private PLMLoginData userDataObj = (PLMLoginData) PLMUtils
	.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA);*/
	
	//Newly Added Fields for bulk Load uploading
	 /**
	 * bulkRequirmntList.
	 */
	 private List<PLMFmiTemplateData> bulkRequirmntList = new ArrayList<PLMFmiTemplateData>();
	/**
	 * ceiBulkData.
	 */
	private DataModel ceiBulkData;
	/**
	 * selectRequirementList.
	 */
	 private List<SelectItem> selectRequirementList= new ArrayList<SelectItem>();
		 /**
	 * ceiBulkData.
	 */
	private DataModel mliBulkData;
	 /**
	 * bulkCeiList.
	 */
	 private List<PLMFmiTemplateData> bulkCeiMliList = new ArrayList<PLMFmiTemplateData>();
	 /**
	 * selectRequirementList.
	 */
	 private List<SelectItem> selectCeiList= new ArrayList<SelectItem>();
	 /**
	   *  Holds the bindVal
	   */
	 private UIDataTable ceiVal = null;

	 /**
	   *  Holds the bindVal
	   */
	 private UIDataTable mliVal = null;
	 
	 /**
	 * rowIndexMliLink.
	 */
	private HtmlAjaxCommandButton rowIndexMliLink= null;
	 /**
	 * rowIndexCeiLink.
	 */
	private HtmlAjaxCommandButton rowIndexCeiLink= null;
	 /**
	   *  Holds the bulkCeiCount
	   */
	 private int bulkCeiCount = 0;
	 /**
	   *  Holds the bulkCeiCount
	   */
	 private int bulkMliCount = 0;
	 /**
	 * reqBulkData.
	 */
	private DataModel reqBulkData;
	 /**
	 * bulkReqList.
	 */
	private List<PLMFmiTemplateData> bulkReqList=new ArrayList<PLMFmiTemplateData>();

	 /**
	   *  Holds the bulkReqCount
	   */
	 private int bulkReqCount = 0;

	 /**
	 * reqBulkData.
	 */
	private HtmlAjaxCommandButton rowIndexReqLink=null;
	/**
	 * Holds the XML_ENCODING
	 */
	private static final String XML_ENCODING = "UTF-8";
	
	/**
	 *  Holds the unitSerialNum
	 */
	private String unitSerialNum;
	/**
	 *  Holds the unitSerialNum
	 */
	private List<PLMBomSalesData> contractList = new ArrayList<PLMBomSalesData>();
	
    /**
	 * Holds the totalContractsCnt
	 */
	private int totalContractsCnt;

	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;

	public PLMDocGenFmiMB() {
	 
		try {
			userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		} catch (PWiException e) {
			e.printStackTrace();
		}
	}
	/**
	 * This method is used for Load Doc Gen Fmi Search Page
	 * 
	 * @return String
	 */
	public String loadDocGenPage() {
		LOG.info("Entering loadDocGenPage Method");
		try {
			commonMB.insertCannedRptRecordHitInfo("FMI - Field Modification Instruction Creation");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		String fwdFlag = "";
		levelList = new ArrayList<SelectItem>();
		level = "";
			contractnumber = "";
		alertMessage="";
		
			fwdFlag = "fmisearch";
		LOG.info("Exiting loadDocGenPage Method");
		return fwdFlag;
	}
	
	
	
	/**
	 * This method is used for Getting the Fmi Details
	 * 
	 * @return String
	 */
	public String getFmiDetails()throws PLMCommonException {
		LOG.info("Entering getFmiDetails Method");
		fmidetails = new PLMDocGenFmiData();
		levelList = new ArrayList<SelectItem>();
		for(int i=3;i<31;i++){
			levelList.add(new SelectItem(String.valueOf(i),String.valueOf(i)));
			}
		String fwdFlag = "";
		if (PLMUtils.isEmpty(contractnumber)) {
			alertMessage = PLMConstants.FMI_SEARCH_CRITERIA;
		}else if(!PLMUtils.checkForSpecialChars(contractnumber)){
			alertMessage = PLMConstants.FMI_SEARCH_SPL_CRITERIA;
		}
		else {
			try {
				fmidetails.setContractnumber(contractnumber.trim());
			searchResultList = plmDocGenService.getFmiDetails(fmidetails);
				if(!PLMUtils.isEmptyList(searchResultList)){
					fwdFlag = "fmigenerate";
				 } else{
				 alertMessage = PLMConstants.FMI_SEARCH_FAILURE;
				}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getFmiDetails: ", exception);
				fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"fmisearch","DGT - FMI");
				}
			}
		LOG.info("Exiting getFmiDetails Method");
		return fwdFlag;
	}

	/**
	 * This method is used for Generating the Fmi Doc
	 * 
	 * @return String
	 */
	@SuppressWarnings("unchecked")
	public String generateFmiDoc(){
		LOG.info("Entering generateFmiDoc Method");
		LOG.info("Selected value from dropdown---------------------->"+level);
		String fwdFlag = "fmigenerate";
		Hashtable htBookmarks = new Hashtable(100);
		fmidetails.setTemplatepath(resourceBundle.getString("OFFLINE_RPT_DIR"));
		fmidetails.setTemplatename(resourceBundle.getString("FMI_TEMPLATE_NAME"));
		fmidetails.setFullfilepath(fmidetails.getTemplatepath()+ fmidetails.getTemplatename());
		fmidetails.setDrpDwnLvl(level);
		File storedtemplate = new File(fmidetails.getFullfilepath());
		String tempStrTemplate = null;

		String toEmailId = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		
		toAddressee = "Dear " + toAddressee + ", \n\n";
			if (storedtemplate.exists()) {
				try {
				LOG.info("Fmi Template Exists");
				//				if(!PLMUtils.isEmpty(fmidetails.getPartNumber())){
//					LOG.info("Part Number " + fmidetails.getPartNumber());
//				} else{
//					LOG.info("Part Number is Empty");
//				}
				searchResultList = plmDocGenService.generateFmiDoc(fmidetails);
				LOG.info("Contract Number " + fmidetails.getContractnumber());
				readFmiTemplate();
				tempStrTemplate = fmidetails.getStrTemplate();
				LOG.info("Successful Reading of Template ");
				List<String> reqNameList = fmidetails.getReqList();
				List<String> ceiList = fmidetails.getCeiList();
				List<String> mliList = fmidetails.getMliList();
				
				LOG.info("reqNameList from TD ------------->"+reqNameList);
				LOG.info("ceiList from TD ------------->"+ceiList);
				LOG.info("mliList from TD ------------->"+mliList);
				List<PLMDocGenFmiData> tempMliList = new ArrayList<PLMDocGenFmiData>();
				List<PLMDocGenFmiData> tempCeiList = new ArrayList<PLMDocGenFmiData>();
				if(!PLMUtils.isEmptyList(fmidetails.getTempMlidetailslist())){
					tempMliList = new ArrayList<PLMDocGenFmiData>(fmidetails.getTempMlidetailslist());
					LOG.info("tempMliList size in session ------------->"+tempMliList.size());
				}
				if(!PLMUtils.isEmptyList(fmidetails.getTempCeiDataList())){
					tempCeiList = new ArrayList<PLMDocGenFmiData>(fmidetails.getTempCeiDataList());
					LOG.info("tempCeiList size in session ------------->"+tempCeiList.size());
				}
				
				List<PLMDocGenFmiData> resultList = plmDocGenService.getFmiReqValues(reqNameList, ceiList, mliList, tempMliList, tempCeiList );
		
				searchResultList.get(0).setStrReqDescList(resultList.get(0).getStrReqDescList());  
				searchResultList.get(0).setStrCeiReqSptlsList(resultList.get(0).getStrCeiReqSptlsList());
				searchResultList.get(0).setStrCeiReqModDescList(resultList.get(0).getStrCeiReqModDescList());
				searchResultList.get(0).setMlilist(resultList.get(0).getMlilist());
				searchResultList.get(0).setStrCeiReqSpNtsList(resultList.get(0).getStrCeiReqSpNtsList());
				searchResultList.get(0).setStrCeiReqSerDcsList(resultList.get(0).getStrCeiReqSerDcsList());
				searchResultList.get(0).setStrCeiReqRepTxtList(resultList.get(0).getStrCeiReqRepTxtList());
				searchResultList.get(0).setStrCeiReqFldTxtList(resultList.get(0).getStrCeiReqFldTxtList());
				htBookmarks = setBookMarks(htBookmarks);
				LOG.info("succesful Setting of Bookmarks ");
				Enumeration enumBookmarks = htBookmarks.keys();
				while (enumBookmarks.hasMoreElements()) {
					String strBoKey = (String) enumBookmarks.nextElement();
					String strBoValue = (String) htBookmarks.get(strBoKey);
					if (tempStrTemplate.indexOf(strBoKey) != -1) {
						tempStrTemplate = tempStrTemplate.substring(0,
								tempStrTemplate.indexOf(strBoKey))
								+ strBoValue
								+ tempStrTemplate.substring(tempStrTemplate
										.indexOf(strBoKey)
										+ strBoKey.length(), tempStrTemplate
										.length());
					}
				}
				LOG.info("Successfully Appended Bookmarks");
				writeFmiTemplate(tempStrTemplate);
				LOG.info("Successful Writing of Output Template");
//				downloadGenDoc();
				LOG.info("Successful Download of Output Template");
				} catch (PLMCommonException exception) {
					LOG.log(Level.ERROR, "Exception@generateFmiDoc: ", exception);
					PLMUtils.checkExceptionAndMail(exception.getMessage(),PLMConstants.BVS_MAIL_FROM,toEmailId,PLMConstants.FMI_MAIL_SUBJECT + fmidetails.getContractnumber(),toAddressee,PLMConstants.COST_CHG_MAIL_SIGNATURE);
					fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"fmigenerate","DGT - FMI");
				}			
			} else {
				LOG.info("Template Not Found in Directory");
				alertMessage = PLMConstants.FMI_TEMPLATE_NOT_FOUND;
			}
		LOG.info("Exiting generateFmiDoc Method");
		return fwdFlag;
	}
	/**
	 * This method is used for Setting the Bookmarks
	 * 
	 * @return Hashtable
	 */
	@SuppressWarnings("unchecked")
	public Hashtable setBookMarks(Hashtable htBookmarks) {
		LOG.info("Entering setBookMarks Method");
		htBookmarks.put("bkmkstart ISSUED}", "bkmkstart ISSUED}"
				+ fmidetails.getIssued());
		htBookmarks.put("bkmkstart REVISION}", "bkmkstart REVISION}"
				+ fmidetails.getRevision());
		htBookmarks.put("bkmkstart CUSTOMER1}", "bkmkstart CUSTOMER1}"
				+ fmidetails.getCustomer());
		htBookmarks.put("bkmkstart FDM_NUMBER1}", "bkmkstart FDM_NUMBER1}"
				+ fmidetails.getContractnumber());
		htBookmarks.put("bkmkstart FDM_TITLE1}", "bkmkstart FDM_TITLE1}"
				+ fmidetails.getTitle());
		htBookmarks.put("bkmkstart DISTRIBUTION}", "bkmkstart DISTRIBUTION}"
				+ fmidetails.getDistribution());
		htBookmarks
				.put("bkmkstart DISTRIBUTION_ADDRESS}",
						"bkmkstart DISTRIBUTION_ADDRESS}"
								+ fmidetails.getDistaddress());
		htBookmarks.put("bkmkstart DISTRIBUTION_ADDRESS_B}",
				"bkmkstart DISTRIBUTION_ADDRESS_B}"
						+ fmidetails.getDisadddressb());
		htBookmarks.put("bkmkstart DIST_CPM}", "bkmkstart DIST_CPM}"
				+ fmidetails.getDistcpm());
		htBookmarks.put("bkmkstart DIST_ADDR_CPM}", "bkmkstart DIST_ADDR_CPM}"
				+ fmidetails.getDistaddrcpm());
		htBookmarks.put("bkmkstart DIST_ADDR_B_CPM}",
				"bkmkstart DIST_ADDR_B_CPM}" + fmidetails.getDistaddrcpmb());
		htBookmarks.put("bkmkstart CUSTOMER2}", "bkmkstart CUSTOMER2}"
				+ fmidetails.getCustomer());
		htBookmarks.put("bkmkstart DISTRIBUTION2}", "bkmkstart DISTRIBUTION2}"
				+ fmidetails.getDistribution());
		htBookmarks.put("bkmkstart DISTRIBUTION_ADDRESS2}",
				"bkmkstart DISTRIBUTION_ADDRESS2}"
						+ fmidetails.getDistaddress());
		htBookmarks.put("bkmkstart DISTRIBUTION_ADDRESS_B2}",
				"bkmkstart DISTRIBUTION_ADDRESS_B2}"
						+ fmidetails.getDisadddressb());
		htBookmarks.put("bkmkstart CUSTOMER4}", "bkmkstart CUSTOMER4}"
				+ fmidetails.getCustomer());
		htBookmarks.put("bkmkstart SERIAL_NUMBERS}",
				"bkmkstart SERIAL_NUMBERS}" + PLMUtils.checkNullVal(fmidetails.getAppunits()));
		// Bookmark Removed from Template
		htBookmarks.put("bkmkstart QL_CODES}", "bkmkstart QL_CODES}"
				+ fmidetails.getQlcodes());
		htBookmarks.put("bkmkstart ICN_NUMBERS}", "bkmkstart ICN_NUMBERS}"
				+ fmidetails.getIcnnumbers());
		htBookmarks.put("bkmkstart REQ_ENGINEER2}", "bkmkstart REQ_ENGINEER2}"
				+ fmidetails.getReqeng());
		htBookmarks.put("bkmkstart REQ_ENGINEER_LOCATION1}",
				"bkmkstart REQ_ENGINEER_LOCATION1}"
						+ fmidetails.getReqenglocation());
		htBookmarks.put("bkmkstart ISSUED3}", "bkmkstart ISSUED3}"
				+ fmidetails.getIssued());
		htBookmarks.put("bkmkstart FDM_TITLE3}", "bkmkstart FDM_TITLE3}"
				+ fmidetails.getTitle());
		htBookmarks.put("bkmkstart MODEL}", "bkmkstart MODEL}"
				+ fmidetails.getModel());
		htBookmarks.put("bkmkstart SERIAL_NUMBERS2}",
				"bkmkstart SERIAL_NUMBERS2}" + PLMUtils.checkNullVal(fmidetails.getAppunits()));
		htBookmarks.put("bkmkstart QL_DESCRIPTION}",
				"bkmkstart QL_DESCRIPTION}" + fmidetails.getStrReqDescList());
		htBookmarks.put("bkmkstart FDM_NUMBER3}", "bkmkstart FDM_NUMBER3}"
				+ fmidetails.getContractnumber());
		htBookmarks.put("bkmkstart SERIAL_NUMBERS3}",
				"bkmkstart SERIAL_NUMBERS3}" + PLMUtils.checkNullVal(fmidetails.getAppunits()));
		htBookmarks.put("bkmkstart MLI_TABLE}", "bkmkstart MLI_TABLE}"
				+ fmidetails.getMlitable());
		/*htBookmarks.put("bkmkstart MLI_TABLE1}", "bkmkstart MLI_TABLE1}"
				+ fmidetails.getMlitable1());*/
		htBookmarks.put("bkmkstart MLI_LIST}", "bkmkstart MLI_LIST}"
				+ fmidetails.getMlilist());
		htBookmarks.put("bkmkstart REQ_ENGINEER3}", "bkmkstart REQ_ENGINEER3}"
				+ fmidetails.getReqeng());
		htBookmarks.put("bkmkstart ADDRESS}", "bkmkstart ADDRESS}"
				+ fmidetails.getAddress());
		htBookmarks.put("bkmkstart REQ_ENGINEER_LOCATION3}",
				"bkmkstart REQ_ENGINEER_LOCATION3}"
						+ fmidetails.getReqenglocation());
		htBookmarks.put("bkmkstart CITY}", "bkmkstart CITY}"
				+ fmidetails.getCity());
		htBookmarks.put("bkmkstart STATE}", "bkmkstart STATE}"
				+ fmidetails.getState());
		htBookmarks.put("bkmkstart ZIP}", "bkmkstart ZIP}"
				+ fmidetails.getZip());
		htBookmarks.put("bkmkstart COUNTRY}", "bkmkstart COUNTRY}"
				+ fmidetails.getCountry());
		htBookmarks.put("bkmkstart PHONE}", "bkmkstart PHONE}"
				+ fmidetails.getPhone());
		htBookmarks.put("bkmkstart DIALCOM}", "bkmkstart DIALCOM}"
				+ fmidetails.getDialcom());
		htBookmarks.put("bkmkstart MSMAIL}", "bkmkstart MSMAIL}"
				+ fmidetails.getMsmail());
		htBookmarks.put("bkmkstart INTERNET}", "bkmkstart INTERNET}"
				+ fmidetails.getMobile());
		htBookmarks.put("bkmkstart FDM_NUMBER6}", "bkmkstart FDM_NUMBER6}"
				+ fmidetails.getContractnumber());
		htBookmarks.put("bkmkstart REQ_ENGINEER5}", "bkmkstart REQ_ENGINEER5}"
				+ fmidetails.getReqeng());
		htBookmarks.put("bkmkstart FDM_NUMBER7}", "bkmkstart FDM_NUMBER7}"
				+ fmidetails.getContractnumber());
		htBookmarks.put("bkmkstart REQ_ENGINEER6}", "bkmkstart REQ_ENGINEER6}"
				+ fmidetails.getReqeng());
		htBookmarks.put("bkmkstart FDM_NUMBER8}", "bkmkstart FDM_NUMBER8}"
				+ fmidetails.getContractnumber());
		htBookmarks.put("bkmkstart SPECIAL_NOTES}", "bkmkstart SPECIAL_NOTES}"
				+ fmidetails.getStrCeiReqSpNtsList());
		htBookmarks.put("bkmkstart GEI_TABLE}", "bkmkstart GEI_TABLE}"
				+ fmidetails.getStrCeiReqSerDcsList());
		htBookmarks.put("bkmkstart INRS}", "bkmkstart INRS}"
				+ fmidetails.getStrCeiReqRepTxtList());
		htBookmarks.put("bkmkstart INFS}", "bkmkstart INFS}"
				+ fmidetails.getStrCeiReqFldTxtList());
		htBookmarks.put("bkmkstart ISSUED2}", "bkmkstart ISSUED2}"
				+ fmidetails.getIssued());
		htBookmarks.put("bkmkstart FDM_NUMBER5}", "bkmkstart FDM_NUMBER5}"
				+ fmidetails.getContractnumber());
		htBookmarks.put("bkmkstart FDM_TITLE2}", "bkmkstart FDM_TITLE2}"
				+ fmidetails.getTitle());
		htBookmarks.put("bkmkstart EBOM}", "bkmkstart EBOM}"+ PLMUtils.checkNullVal(fmidetails.getEbomTable()));
		htBookmarks.put("bkmkstart SPCL_TLS_FIXTURES}", "bkmkstart SPCL_TLS_FIXTURES}"+ fmidetails.getStrCeiReqSptlsList());
		htBookmarks.put("bkmkstart MODIFICATION_DESC}", "bkmkstart MODIFICATION_DESC}"+ fmidetails.getStrCeiReqModDescList());
		
		htBookmarks.put("bkmkstart PICPAC}", "bkmkstart PICPAC}"
				+ PLMUtils.checkNullVal(fmidetails.getMaterialShipTable()));
		LOG.info("Exiting setBookMarks Method");
		return htBookmarks;
	}

	//Added by Raju
	/**
	 * Background Process Thread
	 */
	private class DocGenerationThread implements Runnable {
		public DocGenerationThread(){}
		public void run() {
			generateFmiDoc();
		}
	}
	
	public void generateFmiRtfDoc(){
		alertMessage = PLMConstants.FMI_MAIL_ALERT_MSG;
		taskExecutor.execute(new DocGenerationThread());
	}
	//End
	
	/**
	 * This method is used for Reading the Fmi Template
	 * 
	 * @return void
	 */
	public void readFmiTemplate() throws PLMCommonException {
		LOG.info("Entering readFmiTemplate Method");
		FileInputStream inputStreamTemplate = null;
		try {
			inputStreamTemplate = new FileInputStream(fmidetails.getFullfilepath());
			byte[] byteVal = new byte[inputStreamTemplate.available()];
			int retVal = inputStreamTemplate.read(byteVal);
			LOG.info("Read the file " + retVal);
			String strTemplate = new String(byteVal);
			fmidetails.setStrTemplate(strTemplate);
		} catch (FileNotFoundException exception) {
			LOG.log(Level.ERROR, "Exception@readFmiTemplate: ", exception);
			PLMUtils.checkException(exception.getMessage());
		}  catch (IOException exception) {
			LOG.log(Level.ERROR, "Exception@readFmiTemplate: ", exception);
			PLMUtils.checkException(exception.getMessage());
		} finally {
			try {
				if (inputStreamTemplate != null) {
					inputStreamTemplate.close();
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "Exception@readFmiTemplate: ", exception);
				PLMUtils.checkException(exception.getMessage());
			}
		}
		LOG.info("Exiting readFmiTemplate Method");
	}
	
	/**
	 * This method is used for Writing the Fmi Template
	 * 
	 * @return void
	 */
	public void writeFmiTemplate(String tempStrTemplate) throws PLMCommonException {
		LOG.info("Entering writeFmiTemplate Method");
		BufferedWriter oBufferedWriter = null;
		File oFile = new File(fmidetails.getFullfilepath());
		final SimpleDateFormat DATE_FORMAT_PROC1 = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC1.format(uniqDate);
		File tmpFile = new File(oFile.getParent(), fmidetails.getContractnumber()+"_"+uniqTime+".rtf");
		File tmpFileZip = new File(oFile.getParent(), fmidetails.getContractnumber()+"_"+uniqTime+".zip");
		List<String> tempFilesList = new ArrayList<String>();
		tempFilesList.add(tmpFile.getAbsolutePath());
		//Added By Raju
		String from = PLMConstants.COST_CHG_MAIL_FROM;
		
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.FMI_MAIL_SUBJECT + fmidetails.getContractnumber();
		StringBuffer mailBody = new StringBuffer().append(toAddressee);
		StringBuffer mailNoDataBody = new StringBuffer();
		//File file = null;
		LOG.info("contractNum>>>>>>>"+fmidetails.getContractnumber());
		if (fmidetails.getContractnumber()!=null) {
		toAddressee = "Dear " + toAddressee + ", \n\n";
		mailBody.append(PLMConstants.FMI_MAIL_CONTENT)
		.append(fmidetails.getContractnumber())
		.append(".")
		.append(PLMConstants.COST_CHG_MAIL_SIGNATURE)
		.append(PLMConstants.COST_CHG_MAIL_FOOTER);
		
		mailNoDataBody.append(toAddressee)
		.append(PLMConstants.FMI_NO_CONTENT_BODY)
		.append(fmidetails.getContractnumber())
		.append(".")
		.append(PLMConstants.COST_CHG_MAIL_SIGNATURE)
		.append(PLMConstants.COST_CHG_MAIL_FOOTER);
		//End Raju
		
		try {
			oBufferedWriter = new BufferedWriter(new FileWriter(tmpFile));
			oBufferedWriter.write(tempStrTemplate);
			oBufferedWriter.newLine();
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "Exception@writeFmiTemplate: ", exception);
				PLMUtils.checkException(exception.getMessage());
			} finally {
				try {
					if (oBufferedWriter != null) {
						oBufferedWriter.close();
					}
				} catch (IOException exception) {
					LOG.log(Level.ERROR, "Exception@writeFmiTemplate: ", exception);
					PLMUtils.checkException(exception.getMessage());
				}
			}
		LOG.info("Getting the Old File Absolute Path" + oFile.getAbsolutePath());
		LOG.info("Getting the Temp File Absolute Path" + tmpFile.getAbsolutePath());
		//Added by Raju
		 //file = new File(tmpFile.getAbsolutePath());
		 try{
		 long sizeInBytes = 0;
		 //if(tmpFile!=null){
				sizeInBytes = tmpFile.length();
				//}
				if(sizeInBytes > 0){
				LOG.info("File Size for FMI Doc "+sizeInBytes/1000+"KB");
				PLMUtils.generateZipFile(tempFilesList, tmpFileZip.getAbsolutePath(), false);
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), tmpFileZip.getAbsolutePath());
				LOG.info("Report Attachment Mail sent successfully.");
				}else{
				PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
				LOG.info("No data Mail sent successfully.");
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "Exception@writeFmiTemplate: ", exception);
				PLMUtils.checkException(exception.getMessage());
			} finally{
				PLMUtils.deleteFile(tmpFile);
				PLMUtils.deleteFile(tmpFileZip);
				tempFilesList.clear();
//				if (file!=null) {
//					file.delete();
//				}
			}
		 //End by Raju
		 
		LOG.info("Exiting writeFmiTemplate Method");
	}
	}
	/**
	 * This method is used for Deleting file
	 * 
	 * @return void
	 */
	public void deleteFiles(String rtf){
		LOG.info("Entering deleteFiles method");
		boolean rtfFileExist;
		File rtfFile = new File(rtf);
		rtfFileExist = rtfFile.exists();
		if(rtfFileExist){
			boolean deleted = rtfFile.delete();
			LOG.info("Successfully deleted rtf file : " + deleted);
		}
		LOG.info("Exiting deleteFiles Method");
	}
	
		
	/**
	 * This method is used for Downloading the Generated Fmi Doc
	 * 
	 * @return void
	 */
	public void downloadGenDoc() throws PLMCommonException {
		LOG.info("Entering downloadGenDoc Method");
		File oFile = new File(fmidetails.getFullfilepath());
		File tmpFile = new File(oFile.getParent(), fmidetails.getContractnumber()+ ".rtf");
		BufferedInputStream bufferedInputStream = null;
		HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
		int length = 0;
		byte[] buf = new byte[1024];
		try {
			bufferedInputStream = new BufferedInputStream(new FileInputStream(tmpFile));
			ServletOutputStream ouputStream = response.getOutputStream();
			while ((length = bufferedInputStream.read(buf)) != -1) {
				ouputStream.write(buf, 0, (int) length);
			}
			response.setContentType("application/force-download");
			response.setHeader("Content-Disposition", "attachment; filename="
					+ tmpFile.getName());
			FacesContext.getCurrentInstance().responseComplete();
		} catch (FileNotFoundException exception) {
			LOG.log(Level.ERROR, "Exception@downloadGenDoc: ", exception);
			PLMUtils.checkException(exception.getMessage());
		}  catch (IOException exception) {
			LOG.log(Level.ERROR, "Exception@downloadGenDoc: ", exception);
			PLMUtils.checkException(exception.getMessage());
		} finally {
			try {
				if (bufferedInputStream != null) {
					bufferedInputStream.close();
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "Exception@downloadGenDoc: ", exception);
				PLMUtils.checkException(exception.getMessage());
			} 
		}
		LOG.info("Exiting downloadGenDoc Method");
	}

	/**
	 * This method is used for load FmiTemplate Page
	 * 
	 * @return String
	 */
	public String loadFmiTemplatePage() {
		LOG.info("Entering loadFmiTemplatePage Method");
		try {
			commonMB.insertCannedRptRecordHitInfo("Manage FMI Template");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			templateData = new PLMFmiTemplateData();
			templateData.setTemplatepath(resourceBundle.getString("OFFLINE_RPT_DIR")+ resourceBundle.getString("FMI_TEMPLATE_NAME"));
			File storedfile = new File(templateData.getTemplatepath());
			if (storedfile.exists()) {
				fileexists = "exists";
			} else {
				fileexists = "notexists";
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@loadFmiTemplatePage: ", exception);
		}
		alertMessage = null;
		LOG.info("Exiting loadFmiTemplatePage Method");
		return "fmitemplate";
	}
	/**
	 * This method is used for upload the Fmi Template
	 * 
	 * @return void
	 */
	public void uploadFmiTemplate(UploadEvent event) {
		LOG.info("Entering uploadFmiTemplate Method");
		UploadItem item = event.getUploadItem();
		templateData.setSrcfile(item.getFile());
		if (templateData.getSrcfile().exists()) {
			validateFmiTemplate();
			LOG.info("Error message = " + templateData.getTmpltErrorMsg());
			if (templateData.getTmpltErrorMsg().equals("")) {
				FileInputStream fileInputStream = null;
				FileOutputStream fileOutputStream = null;
				//File fout = null;
				LOG.info("File uploaded path " + templateData.getTemplatepath());
				try {
					fileInputStream = new FileInputStream(templateData.getSrcfile());
					//fout = new File(templateData.getTemplatepath());
					fileOutputStream = new FileOutputStream(templateData.getTemplatepath());
					byte[] buffer = new byte[1024];
					int bytesread;
					while ((bytesread = fileInputStream.read(buffer)) != -1) {
						fileOutputStream.write(buffer, 0, bytesread);
					}
					fileOutputStream.flush();
					fileOutputStream.close();
				} catch (FileNotFoundException ex) {
					LOG.error(ex.getMessage());
				} catch (IOException ex1) {
					LOG.error(ex1.getMessage());
				} finally {
					if (fileInputStream != null) {
						try {
							fileInputStream.close();
						}catch (IOException ex) {
							LOG.error("Exception in Cloing fileInputStream" + ex.getMessage());
						}
					}
					if (fileOutputStream != null) {
						try {
							fileOutputStream.close();
						} catch (IOException ex) {
							LOG.error("Exception in Cloing fileOutputStream " + ex.getMessage());
						}
					}
				}
			} else {
				FacesContext facesContext = FacesContext.getCurrentInstance();
				facesContext.responseComplete();
			}
		}
		LOG.info("Exiting uploadFmiTemplate Method");
	}

	/**
	 * This method is used for validating the Template Bookmarks
	 * 
	 * @return void
	 */
	@SuppressWarnings("unchecked")
	public void validateFmiTemplate() {
		LOG.info("Entering validateFmiTemplate Method");
		FileInputStream inputStreamTemplate = null;
		String errormessage = "";		
		try {
			inputStreamTemplate = new FileInputStream(templateData.getSrcfile());
			byte[] byteVal = new byte[inputStreamTemplate.available()];
			int retVal = inputStreamTemplate.read(byteVal);
			LOG.info("Reading return value " + retVal);
			String strTemplate = new String(byteVal);
			Hashtable htBookmarks = new Hashtable(100);
			htBookmarks.put("bkmkstart ISSUED}", "bkmkstart ISSUED}");
			htBookmarks.put("bkmkstart REVISION}", "bkmkstart REVISION}");
			htBookmarks.put("bkmkstart CUSTOMER1}", "bkmkstart CUSTOMER1}");
			htBookmarks.put("bkmkstart FDM_NUMBER1}", "bkmkstart FDM_NUMBER1}");
			htBookmarks.put("bkmkstart FDM_TITLE1}", "bkmkstart FDM_TITLE1}");
			htBookmarks.put("bkmkstart DISTRIBUTION}",
					"bkmkstart DISTRIBUTION}");
			htBookmarks.put("bkmkstart DISTRIBUTION_ADDRESS}",
					"bkmkstart DISTRIBUTION_ADDRESS}");
			htBookmarks.put("bkmkstart DISTRIBUTION_ADDRESS_B}",
					"bkmkstart DISTRIBUTION_ADDRESS_B}");
			htBookmarks.put("bkmkstart DIST_CPM}", "bkmkstart DIST_CPM}");
			htBookmarks.put("bkmkstart DIST_ADDR_CPM}",
					"bkmkstart DIST_ADDR_CPM}");
			htBookmarks.put("bkmkstart DIST_ADDR_B_CPM}",
					"bkmkstart DIST_ADDR_B_CPM}");
			htBookmarks.put("bkmkstart CUSTOMER2}", "bkmkstart CUSTOMER2}");
			htBookmarks.put("bkmkstart DISTRIBUTION2}",
					"bkmkstart DISTRIBUTION2}");
			htBookmarks.put("bkmkstart DISTRIBUTION_ADDRESS2}",
					"bkmkstart DISTRIBUTION_ADDRESS2}");
			htBookmarks.put("bkmkstart DISTRIBUTION_ADDRESS_B2}",
					"bkmkstart DISTRIBUTION_ADDRESS_B2}");
			htBookmarks.put("bkmkstart CUSTOMER4}", "bkmkstart CUSTOMER4}");
			htBookmarks.put("bkmkstart SERIAL_NUMBERS}",
					"bkmkstart SERIAL_NUMBERS}");
			// Bookmark Removed from Template
			htBookmarks.put("bkmkstart QL_CODES}", "bkmkstart QL_CODES}");
			htBookmarks.put("bkmkstart ICN_NUMBERS}", "bkmkstart ICN_NUMBERS}");
			htBookmarks.put("bkmkstart REQ_ENGINEER2}",
					"bkmkstart REQ_ENGINEER2}");
			htBookmarks.put("bkmkstart REQ_ENGINEER_LOCATION1}",
					"bkmkstart REQ_ENGINEER_LOCATION1}");
			htBookmarks.put("bkmkstart ISSUED3}", "bkmkstart ISSUED3}");
			htBookmarks.put("bkmkstart FDM_TITLE3}", "bkmkstart FDM_TITLE3}");
			htBookmarks.put("bkmkstart MODEL}", "bkmkstart MODEL}");
			htBookmarks.put("bkmkstart SERIAL_NUMBERS2}",
					"bkmkstart SERIAL_NUMBERS2}");
			htBookmarks.put("bkmkstart QL_DESCRIPTION}",
					"bkmkstart QL_DESCRIPTION}");
			htBookmarks.put("bkmkstart FDM_NUMBER3}", "bkmkstart FDM_NUMBER3}");
			htBookmarks.put("bkmkstart SERIAL_NUMBERS3}",
					"bkmkstart SERIAL_NUMBERS3}");
			htBookmarks.put("bkmkstart MLI_TABLE}", "bkmkstart MLI_TABLE}");
			/*htBookmarks.put("bkmkstart MLI_TABLE1}", "bkmkstart MLI_TABLE1}");*/
			htBookmarks.put("bkmkstart MLI_LIST}", "bkmkstart MLI_LIST}");
			htBookmarks.put("bkmkstart REQ_ENGINEER3}",
					"bkmkstart REQ_ENGINEER3}");
			htBookmarks.put("bkmkstart ADDRESS}", "bkmkstart ADDRESS}");
			htBookmarks.put("bkmkstart REQ_ENGINEER_LOCATION3}",
					"bkmkstart REQ_ENGINEER_LOCATION3}");
			htBookmarks.put("bkmkstart CITY}", "bkmkstart CITY}");
			htBookmarks.put("bkmkstart STATE}", "bkmkstart STATE}");
			htBookmarks.put("bkmkstart ZIP}", "bkmkstart ZIP}");
			htBookmarks.put("bkmkstart COUNTRY}", "bkmkstart COUNTRY}");
			htBookmarks.put("bkmkstart PHONE}", "bkmkstart PHONE}");
			htBookmarks.put("bkmkstart DIALCOM}", "bkmkstart DIALCOM}");
			htBookmarks.put("bkmkstart MSMAIL}", "bkmkstart MSMAIL}");
			htBookmarks.put("bkmkstart INTERNET}", "bkmkstart INTERNET}");
			htBookmarks.put("bkmkstart FDM_NUMBER6}", "bkmkstart FDM_NUMBER6}");
			htBookmarks.put("bkmkstart REQ_ENGINEER5}",
					"bkmkstart REQ_ENGINEER5}");
			htBookmarks.put("bkmkstart FDM_NUMBER7}", "bkmkstart FDM_NUMBER7}");
			htBookmarks.put("bkmkstart REQ_ENGINEER6}",
					"bkmkstart REQ_ENGINEER6}");
			htBookmarks.put("bkmkstart FDM_NUMBER8}", "bkmkstart FDM_NUMBER8}");
			htBookmarks.put("bkmkstart SPECIAL_NOTES}",
					"bkmkstart SPECIAL_NOTES}");
			htBookmarks.put("bkmkstart GEI_TABLE}", "bkmkstart GEI_TABLE}");
			htBookmarks.put("bkmkstart INRS}", "bkmkstart INRS}");
			htBookmarks.put("bkmkstart INFS}", "bkmkstart INFS}");
			htBookmarks.put("bkmkstart CUST}", "bkmkstart CUST}");
			htBookmarks.put("bkmkstart DTE}", "bkmkstart DTE}");
			htBookmarks.put("bkmkstart FDM}", "bkmkstart FDM}");
			htBookmarks.put("bkmkstart FDM_NUMBER5}", "bkmkstart FDM_NUMBER5}");
			htBookmarks.put("bkmkstart FDM_TITLE2}", "bkmkstart FDM_TITLE2}");
			htBookmarks.put("bkmkstart ICN}", "bkmkstart ICN}");
			htBookmarks.put("bkmkstart ISSUED2}", "bkmkstart ISSUED2}");
			htBookmarks.put("bkmkstart REQ_ENGINEER_LOCATION2}",
					"bkmkstart REQ_ENGINEER_LOCATION2}");
			htBookmarks.put("bkmkstart TITL}", "bkmkstart TITL}");
			htBookmarks.put("bkmkstart TSN}", "bkmkstart TSN}");
			htBookmarks.put("bkmkstart EBOM}", "bkmkstart EBOM}");
			htBookmarks.put("bkmkstart SPCL_TLS_FIXTURES}", "bkmkstart SPCL_TLS_FIXTURES}");
			htBookmarks.put("bkmkstart MODIFICATION_DESC}", "bkmkstart MODIFICATION_DESC}");
			htBookmarks.put("bkmkstart PICPAC}", "bkmkstart PICPAC}");
			
			Enumeration enumBookmarks = htBookmarks.keys();
			while (enumBookmarks.hasMoreElements()) {
				String strBoKey = (String) enumBookmarks.nextElement();
				if (strTemplate.indexOf(strBoKey) == -1) {
					LOG.info("Missing Bookmark : " + strBoKey);
					errormessage = "fail";
				}
			}
		} catch (IOException ex) {
			LOG.error("Exception in reading : " + ex.getMessage());
		} 
		finally {
			try {
				if (inputStreamTemplate != null) {
					inputStreamTemplate.close();
				}
			} catch (IOException ex) {
				LOG.error("Exception in Closing " + ex.getMessage());
			}
		}
		templateData.setTmpltErrorMsg(errormessage);
		LOG.info("Entering validateFmiTemplate Method");
	}

	/**
	 * This method is used for Downloading the Fmi Template
	 * 
	 * @return String
	 */
	public String downloadFmiTemplate() {
		LOG.info("Entering downloadFmiTemplate Method");
		String fwdflag = "fmitemplate";
		File storedfile = new File(templateData.getTemplatepath());
		if (storedfile.exists()) {
			BufferedInputStream bufferedInputStream = null;
			String documentname = storedfile.getName();
			HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
			int length = 0;
			byte[] buf = new byte[1024];
			try {
				bufferedInputStream = new BufferedInputStream(new FileInputStream(storedfile));
				ServletOutputStream ouputStream = response.getOutputStream();
				while ((bufferedInputStream != null) && ((length = bufferedInputStream.read(buf)) != -1)) {
					ouputStream.write(buf, 0, (int) length);
				}
				response.setContentType("application/force-download");
				response.setHeader("Content-Disposition",
						"attachment; filename=" + documentname);
				FacesContext.getCurrentInstance().responseComplete();
			} catch (FileNotFoundException ex) {
				LOG.error("Exception : File Not Found : " + ex.getMessage());
			} catch (IOException ex1) {
				LOG.error("Exception : Error in Reading : " + ex1.getMessage());
			}
			finally {
				try {
					if (bufferedInputStream != null) {
						bufferedInputStream.close();
					}
				} catch (IOException e) {
					LOG.error("Exception in closing the bufferedInputStream : " + e.getMessage());
				}
			}
		} else {
			alertMessage = PLMConstants.FMI_TEMPLATE_NOT_FOUND;
		}
		LOG.info("Exiting downloadFmiTemplate Method");
		return fwdflag;
	}

	/**
	 * This method is used for load FmiText Page
	 * 
	 * @return String
	 */
	public String loadFmiTextPage() {
		LOG.info("Entering loadFmiTextPage Method");
		try {
			textData = new PLMFmiTextData();

			textData.setTemplatepath(resourceBundle.getString("OFFLINE_RPT_DIR")+ resourceBundle.getString("FMI_TEXTTEMPLATE_NAME"));
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@loadFmiTextPage: ", exception);
		}
		LOG.info("Exiting loadFmiTextPage Method");
		return "fmitext";
	}
	/**
	 * This method is used for upload FmiText
	 * 
	 * @return String
	 */
	public void uploadFmiText(UploadEvent event) throws Exception {
		LOG.info("Entering uploadFmiText Method");
		textDataList = new ArrayList<PLMFmiTextData>();
		UploadItem item = event.getUploadItem();
		textData.setSrcfile(item.getFile());
		if (textData.getSrcfile().exists()) {
			validateFmiText();
			LOG.info("Error message = " + textData.getFmiTxtErrMsg());
			if (textData.getFmiTxtErrMsg().equals("")) {
				readFmiText();
				if (textData.getFmiTxtErrMsg().equals("")) {
					plmDocGenService.uploadFmiText(textDataList);
				} else {
					FacesContext facesContext = FacesContext
							.getCurrentInstance();
					facesContext.responseComplete();
				}
			} else {
				FacesContext facesContext = FacesContext.getCurrentInstance();
				facesContext.responseComplete();
			}
		}
		LOG.info("Exiting uploadFmiText Method");
	}

	/**
	 * This method is used for download FmiText
	 * 
	 * @return String
	 */

	public String downloadFmiText() {
		LOG.info("Entering downloadFmiText Method");
		String fwdflag = "fmitext";
		textDataList = new ArrayList<PLMFmiTextData>();
		File oFile = new File(textData.getTemplatepath());
		File tmpFile = new File(oFile.getParent(), "FmiText.xls");
		FileInputStream fin = null;
		FileOutputStream fout = null;
		BufferedInputStream bufferedInStream = null;
		if (oFile.exists()) {
			try {
				textDataList = plmDocGenService.downloadFmiText();
				fin = new FileInputStream(oFile);
				fout = new FileOutputStream(tmpFile);
				HSSFWorkbook workbook = new HSSFWorkbook(fin);
				HSSFSheet sheet = workbook.getSheetAt(0);
				HSSFRow row;
				HSSFCell cell;
				if (textDataList.size() > 0) {
					for (int i = 0; i < textDataList.size(); i++) {
						row = sheet.createRow((short) i + 1);
						cell = row.createCell(0);
						if (textDataList.get(i).getName() != null)
							cell.setCellValue(textDataList.get(i).getName());
						else
							cell.setCellValue("");
						cell = row.createCell(1);
						if (textDataList.get(i).getMarketingname() != null)
							cell.setCellValue(textDataList.get(i)
									.getMarketingname());
						else
							cell.setCellValue("");
						cell = row.createCell(2);
						if (textDataList.get(i).getCinomenclature() != null)
							cell.setCellValue(textDataList.get(i)
									.getCinomenclature());
						else
							cell.setCellValue("");
						cell = row.createCell(3);
						if (textDataList.get(i).getCinomenclaturdesc() != null)
							cell.setCellValue(textDataList.get(i)
									.getCinomenclaturdesc());
						else
							cell.setCellValue("");

						cell = row.createCell(4);
						if (textDataList.get(i).getFmitext() != null)
							cell.setCellValue(textDataList.get(i).getFmitext());
						else
							cell.setCellValue("");

						cell = row.createCell(5);
						if (textDataList.get(i).getSpecialnotestext() != null)
							cell.setCellValue(textDataList.get(i)
									.getSpecialnotestext());
						else
							cell.setCellValue("");

						cell = row.createCell(6);
						if (textDataList.get(i).getFieldtext() != null)
							cell.setCellValue(textDataList.get(i)
									.getFieldtext());
						else
							cell.setCellValue("");

						cell = row.createCell(7);
						if (textDataList.get(i).getRepairtext() != null)
							cell.setCellValue(textDataList.get(i)
									.getRepairtext());
						else
							cell.setCellValue("");

						cell = row.createCell(8);
						if (textDataList.get(i).getSpecialtoolstext() != null)
							cell.setCellValue(textDataList.get(i)
									.getSpecialtoolstext());
						else
							cell.setCellValue("");

						cell = row.createCell(9);
						if (textDataList.get(i).getRefdoctext() != null)
							cell.setCellValue(textDataList.get(i)
									.getRefdoctext());
						else
							cell.setCellValue("");
					}
				}
				workbook.write(fout);
				fout.flush();
				HttpServletResponse response = (HttpServletResponse) FacesContext
						.getCurrentInstance().getExternalContext()
						.getResponse();
				int length = 0;
				byte[] buf = new byte[1024];
				bufferedInStream = new BufferedInputStream(new FileInputStream(tmpFile));
				ServletOutputStream ouputStream = response.getOutputStream();
				while ((length = bufferedInStream.read(buf)) != -1) {
					ouputStream.write(buf, 0, (int) length);
				}
				response.setContentType("application/force-download");
				response.setHeader("Content-Disposition",
						"attachment; filename=" + tmpFile.getName());
				FacesContext.getCurrentInstance().responseComplete();
			} catch (PLMCommonException e) {
					LOG.error(e.getMessage());
			} catch (FileNotFoundException e) {
				LOG.error(e.getMessage());
			} catch (IOException e) {
				LOG.error(e.getMessage());
			}  finally {
				try {
					if (bufferedInStream != null) {
						bufferedInStream.close();
					}
				} catch (IOException e) {
				  LOG.error("Exception in closing the Input and Output Streams  : " + e.getMessage());
				} finally {
					try {
					if (fin != null) {
						fin.close();
					}
					} catch (IOException ioe) {
						 LOG.error("Exception in closing the Input and Output Streams  : " + ioe.getMessage());
					} finally {
						try {
					if (fout != null) {
						fout.close();
					}
						} catch (IOException ioe){
							 LOG.error("Exception in closing the Input and Output Streams  : " + ioe.getMessage());
						}
				}
			}
			}
		} else {
			alertMessage = PLMConstants.FMI_TEXTTEMPLATE_NOT_FOUND;
		}
		LOG.info("Exiting downloadFmiText Method");
		return fwdflag;
	}

	/**
	 * This method is used for Validate FmiText
	 * 
	 * @return String
	 */
	@SuppressWarnings("unchecked")
	public void validateFmiText() {
		LOG.info("Entering validateFmiText Method");
		FileInputStream fis = null;
		StringBuffer errormessage = new StringBuffer();
		try {
			fis = new FileInputStream(textData.getSrcfile());
			HSSFWorkbook workbook = new HSSFWorkbook(fis);
			HSSFSheet sheet = workbook.getSheetAt(0);
			HSSFRow headerrow = sheet.getRow(0);
			Iterator rows = sheet.rowIterator();
			int totalcols = 10;
			int keyfieldcols = 4;
			if (rows.hasNext()) {
				while (rows.hasNext()) {
					HSSFRow row = (HSSFRow) rows.next();
					if (row.getRowNum() == 0)
						continue;
					Iterator cells = row.cellIterator();
					if (cells.hasNext()) {
						HSSFCell cell = (HSSFCell) cells.next();
						if (cell.getColumnIndex() < totalcols) {
							for (int i = 0; i < keyfieldcols; i++) {
								HSSFCell currentcell = row.getCell(i);
								if (currentcell == null) {
									errormessage.append("Value Required  at field (Row "
											+ (row.getRowNum() + 1) + ","
											+ headerrow.getCell(i) + ")<br>");
									} else if (currentcell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
									if (currentcell.getRichStringCellValue()
											.getString().trim().equals("")) {
										errormessage.append("Value Required  at field (Row "
												+ (row.getRowNum() + 1) + ","
												+ headerrow.getCell(i)
												+ ")<br>");								
										}
								} else if (currentcell.getCellType() == HSSFCell.CELL_TYPE_BLANK) {
									LOG.info("in blank cell");
									errormessage.append("Value Required  at field (Row "
											+ (row.getRowNum() + 1) + ","
											+ headerrow.getCell(i) + ")<br>");
								}
							}
						}
					}
				}
			}
		} catch (FileNotFoundException ex) {
			textData.setFmiTxtErrMsg("File Does not Exist");
		} catch (IOException ec) {
			textData.setFmiTxtErrMsg("Invalid Template Format");
		} finally {
			try {
				if (fis != null) {
					fis.close();
				}
			} catch (IOException e) {
				textData.setFmiTxtErrMsg("Invalid Template Format");
			}
		}
		LOG.info("Error Message " + errormessage.toString());
		textData.setFmiTxtErrMsg(errormessage.toString());
		LOG.info("Exiting validateFmiText Method");
	}
	/**
	 * This method is used for Reading FmiText
	 * 
	 * @return String
	 */
	@SuppressWarnings("unchecked")
	public void readFmiText() {
		LOG.info("Entering readFmiText Method");
		String errormessage = "";
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(textData.getSrcfile());
			HSSFWorkbook workbook = new HSSFWorkbook(fis);
			HSSFSheet sheet = workbook.getSheetAt(0);
			Iterator rows = sheet.rowIterator();
			int totalcols = 10;
			int noofrecords = 0;
			while (rows.hasNext()) {
				tempTextData = new PLMFmiTextData();
				LOG.info("I am in row loop");
				HSSFRow row = (HSSFRow) rows.next();
				if (row.getRowNum() == 0)
					continue;
				Iterator cells = row.cellIterator();
				if (cells.hasNext()) {
					LOG.info("I am in cell loop");
					HSSFCell cell = (HSSFCell) cells.next();
					if (cell.getColumnIndex() < totalcols) {
						for (int i = 0; i < totalcols; i++) {
							HSSFCell currentcell = row.getCell(i);
							LOG.info("Before Null");
							if (currentcell == null) {
								LOG.info("After Null");
								switch (i) {
								case 0:
									tempTextData.setName("");
									break;
								case 1:
									tempTextData.setMarketingname("");
									break;
								case 2:
									tempTextData.setCinomenclature("");
									break;
								case 3:
									tempTextData.setCinomenclaturdesc("");
									break;
								case 4:
									tempTextData.setFmitext("");
									tempTextData.setFmitext1("");
									break;
								case 5:
									tempTextData.setSpecialnotestext("");
									break;
								case 6:
									tempTextData.setFieldtext("");
									break;
								case 7:
									tempTextData.setRepairtext("");
									break;
								case 8:
									tempTextData.setSpecialtoolstext("");
									break;
								case 9:
									tempTextData.setRefdoctext("");
									break;
								default:
									break;
								}
							} else if (currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
								LOG.info("After Numeric");
								switch (i) {
								case 0:
									LOG.info("In Case 0");
									tempTextData.setName(Double
											.toString(currentcell
													.getNumericCellValue()));
									break;
								case 1:
									LOG.info("In Case 1");
									tempTextData.setMarketingname(Double
											.toString(currentcell
													.getNumericCellValue()));
									break;
								case 2:
									LOG.info("In Case 2");
									tempTextData.setCinomenclature(Double
											.toString(currentcell
													.getNumericCellValue()));
									break;
								case 3:
									LOG.info("In Case 3");
									tempTextData.setCinomenclaturdesc(Double
											.toString(currentcell
													.getNumericCellValue()));
									break;
								case 4:
									LOG.info("In Case 4");
									String tempstr = (Double.toString(currentcell.getNumericCellValue()));
									LOG.info("String Length :  " + tempstr.length());
									if(tempstr.length()>5000)
									{
										errormessage = errormessage	+ " Fmi Text at Row # " + (row.getRowNum()+1 ) + " Should not Exceeds 5000 Characters <br>  ";
									}
									else if ( tempstr.length() >= 2500 )
									{
										tempTextData.setFmitext(tempstr.substring(0,2500));
										tempTextData.setFmitext1(tempstr.substring(2500,tempstr.length()));
									}
									else
									{
										tempTextData.setFmitext(tempstr);
										tempTextData.setFmitext1("");
									}
									break;
								case 5:
									LOG.info("In Case 5");
									tempTextData.setSpecialnotestext(Double
											.toString(currentcell
													.getNumericCellValue()));
									break;
								case 6:
									LOG.info("In Case 6");
									tempTextData.setFieldtext(Double
											.toString(currentcell
													.getNumericCellValue()));
									break;
								case 7:
									LOG.info("In Case 7");
									tempTextData.setRepairtext(Double
											.toString(currentcell
													.getNumericCellValue()));
									break;
								case 8:
									LOG.info("In Case 8");
									tempTextData.setSpecialtoolstext(Double
											.toString(currentcell
													.getNumericCellValue()));
									break;
								case 9:
									LOG.info("In Case 9");
									tempTextData.setRefdoctext(Double
											.toString(currentcell
													.getNumericCellValue()));
									break;
								default:
									break;
								}
							} else if (currentcell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
								LOG.info("After String");
								switch (i) {
								case 0:
									LOG.info("In Case 0");
									tempTextData.setName(currentcell
											.getRichStringCellValue()
											.toString());
									break;
								case 1:
									LOG.info("In Case 1");
									tempTextData.setMarketingname(currentcell
											.getRichStringCellValue()
											.toString());
									break;
								case 2:
									LOG.info("In Case 2");
									tempTextData.setCinomenclature(currentcell
											.getRichStringCellValue()
											.toString());
									break;
								case 3:
									LOG.info("In Case 3");
									tempTextData
											.setCinomenclaturdesc(currentcell
													.getRichStringCellValue()
													.toString());
									break;
								case 4:
									LOG.info("In Case 4");
									String tempstr = (currentcell.getRichStringCellValue().toString());
									LOG.info("String Length :  " + tempstr.length());
									if(tempstr.length()>5000)
									{
										errormessage = errormessage	+ " Fmi Text at Row # " + (row.getRowNum()+1 ) + " Should not Exceeds 5000 Characters <br> ";
									}
									else if ( tempstr.length() >= 2500 )
									{
										tempTextData.setFmitext(tempstr.substring(0,2500));
										tempTextData.setFmitext1(tempstr.substring(2500,tempstr.length()));
									}
									else
									{
										tempTextData.setFmitext(tempstr);
										tempTextData.setFmitext1("");
									}
									break;
								case 5:
									LOG.info("In Case 5");
									tempTextData
											.setSpecialnotestext(currentcell
													.getRichStringCellValue()
													.toString());
									break;
								case 6:
									LOG.info("In Case 6");
									tempTextData.setFieldtext(currentcell
											.getRichStringCellValue()
											.toString());
									break;
								case 7:
									LOG.info("In Case 7");
									tempTextData.setRepairtext(currentcell
											.getRichStringCellValue()
											.toString());
									break;
								case 8:
									LOG.info("In Case 8");
									tempTextData
											.setSpecialtoolstext(currentcell
													.getRichStringCellValue()
													.toString());
									break;
								case 9:
									LOG.info("In Case 9");
									tempTextData.setRefdoctext(currentcell
											.getRichStringCellValue()
											.toString());
									break;
								default:
									break;
								}
							}
						}
					}
				}
				textDataList.add(noofrecords, tempTextData);
				noofrecords++;
				LOG.info("Name -->: " + tempTextData.getName());
				LOG.info("Ci Nomenclaturedesc -->: " + tempTextData.getCinomenclaturdesc());
				LOG.info("Ci Nomenclature -->: " + tempTextData.getCinomenclature());
				LOG.info("Ci Nomenclature -->: " + tempTextData.getFmitext());
				LOG.info("FMI Text -->: " + tempTextData.getFmitext());
				LOG.info("noofrecords : " + noofrecords);
			}
			if (textDataList.size() == 0)
				errormessage= errormessage + "No Records Found";
			
			} catch (FileNotFoundException ex) {
				errormessage= errormessage + "File Does not Exist";
			} catch (IOException ex1) {
				errormessage= errormessage + "Error Reading in File";
			} finally {
				try {
					if (fis != null)
						fis.close();
				} catch (IOException ex1) {
					errormessage= errormessage + "Error Reading in File";
				}catch (Exception ex2) {
					errormessage= errormessage + "Error Reading in File";
				}
			}
		textData.setFmiTxtErrMsg(errormessage);
		LOG.info("Exiting readFmiText Method");
	}
	
	/**
	 * This method is used for Loading OMM Page
	 * 
	 * @return String
	 */
	public String loadBomVsSalesReportPage() {
		LOG.info("Entering loadBomVsSalesReportPage Method");
		try {
			commonMB.insertCannedRptRecordHitInfo("CMU Comparison Of BOM To Sales Order");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			partsForContractList = new ArrayList<PLMBomSalesData>();
			partsCount = 0;
			alertMessage = "";
			contractNo = "";
			unitSerialNum="";
			recordCount=PLMConstants.N_100;
			totalContractsCnt=0;
			contractList = new ArrayList<PLMBomSalesData>();
			} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@loadOmmReportPage:", exception);
		}
		LOG.info("Exiting loadBomVsSalesReportPage Method");
		return "bomVsSalesReportSearch";
	}
	
	/**
	 * This method is used for getting Contract List
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String getContractNames() throws PWiException {
		LOG.info("Entering getContractNames Method");
		String fwdflag = "";
		alertMessage = "";
		alertMessage = validateUnitSerialNumber();
		if (PLMUtils.isEmpty(alertMessage)) {
			try {
				contractList =  plmDocGenService.getContractNamesList(unitSerialNum);
				
				if(contractList.size() == 0) {
					alertMessage = PLMConstants.NO_CONTRACT_DATA_ALERT_MSG;
				}else {
					totalContractsCnt = contractList.size();
				    LOG.info("The number of results from Contract List >> "+totalContractsCnt);
				    recordCounts = PLMConstants.N_100;
				 }
			 }catch (PLMCommonException exception) {
					LOG.log(Level.ERROR, "Exception@getContractNames: ", exception);
					fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,fwdflag,"BOM Vs Sales Report");
			}
		}
		LOG.info("Exiting getContractNames Method");
		return fwdflag;
	}
	
	/**
	 * This method is used for Generating BOM Vs Sales Report for Contract with single part
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String getBomVsSalesReport() throws PWiException {
		LOG.info("Entering getBomVsSalesReport Method");
		String fwdflag = "bomVsSalesReportSearch";
		alertMessage="";
		 alertMessage=validateBVSComparisonInput();
		if (PLMUtils.isEmpty(alertMessage)) {			
			try {
				partsForContractList = plmDocGenService.getPartsForContract(contractNo);
				partsCount = partsForContractList.size();
				LOG.info("Parts for Contract : "+partsCount);
				if(partsCount == 0) {
					alertMessage = PLMConstants.BVS_NO_PART_DATA_ALERT_MSG;
				}else if(partsCount == 1){
					partNumber = partsForContractList.get(0).getPartVal();
					alertMessage = PLMConstants.BVS_MAIL_ALERT_MSG;
					taskExecutor.execute(new MailThread());
				}else if(partsCount > 1){
					//partNumber = partsForContractList.get(0).getPartId();
					mltplPartsForCntrctMsg = PLMConstants.BVS_MULTIPLE_PARTS_FOR_CONTRACT.replace("?",contractNo);
					////alertMessage = PLMConstants.BVS_MULTIPLE_PARTS_FOR_CONTRACT;					
				}
			 } catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getOmmReport: ", exception);
				fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,fwdflag,"BOM Vs Sales Report");
			}
		}
		LOG.info("Exiting getBomVsSalesReport Method");
		return fwdflag;
	}
	
	/**
	 * This method is used for Generating BOM Vs Sales Report for Part
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String getBomVsSalesReportForPart() throws PWiException{
		LOG.info("Entering getBomVsSalesReportForPart Method");
		String fwdflag = "bomVsSalesReportSearch";
			partsForContractList = new ArrayList<PLMBomSalesData>();
			partsCount = 0;	
			alertMessage = PLMConstants.BVS_MAIL_ALERT_MSG;
			LOG.info("Part Number = "+partNumber);
			taskExecutor.execute(new MailThread());
		LOG.info("Exiting getBomVsSalesReportForPart Method");
		return fwdflag;
	}
	
	/**
	 * This method is used for Validating Comparison User Input of Unit serial Number
	 * 
	 * @return String
	 */
	public String validateUnitSerialNumber() {
		LOG.info("Entering validateUnitSerialNumber Method");
		LOG.info("Entered unitSerialNum No : " + unitSerialNum);
		if(PLMUtils.isEmpty(unitSerialNum)){
			alertMessage = PLMConstants.BBVS_UNITSRL_CRITERIA;
		} else if(!PLMUtils.checkForSpecialChars(unitSerialNum)){
			alertMessage = PLMConstants.BVS_UNITSR_NO_SPLCHAR_CRITERIA;
		}
		LOG.info("Exiting validateUnitSerialNumber Method");
		return alertMessage;
	}
	
	
	/**
	 * This method is used for Validating Comparison User Input
	 * 
	 * @return String
	 */
	public String validateBVSComparisonInput() {
		LOG.info("Entering validateBVSComparisonInput Method");
		LOG.info("Entered Contract No : " + getContractNo());
		if(PLMUtils.isEmpty(getContractNo())){
			alertMessage = PLMConstants.BVS_COMPARISON_SEARCH_CRITERIA;
		} else if(!PLMUtils.checkForSpecialChars(getContractNo())){
			alertMessage = PLMConstants.BVS_COMPARISON_NO_SPLCHAR_CRITERIA;
		}
		LOG.info("Exiting validateBVSComparisonInput Method");
		return alertMessage;
	}
	
	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendBVSComparisonReportThroughMail();
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return void
	 * @throws PLMCommonException 
	 */
	public void sendBVSComparisonReportThroughMail() {
		LOG.info("Entering sendBVSComparisonReportThroughMail Method");		
		Map<String, Object> varMap = new HashMap<String, Object>();
		boolean fileExist=false;
		String contractLcl=contractNo;
		String partNumLcl =partNumber;
		String filePathZip = "";
		String folderPath = "";
		String fileName = "";
		Writer fw = null;
		SpreadsheetWriter sw = null;
		boolean fileFlag = true;
		String deltempXmlFile="";
		boolean bomDataFlag=false;
		try {			
			
			List<PLMBomSalesData> plmBomDataResultList = plmDocGenService.getBOMDataForContract(contractLcl, partNumLcl);
			List<PLMBomSalesData> plmSalesDataResultList = plmDocGenService.getSalesDataForContract(contractLcl);
			if(!PLMUtils.isEmptyList(plmBomDataResultList) || !PLMUtils.isEmptyList(plmSalesDataResultList)){
				
				 if(!PLMUtils.isEmptyList(plmBomDataResultList)){
					 bomDataFlag=true;
					 LOG.info("bomDataFlag>>>>" +bomDataFlag);
				 }
				 String folPath = resourceBundle.getString("OFFLINE_RPT_DIR");
					fileName = folPath + resourceBundle.getString("BOM_VS_Sales_TEMPLATE_XLSM");
					Date uniqDate = new Date();
			    	final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
					String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
					folderPath = folPath + resourceBundle.getString("BOM_VS_SALES_REPORT_NAME") + contractLcl + "-" + uniqTime;
					filePathZip = folderPath + ".zip";
					
					
					File fol = new File(folPath);
					if(fol.exists()){
						fol = new File(folderPath);
						fol.mkdir();
					}

					varMap.put("contractNo", contractLcl);
					varMap.put("fileName", fileName);
					varMap.put("folderPath", folderPath);
					varMap.put("fileFlag", fileFlag);
					varMap.put("filePathZip", filePathZip);
					
				prepareBOMVsSalesDataForComoparison(plmBomDataResultList, plmSalesDataResultList, varMap);
				//prepareExcelWorkBook(varMap);
				prepareSpreadsheetWriter(varMap, contractLcl, partNumLcl);
				sw = (SpreadsheetWriter) varMap.get("sw");
				compareBOMVsSalesData(varMap,sw,bomDataFlag);
				writeExcelFileUsingAppendedXML(varMap);
				//writeDataToExcelFile(varMap);
				PLMUtils.generateZipFile((String)varMap.get("filePathXls"), (String)varMap.get("filePathZip"));		
				sendMail(varMap);
				deltempXmlFile=folderPath+"/"+(String)varMap.get("tempXmlFile");
				fileExist=true;
			}else{	
				varMap.put("contractNo", contractLcl);
				sendNoBOMSalesDataMail(varMap);
				LOG.info("No data Mail sent");
			}
		} catch (IOException ioexception) {	
			LOG.log(Level.ERROR, "Exception@sendBVSComparisonReportThroughMail: ", ioexception);
			PLMUtils.checkExceptionAndMail(ioexception.getMessage(), PLMConstants.BVS_MAIL_FROM, (String)varMap.get("to"), (String)varMap.get("subject"), (String)varMap.get("toAddressee"), PLMConstants.BVS_MAIL_SIGNATURE + PLMConstants.BVS_MAIL_FOOTER);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendBVSComparisonReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(), PLMConstants.BVS_MAIL_FROM, (String)varMap.get("to"), (String)varMap.get("subject"), (String)varMap.get("toAddressee"), PLMConstants.BVS_MAIL_SIGNATURE + PLMConstants.BVS_MAIL_FOOTER);
		}
		finally {
			
			fw = (Writer) varMap.get("fw");
			if(fw != null){
				LOG.info("Closing Writer");
				try {
					fw.close();
				} catch (IOException e) {
					LOG.info("Exception occurred while Closing Writer: "+ e.getMessage());
					try {
						PLMUtils.checkException(e.getMessage());
					} catch (PLMCommonException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
			
			if(fileExist){
				 PLMUtils.deleteFiles((String)varMap.get("filePathXls"),(String)varMap.get("filePathZip"));
				 PLMUtils.deleteFiles(folderPath,deltempXmlFile);
			 }
			
		}
		LOG.info("Exiting sendBVSComparisonReportThroughMail Method");
	}
	
	
	/**
     * This method is used for createExcelFileMap
	   * 
	   * @param selectedPF,varMap
	   * @return Map
     * @throws PLMCommonException
     */
  private Map<String, Object> createExcelFileMap(Map<String, Object> varMap) throws PLMCommonException {
		String filePathXls = "";
		String folderPath = (String) varMap.get("folderPath");	
		try {
			Date uniqDate = new Date();
			final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat(
					"yyyyMMddHHmmss");
			String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
			filePathXls = folderPath + "/"
					+ resourceBundle.getString("BOM_VS_SALES_REPORT_NAME") + " "
					+ uniqTime + ".xlsm";
	
			varMap.put("filePathXls", filePathXls);
	
		} catch (Exception e) {
			LOG.log(Level.ERROR, "Exception@createNewFile: ", e);
			PLMUtils.checkException(e.getMessage());
		}
	    return varMap;
  }  
	 /**
     * This method is used for writeExcelFileUsingAppendedXML
	 * 
	 * @param varMap
	 * @throws PLMCommonException
	 */
	private void writeExcelFileUsingAppendedXML(Map<String, Object> varMap) throws PLMCommonException {
		String filePathXls;
		Map<String, Object> varMapVal=varMap;
		String folderPath = (String) varMapVal.get("folderPath");
		String fileName = (String) varMapVal.get("fileName");	
	    String tempXmlFile = (String) varMapVal.get("tempXmlFile");
	    Writer fw = (Writer) varMapVal.get("fw");
		SpreadsheetWriter sw = (SpreadsheetWriter) varMapVal.get("sw");
		boolean fileFlag = (Boolean) varMapVal.get("fileFlag");
    	LOG.info("fileFlag>> "+fileFlag);
    	FileOutputStream out=null;
	    try {   
	    	if(fw != null){
				endSheet(sw);
				fw.close();				 
			}
	    	varMapVal = createExcelFileMap(varMapVal); 
			filePathXls = (String) varMapVal.get("filePathXls");											 
			File tmp = new File(folderPath + "/" + tempXmlFile);
			 out = new FileOutputStream(filePathXls);
			PLMUtils.substitute(new File(fileName), tmp, "xl/worksheets/sheet1.xml", out);
			//out.close();		
			
			varMapVal.put("fileFlag",true);
	        //LOG.info("XML Temp File = "+tmp.getName()+" Deleted = "+tmp.delete());
			//LOG.info("Closed File successfully");
	    } catch (FileNotFoundException e) {
	   	 	LOG.log(Level.ERROR, "Exception@writeExcelFileUsingAppendedXML: ", e);
	   	 	PLMUtils.checkException(e.getMessage());
	    } catch (IOException e) {
	   	 	LOG.log(Level.ERROR, "Exception@writeExcelFileUsingAppendedXML: ", e);
	   	 	PLMUtils.checkException(e.getMessage());
	    } 	   
	    finally{
			   if(out != null ){
				   try {
					   out.close();
				} catch (IOException e) {
					PLMUtils.checkException(e.getMessage());
				}
			   }
	    }	   
	}
	/**
     * This method is used for prepareSpreadsheetWriter
	 * 
	 * @param varMap
	 * @param pfName
	 * @throws Exception 
	 */
	private void prepareSpreadsheetWriter(Map<String, Object> varMap, String contract, String partVal) throws IOException {
		String folderPath = (String) varMap.get("folderPath");
		String tempXmlFile = "";
		Writer fw = null;
		SpreadsheetWriter sw = (SpreadsheetWriter) varMap.get("sw");
		if(sw != null){
			LOG.info("sw--->"+sw.toString());
		}
		boolean fileFlag = (Boolean) varMap.get("fileFlag");
		
		if(fileFlag){
			tempXmlFile = createTempFile(folderPath);
			fw = new OutputStreamWriter(new FileOutputStream(folderPath + "/" + tempXmlFile, true), XML_ENCODING);
		    sw = new SpreadsheetWriter(fw);
		    fileFlag = false;
		    
			beginSheet(sw);
	    	addExceHeaders(sw, contract, partVal);
	    	
	    	varMap.put("tempXmlFile", tempXmlFile);
	    	varMap.put("fileFlag", fileFlag);
	    	varMap.put("fw", fw);
	    	varMap.put("sw", sw);
		}		
	}
	/**
     * This method is used for createTempFile
	 * 
	 * @param String folderPath
	 * @return String fileName
	 * @throws IOException
	 */	
	 private String createTempFile(String folderPath) throws IOException{
		 File tmp = File.createTempFile("sheet", ".xml", new File(folderPath));
	     LOG.info("Temp File Name "+tmp.getName());
	     return tmp.getName();
	 }
	 
	 /**
	   * @param SpreadsheetWriter	 
	   */
	 private void beginSheet(SpreadsheetWriter sw) throws IOException{	 
		 sw.beginSheet(resourceBundle.getString(PLMConstants.SPREADSHEET_SCHEMA_URL));
	 }
		 
	 /**
	 * @param SpreadsheetWriter	 
	 */
	 private void endSheet(SpreadsheetWriter sw) throws IOException{	
		 sw.endSheet();
	 }
	 
	 /**
	     * This method is used for addExceHeaders
		 * 
		 * @param SpreadsheetWriter	 
		 * @param String selectedPF 
		 * @throws Exception
		 */
	 private void addExceHeaders(SpreadsheetWriter sw, String selContract, String partVal) throws IOException { 
		 
		 String[] strArr = null;
		 String partName = "";
		 String partRev = "";
		if (!PLMUtils.isEmpty(partVal)) {
			strArr = partVal.split("~");
			partName = strArr[1];
			partRev = strArr[2];
		}
		 sw.insertRow(0);	     
	     sw.createCell(0, "Bom Vs Sales Report for - "+selContract);
	     sw.createCell(1, partName);
	     sw.createCell(2, partRev);
	     sw.endRow();
		 
		 String[] colNames = {"Level", "BOM Prefix", "Name", "Rev", "Description", "State", "Qty", "U of M", "Name", "Unit Serial Number", 
			"MLI/CC", "Part", "Description", "ERP Line Number",	"Quantity",	"Unit Of Measure",	"Reqst Ship date",	"State", "Line Status", 
			"Promised Date","Shipped Date","Delivery","Tracking (LPN Name)", "Internal Comments", "External Comments"};
	     sw.insertRow(2);
	     for ( int i = 0 ; i < colNames.length; i++ ) {
	    	 sw.createCell(i, colNames[i]);
		  }	    
	     sw.endRow();
	 }
	
	/**
	 * This method is used for Sending Mail
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void sendMail(Map<String, Object> varMap) throws PLMCommonException{
		LOG.info("Entering sendMail Method");
		String from = PLMConstants.BVS_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.BVS_MAIL_SUBJECT + varMap.get("contractNo");
		StringBuffer mailBody = new StringBuffer().append(toAddressee);
		boolean isCompared = (Boolean) varMap.get("isCompared");
		
		varMap.put("to", to);
		varMap.put("toAddressee", toAddressee);
		varMap.put("subject", subject);
		
		if(!isCompared){
			mailBody.append(PLMConstants.BVS_MAIL_CONTENT_NO_RECORD);
		} else {
			mailBody.append(PLMConstants.BVS_MAIL_CONTENT);
		}
		mailBody.append(varMap.get("contractNo"))
		.append(".")
		.append(PLMConstants.BVS_MAIL_SIGNATURE)
		.append(PLMConstants.BVS_MAIL_FOOTER);
		PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), (String)varMap.get("filePathZip"));
		
		LOG.info("Exiting sendMail Method");
	}
	
	/**
	 * This method is used for Sending No Mail Mail
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void sendNoBOMSalesDataMail(Map<String, Object> varMap) throws PLMCommonException{
		LOG.info("Entering sendNoBOMSalesDataMail Method");
		String from = PLMConstants.BVS_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.BVS_MAIL_SUBJECT + varMap.get("contractNo");
		StringBuffer mailBody = new StringBuffer().append(toAddressee);
		
		varMap.put("to", to);
		varMap.put("toAddressee", toAddressee);
		varMap.put("subject", subject);
		
		mailBody.append(PLMConstants.BVS_MAIL_CONTENT_NO_RECORD);
		mailBody.append(varMap.get("contractNo"))
		.append(".")
		.append(PLMConstants.BVS_MAIL_SIGNATURE)
		.append(PLMConstants.BVS_MAIL_FOOTER);
		PLMUtils.sendMail(from, to, subject, mailBody.toString());
		
		LOG.info("Exiting sendNoBOMSalesDataMail Method");
	}
	
	/**
	 * This method is used for preparing data ready for Comparison with BOM Vs Sales
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void prepareBOMVsSalesDataForComoparison(List<PLMBomSalesData> plmBomDataResultList, List<PLMBomSalesData> plmSalesDataResultList, Map<String, Object> varMap) throws PLMCommonException{
		LOG.info("Entering sendBVSComparisonReportThroughMail Method");
		List<PLMBomSalesData> emptyListData = new ArrayList<PLMBomSalesData>();
//		Map<String, List<PLMBomSalesData>> bomMLIListMap = new TreeMap<String, List<PLMBomSalesData>>();
//		Map<String, List<PLMBomSalesData>> salesMLIListMap = new TreeMap<String, List<PLMBomSalesData>>();
		Map<String, String> mlisUniqueMap = new TreeMap<String, String>();
		
		LOG.info("Converting BOM Data for comparison");
		Map<String, List<PLMBomSalesData>> bomMLIListMap = convertListToMapForComparison(plmBomDataResultList);
		plmBomDataResultList.clear();
		
		LOG.info("Converting Sales Data for comparison");
		Map<String, List<PLMBomSalesData>> salesMLIListMap = convertListToMapForComparison(plmSalesDataResultList);
		plmSalesDataResultList.clear();
		
		getUniqueMlis(bomMLIListMap, mlisUniqueMap);
		getUniqueMlis(salesMLIListMap, mlisUniqueMap);
		
		LOG.info("BOM Map size before adding missing MLI "+bomMLIListMap.size());
		LOG.info("Sales Map size before adding missing MLI "+bomMLIListMap.size());
		for (Map.Entry<String, String> entry : mlisUniqueMap.entrySet()) {
			//LOG.info("MLI "+entry.getKey());
			if(salesMLIListMap.get(entry.getKey()) == null){
				salesMLIListMap.put(entry.getKey(), emptyListData);
			}
			if(bomMLIListMap.get(entry.getKey()) == null){
				bomMLIListMap.put(entry.getKey(), emptyListData);
			}
		}
		LOG.info("BOM Map size after adding missing MLI "+bomMLIListMap.size());
		if(!PLMUtils.isEmptyMap(bomMLIListMap)){
			List<String> list = new ArrayList<String>(bomMLIListMap.keySet());
			LOG.info("First Key in bomMLIListMap------>"+list.get(0));
			list.clear();
		}
		LOG.info("Sales Map size after adding missing MLI "+salesMLIListMap.size());
		if(!PLMUtils.isEmptyMap(salesMLIListMap)){
			List<String> list = new ArrayList<String>(salesMLIListMap.keySet());
			LOG.info("Keys in salesMLIListMap------>"+list.get(0));
			list.clear();
		}
		
		varMap.put("bomMLIListMap",bomMLIListMap);
		varMap.put("salesMLIListMap",salesMLIListMap);
	}
	
	/**
	 * This method is used for Comparing BOM Vs Sales Data
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	/*private void compareBOMVsSalesData(Map<String, Object> varMap) throws PLMCommonException{
		
			Map<String, List<PLMBomSalesData>> bomMLIListMap = (TreeMap<String, List<PLMBomSalesData>>) varMap.get("bomMLIListMap");
			Map<String, List<PLMBomSalesData>> salesMLIListMap = (TreeMap<String, List<PLMBomSalesData>>) varMap.get("salesMLIListMap");
			//List<PLMBomSalesData> salesListData = new ArrayList<PLMBomSalesData>();
			String bomMliPartStr;
			String salesMliPartStr;
			boolean isCompared = false;
			
			int rowCount1 = 1;
			int count = 0;
			HSSFRow row = null;
			HSSFSheet sheet = null;
			
			sheet = (HSSFSheet) varMap.get("sheet");
			
			for (Map.Entry<String, List<PLMBomSalesData>> entry : bomMLIListMap.entrySet()) {
				List<PLMBomSalesData> salesListData = new ArrayList<PLMBomSalesData>();
				//LOG.info(entry.getKey()+" count results "+entry.getValue().size());
				if(salesMLIListMap.get(entry.getKey()) != null){
					salesListData.addAll(salesMLIListMap.get(entry.getKey()));
					LOG.info(" salesListData>>"+salesListData.size());
				}/*else{
					salesListData = new ArrayList<PLMBomSalesData>();
				}*/
				/*for (PLMBomSalesData bOData : bomMLIListMap.get(entry.getKey())) {					
					
					bomMliPartStr = bOData.getMlNum()+bOData.getPartName();
					for (PLMBomSalesData salesData : salesListData) {
						salesMliPartStr = salesData.getMlNum()+salesData.getPartName();								
						if(bomMliPartStr.equals(salesMliPartStr)){			
							////LOG.info(bOData.getMlno()+"  "+bOData.getPartName()+" sales "+salesData.getMlno()+"  "+salesData.getPartName()+"  "+salesData.getDescription());
							bOData.setCompared(true);						
							salesData.setCompared(true);
							
							row = sheet.createRow(rowCount1);
							writeBOMData(row, bOData);							
							writeSalesData(row, salesData);
							rowCount1++;
						}	
						count++;
					}
					if(!bOData.isCompared()){			
						////LOG.info(bOData.getMlno()+"  "+bOData.getPartName());
						
						row = sheet.createRow(rowCount1);
						writeBOMData(row, bOData);
						writeEmptySales(row);
						rowCount1++;
					}				
					
				}			
				//LOG.info(" size of sales "+salesListData.size()+" "+comparedSalesIndexList.size());
				for (PLMBomSalesData salesData : salesListData) {					
					if(!salesData.isCompared()){
						////LOG.info(" ----------- "+" Unmatched "+salesData.getMlno()+"  "+salesData.getPartName()+"  "+salesData.getDescription());
						
						row = sheet.createRow(rowCount1);
						writeSalesData(row, salesData);	
						writeEmptyBOM(row);
						rowCount1++;
					}
				}
			}
			LOG.info(count);
			isCompared = true;
			varMap.put("isCompared", isCompared);
		
	}*/
	

	/**
	 * This method is used for Comparing BOM Vs Sales Data
	 * 
	 * @return void
	 * @throws PLMCommonException
	 * @throws IOException 
	 */
	private void compareBOMVsSalesData(Map<String, Object> varMap,SpreadsheetWriter sw,boolean bomDataFlagLcl) throws PLMCommonException{
		
			Map<String, List<PLMBomSalesData>> bomMLIListMap = (TreeMap<String, List<PLMBomSalesData>>) varMap.get("bomMLIListMap");
			Map<String, List<PLMBomSalesData>> salesMLIListMap = (TreeMap<String, List<PLMBomSalesData>>) varMap.get("salesMLIListMap");
			//List<PLMBomSalesData> salesListData = new ArrayList<PLMBomSalesData>();
			String bomMliPartStr;
			String salesMliPartStr;
			boolean isCompared = false;
			boolean bomDescFlg = false;
			//boolean salesDescFlg = false;
		try{
			int rowCount1 = 3;
			int count = 0;
			String bomLevel="1";
			int bomCount=0;
			int saleCount=0;
			int unEqQtyCnt=0;
			
			for (Map.Entry<String, List<PLMBomSalesData>> entry : bomMLIListMap.entrySet()) {
				bomDescFlg = false;
				List<PLMBomSalesData> salesListData = new ArrayList<PLMBomSalesData>();
				//LOG.info(entry.getKey()+" count results "+entry.getValue().size());
				if(salesMLIListMap.get(entry.getKey()) != null){
					salesListData.addAll(salesMLIListMap.get(entry.getKey()));
					LOG.info(" salesListData>>"+salesListData.size());
				}/*else{
					salesListData = new ArrayList<PLMBomSalesData>();
				}*/
				for (PLMBomSalesData bOData : bomMLIListMap.get(entry.getKey())) {		
					bomMliPartStr = bOData.getMlNum()+bOData.getPartName();
					for (PLMBomSalesData salesData : salesListData) {
						salesMliPartStr = salesData.getMlNum()+salesData.getPartName();								
						if(bomMliPartStr.equals(salesMliPartStr)){			
							////LOG.info(bOData.getMlno()+"  "+bOData.getPartName()+" sales "+salesData.getMlno()+"  "+salesData.getPartName()+"  "+salesData.getDescription());
							bOData.setCompared(true);						
							salesData.setCompared(true);
							sw.insertRow(rowCount1);	
							sw.createCell(PLMConstants.EXCEL_COL_ZERO,bOData.getBomLevel());
							sw.createCell(PLMConstants.EXCEL_COL_ONE,bOData.getMlNum());
							sw.createCell(PLMConstants.EXCEL_COL_TWO,bOData.getPartName());
							sw.createCell(PLMConstants.EXCEL_COL_THREE,bOData.getBomRevision());		
							sw.createCell(PLMConstants.EXCEL_COL_FOUR,bOData.getDescription());	
							sw.createCell(PLMConstants.EXCEL_COL_FIVE,bOData.getState());	 
							sw.createCell(PLMConstants.EXCEL_COL_SIX,bOData.getQuantity());	
							sw.createCell(PLMConstants.EXCEL_COL_SEVEN,bOData.getUnitOfMeasure());
							
							sw.createCell(PLMConstants.EXCEL_COL_EIGHT,salesData.getSalesID());
							sw.createCell(PLMConstants.EXCEL_COL_NINE,salesData.getUnitSerialNumber());
							sw.createCell(PLMConstants.EXCEL_COL_TEN,salesData.getMlNum());
							sw.createCell(PLMConstants.EXCEL_COL_ELEVEN,salesData.getPartName());		
							sw.createCell(PLMConstants.EXCEL_COL_TWELVE,salesData.getDescription());	
							sw.createCell(PLMConstants.EXCEL_COL_THIRTEEN,salesData.getErpLineNumber());	 
							sw.createCell(PLMConstants.EXCEL_COL_FOURTEEN,salesData.getQuantity());	
							sw.createCell(PLMConstants.EXCEL_COL_FIFTEEN,salesData.getUnitOfMeasure());
							sw.createCell(PLMConstants.EXCEL_COL_SIXTEEN,salesData.getRequestedShipDate());	
							sw.createCell(PLMConstants.EXCEL_COL_SEVENTEEN,salesData.getState());	 
							sw.createCell(PLMConstants.EXCEL_COL_EIGHTEEN,salesData.getLineStatus());	
							sw.createCell(PLMConstants.EXCEL_COL_NINETEEN,salesData.getPromisedDate());	 
							sw.createCell(PLMConstants.EXCEL_COL_TWENTY,salesData.getShipDate());		
							sw.createCell(PLMConstants.EXCEL_COL_TWENTYONE,salesData.getDelivery());
							sw.createCell(PLMConstants.EXCEL_COL_TWENTYTWO,salesData.getTrackingLpn());
							sw.createCell(PLMConstants.EXCEL_COL_TWENTYTHREE,salesData.getInternalComments());
							sw.createCell(PLMConstants.EXCEL_COL_TWENTYFOUR,salesData.getExternalComments());
							sw.endRow();
							if(!PLMUtils.isEmpty(bOData.getQuantity()) && !PLMUtils.isEmpty(salesData.getQuantity()) &&
									!bOData.getQuantity().equalsIgnoreCase(salesData.getQuantity())){
							 unEqQtyCnt++;
							}
							rowCount1++;
							//salesDescFlg = false;
						}	
						count++;
						
						bomLevel=bOData.getBomLevel();
					}
					if(!bOData.isCompared()){			
						////LOG.info(bOData.getMlno()+"  "+bOData.getPartName());
						
						sw.insertRow(rowCount1);	
						sw.createCell(PLMConstants.EXCEL_COL_ZERO,bOData.getBomLevel());
						sw.createCell(PLMConstants.EXCEL_COL_ONE,bOData.getMlNum());
						sw.createCell(PLMConstants.EXCEL_COL_TWO,bOData.getPartName());
						sw.createCell(PLMConstants.EXCEL_COL_THREE,bOData.getBomRevision());		
						sw.createCell(PLMConstants.EXCEL_COL_FOUR,bOData.getDescription());	
						sw.createCell(PLMConstants.EXCEL_COL_FIVE,bOData.getState());	 
						sw.createCell(PLMConstants.EXCEL_COL_SIX,bOData.getQuantity());	
						sw.createCell(PLMConstants.EXCEL_COL_SEVEN,bOData.getUnitOfMeasure());
						
						sw.createCell(PLMConstants.EXCEL_COL_EIGHT,"");
						sw.createCell(PLMConstants.EXCEL_COL_NINE,"");
						sw.createCell(PLMConstants.EXCEL_COL_TEN,"");
						sw.createCell(PLMConstants.EXCEL_COL_ELEVEN,"");
						/*if(salesDescFlg && !bOData.getBomLevel().equalsIgnoreCase("1")) {
						 sw.createCell(PLMConstants.EXCEL_COL_TWELVE,"");
						}else{
						 sw.createCell(PLMConstants.EXCEL_COL_TWELVE,"BOM RECORD NOT FOUND IN ERP");
						}*/
						if(salesListData.size()==0 && bOData.getBomLevel().equalsIgnoreCase("1")){
							 sw.createCell(PLMConstants.EXCEL_COL_TWELVE,"BOM RECORD NOT FOUND IN ERP");//Applied condition for no Sales Data entire level structure from 1 to N
						}else if (salesListData.size() > 0){
							 sw.createCell(PLMConstants.EXCEL_COL_TWELVE,"");//Applied condition for no Sales Data for some levels
						 }else{
							 sw.createCell(PLMConstants.EXCEL_COL_TWELVE,"No Data Found");//Applied condition for no Sales Data for further levels between 1 to N
						 }
						sw.createCell(PLMConstants.EXCEL_COL_THIRTEEN,"");
						sw.createCell(PLMConstants.EXCEL_COL_FOURTEEN,"");
						sw.createCell(PLMConstants.EXCEL_COL_FIFTEEN,"");
						sw.createCell(PLMConstants.EXCEL_COL_SIXTEEN,"");
						sw.createCell(PLMConstants.EXCEL_COL_SEVENTEEN,"");
						sw.createCell(PLMConstants.EXCEL_COL_EIGHTEEN,"");
						sw.createCell(PLMConstants.EXCEL_COL_NINETEEN,"");
						sw.createCell(PLMConstants.EXCEL_COL_TWENTY,"");
						sw.createCell(PLMConstants.EXCEL_COL_TWENTYONE,"");	 
						sw.createCell(PLMConstants.EXCEL_COL_TWENTYTWO,"");	
						sw.createCell(PLMConstants.EXCEL_COL_TWENTYTHREE,"");
						sw.createCell(PLMConstants.EXCEL_COL_TWENTYFOUR,"");
						sw.endRow();
						rowCount1++;
						saleCount++;
						bomLevel=bOData.getBomLevel();
						//salesDescFlg=true;
					}				
					
				}			
				//LOG.info(" size of sales "+salesListData.size()+" "+comparedSalesIndexList.size());
				for (PLMBomSalesData salesData : salesListData) {					
					if(!salesData.isCompared()){
						////LOG.info(" ----------- "+" Unmatched "+salesData.getMlno()+"  "+salesData.getPartName()+"  "+salesData.getDescription());
						sw.insertRow(rowCount1);
						if(bomDataFlagLcl){
							sw.createCell(PLMConstants.EXCEL_COL_ZERO,bomLevel);
							sw.createCell(PLMConstants.EXCEL_COL_ONE,"");
							sw.createCell(PLMConstants.EXCEL_COL_TWO,"");
							sw.createCell(PLMConstants.EXCEL_COL_THREE,"");
							 if(bomDescFlg){
								 sw.createCell(PLMConstants.EXCEL_COL_FOUR,"");
							 }else if(PLMUtils.isEmpty(salesData.getMlNum())){
								 sw.createCell(PLMConstants.EXCEL_COL_FOUR,"MLI/CC Field is Empty");
							  }else if(!PLMUtils.isEmpty(salesData.getMlNum())){
								  sw.createCell(PLMConstants.EXCEL_COL_FOUR,"ERP RECORD WAS NOT FOUND IN BOM FILE");
							  }

						}else{
							sw.createCell(PLMConstants.EXCEL_COL_ZERO,PLMConstants.ONE);
							sw.createCell(PLMConstants.EXCEL_COL_ONE,"");
							sw.createCell(PLMConstants.EXCEL_COL_TWO,"");
							sw.createCell(PLMConstants.EXCEL_COL_THREE,"");
							 if(bomDescFlg){
								 sw.createCell(PLMConstants.EXCEL_COL_FOUR,"");
							 }else if(PLMUtils.isEmpty(salesData.getMlNum())){
								  sw.createCell(PLMConstants.EXCEL_COL_FOUR,"MLI/CC Field is Empty");
							  }else if(!PLMUtils.isEmpty(salesData.getMlNum())){
								  sw.createCell(PLMConstants.EXCEL_COL_FOUR,"ERP RECORD WAS NOT FOUND IN BOM FILE");
							  }
						 }
						
						sw.createCell(PLMConstants.EXCEL_COL_FIVE,"");
						sw.createCell(PLMConstants.EXCEL_COL_SIX,"");
						sw.createCell(PLMConstants.EXCEL_COL_SEVEN,"");
						
						sw.createCell(PLMConstants.EXCEL_COL_EIGHT,salesData.getSalesID());
						sw.createCell(PLMConstants.EXCEL_COL_NINE,salesData.getUnitSerialNumber());
						sw.createCell(PLMConstants.EXCEL_COL_TEN,salesData.getMlNum());
						sw.createCell(PLMConstants.EXCEL_COL_ELEVEN,salesData.getPartName());		
						sw.createCell(PLMConstants.EXCEL_COL_TWELVE,salesData.getDescription());	
						sw.createCell(PLMConstants.EXCEL_COL_THIRTEEN,salesData.getErpLineNumber());	 
						sw.createCell(PLMConstants.EXCEL_COL_FOURTEEN,salesData.getQuantity());	
						sw.createCell(PLMConstants.EXCEL_COL_FIFTEEN,salesData.getUnitOfMeasure());
						sw.createCell(PLMConstants.EXCEL_COL_SIXTEEN,salesData.getRequestedShipDate());	
						sw.createCell(PLMConstants.EXCEL_COL_SEVENTEEN,salesData.getState());	 
						sw.createCell(PLMConstants.EXCEL_COL_EIGHTEEN,salesData.getLineStatus());	
						sw.createCell(PLMConstants.EXCEL_COL_NINETEEN,salesData.getPromisedDate());	 
						sw.createCell(PLMConstants.EXCEL_COL_TWENTY,salesData.getShipDate());		
						sw.createCell(PLMConstants.EXCEL_COL_TWENTYONE,salesData.getDelivery());
						sw.createCell(PLMConstants.EXCEL_COL_TWENTYTWO,salesData.getTrackingLpn());
						sw.createCell(PLMConstants.EXCEL_COL_TWENTYTHREE,salesData.getInternalComments());
						sw.createCell(PLMConstants.EXCEL_COL_TWENTYFOUR,salesData.getExternalComments());
						sw.endRow();
						rowCount1++;
						bomCount++;
						bomDescFlg=true;
						//salesDescFlg = false;
					}
				}
			}
			
			rowCount1++;
			rowCount1++;
			sw.insertRow(rowCount1);
			sw.createCell(PLMConstants.EXCEL_COL_ZERO,"Rows not founded in BOM/MPL");
			sw.createCell(PLMConstants.EXCEL_COL_ONE,"Rows not founded in EPR SON");
			sw.createCell(PLMConstants.EXCEL_COL_TWO,"BOM Quantity is not Equal to ERP Quantity");
			sw.endRow();
			rowCount1++;
			sw.insertRow(rowCount1);
			sw.createCell(PLMConstants.EXCEL_COL_ZERO,bomCount);
			sw.createCell(PLMConstants.EXCEL_COL_ONE,saleCount);
			sw.createCell(PLMConstants.EXCEL_COL_TWO,unEqQtyCnt);
			sw.endRow();
			
			LOG.info(count);
			isCompared = true;
			varMap.put("isCompared", isCompared);
		}catch (IOException e) {
			 LOG.log(Level.ERROR, "Exception@compareBOMVsSalesData : ", e);
		   	 PLMUtils.checkException(e.getMessage());
		}	
		
	}
	
	/**
	 * This method is used for creating Excel which will have BOM Vs Sales Data
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	/*private void prepareExcelWorkBook(Map<String, Object> varMap) throws IOException{
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		FileInputStream file = null;
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String folderPath = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = folderPath + resourceBundle.getString("BOM_VS_SALES_REPORT_NAME") + varMap.get("contractNo") + "_" + uniqTime + ".xls";
		String filePathZip = folderPath + resourceBundle.getString("BOM_VS_SALES_REPORT_NAME") + varMap.get("contractNo") + "_" + uniqTime + ".zip";
		List<String> filePathXlsLst = new ArrayList<String>();
		filePathXlsLst.add(filePathXls);
		LOG.info("folderPath>>>> "+folderPath);
		String outptFileTemplate =  folderPath + resourceBundle.getString("BOM_VS_SALES_TEMPLATE_NAME");
		
		file = new FileInputStream(new File(outptFileTemplate));
		workbook = new HSSFWorkbook(file);
		sheet = workbook.getSheetAt(0);
		
		bomCellStyle = workbook.createCellStyle();
		bomCellStyle.setFillForegroundColor(HSSFColor.RED.index);
		bomCellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND); 
		
		salesCellStyle = workbook.createCellStyle();			
		salesCellStyle.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
		salesCellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);  
		
		varMap.put("workbook", workbook);
		varMap.put("sheet", sheet);	
		varMap.put("folderPath", folderPath);
		varMap.put("filePathXls", filePathXls);
		varMap.put("filePathZip", filePathZip);
		varMap.put("filePathXlsLst", filePathXlsLst);
	}*/
	
	/**
	 * This method is used for Writing data in to Excel File
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void writeDataToExcelFile(Map<String, Object> varMap) throws IOException, PLMCommonException{
		HSSFWorkbook workbook = (HSSFWorkbook)varMap.get("workbook");
		FileOutputStream outFile = null;		
		String folderPath = (String) varMap.get("folderPath");
		String filePathXls = (String) varMap.get("filePathXls");		
		LOG.info("folderPath>> "+folderPath);
		try {
		outFile = new FileOutputStream(new File(filePathXls));
		workbook.write(outFile);
		
		} catch (IOException ioexception) {	
			PLMUtils.checkException(ioexception.getMessage());
			LOG.log(Level.ERROR, "Exception@writeDataToExcelFile: ", ioexception);
		}
		  finally{
			   if(outFile != null ){
				   try {
					   outFile.close();
				} catch (IOException e) {
					PLMUtils.checkException(e.getMessage());
				}
			   }
		}
	}
	
	/**
	 * This method is used for adding BOM data to Excel
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void writeBOMData(HSSFRow row, PLMBomSalesData bOData) throws PLMCommonException{
		row.createCell(0).setCellValue(bOData.getBomLevel());
		row.createCell(1).setCellValue(bOData.getMlNum());
		row.createCell(2).setCellValue(bOData.getPartName());
		row.createCell(3).setCellValue(bOData.getBomRevision());
		row.createCell(4).setCellValue(bOData.getDescription());
		row.createCell(5).setCellValue(bOData.getState());
		row.createCell(6).setCellValue(bOData.getQuantity());
		row.createCell(7).setCellValue(bOData.getUnitOfMeasure());				
	}
	
	/**
	 * This method is used for adding empty BOM data to Excel
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void writeEmptyBOM(HSSFRow row) throws PLMCommonException{
		row.createCell(0).setCellStyle(bomCellStyle);
		row.createCell(1).setCellStyle(bomCellStyle);
		row.createCell(2).setCellStyle(bomCellStyle);
		row.createCell(3).setCellStyle(bomCellStyle);
		row.createCell(4).setCellStyle(bomCellStyle);
		row.createCell(5).setCellStyle(bomCellStyle);
		row.createCell(6).setCellStyle(bomCellStyle);
		row.createCell(7).setCellStyle(bomCellStyle);		
	}
	
	/**
	 * This method is used for adding Sales data to Excel
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void writeSalesData(HSSFRow row, PLMBomSalesData salesData) throws PLMCommonException{
		row.createCell(8).setCellValue(salesData.getSalesID());
		row.createCell(9).setCellValue(salesData.getUnitSerialNumber());
		row.createCell(10).setCellValue(salesData.getMlNum());
		row.createCell(11).setCellValue(salesData.getPartName());
		row.createCell(12).setCellValue(salesData.getDescription());
		row.createCell(13).setCellValue(salesData.getErpLineNumber());
		row.createCell(14).setCellValue(salesData.getQuantity());
		row.createCell(15).setCellValue(salesData.getUnitOfMeasure());
		row.createCell(16).setCellValue(salesData.getRequestedShipDate());
		row.createCell(17).setCellValue(salesData.getState());
		row.createCell(18).setCellValue(salesData.getLineStatus());
		row.createCell(19).setCellValue(salesData.getInternalComments());
		row.createCell(20).setCellValue(salesData.getExternalComments());	
	}
	
	/**
	 * This method is used for adding empty Sales data to Excel
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void writeEmptySales(HSSFRow row) throws PLMCommonException{
		row.createCell(8).setCellStyle(salesCellStyle);
		row.createCell(9).setCellStyle(salesCellStyle);
		row.createCell(10).setCellStyle(salesCellStyle);
		row.createCell(11).setCellStyle(salesCellStyle);
		row.createCell(12).setCellStyle(salesCellStyle);
		row.createCell(13).setCellStyle(salesCellStyle);
		row.createCell(14).setCellStyle(salesCellStyle);
		row.createCell(15).setCellStyle(salesCellStyle);
		row.createCell(16).setCellStyle(salesCellStyle);
		row.createCell(17).setCellStyle(salesCellStyle);
		row.createCell(18).setCellStyle(salesCellStyle);
		row.createCell(19).setCellStyle(salesCellStyle);
		row.createCell(20).setCellStyle(salesCellStyle);
	}	
	
	/**
	 * This method is used for removing duplicate MLI's from BOM and Sales
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void getUniqueMlis(Map<String, List<PLMBomSalesData>> bvsMLIMap, Map<String, String> mlisUniqueMap) throws PLMCommonException{
		for (Map.Entry<String, List<PLMBomSalesData>> entry : bvsMLIMap.entrySet()) {			
			if(mlisUniqueMap.get(entry.getKey()) == null){
				mlisUniqueMap.put(entry.getKey(), entry.getKey());
			}
		}
	}
	
	/**
	 * This method is used for converting List to Map which will simplify comparison of BOM Vs Sales
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private Map<String, List<PLMBomSalesData>> convertListToMapForComparison(List<PLMBomSalesData> bvsDataList) throws PLMCommonException{
		List<PLMBomSalesData> bvsList = new ArrayList<PLMBomSalesData>();
		Map<String, List<PLMBomSalesData>> bvsMLIMap = new TreeMap<String, List<PLMBomSalesData>>();
		String mliNumber = "";					
		for (PLMBomSalesData bvsData : bvsDataList) {
			mliNumber = bvsData.getMlNum();
			if(bvsMLIMap.get(mliNumber) == null){					
				bvsList = new ArrayList<PLMBomSalesData>();					
				bvsMLIMap.put(mliNumber,bvsList);	
			}				
			bvsList.add(bvsData);
		}	
		
		/*for (Map.Entry<String, List<PLMBomSalesData>> entry : bvsMLIMap.entrySet()) {
			LOG.info(entry.getKey()+" count results "+entry.getValue().size());
		}*/			
		return bvsMLIMap;		
	}
	
	
	
//	Added by Shekhar For MBOM Vs SO Report
		
	/**
	 * This method is used for Loading OMM Page
	 * 
	 * @return String
	 */
	public String loadMBomVsSalesReportPage() {
		LOG.info("Entering loadMBomVsSalesReportPage Method");
		try {
			commonMB.insertCannedRptRecordHitInfo("CMU Comparison Of MBOM vs Sales Order");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		try {
			partsForProjectList = new ArrayList<PLMBomSalesData>();
			partsCount = 0;
			alertMessage = "";
			contractNo = "";
			projectNo="";
			//ommReportData = new PLMOmmReportData();
			} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@loadOmmReportPage:", exception);
		}
		LOG.info("Exiting loadMBomVsSalesReportPage Method");
		return "mbomVsSalesReportSearch";
	}
	
	
	/**
	 * This method is used for Generating BOM Vs Sales Report for Contract with single part
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String getMBomVsSalesReport() throws PWiException {
		LOG.info("Entering getMBomVsSalesReport Method");
		String fwdflag = "mbomVsSalesReportSearch";
		List<String> nonMlMplList;
		alertMsg = validateMBVSComparisonInput();
		
		if (PLMUtils.isEmpty(alertMsg)) {			
			try {
				nonMlMplList = new ArrayList<String>();
				partsForProjectList = new ArrayList<PLMBomSalesData>();
				partsForProjectList1 = plmDocGenService.getPartsForProject(projectNo);
				partsCount = partsForProjectList1.size();
				if(partsCount == 0) {
					alertMessage = PLMConstants.MBVS_NO_PART_DATA_ALERT_MSG;
					return fwdflag;
				}
				contractNo=partsForProjectList1.get(0).getContractNo();
				for(PLMBomSalesData partForProj : partsForProjectList1){
					
					if(!partForProj.getPartName().contains("ML-") && !partForProj.getPartName().contains("MPL-")){
						
						nonMlMplList.add(partForProj.getPartName());
						partsForProjectList.add(partForProj);
					}
				}
				
				partsForProjectList1 = plmDocGenService.getPartsForNonMlMpl(nonMlMplList);
				for(PLMBomSalesData partForProj1 : partsForProjectList1){
					partsForProjectList.add(partForProj1);
				}
				partsCount = partsForProjectList.size();
				LOG.info("Parts for Project : "+partsCount);
				
				if(partsCount == 0) {
					alertMessage = PLMConstants.MBVS_NO_PART_DATA_ALERT_MSG;
				}else if(partsCount == 1){
					
					partNumber = partsForProjectList.get(0).getPartName();
					LOG.info("Required data"+contractNo);
					alertMessage = PLMConstants.MBVS_MAIL_ALERT_MSG;
					taskExecutor.execute(new MMailThread());
				}else if(partsCount > 1){
					
					partNumber = partsForProjectList.get(0).getPartName();
					mltplPartsForProjectMsg = 
						PLMConstants.MBVS_MULTIPLE_PARTS_FOR_PROJECT.replace("?",projectNo);
					////alertMessage = PLMConstants.BVS_MULTIPLE_PARTS_FOR_CONTRACT;					
				}
			 } catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getOmmReport: ", exception);
				fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,fwdflag,"BOM Vs Sales Report");
			}
		}
		LOG.info("Exiting getMBomVsSalesReport Method");
		return fwdflag;
	}
	
	/**
	 * @return the partsForProjectList1
	 */
	public List<PLMBomSalesData> getPartsForProjectList1() {
		return partsForProjectList1;
	}
	/**
	 * @param partsForProjectList1 the partsForProjectList1 to set
	 */
	public void setPartsForProjectList1(List<PLMBomSalesData> partsForProjectList1) {
		this.partsForProjectList1 = partsForProjectList1;
	}

	/**
	 * This method is used for Generating MBOM Vs Sales Report for Part
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String getMBomVsSalesReportForPart() throws PWiException{
		LOG.info("Entering getMBomVsSalesReportForPart Method");
		String fwdflag = "mbomVsSalesReportSearch";
			partsForProjectList = new ArrayList<PLMBomSalesData>();
			partsCount = 0;	
			alertMessage = PLMConstants.MBVS_MAIL_ALERT_MSG;
			LOG.info("Part Number = "+partNumber);
			taskExecutor.execute(new MMailThread());
		LOG.info("Exiting getMBomVsSalesReportForPart Method");
		return fwdflag;
	}
	
	/**
	 * This method is used for Validating Comparison User Input
	 * 
	 * @return String
	 */
	public String validateMBVSComparisonInput() {
		LOG.info("Entering validateMBVSComparisonInput Method");
		LOG.info("Entered Project No : " + getProjectNo());
		String alertMsg2 = "";
		if(PLMUtils.isEmpty(getProjectNo())){
			alertMessage = PLMConstants.MBVS_COMPARISON_SEARCH_CRITERIA;
			LOG.info(alertMsg2);
		} else if(!PLMUtils.checkForSpecialChars(getProjectNo())){
			alertMessage = PLMConstants.MBVS_COMPARISON_NO_SPLCHAR_CRITERIA;
			LOG.info(alertMsg2);
		}
		LOG.info("Exiting validateMBVSComparisonInput Method");
		return alertMessage;
	}
	
	/**
	 * Background Process Thread
	 */
	private class MMailThread implements Runnable {
		public MMailThread(){}
		public void run() {
			sendMBVSRptEmail();
		}
	}
	
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return void
	 * @throws PLMCommonException 
	 */
	public void sendMBVSRptEmail() {
		LOG.info("Entering sendMBVSComparisonReportThroughMail Method");		
		Map<String, Object> varMap = new HashMap<String, Object>();
		boolean fileExist=false;
		String contractLcl=contractNo;
		String projectNoLcl =projectNo;
		String partNumberLcl =partNumber;
		try {
			varMap.put("projectNo", projectNoLcl);
			varMap.put("contractNo", contractLcl);
			
			List<PLMBomSalesData> plmMBomDataResultList = plmDocGenService.getMBOMDataForContract(contractLcl, partNumberLcl);
			
			List<PLMBomSalesData> plmMSalesDataResultList = plmDocGenService.getMSalesDataForContract(contractLcl);
			
			if(!PLMUtils.isEmptyList(plmMBomDataResultList) || !PLMUtils.isEmptyList(plmMSalesDataResultList)){
				prepareMBOMVsSalesDataForComoparison(plmMBomDataResultList, plmMSalesDataResultList, varMap);
				prepareMExcelWorkBook(varMap);
				compareMBOMVsSalesData(varMap);
				writeDataToExcelFile(varMap);
				PLMUtils.generateZipFile((List<String>)varMap.get("filePathXlsLst"), (String)varMap.get("filePathZip"), false);		
				sendMMail(varMap);
				fileExist=true;
			}else{
				sendNoMBOMSalesDataMail(varMap);
			}
		} catch (IOException ioexception) {	
			LOG.log(Level.ERROR, "Exception@sendBVSComparisonReportThroughMail: ", ioexception);
			PLMUtils.checkExceptionAndMail(ioexception.getMessage(), PLMConstants.BVS_MAIL_FROM, (String)varMap.get("to"), (String)varMap.get("subject"), (String)varMap.get("toAddressee"), PLMConstants.BVS_MAIL_SIGNATURE + PLMConstants.BVS_MAIL_FOOTER);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendBVSComparisonReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(), PLMConstants.BVS_MAIL_FROM, (String)varMap.get("to"), (String)varMap.get("subject"), (String)varMap.get("toAddressee"), PLMConstants.BVS_MAIL_SIGNATURE + PLMConstants.BVS_MAIL_FOOTER);
		}
		finally {
			if(fileExist){
			PLMUtils.deleteFiles((String)varMap.get("filePathXls"),(String)varMap.get("filePathZip"));
			}
		}
		LOG.info("Exiting sendBVSComparisonReportThroughMail Method");
	}
	
	/**
	 * This method is used for preparing data ready for Comparison with BOM Vs Sales
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void prepareMBOMVsSalesDataForComoparison(List<PLMBomSalesData> plmMBomDataResultList, List<PLMBomSalesData> plmMSalesDataResultList, Map<String, Object> varMap) throws PLMCommonException{
		LOG.info("Entering prepareMBOMVsSalesDataForComoparison Method");
		List<PLMBomSalesData> emptyListData = new ArrayList<PLMBomSalesData>();
//		Map<String, List<PLMBomSalesData>> mbomMLIListMap = new TreeMap<String, List<PLMBomSalesData>>();
//		Map<String, List<PLMBomSalesData>> msalesMLIListMap = new TreeMap<String, List<PLMBomSalesData>>();
		Map<String, String> mmlisUniqueMap = new TreeMap<String, String>();
		
		LOG.info("Converting MBOM Data for comparison");
		Map<String, List<PLMBomSalesData>> mbomMLIListMap = convertListToMapForComparison(plmMBomDataResultList);
		plmMBomDataResultList.clear();
		
		LOG.info("Converting Sales Data for comparison");
		Map<String, List<PLMBomSalesData>> msalesMLIListMap = convertMListToMapForComparison(plmMSalesDataResultList);
		plmMSalesDataResultList.clear();
		
		getMUniqueMlis(mbomMLIListMap, mmlisUniqueMap);
		getMUniqueMlis(msalesMLIListMap, mmlisUniqueMap);
		
		LOG.info("MBOM Map size before adding missing MLI "+mbomMLIListMap.size());
		LOG.info("Sales Map size before adding missing MLI "+mbomMLIListMap.size());
		for (Map.Entry<String, String> entry : mmlisUniqueMap.entrySet()) {
			//LOG.info("MLI "+entry.getKey());
			if(msalesMLIListMap.get(entry.getKey()) == null){
				msalesMLIListMap.put(entry.getKey(), emptyListData);
			}
			if(mbomMLIListMap.get(entry.getKey()) == null){
				mbomMLIListMap.put(entry.getKey(), emptyListData);
			}
		}
		LOG.info("MBOM Map size after adding missing MLI "+mbomMLIListMap.size());
		LOG.info("Sales Map size after adding missing MLI "+msalesMLIListMap.size());
		
		if(!PLMUtils.isEmptyMap(mbomMLIListMap)){
			List<String> list = new ArrayList<String>(mbomMLIListMap.keySet());
			LOG.info("First Key in mbomMLIListMap------>"+list.get(0));
			list.clear();
		}
		
		if(!PLMUtils.isEmptyMap(msalesMLIListMap)){
			List<String> list = new ArrayList<String>(msalesMLIListMap.keySet());
			LOG.info("First Key in msalesMLIListMap------>"+list.get(0));
			list.clear();
		}
		
		varMap.put("mbomMLIListMap",mbomMLIListMap);
		varMap.put("msalesMLIListMap",msalesMLIListMap);
	}
	
	/**
	 * This method is used for creating Excel which will have BOM Vs Sales Data
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void prepareMExcelWorkBook(Map<String, Object> varMap) throws IOException{
		LOG.info("Inside prepareMExcel");
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		FileInputStream file = null;
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String folderPath = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = folderPath + resourceBundle.getString("MBOM_VS_SALES_REPORT_NAME") + varMap.get("projectNo") + "_" + uniqTime + ".xls";
		String filePathZip = folderPath + resourceBundle.getString("MBOM_VS_SALES_REPORT_NAME") + varMap.get("projectNo") + "_" + uniqTime + ".zip";
		List<String> filePathXlsLst = new ArrayList<String>();
		filePathXlsLst.add(filePathXls);
		
		String outptFileTemplate =  folderPath + resourceBundle.getString("MBOM_VS_SALES_TEMPLATE_NAME");
		LOG.info("After Template line");
		
		file = new FileInputStream(new File(outptFileTemplate));
		LOG.info("file created"+file.toString());
		workbook = new HSSFWorkbook(file);
		LOG.info("workbook created"+workbook);
		sheet = workbook.getSheetAt(0);
		LOG.info("sheet created====");

		mbomCellStyle = workbook.createCellStyle();
		mbomCellStyle.setFillForegroundColor(HSSFColor.RED.index);
		mbomCellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND); 
		
		msalesCellStyle = workbook.createCellStyle();			
		msalesCellStyle.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
		msalesCellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);  
		LOG.info("cellstyle done");
		varMap.put("workbook", workbook);
		varMap.put("sheet", sheet);	
		varMap.put("folderPath", folderPath);
		varMap.put("filePathXls", filePathXls);
		varMap.put("filePathZip", filePathZip);
		varMap.put("filePathXlsLst", filePathXlsLst);
		
		LOG.info("Last line of prepareMExcel");
	}
	
	/**
	 * This method is used for Comparing MBOM Vs Sales Data
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void compareMBOMVsSalesData(Map<String, Object> varMap) throws PLMCommonException{
		
			Map<String, List<PLMBomSalesData>> mbomMLIListMap = (TreeMap<String, List<PLMBomSalesData>>) varMap.get("mbomMLIListMap");
			Map<String, List<PLMBomSalesData>> msalesMLIListMap = (TreeMap<String, List<PLMBomSalesData>>) varMap.get("msalesMLIListMap");
			List<PLMBomSalesData> msalesListData = new ArrayList<PLMBomSalesData>();
			LOG.info("msalesListData ----->"+msalesListData);
			String mbomMliPartStr;
			String msalesMliPartStr;
			boolean isCompared = false;
			
			int rowCount1 = 1;
			int count = 0;
			HSSFRow row = null;
			HSSFSheet sheet = null;
			
			sheet = (HSSFSheet) varMap.get("sheet");
			
			for (Map.Entry<String, List<PLMBomSalesData>> entry : mbomMLIListMap.entrySet()) {
				 
				//LOG.info(entry.getKey()+" count results "+entry.getValue().size());
				if(msalesMLIListMap.get(entry.getKey()) != null){
					msalesListData = msalesMLIListMap.get(entry.getKey());
				}else{
					msalesListData = new ArrayList<PLMBomSalesData>();
				}
				for (PLMBomSalesData mbOData : mbomMLIListMap.get(entry.getKey())) {					
					
					mbomMliPartStr = mbOData.getMlNum()+mbOData.getPartName();
					for (PLMBomSalesData msalesData : msalesListData) {
						msalesMliPartStr = msalesData.getMlNum()+msalesData.getPartName();								
						if(mbomMliPartStr.equals(msalesMliPartStr)){			
							////LOG.info(bOData.getMlno()+"  "+bOData.getPartName()+" sales "+salesData.getMlno()+"  "+salesData.getPartName()+"  "+salesData.getDescription());
							mbOData.setCompared(true);						
							msalesData.setCompared(true);
							
							
							row = sheet.createRow(rowCount1);
							writeMBOMData(row, mbOData);							
							writeMSalesData(row, msalesData);
							rowCount1++;
						}	
						count++;
					}
					if(!mbOData.isCompared()){			
						////LOG.info(bOData.getMlno()+"  "+bOData.getPartName());
						
						row = sheet.createRow(rowCount1);
						writeMBOMData(row, mbOData);
						writeEmptyMSales(row);
						rowCount1++;
					}				
					
				}			
				//LOG.info(" size of sales "+salesListData.size()+" "+comparedSalesIndexList.size());
				for (PLMBomSalesData msalesData : msalesListData) {					
					if(!msalesData.isCompared()){
						////LOG.info(" ----------- "+" Unmatched "+salesData.getMlno()+"  "+salesData.getPartName()+"  "+salesData.getDescription());
						
						row = sheet.createRow(rowCount1);
						writeMSalesData(row, msalesData);	
						writeEmptyMBOM(row);
						rowCount1++;
					}
				}
			}
			LOG.info(count);
			isCompared = true;
			varMap.put("isCompared", isCompared);
		
	}
	
	/**
	 * This method is used for adding MBOM data to Excel
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void writeMBOMData(HSSFRow row, PLMBomSalesData mbOData) throws PLMCommonException{
		row.createCell(0).setCellValue(mbOData.getBomLevel());
		row.createCell(1).setCellValue(mbOData.getMlNum());
		row.createCell(2).setCellValue(mbOData.getPartName());
		row.createCell(3).setCellValue(mbOData.getBomRevision());
		row.createCell(4).setCellValue(mbOData.getDescription());
		//row.createCell(5).setCellValue(mbOData.getState());
		row.createCell(5).setCellValue(mbOData.getQuantity());
		row.createCell(6).setCellValue(mbOData.getUnitOfMeasure());
		
		
		DateFormat dateFormat1 = new SimpleDateFormat("MM/dd/yyyy");
		if(mbOData.getPartModDate()!=null){
			row.createCell(7).setCellValue(dateFormat1.format(mbOData.getPartModDate()));
		}else{
			row.createCell(7).setCellValue("");
		}
		
		//row.createCell(7).setCellValue(mbOData.getPartModDate());	
	}
	
	/**
	 * This method is used for adding empty MBOM data to Excel
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void writeEmptyMBOM(HSSFRow row) throws PLMCommonException{
		
		row.createCell(0).setCellStyle(mbomCellStyle);
		row.createCell(1).setCellStyle(mbomCellStyle);
		row.createCell(2).setCellStyle(mbomCellStyle);
		row.createCell(3).setCellStyle(mbomCellStyle);
		row.createCell(4).setCellStyle(mbomCellStyle);
		row.createCell(5).setCellStyle(mbomCellStyle);
		row.createCell(6).setCellStyle(mbomCellStyle);
		row.createCell(7).setCellStyle(mbomCellStyle);
		//row.createCell(8).setCellStyle(mbomCellStyle);
	}
	
	/**
	 * This method is used for adding Sales data to Excel
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void writeMSalesData(HSSFRow row, PLMBomSalesData msalesData) throws PLMCommonException{
		
		DateFormat dateFormat2 = new SimpleDateFormat("MM/dd/yyyy");
		if(msalesData.getLmDate()!=null){
			row.createCell(8).setCellValue(dateFormat2.format(msalesData.getLmDate()));
		}else{
			row.createCell(8).setCellValue("");
		}
		
		//row.createCell(9).setCellValue(msalesData.getLmDate());
		row.createCell(9).setCellValue(msalesData.getSalesID());
		row.createCell(10).setCellValue(msalesData.getUnitSerialNumber());
		row.createCell(11).setCellValue(msalesData.getMlNum());
		row.createCell(12).setCellValue(msalesData.getPartName());
		row.createCell(13).setCellValue(msalesData.getDescription());
		row.createCell(14).setCellValue(msalesData.getErpLineNumber());
		row.createCell(15).setCellValue(msalesData.getQuantity());
		row.createCell(16).setCellValue(msalesData.getUnitOfMeasure());
		row.createCell(17).setCellValue(msalesData.getRequestedShipDate());
		row.createCell(18).setCellValue(msalesData.getState());
		row.createCell(19).setCellValue(msalesData.getLineStatus());
		row.createCell(20).setCellValue(msalesData.getInternalComments());
		row.createCell(21).setCellValue(msalesData.getExternalComments());	
	}
	
	/**
	 * This method is used for adding empty Sales data to Excel
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void writeEmptyMSales(HSSFRow row) throws PLMCommonException{		
		row.createCell(9).setCellStyle(msalesCellStyle);
		row.createCell(10).setCellStyle(msalesCellStyle);
		row.createCell(11).setCellStyle(msalesCellStyle);
		row.createCell(12).setCellStyle(msalesCellStyle);
		row.createCell(13).setCellStyle(msalesCellStyle);
		row.createCell(14).setCellStyle(msalesCellStyle);
		row.createCell(15).setCellStyle(msalesCellStyle);
		row.createCell(16).setCellStyle(msalesCellStyle);
		row.createCell(17).setCellStyle(msalesCellStyle);
		row.createCell(18).setCellStyle(msalesCellStyle);
		row.createCell(19).setCellStyle(msalesCellStyle);
		row.createCell(20).setCellStyle(msalesCellStyle);
		row.createCell(21).setCellStyle(msalesCellStyle);
		//row.createCell(22).setCellStyle(msalesCellStyle);
	}	
	
	
	/**
	 * This method is used for Sendng Mail
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void sendMMail(Map<String, Object> varMap) throws PLMCommonException{
		LOG.info("Entering sendMail Method");
		String from = PLMConstants.BVS_MAIL_FROM;
		
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		
		toAddressee = "Dear " + toAddressee + ", \n\n";
		//String subject = PLMConstants.MBVS_MAIL_SUBJECT + varMap.get("contractNo");
		
		String subject = PLMConstants.MBVS_MAIL_SUBJECT + varMap.get("projectNo");
		StringBuffer mailBody = new StringBuffer().append(toAddressee);
		boolean isCompared = (Boolean) varMap.get("isCompared");
		
		varMap.put("to", to);
		varMap.put("toAddressee", toAddressee);
		varMap.put("subject", subject);
		
		if(!isCompared){
			mailBody.append(PLMConstants.MBVS_MAIL_CONTENT_NO_RECORD);
		} else {
			mailBody.append(PLMConstants.MBVS_MAIL_CONTENT);
		}
		//mailBody.append(varMap.get("contractNo"))
		mailBody.append(varMap.get("projectNo"))
		.append(".")
		.append(PLMConstants.MBVS_MAIL_SIGNATURE)
		.append(PLMConstants.MBVS_MAIL_FOOTER);
		PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), (String)varMap.get("filePathZip"));
		
		LOG.info("Exiting sendMail Method");
	}
	
	/**
	 * This method is used for Sending No Mail Mail
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void sendNoMBOMSalesDataMail(Map<String, Object> varMap) throws PLMCommonException{
		LOG.info("Entering sendNoMBOMSalesDataMail Method");
		String from = PLMConstants.BVS_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.MBVS_MAIL_SUBJECT + varMap.get("projectNo");
		StringBuffer mailBody = new StringBuffer().append(toAddressee);
		
		varMap.put("to", to);
		varMap.put("toAddressee", toAddressee);
		varMap.put("subject", subject);
		
		mailBody.append(PLMConstants.MBVS_MAIL_CONTENT_NO_RECORD);
		mailBody.append(varMap.get("projectNo"))
		.append(".")
		.append(PLMConstants.BVS_MAIL_SIGNATURE)
		.append(PLMConstants.BVS_MAIL_FOOTER);
		PLMUtils.sendMail(from, to, subject, mailBody.toString());
		
		LOG.info("Exiting sendNoMBOMSalesDataMail Method");
	}
	
	/**
	 * This method is used for converting List to Map which will simplify comparison of MBOM Vs Sales
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private Map<String, List<PLMBomSalesData>> convertMListToMapForComparison(List<PLMBomSalesData> mbvsDataList) throws PLMCommonException{
		List<PLMBomSalesData> mbvsList = new ArrayList<PLMBomSalesData>();
		Map<String, List<PLMBomSalesData>> mbvsMLIMap = new TreeMap<String, List<PLMBomSalesData>>();
		String mliNumber = "";					
		for (PLMBomSalesData mbvsData : mbvsDataList) {
			mliNumber = mbvsData.getMlNum();
			if(mbvsMLIMap.get(mliNumber) == null){					
				mbvsList = new ArrayList<PLMBomSalesData>();					
				mbvsMLIMap.put(mliNumber,mbvsList);	
			}				
			mbvsList.add(mbvsData);
		}	
		
		/*for (Map.Entry<String, List<PLMBomSalesData>> entry : bvsMLIMap.entrySet()) {
			LOG.info(entry.getKey()+" count results "+entry.getValue().size());
		}*/			
		return mbvsMLIMap;		
	}
	
	/**
	 * This method is used for removing duplicate MLI's from MBOM and Sales
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void getMUniqueMlis(Map<String, List<PLMBomSalesData>> bvsMLIMap, Map<String, String> mlisUniqueMap) throws PLMCommonException{
		for (Map.Entry<String, List<PLMBomSalesData>> entry : bvsMLIMap.entrySet()) {			
			if(mlisUniqueMap.get(entry.getKey()) == null){
				mlisUniqueMap.put(entry.getKey(), entry.getKey());
			}
		}
	}
	
	
	/**
	 * This method is used for Resetting the Data
	 * 
	 * @return void
	 */
	public void resetMData() {
		if (projectnumber!= null) {
			projectnumber = "";			
		}
		partsForProjectList = new ArrayList<PLMBomSalesData>();
		partsCount = 0;
		alertMessage = "";
		projectNo = "";
	}

	
//	(End Of) Added by Shekhar For MBOM Vs SO Report
	
	/**
	 * This method is used for Resetting the Data
	 * 
	 * @return void
	 */
	public void resetData() {
		if (contractnumber!= null) {
			contractnumber = "";			
		}
		partsForContractList = new ArrayList<PLMBomSalesData>();
		partsCount = 0;
		alertMessage = "";
		contractNo = "";
		levelList = new ArrayList<SelectItem>();
		level = "";
	}
	
	/**
	 * This method is used for Loading requirement,CEI,MLIs
	 * 
	 * @return String
	 * 
	 */
		public String loadRequirementList()throws PLMCommonException{
			LOG.info("PLMDocGenFmiMB class loadRequirementList method");
			
			String fwdFlag="fmiManangeTxt";
			templateData = new PLMFmiTemplateData();
			errorDataList = new ArrayList<PLMFmiTemplateData>();
			alertMessage = "";
			selCeiName ="";
			dropdownValMap = new HashMap<String, List<SelectItem>>();
			selRequirment =new ArrayList<String>();
			selCei = new ArrayList<String>();
			ceiFlag=false;
			mliFlag=false;
			ceiNameList = new ArrayList<SelectItem>();
			ceiNameList.add(new SelectItem("-1"," "));
			mliNameList = new ArrayList<SelectItem>();
			mliNameList.add(new SelectItem("-1"," "));
			reqCeiNamesList =new ArrayList<PLMFmiTemplateData>();
			selMliName ="";
			selMliNameList = new ArrayList<SelectItem>();
			ceiBulkData=null;
			selectRequirementList= new ArrayList<SelectItem>();
			selCeiNameList = new ArrayList<SelectItem>();
			mliBulkData=null;
			bulkCeiMliList = new ArrayList<PLMFmiTemplateData>();
			selectCeiList= new ArrayList<SelectItem>();
			ceiVal = null;
			mliVal = null;
			rowIndexCeiLink = new HtmlAjaxCommandButton();
			rowIndexMliLink = new HtmlAjaxCommandButton();
			rowIndexReqLink = new HtmlAjaxCommandButton();
			bulkCeiCount = 0;
			bulkMliCount = 0;
			bulkReqCount =0;
			bulkReqList = new ArrayList<PLMFmiTemplateData>();
			
			try {
				commonMB.insertCannedRptRecordHitInfo("Manage FMI Text");
			} catch (PLMCommonException ex) {
				LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
			}
			
			try{
			dropdownValMap = plmDocGenService.getRequirementList();
			requirementList = ((List<SelectItem>) dropdownValMap.get("requirement"));
			
			selCeiNameList = plmDocGenService.getCeiNameList();
			  if(selCeiNameList.size() > 0){
			    LOG.info("Retreiving Drop down List of CEI Names >>"+selCeiNameList.size());
			  }
			  
			 selMliNameList = plmDocGenService.getMliNameList();
			  if(selMliNameList.size() > 0){
				LOG.info("Retreiving Drop down List of MLI Names >>"+selMliNameList.size());
			  }
			  
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@loadFMIMangeTxt: ", exception);
			} 
		
			return fwdFlag;
			
		}
		/**
		 * This method is used for retrieving CEI based on requirement 
		 * 
		 * @return String
		 * 
		 */
		//This Action  method is to update CEI Names list based on Requirment Name selection
		public void getCeiList(ActionEvent event){
			LOG.info("Entering getCeiList method");
			try{
				dropdownValMap = new HashMap<String, List<SelectItem>>();
				List<String> reqList = new ArrayList<String>();
				//tempselection =new ArrayList<String>();
				ceiNameList = new ArrayList<SelectItem>();
				selCei = new ArrayList<String>();
				mliNameList = new ArrayList<SelectItem>();
				selMli = new ArrayList<String>();
				alertMessage = "";
				if(!PLMUtils.isEmptyList(selRequirment)){
					reqList.addAll(selRequirment);
					dropdownValMap = plmDocGenService.fetchCeiNameList(reqList);
					ceiNameList = ((List<SelectItem>) dropdownValMap.get("ceiNameList"));
					
					LOG.info("Sel REq>>>>>>>>>>>>.." +selRequirment);
				}
			}catch (Exception e) {
				e.printStackTrace();
			}	
		
		}
		
		/**
		 * This method is used for retrieving MLI based on requirement and CEI Name 
		 * 
		 * @return String
		 * 
		 */
		//This Action  method is to update MLI Names list based on cei Name selection
		public void getMliList(ActionEvent event){
			LOG.info("Entering getMliList method");
			try{
				dropdownValMap = new HashMap<String, List<SelectItem>>();
				List<String> reqList = new ArrayList<String>();
				List<String> ceiList = new ArrayList<String>();
				tempselection =new ArrayList<String>();
				mliNameList = new ArrayList<SelectItem>();
				selMli = new ArrayList<String>();
				alertMessage = "";
				if(!PLMUtils.isEmptyList(selRequirment) && !PLMUtils.isEmptyList(selCei)){
					reqList.addAll(selRequirment);
					ceiList.addAll(selCei);
					dropdownValMap = plmDocGenService.fetchMliNameList(ceiList,reqList);
					mliNameList = ((List<SelectItem>) dropdownValMap.get("mliNameList"));
					LOG.info("Sel CEI >>>>>>>>>>>>.." +ceiList);
				}	
			}catch (Exception e) {
				e.printStackTrace();
			}	
			
		}
		
		
		
		/**
		 * addRequiremnt
		 */
		public void addBulkRequiremnt(ActionEvent ea) {
			LOG.info("In addBulkRequiremnt() Method");
			bulkReqList =new ArrayList<PLMFmiTemplateData>();
			templateData = new PLMFmiTemplateData();
			try {
					bulkReqList.add(templateData);
					reqBulkData = new ListDataModel(bulkReqList);
					bulkReqCount =bulkReqList.size();
					LOG.info("bulkReqList Team List size after Adding ==> "
							+bulkReqCount);
					
			} catch (Exception exeception) {
				LOG.log(Level.ERROR,"addBulkRequiremnt exception" +exeception);
			}
			LOG.info("Exiting addBulkRequiremnt Method");
		}
		
		/**
		 * addRequiremnt
		 */
		public void addRequiremnt(ActionEvent ea) {
			LOG.info("In addRequiremnt() Method");
			templateData = new PLMFmiTemplateData();
			try {
					bulkReqList.add(templateData);
					reqBulkData = new ListDataModel(bulkReqList);
					bulkReqCount =bulkReqList.size();
					LOG.info("bulkReqList Team List size after Adding ==> "
							+bulkReqCount);
					
			} catch (Exception exeception) {
				LOG.log(Level.ERROR,"addRequiremnt exception" +exeception);
			}
			LOG.info("Exiting addRequiremnt Method");
		}
		

		/**
		 * removeRequiremnt
		 */
		public void removeRequiremnt(ActionEvent ea) {
			LOG.info("In removeRequiremnt() Method");
			try {
				int rowIndex = Integer.parseInt(rowIndexReqLink.getTitle());
				LOG.info("removing the row==> " + rowIndex);
				if (bulkReqList.size() > 1) {
					bulkReqList.remove(rowIndex);
				} 
				bulkReqCount =bulkReqList.size();
				LOG.info("bulkReqList Team List size after Removing ==> "
						+bulkReqCount);
			} catch (Exception exeception) {
				LOG.log(Level.ERROR,"removeRequiremnt exception" + exeception);
			}
			LOG.info("Exiting removeRequiremnt Method");
		}
		
		public String addBulkReqNms() throws PLMCommonException{
			LOG.info("Entering addBulkReqNms Method");
			 alertMessage="";
			 String fwdFlag="";
			 try{
			   alertMessage=plmDocGenService.uploadBulkReqData(bulkReqList,userDetails.getUserSSO()); 
						LOG.info("status>>>>>>>>>>>>>>>>>>>>>>>>>> "+alertMessage);
				dropdownValMap = plmDocGenService.getRequirementList();
				requirementList = ((List<SelectItem>) dropdownValMap.get("requirement"));
					
			 }catch (PLMCommonException exception) {
					LOG.log(Level.ERROR, "Exception@addBulkReqNms: ", exception);
			 } 
			LOG.info("Exiting addBulkReqNms Method");
			return fwdFlag;
		
		}
		/**
		 * This method is used for Adding Bulk CEI 
		 * 
		 * 
		 */		
		public void getselRequirementList(){
			LOG.info("Entering getselRequirementList method");
			reqSeqId="";
			templateData = new PLMFmiTemplateData();
			alertMessage = "";
			selCeiName ="";
			List<String> reqList=new ArrayList<String>();
			bulkCeiMliList = new ArrayList<PLMFmiTemplateData>();
			ceiBulkData=null;
			ceiVal = null;
			mliVal = null;
			rowIndexCeiLink = new HtmlAjaxCommandButton();
			rowIndexMliLink = new HtmlAjaxCommandButton();
			try{
				if(!PLMUtils.isEmptyList(selRequirment)){
					reqList.addAll(selRequirment);
					selectRequirementList =plmDocGenService.getselectRequirementNm(reqList);
					templateData.setSelRequirment(selectRequirementList);
					templateData.setSelCeiNameList(selCeiNameList);
					bulkCeiMliList.add(templateData);
					ceiBulkData = new ListDataModel(bulkCeiMliList);
					bulkCeiCount =bulkCeiMliList.size();
					totalSelRequireCnt = selectRequirementList.size();
					}	
			}catch (Exception e) {
				e.printStackTrace();
			}	
		
		}

		/**
		 * addCei
		 */
		public void addCei(ActionEvent ea) {
			LOG.info("In addCei() Method");
			templateData = new PLMFmiTemplateData();
			try {
				    templateData.setSelRequirment(selectRequirementList);
					templateData.setSelCeiNameList(selCeiNameList);
					bulkCeiMliList.add(templateData);
					ceiBulkData = new ListDataModel(bulkCeiMliList);
					bulkCeiCount =bulkCeiMliList.size();
					LOG.info("bulkCeiList Team List size after Adding ==> "
							+bulkCeiCount);
					
			} catch (Exception exeception) {
				LOG.log(Level.ERROR,"addCei exception" +exeception);
			}
			LOG.info("Exiting addCei Method");
		}
		
		/**
		 * removeCei
		 */
		public void removeCei(ActionEvent ea) {
			LOG.info("In removeCei() Method");
			try {
				int rowIndex = Integer.parseInt(rowIndexCeiLink.getTitle());
				LOG.info("removing the row==> " + rowIndex);
				if (bulkCeiMliList.size() > 1) {
					bulkCeiMliList.remove(rowIndex);
				} 
				bulkCeiCount =bulkCeiMliList.size();
				LOG.info("bulkCeiList Team List size after Removing ==> "
						+bulkCeiCount);
			} catch (Exception exeception) {
				LOG.log(Level.ERROR,"removeCei exception" + exeception);
			}
			LOG.info("Exiting removeCei Method");
		}
		
		/**
		 * This method is used for retrieving Requirement Data for cei pop up
		 * 
		 * @return String
		 * 
		 */
		public void getReqDescForCeiPopup(ActionEvent event)throws PLMCommonException{
			LOG.info("Entering getReqDescForCeiPopup method");
			 alertMessage = "";
			try {
				PLMFmiTemplateData tempData = (PLMFmiTemplateData)ceiVal.getRowData();
				int rowIndex = Integer.parseInt(rowIndexCeiLink.getTitle());
				LOG.info(" getReqDesc rowIndex>>>>>>>>>>>>>>"+rowIndex);
			 if(!PLMUtils.isEmpty(tempData.getSelReqName())){
				LOG.info("getSelReqName() "+tempData.getSelReqName());
				LOG.info("getting data the row==> " + rowIndex);
				tempData= plmDocGenService.getReqDesc(tempData.getSelReqName());  
				bulkCeiMliList.get(rowIndex).setReqDescTxt(tempData.getReqDescTxt());
		     	LOG.info("REQ Desc "+tempData.getReqDescTxt());
			 }
			 else{
				 bulkCeiMliList.get(rowIndex).setReqDescTxt("");
			 }
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getReqDescForCeiPopup: ", exception);
			} 
			LOG.info("Exiting getReqDescForCeiPopup method");
			}
		
		/**
		 * This method is used for retrieving Requirement Data for mli pop up
		 * 
		 * @return String
		 * 
		 */
		public void getReqDescForMliPopup(ActionEvent event)throws PLMCommonException{
			LOG.info("Entering getReqDesc method");
			 alertMessage = "";
			try {
				PLMFmiTemplateData tempData = (PLMFmiTemplateData)mliVal.getRowData();
				int rowIndex = Integer.parseInt(rowIndexMliLink.getTitle());
				LOG.info(" getReqDesc rowIndex>>>>>>>>>>>>>>"+rowIndex);
			 if(!PLMUtils.isEmpty(tempData.getSelReqName())){
				LOG.info("getSelReqName() "+tempData.getSelReqName());
				LOG.info("getting data the row==> " + rowIndex);
				tempData= plmDocGenService.getReqDesc(tempData.getSelReqName());  
				bulkCeiMliList.get(rowIndex).setReqDescTxt(tempData.getReqDescTxt());
		     	LOG.info("REQ Desc "+tempData.getReqDescTxt());
			 }
			 else{
				 bulkCeiMliList.get(rowIndex).setReqDescTxt("");
			 }
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getReqDesc: ", exception);
			} 
			LOG.info("Exiting getReqDesc method");
			}
		/**
		 * This method is used for retrieving CEI Data for cei pop up
		 * 
		 * @return String
		 * 
		 */
		public void getCeiDetailsForCeipopUp(ActionEvent event)throws PLMCommonException{
			LOG.info("Entering getCeiDetailsForCeipopUp method");
			 alertMessage = "";
			try {
				PLMFmiTemplateData tempData = (PLMFmiTemplateData)ceiVal.getRowData();
				int rowIndex = Integer.parseInt(rowIndexCeiLink.getTitle());
				LOG.info(" getCeiDetailsForCeipopUp rowIndex>>>>>>>>>>>>>>"+rowIndex);
			 if(!PLMUtils.isEmpty(tempData.getSelCeiName())){
				LOG.info("getSelCeiName() "+tempData.getSelCeiName());
				LOG.info("getting data the row==> " + rowIndex);
				tempData= plmDocGenService.getCeiDetails(tempData.getSelCeiName());  
				bulkCeiMliList.get(rowIndex).setCeiNameTxt(tempData.getCeiNameTxt());
				bulkCeiMliList.get(rowIndex).setCeiDescTxt(tempData.getCeiDescTxt());
				bulkCeiMliList.get(rowIndex).setDisplayFlag(true);
		     	LOG.info("CEI NAME "+tempData.getCeiNameTxt());
		        LOG.info("CEI DESC "+tempData.getCeiDescTxt());
			 }
			 else{
				 bulkCeiMliList.get(rowIndex).setCeiNameTxt("");
				 bulkCeiMliList.get(rowIndex).setCeiDescTxt("");
				 bulkCeiMliList.get(rowIndex).setDisplayFlag(false);
			 }
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getCeiDetailsForCeipopUp: ", exception);
			} 
			LOG.info("Exiting getCeiDetailsForCeipopUp method");
			}
		
		/**
		 * This method is used for retrieving CEI Data for Mli pop up
		 * 
		 * @return String
		 * 
		 */
		public void getCeiDetailsForMlipopUp(ActionEvent event)throws PLMCommonException{
			LOG.info("Entering getCeiDetailsForMlipopUp method");
			 alertMessage = "";
			try {
				PLMFmiTemplateData tempData = (PLMFmiTemplateData)mliVal.getRowData();
				int rowIndex = Integer.parseInt(rowIndexMliLink.getTitle());
				LOG.info(" getCeiDetailsForMlipopUp rowIndex>>>>>>>>>>>>>>"+rowIndex);
			 if(!PLMUtils.isEmpty(tempData.getSelCeiName())){
				LOG.info("getSelCeiName() "+tempData.getSelCeiName());
				LOG.info("getting data the row==> " + rowIndex);
				tempData= plmDocGenService.getCeiDetails(tempData.getSelCeiName());  
				bulkCeiMliList.get(rowIndex).setCeiNameTxt(tempData.getCeiNameTxt());
				bulkCeiMliList.get(rowIndex).setCeiDescTxt(tempData.getCeiDescTxt());
				bulkCeiMliList.get(rowIndex).setDisplayFlag(true);
		     	LOG.info("CEI NAME "+tempData.getCeiNameTxt());
		        LOG.info("CEI DESC "+tempData.getCeiDescTxt());
			 }
			 else{
				 bulkCeiMliList.get(rowIndex).setCeiNameTxt("");
				 bulkCeiMliList.get(rowIndex).setCeiDescTxt("");
				 bulkCeiMliList.get(rowIndex).setDisplayFlag(false);
			 }
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getCeiDetailsForMlipopUp: ", exception);
			} 
			LOG.info("Exiting getCeiDetailsForMlipopUp method");
			}
		
		
		/**
		 * This method is used for Inserting Bulk Load CEI Name 
		 * 
		 * @return String
		 * 
		 */
		public String addBulkCeiNames()throws PLMCommonException{
			LOG.info("Entering addBulkCeiNames method");
			 alertMessage = "";
			 String fwdFlag="";
			try {
			 if(!PLMUtils.isEmptyList(bulkCeiMliList)){
				  alertMessage= plmDocGenService.addBulkCEIData(bulkCeiMliList,userDetails.getUserSSO());  
				  dropdownValMap = plmDocGenService.fetchCeiNameList(selRequirment);
				  ceiNameList = ((List<SelectItem>) dropdownValMap.get("ceiNameList"));
		     	  LOG.info("status of saving CEI Bulk load Data "+alertMessage);
			  }
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@addBulkCeiNames: ", exception);
			} 
			LOG.info("Exiting addBulkCeiNames method");
			return fwdFlag;
			}
		
		/**
		 * This method is used for Adding Bulk Load CEI Name 
		 * 
		 * 
		 */
		public void getReqCeiNameList()throws PLMCommonException{
			LOG.info("Entering getReqCeiNameList method");
			 fmiId="";
			 templateData = new PLMFmiTemplateData();
			 alertMessage = "";
			 selMliName ="";
			 selectCeiList = new ArrayList<SelectItem>();
			 mliBulkData=null;
			 bulkCeiMliList = new ArrayList<PLMFmiTemplateData>();
			 ceiVal = null;
			 mliVal = null;
			 rowIndexCeiLink = new HtmlAjaxCommandButton();
			 rowIndexMliLink = new HtmlAjaxCommandButton();
			 try {
				if(selRequirment.size()!=0 && selCei.size()!=0){
					selectRequirementList =plmDocGenService.getselectRequirementNm(selRequirment);
					selectCeiList = plmDocGenService.getReqCeiNameList(selCei); 
				}
				if (!PLMUtils.isEmptyList(selectCeiList)) {
					totalSelRequireCeiCnt = selectCeiList.size();
					LOG.info("total Selected Requirement Cei Count>>>>.. "+totalSelRequireCeiCnt);
				} 
				templateData.setSelRequirment(selectRequirementList);
				templateData.setSelCeiNameList(selectCeiList);
				templateData.setSelMliNameList(selMliNameList);
				bulkCeiMliList.add(templateData);
				mliBulkData = new ListDataModel(bulkCeiMliList);
				bulkMliCount=bulkCeiMliList.size();
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getReqCeiNameList: ", exception);
				
			} 
			LOG.info("Exiting getReqCeiNameList method");
		}
		/**
		 * addMli
		 */
		public void addMli(ActionEvent ea) {
			LOG.info("In addMli() Method");
			templateData = new PLMFmiTemplateData();
			try {
				templateData.setSelRequirment(selectRequirementList);
				templateData.setSelCeiNameList(selectCeiList);
				templateData.setSelMliNameList(selMliNameList);
				bulkCeiMliList.add(templateData);
				mliBulkData = new ListDataModel(bulkCeiMliList);
				bulkMliCount=bulkCeiMliList.size();
				LOG.info("bulkMliList Team List size after Adding ==> "
						+ bulkMliCount);
			} catch (Exception exeception) {
				LOG.log(Level.ERROR,"addMli exception" +exeception);
			}
			LOG.info("Exiting addMli Method");
		}
		
		/**
		 * removeMli
		 */
		public void removeMli(ActionEvent ea) {
			LOG.info("In removeMli() Method");
			try {
				int rowIndex = Integer.parseInt(rowIndexMliLink.getTitle());
				LOG.info("Removing the row==> " + rowIndex);
				if (bulkCeiMliList.size() > 1) {
					bulkCeiMliList.remove(rowIndex);
				} 
				bulkMliCount=bulkCeiMliList.size();
				LOG.info("bulkMliList Team List size after Removing ==> "
						+ bulkMliCount);
	
			} catch (Exception exeception) {
				LOG.log(Level.ERROR,"removeCei exception" + exeception);
			}
			LOG.info("Exiting removeMli Method");
		}
		/**
		 * This method is used for retrieving MLI data 
		 * 
		 * 
		 */
		public void getMliDetails(ActionEvent event)throws PLMCommonException{
			LOG.info("Entering getMliDetails method");
			 alertMessage = "";
			try {
				PLMFmiTemplateData tempData = (PLMFmiTemplateData)mliVal.getRowData();
				int rowIndex = Integer.parseInt(rowIndexMliLink.getTitle());
				LOG.info("getMliDetails rowIndex>>>>>>>>>>>>>>"+rowIndex);
			 if(!PLMUtils.isEmpty(tempData.getSelMliName())){
				LOG.info("selMliName"+tempData.getSelMliName());
				tempData= plmDocGenService.getMliDetails(tempData.getSelMliName());     
				bulkCeiMliList.get(rowIndex).setMliNameTxt(tempData.getMliNameTxt());
				bulkCeiMliList.get(rowIndex).setMliDescTxt(tempData.getMliDescTxt());
				bulkCeiMliList.get(rowIndex).setMliNotesTxt(tempData.getMliNotesTxt());
				bulkCeiMliList.get(rowIndex).setDisplayMliFlg(true);
				LOG.info("MLI NAME "+tempData.getMliNameTxt());
				LOG.info("MLI DESC "+tempData.getMliDescTxt());
				LOG.info("MLI Notes "+tempData.getMliNotesTxt());
				}
			 else{
				bulkCeiMliList.get(rowIndex).setMliNameTxt("");
				bulkCeiMliList.get(rowIndex).setMliDescTxt("");
				bulkCeiMliList.get(rowIndex).setMliNotesTxt("");
				bulkCeiMliList.get(rowIndex).setDisplayMliFlg(false);
			   }
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getMliDetails: ", exception);
			} 
			LOG.info("Exiting getMliDetails method");
			}
	
		

		/**
		 * This method is used for Inserting Bulk Load MLi Name 
		 * 
		 * @return String
		 * 
		 */
		public String addBulkMliNames()throws PLMCommonException{
			LOG.info("Entering addBulkMliNames method");
			 alertMessage = "";
			 String fwdFlag="";
			try {
			 if(!PLMUtils.isEmptyList(bulkCeiMliList)){
				 alertMessage= plmDocGenService.addBulkMLIData(bulkCeiMliList,userDetails.getUserSSO());  
				dropdownValMap = plmDocGenService.fetchMliNameList(selCei,selRequirment);
				mliNameList = ((List<SelectItem>) dropdownValMap.get("mliNameList"));
				
		     	LOG.info("status of saving MLI Bulk load Data "+alertMessage);
			 }
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@addBulkCeiNames: ", exception);
			} 
			LOG.info("Exiting addBulkCeiNames method");
			return fwdFlag;
			}
		
		
		public void getDropdownMliNames(ActionEvent event){
			LOG.info("Inside getDropdownMliNames() method");
			selMliNameList = new ArrayList<SelectItem>();
			try{
				selMliNameList = plmDocGenService.getMliNameList();
				  if(selMliNameList.size() > 0){
				    LOG.info("Retreiving Drop down List of MLI Names >>"+selMliNameList.size());
				 }
			}
			catch (Exception e) {
				e.printStackTrace();
			}	
		}
		
		public void getReqCeiMliNameList()throws PLMCommonException{
			LOG.info("Entering getReqCeiMliNameList method");
			 fmiId="";
			 templateData = new PLMFmiTemplateData();
			 alertMessage = "";
			 totalSelRequireCeiMliCnt = 0;
			try {
				if(selRequirment.size()!=0 && selCei.size()!=0 && selMli.size()!=0){
			reqCeiMliNamesList = plmDocGenService.getReqCeiMliNameList(selRequirment,selCei,selMli); 
			LOG.info("Sel MLI List >>>>>>>>>>>>.." +selMli);
				}
				if (!PLMUtils.isEmptyList(reqCeiMliNamesList)) {
					totalSelRequireCeiMliCnt = reqCeiMliNamesList.size();
					recordCount = PLMConstants.N_10;		
					LOG.info("total Selected Requirement Cei Mli Count>>>>.. "+totalSelRequireCeiMliCnt);
					} 
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getReqCeiMliNameList: ", exception);
				
			} 
			LOG.info("Exiting getReqCeiMliNameList method");
			
		}
		
		public String saveCei()throws PLMCommonException{
			LOG.info("Entering saveCei method");
			 alertMessage = "";
			 String fwdFlag="";
			try {
				
			alertMessage= plmDocGenService.saveCei(reqSeqId, selCeiName, templateData.getCeiNameTxt(), 
					templateData.getCeiDescTxt() ,userDetails.getUserSSO());
		
			dropdownValMap = new HashMap<String, List<SelectItem>>();
			ceiNameList = new ArrayList<SelectItem>();
			
			dropdownValMap = plmDocGenService.fetchCeiNameList(selRequirment);
			ceiNameList = ((List<SelectItem>) dropdownValMap.get("ceiNameList"));
		
				 
			} catch (PLMCommonException exception) {
				
				LOG.log(Level.ERROR, "Exception@saveCei: ", exception);
				
			} 
			LOG.info("Exiting saveCei method");
			return fwdFlag;
		}
		
		
		public void saveMli()throws PLMCommonException{
			LOG.info("Entering saveMli method");
			 alertMessage = "";
			try {
				LOG.info("assinged>>>>>"+reqId);
				
			alertMessage= plmDocGenService.saveMli(fmiId,selMliName,templateData.getMliNameTxt(),
					templateData.getMliDescTxt(), templateData.getMliNotesTxt(),userDetails.getUserSSO());
			
			dropdownValMap = new HashMap<String, List<SelectItem>>();
			mliNameList = new ArrayList<SelectItem>();
			dropdownValMap = plmDocGenService.fetchMliNameList(selCei,selRequirment);
			mliNameList = ((List<SelectItem>) dropdownValMap.get("mliNameList"));
		
				
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@saveMli: ", exception);
				
			} 
			LOG.info("Exiting saveMli method");
			
		}
		
	
		/**
		 * This method is used to download an Excel File
		 * 
		 *
		 */
		public void downloadExcel() throws PLMCommonException {
			LOG.info("Entering downloadExcel Method");
			String reportName = "Fmi Manage Text";
			try {
				
				if(selRequirment.size()!=0 && selCei.size()!=0 && selMli.size()!=0){
					reqCeiMliNamesList = plmDocGenService.getReqCeiMliNameList(selRequirment,selCei,selMli); 
					}
				
				if (reqCeiMliNamesList!=null && reqCeiMliNamesList.size() > 0) {
					generateFMIManageTxt(reqCeiMliNamesList,reportName);
				}
			} catch (Exception exception) {
				LOG.log(Level.ERROR, "Exception@downloadExcel: ", exception);
			} 
			LOG.info("Exiting downloadExcel Method");
			
		} 	

		/**
		 * This method is used to download an Excel File
		 * 
		 *
		 */
		public void downloadReqMntTemplate() throws PLMCommonException {
			LOG.info("Entering downloadReqMntTemplate Method");
			String reportName = "Requirement Template";
			try {
				generateReqMntTemplate(reportName);
			} catch (Exception exception) {
				LOG.log(Level.ERROR, "Exception@downloadReqMntTemplate: ", exception);
			} 
			LOG.info("Exiting downloadReqMntTemplate Method");
			
		}
		
				
		/**
		 * This method is used for Generating Report in XLS
		 * 
		 * @return File
		 */
		
		public File generateFMIManageTxt(List<PLMFmiTemplateData> reqCeiMliNamesListLcl,String reportName) throws IOException {
			LOG.info("Entering generateFMIManageTxt Method");
			File flexcelFile =null;
			FileOutputStream fileOut = null;
			InputStream fstream = null;
			BufferedOutputStream bos = null;
			OutputStream os = null;
			HSSFWorkbook workbook = null;
			HSSFSheet sheet = null;
			HSSFCell cell=null;
			try {
				
			   StringBuilder fileNameStr = new StringBuilder()
			   .append(PLMUtils.getMessage("OFFLINE_RPT_DIR","com.geinfra.geaviation.pwi.resources.Reports"))
			   .append(reportName)
			   .append(PLMUtils.getCurrentDateTime())
			   .append(".xls");
			   
			   flexcelFile = new File(fileNameStr.toString());
				workbook = new HSSFWorkbook();
					 
				//if (workbook != null){
					
					sheet =  workbook.createSheet(reportName);
					sheet.createFreezePane(0, 1);
					sheet.createFreezePane(1,1);
					HSSFFont fontstyle = workbook.createFont();
					fontstyle.setFontName(PLMConstants.EXCEL_FONT_NAME);
					
					HSSFCellStyle unLockedTextStyle = workbook.createCellStyle(); 
					unLockedTextStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
					unLockedTextStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
					unLockedTextStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
					unLockedTextStyle.setBorderTop((HSSFCellStyle.BORDER_THIN));
					unLockedTextStyle.setFont(fontstyle);
					unLockedTextStyle.setWrapText(true);
					unLockedTextStyle.setLocked(false); 
					unLockedTextStyle.setAlignment(CellStyle.ALIGN_CENTER);
					
					HSSFCellStyle lockedTextStyle = workbook.createCellStyle(); 
					lockedTextStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
					lockedTextStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
					lockedTextStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
					lockedTextStyle.setBorderTop((HSSFCellStyle.BORDER_THIN));
					lockedTextStyle.setFont(fontstyle);
					lockedTextStyle.setWrapText(true);
					lockedTextStyle.setLocked(true); 
					lockedTextStyle.setAlignment(CellStyle.ALIGN_CENTER);
					
					HSSFCellStyle headerStyle = workbook.createCellStyle();
						
					
					headerStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
					headerStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
					headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
					headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
					HSSFFont font = workbook.createFont(); 
					font.setFontName(PLMConstants.EXCEL_FONT_NAME);
					font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
					headerStyle.setFont(font);
					headerStyle.setWrapText(true);
					headerStyle.setLocked(true); 
					headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
					headerStyle = setBorderStyle(headerStyle);
					
				
					int rowcount = -1;
					
					if(!PLMUtils.isEmptyList(reqCeiMliNamesListLcl)) {
						String[] colNames = {"Requirement Name","Requirement Description",
								"CEI Name","CEI Display Name","MLI Name","MLI Description",
								"MLI Notes","Applicability Symbol","Modification Description",
								"Benefits","Special Notes","Repair Text","Field Text","Special Tools",
								"Service Documents","FMI Text","Standard Task Duartion",
								"Similar to Part CCE","FullFilment Lead Time",
								"PRS Text","Hours Effort","MlI ID"};					
						HSSFRow row = sheet.createRow(++rowcount);
						cell = row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						HSSFCellStyle cellStyle = cell.getCellStyle();
						cellStyle.setLocked(true);
						cell.setCellStyle(lockedTextStyle);
						
							for ( int i = 0 ; i < colNames.length; i++ ) {
							cell = row.createCell(i);
							cell. setCellValue(colNames[i]);
							cell.setCellStyle(headerStyle);
							headerStyle = cell.getCellStyle();
							cell.setCellStyle(headerStyle);
						}
						
						//sheet.getRow(0).getCell(0).getCellStyle().setLocked(true);  
						//sheet.getRow(0).getCell(0).setCellStyle(lockedTextStyle); 
							

						for(int i = 0; i < reqCeiMliNamesListLcl.size(); i++) {
							PLMFmiTemplateData	 dataObj = (PLMFmiTemplateData)reqCeiMliNamesListLcl.get(i);
							row =  sheet.createRow(++rowcount);
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_ZERO);
							cell.setCellStyle(lockedTextStyle);
							cell.setCellValue(dataObj.getReqName());
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellStyle(lockedTextStyle);
							cell.setCellValue(dataObj.getReqDesc());
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_TWO);
							cell.setCellStyle(lockedTextStyle);
							cell.setCellValue(dataObj.getCeiName());
				
							cell =   row.createCell(PLMConstants.EXCEL_COL_THREE);
							cell.setCellStyle(lockedTextStyle);
							cell.setCellValue(dataObj.getCeiDesc());
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_FOUR);
							cell.setCellStyle(lockedTextStyle);
							cell.setCellValue(dataObj.getMliName());
								
							cell =   row.createCell(PLMConstants.EXCEL_COL_FIVE);
							cell.setCellStyle(lockedTextStyle);
							cell.setCellValue(dataObj.getMliDesc());
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_SIX);
							cell.setCellStyle(lockedTextStyle);
							cell.setCellValue(dataObj.getMliNotes());
							
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_SEVEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(dataObj.getApplicableSymbol());
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_EIGHT);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(dataObj.getModidicationDesc());
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_NINE);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(dataObj.getFmiBenefits());
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_TEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(dataObj.getSpecialNotes());
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(dataObj.getRepairTextVal());
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_TWELVE);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(dataObj.getTextFeild());
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(dataObj.getSpecialTools());
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(dataObj.getServiceDoc());
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(dataObj.getFmiTextVal());
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(dataObj.getStdTaskDuration());
						
							cell =   row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(dataObj.getSmlrToPartQTC());
						
							cell =   row.createCell(PLMConstants.EXCEL_COL_EIGHTEEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(dataObj.getFillMntLeadTime());
						
							cell =   row.createCell(PLMConstants.EXCEL_COL_NINETEEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(dataObj.getPrsText());
						
							cell =   row.createCell(PLMConstants.EXCEL_COL_TWENTY);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(dataObj.getHoursEffort());
						
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_TWENTYONE);
							cell.setCellStyle(lockedTextStyle);
							cell.setCellValue(dataObj.getMliId());
							
						
						}
						
						row =  sheet.createRow(++rowcount);
						row =  sheet.createRow(++rowcount);
					short colWidth = (short)6400;
					short colWidth1 = (short)6700;
					short colWidth2 = (short)7000;
					short colWidth3 = (short)7200;
					short colWidth4 = (short)7900;
									
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,colWidth4);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,colWidth2);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,colWidth1);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,colWidth);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,colWidth2);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,colWidth2);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWELVE,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTEEN,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTEEN,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTEEN,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIXTEEN,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVENTEEN,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHTEEN,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINETEEN,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTY,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYONE,colWidth3);
				
					
					}
					/*
					for(int i=0;i<reqCeiMliNamesListLcl.size();i++){
						for(int j=0;j<16;j++){
							if(j==7 || j==8 || j==9 || j==10 || j==11 || j==12 || j==13 || j==14){
								sheet.getRow(i+1).getCell(j).getCellStyle().setLocked(false);
							}
							else{
								sheet.getRow(i+1).getCell(j).getCellStyle().setLocked(true);
							}
						}
						
					}*/
					
					
					sheet.protectSheet(resourceBundle.getString("FMI_TXT_EXL_PW"));
					
					
					fileOut = new FileOutputStream(flexcelFile);
					workbook.write(fileOut);
					String fileName = flexcelFile.getName();
					FacesContext context = FacesContext.getCurrentInstance();
					HttpServletResponse response = (HttpServletResponse) context
							.getExternalContext().getResponse();
					response.setContentType("application/vnd.ms-excel");
					response.setHeader("content-disposition",
							"attachment; filename="+ fileName);
					os = response.getOutputStream();
					workbook.write(os);
					fileOut.close();
					os.close();
					context.responseComplete();
					LOG.info("test file name" + fileName);
					LOG.info("test report-------" + flexcelFile);
					
				//}
			} catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@generateFMIManageTxt: ", e);
				throw e;
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@generateFMIManageTxt: ", e);
				throw e;
			}  
			finally {
				try {
					if (bos != null) {
						bos.close();
					}
				} catch (IOException exception) {
					LOG.log(Level.ERROR,"The Exception in generateFMIManageTxt " + exception);
				}
				try {
					if (os != null) {
						os.close();
					}
				} catch (IOException exception) {
					LOG.log(Level.ERROR,"The Exception in generateFMIManageTxt " + exception);
				}
				try {
					if (fstream != null) {
						fstream.close();
					}
				} catch (IOException exception) {
					LOG.log(Level.ERROR,"The Exception in generateFMIManageTxt " + exception);
				}
				try {
					if (flexcelFile != null) {
						PLMUtils.deleteDocument(flexcelFile.getAbsolutePath());
					}
				} catch (Exception exception) {
					LOG.log(Level.ERROR,"The Exception in generateFMIManageTxt " + exception);
				}
				try {
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException exception) {
					LOG.log(Level.ERROR,"The Exception in generateFMIManageTxt " + exception);
				}

			}
			LOG.info("Exiting generateFMIManageTxt Method");
			return flexcelFile;
			
		}
		
		/**
		 * This method is used for Generating Report in XLS
		 * 
		 * @return File
		 */
		
		public File generateReqMntTemplate(String reportName) throws IOException {
			LOG.info("Entering generateReqMntTemplate Method");
			File flexcelFile =null;
			FileOutputStream fileOut = null;
			OutputStream os = null;
			HSSFWorkbook workbook = null;
			HSSFSheet sheet = null;
			HSSFCell cell=null;
			try {
				
			   StringBuilder fileNameStr = new StringBuilder()
			   .append(PLMUtils.getMessage("OFFLINE_RPT_DIR","com.geinfra.geaviation.pwi.resources.Reports"))
			   .append(reportName)
			   .append(PLMUtils.getCurrentDateTime())
			   .append(".xls");
			   
			   flexcelFile = new File(fileNameStr.toString());
				workbook = new HSSFWorkbook();
					 
				//if (workbook != null){
					
					sheet =  workbook.createSheet(reportName);
					HSSFFont fontstyle = workbook.createFont();
					fontstyle.setFontName(PLMConstants.EXCEL_FONT_NAME);
					
					HSSFCellStyle unLockedTextStyle = workbook.createCellStyle(); 
					unLockedTextStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
					unLockedTextStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
					unLockedTextStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
					unLockedTextStyle.setBorderTop((HSSFCellStyle.BORDER_THIN));
					unLockedTextStyle.setFont(fontstyle);
					unLockedTextStyle.setWrapText(true);
					unLockedTextStyle.setLocked(false); 
					unLockedTextStyle.setAlignment(CellStyle.ALIGN_CENTER);
					
					HSSFCellStyle lockedTextStyle = workbook.createCellStyle(); 
					lockedTextStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
					lockedTextStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
					lockedTextStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
					lockedTextStyle.setBorderTop((HSSFCellStyle.BORDER_THIN));
					lockedTextStyle.setFont(fontstyle);
					lockedTextStyle.setWrapText(true);
					lockedTextStyle.setLocked(true); 
					lockedTextStyle.setAlignment(CellStyle.ALIGN_CENTER);
					
					HSSFCellStyle headerStyle = workbook.createCellStyle();
						
					
					headerStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
					headerStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
					headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
					headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
					HSSFFont font = workbook.createFont(); 
					font.setFontName(PLMConstants.EXCEL_FONT_NAME);
					font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
					headerStyle.setFont(font);
					headerStyle.setWrapText(true);
					headerStyle.setLocked(true); 
					headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
					headerStyle = setBorderStyle(headerStyle);
					
				
					int rowcount = -1;
					
						String[] colNames = {"Requirement Name","Requirement Description"};					
						HSSFRow row1 = sheet.createRow(++rowcount);
						cell = row1.createCell(PLMConstants.EXCEL_COL_ZERO); 
						HSSFCellStyle cellStyle = cell.getCellStyle();
						cellStyle.setLocked(true);
						cell.setCellStyle(lockedTextStyle);
						
							for ( int i = 0 ; i < colNames.length; i++ ) {
							cell = row1.createCell(i);
							cell. setCellValue(colNames[i]);
							cell.setCellStyle(headerStyle);
							headerStyle = cell.getCellStyle();
							cell.setCellStyle(headerStyle);
						}
						
						for(int j=0;j<500;j++){	
							HSSFRow	row2 =  sheet.createRow(++rowcount);
							
							cell =   row2.createCell(PLMConstants.EXCEL_COL_ZERO);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue("");
							
							cell =   row2.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue("");
						}				
						
						sheet.createRow(++rowcount);
						sheet.createRow(++rowcount);
					short colWidth1 = (short)5000;
					short colWidth2 = (short)9000;
									
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,colWidth1);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,colWidth2);
					
					sheet.protectSheet(resourceBundle.getString("FMI_TXT_EXL_PW"));
					
					
					fileOut = new FileOutputStream(flexcelFile);
					workbook.write(fileOut);
					String fileName = flexcelFile.getName();
					FacesContext context = FacesContext.getCurrentInstance();
					HttpServletResponse response = (HttpServletResponse) context
							.getExternalContext().getResponse();
					response.setContentType("application/vnd.ms-excel");
					response.setHeader("content-disposition",
							"attachment; filename="+ fileName);
					os = response.getOutputStream();
					workbook.write(os);
					fileOut.close();
					os.close();
					context.responseComplete();
					LOG.info("test file name" + fileName);
					LOG.info("test report-------" + flexcelFile);
					
				//}
			} catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@generateReqMntTemplate: ", e);
				throw e;
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@generateReqMntTemplate: ", e);
				throw e;
			}  
			finally {
				try {
					if (os != null) {
						os.close();
					}
				} catch (IOException exception) {
					LOG.log(Level.ERROR,"The Exception in generateReqMntTemplate " + exception);
				}
				
				try {
					if (flexcelFile != null) {
						PLMUtils.deleteDocument(flexcelFile.getAbsolutePath());
					}
				} catch (Exception exception) {
					LOG.log(Level.ERROR,"The Exception in generateReqMntTemplate " + exception);
				}
				try {
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException exception) {
					LOG.log(Level.ERROR,"The Exception in generateReqMntTemplate " + exception);
				}

			}
			LOG.info("Exiting generateReqMntTemplate Method");
			return flexcelFile;
			
		}

		//start Newly Added by srinivas for uploading bulk Requirement	
				
		/**
		 * This method is used for upload Bulk Requirement Data
		 * 
		 * @return String
		 */
		public void uploadBulkReqData(UploadEvent event) throws Exception {
			LOG.info("Entering uploadFmiManageText Method");
			UploadItem item = event.getUploadItem();
			templateData.setSrcfile(item.getFile());
				String status="";
			 if (templateData.getSrcfile().exists()) {
				 validateReqmntTxt();
				 LOG.info("Error message = " + templateData.getTmpltErrorMsg());
				 if (templateData.getTmpltErrorMsg().equals("")) { 
					 readRequrmntList();
					if (templateData.getTmpltErrorMsg().equals("")) {
						status=plmDocGenService.uploadBulkReqData(bulkRequirmntList,userDetails.getUserSSO()); 
						LOG.info("status>>>>>>>>>>>>>>>>>>>>>>>>>> "+status);
					} else {
						FacesContext facesContext = FacesContext
								.getCurrentInstance();
						facesContext.responseComplete();
					}
				 } else {
						FacesContext facesContext = FacesContext.getCurrentInstance();
						facesContext.responseComplete();
			  }
			}
			LOG.info("Exiting uploadFmiManageText Method");
		}

		/**
		 * Reload FIm Manage Add Text page. Require to fix IE11 issue with rich:fileUpload
		 * */
		public String refreshFixForRichUpload() {
			return "fmiManageAddTxt";
		}
		
		/**
		 * Reload FMI Template page. Require to fix IE11 issue with rich:fileUpload
		 * */
		public String refreshFixForRichUploadTemplate() {
			return "fmitemplate";
		}
		
		/**
		 * This method is used for Validate Bulk Requirement
		 * 
		 * @return String
		 */
		@SuppressWarnings("unchecked")
		public void validateReqmntTxt() {
			LOG.info("Entering validateReqmntTxt Method");
			FileInputStream fis = null;
			StringBuffer errormessage = new StringBuffer();
			try {
				errorDataList = new ArrayList<PLMFmiTemplateData>();
				fis = new FileInputStream(templateData.getSrcfile());
				HSSFWorkbook workbook = new HSSFWorkbook(fis);
				HSSFSheet sheet = workbook.getSheetAt(0);
				HSSFRow headerrow = sheet.getRow(0);
				Iterator rows = sheet.rowIterator();
				int totalcols = 2;
				if (rows.hasNext()) {
					while (rows.hasNext()) {
						HSSFRow row = (HSSFRow) rows.next();
						if (row.getRowNum() == 0)
							continue;
						Iterator cells = row.cellIterator();
						if (cells.hasNext()) {
							HSSFCell cell = (HSSFCell) cells.next();
							if (cell.getColumnIndex() < totalcols) {
								for (int i = 0; i < totalcols; i++) {
									HSSFCell currentcell = row.getCell(i);
								    	if (currentcell != null) {
								    		switch (i) {
											case 0:
												if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
													templateData.setReqName(Double
															.toString(currentcell.getNumericCellValue()));
												  }
												  else{
												       templateData.setReqName(currentcell.getRichStringCellValue()
													      .toString());
												  }
												
												  if(templateData.getReqName().length() > 30){
									    		
													  errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
											   +headerrow.getCell(i)+" Error Description: Exceeds the Size Limit (Input value length: "
											   +templateData.getReqName().length()+" Allowed: 1 <br>");
													  PLMFmiTemplateData tempData1 = new PLMFmiTemplateData();
													  tempData1.setRowcellVal(String.valueOf(row.getRowNum()+1));
													  tempData1.setFieldName(headerrow.getCell(i).toString());
													  tempData1.setErrorDesc("Error Description: Exceeds the Size Limit (Input value length: "
											   +templateData.getReqName().length()+" Allowed: 1");
											 errorDataList.add(tempData1);
									    		  }else if(PLMUtils.checkSplCharWhereUsed(templateData.getReqName())){
													  errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
															   +headerrow.getCell(i)+" Error Description: Special Characters of  "
															   +templateData.getReqName()+" are not Allowed  <br>");
													  	PLMFmiTemplateData tempData2 = new PLMFmiTemplateData();
																	  tempData2.setRowcellVal(String.valueOf(row.getRowNum()+1));
																	  tempData2.setFieldName(headerrow.getCell(i).toString());
																	  tempData2.setErrorDesc("Error Description:  Error Description: Special Characters of "
															   +templateData.getReqName()+" are not Allowed");
															 errorDataList.add(tempData2);
											    	}
												break;
											
								    		
								    	case 1:
								    		if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
												templateData.setReqDesc(Double
														.toString(currentcell.getNumericCellValue()));
											  }
											  else{
											       templateData.setReqDesc(currentcell.getRichStringCellValue()
												      .toString());
											  }
								    		
								    		if(templateData.getReqDesc().length() > 2000){
								    			 errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
														   +headerrow.getCell(i)+" Error Description: Exceeds the Size Limit (Input value length: "
														   +templateData.getReqDesc().length()+" Allowed: 2000 <br>");
								    			 PLMFmiTemplateData tempData3 = new PLMFmiTemplateData();
								    			 tempData3.setRowcellVal(String.valueOf(row.getRowNum()+1));
								    			 tempData3.setFieldName(headerrow.getCell(i).toString());
								    			 tempData3.setErrorDesc("Error Description: Exceeds the Size Limit (Input value length: "
												   +templateData.getReqDesc().length()+" Allowed: 2000");		
												 errorDataList.add(tempData3);
												    	
								    		  }else if(PLMUtils.checkSplCharWhereUsed(templateData.getReqDesc())){
												  errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
														   +headerrow.getCell(i)+" Error Description: Special Characters of  "
														   +templateData.getReqDesc()+" are not Allowed  <br>");
												  PLMFmiTemplateData tempData4 = new PLMFmiTemplateData();
																  tempData4.setRowcellVal(String.valueOf(row.getRowNum()+1));
																  tempData4.setFieldName(headerrow.getCell(i).toString());
																  tempData4.setErrorDesc("Error Description:  Error Description: Special Characters of "
														   +templateData.getReqDesc()+" are not Allowed");
														 errorDataList.add(tempData4);
										    	}
											break;
								       	   default:
											break;
										}
								    		
								    }		
								  }
								}
							}
						}
					}
				
			} catch (FileNotFoundException ex) {
				templateData.setTmpltErrorMsg("File Does not Exist");
			} catch (IOException ec) {
				templateData.setTmpltErrorMsg("Invalid Template Format");
			} finally {
				try {
					if (fis != null) {
						fis.close();
					}
				} catch (IOException e) {
					templateData.setTmpltErrorMsg("Invalid Template Format");
				}
			}
			LOG.info("Error Message " + errormessage.toString());
			templateData.setTmpltErrorMsg(errormessage.toString());
			LOG.info("Exiting validateReqmntTxt Method");
		}
		
		/**
		 * This method is used for Reading Fmi Manage Text
		 * 
		 * @return String
		 */
		@SuppressWarnings("unchecked")
	public void readRequrmntList() {
			LOG.info("Entering readRequrmntList Method");
			StringBuilder errormessage = new StringBuilder();
			bulkRequirmntList = new ArrayList<PLMFmiTemplateData>();
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(templateData.getSrcfile());
				HSSFWorkbook workbook = new HSSFWorkbook(fis);
				HSSFSheet sheet = workbook.getSheetAt(0);
				Iterator rows = sheet.rowIterator();
				int totalcols = 2;
				int noofrecords = 0;
				while (rows.hasNext()) {
					templateData = new PLMFmiTemplateData();
					HSSFRow row = (HSSFRow) rows.next();
					if (row.getRowNum() == 0)
						continue;
					Iterator cells = row.cellIterator();
					if (cells.hasNext()) {
						HSSFCell cell = (HSSFCell) cells.next();
						if (cell.getColumnIndex() < totalcols) {
							for (int i = 0; i < totalcols; i++) {
								HSSFCell currentcell = row.getCell(i);
								if (currentcell == null) {
									if (PLMConstants.N_0==i) {
										templateData.setReqName("");
									} else if (PLMConstants.N_1==i){
										templateData.setReqDesc("");
									}
									
								} else {

									if (PLMConstants.N_0==i) {
										templateData.setReqName(currentcell.getRichStringCellValue().toString());
									} else if (PLMConstants.N_1==i) {
										templateData.setReqDesc(currentcell.getRichStringCellValue().toString());
									}
								}
							}
						}
					}
					bulkRequirmntList.add(noofrecords, templateData);
					noofrecords++;
				}
				LOG.info("noofrecords : " + noofrecords);
				if (bulkRequirmntList.size() == 0)
					errormessage.append("No Records Found");
				
				} catch (FileNotFoundException ex) {
					errormessage.append("File Does not Exist");
				} catch (IOException ex1) {
					errormessage.append("Error Reading in File");
				} finally {
					try {
						if (fis != null)
							fis.close();
					} catch (IOException ex1) {
						errormessage.append("Error Reading in File");
						LOG.info("errormessage -->"+errormessage);
					}catch (Exception ex2) {
						errormessage.append("Error Reading in File");
					}
				}
				
				  templateData.setTmpltErrorMsg(errormessage.toString());

			LOG.info("Exiting readRequrmntList Method");
		}
		//End Newly Added by srinivas for uploading bulk Requirement			
		
		/**
		 * This method is used for upload Fmi Manage Text
		 * 
		 * @return String
		 */
		public void uploadFmiManageText(UploadEvent event) throws Exception {
			LOG.info("Entering uploadFmiManageText Method");
			//fmiMngTextDataList = new ArrayList<PLMFmiTemplateData>();
			UploadItem item = event.getUploadItem();
			templateData.setSrcfile(item.getFile());
	
			 if (templateData.getSrcfile().exists()) {
				 validateFmiManageText();
				 LOG.info("Error message = " + templateData.getTmpltErrorMsg());
				 if (templateData.getTmpltErrorMsg().equals("")) { 
					readFmiManageText();
					if (templateData.getTmpltErrorMsg().equals("")) {
						plmDocGenService.uploadFmiManageText(fmiMngTextDataList,userDetails.getUserSSO()); 
					} else {
						FacesContext facesContext = FacesContext
								.getCurrentInstance();
						facesContext.responseComplete();
					}
				 } else {
						FacesContext facesContext = FacesContext.getCurrentInstance();
						facesContext.responseComplete();
			  }
			}
			LOG.info("Exiting uploadFmiManageText Method");
		}

		
		
		
		/**
		 * This method is used for Validate FmiManageText
		 * 
		 * @return String
		 */
		@SuppressWarnings("unchecked")
		public void validateFmiManageText() {
			LOG.info("Entering validateFmiManageText Method");
			FileInputStream fis = null;
			StringBuffer errormessage = new StringBuffer();
			try {
				//PLMFmiTemplateData tempData = new PLMFmiTemplateData();
				errorDataList = new ArrayList<PLMFmiTemplateData>();
				fis = new FileInputStream(templateData.getSrcfile());
				HSSFWorkbook workbook = new HSSFWorkbook(fis);
				HSSFSheet sheet = workbook.getSheetAt(0);
				HSSFRow headerrow = sheet.getRow(0);
				Iterator rows = sheet.rowIterator();
				int totalcols = 22;
				if (rows.hasNext()) {
					while (rows.hasNext()) {
					HSSFRow row = (HSSFRow) rows.next();
						if (row.getRowNum() == 0)
							continue;
						Iterator cells = row.cellIterator();
						if (cells.hasNext()) {
							HSSFCell cell = (HSSFCell) cells.next();
							if (cell.getColumnIndex() < totalcols) {
								for (int i = 7; i < totalcols; i++) {
									HSSFCell currentcell = row.getCell(i);
								    	if (currentcell != null) {
								    		switch (i) {
											case 7:
												if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
													templateData.setApplicableSymbol(Double
															.toString(currentcell.getNumericCellValue()));
												  }
												  else{
												       templateData.setApplicableSymbol(currentcell.getRichStringCellValue()
													      .toString());
												  }
												
												  if(templateData.getApplicableSymbol().length() > 1){
									    		
													  errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
											   +headerrow.getCell(i)+" Error Description: Exceeds the Size Limit (Input value length: "
											   +templateData.getApplicableSymbol().length()+" Allowed: 1 <br>");
													  PLMFmiTemplateData tempData = new PLMFmiTemplateData();
													  tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
													  tempData.setFieldName(headerrow.getCell(i).toString());
													  tempData.setErrorDesc("Error Description: Exceeds the Size Limit (Input value length: "
											   +templateData.getApplicableSymbol().length()+" Allowed: 1");
													  
													  LOG.info("tempData.getRowcellVal()>>>>>>>>>."+tempData.getRowcellVal());
											 errorDataList.add(tempData);
									    		  }
												break;
											
								    		
								    	case 8:
								    		if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
												templateData.setModidicationDesc(Double
														.toString(currentcell.getNumericCellValue()));
											  }
											  else{
											       templateData.setModidicationDesc(currentcell.getRichStringCellValue()
												      .toString());
											  }

								    		
								    		if(templateData.getModidicationDesc().length() > 2000){
								    			 errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
														   +headerrow.getCell(i)+" Error Description: Exceeds the Size Limit (Input value length: "
														   +templateData.getModidicationDesc().length()+" Allowed: 2000 <br>");
								    			 PLMFmiTemplateData tempData = new PLMFmiTemplateData();
								    			 tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
								    			 tempData.setFieldName(headerrow.getCell(i).toString());
								    			 tempData.setErrorDesc("Error Description: Exceeds the Size Limit (Input value length: "
												   +templateData.getModidicationDesc().length()+" Allowed: 2000");		
												 errorDataList.add(tempData);
												    	
								    		  }
											break;
											
								    	case 9:
								    		if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
												templateData.setFmiBenefits(Double
														.toString(currentcell.getNumericCellValue()));
											  }
											  else{
											       templateData.setFmiBenefits(currentcell.getRichStringCellValue()
												      .toString());
											  }
											
											 if(templateData.getFmiBenefits().length() > 4000){
												 errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
														   +headerrow.getCell(i)+" Error Description: Exceeds the Size Limit (Input value length: "
														   +templateData.getFmiBenefits().length()+" Allowed: 4000 <br>");
												 PLMFmiTemplateData tempData = new PLMFmiTemplateData();
												 tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
												 tempData.setFieldName(headerrow.getCell(i).toString());
												 tempData.setErrorDesc("Error Description: Exceeds the Size Limit (Input value length: "
												   +templateData.getFmiBenefits().length()+" Allowed: 4000");		
												 errorDataList.add(tempData);
								    		 
								    		  }
											break;
											
								    	case 10:
								    		if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
												templateData.setSpecialNotes(Double
														.toString(currentcell.getNumericCellValue()));
											  }
											  else{
											       templateData.setSpecialNotes(currentcell.getRichStringCellValue()
												      .toString());
											  }
											
											 if(templateData.getSpecialNotes().length() > 500){
												 errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
														   +headerrow.getCell(i)+" Error Description: Exceeds the Size Limit (Input value length: "
														   +templateData.getSpecialNotes().length()+" Allowed: 500 <br>");
												 PLMFmiTemplateData tempData = new PLMFmiTemplateData();
												 tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
												 tempData.setFieldName(headerrow.getCell(i).toString());
												 tempData.setErrorDesc("Error Description: Exceeds the Size Limit (Input value length: "
												   +templateData.getSpecialNotes().length()+" Allowed: 500");		
												 errorDataList.add(tempData);
								    		 
								    		  }
											break;

											
								    	case 11:
								    		if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
												templateData.setRepairTextVal(Double
														.toString(currentcell.getNumericCellValue()));
											  }
											  else{
											       templateData.setRepairTextVal(currentcell.getRichStringCellValue()
												      .toString());
											  }
											
											if(templateData.getRepairTextVal().length() > 500){
												 errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
														   +headerrow.getCell(i)+" Error Description: Exceeds the Size Limit (Input value length: "
														   +templateData.getRepairTextVal().length()+" Allowed: 500 <br>");
												 PLMFmiTemplateData tempData = new PLMFmiTemplateData();
												 tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
												 tempData.setFieldName(headerrow.getCell(i).toString());
												 tempData.setErrorDesc("Error Description: Exceeds the Size Limit (Input value length: "
												   +templateData.getRepairTextVal().length()+" Allowed: 500");		
												 errorDataList.add(tempData);
												
								    		  }
											break;
											
								    	case 12:
								    		if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
												templateData.setTextFeild(Double
														.toString(currentcell.getNumericCellValue()));
											  }
											  else{
											       templateData.setTextFeild(currentcell.getRichStringCellValue()
												      .toString());
											  }
											
											  if(templateData.getTextFeild().length() > 2000){
												  errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
														   +headerrow.getCell(i)+" Error Description: Exceeds the Size Limit (Input value length: "
														   +templateData.getTextFeild().length()+" Allowed: 2000 <br>");
												  PLMFmiTemplateData tempData = new PLMFmiTemplateData();
												  tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
												  tempData.setFieldName(headerrow.getCell(i).toString());
												  tempData.setErrorDesc("Error Description: Exceeds the Size Limit (Input value length: "
													   +templateData.getTextFeild().length()+" Allowed: 2000");		
													 errorDataList.add(tempData);
													  }
											break;
											
								    	case 13:
								    		if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
												templateData.setSpecialTools(Double
														.toString(currentcell.getNumericCellValue()));
											  }
											  else{
											       templateData.setSpecialTools(currentcell.getRichStringCellValue()
												      .toString());
											  }
											
											 if(templateData.getSpecialTools().length() > 250){
												 errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
														   +headerrow.getCell(i)+" Error Description: Exceeds the Size Limit (Input value length: "
														   +templateData.getSpecialTools().length()+" Allowed: 250 <br>");
												 PLMFmiTemplateData tempData = new PLMFmiTemplateData();
												 tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
												 tempData.setFieldName(headerrow.getCell(i).toString());
												 tempData.setErrorDesc("Error Description: Exceeds the Size Limit (Input value length: "
												   +templateData.getSpecialTools().length()+" Allowed: 250");		
												 errorDataList.add(tempData);
													  }
											break;
											
								    	case 14:
								    		if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
												templateData.setServiceDoc(Double
														.toString(currentcell.getNumericCellValue()));
											  }
											  else{
											       templateData.setServiceDoc(currentcell.getRichStringCellValue()
												      .toString());
											  }
											
											  if(templateData.getServiceDoc().length() > 250){
													 errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
															   +headerrow.getCell(i)+" Error Description: Exceeds the Size Limit (Input value length: "
															   +templateData.getServiceDoc().length()+" Allowed: 250 <br>");
													 PLMFmiTemplateData tempData = new PLMFmiTemplateData();
													 tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
													 tempData.setFieldName(headerrow.getCell(i).toString());
													 tempData.setErrorDesc("Error Description: Exceeds the Size Limit (Input value length: "
													   +templateData.getServiceDoc().length()+" Allowed: 250");		
													 errorDataList.add(tempData);
													  }
											break;
										
										
											
								    	case 15:
								    		if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
												templateData.setFmiTextVal(Double
														.toString(currentcell.getNumericCellValue()));
											  }
											  else{
											       templateData.setFmiTextVal(currentcell.getRichStringCellValue()
												      .toString());
											  }
											
											 if(templateData.getFmiTextVal().length() > 4000){
												 errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
														   +headerrow.getCell(i)+" Error Description: Exceeds the Size Limit (Input value length: "
														   +templateData.getFmiTextVal().length()+" Allowed: 4000 <br>");
												 PLMFmiTemplateData tempData = new PLMFmiTemplateData();
												 tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
												 tempData.setFieldName(headerrow.getCell(i).toString());
												 tempData.setErrorDesc("Error Description: Exceeds the Size Limit (Input value length: "
												   +templateData.getFmiTextVal().length()+" Allowed: 4000");		
												 errorDataList.add(tempData);
											  }
											break;
									
								    	case 16:
								    		if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
												templateData.setStdTaskDuration(String.valueOf((int)currentcell.getNumericCellValue()));
											  }
											  else{
											       templateData.setStdTaskDuration(currentcell.getRichStringCellValue()
												      .toString());
											  }
								    		if(!PLMUtils.isIntegerFmi(templateData.getStdTaskDuration())){
												  errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
														   +headerrow.getCell(i)+" Error Description: Only Numeric value " +
														   		" is allowed for Standard Task Duartion. Input value is : "
														   +templateData.getStdTaskDuration()+"<br>");
												  				PLMFmiTemplateData tempData = new PLMFmiTemplateData();
																  tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
																  tempData.setFieldName(headerrow.getCell(i).toString());
																  tempData.setErrorDesc(" Error Description: Only Numeric value " +
																	   		" is allowed for Standard Task Duartion. Input value is : "
																		   +templateData.getStdTaskDuration());
																  LOG.info("tempData.getRowcellVal()>>>>>>>>>."+tempData.getRowcellVal());
														 errorDataList.add(tempData);
										 } else if(templateData.getStdTaskDuration().length() > 4){
												  errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
										   +headerrow.getCell(i)+" Error Description: Exceeds the Size Limit (Input value length: "
										   +templateData.getStdTaskDuration()+" Allowed: 4 <br>");
												  PLMFmiTemplateData tempData = new PLMFmiTemplateData();
												  tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
												  tempData.setFieldName(headerrow.getCell(i).toString());
												  tempData.setErrorDesc("Error Description: Exceeds the Size Limit (Input value length: "
										   +templateData.getStdTaskDuration()+" Allowed: 4");
												  LOG.info("tempData.getRowcellVal()>>>>>>>>>."+tempData.getRowcellVal());
										 errorDataList.add(tempData);
								    	 } else if(PLMUtils.checkSplCharWhereUsed(templateData.getStdTaskDuration())){
												  errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
														   +headerrow.getCell(i)+" Error Description: Special Characters of  "
														   +templateData.getStdTaskDuration()+" are not Allowed  <br>");
												  PLMFmiTemplateData tempData = new PLMFmiTemplateData();
																  tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
																  tempData.setFieldName(headerrow.getCell(i).toString());
																  tempData.setErrorDesc("Error Description:  Error Description: Special Characters of "
														   +templateData.getStdTaskDuration()+" are not Allowed");
																  LOG.info("tempData.getRowcellVal()>>>>>>>>>."+tempData.getRowcellVal());
														 errorDataList.add(tempData);
										 }
											break;
							
								     	case 17:
											if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
												templateData.setSmlrToPartQTC(Double
														.toString(currentcell.getNumericCellValue()));
											  }
											  else{
											       templateData.setSmlrToPartQTC(currentcell.getRichStringCellValue()
												      .toString());
											  }
											
											  if(templateData.getSmlrToPartQTC().length() > 30){
								    		
												  errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
										   +headerrow.getCell(i)+" Error Description: Exceeds the Size Limit (Input value length: "
										   +templateData.getSmlrToPartQTC().length()+" Allowed: 30 <br>");
												  PLMFmiTemplateData tempData = new PLMFmiTemplateData();
												  tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
												  tempData.setFieldName(headerrow.getCell(i).toString());
												  tempData.setErrorDesc("Error Description: Exceeds the Size Limit (Input value length: "
										   +templateData.getSmlrToPartQTC().length()+" Allowed: 30");
												  LOG.info("tempData.getRowcellVal()>>>>>>>>>."+tempData.getRowcellVal());
										 errorDataList.add(tempData);
								    		  }
											break;
							
								     	case 18:
								     		if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
												templateData.setFillMntLeadTime(String.valueOf((int)currentcell.getNumericCellValue()));
											  }
											  else{
											       templateData.setFillMntLeadTime(currentcell.getRichStringCellValue()
												      .toString());
											  }

								     		if(!PLMUtils.isIntegerFmi(templateData.getFillMntLeadTime())) {
												  errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
														   +headerrow.getCell(i)+" Error Description: Only Numeric value " +
												   		" is allowed for Standard Task Duartion. Input value is : "
												   +templateData.getFillMntLeadTime()+"<br>");
												  	PLMFmiTemplateData tempData = new PLMFmiTemplateData();
																  tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
																  tempData.setFieldName(headerrow.getCell(i).toString());
																  tempData.setErrorDesc("Error Description: Only Numeric value " +
																	   		" is allowed for FullFilment Lead Time. Input value is : "
																		   +templateData.getFillMntLeadTime());
																  LOG.info("tempData.getRowcellVal()>>>>>>>>>."+tempData.getRowcellVal());
														 errorDataList.add(tempData);
								     		} else if(templateData.getFillMntLeadTime().length() > 4){
												  errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
												   +headerrow.getCell(i)+" Error Description: Exceeds the Size Limit (Input value length: "
												   +templateData.getFillMntLeadTime()+" Allowed: 4 <br>");
												  PLMFmiTemplateData tempData = new PLMFmiTemplateData();
														  tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
														  tempData.setFieldName(headerrow.getCell(i).toString());
														  tempData.setErrorDesc("Error Description: Exceeds the Size Limit (Input value length: "
												   +templateData.getFillMntLeadTime()+" Allowed: 4");
														  LOG.info("tempData.getRowcellVal()>>>>>>>>>."+tempData.getRowcellVal());
												 errorDataList.add(tempData);
								     		}else if(PLMUtils.checkSplCharWhereUsed(templateData.getFillMntLeadTime())){
												  errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
														   +headerrow.getCell(i)+" Error Description: Special Characters of  "
														   +templateData.getFillMntLeadTime()+" are not Allowed  <br>");
												  PLMFmiTemplateData tempData = new PLMFmiTemplateData();
																  tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
																  tempData.setFieldName(headerrow.getCell(i).toString());
																  tempData.setErrorDesc("Error Description:  Error Description: Special Characters of "
														   +templateData.getFillMntLeadTime()+" are not Allowed");
																  LOG.info("tempData.getRowcellVal()>>>>>>>>>."+tempData.getRowcellVal());
														 errorDataList.add(tempData);
								     		}
											  break;
								     	case 19:
											if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
												templateData.setPrsText(Double
														.toString(currentcell.getNumericCellValue()));
											  }
											  else{
											       templateData.setPrsText(currentcell.getRichStringCellValue()
												      .toString());
											  }
											
											  if(templateData.getPrsText().length() > 2000){
								    		
												  errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
										   +headerrow.getCell(i)+" Error Description: Exceeds the Size Limit (Input value length: "
										   +templateData.getPrsText().length()+" Allowed: 2000 <br>");
												  PLMFmiTemplateData tempData = new PLMFmiTemplateData();
												  tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
												  tempData.setFieldName(headerrow.getCell(i).toString());
												  tempData.setErrorDesc("Error Description: Exceeds the Size Limit (Input value length: "
										   +templateData.getPrsText().length()+" Allowed: 2000");
												  LOG.info("tempData.getRowcellVal()>>>>>>>>>."+tempData.getRowcellVal());
										 errorDataList.add(tempData);
								    		  }
											break;
							
								     	case 20:
								     		if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
												templateData.setHoursEffort(String.valueOf((int)currentcell.getNumericCellValue()));
											  }
											  else{
											       templateData.setHoursEffort(currentcell.getRichStringCellValue()
												      .toString());
											  }
								     		
								     		 if(!PLMUtils.isIntegerFmi(templateData.getHoursEffort())){
												  errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
														   +headerrow.getCell(i)+" Error Description: Only Numeric value " +
													   		" is allowed for Hours Effort. Input value is : "
														   +templateData.getHoursEffort()+"<br>");
												  PLMFmiTemplateData tempData = new PLMFmiTemplateData();
																  tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
																  tempData.setFieldName(headerrow.getCell(i).toString());
																  tempData.setErrorDesc(" Error Description: Only Numeric value " +
																	   		" is allowed for Hours Effort. Input value is : "
																		   +templateData.getHoursEffort());
																  LOG.info("tempData.getRowcellVal()>>>>>>>>>."+tempData.getRowcellVal());
														 errorDataList.add(tempData);
										 } else if(templateData.getHoursEffort().length() > 4){
												  errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
												   +headerrow.getCell(i)+" Error Description: Exceeds the Size Limit (Input value length: "
												   +templateData.getHoursEffort()+" Allowed: 4 <br>");
												  PLMFmiTemplateData tempData = new PLMFmiTemplateData();
														  tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
														  tempData.setFieldName(headerrow.getCell(i).toString());
														  tempData.setErrorDesc("Error Description: Exceeds the Size Limit (Input value length: "
												   +templateData.getHoursEffort()+" Allowed: 4");
														  LOG.info("tempData.getRowcellVal()>>>>>>>>>."+tempData.getRowcellVal());
												 errorDataList.add(tempData);
								    	} else if(PLMUtils.checkSplCharWhereUsed(templateData.getHoursEffort())){
												  errormessage.append("Error: Row "+(row.getRowNum()+1)+": Field: "
														   +headerrow.getCell(i)+" Error Description: Special Characters of  "
														   +templateData.getHoursEffort()+" are not Allowed  <br>");
												  PLMFmiTemplateData tempData = new PLMFmiTemplateData();
																  tempData.setRowcellVal(String.valueOf(row.getRowNum()+1));
																  tempData.setFieldName(headerrow.getCell(i).toString());
																  tempData.setErrorDesc("Error Description:  Error Description: Special Characters of "
														   +templateData.getHoursEffort()+" are not Allowed");
																  LOG.info("tempData.getRowcellVal()>>>>>>>>>."+tempData.getRowcellVal());
														 errorDataList.add(tempData);
										   }
											break;
								    	   default:
											break;
										}
								    		
								    }		
								  }
								}
							
							}
						}
					}
				
			} catch (FileNotFoundException ex) {
				templateData.setTmpltErrorMsg("File Does not Exist");
			} catch (IOException ec) {
				templateData.setTmpltErrorMsg("Invalid Template Format");
			} finally {
				try {
					if (fis != null) {
						fis.close();
					}
				} catch (IOException e) {
					templateData.setTmpltErrorMsg("Invalid Template Format");
				}
			}
			LOG.info("Error Message " + errormessage.toString());
			templateData.setTmpltErrorMsg(errormessage.toString());
			LOG.info("Exiting validateFmiManageText Method");
		}
		
		/**
		 * This method is used for Reading Fmi Manage Text
		 * 
		 * @return String
		 */
		@SuppressWarnings("unchecked")
	public void readFmiManageText() {
			LOG.info("Entering readFmiManageText Method");
			StringBuilder errormessage = new StringBuilder();
			FileInputStream fis = null;
			fmiMngTextDataList=new ArrayList<PLMFmiTemplateData>();
			try {
				fis = new FileInputStream(templateData.getSrcfile());
				HSSFWorkbook workbook = new HSSFWorkbook(fis);
				HSSFSheet sheet = workbook.getSheetAt(0);
				Iterator rows = sheet.rowIterator();
				int totalcols = 22;
				int noofrecords = 0;
				while (rows.hasNext()) {
					templateData = new PLMFmiTemplateData();
					HSSFRow row = (HSSFRow) rows.next();
					if (row.getRowNum() == 0)
						continue;
					Iterator cells = row.cellIterator();
					if (cells.hasNext()) {
						HSSFCell cell = (HSSFCell) cells.next();
						if (cell.getColumnIndex() < totalcols) {
							for (int i = 7; i < totalcols; i++) {
								HSSFCell currentcell = row.getCell(i);
								if (currentcell == null) {
									if (PLMConstants.N_7==i) {
										templateData.setApplicableSymbol("");
									} else if (PLMConstants.N_8==i){
										templateData.setModidicationDesc("");
									}else if (PLMConstants.N_9==i){
										templateData.setFmiBenefits("");
									}else if (PLMConstants.N_10==i){
										templateData.setSpecialNotes("");
									}else if (PLMConstants.N_11==i){
										templateData.setRepairTextVal("");
									}else if (PLMConstants.N_12==i){
										templateData.setTextFeild("");
									}else if (PLMConstants.N_13==i){
										templateData.setSpecialTools("");
									}else if (PLMConstants.N_14==i){
										templateData.setServiceDoc("");
									}else if (PLMConstants.N_15==i){
										templateData.setFmiTextVal("");
									}else if (PLMConstants.N_16==i){
										templateData.setStdTaskDuration("");
										templateData.setIntstdTskDur(0);
									}else if (PLMConstants.N_17==i){
										templateData.setSmlrToPartQTC("");
									}else if (PLMConstants.N_18==i){
										templateData.setFillMntLeadTime("");
										templateData.setIntfillMntLdTime(0);
									}else if (PLMConstants.N_19==i){
										templateData.setPrsText("");
									}else if (PLMConstants.N_20==i){
										templateData.setHoursEffort("");
										templateData.setInthoursEffort(0);
									}else if (PLMConstants.N_21==i){
										templateData.setMliId("");
									}
									
									
								} else {

									if (PLMConstants.N_7==i) {
										templateData.setApplicableSymbol(currentcell.getRichStringCellValue().toString());
									} else if (PLMConstants.N_8==i) {
										templateData.setModidicationDesc(currentcell.getRichStringCellValue().toString());
									}else if (PLMConstants.N_9==i){
										templateData.setFmiBenefits(currentcell.getRichStringCellValue().toString());
									}else if (PLMConstants.N_10==i){
										templateData.setSpecialNotes(currentcell.getRichStringCellValue().toString());
									}else if (PLMConstants.N_11==i){
										templateData.setRepairTextVal(currentcell.getRichStringCellValue().toString());
									}else if (PLMConstants.N_12==i){
										templateData.setTextFeild(currentcell.getRichStringCellValue().toString());
									}else if (PLMConstants.N_13==i){
										templateData.setSpecialTools(currentcell.getRichStringCellValue().toString());
									}else if (PLMConstants.N_14==i){
										templateData.setServiceDoc(currentcell.getRichStringCellValue().toString());
									}else if (PLMConstants.N_15==i){
										templateData.setFmiTextVal(currentcell.getRichStringCellValue().toString());
									}else if (PLMConstants.N_16==i){
									  if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
										   templateData.setIntstdTskDur((int)currentcell.getNumericCellValue());
										  }else{
											 templateData.setIntstdTskDur(0);
										  }
									    
									}else if (PLMConstants.N_17==i){
										templateData.setSmlrToPartQTC(currentcell.getRichStringCellValue().toString());
									}else if (PLMConstants.N_18==i){
										 if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
											 templateData.setIntfillMntLdTime((int)currentcell.getNumericCellValue());
										  }else{
											 templateData.setIntfillMntLdTime(0);
										 }
										
									}else if (PLMConstants.N_19==i){
										templateData.setPrsText(currentcell.getRichStringCellValue().toString());
									}else if (PLMConstants.N_20==i){
										 if(currentcell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
											templateData.setInthoursEffort((int)currentcell.getNumericCellValue());
										 }else{
										   templateData.setInthoursEffort(0);
										 }										 
									}else if (PLMConstants.N_21==i){
										templateData.setMliId(currentcell.getRichStringCellValue().toString());
									}
								}
					
							}
						}
					}
					fmiMngTextDataList.add(noofrecords, templateData);
					noofrecords++;
				}
				LOG.info("noofrecords : " + noofrecords);
				if (fmiMngTextDataList.size() == 0)
					errormessage.append("No Records Found");
				
				} catch (FileNotFoundException ex) {
					errormessage.append("File Does not Exist");
				} catch (IOException ex1) {
					errormessage.append("Error Reading in File");
				} finally {
					try {
						if (fis != null)
							fis.close();
					} catch (IOException ex1) {
						errormessage.append("Error Reading in File");
						LOG.info("errormessage -->"+errormessage);
					}catch (Exception ex2) {
						errormessage.append("Error Reading in File");
					}
				}
			templateData.setTmpltErrorMsg(errormessage.toString());
			LOG.info("Exiting readFmiManageText Method");
		}
		
		
		
		/**
		 * This method is used for Bordering Cell in XLS
		 * 
		 * @return StringBuffer
		 */
		
		private HSSFCellStyle setBorderStyle(HSSFCellStyle style) {
			style.setBorderTop(HSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style.setBorderRight(HSSFCellStyle.BORDER_THIN);
			return style;
		}
		
		
		//Newly Added for FMI Applicability Report
		/**
		 * This method is used for getDropDownvalues for requirement and frameType
		 * 
		 * @return String
		 */
		public String getDropDownvaluesFmiAppRpt() {
			LOG.info("getDropDownvaluesFmiAppRpt() Method");
			String fwdFlag = "";
			alertMessage = "";
			allOpenReq=false;
			allOpenFrame=false;
			selfmiAppRequirment = new ArrayList<String>();
			selfmiAppFrame = new ArrayList<String>();
			totalRecordFmiAptMsg="";
			try {
				commonMB.insertCannedRptRecordHitInfo("FMI Applicability Report");
			} catch (PLMCommonException ex) {
				LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
			}
			
			try {
				 Map<String, List<SelectItem>> dropdownlist = plmDocGenService.getDropDownvaluesFmiAppRpt();
				 fmiAppRequirmentList = (List<SelectItem>) dropdownlist.get("requirementname");
				 fmiAppframeTypeList = (List<SelectItem>) dropdownlist.get("frametype");
				fwdFlag = "fmiAppRpt";
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getDropDownvaluesFmiAppRpt: ", exception);
				fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","FMI Applicability Report");
			} 
			
			return fwdFlag;
		}
		
		 /**
		 * This method is used for validateFMIAptReport
		 * 
		 * @return String
		 */
		public String  validateFMIAptReport(){
			alertMessage ="";
			if (PLMUtils.isEmptyList(selfmiAppRequirment) || PLMUtils.isEmptyList(selfmiAppFrame)) {
				alertMessage = "Please Select Both Requirement Name and Frame Type / select All Check boxs";
			} 
			
			return alertMessage;
		}
		
		/**
		 * This method is used for getDropDownvalues for requirement and frameType
		 * 
		 * @return String
		 */
		public String generateFmiAppReport() {
			LOG.info("get data from generateFmiAppReport() Method");
			String fwdFlag = "";
			alertMessage = "";
			totalRecordFmiAptMsg="";
			try { 
				 if (allOpenReq){
					 if(!PLMUtils.isEmptyList(fmiAppRequirmentList))
					      {
							selfmiAppRequirment = new ArrayList<String>();
							   for (int i = 0 ; i < fmiAppRequirmentList.size() ; i++ )
						  	     {
								String requireValue = fmiAppRequirmentList.get(i).getValue().toString();
								selfmiAppRequirment.add(requireValue);
							    }
					      }
				}
				
				if (allOpenFrame){
					 if(!PLMUtils.isEmptyList(fmiAppframeTypeList))
					      {
						 selfmiAppFrame = new ArrayList<String>();
							   for (int i = 0 ; i < fmiAppframeTypeList.size() ; i++ )
						  	     {
								String frameValue = fmiAppframeTypeList.get(i).getValue().toString();
								selfmiAppFrame.add(frameValue);
							    }
					      }
				}
			alertMessage = validateFMIAptReport();
				 if (PLMConstants.EMPTY.equals(alertMessage)) {
					fmiappReportList = plmDocGenService.generateFmiAppReport(selfmiAppRequirment,allOpenReq,selfmiAppFrame,allOpenFrame);
					 if(fmiappReportList.size()>0){
						 totalRecordFmiAptMsg="Total Records of FMI Applicability Report:: "+fmiappReportList.size();
		     		  fwdFlag = "fmiAppRptDetails";
					 }
					 else{
						 alertMessage = "No Records Found for the Selected combination";
						 fwdFlag = "fmiAppRpt";
					 }
				 }
				 else{
					 fwdFlag = "fmiAppRpt";
				 }
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@generateFmiAppReport: ", exception);
				fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","FMI Applicability Report");
			} 
			
			return fwdFlag;
		}
		
		public void downloadfmirptExcel() throws PLMCommonException {

			LOG.info("Entering downloadExcel Method");
			String fileName="FMI Applicability Report";
			LOG.info("fileName>>> " +fileName);
			
			
			
			PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
			
			if (!PLMUtils.isEmptyList(fmiappReportList)) {
				String[] frameTypeValue = fmiappReportList.get(0).getFrameTypeValue();
				
				PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[frameTypeValue.length+2] ;
				
				reportColumns[0] = new PLMXlsxRptColumn("fmiReqName", "FMI Requirement Name", FormatType.TEXT, null, null, 25);
				reportColumns[1] = new PLMXlsxRptColumn("fmiReqDesc", "FMI Requirement Description", FormatType.TEXT, null, null, 35);
				
				for (int i=0;i<frameTypeValue.length;i++) {
					reportColumns[i+2] =  new PLMXlsxRptColumn(String.valueOf(i),String.valueOf(i), FormatType.TEXT, null, null, 5);
				}
				excelUtil.export(fmiappReportList, reportColumns, fileName, fileName, false, null, null);
			}
					
		} 
		
		private XSSFFont headerFont(SXSSFWorkbook wb, int size){
			XSSFFont font = (XSSFFont) wb.createFont();
			font.setFontName(PLMConstants.EXCEL_FONT_NAME);
			font.setFontHeightInPoints((short)size);
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			return font;
		}
		
		private XSSFFont normalFont(SXSSFWorkbook wb, int size){
			XSSFFont font = (XSSFFont) wb.createFont();
			font.setFontName(PLMConstants.EXCEL_FONT_NAME);
			font.setFontHeightInPoints((short)size);
			return font;
		}
		
		private XSSFCellStyle headerCell(SXSSFWorkbook wb, XSSFFont font, short bgcolor, boolean wrap){
			XSSFCellStyle hCell = normalCell(wb, font, XSSFCellStyle.SOLID_FOREGROUND, wrap);
			//FONT
			hCell.setFont(font);
			
			//HORIZONTAL ALIGNMENT
			hCell.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			
			//COLOR
			hCell.setFillForegroundColor(bgcolor);
			return hCell;
		}
		
		private XSSFCellStyle normalCell(SXSSFWorkbook wb, XSSFFont font, short fillPattern, boolean wrap){
			// Cell Style
			XSSFCellStyle cellStyle = (XSSFCellStyle)wb.createCellStyle();
			
			//Set Font
			cellStyle.setFont(font);
			//WRAP TEXT
			cellStyle.setWrapText(wrap);
			
			//VERTICAL ALIGNMENT
			cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			
			//BORDERS
			cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			
			//FILL PATTERN
			cellStyle.setFillPattern(fillPattern);
			return cellStyle;
		}
		
		
		public void downloadFMIAppRptExcel() throws PLMCommonException {

				LOG.info("Entering downloadFMIAppRptExcel Method");
				FacesContext facesContext = FacesContext.getCurrentInstance();
			  	try {
					HttpServletResponse response = 
						(HttpServletResponse)facesContext.getExternalContext().getResponse();
					
					response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
					
					response.setHeader("Content-disposition", 
							"attachment; filename="+"FMI Applicability Report.xlsx");
					
					OutputStream outputStream = response.getOutputStream();
					
					SXSSFWorkbook workbook = new SXSSFWorkbook();
					
					XSSFFont font = headerFont(workbook, 10);
					
					// Header Style
					XSSFCellStyle headerStyle = headerCell(workbook, font, HSSFColor.PALE_BLUE.index, true);

					XSSFFont cellfont = normalFont(workbook, 10);
					// Cell Style
					XSSFCellStyle cellStyle = normalCell(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
					
					SXSSFSheet sheet =  (SXSSFSheet) workbook.createSheet("FmiApplicablityRpt");
					
					String[] colNames = new String[selfmiAppFrame.size()+2] ;
					
					colNames[0] = "FMI Requirement Name";
					colNames[1] = "FMI Requirement Description";
					
					for (int i=0;i<selfmiAppFrame.size();i++) {
						colNames[i+2] =  selfmiAppFrame.get(i);
					}
					
					int rowcount = 0;
					
					SXSSFCell cell=null;
				    
				    SXSSFRow row = (SXSSFRow) sheet.createRow(rowcount);				    
					
					for ( int i = 0 ; i < colNames.length; i++ ) {
						cell = (SXSSFCell)row.createCell(i);
						cell. setCellValue(colNames[i]);
						cell.setCellStyle(headerStyle);
					}
					
					
					for (int i=0;i<fmiappReportList.size();i++) {
						
						row = (SXSSFRow) sheet.createRow(++rowcount);

						cell = (SXSSFCell) row.createCell(0);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(fmiappReportList.get(i).getFmiReqName());
						
						cell = (SXSSFCell) row.createCell(1);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(fmiappReportList.get(i).getFmiReqDesc());
						
						String[] dataValArr = fmiappReportList.get(i).getFrameTypeValue(); 
						
						for ( int j = 0 ; j < dataValArr.length; j++ ) {

							cell = (SXSSFCell) row.createCell(j+2);
							cell.setCellStyle(cellStyle);
							cell.setCellValue(dataValArr[j]);
							
						}
					}
									
					row = (SXSSFRow) sheet.createRow(++rowcount);
					row = (SXSSFRow) sheet.createRow(++rowcount);
					
				    XSSFCellStyle ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
				    ftrStyle.setFont(font);
				    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
				    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
				    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
				    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
				    cell.setCellStyle(ftrStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_THREE));
					
					sheet.createFreezePane( 0, 1 );
					sheet.setColumnWidth(0, 22*256);
					sheet.setColumnWidth(1, 40*256);
					for ( int j = 0 ; j < colNames.length; j++ ) {
						sheet.setColumnWidth(j+2,5*256);
					}
					
					workbook.write(outputStream);
					
					outputStream.flush();
					
					outputStream.close();
					
				} catch (IOException ioex) {
					ioex.printStackTrace();
				} finally {
					facesContext.responseComplete();
			  	}
				LOG.info("Exiting downloadFMIAppRptExcel Method");
	
		} 
		
		public void resetFmiAppReport(){
			alertMessage = "";
			allOpenReq=false;
			allOpenFrame=false;
			totalRecordFmiAptMsg="";
			selfmiAppRequirment = new ArrayList<String>();
			selfmiAppFrame = new ArrayList<String>();
			
		}

	/**
	 * @return the templateData
	 */
	public PLMFmiTemplateData getTemplateData() {
		return templateData;
	}

	/**
	 * @param templateData
	 */
	public void setTemplateData(PLMFmiTemplateData templateData) {
		this.templateData = templateData;
	}

	/**
	 * @return the returnmsg
	 */
	public String getReturnmsg() {
		return returnmsg;
	}

	/**
	 * @param returnmsg
	 *            the returnmsg to set
	 */
	public void setReturnmsg(String returnmsg) {
		this.returnmsg = returnmsg;
	}

	/**
	 * @return the fileexists
	 */
	public String getFileexists() {
		return fileexists;
	}

	/**
	 * @param fileexists
	 *            the fileexists to set
	 */
	public void setFileexists(String fileexists) {
		this.fileexists = fileexists;
	}

	/**
	 * @return the textData
	 */
	public PLMFmiTextData getTextData() {
		return textData;
	}

	/**
	 * @param textData
	 *            the textData to set
	 */
	public void setTextData(PLMFmiTextData textData) {
		this.textData = textData;
	}

	/**
	 * @return the textDataList
	 */
	public List<PLMFmiTextData> getTextDataList() {
		return textDataList;
	}

	/**
	 * @param textDataList
	 *            the textDataList to set
	 */
	public void setTextDataList(List<PLMFmiTextData> textDataList) {
		this.textDataList = textDataList;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage
	 *            the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the alertMessage the alertMessage to set
	 */
	public PLMDocGenServiceIfc getPlmDocGenService() {
		return plmDocGenService;
	}

	/**
	 * @param alertMessage
	 *            the alertMessage to set
	 */
	public void setPlmDocGenService(PLMDocGenServiceIfc plmDocGenService) {
		this.plmDocGenService = plmDocGenService;
	}

	/**
	 * @return the fmidetails
	 */
	public PLMDocGenFmiData getFmidetails() {
		return fmidetails;
	}

	/**
	 * @param alertMessage
	 *            the fmidetails to set
	 */
	public void setFmidetails(PLMDocGenFmiData fmidetails) {
		this.fmidetails = fmidetails;
	}

	/**
	 * @return the searchResultList
	 */
	public List<PLMDocGenFmiData> getSearchResultList() {
		return searchResultList;
	}

	/**
	 * @param alertMessage
	 *            the searchResultList to set
	 */
	public void setSearchResultList(List<PLMDocGenFmiData> searchResultList) {
		this.searchResultList = searchResultList;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the contractnumber
	 */
	public String getContractnumber() {
		return contractnumber;
	}
	/**
	 * @param contractnumber the contractnumber to set
	 */
	public void setContractnumber(String contractnumber) {
		this.contractnumber = contractnumber;
	}
	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	/**
	 * @return Returns the contractNo.
	 */
	public String getContractNo() {
		return contractNo;
	}

	/**
	 * @param contractNo The contractNo to set.
	 */
	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	/**
	 * @return Returns the taskExecutor.
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor The taskExecutor to set.
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return Returns the partsCount.
	 */
	public int getPartsCount() {
		return partsCount;
	}

	/**
	 * @param partsCount The partsCount to set.
	 */
	public void setPartsCount(int partsCount) {
		this.partsCount = partsCount;
	}

	/**
	 * @return Returns the mltplPartsForCntrctMsg.
	 */
	public String getMltplPartsForCntrctMsg() {
		return mltplPartsForCntrctMsg;
	}

	/**
	 * @param mltplPartsForCntrctMsg The mltplPartsForCntrctMsg to set.
	 */
	public void setMltplPartsForCntrctMsg(String mltplPartsForCntrctMsg) {
		this.mltplPartsForCntrctMsg = mltplPartsForCntrctMsg;
	}

	/**
	 * @return Returns the partsForContractList.
	 */
	public List<PLMBomSalesData> getPartsForContractList() {
		return partsForContractList;
	}

	/**
	 * @param partsForContractList The partsForContractList to set.
	 */
	public void setPartsForContractList(List<PLMBomSalesData> partsForContractList) {
		this.partsForContractList = partsForContractList;
	}

	/**
	 * @return the partsForProjectList
	 */
	public List<PLMBomSalesData> getPartsForProjectList() {
		return partsForProjectList;
	}

	/**
	 * @param partsForProjectList the partsForProjectList to set
	 */
	public void setPartsForProjectList(List<PLMBomSalesData> partsForProjectList) {
		this.partsForProjectList = partsForProjectList;
	}
	
	/**
	 * @return
	 */
	/*public String getAlertMsg() {
		return alertMsg;
	}*/

	/**
	 * @param alertMsg
	 */
	/*public void setAlertMsg(String alertMsg) {
		this.alertMsg = alertMsg;
	}*/

	/**
	 * @return the projectNo
	 */
	public String getProjectNo() {
		return projectNo;
	}

	/**
	 * @param projectNo the projectNo to set
	 */
	public void setProjectNo(String projectNo) {
		this.projectNo = projectNo;
	}

	/**
	 * @return the mltplPartsForProjectMsg
	 */
	public String getMltplPartsForProjectMsg() {
		return mltplPartsForProjectMsg;
	}

	/**
	 * @param mltplPartsForProjectMsg the mltplPartsForProjectMsg to set
	 */
	public void setMltplPartsForProjectMsg(String mltplPartsForProjectMsg) {
		this.mltplPartsForProjectMsg = mltplPartsForProjectMsg;
	}

	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}

	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}

	
	/**
	 * @return the levelList
	 */
	public List<SelectItem> getLevelList() {
		return levelList;
	}

	/**
	 * @param levelList the levelList to set
	 */
	public void setLevelList(List<SelectItem> levelList) {
		this.levelList = levelList;
	}

	/**
	 * @return the requirementList
	 */
	public List<SelectItem> getRequirementList() {
		return requirementList;
	}

	/**
	 * @param requirementList the requirementList to set
	 */
	public void setRequirementList(List<SelectItem> requirementList) {
		this.requirementList = requirementList;
	}

	/**
	 * @return the selRequirment
	 */
	public List<String> getSelRequirment() {
		return selRequirment;
	}

	/**
	 * @param selRequirment the selRequirment to set
	 */
	public void setSelRequirment(List<String> selRequirment) {
		this.selRequirment = selRequirment;
	}

	/**
	 * @return the ceiNameList
	 */
	public List<SelectItem> getCeiNameList() {
		return ceiNameList;
	}

	/**
	 * @param ceiNameList the ceiNameList to set
	 */
	public void setCeiNameList(List<SelectItem> ceiNameList) {
		this.ceiNameList = ceiNameList;
	}

	/**
	 * @return the selCei
	 */
	public List<String> getSelCei() {
		return selCei;
	}

	/**
	 * @param selCei the selCei to set
	 */
	public void setSelCei(List<String> selCei) {
		this.selCei = selCei;
	}

	/**
	 * @return the tempselection
	 */
	public List<String> getTempselection() {
		return tempselection;
	}

	/**
	 * @param tempselection the tempselection to set
	 */
	public void setTempselection(List<String> tempselection) {
		this.tempselection = tempselection;
	}

	/**
	 * @return the mliNameList
	 */
	public List<SelectItem> getMliNameList() {
		return mliNameList;
	}

	/**
	 * @param mliNameList the mliNameList to set
	 */
	public void setMliNameList(List<SelectItem> mliNameList) {
		this.mliNameList = mliNameList;
	}

	/**
	 * @return the selMli
	 */
	public List<String> getSelMli() {
		return selMli;
	}

	/**
	 * @param selMli the selMli to set
	 */
	public void setSelMli(List<String> selMli) {
		this.selMli = selMli;
	}

	/**
	 * @return the mliFlag
	 */
	public boolean isMliFlag() {
		return mliFlag;
	}

	/**
	 * @param mliFlag the mliFlag to set
	 */
	public void setMliFlag(boolean mliFlag) {
		this.mliFlag = mliFlag;
	}

	/**
	 * @return the ceiFlag
	 */
	public boolean isCeiFlag() {
		return ceiFlag;
	}

	/**
	 * @param ceiFlag the ceiFlag to set
	 */
	public void setCeiFlag(boolean ceiFlag) {
		this.ceiFlag = ceiFlag;
	}

	/**
	 * @return the reqCeiNamesList
	 */
	public List<PLMFmiTemplateData> getReqCeiNamesList() {
		return reqCeiNamesList;
	}

	/**
	 * @param reqCeiNamesList the reqCeiNamesList to set
	 */
	public void setReqCeiNamesList(List<PLMFmiTemplateData> reqCeiNamesList) {
		this.reqCeiNamesList = reqCeiNamesList;
	}

	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/**
	 * @return the recordCount
	 */
	public int getRecordCount() {
		return recordCount;
	}

	/**
	 * @param recordCount the recordCount to set
	 */
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	/**
	 * @return the fmiId
	 */
	public String getFmiId() {
		return fmiId;
	}

	/**
	 * @param fmiId the fmiId to set
	 */
	public void setFmiId(String fmiId) {
		this.fmiId = fmiId;
	}

	/**
	 * @return the selRequiremntList
	 */
	public List<PLMFmiTemplateData> getSelRequiremntList() {
		return selRequiremntList;
	}

	/**
	 * @param selRequiremntList the selRequiremntList to set
	 */
	public void setSelRequiremntList(List<PLMFmiTemplateData> selRequiremntList) {
		this.selRequiremntList = selRequiremntList;
	}

	/**
	 * @return the reqCeiMliNamesList
	 */
	public List<PLMFmiTemplateData> getReqCeiMliNamesList() {
		return reqCeiMliNamesList;
	}

	/**
	 * @param reqCeiMliNamesList the reqCeiMliNamesList to set
	 */
	public void setReqCeiMliNamesList(List<PLMFmiTemplateData> reqCeiMliNamesList) {
		this.reqCeiMliNamesList = reqCeiMliNamesList;
	}

	/**
	 * @return the fmiMngTextDataList
	 */
	public List<PLMFmiTemplateData> getFmiMngTextDataList() {
		return fmiMngTextDataList;
	}

	/**
	 * @param fmiMngTextDataList the fmiMngTextDataList to set
	 */
	public void setFmiMngTextDataList(List<PLMFmiTemplateData> fmiMngTextDataList) {
		this.fmiMngTextDataList = fmiMngTextDataList;
	}

	/**
	 * @return the errorDataList
	 */
	public List<PLMFmiTemplateData> getErrorDataList() {
		return errorDataList;
	}

	/**
	 * @param errorDataList the errorDataList to set
	 */
	public void setErrorDataList(List<PLMFmiTemplateData> errorDataList) {
		this.errorDataList = errorDataList;
	}

	/**
	 * @return the selCeiName
	 */
	public String getSelCeiName() {
		return selCeiName;
	}

	/**
	 * @param selCeiName the selCeiName to set
	 */
	public void setSelCeiName(String selCeiName) {
		this.selCeiName = selCeiName;
	}

	/**
	 * @return the selCeiNameList
	 */
	public List<SelectItem> getSelCeiNameList() {
		return selCeiNameList;
	}

	/**
	 * @param selCeiNameList the selCeiNameList to set
	 */
	public void setSelCeiNameList(List<SelectItem> selCeiNameList) {
		this.selCeiNameList = selCeiNameList;
	}

	/**
	 * @return the selMliName
	 */
	public String getSelMliName() {
		return selMliName;
	}

	/**
	 * @param selMliName the selMliName to set
	 */
	public void setSelMliName(String selMliName) {
		this.selMliName = selMliName;
	}

	/**
	 * @return the selMliNameList
	 */
	public List<SelectItem> getSelMliNameList() {
		return selMliNameList;
	}

	/**
	 * @param selMliNameList the selMliNameList to set
	 */
	public void setSelMliNameList(List<SelectItem> selMliNameList) {
		this.selMliNameList = selMliNameList;
	}

	/**
	 * @return the selReqName
	 */
	public String getSelReqName() {
		return selReqName;
	}

	/**
	 * @param selReqName the selReqName to set
	 */
	public void setSelReqName(String selReqName) {
		this.selReqName = selReqName;
	}

	/**
	 * @return the selectCeiName
	 */
	public String getSelectCeiName() {
		return selectCeiName;
	}

	/**
	 * @param selectCeiName the selectCeiName to set
	 */
	public void setSelectCeiName(String selectCeiName) {
		this.selectCeiName = selectCeiName;
	}

	/**
	 * @return the reqId
	 */
	public String getReqId() {
		return reqId;
	}

	/**
	 * @param reqId the reqId to set
	 */
	public void setReqId(String reqId) {
		this.reqId = reqId;
	}

	/**
	 * @return the reqSeqId
	 */
	public String getReqSeqId() {
		return reqSeqId;
	}

	/**
	 * @param reqSeqId the reqSeqId to set
	 */
	public void setReqSeqId(String reqSeqId) {
		this.reqSeqId = reqSeqId;
	}

	/**
	 * @return the totalSelRequireCnt
	 */
	public int getTotalSelRequireCnt() {
		return totalSelRequireCnt;
	}

	/**
	 * @param totalSelRequireCnt the totalSelRequireCnt to set
	 */
	public void setTotalSelRequireCnt(int totalSelRequireCnt) {
		this.totalSelRequireCnt = totalSelRequireCnt;
	}

	/**
	 * @return the totalSelRequireCeiCnt
	 */
	public int getTotalSelRequireCeiCnt() {
		return totalSelRequireCeiCnt;
	}

	/**
	 * @param totalSelRequireCeiCnt the totalSelRequireCeiCnt to set
	 */
	public void setTotalSelRequireCeiCnt(int totalSelRequireCeiCnt) {
		this.totalSelRequireCeiCnt = totalSelRequireCeiCnt;
	}

	/**
	 * @return the totalSelRequireCeiMliCnt
	 */
	public int getTotalSelRequireCeiMliCnt() {
		return totalSelRequireCeiMliCnt;
	}

	/**
	 * @param totalSelRequireCeiMliCnt the totalSelRequireCeiMliCnt to set
	 */
	public void setTotalSelRequireCeiMliCnt(int totalSelRequireCeiMliCnt) {
		this.totalSelRequireCeiMliCnt = totalSelRequireCeiMliCnt;
	}



	/**
	 * @return the fmiAppRequirmentList
	 */
	public List<SelectItem> getFmiAppRequirmentList() {
		return fmiAppRequirmentList;
	}



	/**
	 * @param fmiAppRequirmentList the fmiAppRequirmentList to set
	 */
	public void setFmiAppRequirmentList(List<SelectItem> fmiAppRequirmentList) {
		this.fmiAppRequirmentList = fmiAppRequirmentList;
	}



	/**
	 * @return the fmiAppframeTypeList
	 */
	public List<SelectItem> getFmiAppframeTypeList() {
		return fmiAppframeTypeList;
	}



	/**
	 * @param fmiAppframeTypeList the fmiAppframeTypeList to set
	 */
	public void setFmiAppframeTypeList(List<SelectItem> fmiAppframeTypeList) {
		this.fmiAppframeTypeList = fmiAppframeTypeList;
	}



	/**
	 * @return the selfmiAppRequirment
	 */
	public List<String> getSelfmiAppRequirment() {
		return selfmiAppRequirment;
	}



	/**
	 * @param selfmiAppRequirment the selfmiAppRequirment to set
	 */
	public void setSelfmiAppRequirment(List<String> selfmiAppRequirment) {
		this.selfmiAppRequirment = selfmiAppRequirment;
	}



	/**
	 * @return the selfmiAppFrame
	 */
	public List<String> getSelfmiAppFrame() {
		return selfmiAppFrame;
	}



	/**
	 * @param selfmiAppFrame the selfmiAppFrame to set
	 */
	public void setSelfmiAppFrame(List<String> selfmiAppFrame) {
		this.selfmiAppFrame = selfmiAppFrame;
	}



	/**
	 * @return the fmiappReportList
	 */
	public List<PLMFmiAppReportData> getFmiappReportList() {
		return fmiappReportList;
	}



	/**
	 * @param fmiappReportList the fmiappReportList to set
	 */
	public void setFmiappReportList(List<PLMFmiAppReportData> fmiappReportList) {
		this.fmiappReportList = fmiappReportList;
	}



	/**
	 * @return the allOpenReq
	 */
	public boolean isAllOpenReq() {
		return allOpenReq;
	}



	/**
	 * @param allOpenReq the allOpenReq to set
	 */
	public void setAllOpenReq(boolean allOpenReq) {
		this.allOpenReq = allOpenReq;
	}



	/**
	 * @return the allOpenFrame
	 */
	public boolean isAllOpenFrame() {
		return allOpenFrame;
	}



	/**
	 * @param allOpenFrame the allOpenFrame to set
	 */
	public void setAllOpenFrame(boolean allOpenFrame) {
		this.allOpenFrame = allOpenFrame;
	}



	/**
	 * @return the totalRecordFmiAptMsg
	 */
	public String getTotalRecordFmiAptMsg() {
		return totalRecordFmiAptMsg;
	}



	/**
	 * @param totalRecordFmiAptMsg the totalRecordFmiAptMsg to set
	 */
	public void setTotalRecordFmiAptMsg(String totalRecordFmiAptMsg) {
		this.totalRecordFmiAptMsg = totalRecordFmiAptMsg;
	}
	/**
	 * @return the ceiBulkData
	 */
	public DataModel getCeiBulkData() {
		return ceiBulkData;
	}

	/**
	 * @param ceiBulkData the ceiBulkData to set
	 */
	public void setCeiBulkData(DataModel ceiBulkData) {
		this.ceiBulkData = ceiBulkData;
	}
	/**
	 * @return the mliBulkData
	 */
	public DataModel getMliBulkData() {
		return mliBulkData;
	}
	/**
	 * @param mliBulkData the mliBulkData to set
	 */
	public void setMliBulkData(DataModel mliBulkData) {
		this.mliBulkData = mliBulkData;
	}
	/**
	 * @return the ceiVal
	 */
	public UIDataTable getCeiVal() {
		return ceiVal;
	}
	/**
	 * @param ceiVal the ceiVal to set
	 */
	public void setCeiVal(UIDataTable ceiVal) {
		this.ceiVal = ceiVal;
	}
	/**
	 * @return the mliVal
	 */
	public UIDataTable getMliVal() {
		return mliVal;
	}
	/**
	 * @param mliVal the mliVal to set
	 */
	public void setMliVal(UIDataTable mliVal) {
		this.mliVal = mliVal;
	}

	/**
	 * @return the rowIndexMliLink
	 */
	public HtmlAjaxCommandButton getRowIndexMliLink() {
		return rowIndexMliLink;
	}
	/**
	 * @param rowIndexMliLink the rowIndexMliLink to set
	 */
	public void setRowIndexMliLink(HtmlAjaxCommandButton rowIndexMliLink) {
		this.rowIndexMliLink = rowIndexMliLink;
	}
	/**
	 * @return the rowIndexCeiLink
	 */
	public HtmlAjaxCommandButton getRowIndexCeiLink() {
		return rowIndexCeiLink;
	}
	/**
	 * @param rowIndexCeiLink the rowIndexCeiLink to set
	 */
	public void setRowIndexCeiLink(HtmlAjaxCommandButton rowIndexCeiLink) {
		this.rowIndexCeiLink = rowIndexCeiLink;
	}
	/**
	 * @return the bulkCeiCount
	 */
	public int getBulkCeiCount() {
		return bulkCeiCount;
	}
	/**
	 * @param bulkCeiCount the bulkCeiCount to set
	 */
	public void setBulkCeiCount(int bulkCeiCount) {
		this.bulkCeiCount = bulkCeiCount;
	}
	/**
	 * @return the bulkMliCount
	 */
	public int getBulkMliCount() {
		return bulkMliCount;
	}
	/**
	 * @param bulkMliCount the bulkMliCount to set
	 */
	public void setBulkMliCount(int bulkMliCount) {
		this.bulkMliCount = bulkMliCount;
	}



	/**
	 * @return the reqBulkData
	 */
	public DataModel getReqBulkData() {
		return reqBulkData;
	}

	/**
	 * @param reqBulkData the reqBulkData to set
	 */
	public void setReqBulkData(DataModel reqBulkData) {
		this.reqBulkData = reqBulkData;
	}

	/**
	 * @return the rowIndexReqLink
	 */
	public HtmlAjaxCommandButton getRowIndexReqLink() {
		return rowIndexReqLink;
	}

	/**
	 * @param rowIndexReqLink the rowIndexReqLink to set
	 */
	public void setRowIndexReqLink(HtmlAjaxCommandButton rowIndexReqLink) {
		this.rowIndexReqLink = rowIndexReqLink;
	}
	/**
	 * @return the bulkReqCount
	 */
	public int getBulkReqCount() {
		return bulkReqCount;
	}

	/**
	 * @param bulkReqCount the bulkReqCount to set
	 */
	public void setBulkReqCount(int bulkReqCount) {
		this.bulkReqCount = bulkReqCount;
	}
	/**
	 * @return the unitSerialNum
	 */
	public String getUnitSerialNum() {
		return unitSerialNum;
	}
	/**
	 * @param unitSerialNum the unitSerialNum to set
	 */
	public void setUnitSerialNum(String unitSerialNum) {
		this.unitSerialNum = unitSerialNum;
	}
	/**
	 * @return the contractList
	 */
	public List<PLMBomSalesData> getContractList() {
		return contractList;
	}
	/**
	 * @param contractList the contractList to set
	 */
	public void setContractList(List<PLMBomSalesData> contractList) {
		this.contractList = contractList;
	}
	/**
	 * @return the totalContractsCnt
	 */
	public int getTotalContractsCnt() {
		return totalContractsCnt;
	}
	/**
	 * @param totalContractsCnt the totalContractsCnt to set
	 */
	public void setTotalContractsCnt(int totalContractsCnt) {
		this.totalContractsCnt = totalContractsCnt;
	}
	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}
	/**
	 * @param recordCounts the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}
}