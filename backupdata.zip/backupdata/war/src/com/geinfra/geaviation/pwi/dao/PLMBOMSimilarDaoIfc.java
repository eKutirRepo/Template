/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBOMSimilarDaoIfc.java
 * @Creation date: 28-Oct-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.geinfra.geaviation.pwi.data.PLMBOMSimilarData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMBOMSimilarDaoIfc {
	/**
	 * This method is used to get getBOMSmrltyRptDetails
	 * 
	 * @param partGrpInterst,bomMatchLvl
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<PLMBOMSimilarData>> getBOMSmrltyRptDetails(String partGrpInterst,String bomMatchLvl,Date efftStrDate, Date efftEndDate) throws PLMCommonException;

}
