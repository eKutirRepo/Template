/**
 * Copyright (C) 2014 GE Infra. All rights reserved
 * 
 * @FileName PLMBomDfctRptServiceImpl.java
 * @Creation date: 15-July-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.service;

import java.util.List;

import com.geinfra.geaviation.pwi.dao.PLMBomDfctRptDaoIfc;
import com.geinfra.geaviation.pwi.data.PLMBomDfctRptData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public class PLMBomDfctRptServiceImpl implements PLMBomDfctRptServiceIfc{
	
	/**
	 * Holds the PLMBomDfctRptDaoIfc plmBomDfctRptDao
	 */
	private PLMBomDfctRptDaoIfc plmBomDfctRptDao = null;

	/**
	 * This method is used to check for valid partNumber.
	 * 
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<String> checkForValidPartNum(String partNumber)throws PLMCommonException{
		return plmBomDfctRptDao.checkForValidPartNum(partNumber);
	}
	/**
	 * This method is used to get BOM Defect report
	 * 
	 * @param partId
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomDfctRptData> getBomDefectRpt(String partId) throws PLMCommonException{
		return plmBomDfctRptDao.getBomDefectRpt(partId);
	}

	
	/**
	 * @return the plmBomDfctRptDao
	 */
	public PLMBomDfctRptDaoIfc getPlmBomDfctRptDao() {
		return plmBomDfctRptDao;
	}
	/**
	 * @param plmBomDfctRptDao the plmBomDfctRptDao to set
	 */
	public void setPlmBomDfctRptDao(PLMBomDfctRptDaoIfc plmBomDfctRptDao) {
		this.plmBomDfctRptDao = plmBomDfctRptDao;
	}

}
