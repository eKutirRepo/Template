/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEcoMetricsDaoImpl.java
 * @Creation date: 02-July-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMEcoMetricsData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMMetricsQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMEcoMetricsDaoImpl extends SimpleJdbcDaoSupport implements PLMEcoMetricsDaoIfc {
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMEcoMetricsDaoImpl.class);
	/**
	 * Holds the String value specifying start of week.
	 */
	String weekstart = PLMUtils.getFormatedDate("wstart");
	/**
	 * Holds the String value specifying end of week.
	 */
	String weekend = PLMUtils.getFormatedDate("wend");
	/**
	 * Holds the String value specifying start of month.
	 */
	String monthstart = PLMUtils.getFormatedDate("mstart");
	/**
	 * Holds the String value specifying end of month.
	 */
	String monthend = PLMUtils.getFormatedDate("mend");
	/**
	 * Holds the String value specifying start of year.
	 */
	String yearstart = PLMUtils.getFormatedDate("ystart");
	/**
	 * Holds the String value specifying end of year.
	 */
	String yearend = PLMUtils.getFormatedDate("yend");
	/**
	 * This method is used to ecoCatfilterUnorderedLevels
	 * @param templist
	 * @return java.util.List
	 */
	public List<PLMEcoMetricsData> ecoCatfilterUnorderedLevels (List<PLMEcoMetricsData> templist)
	{
		LOG.info("Entering ecoCatfilterUnorderedLevels of DaoImpl");
		List<PLMEcoMetricsData> returnlist = new ArrayList<PLMEcoMetricsData>();
		if(!PLMUtils.isEmptyList(templist))
		{
			for(int i=0;i<templist.size();i++)
			{
				//LOG.info("Size of Array " + templist.size());
				for (int j=i+1;j<templist.size();j++)
				  {
					if(templist.get(i).getName()== null && templist.get(i).getSso()==null )
					continue;
					if(templist.get(i).getName().equalsIgnoreCase(templist.get(j).getName()))
						{
						if(templist.get(j).getName()== null && templist.get(j).getSso()== null)
						continue;	
						templist.get(i).setMissingreqerror(templist.get(i).getMissingreqerror() + templist.get(j).getMissingreqerror());
						templist.get(i).setProductimprovement(templist.get(i).getProductimprovement() + templist.get(j).getProductimprovement());
						templist.get(i).setUnassigned(templist.get(i).getUnassigned() + templist.get(j).getUnassigned());
						templist.get(i).setInitialrelease(templist.get(i).getInitialrelease() + templist.get(j).getInitialrelease());
						templist.get(i).setCustomerchange(templist.get(i).getCustomerchange() + templist.get(j).getCustomerchange());
						templist.get(i).setOwner(false);
						templist.get(i).setExpand(true);
						templist.get(i).setCollapse(false);
						templist.get(j).setName(null);templist.get(j).setSso(null);
						}
				  }
			}
		}
		
		if(!PLMUtils.isEmptyList(templist))
		{
			LOG.info("Size of Templist " + templist.size());
			for(int i=0;i<templist.size();i++)
			{
			if(templist.get(i).getName()!= null && templist.get(i).getSso()!=null)
			{
			returnlist.add(templist.get(i));
			}
			}
		}
		if(!PLMUtils.isEmptyList(templist))
		{
			LOG.info("Size of Returnlist " + returnlist.size());
			for(int i=0;i<returnlist.size();i++)
			{
				returnlist.get(i).setRowIndex(i);
				int sum = returnlist.get(i).getMissingreqerror() + returnlist.get(i).getProductimprovement()+returnlist.get(i).getUnassigned()+returnlist.get(i).getInitialrelease()+returnlist.get(i).getCustomerchange();
				if(sum==0)
				{
				returnlist.get(i).setOwner(true);
				returnlist.get(i).setExpand(false);
				returnlist.get(i).setCollapse(false);	
				}
			}
		}
		LOG.info("Exiting ecoCatfilterUnorderedLevels of DaoImpl");
		return returnlist;
		}
	/**
	 * This method is used to loadEcoCategoryDetailReport
	 * @param ecocategorydata
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<String> loadEcoCategoryDetailReport(PLMEcoMetricsData ecocategorydata) throws PLMCommonException {
		LOG.info("Entering loadEcoCategoryDetailReport of DaoImpl");
		List<String> econameslist = new ArrayList<String>();
		try{
		String selectedsso = PLMUtils.removeHash(ecocategorydata.getSelectedsso());
		LOG.info("Selected SSO :" + selectedsso);
		String criteria =  ecocategorydata.getCriteria();
		LOG.info("Selected criteria :" + criteria);
		if(selectedsso.equalsIgnoreCase("OTHER"))
		{
			LOG.info("Pulling ECO names for Other : " + PLMMetricsQueries.GET_ECOCAT_OTHER_ECONAMES);
			econameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOCAT_OTHER_ECONAMES,new EconameMapper(),new Object[] {criteria,criteria});
		}
		else
		{
			LOG.info("Pulling ECO names : " + PLMMetricsQueries.GET_ECOCAT_ECONAMES);
			econameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOCAT_ECONAMES,new EconameMapper(),new Object[] { criteria, selectedsso, selectedsso, selectedsso,selectedsso,selectedsso,selectedsso,selectedsso,selectedsso });
		}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting loadEcoCategoryDetailReport of DaoImpl");
		return econameslist;
	}
	/**
	 * @return String value.
	 */
	private static final class EconameMapper implements ParameterizedRowMapper<String> {
//	private static ParameterizedRowMapper<String> econamemapper = new ParameterizedRowMapper<String>() {
		public String mapRow(ResultSet rs, int rowCount) throws SQLException {
			String econames = rs.getString("ECO_NAME");
			return econames;
		}
	}
	/**
	 * This method is used to loadEcoCategoryReport
	 * @param ecocategorydata, ecocategorylist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> loadEcoCategoryReport(PLMEcoMetricsData ecocategorydata,List<PLMEcoMetricsData> ecocategorylist) throws PLMCommonException {
		List<PLMEcoMetricsData> ecocatgrylist = new ArrayList<PLMEcoMetricsData>();
		try{
		LOG.info("Entering loadEcoCategoryReport of DaoImpl : "+PLMMetricsQueries.GET_ECOCAT_VPDETAILS);
		ecocatgrylist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOCAT_VPDETAILS,new EcocatvpMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting loadEcoCategoryReport of DaoImpl");
		return ecocatgrylist;
	}
	/**
	 * @return PLMEcoMetricsData objects.
	 */
	private static final class EcocatvpMapper implements ParameterizedRowMapper<PLMEcoMetricsData> {
//	private static ParameterizedRowMapper<PLMEcoMetricsData> ecocatvpmapper = new ParameterizedRowMapper<PLMEcoMetricsData>() {
		public PLMEcoMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMEcoMetricsData tempecocatdata = new PLMEcoMetricsData();
			tempecocatdata.setName(PLMUtils.checkNullVal(rs.getString("VP_NM")).trim());
			tempecocatdata.setSso(PLMUtils.checkNullVal(rs.getString("VP_NO")));
			tempecocatdata.setMissingreqerror(rs.getInt("MISSING_REQ"));
			tempecocatdata.setProductimprovement(rs.getInt("PRODUCT_IMPROVEMENT"));
			tempecocatdata.setUnassigned(rs.getInt("UNASSIGNED"));
			tempecocatdata.setInitialrelease(rs.getInt("INITIAL_RELEASE"));
			tempecocatdata.setCustomerchange(rs.getInt("CUSTOMER_CHANGE"));
			tempecocatdata.setRowIndex(rs.getRow()-1);
			tempecocatdata.setExpand(true);
			tempecocatdata.setOwner(false);
			tempecocatdata.setCollapse(false);
			if(tempecocatdata.getName().equalsIgnoreCase("OTHER") && tempecocatdata.getSso().equalsIgnoreCase("OTHER"))
			{
				tempecocatdata.setOwner(true);
				tempecocatdata.setExpand(false);
				tempecocatdata.setCollapse(false);
			}
			tempecocatdata.setSso(PLMUtils.appendHash(tempecocatdata.getSso()));
			return tempecocatdata;
		}
	}
	/**
	 * This method is used to ecoCatExpandVp
	 * @param ecocategorydata, ecocategorylist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoCatExpandVp(PLMEcoMetricsData ecocategorydata,List<PLMEcoMetricsData> ecocategorylist) throws PLMCommonException {
		LOG.info("Entering ecoCatExpandVp of DaoImpl");
		try{
		int vpindex =  ecocategorydata.getVpIndex();
		String selectedsso = PLMUtils.removeHash(ecocategorydata.getSelectedsso());
		LOG.info("Selected VP :"+selectedsso);
		LOG.info("VP index :" + vpindex);
		LOG.info("ECO Category Expansion Query for VP : " + PLMMetricsQueries.GET_ECOCAT_GMDETAILS);
		List<PLMEcoMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOCAT_GMDETAILS,new EcocatgmMapper(),selectedsso,selectedsso);
		templist = ecoCatfilterUnorderedLevels (templist);
		if(!PLMUtils.isEmptyList(templist))
			{
				ecocategorylist.get(vpindex).setGmTable(templist);
			  	ecocategorylist.get(vpindex).setCollapse(true);
			  	ecocategorylist.get(vpindex).setExpand(false);
			 }
		} catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting ecoCatExpandVp of DaoImpl"); 
		return ecocategorylist;
	}
	/**
	 * @return PLMEcoMetricsData objects.
	 */
	private static final class EcocatgmMapper implements ParameterizedRowMapper<PLMEcoMetricsData> {
//	private static ParameterizedRowMapper<PLMEcoMetricsData> ecocatgmmapper = new ParameterizedRowMapper<PLMEcoMetricsData>() {
		public PLMEcoMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMEcoMetricsData tempecocatdata = new PLMEcoMetricsData();
			tempecocatdata.setName(PLMUtils.checkNullVal(rs.getString("GM_NM")).trim());
			tempecocatdata.setSso(PLMUtils.checkNullVal(rs.getString("GM_NO")));
			tempecocatdata.setMissingreqerror(rs.getInt("MISSING_REQ"));
			tempecocatdata.setProductimprovement(rs.getInt("PRODUCT_IMPROVEMENT"));
			tempecocatdata.setUnassigned(rs.getInt("UNASSIGNED"));
			tempecocatdata.setInitialrelease(rs.getInt("INITIAL_RELEASE"));
			tempecocatdata.setCustomerchange(rs.getInt("CUSTOMER_CHANGE"));
			tempecocatdata.setRowIndex(rs.getRow()-1);
			tempecocatdata.setExpand(true);
			tempecocatdata.setOwner(false);
			tempecocatdata.setCollapse(false);
			if(tempecocatdata.getName().equalsIgnoreCase("") && tempecocatdata.getSso().equalsIgnoreCase(""))
			{
				tempecocatdata.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				tempecocatdata.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				tempecocatdata.setOwner(true);
				tempecocatdata.setExpand(false);
				tempecocatdata.setCollapse(false);
			}
			tempecocatdata.setSso(PLMUtils.appendHash(tempecocatdata.getSso()));
			return tempecocatdata;
		}
	}
	/**
	 * This method is used to ecoCatExpandGm
	 * @param ecocategorydata, ecocategorylist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoCatExpandGm(PLMEcoMetricsData ecocategorydata,List<PLMEcoMetricsData> ecocategorylist) throws PLMCommonException {
		LOG.info("Entering ecoCatExpandGm of DaoImpl");
		try{
		String selectedsso = PLMUtils.removeHash(ecocategorydata.getSelectedsso());
		int vpindex =  ecocategorydata.getVpIndex();
		int gmindex =  ecocategorydata.getGmIndex();
		LOG.info("Selected GM :" + selectedsso);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("ECO Category Expansion Query for GM : " + PLMMetricsQueries.GET_ECOCAT_FMDETAILS);
		List<PLMEcoMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOCAT_FMDETAILS,new EcocatfmMapper(),selectedsso,selectedsso);
		templist = ecoCatfilterUnorderedLevels (templist);
		if(!PLMUtils.isEmptyList(templist))
			{
				ecocategorylist.get(vpindex).getGmTable().get(gmindex).setFmTable(templist);
			  	ecocategorylist.get(vpindex).getGmTable().get(gmindex).setCollapse(true);
			  	ecocategorylist.get(vpindex).getGmTable().get(gmindex).setExpand(false);
			 }
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting ecoCatExpandGm of DaoImpl"); 
		return ecocategorylist;
		}
	/**
	 * @return PLMEcoMetricsData objects.
	 */
	private static final class EcocatfmMapper implements ParameterizedRowMapper<PLMEcoMetricsData> {
//	private static ParameterizedRowMapper<PLMEcoMetricsData> ecocatfmmapper = new ParameterizedRowMapper<PLMEcoMetricsData>() {
		public PLMEcoMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMEcoMetricsData tempecocatdata = new PLMEcoMetricsData();
			tempecocatdata.setName(PLMUtils.checkNullVal(rs.getString("FM_NM")).trim());
			tempecocatdata.setSso(PLMUtils.checkNullVal(rs.getString("FM_NO")));
			tempecocatdata.setMissingreqerror(rs.getInt("MISSING_REQ"));
			tempecocatdata.setProductimprovement(rs.getInt("PRODUCT_IMPROVEMENT"));
			tempecocatdata.setUnassigned(rs.getInt("UNASSIGNED"));
			tempecocatdata.setInitialrelease(rs.getInt("INITIAL_RELEASE"));
			tempecocatdata.setCustomerchange(rs.getInt("CUSTOMER_CHANGE"));
			tempecocatdata.setRowIndex(rs.getRow()-1);
			tempecocatdata.setExpand(true);
			tempecocatdata.setOwner(false);
			tempecocatdata.setCollapse(false);
			if(tempecocatdata.getName().equalsIgnoreCase("") && tempecocatdata.getSso().equalsIgnoreCase(""))
			{
				tempecocatdata.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				tempecocatdata.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				tempecocatdata.setOwner(true);
				tempecocatdata.setExpand(false);
				tempecocatdata.setCollapse(false);
			}
			tempecocatdata.setSso(PLMUtils.appendHash(tempecocatdata.getSso()));
			return tempecocatdata;
		}
	}
	/**
	 * This method is used to ecoCatExpandFm
	 * @param ecocategorydata, ecocategorylist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoCatExpandFm(PLMEcoMetricsData ecocategorydata,List<PLMEcoMetricsData> ecocategorylist) throws PLMCommonException {
		LOG.info("Entering ecoCatExpandFm of DaoImpl");
		try{
		String selectedsso = PLMUtils.removeHash(ecocategorydata.getSelectedsso());
		int vpindex =  ecocategorydata.getVpIndex();
		int gmindex =  ecocategorydata.getGmIndex();
		int fmindex	=   ecocategorydata.getFmIndex();
		LOG.info("Selected FM :" + selectedsso);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("FM index :" + fmindex);
		LOG.info("ECO Category Expansion Query for FM : " + PLMMetricsQueries.GET_ECOCAT_MGR4DETAILS);
		List<PLMEcoMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOCAT_MGR4DETAILS,new Ecocatmgr4Mapper(),selectedsso,selectedsso);
		templist = ecoCatfilterUnorderedLevels (templist);
		if(!PLMUtils.isEmptyList(templist))
			{
				ecocategorylist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).setMgr4table(templist);
			  	ecocategorylist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).setCollapse(true);
			  	ecocategorylist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).setExpand(false);
			 }
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting ecoCatExpandFm of DaoImpl"); 
		return ecocategorylist;
		}
	/**
	 * @return PLMEcoMetricsData objects.
	 */
	private static final class Ecocatmgr4Mapper implements ParameterizedRowMapper<PLMEcoMetricsData> {
//	private static ParameterizedRowMapper<PLMEcoMetricsData> ecocatmgr4mapper = new ParameterizedRowMapper<PLMEcoMetricsData>() {
		public PLMEcoMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMEcoMetricsData tempecocatdata = new PLMEcoMetricsData();
			tempecocatdata.setName(PLMUtils.checkNullVal(rs.getString("MGR4_NM")).trim());
			tempecocatdata.setSso(PLMUtils.checkNullVal(rs.getString("MGR4_NO")));
			tempecocatdata.setMissingreqerror(rs.getInt("MISSING_REQ"));
			tempecocatdata.setProductimprovement(rs.getInt("PRODUCT_IMPROVEMENT"));
			tempecocatdata.setUnassigned(rs.getInt("UNASSIGNED"));
			tempecocatdata.setInitialrelease(rs.getInt("INITIAL_RELEASE"));
			tempecocatdata.setCustomerchange(rs.getInt("CUSTOMER_CHANGE"));
			tempecocatdata.setRowIndex(rs.getRow()-1);
			tempecocatdata.setExpand(true);
			tempecocatdata.setOwner(false);
			tempecocatdata.setCollapse(false);
			if(tempecocatdata.getName().equalsIgnoreCase("") && tempecocatdata.getSso().equalsIgnoreCase(""))
			{
				tempecocatdata.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				tempecocatdata.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				tempecocatdata.setOwner(true);
				tempecocatdata.setExpand(false);
				tempecocatdata.setCollapse(false);
			}
			tempecocatdata.setSso(PLMUtils.appendHash(tempecocatdata.getSso()));
			return tempecocatdata;
		}
	}
	/**
	 * This method is used to ecoCatExpandMgr
	 * @param ecocategorydata, ecocategorylist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoCatExpandMgr4(PLMEcoMetricsData ecocategorydata,List<PLMEcoMetricsData> ecocategorylist) throws PLMCommonException {
		LOG.info("Entering ecoCatExpandMgr4 of DaoImpl");
		try{
		String selectedsso = PLMUtils.removeHash(ecocategorydata.getSelectedsso());
		int vpindex =  ecocategorydata.getVpIndex();
		int gmindex =  ecocategorydata.getGmIndex();
		int fmindex	=   ecocategorydata.getFmIndex();
		int mgr4index = ecocategorydata.getMgr4index();
		LOG.info("Selected MGR4 :" + selectedsso);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("FM index :" + fmindex);
		LOG.info("MGR4 index :"+ mgr4index);
		LOG.info("ECO Category Expansion Query for MGR4 : "+ PLMMetricsQueries.GET_ECOCAT_MGR3DETAILS);
		List<PLMEcoMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOCAT_MGR3DETAILS,new Ecocatmgr3Mapper(),selectedsso,selectedsso);
		templist = ecoCatfilterUnorderedLevels (templist);
		if(!PLMUtils.isEmptyList(templist))
			{
				ecocategorylist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).setMgr3table(templist);
			  	ecocategorylist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).setCollapse(true);
			  	ecocategorylist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).setExpand(false);
			 }
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting ecoCatExpandMgr4 of DaoImpl"); 
		return ecocategorylist;
	}
	/**
	 * @return PLMEcoMetricsData objects.
	 */
	private static final class Ecocatmgr3Mapper implements ParameterizedRowMapper<PLMEcoMetricsData> {
//	private static ParameterizedRowMapper<PLMEcoMetricsData> ecocatmgr3mapper = new ParameterizedRowMapper<PLMEcoMetricsData>() {
		public PLMEcoMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMEcoMetricsData tempecocatdata = new PLMEcoMetricsData();
			tempecocatdata.setName(PLMUtils.checkNullVal(rs.getString("MGR3_NM")).trim());
			tempecocatdata.setSso(PLMUtils.checkNullVal(rs.getString("MGR3_NO")));
			tempecocatdata.setMissingreqerror(rs.getInt("MISSING_REQ"));
			tempecocatdata.setProductimprovement(rs.getInt("PRODUCT_IMPROVEMENT"));
			tempecocatdata.setUnassigned(rs.getInt("UNASSIGNED"));
			tempecocatdata.setInitialrelease(rs.getInt("INITIAL_RELEASE"));
			tempecocatdata.setCustomerchange(rs.getInt("CUSTOMER_CHANGE"));
			tempecocatdata.setRowIndex(rs.getRow()-1);
			tempecocatdata.setExpand(true);
			tempecocatdata.setOwner(false);
			tempecocatdata.setCollapse(false);
			if(tempecocatdata.getName().equalsIgnoreCase("") && tempecocatdata.getSso().equalsIgnoreCase(""))
			{
				tempecocatdata.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				tempecocatdata.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				tempecocatdata.setOwner(true);
				tempecocatdata.setExpand(false);
				tempecocatdata.setCollapse(false);
			}
			tempecocatdata.setSso(PLMUtils.appendHash(tempecocatdata.getSso()));
			return tempecocatdata;
		}
	}
	/**
	 * This method is used to ecoCatExpandMgr
	 * @param ecocategorydata, ecocategorylist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoCatExpandMgr3(PLMEcoMetricsData ecocategorydata,List<PLMEcoMetricsData> ecocategorylist) throws PLMCommonException {
		LOG.info("Entering ecoCatExpandMgr3 of DaoImpl");
		try{
		String selectedsso = PLMUtils.removeHash(ecocategorydata.getSelectedsso());
		int vpindex =  ecocategorydata.getVpIndex();
		int gmindex =  ecocategorydata.getGmIndex();
		int fmindex	=   ecocategorydata.getFmIndex();
		int mgr4index = ecocategorydata.getMgr4index();
		int mgr3index = ecocategorydata.getMgr3index();
		LOG.info("Selected MGR3 :" + selectedsso);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("FM index :" + fmindex);
		LOG.info("MGR4 index :"+ mgr4index);
		LOG.info("MGR3 index :"+ mgr3index);
		LOG.info("ECO Category Expansion Query for MGR3 : "+ PLMMetricsQueries.GET_ECOCAT_MGR2DETAILS);
		List<PLMEcoMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOCAT_MGR2DETAILS,new Ecocatmgr2Mapper(),selectedsso,selectedsso);
		templist = ecoCatfilterUnorderedLevels (templist);
		if(!PLMUtils.isEmptyList(templist))
			{
				ecocategorylist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).setMgr2table(templist);
			  	ecocategorylist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).setCollapse(true);
			  	ecocategorylist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).setExpand(false);
			 }
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting ecoCatExpandMgr3 of DaoImpl"); 
		return ecocategorylist;
	}
	/**
	 * @return PLMEcoMetricsData objects.
	 */
	private static final class Ecocatmgr2Mapper implements ParameterizedRowMapper<PLMEcoMetricsData> {
//	private static ParameterizedRowMapper<PLMEcoMetricsData> ecocatmgr2mapper = new ParameterizedRowMapper<PLMEcoMetricsData>() {
		public PLMEcoMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMEcoMetricsData tempecocatdata = new PLMEcoMetricsData();
			tempecocatdata.setName(PLMUtils.checkNullVal(rs.getString("MGR2_NM")).trim());
			tempecocatdata.setSso(PLMUtils.checkNullVal(rs.getString("MGR2_NO")));
			tempecocatdata.setMissingreqerror(rs.getInt("MISSING_REQ"));
			tempecocatdata.setProductimprovement(rs.getInt("PRODUCT_IMPROVEMENT"));
			tempecocatdata.setUnassigned(rs.getInt("UNASSIGNED"));
			tempecocatdata.setInitialrelease(rs.getInt("INITIAL_RELEASE"));
			tempecocatdata.setCustomerchange(rs.getInt("CUSTOMER_CHANGE"));
			tempecocatdata.setRowIndex(rs.getRow()-1);
			tempecocatdata.setExpand(true);
			tempecocatdata.setOwner(false);
			tempecocatdata.setCollapse(false);
			if(tempecocatdata.getName().equalsIgnoreCase("") && tempecocatdata.getSso().equalsIgnoreCase("") )
			{
				tempecocatdata.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				tempecocatdata.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				tempecocatdata.setOwner(true);
				tempecocatdata.setExpand(false);
				tempecocatdata.setCollapse(false);
			}
			tempecocatdata.setSso(PLMUtils.appendHash(tempecocatdata.getSso()));
			return tempecocatdata;
		}
	}
	
	/**
	 * This method is used to ecoCatExpandMgr
	 * @param ecocategorydata, ecocategorylist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoCatExpandMgr2(PLMEcoMetricsData ecocategorydata,List<PLMEcoMetricsData> ecocategorylist) throws PLMCommonException {
		LOG.info("Entering ecoCatExpandMgr2 of DaoImpl");
		try{
		String selectedsso = PLMUtils.removeHash(ecocategorydata.getSelectedsso());
		int vpindex =  ecocategorydata.getVpIndex();
		int gmindex =  ecocategorydata.getGmIndex();
		int fmindex	=   ecocategorydata.getFmIndex();
		int mgr4index = ecocategorydata.getMgr4index();
		int mgr3index = ecocategorydata.getMgr3index();
		int mgr2index = ecocategorydata.getMgr2index();
		LOG.info("Selected MGR2 :" + selectedsso);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("FM index :" + fmindex);
		LOG.info("MGR4 index :"+ mgr4index);
		LOG.info("MGR3 index :"+ mgr3index);
		LOG.info("MGR2 index :"+ mgr2index);
		LOG.info("ECO Category Expansion Query for MGR2 : "+ PLMMetricsQueries.GET_ECOCAT_MGR1DETAILS);
		List<PLMEcoMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOCAT_MGR1DETAILS,new Ecocatmgr1Mapper(),selectedsso,selectedsso);
		templist = ecoCatfilterUnorderedLevels (templist);
		if(!PLMUtils.isEmptyList(templist))
			{
				ecocategorylist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).setMgr1table(templist);
			  	ecocategorylist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).setCollapse(true);
			  	ecocategorylist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).setExpand(false);
			 }
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting ecoCatExpandMgr2 of DaoImpl"); 
		return ecocategorylist;
		}
	/**
	 * @return PLMEcoMetricsData objects.
	 */
	private static final class Ecocatmgr1Mapper implements ParameterizedRowMapper<PLMEcoMetricsData> {
//	private static ParameterizedRowMapper<PLMEcoMetricsData> ecocatmgr1mapper = new ParameterizedRowMapper<PLMEcoMetricsData>() {
		public PLMEcoMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMEcoMetricsData tempecocatdata = new PLMEcoMetricsData();
			tempecocatdata.setName(PLMUtils.checkNullVal(rs.getString("MGR1_NM")).trim());
			tempecocatdata.setSso(PLMUtils.checkNullVal(rs.getString("MGR1_NO")));
			tempecocatdata.setMissingreqerror(rs.getInt("MISSING_REQ"));
			tempecocatdata.setProductimprovement(rs.getInt("PRODUCT_IMPROVEMENT"));
			tempecocatdata.setUnassigned(rs.getInt("UNASSIGNED"));
			tempecocatdata.setInitialrelease(rs.getInt("INITIAL_RELEASE"));
			tempecocatdata.setCustomerchange(rs.getInt("CUSTOMER_CHANGE"));
			tempecocatdata.setRowIndex(rs.getRow()-1);
			tempecocatdata.setExpand(true);
			tempecocatdata.setOwner(false);
			tempecocatdata.setCollapse(false);
			if(tempecocatdata.getName().equalsIgnoreCase("") && tempecocatdata.getSso().equalsIgnoreCase(""))
			{
				tempecocatdata.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				tempecocatdata.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				tempecocatdata.setOwner(true);
				tempecocatdata.setExpand(false);
				tempecocatdata.setCollapse(false);
			}
			tempecocatdata.setSso(PLMUtils.appendHash(tempecocatdata.getSso()));
			return tempecocatdata;
		}
	}
	/**
	 * This method is used to ecoCatExpandMgr
	 * @param ecocategorydata, ecocategorylist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoCatExpandMgr1(PLMEcoMetricsData ecocategorydata,List<PLMEcoMetricsData> ecocategorylist) throws PLMCommonException {
		LOG.info("Entering ecoCatExpandMgr1 of DaoImpl");
		try{
		String selectedsso = PLMUtils.removeHash(ecocategorydata.getSelectedsso());
		int vpindex =  ecocategorydata.getVpIndex();
		int gmindex =  ecocategorydata.getGmIndex();
		int fmindex	=   ecocategorydata.getFmIndex();
		int mgr4index = ecocategorydata.getMgr4index();
		int mgr3index = ecocategorydata.getMgr3index();
		int mgr2index = ecocategorydata.getMgr2index();
		int mgr1index = ecocategorydata.getMgr1index();
		LOG.info("Selected MGR1 :" + selectedsso);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("FM index :" + fmindex);
		LOG.info("MGR4 index :"+ mgr4index);
		LOG.info("MGR3 index :"+ mgr3index);
		LOG.info("MGR2 index :"+ mgr2index);
		LOG.info("MGR1 index :"+ mgr1index);
		LOG.info("ECO Category Expansion Query for MGR1 : "+ PLMMetricsQueries.GET_ECOCAT_OWNERDETAILS);
		List<PLMEcoMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOCAT_OWNERDETAILS,new EcocatownerMapper(),selectedsso,selectedsso);
		if(!PLMUtils.isEmptyList(templist))
			{
				ecocategorylist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).getMgr1table().get(mgr1index).setOwnertable(templist);
			  	ecocategorylist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).getMgr1table().get(mgr1index).setCollapse(true);
			  	ecocategorylist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).getMgr1table().get(mgr1index).setExpand(false);
			 }
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting ecoCatExpandMgr1 of DaoImpl"); 
		return ecocategorylist;
		}
	/**
	 * @return PLMEcoMetricsData objects.
	 */
	private static final class EcocatownerMapper implements ParameterizedRowMapper<PLMEcoMetricsData> {
//	private static ParameterizedRowMapper<PLMEcoMetricsData> ecocatownermapper = new ParameterizedRowMapper<PLMEcoMetricsData>() {
		public PLMEcoMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMEcoMetricsData tempecocatdata = new PLMEcoMetricsData();
			tempecocatdata.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
			tempecocatdata.setSso(PLMUtils.appendHash(PLMUtils.checkNullVal(rs.getString("OWNER_NO"))));
			tempecocatdata.setMissingreqerror(rs.getInt("MISSING_REQ"));
			tempecocatdata.setProductimprovement(rs.getInt("PRODUCT_IMPROVEMENT"));
			tempecocatdata.setUnassigned(rs.getInt("UNASSIGNED"));
			tempecocatdata.setInitialrelease(rs.getInt("INITIAL_RELEASE"));
			tempecocatdata.setCustomerchange(rs.getInt("CUSTOMER_CHANGE"));
			tempecocatdata.setRowIndex(rs.getRow()-1);
			tempecocatdata.setOwner(true);
			tempecocatdata.setExpand(false);
			tempecocatdata.setCollapse(false);
			return tempecocatdata;
		}
	}

	// Eco Volume 
	/**
	 * This method is used to ecoVolfilterUnorderedLevels
	 * @param templist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoVolfilterUnorderedLevels (List<PLMEcoMetricsData> templist)
	{
		LOG.info("Entering ecoVolfilterUnorderedLevels of DaoImpl");
		List<PLMEcoMetricsData> returnlist = new ArrayList<PLMEcoMetricsData>();
		if(!PLMUtils.isEmptyList(templist))
		{
			for(int i=0;i<templist.size();i++)
			{
				for (int j=i+1;j<templist.size();j++)
				  {
					if(templist.get(i).getName()== null && templist.get(i).getSso()==null )
					continue;
					if(templist.get(i).getName().equalsIgnoreCase(templist.get(j).getName()))
						{
						if(templist.get(j).getName()== null && templist.get(j).getSso()== null)
						continue;	
						templist.get(i).setBacklog(templist.get(i).getBacklog() + templist.get(j).getBacklog());
						templist.get(i).setDueWeek(templist.get(i).getDueWeek() + templist.get(j).getDueWeek());
						templist.get(i).setDueMonth(templist.get(i).getDueMonth() + templist.get(j).getDueMonth());
						templist.get(i).setDueYear(templist.get(i).getDueYear() + templist.get(j).getDueYear());
						templist.get(i).setOwner(false);
						templist.get(i).setExpand(true);
						templist.get(i).setCollapse(false);
						templist.get(j).setName(null);templist.get(j).setSso(null);
						}
				  }
			}
		}
		
		if(!PLMUtils.isEmptyList(templist))
		{
			LOG.info("Size of Templist " + templist.size());
			for(int i=0;i<templist.size();i++)
			{
			if(templist.get(i).getName()!= null && templist.get(i).getSso()!=null)
			{
			returnlist.add(templist.get(i));
			}
			}
		}
		if(!PLMUtils.isEmptyList(templist))
		{
			LOG.info("Size of Returnlist " + returnlist.size());
			for(int i=0;i<returnlist.size();i++)
			{
				returnlist.get(i).setRowIndex(i);
				int sum = returnlist.get(i).getBacklog() + returnlist.get(i).getDueWeek()+returnlist.get(i).getDueMonth()+returnlist.get(i).getDueYear();
				if(sum==0)
				{
				returnlist.get(i).setOwner(true);
				returnlist.get(i).setExpand(false);
				returnlist.get(i).setCollapse(false);	
				}
			}
		}
			LOG.info("Exiting ecoVolfilterUnorderedLevels of DaoImpl");
			return returnlist;
		}
	
	
	/**
	 * This method is used to loadEcoVolumeDetailReport
	 * @param ecovolumedata
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<String> loadEcoVolumeDetailReport(PLMEcoMetricsData ecovolumedata) throws PLMCommonException {
		LOG.info("Entering loadEcoVolumeDetailReport of DaoImpl");
		List<String> econameslist = new ArrayList<String>();
		try{
		String selectedsso = PLMUtils.removeHash(ecovolumedata.getSelectedsso());
		LOG.info("Selected SSO :" + selectedsso);
		String criteria =  ecovolumedata.getCriteria();
		LOG.info("Selected criteria :" + criteria);
		if(selectedsso.equalsIgnoreCase("OTHER"))
		{
			if(criteria.equalsIgnoreCase("BACKLOG"))
			{
			LOG.info("Eco Volume Detail Query for Other Backlog " + PLMMetricsQueries.GET_ECOVOL_OTHER_BACKLOG_ECONAMES);
			econameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOVOL_OTHER_BACKLOG_ECONAMES,new EconameMapper());
			}
			if(criteria.equalsIgnoreCase("DUEWEEK"))
			{
			LOG.info("Eco Volume Detail Query for Other DueWeek " + PLMMetricsQueries.GET_ECOVOL_OTHER_DUES_ECONAMES);
			econameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOVOL_OTHER_DUES_ECONAMES,new EconameMapper(),new Object[] {weekstart,weekend,weekstart,weekend});
			}
			if(criteria.equalsIgnoreCase("DUEMONTH"))
			{
			LOG.info("Eco Volume Detail Query for Other DueMonth " + PLMMetricsQueries.GET_ECOVOL_OTHER_DUES_ECONAMES);
			econameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOVOL_OTHER_DUES_ECONAMES,new EconameMapper(),new Object[] {monthstart,monthend,monthstart,monthend});
			}
			if(criteria.equalsIgnoreCase("DUEYEAR"))
			{
			LOG.info("Eco Volume Detail Query for Other Due year " + PLMMetricsQueries.GET_ECOVOL_OTHER_DUES_ECONAMES);
			econameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOVOL_OTHER_DUES_ECONAMES,new EconameMapper(),new Object[] {yearstart,yearend,yearstart,yearend});
			}
		}
		else
		{
			if(criteria.equalsIgnoreCase("BACKLOG"))
			{
			LOG.info("Eco Volume Detail Query for Backlog " + PLMMetricsQueries.GET_ECOVOL_BACKLOG_ECONAMES);
			econameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOVOL_BACKLOG_ECONAMES,new EconameMapper(),new Object[] { selectedsso, selectedsso, selectedsso,selectedsso,selectedsso,selectedsso,selectedsso,selectedsso });
			}
			if(criteria.equalsIgnoreCase("DUEWEEK"))
			{
			LOG.info("Eco Volume Detail Query for Due Week " + PLMMetricsQueries.GET_ECOVOL_DUES_ECONAMES);
			econameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOVOL_DUES_ECONAMES,new EconameMapper(),new Object[] {weekstart,weekend, selectedsso, selectedsso, selectedsso,selectedsso,selectedsso,selectedsso,selectedsso,selectedsso });
			}
			if(criteria.equalsIgnoreCase("DUEMONTH"))
			{
			LOG.info("Eco Volume Detail Query for Due Month " + PLMMetricsQueries.GET_ECOVOL_DUES_ECONAMES);
			econameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOVOL_DUES_ECONAMES,new EconameMapper(),new Object[] {monthstart,monthend,selectedsso, selectedsso, selectedsso,selectedsso,selectedsso,selectedsso,selectedsso,selectedsso });
			}
			if(criteria.equalsIgnoreCase("DUEYEAR"))
			{
			LOG.info("Eco Volume Detail Query for Due Year " + PLMMetricsQueries.GET_ECOVOL_DUES_ECONAMES);
			econameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOVOL_DUES_ECONAMES,new EconameMapper(),new Object[] {yearstart,yearend, selectedsso, selectedsso,selectedsso,selectedsso,selectedsso,selectedsso,selectedsso,selectedsso});
			}
		}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting loadEcoVolumeDetailReport of DaoImpl");
		return econameslist;
	}
	/**
	 * This method is used to loadEcoVolumeReport
	 * @param ecovolumedata, ecovolumelist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> loadEcoVolumeReport(PLMEcoMetricsData ecovolumedata,List<PLMEcoMetricsData> ecovolumelist) throws PLMCommonException {
		List<PLMEcoMetricsData> ecovolist = new ArrayList<PLMEcoMetricsData>();
		LOG.info("Entering loadEcoVolumeReport of DaoImpl");
		try{
		LOG.info("Due Week  : BETWEEN " + weekstart + " AND " + weekend);
		LOG.info("Due Month : BETWEEN " + monthstart + " AND " + monthend);
		LOG.info("Due Year  : BETWEEN " + yearstart + " AND " + yearend);
		LOG.info("ECO Volume Query : " + PLMMetricsQueries.GET_ECOVOL_VPDETAILS);
		ecovolist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOVOL_VPDETAILS,new EcovolvpMapper(),new Object[] {weekstart,weekend,monthstart,monthend,yearstart,yearend});
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting loadEcoVolumeReport of DaoImpl");
		return ecovolist;
	}
	
	/**
	 * @return PLMEcoMetricsData objects.
	 */
	private static final class EcovolvpMapper implements ParameterizedRowMapper<PLMEcoMetricsData> {
//	private static ParameterizedRowMapper<PLMEcoMetricsData> ecovolvpmapper = new ParameterizedRowMapper<PLMEcoMetricsData>() {
		public PLMEcoMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMEcoMetricsData tempecovoldata = new PLMEcoMetricsData();
			tempecovoldata.setName(PLMUtils.checkNullVal(rs.getString("VP_NM")).trim());
			tempecovoldata.setSso(PLMUtils.checkNullVal(rs.getString("VP_NO")));
			tempecovoldata.setBacklog((rs.getInt("BACK_LOG")));
			tempecovoldata.setDueWeek((rs.getInt("ECO_DUE_THIS_WEEK")));
			tempecovoldata.setDueMonth((rs.getInt("ECO_DUE_THIS_MONTH")));
			tempecovoldata.setDueYear((rs.getInt("ECO_DUE_THIS_YEAR")));
			tempecovoldata.setRowIndex(rs.getRow()-1);
			tempecovoldata.setExpand(true);
			tempecovoldata.setOwner(false);
			tempecovoldata.setCollapse(false);
			if(tempecovoldata.getName().equalsIgnoreCase("OTHER") && tempecovoldata.getSso().equalsIgnoreCase("OTHER"))
			{
				tempecovoldata.setOwner(true);
				tempecovoldata.setExpand(false);
				tempecovoldata.setCollapse(false);
			}
			tempecovoldata.setSso(PLMUtils.appendHash(tempecovoldata.getSso()));
			return tempecovoldata;
		}
	}
	/**
	 * This method is used to ecoVolExpandVp
	 * @param ecovolumedata, ecovolumelist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoVolExpandVp(PLMEcoMetricsData ecovolumedata,List<PLMEcoMetricsData> ecovolumelist) throws PLMCommonException {
		LOG.info("Entering ecoVolExpandVp of DaoImpl");
		try{
		int vpindex =  ecovolumedata.getVpIndex();
		String selectedsso = PLMUtils.removeHash(ecovolumedata.getSelectedsso());
		LOG.info("Selected VP :"+selectedsso);
		LOG.info("VP index :" + vpindex);
		LOG.info("ECO Volume Expansion Query for VP : " + PLMMetricsQueries.GET_ECOVOL_GMDETAILS);
		List<PLMEcoMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOVOL_GMDETAILS,new EcovolgmMapper(),new Object[] {weekstart,weekend,monthstart,monthend,yearstart,yearend,selectedsso,selectedsso});
		templist = ecoVolfilterUnorderedLevels (templist);
		if(!PLMUtils.isEmptyList(templist))
			{
				ecovolumelist.get(vpindex).setGmTable(templist);
				ecovolumelist.get(vpindex).setCollapse(true);
				ecovolumelist.get(vpindex).setExpand(false);
			 }
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting ecoVolExpandVp of DaoImpl"); 
		return ecovolumelist;
	}
	/**
	 * @return PLMEcoMetricsData objects.
	 */
	private static final class EcovolgmMapper implements ParameterizedRowMapper<PLMEcoMetricsData> {
//	private static ParameterizedRowMapper<PLMEcoMetricsData> ecovolgmmapper = new ParameterizedRowMapper<PLMEcoMetricsData>() {
		public PLMEcoMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMEcoMetricsData tempecovoldata = new PLMEcoMetricsData();
			tempecovoldata.setName(PLMUtils.checkNullVal(rs.getString("GM_NM")).trim());
			tempecovoldata.setSso(PLMUtils.checkNullVal(rs.getString("GM_NO")));
			tempecovoldata.setBacklog((rs.getInt("BACK_LOG")));
			tempecovoldata.setDueWeek((rs.getInt("ECO_DUE_THIS_WEEK")));
			tempecovoldata.setDueMonth((rs.getInt("ECO_DUE_THIS_MONTH")));
			tempecovoldata.setDueYear((rs.getInt("ECO_DUE_THIS_YEAR")));
			tempecovoldata.setRowIndex(rs.getRow()-1);
			tempecovoldata.setExpand(true);
			tempecovoldata.setOwner(false);
			tempecovoldata.setCollapse(false);
			if(tempecovoldata.getName().equalsIgnoreCase("") && tempecovoldata.getSso().equalsIgnoreCase(""))
			{
				tempecovoldata.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				tempecovoldata.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				tempecovoldata.setOwner(true);
				tempecovoldata.setExpand(false);
				tempecovoldata.setCollapse(false);
			}
			tempecovoldata.setSso(PLMUtils.appendHash(tempecovoldata.getSso()));
			return tempecovoldata;
		}
	}
	/**
	 * This method is used to ecoVolExpandGm
	 * @param ecovolumedata, ecovolumelist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoVolExpandGm(PLMEcoMetricsData ecovolumedata,List<PLMEcoMetricsData> ecovolumelist) throws PLMCommonException {
		LOG.info("Entering ecoVolExpandGm of DaoImpl");
		try{
		String selectedsso = PLMUtils.removeHash(ecovolumedata.getSelectedsso());
		int vpindex =  ecovolumedata.getVpIndex();
		int gmindex =  ecovolumedata.getGmIndex();
		LOG.info("Selected GM :" + selectedsso);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("ECO Volume Expansion Query for GM : " + PLMMetricsQueries.GET_ECOVOL_FMDETAILS);
		List<PLMEcoMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOVOL_FMDETAILS,new EcovolfmMapper(),new Object[] {weekstart,weekend,monthstart,monthend,yearstart,yearend,selectedsso,selectedsso});
		templist = ecoVolfilterUnorderedLevels (templist);
		if(!PLMUtils.isEmptyList(templist))
			{
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).setFmTable(templist);
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).setCollapse(true);
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).setExpand(false);
			 }
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting ecoVolExpandGm of DaoImpl"); 
		return ecovolumelist;
		}
	/**
	 * @return PLMEcoMetricsData objects.
	 */
	private static final class EcovolfmMapper implements ParameterizedRowMapper<PLMEcoMetricsData> {
//	private static ParameterizedRowMapper<PLMEcoMetricsData> ecovolfmmapper = new ParameterizedRowMapper<PLMEcoMetricsData>() {
		public PLMEcoMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMEcoMetricsData tempecovoldata = new PLMEcoMetricsData();
			tempecovoldata.setName(PLMUtils.checkNullVal(rs.getString("FM_NM")).trim());
			tempecovoldata.setSso(PLMUtils.checkNullVal(rs.getString("FM_NO")));
			tempecovoldata.setBacklog((rs.getInt("BACK_LOG")));
			tempecovoldata.setDueWeek((rs.getInt("ECO_DUE_THIS_WEEK")));
			tempecovoldata.setDueMonth((rs.getInt("ECO_DUE_THIS_MONTH")));
			tempecovoldata.setDueYear((rs.getInt("ECO_DUE_THIS_YEAR")));
			tempecovoldata.setRowIndex(rs.getRow()-1);
			tempecovoldata.setExpand(true);
			tempecovoldata.setOwner(false);
			tempecovoldata.setCollapse(false);
			if(tempecovoldata.getName().equalsIgnoreCase("") && tempecovoldata.getSso().equalsIgnoreCase(""))
			{
				tempecovoldata.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				tempecovoldata.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				tempecovoldata.setOwner(true);
				tempecovoldata.setExpand(false);
				tempecovoldata.setCollapse(false);
			}
			tempecovoldata.setSso(PLMUtils.appendHash(tempecovoldata.getSso()));
			return tempecovoldata;
		}
	}
	/**
	 * This method is used to ecoVolExpandFm
	 * @param ecovolumedata, ecovolumelist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoVolExpandFm(PLMEcoMetricsData ecovolumedata,List<PLMEcoMetricsData> ecovolumelist) throws PLMCommonException {
		LOG.info("Entering ecoCatExpandFm of DaoImpl");
		try{
		String selectedsso = PLMUtils.removeHash(ecovolumedata.getSelectedsso());
		int vpindex =  ecovolumedata.getVpIndex();
		int gmindex =  ecovolumedata.getGmIndex();
		int fmindex	=   ecovolumedata.getFmIndex();
		LOG.info("Selected FM :" + selectedsso);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("FM index :" + fmindex);
		LOG.info("ECO Volume Expansion Query for FM : " + PLMMetricsQueries.GET_ECOVOL_MGR4DETAILS);
		List<PLMEcoMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOVOL_MGR4DETAILS,new Ecovolmgr4Mapper(),new Object[] {weekstart,weekend,monthstart,monthend,yearstart,yearend,selectedsso,selectedsso});
		templist = ecoVolfilterUnorderedLevels (templist);
		if(!PLMUtils.isEmptyList(templist))
			{
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).setMgr4table(templist);
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).setCollapse(true);
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).setExpand(false);
			 }
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting ecoVolExpandFm of DaoImpl"); 
		return ecovolumelist;
		}
	/**
	 * @return PLMEcoMetricsData objects.
	 */
	private static final class Ecovolmgr4Mapper implements ParameterizedRowMapper<PLMEcoMetricsData> {
//	private static ParameterizedRowMapper<PLMEcoMetricsData> ecovolmgr4mapper = new ParameterizedRowMapper<PLMEcoMetricsData>() {
		public PLMEcoMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMEcoMetricsData tempecovoldata = new PLMEcoMetricsData();
			tempecovoldata.setName(PLMUtils.checkNullVal(rs.getString("MGR4_NM")).trim());
			tempecovoldata.setSso(PLMUtils.checkNullVal(rs.getString("MGR4_NO")));
			tempecovoldata.setBacklog((rs.getInt("BACK_LOG")));
			tempecovoldata.setDueWeek((rs.getInt("ECO_DUE_THIS_WEEK")));
			tempecovoldata.setDueMonth((rs.getInt("ECO_DUE_THIS_MONTH")));
			tempecovoldata.setDueYear((rs.getInt("ECO_DUE_THIS_YEAR")));
			tempecovoldata.setRowIndex(rs.getRow()-1);
			tempecovoldata.setExpand(true);
			tempecovoldata.setOwner(false);
			tempecovoldata.setCollapse(false);
			if(tempecovoldata.getName().equalsIgnoreCase("") && tempecovoldata.getSso().equalsIgnoreCase(""))
			{
				tempecovoldata.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				tempecovoldata.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				tempecovoldata.setOwner(true);
				tempecovoldata.setExpand(false);
				tempecovoldata.setCollapse(false);
			}
			tempecovoldata.setSso(PLMUtils.appendHash(tempecovoldata.getSso()));
			return tempecovoldata;
		}
	}
	/**
	 * This method is used to ecoVolExpandMgr
	 * @param ecovolumedata, ecovolumelist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoVolExpandMgr4(PLMEcoMetricsData ecovolumedata,List<PLMEcoMetricsData> ecovolumelist) throws PLMCommonException {
		LOG.info("Entering ecoVolExpandMgr4 of DaoImpl");
		try{
		String selectedsso = PLMUtils.removeHash(ecovolumedata.getSelectedsso());
		int vpindex =  ecovolumedata.getVpIndex();
		int gmindex =  ecovolumedata.getGmIndex();
		int fmindex	=   ecovolumedata.getFmIndex();
		int mgr4index = ecovolumedata.getMgr4index();
		LOG.info("Selected MGR4 :" + selectedsso);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("FM index :" + fmindex);
		LOG.info("MGR4 index :"+ mgr4index);
		LOG.info("ECO Volume Expansion Query for MGR4 : "+ PLMMetricsQueries.GET_ECOVOL_MGR3DETAILS);
		List<PLMEcoMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOVOL_MGR3DETAILS,new Ecovolmgr3Mapper(),new Object[] {weekstart,weekend,monthstart,monthend,yearstart,yearend,selectedsso,selectedsso});
		templist = ecoVolfilterUnorderedLevels (templist);
		if(!PLMUtils.isEmptyList(templist))
			{
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).setMgr3table(templist);
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).setCollapse(true);
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).setExpand(false);
			 }
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting ecoVolExpandMgr4 of DaoImpl"); 
		return ecovolumelist;
	}
	/**
	 * @return PLMEcoMetricsData objects.
	 */
	private static final class Ecovolmgr3Mapper implements ParameterizedRowMapper<PLMEcoMetricsData> {
//	private static ParameterizedRowMapper<PLMEcoMetricsData> ecovolmgr3mapper = new ParameterizedRowMapper<PLMEcoMetricsData>() {
		public PLMEcoMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMEcoMetricsData tempecovoldata = new PLMEcoMetricsData();
			tempecovoldata.setName(PLMUtils.checkNullVal(rs.getString("MGR3_NM")).trim());
			tempecovoldata.setSso(PLMUtils.checkNullVal(rs.getString("MGR3_NO")));
			tempecovoldata.setBacklog((rs.getInt("BACK_LOG")));
			tempecovoldata.setDueWeek((rs.getInt("ECO_DUE_THIS_WEEK")));
			tempecovoldata.setDueMonth((rs.getInt("ECO_DUE_THIS_MONTH")));
			tempecovoldata.setDueYear((rs.getInt("ECO_DUE_THIS_YEAR")));
			tempecovoldata.setRowIndex(rs.getRow()-1);
			tempecovoldata.setExpand(true);
			tempecovoldata.setOwner(false);
			tempecovoldata.setCollapse(false);
			if(tempecovoldata.getName().equalsIgnoreCase("") && tempecovoldata.getSso().equalsIgnoreCase(""))
			{
				tempecovoldata.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				tempecovoldata.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				tempecovoldata.setOwner(true);
				tempecovoldata.setExpand(false);
				tempecovoldata.setCollapse(false);
			}
			tempecovoldata.setSso(PLMUtils.appendHash(tempecovoldata.getSso()));
			return tempecovoldata;
		}
	}
	/**
	 * This method is used to ecoVolExpandMgr
	 * @param ecovolumedata, ecovolumelist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoVolExpandMgr3(PLMEcoMetricsData ecovolumedata,List<PLMEcoMetricsData> ecovolumelist) throws PLMCommonException {
		LOG.info("Entering ecoVolExpandMgr3 of DaoImpl");
		try{
		String selectedsso = PLMUtils.removeHash(ecovolumedata.getSelectedsso());
		int vpindex =  ecovolumedata.getVpIndex();
		int gmindex =  ecovolumedata.getGmIndex();
		int fmindex	=   ecovolumedata.getFmIndex();
		int mgr4index = ecovolumedata.getMgr4index();
		int mgr3index = ecovolumedata.getMgr3index();
		LOG.info("Selected MGR3 :" + selectedsso);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("FM index :" + fmindex);
		LOG.info("MGR4 index :"+ mgr4index);
		LOG.info("MGR3 index :"+ mgr3index);
		LOG.info("ECO Volume Expansion Query for MGR3 : "+ PLMMetricsQueries.GET_ECOVOL_MGR2DETAILS);
		List<PLMEcoMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOVOL_MGR2DETAILS,new Ecovolmgr2Mapper(),new Object[] {weekstart,weekend,monthstart,monthend,yearstart,yearend,selectedsso,selectedsso});
		templist = ecoVolfilterUnorderedLevels (templist);
		if(!PLMUtils.isEmptyList(templist))
			{
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).setMgr2table(templist);
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).setCollapse(true);
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).setExpand(false);
			 }
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting ecoVolExpandMgr3 of DaoImpl"); 
		return ecovolumelist;
	}
	/**
	 * @return PLMEcoMetricsData objects.
	 */
	private static final class Ecovolmgr2Mapper implements ParameterizedRowMapper<PLMEcoMetricsData> {
//	private static ParameterizedRowMapper<PLMEcoMetricsData> ecovolmgr2mapper = new ParameterizedRowMapper<PLMEcoMetricsData>() {
		public PLMEcoMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMEcoMetricsData tempecovoldata = new PLMEcoMetricsData();
			tempecovoldata.setName(PLMUtils.checkNullVal(rs.getString("MGR2_NM")).trim());
			tempecovoldata.setSso(PLMUtils.checkNullVal(rs.getString("MGR2_NO")));
			tempecovoldata.setBacklog((rs.getInt("BACK_LOG")));
			tempecovoldata.setDueWeek((rs.getInt("ECO_DUE_THIS_WEEK")));
			tempecovoldata.setDueMonth((rs.getInt("ECO_DUE_THIS_MONTH")));
			tempecovoldata.setDueYear((rs.getInt("ECO_DUE_THIS_YEAR")));
			tempecovoldata.setRowIndex(rs.getRow()-1);
			tempecovoldata.setExpand(true);
			tempecovoldata.setOwner(false);
			tempecovoldata.setCollapse(false);
			if(tempecovoldata.getName().equalsIgnoreCase("") && tempecovoldata.getSso().equalsIgnoreCase("") )
			{
				tempecovoldata.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				tempecovoldata.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				tempecovoldata.setOwner(true);
				tempecovoldata.setExpand(false);
				tempecovoldata.setCollapse(false);
			}
			tempecovoldata.setSso(PLMUtils.appendHash(tempecovoldata.getSso()));
			return tempecovoldata;
		}
	}
	
	/**
	 * This method is used to ecoVolExpandMgr
	 * @param ecovolumedata, ecovolumelist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoVolExpandMgr2(PLMEcoMetricsData ecovolumedata,List<PLMEcoMetricsData> ecovolumelist) throws PLMCommonException {
		LOG.info("Entering ecoVolExpandMgr2 of DaoImpl");
		try{
		String selectedsso = PLMUtils.removeHash(ecovolumedata.getSelectedsso());
		int vpindex =  ecovolumedata.getVpIndex();
		int gmindex =  ecovolumedata.getGmIndex();
		int fmindex	=   ecovolumedata.getFmIndex();
		int mgr4index = ecovolumedata.getMgr4index();
		int mgr3index = ecovolumedata.getMgr3index();
		int mgr2index = ecovolumedata.getMgr2index();
		LOG.info("Selected MGR2 :" + selectedsso);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("FM index :" + fmindex);
		LOG.info("MGR4 index :"+ mgr4index);
		LOG.info("MGR3 index :"+ mgr3index);
		LOG.info("MGR2 index :"+ mgr2index);
		LOG.info("ECO Volume Expansion Query for MGR2 : "+ PLMMetricsQueries.GET_ECOVOL_MGR1DETAILS);
		List<PLMEcoMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOVOL_MGR1DETAILS,new Ecovolmgr1Mapper(),new Object[] {weekstart,weekend,monthstart,monthend,yearstart,yearend,selectedsso,selectedsso});
		templist = ecoVolfilterUnorderedLevels (templist);
		if(!PLMUtils.isEmptyList(templist))
			{
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).setMgr1table(templist);
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).setCollapse(true);
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).setExpand(false);
			 }
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting ecoVolExpandMgr2 of DaoImpl"); 
		return ecovolumelist;
		}
	/**
	 * @return PLMEcoMetricsData objects.
	 */
	private static final class Ecovolmgr1Mapper implements ParameterizedRowMapper<PLMEcoMetricsData> {
//	private static ParameterizedRowMapper<PLMEcoMetricsData> ecovolmgr1mapper = new ParameterizedRowMapper<PLMEcoMetricsData>() {
		public PLMEcoMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMEcoMetricsData tempecovoldata = new PLMEcoMetricsData();
			tempecovoldata.setName(PLMUtils.checkNullVal(rs.getString("MGR1_NM")).trim());
			tempecovoldata.setSso(PLMUtils.checkNullVal(rs.getString("MGR1_NO")));
			tempecovoldata.setBacklog((rs.getInt("BACK_LOG")));
			tempecovoldata.setDueWeek((rs.getInt("ECO_DUE_THIS_WEEK")));
			tempecovoldata.setDueMonth((rs.getInt("ECO_DUE_THIS_MONTH")));
			tempecovoldata.setDueYear((rs.getInt("ECO_DUE_THIS_YEAR")));
			tempecovoldata.setRowIndex(rs.getRow()-1);
			tempecovoldata.setExpand(true);
			tempecovoldata.setOwner(false);
			tempecovoldata.setCollapse(false);
			if(tempecovoldata.getName().equalsIgnoreCase("") && tempecovoldata.getSso().equalsIgnoreCase(""))
			{
				tempecovoldata.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				tempecovoldata.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				tempecovoldata.setOwner(true);
				tempecovoldata.setExpand(false);
				tempecovoldata.setCollapse(false);
			}
			tempecovoldata.setSso(PLMUtils.appendHash(tempecovoldata.getSso()));
			return tempecovoldata;
		}
	}
	/**
	 * This method is used to ecoVolExpandMgr
	 * @param ecovolumedata, ecovolumelist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoVolExpandMgr1(PLMEcoMetricsData ecovolumedata,List<PLMEcoMetricsData> ecovolumelist) throws PLMCommonException {
		LOG.info("Entering ecoVolExpandMgr1 of DaoImpl");
		try{
		String selectedsso = PLMUtils.removeHash(ecovolumedata.getSelectedsso());
		int vpindex =  ecovolumedata.getVpIndex();
		int gmindex =  ecovolumedata.getGmIndex();
		int fmindex	=   ecovolumedata.getFmIndex();
		int mgr4index = ecovolumedata.getMgr4index();
		int mgr3index = ecovolumedata.getMgr3index();
		int mgr2index = ecovolumedata.getMgr2index();
		int mgr1index = ecovolumedata.getMgr1index();
		LOG.info("Selected MGR1 :" + selectedsso);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("FM index :" + fmindex);
		LOG.info("MGR4 index :"+ mgr4index);
		LOG.info("MGR3 index :"+ mgr3index);
		LOG.info("MGR2 index :"+ mgr2index);
		LOG.info("MGR1 index :"+ mgr1index);
		LOG.info("ECO Volume Expansion Query for MGR1 : "+ PLMMetricsQueries.GET_ECOVOL_OWNERDETAILS);
		List<PLMEcoMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_ECOVOL_OWNERDETAILS,new EcovolownerMapper(),new Object[] {weekstart,weekend,monthstart,monthend,yearstart,yearend,selectedsso,selectedsso});
		if(!PLMUtils.isEmptyList(templist))
			{
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).getMgr1table().get(mgr1index).setOwnertable(templist);
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).getMgr1table().get(mgr1index).setCollapse(true);
				ecovolumelist.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).getMgr1table().get(mgr1index).setExpand(false);
			 }
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting ecoVolExpandMgr1 of DaoImpl"); 
		return ecovolumelist;
		}
	/**
	 * @return PLMEcoMetricsData objects.
	 */
	private static final class EcovolownerMapper implements ParameterizedRowMapper<PLMEcoMetricsData> {
//	private static ParameterizedRowMapper<PLMEcoMetricsData> ecovolownermapper = new ParameterizedRowMapper<PLMEcoMetricsData>() {
		public PLMEcoMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMEcoMetricsData tempecovoldata = new PLMEcoMetricsData();
			tempecovoldata.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
			tempecovoldata.setSso(PLMUtils.appendHash(PLMUtils.checkNullVal(rs.getString("OWNER_NO"))));
			tempecovoldata.setBacklog((rs.getInt("BACK_LOG")));
			tempecovoldata.setDueWeek((rs.getInt("ECO_DUE_THIS_WEEK")));
			tempecovoldata.setDueMonth((rs.getInt("ECO_DUE_THIS_MONTH")));
			tempecovoldata.setDueYear((rs.getInt("ECO_DUE_THIS_YEAR")));
			tempecovoldata.setRowIndex(rs.getRow()-1);
			tempecovoldata.setOwner(true);
			tempecovoldata.setExpand(false);
			tempecovoldata.setCollapse(false);
			return tempecovoldata;
		}
	}
	
	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}
}