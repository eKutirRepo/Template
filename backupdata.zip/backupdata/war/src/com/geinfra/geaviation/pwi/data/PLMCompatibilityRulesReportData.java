/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCompatibilityRulesReportData.java
 * @Creation date: 10-Apr-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMCompatibilityRulesReportData {

	private int level;
	private String name;
	private String leftExpression;
	private String compatibility;
	private String rightExpression;
	private String errorMessage;
	private String mandatory;
	private String designResp;
	private String owner;
	private String hardwareProdNameHeader;
	private String revProdNameHeader;
	private String revision;
	private String inherited;
	
	
	/**
	 * @return the inherited
	 */
	public String getInherited() {
		return inherited;
	}
	/**
	 * @param inherited the inherited to set
	 */
	public void setInherited(String inherited) {
		this.inherited = inherited;
	}
	/**
	 * @return the revision
	 */
	public String getRevision() {
		return revision;
	}
	/**
	 * @param revision the revision to set
	 */
	public void setRevision(String revision) {
		this.revision = revision;
	}
	/**
	 * @return the level
	 */
	public int getLevel() {
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(int level) {
		this.level = level;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the leftExpression
	 */
	public String getLeftExpression() {
		return leftExpression;
	}
	/**
	 * @param leftExpression the leftExpression to set
	 */
	public void setLeftExpression(String leftExpression) {
		this.leftExpression = leftExpression;
	}
	/**
	 * @return the compatibility
	 */
	public String getCompatibility() {
		return compatibility;
	}
	/**
	 * @param compatibility the compatibility to set
	 */
	public void setCompatibility(String compatibility) {
		this.compatibility = compatibility;
	}
	/**
	 * @return the rightExpression
	 */
	public String getRightExpression() {
		return rightExpression;
	}
	/**
	 * @param rightExpression the rightExpression to set
	 */
	public void setRightExpression(String rightExpression) {
		this.rightExpression = rightExpression;
	}
	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}
	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	/**
	 * @return the mandatory
	 */
	public String getMandatory() {
		return mandatory;
	}
	/**
	 * @param mandatory the mandatory to set
	 */
	public void setMandatory(String mandatory) {
		this.mandatory = mandatory;
	}
	/**
	 * @return the designResp
	 */
	public String getDesignResp() {
		return designResp;
	}
	/**
	 * @param designResp the designResp to set
	 */
	public void setDesignResp(String designResp) {
		this.designResp = designResp;
	}
	/**
	 * @return the owner
	 */
	public String getOwner() {
		return owner;
	}
	/**
	 * @param owner the owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}
	/**
	 * @return the hardwareProdNameHeader
	 */
	public String getHardwareProdNameHeader() {
		return hardwareProdNameHeader;
	}
	/**
	 * @param hardwareProdNameHeader the hardwareProdNameHeader to set
	 */
	public void setHardwareProdNameHeader(String hardwareProdNameHeader) {
		this.hardwareProdNameHeader = hardwareProdNameHeader;
	}
	/**
	 * @return the revProdNameHeader
	 */
	public String getRevProdNameHeader() {
		return revProdNameHeader;
	}
	/**
	 * @param revProdNameHeader the revProdNameHeader to set
	 */
	public void setRevProdNameHeader(String revProdNameHeader) {
		this.revProdNameHeader = revProdNameHeader;
	}
	
		
}
