/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMSearchDaoIfc.java
 * @Creation date: 17-Jan-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMEcoSearchData;
import com.geinfra.geaviation.pwi.data.PLMEcrSearchData;
import com.geinfra.geaviation.pwi.data.PLMIssuesReportData;
import com.geinfra.geaviation.pwi.data.PLMTaskSearchData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

/**
 * PLMSearchDaoIfc is the DAO interface used for PLM document search menu
 */

public interface PLMKpiReportDaoIfc {
	/**
	 * This methods is used for getIssuesData
	 * 
	 * @param searchResultsQry
	 * @param appendWhereClause
	 * @return List
	 * throws PLMCommonException
	 */
	public List<PLMIssuesReportData> getIssuesData(StringBuffer searchResultsQry, StringBuffer appendWhereClause)
			throws PLMCommonException;
	/**
	 * This methods is used for getEcoSearchData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * throws PLMCommonException
	 */
	public List<PLMEcoSearchData> getEcoSearchData(StringBuffer searchResultsQry)
			throws PLMCommonException;
	/**
	 * This methods is used for getEcrSearchData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * throws PLMCommonException
	 */
	public List<PLMEcrSearchData> getEcrSearchData(StringBuffer searchResultsQry)
			throws PLMCommonException;
	/**
	 * This methods is used for geteconamesbyselection
	 * 
	 * @param searchResultsQry
	 * @return List
	 * throws PLMCommonException
	 */
	public List<PLMEcoSearchData> geteconamesbyselection(
			StringBuffer searchResultsQry,Map<String, Object> params) throws PLMCommonException;
	/**
	 * This methods is used for getecrNameBySelection
	 * 
	 * @param searchResultsQry
	 * @return List
	 * throws PLMCommonException
	 */
	public List<PLMEcrSearchData> getecrNameBySelection(
			StringBuffer searchResultsQry,Map<String, Object> params) throws PLMCommonException;
	/**
	 * This methods is used for getEcrAffectedItems
	 * 
	 * @param ecrsessionvalue
	 * @return List
	 * throws PLMCommonException
	 */
	public List<PLMEcrSearchData> getEcrAffectedItems(
			String ecrsessionvalue) throws PLMCommonException;
	/**
	 * This methods is used for getIssuesDetailedReport
	 * 
	 * @param issuesValuesList,searchDetails
	 * @return List
	 * throws PLMCommonException
	 */
	public List<PLMIssuesReportData> getIssuesDetailedReport(
			List<String>  issuesValuesList,PLMIssuesReportData searchDetails) throws PLMCommonException;

	/**
	 * This methods is used for getDropDownvalues
	 * 
	 * @return Map
	 * throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getDropDownvalues()
			throws PLMCommonException;
	/**
	 * This methods is used for getDropDownvaluesecr
	 * 
	 * @return Map
	 * throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getDropDownvaluesecr()
			throws PLMCommonException;
	/**
	 * This methods is used for getDropDownvalueissues
	 * 
	 * @return Map
	 * throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getDropDownvalueissues()
			throws PLMCommonException;
	/**
	 * This methods is used for getTaskSearchData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * throws PLMCommonException
	 */
	public Map<String,List<PLMTaskSearchData>> getTaskSearchData(StringBuffer whereClauseQry,PLMTaskSearchData tasksearchDetails) throws PLMCommonException;
	/**
	 * This method is used for insertTaskSaveAndSearchData
	 * 
	 * @param taskSaveSearchFieldNameList
	 * @param taskSaveSearchFieldValueList
	 * @param tasksearchDetails
	 * @return int
	 * @throws PLMCommonException
	 */
	public int insertTaskSaveAndSearchData(List<String> taskSaveSearchFieldNameList,List<String> taskSaveSearchFieldValueList,PLMTaskSearchData tasksearchDetails) throws PLMCommonException;
	
	//raju for save &search
	/**
	 * This method is used for updateTaskSaveAndSearchData
	 * 
	 * @param taskSaveSearchFieldNameList
	 * @param taskSaveSearchFieldValueList
	 * @param tasksearchDetails
	 * @return int
	 * @throws PLMCommonException
	 */
	public int updateTaskSaveAndSearchData(List<String> taskSaveSearchFieldNameList,List<String> taskSaveSearchFieldValueList,PLMTaskSearchData tasksearchDetails) throws PLMCommonException;
	/**
	 * This method is used for queryNameCheck
	 * 
	 * @param queryName,ssoId
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean queryNameCheck(String ssoId,String queryName) throws PLMCommonException;
	/**
	 * This method is used for displaySaveAndSearchQuries
	 * 
	 * @param ssoId
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> displaySaveAndSearchQuries(String ssoId) throws PLMCommonException;
	/**
	 * This method is used for deleteQryNameByCheckboxSelection
	 * 
	 * @param selectedQueryName,ssoId
	 * @return int
	 * @throws PLMCommonException
	 */
	public int deleteQryNameByCheckboxSelection(String selectedQueryName,String ssoId) throws PLMCommonException;
	/**
	 * This method is used for getTaskSearchSavedFields
	 * 
	 * @param selectedQueryName
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> getTaskSearchSavedFields(String selectedQueryName) throws PLMCommonException;
	/**
	 * This method is used for getAssigneeList
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */	
	public List<PLMTaskSearchData> getAssigneeList(StringBuffer searchResultsQry) throws PLMCommonException;
	/**
	 * This method is used for getTaskDetailedReport
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> getTaskDetailedReport(StringBuffer searchResultsQuery) throws PLMCommonException;
	/**
	 * This method is used for getPartDropDownvalues
	 * 
	 * @param searchResultsQry
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getRdoValues() throws PLMCommonException;
	/**
	 * This method is used for displaySelectedEccnTag
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> displaySelectedEccnTag() throws PLMCommonException;
		/**
	 * This method is used for getTaskDetailDiscussionRpt
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> getTaskDetailDiscussionRpt(StringBuffer searchResultsQuery) throws PLMCommonException;
	/**
	 * This method is used for getTaskDropDownValues
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getTaskDropDownValues()throws PLMCommonException;

	//ADDED BY SUDHAKAR FOR PREDESSOR SUCCESSOR PAGE
	/**
	 * This method is used for getSucesPredessorData
	 * 
	 * @param searchResultsQry
	 * @param selectedTaskDetails
	 * @param selectedId
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> getSucesPredessorData(StringBuffer searchResultsQry,String selectedTaskDetails,Map<String,String> selectedId)throws PLMCommonException;

	//ENDED BY SUDHAKAR FOR PREDESSOR SUCCESSOR PAGE

	/**
	 * This method is used for fetchTaskSearchDetails
	 * 
	 * @param seqId
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> fetchTaskSearchDetails(String seqId) throws PLMCommonException;
    
	//public String queryNameModify(String seqID) throws PLMCommonException ;
	
	/**
	 * This method is used for getEccnOnScreenValues
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> getEccnOnScreenReport(List <String> rdoNamesList, List <String> eccnTagList) throws PLMCommonException;
	
	/**
	 * This method is used for getEccnOnScreenValues
	 * 
	 * @param searchResultsQry
	 * @param eccnTagList
	 * @param filePath
	 * @param destination
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, Object> createEccnCSVFile(StringBuffer searchResultsQry, List<String> rdoNamesList, List<String> eccnTagList, String filePath, String destination) throws PLMCommonException;
	
	//Newly added by srinivas for 3.0.7 
	/**
	 * This method is used to get Task Detailed Report task detail page filter for deliverable type 
	 * 
	 * @param selectedTaskDetails
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> getTaskDetailedRptDeliverable(StringBuffer whereClauseQry, PLMTaskSearchData plmSearchDataLcl,String selectedTaskDetails) throws PLMCommonException;
	
	public List<String> getUniquePartNamesForECR(String ecrsessionvalue);
	
	public List<PLMEcrSearchData> getPartsNotHavingRevOthrECR(String ecrsessionvalue);


}
