/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBomTrendsData.java
 * @Creation date: 15-June-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMBomTrendsData {
	/**
	  * Holds the rdoName
	  */
	private String rdoName;
	/**
	  * Holds the productconfigNumber
	  */
	private String productconfigNumber;
	/**
	  * Holds the partsReuse
	  */
	private String partsReuse;
	/**
	  * Holds the newPart
	  */
	private String newPart;
	/**
	  * Holds the partsChange
	  */
	private String partsChange;
	/**
	  * Holds the partChangeRe
	  */
	private String partChangeRe;
	/**
	  * Holds the partsChangeOrder
	  */
	private String partsChangeOrder;
	
	/**
	 * @return Returns the productconfigNumber
	 */
	public String getProductconfigNumber() {
		return productconfigNumber;
	}
	/**
	 * @param productconfigNumber The productconfigNumber to set.
	 */
	public void setProductconfigNumber(String productconfigNumber) {
		this.productconfigNumber = productconfigNumber;
	}
	/**
	 * @return Returns the rdoName
	 */
	public String getRdoName() {
		return rdoName;
	}
	/**
	 * @param rdoName The rdoName to set.
	 */
	public void setRdoName(String rdoName) {
		this.rdoName = rdoName;
	}
	/**
	 * @return Returns the partsReuse
	 */
	public String getPartsReuse() {
		return partsReuse;
	}
	/**
	 * @param partsReuse The partsReuse to set.
	 */
	public void setPartsReuse(String partsReuse) {
		this.partsReuse = partsReuse;
	}
	/**
	 * @return Returns the newPart
	 */
	public String getNewPart() {
		return newPart;
	}
	/**
	 * @param newPart The newPart to set.
	 */
	public void setNewPart(String newPart) {
		this.newPart = newPart;
	}
	/**
	 * @return Returns the partsChange
	 */
	public String getPartsChange() {
		return partsChange;
	}
	/**
	 * @param partsChange The partsChange to set.
	 */
	public void setPartsChange(String partsChange) {
		this.partsChange = partsChange;
	}
	/**
	 * @return Returns the partChangeRe
	 */
	public String getPartChangeRe() {
		return partChangeRe;
	}
	/**
	 * @param partChangeRe The partChangeRe to set.
	 */
	public void setPartChangeRe(String partChangeRe) {
		this.partChangeRe = partChangeRe;
	}
	/**
	 * @return Returns the partsChangeOrder
	 */
	public String getPartsChangeOrder() {
		return partsChangeOrder;
	}
	/**
	 * @param partsChangeOrder The partsChangeOrder to set.
	 */
	public void setPartsChangeOrder(String partsChangeOrder) {
		this.partsChangeOrder = partsChangeOrder;
	}

}
