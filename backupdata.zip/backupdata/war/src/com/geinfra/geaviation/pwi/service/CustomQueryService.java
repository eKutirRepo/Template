package com.geinfra.geaviation.pwi.service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.QueryAccessException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.context.PWiContext;
import com.geinfra.geaviation.pwi.dao.CustomQueryDAO;
import com.geinfra.geaviation.pwi.model.PWiFrequencyTypeVO;
import com.geinfra.geaviation.pwi.model.PWiUserCustomQueryVO;
import com.geinfra.geaviation.pwi.service.vo.QueryUserOptions;
import com.geinfra.geaviation.pwi.xml.SearchInputXmlReader;
import com.geinfra.geaviation.pwi.xml.SelectedColumnsXmlReader;

/**
 * Project : Product Lifecycle Management Date Written : Apr 20, 2011 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : CustomQueryService
 * 
 * Revision Log Apr 20, 2011 | v1.0.
 * --------------------------------------------------------------
 */
public class CustomQueryService extends BaseBean{
	// Injected
	private QuerySubmissionService querySubmissionService;
	private CustomQueryDAO customQueryDAO;

	public void setQuerySubmissionService(
			QuerySubmissionService querySubmissionService) {
		this.querySubmissionService = querySubmissionService;
	}

	public void setCustomQueryDAO(CustomQueryDAO customQueryDAO) {
		this.customQueryDAO = customQueryDAO;
	}

	public boolean addQueriesAsFavorite(PWiUserCustomQueryVO vo) {
		return customQueryDAO.addQueriesAsFavorite(vo);
	}

	/**
	 * To cancel the subscription of custom queries
	 * 
	 * @param strUserSSOId
	 * @param prtyCstmQrySeqId
	 * @return success or failure as integer
	 */
	public int cancelFavoriteQuerySubscriptionById(String strUserSSOId,
			int prtyCstmQrySeqId) {
		return customQueryDAO.cancelFavoriteQuerySubscriptionById(strUserSSOId,
				prtyCstmQrySeqId);
	}

	/**
	 * Creates a new favorite.
	 * 
	 * @param queryId
	 * @param customName
	 * @param options
	 * @return the number of favorites created (should be one on success, zero
	 *         on fail)
	 * @throws PWiException
	 * @throws QueryAccessException
	 */
	public int createFavorite(Integer queryId, String customName,
			QueryUserOptions options) throws PWiException,
			QueryAccessException {
		// Ensure user has access to query
		querySubmissionService.verifyQueryPermissions(queryId);

		String sso = PWiContext.getCurrentInstance().getUserSso();
		String searchXml = new SearchInputXmlReader().generateXml(options
				.getSearch());
		String selectedColumnsXml = new SelectedColumnsXmlReader()
				.generateXml(options.getSelectedColumns());

		return customQueryDAO.insertCustomQuery(sso, queryId, customName,
				searchXml, selectedColumnsXml, null, null, options
						.getQueryProcessorId());
	}

	/**
	 * To delete favorite custom queries.
	 * 
	 * @param prtyCstmQrySeqId
	 * @return Number of favorite custom queries deleted.
	 */
	public int deleteFavoriteQueryById(Integer prtyCstmQrySeqId) {
		return customQueryDAO.deleteFavoriteQueryById(prtyCstmQrySeqId);
	}

	/**
	 * To delete favorite custom queries from the queries search page.  All
	 * favorite custom queries for the given query id without options specified
	 * will be deleted from the favorites view
	 * 
	 * @param strUserSSOId
	 * @param queryId
	 * @return Number of favorite custom queries deleted.
	 */
	public int deleteFavoriteQueriesForSearch(String strUserSSOId,
			Integer queryId) {
		return customQueryDAO.deleteFavoriteQueriesForSearch(strUserSSOId,
				queryId);
	}

	public List<PWiUserCustomQueryVO> getAllFavoriteQueriesforUser(
			String strUserSSOId) {
		return customQueryDAO.getAllFavoriteQueriesforUser(strUserSSOId);
	}

	public List<PWiFrequencyTypeVO> getAllSubscrictionFrequencies() {
		return customQueryDAO.getSubscriptionFrquencies();

	}

	public PWiUserCustomQueryVO getFavoriteById(Integer favId) {
		return customQueryDAO.getUserCustomQueryById(favId);
	}

	public List<PWiUserCustomQueryVO> getSubscribedQueries() {
		return customQueryDAO.getSubscribedQueries();
	}

	/**
	 * To update subscription frequency for favorite custom queries.
	 * 
	 * @param ssoId
	 * @param trprtyCstmQrySeqId
	 * @param frqncyTypSeqId
	 * @param nextExeDate
	 * @param currQryRsltFlPthTxt
	 * @param prrQryRsltFlPthTxt
	 * @return Number of subscriptions updated.
	 */
	public int modifySubscrptnFavoriteQueriesforUser(String ssoId,
			Integer trprtyCstmQrySeqId, Integer frqncyTypSeqId,
			Timestamp nextExeDate, String currQryRsltFlPthTxt,
			String prrQryRsltFlPthTxt) {
		return customQueryDAO.modifySubscrptnFavoriteQueriesforUser(ssoId,
				trprtyCstmQrySeqId, frqncyTypSeqId, nextExeDate,
				currQryRsltFlPthTxt, prrQryRsltFlPthTxt);
	}

	public boolean updateSubscriptionResult(Integer cstmQrySeqId, Date nxtdt,
			String prevFile, String currFile, String comparisonFile) {
		return customQueryDAO.updateSubscriptionResult(cstmQrySeqId, nxtdt,
				prevFile, currFile, comparisonFile);
	}

}
