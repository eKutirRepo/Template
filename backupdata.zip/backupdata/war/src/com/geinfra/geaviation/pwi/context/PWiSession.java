package com.geinfra.geaviation.pwi.context;

import javax.servlet.http.HttpSession;

import com.geinfra.geaviation.pwi.common.PWiException;

/**
 * Project : Product Lifecycle Management Date Written : Apr 13, 2011 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description :
 * 
 * Since the external context returns session as type Object, retrieving
 * information from the session requires having to determine what type of object
 * the session is and then having to cast. This class abstracts away that
 * functionality so that we can get information from the session without
 * worrying about determining the class of the session.
 * 
 * This class has been written to handle the two common session types we use --
 * HttpSession and PortletSession -- and provides methods to access information
 * common to both that we are interested in.
 * 
 * Revision Log Apr 13, 2011 | v1.0.
 * --------------------------------------------------------------
 */
public abstract class PWiSession {
	public static PWiSession getPWiSession(Object sessionObject)
			throws PWiException {
		if (sessionObject instanceof HttpSession) {
			return new HttpSessionAdapter((HttpSession) sessionObject);
		} else {
			throw new PWiException("Unsupported session object type: "
					+ sessionObject);
		}
	}

	public abstract PWiApplication getApplication() throws PWiException;

	public abstract String getId();

	public abstract Object getAttribute(String attributeName);

	public abstract void removeAttribute(String attributeName);

	private static class HttpSessionAdapter extends PWiSession {
		HttpSession httpSession;

		public HttpSessionAdapter(HttpSession httpSession) {
			this.httpSession = httpSession;
		}

		public PWiApplication getApplication() throws PWiException {
			return PWiApplication.getPWiApplication(httpSession
					.getServletContext());
		}

		public String getId() {
			return httpSession.getId();
		}

		public Object getAttribute(String attributeName) {
			return httpSession.getAttribute(attributeName);
		}

		public void removeAttribute(String attributeName) {
			httpSession.removeAttribute(attributeName);
		}
	}
}