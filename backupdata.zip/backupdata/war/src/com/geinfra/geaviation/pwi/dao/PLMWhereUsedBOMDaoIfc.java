/**
 * Copyright (C) 2017 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhereUsedBOMDaoIfc.java
 * @Creation date: 16-November-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import com.geinfra.geaviation.pwi.data.PLMWhereUsedBOMData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMWhereUsedBOMDaoIfc {

	/**
	 * This method is used to fetch BOM Implosion  Where Used Tool data
	 * 
	 * @param partList
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String,List<PLMWhereUsedBOMData>> fetchBOMImplsnWhereUsedData(List<PLMWhereUsedBOMData> partList, String levelsUpTo, int level) throws PLMCommonException;
}
