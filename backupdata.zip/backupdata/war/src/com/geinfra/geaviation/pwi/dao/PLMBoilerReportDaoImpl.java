/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBoilerReportDaoImpl.java
 * @Creation date: 17-Feb-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMBoilerReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMBoilerReportDaoImpl extends SimpleJdbcDaoSupport implements PLMBoilerReportDaoIfc{

	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMBoilerReportDaoImpl.class);
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	
	
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}
	/**
	 * This method is used for getProjectNameAndTaskList
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public Map<String, List<SelectItem>> getProjectNameAndTaskList() throws PLMCommonException {
		LOG.info("Inside getProjectNameAndTaskList method of PLMBoilerReportDaoImpl class");
		Map<String, List<SelectItem>> dropdownlist = new HashMap<String, List<SelectItem>>();		
		List<SelectItem> taskNameList = null;
		List<SelectItem> taskStateList = null;
		try {			
			
			LOG.info("Query for getting distinct Task Name List : " + PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_TASK);
			taskNameList = getJdbcTemplate().query(PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_TASK, new DstnctTaskMapper());		
			Collections.sort(taskNameList, new PLMUtils.SortListSelItem());
			LOG.info("size of  Task Name List : " + taskNameList.size());
			
			LOG.info("Query for getting distinct Task State List : " + PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_TASK_STATE);
			taskStateList = getJdbcTemplate().query(PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_TASK_STATE, new DstnctTaskStateMapper());		
			Collections.sort(taskStateList, new PLMUtils.SortListSelItem());
			LOG.info("size of  Task State List : " + taskStateList.size());
			
			dropdownlist.put("tasknamelist", taskNameList);
			dropdownlist.put("taskstatelist", taskStateList);
			

		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return dropdownlist;
	}
	
	/**
	 * Row mapper for getting DISTINCT PROJECTS
	 */
	private static final class DstnctPrjMapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(rs
					.getString("PROJECT_NAME").toUpperCase());

			return selectItem;

		}
	}
	/**
	 * Row mapper for getting DISTINCT TASK STATE
	 */
	private static final class DstnctTaskStateMapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(rs
					.getString("STATE").toUpperCase());

			return selectItem;

		}
	}
	/**
	 * Row mapper for getting DISTINCT TASKS
	 */
	private static final class DstnctTaskMapper implements ParameterizedRowMapper<SelectItem>{
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs
					.getString("NAME").toUpperCase());
			return selectItem;
		}
	}
	
	/**
	 * This method is used to getStrBufferConsolidate 
	 * @param list
	 * @param String
	 * @return StringBuffer
	 * @throws PLMCommonException
	 */
	public StringBuffer getStrBufferConsolidate(List<String> colList,String colName) throws PLMCommonException{
		LOG.info("Entering getStrBufferConsolidate() method.");
		StringBuffer sqlQuery =new StringBuffer();
		try{
			if(!PLMUtils.isEmptyList(colList)){
				int vtCntInt =0;
				int vtCntIncr=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				int vtCntLimit=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				int val = 0;
				int loopCount = 0;
				int partListCnt=colList.size();
				boolean vtFlag=false;
				
				if(partListCnt <=vtCntLimit){
					loopCount = 1;
				}else{
					loopCount = partListCnt/vtCntLimit;				
					val = partListCnt - (vtCntLimit * loopCount);
					  if (val > 0) {
						loopCount++;					
					   }
				}
				
				for (int i=0;i<loopCount;i++) {
					if(vtCntIncr > partListCnt){
						vtCntIncr=partListCnt;
					 }
					List <String> partNumListLcl = new ArrayList<String>();
					LOG.info("-------------------Loop Rotating from part list index "+vtCntInt +" and "+vtCntIncr);
					 for(int j=vtCntInt;j<vtCntIncr;j++){
						 partNumListLcl.add(colList.get(j));
					 }
					if(!vtFlag){
						sqlQuery.append(""+colName+" IN ("+PLMUtils.setListForQuery(partNumListLcl)+")");
						vtFlag =true;
					}else{
						sqlQuery.append(" OR "+colName+" IN ("+PLMUtils.setListForQuery(partNumListLcl)+")");
					}
					vtCntInt =vtCntIncr+1;
					if(vtCntIncr > partListCnt){
						vtCntIncr=partListCnt;
					 }else{
					  vtCntIncr =vtCntIncr+Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
					 }
				}
			}
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getStrBufferConsolidate() method.");
		return sqlQuery;
	}
	
	/**
	 * This method is used to Generate backlog Report
	 * @param selBacklogProjectName
	 * @param allOpenPrjName
	 * @param selBacklogTaskName
	 * @param allOpenTaskName
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMBoilerReportData> generateBacklogAppReport(List<String> selBacklogProjectName, boolean allOpenPrjName,List<String> selBacklogTaskName, boolean allOpenTaskName,List<String> selBacklogTaskState,List<SelectItem> projectList,List<SelectItem> taskList,String owner)
			throws PLMCommonException {
		LOG.info("Entering into  generateBacklogAppReport");
		List <PLMBoilerReportData> fmiappReportList= new ArrayList <PLMBoilerReportData>();
		StringBuffer sqlQuery = new StringBuffer();
		boolean whereFlag=false;
		 try {
				
				sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_BOILER_BACKLOG_REPORT);
				sqlQuery.append(" WHERE (");
				if(!PLMUtils.isEmptyList(selBacklogProjectName)){
					 if(!whereFlag){
						 if(selBacklogProjectName.size()==projectList.size()){
							 sqlQuery.append("T_PRJ_SPACE.NAME IN(SELECT DISTINCT NAME FROM GEEDW_PWPLM_ODS_BULK_V.CDR_PWODS_T_PRJ_SPACE)");
						 }else{
						 sqlQuery.append(getStrBufferConsolidate(selBacklogProjectName, "T_PRJ_SPACE.NAME"));
						 }
						 if(!PLMUtils.isEmptyList(selBacklogTaskState))
						 {
						 sqlQuery.append(" AND T_TASK.STATE IN("); 
						 sqlQuery.append(PLMUtils.setListForQuery(selBacklogTaskState));
						 sqlQuery.append(")");
						 }
					 	whereFlag=true;
					 }
				}
				
				if(!PLMUtils.isEmptyList(selBacklogTaskName)){
					 if(!whereFlag){
						 if(selBacklogTaskName.size()==taskList.size()){
							 sqlQuery.append(" T_TASK.NAME IN(SELECT DISTINCT T_TASK.NAME AS TASK_NAME FROM GEEDW_PWPLM_ODS_BULK_V.CDR_PWODS_T_TASK T_TASK INNER JOIN GEEDW_PWPLM_ODS_BULK_V.CDR_PWODS_R_SUBTASK R_SUBTASK");
							 sqlQuery.append(" ON  T_TASK.ID=R_SUBTASK.TO_ID INNER JOIN GEEDW_PWPLM_ODS_BULK_V.CDR_PWODS_T_PRJ_SPACE T_PRJ_SPACE ON R_SUBTASK.FROM_ID=T_PRJ_SPACE.ID)");
						 }else{
							 sqlQuery.append(getStrBufferConsolidate(selBacklogTaskName, "T_TASK.NAME"));
						 }
						 
						 if(!PLMUtils.isEmptyList(selBacklogTaskState))
						 {
						 sqlQuery.append(" AND T_TASK.STATE IN("); 
						 sqlQuery.append(PLMUtils.setListForQuery(selBacklogTaskState));
						 sqlQuery.append(")");
						 }
					 }
					 else{
						 sqlQuery.append(" AND (");
						 if(selBacklogTaskName.size()==taskList.size()){
							 sqlQuery.append(" T_TASK.NAME IN(SELECT DISTINCT T_TASK.NAME AS TASK_NAME FROM GEEDW_PWPLM_ODS_BULK_V.CDR_PWODS_T_TASK T_TASK INNER JOIN GEEDW_PWPLM_ODS_BULK_V.CDR_PWODS_R_SUBTASK R_SUBTASK");
							 sqlQuery.append(" ON  T_TASK.ID=R_SUBTASK.TO_ID INNER JOIN GEEDW_PWPLM_ODS_BULK_V.CDR_PWODS_T_PRJ_SPACE T_PRJ_SPACE ON R_SUBTASK.FROM_ID=T_PRJ_SPACE.ID)");
						 }else{
							 sqlQuery.append(getStrBufferConsolidate(selBacklogTaskName, "T_TASK.NAME"));
						 }
						 sqlQuery.append(")");
						 
					 }
					
				 	whereFlag=true;
				}
				if(PLMUtils.isEmptyList(selBacklogTaskName) && PLMUtils.isEmptyList(selBacklogProjectName) && !PLMUtils.isEmptyList(selBacklogTaskState)){
					sqlQuery.append(" T_TASK.STATE IN(");
					 sqlQuery.append(PLMUtils.setListForQuery(selBacklogTaskState));
					 sqlQuery.append(")");
					whereFlag=true;
				}
				if(!PLMUtils.isEmpty(owner))
				{
					List<String> ownerList = new ArrayList<String>();
					String[] test = owner.trim().split(",");
					for(String i:test){
						ownerList.add(i);
					}
					sqlQuery.append(" AND T_PRJ_SPACE.OWNER1 IN(");
					 sqlQuery.append(PLMUtils.setListForQuery(ownerList));
					 sqlQuery.append(")");
					whereFlag=true;
				}
				sqlQuery.append(")");
				
				LOG.info("Final Query for backlog report:: "+sqlQuery);
				fmiappReportList =  getJdbcTemplate().query(sqlQuery.toString(), new BacklogMapper());	
				LOG.info("backlog report Record Count:: "+fmiappReportList.size());
					
			} catch (DataAccessException e) {
				PLMUtils.checkException(e.getMessage());
			}catch (Exception e) {
				PLMUtils.checkException(e.getMessage());
			}
			return fmiappReportList;
	}
	private static final class BacklogMapper implements ParameterizedRowMapper<PLMBoilerReportData> {
		public PLMBoilerReportData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
					"MM/dd/yyyy");
			PLMBoilerReportData tempData =new PLMBoilerReportData();
			tempData.setTaskName(PLMUtils.checkNullVal(rs.getString("TASK_NAME")));
			tempData.setTaskState(PLMUtils.checkNullVal(rs.getString("TASK_STATE")));
			tempData.setTaskDescription(PLMUtils.checkNullVal(rs.getString("TASK_DESCRIPTION")));
			
			if(rs.getDate("TASK_CREATION_DATE")!=null)
			{
				try {
					tempData.setTaskCrtnDateNew(SIMPLE_DATE_FORMAT.parse(SIMPLE_DATE_FORMAT.format(rs.getDate("TASK_CREATION_DATE"))));
					tempData.setTaskCrtnDate(SIMPLE_DATE_FORMAT.format(rs.getDate("TASK_CREATION_DATE")));
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
			if(rs.getDate("TASK_ESTD_FINISH_DATE")!=null)
			{
				try {
					tempData.setTaskEstdFinishDateNew(SIMPLE_DATE_FORMAT.parse(SIMPLE_DATE_FORMAT.format(rs.getDate("TASK_ESTD_FINISH_DATE"))));
					tempData.setTaskEstdFinishDate(SIMPLE_DATE_FORMAT.format(rs.getDate("TASK_ESTD_FINISH_DATE")));
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
			tempData.setTaskDuration(PLMUtils.checkNullVal(rs.getString("TASK_DURATION")).substring(0,
					PLMUtils.checkNullVal(rs.getString("TASK_DURATION")).lastIndexOf(".")+4));
			tempData.setProjectName(PLMUtils.checkNullVal(rs.getString("PROJECT_NAME")));
			tempData.setPrjOwner(PLMUtils.checkNullVal(rs.getString("PROJECT_OWNER")));
			tempData.setPrjState(PLMUtils.checkNullVal(rs.getString("PROJECT_STATE")));
			tempData.setCntName(PLMUtils.checkNullVal(rs.getString("CONTRACT_NAME")));
			tempData.setCstmrName(PLMUtils.checkNullVal(rs.getString("CUSTOMER")));
			return tempData;
		}
	}

	/**
	 * This method is used to fetch PC Info
	 * 
	 * @param cntrtNm
	 * @param cstGrpList
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMBoilerReportData> fetchPCInfo(List<String> cstGrpList,List<SelectItem> projectList,boolean allOpenPrjName) throws PLMCommonException{
		StringBuffer searchQuery =new StringBuffer();
		searchQuery.append(PLMSearchQueries.GET_TASK_INFO_QUERY);
		LOG.info("cstGrpList size ------------- " + cstGrpList.size());
		LOG.info("projectList size ------------- " + projectList.size());
		if(!PLMUtils.isEmptyList(cstGrpList)){
				searchQuery.append(" WHERE (");
				searchQuery.append(getStrBufferConsolidate(cstGrpList, "T_PRJ_SPACE.NAME"));
				searchQuery.append(")");
		}else if(PLMUtils.isEmptyList(cstGrpList) && !PLMUtils.isEmptyList(projectList) && allOpenPrjName==true) {
			List<String> temp = new ArrayList<String>();
			for(int i = 0; i < projectList.size(); i++) {
				temp.add(projectList.get(i).getValue().toString());
			}
			searchQuery.append(" WHERE (");
			searchQuery.append(getStrBufferConsolidate(temp, "T_PRJ_SPACE.NAME"));
			searchQuery.append(")");
			//searchQuery.append(" WHERE ");
			//searchQuery.append("T_PRJ_SPACE.NAME IN(SELECT DISTINCT NAME FROM GEEDW_PWPLM_ODS_BULK_V.CDR_PWODS_T_PRJ_SPACE )");
		}
		LOG.info("Executing GET_PC_INFO_QUERY : " + searchQuery.toString() + "\n");
		return getJdbcTemplate().query(searchQuery.toString(), new PcInfoMapper());
	}
	/**
	 * This method is used to fetch Task Info
	 * 
	 * @param cstGrpList
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMBoilerReportData> fetchTaskFromTaskState(List<String> cstGrpList) throws PLMCommonException{
		StringBuffer searchQuery =new StringBuffer();
		    searchQuery.append(PLMSearchQueries.GET_TASK_INFO_QUERY);
		   if(!PLMUtils.isEmptyList(cstGrpList)){
			searchQuery.append(" WHERE T_TASK.STATE IN(");
			searchQuery.append(PLMUtils.setListForQuery(cstGrpList));
			searchQuery.append(")");
		   }
		LOG.info("Executing GET_PC_INFO_QUERY : " + searchQuery.toString() + "\n");
		return getJdbcTemplate().query(searchQuery.toString(), new PcInfoMapper());
	}
	
	
	/**
	 * @return PLMCFCRPRSRptData objects.
	 */
	private static final class PcInfoMapper implements ParameterizedRowMapper<PLMBoilerReportData> {
		public PLMBoilerReportData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMBoilerReportData data = new PLMBoilerReportData();
			data.setTaskName(PLMUtils.checkNullVal(rs.getString("TASK_NAME")));
			return data;
		}
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<SelectItem> projectFamilyAutocomplete(String selectedPrjName)
			throws PLMCommonException {
		List<SelectItem> projectNameList = new ArrayList<SelectItem>();
		try{
		
		StringBuffer sb = new StringBuffer();
		sb.append(PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_PROJECT);
		if(!PLMUtils.isEmpty(selectedPrjName)){
			sb.append(" where PROJECT_NAME like'");
			sb.append(selectedPrjName);
			sb.append("%'");
		}
		LOG.info("Query for getting distinct Project Name List : " + sb.toString());
		projectNameList = getJdbcTemplate().query(sb.toString(),new DstnctPrjMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return projectNameList;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<SelectItem> taskFamilyAutocomplete(String selectedTaskName)
			throws PLMCommonException {
		List<SelectItem> taskNameList = new ArrayList<SelectItem>();
		try{
			StringBuffer sb = new StringBuffer();
			sb.append(PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_TASK);
			if(!PLMUtils.isEmpty(selectedTaskName)){
				sb.append(" where T_TASK.NAME like'");
				sb.append(selectedTaskName);
				sb.append("%'");
			}
		LOG.info("Query for getting distinct Task Name List : " + sb.toString());
		taskNameList = getJdbcTemplate().query(sb.toString(),new DstnctTaskMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return taskNameList;
	}

}
