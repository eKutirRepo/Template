 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileNamePLMABITSearchMB.java
 * @Creation date: 03-Nov-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.bean;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.data.PLMABITData;
import com.geinfra.geaviation.pwi.service.PLMCopicsSearchServiceImpl;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

public class PLMABITSearchMB {
	/**
	 * Holds the count
	 */
	private int count;
	/**
	 * Holds the itemIDInput
	 */
	private String itemIDInput;
	/**
	 * Holds the itemCmntInput
	 */
	private String itemCmntInput;
	/**
	 * Holds the itemSrcInput
	 */
	private String itemSrcInput;
	/**
	 * Holds the itemID
	 */
	private String itemID = "";
	/**
	 * Holds the itemComments
	 */
	private String itemComments = "";
	/**
	 * Holds the itemSource
	 */
	private String itemSource = "";
	/**
	 * Holds the plmCopicsSearchService
	 */
	private PLMCopicsSearchServiceImpl plmCopicsSearchService=null;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the totalRecCountMsg
	 */
	private String totalRecCountMsg = null;
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the searchResultList
	 */
	private List<PLMABITData> searchResultList;
	/**
	 * Holds the Logger
	 */
	private static final Logger LOG = Logger.getLogger(PLMABITSearchMB.class);
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;

	/**
	 * This method is used for Loading Result Data
	 * 
	 * @return String
	 */
	public String getResultData() {
		LOG.info("In getResultData() Method.");
		String fwdFlag = "";
		totalRecCount = 0;
		this.itemIDInput = getTrimValue(this.itemIDInput);
		this.itemCmntInput = getTrimValue(this.itemCmntInput);
		this.itemSrcInput = getTrimValue(this.itemSrcInput);

		if ((PLMUtils.isEmpty(this.itemIDInput))
				&& (PLMUtils.isEmpty(this.itemCmntInput))) {
			alertMessage = alertMessage + PLMConstants.AbitSearch_SRCH_CRIT;

		} else {
			if (!PLMUtils.isEmpty(this.itemIDInput)
					&& !PLMUtils
							.checkForSpecialCharsForAbitSearch(this.itemIDInput)) {
				alertMessage = alertMessage + PLMConstants.ItemId_SplValMsg;
				fwdFlag = "abitsearch";
			}
			if (!PLMUtils.isEmpty(this.itemCmntInput)
					&& !PLMUtils
							.checkForSpecialCharsForAbitSearch(this.itemCmntInput)) {
				alertMessage = alertMessage + PLMConstants.ItemCommt_SplValMsg;
				fwdFlag = "abitsearch";
			}
		}

		if (PLMUtils.isEmpty(alertMessage)) {
			try {
				this.searchResultList = this.plmCopicsSearchService
						.getSearchDetails(this.itemIDInput, this.itemCmntInput,
								this.itemSrcInput);
				if (this.searchResultList != null) {
					totalRecCount = this.searchResultList.size();
				} else {
					totalRecCount = 0;
				}
				totalRecCountMsg = "Total Results Count : " + totalRecCount;
				LOG.info("totalRecCount::::::::::::::::::" + totalRecCount);
				if (totalRecCount == 0) {
					fwdFlag = "norecordsabit";
				} else {
					recordCounts = PLMConstants.N_100;
					fwdFlag = "abitsearchresult";
				}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getResultData: ", exception);
				fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"abitsearch","ABIT Search");
			}
		}
		return fwdFlag;
	}

	/**
	 * This method is used for Loading Data
	 * 
	 * @return String
	 */
	public String getLoadingData() {
		try {
			commonMB.insertCannedRptRecordHitInfo("ABIX - COPICS Part Content");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		alertMessage = "";
		resetAbitSearchData();
		String fwdFlag = "abitsearch";
		return fwdFlag;
	}
	
	/**
	 * This method is used for reset of Abit search Data
	 * 
	 * @return String
	 */
	public String resetAbitSearchData() {
		String fwdFlag = "abitsearch";
		this.setItemIDInput("");
		this.setItemCmntInput("");
		return fwdFlag;
	}

	public String getAlertMessage() {
		return this.alertMessage;
	}

	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/*
	 * This method may be useful in future. public void printResultsToPDF()
	 * throws PLMCommonException { GeneratePDFDocs pdfUtilHandle = new
	 * GeneratePDFDocs(); try {
	 * pdfUtilHandle.generateABITResultsPDF(this.searchResultList); } catch
	 * (Exception e) {  } }
	 */

	public int getCount() {
		return this.count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getTrimValue(String value) {
		String retStr = null;
		if (!PLMUtils.isEmpty(value)) {
			retStr = value.trim();
		}
		return retStr;
	}

	public int getRecordCounts() {
		return this.recordCounts;
	}

	public void setRecordCounts(int recordCounts) {
		PLMUtils.getServletSession(true).setAttribute("RecDropDown",
				Integer.valueOf(recordCounts));
		this.recordCounts = recordCounts;
	}

	public int getTotalRecCount() {
		return this.totalRecCount;
	}

	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	public String getPlmhomeframepage() {
		return "bkhomeFromLegal";
	}

	public String getTotalRecCountMsg() {
		return this.totalRecCountMsg;
	}

	public void setTotalRecCountMsg(String totalRecCountMsg) {
		this.totalRecCountMsg = totalRecCountMsg;
	}

	public String getItemIDInput() {
		return this.itemIDInput;
	}

	public void setItemIDInput(String itemIDInput) {
		this.itemIDInput = itemIDInput;
	}

	public String getItemID() {
		return this.itemID;
	}

	public void setItemID(String itemID) {
		this.itemID = itemID;
	}

	public String getItemComments() {
		return this.itemComments;
	}

	public void setItemComments(String itemComments) {
		this.itemComments = itemComments;
	}

	public PLMCopicsSearchServiceImpl getPlmCopicsSearchService() {
		return this.plmCopicsSearchService;
	}

	public void setPlmCopicsSearchService(
			PLMCopicsSearchServiceImpl plmCopicsSearchService) {
		this.plmCopicsSearchService = plmCopicsSearchService;
	}

	public List<PLMABITData> getSearchResultList() {
		return this.searchResultList;
	}

	public void setSearchResultList(List<PLMABITData> searchResultList) {
		this.searchResultList = searchResultList;
	}

	public String getItemCmntInput() {
		return this.itemCmntInput;
	}

	public void setItemCmntInput(String itemCmntInput) {
		this.itemCmntInput = itemCmntInput;
	}

	public String getItemSrcInput() {
		return this.itemSrcInput;
	}

	public void setItemSrcInput(String itemSrcInput) {
		this.itemSrcInput = itemSrcInput;
	}

	public String getItemSource() {
		return this.itemSource;
	}

	public void setItemSource(String itemSource) {
		this.itemSource = itemSource;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	
	public void downloadExcel() throws PLMCommonException {

		LOG.info("Entering downloadExcel ABIX Report Method");
		String reportName = "ABIXSearchResults";
		String fileName = "ABIXSearchResults";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();

		PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
				new PLMXlsxRptColumn("itemID", "Item ID",
						FormatType.TEXT, null, null, 20),
				new PLMXlsxRptColumn("itemComments", "Item Comments",
						FormatType.TEXT, null, null, 110),
				new PLMXlsxRptColumn("itemSource", "Item Source",
						FormatType.TEXT)

		};

		excelUtil.export(searchResultList, reportColumns, fileName, fileName,
				false, null, null);

	}
	
	public void downloadCSV() throws PLMCommonException {

		LOG.info("Entering downloadCSV ABIX Report Method");
		String reportName = "ABIXSearchResults";
		String fileName = "ABIXSearchResults";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
				new PLMCsvRptColumn("itemID", "Item ID",FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("itemComments", "Item Comments",FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("itemSource", "Item Source",FormatTypeCsv.TEXT)
		};
		csvUtil.exportCsv(searchResultList,reportColumns,fileName,dateFormat,false, null, null,",");

	}
	
	
	public void recordsPerPageListner(ActionEvent event) {
		LOG.info("Entering recordsPerPageListner method");
		LOG.info("Action listner called.....--------------------------->"
				+ recordCounts);
		if (recordCounts == 15) {
			LOG.info("15");
			recordCounts = 15;
		} else if (recordCounts == 30) {
			LOG.info("30");
			recordCounts = 30;
		} else if (recordCounts == 50) {
			LOG.info("50");
			recordCounts = 50;
		} else if (recordCounts == 100) {
			LOG.info("100");
			recordCounts = 100;
		} else if (recordCounts == 200) {
			LOG.info("200");
			recordCounts = 200;
		}
		LOG.info("final value.....--------------------------->" + recordCounts);
	}

}