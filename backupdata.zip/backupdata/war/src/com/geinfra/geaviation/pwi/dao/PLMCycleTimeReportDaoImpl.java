/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCycleTimeReportDaoImpl.java
 * @Creation date: 05-Dec-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMCycleTimeReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMMetricsQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMCycleTimeReportDaoImpl extends SimpleJdbcDaoSupport implements PLMCycleTimeReportDaoIfc{
	private static final Logger LOG = Logger.getLogger(PLMCycleTimeReportDaoImpl.class);
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
		 
	}

	/**
	 * This method is used for getDropDownvalues
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getDropDownvalues()
			throws PLMCommonException {
		Map<String, List<SelectItem>> dropdownlist = new HashMap<String, List<SelectItem>>();
		List<SelectItem> partFamily = null;
		List<SelectItem> rdo = null;

		try {
			LOG.info("Executed Query for PART FAMILY"+PLMMetricsQueries.GET_PARTFAMILY_CYCLETIME);
			partFamily = getJdbcTemplate().query(
					PLMMetricsQueries.GET_PARTFAMILY_CYCLETIME, new PartFamilyMapper());	
			LOG.info("Executed Query for RDO"+PLMMetricsQueries.GET_RDO_CYCLETIME);
			rdo = getJdbcTemplate().query(
					PLMMetricsQueries.GET_RDO_CYCLETIME, new RDOMapper());		

			dropdownlist.put("partFamily", partFamily);
			dropdownlist.put("rdo", rdo);
			//dropdownlist.put("partType", partType);			
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return dropdownlist;
	}
	
	/**
	 * Row mapper for getting dropMapper
	 */
	
	private static final class PartFamilyMapper implements ParameterizedRowMapper<SelectItem>{ 	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(rs.getString("FROM_NAME"));

			return selectItem;

		}
	
}
	/**
	 * Row mapper for getting dropMapper
	 */
	
	private static final class RDOMapper implements ParameterizedRowMapper<SelectItem>{ 	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs.getString("FROM_NAME"));
			return selectItem;
		}
	
}
	
	/**
	 * This method is used to get Result List
	 * 
	 * @param plmDRLReportData
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public PLMCycleTimeReportData getCycleTimeReportResult(PLMCycleTimeReportData plmCycleTimeReportData) throws PLMCommonException {
		
		PLMCycleTimeReportData data1 = new PLMCycleTimeReportData();
		Map<String, Object> params = new HashMap<String, Object>();
		try{
			StringBuffer searchQuery = new StringBuffer();
			searchQuery.append(PLMMetricsQueries.GET_CYCLETIME_RESULT1);

			if (plmCycleTimeReportData.getEnteredPartName() != null && !plmCycleTimeReportData.getEnteredPartName().equals("")){
				params.put("HSTNM", plmCycleTimeReportData.getEnteredPartName());
				searchQuery.append("AND HST_PART_NAME =:HSTNM");
			}
			
			if (plmCycleTimeReportData.getEnteredOwner() != null && !plmCycleTimeReportData.getEnteredOwner().equals("")) {
				plmCycleTimeReportData.setEnteredOwner(plmCycleTimeReportData.getEnteredOwner().trim());

				if (PLMUtils.isInteger(plmCycleTimeReportData.getEnteredOwner())) {
					searchQuery.append(" AND PART_OWNR_SSO LIKE ");
					searchQuery.append("'%"+plmCycleTimeReportData.getEnteredOwner()+"%'");
				} else {
					searchQuery.append(" AND PART_OWNR_NM LIKE ");
					searchQuery.append("'%"+plmCycleTimeReportData.getEnteredOwner()+"%'");
				}
			}
			
			if (plmCycleTimeReportData.getEnteredPartFamily() != null && !plmCycleTimeReportData.getEnteredPartFamily().equals("")){
				params.put("PARTFM", plmCycleTimeReportData.getEnteredPartFamily());
				searchQuery.append(" AND PART_FAMILY =:PARTFM");
			}	
			if (plmCycleTimeReportData.getEnteredRdo() != null && !plmCycleTimeReportData.getEnteredRdo().equals("")){
				params.put("RDOFM", plmCycleTimeReportData.getEnteredRdo());
				searchQuery.append(" AND RDO.FROM_NAME =:RDOFM");
			}
			if (plmCycleTimeReportData.getEnteredPartType() != null && !plmCycleTimeReportData.getEnteredPartType().equals("")){
				params.put("PRTTYPE", plmCycleTimeReportData.getEnteredPartType());
				searchQuery.append(" AND PART_TYPE  =:PRTTYPE");
			}
			
			searchQuery.append(PLMMetricsQueries.GET_CYCLETIME_RESULT2);
				
			LOG.info("Query for  getting Cycle Time Report Result List : "+searchQuery);
			List<PLMCycleTimeReportData> resultList = getNamedJdbcTemplate().query(searchQuery.toString(),params, new CycleTimeReportResultMapper());
			
			LOG.info(resultList.get(0).getReviewCount());
			LOG.info(resultList.get(0).getReviewSum());
			LOG.info(resultList.get(0).getApprovedCount());
			LOG.info(resultList.get(0).getApprovedSum());
			LOG.info(resultList.get(0).getReleaseCount());
			LOG.info(resultList.get(0).getReleaseSum());
			
			data1= new PLMCycleTimeReportData();
			data1.setReviewCount(resultList.get(0).getReviewCount());
			data1.setReviewSum(resultList.get(0).getReviewSum());
			data1.setApprovedCount(resultList.get(0).getApprovedCount());
			data1.setApprovedSum(resultList.get(0).getApprovedSum());
			data1.setReleaseCount(resultList.get(0).getReleaseCount());
			data1.setReleaseSum(resultList.get(0).getReleaseSum());
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
	}
	return data1;
	}
	

	/**
	 * @return .
	 */
	private static final class CycleTimeReportResultMapper implements ParameterizedRowMapper<PLMCycleTimeReportData> {
		public PLMCycleTimeReportData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMCycleTimeReportData resultList = new PLMCycleTimeReportData();
			resultList.setReviewCount((rs.getInt("REVIEW_COUNT")));
			resultList.setReviewSum((rs.getDouble("REVIEW_SUM")));
			resultList.setApprovedCount((rs.getInt("APPROVED_COUNT")));
			resultList.setApprovedSum((rs.getDouble("APPROVED_SUM")));
			resultList.setReleaseCount((rs.getInt("RELEASE_COUNT")));
			resultList.setReleaseSum((rs.getDouble("RELEASE_SUM")));
		return resultList;
		}
	}
	
	//Newly Added for Cycle Time part by Production Line

	/**
	 * This methods is used for getProductLines
	 * 
	 * @return list
	 * throws PLMCommonException
	 */
	public List<SelectItem> getProductLines() throws PLMCommonException{
		List<SelectItem> productLineLst = new ArrayList<SelectItem>();
		try{
		 LOG.info("Query to get productLine List: " + PLMMetricsQueries.GET_MODELNAME_CYCLETIME);
		 productLineLst = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_MODELNAME_CYCLETIME, new ProductLineMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}catch(Exception e){
			e.printStackTrace();
		}
		return productLineLst;
	}

	/**
	 * @return SelectItem objects.
	 */
	private static final class ProductLineMapper implements ParameterizedRowMapper<SelectItem> {
	//private static ParameterizedRowMapper<SelectItem> ProductLineMapper = new ParameterizedRowMapper<SelectItem>() {
			public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
		   SelectItem selectItem = new SelectItem(rs.getString("PRODUCT_LINE"));
			return selectItem;
			}
	}
	/**
	 * This method is used to get FrameType
	 * 
	 * @param selProductLn
	 * @return lsit
	 * @throws PLMCommonException 
	 */
	public List <SelectItem> getFrameTypeLst(String selProductLn) throws PLMCommonException{
		List<SelectItem> frameTypeLst = new ArrayList<SelectItem>();
		try{
			LOG.info("Query to get Frame Type List: " + PLMMetricsQueries.GET_FRAMETYPE_CYCLETIME);
			frameTypeLst = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_FRAMETYPE_CYCLETIME, new FrameTypeMapper(),
					new Object[]{selProductLn});
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return frameTypeLst;
	}
	
	/**
	 * @return SelectItem objects.
	 */
	private static final class FrameTypeMapper implements ParameterizedRowMapper<SelectItem> {
//	private static ParameterizedRowMapper<SelectItem> FrameTypeMapper = new ParameterizedRowMapper<SelectItem>() {
		public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
	   SelectItem selectItem = new SelectItem(rs.getString("FRAME_TYPE"));
		return selectItem;
		}
	}
	
	/**
	 * This method is used to get HardWares
	 * 
	 * @param selProductLn
	 * @return list
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List <PLMCycleTimeReportData> getHardWareLst(String selProductLn,List<String> selFrameType) throws PLMCommonException{
		List<PLMCycleTimeReportData> hardwareLst = new ArrayList<PLMCycleTimeReportData>();
		Map<String, Object> params = new HashMap<String, Object>();
		try{
			params.put("PRDLN", selProductLn);
			params.put("FRMTYPE", selFrameType);
			LOG.info("Query to get HardWare List: " + PLMMetricsQueries.GET_HARDWARE_DATA);
			hardwareLst = getNamedJdbcTemplate().query(PLMMetricsQueries.GET_HARDWARE_DATA, params,new HardWareMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return hardwareLst;
	}

	
	/**
	 * @return SelectItem objects.
	 */
	private static final class HardWareMapper implements ParameterizedRowMapper<PLMCycleTimeReportData> {
//	private static ParameterizedRowMapper<SelectItem> FrameTypeMapper = new ParameterizedRowMapper<SelectItem>() {
		public PLMCycleTimeReportData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMCycleTimeReportData resultList = new PLMCycleTimeReportData();
		resultList.setFrameType(rs.getString("FRAME_TYPE"));
		resultList.setHwPrdtNm(rs.getString("MODEL_NAME"));
		return resultList;
		}
	}
	
	/**
	 * This method is used to get Result List by product
	 * 
	 * @param PLMCycleTimeReportData
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMCycleTimeReportData> getCycleTimePartProduct(List<String> selFrameType, List<PLMCycleTimeReportData> hardwareObjLst,Date releaseFrmDt, Date releaseToDt) throws PLMCommonException{

		String timeStamp = null;
		String VT_PRT="";
		StringBuffer volatileQuery = new StringBuffer();
		StringBuffer searchQuery = new StringBuffer();
		List<String> hardWareLst = new ArrayList<String>();
		List<PLMCycleTimeReportData> finalResultList = new ArrayList<PLMCycleTimeReportData>();
		final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
				"MM/dd/yyyy");
		try{
			for (int i = 0; i < hardwareObjLst.size(); i++) {
				 hardWareLst.add(hardwareObjLst.get(i).getHwPrdtNm());
			}
			timeStamp = PLMUtils.volTableFormatDate();
			VT_PRT = PLMConstants.VT_PRT.concat(timeStamp);
			volatileQuery.append(PLMMetricsQueries.CREATE_PARTS_FOR_HWPRD.replace(PLMConstants.VT_PRT, VT_PRT));
			volatileQuery.append("(" +PLMUtils.setListForQuery(hardWareLst)+ ")");
			volatileQuery.append(PLMMetricsQueries.CREATE_PARTS_FOR_HWPRD1);
			LOG.info("Executing Volatile for Parts for identified Hardware Products  : "+volatileQuery);
			getJdbcTemplate().execute(volatileQuery.toString());
			
			LOG.info("Executing Collect stats Query  : "+PLMMetricsQueries.COLLECT_STATS_FOR_PRD.replace(PLMConstants.VT_PRT, VT_PRT));
			getJdbcTemplate().execute(PLMMetricsQueries.COLLECT_STATS_FOR_PRD.replace(PLMConstants.VT_PRT, VT_PRT));
		
			searchQuery.append(PLMMetricsQueries.GET_CYCLE_TIME_PART_RPODCUCT.replace(PLMConstants.VT_PRT, VT_PRT));
			
			if (releaseFrmDt != null && releaseToDt != null) {
				LOG.info("relase From Date: " + SIMPLE_DATE_FORMAT.format(releaseFrmDt) +" To Date"+SIMPLE_DATE_FORMAT.format(releaseToDt));
				searchQuery.append(" AND ");
				searchQuery.append("(D.STATE4 IS NOT NULL AND D.STATE4 BETWEEN CAST('");
				searchQuery.append(SIMPLE_DATE_FORMAT.format(releaseFrmDt)+ "' AS DATE FORMAT 'MM/DD/YYYY') AND ");
				searchQuery.append(" CAST('");
				searchQuery.append(SIMPLE_DATE_FORMAT.format(releaseToDt)+ "' AS DATE FORMAT 'MM/DD/YYYY'))");
			}
			searchQuery.append(PLMMetricsQueries.GET_CYCLE_TIME_PART_RPODCUCT1);
			
			LOG.info("Query for  getting Cycle Time Report Result List : "+searchQuery);
			List<PLMCycleTimeReportData> resultList = getSimpleJdbcTemplate().query(searchQuery.toString(), new CycleTimeReportProdLineMapper());
			String hwPrdtNm = "";
			// Set Frame Type for each record thru hardwareObjLst in resultList object
			for (int i = 0; i < resultList.size(); i++) {
				hwPrdtNm = resultList.get(i).getHwPrdtNm();
				for (int j = 0; j < hardwareObjLst.size(); j++) {
					if (hwPrdtNm.equalsIgnoreCase(hardwareObjLst.get(j).getHwPrdtNm())) {
						resultList.get(i).setFrameType(hardwareObjLst.get(j).getFrameType());
					}
				}
			}
			String selFrameVal = "";
			int reviewCount = 0;
			int approvedCount = 0;
			int releaseCount = 0;
			double reviewSum = 0.0;
			double approvedSum = 0.0;
			double releaseSum = 0.0;
			for (int i = 0; i < selFrameType.size(); i++) {
				PLMCycleTimeReportData data = new PLMCycleTimeReportData();
				selFrameVal = selFrameType.get(i);
				for (int j = 0; j < resultList.size(); j++) {
					PLMCycleTimeReportData data1 = resultList.get(j);
					if (selFrameVal.equalsIgnoreCase(data1.getFrameType())) {
						reviewCount += data1.getReviewCount();
						reviewSum += data1.getReviewSum();
						approvedCount += data1.getApprovedCount();
						approvedSum += data1.getApprovedSum();
						releaseCount += data1.getReleaseCount();
						releaseSum += data1.getReleaseSum();
					}
				}
				
				data.setFrameType(selFrameVal);
				
				data.setReviewCount(reviewCount);
				data.setReviewSum(reviewSum);
				if(reviewCount != 0){
	 				double reviewVal = reviewSum/reviewCount;
	 				data.setReviewCycleTime(PLMUtils.convertCyclePart(reviewVal));
	 			}
				data.setApprovedCount(approvedCount);
				data.setApprovedSum(approvedSum);
				if(approvedCount != 0){
	 				double approveVal = approvedSum/approvedCount;
	 				data.setApprovedCycleTime(PLMUtils.convertCyclePart(approveVal));
	 			}
				data.setReleaseCount(releaseCount);
				data.setReleaseSum(releaseSum);
				if(releaseCount != 0){
	 				double releaseVal = releaseSum/releaseCount;
	 				data.setReleaseCycleTime(PLMUtils.convertCyclePart(releaseVal));
	 			}
				finalResultList.add(data);
				reviewCount = 0;
				approvedCount = 0;
				releaseCount = 0;
				reviewSum = 0.0;
				approvedSum = 0.0;
				releaseSum = 0.0;
			}
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
	}
	return finalResultList;
	}
	
	/**
	 * @return .
	 */
	private static final class CycleTimeReportProdLineMapper implements ParameterizedRowMapper<PLMCycleTimeReportData> {
		public PLMCycleTimeReportData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMCycleTimeReportData resultList = new PLMCycleTimeReportData();
			resultList.setHwPrdtNm(rs.getString("HW_PRDT_NM"));
			resultList.setReviewCount(rs.getInt("REVIEW_COUNT"));
			resultList.setReviewSum(rs.getDouble("REVIEW_SUM"));
			resultList.setApprovedCount(rs.getInt("APPROVED_COUNT"));
			resultList.setApprovedSum(rs.getDouble("APPROVED_SUM"));
			resultList.setReleaseCount(rs.getInt("RELEASE_COUNT"));
			resultList.setReleaseSum(rs.getDouble("RELEASE_SUM"));
			return resultList;
		}
	}

	/**
	 * This method is used to get Result List by product detials
	 * 
	 * @param PLMCycleTimeReportData
	 * @return hardwareLst,releaseFrmDt,releaseToDt
	 * @throws PLMCommonException
	 */
	public List<PLMCycleTimeReportData> getCycleTimeProductDetials(List<String> hardwareLst,String state,Date releaseFrmDt, Date releaseToDt) throws PLMCommonException{
		String timeStamp = null;
		String VT_PRT="";
		List<PLMCycleTimeReportData>  cycleTimePrdList = new ArrayList<PLMCycleTimeReportData>();
		StringBuffer volatileQuery = new StringBuffer();
		StringBuffer searchQuery = new StringBuffer();
		final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
				"MM/dd/yyyy");
		try{
			timeStamp = PLMUtils.volTableFormatDate();
			VT_PRT = PLMConstants.VT_PRT.concat(timeStamp);
			volatileQuery.append(PLMMetricsQueries.CREATE_PARTS_FOR_HWPRD.replace(PLMConstants.VT_PRT, VT_PRT));
			volatileQuery.append("(" +PLMUtils.setListForQuery(hardwareLst)+ ")");
			volatileQuery.append(PLMMetricsQueries.CREATE_PARTS_FOR_HWPRD1);
			LOG.info("Executing Volatile for Parts for identified Hardware Products  : "+volatileQuery);
			getJdbcTemplate().execute(volatileQuery.toString());
			
			LOG.info("Executing Collect stats Query  : "+PLMMetricsQueries.COLLECT_STATS_FOR_PRD.replace(PLMConstants.VT_PRT, VT_PRT));
			getJdbcTemplate().execute(PLMMetricsQueries.COLLECT_STATS_FOR_PRD.replace(PLMConstants.VT_PRT, VT_PRT));
		
			searchQuery.append(PLMMetricsQueries.GET_CYCLE_TINE_PART_PRD_DETAILS.replace(PLMConstants.VT_PRT, VT_PRT));
			
			if (releaseFrmDt != null && releaseToDt != null) {
				LOG.info("relase From Date: " + SIMPLE_DATE_FORMAT.format(releaseFrmDt) +" To Date"+SIMPLE_DATE_FORMAT.format(releaseToDt));
				searchQuery.append(" AND ");
				searchQuery.append("(D.STATE4 IS NOT NULL AND D.STATE4 BETWEEN CAST('");
				searchQuery.append(SIMPLE_DATE_FORMAT.format(releaseFrmDt)+ "' AS DATE FORMAT 'MM/DD/YYYY') AND ");
				searchQuery.append(" CAST('");
				searchQuery.append(SIMPLE_DATE_FORMAT.format(releaseToDt)+ "' AS DATE FORMAT 'MM/DD/YYYY'))");
			}
			
			 LOG.info("Assigned State: " +state);
			if(state.equals("Review")) {
			  searchQuery.append(" AND B.PART_ID IS NOT NULL");
			}else if(state.equals("Approved")){
		       searchQuery.append(" AND C.PART_ID IS NOT NULL");
			 }else{
			    searchQuery.append(" AND D.PART_ID IS NOT NULL");
			  }
   		     
			 LOG.info("Query for  getting Cycle Time Report Result List : "+searchQuery);
			 cycleTimePrdList = getSimpleJdbcTemplate().query(searchQuery.toString(), new CycleTimePrdDetailMapper());
		
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
	}
	return cycleTimePrdList;
	}

	
	/**
	 * @return PLMCycleTimeReportData objects.
	 */
	private static final class CycleTimePrdDetailMapper implements ParameterizedRowMapper<PLMCycleTimeReportData> {
				public PLMCycleTimeReportData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
			PLMCycleTimeReportData tempdata = new PLMCycleTimeReportData();
			tempdata.setPartName(PLMUtils.checkNullVal(rs.getString("HST_PART_NAME")));
			tempdata.setPartRev(PLMUtils.checkNullVal(rs.getString("HST_PART_REVISION")));
			tempdata.setPartType(PLMUtils.checkNullVal(rs.getString("HST_PART_TYPE")));
			tempdata.setPartState(PLMUtils.checkNullVal(rs.getString("PART_STATE")));
			 if(rs.getDate("RELEASE_DATE") != null) {				
				tempdata.setReleaseDt(df.format(rs.getDate("RELEASE_DATE")));
			 }else{
			  tempdata.setReleaseDt("");
			  }							
			return tempdata;
		}
	}
	
}
