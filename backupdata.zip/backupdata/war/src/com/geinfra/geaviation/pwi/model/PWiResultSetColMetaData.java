package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;

/**
 * Module:       PWiResultSetColMetaData.java
 * Author:       Sandeep Chaturvedi
 * Project:      Design Center
 * Date-Written: April 2001
 * Security:     GE Confidential
 * Restrictions: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 * Copyright(C) 2012 GE All rights reserved
 *
 * Description:  <code>PWiResultSetColMetaData</code> is for storing metadata information
 * about each column in a <code>PWiResultSet</code>
 *
 * Revision Log (dd.mm.yy name description)
 * ---------------------------------------------------------
 * 23.09.2004   Parimala    Added the attributes catalogName & colLabel
 * 29.03.2005   Parimala    Added an attribute colTag for the case #2456542 
 * 12.12.2012   Hasso       Updated package to com.geinfra.geaviation.pwi.model
 * 				            (was geae.dao.GEAEResultSetMetaData).
 *                          removed GEAETag, updated serialVersionUID
 */
public class PWiResultSetColMetaData implements Serializable
{
	private static final long serialVersionUID = 7886545443813868786L;
	public int colindex; // Index
    public String colheading; // PLMi-specific
    public String catalogname;
	public String colclassname;
    public String collabel;
	public String colname; // Hashtable key
	public int coltype;
	public String coltypename;
	public int precision;
	public int scale;
	public String schema;
	public String table;
	public boolean iscurrency;
}
