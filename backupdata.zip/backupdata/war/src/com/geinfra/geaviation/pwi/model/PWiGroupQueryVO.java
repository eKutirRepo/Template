package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 9, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description :
 * 
 * Revision Log Aug 9, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiGroupQueryVO extends PWiBaseVO implements Serializable {
	public static final String TABLE = "pwi.PWi_GROUP_QUERY";
	public static final String COLUMN_QRY_SEQ_ID = "QRY_SEQ_ID";
	public static final String COLUMN_QRY_GRP_SEQ_ID = "QRY_GRP_SEQ_ID";

	private static final long serialVersionUID = 1L;

	private PWiQueryGroupVO group;
	private PWiQueryNoXmlVO query;

	public PWiQueryGroupVO getGroup() {
		return group;
	}

	public void setGroup(PWiQueryGroupVO group) {
		this.group = group;
	}

	public PWiQueryNoXmlVO getQuery() {
		return query;
	}

	public void setQuery(PWiQueryNoXmlVO query) {
		this.query = query;
	}
}
