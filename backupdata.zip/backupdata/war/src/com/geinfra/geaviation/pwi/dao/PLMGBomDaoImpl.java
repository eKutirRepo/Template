/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMGBomDaoImpl.java
 * @Creation date: 4-April-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMCostCatalogData;
import com.geinfra.geaviation.pwi.data.PLMEPEBoMData;
import com.geinfra.geaviation.pwi.data.PLMGBomData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMGBomDaoImpl extends SimpleJdbcDaoSupport implements PLMGBomDaoIfc{
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger
	.getLogger(PLMGBomDaoImpl.class);
	/**
	 * Holds the gbomDataList.
	 */
	private List<PLMGBomData> gbomDataList;
	/**
	 * Holds the excelHeaderList1.
	 */
	private List<PLMGBomData> excelHeaderList1;
	/**
	 * Holds the excelHeaderList2.
	 */
	//private List<PLMGBomData> excelHeaderList2;
	/**
	 * Holds the excelHeaderList.
	 */
	private List<PLMGBomData> excelHeaderList;
	/**
	 * Holds the hwPrdNameList.
	 */
	private List<PLMGBomData> hwPrdNameList;
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
		 
	}

	/**
	 * This method is used to getDropDownData
	 * @return java.util.Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getDropDownData() throws PLMCommonException {
		Map<String, List<SelectItem>> dropDownDataMap = new HashMap<String, List<SelectItem>>();
		List<SelectItem> modelMktNamesList = null;
		try{
		LOG.info("Query to get ModelMktingName is: " + PLMOfflineQueries.GET_MOD_MKT_NAME_LIST);
		modelMktNamesList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_MOD_MKT_NAME_LIST, new ModelMktNamesListMapper());
		dropDownDataMap.put("modelMktNamesList", modelMktNamesList);
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}catch(Exception e){
			e.printStackTrace();
		}
		return dropDownDataMap;
	}
	/**
	 * This method is used to getGBOMData
	 * @return java.util.List
	 * @param varMap, hwPrdMap
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMGBomData> getGBOMData(Map<String, Object> varMap,Map<String, Object> hwPrdMap) throws PLMCommonException{
		 try{
			 LOG.info("Inside getGBOMData() of DAO Impl");
		/* List<String> selectedModelMktNamesList=(List<String>) varMap.get("selectedModelMktNamesList");
		 List<String> selectedTfDisplayNamesList=(List<String>) varMap.get("selectedTfDisplayNamesList");*/
		 List<String> selectedCiNomenNamesList=(List<String>) varMap.get("selectedCiNomenNamesList");
		 List<String> selectedHwPrdNameList=(List<String>) varMap.get("selectedHwPrdNameList");
		 
		/* LOG.info("Selected MMList:"+selectedModelMktNamesList.toString());
		 LOG.info("Selected TFDList:"+selectedTfDisplayNamesList.toString());
		 LOG.info("Selected CINList:"+selectedCiNomenNamesList.toString());
		 LOG.info("Selected HwPrdNameList:"+selectedHwPrdNameList.toString());*/
		 Map<String, Object> params = new HashMap<String, Object>();
		 Map<String, Object> paramsInsert = new HashMap<String, Object>();
			
		 LOG.info("Executing DELETE FROM CDR_GTT_FIR_GBOM Query : "+PLMOfflineQueries.DELETE_GTT_FIR_GBOM);
			getJdbcTemplate().execute(PLMOfflineQueries.DELETE_GTT_FIR_GBOM);
				
			//Insert tab query
			paramsInsert.put("HWRPD", selectedHwPrdNameList);
			LOG.info("Executing INSERT INTO CDR_GTT_FIR_GBOM Query For Tab1: " + PLMOfflineQueries.CREATE_VT_TAB1_CF + "\n");
			/*LOG.info("hrdwrPrdctNm List size------------->"+selectedHwPrdNameList.size());*/
			LOG.info("hrdwrPrdctNm List in DAO------------->"+selectedHwPrdNameList);
			getNamedJdbcTemplate().update(PLMOfflineQueries.CREATE_VT_TAB1_CF,paramsInsert);
		
		 StringBuffer searchResultsQry = new StringBuffer();
		 
		 if(selectedHwPrdNameList != null && selectedHwPrdNameList.size() > 0){
			 searchResultsQry.append(PLMOfflineQueries.GBOM_QUERY1);
			 params.put("HWPRDT", selectedHwPrdNameList);
		 } 
		 
		 if(selectedCiNomenNamesList != null && selectedCiNomenNamesList.size() > 0){
			 searchResultsQry.append(PLMOfflineQueries.GBOM_QUERY2);
			 params.put("CINOMEN", selectedCiNomenNamesList);
		 }
		searchResultsQry.append(PLMOfflineQueries.GBOM_QUERY3);
		 
		 LOG.info("Executing Query to fetch GBOM Data:"+searchResultsQry.toString());
		 gbomDataList = getNamedJdbcTemplate().query(searchResultsQry.toString(),params, new GetGBomDataMapper());

		 }catch(DataAccessException e){
			 PLMUtils.checkException(e.getMessage());
		 }
		 
		LOG.info("Existing getGBOMData() of DAO Impl"); 
		return gbomDataList;
	}
	/**
	 * @return PLMGBomData objects.
	 */
	private static final class GetGBomDataMapper implements ParameterizedRowMapper<PLMGBomData> {
//	private static ParameterizedRowMapper<PLMGBomData> getGBomDataMapper = new ParameterizedRowMapper<PLMGBomData>() {
		public PLMGBomData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMGBomData gbomData = new PLMGBomData();
		
		gbomData.setMktName(PLMUtils.checkNullVal(rs.getString("HW_PRDT_NM")));
	//	gbomData.setCiDispName(PLMUtils.checkNullVal(rs.getString("CI_IDNFR_NM"))); // CHILD_FEAT_DISPLAY_NAME
		gbomData.setChildFeatId(PLMUtils.checkNullVal(rs.getString("CHILD_FEAT_ID"))); 
		gbomData.setCiDispName(PLMUtils.checkNullVal(rs.getString("CHILD_FEAT_DISPLAY_NAME"))); 
		gbomData.setGbomPartId(PLMUtils.checkNullVal(rs.getString("GBOM_PART_ID"))); 
		gbomData.setGbomPart(PLMUtils.checkNullVal(rs.getString("GBOM_PART")));
		gbomData.setCfId(PLMUtils.checkNullVal(rs.getString("CF_ID"))); 
		gbomData.setConfFeatureName(PLMUtils.checkNullVal(rs.getString("CF_NAME")));
		gbomData.setCoId(PLMUtils.checkNullVal(rs.getString("CO_ID")));
		gbomData.setConfOptnName(PLMUtils.checkNullVal(rs.getString("CO_NAME")));
		
		return gbomData;
		}
	}
	/**
	 * This method is used to getExcelHeaderList
	 * @return java.util.List
	 * @param headerCFNamesList
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMGBomData> getExcelHeaderList(List<String> headerCFNamesList) throws PLMCommonException {
		
		try{
			excelHeaderList=new ArrayList<PLMGBomData>();
			excelHeaderList1=new ArrayList<PLMGBomData>();
			LOG.info("Inside getExcelHeaderList() of DAO Impl");
			LOG.info("Get Excel Header List for CF Names:"+headerCFNamesList.toString());
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("CFNM", headerCFNamesList);
			PLMGBomData firstColumn=new PLMGBomData();
			firstColumn.setHeaderConfFeature("");
			firstColumn.setHeaderConfOption("Always Applied");
			firstColumn.setHeaderConfOptionDispName("Always Applied");
			excelHeaderList.add(firstColumn);
			LOG.info("First column added.....");
			LOG.info("Executed query to get Excel header List"+PLMOfflineQueries.GET_HEADER_LIST_FOR_CF);
			excelHeaderList1=getNamedJdbcTemplate().query(PLMOfflineQueries.GET_HEADER_LIST_FOR_CF,params, new GetExcelHeaderMapper());
			for(PLMGBomData data:excelHeaderList1){
				excelHeaderList.add(data);	
			}
			LOG.info("Header List Added.....");
		}catch(DataAccessException e){
			 PLMUtils.checkException(e.getMessage());
		 }
		LOG.info("Existing getExcelHeaderList() of DAO Impl"); 
		return excelHeaderList;
	}
	/**
	 * @return PLMGBomData objects.
	 */
	private static final class GetExcelHeaderMapper implements ParameterizedRowMapper<PLMGBomData> {
//	private static ParameterizedRowMapper<PLMGBomData> getExcelHeaderMapper = new ParameterizedRowMapper<PLMGBomData>() {
		public PLMGBomData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMGBomData headerData = new PLMGBomData();
		headerData.setCfId(PLMUtils.checkNullVal(rs.getString("CF_ID"))); 
		headerData.setHeaderConfFeature(PLMUtils.checkNullVal(rs.getString("CF_NAME")));
		headerData.setHeaderConfFeatureDispName(PLMUtils.checkNullVal(rs.getString("CF_DISP_NM")));
		headerData.setHeaderConfOption(PLMUtils.checkNullVal(rs.getString("CO_NAME")));
		headerData.setHeaderConfOptionDispName(PLMUtils.checkNullVal(rs.getString("CO_DISP_NM")));
		
		
		return headerData;
		}
	}
	/**
	 * This method is used to getDispNameForMMName
	 * @return java.util.Map
	 * @param selectedModelMktNamesList
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public Map<String, List<SelectItem>> getDispNameForMMName(List<String> selectedModelMktNamesList) throws PLMCommonException {
		Map<String, List<SelectItem>> dropDownDataMap = new HashMap<String, List<SelectItem>>();
		List<SelectItem> tfDisplayNamesListForMMName = null;
		Map<String, Object> params = new HashMap<String, Object>();
		try{
		params.put("PRDLN", selectedModelMktNamesList);
		LOG.info("Query to get TF Display Name for MMName is: " + PLMOfflineQueries.GET_TF_DISP_NAME_LIST_FOR_MMNAME);
		tfDisplayNamesListForMMName = getNamedJdbcTemplate().query(PLMOfflineQueries.GET_TF_DISP_NAME_LIST_FOR_MMNAME,params, new TfDisplayNamesListMapper());
		dropDownDataMap.put("tfDisplayNamesListForMMName", tfDisplayNamesListForMMName);
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return dropDownDataMap;
	}
	
	
	/**
	 * This method is used to getHwPrdNameList
	 * @return java.util.List
	 * @param selectedModelMktNamesList,selectedTfDisplayNamesList
	 * @throws PLMCommonException
	 */
@SuppressWarnings("unchecked")
public List<PLMGBomData> getHwPrdNameList(List<String> selectedModelMktNamesList,List<String> selectedTfDisplayNamesList) throws PLMCommonException {
		try{
			LOG.info("Inside getHwPrdNameList of DAO Impl");
			 Map<String, Object> params = new HashMap<String, Object>();
			 params.put("PRDLN", selectedModelMktNamesList);
			 params.put("FRMTYPE", selectedTfDisplayNamesList);
			LOG.info("Executed query to get HwPrdNameList"+PLMOfflineQueries.GET_HW_PRD_NAME_LIST);
			hwPrdNameList = getNamedJdbcTemplate().query(PLMOfflineQueries.GET_HW_PRD_NAME_LIST,params, new GetHwPrdNameMapper());
		}catch(DataAccessException e){
			 PLMUtils.checkException(e.getMessage());
		 }
		LOG.info("Existing getHwPrdNameList() of DAO Impl"); 
		return hwPrdNameList;
	}
/**
 * @return PLMGBomData objects.
 */
private static final class GetHwPrdNameMapper implements ParameterizedRowMapper<PLMGBomData> {
//private static ParameterizedRowMapper<PLMGBomData> getHwPrdNameMapper = new ParameterizedRowMapper<PLMGBomData>() {
	public PLMGBomData mapRow(ResultSet rs, int rowCount) throws SQLException {
	PLMGBomData hwPrdName = new PLMGBomData();
	
	hwPrdName.setFrameType(PLMUtils.checkNullVal(rs.getString("FRAME_TYPE")));
	LOG.info("set frame type"+PLMUtils.checkNullVal(rs.getString("FRAME_TYPE")));
	hwPrdName.setModelName(PLMUtils.checkNullVal(rs.getString("MODEL_NAME")));
	LOG.info("set model name"+PLMUtils.checkNullVal(rs.getString("MODEL_NAME")));
	
	
	
	return hwPrdName;
	}
}
/**
 * @return SelectItem objects.
 */
private static final class ModelMktNamesListMapper implements ParameterizedRowMapper<SelectItem> {
//private static ParameterizedRowMapper<SelectItem> modelMktNamesListMapper = new ParameterizedRowMapper<SelectItem>() {
		public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
	   SelectItem selectItem = new SelectItem(rs.getString("PRODUCT_LINE"));
		return selectItem;
		}
	}
	/**
	 * @return SelectItem objects.
	 */
	private static final class TfDisplayNamesListMapper implements ParameterizedRowMapper<SelectItem> {
//	private static ParameterizedRowMapper<SelectItem> tfDisplayNamesListMapper = new ParameterizedRowMapper<SelectItem>() {
		public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
	   SelectItem selectItem = new SelectItem(rs.getString("FRAME_TYPE"));
		return selectItem;
		}
	}
	
	/**
	 * This method is used to get Excel Header List for Fir
	 * 
	 * @return List<PLMGBomData>
	 */
	@SuppressWarnings("unchecked")
	public List<PLMGBomData> getExcelHeaderListFir(List<String> headerCFNamesList) throws PLMCommonException{
		List<PLMGBomData> excelHeaderListFir = new ArrayList<PLMGBomData>();
		try{
			LOG.info("Inside getExcelHeaderListFir() of DAO Impl");
			LOG.info("Get Excel Header List for CF Names:"+headerCFNamesList);
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("CFNM", headerCFNamesList);
			LOG.info("Executed query to get Excel header List"+PLMOfflineQueries.GET_HEADER_LIST_FOR_CF);
			List<PLMGBomData> excelHeaderListFir1=getNamedJdbcTemplate().query(PLMOfflineQueries.GET_HEADER_LIST_FOR_CF,params, new ExcelHeaderMapper());
			LOG.info("excelHeaderListFir1 +++++++++++++++++++++++++++++++++++++++++++++++"+excelHeaderListFir1.size());
			for(PLMGBomData data:excelHeaderListFir1){
				excelHeaderListFir.add(data);	
			}
			LOG.info("Header List Added.....");
		}catch(DataAccessException e){
			 PLMUtils.checkException(e.getMessage());
		 }
		LOG.info("Existing getExcelHeaderListFir() of DAO Impl"); 
		return excelHeaderListFir;
	}
	
	/**
	  * Row mapper for getting ExcelHeaderMapper
	  */
	private static class ExcelHeaderMapper implements ParameterizedRowMapper<PLMGBomData> {
		public PLMGBomData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMGBomData headerData = new PLMGBomData();
		headerData.setCfId(PLMUtils.checkNullVal(rs.getString("CF_ID")));
		headerData.setHeaderConfFeature(PLMUtils.checkNullVal(rs.getString("CF_NAME")));
		headerData.setHeaderConfFeatureDispName(PLMUtils.checkNullVal(rs.getString("CF_DISP_NM")));
		headerData.setHeaderConfOption(PLMUtils.checkNullVal(rs.getString("CO_NAME")));
		headerData.setHeaderConfOptionDispName(PLMUtils.checkNullVal(rs.getString("CO_DISP_NM")));
		
		
		return headerData;
		}
	}
	
	public List<SelectItem> getFeatImptReptDrpDwnData() throws PLMCommonException{

		List<SelectItem> productLineList = null;		
		try{
		LOG.info("Query to get ModelMktingName is: " + PLMSearchQueries.GET_PRODUCT_LINE);
		productLineList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_PRODUCT_LINE, new ProductLineMapper() );
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return productLineList;
	}
	
	private static final class ProductLineMapper implements ParameterizedRowMapper<SelectItem>{
		public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
		   SelectItem selectItem = new SelectItem(rs.getString("PRODUCT_LINE"));
			return selectItem;
		}
	}
	
	public List<SelectItem> getFrameTypeData(String selectedProductLine) throws PLMCommonException {
		List<SelectItem> frameTypeList = null;
		try{	
		LOG.info("Query to get TF Display Name for MMName is: " + PLMSearchQueries.GET_TF_DISP_NAME_LIST_FOR_MMNAME_FIR);
		frameTypeList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_TF_DISP_NAME_LIST_FOR_MMNAME_FIR, new FrameTypeMapper(), new Object[]{selectedProductLine});
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return frameTypeList;
	}
	
	private static class FrameTypeMapper implements ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
	   SelectItem selectItem = new SelectItem(rs.getString("FRAME_TYPE"));
		return selectItem;
		}
	}
	
	public List<PLMGBomData> getFeatureNameList(String selectedProductLine,String selectedFrameType) throws PLMCommonException {
		List<PLMGBomData> featureNameList = new ArrayList<PLMGBomData>();	
		try{
				LOG.info("Inside getFeatureNameList of DAO Impl");
				LOG.info("Executed query to get HwPrdNameList"+PLMSearchQueries.GET_HW_PRD_NAME_LIST1_FIR);
				LOG.info("selectedProductLine in DAO Impl"+selectedProductLine); 
				LOG.info("selectedFrameType in DAO Impl"+selectedFrameType); 
				featureNameList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_HW_PRD_NAME_LIST1_FIR, new FeatureNameMapper(), new Object[]{selectedProductLine, selectedFrameType});
				LOG.info("featureNameList.size() in dao------------------>"+featureNameList.size());
			}catch(DataAccessException e){
				 PLMUtils.checkException(e.getMessage());
			 }
			LOG.info("Existing getHwPrdNameList() of DAO Impl"); 
			return featureNameList;
		}
	
	private static class FeatureNameMapper implements ParameterizedRowMapper<PLMGBomData> {
		public PLMGBomData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMGBomData hwPrdName = new PLMGBomData();
		
		hwPrdName.setFrameType(PLMUtils.checkNullVal(rs.getString("FRAME_TYPE")));
		hwPrdName.setModelName(PLMUtils.checkNullVal(rs.getString("MODEL_NAME")));
		return hwPrdName;
		}
	}
	 
	
	public Map<String, List<PLMGBomData>> getCFList(List<String> hrdwrPrdctList) throws PLMCommonException{
		LOG.info("Executing DELETE FROM CDR_GTT_FIR_GBOM Query : "+PLMOfflineQueries.DELETE_GTT_FIR_GBOM);
		getJdbcTemplate().execute(PLMOfflineQueries.DELETE_GTT_FIR_GBOM);
		 Map<String, Object> params = new HashMap<String, Object>();
		
		//Insert Tab1
		 params.put("HWRPD", hrdwrPrdctList);
		LOG.info("Executing INSERT INTO CDR_GTT_FIR_GBOM Query For Tab1: " + PLMOfflineQueries.CREATE_VT_TAB1_CF + "\n");
		LOG.info("hrdwrPrdctNm List size------------->"+hrdwrPrdctList.size());
		LOG.info("hrdwrPrdctNm List in DAO------------->"+hrdwrPrdctList);
		getNamedJdbcTemplate().update(PLMOfflineQueries.CREATE_VT_TAB1_CF,params);
		
		//Insert into tab2
		 LOG.info("Executing INSERT INTO CDR_GTT_FIR_GBOM Query For Tab2: " + PLMOfflineQueries.CREATE_VT_TAB2_CF + "\n");
		 getNamedJdbcTemplate().update(PLMOfflineQueries.CREATE_VT_TAB2_CF ,params);
		
		Map<String, List<PLMGBomData>> firMap = new HashMap<String, List<PLMGBomData>>();
		
		LOG.info("Executing GET_CF_NAME Query : " + PLMOfflineQueries.GET_CF_NAME + "\n");
		firMap.put("CFNameList", getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_CF_NAME, new CFNameMapper()));
		/*List<PLMGBomData> list = new ArrayList<PLMGBomData>();
		PLMGBomData data = new PLMGBomData();
		list.add(data);*/
		return firMap;
	}
	
	private static class CFNameMapper  implements ParameterizedRowMapper<PLMGBomData> {
		public PLMGBomData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMGBomData data = new PLMGBomData();
			data.setCfName(rs.getString("CF_NAME"));
			data.setCfDispName(rs.getString("CF_DISP_NM"));	
			return data;
		}
	}
	
	@SuppressWarnings("unchecked")
	public Map<String, List<PLMGBomData>> getFeatImptReptTab1Data(Map<String, Object> varMap,Map<String, Object> hwPrdMap) throws PLMCommonException{
			 Map<String, List<PLMGBomData>> tabMap = new HashMap<String, List<PLMGBomData>>();
		 try{
			 LOG.info("Inside getFeatImptReptTab1Data() of DAO Impl");
			 List<String> selectedProductLine= new ArrayList<String>();
			 selectedProductLine.add((String) varMap.get("selectedProductLine"));
			 List<String> selectedFrameType= new ArrayList<String>();
			 selectedFrameType.add((String) varMap.get("selectedFrameType"));
			 List<String> selectedFeatureName= new ArrayList<String>();
			 selectedFeatureName.add((String) varMap.get("selectedFeatureName"));
			 List<String> selectedHwPrdNameList1=(List<String>) varMap.get("selectedHwPrdNameList1");
			 Map<String, Object> params = new HashMap<String, Object>();
			 Map<String, Object> params1 = new HashMap<String, Object>();
			 Map<String, Object> params2 = new HashMap<String, Object>();
						
		 LOG.info("Selected selectedProductLine:"+selectedProductLine);
		 LOG.info("Selected selectedFrameType:"+selectedFrameType);
		 LOG.info("Selected selectedFeatureName:"+selectedFeatureName);
		 LOG.info("Selected selectedHwPrdNameList1:"+selectedHwPrdNameList1);
		 
		 LOG.info("Executing DELETE FROM CDR_GTT_FIR_GBOM Query : "+PLMOfflineQueries.DELETE_GTT_FIR_GBOM);
		 getJdbcTemplate().execute(PLMOfflineQueries.DELETE_GTT_FIR_GBOM);
		
		 //Insert into tab1
		 params.put("HWRPD", selectedHwPrdNameList1);
		 LOG.info("Executing INSERT INTO CDR_GTT_FIR_GBOM Query For Tab1: " + PLMOfflineQueries.CREATE_VT_TAB1_CF + "\n");
		 /*LOG.info("hrdwrPrdctNm List size------------->"+selectedHwPrdNameList1.size());*/
		 LOG.info("hrdwrPrdctNm List in DAO------------->"+selectedHwPrdNameList1);
		 getNamedJdbcTemplate().update(PLMOfflineQueries.CREATE_VT_TAB1_CF,params);
		 
		//Insert into tab2
		 LOG.info("Executing INSERT INTO CDR_GTT_FIR_GBOM Query For Tab2: " + PLMOfflineQueries.CREATE_VT_TAB2_CF + "\n");
		/* LOG.info("hrdwrPrdctNm List size------------->"+selectedHwPrdNameList1.size());*/
		 LOG.info("hrdwrPrdctNm List in DAO------------->"+selectedHwPrdNameList1);
		 getNamedJdbcTemplate().update(PLMOfflineQueries.CREATE_VT_TAB2_CF,params);
		 
		 StringBuffer searchResultsQry1 = new StringBuffer();
		 
		 if(selectedHwPrdNameList1 != null && selectedHwPrdNameList1.size() > 0){
			 searchResultsQry1.append(PLMOfflineQueries.FIR_TAB1_QUERY1);
			 params1.put("HWPRD", selectedHwPrdNameList1);
		 }
		
		 if(selectedFeatureName.size() > 0){
			 searchResultsQry1.append(PLMOfflineQueries.FIR_TAB1_QUERY2);
		 }
		 params1.put("CFNM", (String) varMap.get("selectedFeatureName"));
			
		 LOG.info("Executing Query to fetch FeatImptReptTab1 Data:"+searchResultsQry1);
		 LOG.info("Selected Feature Name in dao--------->:"+(String) varMap.get("selectedFeatureName"));
		 LOG.info("Hardware product list in dao --------->:"+selectedHwPrdNameList1);
		 List<PLMGBomData>featImptReptList = getNamedJdbcTemplate().query(searchResultsQry1.toString(),params1, new FeatImptReptTab1DataMapper());
		 LOG.info("featImptReptList size------------------------>"+featImptReptList.size());
	
		 StringBuffer searchResultsQry2 = new StringBuffer();
		 if(selectedHwPrdNameList1 != null && selectedHwPrdNameList1.size() > 0){
			 searchResultsQry2.append(PLMOfflineQueries.FIR_TAB2_QUERY11);
			 params2.put("HWPRD", selectedHwPrdNameList1);
		 }
		
		 if(selectedFeatureName.size() > 0){
			 searchResultsQry2.append(PLMOfflineQueries.FIR_TAB2_QUERY21);
		 }
		 params2.put("CFNM", (String) varMap.get("selectedFeatureName"));
			
		 LOG.info("Executing Query to fetch FeatImptReptTab2 Data:"+searchResultsQry2);
		 LOG.info("Selected Feature Name in dao--------->:"+(String) varMap.get("selectedFeatureName"));
		 LOG.info("Hardware product list in dao --------->:"+selectedHwPrdNameList1);
		 List<PLMGBomData> featImptReptList1 = getNamedJdbcTemplate().query(searchResultsQry2.toString(),params2, new FeatImptReptTab1DataMapper());
		 LOG.info("featImptReptList1 size------------------------>"+featImptReptList1.size());
		 
		 tabMap.put("featImptReptList", featImptReptList);
		 tabMap.put("featImptReptList1", featImptReptList1);
		 
		 }catch(DataAccessException e){
			 LOG.info("@@@@@@@@@@@@@@@@@@@@@  EXCEPTION OCCURED VOTILE TABLE in getFeatImptReptTab1Data @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"+e.getMessage());
			 PLMUtils.checkException(e.getMessage());
		 }
		 
		LOG.info("Existing getGBOMData() of DAO Impl"); 
		return tabMap;
	}
	
	
	@SuppressWarnings("unchecked")
	public Map<String ,List<PLMGBomData>> getFeatImptReptTab2Data(Map<String, Object> varMap) throws PLMCommonException{
		 Map<String ,List<PLMGBomData>> map = new HashMap<String, List<PLMGBomData>>();
		 try{
			 LOG.info("Inside getFeatImptReptTab2Data() of DAO Impl");
			 List<String> selectedHwPrdNameList1=(List<String>) varMap.get("selectedHwPrdNameList1");
			 List<String> coNameList=(List<String>) varMap.get("coNameList");
			 String selectedFeatureName = (String) varMap.get("selectedFeatureName");
			 Map<String, Object> params = new HashMap<String, Object>();
				
		 LOG.info("Selected selectedFeatureName:"+selectedFeatureName);
		 LOG.info("Selected coNameList:"+coNameList);
		 LOG.info("Selected selectedHwPrdNameList1:"+selectedHwPrdNameList1);
		 
		 LOG.info("Execting query to fetch Enire Data from VT Table:------>"+ PLMOfflineQueries.FIR_TAB2_QUERY1);
		 List<PLMGBomData> mainList = getSimpleJdbcTemplate().query(PLMOfflineQueries.FIR_TAB2_QUERY1, new FeatImptRptTab2DataMapr());
		 LOG.info("query executed to fetch Enire Data from VT Table.Data Size -------->:"+ mainList.size());
		 
		 List<PLMGBomData> searchedList = new ArrayList<PLMGBomData>();
			for(int i=0;i<coNameList.size();i++){
				LOG.info("Looping started for CO Name >>>>> " + coNameList.get(i));
				params.put("CFNM", selectedFeatureName);
				params.put("CONM",  coNameList.get(i));
					 List<PLMGBomData> list1 = getNamedJdbcTemplate().query(PLMOfflineQueries.FIR_TAB2_QUERY2,params, new FeatImptRptTab2DataMapr());
					 Set<String> addSet = new HashSet<String>();
					 Set<String> delSet = new HashSet<String>();
					 
					 for(int k=0;k<list1.size();k++){
						 List<PLMGBomData> tempSearchList = new ArrayList<PLMGBomData>();
						 for(int l=0;l<mainList.size();l++){
							 if(list1.get(k).getDfsOrder()!=null && mainList.get(l).getDfsOrder()!= null){
								 if(mainList.get(l).getDfsOrder().contains(list1.get(k).getDfsOrder())){
									     tempSearchList.add(mainList.get(l));
								 }
							 }
						 }
						 if(tempSearchList.size() > 0){
								 if (list1.get(k).getRuleType().equalsIgnoreCase("Inclusion")) {
								 for(PLMGBomData data : tempSearchList){
									 addSet.add(data.getChildFeatDispName());
								 }
							 } else if (list1.get(k).getRuleType().equalsIgnoreCase("Exclusion")) {
								 for(PLMGBomData data : tempSearchList){
									 delSet.add(data.getChildFeatDispName());
								 }
							 }
							 LOG.info("addSet values >>> " + addSet);
							 LOG.info("delSet values >>> " + delSet);
						 }	
					  }
					 PLMGBomData data = new PLMGBomData();
					 data.setStrAdd(PLMUtils.convertListToStr(new ArrayList<String>(addSet)));
					 data.setStrDel(PLMUtils.convertListToStr(new ArrayList<String>(delSet)));
					 searchedList.add(data);
					 LOG.info("============================================================");
					 LOG.info("KEY VALUE ------->"+coNameList.get(i));
					 LOG.info("searchedList.get(0).getStrAdd()"+data.getStrAdd());
					 LOG.info("searchedList.get(0).getStrDel()"+data.getStrDel());
					 LOG.info("============================================================");
				
				 map.put(coNameList.get(i), searchedList);
			}
		 }catch(DataAccessException e){
			 LOG.info("@@@@@@@@@@@@@@@@@@@@@  EXCEPTION OCCURED VOTILE TABLE in getFeatImptReptTab2Data @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"+e.getMessage());
			 PLMUtils.checkException(e.getMessage());
		 } finally {
			 LOG.info("Executing DELETE FROM CDR_GTT_FIR_GBOM Query : "+PLMOfflineQueries.DELETE_GTT_FIR_GBOM);
			 getJdbcTemplate().execute(PLMOfflineQueries.DELETE_GTT_FIR_GBOM);
		 }
		 
		LOG.info("Existing getGBOMData() of DAO Impl"); 
		return map;
	}
	
	
	private static class FeatImptReptTab1DataMapper implements ParameterizedRowMapper<PLMGBomData> {
		public PLMGBomData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMGBomData gbomData = new PLMGBomData();
		
		gbomData.setMktName(PLMUtils.checkNullVal(rs.getString("HW_PRDT_NM")));
		gbomData.setChildFeatId(PLMUtils.checkNullVal(rs.getString("CHILD_FEAT_ID"))); 
		gbomData.setCiDispName(PLMUtils.checkNullVal(rs.getString("CHILD_FEAT_DISPLAY_NAME")));
		gbomData.setGbomPartId(PLMUtils.checkNullVal(rs.getString("GBOM_PART_ID"))); 
		gbomData.setGbomPart(PLMUtils.checkNullVal(rs.getString("GBOM_PART")));
		gbomData.setCfId(PLMUtils.checkNullVal(rs.getString("CF_ID"))); 
		gbomData.setConfFeatureName(PLMUtils.checkNullVal(rs.getString("CF_NAME")));
		gbomData.setCoId(PLMUtils.checkNullVal(rs.getString("CO_ID"))); 
		gbomData.setConfOptnName(PLMUtils.checkNullVal(rs.getString("CO_NAME")));
		
		return gbomData;
		}
	}
	
	private static class FeatImptRptTab2DataMapr implements ParameterizedRowMapper<PLMGBomData> {
		public PLMGBomData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMGBomData gbomData = new PLMGBomData();
		
		gbomData.setLevel(PLMUtils.checkNullVal(rs.getString("LVL")));
		gbomData.setParentFeatName(PLMUtils.checkNullVal(rs.getString("PRNT_FEAT_NAME")));
		gbomData.setChildFeatName(PLMUtils.checkNullVal(rs.getString("CHILD_FEAT_NAME")));
		gbomData.setChildFeatDispName(PLMUtils.checkNullVal(rs.getString("CHILD_FEAT_DISPLAY_NAME")));
		gbomData.setRuleType(PLMUtils.checkNullVal(rs.getString("RULE_TYPE")));
		//gbomData.setCfName(PLMUtils.checkNullVal(rs.getString("CF_NAME")));
		//gbomData.setCoName(PLMUtils.checkNullVal(rs.getString("CO_NAME")));
		gbomData.setDfsOrder(PLMUtils.checkNullVal(rs.getString("DFSORDER")));
		
		return gbomData;
		}
	}

	
	//End Raju
	
	//Newly Added for Part Cost Catalog Report
	/**
	 * This method is used for Generating Part Cost Catalog Report
	 * 
	 * @param selectedHwPrdNameList
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMCostCatalogData> getPartCostCatalogData(List<String> selectedHwPrdNameList,String selCostType) throws PLMCommonException{
		LOG.info("Entering getPartCostCatalogData() of DAO Impl"); 
		 List<PLMCostCatalogData> finalpartCostCataolgList = new ArrayList<PLMCostCatalogData>();
		 List<String> partIdParentList = new ArrayList<String>();
		 Map<String, Object> params = new HashMap<String, Object>();
		 try{
			 
			 params.put("FRMNM", selectedHwPrdNameList);
			 LOG.info("Executing Insert Query of part Cost catalog" +PLMSearchQueries.INSERT_PART_COST_CATALOG);
			 getNamedJdbcTemplate().update(PLMSearchQueries.INSERT_PART_COST_CATALOG,params);
			 
			 LOG.info("Executing parent part Cost catalog" +PLMSearchQueries.GET_PART_COST_CATALOG);
			 LOG.info("Selected Cost Type " +selCostType);
			 String[] parts = selCostType.split("~!~");
			 String part1 = parts[0]; // 004
			 String part2 = parts[1]; 
			 LOG.info("Selected Source System " +part1);
			 LOG.info("Selected Cost Type " +part2);
			 List<PLMCostCatalogData> parentCostCataolgList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_PART_COST_CATALOG, new PrntCstCtlgMapper(),new Object[] {part1, part2});
			 
			  if(parentCostCataolgList.size()>0){
				  for(int i=0;i<parentCostCataolgList.size();i++){
						 if(parentCostCataolgList.get(i).getCostItemType().equals("9") && parentCostCataolgList.get(i).getMsdfLogicCal().equals("MSD")){
						  partIdParentList.add(parentCostCataolgList.get(i).getPartId());
						  }
				   }
			  }

			  if(!PLMUtils.isEmptyList(partIdParentList)){
				  params.put("SRCSYS", part1);
				  params.put("CSTYPE", part2);
				  params.put("EBOMID", partIdParentList);
			   LOG.info("Executing Child part Cost catalog" +PLMSearchQueries.GET_FINAL_PART_COST_CATALOG);
			    List<PLMCostCatalogData> childCostCataolgList = getNamedJdbcTemplate().query(PLMSearchQueries.GET_FINAL_PART_COST_CATALOG,
			    		params,new ChldCstCtlgMapper());
			  
			   for(int i=0;i<parentCostCataolgList.size();i++){
				   PLMCostCatalogData partCostCtlgData = new PLMCostCatalogData();
				    partCostCtlgData.setPartId(parentCostCataolgList.get(i).getPartId());
					partCostCtlgData.setPartName(parentCostCataolgList.get(i).getPartName());
					partCostCtlgData.setPartRevision(parentCostCataolgList.get(i).getPartRevision());
					partCostCtlgData.setLfName(parentCostCataolgList.get(i).getLfName());
					partCostCtlgData.setLfDesc(parentCostCataolgList.get(i).getLfDesc());
					partCostCtlgData.setMli(parentCostCataolgList.get(i).getMli());
					partCostCtlgData.setPin(parentCostCataolgList.get(i).getPin());
					partCostCtlgData.setQuantity(parentCostCataolgList.get(i).getQuantity());
					partCostCtlgData.setTotalMaterialCost(parentCostCataolgList.get(i).getTotalMaterialCost());
					partCostCtlgData.setTotalLabourCost(parentCostCataolgList.get(i).getTotalLabourCost());
					partCostCtlgData.setTotalCost(parentCostCataolgList.get(i).getTotalCost());
					partCostCtlgData.setTotalLabourHours(parentCostCataolgList.get(i).getTotalLabourHours());
					partCostCtlgData.setQuantityExl(parentCostCataolgList.get(i).getQuantityExl());
					partCostCtlgData.setTotalMaterialCostExl(parentCostCataolgList.get(i).getTotalMaterialCostExl());
					partCostCtlgData.setTotalLabourCostExl(parentCostCataolgList.get(i).getTotalLabourCostExl());
					partCostCtlgData.setTotalCostExl(parentCostCataolgList.get(i).getTotalCostExl());
					partCostCtlgData.setTotalLabourHoursExl(parentCostCataolgList.get(i).getTotalLabourHoursExl());
					partCostCtlgData.setCostItemType(parentCostCataolgList.get(i).getCostItemType());
					partCostCtlgData.setMsdfLogicCal(parentCostCataolgList.get(i).getMsdfLogicCal());
					partCostCtlgData.setSystemName(parentCostCataolgList.get(i).getSystemName());
					
					finalpartCostCataolgList.add(partCostCtlgData);

				      for(int j=0;j<childCostCataolgList.size();j++){
				    	  if(parentCostCataolgList.get(i).getPartId().equals(childCostCataolgList.get(j).getPartId())){
				    		    PLMCostCatalogData  partCostCtlgData1 = new PLMCostCatalogData();
				    		    partCostCtlgData1.setPartId(childCostCataolgList.get(j).getPartId());
				    		    partCostCtlgData1.setPartName(childCostCataolgList.get(j).getPartName());
				    		    partCostCtlgData1.setPartRevision(childCostCataolgList.get(j).getPartRevision());
				    		    partCostCtlgData1.setLfName(childCostCataolgList.get(j).getLfName());
				    		    partCostCtlgData1.setLfDesc(childCostCataolgList.get(j).getLfDesc());
				    		    partCostCtlgData1.setMli(parentCostCataolgList.get(i).getMli());
				    		    partCostCtlgData1.setPin(childCostCataolgList.get(j).getPin());
				    		    partCostCtlgData1.setQuantity(childCostCataolgList.get(j).getQuantity());
				    		    partCostCtlgData1.setTotalMaterialCost(childCostCataolgList.get(j).getTotalMaterialCost());
				    		    partCostCtlgData1.setTotalLabourCost(childCostCataolgList.get(j).getTotalLabourCost());
				    		    partCostCtlgData1.setTotalCost(childCostCataolgList.get(j).getTotalCost());
				    		    partCostCtlgData1.setTotalLabourHours(childCostCataolgList.get(j).getTotalLabourHours());
				    		    partCostCtlgData1.setQuantityExl(childCostCataolgList.get(j).getQuantityExl());
				    		    partCostCtlgData1.setTotalMaterialCostExl(childCostCataolgList.get(j).getTotalMaterialCostExl());
				    		    partCostCtlgData1.setTotalLabourCostExl(childCostCataolgList.get(j).getTotalLabourCostExl());
				    		    partCostCtlgData1.setTotalCostExl(childCostCataolgList.get(j).getTotalCostExl());
				    		    partCostCtlgData1.setTotalLabourHoursExl(childCostCataolgList.get(j).getTotalLabourHoursExl());
				    		    partCostCtlgData1.setCostItemType(childCostCataolgList.get(j).getCostItemType());
				    		    partCostCtlgData1.setMsdfLogicCal(childCostCataolgList.get(j).getMsdfLogicCal());
				    		    partCostCtlgData1.setSystemName(parentCostCataolgList.get(i).getSystemName());
								finalpartCostCataolgList.add(partCostCtlgData1);
				    	  }
				      }
			  	  }
			  }
			  else{
			    finalpartCostCataolgList.addAll(parentCostCataolgList);
			  }
		 }catch(DataAccessException e){
		 LOG.info("Exception on getPartCostCatalogData"+e.getMessage());
		 PLMUtils.checkException(e.getMessage());
	   }
 	 LOG.info("Existing getPartCostCatalogData() of DAO Impl"); 
	 return finalpartCostCataolgList;
	}
	/**
	 * 
	 * This mapper is used to get the report of parent Cost Catalog
	 *
	 */
	private static class PrntCstCtlgMapper implements ParameterizedRowMapper<PLMCostCatalogData> {
		public PLMCostCatalogData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMCostCatalogData partCostCtlgData = new PLMCostCatalogData();
		
			partCostCtlgData.setPartId(PLMUtils.checkNullVal(rs.getString("GBOM_PART_ID")));
			partCostCtlgData.setPartName(PLMUtils.checkNullVal(rs.getString("GBOM_PART_NAME")));
			partCostCtlgData.setPartRevision(PLMUtils.checkNullVal(rs.getString("PART_REVISION")));
			partCostCtlgData.setLfName(PLMUtils.checkNullVal(rs.getString("LF_NAME")));
			partCostCtlgData.setLfDesc(PLMUtils.checkNullVal(rs.getString("LF_DESCRIPTION")));
			partCostCtlgData.setMli(PLMUtils.checkNullVal(rs.getString("MLI")));
			partCostCtlgData.setPin(PLMUtils.checkNullVal(rs.getString("PIN")));
			partCostCtlgData.setQuantity(rs.getInt("QUANTITY"));
			partCostCtlgData.setTotalMaterialCost(rs.getInt("MATERIAL_COST"));
			partCostCtlgData.setTotalLabourCost(rs.getInt("LABOR_COST"));
			partCostCtlgData.setTotalCost(rs.getInt("TOTAL_COST"));
			partCostCtlgData.setTotalLabourHours(rs.getInt("LABOR_HOURS"));
			partCostCtlgData.setQuantityExl(rs.getFloat("QUANTITY"));
			partCostCtlgData.setTotalMaterialCostExl(rs.getFloat("MATERIAL_COST"));
			partCostCtlgData.setTotalLabourCostExl(rs.getFloat("LABOR_COST"));
			partCostCtlgData.setTotalCostExl(rs.getFloat("TOTAL_COST"));
			partCostCtlgData.setTotalLabourHoursExl(rs.getFloat("LABOR_HOURS"));
			partCostCtlgData.setCostItemType(PLMUtils.checkNullVal(rs.getString("ITEM_TYPE")));
			partCostCtlgData.setMsdfLogicCal(PLMUtils.checkPINVal(PLMUtils.checkNullVal(rs.getString("PIN"))));
			partCostCtlgData.setSystemName(PLMUtils.checkNullVal(PLMUtils.checkNullVal(rs.getString("SYSTEM_NAME"))));
			
		return partCostCtlgData;
		}
	}
	
	/**
	 * 
	 * This mapper is used to get the report of child Cost Catalog
	 *
	 */
	private static class ChldCstCtlgMapper implements ParameterizedRowMapper<PLMCostCatalogData> {
		public PLMCostCatalogData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMCostCatalogData partCostCtlgData = new PLMCostCatalogData();
		
			partCostCtlgData.setPartId(PLMUtils.checkNullVal(rs.getString("GBOM_PARENT_PART_ID")));
			partCostCtlgData.setPartName(PLMUtils.checkNullVal(rs.getString("GBOM_PART_NAME")));
			partCostCtlgData.setPartRevision(PLMUtils.checkNullVal(rs.getString("PART_REVISION")));
			partCostCtlgData.setMli(PLMUtils.checkNullVal(rs.getString("MLI")));
			partCostCtlgData.setPin(PLMUtils.checkNullVal(rs.getString("PIN")));
			partCostCtlgData.setQuantity(rs.getInt("QUANTITY"));
			partCostCtlgData.setTotalMaterialCost(rs.getInt("MATERIAL_COST"));
			partCostCtlgData.setTotalLabourCost(rs.getInt("LABOR_COST"));
			partCostCtlgData.setTotalCost(rs.getInt("TOTAL_COST"));
			partCostCtlgData.setTotalLabourHours(rs.getInt("LABOR_HOURS"));
			partCostCtlgData.setQuantityExl(rs.getFloat("QUANTITY"));
			partCostCtlgData.setTotalMaterialCostExl(rs.getFloat("MATERIAL_COST"));
			partCostCtlgData.setTotalLabourCostExl(rs.getFloat("LABOR_COST"));
			partCostCtlgData.setTotalCostExl(rs.getFloat("TOTAL_COST"));
			partCostCtlgData.setTotalLabourHoursExl(rs.getFloat("LABOR_HOURS"));
			partCostCtlgData.setCostItemType(PLMUtils.checkNullVal(rs.getString("ITEM_TYPE")));
			partCostCtlgData.setMsdfLogicCal(PLMUtils.checkPINVal(PLMUtils.checkNullVal(rs.getString("PIN"))));
		return partCostCtlgData;
		}
	}
	
	/**
	 * This method is used for getting Hardware product and Revision
	 * 
	 * @param selectedHwPrdNameList
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMCostCatalogData> getHardwarePrdRevision(List<String> selectedHwPrdNameList) throws PLMCommonException{
	LOG.info("Entering getHardwarePrdRevision() of DAO Impl"); 
	 List<PLMCostCatalogData> hardWarePrdRevList = new ArrayList<PLMCostCatalogData>();
	 Map<String, Object> params = new HashMap<String, Object>();
	 try{
		 params.put("NM", selectedHwPrdNameList);
		  LOG.info("Executing parent part Cost catalog" +PLMSearchQueries.GET_HARDWARE_PRD_REV);
		  hardWarePrdRevList = getNamedJdbcTemplate().query(PLMSearchQueries.GET_HARDWARE_PRD_REV,params, new HwPrdtRevMapper());
	  }
	  catch(DataAccessException e){
		 LOG.info("Exception on getPartCostCatalogData"+e.getMessage());
		 PLMUtils.checkException(e.getMessage());
	   }
	 LOG.info("Existing getPartCostCatalogData() of DAO Impl"); 
	 return hardWarePrdRevList;
	}
	
	/**
	 * 
	 * This mapper is used to get the hwProduct Revision 
	 *
	 */
	private static class HwPrdtRevMapper implements ParameterizedRowMapper<PLMCostCatalogData> {
		public PLMCostCatalogData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMCostCatalogData partCostCtlgData = new PLMCostCatalogData();
		
			partCostCtlgData.setHardwarePrd(PLMUtils.checkNullVal(rs.getString("NM")));
			partCostCtlgData.setHardwarePrdRev(PLMUtils.checkNullVal(rs.getString("REVISION")));
			
			return partCostCtlgData;
		}
	}
	
	
	
	public Map<String, List<PLMGBomData>> getCINomenList(List<String> hrdwrPrdctList) throws PLMCommonException{
	
		LOG.info("Executing DELETE FROM CDR_GTT_FIR_GBOM Query : "+PLMOfflineQueries.DELETE_GTT_FIR_GBOM);
		getJdbcTemplate().execute(PLMOfflineQueries.DELETE_GTT_FIR_GBOM);
		 Map<String, Object> params = new HashMap<String, Object>();
			
		//Insert tab query
		 params.put("HWRPD", hrdwrPrdctList);
		LOG.info("Executing INSERT INTO CDR_GTT_FIR_GBOM Query For Tab1: " + PLMOfflineQueries.CREATE_VT_TAB1_CF + "\n");
		LOG.info("hrdwrPrdctNm List size------------->"+hrdwrPrdctList.size());
		LOG.info("hrdwrPrdctNm List in DAO------------->"+hrdwrPrdctList);
		getNamedJdbcTemplate().update(PLMOfflineQueries.CREATE_VT_TAB1_CF,params);
		
		
		Map<String, List<PLMGBomData>> firMap = new HashMap<String, List<PLMGBomData>>();
		
		LOG.info("Executing GET_CF_NAME Query : " + PLMOfflineQueries.GET_CI_NOMENCLATURE + "\n");
		firMap.put("CINomenList", getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_CI_NOMENCLATURE, new CINomenMapper()));
		/*List<PLMGBomData> list = new ArrayList<PLMGBomData>();
		PLMGBomData data = new PLMGBomData();
		list.add(data);*/
		return firMap;
	}
	
	

	private static class CINomenMapper  implements ParameterizedRowMapper<PLMGBomData> {
		public PLMGBomData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMGBomData data = new PLMGBomData();
			data.setCfDispName(rs.getString("CI_NOMENCLATURE"));	
			return data;
		}
	}
	
	/**
	 * This method is used for getting Cost type
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getCostTypeList() throws PLMCommonException{
		List<SelectItem> costTypeList = null;		
		try{
		LOG.info("Query to get CostType : " + PLMSearchQueries.GET_COST_TYPE_PART_COST_CATLG);
		costTypeList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_COST_TYPE_PART_COST_CATLG, new CostTypeMapper() );
		Collections.sort(costTypeList, new PLMUtils.SortListSelItem());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return costTypeList;
	}
	/**
	 * 
	 * This mapper is used to get the CostType 
	 *
	 */
	private static final class CostTypeMapper implements ParameterizedRowMapper<SelectItem>{
		public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
		   SelectItem selectItem = new SelectItem(rs.getString("COST_TYPE_VAL"),rs.getString("COST_TYPE_LBL"));
			return selectItem;
		}
	}
	//Newly Added for BOM Report for GBoM Parts for 4.5 Release
	/**
	 * This method is used for inserting GBOM part into GTT Tables
	 * 
	 * @param hrdwrPrdctList,ciNomenNamesList
	 * @return int
	 * @throws PLMCommonException
	 */
	public List<String> gbomPartsBoMReport(List<String> hrdwrPrdctList,List<String> ciNomenNamesList
			, String fileDir) throws PLMCommonException {
		LOG.info("Entering in to gbomPartsBoMReport");
		int bomresultCnt=0; 
		Map<String, Object> paramsInsert = new HashMap<String, Object>();
		List<String> csvFlsLst = new ArrayList<String>();
		/*boolean rptSccsFlg = false;
		boolean rptFnlFlg = false;*/
		try{
			 	LOG.info("Selected HwPrdNameList:"+hrdwrPrdctList);
			 	LOG.info("Selected CINList:"+ciNomenNamesList);
			 	
			 	LOG.info("DELETE Query of BOM Report for GBoM Parts : "+PLMOfflineQueries.DELETE_GTT_GBOM_PARTS);
			 	getJdbcTemplate().execute(PLMOfflineQueries.DELETE_GTT_GBOM_PARTS);
					
				//Insert GTT Table query
				paramsInsert.put("HWRPD", hrdwrPrdctList);
				paramsInsert.put("CFNM", ciNomenNamesList);
				LOG.info("INSERT Query of BOM Report for GBoM Parts: " + PLMOfflineQueries.INSERT_GBOM_GTT_PARTS + "\n");
				getNamedJdbcTemplate().update(PLMOfflineQueries.INSERT_GBOM_GTT_PARTS,paramsInsert);
				
				LOG.info("Query of Collect STATS for BOM Report for GBoM Parts : " + PLMOfflineQueries.COL_STAT_GBOM_PRT_GTT + "\n");
				getJdbcTemplate().execute(PLMOfflineQueries.COL_STAT_GBOM_PRT_GTT);
				
				LOG.info("Query of getting Count for BOM Report for GBoM Parts : " + PLMOfflineQueries.COUNT_GBOM_GTT_PARTS + "\n");
				bomresultCnt=getJdbcTemplate().queryForInt(PLMOfflineQueries.COUNT_GBOM_GTT_PARTS);
				LOG.info("Result size of BOM Report for GBoM Parts: " + bomresultCnt);
				
				int vtCntInt =1;
				int vtCntLimit=Integer.parseInt(PLMUtils.getMessage(PLMConstants.GBOM_PARTS_LOOP_CNTR));
				int vtCntIncr =Integer.parseInt(PLMUtils.getMessage(PLMConstants.GBOM_PARTS_LOOP_CNTR));
				int val = 0;
				int loopCount = 0;
				
				if(bomresultCnt <=vtCntLimit){
					loopCount = 1;
				}else{
					loopCount = bomresultCnt/vtCntLimit;				
					val = bomresultCnt - (vtCntLimit * loopCount);
					  if (val > 0) {
						loopCount++;					
					   }
				}
				int fileNmCtr = 1;
				int rowCount=0;
				int loopIterCnt=1;
				String filePathCSVLcl="";
				List<String> filePathcsvList =new ArrayList<String>();
				Map<String, Object> varFileWrtMap =new HashMap<String, Object>();
				varFileWrtMap.put("FileCsvList", filePathcsvList);
				varFileWrtMap.put("RowCount", rowCount);
				varFileWrtMap.put("FileCount", fileNmCtr);
				//if(pwriter!=null){
				// varFileWrtMap.put("pwriter", pwriter);
				//}
				//if(fileOut!=null){
				 //varFileWrtMap.put("fileOut", fileOut);
				//}
				varFileWrtMap.put("filePathCSV", filePathCSVLcl);
				 for (int i=0;i<loopCount;i++) {
					if(vtCntIncr > bomresultCnt){
						vtCntIncr=bomresultCnt;
					}
					
					LOG.info("-------------------Loop Rotating From Row key "+vtCntInt +" and To RowKey "+vtCntIncr);
					 varFileWrtMap= getGbomPartsBoM(vtCntInt,vtCntIncr, fileDir,loopIterCnt,loopCount,
							 //fileNmCtr,rowCount,pwriter,fileOut,filePathCSVLcl,
							 varFileWrtMap);
					
					 /*if(loopIterCnt < loopCount){
						 filePathcsvList= (List<String>) varFileWrtMap.get("FileCsvList");
						 rowCount=  (Integer) varFileWrtMap.get("RowCount");
						 LOG.info("rowCount>>>>>>>>>> "+rowCount);
						 fileNmCtr=  (Integer) varFileWrtMap.get("FileCount");
						 LOG.info("fileNmCtr>>>>>>>>>> "+fileNmCtr);
						 pwriter=(PrintWriter) varFileWrtMap.get("pwriter");
						 fileOut=(FileOutputStream) varFileWrtMap.get("fileOut");
						 filePathCSVLcl=(String) varFileWrtMap.get("filePathCSV");
					 }else{
						 filePathcsvList= (List<String>) varFileWrtMap.get("FileCsvList");
					 }*/
					 
					loopIterCnt++;
					vtCntInt=vtCntInt+Integer.parseInt(PLMUtils.getMessage(PLMConstants.GBOM_PARTS_LOOP_CNTR));
					vtCntIncr=vtCntIncr+Integer.parseInt(PLMUtils.getMessage(PLMConstants.GBOM_PARTS_LOOP_CNTR));
					
				}
				filePathcsvList= (List<String>) varFileWrtMap.get("FileCsvList");
				if (!PLMUtils.isEmptyList(filePathcsvList)) {
						csvFlsLst.addAll(filePathcsvList);
				}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}/*finally {
			try {
				if (pwriter !=null) {
					pwriter.close();
				}
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@gbomPartsBoMReport: ", e);
				PLMUtils.checkException(e.getMessage());
			}
		}*/
		LOG.info("Exiting method gbomPartsBoMReport");
		return csvFlsLst;
	}
	
	/**
	 * This method is used to get EPE BA BOM report
	 * 
	 * @param mlNo
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, Object> getGbomPartsBoM(int key1, int key2, String fileDir, int loopIterCnt,int loopCount,
			//int fileNmCtr,int rowCount,PrintWriter pwriter,FileOutputStream fileOut,String filePathCSV, 
			Map<String, Object> varFileWrtMap) throws PLMCommonException{
		LOG.info("Entering getGbomPartsBoM Method");
		Map<String,List<PLMEPEBoMData>> docRecMap =new HashMap<String,List<PLMEPEBoMData>>();
		String timeStamp = null;
		String ELTTR_VT1 = null;
		String ELTTR_VT2 = null;
		String ELTTR_VT3 = null;
		String ELTTR_VT4 = null;
		//String ELTTR_VT5 = null;
		String ELTTR_VT6 = null;
		String ELTTR_VT7 = null;
		String ELTTR_VT8 = null;
		String ELTTR_VT9 = null;
		//boolean fileSccsFlg = false;
		//String csvFlNm = "";
		//Map<String, Object> varFileWrtMap =new HashMap<String, Object>();
		Map<String, Object> varFileWrtMapLcl=varFileWrtMap;
		try{
			timeStamp = PLMUtils.volTableFormatDate();
			LOG.info("The timeStamp for the Report "+timeStamp);
			
			ELTTR_VT1 = PLMConstants.ELTTR_VT1.concat(timeStamp);
			ELTTR_VT2 = PLMConstants.ELTTR_VT2.concat(timeStamp);
			ELTTR_VT3 = PLMConstants.ELTTR_VT3.concat(timeStamp);
			ELTTR_VT4 = PLMConstants.ELTTR_VT4.concat(timeStamp); 
			//ELTTR_VT5 = PLMConstants.ELTTR_VT5.concat(timeStamp);
			ELTTR_VT6 = PLMConstants.ELTTR_VT6.concat(timeStamp);
			ELTTR_VT7 = PLMConstants.ELTTR_VT7.concat(timeStamp);
			ELTTR_VT8 = PLMConstants.ELTTR_VT8.concat(timeStamp);
			ELTTR_VT9 = PLMConstants.ELTTR_VT9.concat(timeStamp);
			
			LOG.info("Query for Creating ELTTR_VT1 : "+PLMOfflineQueries.CREATE_BOMPART_ELTTR_VT1.replace(PLMConstants.ELTTR_VT1, ELTTR_VT1)
					.replace("#KEY1#", ""+key1)
					.replace("#KEY2#", ""+key2));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_BOMPART_ELTTR_VT1.replace(PLMConstants.ELTTR_VT1, ELTTR_VT1)
					.replace("#KEY1#", ""+key1)
					.replace("#KEY2#", ""+key2));
			
			LOG.info("Query for Creating ELTTR_VT1 : "+PLMOfflineQueries.INSERT_BOMPART_ELTTR_VT1.replace(PLMConstants.ELTTR_VT1, ELTTR_VT1)
					.replace("#KEY1#", ""+key1)
					.replace("#KEY2#", ""+key2));
			getJdbcTemplate().execute(PLMOfflineQueries.INSERT_BOMPART_ELTTR_VT1.replace(PLMConstants.ELTTR_VT1, ELTTR_VT1)
					.replace("#KEY1#", ""+key1)
					.replace("#KEY2#", ""+key2));
			
			/*LOG.info("Query for Collect STATS ELTTR_VT1 : " + PLMOfflineQueries.COLLECT_STATS_ELTTR_VT1.replace(PLMConstants.ELTTR_VT1, ELTTR_VT1));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ELTTR_VT1.replace(PLMConstants.ELTTR_VT1, ELTTR_VT1));*/
			
			LOG.info("Query for Creating ELTTR_VT2 : " + PLMOfflineQueries.CREATE_ELTTR_VT2.replace(PLMConstants.ELTTR_VT2, ELTTR_VT2)
						.replace(PLMConstants.ELTTR_VT1, ELTTR_VT1));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_ELTTR_VT2.replace(PLMConstants.ELTTR_VT2, ELTTR_VT2)
						.replace(PLMConstants.ELTTR_VT1, ELTTR_VT1));
			
			/*LOG.info("Query for Collect STATS ELTTR_VT2 : " + PLMOfflineQueries.COLLECT_STATS_ELTTR_VT2.replace(PLMConstants.ELTTR_VT2, ELTTR_VT2));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ELTTR_VT2.replace(PLMConstants.ELTTR_VT2, ELTTR_VT2));*/
			
			LOG.info("Query for Creating ELTTR_VT3 : " + PLMOfflineQueries.CREATE_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
		
			/*LOG.info("Query for Collect STATS ELTTR_VT3 : " + PLMOfflineQueries.COLLECT_STATS_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));*/
			
			LOG.info("Query for First INSERT ELTTR_VT3 : " + PLMOfflineQueries.INSERT_ONE_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.INSERT_ONE_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
		
			/*LOG.info("Query for Collect STATS ELTTR_VT3 : " + PLMOfflineQueries.COLLECT_STATS_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));*/
			
			LOG.info("Query for Second INSERT ELTTR_VT3 : " + PLMOfflineQueries.INSERT_TWO_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.INSERT_TWO_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
		
			/*LOG.info("Query for Collect STATS ELTTR_VT3 : " + PLMOfflineQueries.COLLECT_STATS_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));*/
			
			LOG.info("Query for Third INSERT ELTTR_VT3 : " + PLMOfflineQueries.INSERT_THREE_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.INSERT_THREE_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));

			LOG.info("Query for Creating ELTTR_VT4 : " + PLMOfflineQueries.CREATE_ELTTR_VT4.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4)
					.replace(PLMConstants.ELTTR_VT2, ELTTR_VT2).replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_ELTTR_VT4.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4)
					.replace(PLMConstants.ELTTR_VT2, ELTTR_VT2).replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
		
			LOG.info("Query for INSERT ELTTR_VT4 : " + PLMOfflineQueries.INSERT_ELTTR_VT4.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4)
					.replace(PLMConstants.ELTTR_VT2, ELTTR_VT2));
			getJdbcTemplate().execute(PLMOfflineQueries.INSERT_ELTTR_VT4.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4)
					.replace(PLMConstants.ELTTR_VT2, ELTTR_VT2));
		
			/*LOG.info("Query for Collect STATS ELTTR_VT4 : " + PLMOfflineQueries.COLLECT_STATS_ELTTR_VT4.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ELTTR_VT4.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4));*/
					
			/*LOG.info("Query for Creating ELTTR_VT5 : " + PLMOfflineQueries.CREATE_ELTTR_VT5.replace(PLMConstants.ELTTR_VT5, ELTTR_VT5)
					.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4).replace(PLMConstants.ELTTR_VT2, ELTTR_VT2));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_ELTTR_VT5.replace(PLMConstants.ELTTR_VT5, ELTTR_VT5)
					.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4).replace(PLMConstants.ELTTR_VT2, ELTTR_VT2));
		
			LOG.info("Query for Collect STATS ELTTR_VT5 : " + PLMOfflineQueries.COLLECT_STATS_ELTTR_VT5.replace(PLMConstants.ELTTR_VT5, ELTTR_VT5));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ELTTR_VT5.replace(PLMConstants.ELTTR_VT5, ELTTR_VT5));*/
		
			
			LOG.info("Query for Creating ELTTR_VT6 : " + PLMOfflineQueries.CREATE_ELTTR_VT6.replace(PLMConstants.ELTTR_VT6, ELTTR_VT6)
					.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4).replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_ELTTR_VT6.replace(PLMConstants.ELTTR_VT6, ELTTR_VT6)
					.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4).replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
		
			/*LOG.info("Query for Collect STATS ELTTR_VT6 : " + PLMOfflineQueries.COLLECT_STATS_ELTTR_VT6.replace(PLMConstants.ELTTR_VT6, ELTTR_VT6));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ELTTR_VT6.replace(PLMConstants.ELTTR_VT6, ELTTR_VT6));*/
		
			
			LOG.info("Query for Creating ELTTR_VT7 : " + PLMOfflineQueries.CREATE_ELTTR_VT7.replace(PLMConstants.ELTTR_VT7, ELTTR_VT7)
					.replace(PLMConstants.ELTTR_VT6, ELTTR_VT6));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_ELTTR_VT7.replace(PLMConstants.ELTTR_VT7, ELTTR_VT7)
					.replace(PLMConstants.ELTTR_VT6, ELTTR_VT6));
		
			/*LOG.info("Query for Collect STATS ELTTR_VT7 : " + PLMOfflineQueries.COLLECT_STATS_ELTTR_VT7.replace(PLMConstants.ELTTR_VT7, ELTTR_VT7));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ELTTR_VT7.replace(PLMConstants.ELTTR_VT7, ELTTR_VT7));*/
			

			LOG.info("Query for Creating ELTTR_VT8 : " + PLMOfflineQueries.CREATE_ELTTR_VT8.replace(PLMConstants.ELTTR_VT8, ELTTR_VT8)
					.replace(PLMConstants.ELTTR_VT7, ELTTR_VT7));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_ELTTR_VT8.replace(PLMConstants.ELTTR_VT8, ELTTR_VT8)
					.replace(PLMConstants.ELTTR_VT7, ELTTR_VT7));
		
			/*LOG.info("Query for Collect STATS ELTTR_VT8 : " + PLMOfflineQueries.COLLECT_STATS_ELTTR_VT8.replace(PLMConstants.ELTTR_VT8, ELTTR_VT8));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ELTTR_VT8.replace(PLMConstants.ELTTR_VT8, ELTTR_VT8));*/
		
			
			LOG.info("Query for Creating ELTTR_VT9 : " + PLMOfflineQueries.CREATE_ELTTR_VT9.replace(PLMConstants.ELTTR_VT9, ELTTR_VT9)
					.replace(PLMConstants.ELTTR_VT8, ELTTR_VT8));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_ELTTR_VT9.replace(PLMConstants.ELTTR_VT9, ELTTR_VT9)
					.replace(PLMConstants.ELTTR_VT8, ELTTR_VT8));
		
			/*LOG.info("Query for Collect STATS ELTTR_VT9 : " + PLMOfflineQueries.COLLECT_STATS_ELTTR_VT9.replace(PLMConstants.ELTTR_VT9, ELTTR_VT9));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ELTTR_VT9.replace(PLMConstants.ELTTR_VT9, ELTTR_VT9));*/
			
			/*LOG.info("Query for Getting GET_ELTTR_VT9 : " + PLMOfflineQueries.GET_ELTTR_VT9.replace(PLMConstants.ELTTR_VT9, ELTTR_VT9));
			epaBaBomResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_ELTTR_VT9.replace(PLMConstants.ELTTR_VT9, ELTTR_VT9),new epeBaResultMapper());
			LOG.info("Result of ELTTR_VT9 : " + epaBaBomResultList.size());
			*/
			
			LOG.info("Query for Getting GET_ELTTR_PART_DATA : " + PLMOfflineQueries.GET_ELTTR_PART_DATA.
					replace(PLMConstants.ELTTR_VT1, ELTTR_VT1).replace(PLMConstants.ELTTR_VT2, ELTTR_VT2));
			List<PLMEPEBoMData> partDataList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_ELTTR_PART_DATA.
					replace(PLMConstants.ELTTR_VT1, ELTTR_VT1).replace(PLMConstants.ELTTR_VT2, ELTTR_VT2),new EpeBaPartMapper());
			
			LOG.info("Query for Getting GET_ELTTR_DOC_DATA : " + PLMOfflineQueries.GET_ELTTR_DOC_DATA.replace(PLMConstants.ELTTR_VT9, ELTTR_VT9));
			List<PLMEPEBoMData> docDataList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_ELTTR_DOC_DATA.
					replace(PLMConstants.ELTTR_VT9, ELTTR_VT9),new EpeBaDocMapper());
						
			if (!PLMUtils.isEmptyList(docDataList)) {
				List<PLMEPEBoMData> docChldLst = null;
				for (int i =0;i<docDataList.size();i++) {
					docChldLst = null;
					if (docRecMap.containsKey(docDataList.get(i).getTopDocId())){
						docChldLst = docRecMap.get(docDataList.get(i).getTopDocId());
						docChldLst.add(docDataList.get(i));
					} else {
						docChldLst = new ArrayList<PLMEPEBoMData>();
						docChldLst.add(docDataList.get(i));
					}
					docRecMap.put(docDataList.get(i).getTopDocId(),docChldLst);
				}
			}

			LOG.info("partDataList size "+partDataList.size());
			LOG.info("docDataList size "+docDataList.size());
			LOG.info("docRecMap size "+docRecMap.size());
			Collections.sort(partDataList, new SortEPEBOM());
			
			if(!PLMUtils.isEmptyList(partDataList)){
				varFileWrtMapLcl = createGbomCsvFiles(partDataList,docRecMap, fileDir, loopIterCnt,loopCount,
						//fileNmCtr,rowCount,pwriter,fileOut,filePathCSV, 
						varFileWrtMapLcl);
				docRecMap.clear();
				partDataList.clear();
				//fileSccsFlg = true;
			}
		} catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		} 
		LOG.info("Exiting getGbomPartsBoM Method");
		return varFileWrtMapLcl;
	}
	/**
	 * Row mapper for getting EpeBaDocMapper
	 */
	private static final class EpeBaDocMapper implements ParameterizedRowMapper<PLMEPEBoMData>{	
	public PLMEPEBoMData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMEPEBoMData tempData = new PLMEPEBoMData();
		tempData.setDocId(PLMUtils.checkNullVal(rs.getString("DOC_ID")));
		tempData.setTopDocId(PLMUtils.checkNullVal(rs.getString("TOP_DOC_ID")));
		tempData.setDocBomLvl(PLMUtils.checkNullVal(rs.getString("DOC_BOM_LVL")));
		tempData.setDocParent(PLMUtils.checkNullVal(rs.getString("DOC_PARENT")));
		tempData.setDocName(PLMUtils.checkNullVal(rs.getString("DOC_NAME")));
		tempData.setLogicIndr(PLMUtils.checkNullVal(rs.getString("LOGICAL_INDR")));
		tempData.setDocRev(PLMUtils.checkNullVal(rs.getString("DOC_REV")));
		tempData.setDocType(PLMUtils.checkNullVal(rs.getString("DOC_TYPE")));
		tempData.setDocState(PLMUtils.checkNullVal(rs.getString("DOC_STATE")));
		tempData.setDocTitle(PLMUtils.checkNullVal(rs.getString("DOC_TITLE")));
		tempData.setDocClass(PLMUtils.checkNullVal(rs.getString("DOC_CLASS")));
		tempData.setDwgCrtlCode(PLMUtils.checkNullVal(rs.getString("DWG_CRITICAL_CODE")));
		tempData.setExportCntrl(PLMUtils.checkNullVal(rs.getString("EXPORT_CONTROL")));
		tempData.setModelValidated(PLMUtils.checkNullVal(rs.getString("MODEL_VALIDATED")));
		return tempData;
		}
	}
	
	/**
	 * Row mapper for getting EpeBaPartMapper
	 */
	private static final class EpeBaPartMapper implements ParameterizedRowMapper<PLMEPEBoMData>{	
	public PLMEPEBoMData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMEPEBoMData tempData = new PLMEPEBoMData();
		tempData.setDfsOrder(PLMUtils.checkNullVal(rs.getString("DFSORDER")));
		tempData.setMli(PLMUtils.checkNullVal(rs.getString("MLI")));
		tempData.setPartId(PLMUtils.checkNullVal(rs.getString("PART_ID")));
		tempData.setPartBomLvl(PLMUtils.checkNullVal(rs.getString("PART_BOM_LVL")));
		tempData.setParentPart(PLMUtils.checkNullVal(rs.getString("PARENT_PART")));
		tempData.setPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
		tempData.setPartRev(PLMUtils.checkNullVal(rs.getString("PART_REV")));
		tempData.setPartDesc(PLMUtils.checkNullVal(rs.getString("PART_DESC")));
		tempData.setPartState(PLMUtils.checkNullVal(rs.getString("PART_STATE")));
		tempData.setFindNum(PLMUtils.checkNullVal(rs.getString("FIND_NUM")));
		tempData.setQuantity(PLMUtils.checkNullVal(rs.getString("QUANTITY")));
		tempData.setUom(PLMUtils.checkNullVal(rs.getString("UOM")));
		tempData.setDocId(PLMUtils.checkNullVal(rs.getString("DOC_ID")));
		tempData.setLogicIndr(PLMUtils.checkNullVal(rs.getString("GE_LOGICAL_INDR")));
		tempData.setReplacePart(PLMUtils.checkNullVal(rs.getString("REPLACEMENT_PART")));
		tempData.setModelValidated(PLMUtils.checkNullVal(rs.getString("MODEL_VALIDATED")));
		return tempData;
		}
	}
			
	/**
	 * 
	 * class to sort list of object of type PLMEPABoMData
	 * 
	 */
	private static class SortEPEBOM implements Comparator<PLMEPEBoMData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMEPEBoMData aString,
				PLMEPEBoMData bString) {
			
			return aString.getDfsOrder().compareTo(bString.getDfsOrder());
		   		      
		}
	}
	
	public Map<String,Object> createGbomHdrFile(String fileDir,int fileNmCtr
			, Map<String, Object> varFileWrtMap) throws PLMCommonException {
		LOG.info("Entering createGbomHdrFile Method");
		Map<String,Object> varMap= new HashMap<String, Object>();
		PrintWriter pwriter =null;
		FileOutputStream fileOut = null;
		boolean createFileExist;
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String filePathCSV = fileDir + PLMUtils.getMessage(PLMConstants.BOM_RPT_FOR_PART_NM)+"-" +fileNmCtr+ "_" + uniqTime + ".csv";
		LOG.info("Inside createGbomHdrFile Method writing new file >>>>>>>>>>>>>>>>>>>>>>>>>> "+filePathCSV);
		try {
			/*pwriter = (PrintWriter)varMap.get("pwriter");
			fileOut = (FileOutputStream)varMap.get("fileOut");
			if(pwriter!=null){
				 pwriter.close();
			 }
			 if(fileOut!=null){
				 fileOut.close();
			 }*/
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathCSV);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathCSV);
				pwriter =  new PrintWriter( new FileWriter(filePathCSV));
				  	pwriter.write("BOM_PREFIX");
		 			pwriter.write(",");
		 			pwriter.write("PART_BOM_LVL");
		 			pwriter.write(",");
		 			pwriter.write("PARENT_PART");
		 			pwriter.write(",");
		 			pwriter.write("PART_NAME");
		 			pwriter.write(",");
		 			pwriter.write("PART_REV");
		 			pwriter.write(",");
		  			pwriter.write("PART_DESC");
		 			pwriter.write(",");
		 			pwriter.write("PART_STATE");
		 			pwriter.write(",");
		 			pwriter.write("FIND_NUM");
		 			pwriter.write(",");
		 			pwriter.write("QUANTITY");
		 			pwriter.write(",");
		 			pwriter.write("UOM");
		 			pwriter.write(",");
		 			pwriter.write("REPLACEMENT_PART");
		 			pwriter.write(",");
		 			pwriter.write("DOC_BOM_LVL");
		 			pwriter.write(",");
		 			pwriter.write("DOC_PARENT");
		 			pwriter.write(",");
		 			pwriter.write("DOC_NAME");
		 			pwriter.write(",");
		 			pwriter.write("LOGICAL_INDR");
		 			pwriter.write(",");
		 			pwriter.write("DOC_REV");
		 			pwriter.write(",");
		 			pwriter.write("DOC_TYPE");
		 			pwriter.write(",");
		 			pwriter.write("DOC_STATE");
		 			pwriter.write(",");
		 			pwriter.write("DOC_TITLE");
		 			pwriter.write(",");
		 			pwriter.write("DOC_CLASS");
		 			pwriter.write(",");
		 			pwriter.write("DWG_CRITICAL_CODE");
		 			pwriter.write(",");
		 			pwriter.write("EXPORT_CONTROL");
		 			pwriter.write(",");
		 			pwriter.write("MODEL_VALIDATED");
					pwriter.write("\n");
		 	  }
			 varMap.put("pwriter", pwriter);
			 varMap.put("fileOut", fileOut);
			 varMap.put("fileNmCtr", fileNmCtr);
			 varMap.put("filePathCSV", filePathCSV);
			 
			 List<String> filePathcsvList = (List<String>)varFileWrtMap.get("FileCsvList");
			 boolean fileExtLst = false;
			 if (!PLMUtils.isEmptyList(filePathcsvList)) {
				 for (int i=0;i<filePathcsvList.size();i++) {
					 if (filePathCSV.equals(filePathcsvList.get(i))) {
						 LOG.info("File Name already Exist in List "+filePathcsvList.get(i));
						 fileExtLst = true;
					 }
				 }
			 }
			 if (!fileExtLst) {
				 LOG.info("Before Adding File Name "+filePathCSV+" to filePathcsvList >>>>>>>>>>>>>>>>>>>>> "+filePathcsvList);
				 filePathcsvList.add(filePathCSV);
				 LOG.info("After Adding File Name "+filePathCSV+" to filePathcsvList >>>>>>>>>>>>>>>>>>>>> "+filePathcsvList);
			 }
			 varFileWrtMap.put("FileCsvList", filePathcsvList);
			 varMap.put("varFileWrtMap",varFileWrtMap);
			 
			} catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@createGbomHdrFile: ", e);
				PLMUtils.checkException(e.getMessage());
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@createGbomHdrFile: ", e);
				PLMUtils.checkException(e.getMessage());
			} finally {
				try {
					if (fileOut!=null) {
						fileOut.close();
					}
				} catch(IOException ie){
					LOG.log(Level.ERROR, "Exception@createGbomHdrFile: ", ie);
					PLMUtils.checkException(ie.getMessage());
				
				}
			}
			LOG.info("Exiting createGbomHdrFile Method");
			return varMap;
	}
	
	public Map<String ,Object> createGbomCsvFiles(List<PLMEPEBoMData> partDataList,
			Map<String,List<PLMEPEBoMData>> docRecMap,String fileDir, int loopIterCnt,int loopCount,
			//int fileNmCtr,int rowCount,PrintWriter pwriter,FileOutputStream fileOut,String filePathCSV, 
			Map<String, Object> varFileWrtMap) throws PLMCommonException {
		LOG.info("Entering createGbomCsvFiles Method");
		//Map<String,Object> varHeaderMap= new HashMap<String, Object>();
		Map<String,Object> varFileWrtMapLcl= varFileWrtMap;
		int fileNmCtLcl=(Integer)varFileWrtMapLcl.get("FileCount");
		int rowCntLcl=(Integer)varFileWrtMapLcl.get("RowCount");
		int maxLimitVal = Integer.parseInt(PLMUtils.getMessage(PLMConstants.GBOM_PARTS_MAX_LIMIT));
		PrintWriter pwriterLcl =null;
		FileOutputStream fileOutLcl = null;
		String filePathCSVLcl="";
		//Map<String, Object> varFileWrtMap =new HashMap<String, Object>();
		//List<String> filePathcsvList =new ArrayList<String>();
		try {
			
				if(rowCntLcl==0 && fileNmCtLcl==1){
					Map<String,Object>  varHeaderMap = createGbomHdrFile(fileDir,fileNmCtLcl,varFileWrtMapLcl);
					varFileWrtMapLcl = (Map<String, Object>)varHeaderMap.get("varFileWrtMap");
					pwriterLcl= (PrintWriter) varHeaderMap.get("pwriter");
					fileOutLcl= (FileOutputStream) varHeaderMap.get("fileOut");
					filePathCSVLcl=(String) varHeaderMap.get("filePathCSV");
				}else{
					pwriterLcl= (PrintWriter) varFileWrtMapLcl.get("pwriter");
					fileOutLcl= (FileOutputStream) varFileWrtMapLcl.get("fileOut");
					filePathCSVLcl=(String) varFileWrtMapLcl.get("filePathCSV");
				}
			
			
					if(!PLMUtils.isEmptyList(partDataList)) {
		 		     		
				   		for(int i=0; i<partDataList.size(); i++) {
				   			PLMEPEBoMData dataObj = (PLMEPEBoMData)partDataList.get(i);
				   			
							if(!PLMUtils.isEmpty(dataObj.getDocId())){	
								List<PLMEPEBoMData> docDataList = docRecMap.get(dataObj.getDocId());
								if (!PLMUtils.isEmptyList(docDataList)) {
									Collections.sort(docDataList, new SortEPEDocs());
									
									for (int j=0;j<docDataList.size();j++) {
										
										PLMEPEBoMData docDataObj = docDataList.get(j);
									  
									 if(rowCntLcl < maxLimitVal){	
										 
										if(dataObj.getMli()!= null){
								   			pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getMli()+"\""));
								   		}
							   			pwriterLcl.write(",");
							   			if(dataObj.getPartBomLvl()!= null){
							   				if (dataObj.getPartBomLvl().equals("0")) {
							   					pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getPartBomLvl()+"\""));
							   				} else {
							   					pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getPartBomLvl()));
							   				}
										}
										pwriterLcl.write(",");
										if(dataObj.getParentPart()!= null){
											pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getParentPart()));
										}
										pwriterLcl.write(",");
										if(dataObj.getPartName()!= null){
											pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getPartName()));
										}
										pwriterLcl.write(",");
							   			if(dataObj.getPartRev()!= null){
								   			pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getPartRev()+"\""));
								   		}
							   			pwriterLcl.write(",");
							   			if(dataObj.getPartDesc()!= null){
								   			pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getPartDesc()));
								   		}
							   			pwriterLcl.write(",");
							   			
							   			if(dataObj.getPartState()!= null){
							   	   		pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getPartState()));
									   	}
							   			pwriterLcl.write(",");
							   			if(dataObj.getFindNum()!= null){
								   			   pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getFindNum()+"\""));
										 }
										 pwriterLcl.write(",");
										if(dataObj.getQuantity()!= null){
											if (dataObj.getQuantity().equals("0")) {
												pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getQuantity()+"\""));
							   				} else {
							   					pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getQuantity()));
							   				}
										}
										pwriterLcl.write(",");
										if(dataObj.getUom()!= null){
											pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getUom()));
										}
										pwriterLcl.write(",");
										if(dataObj.getReplacePart()!= null){
											pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getReplacePart()));
										}
										pwriterLcl.write(",");
	
										//APPENDING DOC ATTRIBUTES
										if(docDataObj.getDocBomLvl()!= null){
											pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDocBomLvl()));
										}
										pwriterLcl.write(",");
										if(docDataObj.getDocParent()!= null){
											pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDocParent()));
										}
										pwriterLcl.write(",");
										if(docDataObj.getDocName()!= null){
											pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDocName()));
										}
										pwriterLcl.write(",");
										if (docDataObj.getDocBomLvl()!=null) {
											if (Integer.parseInt(docDataObj.getDocBomLvl())==1) {
												if (dataObj.getLogicIndr()!=null) {
													pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getLogicIndr()+"\""));
												}
												pwriterLcl.write(",");
											} else {
												if(docDataObj.getLogicIndr()!= null){
													pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+docDataObj.getLogicIndr()+"\""));
												}
												pwriterLcl.write(",");
											}
												
										} 
										
										if(docDataObj.getDocRev()!= null){
											pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDocRev()));
										}
										pwriterLcl.write(",");
										if(docDataObj.getDocType()!= null){
											pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDocType()));
										}
										pwriterLcl.write(",");
										if(docDataObj.getDocState()!= null){
											pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDocState()));
										}
										pwriterLcl.write(",");
										if(docDataObj.getDocTitle()!= null){
											pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDocTitle()));
										}
										pwriterLcl.write(",");
										if(docDataObj.getDocClass()!= null){
											pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDocClass()));
										}
										pwriterLcl.write(",");
										if(docDataObj.getDwgCrtlCode()!= null){
											pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDwgCrtlCode()));
										}
										pwriterLcl.write(",");
										if(docDataObj.getExportCntrl()!= null){
											pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getExportCntrl()));
										}
										pwriterLcl.write(",");
										if(docDataObj.getModelValidated()!= null){
											pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getModelValidated()));
										}
										pwriterLcl.write("\n");
										rowCntLcl++;
									  }else{
										  if(pwriterLcl!=null){
										    pwriterLcl.close();
										  }
										  if(fileOutLcl!=null){
										    fileOutLcl.close();
										  }
										  //filePathcsvList.add(filePathCSVLcl);
										 // LOG.info("Adding File Name to filePathcsvList >>>>>>>>>>>>>>>>>>>>> "+filePathcsvList);
										  fileNmCtLcl++;
										  Map<String,Object>  varHeaderMap = createGbomHdrFile(fileDir,fileNmCtLcl,varFileWrtMapLcl);
										  varFileWrtMapLcl = (Map<String, Object>)varHeaderMap.get("varFileWrtMap");
										  pwriterLcl= (PrintWriter) varHeaderMap.get("pwriter");
										  fileOutLcl= (FileOutputStream) varHeaderMap.get("fileOut");
										  filePathCSVLcl=(String) varHeaderMap.get("filePathCSV");
										  
											if(dataObj.getMli()!= null){
									   			pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getMli()+"\""));
									   		}
								   			pwriterLcl.write(",");
								   			if(dataObj.getPartBomLvl()!= null){
								   				if (dataObj.getPartBomLvl().equals("0")) {
								   					pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getPartBomLvl()+"\""));
								   				} else {
								   					pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getPartBomLvl()));
								   				}
											}
											pwriterLcl.write(",");
											if(dataObj.getParentPart()!= null){
												pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getParentPart()));
											}
											pwriterLcl.write(",");
											if(dataObj.getPartName()!= null){
												pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getPartName()));
											}
											pwriterLcl.write(",");
								   			if(dataObj.getPartRev()!= null){
									   			pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getPartRev()+"\""));
									   		}
								   			pwriterLcl.write(",");
								   			if(dataObj.getPartDesc()!= null){
									   			pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getPartDesc()));
									   		}
								   			pwriterLcl.write(",");
								   			
								   			if(dataObj.getPartState()!= null){
								   	   		pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getPartState()));
										   	}
								   			pwriterLcl.write(",");
								   			if(dataObj.getFindNum()!= null){
									   			   pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getFindNum()+"\""));
											 }
											 pwriterLcl.write(",");
											if(dataObj.getQuantity()!= null){
												if (dataObj.getQuantity().equals("0")) {
													pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getQuantity()+"\""));
								   				} else {
								   					pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getQuantity()));
								   				}
											}
											pwriterLcl.write(",");
											if(dataObj.getUom()!= null){
												pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getUom()));
											}
											pwriterLcl.write(",");
											if(dataObj.getReplacePart()!= null){
												pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getReplacePart()));
											}
											pwriterLcl.write(",");
		
											//APPENDING DOC ATTRIBUTES
											if(docDataObj.getDocBomLvl()!= null){
												pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDocBomLvl()));
											}
											pwriterLcl.write(",");
											if(docDataObj.getDocParent()!= null){
												pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDocParent()));
											}
											pwriterLcl.write(",");
											if(docDataObj.getDocName()!= null){
												pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDocName()));
											}
											pwriterLcl.write(",");
											if (docDataObj.getDocBomLvl()!=null) {
												if (Integer.parseInt(docDataObj.getDocBomLvl())==1) {
													if (dataObj.getLogicIndr()!=null) {
														pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getLogicIndr()+"\""));
													}
													pwriterLcl.write(",");
												} else {
													if(docDataObj.getLogicIndr()!= null){
														pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+docDataObj.getLogicIndr()+"\""));
													}
													pwriterLcl.write(",");
												}
													
											} 
											
											if(docDataObj.getDocRev()!= null){
												pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDocRev()));
											}
											pwriterLcl.write(",");
											if(docDataObj.getDocType()!= null){
												pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDocType()));
											}
											pwriterLcl.write(",");
											if(docDataObj.getDocState()!= null){
												pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDocState()));
											}
											pwriterLcl.write(",");
											if(docDataObj.getDocTitle()!= null){
												pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDocTitle()));
											}
											pwriterLcl.write(",");
											if(docDataObj.getDocClass()!= null){
												pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDocClass()));
											}
											pwriterLcl.write(",");
											if(docDataObj.getDwgCrtlCode()!= null){
												pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getDwgCrtlCode()));
											}
											pwriterLcl.write(",");
											if(docDataObj.getExportCntrl()!= null){
												pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getExportCntrl()));
											}
											pwriterLcl.write(",");
											if(docDataObj.getModelValidated()!= null){
												pwriterLcl.write(PLMUtils.convertToCsvValue(docDataObj.getModelValidated()));
											}
											pwriterLcl.write("\n");
										   rowCntLcl=1;
									  }
									} // END OF FOR CONDITION FOR ADDING DOCS FOR A PART
									
								} // END OF IF CONDITION FOR DOCS LIST PRESENT FOR A PART
							} else {
								
						     if(rowCntLcl < maxLimitVal){	
											
								if(dataObj.getMli()!= null){
						   			pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getMli()+"\""));
						   		}
					   			pwriterLcl.write(",");
					   			if(dataObj.getPartBomLvl()!= null){
					   				if (dataObj.getPartBomLvl().equals("0")) {
					   					pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getPartBomLvl()+"\""));
					   				} else {
					   					pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getPartBomLvl()));
					   				}
								}
								pwriterLcl.write(",");
								if(dataObj.getParentPart()!= null){
									pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getParentPart()));
								}
								pwriterLcl.write(",");
								if(dataObj.getPartName()!= null){
									pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getPartName()));
								}
								pwriterLcl.write(",");
					   			if(dataObj.getPartRev()!= null){
						   			pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getPartRev()+"\""));
						   		}
					   			pwriterLcl.write(",");
					   			if(dataObj.getPartDesc()!= null){
						   			pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getPartDesc()));
						   		}
					   			pwriterLcl.write(",");
					   			
					   			if(dataObj.getPartState()!= null){
					   	   		pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getPartState()));
							   	}
					   			pwriterLcl.write(",");
					   			if(dataObj.getFindNum()!= null){
						   			   pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getFindNum()+"\""));
								 }
								 pwriterLcl.write(",");
								if(dataObj.getQuantity()!= null){
									if (dataObj.getQuantity().equals("0")) {
										pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getQuantity()+"\""));
					   				} else {
					   					pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getQuantity()));
					   				}
								}
								pwriterLcl.write(",");
								if(dataObj.getUom()!= null){
									pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getUom()));
								}
								pwriterLcl.write(",");
								if(dataObj.getReplacePart()!= null){
									pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getReplacePart()));
								}
								pwriterLcl.write(",");
								
								//DOC BOM LEVEL
								pwriterLcl.write("");
								pwriterLcl.write(",");
								
								//DOC PARENT
								pwriterLcl.write("");
								pwriterLcl.write(",");
								
								//DOC NAME
								pwriterLcl.write("");
								pwriterLcl.write(",");
								
								//LOGICAL INDICATOR
								pwriterLcl.write("");
								pwriterLcl.write(",");
								
								//DOC REV
								pwriterLcl.write("");
								pwriterLcl.write(",");
								
								//DOC TYPE
								pwriterLcl.write("");
								pwriterLcl.write(",");
								
								//DOC STATE
								pwriterLcl.write("");
								pwriterLcl.write(",");
								
								//DOC TITLE
								pwriterLcl.write("");
								pwriterLcl.write(",");
								
								//DOC CLASS
								pwriterLcl.write("");
								pwriterLcl.write(",");
								
								//DWG CRITICAL CODE
								pwriterLcl.write("");
								pwriterLcl.write(",");
								
								//EXPORT CONTROL
								pwriterLcl.write("");
								pwriterLcl.write(",");
								
								//MODEL VALIDATED
								pwriterLcl.write("");
					   			pwriterLcl.write("\n");
					   			rowCntLcl++;
						        }else{
						        	 if(pwriterLcl!=null){
									    pwriterLcl.close();
									 }
									 if(fileOutLcl!=null){
									    fileOutLcl.close();
									 }
								  //filePathcsvList.add(filePathCSVLcl);
								  //LOG.info("Adding File Name to filePathcsvList >>>>>>>>>>>>>>>>>>>>> "+filePathcsvList);
								  fileNmCtLcl++;
								  Map<String,Object>  varHeaderMap = createGbomHdrFile(fileDir,fileNmCtLcl,varFileWrtMapLcl);
								  varFileWrtMapLcl = (Map<String, Object>)varHeaderMap.get("varFileWrtMap");
								  pwriterLcl= (PrintWriter) varHeaderMap.get("pwriter");
								  fileOutLcl= (FileOutputStream) varHeaderMap.get("fileOut");
								  filePathCSVLcl=(String) varHeaderMap.get("filePathCSV");
									if(dataObj.getMli()!= null){
							   			pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getMli()+"\""));
							   		}
						   			pwriterLcl.write(",");
						   			if(dataObj.getPartBomLvl()!= null){
						   				if (dataObj.getPartBomLvl().equals("0")) {
						   					pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getPartBomLvl()+"\""));
						   				} else {
						   					pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getPartBomLvl()));
						   				}
									}
									pwriterLcl.write(",");
									if(dataObj.getParentPart()!= null){
										pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getParentPart()));
									}
									pwriterLcl.write(",");
									if(dataObj.getPartName()!= null){
										pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getPartName()));
									}
									pwriterLcl.write(",");
						   			if(dataObj.getPartRev()!= null){
							   			pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getPartRev()+"\""));
							   		}
						   			pwriterLcl.write(",");
						   			if(dataObj.getPartDesc()!= null){
							   			pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getPartDesc()));
							   		}
						   			pwriterLcl.write(",");
						   			
						   			if(dataObj.getPartState()!= null){
						   	   		pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getPartState()));
								   	}
						   			pwriterLcl.write(",");
						   			if(dataObj.getFindNum()!= null){
							   			   pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getFindNum()+"\""));
									 }
									 pwriterLcl.write(",");
									if(dataObj.getQuantity()!= null){
										if (dataObj.getQuantity().equals("0")) {
											pwriterLcl.write(PLMUtils.convertToCsvValue("=\""+dataObj.getQuantity()+"\""));
						   				} else {
						   					pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getQuantity()));
						   				}
									}
									pwriterLcl.write(",");
									if(dataObj.getUom()!= null){
										pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getUom()));
									}
									pwriterLcl.write(",");
									if(dataObj.getReplacePart()!= null){
										pwriterLcl.write(PLMUtils.convertToCsvValue(dataObj.getReplacePart()));
									}
									pwriterLcl.write(",");
									
									//DOC BOM LEVEL
									pwriterLcl.write("");
									pwriterLcl.write(",");
									
									//DOC PARENT
									pwriterLcl.write("");
									pwriterLcl.write(",");
									
									//DOC NAME
									pwriterLcl.write("");
									pwriterLcl.write(",");
									
									//LOGICAL INDICATOR
									pwriterLcl.write("");
									pwriterLcl.write(",");
									
									//DOC REV
									pwriterLcl.write("");
									pwriterLcl.write(",");
									
									//DOC TYPE
									pwriterLcl.write("");
									pwriterLcl.write(",");
									
									//DOC STATE
									pwriterLcl.write("");
									pwriterLcl.write(",");
									
									//DOC TITLE
									pwriterLcl.write("");
									pwriterLcl.write(",");
									
									//DOC CLASS
									pwriterLcl.write("");
									pwriterLcl.write(",");
									
									//DWG CRITICAL CODE
									pwriterLcl.write("");
									pwriterLcl.write(",");
									
									//EXPORT CONTROL
									pwriterLcl.write("");
									pwriterLcl.write(",");

									//MODEL VALIDATED
									pwriterLcl.write("");
						   			pwriterLcl.write("\n");

								   rowCntLcl=1;
							  }
							} // END OF ELSE CONDITION FOR DOC ID NOT AVAILABLE FOR A PART
				   			
				   		}//END OF FOR LOOP FOR PART RECORDS
				   		
		 			} // END OF IF CONDITION FOR PART LIST EMPTY
					if(loopIterCnt < loopCount){
					 //varFileWrtMap.put("FileCsvList", filePathcsvList);
					 varFileWrtMapLcl.put("RowCount", rowCntLcl);
					 varFileWrtMapLcl.put("FileCount", fileNmCtLcl);
					 varFileWrtMapLcl.put("pwriter", pwriterLcl);
					 varFileWrtMapLcl.put("fileOut", fileOutLcl);
					 varFileWrtMapLcl.put("filePathCSV", filePathCSVLcl);
					}else {
					  if(pwriterLcl!=null){	
					    pwriterLcl.close();
					  }
					  if(fileOutLcl!=null){
					    fileOutLcl.close();
					  }
					  /*filePathCSVLcl=(String) varHeaderMap.get("filePathCSV");
					  filePathcsvList.add(filePathCSVLcl);
					  LOG.info("Adding File Name to filePathcsvList >>>>>>>>>>>>>>>>>>>>> "+filePathcsvList);
					  varFileWrtMap.put("FileCsvList", filePathcsvList);*/
					}
					  
			}catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@createGbomCsvFiles: ", e);
				PLMUtils.checkException(e.getMessage());
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@createGbomCsvFiles: ", e);
				PLMUtils.checkException(e.getMessage());
			} /*finally {
				try {
					if (pwriter !=null) {
						pwriter.close();
					}
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@gbomPartsInsertToGTTtables: ", e);
					throw e;
				}
			}  */
			LOG.info("Exiting createGbomCsvFiles Method");
			return varFileWrtMapLcl;
		}
	/**
	 * 
	 * class to sort list of object of type PLMEPABoMData
	 * 
	 */
	private static class SortEPEDocs implements Comparator<PLMEPEBoMData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMEPEBoMData aString,
				PLMEPEBoMData bString) {
			
			return aString.getDocBomLvl().compareTo(bString.getDocBomLvl());
		   
		}
	}

	/**
	 * @return gbomDataList.
	 */
	public List<PLMGBomData> getGbomDataList() {
		return gbomDataList;
	}
	/**
	 * @param gbomDataList the gbomDataList to set
	 */
	public void setGbomDataList(List<PLMGBomData> gbomDataList) {
		this.gbomDataList = gbomDataList;
	}
	/**
	 * @return excelHeaderList.
	 */
	public List<PLMGBomData> getExcelHeaderList() {
		return excelHeaderList;
	}
	/**
	 * @param excelHeaderList the excelHeaderList to set
	 */
	public void setExcelHeaderList(List<PLMGBomData> excelHeaderList) {
		this.excelHeaderList = excelHeaderList;
	}

	
}
