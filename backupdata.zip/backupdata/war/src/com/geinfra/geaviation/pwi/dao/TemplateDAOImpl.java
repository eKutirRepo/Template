package com.geinfra.geaviation.pwi.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.TemplateVO;
import com.geinfra.geaviation.pwi.util.QueryConstants;
import com.geinfra.geaviation.pwi.util.QueryLoader;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Sep 27, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : TemplateDAO - implementation of DAO for accessing excel
 * templates in the DB.
 * 
 * Revision Log Sep 27, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class TemplateDAOImpl extends PWiDAO implements TemplateDAO {

	private static final class TemplateRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			TemplateVO template = new TemplateVO();
			template.setTemplateId(Integer.valueOf(rs
					.getInt(TemplateDAO.COLUMN_TEMPLATE_ID)));
			template.setTemplateName(rs
					.getString(TemplateDAO.COLUMN_TEMPLATE_NAME));
			template.setEnabled(rs.getBoolean(TemplateDAO.COLUMN_ENABLED));
			template.setExcelFileName(rs
					.getString(TemplateDAO.COLUMN_EXCEL_FILE_PATH));
			template.setQueryId(Integer.valueOf(rs
					.getInt(TemplateDAO.COLUMN_QUERY_ID)));
			template.setCrtnDt(rs.getDate(TemplateDAO.COLUMN_CREATED_DATE));
			template.setCrtdBy(rs.getString(TemplateDAO.COLUMN_CREATED_BY));
			template.setLstUpdtDt(rs
					.getDate(TemplateDAO.COLUMN_LAST_UPDATE_DATE));
			template.setLstUpdtdBy(rs
					.getString(TemplateDAO.COLUMN_LAST_UPDATED_BY));
			return template;
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @throws PWiException
	 */
	public Integer createTemplate(final String templateName,
			final boolean enabled, final String excelFilePath,
			final int queryId, final String sso) throws PWiException {
		String sql = QueryLoader.getQuery(QueryConstants.TEMPLATE_INSERT);

		Connection connection = null;
		CallableStatement statement = null;
		try {
			connection = getJdbcTemplate().getDataSource().getConnection();
			statement = connection.prepareCall(sql);

			// Set input parameters
			statement.setString(1, templateName);
			statement.setBoolean(2, enabled);
			statement.setString(3, excelFilePath);
			statement.setInt(4, queryId);
			statement.setString(5, sso);
			statement.setString(6, sso);

			// Set output parameters
			statement.registerOutParameter(7, Types.NUMERIC);

			// Execute query
			statement.execute();

			// Retrieve primary key
			int id = statement.getInt(7);

			return Integer.valueOf(id);
		} catch (SQLException e) {
			throw new PWiException(e);
		} finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
					throw new PWiException(e);
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					throw new PWiException(e);
				}
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void deleteTemplate(final Integer templateId) {
		// Retrieve SQL with bind parameters
		String sql = QueryLoader.getQuery(QueryConstants.TEMPLATE_DELETE);

		// Define prepared statement setter
		PreparedStatementSetter pss = new DeleteTemplateSetter(templateId);

		// Run delete statement on database
		getJdbcTemplate().update(sql, pss);
	}

	private static class DeleteTemplateSetter implements
			PreparedStatementSetter {
		private Integer templateId;

		public DeleteTemplateSetter(Integer templateId) {
			this.templateId = templateId;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setInt(1, templateId.intValue());
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @param templateId
	 * @return template value object
	 */
	public TemplateVO getTemplateById(final Integer templateId) {
		// Retrieve SQL with bind parameters
		String sql = QueryLoader.getQuery(QueryConstants.TEMPLATE_SELECT_BY_ID);

		// Define prepared statement setter
		PreparedStatementSetter pss = new GetTemplateByIdSetter(templateId);

		// Define row mapper
		RowMapper rowMapper = new TemplateRowMapper();

		// Run query on database
		@SuppressWarnings("unchecked")
		List<TemplateVO> templates = getJdbcTemplate().query(sql, pss,
				rowMapper);
		if (templates.size() == 1) {
			return templates.get(0);
		} else if (templates.size() == 0) {
			return null;
		}
		throw new IllegalStateException(
				"Failed to return one or zero templates for template ID: "
						+ templateId + ", templates: " + templates);
	}

	private static class GetTemplateByIdSetter implements
			PreparedStatementSetter {
		private Integer templateId;

		public GetTemplateByIdSetter(Integer templateId) {
			this.templateId = templateId;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setInt(1, templateId.intValue());
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public List<TemplateVO> getTemplatesForQuery(final Integer queryId) {
		// Retrieve SQL with bind parameters
		String sql = QueryLoader
				.getQuery(QueryConstants.TEMPLATE_SELECT_FOR_QUERY);

		// Define prepared statement setter
		PreparedStatementSetter pss = new GetTemplatesForQuerySetter(queryId);

		// Define row mapper
		RowMapper rowMapper = new TemplateRowMapper();

		// Run query on database
		@SuppressWarnings("unchecked")
		List<TemplateVO> templates = getJdbcTemplate().query(sql, pss,
				rowMapper);

		return templates;
	}

	private static class GetTemplatesForQuerySetter implements
			PreparedStatementSetter {
		private Integer queryId;

		public GetTemplatesForQuerySetter(Integer queryId) {
			this.queryId = queryId;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setInt(1, queryId.intValue());
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void updateTemplate(final TemplateVO template, final String userId) {
		// Retrieve SQL with bind parameters
		String sql = QueryLoader.getQuery(QueryConstants.TEMPLATE_UPDATE);

		// Define prepared statement setter
		PreparedStatementSetter pss = new UpdateTemplateSetter(template, userId);

		// Run update on database
		getJdbcTemplate().update(sql, pss);
	}

	private static class UpdateTemplateSetter implements
			PreparedStatementSetter {
		private TemplateVO template;
		private String userId;

		public UpdateTemplateSetter(TemplateVO template, String userId) {
			this.template = template;
			this.userId = userId;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setString(1, template.getTemplateName());
			ps.setString(2, template.getExcelFileName());
			ps.setBoolean(3, template.isEnabled());
			ps.setInt(4, template.getQueryId().intValue());
			ps.setString(5, userId); // last updated by
			ps.setInt(6, template.getTemplateId().intValue());
		}
	}
}
