package com.geinfra.geaviation.pwi.queryprocessing;

import java.util.Properties;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.xml.query.PropertyType;
import com.geinfra.geaviation.pwi.xml.query.QueryProcessorType;

/**
 * Project : Product Lifecycle Management Date Written : Oct 14, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : QueryProcessorFactory
 * 
 * Revision Log Oct 14, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class QueryProcessorFactory {
	/*
	 * comment the code on 31-oct as is is unused as per nimble report*/
	/*private ConfigService configService;

	public void setConfigService(ConfigService configService) {
		this.configService = configService;
	}*/
	
	/**
	 * Creates and initializes the appropriate query processor as defined by the
	 * specified query processor type.
	 * 
	 * @param procType
	 *            describes the query processor to be constructed
	 * @return a query processor as defined by the query processor type.
	 * @throws PWiException
	 */
	public QueryProcessor create(QueryProcessorType procType)
			throws PWiException {
		String type = procType.getType();

		Properties properties = new Properties();
		for (PropertyType propertyType : procType.getProperty()) {
			properties.setProperty(propertyType.getName(), propertyType
					.getValue());
		}

		QueryProcessor queryProcessor = null;
		if (PivotQueryProcessor.TYPE.equals(type)) {
			queryProcessor = new PivotQueryProcessor(properties);
		} else if (NoResultRowsQueryProcessor.TYPE.equals(type)) {
			queryProcessor = new NoResultRowsQueryProcessor(properties);
		} else if (SortQueryProcessor.TYPE.equals(type)) {
			queryProcessor = new SortQueryProcessor();
		} else if (AssyQueryProcessor.TYPE.equals(type)) {
			queryProcessor = new AssyQueryProcessor();
		/*} else if (HardwareQueryProcessor.TYPE.equals(type)) {
			queryProcessor = new HardwareQueryProcessor(configService, properties);*/
		} else if (DummyQueryProcessor.TYPE.equals(type)) {
			queryProcessor = new DummyQueryProcessor();
		} else {
			throw new PWiException(
					"Failed to recognize query processor type: " + type
							+ ", for ID: " + procType.getId());
		}
		return queryProcessor;
	}
}
