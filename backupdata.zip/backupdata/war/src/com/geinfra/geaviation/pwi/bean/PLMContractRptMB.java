 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMContractRptMB.java
 * @Creation date: 12-Aug-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import javax.faces.event.ActionEvent;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.common.usermodel.Hyperlink;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFCreationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFHyperlink;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMContractRptData;
import com.geinfra.geaviation.pwi.data.PLMContractSystemAsignData;
import com.geinfra.geaviation.pwi.service.PLMContractRptServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMContractRptMB {
	/**
	 *  Holds the lOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMContractRptMB.class);
	/**
	 *  Holds the plmContractRptService
	 */
	private PLMContractRptServiceIfc plmContractRptService = null;
	/**
	 *  Holds the loginMB
	 */
	private PLMCommonMB commonMB;
	/**
	 *  Holds the contractNum
	 */
	private String contractNum = "";
	/**
	 *  Holds the alertCntRptMsg
	 */
	private String alertCntRptMsg;
	private String totalRecordAptMsg;
	private String totalRecordAptMsgAddCntract;
	
	 /**
	  *  Holds the cntrctList
	  */
	 private List<PLMContractRptData> cntrctList = new ArrayList<PLMContractRptData>();
	 /**
	   * Holds the contractInfoRptMap
	   */
	private Map<String, List<PLMContractRptData>> contractInfoRptMap;
	/**
	 *  Holds the mlMplList
	 */
	private List<PLMContractRptData> mlMplList = new ArrayList<PLMContractRptData>();
	/**
	 *  Holds the projectInfoList
	 */
	private List<PLMContractRptData> projectInfoList = new ArrayList<PLMContractRptData>();
	/**
	 *  Holds the productList
	 */
	private List<PLMContractRptData> productList = new ArrayList<PLMContractRptData>();
	/**
	 *  Holds the prsList
	 */
	private List<PLMContractRptData> prsList = new ArrayList<PLMContractRptData>();
	/**
	 *  Holds the crsList
	 */
	private List<PLMContractRptData> crsList = new ArrayList<PLMContractRptData>();

	/**
	 * Holds the mlmplFlag
	 */
	private boolean mlmplFlag;
	/**
	 * Holds the projectFlag
	 */
	private boolean projectFlag;
	/**
	 * Holds the productFlag
	 */
	private boolean productFlag;
	/**
	 * Holds the prsFlag
	 */
	private boolean prsFlag;
	/**
	 * Holds the crsFlag
	 */
	private boolean crsFlag;
	
	 /**
	   *  Holds the projectIdName
	   */
	 private String projectIdName = "";
	 /**
	   *  Holds the selectRadio
	   */
	 private String selectRadio;
	 
	 /**
	   *  Holds the projectId
	   */
	 private String projectId;
	 
	 /**
	   *  Holds the projectName
	   */
	 private String projectName;
	 
	 /**
	   *  Holds the workSpaceId
	   */
	 private String workSpaceId;
	 
	 /**
	   * Holds the resourceBundle
	   */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");

	//Newly Added for Project Summary Report
	 /**
	   *  Holds the projectNm
	   */
	 private String projectNm;
	 /**
	   *  Holds the alertProjInfMsg
	   */
	 private String alertProjInfMsg;
	 /**
	  *  Holds the projectList
	  */
	 private List<PLMContractRptData> projectList = new ArrayList<PLMContractRptData>();
	 /**
	   * Holds the projectInfoRptMap
	   */
	private Map<String, List<PLMContractRptData>> projectInfoRptMap;
	/**
	 *  Holds the prjmlMplList
	 */
	private List<PLMContractRptData> prjmlMplList = new ArrayList<PLMContractRptData>();
	/**
	 *  Holds the prjprojectInfoList
	 */
	private List<PLMContractRptData> prjprojectInfoList = new ArrayList<PLMContractRptData>();
	/**
	 *  Holds the prjproductList
	 */
	private List<PLMContractRptData> prjproductList = new ArrayList<PLMContractRptData>();
	/**
	 *  Holds the prjprsList
	 */
	private List<PLMContractRptData> prjprsList = new ArrayList<PLMContractRptData>();
	/**
	 *  Holds the prjcrsList
	 */
	private List<PLMContractRptData> prjcrsList = new ArrayList<PLMContractRptData>();
	/**
	 * Holds the prjmlmplFlag
	 */
	private boolean prjmlmplFlag;
	/**
	 * Holds the prjprojectFlag
	 */
	private boolean prjprojectFlag;
	/**
	 * Holds the prjproductFlag
	 */
	private boolean prjproductFlag;
	/**
	 * Holds the prjprsFlag
	 */
	private boolean prjprsFlag;
	/**
	 * Holds the prjcrsFlag
	 */
	private boolean prjcrsFlag;
	
	 /**
	   *  Holds the prjprojectIdName
	   */
	 private String prjprojectIdName = "";
	 /**
	   *  Holds the prjselectRadio
	   */
	 private String prjselectRadio;
	 
	 /**
	   *  Holds the prjprojectId
	   */
	 private String prjprojectId;
	 
	 /**
	   *  Holds the prjprojectName
	   */
	 private String prjprojectName;
	 
	 /**
	   *  Holds the prjworkSpaceId
	   */
	 private String prjworkSpaceId;
	 
	 /**
	   *  Holds the prjworkSpaceId
	   */
	 private String systemName;
	 
	 private String systemNameOld;
	 private String systemNameOldHide;
	 
	 private boolean sysOldEnabled;
	 
	 private String hdnSystmId;
	 
	 private String hdnSelectedOption;
	 
	 private boolean showSysTable;
	 
	 private boolean showAssignSysTable;
	 private boolean showAssignSysTableRec;
	private List<String> selSysNames = new ArrayList<String>();
	 
	 private int recordCount=PLMConstants.N_100;

	 private PLMContractSystemAsignData optionSystemMapData = new  PLMContractSystemAsignData();
	 
	/**
		 *  Holds the systemList
		 */
	private List<PLMContractSystemAsignData> systemList = new ArrayList<PLMContractSystemAsignData>();
	
	/**
	 *  Holds the systemList
	 */
	private List<PLMContractSystemAsignData> aasignSystemList = new ArrayList<PLMContractSystemAsignData>();
	
	private List<PLMContractSystemAsignData> popUpOptionMapList = new ArrayList<PLMContractSystemAsignData>();
	
	private List<SelectItem> systemSelList = new ArrayList<SelectItem>();
	
	private List<String> selectedSysNameList = new ArrayList<String>();
	
	private List<SelectItem> prdctSelList = new ArrayList<SelectItem>();
	
	private List<String> selectedPrdctList = new ArrayList<String>();
	
	private boolean sysUnAssigned;
	
	private boolean sysAssigned;
	
	private String alertCntRptMapMsg;

	private boolean gasId;
	private boolean genId;
	private boolean steamId;
	
	public boolean isGasId() {
		return gasId;
	}

	public void setGasId(boolean gasId) {
		this.gasId = gasId;
	}

	public boolean isGenId() {
		return genId;
	}

	public void setGenId(boolean genId) {
		this.genId = genId;
	}

	public boolean isSteamId() {
		return steamId;
	}

	public void setSteamId(boolean steamId) {
		this.steamId = steamId;
	}

	private XSSFFont headerFont(SXSSFWorkbook wb, int size){
			XSSFFont font = (XSSFFont) wb.createFont();
			font.setFontName(PLMConstants.EXCEL_FONT_NAME);
			font.setFontHeightInPoints((short)size);
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			return font;
		}
		
		private XSSFFont normalFont(SXSSFWorkbook wb, int size){
			XSSFFont font = (XSSFFont) wb.createFont();
			font.setFontName(PLMConstants.EXCEL_FONT_NAME);
			font.setFontHeightInPoints((short)size);
			return font;
		}
		
		private XSSFCellStyle headerCell(SXSSFWorkbook wb, XSSFFont font, short bgcolor, boolean wrap){
			XSSFCellStyle hCell = normalCell(wb, font, XSSFCellStyle.SOLID_FOREGROUND, wrap);
			//FONT
			hCell.setFont(font);
			
			//HORIZONTAL ALIGNMENT
			hCell.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			
			//COLOR
			hCell.setFillForegroundColor(bgcolor);
			return hCell;
		}
		
		private XSSFCellStyle normalCell(SXSSFWorkbook wb, XSSFFont font, short fillPattern, boolean wrap){
			// Cell Style
			XSSFCellStyle cellStyle = (XSSFCellStyle)wb.createCellStyle();
			
			//Set Font
			cellStyle.setFont(font);
			//WRAP TEXT
			cellStyle.setWrapText(wrap);
			
			//VERTICAL ALIGNMENT
			cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			
			//BORDERS
			cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			
			//FILL PATTERN
			cellStyle.setFillPattern(fillPattern);
			return cellStyle;
		}

		/**
		 * This method is used for Bordering Cell in XLS
		 * 
		 * @return StringBuffer
		 */
		private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
			style.setBorderTop(XSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			style.setBorderRight(XSSFCellStyle.BORDER_THIN);
			return style;
		}
		
	 /**
		 * This method is used to download excel for Contract Info Report
		 * 
		 * @throws PLMCommonException
		 */

		public void downloadCIRExcel() throws PLMCommonException {

			LOG.info("Entering downloadCIRExcel Method");
			FacesContext facesContext = FacesContext.getCurrentInstance();
		  	try {
				HttpServletResponse response = 
					(HttpServletResponse)facesContext.getExternalContext().getResponse();
				
				response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
				
				response.setHeader("Content-disposition", 
						"attachment; filename="+"Contract Information.xlsx");
				
				OutputStream outputStream = response.getOutputStream();
				
				SXSSFWorkbook workbook = new SXSSFWorkbook();
				
				XSSFFont font = headerFont(workbook, 10);
				
				// Header Style
				XSSFCellStyle headerStyle = headerCell(workbook, font, HSSFColor.PALE_BLUE.index, true);

				XSSFFont cellfont = normalFont(workbook, 10);
				// Cell Style
				XSSFCellStyle cellStyle = normalCell(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
				
				// cell hyper link
				XSSFCreationHelper helper= (XSSFCreationHelper) workbook.getCreationHelper();
				
			    XSSFFont underLinedFont = (XSSFFont) workbook.createFont();
		        underLinedFont.setUnderline(HSSFFont.U_SINGLE);
		        underLinedFont.setColor(IndexedColors.BLUE.getIndex());
				XSSFCellStyle hyperLinkStyle = (XSSFCellStyle) workbook.createCellStyle();				
				hyperLinkStyle = setBorderStyle(hyperLinkStyle);
				hyperLinkStyle.setFont(underLinedFont);
				
				SXSSFSheet sheet = (SXSSFSheet) workbook.createSheet("Contract Info");
				
				int rowcount = 0;
				
				SXSSFCell cell=null;
			    
			    SXSSFRow row = (SXSSFRow) sheet.createRow(rowcount);
			    
				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
				cell.setCellValue("Contract Number");
				cell.setCellStyle(cellStyle);

				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellValue(contractNum);
				cell.setCellStyle(cellStyle);
				
				row = (SXSSFRow) sheet.createRow(++rowcount);
				row = (SXSSFRow) sheet.createRow(++rowcount);
			    
	            	
	             String[] mlPlColumns = {"ML/MPL Number","Serial Number","Shop Order Number"};
	        			
	            	for ( int i = 0 ; i < mlPlColumns.length; i++ ) {
	    				cell = (SXSSFCell)row.createCell(i);
	    				cell. setCellValue(mlPlColumns[i]);
	    				cell.setCellStyle(headerStyle);
	    			}
	             
					for(int i=0;i<mlMplList.size();i++){
					
						PLMContractRptData dataObj = (PLMContractRptData) mlMplList.get(i);
						
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
						
						if(!PLMUtils.isEmpty(dataObj.getMlmplId())){
							cell.setCellStyle(hyperLinkStyle);
							XSSFHyperlink url_link1 = helper.createHyperlink(Hyperlink.LINK_URL);
							url_link1.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getMlmplId());
							cell.setHyperlink(url_link1);
							cell.setCellValue(dataObj.getMlmplNm());
						}else{
							cell.setCellStyle(cellStyle);
							 cell.setCellValue("");
						}
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(dataObj.getGeSerialNum());
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(dataObj.getShopOrder());
			  	   }
				
	             	row = (SXSSFRow) sheet.createRow(++rowcount);
	             	row = (SXSSFRow) sheet.createRow(++rowcount);
	             	
		    		cell = (SXSSFCell)row.createCell(0);
		    		cell. setCellValue("Project Name");
		    		cell.setCellStyle(headerStyle);
		    		
		    		for(int j=0;j<projectInfoList.size();j++){
						
						PLMContractRptData dataObj = (PLMContractRptData) projectInfoList.get(j);
						
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
						
						if(!PLMUtils.isEmpty(dataObj.getProjectId())){
							cell.setCellStyle(hyperLinkStyle);
							XSSFHyperlink url_link2 = helper.createHyperlink(Hyperlink.LINK_URL);
							url_link2.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getProjectId());
							cell.setHyperlink(url_link2);
							cell.setCellValue(dataObj.getProjectName());
						}else{
							cell.setCellStyle(cellStyle);
							 cell.setCellValue("");
						}
						
			  	   }
		    		
		    		row = (SXSSFRow) sheet.createRow(++rowcount);
	             	row = (SXSSFRow) sheet.createRow(++rowcount);
	            
	             	cell = (SXSSFCell)row.createCell(0);
		    		cell. setCellValue("Hardware Product(s)");
		    		cell.setCellStyle(headerStyle);
		    		
		    		for(int k=0;k<productList.size();k++){
						
						PLMContractRptData dataObj = (PLMContractRptData) productList.get(k);
						
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
						
						if(!PLMUtils.isEmpty(dataObj.getProductId())){
							cell.setCellStyle(hyperLinkStyle);
							XSSFHyperlink url_link3 = helper.createHyperlink(Hyperlink.LINK_URL);
							url_link3.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getProductId());
							cell.setHyperlink(url_link3);
							cell.setCellValue(dataObj.getHdWareProduct());
						}else{
							cell.setCellStyle(cellStyle);
							 cell.setCellValue("");
						}
						
			  	   }
		    		
		    		row = (SXSSFRow) sheet.createRow(++rowcount);
	             	row = (SXSSFRow) sheet.createRow(++rowcount);
	            
	             	cell = (SXSSFCell)row.createCell(0);
		    		cell. setCellValue("Product Requirement Specification (PRS)");
		    		cell.setCellStyle(headerStyle);
		    		
		    		for(int l=0;l<prsList.size();l++){
						
						PLMContractRptData dataObj = (PLMContractRptData) prsList.get(l);
						
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
						
						if(!PLMUtils.isEmpty(dataObj.getPrsId())){
							cell.setCellStyle(hyperLinkStyle);
							XSSFHyperlink url_link4 = helper.createHyperlink(Hyperlink.LINK_URL);
							url_link4.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getPrsId());
							cell.setHyperlink(url_link4);
							cell.setCellValue(dataObj.getPrsName());
						}else{
							cell.setCellStyle(cellStyle);
							 cell.setCellValue("");
						}
						
			  	   }
		    		
		    		row = (SXSSFRow) sheet.createRow(++rowcount);
	             	row = (SXSSFRow) sheet.createRow(++rowcount);
	            
	             	cell = (SXSSFCell)row.createCell(0);
		    		cell. setCellValue("Customer Requirement Specification (CRS)");
		    		cell.setCellStyle(headerStyle);
		    		
		    		for(int m=0;m<crsList.size();m++){
						
						PLMContractRptData dataObj = (PLMContractRptData) crsList.get(m);
						
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
						
						if(!PLMUtils.isEmpty(dataObj.getCrsId())){
							cell.setCellStyle(hyperLinkStyle);
							XSSFHyperlink url_link5 = helper.createHyperlink(Hyperlink.LINK_URL);
							url_link5.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getCrsId());
							cell.setHyperlink(url_link5);
							cell.setCellValue(dataObj.getCrsName());
						}else{
							cell.setCellStyle(cellStyle);
							 cell.setCellValue("");
						}
						
			  	   }
		    		
		    		row = (SXSSFRow) sheet.createRow(++rowcount);
	             	row = (SXSSFRow) sheet.createRow(++rowcount);
	             	
				    XSSFCellStyle ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
				    ftrStyle.setFont(font);
				    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
				    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
				    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
				    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
				    cell.setCellStyle(ftrStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_TWO));

					sheet.setColumnWidth(0,20*256);
					sheet.setColumnWidth(1,15*256);
					sheet.setColumnWidth(2,15*256);
				
	            workbook.write(outputStream);
				
				outputStream.flush();
				
				outputStream.close();
				
			} catch (IOException ioex) {
				ioex.printStackTrace();
			} finally {
				facesContext.responseComplete();
		  	}
			LOG.info("Exiting downloadCIRExcel Method");
			
		}
	
	/**
	 * This method is used to load home page of contract Info Home page 
	 * 
	 * @return String
	 * @throws PLMCommonException 
	 */
	public String getContractInfoHomePage() {
		LOG.info("Entering getContractInfoHomePage method");
		
		try {
			commonMB.insertCannedRptRecordHitInfo("Contract Info Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		String fwdFlag="contractInfoSearchRpt";
		  alertCntRptMsg = "";
		  contractNum = "";
		  projectIdName="";
		  mlMplList = new ArrayList<PLMContractRptData>();
          projectInfoList = new ArrayList<PLMContractRptData>();
          productList = new ArrayList<PLMContractRptData>();
          prsList = new ArrayList<PLMContractRptData>();
          crsList = new ArrayList<PLMContractRptData>();
          mlmplFlag=false;
          projectFlag=false;
          productFlag=false;
          prsFlag=false;  
          crsFlag=false;
	   LOG.info("Exiting getContractInfoHomePage method");
		return fwdFlag;
		
	}

	/**
	 * This method is used to get contract information Report
	 * 
	 * @return String
	 * @throws PLMCommonException 
	 */
	public String getContractInfoRpt() throws PLMCommonException{
		LOG.info("Entering getContractInfoRpt method");
		String fwdFlag="contractInfoSearchRpt";
		projectIdName="";
		try {
		  mlMplList = new ArrayList<PLMContractRptData>();
          projectInfoList = new ArrayList<PLMContractRptData>();
          productList = new ArrayList<PLMContractRptData>();
          prsList = new ArrayList<PLMContractRptData>();
          crsList = new ArrayList<PLMContractRptData>();
          mlmplFlag=false;
          projectFlag=false;
          productFlag=false;
          prsFlag=false;  
          crsFlag=false;
		  alertCntRptMsg = "";
			alertCntRptMsg = validationForCntrctSmryRpt(contractNum);
			  if(PLMUtils.isEmpty(alertCntRptMsg)){
					cntrctList = plmContractRptService.fetchCntrInfo(contractNum);
			  	   if(PLMUtils.isEmptyList(cntrctList)){
			  			alertCntRptMsg = PLMConstants.CNTRCT_SMRY_ONSCN_SEARCH_CRITERIA;
					 }else{
						 contractInfoRptMap = plmContractRptService.getContractInfoRpt(contractNum);
						
						 mlMplList =contractInfoRptMap.get("MLMPL");
						 projectInfoList =contractInfoRptMap.get("PROJECT");
						 productList =contractInfoRptMap.get("PRODUCT");
						 prsList =contractInfoRptMap.get("PRS");
						 crsList =contractInfoRptMap.get("CRS");
						 
						 if(mlMplList.size()>0){
							 mlmplFlag=true;
						 }else{
							 mlmplFlag=false;
						 }
						
						 
						 if(projectInfoList.size()>0){
							 projectFlag=true;
								setSelectRadio(projectInfoList.get(0)
										.getProjectIdNm());
								projectIdName = selectRadio;
								  String[] projectidNmArr = projectIdName.split("~");
								  workSpaceId = projectidNmArr[0];
								 LOG.info("workSpaceId>>> "+workSpaceId);
								 projectId = projectidNmArr[1];
								 LOG.info("projectId>>> "+projectId);
								 projectName = projectidNmArr[2];
								 LOG.info("projectName>>> "+projectName);
						 }else{
							 projectFlag=false;
						 }
						 
						 if(productList.size()>0){
							 productFlag=true;
						 }else{
							 productFlag=false;
						 }
						 
						 if(prsList.size()>0){
							 prsFlag=true;
						 }else{
							 prsFlag=false;
						 }
						 
						 if(crsList.size()>0){
							 crsFlag=true;
						 }else{
							 crsFlag=false;
						 }
				       }
		        	 }
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getContractInfoRpt: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"contractInfoSearchRpt","Contract Info Report");
		}
	    LOG.info("Exiting getContractInfoRpt method");
		return fwdFlag;
		
	}
	
	public void chngProjectIdNm(){
		
		LOG.info("Entering into  chngProjectIdNm method");
			if(!PLMUtils.isEmpty(projectIdName)){
			 String[] projectidNmArr = projectIdName.split("~");
			     workSpaceId = projectidNmArr[0];
				 LOG.info("workSpaceId>>> "+workSpaceId);
				 projectId = projectidNmArr[1];
				 LOG.info("projectId>>> "+projectId);
				 projectName = projectidNmArr[2];
				 LOG.info("projectName>>> "+projectName);
	 setSelectRadio(projectIdName);
		}
		LOG.info("Exiting into  chngProjectIdNm method");
	
	}
	
	
	/**
	 * This method is used for validating contract number
	 * 
	 * @param contractNumLcl
	 * @return String
	 */
	public String validationForCntrctSmryRpt(String contractNumLcl){
		alertCntRptMsg = "";
		if (PLMUtils.isEmpty(contractNumLcl)) {
			alertCntRptMsg = PLMConstants.CNTRCT_SMRY_ONSCN_SEARCH_CRITERIA_EMPTY_CHK;
		} else if(!PLMUtils.checkForSpecialChars(contractNumLcl)){
			alertCntRptMsg = PLMConstants.PRJ_SMRY_SEARCH_CRITERIA_SPL_CHARS;
		}
		return alertCntRptMsg;
	}
	
	//Start Added methods for Project Summary Report
	
	/**
	 * This method is used to load home page of Project Summary Report Home page 
	 * 
	 * @return String
	 * @throws PLMCommonException 
	 */
	public String getProjectSmryHomePage() {
		LOG.info("Entering getProjectSmryHomePage method");
		
		try {
			commonMB.insertCannedRptRecordHitInfo("Project Summary Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		String fwdFlag="projectSmrySearchRpt";
		  projectNm = "";
		  alertProjInfMsg="";
		  prjmlMplList = new ArrayList<PLMContractRptData>();
		  prjprojectInfoList = new ArrayList<PLMContractRptData>();
		  prjproductList = new ArrayList<PLMContractRptData>();
		  prjprsList = new ArrayList<PLMContractRptData>();
		  prjcrsList = new ArrayList<PLMContractRptData>();
		  prjmlmplFlag=false;
		  prjprojectFlag=false;
		  prjproductFlag=false;
		  prjprsFlag=false;  
		  prjcrsFlag=false;

	   LOG.info("Exiting getProjectSmryHomePage method");
		return fwdFlag;
	}
	
	/**
	 * This method is used to get project information Report
	 * 
	 * @return String
	 * @throws PLMCommonException 
	 */
	public String getProjectInfoRpt() throws PLMCommonException{
		LOG.info("Entering getProjectInfoRpt method");
		String fwdFlag="projectSmrySearchRpt";
		try {
			alertProjInfMsg = "";
			alertProjInfMsg = validationForProjSmryRpt(projectNm);
			  if(PLMUtils.isEmpty(alertProjInfMsg)){
				   projectList = plmContractRptService.fetchProjectInfo(projectNm);
			  	   if(PLMUtils.isEmptyList(projectList)){
			  		 alertProjInfMsg = PLMConstants.PRJ_SMRY_VALID_SEARCH_CRITERIA;
					 }else{
						 projectInfoRptMap = plmContractRptService.getProjectInfoRpt(projectNm);
						
						 prjmlMplList =projectInfoRptMap.get("MLMPL");
						 prjprojectInfoList =projectInfoRptMap.get("PROJECT");
						 prjproductList =projectInfoRptMap.get("PRODUCT");
						 prjprsList =projectInfoRptMap.get("PRS");
						 prjcrsList =projectInfoRptMap.get("CRS");
						 
						 if(prjmlMplList.size()>0){
							 prjmlmplFlag=true;
						 }else{
							 prjmlmplFlag=false;
						 }
						
						 
						 if(prjprojectInfoList.size()>0){
							 prjprojectFlag=true;
							 setPrjselectRadio(prjprojectInfoList.get(0)
										.getProjectIdNm());
								prjprojectIdName = prjselectRadio;
								  String[] projectidNmArr = prjprojectIdName.split("~");
								  prjworkSpaceId = projectidNmArr[0];
								 LOG.info("prjworkSpaceId>>> "+prjworkSpaceId);
								 prjprojectId = projectidNmArr[1];
								 LOG.info("prjprojectId>>> "+prjprojectId);
								 prjprojectName = projectidNmArr[2];
								 LOG.info("prjprojectName>>> "+prjprojectName);
						 }else{
							 prjprojectFlag=false;
						 }
						 
						 
						 if(prjproductList.size()>0){
							 prjproductFlag=true;
						 }else{
							 prjproductFlag=false;
						 }
						 
						 if(prjprsList.size()>0){
							 prjprsFlag=true;
						 }else{
							 prjprsFlag=false;
						 }
						 
						 if(prjcrsList.size()>0){
							 prjcrsFlag=true;
						 }else{
							 prjcrsFlag=false;
						 }
						 
				       }
		        	 }
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getProjectInfoRpt: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"getProjectInfoRpt","Project Summary Report");
		}
	    LOG.info("Exiting getProjectInfoRpt method");
		return fwdFlag;
		
	}

	public void chngPrjProjectIdNm(){
		LOG.info("Entering into  chngPrjProjectIdNm method");
			if(!PLMUtils.isEmpty(projectIdName)){
			 String[] prjprojectidNmArr = projectIdName.split("~");
			     prjworkSpaceId = prjprojectidNmArr[0];
				 LOG.info("prjworkSpaceId>>> "+prjworkSpaceId);
				 prjprojectId = prjprojectidNmArr[1];
				 LOG.info("prjprojectId>>> "+prjprojectId);
				 prjprojectName = prjprojectidNmArr[2];
				 LOG.info("prjprojectName>>> "+prjprojectName);
				 setPrjselectRadio(prjprojectId);
		}
		LOG.info("Exiting into  chngPrjProjectIdNm method");
	
	}
	/**
	 * This method is used for validating Project number
	 * 
	 * @param contractNumLcl
	 * @return String
	 */
	public String validationForProjSmryRpt(String projectNmLcl){
		alertProjInfMsg = "";
		if (PLMUtils.isEmpty(projectNmLcl)) {
			alertProjInfMsg = PLMConstants.PRJ_SMRY_SEARCH_CRITERIA_EMPTY_CHK;
		} else if(!PLMUtils.checkForSpecialChars(projectNmLcl)){
			alertProjInfMsg = PLMConstants.PRJ_SMRY_SEARCH_CRITERIA_SPL_CHARS;
		}
		return alertProjInfMsg;
	}
	
	
	 /**
		 * This method is used to download excel for Contract Info Report
		 * 
		 * @throws PLMCommonException
		 */

		public void downloadPIRExcel() throws PLMCommonException {

			LOG.info("Entering downloadCIRExcel Method");
			FacesContext facesContext = FacesContext.getCurrentInstance();
		  	try {
				HttpServletResponse response = 
					(HttpServletResponse)facesContext.getExternalContext().getResponse();
				
				response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
				
				response.setHeader("Content-disposition", 
						"attachment; filename="+"Project Information.xlsx");
				
				OutputStream outputStream = response.getOutputStream();
				
				SXSSFWorkbook workbook = new SXSSFWorkbook();
				
				XSSFFont font = headerFont(workbook, 10);
				
				// Header Style
				XSSFCellStyle headerStyle = headerCell(workbook, font, HSSFColor.PALE_BLUE.index, true);

				XSSFFont cellfont = normalFont(workbook, 10);
				// Cell Style
				XSSFCellStyle cellStyle = normalCell(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
				
				// cell hyper link
				XSSFCreationHelper helper= (XSSFCreationHelper) workbook.getCreationHelper();
				
			    XSSFFont underLinedFont = (XSSFFont) workbook.createFont();
		        underLinedFont.setUnderline(HSSFFont.U_SINGLE);
		        underLinedFont.setColor(IndexedColors.BLUE.getIndex());
				XSSFCellStyle hyperLinkStyle = (XSSFCellStyle) workbook.createCellStyle();				
				hyperLinkStyle = setBorderStyle(hyperLinkStyle);
				hyperLinkStyle.setFont(underLinedFont);
				
				SXSSFSheet sheet = (SXSSFSheet) workbook.createSheet("Project Info");
				
				int rowcount = 0;
				
				SXSSFCell cell=null;
			    
			    SXSSFRow row = (SXSSFRow) sheet.createRow(rowcount);
			    
				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
				cell.setCellValue("Project Name");
				cell.setCellStyle(cellStyle);

				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellValue(projectNm);
				cell.setCellStyle(cellStyle);
				
				row = (SXSSFRow) sheet.createRow(++rowcount);
				row = (SXSSFRow) sheet.createRow(++rowcount);
			    
	            	
				if(!PLMUtils.isEmptyList(prjmlMplList)){
					
	             String[] mlPlColumns = {"ML/MPL Number","Serial Number","Shop Order Number"};
	        			
	            	for ( int i = 0 ; i < mlPlColumns.length; i++ ) {
	    				cell = (SXSSFCell)row.createCell(i);
	    				cell. setCellValue(mlPlColumns[i]);
	    				cell.setCellStyle(headerStyle);
	    			}
	             
					for(int i=0;i<prjmlMplList.size();i++){
					
						PLMContractRptData dataObj = (PLMContractRptData) prjmlMplList.get(i);
						
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
						
						if(!PLMUtils.isEmpty(dataObj.getMlmplId())){
							cell.setCellStyle(hyperLinkStyle);
							XSSFHyperlink url_link1 = helper.createHyperlink(Hyperlink.LINK_URL);
							url_link1.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getMlmplId());
							cell.setHyperlink(url_link1);
							cell.setCellValue(dataObj.getMlmplNm());
						}else{
							cell.setCellStyle(cellStyle);
							 cell.setCellValue("");
						}
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(dataObj.getGeSerialNum());
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(dataObj.getShopOrder());
			  	   }
				
	             	row = (SXSSFRow) sheet.createRow(++rowcount);
	             	row = (SXSSFRow) sheet.createRow(++rowcount);
				 }
	             	
		    		cell = (SXSSFCell)row.createCell(0);
		    		cell. setCellValue("Project Name");
		    		cell.setCellStyle(headerStyle);
		    		
		    		cell = (SXSSFCell)row.createCell(1);
		    		cell. setCellValue("Safer/External Dependency ID");
		    		cell.setCellStyle(headerStyle);
		    		
		    		for(int j=0;j<prjprojectInfoList.size();j++){
						
						PLMContractRptData dataObj = (PLMContractRptData) prjprojectInfoList.get(j);
						
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
						
						if(!PLMUtils.isEmpty(dataObj.getProjectId())){
							cell.setCellStyle(hyperLinkStyle);
							XSSFHyperlink url_link2 = helper.createHyperlink(Hyperlink.LINK_URL);
							url_link2.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getProjectId());
							cell.setHyperlink(url_link2);
							cell.setCellValue(dataObj.getProjectName());
						}else{
							cell.setCellStyle(cellStyle);
							 cell.setCellValue("");
						}
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(dataObj.getSaferId());
						
			  	   }
		    		
		    		
		    		if(!PLMUtils.isEmptyList(prjproductList)){
		    		row = (SXSSFRow) sheet.createRow(++rowcount);
	             	row = (SXSSFRow) sheet.createRow(++rowcount);
	            
	             	cell = (SXSSFCell)row.createCell(0);
		    		cell. setCellValue("Hardware Product(s)");
		    		cell.setCellStyle(headerStyle);
		    		
			    		for(int k=0;k<prjproductList.size();k++){
							
							PLMContractRptData dataObj = (PLMContractRptData) prjproductList.get(k);
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
							
							if(!PLMUtils.isEmpty(dataObj.getProductId())){
								cell.setCellStyle(hyperLinkStyle);
								XSSFHyperlink url_link3 = helper.createHyperlink(Hyperlink.LINK_URL);
								url_link3.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getProductId());
								cell.setHyperlink(url_link3);
								cell.setCellValue(dataObj.getHdWareProduct());
							}else{
								cell.setCellStyle(cellStyle);
								 cell.setCellValue("");
							}
							
				  	   }
		    		}
		    		
		    		if(!PLMUtils.isEmptyList(prjprsList)){
		    		row = (SXSSFRow) sheet.createRow(++rowcount);
	             	row = (SXSSFRow) sheet.createRow(++rowcount);
	            
	             	cell = (SXSSFCell)row.createCell(0);
		    		cell. setCellValue("Product Requirement Specification (PRS)");
		    		cell.setCellStyle(headerStyle);
		    		
			    		for(int l=0;l<prjprsList.size();l++){
							
							PLMContractRptData dataObj = (PLMContractRptData) prjprsList.get(l);
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
							
							if(!PLMUtils.isEmpty(dataObj.getPrsId())){
								cell.setCellStyle(hyperLinkStyle);
								XSSFHyperlink url_link4 = helper.createHyperlink(Hyperlink.LINK_URL);
								url_link4.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getPrsId());
								cell.setHyperlink(url_link4);
								cell.setCellValue(dataObj.getPrsName());
							}else{
								cell.setCellStyle(cellStyle);
								 cell.setCellValue("");
							}
							
				  	   }
		    		}
		    		
		    		if(!PLMUtils.isEmptyList(prjcrsList)){
		    		row = (SXSSFRow) sheet.createRow(++rowcount);
	             	row = (SXSSFRow) sheet.createRow(++rowcount);
	            
	             	cell = (SXSSFCell)row.createCell(0);
		    		cell. setCellValue("Customer Requirement Specification (CRS)");
		    		cell.setCellStyle(headerStyle);
		    		
			    		for(int m=0;m<prjcrsList.size();m++){
							
							PLMContractRptData dataObj = (PLMContractRptData) prjcrsList.get(m);
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
							
							if(!PLMUtils.isEmpty(dataObj.getCrsId())){
								cell.setCellStyle(hyperLinkStyle);
								XSSFHyperlink url_link5 = helper.createHyperlink(Hyperlink.LINK_URL);
								url_link5.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getCrsId());
								cell.setHyperlink(url_link5);
								cell.setCellValue(dataObj.getCrsName());
							}else{
								cell.setCellStyle(cellStyle);
								 cell.setCellValue("");
							}
							
				  	   }
		    		}
		    		
		    		row = (SXSSFRow) sheet.createRow(++rowcount);
	             	row = (SXSSFRow) sheet.createRow(++rowcount);
	             	
				    XSSFCellStyle ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
				    ftrStyle.setFont(font);
				    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
				    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
				    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
				    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
				    cell.setCellStyle(ftrStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_TWO));

					sheet.setColumnWidth(0,20*256);
					sheet.setColumnWidth(1,15*256);
					sheet.setColumnWidth(2,15*256);
				
	            workbook.write(outputStream);
				
				outputStream.flush();
				
				outputStream.close();
				
			} catch (IOException ioex) {
				ioex.printStackTrace();
			} finally {
				facesContext.responseComplete();
		  	}
			LOG.info("Exiting downloadCIRExcel Method");
			
		}
		
		
	
	//End Added methods for Project Summary Report
		
		//Start contract system mapping screen
		
		/**
		 * This method is used to load home page of System Info Home page 
		 * 
		 * @return String
		 * @throws PLMCommonException 
		 */
		public String getSystemNameAddHomePage() {
			LOG.info("Entering getSystemNameAddHomePage method");
			
			try {
				commonMB.insertCannedRptRecordHitInfo("Add System Name");
				systemList =  new ArrayList<PLMContractSystemAsignData>();
				systemList =  getSystemNames("%");
			} catch (PLMCommonException ex) {
				LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
			}
			String fwdFlag="addSystemMapping";
			  alertCntRptMsg = "";
			  systemName = "";
			  systemNameOld="";
			  systemNameOldHide="";
			  sysOldEnabled=false;
			  gasId=false;
			  genId=false;
			  steamId=false;
			  projectIdName="";
			  showSysTable=true;
			  recordCount = systemList.size();
			  totalRecordAptMsgAddCntract="Total Number of Records Count :: "+recordCount;
			  LOG.info("Total Number of Records Count in getSystemNameAddHomePage method:: "+recordCount);
		   LOG.info("Exiting getSystemNameAddHomePage method");
			return fwdFlag;
			
		}
		/**
		 * This method is used to get contract information Report
		 * 
		 * @return String
		 * @throws PLMCommonException 
		 */
		/*public List<String> suggestionSystemNameSearch(Object theSearchCriteria) throws PWiException, PLMCommonException {
			String searchCriteria = (String)theSearchCriteria;
			if (searchCriteria != null && searchCriteria.length() > 0) {
				List<String> resultList = plmContractRptService.searchSystemNameTypeahead(
						PLMUtils.surroundWithWildcards(searchCriteria));
				return resultList;
			}
			return new ArrayList<String>(0);
			
		}*/
		
		/**
		 * This method is used to get System Name Information for Product Type
		 * 
		 * @param event
		 */
		public void fetchAssignSystemDataList(ActionEvent event){
			LOG.info("Entering fetchAssignSystemDataList method PLMContractRptMB");
			try{
				List<PLMContractSystemAsignData> systemListData = new ArrayList<PLMContractSystemAsignData>();
				 systemSelList = new ArrayList<SelectItem>();
				 systemListData = plmContractRptService.fetchAssignSystemDataList(selectedPrdctList);
				
				  for(PLMContractSystemAsignData sysData : systemListData)
				  {
					  systemSelList.add(new SelectItem(sysData.getSystemId(), sysData.getSystemName()));
				  }
				 
				 LOG.info("System Names DATA Size"+systemSelList.size());
			 }catch (Exception e) {
				e.printStackTrace();
			}	
			LOG.info("Exiting fetchAssignSystemDataList method PLMContractRptMB");
		}
		
		/**
		 * This method is used to get contract information Report
		 * 
		 * @return String
		 * @throws PLMCommonException 
		 */
		public List<PLMContractSystemAsignData> getSystemNames(String systemName) throws PLMCommonException
		{
			List<PLMContractSystemAsignData> sysList = plmContractRptService.searchSystemNames(
					PLMUtils.surroundWithWildcards(systemName));
			return sysList;
		}
		
		public void systemNameSearch() throws PWiException, PLMCommonException {
			systemList =  new ArrayList<PLMContractSystemAsignData>();
			systemList =  getSystemNames("");
				if (systemList.size() > 0) {
					LOG.info("userVOList.size() >>>>>>>>>>>>>>>>>>> "+systemList.size());
					totalRecordAptMsgAddCntract="Total Number of Records Count :: "+systemList.size();
					recordCount=PLMConstants.N_100;
					showSysTable = true;
				}
		
		}
		
		public void addSystemName() throws PWiException, PLMCommonException {
			LOG.info("System Name Old Value >>>>>>>>>>>>>>>>>>> "+systemNameOldHide+" System Name New Value >>>>>>>>>>>>>>>>>>> "+systemName);
			boolean sysUpdate ;
			if(PLMUtils.isEmpty(systemName) && PLMUtils.isEmpty(systemNameOldHide) && gasId==false && genId==false && steamId==false){
				alertCntRptMsg = PLMConstants.SEARCH_CRITERIA;
			}else if(gasId!=false && genId!=false){
				alertCntRptMsg="System Name can't be assigned to both";
			}else if(gasId!=false && steamId!=false){
				alertCntRptMsg="System Name can't be assigned to both";
			}else if(steamId!=false && genId!=false){
				alertCntRptMsg="System Name can't be assigned to both";
			}
			else if(PLMUtils.isEmpty(systemName) && !PLMUtils.isEmpty(systemNameOldHide) && (gasId!=false || genId!=false || steamId!=false)){
				sysUpdate = plmContractRptService.addSystemNames(systemNameOldHide,hdnSystmId,gasId,genId,steamId);
				if (sysUpdate) {
					alertCntRptMsg = "System Name: " +systemNameOldHide+" saved successfully";
					systemName="";
					systemNameOld="";
					systemNameOldHide="";
					gasId=false;
					genId=false;
					steamId=false;
					sysOldEnabled=false;
					hdnSystmId="";
					systemNameSearch();
				} else {
					showSysTable = false;
					alertCntRptMsg = PLMConstants.N0_RECORDS;
				}
			
			}else if (systemName != null && systemName.length() > 0 && (gasId!=false || genId!=false || steamId!=false)) {
				sysUpdate = plmContractRptService.addSystemNames(systemName,hdnSystmId,gasId,genId,steamId);
				if (sysUpdate) {
					alertCntRptMsg = "System Name: " +systemName+" saved successfully";
					systemName="";
					systemNameOld="";
					systemNameOldHide="";
					gasId=false;
					genId=false;
					steamId=false;
					sysOldEnabled=false;
					hdnSystmId="";
					systemNameSearch();
				} else {
					showSysTable = false;
					alertCntRptMsg = PLMConstants.N0_RECORDS;
				}
			} else {
				alertCntRptMsg = PLMConstants.SEARCH_CRITERIA;
			}
		
		
		}
		
		public void deleteSystemName() throws PWiException, PLMCommonException {
			boolean sysUpdate ;
			if (hdnSystmId != null && hdnSystmId.length() > 0) {
				sysUpdate = plmContractRptService.deleteSystemName(hdnSystmId);
				if (sysUpdate) {
					alertCntRptMsg ="System Name: " +systemNameOldHide+" and the mapping details are deleted successfully";
					systemName="";
					systemNameOld="";
					systemNameOldHide="";
					sysOldEnabled=false;
					hdnSystmId="";
					gasId=false;
					genId=false;
					steamId=false;
					systemNameSearch();
				} else {
					showSysTable = false;
					alertCntRptMsg = PLMConstants.N0_RECORDS;
				}
			} else {
				alertCntRptMsg = PLMConstants.SEARCH_CRITERIA;
			}		
		}
		
		public void resetSystemName() throws PWiException, PLMCommonException {
			
			systemName="";
			systemNameOld="";
			systemNameOldHide="";
			hdnSystmId="";
			alertCntRptMsg="";
			gasId=false;
			genId=false;
			steamId=false;
		}
		
		/**
		 * This method is used to load home page of assign System Info Home page 
		 * 
		 * @return String
		 * @throws PLMCommonException 
		 */
		public String getSystemNameAssignHomePage() throws PLMCommonException {
			LOG.info("Entering getSystemNameAddHomePage method");
			
			try {
				commonMB.insertCannedRptRecordHitInfo("Assign System Name");
				
			} catch (PLMCommonException ex) {
				LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
			}
			selectedSysNameList=new ArrayList<String>();
			 selectedPrdctList=new ArrayList<String>();
			String fwdFlag="assignSystemMapping";
			  systemSelList = new ArrayList<SelectItem>();
			  prdctSelList = new ArrayList<SelectItem>();
			  prdctSelList.add(new SelectItem("Gas","Gas"));
			  prdctSelList.add(new SelectItem("Steam","Steam"));
			  prdctSelList.add(new SelectItem("Gen","Gen"));
			  prdctSelList.add(new SelectItem("PLANT","PLANT"));
			  
			  sysAssigned = true;
			  sysUnAssigned = true;
			  alertCntRptMapMsg = "";
			  showAssignSysTable=false;
			  showAssignSysTableRec=false;
		   LOG.info("Exiting getSystemNameAddHomePage method");
			return fwdFlag;
			
		}
		
		/**
		 * This method is used to load home page of assign System Info Home page 
		 * 
		 * @return String
		 * @throws PLMCommonException 
		 */
		public void getSystemOptionMapping() throws PLMCommonException {
			LOG.info("Entering getSystemOptionMapping method");
			systemList =  new ArrayList<PLMContractSystemAsignData>();
			PLMContractSystemAsignData assignData = new PLMContractSystemAsignData();
			 LOG.info("Exiting getSystemOptionMapping method"+sysAssigned+" "+sysUnAssigned+" "+selectedSysNameList.size()+selectedPrdctList.size());
			try {
				if(sysAssigned!=true && sysUnAssigned!=true && selectedSysNameList.size()==0 && selectedPrdctList.size()==0){
					alertCntRptMapMsg="Please Enter valid Search Criteria";
				}else{
					if(sysAssigned==true && sysUnAssigned!=true && selectedSysNameList.size()==0 && selectedPrdctList.size()==0){
						systemList =  getSystemNames("%");
					}else if(sysAssigned==true && sysUnAssigned!=true && selectedSysNameList.size()==0 && selectedPrdctList.size()>0){
						systemList =  plmContractRptService.fetchAssignSystemDataList(selectedPrdctList);
					}else if(sysAssigned==true && sysUnAssigned!=true && selectedSysNameList.size()>0){
						for(String system:selectedSysNameList){
						for(SelectItem item:systemSelList ){
							PLMContractSystemAsignData sysName = new PLMContractSystemAsignData();
							if(item.getValue().equals(system)){
								sysName.setSystemId(item.getValue().toString());
							}
							systemList.add(sysName);
						}
						}
						
					}
				assignData.setSysAssigned(sysAssigned);
				assignData.setSysUnAssigned(sysUnAssigned);
				assignData.setSelSysNameList(selectedSysNameList);
				assignData.setSelectedPrdctList(selectedPrdctList);
				for(PLMContractSystemAsignData sysName : systemList)
				{
					assignData.getSysNameList().add(sysName.getSystemId());
				}
	
				aasignSystemList = plmContractRptService.searchAssignSystems(assignData); 
				totalRecordAptMsg = "Total Number of Records Count :: "+aasignSystemList.size();
				LOG.info("Total no. of records for aasignSystemList"+aasignSystemList.size());
				showAssignSysTable=true;
				showAssignSysTableRec=true;
				alertCntRptMapMsg="";
			    recordCount = aasignSystemList.size();
			}
			   LOG.info("Exiting getSystemOptionMapping method");
			} catch (PLMCommonException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			  
			
		}
		public void resetSystemOptionMapping(){
			totalRecordAptMsg="";
			 sysAssigned = true;
			  sysUnAssigned = true;
			  alertCntRptMapMsg = "";
			 showAssignSysTable=false;
			 showAssignSysTableRec=false;
			 selectedSysNameList=new ArrayList<String>();
			 selectedPrdctList=new ArrayList<String>();
			 systemSelList= new ArrayList<SelectItem>();
		}
		/**
		 * This method is used to load home page of assign System Info Home page 
		 * 
		 * @return String
		 * @throws PLMCommonException 
		 */
		public String getAssignOptionData() throws PLMCommonException {
			
			LOG.info("Entering getAssignOptionData method");
						
			try {
				if(selectedSysNameList.size()==0){
					List<PLMContractSystemAsignData> systemListData = new ArrayList<PLMContractSystemAsignData>();
					 systemSelList = new ArrayList<SelectItem>();
					 List<String> allPrd=new ArrayList<String>();
					 allPrd.add("Gas");
					 allPrd.add("Gen");
					 allPrd.add("Steam");
					 allPrd.add("PLANT");
					 systemListData = plmContractRptService.fetchAssignSystemDataList(allPrd);
					
					  for(PLMContractSystemAsignData sysData : systemListData)
					  {
						  systemSelList.add(new SelectItem(sysData.getSystemId(), sysData.getSystemName()));
					  }
				}
				popUpOptionMapList = plmContractRptService.getAssignOptionData(hdnSelectedOption);
				alertCntRptMapMsg = "";
			} catch (PLMCommonException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		   LOG.info("Exiting getAssignOptionData method");
		   
		   return "assignSystemMappingDtls";
			
		}
		 
		 public void assignSystemMapping() throws PLMCommonException {
				
				LOG.info("Entering getAssignOptionData method");
				String isSuccess = "";
				String assignSystem="assignSystemMapping";
				try {
					isSuccess = plmContractRptService.assignSystemMapping(popUpOptionMapList,assignSystem);
				} catch (PLMCommonException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				if("true".equalsIgnoreCase(isSuccess))
				{
					alertCntRptMapMsg = "System has been assigned successfully";
				}

			   LOG.info("Exiting getAssignOptionData method");
				
			}
		 public void assignToSiblingMapping() throws PLMCommonException {
				
				LOG.info("Entering assignToSiblingMapping method");
				String isSuccess = "";
				String siblings="";
				String assignSystem="assignToSiblingMapping";
				try {
					isSuccess = plmContractRptService.assignSystemMapping(popUpOptionMapList,assignSystem);
				} catch (PLMCommonException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				if(isSuccess!="" || isSuccess!=null)
				{
					if(isSuccess.length()>4){
						siblings="to ".concat(isSuccess.substring(isSuccess.lastIndexOf("|")+1,isSuccess.length()));
					}else{
						siblings=".";
					}
					
					alertCntRptMapMsg = "System has been assigned successfully "+siblings;
				}

			   LOG.info("Exiting assignToSiblingMapping method");
				
			}
		 
		 
		 public String backAssignSystemMapping() throws PLMCommonException {
			 List<PLMContractSystemAsignData> systemListData = new ArrayList<PLMContractSystemAsignData>();
			 systemSelList = new ArrayList<SelectItem>();
			 
			 if(selectedPrdctList.size()==0){
				 systemSelList=new ArrayList<SelectItem>();
			 }else{
				 systemListData = plmContractRptService.fetchAssignSystemDataList(selectedPrdctList);
					
				  for(PLMContractSystemAsignData sysData : systemListData)
				  {
					  systemSelList.add(new SelectItem(sysData.getSystemId(), sysData.getSystemName()));
				  }
			 }
				
			return "assignSystemMapping";
			}
	
	/**
	 * @return the plmContractRptService
	 */
	public PLMContractRptServiceIfc getPlmContractRptService() {
		return plmContractRptService;
	}
	/**
	 * @param plmContractRptService the plmContractRptService to set
	 */
	public void setPlmContractRptService(
			PLMContractRptServiceIfc plmContractRptService) {
		this.plmContractRptService = plmContractRptService;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the contractNum
	 */
	public String getContractNum() {
		return contractNum;
	}
	/**
	 * @param contractNum the contractNum to set
	 */
	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}
	/**
	 * @return the alertCntRptMsg
	 */
	public String getAlertCntRptMsg() {
		return alertCntRptMsg;
	}
	/**
	 * @param alertCntRptMsg the alertCntRptMsg to set
	 */
	public void setAlertCntRptMsg(String alertCntRptMsg) {
		this.alertCntRptMsg = alertCntRptMsg;
	}


	/**
	 * @return the cntrctList
	 */
	public List<PLMContractRptData> getCntrctList() {
		return cntrctList;
	}


	/**
	 * @param cntrctList the cntrctList to set
	 */
	public void setCntrctList(List<PLMContractRptData> cntrctList) {
		this.cntrctList = cntrctList;
	}



	/**
	 * @return the contractInfoRptMap
	 */
	public Map<String, List<PLMContractRptData>> getContractInfoRptMap() {
		return contractInfoRptMap;
	}



	/**
	 * @param contractInfoRptMap the contractInfoRptMap to set
	 */
	public void setContractInfoRptMap(
			Map<String, List<PLMContractRptData>> contractInfoRptMap) {
		this.contractInfoRptMap = contractInfoRptMap;
	}



	/**
	 * @return the mlMplList
	 */
	public List<PLMContractRptData> getMlMplList() {
		return mlMplList;
	}



	/**
	 * @param mlMplList the mlMplList to set
	 */
	public void setMlMplList(List<PLMContractRptData> mlMplList) {
		this.mlMplList = mlMplList;
	}



	/**
	 * @return the projectInfoList
	 */
	public List<PLMContractRptData> getProjectInfoList() {
		return projectInfoList;
	}



	/**
	 * @param projectInfoList the projectInfoList to set
	 */
	public void setProjectInfoList(List<PLMContractRptData> projectInfoList) {
		this.projectInfoList = projectInfoList;
	}



	/**
	 * @return the productList
	 */
	public List<PLMContractRptData> getProductList() {
		return productList;
	}



	/**
	 * @param productList the productList to set
	 */
	public void setProductList(List<PLMContractRptData> productList) {
		this.productList = productList;
	}



	/**
	 * @return the prsList
	 */
	public List<PLMContractRptData> getPrsList() {
		return prsList;
	}



	/**
	 * @param prsList the prsList to set
	 */
	public void setPrsList(List<PLMContractRptData> prsList) {
		this.prsList = prsList;
	}



	/**
	 * @return the crsList
	 */
	public List<PLMContractRptData> getCrsList() {
		return crsList;
	}



	/**
	 * @param crsList the crsList to set
	 */
	public void setCrsList(List<PLMContractRptData> crsList) {
		this.crsList = crsList;
	}



	/**
	 * @return the mlmplFlag
	 */
	public boolean isMlmplFlag() {
		return mlmplFlag;
	}



	/**
	 * @param mlmplFlag the mlmplFlag to set
	 */
	public void setMlmplFlag(boolean mlmplFlag) {
		this.mlmplFlag = mlmplFlag;
	}



	/**
	 * @return the projectFlag
	 */
	public boolean isProjectFlag() {
		return projectFlag;
	}



	/**
	 * @param projectFlag the projectFlag to set
	 */
	public void setProjectFlag(boolean projectFlag) {
		this.projectFlag = projectFlag;
	}



	/**
	 * @return the productFlag
	 */
	public boolean isProductFlag() {
		return productFlag;
	}



	/**
	 * @param productFlag the productFlag to set
	 */
	public void setProductFlag(boolean productFlag) {
		this.productFlag = productFlag;
	}



	/**
	 * @return the prsFlag
	 */
	public boolean isPrsFlag() {
		return prsFlag;
	}



	/**
	 * @param prsFlag the prsFlag to set
	 */
	public void setPrsFlag(boolean prsFlag) {
		this.prsFlag = prsFlag;
	}



	/**
	 * @return the crsFlag
	 */
	public boolean isCrsFlag() {
		return crsFlag;
	}



	/**
	 * @param crsFlag the crsFlag to set
	 */
	public void setCrsFlag(boolean crsFlag) {
		this.crsFlag = crsFlag;
	}

	/**
	 * @return the projectIdName
	 */
	public String getProjectIdName() {
		return projectIdName;
	}

	/**
	 * @param projectIdNm the projectIdName to set
	 */
	public void setProjectIdName(String projectIdName) {
		this.projectIdName = projectIdName;
	}

	/**
	 * @return the selectRadio
	 */
	public String getSelectRadio() {
		return selectRadio;
	}

	/**
	 * @param selectRadio the selectRadio to set
	 */
	public void setSelectRadio(String selectRadio) {
		this.selectRadio = selectRadio;
	}

	/**
	 * @return the projectId
	 */
	public String getProjectId() {
		return projectId;
	}

	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	/**
	 * @return the workSpaceId
	 */
	public String getWorkSpaceId() {
		return workSpaceId;
	}

	/**
	 * @param workSpaceId the workSpaceId to set
	 */
	public void setWorkSpaceId(String workSpaceId) {
		this.workSpaceId = workSpaceId;
	}

	/**
	 * @return the projectNm
	 */
	public String getProjectNm() {
		return projectNm;
	}

	/**
	 * @param projectNm the projectNm to set
	 */
	public void setProjectNm(String projectNm) {
		this.projectNm = projectNm;
	}

	/**
	 * @return the alertProjInfMsg
	 */
	public String getAlertProjInfMsg() {
		return alertProjInfMsg;
	}

	/**
	 * @param alertProjInfMsg the alertProjInfMsg to set
	 */
	public void setAlertProjInfMsg(String alertProjInfMsg) {
		this.alertProjInfMsg = alertProjInfMsg;
	}

	/**
	 * @return the projectList
	 */
	public List<PLMContractRptData> getProjectList() {
		return projectList;
	}

	/**
	 * @param projectList the projectList to set
	 */
	public void setProjectList(List<PLMContractRptData> projectList) {
		this.projectList = projectList;
	}

	/**
	 * @return the projectInfoRptMap
	 */
	public Map<String, List<PLMContractRptData>> getProjectInfoRptMap() {
		return projectInfoRptMap;
	}

	/**
	 * @param projectInfoRptMap the projectInfoRptMap to set
	 */
	public void setProjectInfoRptMap(
			Map<String, List<PLMContractRptData>> projectInfoRptMap) {
		this.projectInfoRptMap = projectInfoRptMap;
	}

	/**
	 * @return the prjmlMplList
	 */
	public List<PLMContractRptData> getPrjmlMplList() {
		return prjmlMplList;
	}

	/**
	 * @param prjmlMplList the prjmlMplList to set
	 */
	public void setPrjmlMplList(List<PLMContractRptData> prjmlMplList) {
		this.prjmlMplList = prjmlMplList;
	}

	/**
	 * @return the prjprojectInfoList
	 */
	public List<PLMContractRptData> getPrjprojectInfoList() {
		return prjprojectInfoList;
	}

	/**
	 * @param prjprojectInfoList the prjprojectInfoList to set
	 */
	public void setPrjprojectInfoList(List<PLMContractRptData> prjprojectInfoList) {
		this.prjprojectInfoList = prjprojectInfoList;
	}

	/**
	 * @return the prjproductList
	 */
	public List<PLMContractRptData> getPrjproductList() {
		return prjproductList;
	}

	/**
	 * @param prjproductList the prjproductList to set
	 */
	public void setPrjproductList(List<PLMContractRptData> prjproductList) {
		this.prjproductList = prjproductList;
	}

	/**
	 * @return the prjprsList
	 */
	public List<PLMContractRptData> getPrjprsList() {
		return prjprsList;
	}

	/**
	 * @param prjprsList the prjprsList to set
	 */
	public void setPrjprsList(List<PLMContractRptData> prjprsList) {
		this.prjprsList = prjprsList;
	}

	/**
	 * @return the prjcrsList
	 */
	public List<PLMContractRptData> getPrjcrsList() {
		return prjcrsList;
	}

	/**
	 * @param prjcrsList the prjcrsList to set
	 */
	public void setPrjcrsList(List<PLMContractRptData> prjcrsList) {
		this.prjcrsList = prjcrsList;
	}

	/**
	 * @return the prjmlmplFlag
	 */
	public boolean isPrjmlmplFlag() {
		return prjmlmplFlag;
	}

	/**
	 * @param prjmlmplFlag the prjmlmplFlag to set
	 */
	public void setPrjmlmplFlag(boolean prjmlmplFlag) {
		this.prjmlmplFlag = prjmlmplFlag;
	}

	/**
	 * @return the prjprojectFlag
	 */
	public boolean isPrjprojectFlag() {
		return prjprojectFlag;
	}

	/**
	 * @param prjprojectFlag the prjprojectFlag to set
	 */
	public void setPrjprojectFlag(boolean prjprojectFlag) {
		this.prjprojectFlag = prjprojectFlag;
	}

	/**
	 * @return the prjproductFlag
	 */
	public boolean isPrjproductFlag() {
		return prjproductFlag;
	}

	/**
	 * @param prjproductFlag the prjproductFlag to set
	 */
	public void setPrjproductFlag(boolean prjproductFlag) {
		this.prjproductFlag = prjproductFlag;
	}

	/**
	 * @return the prjprsFlag
	 */
	public boolean isPrjprsFlag() {
		return prjprsFlag;
	}

	/**
	 * @param prjprsFlag the prjprsFlag to set
	 */
	public void setPrjprsFlag(boolean prjprsFlag) {
		this.prjprsFlag = prjprsFlag;
	}

	/**
	 * @return the prjcrsFlag
	 */
	public boolean isPrjcrsFlag() {
		return prjcrsFlag;
	}

	/**
	 * @param prjcrsFlag the prjcrsFlag to set
	 */
	public void setPrjcrsFlag(boolean prjcrsFlag) {
		this.prjcrsFlag = prjcrsFlag;
	}

	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return the prjprojectIdName
	 */
	public String getPrjprojectIdName() {
		return prjprojectIdName;
	}

	/**
	 * @param prjprojectIdName the prjprojectIdName to set
	 */
	public void setPrjprojectIdName(String prjprojectIdName) {
		this.prjprojectIdName = prjprojectIdName;
	}

	/**
	 * @return the prjselectRadio
	 */
	public String getPrjselectRadio() {
		return prjselectRadio;
	}

	/**
	 * @param prjselectRadio the prjselectRadio to set
	 */
	public void setPrjselectRadio(String prjselectRadio) {
		this.prjselectRadio = prjselectRadio;
	}

	/**
	 * @return the prjprojectId
	 */
	public String getPrjprojectId() {
		return prjprojectId;
	}

	/**
	 * @param prjprojectId the prjprojectId to set
	 */
	public void setPrjprojectId(String prjprojectId) {
		this.prjprojectId = prjprojectId;
	}

	/**
	 * @return the prjprojectName
	 */
	public String getPrjprojectName() {
		return prjprojectName;
	}

	/**
	 * @param prjprojectName the prjprojectName to set
	 */
	public void setPrjprojectName(String prjprojectName) {
		this.prjprojectName = prjprojectName;
	}

	/**
	 * @return the prjworkSpaceId
	 */
	public String getPrjworkSpaceId() {
		return prjworkSpaceId;
	}

	/**
	 * @param prjworkSpaceId the prjworkSpaceId to set
	 */
	public void setPrjworkSpaceId(String prjworkSpaceId) {
		this.prjworkSpaceId = prjworkSpaceId;
	}

	public String getSystemName() {
		return systemName;
	}

	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}

	 
	 public List<PLMContractSystemAsignData> getSystemList() {
		return systemList;
	}

	public void setSystemList(List<PLMContractSystemAsignData> systemList) {
		this.systemList = systemList;
	}

	 public boolean isShowSysTable() {
			return showSysTable;
	}

	public void setShowSysTable(boolean showSysTable) {
			this.showSysTable = showSysTable;
	}

	public int getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	public List<PLMContractSystemAsignData> getAasignSystemList() {
		return aasignSystemList;
	}

	public void setAasignSystemList(
			List<PLMContractSystemAsignData> aasignSystemList) {
		this.aasignSystemList = aasignSystemList;
	}

	public boolean isShowAssignSysTableRec() {
		return showAssignSysTableRec;
	}

	public void setShowAssignSysTableRec(boolean showAssignSysTableRec) {
		this.showAssignSysTableRec = showAssignSysTableRec;
	}

	public boolean isShowAssignSysTable() {
		return showAssignSysTable;
	}

	public void setShowAssignSysTable(boolean showAssignSysTable) {
		this.showAssignSysTable = showAssignSysTable;
	}

	public List<String> getSelSysNames() {
		return selSysNames;
	}

	public void setSelSysNames(List<String> selSysNames) {
		this.selSysNames = selSysNames;
	}
	
	public String getHdnSystmId() {
		return hdnSystmId;
	}

	public void setHdnSystmId(String hdnSystmId) {
		this.hdnSystmId = hdnSystmId;
	}

	public List<SelectItem> getSystemSelList() {
		return systemSelList;
	}

	public void setSystemSelList(List<SelectItem> systemSelList) {
		this.systemSelList = systemSelList;
	}

	public List<String> getSelectedSysNameList() {
		return selectedSysNameList;
	}

	public void setSelectedSysNameList(List<String> selectedSysNameList) {
		this.selectedSysNameList = selectedSysNameList;
	}

	public List<SelectItem> getPrdctSelList() {
		return prdctSelList;
	}

	public void setPrdctSelList(List<SelectItem> prdctSelList) {
		this.prdctSelList = prdctSelList;
	}

	public List<String> getSelectedPrdctList() {
		return selectedPrdctList;
	}

	public void setSelectedPrdctList(List<String> selectedPrdctList) {
		this.selectedPrdctList = selectedPrdctList;
	}

	public boolean isSysUnAssigned() {
		return sysUnAssigned;
	}

	public void setSysUnAssigned(boolean sysUnAssigned) {
		this.sysUnAssigned = sysUnAssigned;
	}

	public boolean isSysAssigned() {
		return sysAssigned;
	}

	public void setSysAssigned(boolean sysAssigned) {
		this.sysAssigned = sysAssigned;
	}

	public String getHdnSelectedOption() {
		return hdnSelectedOption;
	}

	public void setHdnSelectedOption(String hdnSelectedOption) {
		this.hdnSelectedOption = hdnSelectedOption;
	}

	public PLMContractSystemAsignData getOptionSystemMapData() {
		return optionSystemMapData;
	}

	public void setOptionSystemMapData(
			PLMContractSystemAsignData optionSystemMapData) {
		this.optionSystemMapData = optionSystemMapData;
	}

	public List<PLMContractSystemAsignData> getPopUpOptionMapList() {
		return popUpOptionMapList;
	}

	public void setPopUpOptionMapList(
			List<PLMContractSystemAsignData> popUpOptionMapList) {
		this.popUpOptionMapList = popUpOptionMapList;
	}
	
	public String getAlertCntRptMapMsg() {
		return alertCntRptMapMsg;
	}

	public void setAlertCntRptMapMsg(String alertCntRptMapMsg) {
		this.alertCntRptMapMsg = alertCntRptMapMsg;
	}

	public String getSystemNameOld() {
		return systemNameOld;
	}

	public void setSystemNameOld(String systemNameOld) {
		this.systemNameOld = systemNameOld;
	}
	public String getSystemNameOldHide() {
		return systemNameOldHide;
	}

	public void setSystemNameOldHide(String systemNameOldHide) {
		this.systemNameOldHide = systemNameOldHide;
	}

	public boolean isSysOldEnabled() {
		return sysOldEnabled;
	}

	public void setSysOldEnabled(boolean sysOldEnabled) {
		this.sysOldEnabled = sysOldEnabled;
	}

	public String getTotalRecordAptMsg() {
		return totalRecordAptMsg;
	}

	public void setTotalRecordAptMsg(String totalRecordAptMsg) {
		this.totalRecordAptMsg = totalRecordAptMsg;
	}
	public String getTotalRecordAptMsgAddCntract() {
		return totalRecordAptMsgAddCntract;
	}

	public void setTotalRecordAptMsgAddCntract(String totalRecordAptMsgAddCntract) {
		this.totalRecordAptMsgAddCntract = totalRecordAptMsgAddCntract;
	}
	
	
}
