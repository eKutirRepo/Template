/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMPercentPartMB.java
 * @Creation date: 15-June-2011
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMPercentPartData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMMetricsServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

/**
 * PLMPercentPartMB is the managed bean class for PartPercentReuse.
 */

public class PLMPercentPartMB {
	
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMPercentPartMB.class);
	
	private ThreadPoolTaskExecutor taskExecutor =null;
	
	ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the Service  
	 */
	private PLMMetricsServiceIfc plmMetricsService = null;
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB=null;
	
	/**
	 * Holds the total records fetched for given search criteria.
	 */
	private int totalRecCount;
	
	/**
	 * Holds the ML/MPL Number.
	 */
	private String mlNumber = "";
	/**
	 * Holds the pprRadioValue
	 */
	private String pprRadioValue = "GAS";	
	
	/**
	 * Holds the ship Date to be displayed in report page header.
	 */
	private List<PLMPercentPartData> searchResultList = new ArrayList<PLMPercentPartData>();
	/**
	 * Holds the messages to be displayed.
	 */
	private String alertMessage;
	
	/**
	 * Holds the MFG Complete Date table Header
	 */
	private String mfgDateHeader;
	
	/**
	 * Holds the Today Date table Header
	 */
	private String todayDateHeader;
	
	/**
	 * Holds user details
	 */
	private PLMPwiUserData userDetails;
	/**
	 * This method is used to display Percent Part Reuse report based on given ML/MPL Number.
	 */
	
	PLMPercentPartData plmPercentPartData = new PLMPercentPartData();
	
	public PLMPercentPartMB() {
		 
		try {
			userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		} catch (PWiException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Sending Mail Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			LOG.info("Entering into Thread");
			sendReportThroughMail();
			LOG.info("Exiting from Thread");
		}
	}
	
	/**
	 * This method is used to getPercentReuseData
	 * 
	 * @return boolean
	 */
	public String getPercentReuseData() {
		LOG.info("Entering getPercentReuseData method");
		LOG.info("mlNumber : " + mlNumber + " " + "Radio selection Value : " + pprRadioValue);
		boolean continueFlag = false;
		String fwdFlag = "percentpartsearch";
		try {
			continueFlag = validateSearchParams();
			if (continueFlag) {
				searchResultList = plmMetricsService.getPercentReuseDataFromDB(mlNumber,pprRadioValue);
				LOG.info("Result Size : " + searchResultList.size());
				if (PLMUtils.isEmptyList(searchResultList)) {
					fwdFlag = "invalidpercentpartsearch";
				} else {
					totalRecCount = searchResultList.size();
					mfgDateHeader = searchResultList.get(0).getMfgDateHeader();
					todayDateHeader = searchResultList.get(0).getTodayDateHeader();
					fwdFlag = "percentpartreport";
				}
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPercentReuseData: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"percentpartsearch","Percent Part Re-use Report");
		} 
		return fwdFlag;
	}
	
	/**
	 * This method is used to check validation .
	 * 
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean validateSearchParams() throws PLMCommonException {
		LOG.info("Entering into validateSearchParams Method");
		boolean isValidated = true;
		mlNumber = mlNumber.toUpperCase(Locale.US);
		LOG.info("Ml Number : " + mlNumber);
		if (PLMUtils.isEmpty(mlNumber)) {
			LOG.info("in validate if");
			alertMessage = PLMConstants.INVALID_MLMPL_NUM;
			isValidated = false;
		} else if (!mlNumber.matches("[a-zA-Z0-9/-]*")) {
			alertMessage = PLMConstants.MLMPL_NUM_SPL_CHARS;
			isValidated = false;
		} else if (!(mlNumber.contains("ML") || mlNumber.contains("MPL"))){
			alertMessage = PLMConstants.INVALID_MLMPL_NUM;
			isValidated = false;
		} 
		return isValidated;
	}
	
	/**
	 * This method is used to load the percentPartReuse page.
	 * 
	 * @return String
	 */
	public String loadPercentPart() {
		String fwdflag = "percentpartsearch";
		try {
			commonMB.insertCannedRptRecordHitInfo("Percent Part Re-use Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		resetData();
		try {			
		commonMB.getLegacyDateStamp();
	
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getLegacyDateStamp: ", exception);
		} 
		return fwdflag;
	}
	
	/**
	 * This method is used for setBorderStyle
	 * 
	 * @param style
	 * @return HSSFCellStyle
	 */
	private HSSFCellStyle setBorderStyle(HSSFCellStyle style) {
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		return style;
	}
	
	/**
	 * Generates the Percent Part Search List and sends a mail to the logged in user.
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getPercentReuseMailData() throws PLMCommonException {
		LOG.info("Entering into getPercentReuseMailData method");
		boolean alertMsg = validateSearchParams();
		if ((alertMsg)) {
			alertMessage = alertMessage + PLMConstants.Embom_Mail_Msg;
			taskExecutor.execute(new MailThread());
		}
		LOG.info("Exiting from getPercentReuseMailData method");
		return "percentpartsearch";
	}
	/**
	 * sendReportThroughMail
	 * 
	 */
	public void sendReportThroughMail(){
		LOG.info("Entering into sendReportThroughMail method");
		String timeStamp = null;
		String successMsg = "";
		String mlNum = mlNumber;
		String from = PLMConstants.WHERE_USED_MAIL_FROM;
		
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.PERCENT_PART_MAIL_SUBJECT + mlNum;
		String mailContent = toAddressee + PLMConstants.PERCENT_PART_MAIL_CONTENT + mlNum + "." + PLMConstants.WHERE_USED_LOU_MAIL_SIGNATURE;
		String filePathXLS = "";
		String signature = PLMConstants.WHERE_USED_LOU_MAIL_SIGNATURE;
		LOG.info("mlNumber : " + mlNum + " " + "Radio selection Value : " + pprRadioValue);
		try {
			timeStamp = PLMUtils.volTableFormatDate();
			filePathXLS = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("PERCENT_PART_REPORT_NAME") + " " + mlNum +  "_" + timeStamp + ".xls";
			searchResultList = plmMetricsService.getPercentReuseDataFromDB(mlNum,pprRadioValue);
			savePercentPartExcelFile(mlNum,filePathXLS);
			PLMUtils.sendMailWithAttachment(from, to, subject, mailContent, filePathXLS);	
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,signature);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,signature);
		}finally {
			deleteFiles(filePathXLS);
		}   
		if(PLMUtils.isEmpty(successMsg)){
			LOG.info("Mail sent successfully");
		}
	}
	
	
	/**
	 * This method is used for Deleting xls file
	 * 
	 * @param filePathXls
	 * @return void
	 */
	public void deleteFiles(String filePathXls){
		LOG.info("Entering deleteFiles method");
		boolean xlsFileExist;
		File xlsFile = new File(filePathXls);
		xlsFileExist = xlsFile.exists();
		if(xlsFileExist){
			boolean deleted = xlsFile.delete();
			LOG.info("Successfully deleted xls file : " + deleted);
		}
		LOG.info("Exiting deleteFiles Method");
	}
	
	
	/**
	 * This method is used for savePercentPartExcelFile
	 * 
	 * @param mlNum,filePathXls
	 * @throws Exception
	 */
	public void savePercentPartExcelFile(String mlNum, String filePathXLS) throws Exception {
	//String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
	FileOutputStream fileOut = null;
	boolean createFileExist;
	try {
		/*File file = new File(fileDir);
		boolean dirExists = file.exists();
		if (!dirExists) {	
			file.mkdir();
		}*/
		File fileName = new File(filePathXLS);
		boolean fileExist = fileName.exists();
		if(!fileExist) {
			createFileExist =fileName.createNewFile();
			LOG.info("createFileExist>>>>.."+createFileExist);
	 	}
		if (fileName.exists()) {
			fileOut = new FileOutputStream(filePathXLS);
			HSSFWorkbook workbook = new HSSFWorkbook();
			HSSFSheet sheet =  workbook.createSheet(mlNum);
			HSSFCellStyle headerStyle = workbook.createCellStyle();
			
			headerStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
			headerStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			headerStyle.setFillForegroundColor(HSSFColor.YELLOW.index);
			headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			HSSFFont font = workbook.createFont(); 
			font.setFontName("GE Inspira");
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			headerStyle.setFont(font);
			headerStyle = setBorderStyle(headerStyle);
			
			HSSFCellStyle cellBoldStyle = workbook.createCellStyle();
			cellBoldStyle = setBorderStyle(cellBoldStyle);
			cellBoldStyle.setFont(font);
			
			HSSFFont nonBoldFont = workbook.createFont();
			nonBoldFont.setFontName("GE Inspira");
			HSSFCellStyle contentStyle = workbook.createCellStyle();				
			contentStyle = setBorderStyle(contentStyle);
			contentStyle.setFont(nonBoldFont);
									
			HSSFFont noRecordFont = workbook.createFont(); 
			noRecordFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			noRecordFont.setColor(HSSFColor.RED.index);
			noRecordFont.setFontName("GE Inspira");
			HSSFCellStyle noRecordCellStyle = workbook.createCellStyle();
			noRecordCellStyle = setBorderStyle(noRecordCellStyle);
			noRecordCellStyle.setFont(noRecordFont);
			
			int rowcount = -1;
			
			LOG.info("SearchResultList Size : " + searchResultList.size());
			
			if(!PLMUtils.isEmptyList(searchResultList)) {
				String searchCriteria = "ML/MPL Number : ";
				String searchCriteriaValue = mlNum;
				mfgDateHeader = searchResultList.get(0).getMfgDateHeader();
				todayDateHeader = searchResultList.get(0).getTodayDateHeader();
				String[] colNames = {"Product Line", "ML/MPL Number", "Unit Serial Number", "Customer Name", "Site", mfgDateHeader, todayDateHeader };
				
				HSSFRow row = sheet.createRow(++rowcount);
				HSSFCell cell = row.createCell(0); 
				cell.setCellValue(searchCriteria);
				cell.setCellStyle(cellBoldStyle);

				HSSFCell cell1 = row.createCell(1);
				cell1.setCellValue(searchCriteriaValue);
				cell1.setCellStyle(cellBoldStyle);
				
				sheet.createRow(++rowcount);
				HSSFRow row1 = sheet.createRow(++rowcount);
				
				for ( int i = 0 ; i < colNames.length; i++ ) {
					HSSFCell cell2 = row1.createCell(i);
					cell2. setCellValue(colNames[i]);
					cell2.setCellStyle(headerStyle);
				}
				
				for(int i = 0; i < searchResultList.size(); i++) {
					PLMPercentPartData dataObj = (PLMPercentPartData) searchResultList.get(i);
						HSSFRow row2 = sheet.createRow(++rowcount);

						HSSFCell cell3 = row2.createCell(0);
						cell3.setCellStyle(contentStyle);
						cell3.setCellValue(dataObj.getProductLine());
						
						HSSFCell cell4 = row2.createCell(1);
						cell4.setCellStyle(contentStyle);
						cell4.setCellValue(dataObj.getTurbineNumber());
			
						HSSFCell cell5 = row2.createCell(2);
						cell5.setCellStyle(contentStyle);
						cell5.setCellValue(dataObj.getSerialNumber());
			
						HSSFCell cell6 = row2.createCell(3);
						cell6.setCellStyle(contentStyle);
						cell6.setCellValue(dataObj.getCustomerName());
			
						HSSFCell cell7 = row2.createCell(4);
						cell7.setCellStyle(contentStyle);
						cell7.setCellValue(dataObj.getSiteLoc());

						HSSFCell cell8 = row2.createCell(5);
						cell8.setCellStyle(contentStyle);
						cell8.setCellValue(dataObj.getMfgDatePercent());
						
						HSSFCell cell9 = row2.createCell(6);
						cell9.setCellStyle(contentStyle);
						cell9.setCellValue(dataObj.getTodayDatePercent());
						
				}
				
				sheet.createRow(++rowcount);
				sheet.createRow(++rowcount);
				
				sheet.autoSizeColumn(0);
				sheet.autoSizeColumn(1);
				sheet.autoSizeColumn(2);
				sheet.autoSizeColumn(3);
				sheet.autoSizeColumn(4);
				sheet.autoSizeColumn(5);
				sheet.autoSizeColumn(6);
			} else {
				LOG.info("There is no record found for "+mlNumber);
				HSSFRow row = sheet.createRow(++rowcount);
				HSSFCell cell = row.createCell(0); 
				String noRecordMsg = PLMConstants.PERCENT_PART_NO_RECORD_FOUND + mlNumber;	
				cell.setCellValue(noRecordMsg);
				cell.setCellStyle(noRecordCellStyle);
				sheet.autoSizeColumn(0);
			}	
			workbook.write(fileOut);
			fileOut.close();
		}
	} catch (FileNotFoundException e) {
		LOG.log(Level.ERROR, "Exception@savePercentPartExcelFile: ", e);
		throw e;
	} catch (IOException e) {
		LOG.log(Level.ERROR, "Exception@savePercentPartExcelFile: ", e);
		throw e;
	}  finally {
		try {
			if (fileOut != null) {
				fileOut.close();
			}
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@savePercentPartExcelFile: ", e);
			throw e;
		}
	}
}
	
	/**
	 * This method is used to download excel
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	
	public void downloadPercentPartReUseExcel() throws PLMCommonException {
		
		LOG.info("Entering downloadPercentPartReUseExcel Method");
		String reportName="percentpartreportDoc";
		String fileName="percentpartreport";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("productLine", "Product Line", FormatType.TEXT, null, null, 12),
                    new PLMXlsxRptColumn("turbineNumber", "ML/MPL Number", FormatType.TEXT, null, null, 17),
                    new PLMXlsxRptColumn("serialNumber", "Unit Serial Number", FormatType.TEXT, null, null, 18),
                    new PLMXlsxRptColumn("customerName", "Customer Name", FormatType.TEXT, null, null, 36),
                    new PLMXlsxRptColumn("siteLoc", "Site", FormatType.TEXT, null, null, 11),
                    new PLMXlsxRptColumn("mfgDatePercent", mfgDateHeader, FormatType.TEXT, null, null, 36),
                    new PLMXlsxRptColumn("todayDatePercent", todayDateHeader, FormatType.TEXT, null, null, 36)
			};

		PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] {
				new PLMXlsxRptColumn("mlNumber", "ML/MPL #:", FormatType.TEXT)
		};

		PLMPercentPartData plmPercentPartData_t = new PLMPercentPartData();
		plmPercentPartData_t.setMlNumber(mlNumber);
		
		excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, plmPercentPartData_t);
		
	}
	
	/**
	 * This method is used for Generating Report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadPercentPartReUseCSV() throws PLMCommonException {
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
				new PLMCsvRptColumn("productLine", "Product Line", FormatTypeCsv.TEXT, null, null, 12),
                new PLMCsvRptColumn("turbineNumber", "ML/MPL Number", FormatTypeCsv.TEXT, null, null, 17),
                new PLMCsvRptColumn("serialNumber", "Unit Serial Number", FormatTypeCsv.TEXT, null, null, 18),
                new PLMCsvRptColumn("customerName", "Customer Name", FormatTypeCsv.TEXT, null, null, 36),
                new PLMCsvRptColumn("siteLoc", "Site", FormatTypeCsv.TEXT, null, null, 11),
                new PLMCsvRptColumn("mfgDatePercent", mfgDateHeader, FormatTypeCsv.TEXT, null, null, 36),
                new PLMCsvRptColumn("todayDatePercent", todayDateHeader, FormatTypeCsv.TEXT, null, null, 36)
		};

		csvUtil.exportCsv(searchResultList, reportColumns, "percentpartreport", dateFormat, false, null, null, ",");
		
	}
	
	
	/**
	 * This method resets values.
	 */
	public String resetData() {
		String fwdflag = "percentpartsearch";
		mlNumber = null;
		pprRadioValue = "GAS";
		return fwdflag;
	}

	/**
	 * @return the plmMetricsService
	 */
	public PLMMetricsServiceIfc getPlmMetricsService() {
		return plmMetricsService;
	}

	/**
	 * @param plmMetricsService the plmMetricsService to set
	 */
	public void setPlmMetricsService(PLMMetricsServiceIfc plmMetricsService) {
		this.plmMetricsService = plmMetricsService;
	}
	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/**
	 * @return the mlNumber
	 */
	public String getMlNumber() {
		return mlNumber;
	}

	/**
	 * @param mlNumber the mlNumber to set
	 */
	public void setMlNumber(String mlNumber) {
		this.mlNumber = mlNumber;
	}

	/**
	 * @return the searchResultList
	 */
	public List<PLMPercentPartData> getSearchResultList() {
		return searchResultList;
	}

	/**
	 * @param searchResultList the searchResultList to set
	 */
	public void setSearchResultList(List<PLMPercentPartData> searchResultList) {
		this.searchResultList = searchResultList;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}

	/**
	 * @return the mfgDateHeader
	 */
	public String getMfgDateHeader() {
		return mfgDateHeader;
	}

	/**
	 * @param mfgDateHeader the mfgDateHeader to set
	 */
	public void setMfgDateHeader(String mfgDateHeader) {
		this.mfgDateHeader = mfgDateHeader;
	}

	/**
	 * @return the todayDateHeader
	 */
	public String getTodayDateHeader() {
		return todayDateHeader;
	}

	/**
	 * @param todayDateHeader the todayDateHeader to set
	 */
	public void setTodayDateHeader(String todayDateHeader) {
		this.todayDateHeader = todayDateHeader;
	}
	
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the plmPercentPartData
	 */
	
	public PLMPercentPartData getPlmPercentPartData() {
		return plmPercentPartData;
	}
	
	/**
	 * @param plmPercentPartData the plmPercentPartData to set
	 */
	public void setPlmPercentPartData(PLMPercentPartData plmPercentPartData) {
		this.plmPercentPartData = plmPercentPartData;
	}
	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the pprRadioValue
	 */
	public String getPprRadioValue() {
		return pprRadioValue;
	}

	/**
	 * @param pprRadioValue the pprRadioValue to set
	 */
	public void setPprRadioValue(String pprRadioValue) {
		this.pprRadioValue = pprRadioValue;
	}
}