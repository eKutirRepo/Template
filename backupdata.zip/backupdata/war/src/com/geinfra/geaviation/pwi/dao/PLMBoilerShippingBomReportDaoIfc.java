/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBoilerShippingBomReportDaoIfc.java
 * @Creation date: 21-Feb-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMBoilerShipBomReportData;
import com.geinfra.geaviation.pwi.data.PLMBoilerShopBomReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMBoilerShippingBomReportDaoIfc {

	/**
	 * This method is used to getProjectNameAndContractNameList
	 * @return Map<String, List<SelectItem>>
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getProjectNameAndContractNameList() throws PLMCommonException;
/**
 * fetchProjectList for contracts
 * @param selShipBomCntractName
 * @return
 * @throws PLMCommonException
 */
	public List<PLMBoilerShipBomReportData> fetchProjectList(String selShipBomCntractName) throws PLMCommonException;
/**
 * fetchTopLvlPartList for projects
 * @param selShipBomProjectName
 * @return
 * @throws PLMCommonException
 */
	public List<PLMBoilerShipBomReportData> fetchTasktList(List<String> selShipBomProjectName,List<SelectItem> projectList,boolean allOpenPrjName) throws PLMCommonException;
	/**
	 * this method for generateShippingBomAppReport
	 * @param selShipBomCntractName
	 * @param allOpenContractName
	 * @param selShipBomProjectName
	 * @param allOpenPrjName
	 * @param selShipBomTopLvlPartName
	 * @param allOpenTopLvlPart
	 * @param showDocRev
	 * @return
	 */
public List<PLMBoilerShipBomReportData> generateShippingBomAppReport(
		String selShipBomCntractName, boolean allOpenContractName,
		List<String> selShipBomProjectName, boolean allOpenPrjName,
		List<String> selShipBomTopLvlPartName, boolean allOpenTopLvlPart,List<SelectItem>projectList,List<SelectItem>taskList, boolean showDocRev)  
				throws PLMCommonException;

//Added for Customer BOM Report

/**
 * @param selContractNm
 * @param selProjectList
 * @param allOpenPrjName
 * @param selTaskName
 * @param allAssyNum
 * @param selPartAssmblyNumList
 * @param showPartRev
 * @param showDocRev
 * @return
 * @throws PLMCommonException
 */
public List<PLMBoilerShipBomReportData> getCustomerBOMRptData(
		String selContractNm,List<String> selProjectList, 
		boolean allOpenPrjName,String selTaskName, boolean allAssyNum, List<String> selPartAssmblyNumList,
		boolean showPartRev, boolean showDocRev) throws PLMCommonException;


//Added for Shop BOM

/**
 * @param selShipBomCntractName
 * @param allOpenContractName
 * @param selShipBomProjectName
 * @param allOpenPrjName
 * @param selShipBomTopLvlPartName
 * @param allOpenTopLvlPart
 * @param selShipBomParentAssyNo
 * @param allOpenParentAssy
 * @param showPartRev
 * @param showDocRev
 * @return
 * @throws PLMCommonException
 */
public List<PLMBoilerShopBomReportData> getShopBomHeaderSectionDataList(
	String selShipBomCntractName, boolean allOpenContractName,
	List<String> selShipBomProjectName, boolean allOpenPrjName,
	String selShipBomTopLvlPartName, boolean allOpenTopLvlPart,List<String> selShipBomParentAssyNo, boolean allOpenParentAssy,boolean showPartRev, boolean showDocRev)
	throws PLMCommonException;

/**
* 
* @param matlCodeList
* @return
*/
public List<PLMBoilerShopBomReportData> getShopBomMaterialSectionDataList(
	List<String> matlCodeList) throws PLMCommonException;


/**
 * This method is used to fetch Part Assembly Numbers
 * @param taskName
 * @return
 * @throws PLMCommonException
 */
public List<PLMBoilerShipBomReportData> fetchPartAssemblyNumList(String selContractNm,List<String> selProjectList, 
		boolean allOpenPrjName, String selTaskName) throws PLMCommonException;
public List<SelectItem> contractFamilyAutocomplete(String contract) throws PLMCommonException;

/**
 * @param selContractNm
 * @param selProjectList
 * @param allOpenPrjName
 * @param selTaskName
 * @param allAssyNum
 * @param selPartAssmblyNumList
 * @return
 * @throws PLMCommonException
 */
public List<PLMBoilerShipBomReportData> getHeaderData(
		String selContractNm,List<String> selProjectList, 
		boolean allOpenPrjName,String selTaskName, boolean allAssyNum, List<String> selPartAssmblyNumList) throws PLMCommonException;

/**
 * @param selContractNm
 * @param selProjectList
 * @param allOpenPrjName
 * @param selTaskName
 * @param allOpenTopLvlPart
 * @return
 * @throws PLMCommonException
 */
public List<PLMBoilerShipBomReportData> getShippingHeaderData(
		String selContractNm, List<String> selProjectList, 
		boolean allOpenPrjName,List<String> selTaskName, boolean allOpenTopLvlPart) throws PLMCommonException;
}
