/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMSoKitReportDaoImpl.java
 * @Creation date: 01-Jan-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMSoKitReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMSoKitReportDaoImpl extends SimpleJdbcDaoSupport implements PLMSoKitReportDaoIfc{
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger
	.getLogger(PLMSoKitReportDaoImpl.class);
	
	/**
	 * Holds the genSOKitRptDataList.
	 */
	private List<PLMSoKitReportData> tab1DataList;
	/**
	 * Holds the partDataList.
	 */
	private List<PLMSoKitReportData> tab2DataList;
	
	
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");

	/**
	 * This method is used to getGBOMData
	 * @return java.util.List
	 * @param varMap, hwPrdMap
	 * @throws PLMCommonException
	 */
	public Map<String,Object> getGenSOKitRptData(Map<String, Object> varMap) throws PLMCommonException,Exception{
		String timeStamp = null;
		String timeStampLoop = null;
		String SOB_VT1 = "SOB_VT1";
		String SOB_VT2 = "SOB_VT2";
		String SOB_VT3 = "SOB_VT3";
		String SOB_VT4 = "SOB_VT4";
		
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		//String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathErp = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("GENSOKIT_REPORT_NAME1") +  varMap.get("erpNum") + "_" + uniqTime + ".csv";
		String filePathEbom = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("GENSOKIT_REPORT_NAME2") +  varMap.get("erpNum") + "_" + uniqTime + ".csv";
		Map<String, Object> varMapCsv1 =new HashMap<String,Object>();
		Map<String, String> requiredParts=new HashMap<String,String>();
		List<String> requiredPartsNm=new ArrayList<String>();
		List<PLMSoKitReportData> currentPartDataList=new ArrayList<PLMSoKitReportData>();
		Map<String,List<PLMSoKitReportData>> varMapCsv2= new HashMap<String,List<PLMSoKitReportData>>();
		Map<String,Object> dataMap = new HashMap<String,Object>();
		FileOutputStream fileOut = null;
		PrintWriter pwriter =null;
		boolean createFileExist;
		int tab1DataLstCnt=0;
			try{
				 LOG.info("Inside getGenSOKitRptData() of DAO Impl");
			 String erpNum=(String)varMap.get("erpNum");
			 String inputRadio=(String)varMap.get("inputRadio");
			 
			 
			 LOG.info("ERP num in DAO Impl"+erpNum);
			 LOG.info("Input Radio in DAO Impl"+inputRadio);
			
			 StringBuffer searchResultsQry = new StringBuffer();
			 StringBuffer searchResultsQry1 = new StringBuffer();
			 StringBuffer vt3Query = new StringBuffer();
				
			 timeStamp = PLMUtils.volTableFormatDate();
				LOG.info("The timeStamp for the Report "+timeStamp);
				
				SOB_VT1 = SOB_VT1.concat(timeStamp);
				SOB_VT2 = SOB_VT2.concat(timeStamp);
				
				int vt2Count=0;
			 
			 if(inputRadio.endsWith("ePNorERPNumber")){
				 LOG.info("Input Radio is ePNorERPNumber");
					//VT1
					LOG.info("Query for Creating SOB_VT1 : "+PLMOfflineQueries.CREATE_SOB_VT1_ERP.replace("SOB_VT1", SOB_VT1)
							.replace("VAR_ERP", "'"+erpNum+"'"));
					getJdbcTemplate().execute(PLMOfflineQueries.CREATE_SOB_VT1_ERP.replace("SOB_VT1", SOB_VT1)
							.replace("VAR_ERP", "'"+erpNum+"'"));
					
					LOG.info("Query for Collect STATS SOB_VT1 : " + PLMOfflineQueries.COLLECT_STATS_SOB_VT1.replace("SOB_VT1", SOB_VT1));
					getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_SOB_VT1.replace("SOB_VT1", SOB_VT1));
					
					LOG.info("************VT1 DONE************");
					//VT2
					/*LOG.info("Query for Creating SOB_VT2 : "+PLMOfflineQueries.CREATE_SOB_VT2.replace("SOB_VT2", SOB_VT2)
							.replace("SOB_VT1", SOB_VT1));
					getJdbcTemplate().execute(PLMOfflineQueries.CREATE_SOB_VT2.replace("SOB_VT2", SOB_VT2)
							.replace("SOB_VT1", SOB_VT1));*/
					
			 }else{
				 LOG.info("Input Radio is AccordSalesOrderNumber");
					LOG.info("Query for Creating SOB_VT1 : "+PLMOfflineQueries.CREATE_SOB_VT1_SO.replace("SOB_VT1", SOB_VT1)
							.replace("VAR_SO", "'"+erpNum+"'"));
					getJdbcTemplate().execute(PLMOfflineQueries.CREATE_SOB_VT1_SO.replace("SOB_VT1", SOB_VT1)
							.replace("VAR_SO", "'"+erpNum+"'"));
					
					LOG.info("Query for Collect STATS SOB_VT1 : " + PLMOfflineQueries.COLLECT_STATS_SOB_VT1.replace("SOB_VT1", SOB_VT1));
					getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_SOB_VT1.replace("SOB_VT1", SOB_VT1));
					
					LOG.info("************VT1 DONE************");
					
			 }
			 LOG.info("Query for Creating SOB_VT2 : "+PLMOfflineQueries.CREATE_SOB1_VT2.replace("SOB_VT2", SOB_VT2)
					 .replace("SOB_VT1", SOB_VT1));
			 getJdbcTemplate().execute(PLMOfflineQueries.CREATE_SOB1_VT2.replace("SOB_VT2", SOB_VT2)
					 .replace("SOB_VT1", SOB_VT1));
			 LOG.info("Query for Collect STATS SOB_VT2 : " + PLMOfflineQueries.COLLECT_STATS_SOB_VT2.replace("SOB_VT2", SOB_VT2));
			 getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_SOB_VT2.replace("SOB_VT2", SOB_VT2));
			 
				searchResultsQry.append(PLMOfflineQueries.GET_TAB1_DATA);
				LOG.info("Executing query to fetch TAB1 details : "+searchResultsQry.toString().replace("SOB_VT1", SOB_VT1));
				tab1DataList = getSimpleJdbcTemplate().query(searchResultsQry.toString().replace("SOB_VT1", SOB_VT1), new GetTab1DataMapper());
				tab1DataLstCnt =tab1DataList.size();
				varMapCsv1.put("tab1DataList", tab1DataList);
				varMapCsv1.put("erpNum", erpNum);
				dataMap.put("tab1DataLstCnt", tab1DataLstCnt);
				// write tab1DataList data into CSV file
				if(tab1DataList.size() != 0){
					for(PLMSoKitReportData data : tab1DataList){
						requiredParts.put(data.getTab1PartName(),data.getTab1PartName() + " " + data.getTab1PartRev());
						requiredPartsNm.add(data.getTab1PartName());
					}
					LOG.info("Number of Parts Fetched for 2nd Tab==="+requiredPartsNm.size());
					LOG.info("Before writing CSV1 file............");
					writeCSV1Data(varMapCsv1,filePathErp);
					dataMap.put("filePathErp", filePathErp);
					LOG.info("After writing CSV1 file............");
				}
				
				
				LOG.info("Query for Count of SOB_VT2 : " + PLMOfflineQueries.SEL_CNT_SOB_VT2.replace("SOB_VT2", SOB_VT2));
				vt2Count= getJdbcTemplate().queryForInt(PLMOfflineQueries.SEL_CNT_SOB_VT2.replace("SOB_VT2", SOB_VT2));
			    LOG.info("SOB_VT2 Count "+vt2Count);
				
				LOG.info("************VT2 DONE************");
				int vtCntInt =1;
				int vtCntLimit=Integer.parseInt(resourceBundle.getString("PDDR_LOOP_CNTR"));;
				int vtCntIncr =Integer.parseInt(resourceBundle.getString("PDDR_LOOP_CNTR"));;
				int val = 0;
				int loopCount = 0;
				
				if(vt2Count <=vtCntLimit){
					loopCount = 1;
				}else{
					loopCount = vt2Count/vtCntLimit;				
					val = vt2Count - (vtCntLimit * loopCount);
					  if (val > 0) {
						loopCount++;					
					   }
				}
				
				if(tab1DataList.size()!=0){
				/*File file = new File(fileDir);
				boolean dirExists = file.exists();
				if (!dirExists) {	
					file.mkdir();
				}*/
				File fileName = new File(filePathEbom);
				boolean fileExist = fileName.exists();
				if(!fileExist) {
					createFileExist =fileName.createNewFile();
					LOG.info("createFileExist>>>>.."+createFileExist);
			 	}
				if (fileName.exists()) {
					fileOut = new FileOutputStream(filePathEbom);
					pwriter =  new PrintWriter( new FileWriter(filePathEbom));
			  
					pwriter.write("Level");
			 		pwriter.write(",");
		 			pwriter.write("Part Name");
		 			pwriter.write(",");
		 			pwriter.write("Part Type");
		 			pwriter.write(",");
		 			pwriter.write("Part Revision");
		 			pwriter.write(",");
		 			pwriter.write("Part Policy");
		 			pwriter.write(",");
		 			pwriter.write("Find Num");
		 			pwriter.write(",");
		  			pwriter.write("Ref Designator");
		 			pwriter.write(",");
		 			pwriter.write("Component Location");
		 			pwriter.write(",");
		 			pwriter.write("Part Description");
		 			pwriter.write(",");
		 			pwriter.write("Part State");
		 			pwriter.write(",");
		 			pwriter.write("Part Qty");
		 			pwriter.write(",");
		 			pwriter.write("UOM");
		 			pwriter.write(",");
				    pwriter.write("Usage");
		 			pwriter.write(",");
		 			pwriter.write("Part Family");
		 			pwriter.write(",");
		 			pwriter.write("GE Tech Feature");
		 			pwriter.write(",");
		 			pwriter.write("BOM Prefix");
		 			pwriter.write(",");
		 			pwriter.write("Copics Parent");
		 			pwriter.write(",");
		  			pwriter.write("Copics Suffix");
		 			pwriter.write(",");
		 			pwriter.write("Start Effectivity Date");
		 			pwriter.write(",");
		 			pwriter.write("End Effectivity Date");
		 			pwriter.write(",");
		 			pwriter.write("Material Spec");
		 			pwriter.write(",");
		 			pwriter.write("GE LDPA");
		 			
		 			pwriter.write("\n");
	
				 for (int i=0;i<loopCount;i++) {
					 LOG.info("-------------------Loop Rotating from Row key "+vtCntInt +" and "+vtCntIncr);
					if(vtCntIncr > vt2Count){
						vtCntIncr=vt2Count;
					 }
					tab2DataList= new ArrayList<PLMSoKitReportData>();
					timeStampLoop = PLMUtils.volTableFormatDate();
					LOG.info("The timeStamp for the Report inside Loop "+timeStampLoop);
					
					SOB_VT3 = SOB_VT3.concat(timeStampLoop);
					SOB_VT4 = SOB_VT4.concat(timeStampLoop); 
					
					//VT3
					vt3Query = new StringBuffer();
					vt3Query.append(PLMOfflineQueries.CREATE_SOB_VT31.replace("SOB_VT3", SOB_VT3)
							.replace("SOB_VT2", SOB_VT2));
					vt3Query.append(" WHERE VT2.ROW_KEY BETWEEN ");
					vt3Query.append(vtCntInt);
					vt3Query.append(" AND ");
					vt3Query.append(vtCntIncr);
					vt3Query.append(PLMOfflineQueries.CREATE_SOB_VT32);
					
					LOG.info("Query for Creating SOB_VT3 : "+vt3Query);
					getJdbcTemplate().execute(vt3Query.toString());
					
					LOG.info("Query for Collect STATS SOB_VT3 : " + PLMOfflineQueries.COLLECT_STATS_SOB_VT3.replace("SOB_VT3", SOB_VT3));
					getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_SOB_VT3.replace("SOB_VT3", SOB_VT3));
					
					LOG.info("************VT3 DONE************");
					
					//VT4
					LOG.info("Query for Creating SOB_VT4 : "+PLMOfflineQueries.CREATE_SOB_VT4.replace("SOB_VT4", SOB_VT4)
							.replace("SOB_VT3", SOB_VT3));
					getJdbcTemplate().execute(PLMOfflineQueries.CREATE_SOB_VT4.replace("SOB_VT4", SOB_VT4)
							.replace("SOB_VT3", SOB_VT3));
					
					LOG.info("Query for Inserting SOB_VT4 : "+PLMOfflineQueries.INSERT_SOB_VT4.replace("SOB_VT4", SOB_VT4).replace("SOB_VT3", SOB_VT3)
							.replace("SOB_VT2", SOB_VT2));
					getJdbcTemplate().execute(PLMOfflineQueries.INSERT_SOB_VT4.replace("SOB_VT4", SOB_VT4)
							.replace("SOB_VT3", SOB_VT3).replace("SOB_VT2", SOB_VT2));
				
					
					//LOG.info("Query for Collect STATS SOB_VT4 : " + PLMOfflineQueries.COLLECT_STATS_SOB_VT4.replace("SOB_VT4", SOB_VT4));
					//getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_SOB_VT4.replace("SOB_VT4", SOB_VT4));
					
					LOG.info("************VT4 DONE************");
					searchResultsQry1 = new StringBuffer();
					searchResultsQry1.append(PLMOfflineQueries.GET_TAB2_DATA);
					LOG.info("Executing query to fetch TAB2 details : "+searchResultsQry1.toString().replace("SOB_VT4", SOB_VT4));
					tab2DataList = new ArrayList<PLMSoKitReportData>();
					tab2DataList = getSimpleJdbcTemplate().query(searchResultsQry1.toString().replace("SOB_VT4", SOB_VT4), new GetTab2DataMapper());
					vtCntInt=vtCntInt+Integer.parseInt(resourceBundle.getString("PDDR_LOOP_CNTR"));;
					vtCntIncr=vtCntIncr+Integer.parseInt(resourceBundle.getString("PDDR_LOOP_CNTR"));;
					
					// write tab2DataList data into CSV file
					if(tab1DataList.size() != 0){
						for(String currentPart : requiredPartsNm){
							currentPartDataList=new ArrayList<PLMSoKitReportData>();
								for(PLMSoKitReportData data1 : tab2DataList){
								if(data1.getTab2TopLevelPart().equals(currentPart))
								{
									currentPartDataList.add(data1);						
								}
							}
							Collections.sort(currentPartDataList, new SortDFSOrder());
							varMapCsv2.put(requiredParts.get(currentPart),currentPartDataList);
						}
						LOG.info("Before writing CSV2 Data for number of parts : "+varMapCsv2.size());
					}
					for(Map.Entry<String,List<PLMSoKitReportData>> entry : varMapCsv2.entrySet()){
		 				//String localPart = entry.getKey();
		 				List<PLMSoKitReportData> localPartList = entry.getValue();
		 				
		 				/*pwriter.write("\n");
		 				pwriter.write(localPart);
		 				pwriter.write("\n");*/
		 				
		 			for(int j=0; j<localPartList.size(); j++) {
		 				PLMSoKitReportData dataObj = (PLMSoKitReportData)localPartList.get(j);
		 				
		 				if(dataObj.getTab2BomLevel()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab2BomLevel()));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2PartName()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab2PartName()));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2PartType()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab2PartType()));
				   		}
			   			pwriter.write(",");
			   			
			   			if(dataObj.getTab2PartRev()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getTab2PartRev()+"\""));
				   		}
			   			pwriter.write(",");
			   		
		 				if(dataObj.getTab2PartPolicy()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab2PartPolicy()));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2FindNum()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getTab2FindNum()+"\""));
							
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2RefDesignator()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab2RefDesignator()));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2CompLocation()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab2CompLocation()));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2PartDesc()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab2PartDesc()));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2PartState()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab2PartState()));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2PartQty()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getTab2PartQty()+"\""));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2Uom()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab2Uom()));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2Usage()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab2Usage()));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2PartFamily()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab2PartFamily()));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2GeTechFeature()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab2GeTechFeature()));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2BomPrefix()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getTab2BomPrefix()+"\""));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2CopicsParent()!= null){
		 		   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getTab2CopicsParent()+"\""));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2CopicsSuffix()!= null){
		 					pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getTab2CopicsSuffix()+"\""));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2StEffDt()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab2StEffDt()));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2EndEffDt()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab2EndEffDt()));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2MaterialSpec()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab2MaterialSpec()));
				   		}
			   			pwriter.write(",");
			   			
		 				if(dataObj.getTab2GeLdpa()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab2GeLdpa()));
				   		}
	 		   			pwriter.write("\n");
		 				}
		 			}
				}
			 }
			dataMap.put("filePathEbom", filePathEbom);
		  }	
		 }catch(DataAccessException e){
			 PLMUtils.checkException(e.getMessage());
		 } catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@getGenSOKitRptData: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@getGenSOKitRptData: ", e);
			throw e;
		}finally {
			try {
				if (pwriter !=null) {
					pwriter.close();
				}
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@getGenSOKitRptData: ", e);
				throw e;
			}
		}
		LOG.info("Existing getGenSOKitRptData() of DAO Impl"); 
		return dataMap;
	}
	/**
	 * 
	 * class to sort list of object of type PLMSoKitReportData
	 * 
	 */
	private static class SortDFSOrder implements Comparator<PLMSoKitReportData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMSoKitReportData aString,
				PLMSoKitReportData bString) {
			
		 return aString.getTab2DfsOrder().compareTo(bString.getTab2DfsOrder());
		      
		}
	}
	private void writeCSV1Data(Map<String, Object> varMap, String filePathCSV) throws Exception{
		LOG.info("Write CSV1 Data Method");
		FileOutputStream fileOut = null;
		PrintWriter pwriter =null;
		boolean createFileExist;
		List<PLMSoKitReportData> localList=(List<PLMSoKitReportData>) varMap.get("tab1DataList");
		try{
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathCSV);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathCSV);
				pwriter =  new PrintWriter( new FileWriter(filePathCSV));
				
				pwriter.write("PLM SO # / ERP EPN # :");
				pwriter.write(",");
				pwriter.write(varMap.get("erpNum").toString());
				pwriter.write("\n");
			
			    pwriter.write("\n");
			    
			    pwriter.write("Order Number");
	 			pwriter.write(",");
	 			pwriter.write("ERP Line Number");
	 			pwriter.write(",");
	 			pwriter.write("Part Name");
	 			pwriter.write(",");
	 			pwriter.write("PART_Description");
	 			pwriter.write(",");
	 			pwriter.write("MLI");
	 			pwriter.write(",");
	  			pwriter.write("Line Status");
	 			pwriter.write(",");
	 			pwriter.write("Customer Line Number");
	 			pwriter.write(",");
	 			pwriter.write("Quantity");
	 			pwriter.write(",");
	 			pwriter.write("UOM");
	 			pwriter.write(",");
	 			pwriter.write("Ship Date");
	 			pwriter.write(",");
	 			pwriter.write("Request Date");
	 			
	 			pwriter.write("\n");
	 			
	 			for(int i=0; i<localList.size(); i++) {
	 				PLMSoKitReportData dataObj = (PLMSoKitReportData)localList.get(i);
	 				if(dataObj.getTab1OrderNum()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab1OrderNum()));
			   		}
		   			pwriter.write(",");
		   			
	 				if(dataObj.getTab1ErpLineNum()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab1ErpLineNum()));
			   		}
		   			pwriter.write(",");
		   			
	 				if(dataObj.getTab1PartName()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab1PartName()));
			   		}
		   			pwriter.write(",");
		   			
	 				if(dataObj.getTab1PartDesc()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab1PartDesc()));
			   		}
		   			pwriter.write(",");
		   			
	 				if(dataObj.getTab1Mli()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab1Mli()));
			   		}
		   			pwriter.write(",");
		   			
	 				if(dataObj.getTab1LineStatus()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab1LineStatus()));
			   		}
		   			pwriter.write(",");
		   			
	 				if(dataObj.getTab1CustLineNum()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab1CustLineNum()));
			   		}
		   			pwriter.write(",");
		   			
	 				if(dataObj.getTab1Qty()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab1Qty()));
			   		}
		   			pwriter.write(",");
		   			
	 				if(dataObj.getTab1Uom()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab1Uom()));
			   		}
		   			pwriter.write(",");
		   			
	 				if(dataObj.getTab1ShipDate()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab1ShipDate()));
			   		}
		   			pwriter.write(",");
		   			
	 				if(dataObj.getTab1RequestDate()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTab1RequestDate()));
			   		}
		   			pwriter.write(",");
		   			
		   			pwriter.write("\n");
	 				}
			}
		}catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@writeCSV1Data: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@writeCSV1Data: ", e);
			throw e;
		}finally {
			try {
				if (pwriter !=null) {
					pwriter.close();
				}
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@writeCSV1Data: ", e);
				throw e;
			}
		}
		LOG.info("Exiting WriteCSVData1 Method");
	}
	
	/**
	 * @return PLMGBomData objects.
	 */
	private static final class GetTab1DataMapper implements ParameterizedRowMapper<PLMSoKitReportData> {
		public PLMSoKitReportData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMSoKitReportData reportData = new PLMSoKitReportData();
		
			final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("MM/dd/yyyy");
			
			reportData.setTab1OrderNum(PLMUtils.checkNullVal(rs.getString("ORDER_NUM")));
			reportData.setTab1ErpLineNum(PLMUtils.checkNullVal(rs.getString("ERP_LINE_NUM"))); 
			reportData.setTab1PartName(PLMUtils.checkNullVal(rs.getString("PART_NAME"))); 
			reportData.setTab1PartRev(PLMUtils.checkNullVal(rs.getString("PART_REV"))); 
			reportData.setTab1PartDesc(PLMUtils.checkNullVal(rs.getString("PART_DESCRIPTION"))); 
			reportData.setTab1Mli(PLMUtils.checkNullVal(rs.getString("MLI")));
			reportData.setTab1LineStatus(PLMUtils.checkNullVal(rs.getString("LINE_STATUS"))); 
			reportData.setTab1CustLineNum(PLMUtils.checkNullVal(rs.getString("CUSTOMER_LINE_NUMBER")));
			reportData.setTab1Qty(PLMUtils.checkNullVal(rs.getString("QTY")));
			reportData.setTab1Uom(PLMUtils.checkNullVal(rs.getString("UOM")));
			//reportData.setTab1ShipDate(PLMUtils.checkNullVal(rs.getString("SHIP_DATE")));
			Date shipDate = rs.getDate("SHIP_DATE");
			if(shipDate!=null){
				reportData.setTab1ShipDate(DATE_FORMAT_PROC.format(shipDate));
			}
			//reportData.setTab1RequestDate(PLMUtils.checkNullVal(rs.getString("REQUEST_DATE")));			
			Date requestDate = rs.getDate("REQUEST_DATE");
			if(requestDate!=null){
				reportData.setTab1RequestDate(DATE_FORMAT_PROC.format(requestDate));
			}
		
		return reportData;
		}
	}
	/**
	 * @return PLMGBomData objects.
	 */
	private static final class GetTab2DataMapper implements ParameterizedRowMapper<PLMSoKitReportData> {

		public PLMSoKitReportData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMSoKitReportData partData = new PLMSoKitReportData();
			
			final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("MM/dd/yyyy");
			
			partData.setTab2DfsOrder(PLMUtils.checkNullVal(rs.getString("DFSORDER")));
			partData.setTab2BomLevel(PLMUtils.checkNullVal(rs.getString("BOM_LEVEL")));
			partData.setTab2TopLevelPart(PLMUtils.checkNullVal(rs.getString("TOP_LEVEL_PART"))); 
			partData.setTab2PartId(PLMUtils.checkNullVal(rs.getString("PART_ID")));
			partData.setTab2PartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
			partData.setTab2PartType(PLMUtils.checkNullVal(rs.getString("PART_TYPE"))); 
			partData.setTab2PartRev(PLMUtils.checkNullVal(rs.getString("PART_REV"))); 
			partData.setTab2PartPolicy(PLMUtils.checkNullVal(rs.getString("PART_POLICY")));
			partData.setTab2FindNum(PLMUtils.checkNullVal(rs.getString("FIND_NUM"))); 
			partData.setTab2RefDesignator(PLMUtils.checkNullVal(rs.getString("REF_DESIGNATOR")));
			partData.setTab2CompLocation(PLMUtils.checkNullVal(rs.getString("COMPONENT_LOCATION")));
			partData.setTab2PartDesc(PLMUtils.checkNullVal(rs.getString("PART_DESCRIPTION")));
			partData.setTab2PartState(PLMUtils.checkNullVal(rs.getString("PART_STATE")));
			partData.setTab2PartQty(PLMUtils.checkNullVal(rs.getString("PART_QTY")));
			partData.setTab2Uom(PLMUtils.checkNullVal(rs.getString("UOM"))); 
			partData.setTab2Usage(PLMUtils.checkNullVal(rs.getString("USAGE"))); 
			partData.setTab2PartFamily(PLMUtils.checkNullVal(rs.getString("PART_FAMILY"))); 
			partData.setTab2GeTechFeature(PLMUtils.checkNullVal(rs.getString("GE_TECH_FEATURE")));
			partData.setTab2BomPrefix(PLMUtils.checkNullVal(rs.getString("BOM_PREFIX"))); 
			partData.setTab2CopicsParent(PLMUtils.checkNullVal(rs.getString("COPICS_PARENT")));
			partData.setTab2CopicsSuffix(PLMUtils.checkNullVal(rs.getString("COPICS_SUFFIX")));
			//partData.setTab2StEffDt(PLMUtils.checkNullVal(rs.getString("START_EFFECTIVITY_DT")));
			Date stDate = rs.getDate("START_EFFECTIVITY_DT");
			if(stDate!=null){
				partData.setTab2StEffDt(DATE_FORMAT_PROC.format(stDate));
			}
			//partData.setTab2EndEffDt(PLMUtils.checkNullVal(rs.getString("END_EFFECTIVITY_DT")));
			Date endDate = rs.getDate("END_EFFECTIVITY_DT");
			if(endDate!=null){
				partData.setTab2EndEffDt(DATE_FORMAT_PROC.format(endDate));
			}
			
			partData.setTab2MaterialSpec(PLMUtils.checkNullVal(rs.getString("MATERIAL_SPEC")));
			partData.setTab2GeLdpa(PLMUtils.checkNullVal(rs.getString("GE_LDPA")));
		
		return partData;
		}
	}
	
	/**
	 * @return the tab1DataList
	 */
	public List<PLMSoKitReportData> getTab1DataList() {
		return tab1DataList;
	}

	/**
	 * @param tab1DataList the tab1DataList to set
	 */
	public void setTab1DataList(List<PLMSoKitReportData> tab1DataList) {
		this.tab1DataList = tab1DataList;
	}
	/**
	 * @return the tab2DataList
	 */
	public List<PLMSoKitReportData> getTab2DataList() {
		return tab2DataList;
	}
	/**
	 * @param tab2DataList the tab2DataList to set
	 */
	public void setTab2DataList(List<PLMSoKitReportData> tab2DataList) {
		this.tab2DataList = tab2DataList;
	}
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}
	
	

}
