 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileNamePLMCustDocReportDaoImpl.java
 * @Creation date: 16-March-2015
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMCustDocReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMCustDocReportDaoImpl extends SimpleJdbcDaoSupport implements PLMCustDocReportDaoIfc{
	private static final Logger LOG = Logger.getLogger(PLMCustDocReportDaoImpl.class);
	//private static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
	private static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
	private static final SimpleDateFormat SIMPLE_DATE_FORMAT1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	/**
	 * This method is used for getIssuesData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMCustDocReportData> getCustDocReport(String finalQuery, PLMCustDocReportData srchData)
			throws PLMCommonException {
		LOG.info("Inside getCustDocReport of DAOImpl");
		List<PLMCustDocReportData> searchResultList = null;
		try{
		if(srchData.isExhaustiveList() && 
				(srchData.getSourceOfResult().equals("pgplmtcf"))){
			LOG.info("Fetching Exhaustive PGPLM and TC5 Columns---Going to Mapper1111111111111************");
		searchResultList = getJdbcTemplate().query(finalQuery, new CustDocMapper1());
		}
		if(srchData.isExhaustiveList() && 
				(srchData.getSourceOfResult().equals("pgplm"))){
			LOG.info("Fetching Exhaustive PGPLM Columns---Going to Mapper222222222************");
		searchResultList = getJdbcTemplate().query(finalQuery, new CustDocMapper2());
		}
		if(srchData.isExhaustiveList() && 
				(srchData.getSourceOfResult().equals("tcf"))){	
			LOG.info("Fetching Exhaustive TC5 Columns---Going to Mapper33333333333************");
		searchResultList = getJdbcTemplate().query(finalQuery, new CustDocMapper3());
		}
		if(!srchData.isExhaustiveList()){
			LOG.info("Not Fetching Exhaustive Columns---Going to Mapper444444444444************");
		searchResultList = getJdbcTemplate().query(finalQuery, new CustDocMapper4());
		}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Existing getCustDocReport of DAOImpl");
		return searchResultList;
	}
	
	private static final class CustDocMapper1 implements ParameterizedRowMapper<PLMCustDocReportData>{	
		public PLMCustDocReportData mapRow(ResultSet rs, int rowCount) throws SQLException {			
			PLMCustDocReportData searchData = new PLMCustDocReportData();
			
				searchData.setOpContract(PLMUtils.checkNullVal(rs.getString("CONTRACT_NAME")));
				searchData.setOpContractDesc(PLMUtils.checkNullVal(rs.getString("CONTRACT_DESCRIPTION")));
				searchData.setOpWBSEName(PLMUtils.checkNullVal(rs.getString("WBSE_NAME")));
				searchData.setOpWBSERev(PLMUtils.checkNullVal(rs.getString("WBSE_REV")));
				searchData.setOpWBSEState(PLMUtils.checkNullVal(rs.getString("WBSE_STATE")));
				searchData.setOpPld(PLMUtils.checkNullVal(rs.getString("PLD_TITLE")));
				searchData.setOpPldRev(PLMUtils.checkNullVal(rs.getString("PLD_REV")));
				//searchData.setOpPldRelease(PLMUtils.checkNullVal(rs.getString("PLD_RELEASE")));
				Date pldReleaseDt = rs.getDate("PLD_RELEASE");
				if(pldReleaseDt != null){
					String strpldReleaseDt = SIMPLE_DATE_FORMAT.format(pldReleaseDt);
					searchData.setOpPldRelease(strpldReleaseDt);
					searchData.setOpPldReleaseExl(pldReleaseDt);
				} else {
					searchData.setOpPldRelease("");
				}
				
				searchData.setOpGenTitle(PLMUtils.checkNullVal(rs.getString("GENERAL_TITLE")));
				searchData.setOpDetTitle(PLMUtils.checkNullVal(rs.getString("DETAILED_TITLE")));
				searchData.setOpDocType(PLMUtils.checkNullVal(rs.getString("DOCUMENT_TYPE")));
				searchData.setOpDocument(PLMUtils.checkNullVal(rs.getString("DOCUMENT_NAME")));
				searchData.setOpDocRev(PLMUtils.checkNullVal(rs.getString("DOCUMENT_REV")));
				searchData.setOpTc5Label(PLMUtils.checkNullVal(rs.getString("TC5_LABEL")));
				searchData.setOpLabelRev(PLMUtils.checkNullVal(rs.getString("LABEL_REV")));
				//searchData.setOpLabelRelease(PLMUtils.checkNullVal(rs.getString("LABEL_RELEASE")));
				Date lblReleaseDt = rs.getDate("LABEL_RELEASE");
				if(lblReleaseDt != null){
					String strlblReleaseDt = SIMPLE_DATE_FORMAT.format(lblReleaseDt);
					searchData.setOpLabelRelease(strlblReleaseDt);
					searchData.setOpLabelReleaseExl(lblReleaseDt);
				} else {
					searchData.setOpLabelRelease("");
				}
				
				searchData.setOpWbseId(PLMUtils.checkNullVal(rs.getString("WBSE_ID")));
				searchData.setOpPlpId(PLMUtils.checkNullVal(rs.getString("PLD_ID")));
				searchData.setOpDocumentId(PLMUtils.checkNullVal(rs.getString("DOCUMENT_ID")));
				
				searchData.setOpGenTitleFlag(PLMUtils.checkNullVal(rs.getString("GENERAL_TITLE_FLAG")));
				searchData.setOpDetTitleFlag(PLMUtils.checkNullVal(rs.getString("DETAILED_TITLE_FLAG")));
				
				searchData.setOpWbseOriginator(PLMUtils.checkNullVal(rs.getString("WBSE_ORIGINATOR")));				
				//searchData.setOpWbseOriginated(PLMUtils.checkNullVal(rs.getString("WBSE_ORIGINATED")));
				//Date wbseOrigDt = rs.getDate("WBSE_ORIGINATED");
				Date wbseOrigDt = rs.getTimestamp("WBSE_ORIGINATED");
				if(wbseOrigDt != null){
					String strWbseOrigDt = SIMPLE_DATE_FORMAT1.format(wbseOrigDt);
					searchData.setOpWbseOriginated(strWbseOrigDt);
					searchData.setOpWbseOriginatedExl(wbseOrigDt);
				} else {
					searchData.setOpWbseOriginated("");
				}
				
				//searchData.setOpWbseModified(PLMUtils.checkNullVal(rs.getString("WBSE_MODIFIED")));
				//Date wbseModDt = rs.getDate("WBSE_MODIFIED");
				Date wbseModDt = rs.getTimestamp("WBSE_MODIFIED");
				if(wbseModDt != null){
					String strWbseModDt = SIMPLE_DATE_FORMAT1.format(wbseModDt);
					searchData.setOpWbseModified(strWbseModDt);
					searchData.setOpWbseModifiedExl(wbseModDt);
				} else {
					searchData.setOpWbseModified("");
				}
				
				searchData.setOpWbseOwner(PLMUtils.checkNullVal(rs.getString("WBSE_OWNER")));
				searchData.setOpWbseMgr(PLMUtils.checkNullVal(rs.getString("WBSE_MGR")));
				searchData.setOpWbseAssignee(PLMUtils.checkNullVal(rs.getString("WBSE_ASSIGNEE")));
				searchData.setOpWbseProjRole(PLMUtils.checkNullVal(rs.getString("WBSE_PROJECT_ROLE")));
				
				//searchData.setOpWbseDueDate(PLMUtils.checkNullVal(rs.getString("WBSE_DUE_DATE")));
				Date wbseDueDt = rs.getDate("WBSE_DUE_DATE1");
				if(wbseDueDt != null){
					String strWbseDueDt = SIMPLE_DATE_FORMAT.format(wbseDueDt);
					searchData.setOpWbseDueDate(strWbseDueDt);
					searchData.setOpWbseDueDateExl(wbseDueDt);
				} else {
					searchData.setOpWbseDueDate("");
				}
				
				//searchData.setOpWbseEstFinish(PLMUtils.checkNullVal(rs.getString("WBSE_EST_FINISH")));
				Date wbseEstFinishDt = rs.getDate("WBSE_EST_FINISH");
				if(wbseEstFinishDt != null){
					String strWbseEstFinishDt = SIMPLE_DATE_FORMAT.format(wbseEstFinishDt);
					searchData.setOpWbseEstFinish(strWbseEstFinishDt);
					searchData.setOpWbseEstFinishExl(wbseEstFinishDt);
				} else {
					searchData.setOpWbseEstFinish("");
				}
				
				//searchData.setOpWbseEstStart(PLMUtils.checkNullVal(rs.getString("WBSE_EST_START")));
				Date wbseEstStartDt = rs.getDate("WBSE_EST_START");
				if(wbseEstStartDt != null){
					String strWbseEstStartDt = SIMPLE_DATE_FORMAT.format(wbseEstStartDt);
					searchData.setOpWbseEstStart(strWbseEstStartDt);
					searchData.setOpWbseEstStartExl(wbseEstStartDt);					
				} else {
					searchData.setOpWbseEstStart("");
				}
				
				searchData.setOpWbseLiqDamage(PLMUtils.checkNullVal(rs.getString("WBSE_LIQUIDATED_DAMAGE")));
				searchData.setOpWbseForDist(PLMUtils.checkNullVal(rs.getString("WBSE_FOR_DISTRIB")));
				searchData.setOpWbsePldReq(PLMUtils.checkNullVal(rs.getString("WBSE_PLD_REQUIRED")));
				searchData.setOpWbseEid(PLMUtils.checkNullVal(rs.getString("WBSE_EID")));
				searchData.setOpWbseEquipCode(PLMUtils.checkNullVal(rs.getString("WBSE_EQUIPMENT_CODE")));
				searchData.setOpWbseFunSys(PLMUtils.checkNullVal(rs.getString("WBSE_FNCTL_SYSTEM")));
				searchData.setOpWbseClsfCode(PLMUtils.checkNullVal(rs.getString("WBSE_CLASSIF_CODE")));
				searchData.setOpWbsePldCode(PLMUtils.checkNullVal(rs.getString("WBSE_PLD_CODE")));
				searchData.setOpWbseExtdocCode(PLMUtils.checkNullVal(rs.getString("WBSE_EXTDOC_CODE")));
				searchData.setOpWbseExtRev(PLMUtils.checkNullVal(rs.getString("WBSE_EXTREV")));
				searchData.setOpWbseExtFld1(PLMUtils.checkNullVal(rs.getString("WBSE_EXTFIELD1")));
				searchData.setOpWbseExtFld2(PLMUtils.checkNullVal(rs.getString("WBSE_EXTFIELD2")));
				searchData.setOpWbseExtFld3(PLMUtils.checkNullVal(rs.getString("WBSE_EXTFIELD3")));
				searchData.setOpWbseRelProj(PLMUtils.checkNullVal(rs.getString("WBSE_RELATED_PROJECT")));
				searchData.setOpWbsePolicy(PLMUtils.checkNullVal(rs.getString("WBSE_POLICY")));
				searchData.setOpWbseCwbse(PLMUtils.checkNullVal(rs.getString("WBSE_CWBSE")));
				searchData.setOpWbseDesc(PLMUtils.checkNullVal(rs.getString("WBSE_DESCRIPTION")));
				searchData.setOpWbseTitle(PLMUtils.checkNullVal(rs.getString("WBSE_TITLE")));
				searchData.setOpWbseNotes(PLMUtils.checkNullVal(rs.getString("WBSE_NOTES")));
				searchData.setOpWbseSynopsis(PLMUtils.checkNullVal(rs.getString("WBSE_SYNOPSIS")));
				

					//LOG.info("Fetch TC5 Exhaustive Cols******************************");
				searchData.setOpTc5Status(PLMUtils.checkNullVal(rs.getString("TC5_STATUS")));
				searchData.setOpSuperseded(PLMUtils.checkNullVal(rs.getString("SUPERSEDED")));
				searchData.setOpOfficial(PLMUtils.checkNullVal(rs.getString("OFFICIAL")));
				searchData.setOpTc5MainType(PLMUtils.checkNullVal(rs.getString("TC5_MAINTYPE")));
				searchData.setOpTc5SecType(PLMUtils.checkNullVal(rs.getString("TC5_SEC_TYPE")));
				//searchData.setOpTc5Metrix(PLMUtils.checkNullVal(rs.getString("TC5_METRIX")));
				Date tc5MatrixDt = rs.getDate("TC5_METRIX");
				if(tc5MatrixDt != null){
					String strTc5MatrixDt = SIMPLE_DATE_FORMAT.format(tc5MatrixDt);
					searchData.setOpTc5Metrix(strTc5MatrixDt);
					searchData.setOpTc5MetrixExl(tc5MatrixDt);
				} else {
					searchData.setOpTc5Metrix("");
				}
				
				//searchData.setOpTc5Sent(PLMUtils.checkNullVal(rs.getString("TC5_SENT")));
				Date tc5SentDt = rs.getDate("TC5_SENT");
				if(tc5SentDt != null){
					String strTc5SentDt = SIMPLE_DATE_FORMAT.format(tc5SentDt);
					searchData.setOpTc5Sent(strTc5SentDt);
					searchData.setOpTc5SentExl(tc5SentDt);
				} else {
					searchData.setOpTc5Sent("");
				}
				
				//searchData.setOpTc5Reply(PLMUtils.checkNullVal(rs.getString("TC5_REPLY")));
				Date tc5ReplyDt = rs.getDate("TC5_REPLY");
				if(tc5ReplyDt != null){
					String strTc5ReplyDt = SIMPLE_DATE_FORMAT.format(tc5ReplyDt);
					searchData.setOpTc5Reply(strTc5ReplyDt);
					searchData.setOpTc5ReplyExl(tc5ReplyDt);
				} else {
					searchData.setOpTc5Reply("");
				}
				
				//searchData.setOpTc5Resubmit(PLMUtils.checkNullVal(rs.getString("TC5_RESUBMIT")));
				Date tc5ResubmitDt = rs.getDate("TC5_RESUBMIT");
				if(tc5ResubmitDt != null){
					String strTc5ResubmitDt = SIMPLE_DATE_FORMAT.format(tc5ResubmitDt);
					searchData.setOpTc5Resubmit(strTc5ResubmitDt);
					searchData.setOpTc5ResubmitExl(tc5ResubmitDt);
				} else {
					searchData.setOpTc5Resubmit("");
				}
				
				searchData.setOpTc5CustStatus(PLMUtils.checkNullVal(rs.getString("TC5_CUSTOMER_STATUS")));
				searchData.setOpTc5Customer(PLMUtils.checkNullVal(rs.getString("TC5_CUSTOMER")));
				searchData.setOpTc5Supplier(PLMUtils.checkNullVal(rs.getString("TC5_SUPPLIER")));
				searchData.setOpTc5CustFld1(PLMUtils.checkNullVal(rs.getString("TC5_CUSTOM_FIELD1")));
				searchData.setOpTc5CustFld2(PLMUtils.checkNullVal(rs.getString("TC5_CUSTOM_FIELD2")));
				searchData.setOpTc5CustFld3(PLMUtils.checkNullVal(rs.getString("TC5_CUSTOM_FIELD3")));
				searchData.setOpTc5ForApproval(PLMUtils.checkNullVal(rs.getString("TC5_FOR_APPROVAL")));
				searchData.setOpTc5Contractual(PLMUtils.checkNullVal(rs.getString("TC5_CONTRACTUAL")));
				searchData.setOpTc5Asb(PLMUtils.checkNullVal(rs.getString("TC5_ASB")));
				searchData.setOpTc5Pole(PLMUtils.checkNullVal(rs.getString("TC5_POLE")));
					
				
				
				
			return 	searchData;
		}
	}
	
	private static final class CustDocMapper2 implements ParameterizedRowMapper<PLMCustDocReportData>{	
		public PLMCustDocReportData mapRow(ResultSet rs, int rowCount) throws SQLException {			
			PLMCustDocReportData searchData = new PLMCustDocReportData();
			
				searchData.setOpContract(PLMUtils.checkNullVal(rs.getString("CONTRACT_NAME")));
				searchData.setOpContractDesc(PLMUtils.checkNullVal(rs.getString("CONTRACT_DESCRIPTION")));
				searchData.setOpWBSEName(PLMUtils.checkNullVal(rs.getString("WBSE_NAME")));
				searchData.setOpWBSERev(PLMUtils.checkNullVal(rs.getString("WBSE_REV")));
				searchData.setOpWBSEState(PLMUtils.checkNullVal(rs.getString("WBSE_STATE")));
				searchData.setOpPld(PLMUtils.checkNullVal(rs.getString("PLD_TITLE")));
				searchData.setOpPldRev(PLMUtils.checkNullVal(rs.getString("PLD_REV")));
				//searchData.setOpPldRelease(PLMUtils.checkNullVal(rs.getString("PLD_RELEASE")));
				Date pldReleaseDt = rs.getDate("PLD_RELEASE");
				if(pldReleaseDt != null){
					String strpldReleaseDt = SIMPLE_DATE_FORMAT.format(pldReleaseDt);
					searchData.setOpPldRelease(strpldReleaseDt);
					searchData.setOpPldReleaseExl(pldReleaseDt);
				} else {
					searchData.setOpPldRelease("");
				}
				
				searchData.setOpGenTitle(PLMUtils.checkNullVal(rs.getString("GENERAL_TITLE")));
				searchData.setOpDetTitle(PLMUtils.checkNullVal(rs.getString("DETAILED_TITLE")));
				searchData.setOpDocType(PLMUtils.checkNullVal(rs.getString("DOCUMENT_TYPE")));
				searchData.setOpDocument(PLMUtils.checkNullVal(rs.getString("DOCUMENT_NAME")));
				searchData.setOpDocRev(PLMUtils.checkNullVal(rs.getString("DOCUMENT_REV")));
				searchData.setOpTc5Label(PLMUtils.checkNullVal(rs.getString("TC5_LABEL")));
				searchData.setOpLabelRev(PLMUtils.checkNullVal(rs.getString("LABEL_REV")));
				//searchData.setOpLabelRelease(PLMUtils.checkNullVal(rs.getString("LABEL_RELEASE")));
				Date lblReleaseDt = rs.getDate("LABEL_RELEASE");
				if(lblReleaseDt != null){
					String strlblReleaseDt = SIMPLE_DATE_FORMAT.format(lblReleaseDt);
					searchData.setOpLabelRelease(strlblReleaseDt);
					searchData.setOpLabelReleaseExl(lblReleaseDt);
				} else {
					searchData.setOpLabelRelease("");
				}
				
				searchData.setOpWbseId(PLMUtils.checkNullVal(rs.getString("WBSE_ID")));
				searchData.setOpPlpId(PLMUtils.checkNullVal(rs.getString("PLD_ID")));
				searchData.setOpDocumentId(PLMUtils.checkNullVal(rs.getString("DOCUMENT_ID")));
				
				searchData.setOpGenTitleFlag(PLMUtils.checkNullVal(rs.getString("GENERAL_TITLE_FLAG")));
				searchData.setOpDetTitleFlag(PLMUtils.checkNullVal(rs.getString("DETAILED_TITLE_FLAG")));
				
				searchData.setOpWbseOriginator(PLMUtils.checkNullVal(rs.getString("WBSE_ORIGINATOR")));				
				//searchData.setOpWbseOriginated(PLMUtils.checkNullVal(rs.getString("WBSE_ORIGINATED")));
				//Date wbseOrigDt = rs.getDate("WBSE_ORIGINATED");
				Date wbseOrigDt = rs.getTimestamp("WBSE_ORIGINATED");
				if(wbseOrigDt != null){
					String strWbseOrigDt = SIMPLE_DATE_FORMAT1.format(wbseOrigDt);
					searchData.setOpWbseOriginated(strWbseOrigDt);
					searchData.setOpWbseOriginatedExl(wbseOrigDt);
				} else {
					searchData.setOpWbseOriginated("");
				}
				
				//searchData.setOpWbseModified(PLMUtils.checkNullVal(rs.getString("WBSE_MODIFIED")));
				//Date wbseModDt = rs.getDate("WBSE_MODIFIED");
				Date wbseModDt = rs.getTimestamp("WBSE_MODIFIED");
				if(wbseModDt != null){
					String strWbseModDt = SIMPLE_DATE_FORMAT1.format(wbseModDt);
					searchData.setOpWbseModified(strWbseModDt);
					searchData.setOpWbseModifiedExl(wbseModDt);
				} else {
					searchData.setOpWbseModified("");
				}
				
				searchData.setOpWbseOwner(PLMUtils.checkNullVal(rs.getString("WBSE_OWNER")));
				searchData.setOpWbseMgr(PLMUtils.checkNullVal(rs.getString("WBSE_MGR")));
				searchData.setOpWbseAssignee(PLMUtils.checkNullVal(rs.getString("WBSE_ASSIGNEE")));
				searchData.setOpWbseProjRole(PLMUtils.checkNullVal(rs.getString("WBSE_PROJECT_ROLE")));
				
				//searchData.setOpWbseDueDate(PLMUtils.checkNullVal(rs.getString("WBSE_DUE_DATE")));
				Date wbseDueDt = rs.getDate("WBSE_DUE_DATE1");
				if(wbseDueDt != null){
					String strWbseDueDt = SIMPLE_DATE_FORMAT.format(wbseDueDt);
					searchData.setOpWbseDueDate(strWbseDueDt);
					searchData.setOpWbseDueDateExl(wbseDueDt);
				} else {
					searchData.setOpWbseDueDate("");
				}
				
				//searchData.setOpWbseEstFinish(PLMUtils.checkNullVal(rs.getString("WBSE_EST_FINISH")));
				Date wbseEstFinishDt = rs.getDate("WBSE_EST_FINISH");
				if(wbseEstFinishDt != null){
					String strWbseEstFinishDt = SIMPLE_DATE_FORMAT.format(wbseEstFinishDt);
					searchData.setOpWbseEstFinish(strWbseEstFinishDt);
					searchData.setOpWbseEstFinishExl(wbseEstFinishDt);
				} else {
					searchData.setOpWbseEstFinish("");
				}
				
				//searchData.setOpWbseEstStart(PLMUtils.checkNullVal(rs.getString("WBSE_EST_START")));
				Date wbseEstStartDt = rs.getDate("WBSE_EST_START");
				if(wbseEstStartDt != null){
					String strWbseEstStartDt = SIMPLE_DATE_FORMAT.format(wbseEstStartDt);
					searchData.setOpWbseEstStart(strWbseEstStartDt);
					searchData.setOpWbseEstStartExl(wbseEstStartDt);		
				} else {
					searchData.setOpWbseEstStart("");
				}
				
				searchData.setOpWbseLiqDamage(PLMUtils.checkNullVal(rs.getString("WBSE_LIQUIDATED_DAMAGE")));
				searchData.setOpWbseForDist(PLMUtils.checkNullVal(rs.getString("WBSE_FOR_DISTRIB")));
				searchData.setOpWbsePldReq(PLMUtils.checkNullVal(rs.getString("WBSE_PLD_REQUIRED")));
				searchData.setOpWbseEid(PLMUtils.checkNullVal(rs.getString("WBSE_EID")));
				searchData.setOpWbseEquipCode(PLMUtils.checkNullVal(rs.getString("WBSE_EQUIPMENT_CODE")));
				searchData.setOpWbseFunSys(PLMUtils.checkNullVal(rs.getString("WBSE_FNCTL_SYSTEM")));
				searchData.setOpWbseClsfCode(PLMUtils.checkNullVal(rs.getString("WBSE_CLASSIF_CODE")));
				searchData.setOpWbsePldCode(PLMUtils.checkNullVal(rs.getString("WBSE_PLD_CODE")));
				searchData.setOpWbseExtdocCode(PLMUtils.checkNullVal(rs.getString("WBSE_EXTDOC_CODE")));
				searchData.setOpWbseExtRev(PLMUtils.checkNullVal(rs.getString("WBSE_EXTREV")));
				searchData.setOpWbseExtFld1(PLMUtils.checkNullVal(rs.getString("WBSE_EXTFIELD1")));
				searchData.setOpWbseExtFld2(PLMUtils.checkNullVal(rs.getString("WBSE_EXTFIELD2")));
				searchData.setOpWbseExtFld3(PLMUtils.checkNullVal(rs.getString("WBSE_EXTFIELD3")));
				searchData.setOpWbseRelProj(PLMUtils.checkNullVal(rs.getString("WBSE_RELATED_PROJECT")));
				searchData.setOpWbsePolicy(PLMUtils.checkNullVal(rs.getString("WBSE_POLICY")));
				searchData.setOpWbseCwbse(PLMUtils.checkNullVal(rs.getString("WBSE_CWBSE")));
				searchData.setOpWbseDesc(PLMUtils.checkNullVal(rs.getString("WBSE_DESCRIPTION")));
				searchData.setOpWbseTitle(PLMUtils.checkNullVal(rs.getString("WBSE_TITLE")));
				searchData.setOpWbseNotes(PLMUtils.checkNullVal(rs.getString("WBSE_NOTES")));
				searchData.setOpWbseSynopsis(PLMUtils.checkNullVal(rs.getString("WBSE_SYNOPSIS")));
				

					
				
			return 	searchData;
		}
	}
	
	private static final class CustDocMapper3 implements ParameterizedRowMapper<PLMCustDocReportData>{	
		public PLMCustDocReportData mapRow(ResultSet rs, int rowCount) throws SQLException {			
			PLMCustDocReportData searchData = new PLMCustDocReportData();
			
				searchData.setOpContract(PLMUtils.checkNullVal(rs.getString("CONTRACT_NAME")));
				searchData.setOpContractDesc(PLMUtils.checkNullVal(rs.getString("CONTRACT_DESCRIPTION")));
				searchData.setOpWBSEName(PLMUtils.checkNullVal(rs.getString("WBSE_NAME")));
				searchData.setOpWBSERev(PLMUtils.checkNullVal(rs.getString("WBSE_REV")));
				searchData.setOpWBSEState(PLMUtils.checkNullVal(rs.getString("WBSE_STATE")));
				searchData.setOpPld(PLMUtils.checkNullVal(rs.getString("PLD_TITLE")));
				searchData.setOpPldRev(PLMUtils.checkNullVal(rs.getString("PLD_REV")));
				//searchData.setOpPldRelease(PLMUtils.checkNullVal(rs.getString("PLD_RELEASE")));
				Date pldReleaseDt = rs.getDate("PLD_RELEASE");
				if(pldReleaseDt != null){
					String strpldReleaseDt = SIMPLE_DATE_FORMAT.format(pldReleaseDt);
					searchData.setOpPldRelease(strpldReleaseDt);
					searchData.setOpPldReleaseExl(pldReleaseDt);
				} else {
					searchData.setOpPldRelease("");
				}
				
				searchData.setOpGenTitle(PLMUtils.checkNullVal(rs.getString("GENERAL_TITLE")));
				searchData.setOpDetTitle(PLMUtils.checkNullVal(rs.getString("DETAILED_TITLE")));
				searchData.setOpDocType(PLMUtils.checkNullVal(rs.getString("DOCUMENT_TYPE")));
				searchData.setOpDocument(PLMUtils.checkNullVal(rs.getString("DOCUMENT_NAME")));
				searchData.setOpDocRev(PLMUtils.checkNullVal(rs.getString("DOCUMENT_REV")));
				searchData.setOpTc5Label(PLMUtils.checkNullVal(rs.getString("TC5_LABEL")));
				searchData.setOpLabelRev(PLMUtils.checkNullVal(rs.getString("LABEL_REV")));
				//searchData.setOpLabelRelease(PLMUtils.checkNullVal(rs.getString("LABEL_RELEASE")));
				Date lblReleaseDt = rs.getDate("LABEL_RELEASE");
				if(lblReleaseDt != null){
					String strlblReleaseDt = SIMPLE_DATE_FORMAT.format(lblReleaseDt);
					searchData.setOpLabelRelease(strlblReleaseDt);
					searchData.setOpLabelReleaseExl(lblReleaseDt);
				} else {
					searchData.setOpLabelRelease("");
				}
				
				searchData.setOpWbseId(PLMUtils.checkNullVal(rs.getString("WBSE_ID")));
				searchData.setOpPlpId(PLMUtils.checkNullVal(rs.getString("PLD_ID")));
				searchData.setOpDocumentId(PLMUtils.checkNullVal(rs.getString("DOCUMENT_ID")));
				
				searchData.setOpGenTitleFlag(PLMUtils.checkNullVal(rs.getString("GENERAL_TITLE_FLAG")));
				searchData.setOpDetTitleFlag(PLMUtils.checkNullVal(rs.getString("DETAILED_TITLE_FLAG")));
				

					//LOG.info("Fetch TC5 Exhaustive Cols******************************");
				searchData.setOpTc5Status(PLMUtils.checkNullVal(rs.getString("TC5_STATUS")));
				searchData.setOpSuperseded(PLMUtils.checkNullVal(rs.getString("SUPERSEDED")));
				searchData.setOpOfficial(PLMUtils.checkNullVal(rs.getString("OFFICIAL")));
				searchData.setOpTc5MainType(PLMUtils.checkNullVal(rs.getString("TC5_MAINTYPE")));
				searchData.setOpTc5SecType(PLMUtils.checkNullVal(rs.getString("TC5_SEC_TYPE")));
				//searchData.setOpTc5Metrix(PLMUtils.checkNullVal(rs.getString("TC5_METRIX")));
				Date tc5MatrixDt = rs.getDate("TC5_METRIX");
				if(tc5MatrixDt != null){
					String strTc5MatrixDt = SIMPLE_DATE_FORMAT.format(tc5MatrixDt);
					searchData.setOpTc5Metrix(strTc5MatrixDt);
					searchData.setOpTc5MetrixExl(tc5MatrixDt);
				} else {
					searchData.setOpTc5Metrix("");
				}
				
				//searchData.setOpTc5Sent(PLMUtils.checkNullVal(rs.getString("TC5_SENT")));
				Date tc5SentDt = rs.getDate("TC5_SENT");
				if(tc5SentDt != null){
					String strTc5SentDt = SIMPLE_DATE_FORMAT.format(tc5SentDt);
					searchData.setOpTc5Sent(strTc5SentDt);
					searchData.setOpTc5SentExl(tc5SentDt);
				} else {
					searchData.setOpTc5Sent("");
				}
			
				//searchData.setOpTc5Reply(PLMUtils.checkNullVal(rs.getString("TC5_REPLY")));
				Date tc5ReplyDt = rs.getDate("TC5_REPLY");
				if(tc5ReplyDt != null){
					String strTc5ReplyDt = SIMPLE_DATE_FORMAT.format(tc5ReplyDt);
					searchData.setOpTc5Reply(strTc5ReplyDt);
					searchData.setOpTc5ReplyExl(tc5ReplyDt);
				} else {
					searchData.setOpTc5Reply("");
				}
				
				//searchData.setOpTc5Resubmit(PLMUtils.checkNullVal(rs.getString("TC5_RESUBMIT")));
				Date tc5ResubmitDt = rs.getDate("TC5_RESUBMIT");
				if(tc5ResubmitDt != null){
					String strTc5ResubmitDt = SIMPLE_DATE_FORMAT.format(tc5ResubmitDt);
					searchData.setOpTc5Resubmit(strTc5ResubmitDt);
					searchData.setOpTc5ResubmitExl(tc5ResubmitDt);
				} else {
					searchData.setOpTc5Resubmit("");
				}
				
				searchData.setOpTc5CustStatus(PLMUtils.checkNullVal(rs.getString("TC5_CUSTOMER_STATUS")));
				searchData.setOpTc5Customer(PLMUtils.checkNullVal(rs.getString("TC5_CUSTOMER")));
				searchData.setOpTc5Supplier(PLMUtils.checkNullVal(rs.getString("TC5_SUPPLIER")));
				searchData.setOpTc5CustFld1(PLMUtils.checkNullVal(rs.getString("TC5_CUSTOM_FIELD1")));
				searchData.setOpTc5CustFld2(PLMUtils.checkNullVal(rs.getString("TC5_CUSTOM_FIELD2")));
				searchData.setOpTc5CustFld3(PLMUtils.checkNullVal(rs.getString("TC5_CUSTOM_FIELD3")));
				searchData.setOpTc5ForApproval(PLMUtils.checkNullVal(rs.getString("TC5_FOR_APPROVAL")));
				searchData.setOpTc5Contractual(PLMUtils.checkNullVal(rs.getString("TC5_CONTRACTUAL")));
				searchData.setOpTc5Asb(PLMUtils.checkNullVal(rs.getString("TC5_ASB")));
				searchData.setOpTc5Pole(PLMUtils.checkNullVal(rs.getString("TC5_POLE")));
					
				
				
				
			return 	searchData;
		}
	}
	
	private static final class CustDocMapper4 implements ParameterizedRowMapper<PLMCustDocReportData>{	
		public PLMCustDocReportData mapRow(ResultSet rs, int rowCount) throws SQLException {			
			PLMCustDocReportData searchData = new PLMCustDocReportData();
			
				searchData.setOpContract(PLMUtils.checkNullVal(rs.getString("CONTRACT_NAME")));
				searchData.setOpContractDesc(PLMUtils.checkNullVal(rs.getString("CONTRACT_DESCRIPTION")));
				searchData.setOpWBSEName(PLMUtils.checkNullVal(rs.getString("WBSE_NAME")));
				searchData.setOpWBSERev(PLMUtils.checkNullVal(rs.getString("WBSE_REV")));
				searchData.setOpWBSEState(PLMUtils.checkNullVal(rs.getString("WBSE_STATE")));
				searchData.setOpPld(PLMUtils.checkNullVal(rs.getString("PLD_TITLE")));
				searchData.setOpPldRev(PLMUtils.checkNullVal(rs.getString("PLD_REV")));
				//searchData.setOpPldRelease(PLMUtils.checkNullVal(rs.getString("PLD_RELEASE")));
				Date pldReleaseDt = rs.getDate("PLD_RELEASE");
				if(pldReleaseDt != null){
					String strpldReleaseDt = SIMPLE_DATE_FORMAT.format(pldReleaseDt);
					searchData.setOpPldRelease(strpldReleaseDt);
					searchData.setOpPldReleaseExl(pldReleaseDt);
				} else {
					searchData.setOpPldRelease("");
				}
				
				searchData.setOpGenTitle(PLMUtils.checkNullVal(rs.getString("GENERAL_TITLE")));
				searchData.setOpDetTitle(PLMUtils.checkNullVal(rs.getString("DETAILED_TITLE")));
				searchData.setOpDocType(PLMUtils.checkNullVal(rs.getString("DOCUMENT_TYPE")));
				searchData.setOpDocument(PLMUtils.checkNullVal(rs.getString("DOCUMENT_NAME")));
				searchData.setOpDocRev(PLMUtils.checkNullVal(rs.getString("DOCUMENT_REV")));
				searchData.setOpTc5Label(PLMUtils.checkNullVal(rs.getString("TC5_LABEL")));
				searchData.setOpLabelRev(PLMUtils.checkNullVal(rs.getString("LABEL_REV")));
				//searchData.setOpLabelRelease(PLMUtils.checkNullVal(rs.getString("LABEL_RELEASE")));
				Date lblReleaseDt = rs.getDate("LABEL_RELEASE");
				if(lblReleaseDt != null){
					String strlblReleaseDt = SIMPLE_DATE_FORMAT.format(lblReleaseDt);
					searchData.setOpLabelRelease(strlblReleaseDt);
					searchData.setOpLabelReleaseExl(lblReleaseDt);
				} else {
					searchData.setOpLabelRelease("");
				}
				
				searchData.setOpWbseId(PLMUtils.checkNullVal(rs.getString("WBSE_ID")));
				searchData.setOpPlpId(PLMUtils.checkNullVal(rs.getString("PLD_ID")));
				searchData.setOpDocumentId(PLMUtils.checkNullVal(rs.getString("DOCUMENT_ID")));
				
				searchData.setOpGenTitleFlag(PLMUtils.checkNullVal(rs.getString("GENERAL_TITLE_FLAG")));
				searchData.setOpDetTitleFlag(PLMUtils.checkNullVal(rs.getString("DETAILED_TITLE_FLAG")));
				
				
				
			return 	searchData;
		}
	}

}
