/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhereUsedData.java
 * @Creation date: 23-July-2011
 * @version 1.0
 * @author :Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;


public class PLMImpactAnalysisData {

	/**
	  * Holds the immediateParentId
	  */
	private String immediateParentId;
	/**
	  * Holds the immediateParent
	  */
	private String immediateParent;
	/**
	  * Holds the immediateParentRev
	  */
	private String immediateParentRev;
	/**
	  * Holds the topLvlParentNm
	  */
	private String topLvlParentNm;

	/**
	  * Holds the lgclFtrNm
	  */
	private String lgclFtrNm;

	/**
	  * Holds the lgclFtrType
	  */
	private String lgclFtrType;

	/**
	  * Holds the prdtCnfgNm
	  */
	private String prdtCnfgNm;

	/**
	  * Holds the topLvlParentNm
	  */
	private String hwBldNm;

	/**
	  * Holds the hwBldState
	  */
	private String hwBldState;

	/**
	  * Holds the bldRelDate
	  */
	private String bldRelDate;

	/**
	  * Holds the plantNm
	  */
	private String plantNm;
	/**
	  * Holds the partId
	  */
	private String partId;
	/**
	  * Holds the partNm
	  */
	private String partNm;
	/**
	  * Holds the lvl
	  */
	private String lvl;
	/**
	  * Holds the dfsOrdr
	  */
	private String dfsOrdr;
	/**
	 * @return the immediateParentId
	 */
	public String getImmediateParentId() {
		return immediateParentId;
	}
	/**
	 * @param immediateParentId the immediateParentId to set
	 */
	public void setImmediateParentId(String immediateParentId) {
		this.immediateParentId = immediateParentId;
	}
	/**
	 * @return the immediateParent
	 */
	public String getImmediateParent() {
		return immediateParent;
	}
	/**
	 * @param immediateParent the immediateParent to set
	 */
	public void setImmediateParent(String immediateParent) {
		this.immediateParent = immediateParent;
	}
	/**
	 * @return the immediateParentRev
	 */
	public String getImmediateParentRev() {
		return immediateParentRev;
	}
	/**
	 * @param immediateParentRev the immediateParentRev to set
	 */
	public void setImmediateParentRev(String immediateParentRev) {
		this.immediateParentRev = immediateParentRev;
	}
	/**
	 * @return the topLvlParentNm
	 */
	public String getTopLvlParentNm() {
		return topLvlParentNm;
	}
	/**
	 * @param topLvlParentNm the topLvlParentNm to set
	 */
	public void setTopLvlParentNm(String topLvlParentNm) {
		this.topLvlParentNm = topLvlParentNm;
	}
	/**
	 * @return the lgclFtrNm
	 */
	public String getLgclFtrNm() {
		return lgclFtrNm;
	}
	/**
	 * @param lgclFtrNm the lgclFtrNm to set
	 */
	public void setLgclFtrNm(String lgclFtrNm) {
		this.lgclFtrNm = lgclFtrNm;
	}
	/**
	 * @return the lgclFtrType
	 */
	public String getLgclFtrType() {
		return lgclFtrType;
	}
	/**
	 * @param lgclFtrType the lgclFtrType to set
	 */
	public void setLgclFtrType(String lgclFtrType) {
		this.lgclFtrType = lgclFtrType;
	}
	/**
	 * @return the prdtCnfgNm
	 */
	public String getPrdtCnfgNm() {
		return prdtCnfgNm;
	}
	/**
	 * @param prdtCnfgNm the prdtCnfgNm to set
	 */
	public void setPrdtCnfgNm(String prdtCnfgNm) {
		this.prdtCnfgNm = prdtCnfgNm;
	}
	/**
	 * @return the hwBldNm
	 */
	public String getHwBldNm() {
		return hwBldNm;
	}
	/**
	 * @param hwBldNm the hwBldNm to set
	 */
	public void setHwBldNm(String hwBldNm) {
		this.hwBldNm = hwBldNm;
	}
	/**
	 * @return the hwBldState
	 */
	public String getHwBldState() {
		return hwBldState;
	}
	/**
	 * @param hwBldState the hwBldState to set
	 */
	public void setHwBldState(String hwBldState) {
		this.hwBldState = hwBldState;
	}
	/**
	 * @return the bldRelDate
	 */
	public String getBldRelDate() {
		return bldRelDate;
	}
	/**
	 * @param bldRelDate the bldRelDate to set
	 */
	public void setBldRelDate(String bldRelDate) {
		this.bldRelDate = bldRelDate;
	}
	/**
	 * @return the plantNm
	 */
	public String getPlantNm() {
		return plantNm;
	}
	/**
	 * @param plantNm the plantNm to set
	 */
	public void setPlantNm(String plantNm) {
		this.plantNm = plantNm;
	}
	/**
	 * @return the partId
	 */
	public String getPartId() {
		return partId;
	}
	/**
	 * @param partId the partId to set
	 */
	public void setPartId(String partId) {
		this.partId = partId;
	}
	/**
	 * @return the partNm
	 */
	public String getPartNm() {
		return partNm;
	}
	/**
	 * @param partNm the partNm to set
	 */
	public void setPartNm(String partNm) {
		this.partNm = partNm;
	}
	/**
	 * @return the lvl
	 */
	public String getLvl() {
		return lvl;
	}
	/**
	 * @param lvl the lvl to set
	 */
	public void setLvl(String lvl) {
		this.lvl = lvl;
	}
	/**
	 * @return the dfsOrdr
	 */
	public String getDfsOrdr() {
		return dfsOrdr;
	}
	/**
	 * @param dfsOrdr the dfsOrdr to set
	 */
	public void setDfsOrdr(String dfsOrdr) {
		this.dfsOrdr = dfsOrdr;
	}
	
}