 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileNamePLMPwiUserData.java
 * @Creation date: 16-March-2015
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.data;

import java.io.Serializable;
import java.util.List;

public class PLMPwiGroupsData implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int userGroupId;
	
	private String userGroupName;
	
	private String userGrpDisplayName;
	
	private List<String> userGroupQueries;

	public int getUserGroupId() {
		return userGroupId;
	}

	public void setUserGroupId(int userGroupId) {
		this.userGroupId = userGroupId;
	}
	
	public String getUserGroupName() {
		return userGroupName;
	}

	public void setUserGroupName(String userGroupName) {
		this.userGroupName = userGroupName;
	}

	public String getUserGrpDisplayName() {
		return userGrpDisplayName;
	}

	public void setUserGrpDisplayName(String userDisplayName) {
		this.userGrpDisplayName = userDisplayName;
	}

	public List<String> getUserGroupQueries() {
		return userGroupQueries;
	}

	public void setUserGroupQueries(List<String> userGroupQueries) {
		this.userGroupQueries = userGroupQueries;
	}
	
	
	

}
