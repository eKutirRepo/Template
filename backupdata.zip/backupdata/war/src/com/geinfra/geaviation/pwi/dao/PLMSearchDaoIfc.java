/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMSearchDaoIfc.java
 * @Creation date: 24-Oct-2010
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMCostChngData;
import com.geinfra.geaviation.pwi.data.PLMDrawingSearchData;
import com.geinfra.geaviation.pwi.data.PLMSearchData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

/**
 * PLMSearchDaoIfc is the DAO interface used for PLM document search menu
 */

public interface PLMSearchDaoIfc {
	
	/**
	 * This method is used for getStateDropDownvalues
	 * 
	 * @param stateDropDownValues
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getStateDropDownvalues()
			throws PLMCommonException;
	/**
	 * This method is used for getSearchDetails
	 * 
	 * @param searchData
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMSearchData> getSearchDetails(PLMSearchData searchData)
			throws PLMCommonException;

	/**

	 * 
	 * @param docnum
	 * @param docname
	 * @param docrev
	 * @return 
	 */
	/*public PLMSearchData itemDetails(String docnum, String docname,
			String docrev) throws PLMCommonException;
	*/
	/**
	 * This method is used for getSearchDetails
	 * 
	 * This method is used for getStateDropDownvalues
	 * @param searchData
	 * @return List
	 */
	public List<PLMDrawingSearchData> getSearchDetails(
			PLMDrawingSearchData searchData) throws PLMCommonException;

	/**
	 * This method is used for getDrawingData
	 * 
	 * @param searchData
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMDrawingSearchData> getDrawingData(
			PLMDrawingSearchData searchData) throws PLMCommonException;

  //Newly added for Cost Change summary
	/**
     * This method is used for getValidContractData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMCostChngData> getValidContractData(String contractNameList) throws PLMCommonException;

	/**
	 * This method is used for getCostChngReport
	 * 
	 * @param ContractName
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMCostChngData> getCostChngReport(String ContractName) throws PLMCommonException;
	
	/**
	 * This method is used to display selected Items
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> displaySelectedItems() throws PLMCommonException;

}
