package com.geinfra.geaviation.pwi.bean;

import java.util.ArrayList;
import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.QueryAccessException;
import com.geinfra.geaviation.pwi.context.PWiContext;
import com.geinfra.geaviation.pwi.json.JsonBuilder;
import com.geinfra.geaviation.pwi.json.JsonUtil;
import com.geinfra.geaviation.pwi.model.PWiObjectTypeVO;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.model.PWiQueryNoXmlVO;
import com.geinfra.geaviation.pwi.model.QiOptionsVO;
import com.geinfra.geaviation.pwi.service.ObjectTypeService;
import com.geinfra.geaviation.pwi.service.QiService;
import com.geinfra.geaviation.pwi.service.QueriesService;
import com.geinfra.geaviation.pwi.service.QueryGroupService;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;
import com.geinfra.geaviation.pwi.util.collections.PWiCollectionUtil;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Jan 6, 2012 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : QuickIntelligenceBean - bean for Quick Intelligence
 * 
 * --------------------------------------------------------------
 */
public class QiBean {
	// injected services
	private ObjectTypeService objectTypeService;
	private QueriesService queriesService;
	private QueryGroupService queryGroupService;
	private QiService qiService;

	private String qiOptionsJson;
	private String queriesJson;
	private String groupsJson;
	private String userInfoJson;
	private List<PWiObjectTypeVO> objectTypes;
	private String selectedObjectTypeId;
	private String objectValue;
	

	public void setObjectTypeService(ObjectTypeService objectTypeService) {
		this.objectTypeService = objectTypeService;
	}
	
	public void setQueriesService(QueriesService queriesService) {
		this.queriesService = queriesService;
	}

	public void setQueryGroupService(QueryGroupService queryGroupService) {
		this.queryGroupService = queryGroupService;
	}

	public void setQiService(QiService qiService) {
		this.qiService = qiService;
	}
	
	/*
	 * commented on 31-Oct-2014 as per nimble report
	private UserInfoPortalUtil userInfoPortalUtil;
	
	public void setUserInfoPortalUtil(
			UserInfoPortalUtil userInfoPortalUtil) {
		this.userInfoPortalUtil = userInfoPortalUtil;
	}
	 */
	public void init(String objectTypeName, String anObjectValue,
			List<String> queryIds, List<String> collapseResults)
			throws PWiException, QueryAccessException {
		String sso = PWiContext.getCurrentInstance().getUserSso();

		PWiObjectTypeVO objectType = objectTypeService
				.getObjectTypeByName(objectTypeName);

		this.qiOptionsJson = getQiOptionsJsonHelper(objectType, queryIds,
				collapseResults, sso);
		this.selectedObjectTypeId = objectType.getObjTypSeqId().toString();

		this.objectValue = anObjectValue;
	}

	public String getQiOptionsJson() throws PWiException, QueryAccessException {
		if (qiOptionsJson == null) {
			String sso = PWiContext.getCurrentInstance().getUserSso();
			this.qiOptionsJson = getQiOptionsJsonHelper(null, null, null, sso);
		}
		return qiOptionsJson;
	}

	public String getObjectValue() {
		JsonBuilder builder = new JsonBuilder();
		builder.startObject();
		builder.addStringProperty("objectValue", objectValue);
		builder.endObject();
		return builder.toString();
	}

	public String getSelectedObjectTypeId() throws PWiException {
		if (selectedObjectTypeId == null) {
			// default to first object type
			List<PWiObjectTypeVO> dataTypes = getObjectTypes(); 
			selectedObjectTypeId = dataTypes.size() > 0 ? dataTypes.get(0).getObjTypSeqId().toString() : "";
		}

		JsonBuilder builder = new JsonBuilder();
		builder.startObject();
		builder.addStringProperty("id", selectedObjectTypeId);
		builder.endObject();
		return builder.toString();
	}

	public String getQueriesJson() throws PWiException {
		if (queriesJson == null) {
			List<PWiQueryNoXmlVO> queries = queriesService.getQueries();
			queriesJson = JsonUtil.listToJsonStatic(queries);
		}
		return queriesJson;
	}

	private List<PWiObjectTypeVO> getObjectTypes() throws PWiException {
		if (objectTypes == null) {
			objectTypes = objectTypeService.getPWiQiObjectTypes();
			//added by subrajit
			PWiObjectTypeVO pwiVo = new PWiObjectTypeVO();
			pwiVo.setObjTypNm("Query A");
			pwiVo.setObjTypDesc("Query A desc");
			pwiVo.setObjTypSeqId(1);
			objectTypes.add(pwiVo);
		}
		return objectTypes;
	}

	public String getObjectTypesJson() throws PWiException {
		List<PWiObjectTypeVO> theObjectTypes = getObjectTypes();
		return JsonUtil.listToJsonStatic(theObjectTypes);
	}

	public String getGroupsJson() {
		if (groupsJson == null) {
			List<PWiQueryGroupVO> groups = queryGroupService
					.getAllQueryGroups();
			groupsJson = JsonUtil.listToJsonStatic(groups);
		}
		return groupsJson;
	}

	public String getUserInfoJson() throws PWiException {
		if (userInfoJson == null) {
			String sso = PWiContext.getCurrentInstance().getUserSso();
			boolean usPerson = UserInfoPortalUtil.getInstance().isUsPerson();
			boolean geEmployee = UserInfoPortalUtil.getInstance().isGePerson();
			List<PWiQueryGroupVO> groups = queryGroupService
					.getUserGroups(sso);

			JsonBuilder builder = new JsonBuilder();
			builder.startObject();
			builder.startArrayProperty("groupIds");
			for (PWiQueryGroupVO group : groups) {
				Integer groupId = group.getQueryGroupId();
				builder.addStringElement(groupId);
			}
			builder.endArray();
			builder.addBooleanProperty("usPerson", usPerson);
			builder.addBooleanProperty("geEmployee", geEmployee);
			builder.addStringProperty("ssoId", sso);
			builder.endObject();
			
			userInfoJson = builder.toString();
		}
		return userInfoJson;
	}

	private String getQiOptionsJsonHelper(PWiObjectTypeVO objectType,
			List<String> requestedDefaultQueries,
			List<String> requestedCollapseOptions, String sso)
			throws PWiException {
		// get QI options
		List<QiOptionsVO> qiOptions = qiService.getQiOptions(sso);

		// apply overrides if specified
		if (objectType != null && requestedDefaultQueries != null) {

			// determine default selected object type
			Integer defaultObjectTypeOverride = objectType.getObjTypSeqId();

			// get requested selected query overrides
			List<Integer> defaultSelectedQueriesOverride = new ArrayList<Integer>();
			for (String queryId : requestedDefaultQueries) {
				defaultSelectedQueriesOverride.add(Integer.valueOf(queryId));
			}

			// get requested collapse result overrides
			List<Boolean> defaultCollapseResultOverride = null;
			if (requestedCollapseOptions != null) {
				defaultCollapseResultOverride = new ArrayList<Boolean>();
				for (String requestedCollapseOption : requestedCollapseOptions) {
					defaultCollapseResultOverride.add(
							Boolean.valueOf(requestedCollapseOption));
				}
			}

			// apply overrides
			List<QiOptionsVO> qiOptionsForObjectType = PWiCollectionUtil
					.getInstance().filter(qiOptions,
							new QiOptionsVO.HasObjectType(defaultObjectTypeOverride));
			for (QiOptionsVO qiOption : qiOptionsForObjectType) {
				int index = defaultSelectedQueriesOverride.indexOf(qiOption
						.getQueryId());
				if (index >= 0) {
					// override
					qiOption.setQuerySelected(true);
					if (requestedCollapseOptions != null) {
						qiOption.setCollapseResult(defaultCollapseResultOverride
										.get(index).booleanValue());
					}
					qiOption.setOrderIndex(Integer.valueOf(index));
				} else {
					// clear
					qiOption.setQuerySelected(false);
					qiOption.setCollapseResult(false);
				}
			}
		}
		return JsonUtil.listToJsonStatic(qiOptions);
	}
}
