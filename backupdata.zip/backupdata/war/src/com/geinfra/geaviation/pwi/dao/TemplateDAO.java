package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.TemplateVO;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Sep 27, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Data access object interface for accessing excel templates.
 * 
 * Revision Log Sep 27, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public interface TemplateDAO {
	public static String COLUMN_TEMPLATE_ID = "template_seq_id";
	public static String COLUMN_TEMPLATE_NAME = "template_nm";
	public static String COLUMN_ENABLED = "template_enabled_ind";
	public static String COLUMN_EXCEL_FILE_PATH = "template_excl_fl_pth";
	public static String COLUMN_QUERY_ID = "qry_seq_id";
	public static String COLUMN_CREATED_DATE = "crtn_dt";
	public static String COLUMN_CREATED_BY = "crtd_by";
	public static String COLUMN_LAST_UPDATE_DATE = "lst_updt_dt";
	public static String COLUMN_LAST_UPDATED_BY = "lst_updtd_by";

	/**
	 * Creates a template record in the database.
	 * 
	 * @param templateName
	 * @param enabled
	 * @param excelFilePath
	 * @param queryId
	 * @param sso
	 *            the SSO of the user who created the template
	 * @return the template ID of the newly created template record in the
	 *         database
	 * @throws PWiException 
	 */
	public Integer createTemplate(String templateName, boolean enabled,
			String excelFilePath, int queryId, String sso) throws PWiException;

	/**
	 * Updates a template record in the database. Take care that all arguments
	 * are specified.
	 * 
	 * @param template
	 * @param userId
	 */
	public void updateTemplate(TemplateVO template, String userId);

	/**
	 * Deletes the template record with the specified template ID.
	 * 
	 * @param templateId
	 */
	public void deleteTemplate(Integer templateId);

	/**
	 * Retrieves all templates associated with the specified query ID.
	 * 
	 * @param queryId
	 * @return The list of templates associated with the specified query ID
	 */
	public List<TemplateVO> getTemplatesForQuery(Integer queryId);

	/**
	 * Retrieves the template with the specified template ID.
	 * 
	 * @param templateId
	 * @return The template with the specified template ID.
	 */
	public TemplateVO getTemplateById(Integer templateId);
}
