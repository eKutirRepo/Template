package com.geinfra.geaviation.pwi.bean;

import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.PWiUserCustomQueryVO;
import com.geinfra.geaviation.pwi.model.QueryResultColumn;
import com.geinfra.geaviation.pwi.util.FilePathUtil;
import com.geinfra.geaviation.pwi.util.FileUtil;
import com.geinfra.geaviation.pwi.util.PWiConstants;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 5, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : QueryResultBean - Subscription result representation.
 * 
 * Revision Log Aug 5, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class SubscriptionResultBean extends BaseBean {
	private PWiUserCustomQueryVO selectedCustQry;
	private List<QueryResultColumn> columns;
	private List<List<String>> data;
	private List<List<String>> info;
	private String selectedFileType;

	public SubscriptionResultBean() {
		selectedCustQry = new PWiUserCustomQueryVO();
	}

	public String getPreviousResultLink() {
		int lastDash = StringUtils.lastIndexOf(selectedCustQry
				.getPrrQryRsltFlPthTxt(), "-");
		String ret = "Previous Results - "
				+ StringUtils.substring(
						selectedCustQry.getPrrQryRsltFlPthTxt(), lastDash + 1,
						StringUtils.indexOf(selectedCustQry
								.getCurrQryRsltFlPthTxt(), "_"));
		return ret;
	}

	public void downloadPreviousResult() throws PWiException {
		String fileName = selectedCustQry.getPrrQryRsltFlPthTxt();
		FileUtil.getInstance().downloadFile(
				fileName,
				FilePathUtil.getInstance().subscriptionPath(
						FilePathUtil.getInstance().appDataMountPathDefault(),
						selectedCustQry.getUsrSsoId()), false);
	}

	public String getCurrentResultLink() {
		String ret = "Current Results - "
				+ StringUtils.substring(selectedCustQry
						.getCurrQryRsltFlPthTxt(), StringUtils.lastIndexOf(
						selectedCustQry.getCurrQryRsltFlPthTxt(), "-") + 1,
						StringUtils.indexOf(selectedCustQry
								.getCurrQryRsltFlPthTxt(), "_"));
		return ret;
	}

	public void downloadCurrentResult() throws PWiException {
		String fileName = selectedCustQry.getCurrQryRsltFlPthTxt();
		FileUtil.getInstance().downloadFile(
				fileName,
				FilePathUtil.getInstance().subscriptionPath(
						FilePathUtil.getInstance().appDataMountPathDefault(),
						selectedCustQry.getUsrSsoId()), false);
	}

	public void downloadComparison() throws PWiException {
		String fileName = selectedCustQry.getCmprsnRsltFlPthTxt();
		if (StringUtils.equals(PWiConstants.PDF, selectedFileType)) {
			FileUtil.getInstance().writePDFQueryresults(
					fileName,
					FilePathUtil.getInstance().onlineModePath(
							FilePathUtil.getInstance()
									.appDataMountPathDefault()), columns, data, info,
					selectedCustQry.getCstmQryNm());
		} else if (StringUtils.equals(PWiConstants.EXCEL, selectedFileType)) {
			FileUtil.getInstance().writeEXCELQueryResults(
					fileName,
					FilePathUtil.getInstance().onlineModePath(
							FilePathUtil.getInstance()
									.appDataMountPathDefault()), columns, data, info);
		} else if (StringUtils.equals(PWiConstants.CSV, selectedFileType)) {
			FileUtil.getInstance().writeCSVQueryresults(
					fileName,
					FilePathUtil.getInstance().onlineModePath(
							FilePathUtil.getInstance()
									.appDataMountPathDefault()), columns, data);
		}
	}

	public PWiUserCustomQueryVO getSelectedCustQry() {
		return selectedCustQry;
	}

	public void setSelectedCustQry(PWiUserCustomQueryVO selectedCustQry) {
		this.selectedCustQry = selectedCustQry;
	}

	public List<QueryResultColumn> getColumns() {
		return columns;
	}

	public void setColumns(List<QueryResultColumn> columns) {
		this.columns = columns;
	}

	public List<List<String>> getData() {
		return data;
	}

	public void setData(List<List<String>> data) {
		this.data = data;
	}
	
	public List<List<String>> getInfo() {
		return info;
	}

	public void setInfo(List<List<String>> info) {
		this.info = info;
	}

	public String getSelectedFileType() {
		return selectedFileType;
	}

	public void setSelectedFileType(String selectedFileType) {
		this.selectedFileType = selectedFileType;
	}
}
