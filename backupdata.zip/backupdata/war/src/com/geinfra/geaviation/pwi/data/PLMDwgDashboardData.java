/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMDwgDashboardData.java
 * @Creation date: 4-April-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMDwgDashboardData {
	
	/**
	  * Holds the tskTyp
	  */
	private String tskTyp;
	/**
	  * Holds the group
	  */
	private String group;
	/**
	  * Holds the percTskCmpl
	  */
	private double percTskCmpl;
	/**
	  * Holds the percTskOtd
	  */
	private double percTskOtd;
	/**
	  * Holds the numTskLate
	  */
	private String numTskLate;
	/**
	  * Holds the numTskToGo
	  */
	private String numTskToGo;
	/**
	  * Holds the numTsk30DyAhead
	  */
	private String numTsk30DyAhead;
	/**
	  * Holds the closedLate
	  */
	private String closedLate;
	/**
	  * Holds the closedOnTime
	  */
	private String closedOnTime;
	/**
	  * Holds the sumOfDelvs
	  */
	private String sumOfDelvs;
	/**
	  * Holds the selectedGroup
	  */
	
	private String selectedGroup;
	/**
	  * Holds the selectedTaskType
	  */
	private String selectedTaskType;
	/**
	  * Holds the selectedTaskStatus
	  */
	private String selectedTaskStatus;
	/**
	  * Holds the taskType
	  */
	
	
	private String taskType;
	/**
	  * Holds the bussGroup
	  */
	private String bussGroup;
	/**
	  * Holds the taskStatus
	  */
	private String taskStatus;
	/**
	  * Holds the contractName
	  */
	private String contractName;
	/**
	  * Holds the projectName
	  */
	private String projectName;
	/**
	  * Holds the projectDescription
	  */
	private String projectDescription;
	/**
	  * Holds the geActivityCode
	  */
	private String geActivityCode;
	/**
	  * Holds the state
	  */
	private String state;
	/**
	  * Holds the estimatedFinishDte
	  */
	private String estimatedFinishDte;
	/**
	  * Holds the cstmrNeedDte
	  */
	private String cstmrNeedDte;
	/**
	  * Holds the clinInitialDeliveryDte
	  */
	private String clinInitialDeliveryDte;
	/**
	  * Holds the actualFinishDte
	  */
	private String actualFinishDte;
	/**
	  * Holds the ownerName
	  */
	private String ownerName;
	/**
	  * Holds the taskOwnr
	  */
	private String taskOwnr;
	/**
	  * Holds the geMfggDeliverableIndr
	  */
	private String geMfggDeliverableIndr;
	/**
	  * Holds the geTaskResponsibleUnit
	  */
	private String geTaskResponsibleUnit;
	/**
	  * Holds the geVoucherFundingSource
	  */
	private String geVoucherFundingSource;
	/**
	  * Holds the tskTypFull
	  */
	
    private String tskTypFull;
    /**
	  * Holds the tskTypDesc1
	  */
    private String tskTypDesc1;
    /**
	  * Holds the tskTypDesc2
	  */
    private String tskTypDesc2;
    /**
	  * Holds the gtFlag
	  */
    
	private String gtFlag="";
	/**
	  * Holds the gtGenFlag
	  */
	private String gtGenFlag="";
	/**
	  * Holds the stFlag
	  */
	private String stFlag="";
	/**
	  * Holds the stGenFlag
	  */
	private String stGenFlag="";
    

	
	

	
	
	/**
	 * @return the tskTyp
	 */
	public String getTskTyp() {
		return tskTyp;
	}
	/**
	 * @param tskTyp the tskTyp to set
	 */
	public void setTskTyp(String tskTyp) {
		this.tskTyp = tskTyp;
	}
	/**
	 * @return the group
	 */
	public String getGroup() {
		return group;
	}
	/**
	 * @param group the group to set
	 */
	public void setGroup(String group) {
		this.group = group;
	}
	/**
	 * @return the percTskCmpl
	 */
	public double getPercTskCmpl() {
		return percTskCmpl;
	}
	/**
	 * @param percTskCmpl the percTskCmpl to set
	 */
	public void setPercTskCmpl(double percTskCmpl) {
		this.percTskCmpl = percTskCmpl;
	}
	/**
	 * @return the percTskOtd
	 */
	public double getPercTskOtd() {
		return percTskOtd;
	}
	/**
	 * @param percTskOtd the percTskOtd to set
	 */
	public void setPercTskOtd(double percTskOtd) {
		this.percTskOtd = percTskOtd;
	}
	/**
	 * @return the numTskLate
	 */
	public String getNumTskLate() {
		return numTskLate;
	}
	/**
	 * @param numTskLate the numTskLate to set
	 */
	public void setNumTskLate(String numTskLate) {
		this.numTskLate = numTskLate;
	}
	/**
	 * @return the numTskToGo
	 */
	public String getNumTskToGo() {
		return numTskToGo;
	}
	/**
	 * @param numTskToGo the numTskToGo to set
	 */
	public void setNumTskToGo(String numTskToGo) {
		this.numTskToGo = numTskToGo;
	}
	/**
	 * @return the numTsk30DyAhead
	 */
	public String getNumTsk30DyAhead() {
		return numTsk30DyAhead;
	}
	/**
	 * @param numTsk30DyAhead the numTsk30DyAhead to set
	 */
	public void setNumTsk30DyAhead(String numTsk30DyAhead) {
		this.numTsk30DyAhead = numTsk30DyAhead;
	}
	/**
	 * @return the closedLate
	 */
	public String getClosedLate() {
		return closedLate;
	}
	/**
	 * @param closedLate the closedLate to set
	 */
	public void setClosedLate(String closedLate) {
		this.closedLate = closedLate;
	}
	/**
	 * @return the closedOnTime
	 */
	public String getClosedOnTime() {
		return closedOnTime;
	}
	/**
	 * @param closedOnTime the closedOnTime to set
	 */
	public void setClosedOnTime(String closedOnTime) {
		this.closedOnTime = closedOnTime;
	}
	/**
	 * @return the selectedGroup
	 */
	public String getSelectedGroup() {
		return selectedGroup;
	}
	/**
	 * @param selectedGroup the selectedGroup to set
	 */
	public void setSelectedGroup(String selectedGroup) {
		this.selectedGroup = selectedGroup;
	}
	/**
	 * @return the selectedTaskType
	 */
	public String getSelectedTaskType() {
		return selectedTaskType;
	}
	/**
	 * @param selectedTaskType the selectedTaskType to set
	 */
	public void setSelectedTaskType(String selectedTaskType) {
		this.selectedTaskType = selectedTaskType;
	}
	/**
	 * @return the selectedTaskStatus
	 */
	public String getSelectedTaskStatus() {
		return selectedTaskStatus;
	}
	/**
	 * @param selectedTaskStatus the selectedTaskStatus to set
	 */
	public void setSelectedTaskStatus(String selectedTaskStatus) {
		this.selectedTaskStatus = selectedTaskStatus;
	}
	/**
	 * @return the taskType
	 */
	public String getTaskType() {
		return taskType;
	}
	/**
	 * @param taskType the taskType to set
	 */
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	/**
	 * @return the bussGroup
	 */
	public String getBussGroup() {
		return bussGroup;
	}
	/**
	 * @param bussGroup the bussGroup to set
	 */
	public void setBussGroup(String bussGroup) {
		this.bussGroup = bussGroup;
	}
	/**
	 * @return the taskStatus
	 */
	public String getTaskStatus() {
		return taskStatus;
	}
	/**
	 * @param taskStatus the taskStatus to set
	 */
	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}
	/**
	 * @return the contractName
	 */
	public String getContractName() {
		return contractName;
	}
	/**
	 * @param contractName the contractName to set
	 */
	public void setContractName(String contractName) {
		this.contractName = contractName;
	}
	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}
	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	/**
	 * @return the projectDescription
	 */
	public String getProjectDescription() {
		return projectDescription;
	}
	/**
	 * @param projectDescription the projectDescription to set
	 */
	public void setProjectDescription(String projectDescription) {
		this.projectDescription = projectDescription;
	}
	/**
	 * @return the geActivityCode
	 */
	public String getGeActivityCode() {
		return geActivityCode;
	}
	/**
	 * @param geActivityCode the geActivityCode to set
	 */
	public void setGeActivityCode(String geActivityCode) {
		this.geActivityCode = geActivityCode;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the estimatedFinishDte
	 */
	public String getEstimatedFinishDte() {
		return estimatedFinishDte;
	}
	/**
	 * @param estimatedFinishDte the estimatedFinishDte to set
	 */
	public void setEstimatedFinishDte(String estimatedFinishDte) {
		this.estimatedFinishDte = estimatedFinishDte;
	}
	/**
	 * @return the cstmrNeedDte
	 */
	public String getCstmrNeedDte() {
		return cstmrNeedDte;
	}
	/**
	 * @param cstmrNeedDte the cstmrNeedDte to set
	 */
	public void setCstmrNeedDte(String cstmrNeedDte) {
		this.cstmrNeedDte = cstmrNeedDte;
	}
	/**
	 * @return the clinInitialDeliveryDte
	 */
	public String getClinInitialDeliveryDte() {
		return clinInitialDeliveryDte;
	}
	/**
	 * @param clinInitialDeliveryDte the clinInitialDeliveryDte to set
	 */
	public void setClinInitialDeliveryDte(String clinInitialDeliveryDte) {
		this.clinInitialDeliveryDte = clinInitialDeliveryDte;
	}
	/**
	 * @return the actualFinishDte
	 */
	public String getActualFinishDte() {
		return actualFinishDte;
	}
	/**
	 * @param actualFinishDte the actualFinishDte to set
	 */
	public void setActualFinishDte(String actualFinishDte) {
		this.actualFinishDte = actualFinishDte;
	}
	/**
	 * @return the ownerName
	 */
	public String getOwnerName() {
		return ownerName;
	}
	/**
	 * @param ownerName the ownerName to set
	 */
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	/**
	 * @return the taskOwnr
	 */
	public String getTaskOwnr() {
		return taskOwnr;
	}
	/**
	 * @param taskOwnr the taskOwnr to set
	 */
	public void setTaskOwnr(String taskOwnr) {
		this.taskOwnr = taskOwnr;
	}
	/**
	 * @return the geMfggDeliverableIndr
	 */
	public String getGeMfggDeliverableIndr() {
		return geMfggDeliverableIndr;
	}
	/**
	 * @param geMfggDeliverableIndr the geMfggDeliverableIndr to set
	 */
	public void setGeMfggDeliverableIndr(String geMfggDeliverableIndr) {
		this.geMfggDeliverableIndr = geMfggDeliverableIndr;
	}
	/**
	 * @return the geTaskResponsibleUnit
	 */
	public String getGeTaskResponsibleUnit() {
		return geTaskResponsibleUnit;
	}
	/**
	 * @param geTaskResponsibleUnit the geTaskResponsibleUnit to set
	 */
	public void setGeTaskResponsibleUnit(String geTaskResponsibleUnit) {
		this.geTaskResponsibleUnit = geTaskResponsibleUnit;
	}
	/**
	 * @return the geVoucherFundingSource
	 */
	public String getGeVoucherFundingSource() {
		return geVoucherFundingSource;
	}
	/**
	 * @param geVoucherFundingSource the geVoucherFundingSource to set
	 */
	public void setGeVoucherFundingSource(String geVoucherFundingSource) {
		this.geVoucherFundingSource = geVoucherFundingSource;
	}
	/**
	 * @return the gtFlag
	 */
	public String getGtFlag() {
		return gtFlag;
	}
	/**
	 * @param gtFlag the gtFlag to set
	 */
	public void setGtFlag(String gtFlag) {
		this.gtFlag = gtFlag;
	}
	/**
	 * @return the gtGenFlag
	 */
	public String getGtGenFlag() {
		return gtGenFlag;
	}
	/**
	 * @param gtGenFlag the gtGenFlag to set
	 */
	public void setGtGenFlag(String gtGenFlag) {
		this.gtGenFlag = gtGenFlag;
	}
	/**
	 * @return the stFlag
	 */
	public String getStFlag() {
		return stFlag;
	}
	/**
	 * @param stFlag the stFlag to set
	 */
	public void setStFlag(String stFlag) {
		this.stFlag = stFlag;
	}
	/**
	 * @return the stGenFlag
	 */
	public String getStGenFlag() {
		return stGenFlag;
	}
	/**
	 * @param stGenFlag the stGenFlag to set
	 */
	public void setStGenFlag(String stGenFlag) {
		this.stGenFlag = stGenFlag;
	}
	/**
	 * @return the tskTypFull
	 */
	public String getTskTypFull() {
		return tskTypFull;
	}
	/**
	 * @return the sumOfDelvs
	 */
	public String getSumOfDelvs() {
		return sumOfDelvs;
	}
	/**
	 * @param sumOfDelvs the sumOfDelvs to set
	 */
	public void setSumOfDelvs(String sumOfDelvs) {
		this.sumOfDelvs = sumOfDelvs;
	}
	/**
	 * @param tskTypFull the tskTypFull to set
	 */
	public void setTskTypFull(String tskTypFull) {
		this.tskTypFull = tskTypFull;
	}
	/**
	 * @return the tskTypDesc1
	 */
	public String getTskTypDesc1() {
		return tskTypDesc1;
	}
	/**
	 * @param tskTypDesc1 the tskTypDesc1 to set
	 */
	public void setTskTypDesc1(String tskTypDesc1) {
		this.tskTypDesc1 = tskTypDesc1;
	}
	/**
	 * @return the tskTypDesc2
	 */
	public String getTskTypDesc2() {
		return tskTypDesc2;
	}
	/**
	 * @param tskTypDesc2 the tskTypDesc2 to set
	 */
	public void setTskTypDesc2(String tskTypDesc2) {
		this.tskTypDesc2 = tskTypDesc2;
	}

	
}
