package com.geinfra.geaviation.pwi.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.model.PWiUserVO;
import com.geinfra.geaviation.pwi.model.QueriesVO;
import com.geinfra.geaviation.pwi.util.ColumnConstants;
import com.geinfra.geaviation.pwi.util.QueryConstants;
import com.geinfra.geaviation.pwi.util.QueryLoader;
import com.geinfra.geaviation.pwi.util.RoleInfoUtil;

/**
 * 
 * Project : Product Lifecycle Management Date Written : May 19, 2010 Security : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : QueryGroupDAOImpl
 * 
 * Revision Log May 19, 2010 | v1.0. --------------------------------------------------------------
 */

public class QueryGroupDAOImpl extends PWiDAO implements QueryGroupDAO {

	// TODO move up to service level?
	private TransactionTemplate transactionTemplate;


	public TransactionTemplate getTransactionTemplate() {

		return transactionTemplate;
	}


	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {

		this.transactionTemplate = transactionTemplate;
	}


	public void createQueryGroup(PWiQueryGroupVO creategroup) throws SQLException {

		final PWiQueryGroupVO createGroup = creategroup;
		creategroup.setQueryGroupId(1);
		transactionTemplate.execute(new TransactionCallback() {

			public Object doInTransaction(TransactionStatus ts) {

				String sql = QueryLoader.getQuery(QueryConstants.INSERT_GRP);

				Connection connection = null;
				CallableStatement statement = null;
				try {
					connection = getJdbcTemplate().getDataSource().getConnection();
					statement = connection.prepareCall(sql);

					// Set input parameters
					statement.setString(1, createGroup.getQueryGroupName());
					statement.setString(2, createGroup.getQueryGroupDescription());
					statement.setString(3, createGroup.isAlwaysShow() ? "Y" : "N");
					statement.setString(4, createGroup.getGroupDisplayName());

					// Set output parameters
					statement.registerOutParameter(5, Types.NUMERIC);

					// Execute query
					statement.execute();

					// Retrieve primary key
					Integer groupId = Integer.valueOf(statement.getInt(5));

					// Insert query-group relationship
					Object obj[] = new Object[2];
					obj[1] = groupId;
					for (QueriesVO q : createGroup.getQueriesList()) {
						obj[0] = q.getQueryId();
						getJdbcTemplate().update(QueryLoader.getQuery(QueryConstants.INSERT_GRP_QRY), obj);
					}

					return null;
				} catch (SQLException e) {
					// Throw runtime exception to trigger rollback
					throw new RuntimeException(e);
				} finally {
					// close everything
					try {
						if (statement != null) {
							statement.close();
						}
						if (connection != null) {
							connection.close();
						}
					} catch (SQLException e) {
						// Throw runtime exception to trigger rollback
						throw new RuntimeException(e);
					}
				}
			}
		}); // end anonymous inner TransactionCallback class; max length 60
	}


	/*
	 * public void createQueryGroup(PWiQueryGroupVO creategroup) throws SQLException {
	 * 
	 * final PWiQueryGroupVO createGroup = creategroup; creategroup.setQueryGroupId(1);
	 * transactionTemplate.execute(new TransactionCallback() { public Object
	 * doInTransaction(TransactionStatus ts) { String sql =
	 * QueryLoader.getQuery(QueryConstants.INSERT_GRP);
	 * 
	 * Connection connection = null; PreparedStatement statement = null; try { connection =
	 * getJdbcTemplate().getDataSource() .getConnection();
	 * 
	 * Object objGrp[] = new Object[5]; objGrp[0] = 1; objGrp[1] = createGroup.getQueryGroupName();
	 * objGrp[2] = createGroup.getQueryGroupDescription(); objGrp[3] = createGroup.isAlwaysShow() ?
	 * "Y" : "N"; objGrp[4] = createGroup.getGroupDisplayName(); getJdbcTemplate().update(
	 * QueryLoader.getQuery(QueryConstants.INSERT_GRP), objGrp);
	 * 
	 * // Insert query-group relationship Object obj[] = new Object[2]; obj[1] = 1; for (QueriesVO q
	 * : createGroup.getQueriesList()) { obj[0] = q.getQueryId(); getJdbcTemplate().update(
	 * QueryLoader.getQuery(QueryConstants.INSERT_GRP_QRY), obj); }
	 * 
	 * return null; } catch (SQLException e) { // Throw runtime exception to trigger rollback throw
	 * new RuntimeException(e); } finally { // close everything try { if ( statement != null) {
	 * statement.close(); } if (connection != null) { connection.close(); } } catch (SQLException e)
	 * { // Throw runtime exception to trigger rollback throw new RuntimeException(e); } } } }); //
	 * end anonymous inner TransactionCallback class; max length 60 }
	 */

	@SuppressWarnings("unchecked")
	public List<PWiQueryGroupVO> getAllQueryGroups() {
		
		String getAllGrpsQry = QueryLoader.getQuery(QueryConstants.GET_ALL_GRP_FR_RLTYP);
		
		String roleTypes = RoleInfoUtil.getAllRoleTypesForUser();
		getAllGrpsQry = getAllGrpsQry + roleTypes +")";
		

		return (List<PWiQueryGroupVO>) getJdbcTemplate().query(getAllGrpsQry, new PWiQueryGroupVORowMapper());
	}


	/**
	 * getUnmappedRolesList gets all roles from the table jbp_roles (@see
	 * RoleInfoUtil.getPWiRoles()) that are not currently in the pwi.PWi_QUERY_GROUP table. These
	 * are made available when creating a new group on the admin page.
	 */
	public List<String> getUnmappedRolesList() throws PWiException {

		List<String> rolesset = RoleInfoUtil.getInstance().getPWiRoles();
		Set<String> tmprolesset = new HashSet<String>();
		tmprolesset.addAll(rolesset);
		List<String> roleslist = new ArrayList<String>();
		List<PWiQueryGroupVO> allgroups = getAllQueryGroups();
		boolean rolespresent = false;
		for (Iterator<String> i = tmprolesset.iterator(); i.hasNext();) {
			String rol = i.next();
			for (Iterator<PWiQueryGroupVO> j = allgroups.iterator(); j.hasNext();) {
				PWiQueryGroupVO groupname = j.next();
				if ((rol.equals(groupname.getQueryGroupName()))) {
					rolespresent = true;
				}
			}
			if (rolespresent == true) {
				rolesset.remove(rol);
				rolespresent = false;
			}

		}
		for (Iterator<String> i = rolesset.iterator(); i.hasNext();) {
			roleslist.add(i.next());
		}
		return roleslist;

	}


	public void updateQueryGroup(PWiQueryGroupVO updategroup) {

		final PWiQueryGroupVO updateGroup = updategroup;
		transactionTemplate.execute(new TransactionCallback() {

			public Object doInTransaction(TransactionStatus ts) {

				Object update[] = new Object[5];
				update[0] = updateGroup.getQueryGroupName();
				update[1] = updateGroup.getQueryGroupDescription();
				update[2] = updateGroup.isAlwaysShow() ? "Y" : "N";
				update[3] = updateGroup.getGroupDisplayName();
				update[4] = updateGroup.getQueryGroupId();
				getJdbcTemplate().update(QueryLoader.getQuery(QueryConstants.UPDATE_NEW_GRP_DESC), update);

				Object delete[] = new Object[1];
				delete[0] = updateGroup.getQueryGroupId();
				getJdbcTemplate().update(QueryLoader.getQuery(QueryConstants.DELETE_EXT_RLTN), delete);

				Object insert[] = new Object[2];
				insert[1] = updateGroup.getQueryGroupId();
				for (QueriesVO q : updateGroup.getQueriesList()) {
					insert[0] = q.getQueryId();
					getJdbcTemplate().update(QueryLoader.getQuery(QueryConstants.INSERT_GRP_QRY), insert);
				}
				return null;
			}

		});

	}


	/**
	 * Code review requires JavaDoc comments on all public classes.
	 */
	public static class PWiQueryGroupVORowMapper implements ParameterizedRowMapper<PWiQueryGroupVO> {

		public PWiQueryGroupVO mapRow(ResultSet rs, int rowNum) throws SQLException {

			PWiQueryGroupVO queryGroupVO = new PWiQueryGroupVO();
			queryGroupVO.setQueryGroupId(Integer.valueOf(rs.getInt(ColumnConstants.QRY_GRP_SEQ_ID)));
			queryGroupVO.setQueryGroupName(rs.getString(ColumnConstants.QRY_GRP_NM));
			queryGroupVO.setQueryGroupDescription(rs.getString(ColumnConstants.QRY_GRP_DESC));
			queryGroupVO.setAlwaysShow("Y".equals(rs.getString(ColumnConstants.QRY_GRP_ALWYS_SHW)));
			queryGroupVO.setGroupDisplayName(rs.getString(ColumnConstants.QRY_GRP_DSPLY_NM));
			return queryGroupVO;
		}
	}


	@SuppressWarnings("unchecked")
	public List<PWiQueryGroupVO> findSelectedQueryGroups(Integer querySeqId) throws PWiException {

		List<PWiQueryGroupVO> result = null;
		Collection list = new ArrayList();
		// list.add(userId);
		list.add(querySeqId);
		try {
			final ParameterizedRowMapper<PWiQueryGroupVO> mapper = new FindSelectedGroupsMapper();
			result = (List<PWiQueryGroupVO>) getJdbcTemplate().query(QueryLoader.getQuery(QueryConstants.SELECTED_QUERY_GROUPS), list.toArray(), mapper);
			return result;
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}


	@SuppressWarnings("unchecked")
	public List<PWiUserVO> findSelectedQueryGroupsUsers(Integer querySeqId) throws PWiException {

		List<PWiUserVO> result = null;
		Collection list = new ArrayList();
		// list.add(userId);
		list.add(querySeqId);
		try {
			final ParameterizedRowMapper<PWiUserVO> mapper = new FindSelectedGroupsUsersMapper();
			result = (List<PWiUserVO>) getJdbcTemplate().query(QueryLoader.getQuery(QueryConstants.SELECTED_QUERY_GROUPS_USERS), list.toArray(), mapper);
			return result;
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}


	@SuppressWarnings("unchecked")
	public List<PWiQueryGroupVO> findSelectedGroupsForObjectType(Integer objTypSeqId) throws PWiException {

		List<PWiQueryGroupVO> result = null;
		Object[] parameter = {objTypSeqId};
		try {
			final ParameterizedRowMapper<PWiQueryGroupVO> mapper = new FindSelectedGroupsMapper();
			result = (List<PWiQueryGroupVO>) getJdbcTemplate().query(QueryLoader.getQuery(QueryConstants.SELECTED_GROUPS_FOR_TYPE), parameter, mapper);
			return result;
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}


	private static class FindSelectedGroupsMapper implements ParameterizedRowMapper<PWiQueryGroupVO> {

		public PWiQueryGroupVO mapRow(ResultSet rs, int rowNum) throws SQLException {

			PWiQueryGroupVO queryGroupVO = new PWiQueryGroupVO();
			queryGroupVO.setQueryGroupId(Integer.valueOf(rs.getInt("querygroupid")));
			queryGroupVO.setQueryGroupName(rs.getString("querygroupname"));
			return queryGroupVO;
		}
	}


	private static class FindSelectedGroupsUsersMapper implements ParameterizedRowMapper<PWiUserVO> {

		public PWiUserVO mapRow(ResultSet rs, int rowNum) throws SQLException {

			PWiUserVO queryGroupVO = new PWiUserVO();
			queryGroupVO.setSelectedGroupId(Integer.valueOf(rs.getInt("QRY_GRP_SEQ_ID")));
			queryGroupVO.setUserForSelectedGroup(rs.getString("QRY_GRP_NM"));
			queryGroupVO.setUserId(Integer.valueOf(rs.getInt("PWI_UID")));
			queryGroupVO.setUserNm(rs.getString("PWI_GIVENNAME"));
			queryGroupVO.setUserLastNm(rs.getString("PWI_FAMILYNAME"));
			queryGroupVO.setSso(rs.getString("PWI_UNAME"));
			queryGroupVO.setEmail(rs.getString("PWI_VIEWREALEMAIL"));
			queryGroupVO.setUserSelected(rs.getString("ACTIVE_USER").toUpperCase(Locale.US).equals("TRUE"));
			return queryGroupVO;
		}
	}


	@SuppressWarnings("unchecked")
	public List<PWiQueryGroupVO> getUserQueryGroups(String ssoId) {

		final PreparedStatementSetter setter = new ssoIdSetter(ssoId);

		return (List<PWiQueryGroupVO>) getJdbcTemplate().query(QueryLoader.getQuery(QueryConstants.GET_USER_GRP), setter, new PWiQueryGroupVORowMapper());
	}


	private static class ssoIdSetter implements PreparedStatementSetter {

		private String ssoId;


		public ssoIdSetter(String ssoId) {

			this.ssoId = ssoId;
		}


		public void setValues(PreparedStatement ps) throws SQLException {

			ps.setString(1, ssoId.toString());
		}
	}
	
	
	@SuppressWarnings("unchecked")
	public List<PWiQueryGroupVO> findSelectedGroupsForRole(
			Integer roleSeqId) throws PWiException {
		List<PWiQueryGroupVO> result = null;
		Object[] parameter = {roleSeqId};
		try {
			final ParameterizedRowMapper<PWiQueryGroupVO> mapper = new FindSelectedGroupsFrRoleMapper();
			result = (List<PWiQueryGroupVO>) getJdbcTemplate().query(
					QueryLoader.getQuery(QueryConstants.SELECTED_GROUPS_FOR_ROLE),
					parameter, mapper);
			return result;
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}

	private static class FindSelectedGroupsFrRoleMapper implements
			ParameterizedRowMapper<PWiQueryGroupVO> {
		public PWiQueryGroupVO mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PWiQueryGroupVO queryGroupVO = new PWiQueryGroupVO();
			queryGroupVO.setQueryGroupId(Integer.valueOf(rs.getInt("querygroupid")));
			queryGroupVO.setQueryGroupName(rs.getString("querygroupname"));
			return queryGroupVO;
		}
	}
}
