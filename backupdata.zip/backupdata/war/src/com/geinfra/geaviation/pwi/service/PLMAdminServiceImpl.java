/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMAdminServiceImpl.java
 * @Creation date: 17-Jul-2009
 * @version 1.0
 * @author Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.dao.PLMAdminDaoIfc;
import com.geinfra.geaviation.pwi.data.PLMAdminData;
import com.geinfra.geaviation.pwi.data.PLMAdminReportsData;
import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.data.PLMReportData;
import com.geinfra.geaviation.pwi.data.PLMRequestData;
import com.geinfra.geaviation.pwi.data.PLMSecurityMatrixData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMUtils;

/**
 * PLMAdminServiceImpl is the Service implementation class used for ICM
 * Administrator Menu.
 */
public class PLMAdminServiceImpl implements PLMAdminServiceIfc {
	/**
	 * Holds the Logger
	 */
	private static final Logger LOG = Logger
			.getLogger(PLMAdminServiceImpl.class);

	/**
	 * Folder Dao Object
	 */
	private PLMAdminDaoIfc adminDao;
	
	/**
	 * This method is used to get list of reports
	 * 
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMAdminData> getListOfReports() throws PLMCommonException {

		List<PLMAdminData> reports = getAdminDao().getListOfReports();

		return reports;
	}
	
	/**
	 * This method is used to get the names of the reports
	 * 
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMAdminReportsData> getReportNames() throws PLMCommonException {
//		List<PLMAdminReportsData> homePageReports = new ArrayList<PLMAdminReportsData>();
		List<PLMAdminReportsData> homePageReports = getAdminDao().getReportNames();
		if(!PLMUtils.isEmptyList(homePageReports)){
			LOG.info(homePageReports.get(0));
		}
		return homePageReports;
	}
	
	/**
	 * This method is used to add data to the reports
	 * 
	 * @param reportData
	 * @param sso_id
	 * @return String
	 * @throws PLMCommonException
	 */
	public String addReportData(PLMAdminReportsData reportData,String sso_id) throws PLMCommonException {
		String successIndicator;
		successIndicator = getAdminDao().addReportData(reportData,sso_id);
		return successIndicator;
	}
	/**
	 * This method is used to modify report data
	 * 
	 * @param reportData
	 * @param oldReportName
	 * @param sso_id
	 * @return String
	 * @throws PLMCommonException
	 */
	public String modifyReportData(PLMAdminReportsData reportData,String oldReportName,String sso_id) throws PLMCommonException {
		String successIndicator;
		successIndicator = getAdminDao().modifyReportData(reportData,oldReportName,sso_id);
		return successIndicator;
	}
	
	/**
	 * This method is used to delete report data
	 * 
	 * @param reportData
	 * @return String
	 * @throws PLMCommonException
	 */
	public String deleteReportData(String reportData) throws PLMCommonException {
		String successIndicator;
		successIndicator = getAdminDao().deleteReportData(reportData);
		return successIndicator;
	}
	

	/**
	 * This method is used to get the application details
	 * 
	 * @return PLMRequestData
	 * @throws PLMCommonException
	 */
	public PLMRequestData getAppDetails() throws PLMCommonException {
		PLMRequestData requestData = null;
		requestData = getAdminDao().getAppDetails();
		return requestData;
	}

	/**
	 * This method is used to request a new user
	 * 
	 * @return PLMRequestData 
	 * @throws PLMCommonException
	 */
	public PLMRequestData requestNewUser() throws PLMCommonException {
		PLMRequestData requestData = null;
		requestData = getAdminDao().requestNewUser();
		return requestData;
	}

	/**
	 * This method is used to save new user data
	 * 
	 * @param requestData
	 * @param groupIdReq
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<String>> saveNewUserRequest(
			PLMRequestData requestData, String groupIdReq,boolean isPwiUser) throws PLMCommonException {
		Map<String, List<String>> saveMap = null;
	
		/** Update User Info from IDM Start */
		if(!isPwiUser)
		{
			if (requestData.getReadOnlyAccsGrp()) {
				getAdminDao().grantAutoAccess(requestData,groupIdReq);
			}
		}
		
		/** Update User Info from IDM End */
		saveMap = (Map<String, List<String>>) getAdminDao().saveNewUserRequest(
				requestData,isPwiUser);

		return saveMap;
	}

	/**
	 * This method is used to get the change details
	 * 
	 * @param selectedVal
	 * @return PLMRequestData
	 * @throws PLMCommonException
	 */
	public PLMRequestData getChangedDetails(String selectedVal)
			throws PLMCommonException {
		PLMRequestData requestData = null;
		requestData = getAdminDao().getChangedDetails(selectedVal);
		return requestData;
	}

	/**
	 * This method is used to save the Maintain WS details
	 * 
	 * @param requestData
	 * @throws PLMCommonException
	 */
	public void saveAppDetails(PLMRequestData requestData)
			throws PLMCommonException {
		getAdminDao().saveAppDetails(requestData);
	}

	/**
	 * This method is used to save the Maintain WS details
	 * 
	 * @param maitnAnnouncements
	 * @throws PLMCommonException
	 */
	public void saveAncmtDetails(String maitnAnnouncements)
			throws PLMCommonException {
		getAdminDao().saveAncmtDetails(maitnAnnouncements);
	}

	/**
	 * This method is used to save the Maintain WS details
	 * 
	 * @param requestData
	 * @throws PLMCommonException
	 */
	public void saveIcmDetails(PLMRequestData requestData)
			throws PLMCommonException {
		getAdminDao().saveIcmDetails(requestData);
	}

	// Ended by Kishore

	/**
	 * @param userSSO
	 * @return PLMLoginData
	 * @throws PLMCommonException
	 */
	public PLMLoginData validateUserDetails(String userSSO)
			throws PLMCommonException {
		PLMLoginData userData = null;
		LOG
				.info("loginUserSSO in validUserDetails of PLMAdminServiceImpl >>>>>>>>>>"
						+ userSSO);
		userData = getAdminDao().validateUserDetails(userSSO);
		LOG
				.info("userData in validUserDetails of PLMAdminServiceImpl >>>>>>>>>>"
						+ userData);
		return userData;
	}

	/**
	 * @param userSSO
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMLoginData> getPermissionDetails(String userGrp)
			throws PLMCommonException {
		LOG
				.info("Group in getPermissionDetails of PLMAdminServiceImpl >>>>>>>>>>"
						+ userGrp);
		List<PLMLoginData> permissionData = null;
		permissionData = getAdminDao().getPermissionDetails(userGrp);
		return permissionData;
	}

	/**
	 * @param userSSO
	 * @return String
	 * @throws PLMCommonException
	 */
	public List<SelectItem> fetchUserGroups(String userSSO)
			throws PLMCommonException {
		List<SelectItem> userGroups = null;
		LOG
				.info("loginUserSSO in fetchUserGroups of PLMAdminServiceImpl >>>>>>>>>>"
						+ userSSO);
		userGroups = getAdminDao().fetchUserGroups(userSSO);
		return userGroups;
	}

	/**
	 * @param userSSO
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean addSystemLogEvent(String userSSO, String event)
			throws PLMCommonException {
		boolean isSubmit = false;
		LOG
				.info("loginUserSSO in addSystemLogEvent of PLMAdminServiceImpl >>>>>>>>>>"
						+ userSSO);
		isSubmit = getAdminDao().addSystemLogEvent(userSSO, event);
		LOG
				.info("isValid in addSystemLogEvent of PLMAdminServiceImpl >>>>>>>>>>"
						+ isSubmit);
		return isSubmit;
	}

	// Added for Dropdown Menu Edit and System Logs

	/**
	 * This method is used to get the system log contents
	 * 
	 * @param beginDate
	 * @param endDate
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMReportData> getSysLogContents(String beginDate,
			String endDate) throws PLMCommonException {
		List<PLMReportData> sysLogEvents = getAdminDao().getSysLogContents(
				beginDate, endDate);
		return sysLogEvents;
	}

	
	// Start OF Adminusecase

	/**
	 * @return java.util.List For getting the list of groups.
	 */
	public List<PLMAdminData> getListOfGroups() throws PLMCommonException {

		List<PLMAdminData> group = getAdminDao().getListOfGroups();

		return group;
	}
	
	
	/**
	 * This method is used to get list of user groups
	 * 
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getListOfUserGroups() throws PLMCommonException {

		List<SelectItem> attDataLst = getAdminDao().getListOfUserGroups();
		return attDataLst;
	}

	/**
	 * This method is used to get list of users
	 * 
	 * @param groupID
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMLoginData> getUserList(String groupID)
			throws PLMCommonException {

		List<PLMLoginData> userData = getAdminDao().getUserList(groupID);
		return userData;
	}

	/**
	 * This method is used to modify the users
	 * 
	 * @param ssoID
	 * @return PLMLoginData
	 * @throws PLMCommonException
	 */
	public PLMLoginData modifyUser(String ssoID) throws PLMCommonException {
		PLMLoginData userData = getAdminDao().modifyUser(ssoID);
		return userData;
	}

	/**
	 * This method is used to add the users
	 * 
	 * @return PLMLoginData
	 * @throws PLMCommonException
	 */
	public PLMLoginData addUser() throws PLMCommonException {
		PLMLoginData userData = getAdminDao().addUser();
		return userData;
	}

	/**
	 * This method is used to delete users
	 * 
	 * @param ssoID
	 * @param groupID
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean deleteUser(List<String> ssoID, String groupID)
			throws PLMCommonException {
		boolean result = getAdminDao().deleteUser(ssoID, groupID);
		return result;
	}

	/**
	 * This method is used to validate the users
	 * 
	 * @param ssoID
	 * @return PLMLoginData
	 * @throws PLMCommonException
	 */
	public PLMLoginData validateUser(String ssoID) throws PLMCommonException {
		PLMLoginData userData = getAdminDao().fetchIDMData(ssoID);
		return userData;
	}

	/**
	 * This method is used to group permissions
	 * 
	 * @param gruopId
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMSecurityMatrixData> getGroupPermissions(String gruopId)
			throws PLMCommonException {
		List<PLMSecurityMatrixData> groupDate = getAdminDao()
				.getGroupPermissions(gruopId);
		return groupDate;
	}

	/**
	 * This method is used to update the users
	 * 
	 * @param userDetails
	 * @param selectedPersons
	 * @param loggedUser
	 * @param flag
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean updateUser(PLMLoginData userDetails,
			List<String> selectedPersons, String loggedUser, boolean flag)
			throws PLMCommonException {
		boolean result = getAdminDao().updateUser(userDetails, selectedPersons,
				loggedUser, flag);
		return result;
	}

	/**
	 * 
	 * @param userDetails
	 * @param loggedUser
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean userAdd(PLMLoginData userDetails, String loggedUser)
			throws PLMCommonException {
		boolean result = getAdminDao().userAdd(userDetails, loggedUser);
		return result;
	}

	/**
	 * This method is used to add group
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMSecurityMatrixData> addGroup() throws PLMCommonException {
		List<PLMSecurityMatrixData> groupDate = getAdminDao().addGroup();
		return groupDate;
	}

	/**
	 * This method is used to delete group
	 * 
	 * @param groupID
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean deleteGroup(String groupID) throws PLMCommonException {
		boolean result = getAdminDao().deleteGroup(groupID);
		return result;
	}

	/**
	 * This method is used to update group
	 * 
	 * @param groupName
	 * @param groupDesc
	 * @param securityData
	 * @param grpFlag
	 * @param userSSo
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean updateGroup(String groupName, String groupDesc,
			ArrayList<PLMSecurityMatrixData> securityData, String grpFlag,
			String userSSo) throws PLMCommonException {

		boolean result = getAdminDao().updateGroup(groupName, groupDesc,
				securityData, grpFlag, userSSo);
		return result;
	}

	/**
	 * 
	 * @param groupName
	 * @param groupDesc
	 * @param securityData
	 * @param grpFlag
	 * @param userSSo
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean groupAdd(String groupName, String groupDesc,
			ArrayList<PLMSecurityMatrixData> securityData, String grpFlag,
			String userSSo) throws PLMCommonException {

		boolean result = getAdminDao().groupAdd(groupName, groupDesc,
				securityData, grpFlag, userSSo);
		return result;
	}

	/**
	 * This method is used to search user
	 * 
	 * @param searchSso
	 * @param searchFname
	 * @param searchLname
	 * @param status
	 * @param searchSso
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMLoginData> searchUser(String searchSso, String searchFname,
			String searchLname, String groupId, String status)
			throws PLMCommonException {

		List<PLMLoginData> userData = getAdminDao().searchUser(searchSso,
				searchFname, searchLname, groupId, status);

		return userData;
	}

	// End OF Adminusecase Methods

	/**
	 * @return the adminDao
	 */
	public PLMAdminDaoIfc getAdminDao() {
		return adminDao;
	}

	/**
	 * @param adminDao1
	 *            the adminDao to set
	 */
	public void setAdminDao(PLMAdminDaoIfc adminDao1) {
		this.adminDao = adminDao1;

	}

}
