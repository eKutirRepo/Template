/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMPartFamViewDaoIfc.java
 * @Creation date: 21-Oct-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import com.geinfra.geaviation.pwi.data.PLMInterfaceAttrData;
import com.geinfra.geaviation.pwi.data.PLMPddrData;
import com.geinfra.geaviation.pwi.data.PLMPddrSearchData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMPartFamViewDaoIfc {
	/**
	 * This method is used to search item explorer
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMPddrSearchData> searchItemExplorer() throws PLMCommonException;
	/**
	 * This method is used to get child for parent
	 * 
	 * @param mplNumber
	 * @param level
	 * @return HashMap
	 * @throws PLMCommonException
	 */
	public List<PLMPddrData> getChildForParent(
			List<String> mplNumber, String level) throws PLMCommonException;
	/**
	 * This methods is used for getChildForParentList
	 * 
	 * @param topmplNumber
	 * @param navigList
	 * @param level
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMPddrData> getChildForParentList(String topmplNumber,
			List<PLMPddrData> navigList, int level) throws PLMCommonException;
	
	/**
	 * This method is used to get PF details
	 * 
	 * @param nodeTitleP
	 * @return PLMPddrData
	 * @throws PLMCommonException
	 */
	public PLMPddrData getPFDetails(String nodeTitleP) throws PLMCommonException;
	/**
	 * This method is used to get Part Family Viewer Data
	 * 
	 * @param nodeTitleP
	 * @return PLMPddrData
	 * @throws PLMCommonException
	 */
	public Map<String,String> getPartFamilyAttrMasterResultList(String selectedPartFamily,String optionType,boolean hyperLinkFlg) throws PLMCommonException;


}
