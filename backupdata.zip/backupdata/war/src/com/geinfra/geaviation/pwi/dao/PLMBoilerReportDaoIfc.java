/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBoilerReportDaoIfc.java
 * @Creation date: 17-Feb-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMBoilerReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMBoilerReportDaoIfc {

	/**
	 * This method is used to getProjectNameAndTaskList
	 * @return 
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getProjectNameAndTaskList() throws PLMCommonException;
	/**
	 * This method is used to Generate backlog Report
	 * 
	 * @param selBacklogProjectName
	 * @param allOpenPrjName
	 * @param selBacklogTaskName
	 * @param allOpenTaskName
	 * @param selBacklogTaskState
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerReportData> generateBacklogAppReport(List<String> selBacklogProjectName, boolean allOpenPrjName,List<String> selBacklogTaskName, boolean allOpenTaskName,List<String> selBacklogTaskState
			,List<SelectItem> projectList,List<SelectItem> taskList,String owner) throws PLMCommonException;
	/**
	 * This method is used to fetchPCInfo
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerReportData> fetchPCInfo(List<String> cstGrpList,List<SelectItem> projectList,boolean allOpenPrjName) throws PLMCommonException;
	/**
	 * This method is used to fetchTaskFromTaskState
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerReportData> fetchTaskFromTaskState(List<String> cstGrpList) throws PLMCommonException;
	public List<SelectItem> projectFamilyAutocomplete(String selectedPrjName) throws PLMCommonException;
	public List<SelectItem> taskFamilyAutocomplete(String selectedTaskName) throws PLMCommonException;
}
