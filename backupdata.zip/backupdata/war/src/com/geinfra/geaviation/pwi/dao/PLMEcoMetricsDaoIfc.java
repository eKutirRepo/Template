/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEcoMetricsDaoIfc.java
 * @Creation date: 02-July-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.data.PLMEcoMetricsData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMEcoMetricsDaoIfc {
	/**
	 * This method is used to loadEcoCategoryReport
	 * @param ecocategorydata, ecocategorylist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> loadEcoCategoryReport(PLMEcoMetricsData ecocategorydata,List<PLMEcoMetricsData> ecocategorylist) throws PLMCommonException;
	/**
	 * This method is used to loadEcoCategoryDetailReport
	 * @param ecocategorydata
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<String> loadEcoCategoryDetailReport(PLMEcoMetricsData ecocategorydata) throws PLMCommonException;
	/**
	 * This method is used to ecoCatExpandVp
	 * @param ecocategorydata, ecocategorylist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoCatExpandVp(PLMEcoMetricsData ecocategorydata,List<PLMEcoMetricsData> ecocategorylist) throws PLMCommonException;
	/**
	 * This method is used to ecoCatExpandGm
	 * @param ecocategorydata, ecocategorylist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoCatExpandGm(PLMEcoMetricsData ecocategorydata,List<PLMEcoMetricsData> ecocategorylist) throws PLMCommonException;
	/**
	 * This method is used to ecoCatExpandFm
	 * @param ecocategorydata, ecocategorylist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoCatExpandFm(PLMEcoMetricsData ecocategorydata,List<PLMEcoMetricsData> ecocategorylist) throws PLMCommonException;
	/**
	 * This method is used to ecoCatExpandMgr
	 * @param ecocategorydata, ecocategorylist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoCatExpandMgr4(PLMEcoMetricsData ecocategorydata,List<PLMEcoMetricsData> ecocategorylist) throws PLMCommonException;
	/**
	 * This method is used to ecoCatExpandMgr
	 * @param ecocategorydata, ecocategorylist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoCatExpandMgr3(PLMEcoMetricsData ecocategorydata,List<PLMEcoMetricsData> ecocategorylist) throws PLMCommonException;
	/**
	 * This method is used to ecoCatExpandMgr
	 * @param ecocategorydata, ecocategorylist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoCatExpandMgr2(PLMEcoMetricsData ecocategorydata,List<PLMEcoMetricsData> ecocategorylist) throws PLMCommonException;
	/**
	 * This method is used to ecoCatExpandMgr
	 * @param ecocategorydata, ecocategorylist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoCatExpandMgr1(PLMEcoMetricsData ecocategorydata,List<PLMEcoMetricsData> ecocategorylist) throws PLMCommonException;
	/**
	 * This method is used to loadEcoVolumeReport
	 * @param ecovolumedata, ecovolumelist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> loadEcoVolumeReport(PLMEcoMetricsData ecovolumedata,List<PLMEcoMetricsData> ecovolumelist) throws PLMCommonException;
	/**
	 * This method is used to loadEcoVolumeDetailReport
	 * @param ecovolumedata
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<String> loadEcoVolumeDetailReport(PLMEcoMetricsData ecovolumedata) throws PLMCommonException;
	/**
	 * This method is used to ecoVolExpandVp
	 * @param ecovolumedata, ecovolumelist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoVolExpandVp(PLMEcoMetricsData ecovolumedata,List<PLMEcoMetricsData> ecovolumelist) throws PLMCommonException;
	/**
	 * This method is used to ecoVolExpandGm
	 * @param ecovolumedata, ecovolumelist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoVolExpandGm(PLMEcoMetricsData ecovolumedata,List<PLMEcoMetricsData> ecovolumelist) throws PLMCommonException;
	/**
	 * This method is used to ecoVolExpandFm
	 * @param ecovolumedata, ecovolumelist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoVolExpandFm(PLMEcoMetricsData ecovolumedata,List<PLMEcoMetricsData> ecovolumelist) throws PLMCommonException;
	/**
	 * This method is used to ecoVolExpandMgr
	 * @param ecovolumedata, ecovolumelist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoVolExpandMgr4(PLMEcoMetricsData ecovolumedata,List<PLMEcoMetricsData> ecovolumelist) throws PLMCommonException;
	/**
	 * This method is used to ecoVolExpandMgr
	 * @param ecovolumedata, ecovolumelist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoVolExpandMgr3(PLMEcoMetricsData ecovolumedata,List<PLMEcoMetricsData> ecovolumelist) throws PLMCommonException;
	/**
	 * This method is used to ecoVolExpandMgr
	 * @param ecovolumedata, ecovolumelist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoVolExpandMgr2(PLMEcoMetricsData ecovolumedata,List<PLMEcoMetricsData> ecovolumelist) throws PLMCommonException;
	/**
	 * This method is used to ecoVolExpandMgr
	 * @param ecovolumedata, ecovolumelist
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoMetricsData> ecoVolExpandMgr1(PLMEcoMetricsData ecovolumedata,List<PLMEcoMetricsData> ecovolumelist) throws PLMCommonException;
	
	
	
}
