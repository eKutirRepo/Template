/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBOMSimilarData.java
 * @Creation date: 28-Oct-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;

public class PLMBOMSimilarData {
	
	/**
	 * Holds partId
	 */
	private String partId;
	/**
	 * Holds similarId
	 */
	private String similarId;
	/**
	 * Holds parent
	 */
	private String parent;
	/**
	 * Holds item
	 */
	private String item;
	/**
	 * Holds description
	 */
	private String description;
	/**
	 * Holds quantity
	 */
	private String quantity;
	/**
	 * Holds similarPartParentId
	 */
	private String similarPartParentId;
	
		/**
	  * Holds the efftStrDate
	  */
	 private Date efftStrDate;
	 
	 /**
	  * Holds the efftEndDate
	  */
	 private Date efftEndDate;

	/**
	 * @return the partId
	 */
	public String getPartId() {
		return partId;
	}
	/**
	 * @param partId the partId to set
	 */
	public void setPartId(String partId) {
		this.partId = partId;
	}
	/**
	 * @return the similarId
	 */
	public String getSimilarId() {
		return similarId;
	}
	/**
	 * @param similarId the similarId to set
	 */
	public void setSimilarId(String similarId) {
		this.similarId = similarId;
	}
	/**
	 * @return the parent
	 */
	public String getParent() {
		return parent;
	}
	/**
	 * @param parent the parent to set
	 */
	public void setParent(String parent) {
		this.parent = parent;
	}
	/**
	 * @return the item
	 */
	public String getItem() {
		return item;
	}
	/**
	 * @param item the item to set
	 */
	public void setItem(String item) {
		this.item = item;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the quantity
	 */
	public String getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return the similarPartParentId
	 */
	public String getSimilarPartParentId() {
		return similarPartParentId;
	}
	/**
	 * @param similarPartParentId the similarPartParentId to set
	 */
	public void setSimilarPartParentId(String similarPartParentId) {
		this.similarPartParentId = similarPartParentId;
	}
	
	/**
	 * @return the efftStrDate
	 */
	public Date getEfftStrDate() {
		Date efftStrDt=efftStrDate;
		return efftStrDt;
	}
	/**
	 * @param efftStrDate the efftStrDate to set
	 */
	public void setEfftStrDate(Date efftStrDate) {
		Date efftStrDt=efftStrDate;
		this.efftStrDate = efftStrDt;
	}
	
	/**
	 * @return the efftEndDate
	 */
	public Date getEfftEndDate() {
		Date efftEndDt=efftEndDate;
		return efftEndDt;
	}
	/**
	 * @param efftEndDate the efftEndDate to set
	 */
	public void setEfftEndDate(Date efftEndDate) {
		Date efftEndDt=efftEndDate;
		this.efftEndDate = efftEndDt;
	}
}
