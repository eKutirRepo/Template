/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMPddrData.java
 * @Creation date: 22-May-2014
 * @version 3.0.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.data;

public class PLMPddrReportData {
	/**
	  * Holds the bomLevel
	  */
	private int bomLevel;
	/**
	  * Holds the rowKey
	  */
	private int rowKey;
	/**
	  * Holds the topPartName
	  */
	private String topPartName;
	/**
	  * Holds the topPartRev
	  */
	private String topPartRev;
	/**
	  * Holds the parentPartName
	  */
	private String parentPartName;
	/**
	  * Holds the parentPartRev
	  */
	private String parentPartRev;
	/**
	  * Holds the parentPartType
	  */
	private String parentPartType;
	/**
	  * Holds the childPartName
	  */
	private String childPartName;
	/**
	  * Holds the childPartRev
	  */
	private String childPartRev;
	/**
	  * Holds the childPartType
	  */
	private String childPartType;
	/**
	  * Holds the childPartState
	  */
	private String childPartState;
	/**
	  * Holds the childPartDesc
	  */
	private String childPartDesc;
	/**
	  * Holds the logicalIndicator
	  */
	private String logicalIndicator;
	/**
	  * Holds the documentName
	  */
	private String documentName;
	/**
	  * Holds the documentRev
	  */
	private String documentRev;
	/**
	  * Holds the documentType
	  */
	private String documentType;
	/**
	  * Holds the documentState
	  */
	private String documentState;
	/**
	  * Holds the documentDesc
	  */
	private String documentDesc;
	/**
	 * @return Returns the bomLevel.
	 */
	public int getBomLevel() {
		return bomLevel;
	}
	/**
	 * @param bomLevel The bomLevel to set.
	 */
	public void setBomLevel(int bomLevel) {
		this.bomLevel = bomLevel;
	}
	/**
	 * @return Returns the childPartDesc.
	 */
	public String getChildPartDesc() {
		return childPartDesc;
	}
	/**
	 * @param childPartDesc The childPartDesc to set.
	 */
	public void setChildPartDesc(String childPartDesc) {
		this.childPartDesc = childPartDesc;
	}
	/**
	 * @return Returns the childPartName.
	 */
	public String getChildPartName() {
		return childPartName;
	}
	/**
	 * @param childPartName The childPartName to set.
	 */
	public void setChildPartName(String childPartName) {
		this.childPartName = childPartName;
	}
	/**
	 * @return Returns the childPartRev.
	 */
	public String getChildPartRev() {
		return childPartRev;
	}
	/**
	 * @param childPartRev The childPartRev to set.
	 */
	public void setChildPartRev(String childPartRev) {
		this.childPartRev = childPartRev;
	}
	/**
	 * @return Returns the childPartState.
	 */
	public String getChildPartState() {
		return childPartState;
	}
	/**
	 * @param childPartState The childPartState to set.
	 */
	public void setChildPartState(String childPartState) {
		this.childPartState = childPartState;
	}
	/**
	 * @return Returns the childPartType.
	 */
	public String getChildPartType() {
		return childPartType;
	}
	/**
	 * @param childPartType The childPartType to set.
	 */
	public void setChildPartType(String childPartType) {
		this.childPartType = childPartType;
	}
	/**
	 * @return Returns the documentDesc.
	 */
	public String getDocumentDesc() {
		return documentDesc;
	}
	/**
	 * @param documentDesc The documentDesc to set.
	 */
	public void setDocumentDesc(String documentDesc) {
		this.documentDesc = documentDesc;
	}
	/**
	 * @return Returns the documentName.
	 */
	public String getDocumentName() {
		return documentName;
	}
	/**
	 * @param documentName The documentName to set.
	 */
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	/**
	 * @return Returns the documentRev.
	 */
	public String getDocumentRev() {
		return documentRev;
	}
	/**
	 * @param documentRev The documentRev to set.
	 */
	public void setDocumentRev(String documentRev) {
		this.documentRev = documentRev;
	}
	/**
	 * @return Returns the documentState.
	 */
	public String getDocumentState() {
		return documentState;
	}
	/**
	 * @param documentState The documentState to set.
	 */
	public void setDocumentState(String documentState) {
		this.documentState = documentState;
	}
	/**
	 * @return Returns the documentType.
	 */
	public String getDocumentType() {
		return documentType;
	}
	/**
	 * @param documentType The documentType to set.
	 */
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	/**
	 * @return Returns the logicalIndicator.
	 */
	public String getLogicalIndicator() {
		return logicalIndicator;
	}
	/**
	 * @param logicalIndicator The logicalIndicator to set.
	 */
	public void setLogicalIndicator(String logicalIndicator) {
		this.logicalIndicator = logicalIndicator;
	}
	/**
	 * @return Returns the parentPartName.
	 */
	public String getParentPartName() {
		return parentPartName;
	}
	/**
	 * @param parentPartName The parentPartName to set.
	 */
	public void setParentPartName(String parentPartName) {
		this.parentPartName = parentPartName;
	}
	/**
	 * @return Returns the parentPartRev.
	 */
	public String getParentPartRev() {
		return parentPartRev;
	}
	/**
	 * @param parentPartRev The parentPartRev to set.
	 */
	public void setParentPartRev(String parentPartRev) {
		this.parentPartRev = parentPartRev;
	}
	/**
	 * @return Returns the parentPartType.
	 */
	public String getParentPartType() {
		return parentPartType;
	}
	/**
	 * @param parentPartType The parentPartType to set.
	 */
	public void setParentPartType(String parentPartType) {
		this.parentPartType = parentPartType;
	}
	/**
	 * @return Returns the rowKey.
	 */
	public int getRowKey() {
		return rowKey;
	}
	/**
	 * @param rowKey The rowKey to set.
	 */
	public void setRowKey(int rowKey) {
		this.rowKey = rowKey;
	}
	/**
	 * @return Returns the topPartName.
	 */
	public String getTopPartName() {
		return topPartName;
	}
	/**
	 * @param topPartName The topPartName to set.
	 */
	public void setTopPartName(String topPartName) {
		this.topPartName = topPartName;
	}
	/**
	 * @return Returns the topPartRev.
	 */
	public String getTopPartRev() {
		return topPartRev;
	}
	/**
	 * @param topPartRev The topPartRev to set.
	 */
	public void setTopPartRev(String topPartRev) {
		this.topPartRev = topPartRev;
	}
	

}
