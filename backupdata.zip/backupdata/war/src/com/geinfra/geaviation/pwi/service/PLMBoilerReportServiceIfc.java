/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBoilerReportServiceIfc.java
 * @Creation date: 17-Feb-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.service;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMBoilerReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMBoilerReportServiceIfc {

	/**
	 * This method is used to fetch Project Names and Task Names
	 * 
	 * @return Map<String, List<SelectItem>>
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getProjectNameAndTaskList() throws PLMCommonException;
	/**
	 * This method is used to generate backlog report based on project and task
	 * 
	 * @return List<PWiBoilerCommonReportVO>
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerReportData> generateBacklogAppReport(List<String> selBacklogProjectName, boolean allOpenPrjName,List<String> selBacklogTaskName, boolean allOpenTaskName,List<String> selBacklogTaskState
			,List<SelectItem> projectList,List<SelectItem> taskList,String owner) throws PLMCommonException;
	
	/**
	 * This method is used to fetchPCInfo
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerReportData> fetchPCInfo(List<String> cstGrpList,List<SelectItem> projectList,boolean allOpenPrjName) throws PLMCommonException;
	/**
	 * This method is used to fetchTaskFromTaskState
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerReportData> fetchTaskFromTaskState(List<String> cstGrpList) throws PLMCommonException;
	
	public List<SelectItem> projectFamilyAutocomplete(String selectedPrjName) throws PLMCommonException;
	public List<SelectItem> taskFamilyAutocomplete(String selectedPrjName) throws PLMCommonException;	
}
