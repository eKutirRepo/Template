/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhrUsdSubstncDaoIfc.java
 * @Creation date: 01-Jan-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMWhrUsdSubstncData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMWhrUsdSubstncDaoIfc {
	/**
	 * This methods is used for getDropDownvalues
	 * 
	 * @return List
	 * throws PLMCommonException
	 */
	public List<SelectItem> getDropDownvalues(String substance,String casSubstanceNum) throws PLMCommonException;
	/**
	 * This method is used to getGBOMData
	 * @return java.util.List
	 * @param varMap
	 * @throws PLMCommonException
	 */
	public List<PLMWhrUsdSubstncData> getWhUsedCASSubData(String substance,String casubstanceNum,String material) throws PLMCommonException;


}
