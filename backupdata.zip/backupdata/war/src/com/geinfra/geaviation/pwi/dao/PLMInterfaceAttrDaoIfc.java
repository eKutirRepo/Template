/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMInterfaceAttrDaoIfc.java
 * @Creation date: 29-Aug-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMInterfaceAttrData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMInterfaceAttrDaoIfc {
	
	/**
	 * This method is used to getDropDownData
	 * @return java.util.Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getPartFamilyDropDownData() throws PLMCommonException;
	
	/**
	 * This method is used to getAttrNameForPartFamily
	 * @return java.util.Map
	 * @param selectedPartFamily
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getAttrNameForPartFamily(String selectedPartFamily) throws PLMCommonException;
	/**
	 * This method is used to get Result List
	 * 
	 * @param selectedPartFamily
	 * @param selectedAttributeName
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMInterfaceAttrData> getPartFamilyResultList(PLMInterfaceAttrData partFamilyIntAttrData) throws PLMCommonException;

}
