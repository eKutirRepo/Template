/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMFmiDaoImpl.java
 * @Creation date: 12-June-2014
 * @version 1.0
 * @author : Srinivas
 */

package com.geinfra.geaviation.pwi.dao;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import com.geinfra.geaviation.pwi.data.PLMDocGenFmiData;
import com.geinfra.geaviation.pwi.data.PLMFmiAppReportData;
import com.geinfra.geaviation.pwi.data.PLMFmiTemplateData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMQueryConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMFmiDaoImpl extends SimpleJdbcDaoSupport implements PLMFmiDaoIfc {

	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMFmiDaoImpl.class);
	private static List<String> selfmiLclAppFrame =new ArrayList<String>();
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
		 
	}

	
	@SuppressWarnings("unchecked")
	public List<PLMDocGenFmiData> fetchReqDesc(List<String> reqList) throws PLMCommonException{
		Map<String, Object> params = new HashMap<String, Object>();
		LOG.info("Executing reqDescQry Query : " + PLMQueryConstants.GET_REQ_DESC + "\n");
		params.put("REQNM", reqList);
		LOG.info("reqList------------->"+reqList);
		List<PLMDocGenFmiData> reqDescList = getNamedJdbcTemplate().query(PLMQueryConstants.GET_REQ_DESC,params, new ReqDescMapper());
		return reqDescList;
	}

	private static final class ReqDescMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
//	private static ParameterizedRowMapper<PLMDocGenFmiData> reqDescMapper = new ParameterizedRowMapper<PLMDocGenFmiData>() {
		public PLMDocGenFmiData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMDocGenFmiData data = new PLMDocGenFmiData();
			data.setFmiSeqId(rs.getString("FMI_REQ_SEQ_ID"));
			data.setFmiReqNm(rs.getString("FMI_REQ_NAME"));
			data.setFmiReqDesc(rs.getString("FMI_REQ_DESC"));
			return data;
		}
	}

	@SuppressWarnings("unchecked")
	public List<PLMDocGenFmiData> getFmiText(List<String> reqList, List<String> ceiList) throws PLMCommonException{
		 Map<String, Object> params = new HashMap<String, Object>();
		LOG.info("Executing fmiTxtQry Query : " + PLMQueryConstants.GET_FMI_TEXT1 + "\n");
		LOG.info("reqList------------->"+reqList);
		LOG.info("ceiList------------->"+ceiList);
		params.put("REQNM", reqList);
		params.put("CEINM", ceiList);
		List<PLMDocGenFmiData> fmiTxtList = getNamedJdbcTemplate().query(PLMQueryConstants.GET_FMI_TEXT1,params, new FmiTxtMapper());
		return fmiTxtList;
	}
	private static final class FmiTxtMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
//	private static ParameterizedRowMapper<PLMDocGenFmiData> fmiTxtMapper = new ParameterizedRowMapper<PLMDocGenFmiData>() {
		public PLMDocGenFmiData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMDocGenFmiData data = new PLMDocGenFmiData();
			data.setFmiCeiNm(rs.getString("FMI_CEI_NAME"));
			data.setCiDisplayName(rs.getString("FMI_CEI_DISP_NAME"));
			data.setFmiReqNm1(rs.getString("FMI_REQ_NAME"));
			data.setFmiSpTools(rs.getString("FMI_SPCL_TOOLS"));
			data.setFmiMdfctnDsc(rs.getString("FMI_MDFCTN_DESC"));
			data.setFmiFmiSplNts(rs.getString("FMI_SPCL_NOTES"));
			data.setFmiSrvcDocs(rs.getString("FMI_SRVC_DCMNTS"));
			data.setFmiRprTxt(rs.getString("FMI_RPR_TXT"));
			data.setFmiFldTxtVal(rs.getString("FMI_FLD_TXT"));
			data.setFmiTxtVal(rs.getString("FMI_TEXT_VAL"));
			return data;
		}
	}

	@SuppressWarnings("unchecked")
	public List<PLMDocGenFmiData> getFmiTextForMli(List<String> reqList, List<String> ceiList, List<String> mliList) throws PLMCommonException{
		 Map<String, Object> params = new HashMap<String, Object>();
		LOG.info("Executing mliTxtQry Query : " + PLMQueryConstants.GET_FMI_TEXT_FOR_MLI + "\n");
		LOG.info("reqList------------->"+reqList);
		LOG.info("ceiList------------->"+ceiList);
		LOG.info("mliList------------->"+mliList);
		params.put("REQNM", reqList);
		params.put("CEINM", ceiList);
		params.put("MLINM", mliList);
		List<PLMDocGenFmiData> fmiTxtList = getNamedJdbcTemplate().query(PLMQueryConstants.GET_FMI_TEXT_FOR_MLI,params, new MliTxtMapper());
		return fmiTxtList;
	}
	private static final class MliTxtMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
//	private static ParameterizedRowMapper<PLMDocGenFmiData> mliTxtMapper = new ParameterizedRowMapper<PLMDocGenFmiData>() {
		public PLMDocGenFmiData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMDocGenFmiData data = new PLMDocGenFmiData();
			data.setFmiCeiNm1(rs.getString("FMI_CEI_NAME"));
			data.setCiDisplayName(rs.getString("FMI_CEI_DISP_NAME"));
			data.setFmiReqNm2(rs.getString("FMI_REQ_NAME"));
			data.setFmiMliNm(rs.getString("FMI_MLI_NAME"));
			data.setFmiTxtVal1(rs.getString("FMI_TEXT_VAL"));
			return data;
		}
	}

	public StringBuffer loadReqDescList(List<PLMDocGenFmiData> reqDescList) {
		StringBuffer strbmlilist = new StringBuffer("");
		if(!PLMUtils.isEmptyList(reqDescList)){
		strbmlilist.append("\\par ");
		for (int i = 0; i < reqDescList.size(); i++) {
			strbmlilist.append(PLMUtils.checkNullVal(reqDescList.get(i).getFmiReqDesc()));
			strbmlilist.append("\\par ");
		}
		
		}else{
			strbmlilist.append(" ");
		}
		return strbmlilist;
	}

	public StringBuffer loadCeiReqSptlsList(List<PLMDocGenFmiData> list, List<PLMDocGenFmiData> ceiDataList) {
		StringBuffer strbmlilist = new StringBuffer("");
		if(!PLMUtils.isEmptyList(list)){
		strbmlilist.append("\\par ");
		boolean flag = false;
		for (int i = 0; i < list.size(); i++) {
			for(int j = 0; j < ceiDataList.size(); j++){
				if(list.get(i).getFmiCeiNm().equals(ceiDataList.get(j).getCiNum())){
					strbmlilist.append( PLMUtils.checkNullVal(list.get(i).getCiDisplayName())+" "+PLMUtils.checkNullVal(list.get(i).getFmiReqNm1())+" : "+PLMUtils.checkNullVal(list.get(i).getFmiSpTools()));
					strbmlilist.append("\\par ");
					flag = true;
				}
				if(flag == true){
					break;
				}
			}
			
		}
		}else{
			strbmlilist.append(" ");
		}
		return strbmlilist;
	}

	public StringBuffer loadCeiReqModDescList(List<PLMDocGenFmiData> list, List<PLMDocGenFmiData> ceiDataList) {
		StringBuffer strbmlilist = new StringBuffer("");
		boolean flag = false;
		if(!PLMUtils.isEmptyList(list)){
		strbmlilist.append("\\par ");
		for (int i = 0; i < list.size(); i++) {
			for(int j = 0; j < ceiDataList.size(); j++){
				if(list.get(i).getFmiCeiNm().equals(ceiDataList.get(j).getCiNum())){
					strbmlilist.append( PLMUtils.checkNullVal(list.get(i).getCiDisplayName())+" "+PLMUtils.checkNullVal(list.get(i).getFmiReqNm1())+" : "+PLMUtils.checkNullVal(list.get(i).getFmiMdfctnDsc()));
					strbmlilist.append("\\par ");
				}
				if(flag == true){
					break;
				}
			}
		}
		}else{
			strbmlilist.append(" ");
		}
		return strbmlilist;
	}

	public StringBuffer loadSpecialNotes(List<PLMDocGenFmiData> list, List<PLMDocGenFmiData> ceiDataList) {
		StringBuffer strbmlilist = new StringBuffer("");
		boolean flag = false;
		if(!PLMUtils.isEmptyList(list)){
		strbmlilist.append("\\par ");
		for (int i = 0; i < list.size(); i++) {
			for(int j = 0; j < ceiDataList.size(); j++){
				if(list.get(i).getFmiCeiNm().equals(ceiDataList.get(j).getCiNum())){
					strbmlilist.append( PLMUtils.checkNullVal(list.get(i).getCiDisplayName())+" "+PLMUtils.checkNullVal(list.get(i).getFmiReqNm1())+" : "+PLMUtils.checkNullVal(list.get(i).getFmiFmiSplNts()));
					strbmlilist.append("\\par ");
				}
				if(flag == true){
					break;
				}
			}
		}
		}else{
			strbmlilist.append(" ");
		}
		return strbmlilist;
	}

	public StringBuffer loadServDcmts(List<PLMDocGenFmiData> list, List<PLMDocGenFmiData> ceiDataList) {
		StringBuffer strbmlilist = new StringBuffer("");
		boolean flag = false;
		if(!PLMUtils.isEmptyList(list)){
		strbmlilist.append("\\par ");
		for (int i = 0; i < list.size(); i++) {
			for(int j = 0; j < ceiDataList.size(); j++){
				if(list.get(i).getFmiCeiNm().equals(ceiDataList.get(j).getCiNum())){
			strbmlilist.append( PLMUtils.checkNullVal(list.get(i).getCiDisplayName())+" "+PLMUtils.checkNullVal(list.get(i).getFmiReqNm1())+" : "+PLMUtils.checkNullVal(list.get(i).getFmiSrvcDocs()));
			strbmlilist.append("\\par ");
				}
				if(flag == true){
					break;
				}
			}
		}
		}else{
			strbmlilist.append(" ");
		}
		return strbmlilist;
	}

	public StringBuffer loadRprText(List<PLMDocGenFmiData> list, List<PLMDocGenFmiData> ceiDataList) {
		StringBuffer strbmlilist = new StringBuffer("");
		boolean flag = false;
		if(!PLMUtils.isEmptyList(list)){
		strbmlilist.append("\\par ");
		for (int i = 0; i < list.size(); i++) {
			for(int j = 0; j < ceiDataList.size(); j++){
				if(list.get(i).getFmiCeiNm().equals(ceiDataList.get(j).getCiNum())){
			strbmlilist.append( PLMUtils.checkNullVal(list.get(i).getCiDisplayName())+" "+PLMUtils.checkNullVal(list.get(i).getFmiReqNm1())+" : "+PLMUtils.checkNullVal(list.get(i).getFmiRprTxt()));
			strbmlilist.append("\\par ");
				}
				if(flag == true){
					break;
				}
			}
		}
		}else{
			strbmlilist.append(" ");
		}
		return strbmlilist;
	}

	public StringBuffer loadFieldText(List<PLMDocGenFmiData> list, List<PLMDocGenFmiData> ceiDataList) {
		StringBuffer strbmlilist = new StringBuffer("");
		boolean flag = false;
		if(!PLMUtils.isEmptyList(list)){
		strbmlilist.append("\\par ");
		for (int i = 0; i < list.size(); i++) {
			for(int j = 0; j < ceiDataList.size(); j++){
				if(list.get(i).getFmiCeiNm().equals(ceiDataList.get(j).getCiNum())){
			strbmlilist.append( PLMUtils.checkNullVal(list.get(i).getCiDisplayName())+" "+PLMUtils.checkNullVal(list.get(i).getFmiReqNm1())+" : "+PLMUtils.checkNullVal(list.get(i).getFmiFldTxtVal()));
			strbmlilist.append("\\par ");
				}
				if(flag == true){
					break;
				}
			}
		}
		}else{
			strbmlilist.append(" ");
		}
		return strbmlilist;
	}

//Commented the code for On Demand FMI for July Release
	/*public StringBuffer loadMliList(List<PLMDocGenFmiData> mlidetailslist, List<PLMDocGenFmiData> fmiTextForMli, List<PLMDocGenFmiData> ceiDataList) {
		StringBuffer strbmlilist = new StringBuffer("");
		boolean flag = false;
		//boolean flag1 = false;
		String mliCompare="";
		strbmlilist.append("\\par ");
		for (int i = 0; i < mlidetailslist.size(); i++) {
			flag = false;
			//Comparing  MLIs and till continues to display same MLIs 
			if(PLMUtils.isEmpty(mliCompare) ||
					mliCompare.equalsIgnoreCase(mlidetailslist.get(i).getMlino())){
				strbmlilist.append("ML" + mlidetailslist.get(i).getMlino() + "     ");
				strbmlilist.append(mlidetailslist.get(i).getDocName() + "     ");
				strbmlilist.append(mlidetailslist.get(i).getDocDesc());
				strbmlilist.append("\\par ");
				mliCompare= mlidetailslist.get(i).getMlino();
			}else{
				
				//comparing description based on MLI Name in fmi text
				for(int j = 0; j < mlidetailslist.size(); j++){
					if(mliCompare.equals(mlidetailslist.get(j).getMlino()) && !PLMUtils.isEmpty(mlidetailslist.get(j).getModifcationDesc())){
								strbmlilist.append("\\par ");
								strbmlilist.append( PLMUtils.checkNullVal(mlidetailslist.get(j).getModifcationDesc()));
								strbmlilist.append("\\par ");
								strbmlilist.append("\\par ");
								strbmlilist.append("\\par ");
								flag = true;
								break;
					}
				}
				
				//comparing description based on MLI Name in PWI text
				if(!flag){
					for(int j = 0; j < fmiTextForMli.size(); j++){
						if(mliCompare.equals(fmiTextForMli.get(j).getFmiMliNm())){
							for(int k = 0; k < ceiDataList.size(); k++){
								if(fmiTextForMli.get(j).getFmiCeiNm1().equals(ceiDataList.get(k).getCiNum())){
									strbmlilist.append("\\par ");
									strbmlilist.append( PLMUtils.checkNullVal(fmiTextForMli.get(j).getCiDisplayName())+" "+PLMUtils.checkNullVal(fmiTextForMli.get(j).getFmiReqNm2())+" "+PLMUtils.checkNullVal(fmiTextForMli.get(j).getFmiMliNm())+" : "+PLMUtils.checkNullVal(fmiTextForMli.get(j).getFmiTxtVal1()));
									strbmlilist.append("\\par ");
									strbmlilist.append("\\par ");
									strbmlilist.append("\\par ");
									flag = true;
									break;
								}
							}
						}
					}
			   }	
				
				if(!flag){
					strbmlilist.append("\\par ");
					strbmlilist.append("<Put the Modification for " +PLMUtils.checkNullVal( mliCompare) + " here>");
					strbmlilist.append("\\par ");
				}
				
				//Adding new MLI for next Description
					strbmlilist.append("\\par ");
					strbmlilist.append("ML" + mlidetailslist.get(i).getMlino() + "     ");
					strbmlilist.append(mlidetailslist.get(i).getDocName() + "     ");
					strbmlilist.append(mlidetailslist.get(i).getDocDesc());
					strbmlilist.append("\\par ");
					mliCompare= mlidetailslist.get(i).getMlino();
					flag=false;
			}
		}
		
		//Adding Last Description based on MLI
		if(!flag){
			
			//comparing description based on MLI Name in fmi text
			for(int j = 0; j < mlidetailslist.size(); j++){
				if(mliCompare.equals(mlidetailslist.get(j).getMlino()) && !PLMUtils.isEmpty(mlidetailslist.get(j).getModifcationDesc())){
							strbmlilist.append("\\par ");
							strbmlilist.append( PLMUtils.checkNullVal(mlidetailslist.get(j).getModifcationDesc()));
							strbmlilist.append("\\par ");
							strbmlilist.append("\\par ");
							strbmlilist.append("\\par ");
							flag = true;
							break;
				}
			}
			
			
			//comparing description based on MLI Name in PWI text
			if(!flag){
				for(int j = 0; j < fmiTextForMli.size(); j++){
					if(mliCompare.equals(fmiTextForMli.get(j).getFmiMliNm())){
						for(int k = 0; k < ceiDataList.size(); k++){
							if(fmiTextForMli.get(j).getFmiCeiNm1().equals(ceiDataList.get(k).getCiNum())){
								strbmlilist.append("\\par ");
								strbmlilist.append( PLMUtils.checkNullVal(fmiTextForMli.get(j).getCiDisplayName())+" "+PLMUtils.checkNullVal(fmiTextForMli.get(j).getFmiReqNm2())+" "+PLMUtils.checkNullVal(fmiTextForMli.get(j).getFmiMliNm())+" : "+PLMUtils.checkNullVal(fmiTextForMli.get(j).getFmiTxtVal1()));
								strbmlilist.append("\\par ");
								strbmlilist.append("\\par ");
								strbmlilist.append("\\par ");
								flag = true;
								break;
							}
						}
					}
				}
			}	
		}
		
		if(!flag){
			strbmlilist.append("\\par ");
			strbmlilist.append("<Put the Modification for " +PLMUtils.checkNullVal( mliCompare) + " here>");
			strbmlilist.append("\\par ");
		}
		return strbmlilist;
	}*/
	
	public StringBuffer loadMliList(List<PLMDocGenFmiData> mlidetailslist, List<PLMDocGenFmiData> fmiTextForMli, List<PLMDocGenFmiData> ceiDataList) {
		StringBuffer strbmlilist = new StringBuffer("");
		boolean flag = false;
		//boolean flag1 = false;
		String mliCompare="";
		strbmlilist.append("\\par ");
		for (int i = 0; i < mlidetailslist.size(); i++) {
			flag = false;
			//Comparing  MLIs and till continues to display same MLIs 
			if(PLMUtils.isEmpty(mliCompare) ||
					mliCompare.equalsIgnoreCase(mlidetailslist.get(i).getMlino())){
				strbmlilist.append("\\b ");
				strbmlilist.append("ML " + mlidetailslist.get(i).getMlino() + "\t");
				strbmlilist.append(mlidetailslist.get(i).getDocName() + "\t");
				strbmlilist.append(mlidetailslist.get(i).getDocDesc());
				strbmlilist.append("\\b0 ");
				strbmlilist.append("\\par ");
				mliCompare= mlidetailslist.get(i).getMlino();
			}else{
				//comparing description based on MLI Name
				for(int j = 0; j < fmiTextForMli.size(); j++){
					if(mliCompare.equals(fmiTextForMli.get(j).getFmiMliNm())){
						for(int k = 0; k < ceiDataList.size(); k++){
							if(fmiTextForMli.get(j).getFmiCeiNm1().equals(ceiDataList.get(k).getCiNum())){
								strbmlilist.append("\\par ");
								strbmlilist.append( PLMUtils.checkNullVal(fmiTextForMli.get(j).getCiDisplayName())+" "+PLMUtils.checkNullVal(fmiTextForMli.get(j).getFmiReqNm2())+" "+PLMUtils.checkNullVal(fmiTextForMli.get(j).getFmiMliNm())+" : "+PLMUtils.checkNullVal(fmiTextForMli.get(j).getFmiTxtVal1()));
								strbmlilist.append("\\par ");
								strbmlilist.append("\\par ");
								strbmlilist.append("\\par ");
								flag = true;
								break;
							}
						}
					}
				}
				
				if(flag == false){
					strbmlilist.append("\\par ");
					strbmlilist.append("<Put the Modification for " +PLMUtils.checkNullVal( mliCompare) + " here>");
					strbmlilist.append("\\par ");
				}
				
				//Adding new MLI for next Description
					strbmlilist.append("\\par ");
					strbmlilist.append("\\b ");
					strbmlilist.append("ML " + mlidetailslist.get(i).getMlino() + "\t");
					strbmlilist.append(mlidetailslist.get(i).getDocName() + "\t");
					strbmlilist.append(mlidetailslist.get(i).getDocDesc());
					strbmlilist.append("\\b0 ");
					strbmlilist.append("\\par ");
					mliCompare= mlidetailslist.get(i).getMlino();
			}
		}
		
		//Adding Last Description based on MLI
		if(!flag){
			for(int j = 0; j < fmiTextForMli.size(); j++){
				if(mliCompare.equals(fmiTextForMli.get(j).getFmiMliNm())){
					for(int k = 0; k < ceiDataList.size(); k++){
						if(fmiTextForMli.get(j).getFmiCeiNm1().equals(ceiDataList.get(k).getCiNum())){
							strbmlilist.append("\\par ");
							strbmlilist.append( PLMUtils.checkNullVal(fmiTextForMli.get(j).getCiDisplayName())+" "+PLMUtils.checkNullVal(fmiTextForMli.get(j).getFmiReqNm2())+" "+PLMUtils.checkNullVal(fmiTextForMli.get(j).getFmiMliNm())+" : "+PLMUtils.checkNullVal(fmiTextForMli.get(j).getFmiTxtVal1()));
							strbmlilist.append("\\par ");
							strbmlilist.append("\\par ");
							strbmlilist.append("\\par ");
							flag = true;
							break;
						}
					}
				}
			}
				
		}
		
		if(flag == false){
			strbmlilist.append("\\par ");
			strbmlilist.append("<Put the Modification for " +PLMUtils.checkNullVal( mliCompare) + " here>");
			strbmlilist.append("\\par ");
		}
		return strbmlilist;
	}


	public List<PLMDocGenFmiData> getFmiReqValues(List<String> reqNameList, List<String> ceiList, 
			List<String> mliList, List<PLMDocGenFmiData> tempMlidetailslist, 
			List<PLMDocGenFmiData> ceiDataList) throws PLMCommonException {
		LOG.info("Entering generateFmiDoc1 method");
		List<PLMDocGenFmiData> resultList = new ArrayList<PLMDocGenFmiData>();
		PLMDocGenFmiData data = new PLMDocGenFmiData();
		List<PLMDocGenFmiData> reqDescList = new ArrayList<PLMDocGenFmiData>();
		List<PLMDocGenFmiData> fmiText = new ArrayList<PLMDocGenFmiData>();
		List<PLMDocGenFmiData> fmiTextForMli = new ArrayList<PLMDocGenFmiData>();
		
		LOG.info("*****************  Executing Oracle Queries ********************");
		if(!PLMUtils.isEmptyList(reqNameList)){
			LOG.info("reqNameList size--------->"+reqNameList.size());
			reqDescList = fetchReqDesc(reqNameList);
			LOG.info("reqDescList size---- >"+reqDescList.size());
			if(!PLMUtils.isEmptyList(ceiList)){
				fmiText = getFmiText(reqNameList, ceiList);
				LOG.info("fmiText size---- >"+fmiText.size());
				if(!PLMUtils.isEmptyList(mliList)){
					fmiTextForMli = getFmiTextForMli(reqNameList, ceiList, mliList);
					LOG.info("fmiTextForMli size---- >"+fmiTextForMli.size());
				}
			}
		}
		
		data.setStrReqDescList(loadReqDescList(reqDescList).toString());  
		data.setStrCeiReqSptlsList(loadCeiReqSptlsList(fmiText,ceiDataList).toString());
		data.setStrCeiReqModDescList(loadCeiReqModDescList(fmiText,ceiDataList).toString());
		data.setMlilist(loadMliList(tempMlidetailslist, fmiTextForMli,ceiDataList).toString());
		data.setStrCeiReqSpNtsList(loadSpecialNotes(fmiText,ceiDataList).toString());
		data.setStrCeiReqSerDcsList(loadServDcmts(fmiText,ceiDataList).toString());
		data.setStrCeiReqRepTxtList(loadRprText(fmiText,ceiDataList).toString());
		data.setStrCeiReqFldTxtList(loadFieldText(fmiText,ceiDataList).toString());
		resultList.add(data);
		return resultList;
		}
		
	//Newly Added for FMI Manage Text
	
	public Map<String, List<SelectItem>> getRequirementList() throws PLMCommonException{
		
		LOG.info("In getRequirementList method");
		Map<String, List<SelectItem>> reqListMap = new HashMap<String, List<SelectItem>>();
		List<SelectItem> reqList = null;
		StringBuffer searchQuery =new StringBuffer();
		try {
			searchQuery.append(PLMQueryConstants.GET_REQUIREMENT_NAME_lIST);
			LOG.info("Query for Requirement Dropdown is : " + searchQuery.toString());
			reqList = getSimpleJdbcTemplate().query(searchQuery.toString(), new RequireListtMapper());
			Collections.sort(reqList, new PLMUtils.SortListSelItmLbl());
			LOG.info("requirementName List size : " + reqList.size());
			reqListMap.put("requirement", reqList);
			
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return reqListMap;
	}

	private static final class RequireListtMapper implements ParameterizedRowMapper<SelectItem> {
//	private static ParameterizedRowMapper<SelectItem> requireListtMapper = new ParameterizedRowMapper<SelectItem>() {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(PLMUtils.checkNullVal(rs.getString("FMI_REQ_SEQ_ID")),PLMUtils.checkNullVal(rs.getString("FMI_REQ_NAME")));
			return selectItem;
		}
	}



	@SuppressWarnings("unchecked")
	public Map<String, List<SelectItem>> fetchCeiNameList(List<String> selRequirementList) throws PLMCommonException{
		
		LOG.info("In the method fetchCeiNameList");
		Map<String, List<SelectItem>> ceiValMap = new HashMap<String, List<SelectItem>>();
		Map<String, Object> params = new HashMap<String, Object>();
		try {
			LOG.info("Query for Populating CEI Names Dropdown : " + PLMQueryConstants.GET_CEI_NAME_lIST);
			params.put("FMIREQID", selRequirementList);
			List<SelectItem> ceiList = getNamedJdbcTemplate().query(PLMQueryConstants.GET_CEI_NAME_lIST,params, new CeiListtMapper());
			Collections.sort(ceiList, new PLMUtils.SortListSelItmLbl());
			LOG.info("ceiName List size : " + ceiList.size());
			ceiValMap.put("ceiNameList", ceiList);
			
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return ceiValMap;
		}

	private static final class CeiListtMapper implements ParameterizedRowMapper<SelectItem> {
//	private static ParameterizedRowMapper<SelectItem> ceiListtMapper = new ParameterizedRowMapper<SelectItem>() {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(PLMUtils.checkNullVal(rs.getString("FMI_CEI_SEQ_ID")),PLMUtils.checkNullVal(rs.getString("FMI_CEI_NAME"))+"-"+PLMUtils.checkNullVal(rs.getString("FMI_CEI_DISP_NAME")));
			return selectItem;
		}
	}

	@SuppressWarnings("unchecked")
	public Map<String, List<SelectItem>> getMliNameList(List<String> selCeiList,List<String> selRequirment) throws PLMCommonException{
		LOG.info("In the method getMliNameList");
		Map<String, List<SelectItem>> mliValMap = new HashMap<String, List<SelectItem>>();
		List<SelectItem> mliList = null;
		Map<String, Object> params = new HashMap<String, Object>();
		try {
			params.put("CEIID", selCeiList);
			params.put("REQID", selRequirment);
			LOG.info("Query for Populating MLIs in MLI Dropdown box is : " + PLMQueryConstants.GET_MLI_NAME_lIST);
			mliList = getNamedJdbcTemplate().query(PLMQueryConstants.GET_MLI_NAME_lIST,params, new MliListtMapper());
			Collections.sort(mliList, new PLMUtils.SortListSelItmLbl());
			LOG.info("mliName List size : " + mliList.size());
			mliValMap.put("mliNameList", mliList);
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return mliValMap;
		}
	private static final class MliListtMapper implements ParameterizedRowMapper<SelectItem> {
//	private static ParameterizedRowMapper<SelectItem> mliListtMapper = new ParameterizedRowMapper<SelectItem>() {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(PLMUtils.checkNullVal(rs.getString("FMI_MLI_SEQ_ID")),PLMUtils.checkNullVal(rs.getString("FMI_MLI_NAME")));
			return selectItem;
		}
	}

	@SuppressWarnings("unchecked")
	public List<SelectItem> getReqCeiNameList(List<String> selCei) throws PLMCommonException{
		LOG.info("In the method getReqCeiNameList");
		 Map<String, Object> params = new HashMap<String, Object>();
		 params.put("CEIID", selCei);	
		 LOG.info("Query for Add MLI Popup : "+PLMQueryConstants.GET_SELECT_CEI_NAMES);
		 List<SelectItem>selCeiNm = getNamedJdbcTemplate().query(PLMQueryConstants.GET_SELECT_CEI_NAMES,params, new SelCeiNameMapper());
			LOG.info("Selected CEI Names List size : " + selCeiNm.size());
		return selCeiNm;
	}


	private static final class SelCeiNameMapper implements ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			  SelectItem selectItem = new SelectItem(rs.getString("FMI_CEI_SEQ_ID"),
					  rs.getString("FMI_CEI_NAME")+"-"+rs.getString("FMI_CEI_DISP_NAME"));
				return selectItem;
		}
	}

	
/*	private static final class ReqCeiNamesMapper implements ParameterizedRowMapper<PLMFmiTemplateData> {
//	private static ParameterizedRowMapper<PLMFmiTemplateData> reqCeiNamesMapper = new ParameterizedRowMapper<PLMFmiTemplateData>() {
		public PLMFmiTemplateData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMFmiTemplateData tempData = new PLMFmiTemplateData();
			String reqId = PLMUtils.checkNullVal(rs.getString("FMI_REQ_SEQ_ID"));
			String ceiId = PLMUtils.checkNullVal(rs.getString("FMI_CEI_SEQ_ID"));
			
			tempData.setReqCeiId(reqId+"~"+ceiId);
			tempData.setReqId(reqId);
			tempData.setCeiId(ceiId);
			tempData.setReqName(PLMUtils.checkNullVal(rs.getString("FMI_REQ_NAME")));
			tempData.setReqDesc(PLMUtils.checkNullVal(rs.getString("FMI_REQ_DESC")));
			tempData.setCeiName(PLMUtils.checkNullVal(rs.getString("FMI_CEI_NAME")));
			tempData.setCeiDesc(PLMUtils.checkNullVal(rs.getString("FMI_CEI_DISP_NAME")));
			return tempData;
		}
	}
*/
	@SuppressWarnings("unchecked")
	public List<SelectItem> getselectRequirementNm(List<String> selRequirment) throws PLMCommonException{
		List<SelectItem> selRequriementNm=new ArrayList<SelectItem>();
		Map<String, Object> params = new HashMap<String, Object>();
		try {
			params.put("REQID", selRequirment);
			LOG.info("Query for Add CEI popup is : " + PLMQueryConstants.GET_REQUIREMENT_NAME_WHERE);
			selRequriementNm = getNamedJdbcTemplate().query(PLMQueryConstants.GET_REQUIREMENT_NAME_WHERE,params, new SelRequirementNameMapper());
			LOG.info("Selected Requirement Names List size : " + selRequriementNm.size());
					
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return selRequriementNm;
	}

	private static final class SelRequirementNameMapper implements ParameterizedRowMapper<SelectItem> {
//	private static ParameterizedRowMapper<PLMFmiTemplateData> selRequirementNameMapper = new ParameterizedRowMapper<PLMFmiTemplateData>() {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			  SelectItem selectItem = new SelectItem(rs.getString("FMI_REQ_SEQ_ID"),
					  rs.getString("FMI_REQ_NAME"));
				return selectItem;
		}
	}


	@SuppressWarnings("unchecked")
	public List<PLMFmiTemplateData> getReqCeiMliNameList(List<String> selRequirment,List<String> selCei,List<String> selMli) throws PLMCommonException{
		LOG.info("In the method getReqCeiMliNameList");
		 Map<String, Object> params = new HashMap<String, Object>();
		 params.put("REQID", selRequirment);
		 params.put("CEIID", selCei);
		 params.put("MLIID", selMli);
		LOG.info("Query for Add FMI Text Popup : "+PLMQueryConstants.GET_REQ_CEI_MLI_NAMES_LIST);
		List<PLMFmiTemplateData> reqCeiMliNamesList = getNamedJdbcTemplate().
		query(PLMQueryConstants.GET_REQ_CEI_MLI_NAMES_LIST,params, new ReqCeiMliNamesMapper());
		Collections.sort(reqCeiMliNamesList, new SortFmiText());
		LOG.info("reqCeiMliNamesList size: "+reqCeiMliNamesList.size());
		return reqCeiMliNamesList;
	 }
	
	/**
	 * 
	 * class to sort list of object of type PLMFmiTemplateData
	 * 
	 */
	private static class SortFmiText implements Comparator<PLMFmiTemplateData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMFmiTemplateData aString,
				PLMFmiTemplateData bString) {
			
			int result= aString.getReqName().compareTo(bString.getReqName());
		       if (result != 0)
		       {
		           return result;
		       }
		       result = aString.getMliName().compareTo(bString.getMliName());
		       if (result != 0)
		       {
		           return result; 
		       }
		       
		      return aString.getCeiDesc().compareTo(bString.getCeiDesc());
		      
		}
	}
	
	private static final class ReqCeiMliNamesMapper implements ParameterizedRowMapper<PLMFmiTemplateData> {
//	private static ParameterizedRowMapper<PLMFmiTemplateData> reqCeiMliNamesMapper = new ParameterizedRowMapper<PLMFmiTemplateData>() {
		public PLMFmiTemplateData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMFmiTemplateData tempData = new PLMFmiTemplateData();
		    tempData.setReqName(PLMUtils.checkNullVal(rs.getString("FMI_REQ_NAME")));
			tempData.setReqDesc(PLMUtils.checkNullVal(rs.getString("FMI_REQ_DESC")));
			tempData.setCeiName(PLMUtils.checkNullVal(rs.getString("FMI_CEI_NAME")));
			tempData.setCeiDesc(PLMUtils.checkNullVal(rs.getString("FMI_CEI_DISP_NAME")));
			tempData.setMliName(PLMUtils.checkNullVal(rs.getString("FMI_MLI_NAME")));
			tempData.setMliDesc(PLMUtils.checkNullVal(rs.getString("MLI_DESCRIPTION")));
			tempData.setMliNotes(PLMUtils.checkNullVal(rs.getString("MLI_NOTES")));
			

			tempData.setApplicableSymbol(PLMUtils.checkNullVal(rs.getString("FMI_APPLCBLTY_SMBL")));
			tempData.setModidicationDesc(PLMUtils.checkNullVal(rs.getString("FMI_MDFCTN_DESC")));
			tempData.setFmiBenefits(PLMUtils.checkNullVal(rs.getString("FMI_BENEFITS")));
			tempData.setSpecialNotes(PLMUtils.checkNullVal(rs.getString("FMI_SPCL_NOTES")));
			
			tempData.setRepairTextVal(PLMUtils.checkNullVal(rs.getString("FMI_RPR_TXT")));
			tempData.setTextFeild(PLMUtils.checkNullVal(rs.getString("FMI_FLD_TXT")));
			tempData.setSpecialTools(PLMUtils.checkNullVal(rs.getString("FMI_SPCL_TOOLS")));
			tempData.setServiceDoc(PLMUtils.checkNullVal(rs.getString("FMI_SRVC_DCMNTS")));
			tempData.setFmiTextVal(PLMUtils.checkNullVal(rs.getString("FMI_TEXT_VAL")));
			tempData.setMliId(PLMUtils.checkNullVal(rs.getString("FMI_TEXT_SEQ_ID")));
			
			tempData.setStdTaskDuration(PLMUtils.checkNullVal(rs.getString("STD_TASK_DURATION")));
			tempData.setSmlrToPartQTC(PLMUtils.checkNullVal(rs.getString("SMLR_TO_PART_QT_CCE")));
			tempData.setFillMntLeadTime(PLMUtils.checkNullVal(rs.getString("FLFLMNT_LEAD_TIME")));
			tempData.setPrsText(PLMUtils.checkNullVal(rs.getString("PRS_TEXT")));
			tempData.setHoursEffort(PLMUtils.checkNullVal(rs.getString("HOURS_EFFORT")));
			return tempData;
		}
	}

	@Transactional
	public String saveRequirement(PLMFmiTemplateData templateData,String ssoId) throws PLMCommonException{
		LOG.info("Entering into saveRequirement");
		String status=null;
		int count = 0;
		int addCount =0;

		if(templateData.getReqNameTxt()!=null && templateData.getReqNameTxt().length() >0){
			
			LOG.info("Get Count Query for Requirement >>> "+PLMQueryConstants.GET_COUNT_REQUIREMENT_NAMES);
			count = getJdbcTemplate().queryForInt(PLMQueryConstants.GET_COUNT_REQUIREMENT_NAMES, 
								new Object[] { templateData.getReqNameTxt()});
			if(count==0){
				LOG.info("Insert Query for Requirement >>> "+PLMQueryConstants.INSERT_NEW_REQUIREMENT);
				addCount = getSimpleJdbcTemplate().update(PLMQueryConstants.INSERT_NEW_REQUIREMENT,new Object[] 
				{templateData.getReqNameTxt(),templateData.getReqDescTxt(),ssoId,ssoId});
				if(addCount!=0){
				  	LOG.info("Added Record of Requirement : " + addCount);
				   	status= templateData.getReqNameTxt()+" Requirement added successfully.";
				}
				else{
				    status="Failed to add the Requirement";
				}
			}
			else{
				status= templateData.getReqNameTxt()+" Requirement name already exist. Please add a New Requirement";
			}
		}
		
		return status;
	}

	@Transactional
	public String saveCei(String reqSeqId, String ceiSeqId, String ceiName, String ceiDesc, String ssoId) throws PLMCommonException{
		String status=null;
		int reqCeiCmbCnt = 0;
		int ceiSeqCnt =0;
		int addCei =0;
		int addCeiTxt =0;
		int ceiSeqDbId = 0;

		if (PLMUtils.isEmpty(ceiSeqId)) {
			
			ceiSeqCnt =  getJdbcTemplate().queryForInt(PLMQueryConstants.GET_COUNT_CEI_SEQ_ID, 
					new Object[] { ceiName});
			
			if(ceiSeqCnt!=0){
			    ceiSeqDbId =  getJdbcTemplate().queryForInt(PLMQueryConstants.GET_COUNT_CEI_VAL, 
					new Object[] { ceiName});
			 }
			
			if (ceiSeqDbId!=0) {
				
				reqCeiCmbCnt = getJdbcTemplate().queryForInt(PLMQueryConstants.GET_COUNT_CEI_NAMES, 
						new Object[] { reqSeqId, ceiSeqDbId});
				
				if (reqCeiCmbCnt==0) {
					
					LOG.info("Insert Query of CEI TXT>>> "+PLMQueryConstants.INSERT_NEW_CEI_FMI_TXT);
					addCeiTxt = getSimpleJdbcTemplate().update(PLMQueryConstants.INSERT_NEW_CEI_FMI_TXT,new Object[]
					  {reqSeqId, ceiSeqDbId,ssoId,ssoId});
					LOG.info("Inserted CEI>> "+addCei);
					
					status = ceiName +" CEI added successfully";
					
				} else {
					
					status= ceiName+" CEI Name already exists and associated to the selected Requirement";
				}
				
			} else {
				
				ceiSeqDbId = getJdbcTemplate().queryForInt(PLMQueryConstants.GET_MAX_CEI_SEQ_ID);
				
				LOG.info("Insert Query of CEI >>> "+PLMQueryConstants.INSERT_NEW_CEI);
				addCei = getSimpleJdbcTemplate().update(PLMQueryConstants.INSERT_NEW_CEI,new Object[] 
				{ceiSeqDbId, ceiName,ceiDesc,ssoId,ssoId});
				LOG.info("Inserted CEI>> "+addCei);
				
				LOG.info("Insert Query of CEI TXT>>> "+PLMQueryConstants.INSERT_NEW_CEI_FMI_TXT);
				addCeiTxt = getSimpleJdbcTemplate().update(PLMQueryConstants.INSERT_NEW_CEI_FMI_TXT,new Object[]
				  {reqSeqId,ceiSeqDbId,ssoId,ssoId});
				LOG.info("Inserted CEI TXT>> "+addCeiTxt);

				status = ceiName +" CEI added successfully";
			}
			
		} else {
				
				reqCeiCmbCnt = getJdbcTemplate().queryForInt(PLMQueryConstants.GET_COUNT_CEI_NAMES, 
					new Object[] { reqSeqId, ceiSeqId});
			
				if (reqCeiCmbCnt!=0) {
					status= ceiName+" CEI Name already exists and associated to the selected Requirement";
				} else {
					
					LOG.info("Insert Query of CEI TXT>>> "+PLMQueryConstants.INSERT_NEW_CEI_FMI_TXT);
					addCeiTxt = getSimpleJdbcTemplate().update(PLMQueryConstants.INSERT_NEW_CEI_FMI_TXT,new Object[]
					  {reqSeqId,ceiSeqId,ssoId,ssoId});
					LOG.info("Inserted CEI TXT if CeiSeqId assigned >> "+addCeiTxt);

					status = ceiName +" CEI added successfully";
				}
				
		}
		LOG.info("CEI TXT  addCeiTxt >> "+addCeiTxt);

		return status;
	}



	@Transactional
	public String saveMli(String fmiId,String mliSeqId,String mliName, String mliDesc, String mliNotes, String ssoId) throws PLMCommonException{
		String status="";
		int addMli =0;
		int mliSeqCnt=0;
		int mliSequenceId=0;
		String[] reqCei = fmiId.split("~");
		String reqId = reqCei[0];
		String ceiId = reqCei[1];
		int astdFlg = 0;
		
		LOG.info("reqId "+reqId);
		LOG.info("ceiId "+ceiId);
		
		if (PLMUtils.isEmpty(mliSeqId)) {
			
			LOG.info("Get Count Query of MLI Seqid >>> "+PLMQueryConstants.GET_COUNT_MLI_SEQ_ID);
			
	        mliSeqCnt =  getJdbcTemplate().queryForInt(PLMQueryConstants.GET_COUNT_MLI_SEQ_ID, 
					new Object[] { mliName});
			
			if(mliSeqCnt!=0){
				mliSequenceId =  getJdbcTemplate().queryForInt(PLMQueryConstants.GET_COUNT_MLI_VAL, 
					new Object[] { mliName});
			}
			if (mliSequenceId==0) { 
				LOG.info("Get Query of Max seq id MLI >>> "+PLMQueryConstants.GET_MAX_MLI_SEQID);
		     
				mliSequenceId = getJdbcTemplate().queryForInt(PLMQueryConstants.GET_MAX_MLI_SEQID);
		      
				LOG.info("Insert Query of MLI >>> "+PLMQueryConstants.INSERT_NEW_MLI);
		      
				addMli = getSimpleJdbcTemplate().update(PLMQueryConstants.INSERT_NEW_MLI,new Object[] 
		            {mliSequenceId,mliName,mliDesc,mliNotes,ssoId,ssoId});
				LOG.info("Added Record of MLI : " + addMli);
				astdFlg = addFmiMliText(reqId,ceiId,mliSequenceId,ssoId);
		   } else{
			   astdFlg = addFmiMliText(reqId,ceiId,mliSequenceId, ssoId);
		   }
			
		} else{
			astdFlg = addFmiMliText(reqId,ceiId,Integer.parseInt(mliSeqId), ssoId);
		}
		
		if (astdFlg==1){
			status = mliName+" MLI has been associated successfully.";
		} else if (astdFlg == 0){
			status = mliName+" MLI has been added successfully.";
		} else if (astdFlg ==2) {
			status = mliName+" MLI is already associated to the Selected Requirement and CEI";
		}
		return status;
	}

	@Transactional
	public int addFmiMliText(String reqId,String ceiId,int mliSequenceId,String ssoId){
		int countFmiTxt = 0;
		int addMlitxt = 0;
		int updateMlitxt = 0;
		int countMliTxt = 0;
		int astdFlg = 0;
		LOG.info("addFmiMliText reqId "+reqId);
		LOG.info("addFmiMliText ceiId "+ceiId);
		
	   LOG.info("Get Count Query of MLI Seqid >>> "+PLMQueryConstants.GET_COUNT_MLI_TXT);
		
	   countFmiTxt = getJdbcTemplate().queryForInt(PLMQueryConstants.GET_COUNT_MLI_TXT, 
			new Object[] {reqId,ceiId});
		
	   if(countFmiTxt==0){
		   
		   countMliTxt = getJdbcTemplate().queryForInt(PLMQueryConstants.GET_COUNT_MLI_FMI_TXT, 
					new Object[] {reqId,ceiId,mliSequenceId});
		   
		   if (countMliTxt==0) {
		   
	    	   LOG.info("Insert Query of MLI Text >>> "+PLMQueryConstants.INSERT_NEW_MLI_TXT);
	    	   addMlitxt = getSimpleJdbcTemplate().update(PLMQueryConstants.INSERT_NEW_MLI_TXT,new Object[] 
				                {reqId,ceiId,mliSequenceId,ssoId,ssoId});
	    	   LOG.info("Added Record of MLI Text: " + addMlitxt);
		   } else {
			   astdFlg = 2;
		   }
	   }
	   else{
		   LOG.info("Update Query of MLI Text >>> "+PLMQueryConstants.UPDATE_MLI_TXT);
		   updateMlitxt = getSimpleJdbcTemplate().update(PLMQueryConstants.UPDATE_MLI_TXT,new Object[] 
			                {mliSequenceId,ssoId,reqId,ceiId});
		   LOG.info("Update Record of MLI Text: "+updateMlitxt );
		   astdFlg = 1;
	   }
	   return astdFlg;
	}
		
	@Transactional
	public String uploadFmiManageText(List<PLMFmiTemplateData> fmiMngTextDataList, String ssoId)
			throws PLMCommonException {
		LOG.info("Inside uploadFmiManageText(List<PLMFmiTemplateData> fmiMngTextDataList)");
		String status=null;
		
		final List<PLMFmiTemplateData> finalTextList=fmiMngTextDataList;
		final String sso=ssoId;
	 if(!PLMUtils.isEmptyList(finalTextList)){
			int[] updateCount =null;
			LOG.info("Update Query of upload FmiManageText :  " + PLMQueryConstants.UPDATE_FMI_MANAGE_TXT);
			updateCount  = getSimpleJdbcTemplate().getJdbcOperations().batchUpdate(PLMQueryConstants.UPDATE_FMI_MANAGE_TXT,new BatchPreparedStatementSetter() 
			{
			public void setValues(PreparedStatement ps,int iCount)throws SQLException {
			ps.setString(1, finalTextList.get(iCount).getApplicableSymbol());
			ps.setString(2, finalTextList.get(iCount).getModidicationDesc());
			ps.setString(3, finalTextList.get(iCount).getFmiBenefits());
			ps.setString(4, finalTextList.get(iCount).getSpecialNotes());
			ps.setString(5, finalTextList.get(iCount).getRepairTextVal());
			ps.setString(6, finalTextList.get(iCount).getTextFeild());
			ps.setString(7, finalTextList.get(iCount).getSpecialTools());
			ps.setString(8, finalTextList.get(iCount).getServiceDoc());
			ps.setString(9, finalTextList.get(iCount).getFmiTextVal());
			ps.setInt(10, finalTextList.get(iCount).getIntstdTskDur());
			ps.setString(11, finalTextList.get(iCount).getSmlrToPartQTC());
			ps.setInt(12, finalTextList.get(iCount).getIntfillMntLdTime());
			ps.setString(13, finalTextList.get(iCount).getPrsText());
			ps.setInt(14, finalTextList.get(iCount).getInthoursEffort());
			ps.setString(15, sso);
			ps.setString(16, finalTextList.get(iCount).getMliId());
			
			}
			public int getBatchSize() {
				return finalTextList.size();
			}
			});			
			if(fmiMngTextDataList.size()==updateCount.length){
				LOG.info("Uploaded Successfully");
				  status= "File has been uploaded successfully";
			  }
			else{
				LOG.info("Uploaded failed");
				status= "Uploaded Failed";
			}
		 }
	 return status;	
	}


	public List<SelectItem> getCeiNameList() throws PLMCommonException{
		
		LOG.info("Executing getCeiNameList");
		List<SelectItem> ceiNameList  = new ArrayList<SelectItem>();
		try {
			LOG.info("Final Query getCeiNameList is : " + PLMQueryConstants.GET_SEL_CEI_NAMES_LIST);
			ceiNameList = getSimpleJdbcTemplate().query(PLMQueryConstants.GET_SEL_CEI_NAMES_LIST, new CeiNamesListMapper());
			Collections.sort(ceiNameList, new PLMUtils.SortListSelItmLbl());
			LOG.info("getCeiNameList size : " + ceiNameList.size());
			
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return ceiNameList;
		}
	private static final class CeiNamesListMapper implements ParameterizedRowMapper<SelectItem> {
//	private static ParameterizedRowMapper<SelectItem> ceiNamesListMapper = new ParameterizedRowMapper<SelectItem>() {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(PLMUtils.checkNullVal(rs.getString("FMI_CEI_SEQ_ID")),PLMUtils.checkNullVal(rs.getString("FMI_CEI_NAME"))+"-"+PLMUtils.checkNullVal(rs.getString("FMI_CEI_DISP_NAME")));
			return selectItem;
		}
	}


	public PLMFmiTemplateData getCeiDetails(String selCeiId)throws PLMCommonException{
		LOG.info("Executing getCeiDetails");
		PLMFmiTemplateData tempData  = new PLMFmiTemplateData();
	 	try {
				LOG.info("Final Query getCeiDetails is : " + PLMQueryConstants.GET_CEI_DETAILS);
			tempData = (PLMFmiTemplateData) getSimpleJdbcTemplate().queryForObject(PLMQueryConstants.GET_CEI_DETAILS, new CeiDetailsMapper(),
					new Object[] { Integer.parseInt(selCeiId)  });
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return tempData;
	}

	private static final class CeiDetailsMapper implements ParameterizedRowMapper<PLMFmiTemplateData> {
//	private static ParameterizedRowMapper<PLMFmiTemplateData> ceiDetailsMapper = new ParameterizedRowMapper<PLMFmiTemplateData>() {
		public PLMFmiTemplateData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMFmiTemplateData tempData =new PLMFmiTemplateData();
			tempData.setCeiNameTxt(PLMUtils.checkNullVal(rs.getString("FMI_CEI_NAME")));
			tempData.setCeiDescTxt(PLMUtils.checkNullVal(rs.getString("FMI_CEI_DISP_NAME")));
			tempData.setDisplayFlag(true);
			return tempData;
		}
	}



	public List<SelectItem> getMliNameList() throws PLMCommonException{
		
		LOG.info("Executing getMliNameList");
		List<SelectItem> mliNameList  = new ArrayList<SelectItem>();
		try {
			LOG.info("Final Query getMliNameList is : " + PLMQueryConstants.GET_SEL_MLI_NAMES_LIST);
			mliNameList = getSimpleJdbcTemplate().query(PLMQueryConstants.GET_SEL_MLI_NAMES_LIST, new MliNamesListMapper());
			Collections.sort(mliNameList, new PLMUtils.SortListSelItmLbl());
			LOG.info("getMliNameList size : " + mliNameList.size());
			
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return mliNameList;
		}
	private static final class MliNamesListMapper implements ParameterizedRowMapper<SelectItem> {
//	private static ParameterizedRowMapper<SelectItem> mliNamesListMapper = new ParameterizedRowMapper<SelectItem>() {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(PLMUtils.checkNullVal(rs.getString("FMI_MLI_SEQ_ID")),PLMUtils.checkNullVal(rs.getString("FMI_MLI_NAME")));
			return selectItem;
		}
	}

	public PLMFmiTemplateData getMliDetails(String selMliName)throws PLMCommonException{
		LOG.info("Executing getMliDetails");
		PLMFmiTemplateData tempData  = new PLMFmiTemplateData();
	 	try {
			LOG.info("Final Query getMliDetails is : " + PLMQueryConstants.GET_MLI_DETAILS);
			tempData = (PLMFmiTemplateData) getSimpleJdbcTemplate().queryForObject(PLMQueryConstants.GET_MLI_DETAILS, new MliDetailsMapper(),
					new Object[] { Integer.parseInt(selMliName)  });
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return tempData;
	}
	private static final class MliDetailsMapper implements ParameterizedRowMapper<PLMFmiTemplateData> {
//	private static ParameterizedRowMapper<PLMFmiTemplateData> mliDetailsMapper = new ParameterizedRowMapper<PLMFmiTemplateData>() {
		public PLMFmiTemplateData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMFmiTemplateData tempData =new PLMFmiTemplateData();
			tempData.setMliNameTxt(PLMUtils.checkNullVal(rs.getString("FMI_MLI_NAME")));
			tempData.setMliDescTxt(PLMUtils.checkNullVal(rs.getString("MLI_DESCRIPTION")));
			tempData.setMliNotesTxt(PLMUtils.checkNullVal(rs.getString("MLI_NOTES")));
			tempData.setDisplayMliFlg(true);
			return tempData;
		}
	}

	//Newly Added for FMI Applicability Report
	/**
	 * This method is used for getDropDownvaluesFmiAppRpt
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public Map<String, List<SelectItem>> getDropDownvaluesFmiAppRpt()
			throws PLMCommonException {
		Map<String, List<SelectItem>> dropdownlist = new HashMap<String, List<SelectItem>>();		
		List<SelectItem> requirementList = null;
		List<SelectItem> frametypeList = null;
		try {			
			LOG.info("Query for getting Requirment Name List : " + PLMQueryConstants.GET_REQUIREMENT_NAME);
			requirementList = getJdbcTemplate().query(PLMQueryConstants.GET_REQUIREMENT_NAME,
					new FmiRequirementMapper());	
			Collections.sort(requirementList, new PLMUtils.SortListSelItem());
			LOG.info("size of  Requirment Name List : " + requirementList.size());
			LOG.info("Query for getting Frame Type List : " + PLMQueryConstants.GET_FRAME_TYPE);
			frametypeList = getJdbcTemplate().query(
					PLMQueryConstants.GET_FRAME_TYPE, new FmiFrameMapper());		
			Collections.sort(frametypeList, new PLMUtils.SortListSelItem());
			LOG.info("size of  Frame Type List : " + frametypeList.size());
			dropdownlist.put("requirementname", requirementList);
			dropdownlist.put("frametype", frametypeList);
				

		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return dropdownlist;
	}
	
	/**
	 * Row mapper for getting requirement name
	 */
	private static final class FmiRequirementMapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(rs
					.getString("FMI_REQ_NAME"));

			return selectItem;

		}
	}
	
	/**
	 * Row mapper for getting FRAME TYPE
	 */
	private static final class FmiFrameMapper implements ParameterizedRowMapper<SelectItem>{
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs
					.getString("FMI_CEI_DISP_NAME"));

			return selectItem;

		}
	}
	
	/**
	 * This method is used to Generate FMI Report
	 * 
	 * @param cntrtNm
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMFmiAppReportData> generateFmiAppReport(List<String> selfmiAppRequirment,boolean allOpenReq,List<String> selfmiAppFrame,boolean allOpenFrame) throws PLMCommonException{
		LOG.info("Entering into  generateFmiAppReport");
		List <PLMFmiAppReportData> fmiappReportList= new ArrayList <PLMFmiAppReportData>();
		StringBuffer sqlQuery = new StringBuffer();
		StringBuffer pivotFrames =new StringBuffer();
		boolean whereFlag=false;
		Map<String, Object> params = new HashMap<String, Object>();
		 String strpivotFrames="";
		 selfmiLclAppFrame =selfmiAppFrame;
		try {
		
			sqlQuery.append(PLMQueryConstants.GET_FMI_APP_RPT1);
			if(!allOpenReq){
				 if(!whereFlag){
					 sqlQuery.append(" WHERE D.FMI_REQ_NAME IN(:REQNM)" );
					 params.put("REQNM", selfmiAppRequirment);
				 	whereFlag=true;
				 }
				
			}
			
			if(!allOpenFrame){
				 if(!whereFlag){
					 sqlQuery.append(" WHERE C.FMI_CEI_DISP_NAME IN(:CEIDISPNM)" );
					 
				 }
				 else{
					 sqlQuery.append(" AND C.FMI_CEI_DISP_NAME IN(:CEIDISPNM)" );
				 }
				
				 params.put("CEIDISPNM", selfmiAppFrame);
			 	whereFlag=true;
			}
			
			for(int i=0;i<selfmiAppFrame.size();i++){
				pivotFrames.append("'"+selfmiAppFrame.get(i) +"'  AS  \""+selfmiAppFrame.get(i)+"\",");
				strpivotFrames = pivotFrames.substring(0, pivotFrames.length()-1);
			}
			sqlQuery.append(PLMQueryConstants.GET_FMI_APP_RPT2);
			sqlQuery.append(strpivotFrames);
			 sqlQuery.append(" ))" );
			LOG.info("Final Query for FMI APP:: "+sqlQuery);
			
			if(whereFlag){
			   fmiappReportList =  getNamedJdbcTemplate().query(sqlQuery.toString(),params, new FmiAppMapper());
			}else{			
				fmiappReportList =  getJdbcTemplate().query(sqlQuery.toString(), new FmiAppMapper());	
			}
			
			LOG.info("FMI Applicability Record Count:: "+fmiappReportList.size());
				
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return fmiappReportList;
	}
	
	
	private static final class FmiAppMapper implements ParameterizedRowMapper<PLMFmiAppReportData> {
			public PLMFmiAppReportData mapRow(ResultSet rs, int rowCount)
					throws SQLException {
				PLMFmiAppReportData tempData =new PLMFmiAppReportData();
				String[] frameTypeValue=new String[selfmiLclAppFrame.size()]; 
				tempData.setFmiReqName(PLMUtils.checkNullVal(rs.getString("FMI_REQ_NAME")));
				tempData.setFmiReqDesc(PLMUtils.checkNullVal(rs.getString("FMI_REQ_DESC")));
					
			for (int i = 0; i < selfmiLclAppFrame.size();i++){
				frameTypeValue [i]=PLMUtils.checkNullVal(rs.getString(selfmiLclAppFrame.get(i)));	
				}
			   tempData.setFrameTypeValue(frameTypeValue);
				
				return tempData;
			}
		}
	
	//Newly Added by srinvias
	/**
	 * This method is used for bulk upload of Requirement
	 * 
	 * @param ssoId
	 * @return List
	 * @throws PLMCommonException
	 */
	public String uploadBulkReqData(List<PLMFmiTemplateData> bulkRequirmntList, String ssoId)	throws PLMCommonException{
		LOG.info("Inside uploadBulkReqData");
		String status="All the requirement names provided are already available in the database.";
		int count=0;
		StringBuffer statusMsg=new StringBuffer();
		List<PLMFmiTemplateData> tempBulkRequirmntList= new ArrayList<PLMFmiTemplateData>();
		List<String> dbExtLst = new ArrayList<String>();
		statusMsg.append("Requirements ");
		for(int i=0;i<bulkRequirmntList.size();i++){
			if(!PLMUtils.isEmpty(bulkRequirmntList.get(i).getReqNameTxt())){
				LOG.info("Get Count Query for Requirement >>> "+PLMQueryConstants.GET_COUNT_REQUIREMENT_NAMES);
				count = getJdbcTemplate().queryForInt(PLMQueryConstants.GET_COUNT_REQUIREMENT_NAMES, 
							new Object[] { bulkRequirmntList.get(i).getReqNameTxt()});
				if(count==0){
					tempBulkRequirmntList.add(bulkRequirmntList.get(i));
				}else{
					dbExtLst.add(bulkRequirmntList.get(i).getReqNameTxt());
				}
			}
		}
		String dbExtReq = PLMUtils.joinToString(dbExtLst);
		if (!PLMUtils.isEmpty(dbExtReq)) {
			statusMsg.append(dbExtReq);
			statusMsg.append(" already exist in database and could not be added. Rest of the requirements have been succesfully added to FMI Text Store.");
		}
		
		final List<PLMFmiTemplateData> finalBulkRequirmntList=tempBulkRequirmntList;
		final String sso=ssoId;
	 if(!PLMUtils.isEmptyList(finalBulkRequirmntList)){
			int[] insertCount =null;
			LOG.info("Update Query of  uploadBulkReqData :  " + PLMQueryConstants.INSERT_NEW_REQUIREMENT);
			insertCount  = getSimpleJdbcTemplate().getJdbcOperations().batchUpdate(PLMQueryConstants.INSERT_NEW_REQUIREMENT,new BatchPreparedStatementSetter() 
			{
			public void setValues(PreparedStatement ps,int iCount)throws SQLException {
			ps.setString(1, finalBulkRequirmntList.get(iCount).getReqNameTxt());
			ps.setString(2, finalBulkRequirmntList.get(iCount).getReqDescTxt());
			ps.setString(3, sso);
			ps.setString(4, sso);
			}
			public int getBatchSize() {
				return finalBulkRequirmntList.size();
			}
			});			
			if(bulkRequirmntList.size()==insertCount.length){
				LOG.info("Uploaded Successfully");
				  status= "The requirements are added succesfully to FMI Text Store.";
			  }
			else {
				 status= statusMsg.toString();
			}
		 }
	 return status;	
	}
	
	/**
	 * This method is used for bulk upload of Requirement
	 * 
	 * @param ssoId
	 * @return List
	 * @throws PLMCommonException
	 */
	public PLMFmiTemplateData getReqDesc(String selRequirment) throws PLMCommonException{
		LOG.info("Executing getCeiDetails");
		PLMFmiTemplateData tempData  = new PLMFmiTemplateData();
	 	try {
				LOG.info("Final Query getReqDesc is : " + PLMQueryConstants.GET_REQUIREMENT_NAME_DETAILS);
			tempData = (PLMFmiTemplateData) getSimpleJdbcTemplate().queryForObject(PLMQueryConstants.GET_REQUIREMENT_NAME_DETAILS, new RequiremntDetailsMapper(),
					new Object[] { Integer.parseInt(selRequirment)  });
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return tempData;
	}

	
	private static final class RequiremntDetailsMapper implements ParameterizedRowMapper<PLMFmiTemplateData> {
			public PLMFmiTemplateData mapRow(ResultSet rs, int rowCount)
					throws SQLException {
				PLMFmiTemplateData tempData =new PLMFmiTemplateData();
				tempData.setReqDescTxt(PLMUtils.checkNullVal(rs.getString("FMI_REQ_DESC")));
				return tempData;
			}
		}
	
	
	/**
	 * This method is used for saving Bulk CEI Data
	 * 
	 * @param ssoId
	 * @return List
	 * @throws PLMCommonException
	 */
	public String addBulkCEIData(List<PLMFmiTemplateData> bulkCeiList, String ssoId)throws PLMCommonException{
		LOG.info("Inside addBulkCEIData");
		String status="CEI Names added successfully. Note: Some CEIs already exist and associated to the selected Requirements";
		String recordExistMsg="";
		String recordAddMsg="";
		int ceiSeqCnt=0;
		int ceiSeqDbId=0;
		int reqCeiCmbCnt=0;
		int addCei=0;
		
		for(int i=0;i<bulkCeiList.size();i++){
			if(!PLMUtils.isEmpty(bulkCeiList.get(i).getSelReqName()) && !PLMUtils.isEmpty(bulkCeiList.get(i).getCeiNameTxt())){
				String reqId=bulkCeiList.get(i).getSelReqName();
				String ceiNm=bulkCeiList.get(i).getCeiNameTxt();
				String ceiDesc=bulkCeiList.get(i).getCeiDescTxt();
				
				ceiSeqCnt =  getJdbcTemplate().queryForInt(PLMQueryConstants.GET_COUNT_CEI_SEQ_ID, 
						new Object[] { ceiNm});
				
				if(ceiSeqCnt!=0){
				    ceiSeqDbId =  getJdbcTemplate().queryForInt(PLMQueryConstants.GET_COUNT_CEI_VAL, 
						new Object[] { ceiNm});
				 }
				
				if (ceiSeqDbId!=0) {
					
					reqCeiCmbCnt = getJdbcTemplate().queryForInt(PLMQueryConstants.GET_COUNT_CEI_NAMES, 
							new Object[] { reqId, ceiSeqDbId});
					
					if (reqCeiCmbCnt==0) {
						
						LOG.info("Insert Query of CEI TXT>>> "+PLMQueryConstants.INSERT_NEW_CEI_FMI_TXT);
						int addCeiTxt = getSimpleJdbcTemplate().update(PLMQueryConstants.INSERT_NEW_CEI_FMI_TXT,new Object[]
						  {reqId, ceiSeqDbId,ssoId,ssoId});
						recordAddMsg ="CEI Names added successfully";
						LOG.info("Inserted CEI TXT>> "+addCeiTxt);
					} else {
						
						recordExistMsg= "CEI Names already exists and associated to the selected Requirement";
					}
					
				}else {
					
					ceiSeqDbId = getJdbcTemplate().queryForInt(PLMQueryConstants.GET_MAX_CEI_SEQ_ID);
					
					LOG.info("Insert Query of CEI >>> "+PLMQueryConstants.INSERT_NEW_CEI);
					addCei = getSimpleJdbcTemplate().update(PLMQueryConstants.INSERT_NEW_CEI,new Object[] 
					{ceiSeqDbId, ceiNm,ceiDesc,ssoId,ssoId});
					LOG.info("Inserted CEI>> "+addCei);
					
					LOG.info("Insert Query of CEI TXT>>> "+PLMQueryConstants.INSERT_NEW_CEI_FMI_TXT);
					int addCeiTxt = getSimpleJdbcTemplate().update(PLMQueryConstants.INSERT_NEW_CEI_FMI_TXT,new Object[]
					  {reqId,ceiSeqDbId,ssoId,ssoId});
					LOG.info("Inserted CEI TXT>> "+addCeiTxt);
					recordAddMsg = " CEI Names added successfully";
				}
			}
			 ceiSeqCnt=0;
			 ceiSeqDbId=0;
			 reqCeiCmbCnt=0;
			 addCei=0;
		}	
		if(!recordAddMsg.equals(PLMConstants.EMPTY)&& recordExistMsg.equals(PLMConstants.EMPTY)){
			status=recordAddMsg;
		}else if(recordAddMsg.equals(PLMConstants.EMPTY)&& !recordExistMsg.equals(PLMConstants.EMPTY)){
			status=recordExistMsg;
		}else{
			status="CEI Names added successfully. Note: Some CEIs already exist and associated to the selected Requirements";
		}
	 return status;	
	}
	
	/**
	 * This method is used for saving Bulk MLI Data
	 * 
	 * @param ssoId
	 * @return List
	 * @throws PLMCommonException
	 */
	public String addBulkMLIData(List<PLMFmiTemplateData> bulkMliList, String ssoId)throws PLMCommonException{
		String status="added";
		int addMli =0;
		int mliSeqCnt=0;
		int mliSequenceId=0;
		int astdFlg = 0;
		int addFlg = 0;
		int updFlg = 0;
		int extFlg = 0;
		int mliLstSize = bulkMliList.size();
		
		for(int i=0;i<mliLstSize;i++){	
		  if(!PLMUtils.isEmpty(bulkMliList.get(i).getSelReqName()) && !PLMUtils.isEmpty(bulkMliList.get(i).getSelCeiName())&&
				  !PLMUtils.isEmpty(bulkMliList.get(i).getMliNameTxt())){
			  
			  String reqId=bulkMliList.get(i).getSelReqName();
			  String ceiId=bulkMliList.get(i).getSelCeiName();
			  String mliSeqId=bulkMliList.get(i).getSelMliName();
			  String mliName=bulkMliList.get(i).getMliNameTxt();
			  String mliDesc=bulkMliList.get(i).getMliDescTxt();
			  String mliNotes =bulkMliList.get(i).getMliNotesTxt();
				  
			  LOG.info("requirement Id : " + reqId);
			  LOG.info("CEI Id: " + ceiId);
			  LOG.info(" MLI Id: " +mliSeqId);
			  LOG.info(" MLI Name  : " +mliName);
				
				
			if (PLMUtils.isEmpty(mliSeqId)) {
				
				LOG.info("Get Count Query of MLI Seqid >>> "+PLMQueryConstants.GET_COUNT_MLI_SEQ_ID);
				
		        mliSeqCnt =  getJdbcTemplate().queryForInt(PLMQueryConstants.GET_COUNT_MLI_SEQ_ID, 
						new Object[] { mliName});
				
				if(mliSeqCnt!=0){
					mliSequenceId =  getJdbcTemplate().queryForInt(PLMQueryConstants.GET_COUNT_MLI_VAL, 
						new Object[] { mliName});
				}
				if (mliSequenceId==0) { 
					LOG.info("Get Query of Max seq id MLI >>> "+PLMQueryConstants.GET_MAX_MLI_SEQID);
			     
					mliSequenceId = getJdbcTemplate().queryForInt(PLMQueryConstants.GET_MAX_MLI_SEQID);
			      
					LOG.info("Insert Query of MLI >>> "+PLMQueryConstants.INSERT_NEW_MLI);
			      
					addMli = getSimpleJdbcTemplate().update(PLMQueryConstants.INSERT_NEW_MLI,new Object[] 
			            {mliSequenceId,mliName,mliDesc,mliNotes,ssoId,ssoId});
					LOG.info("Added Record of MLI : " + addMli);
					astdFlg = addFmiMliText(reqId,ceiId,mliSequenceId,ssoId);
			   } else{
				   astdFlg = addFmiMliText(reqId,ceiId,mliSequenceId, ssoId);
			   }
				
			} else{
				astdFlg = addFmiMliText(reqId,ceiId,Integer.parseInt(mliSeqId), ssoId);
			}
		 }
		 if (astdFlg==0)  {
			 //A new Req, CEI, MLI association record has been added to database 
			addFlg++;
		 }
		 if (astdFlg==1) {
			 //A new mli has been associated to exiting Req, CEI combination
			updFlg++;
		 }
		 if (astdFlg==2) {
			 //No record has been added / update to the database as the association of Req, CEI, MLI aleady exist
			extFlg++;
		 }
		 addMli =0;
		 mliSeqCnt=0;
		 mliSequenceId=0;
		}
		LOG.info("astdFlg>>>>>>>>>>>>>>>>>>>>>> "+astdFlg);
		if (addFlg !=0 && updFlg!=0 && extFlg !=0){
			status = "MLIs data have been added / updated successfully. Note: Few MLI combinations already exist in database.";
		} else if (addFlg !=0 && updFlg!=0 && extFlg ==0){
			status = "MLIs data have been added / updated successfully.";
		} else if (addFlg !=0 && updFlg==0 && extFlg ==0){
			status = "MLIs data have been added successfully.";
		} else if (addFlg ==0 && updFlg!=0 && extFlg !=0) {
			status = "MLIs data have been updated successfully. Note: Few MLI combinations already exist in database.";
		} else if (addFlg ==0 && updFlg==0 && extFlg !=0) {
			status = "MLI combinations already exist in database.";
		} else if (addFlg ==0 && updFlg!=0 && extFlg ==0) {
			status = "MLIs data have been updated successfully.";
		} else if (addFlg !=0 && updFlg==0 && extFlg !=0) {
			status = "MLIs data have been added successfully. Note: Few MLI combinations already exist in database.";
		} 
		return status;
	}

	
}
