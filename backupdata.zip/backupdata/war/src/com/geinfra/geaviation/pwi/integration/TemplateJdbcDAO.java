package com.geinfra.geaviation.pwi.integration;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.PWiQueryTimeoutException;
import com.geinfra.geaviation.pwi.common.PWiResultSizeLimitExceededException;
import com.geinfra.geaviation.pwi.model.PWiResultSet;
import com.geinfra.geaviation.pwi.sqltemplating.TemplateEval;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.QueryProcessingUtil;
import com.geinfra.geaviation.pwi.util.SqlTemplateUtil;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.query.SqlQueryType;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;

/**
 * Project      : Product Lifecycle Management
 * Date Written : May 18, 2010
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : TemplateJdbcDAO - DAO class for Template JDBC queries. Uses
 * template SQL text from XML for executing query.
 * 
 * Revision Log May 18, 2010 | v1.0.
 * 2012.12.18 pH  replaced GEAEResultSet with PWiResultSet
 * --------------------------------------------------------------
 */
public class TemplateJdbcDAO extends QueryingDao {
	private TemplateEval templateEval;

	public TemplateJdbcDAO(int queryTimeoutSecs, int resultSizeLimit) {
		super(queryTimeoutSecs, resultSizeLimit);
	}

	public PWiResultSet executeQuery(QueryType queryType, Search search,
			SelectedColumns selectedColumns, String sso) throws PWiException,
			PWiResultSizeLimitExceededException, PWiQueryTimeoutException {
		PWiResultSet rs = null;
		List<SqlQueryType> pipelineSQLAfter = new ArrayList<SqlQueryType>();
		List<SqlQueryType> pipelineSQLBefore = new ArrayList<SqlQueryType>();
		String timeStamp;
		try {
			timeStamp = "_"+PLMUtils.volTableFormatHMS();
		
		//String VT_TEMP_DT = PLMConstants.VTXML_REP.concat(timeStamp);
//		try {
			String sqlTemplate = queryType.getQuerydefinition()
					.getQuerytemplate().getText().trim();
			templateEval = SqlTemplateUtil.getInstance().evaluateTemplate(
					queryType, sqlTemplate.replace(PLMConstants.VTXML_REP, timeStamp), search, selectedColumns, sso, null,
					null);
			String dataSource = queryType.getQuerydefinition().getDb()
					.getTemplatedb().getDsn();

			boolean isPipeline = queryType.getQuerydefinition()
					.getQuerytemplate().isPipeline();

		/*	rs = QueryProcessingUtil.getInstance().executeQuery(queryType,
					dataSource, templateEval, getQueryTimeoutSecs(),
					getResultSizeLimit());
			if (rs != null && rs.size() > 0) {*/
				// Do pipeline
				if (isPipeline) {
									
					List<SqlQueryType> pipelineSQL = queryType
							.getQuerydefinition().getQuerytemplate()
							.getPipelineSQL().getSqlQuery();
					
					
					for (int index = 0; index < pipelineSQL.size(); index++) {
						SqlQueryType pipeQry = pipelineSQL.get(index);
						String pipelineType = pipeQry.getType();
						//String pipelineExecType = pipeQry.getExecstat();
						//validate vttype
						//pipeQry.getSqlText()
						
						if("before".equals(pipelineType)){
							
							pipelineSQLBefore.add(pipeQry);
							
						}else
						{
							
							pipelineSQLAfter.add(pipeQry);
						}
					}
					
					Collections.sort(pipelineSQLAfter, new SqlQueryTypeComparator());
					Collections.sort(pipelineSQLBefore, new SqlQueryTypeComparator());

					// Sort pipeline queries by their specified seq attribute
					// value
					Collections.sort(pipelineSQL, new SqlQueryTypeComparator());

					// Process each pipeline query in order
					
		
					for (int index = 0; index < pipelineSQLBefore.size(); index++) {
						SqlQueryType pipeQry = pipelineSQLBefore.get(index);
						
						//added for parametrized pipeline
						//
						
						/*TemplateEval pipelineJdbcQuery = SqlTemplateUtil
								.getInstance().evaluateTemplate(queryType,
										pipeQry.getSqlText(), search,
										selectedColumns, sso, null, null);*/
						TemplateEval pipelineJdbcQuery = SqlTemplateUtil
								.getInstance().evaluateTemplateDDL(queryType,
										pipeQry.getSqlText().replace(PLMConstants.VTXML_REP, timeStamp), search,
										selectedColumns, sso, null, null);
						
						executePipelineForNone(pipeQry,queryType,pipelineJdbcQuery,timeStamp);
						//ended
						
						
						//commented temporarily subrajit	executePipelineForNone(pipeQry,queryType);//Assinged null as second parameter value instead of rs as rs is anyways null 
							//- corrected on 31-Oct-2014 as per Nimble report						
					}
					try{
					rs = QueryProcessingUtil.getInstance().executeQuery(queryType,
							dataSource, templateEval, getQueryTimeoutSecs(),
							getResultSizeLimit());
					if (rs != null && rs.size() > 0) {
					
					for (int index = 0; index < pipelineSQLAfter.size(); index++) {
						SqlQueryType pipeQry = pipelineSQLAfter.get(index);
						String pipelineType = pipeQry.getType();				
							if ("append".equals(pipelineType)) {
								// Get pipeline SQL with search placeholders
								// replaced
								TemplateEval pipelineJdbcQuery = SqlTemplateUtil
										.getInstance().evaluateTemplate(queryType,
												pipeQry.getSqlText().replace(PLMConstants.VTXML_REP, timeStamp), search,
												selectedColumns, sso, null, null);
	
								// Get pipeline data source
								String pipelineDataSource = pipeQry.getDb()
										.getTemplatedb().getDsn();
	
								// Execute pipeline query
								PWiResultSet pipelineRs = QueryProcessingUtil
										.getInstance().executeQuery(queryType,
												pipelineDataSource,
												pipelineJdbcQuery,
												getQueryTimeoutSecs(),
												getResultSizeLimit());
	
								// Check that pipeline results has same number of
								// columns as previous result set
								if (pipelineRs.getColumnCount() != rs
										.getColumnCount()) {
									StringBuilder builder = new StringBuilder();
									builder
											.append("Pipeline has different number of columns");
									builder
											.append(" than the previous result set.");
									throw new IllegalStateException(builder
											.toString());
								}
	
								QueryProcessingUtil.getInstance().appendResultSet(
										rs, pipelineRs);
							} else if ("flow".equals(pipelineType)){
								// Execute pipeline query with data from previous
								// result set
								rs = executePipeline(pipeQry, rs, queryType,
										search, selectedColumns, sso);
	
								if (rs.size() <= 0) {
									rs = new PWiResultSet();
									break;
								}
							}
						}
					}
					}
					catch(Exception ex)
					{
						throw new PWiException(ex);
					}
					finally
					{
						for (int index = 0; index < pipelineSQLAfter.size(); index++) {
							SqlQueryType pipeQry = pipelineSQLAfter.get(index);
							String pipelineType = pipeQry.getType();
							if (!"append".equals(pipelineType)&&!"flow".equals(pipelineType)) {
								TemplateEval pipelineJdbcQuery = SqlTemplateUtil
										.getInstance().evaluateTemplateDDL(queryType,
												pipeQry.getSqlText().replace(PLMConstants.VTXML_REP, timeStamp), search,
												selectedColumns, sso, null, null);
								executePipelineForNone(pipeQry,queryType,pipelineJdbcQuery,timeStamp);
							}
							
						}
					}
					
				}
		} catch (PLMCommonException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			//}
//		} catch (SQLException e) {
//			throw new PWiException(e, "Exception occurred executing query.");
//		}
		return rs;
	}

	private static class SqlQueryTypeComparator implements
			Comparator<SqlQueryType>, Serializable {
		private static final long serialVersionUID = 1L;

		public int compare(SqlQueryType obj1, SqlQueryType obj2) {
			return obj1.getSeq().compareTo(obj2.getSeq());
		}
	}

	private PWiResultSet executePipeline(SqlQueryType pipeQry,
			PWiResultSet rs, QueryType queryType, Search search,
			SelectedColumns selectedColumns, String sso) throws PWiException,
			PWiResultSizeLimitExceededException, PWiQueryTimeoutException {
		PWiResultSet pipeRs = null;
//		try {
			String pipeSql = pipeQry.getSqlText();

			String[] cols = QueryProcessingUtil.getInstance().getColumns(rs);
			List<Object[]> rows = QueryProcessingUtil.getInstance().getRows(rs);

			if ("single".equals(pipeQry.getOperationtype())) {
				// When single is specified, run a separate query for each input
				// row and then append the results of each query
				for (Object[] row : rows) {
					// Create a list containing just the single row to pass into
					// method to generate SQL
					List<Object[]> singleRows = new ArrayList<Object[]>();
					singleRows.add(row);

					// Generate the query
					TemplateEval pipelineJdbcQuery = SqlTemplateUtil
							.getInstance().evaluateTemplate(queryType, pipeSql,
									search, selectedColumns, sso, cols,
									singleRows);

					// Execute the query
					PWiResultSet newResult = QueryProcessingUtil
							.getInstance()
							.executeQuery(queryType,
									pipeQry.getDb().getTemplatedb().getDsn(),
									pipelineJdbcQuery, false,
									getQueryTimeoutSecs(), getResultSizeLimit());

					// Append to existing results
					if (pipeRs == null) {
						pipeRs = newResult;
					} else {
						QueryProcessingUtil.getInstance().appendResultSet(
								pipeRs, newResult);
					}
				}
			} else {
				// Generate the query
				TemplateEval pipelineTemplateEval = SqlTemplateUtil
						.getInstance().evaluateTemplate(queryType, pipeSql,
								search, selectedColumns, sso, cols, rows);

				// Execute the query
				pipeRs = QueryProcessingUtil.getInstance().executeQuery(
						queryType, pipeQry.getDb().getTemplatedb().getDsn(),
						pipelineTemplateEval, false, getQueryTimeoutSecs(),
						getResultSizeLimit());
			}
//		} catch (SQLException e) {
//			throw new PWiException(e);
//		}
		return pipeRs;
	}

	/**
	 * Note: Not set until executeQuery has been called.
	 * 
	 * @return the query string that was executed
	 */
	public String getExecutedQuery() {
		return templateEval.toString();
	}
	
	/*
	 * commented for Nimble report PMD fixes-6-Nov-2014
	 * private int executePipelineForNone(SqlQueryType pipeQry,
			PWiResultSet rs, QueryType queryType, Search search,
			SelectedColumns selectedColumns, String sso) throws PWiException,
			PWiResultSizeLimitExceededException, PWiQueryTimeoutException {
		PWiResultSet pipeRs = null;
		int updateStat = 0;
//		try {
			String pipeSql = pipeQry.getSqlText();
			
			
			
			updateStat = QueryProcessingUtil.getInstance().executeUpdateQuery(
					pipeQry.getDb().getTemplatedb().getDsn(),pipeSql, null,
					queryType, getQueryTimeoutSecs(), getResultSizeLimit());

			String[] cols = QueryProcessingUtil.getInstance().getColumns(rs);
			List<Object[]> rows = QueryProcessingUtil.getInstance().getRows(rs);

				TemplateEval pipelineTemplateEval = SqlTemplateUtil
						.getInstance().evaluateTemplate(queryType, pipeSql,
								search, selectedColumns, sso, cols, rows);

				// Execute the query
				updateStat = QueryProcessingUtil.getInstance().executeUpdateQuery(queryType, pipeQry.getDb().getTemplatedb().getDsn(),
						pipelineTemplateEval, false, getQueryTimeoutSecs(),
						getResultSizeLimit());
//		} catch (SQLException e) {
//			throw new PWiException(e);
//		}
		return updateStat;
	}*/
	private int executePipelineForNone(SqlQueryType pipeQry,QueryType queryType) throws PWiException,
			PWiResultSizeLimitExceededException, PWiQueryTimeoutException {
		int updateStat = 0;
	String pipeSql = pipeQry.getSqlText();
	
	updateStat = QueryProcessingUtil.getInstance().executeUpdateQuery(
			pipeQry.getDb().getTemplatedb().getDsn(),pipeSql, null,
			queryType, getQueryTimeoutSecs(), getResultSizeLimit());
	
		return updateStat;
	}
	
	private int executePipelineForNone(SqlQueryType pipeQry,QueryType queryType,TemplateEval pipelineJdbcQuery,String timeStamp) throws PWiException,
	PWiResultSizeLimitExceededException, PWiQueryTimeoutException {
int updateStat = 0;
String pipeSql =pipelineJdbcQuery.getSql().replace(PLMConstants.VTXML_REP, timeStamp);

updateStat = QueryProcessingUtil.getInstance().executeUpdateQuery(
		pipeQry.getDb().getTemplatedb().getDsn(),pipeSql, pipelineJdbcQuery.getParams(),
		queryType, getQueryTimeoutSecs(), getResultSizeLimit());


return updateStat;
}

	
}
