package com.geinfra.geaviation.pwi.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.AdminToolTipVO;
import com.geinfra.geaviation.pwi.util.QueryConstants;
import com.geinfra.geaviation.pwi.util.QueryLoader;

/**
 * 
 * Project : Product Lifecycle Management Date Written : May 19, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : QueryGroupDAOImpl
 * 
 * Revision Log May 19, 2010 | v1.0.
 * --------------------------------------------------------------
 */

public class AdminToolTipDAOImpl extends PWiDAO implements AdminToolTipDAO {
	private static final Logger LOGGER = Logger
			.getLogger(AdminToolTipDAOImpl.class);

	public AdminToolTipVO getToolTip(final String toolTipName)
			throws PWiException {
		String searchQuery = QueryLoader.getQuery(QueryConstants.GET_TOOLTIP);
		try {
			PreparedStatementSetter pss = new GetToolTipPreparedStatementSetter(
					toolTipName);

			ParameterizedRowMapper<AdminToolTipVO> mapper = new GetToolTipParameterizedRowMapper();
			@SuppressWarnings("unchecked")

			List<AdminToolTipVO> result = (List<AdminToolTipVO>) getJdbcTemplate()
					.query(searchQuery, pss, mapper);
			if (result.size() > 0) {
				if (result.size() > 1) {
					LOGGER.warn("Query for setting with name " + toolTipName
							+ " returned more than one result!");
				}
				return result.get(0);
			}
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
		return null;
	}

	private static class GetToolTipPreparedStatementSetter implements
			PreparedStatementSetter {
		private String settingName;

		public GetToolTipPreparedStatementSetter(String settingName) {
			this.settingName = settingName;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setString(1, settingName);
		}
	}

	private static class GetToolTipParameterizedRowMapper implements
			ParameterizedRowMapper<AdminToolTipVO> {
		public AdminToolTipVO mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			AdminToolTipVO adminToolTipVO = new AdminToolTipVO();
			adminToolTipVO.setTlTpSeqId(rs.getString("tlTpSeqId"));
			adminToolTipVO.setTlTpPrmNm(rs.getString("tlTpPrmNm"));
			adminToolTipVO.setTlTpParVal(rs.getString("tlTpParVal"));
			adminToolTipVO.setTlTpShwInd("Y".equals(rs
					.getString("tlTpShwInd")));
			return adminToolTipVO;
		}
	}

	/**
	 * Create the specified setting.
	 * 
	 * @param name
	 * @param value
	 * @param updateSso
	 * @throws PWiException
	 */
	public void createToolTip(String name, String value, String updateSso)
			throws PWiException {
		try {
			StringBuilder builder = new StringBuilder();
			builder.append("INSERT INTO pwi.PWi_TLTP_PARAMETER");
			builder.append(" (TLTP_PRM_NM, TLTP_PRM_VAL");
			builder.append(", TLTP_PRM_SHW_IND, CRTN_DT");
			builder.append(", CRTD_BY, LST_UPDT_DT, LST_UPDTD_BY)");
			builder.append(" VALUES (?,?,?,SYSDATE,?,SYSDATE,?)");
			CreateToolTipPreparedStatementSetter pss = new CreateToolTipPreparedStatementSetter(
					name, value, updateSso);

			getJdbcTemplate().update(builder.toString(), pss);
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}

	private static class CreateToolTipPreparedStatementSetter implements
			PreparedStatementSetter {
		private String toolTipName;
		private String toolTipValue;
		private String updateSso;

		public CreateToolTipPreparedStatementSetter(String toolTipName,
				String toolTipValue, String updateSso) {
			this.toolTipName = toolTipName;
			this.toolTipValue = toolTipValue;
			this.updateSso = updateSso;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setString(1, toolTipName);
			ps.setString(2, toolTipValue);
			ps.setString(3, updateSso);
			ps.setString(4, updateSso);
			ps.setString(5, updateSso);
		}
	}

	/**
	 * Updates the value of an existing setting by name.
	 * 
	 * @param name
	 * @param value
	 * @param updateSso
	 * @throws PWiException
	 */
	public void updateToolTip(String name, String value, String updateSso)
			throws PWiException {
		try {
			StringBuilder builder = new StringBuilder();
			builder.append("UPDATE pwi.PWi_TLTP_PARAMETER");
			builder
					.append(" SET TLTP_PRM_VAL=?, LST_UPDT_DT=SYSDATE, LST_UPDTD_BY=?");
			builder.append(" WHERE TLTP_PRM_NM=?");

			UpdateToolTipPreparedStatementSetter pss = new UpdateToolTipPreparedStatementSetter(
					name, value, updateSso);

			getJdbcTemplate().update(builder.toString(), pss);
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}

	private static class UpdateToolTipPreparedStatementSetter implements
			PreparedStatementSetter {
		private String toolTipName;
		private String toolTipValue;
		private String updateSso;

		public UpdateToolTipPreparedStatementSetter(String toolTipName,
				String toolTipValue, String updateSso) {
			this.toolTipName = toolTipName;
			this.toolTipValue = toolTipValue;
			this.updateSso = updateSso;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setString(1, toolTipValue);
			ps.setString(2, updateSso);
			ps.setString(3, toolTipName);
		}
	}
}
