package com.geinfra.geaviation.pwi.json;

/**
 * 
 * Project      : Product Lifecycle Management Intelligence
 * Date Written : Jan 6, 2012
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : interface for objects that can be converted to JSON
 *               (JavaScript Object Notation - strings representing objects
 *               to communicate between Java and JavaScript)
 * 
 * Revision Log Jan 6, 2012 | v1.0.
 * --------------------------------------------------------------
 */
public interface Jsonable {
	public String toJson();
}
