/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMPersonDaoIfc.java
 * @Creation date: 09-Nov-2009
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.model.PWiUserVO;
import com.geinfra.geaviation.pwi.util.PLMCommonException;


/**
 * ICMPersonDaoIfc is the DAO implementation class used for Validating the User
 * SSOID.
 */
public interface PLMPersonDaoIfc {

	/**
	 * 
	 * @param ssoID
	 * @return Object
	 * @throws ICMCommonException
	 */
	public PLMLoginData validateUser(String ssoID) throws PLMCommonException;
	
	public PWiUserVO validateUserSSO(String ssoID) throws PLMCommonException;

}
