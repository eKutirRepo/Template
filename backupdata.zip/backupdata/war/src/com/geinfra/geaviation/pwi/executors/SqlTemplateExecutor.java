package com.geinfra.geaviation.pwi.executors;

import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.PWiQueryTimeoutException;
import com.geinfra.geaviation.pwi.common.PWiResultSizeLimitExceededException;
import com.geinfra.geaviation.pwi.model.PWiResultSet;
import com.geinfra.geaviation.pwi.sqltemplating.TemplateEval;
import com.geinfra.geaviation.pwi.util.QueryProcessingUtil;
import com.geinfra.geaviation.pwi.util.SqlTemplateUtil;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 1, 2011 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : Executes SQL queries based on a SQL template written with
 * PLMi's SQL template language.
 * 
 * Revision Log Aug 1, 2011 | v1.0.
 * 2012.12.18 pH  replaced GEAEResultSet with PWiResultSet
 * --------------------------------------------------------------
 */
public class SqlTemplateExecutor implements Executor {
	// Input parameters
	private String queryTemplate;
	private String dataSource;

	private TemplateEval templateEval;

	// Service
	private int queryTimeoutSecs;
	private int resultSizeLimit;

	public SqlTemplateExecutor(String dataSource, String queryTemplate,
			int queryTimeoutSecs, int resultSizeLimit) {
		this.dataSource = dataSource;
		this.queryTemplate = queryTemplate;
		this.queryTimeoutSecs = queryTimeoutSecs;
		this.resultSizeLimit = resultSizeLimit;
	}

	public PWiResultSet execute(QueryType queryType, Search search,
			SelectedColumns selectedColumns, String sso, String[] cols,
			List<Object[]> rows) throws PWiException,
			PWiResultSizeLimitExceededException, PWiQueryTimeoutException {
		// Generate SQL from template and input
		templateEval = SqlTemplateUtil.getInstance().evaluateTemplate(queryType,
				queryTemplate, search, selectedColumns, sso, cols, rows);

		// Execute SQL
		return QueryProcessingUtil.getInstance().executeQuery(queryType,
				dataSource, templateEval, queryTimeoutSecs, resultSizeLimit);
	}

	public String getExecutedQuery() {
		return templateEval.toString();
	}
}
