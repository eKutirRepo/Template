package com.geinfra.geaviation.pwi.bean;

import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;

import com.geinfra.geaviation.pwi.bean.util.BeanUtil;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.QueryAccessException;
import com.geinfra.geaviation.pwi.context.PWiContext;
import com.geinfra.geaviation.pwi.json.JsonBuilder;
import com.geinfra.geaviation.pwi.json.JsonUtil;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.model.PWiQueryNoXmlVO;
import com.geinfra.geaviation.pwi.service.QueriesService;
import com.geinfra.geaviation.pwi.service.QueryGroupService;
import com.geinfra.geaviation.pwi.servlet.KeywordSearchServlet;
import com.geinfra.geaviation.pwi.util.BookmarkableLinkUtil;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.util.RoleInfoUtil;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;


/**
 * 
 * Project : Product Lifecycle Management Intelligence
 * Date Written : May 21, 2010
 * Security : GE Confidential 
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Managed backing bean for the query search list page.
 * 
 * --------------------------------------------------------------
 */
public class QueryListBean {
	// Injected properties
	private QueriesService queriesService;
	private QueryGroupService queryGroupService;
	private QueriesBean queriesBean;

	private String queriesJson;
	private String groupsJson;
	private String userInfoJson;
	private String searchCriteria;
	private String searchResultsMessage;

	public void setQueriesService(QueriesService queriesService) {
		this.queriesService = queriesService;
	}

	public void setQueryGroupService(QueryGroupService queryGroupService) {
		this.queryGroupService = queryGroupService;
	}

	public void setQueriesBean(QueriesBean queriesBean) {
		this.queriesBean = queriesBean;
	}

	/**
	 * Initializes the query list bean for displaying the query list screen.
	 * 
	 * @param theSearchCriteria
	 * @param theQueries
	 * @return JSF navigation string
	 */
	public String init(String theSearchCriteria,
			List<PWiQueryNoXmlVO> theQueries) throws PWiException {
		// clear information to force a fresh retrieval
		queriesJson = null;
		groupsJson = null;
		userInfoJson = null;
		
		this.searchCriteria = theSearchCriteria;
		if (theQueries != null) {
			queriesJson = JsonUtil.getInstance().listToJson(theQueries);
			
		}

		// if we have queries, and we have searched on something, show a
		// message with the number of results and the search criteria
		if (theQueries != null && searchCriteria != null ) {
			if(theQueries.size()!=0)
			{
				searchResultsMessage = new StringBuffer().append("Showing ")
					.append(String.valueOf(theQueries.size()))
					.append((theQueries.size() == 1 ? " result" : " results"))
			        .append(" matching \"").append(getSearchCriteria())
			        .append("\".").toString();
			}
			else
			{
				//searchResultsMessage = "No result found for "+getSearchCriteria(); 
				searchResultsMessage = "No result found.";
			}
		} 
		else if(searchCriteria == null  || searchCriteria.equals("") ) {			
			searchResultsMessage = new StringBuffer().append("Please ")
				   .append(" enter the search criteria.").toString();
		}else
		{
			//searchResultsMessage = "No result found for "+getSearchCriteria();
			searchResultsMessage = "No result found.";
		}
	
		return PWiConstants.NAV_QUERY_LIST;
	}

	/**
	 * Searches for queries based on the search criteria entered by the user.
	 * 
	 * @return JSF navigation string
	 * @throws PWiException
	 * @throws NumberFormatException
	 * @throws QueryAccessException
	 */
	public String actionQuerySearch() throws NumberFormatException,
			PWiException, QueryAccessException {
		if ( ! queriesService.validateSearchQueryName(searchCriteria)) {
			this.searchResultsMessage = "No result found for invalid request.";
			
			return "";
		}
		else
		{
			return queriesBean.querySearch(searchCriteria);
		}
		
	}
	public String actionQuerySearchForKeyWord() throws NumberFormatException,
	PWiException, QueryAccessException {

		Map<?, ?> parameterMap = BookmarkableLinkUtil.getInstance()
		.getKeywordSearchParameterMapAttribute(
				FacesContext.getCurrentInstance(), true);

		// Retrieve keyword from parameters
		String keywordVal = BookmarkableLinkUtil
				.getInstance()
				.getParameter(
						parameterMap,
						KeywordSearchServlet.PARAMETER_SEARCH_KEYWORD);

			if ( ! queriesService.validateSearchQueryName(keywordVal)) {
				this.searchResultsMessage = "No result found for invalid request.";
	
				return "";
				}
			else
			{
	
				return queriesBean.querySearch(keywordVal);
			}

	}
	

	/**
	 * Clears the search criteria and loads all queries.
	 * 
	 * @return JSF navigation string
	 */
	public String actionClearSearch() {
		
		this.queriesJson = null;
		this.groupsJson = null;
		this.userInfoJson = null;
		this.searchCriteria = null;
		return PWiConstants.NAV_QUERY_LIST;
	}

	public List<String> suggestionActionQuerySearch(Object theSearchCriteria)
			throws PWiException {
		return queriesBean.getQuerySearchTypeahead((String) theSearchCriteria);
	}

	public String getSearchCriteria() {
		return searchCriteria;
	}

	public void setSearchCriteria(String searchCriteria) {
		
		if (searchCriteria == null || searchCriteria.trim().equals("")) {
			this.searchCriteria = null;
		}else{
			this.searchCriteria = searchCriteria;
		}
	}

	public String getSearchResultsMessage() {
		return searchResultsMessage;
	}

	public String getQueriesJson() throws PWiException {
		if (queriesJson == null) {
		
			List<String> groups = RoleInfoUtil.getInstance()
					.getRolesForUser(PWiContext.getCurrentInstance()
							.getUserSso());
			List<PWiQueryNoXmlVO> queries = queriesService.getVisibleQueries(groups);
			queriesJson = JsonUtil.getInstance().listToJson(queries);
		
		}		
		return queriesJson;
	}

	public String getGroupsJson() {
		if (groupsJson == null) {
			List<PWiQueryGroupVO> groups = queryGroupService
			.getAllQueryGroups();
			groupsJson = JsonUtil.getInstance().listToJson(groups);
		}
	
		return groupsJson;
	}

	public String getUserInfoJson() throws PWiException {
		if (userInfoJson == null) {
			String sso = PWiContext.getCurrentInstance().getUserSso();
			boolean usPerson = UserInfoPortalUtil.getInstance().isUsPerson();
			boolean geEmployee = UserInfoPortalUtil.getInstance().isGePerson();
			List<PWiQueryGroupVO> groups = queryGroupService.getUserGroups(sso);

			JsonBuilder builder = new JsonBuilder();
			builder.startObject();
			builder.addStringProperty("ssoId", sso);
			builder.startArrayProperty("groupIds");
			for (PWiQueryGroupVO group : groups) {
				Integer groupId = group.getQueryGroupId();
				builder.addStringElement(groupId);
			}
			builder.endArray();
			builder.addBooleanProperty("usPerson", usPerson);
			builder.addBooleanProperty("geEmployee", geEmployee);
			builder.endObject();
			
			userInfoJson = builder.toString();
		}
		return userInfoJson;
	}
	public String actionBuildQuery() throws NumberFormatException,PWiException, QueryAccessException 
	{	
		FacesContext context = FacesContext.getCurrentInstance();
		String queryId = context.getExternalContext().getRequestParameterMap()
				.get("qryId");
		QueryBuilderBean queryBuilderBean = BeanUtil.getInstance().getQueryBuilderBean();
		queryBuilderBean.init(Integer.valueOf(queryId), null);
		return PWiConstants.NAV_QUERY_BUILDER;
	}
}