/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMLttrData.java
 * @Creation date: 27-Mar-2012
 * @version 2.0.1
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.data;



public class PLMLttrData 
{
	/**
	  * Holds the rowKey
	  */
	private int rowKey;
	/**
	  * Holds the mlNo
	  */
	private String mlNumLttr;
	/**
	  * Holds the bomLevel
	  */
	private int bomLevel;
	/**
	  * Holds the parentPdName
	  */
	private String parentPdName;
	/**
	  * Holds the parentPin
	  */
	private String parentPin;
	/**
	  * Holds the pdName
	  */
	private String pdName;
	/**
	  * Holds the pdNameDesc
	  */
	private String pdNameDesc;
	/**
	  * Holds the mli
	  */
	private String mli;
	/**
	  * Holds the pin
	  */
	private String pin;
	/**
	  * Holds the hpin
	  */
	private String hpin;
	/**
	  * Holds the prefix
	  */
	private String prefix;
	/**
	  * Holds the suffix
	  */
	private String suffix;
	/**
	  * Holds the qty
	  */
	private double qty;
	/**
	  * Holds the unitMeasure
	  */
	private String unitMeasure;
	/**
	  * Holds the weekChange
	  */
	private String weekChange;
	/**
	  * Holds the monthChange
	  */
	private String monthChange;
	/**
	  * Holds the dateChange
	  */
	private String dateChange;
	/**
	  * Holds the docName
	  */
	private String docName;
	/**
	  * Holds the docRev
	  */
	private String docRev;
	/**
	  * Holds the docDesc
	  */
	private String docDesc;
	/**
	  * Holds the docType
	  */
	private String docType;
	/**
	  * Holds the exportControl
	  */
	private String exportControl;
	/**
	  * Holds the docClass
	  */
	private String docClass;
	/**
	  * Holds the pathFlag
	  */
	private String pathFlag;
	/**
	  * Holds the lastMonthChng
	  */
	private String lastMonthChng;
	/**
	  * Holds the lastWeekChng
	  */
	private String lastWeekChng;
	/**
	  * Holds the docState
	  */
	private String docState;
	//Newly Added fields for 6.1 Release
	/**
	  * Holds the prntItemSrcType
	  */
	private String prntItemSrcType;
	/**
	  * Holds the cntntItemSrcType
	  */
	private String cntntItemSrcType;
	 /**
	  * Holds the modelValidated
	  */
	 private String modelValidated;

	/**
	 * @return the mlNumLttr
	 */
	public String getMlNumLttr() {
		return mlNumLttr;
	}
	/**
	 * @param mlNumLttr the mlNumLttr to set
	 */
	public void setMlNumLttr(String mlNumLttr) {
		this.mlNumLttr = mlNumLttr;
	}
	/**
	 * @return the prefix
	 */
	public String getPrefix() {
		return prefix;
	}
	/**
	 * @param prefix the prefix to set
	 */
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	/**
	 * @return the mli
	 */
	public String getMli() {
		return mli;
	}
	/**
	 * @param mli the mli to set
	 */
	public void setMli(String mli) {
		this.mli = mli;
	}
	/**
	 * @return the pin
	 */
	public String getPin() {
		return pin;
	}
	/**
	 * @param pin the pin to set
	 */
	public void setPin(String pin) {
		this.pin = pin;
	}
	/**
	 * @return the hpin
	 */
	public String getHpin() {
		return hpin;
	}
	/**
	 * @param hpin the hpin to set
	 */
	public void setHpin(String hpin) {
		this.hpin = hpin;
	}
	/**
	 * @return the pdName
	 */
	public String getPdName() {
		return pdName;
	}
	/**
	 * @param pdName the pdName to set
	 */
	public void setPdName(String pdName) {
		this.pdName = pdName;
	}
	/**
	 * @return the suffix
	 */
	public String getSuffix() {
		return suffix;
	}
	/**
	 * @param suffix the suffix to set
	 */
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	/**
	 * @return the unitMeasure
	 */
	public String getUnitMeasure() {
		return unitMeasure;
	}
	/**
	 * @param unitMeasure the unitMeasure to set
	 */
	public void setUnitMeasure(String unitMeasure) {
		this.unitMeasure = unitMeasure;
	}
	/**
	 * @return the docName
	 */
	public String getDocName() {
		return docName;
	}
	/**
	 * @param docName the docName to set
	 */
	public void setDocName(String docName) {
		this.docName = docName;
	}
	/**
	 * @return the docRev
	 */
	public String getDocRev() {
		return docRev;
	}
	/**
	 * @param docRev the docRev to set
	 */
	public void setDocRev(String docRev) {
		this.docRev = docRev;
	}
	/**
	 * @return the docDesc
	 */
	public String getDocDesc() {
		return docDesc;
	}
	/**
	 * @param docDesc the docDesc to set
	 */
	public void setDocDesc(String docDesc) {
		this.docDesc = docDesc;
	}
	/**
	 * @return the docType
	 */
	public String getDocType() {
		return docType;
	}
	/**
	 * @param docType the docType to set
	 */
	public void setDocType(String docType) {
		this.docType = docType;
	}
	/**
	 * @return the exportControl
	 */
	public String getExportControl() {
		return exportControl;
	}
	/**
	 * @param exportControl the exportControl to set
	 */
	public void setExportControl(String exportControl) {
		this.exportControl = exportControl;
	}
	/**
	 * @return the docClass
	 */
	public String getDocClass() {
		return docClass;
	}
	/**
	 * @param docClass the docClass to set
	 */
	public void setDocClass(String docClass) {
		this.docClass = docClass;
	}
	/**
	 * @return the dateChange
	 */
	public String getDateChange() {
		return dateChange;
	}
	/**
	 * @param dateChange the dateChange to set
	 */
	public void setDateChange(String dateChange) {
		this.dateChange = dateChange;
	}
	
	/**
	 * @return the parentPdName
	 */
	public String getParentPdName() {
		return parentPdName;
	}
	/**
	 * @param parentPdName the parentPdName to set
	 */
	public void setParentPdName(String parentPdName) {
		this.parentPdName = parentPdName;
	}
	/**
	 * @return the parentPin
	 */
	public String getParentPin() {
		return parentPin;
	}
	/**
	 * @param parentPin the parentPin to set
	 */
	public void setParentPin(String parentPin) {
		this.parentPin = parentPin;
	}
	/**
	 * @return the pdNameDesc
	 */
	public String getPdNameDesc() {
		return pdNameDesc;
	}
	/**
	 * @param pdNameDesc the pdNameDesc to set
	 */
	public void setPdNameDesc(String pdNameDesc) {
		this.pdNameDesc = pdNameDesc;
	}
	
	/**
	 * @return the bomLevel
	 */
	public int getBomLevel() {
		return bomLevel;
	}
	/**
	 * @param bomLevel the bomLevel to set
	 */
	public void setBomLevel(int bomLevel) {
		this.bomLevel = bomLevel;
	}
	
	/**
	 * @return the pathFlag
	 */
	public String getPathFlag() {
		return pathFlag;
	}
	/**
	 * @param pathFlag the pathFlag to set
	 */
	public void setPathFlag(String pathFlag) {
		this.pathFlag = pathFlag;
	}
	
	/**
	 * @return the rowKey
	 */
	public int getRowKey() {
		return rowKey;
	}
	/**
	 * @param rowKey the rowKey to set
	 */
	public void setRowKey(int rowKey) {
		this.rowKey = rowKey;
	}
	/**
	 * @return the qty
	 */
	public double getQty() {
		return qty;
	}
	/**
	 * @param qty the qty to set
	 */
	public void setQty(double qty) {
		this.qty = qty;
	}
	/**
	 * @return the lastMonthChng
	 */
	public String getLastMonthChng() {
		return lastMonthChng;
	}
	/**
	 * @param lastMonthChng the lastMonthChng to set
	 */
	public void setLastMonthChng(String lastMonthChng) {
		this.lastMonthChng = lastMonthChng;
	}
	/**
	 * @return the lastWeekChng
	 */
	public String getLastWeekChng() {
		return lastWeekChng;
	}
	/**
	 * @param lastWeekChng the lastWeekChng to set
	 */
	public void setLastWeekChng(String lastWeekChng) {
		this.lastWeekChng = lastWeekChng;
	}
	/**
	 * @return the weekChange
	 */
	public String getWeekChange() {
		return weekChange;
	}
	/**
	 * @param weekChange the weekChange to set
	 */
	public void setWeekChange(String weekChange) {
		this.weekChange = weekChange;
	}
	/**
	 * @return the monthChange
	 */
	public String getMonthChange() {
		return monthChange;
	}
	/**
	 * @param monthChange the monthChange to set
	 */
	public void setMonthChange(String monthChange) {
		this.monthChange = monthChange;
	}
	/**
	 * @return the docState
	 */
	public String getDocState() {
		return docState;
	}
	/**
	 * @param docState the docState to set
	 */
	public void setDocState(String docState) {
		this.docState = docState;
	}
	/**
	 * @return the prntItemSrcType
	 */
	public String getPrntItemSrcType() {
		return prntItemSrcType;
	}
	/**
	 * @param prntItemSrcType the prntItemSrcType to set
	 */
	public void setPrntItemSrcType(String prntItemSrcType) {
		this.prntItemSrcType = prntItemSrcType;
	}
	/**
	 * @return the cntntItemSrcType
	 */
	public String getCntntItemSrcType() {
		return cntntItemSrcType;
	}
	/**
	 * @param cntntItemSrcType the cntntItemSrcType to set
	 */
	public void setCntntItemSrcType(String cntntItemSrcType) {
		this.cntntItemSrcType = cntntItemSrcType;
	}
	/**
	 * @return the modelValidated
	 */
	public String getModelValidated() {
		return modelValidated;
	}
	/**
	 * @param modelValidated the modelValidated to set
	 */
	public void setModelValidated(String modelValidated) {
		this.modelValidated = modelValidated;
	}
	
}