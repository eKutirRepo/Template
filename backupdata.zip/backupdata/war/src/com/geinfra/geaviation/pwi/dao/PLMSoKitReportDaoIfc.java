/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMSoKitReportDaoIfc.java
 * @Creation date: 01-Jan-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.Map;

import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMSoKitReportDaoIfc {
	
	/**
	 * This method is used to getGBOMData
	 * @return java.util.List
	 * @param varMap
	 * @throws PLMCommonException
	 */
	public Map<String,Object> getGenSOKitRptData(Map<String, Object> varMap) throws PLMCommonException,Exception;

}
