/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileNamePLMCustDocReportMB.java
 * @Creation date: 16-March-2015
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMCustDocReportData;
import com.geinfra.geaviation.pwi.service.PLMCustDocReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;


public class PLMCustDocReportMB {
	private static final Logger LOG = Logger.getLogger(PLMCustDocReportMB.class);
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor=null;
	/**
	 * Holds the PLMCustDocReportServiceIfc
	 */
	private PLMCustDocReportServiceIfc plmCustDocReportService = null;

	/**
	 * Holds the PLMCommonMB
	 */
	private PLMCommonMB commonMB=null;

	/**
	 * Holds the PLMCustDocReportData
	 */
	private PLMCustDocReportData plmCustDocReportData = new PLMCustDocReportData();

	private String alertMessage="";
	private String fwdFlag;
	private String typeOfReport="";
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the searchResultList
	 */
	private List<PLMCustDocReportData> searchResultList=new ArrayList<PLMCustDocReportData>();
	/**
	 * Holds the totalRecCountMsg
	 */
	private String totalRecCountMsg;
	private String selCrtMsg;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;

	private String userEmail;
	private String userName;

	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");

	private boolean pgplmtcfExhFlag = false;
	private boolean pgplmExhFlag = false;
	private boolean tcfExhFlag = false;
	private boolean exportToExcelFlag=false;
	private boolean pgplmtcfFixedFlag = false;
	private boolean pgplmFixedFlag = false;
	private boolean tcfFixedFlag = false;


	/**
	 * This method is used for loadCustDocReportSearchPage
	 * 
	 * @return String
	 */
	public String loadCustDocReportSearchPage() {
		LOG.info("Entering loadCustDocReportSearchPage Method");
		try {
			commonMB.insertCannedRptRecordHitInfo("Customer Documents Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		alertMessage="";
		plmCustDocReportData = new PLMCustDocReportData();
		resetSearchData();
		searchResultList.clear();
		plmCustDocReportData.setSourceOfResult("pgplmtcf");

		LOG.info("Exiting loadCustDocReportSearchPage Method");
		return "custDocReportSearch";
	}

	public String resetSearchData(){
		LOG.info("Inside resetSearchData()...");
		alertMessage="";
		plmCustDocReportData.setEnteredProjContract("");
		plmCustDocReportData.setEnteredMLI("");
		plmCustDocReportData.setEnteredFuncSystem("");
		plmCustDocReportData.setEnteredDocName("");
		plmCustDocReportData.setOrigFromDate(null);
		plmCustDocReportData.setOrigToDate(null);
		plmCustDocReportData.setOnlySentDocs(false);
		plmCustDocReportData.setExhaustiveList(false);
		plmCustDocReportData.setSourceOfResult("pgplmtcf");
		searchResultList.clear();
		typeOfReport="";
		LOG.info("Existing resetSearchData()...");

		return "custDocReportSearch";
	}


	/**
	 * This method is used for Get Search Eco Data
	 * 
	 * @return String
	 */
	public String getCustDocReport() {
		LOG.info("Inside getCustDocReport.....");
		alertMessage="";
		exportToExcelFlag=false;
		LOG.info("Selected Contract/Project: "+plmCustDocReportData.getEnteredProjContract());
		LOG.info("Selected MLI: "+plmCustDocReportData.getEnteredMLI());
		LOG.info("Selected Functional System: "+plmCustDocReportData.getEnteredFuncSystem());
		LOG.info("Selected Document Name: "+plmCustDocReportData.getEnteredDocName());
		LOG.info("Selected From Date: "+plmCustDocReportData.getOrigFromDate());
		LOG.info("Selected To Date: "+plmCustDocReportData.getOrigToDate());
		LOG.info("Selected Only Sent Documents: "+plmCustDocReportData.isOnlySentDocs());
		LOG.info("Selected Source: "+plmCustDocReportData.getSourceOfResult());
		LOG.info("Selected Exhaustive Attribute List: "+plmCustDocReportData.isExhaustiveList());
		fwdFlag = "";
		totalRecCount = 0;
		Date frm_orig_date = plmCustDocReportData.getOrigFromDate();
		Date to_orig_date = plmCustDocReportData.getOrigToDate();
		if (PLMUtils.isEmpty(plmCustDocReportData.getEnteredProjContract())
				&& PLMUtils.isEmpty(plmCustDocReportData.getEnteredMLI())
				&& PLMUtils.isEmpty(plmCustDocReportData.getEnteredFuncSystem())
				&& PLMUtils.isEmpty(plmCustDocReportData.getEnteredDocName())
				&& PLMUtils.isEmptyDate(frm_orig_date)
				&& PLMUtils.isEmptyDate(to_orig_date)) {
			//fieldName = PLMConstants.UI_ISSUES_SEARCH;
			alertMessage = PLMConstants.CUST_DOC_SRCH_CRT;
			return "custDocReportSearch";
		} else {

			//Checking and Formatting Contract/Project Name

			if(!PLMUtils.checkForSpecialCharsCustDoc((plmCustDocReportData.getEnteredProjContract()))){
				LOG.info("Special Character exists in Project Contract...");
				//alertMessage="No Special Characters allowed in Contract/Project";
				alertMessage=PLMConstants.CUSTDOC_SPLCHAR_PROJCON;
				return "custDocReportSearch";

			}
			if(plmCustDocReportData.getEnteredProjContract().contains("*") 
					|| plmCustDocReportData.getEnteredProjContract().contains("?")){
				if(!PLMUtils.checkForCharsDigitsCustDocNew((plmCustDocReportData.getEnteredProjContract()))){
					LOG.info("Project Contract has a * or ? but does not have a char or digit...");
					//alertMessage="No Special Characters allowed in Contract/Project";
					alertMessage=PLMConstants.CUSTDOC_CHARDIGIT_PROJCON;
					return "custDocReportSearch";

				}
			}
			//Checking and Formatting MLI
			if(!PLMUtils.checkForSpecialCharsCustDoc1((plmCustDocReportData.getEnteredMLI()))){
				LOG.info("Special Character exists in MLI...");
				//alertMessage="No Special Characters allowed in MLI";
				alertMessage=PLMConstants.CUSTDOC_SPLCHAR_MLI;
				return "custDocReportSearch";

			}
			//Checking and Formatting Functional System

			if(!PLMUtils.checkForSpecialCharsCustDoc1((plmCustDocReportData.getEnteredFuncSystem()))){
				LOG.info("Special Character exists in Func System...");
				//alertMessage="No Special Characters allowed in Functional System";
				alertMessage=PLMConstants.CUSTDOC_SPLCHAR_FUNSYS;
				return "custDocReportSearch";

			}
			//Checking and Formatting Document Name

			if(!PLMUtils.checkForSpecialCharsCustDoc((plmCustDocReportData.getEnteredDocName()))){
				LOG.info("Special Character exists in Document Name...");
				//alertMessage="No Special Characters allowed in Document Name";
				alertMessage=PLMConstants.CUSTDOC_SPLCHAR_DOC;
				return "custDocReportSearch";

			}
			if(plmCustDocReportData.getEnteredDocName().contains("*") 
					|| plmCustDocReportData.getEnteredDocName().contains("?")){
				if(!PLMUtils.checkForCharsDigitsCustDocNew((plmCustDocReportData.getEnteredDocName()))){
					LOG.info("Document Name has a ? or * but does not have a char or digit...");
					alertMessage=PLMConstants.CUSTDOC_CHARDIGIT_DOC;
					return "custDocReportSearch";

				}
			}
			//Checking and Formatting Dates
			if (PLMUtils.checkForNullOfTwoDates(frm_orig_date, to_orig_date)) {
				alertMessage = alertMessage + PLMConstants.Dates_NullCheck_Msg;
				return "custDocReportSearch";
			} 
			if (PLMUtils.checkForFromAndToDate(frm_orig_date, to_orig_date)) {
				alertMessage = alertMessage + PLMConstants.Date_ValMsg;
				return "custDocReportSearch";
			}
		}
		if (PLMUtils.isEmpty(alertMessage)) {
			LOG.info("No Validation error is there... proceeding further");

			try {
				searchResultList = plmCustDocReportService
						.getCustDocReport(plmCustDocReportData);
				if (searchResultList != null) {
					totalRecCount = searchResultList.size();
					if(!plmCustDocReportData.isExhaustiveList() && totalRecCount<=PLMConstants.CUSTDOC_RPT_SIZE_NONEX){
						exportToExcelFlag=true;
					}else if(plmCustDocReportData.isExhaustiveList() && totalRecCount<=PLMConstants.CUSTDOC_RPT_SIZE_EX){
						exportToExcelFlag=true;
					}
					else{
						exportToExcelFlag=false;
					}
				} else {
					totalRecCount = 0;
				}
				LOG.info("Fetched Result List of size:: "+totalRecCount);

				StringBuffer selCrtMsgTemp=new StringBuffer();
				if(plmCustDocReportData.getEnteredProjContract()!=null && plmCustDocReportData.getEnteredProjContract().length()>0){
					selCrtMsgTemp.append("Project/Contract: "+plmCustDocReportData.getEnteredProjContract());
				}
				if(plmCustDocReportData.getEnteredMLI()!=null && plmCustDocReportData.getEnteredMLI().length()>0){
					selCrtMsgTemp.append(" MLI: "+plmCustDocReportData.getEnteredMLI());
				}
				if(plmCustDocReportData.getEnteredFuncSystem()!=null && plmCustDocReportData.getEnteredFuncSystem().length()>0){
					selCrtMsgTemp.append(" Functional System: "+plmCustDocReportData.getEnteredFuncSystem());
				}
				if(plmCustDocReportData.getEnteredDocName()!=null && plmCustDocReportData.getEnteredDocName().length()>0){
					selCrtMsgTemp.append(" Document Name: "+plmCustDocReportData.getEnteredDocName());
				}
				selCrtMsg=selCrtMsgTemp.toString();

				totalRecCountMsg = "Total Results Count : " + totalRecCount;
				LOG.info("totalRecCount::::::::::::::::::" + totalRecCount);
				if (totalRecCount == 0) {
					fwdFlag = "invalidCustDoc";
				} else {
					recordCounts = PLMConstants.N_100;
					fwdFlag = "custDocReportResult";
				}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getCustDocReport: ", exception);
				//fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"custDocReportSearch","custDocReportResult");
				fwdFlag="";
			} 
		}
		setFixedFlags();
		setExhFlags();

		LOG.info("Existing getCustDocReport.....");
		//return "custDocReportResult";
		return fwdFlag;

	}

	public void setExhFlags(){
		LOG.info("Inside setExhFlags()");
		pgplmtcfExhFlag=false;
		pgplmExhFlag=false;
		tcfExhFlag=false;
		if(plmCustDocReportData.isExhaustiveList() && plmCustDocReportData.getSourceOfResult().equals("pgplmtcf")){
			LOG.info("Making pgplmtcfExhFlag=true...........");
			pgplmtcfExhFlag=true;
		}

		if(plmCustDocReportData.isExhaustiveList() && plmCustDocReportData.getSourceOfResult().equals("pgplm")){
			LOG.info("Making pgplmExhFlag=true...........");
			pgplmExhFlag=true;
		}

		if(plmCustDocReportData.isExhaustiveList() && plmCustDocReportData.getSourceOfResult().equals("tcf")){
			LOG.info("Making tcfExhFlag=true...........");
			tcfExhFlag=true;
		}

		LOG.info("Existing setExhFlags()");

	}

	public void setFixedFlags(){
		LOG.info("Inside setFixedFlags()");
		pgplmtcfFixedFlag=false;
		pgplmFixedFlag=false;
		tcfFixedFlag=false;
		if(plmCustDocReportData.getSourceOfResult().equals("pgplmtcf")){
			LOG.info("Making pgplmtcfFixedFlag=true...........");
			pgplmtcfFixedFlag=true;
		}

		if(plmCustDocReportData.getSourceOfResult().equals("pgplm")){
			LOG.info("Making pgplmFixedFlag=true...........");
			pgplmFixedFlag=true;
		}

		if(plmCustDocReportData.getSourceOfResult().equals("tcf")){
			LOG.info("Making tcfFixedFlag=true...........");
			tcfFixedFlag=true;
		}

		LOG.info("Existing setFixedFlags()");

	}

	/**
	 * This method is used for sendEmail
	 * 
	 */
	public void sendEmail(){
		alertMessage="";
		Date frm_orig_date = plmCustDocReportData.getOrigFromDate();
		Date to_orig_date = plmCustDocReportData.getOrigToDate();
		if (PLMUtils.isEmpty(plmCustDocReportData.getEnteredProjContract())
				&& PLMUtils.isEmpty(plmCustDocReportData.getEnteredMLI())
				&& PLMUtils.isEmpty(plmCustDocReportData.getEnteredFuncSystem())
				&& PLMUtils.isEmpty(plmCustDocReportData.getEnteredDocName())
				&& PLMUtils.isEmptyDate(frm_orig_date)
				&& PLMUtils.isEmptyDate(to_orig_date)) {

			alertMessage =alertMessage+ PLMConstants.CUST_DOC_SRCH_CRT;
			//return "custDocReportSearch";
		} else {

			//Checking and Formatting Contract/Project Name

			if(!PLMUtils.checkForSpecialCharsCustDoc((plmCustDocReportData.getEnteredProjContract()))){
				LOG.info("Special Character exists in Project Contract...");

				alertMessage=alertMessage+PLMConstants.CUSTDOC_SPLCHAR_PROJCON;
				//return "custDocReportSearch";

			}
			if(plmCustDocReportData.getEnteredProjContract().contains("*") 
					|| plmCustDocReportData.getEnteredProjContract().contains("?")){
				if(!PLMUtils.checkForCharsDigitsCustDocNew((plmCustDocReportData.getEnteredProjContract()))){
					LOG.info("Project Contract has a * or ? but does not have a char or digit...");
					//alertMessage="No Special Characters allowed in Contract/Project";
					alertMessage=alertMessage+PLMConstants.CUSTDOC_CHARDIGIT_PROJCON;
					//return "custDocReportSearch";

				}
			}
			//Checking and Formatting Contract/Project Name


			if(!PLMUtils.checkForSpecialCharsCustDoc1((plmCustDocReportData.getEnteredMLI()))){
				LOG.info("Special Character exists in MLI...");

				alertMessage=alertMessage+PLMConstants.CUSTDOC_SPLCHAR_MLI;
				//return "custDocReportSearch";

			}
			//Checking and Formatting Functional System
			if(!PLMUtils.checkForSpecialCharsCustDoc1((plmCustDocReportData.getEnteredFuncSystem()))){
				LOG.info("Special Character exists in Func System...");

				alertMessage=alertMessage+PLMConstants.CUSTDOC_SPLCHAR_FUNSYS;
				//return "custDocReportSearch";

			}
			//Checking and Formatting Document Name
			if(!PLMUtils.checkForSpecialCharsCustDoc((plmCustDocReportData.getEnteredDocName()))){
				LOG.info("Special Character exists in Document Name...");

				alertMessage=alertMessage+PLMConstants.CUSTDOC_SPLCHAR_DOC;
				//return "custDocReportSearch";
			}
			if(plmCustDocReportData.getEnteredDocName().contains("*") 
					|| plmCustDocReportData.getEnteredDocName().contains("?")){
				if(!PLMUtils.checkForCharsDigitsCustDocNew((plmCustDocReportData.getEnteredDocName()))){
					LOG.info("Document Name has a ? or * but does not have a char or digit...");
					//alertMessage="No Special Characters allowed in Contract/Project";
					alertMessage=alertMessage+PLMConstants.CUSTDOC_CHARDIGIT_DOC;
					//return "custDocReportSearch";

				}
			}
			//Checking and Formatting Dates
			if (PLMUtils.checkForNullOfTwoDates(frm_orig_date, to_orig_date)) {
				alertMessage = alertMessage + PLMConstants.Dates_NullCheck_Msg;
				//return "custDocReportSearch";
			} 
			if (PLMUtils.checkForFromAndToDate(frm_orig_date, to_orig_date)) {
				alertMessage = alertMessage + PLMConstants.Date_ValMsg;
				//return "custDocReportSearch";
			}
		}
		if (PLMUtils.isEmpty(alertMessage)) {
			LOG.info("No Validation error is there... proceeding further to send Email");
			try {
				userName = UserInfoPortalUtil.getInstance().getUserName();
				userEmail = UserInfoPortalUtil.getInstance().getUserEmail();		
			}catch (PWiException e) {
				LOG.log(Level.ERROR, "Exception@sendEmail: ", e);
			}
			alertMessage = PLMConstants.CUSTDOC_MAIL_RERORT_ALERT;
			taskExecutor.execute(new MailThread());
		}

	}

	/**
	 * This method is used for sendEmail
	 * 
	 */
	public void sendEmailComma(){
		alertMessage="";
		Date frm_orig_date = plmCustDocReportData.getOrigFromDate();
		Date to_orig_date = plmCustDocReportData.getOrigToDate();
		if (PLMUtils.isEmpty(plmCustDocReportData.getEnteredProjContract())
				&& PLMUtils.isEmpty(plmCustDocReportData.getEnteredMLI())
				&& PLMUtils.isEmpty(plmCustDocReportData.getEnteredFuncSystem())
				&& PLMUtils.isEmpty(plmCustDocReportData.getEnteredDocName())
				&& PLMUtils.isEmptyDate(frm_orig_date)
				&& PLMUtils.isEmptyDate(to_orig_date)) {

			alertMessage = alertMessage+PLMConstants.CUST_DOC_SRCH_CRT;
			//return "custDocReportSearch";
		} else {

			//Checking and Formatting Contract/Project Name

			if(!PLMUtils.checkForSpecialCharsCustDoc((plmCustDocReportData.getEnteredProjContract()))){
				LOG.info("Special Character exists in Project Contract...");
				//alertMessage="No Special Characters allowed in Contract/Project";
				alertMessage=alertMessage+PLMConstants.CUSTDOC_SPLCHAR_PROJCON;
				//return "custDocReportSearch";

			}
			if(plmCustDocReportData.getEnteredProjContract().contains("*") 
					|| plmCustDocReportData.getEnteredProjContract().contains("?")){
				if(!PLMUtils.checkForCharsDigitsCustDocNew((plmCustDocReportData.getEnteredProjContract()))){
					LOG.info("Project Contract has a * or ? but does not have a char or digit...");
					//alertMessage="No Special Characters allowed in Contract/Project";
					alertMessage=alertMessage+PLMConstants.CUSTDOC_CHARDIGIT_PROJCON;
					//return "custDocReportSearch";

				}
			}
			//Checking and Formatting Contract/Project Name


			if(!PLMUtils.checkForSpecialCharsCustDoc1((plmCustDocReportData.getEnteredMLI()))){
				LOG.info("Special Character exists in MLI...");
				//alertMessage="No Special Characters allowed in MLI";
				alertMessage=alertMessage+PLMConstants.CUSTDOC_SPLCHAR_MLI;
				//return "custDocReportSearch";

			}

			//Checking and Formatting Functional System
			if(!PLMUtils.checkForSpecialCharsCustDoc1((plmCustDocReportData.getEnteredFuncSystem()))){
				LOG.info("Special Character exists in Func System...");
				//alertMessage="No Special Characters allowed in Functional System";
				alertMessage=alertMessage+PLMConstants.CUSTDOC_SPLCHAR_FUNSYS;
				//return "custDocReportSearch";

			}
			//Checking and Formatting Document Name

			if(!PLMUtils.checkForSpecialCharsCustDoc((plmCustDocReportData.getEnteredDocName()))){
				LOG.info("Special Character exists in Document Name...");
				//alertMessage="No Special Characters allowed in Document Name";
				alertMessage=alertMessage+PLMConstants.CUSTDOC_SPLCHAR_DOC;
				//return "custDocReportSearch";

			}
			if(plmCustDocReportData.getEnteredDocName().contains("*") 
					|| plmCustDocReportData.getEnteredDocName().contains("?")){
				if(!PLMUtils.checkForCharsDigitsCustDocNew((plmCustDocReportData.getEnteredDocName()))){
					LOG.info("Document Name has a ? or * but does not have a char or digit...");
					//alertMessage="No Special Characters allowed in Contract/Project";
					alertMessage=alertMessage+PLMConstants.CUSTDOC_CHARDIGIT_DOC;
					//return "custDocReportSearch";

				}
			}
			//Checking and Formatting Dates
			if (PLMUtils.checkForNullOfTwoDates(frm_orig_date, to_orig_date)) {
				alertMessage = alertMessage + PLMConstants.Dates_NullCheck_Msg;
				//return "custDocReportSearch";
			} 
			if (PLMUtils.checkForFromAndToDate(frm_orig_date, to_orig_date)) {
				alertMessage = alertMessage + PLMConstants.Date_ValMsg;
				//return "custDocReportSearch";
			}
		}
		if (PLMUtils.isEmpty(alertMessage)) {
			LOG.info("No Validation error is there... proceeding further to send Email");
			try {
				userName = UserInfoPortalUtil.getInstance().getUserName();
				userEmail = UserInfoPortalUtil.getInstance().getUserEmail();		
			}catch (PWiException e) {
				LOG.log(Level.ERROR, "Exception@sendEmailComma: ", e);
			}
			
			alertMessage = PLMConstants.CUSTDOC_MAIL_RERORT_ALERT;
			taskExecutor.execute(new MailThreadComma());
		}

	}
	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendCustDocReportMail();
		}
	}	

	/**
	 * Background Process Thread
	 */
	private class MailThreadComma implements Runnable {
		public MailThreadComma(){}
		public void run() {
			sendCustDocReportMailComma();
		}
	}

	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return String
	 */
	public void sendCustDocReportMail() {
		LOG.info("Entering sendCustDocReportMail Method");

		String from = PLMConstants.LTTR_MAIL_FROM;
		//String to = userDataObj.getUserEmail();
		String to = userEmail;
		//String toAddressee = userDataObj.getGivenName_LD().replace(",", "");
		String toAddressee = userName;
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.CUSTDOC_MAIL_SUBJECT;
		StringBuffer mailBody = new StringBuffer().append(toAddressee)
				.append(PLMConstants.CUSTDOC_MAIL_CONTENT)

				.append("\n")
				.append("Search Criteria \n")
				.append("--------------- \n")
				.append("Project/Contract: "+plmCustDocReportData.getEnteredProjContract()+"\n")
				.append("MLI: "+plmCustDocReportData.getEnteredMLI()+"\n")
				.append("Functional System: "+plmCustDocReportData.getEnteredFuncSystem()+"\n")
				.append("Document Name: "+plmCustDocReportData.getEnteredDocName()+"\n");
		if(plmCustDocReportData.getOrigFromDate()!=null){
			mailBody.append("Contract Originated (From) : "+plmCustDocReportData.getOrigFromDate()+"\n");

		}else{
			mailBody.append("Contract Originated (From) : "+""+"\n");

		}
		if(plmCustDocReportData.getOrigToDate()!=null){
			mailBody.append("Contract Originated (To) : "+plmCustDocReportData.getOrigToDate()+"\n\n\n");
		}else{
			mailBody.append("Contract Originated (To) : "+""+"\n\n\n");
		}
		mailBody.append(PLMConstants.LTTR_MAIL_SIGNATURE)
		.append(PLMConstants.LTTR_MAIL_FOOTER);
		LOG.info(mailBody.toString());

		StringBuffer mailNoDataBody = new StringBuffer()
		.append(toAddressee)
		.append(PLMConstants.CUSTDOC_NO_CONTENT_BODY)

		.append("\n")
		.append("Search Criteria \n")
		.append("--------------- \n")
		.append("Project/Contract: "+plmCustDocReportData.getEnteredProjContract()+"\n")
		.append("MLI: "+plmCustDocReportData.getEnteredMLI()+"\n")
		.append("Functional System: "+plmCustDocReportData.getEnteredFuncSystem()+"\n")
		.append("Document Name: "+plmCustDocReportData.getEnteredDocName()+"\n");
		if(plmCustDocReportData.getOrigFromDate()!=null){
			mailNoDataBody.append("Contract Originated (From) : "+plmCustDocReportData.getOrigFromDate()+"\n");
		}else{
			mailNoDataBody.append("Contract Originated (From) : "+""+"\n");
		}
		if(plmCustDocReportData.getOrigToDate()!=null){
			mailNoDataBody.append("Contract Originated (To) : "+plmCustDocReportData.getOrigToDate()+"\n\n\n");
		}else{
			mailNoDataBody.append("Contract Originated (To) : "+""+"\n\n\n");
		}

		mailNoDataBody.append(PLMConstants.LTTR_MAIL_SIGNATURE)

		.append(PLMConstants.LTTR_MAIL_FOOTER);
		LOG.info(mailNoDataBody.toString());

		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		LOG.info("file dir=============================="+fileDir);

		String filePathCSVSemColDelim = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("CUST_DOC_RPT_NM")  + "_" + uniqTime + ".csv";
		LOG.info("filePathCSVSemColDelim=============================="+filePathCSVSemColDelim);

		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("CUST_DOC_RPT_NM")  + "_" + uniqTime + ".zip";
		try {
			searchResultList=new ArrayList<PLMCustDocReportData>();
			searchResultList = plmCustDocReportService.getCustDocReport(plmCustDocReportData);

			if(!PLMUtils.isEmptyList(searchResultList)){

				saveCustDocCSVFileSemColDelim(plmCustDocReportData,searchResultList,fileDir,filePathCSVSemColDelim);

				PLMUtils.generateZipFile(filePathCSVSemColDelim,filePathZip);

				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);


				searchResultList.clear();

			}else {				
				PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
				LOG.info("No data Mail sent...............");
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendCustDocReportMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendCustDocReportMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
		} finally {
			deleteFiles(filePathCSVSemColDelim,filePathZip);
		}
		LOG.info("Mail sent successfully.....................");
		LOG.info("Exiting sendCustDocReportMail Method");
	}

	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return String
	 */
	public void sendCustDocReportMailComma() {
		LOG.info("Entering sendCustDocReportMail Method");

		String from = PLMConstants.LTTR_MAIL_FROM;
		//String to = userDataObj.getUserEmail();	
		String to = userEmail;
		//String toAddressee = userDataObj.getGivenName_LD().replace(",", "");
		String toAddressee = userName;
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.CUSTDOC_MAIL_SUBJECT;
		StringBuffer mailBody = new StringBuffer().append(toAddressee)
				.append(PLMConstants.CUSTDOC_MAIL_CONTENT)

				.append("\n")
				.append("Search Criteria \n")
				.append("--------------- \n")
				.append("Project/Contract: "+plmCustDocReportData.getEnteredProjContract()+"\n")
				.append("MLI: "+plmCustDocReportData.getEnteredMLI()+"\n")
				.append("Functional System: "+plmCustDocReportData.getEnteredFuncSystem()+"\n")
				.append("Document Name: "+plmCustDocReportData.getEnteredDocName()+"\n");
		if(plmCustDocReportData.getOrigFromDate()!=null){
			mailBody.append("Contract Originated (From) : "+plmCustDocReportData.getOrigFromDate()+"\n");
		}else{
			mailBody.append("Contract Originated (From) : "+""+"\n");
		}
		if(plmCustDocReportData.getOrigToDate()!=null){
			mailBody.append("Contract Originated (To) : "+plmCustDocReportData.getOrigToDate()+"\n\n\n");
		}else{
			mailBody.append("Contract Originated (To) : "+""+"\n\n\n");
		}
		mailBody.append(PLMConstants.LTTR_MAIL_SIGNATURE)
		.append(PLMConstants.LTTR_MAIL_FOOTER);
		LOG.info(mailBody.toString());

		StringBuffer mailNoDataBody = new StringBuffer()
		.append(toAddressee)
		.append(PLMConstants.CUSTDOC_NO_CONTENT_BODY)

		.append("\n")
		.append("Search Criteria \n")
		.append("--------------- \n")
		.append("Project/Contract: "+plmCustDocReportData.getEnteredProjContract()+"\n")
		.append("MLI: "+plmCustDocReportData.getEnteredMLI()+"\n")
		.append("Functional System: "+plmCustDocReportData.getEnteredFuncSystem()+"\n")
		.append("Document Name: "+plmCustDocReportData.getEnteredDocName()+"\n");
		if(plmCustDocReportData.getOrigFromDate()!=null){
			mailNoDataBody.append("Contract Originated (From) : "+plmCustDocReportData.getOrigFromDate()+"\n");
		}else{
			mailNoDataBody.append("Contract Originated (From) : "+""+"\n");
		}
		if(plmCustDocReportData.getOrigToDate()!=null){
			mailNoDataBody.append("Contract Originated (To) : "+plmCustDocReportData.getOrigToDate()+"\n\n\n");
		}else{
			mailNoDataBody.append("Contract Originated (To) : "+""+"\n\n\n");
		}

		mailNoDataBody.append(PLMConstants.LTTR_MAIL_SIGNATURE)
		.append(PLMConstants.LTTR_MAIL_FOOTER);
		LOG.info(mailNoDataBody.toString());

		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");

		String filePathCSV = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("CUST_DOC_RPT_NM")  + "_" + uniqTime + ".csv";


		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("CUST_DOC_RPT_NM")  + "_" + uniqTime + ".zip";
		LOG.info("fileDir..............."+fileDir);
		
		LOG.info("filePathCSV..............."+filePathCSV);
		
		LOG.info("filePathZip..............."+filePathZip);
		try {
			searchResultList=new ArrayList<PLMCustDocReportData>();
			searchResultList = plmCustDocReportService.getCustDocReport(plmCustDocReportData);

			if(!PLMUtils.isEmptyList(searchResultList)){


				saveCustDocCSVFile(plmCustDocReportData,searchResultList,fileDir,filePathCSV);

				PLMUtils.generateZipFile(filePathCSV,filePathZip);

				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);


				searchResultList.clear();

			}else {				
				PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
				LOG.info("No data Mail sent...............");
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendCustDocReportMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendCustDocReportMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
		} finally {
			deleteFiles(filePathCSV,filePathZip);
		}
		LOG.info("Mail sent successfully.....................");
		LOG.info("Exiting sendCustDocReportMail Method");
	}




	/**
	 * This method is used for saveEpeBaBoMCSVFile
	 * 
	 * @param  partNameLcl, epeBaBomRptList,fileDir,filePathCSV
	 * @throws Exception
	 */
	public void saveCustDocCSVFile(PLMCustDocReportData plmCustDocReportDataLcl,List<PLMCustDocReportData> searchResultListLcl,
			String fileDir,String filePathCSV) throws Exception {
		LOG.info("Entering saveCustDocCSVFile Method");
		setFixedFlags();
		setExhFlags();
		FileOutputStream fileOut = null;
		PrintWriter pwriter =null;
		boolean createFileExist;
		try {
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathCSV);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
			}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathCSV);
				pwriter =  new PrintWriter( new FileWriter(filePathCSV));


				pwriter.write("Project/Contract");
				pwriter.write(",");
				pwriter.write(plmCustDocReportDataLcl.getEnteredProjContract());
				pwriter.write("\n");
				pwriter.write("MLI");
				pwriter.write(",");
				pwriter.write(plmCustDocReportDataLcl.getEnteredMLI());
				pwriter.write("\n");
				pwriter.write("Functional System");
				pwriter.write(",");
				pwriter.write(plmCustDocReportDataLcl.getEnteredFuncSystem());
				pwriter.write("\n");
				pwriter.write("Document Name");
				pwriter.write(",");
				pwriter.write(plmCustDocReportDataLcl.getEnteredDocName());
				pwriter.write("\n");

				pwriter.write("\n");

				pwriter.write("Contract");
				pwriter.write(",");
				pwriter.write("Contract Desc");
				if(pgplmtcfFixedFlag || pgplmFixedFlag){
					pwriter.write(",");
					pwriter.write("WBSE");
					pwriter.write(",");
					pwriter.write("WBSE Rev");
					pwriter.write(",");
					pwriter.write("WBSE State");
					pwriter.write(",");
					pwriter.write("PLD");
					pwriter.write(",");
					pwriter.write("PLD Rev");
					pwriter.write(",");
					pwriter.write("PLD Release");
					pwriter.write(",");
					pwriter.write("General Title");
					pwriter.write(",");
					pwriter.write("Detailed Title");
				}
				pwriter.write(",");
				pwriter.write("Doc Type");
				pwriter.write(",");
				pwriter.write("Document");
				pwriter.write(",");
				pwriter.write("Doc Rev");
				if(pgplmtcfFixedFlag || tcfFixedFlag){
					pwriter.write(",");
					pwriter.write("TC5 Label");
					pwriter.write(",");
					pwriter.write("Label Rev");
					pwriter.write(",");
					pwriter.write("Label Release");
				}

				//Adding Columns for PGPLM Exh Cols
				if(pgplmtcfExhFlag || pgplmExhFlag){
					pwriter.write(",");
					pwriter.write("WBSE Originator");
					pwriter.write(",");
					pwriter.write("WBSE Originated");
					pwriter.write(",");
					pwriter.write("WBSE Modified");
					pwriter.write(",");
					pwriter.write("WBSE Owner");
					pwriter.write(",");
					pwriter.write("WBSE Mgr");
					pwriter.write(",");
					pwriter.write("WBSE Assignee");
					pwriter.write(",");
					pwriter.write("WBSE ProjectRole");
					pwriter.write(",");
					pwriter.write("WBSE Due Date");
					pwriter.write(",");
					pwriter.write("WBSE Est. Finish");
					pwriter.write(",");
					pwriter.write("WBSE Est. Start");
					pwriter.write(",");
					pwriter.write("WBSE Liquidated Damage");
					pwriter.write(",");
					pwriter.write("WBSE For Distrib");
					pwriter.write(",");
					pwriter.write("WBSE PLD Required");
					pwriter.write(",");
					pwriter.write("WBSE EID");
					pwriter.write(",");
					pwriter.write("WBSE Equipment Code");
					pwriter.write(",");
					pwriter.write("WBSE Fnctl System");
					pwriter.write(",");
					pwriter.write("WBSE Classif Code");
					pwriter.write(",");
					pwriter.write("WBSE PLD Code");
					pwriter.write(",");
					pwriter.write("WBSE ExtDoc Code");
					pwriter.write(",");
					pwriter.write("WBSE ExtRev");
					pwriter.write(",");
					pwriter.write("WBSE ExtField1");
					pwriter.write(",");
					pwriter.write("WBSE ExtField2");
					pwriter.write(",");
					pwriter.write("WBSE ExtField3");
					pwriter.write(",");
					pwriter.write("WBSE Related Project");
					pwriter.write(",");
					pwriter.write("WBSE Policy");
					pwriter.write(",");
					pwriter.write("WBSE CWBSE");
					pwriter.write(",");
					pwriter.write("WBSE Description");
					pwriter.write(",");
					pwriter.write("WBSE Title");
					pwriter.write(",");
					pwriter.write("WBSE Notes");
					pwriter.write(",");
					pwriter.write("WBSE Synopsis");
				}

				//Adding Columns for TC5 Exh Cols
				if(pgplmtcfExhFlag || tcfExhFlag){
					pwriter.write(",");
					pwriter.write("TC5 Status");
					pwriter.write(",");
					pwriter.write("Superseded");
					pwriter.write(",");
					pwriter.write("Official");
					pwriter.write(",");
					pwriter.write("TC5 MainType");
					pwriter.write(",");
					pwriter.write("TC5 Sec. Type");
					pwriter.write(",");
					pwriter.write("TC5 Metrix");
					pwriter.write(",");
					pwriter.write("TC5 Sent");
					pwriter.write(",");
					pwriter.write("TC5 Reply");
					pwriter.write(",");
					pwriter.write("TC5 Resubmit");
					pwriter.write(",");
					pwriter.write("TC5 Customer Status");
					pwriter.write(",");
					pwriter.write("TC5 Customer");
					pwriter.write(",");
					pwriter.write("TC5 Supplier");
					pwriter.write(",");
					pwriter.write("TC5 Custom Field1");
					pwriter.write(",");
					pwriter.write("TC5 Custom Field2");
					pwriter.write(",");
					pwriter.write("TC5 Custom Field3");
					pwriter.write(",");
					pwriter.write("TC5 For Approval");
					pwriter.write(",");
					pwriter.write("TC5 Contractual");
					pwriter.write(",");
					pwriter.write("TC5 ASB");
					pwriter.write(",");
					pwriter.write("TC5 Poles");
				}


				pwriter.write("\n");
				if(!PLMUtils.isEmptyList(searchResultListLcl)) {
					for(int i=0; i<searchResultListLcl.size(); i++) {
						PLMCustDocReportData dataObj = (PLMCustDocReportData)searchResultListLcl.get(i);

						if(dataObj.getOpContract()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpContract()));
						}
						pwriter.write(",");

						if(dataObj.getOpContractDesc()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpContractDesc()));
						}
						if(pgplmtcfFixedFlag || pgplmFixedFlag){
							pwriter.write(",");

							if(dataObj.getOpWBSEName()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWBSEName()));
							}
							pwriter.write(",");

							if(dataObj.getOpWBSERev()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWBSERev()+"\""));
							}
							pwriter.write(",");

							if(dataObj.getOpWBSEState()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWBSEState()));
							}
							pwriter.write(",");

							if(dataObj.getOpPld()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpPld()));
							}
							pwriter.write(",");

							if(dataObj.getOpPldRev()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpPldRev()+"\""));
							}
							pwriter.write(",");

							if(dataObj.getOpPldRelease()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpPldRelease()));
							}
							pwriter.write(",");

							if(dataObj.getOpGenTitle()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpGenTitle()+"\""));
							}
							pwriter.write(",");

							if(dataObj.getOpDetTitle()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpDetTitle()+"\""));
							}
						}
						pwriter.write(",");

						if(dataObj.getOpDocType()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpDocType()));
						}
						pwriter.write(",");

						if(dataObj.getOpDocument()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpDocument()));
						}
						pwriter.write(",");

						if(dataObj.getOpDocRev()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpDocRev()+"\""));
						}
						if(pgplmtcfFixedFlag || tcfFixedFlag){
							pwriter.write(",");

							if(dataObj.getOpTc5Label()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Label()));
							}
							pwriter.write(",");

							if(dataObj.getOpLabelRev()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpLabelRev()+"\""));
							}
							pwriter.write(",");

							if(dataObj.getOpLabelRelease()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpLabelRelease()));
							}
						}

						//Adding Columns for PGPLM Exh Cols
						if(pgplmtcfExhFlag || pgplmExhFlag){
							//LOG.info("WBSE Originator==="+dataObj.getOpWbseOriginator());
							pwriter.write(",");
							if(dataObj.getOpWbseOriginator()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseOriginator()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseOriginated()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseOriginated()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseModified()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseModified()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseOwner()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseOwner()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseMgr()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseMgr()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseAssignee()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseAssignee()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseProjRole()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseProjRole()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseDueDate()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseDueDate()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseEstFinish()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseEstFinish()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseEstStart()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseEstStart()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseLiqDamage()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseLiqDamage()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseForDist()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseForDist()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbsePldReq()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbsePldReq()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseEid()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseEid()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseEquipCode()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseEquipCode()+"\""));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseFunSys()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseFunSys()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseClsfCode()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseClsfCode()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbsePldCode()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbsePldCode()+"\""));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseExtdocCode()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseExtdocCode()+"\""));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseExtRev()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseExtRev()+"\""));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseExtFld1()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseExtFld1()+"\""));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseExtFld2()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseExtFld2()+"\""));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseExtFld3()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseExtFld3()+"\""));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseRelProj()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseRelProj()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbsePolicy()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbsePolicy()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseCwbse()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseCwbse()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseDesc()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseDesc()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseTitle()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseTitle()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseNotes()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseNotes()));
							}
							pwriter.write(",");
							if(dataObj.getOpWbseSynopsis()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseSynopsis()));
							}
						}

						//Adding Columns for TC5 Exh Cols
						if(pgplmtcfExhFlag || tcfExhFlag){
							//LOG.info("TC5 Status==="+dataObj.getOpTc5Status());
							pwriter.write(",");
							if(dataObj.getOpTc5Status()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Status()));
							}
							pwriter.write(",");
							if(dataObj.getOpSuperseded()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpSuperseded()));
							}
							pwriter.write(",");
							if(dataObj.getOpOfficial()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpOfficial()));
							}
							pwriter.write(",");
							if(dataObj.getOpTc5MainType()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5MainType()));
							}
							pwriter.write(",");
							if(dataObj.getOpTc5SecType()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5SecType()));
							}
							pwriter.write(",");
							if(dataObj.getOpTc5Metrix()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Metrix()));
							}
							pwriter.write(",");
							if(dataObj.getOpTc5Sent()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Sent()));
							}
							pwriter.write(",");
							if(dataObj.getOpTc5Reply()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Reply()));
							}
							pwriter.write(",");
							if(dataObj.getOpTc5Resubmit()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Resubmit()));
							}
							pwriter.write(",");
							if(dataObj.getOpTc5CustStatus()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5CustStatus()));
							}
							pwriter.write(",");
							if(dataObj.getOpTc5Customer()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpTc5Customer()+"\""));
							}
							pwriter.write(",");
							if(dataObj.getOpTc5Supplier()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpTc5Supplier()+"\""));
							}
							pwriter.write(",");
							if(dataObj.getOpTc5CustFld1()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpTc5CustFld1()+"\""));
							}
							pwriter.write(",");
							if(dataObj.getOpTc5CustFld2()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpTc5CustFld2()+"\""));
							}
							pwriter.write(",");
							if(dataObj.getOpTc5CustFld3()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpTc5CustFld3()+"\""));
							}
							pwriter.write(",");
							if(dataObj.getOpTc5ForApproval()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5ForApproval()));
							}
							pwriter.write(",");
							if(dataObj.getOpTc5Contractual()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Contractual()));
							}
							pwriter.write(",");
							if(dataObj.getOpTc5Asb()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Asb()));
							}
							pwriter.write(",");
							if(dataObj.getOpTc5Pole()!= null){
								pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Pole()));
							}
						}

						pwriter.write("\n");
					} 

				}
			}

		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveCustDocCSVFile: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveCustDocCSVFile: ", e);
			throw e;
		}  finally {
			try {
				if (pwriter !=null) {
					pwriter.close();
				}
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveCustDocCSVFile: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveCustDocCSVFile Method");
	}




	/**
	 * This method is used for saveEpeBaBoMCSVFile
	 * 
	 * @param  partNameLcl, epeBaBomRptList,fileDir,filePathCSV
	 * @throws Exception
	 */
	public void saveCustDocCSVFileSemColDelim(PLMCustDocReportData plmCustDocReportDataLcl,List<PLMCustDocReportData> searchResultListLcl,
			String fileDir,String filePathCSV) throws Exception {
		LOG.info("Entering saveCustDocCSVFileSemColDelim Method");
		setFixedFlags();
		setExhFlags();
		FileOutputStream fileOut = null;
		PrintWriter pwriter =null;
		boolean createFileExist;
		try {
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathCSV);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
			}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathCSV);
				pwriter =  new PrintWriter( new FileWriter(filePathCSV));


				pwriter.write("Project/Contract");
				pwriter.write(";");
				pwriter.write(plmCustDocReportDataLcl.getEnteredProjContract());
				pwriter.write("\n");
				pwriter.write("MLI");
				pwriter.write(";");
				pwriter.write(plmCustDocReportDataLcl.getEnteredMLI());
				pwriter.write("\n");
				pwriter.write("Functional System");
				pwriter.write(";");
				pwriter.write(plmCustDocReportDataLcl.getEnteredFuncSystem());
				pwriter.write("\n");
				pwriter.write("Document Name");
				pwriter.write(";");
				pwriter.write(plmCustDocReportDataLcl.getEnteredDocName());
				pwriter.write("\n");

				pwriter.write("\n");

				pwriter.write("Contract");
				pwriter.write(";");
				pwriter.write("Contract Desc");
				if(pgplmtcfFixedFlag || pgplmFixedFlag){
					pwriter.write(";");
					pwriter.write("WBSE");
					pwriter.write(";");
					pwriter.write("WBSE Rev");
					pwriter.write(";");
					pwriter.write("WBSE State");
					pwriter.write(";");
					pwriter.write("PLD");
					pwriter.write(";");
					pwriter.write("PLD Rev");
					pwriter.write(";");
					pwriter.write("PLD Release");
					pwriter.write(";");
					pwriter.write("General Title");
					pwriter.write(";");
					pwriter.write("Detailed Title");
				}
				pwriter.write(";");
				pwriter.write("Doc Type");
				pwriter.write(";");
				pwriter.write("Document");
				pwriter.write(";");
				pwriter.write("Doc Rev");
				if(pgplmtcfFixedFlag || tcfFixedFlag){
					pwriter.write(";");
					pwriter.write("TC5 Label");
					pwriter.write(";");
					pwriter.write("Label Rev");
					pwriter.write(";");
					pwriter.write("Label Release");
				}

				//Adding Columns for PGPLM Exh Cols
				if(pgplmtcfExhFlag || pgplmExhFlag){
					pwriter.write(";");
					pwriter.write("WBSE Originator");
					pwriter.write(";");
					pwriter.write("WBSE Originated");
					pwriter.write(";");
					pwriter.write("WBSE Modified");
					pwriter.write(";");
					pwriter.write("WBSE Owner");
					pwriter.write(";");
					pwriter.write("WBSE Mgr");
					pwriter.write(";");
					pwriter.write("WBSE Assignee");
					pwriter.write(";");
					pwriter.write("WBSE ProjectRole");
					pwriter.write(";");
					pwriter.write("WBSE Due Date");
					pwriter.write(";");
					pwriter.write("WBSE Est. Finish");
					pwriter.write(";");
					pwriter.write("WBSE Est. Start");
					pwriter.write(";");
					pwriter.write("WBSE Liquidated Damage");
					pwriter.write(";");
					pwriter.write("WBSE For Distrib");
					pwriter.write(";");
					pwriter.write("WBSE PLD Required");
					pwriter.write(";");
					pwriter.write("WBSE EID");
					pwriter.write(";");
					pwriter.write("WBSE Equipment Code");
					pwriter.write(";");
					pwriter.write("WBSE Fnctl System");
					pwriter.write(";");
					pwriter.write("WBSE Classif Code");
					pwriter.write(";");
					pwriter.write("WBSE PLD Code");
					pwriter.write(";");
					pwriter.write("WBSE ExtDoc Code");
					pwriter.write(";");
					pwriter.write("WBSE ExtRev");
					pwriter.write(";");
					pwriter.write("WBSE ExtField1");
					pwriter.write(";");
					pwriter.write("WBSE ExtField2");
					pwriter.write(";");
					pwriter.write("WBSE ExtField3");
					pwriter.write(";");
					pwriter.write("WBSE Related Project");
					pwriter.write(";");
					pwriter.write("WBSE Policy");
					pwriter.write(";");
					pwriter.write("WBSE CWBSE");
					pwriter.write(";");
					pwriter.write("WBSE Description");
					pwriter.write(";");
					pwriter.write("WBSE Title");
					pwriter.write(";");
					pwriter.write("WBSE Notes");
					pwriter.write(";");
					pwriter.write("WBSE Synopsis");
				}

				//Adding Columns for TC5 Exh Cols
				if(pgplmtcfExhFlag || tcfExhFlag){
					pwriter.write(";");
					pwriter.write("TC5 Status");
					pwriter.write(";");
					pwriter.write("Superseded");
					pwriter.write(";");
					pwriter.write("Official");
					pwriter.write(";");
					pwriter.write("TC5 MainType");
					pwriter.write(";");
					pwriter.write("TC5 Sec. Type");
					pwriter.write(";");
					pwriter.write("TC5 Metrix");
					pwriter.write(";");
					pwriter.write("TC5 Sent");
					pwriter.write(";");
					pwriter.write("TC5 Reply");
					pwriter.write(";");
					pwriter.write("TC5 Resubmit");
					pwriter.write(";");
					pwriter.write("TC5 Customer Status");
					pwriter.write(";");
					pwriter.write("TC5 Customer");
					pwriter.write(";");
					pwriter.write("TC5 Supplier");
					pwriter.write(";");
					pwriter.write("TC5 Custom Field1");
					pwriter.write(";");
					pwriter.write("TC5 Custom Field2");
					pwriter.write(";");
					pwriter.write("TC5 Custom Field3");
					pwriter.write(";");
					pwriter.write("TC5 For Approval");
					pwriter.write(";");
					pwriter.write("TC5 Contractual");
					pwriter.write(";");
					pwriter.write("TC5 ASB");
					pwriter.write(";");
					pwriter.write("TC5 Poles");
				}


				pwriter.write("\n");
				if(!PLMUtils.isEmptyList(searchResultListLcl)) {
					for(int i=0; i<searchResultListLcl.size(); i++) {
						PLMCustDocReportData dataObj = (PLMCustDocReportData)searchResultListLcl.get(i);

						if(dataObj.getOpContract()!= null){
							pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpContract()));
						}
						pwriter.write(";");

						if(dataObj.getOpContractDesc()!= null){
							pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpContractDesc()));
						}
						if(pgplmtcfFixedFlag || pgplmFixedFlag){
							pwriter.write(";");

							if(dataObj.getOpWBSEName()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWBSEName()));
							}
							pwriter.write(";");

							if(dataObj.getOpWBSERev()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWBSERev()+"\""));
							}
							pwriter.write(";");

							if(dataObj.getOpWBSEState()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWBSEState()));
							}
							pwriter.write(";");

							if(dataObj.getOpPld()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpPld()));
							}
							pwriter.write(";");

							if(dataObj.getOpPldRev()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpPldRev()+"\""));
							}
							pwriter.write(";");

							if(dataObj.getOpPldRelease()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpPldRelease()));
							}
							pwriter.write(";");

							if(dataObj.getOpGenTitle()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpGenTitle()+"\""));
							}
							pwriter.write(";");

							if(dataObj.getOpDetTitle()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpDetTitle()+"\""));
							}
						}
						pwriter.write(";");

						if(dataObj.getOpDocType()!= null){
							pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpDocType()));
						}
						pwriter.write(";");

						if(dataObj.getOpDocument()!= null){
							pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpDocument()));
						}
						pwriter.write(";");

						if(dataObj.getOpDocRev()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpDocRev()+"\""));
						}
						if(pgplmtcfFixedFlag || tcfFixedFlag){
							pwriter.write(";");

							if(dataObj.getOpTc5Label()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpTc5Label()));
							}
							pwriter.write(";");

							/*if(dataObj.getOpLabelRev()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpLabelRev()+"\""));
						   		}*/
							if(dataObj.getOpLabelRev()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpLabelRev()+"\""));
							}
							pwriter.write(";");

							if(dataObj.getOpLabelRelease()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpLabelRelease()));
							}
						}

						//Adding Columns for PGPLM Exh Cols
						if(pgplmtcfExhFlag || pgplmExhFlag){
							pwriter.write(";");
							if(dataObj.getOpWbseOriginator()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseOriginator()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseOriginated()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseOriginated()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseModified()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseModified()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseOwner()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseOwner()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseMgr()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseMgr()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseAssignee()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseAssignee()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseProjRole()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseProjRole()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseDueDate()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseDueDate()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseEstFinish()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseEstFinish()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseEstStart()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseEstStart()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseLiqDamage()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseLiqDamage()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseDesc()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseForDist()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseForDist()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbsePldReq()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseEid()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseEid()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseEquipCode()!= null){
								pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseEquipCode()+"\""));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseFunSys()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseFunSys()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseClsfCode()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseClsfCode()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbsePldCode()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew("=\""+dataObj.getOpWbsePldCode()+"\""));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseExtdocCode()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew("=\""+dataObj.getOpWbseExtdocCode()+"\""));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseExtRev()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew("=\""+dataObj.getOpWbseExtRev()+"\""));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseExtFld1()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew("=\""+dataObj.getOpWbseExtFld1()+"\""));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseExtFld2()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew("=\""+dataObj.getOpWbseExtFld2()+"\""));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseExtFld3()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew("=\""+dataObj.getOpWbseExtFld3()+"\""));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseRelProj()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseRelProj()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbsePolicy()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbsePolicy()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseCwbse()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseCwbse()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseDesc()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseDesc()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseTitle()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseTitle()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseNotes()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseNotes()));
							}
							pwriter.write(";");
							if(dataObj.getOpWbseSynopsis()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpWbseSynopsis()));
							}
						}

						//Adding Columns for TC5 Exh Cols
						if(pgplmtcfExhFlag || tcfExhFlag){
							pwriter.write(";");
							if(dataObj.getOpTc5Status()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpTc5Status()));
							}
							pwriter.write(";");
							if(dataObj.getOpSuperseded()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpSuperseded()));
							}
							pwriter.write(";");
							if(dataObj.getOpOfficial()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpOfficial()));
							}
							pwriter.write(";");
							if(dataObj.getOpTc5MainType()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpTc5MainType()));
							}
							pwriter.write(";");
							if(dataObj.getOpTc5SecType()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpTc5SecType()));
							}
							pwriter.write(";");
							if(dataObj.getOpTc5Metrix()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpTc5Metrix()));
							}
							pwriter.write(";");
							if(dataObj.getOpTc5Sent()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpTc5Sent()));
							}
							pwriter.write(";");
							if(dataObj.getOpTc5Reply()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpTc5Reply()));
							}
							pwriter.write(";");
							if(dataObj.getOpTc5Resubmit()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpTc5Resubmit()));
							}
							pwriter.write(";");
							if(dataObj.getOpTc5CustStatus()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpTc5CustStatus()));
							}
							pwriter.write(";");
							if(dataObj.getOpTc5Customer()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew("=\""+dataObj.getOpTc5Customer()+"\""));
							}
							pwriter.write(";");
							if(dataObj.getOpTc5Supplier()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew("=\""+dataObj.getOpTc5Supplier()+"\""));
							}
							pwriter.write(";");
							if(dataObj.getOpTc5CustFld1()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew("=\""+dataObj.getOpTc5CustFld1()+"\""));
							}
							pwriter.write(";");
							if(dataObj.getOpTc5CustFld2()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew("=\""+dataObj.getOpTc5CustFld2()+"\""));
							}
							pwriter.write(";");
							if(dataObj.getOpTc5CustFld3()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew("=\""+dataObj.getOpTc5CustFld3()+"\""));
							}
							pwriter.write(";");
							if(dataObj.getOpTc5ForApproval()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpTc5ForApproval()));
							}
							pwriter.write(";");
							if(dataObj.getOpTc5Contractual()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpTc5Contractual()));
							}
							pwriter.write(";");
							if(dataObj.getOpTc5Asb()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpTc5Asb()));
							}
							pwriter.write(";");
							if(dataObj.getOpTc5Pole()!= null){
								pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpTc5Pole()));
							}
						}

						pwriter.write("\n");
					} 

				}
			}

		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveCustDocCSVFileSemColDelim: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveCustDocCSVFileSemColDelim: ", e);
			throw e;
		}  finally {
			try {
				if (pwriter !=null) {
					pwriter.close();
				}
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveCustDocCSVFileSemColDelim: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveCustDocCSVFileSemColDelim Method");
	}

	/**
	 * This method is used for Bordering Cell in XLSX
	 * 
	 * @return StringBuffer
	 */
	/*private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
		style.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style.setBorderRight(XSSFCellStyle.BORDER_THIN);
		return style;
	}*/
	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return StringBuffer
	 */



	/**
	 * This method is used for Deleting zip file and xls file
	 * 
	 * @return void
	 */
	public void deleteFiles(String filePathXls,String filePathZip){
		LOG.info("Entering deleteFiles method");
		boolean zipFileExist;
		boolean xlsFileExist;
		File zipFile = new File(filePathZip);
		zipFileExist = zipFile.exists();
		File xlsFile = new File(filePathXls);
		xlsFileExist = xlsFile.exists();
		if(zipFileExist){
			boolean deleted = zipFile.delete();
			LOG.info("Successfully deleted zip file : " + deleted);
		}
		if(xlsFileExist){
			boolean deleted = xlsFile.delete();
			LOG.info("Successfully deleted xls file : " + deleted);
		}
		LOG.info("Exiting deleteFiles Method");
	}






	/**
	 * This method is used for recordsPerPageListner
	 * 
	 * @param event
	 * 
	 */
	public void recordsPerPageListner(ActionEvent event) {
		LOG.info("Entering recordsPerPageListner method");
		LOG.info("Action listner called.....--------------------------->"
				+ recordCounts);
		if (recordCounts == 15) {
			LOG.info("15");
			recordCounts = 15;
		} else if (recordCounts == 30) {
			LOG.info("30");
			recordCounts = 30;
		} else if (recordCounts == 50) {
			LOG.info("50");
			recordCounts = 50;
		} else if (recordCounts == 100) {
			LOG.info("100");
			recordCounts = 100;
		} else if (recordCounts == 200) {
			LOG.info("200");
			recordCounts = 200;
		}

		else if (recordCounts == totalRecCount) {
			LOG.info("All");
			recordCounts = totalRecCount;
		}
		LOG.info("final value.....--------------------------->" + recordCounts);
	}

	public void downloadExcel() throws PLMCommonException {
		LOG.info("Entering downloadExcel Method");
		String reportName = "custDocReportResult";
		String fileName = "custDocReportResult";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		//Export to Excel for Customer Document Report
		
		PLMXlsxRptColumn[] critcolumns  = new PLMXlsxRptColumn[] {
                new PLMXlsxRptColumn("enteredProjContract", "Project/Contract", FormatType.TEXT),
                new PLMXlsxRptColumn("enteredMLI", "MLI", FormatType.TEXT),
                new PLMXlsxRptColumn("enteredFuncSystem", "Functional System", FormatType.TEXT),
                new PLMXlsxRptColumn("enteredDocName", "Document Name", FormatType.TEXT),
                 new PLMXlsxRptColumn("origFromDate", "Contract Originated (From)", FormatType.DATEFR),
                new PLMXlsxRptColumn("origToDate", "Contract Originated (To)", FormatType.DATEFR)
                };
		
		if(isPgplmFixedFlag() && !isPgplmExhFlag()){
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					  new PLMXlsxRptColumn("opContract", "Contract", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("opContractDesc", "Contract Description", FormatType.TEXT, null, null, 36),
					  new PLMXlsxRptColumn("opWBSEName", "WBSE", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("opWBSERev", "WBSE Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWBSEState", "WBSE State", FormatType.TEXT),
					  new PLMXlsxRptColumn("opPld", "PLD", FormatType.TEXT),
					  new PLMXlsxRptColumn("opPldRev", "PLD Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opPldReleaseExl", "PLD Release", FormatType.DATEFR, null, null, 15),
					  new PLMXlsxRptColumn("opGenTitle", "General Title", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDetTitle", "Detailed Title", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDocType", "Doc Type", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDocument", "Document", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDocRev", "Doc Rev", FormatType.TEXT)};
			excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, plmCustDocReportData);	
			
		}else if(isPgplmtcfFixedFlag() && !isPgplmtcfExhFlag()){
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					  new PLMXlsxRptColumn("opContract", "Contract", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("opContractDesc", "Contract Description", FormatType.TEXT, null, null, 36),
					  new PLMXlsxRptColumn("opWBSEName", "WBSE", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("opWBSERev", "WBSE Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWBSEState", "WBSE State", FormatType.TEXT),
					  new PLMXlsxRptColumn("opPld", "PLD", FormatType.TEXT),
					  new PLMXlsxRptColumn("opPldRev", "PLD Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opPldReleaseExl", "PLD Release", FormatType.DATEFR, null, null, 15),
					  new PLMXlsxRptColumn("opGenTitle", "General Title", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDetTitle", "Detailed Title", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDocType", "Doc Type", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDocument", "Document", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDocRev", "Doc Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5Label", "TC5 Label", FormatType.TEXT),
					  new PLMXlsxRptColumn("opLabelRev", "Label Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opLabelReleaseExl", "Label Release", FormatType.DATEFR,null,null,15)};
			excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, plmCustDocReportData);	
			
		}else if(isTcfFixedFlag() && !isTcfExhFlag()){
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					  new PLMXlsxRptColumn("opContract", "Contract", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("opContractDesc", "Contract Description", FormatType.TEXT, null, null, 36),
					  new PLMXlsxRptColumn("opDocType", "Doc Type", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDocument", "Document", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDocRev", "Doc Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5Label", "TC5 Label", FormatType.TEXT),
					  new PLMXlsxRptColumn("opLabelRev", "Label Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opLabelReleaseExl", "Label Release", FormatType.DATEFR,null,null,15)};
			excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, plmCustDocReportData);	
			
		}else if(isPgplmFixedFlag() && isPgplmExhFlag()){
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					  new PLMXlsxRptColumn("opContract", "Contract", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("opContractDesc", "Contract Description", FormatType.TEXT, null, null, 36),
					  
					  new PLMXlsxRptColumn("opWBSEName", "WBSE", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("opWBSERev", "WBSE Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWBSEState", "WBSE State", FormatType.TEXT),
					  new PLMXlsxRptColumn("opPld", "PLD", FormatType.TEXT),
					  new PLMXlsxRptColumn("opPldRev", "PLD Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opPldReleaseExl", "PLD Release", FormatType.DATEFR, null, null, 15),
					  new PLMXlsxRptColumn("opGenTitle", "General Title", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDetTitle", "Detailed Title", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDocType", "Doc Type", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDocument", "Document", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDocRev", "Doc Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseOriginator", "WBSE Orginator", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseOriginatedExl", "WBSE Orginated", FormatType.DATEFRMTTM,null,null,20),
					  new PLMXlsxRptColumn("opWbseModifiedExl", "WBSE Modified", FormatType.DATEFRMTTM,null,null,20),
					  new PLMXlsxRptColumn("opWbseOwner", "WBSE Owner", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseMgr", "WBSE Mgr", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseAssignee", "WBSE Assignee", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseProjRole", "WBSE Project Role", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseDueDateExl", "WBSE Due Date", FormatType.DATEFR,null,null,15),
					  new PLMXlsxRptColumn("opWbseEstFinishExl", "WBSE Est. Finish", FormatType.DATEFR,null,null,15),
					  new PLMXlsxRptColumn("opWbseEstStartExl", "WBSE Est. Start", FormatType.DATEFR,null,null,15),
					  new PLMXlsxRptColumn("opWbseLiqDamage", "WBSE Liquidated Damage", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseForDist", "WBSE for Distirb", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbsePldReq", "WBSE PDL Required", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseEid", "WBSE Eid", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseEquipCode", "WBSE Equipment Code", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseFunSys", "WBSE Fnctl System", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseClsfCode", "WBSE Classif Code", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbsePldCode", "WBSE PLD Code", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseExtdocCode", "WBSE ExtDoc Code", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseExtRev", "WBSE ExtRev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseExtFld1", "WBSE ExtField1", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseExtFld2", "WBSE ExtField2", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseExtFld3", "WBSE ExtField3", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseRelProj", "WBSE Related Project", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbsePolicy", "WBSE Policy", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseCwbse", "WBSE CWBSE", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseDesc", "WBSE Description", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseTitle", "WBSE Title", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseNotes", "WBSE Notes", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseSynopsis", "WBSE Synopsis", FormatType.TEXT)};
			excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, plmCustDocReportData);	
		
		}else if(isPgplmtcfFixedFlag() && isPgplmtcfExhFlag()){
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					  new PLMXlsxRptColumn("opContract", "Contract", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("opContractDesc", "Contract Description", FormatType.TEXT, null, null, 36),
					  new PLMXlsxRptColumn("opWBSEName", "WBSE", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("opWBSERev", "WBSE Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWBSEState", "WBSE State", FormatType.TEXT),
					  new PLMXlsxRptColumn("opPld", "PLD", FormatType.TEXT),
					  new PLMXlsxRptColumn("opPldRev", "PLD Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opPldReleaseExl", "PLD Release", FormatType.DATEFR, null, null, 15),
					  new PLMXlsxRptColumn("opGenTitle", "General Title", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDetTitle", "Detailed Title", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDocType", "Doc Type", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDocument", "Document", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDocRev", "Doc Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5Label", "TC5 Label", FormatType.TEXT),
					  new PLMXlsxRptColumn("opLabelRev", "Label Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opLabelReleaseExl", "Label Release", FormatType.DATEFR,null,null,15),
					  new PLMXlsxRptColumn("opWbseOriginator", "WBSE Orginator", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseOriginatedExl", "WBSE Orginated", FormatType.DATEFRMTTM,null,null,20),
					  new PLMXlsxRptColumn("opWbseModifiedExl", "WBSE Modified", FormatType.DATEFRMTTM,null,null,20),
					  new PLMXlsxRptColumn("opWbseOwner", "WBSE Owner", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseMgr", "WBSE Mgr", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseAssignee", "WBSE Assignee", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseProjRole", "WBSE Project Role", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseDueDateExl", "WBSE Due Date", FormatType.DATEFR,null,null,15),
					  new PLMXlsxRptColumn("opWbseEstFinishExl", "WBSE Est. Finish", FormatType.DATEFR,null,null,15),
					  new PLMXlsxRptColumn("opWbseEstStartExl", "WBSE Est. Start", FormatType.DATEFR,null,null,15),
					  new PLMXlsxRptColumn("opWbseLiqDamage", "WBSE Liquidated Damage", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseForDist", "WBSE for Distirb", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbsePldReq", "WBSE PDL Required", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseEid", "WBSE Eid", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseEquipCode", "WBSE Equipment Code", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseFunSys", "WBSE Fnctl System", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseClsfCode", "WBSE Classif Code", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbsePldCode", "WBSE PLD Code", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseExtdocCode", "WBSE ExtDoc Code", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseExtRev", "WBSE ExtRev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseExtFld1", "WBSE ExtField1", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseExtFld2", "WBSE ExtField2", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseExtFld3", "WBSE ExtField3", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseRelProj", "WBSE Related Project", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbsePolicy", "WBSE Policy", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseCwbse", "WBSE CWBSE", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseDesc", "WBSE Description", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseTitle", "WBSE Title", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseNotes", "WBSE Notes", FormatType.TEXT),
					  new PLMXlsxRptColumn("opWbseSynopsis", "WBSE Synopsis", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5Status", "TC5 Status", FormatType.TEXT),
					  new PLMXlsxRptColumn("opSuperseded", "Superseded", FormatType.TEXT),
					  new PLMXlsxRptColumn("opOfficial", "Official", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5MainType", "TC5 Main Type", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5SecType", "TC5 Sec Type", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5MetrixExl", "TC5 Metrix", FormatType.DATEFR,null,null,15),
					  new PLMXlsxRptColumn("opTc5SentExl", "TC5 Sent", FormatType.DATEFR,null,null,15),
					  new PLMXlsxRptColumn("opTc5ReplyExl", "TC5 Reply", FormatType.DATEFR,null,null,15),
					  new PLMXlsxRptColumn("opTc5ResubmitExl", "TC5 Resubmit", FormatType.DATEFR,null,null,15),
					  new PLMXlsxRptColumn("opTc5CustStatus", "TC5 Customer Status", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5Customer", "TC5 Customer", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5Supplier", "TC5 Supplier", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5CustFld1", "TC5 Custom Field1", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5CustFld2", "TC5 Custom Field2", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5CustFld3", "TC5 Custom Field3", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5ForApproval", "TC5 for Approval", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5Contractual", "TC5 Contractual", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5Asb", "TC5 ASB", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5Pole", "TC5 Pole", FormatType.TEXT)};
			excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, plmCustDocReportData);	
		
		}else if(isTcfFixedFlag() && isTcfExhFlag()){
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					  new PLMXlsxRptColumn("opContract", "Contract", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("opContractDesc", "Contract Description", FormatType.TEXT, null, null, 36),
					  new PLMXlsxRptColumn("opDocType", "Doc Type", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDocument", "Document", FormatType.TEXT),
					  new PLMXlsxRptColumn("opDocRev", "Doc Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5Label", "TC5 Label", FormatType.TEXT),
					  new PLMXlsxRptColumn("opLabelRev", "Label Rev", FormatType.TEXT),
					  new PLMXlsxRptColumn("opLabelReleaseExl", "Label Release", FormatType.DATEFR,null,null,15),
					  new PLMXlsxRptColumn("opTc5Status", "TC5 Status", FormatType.TEXT),
					  new PLMXlsxRptColumn("opSuperseded", "Superseded", FormatType.TEXT),
					  new PLMXlsxRptColumn("opOfficial", "Official", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5MainType", "TC5 Main Type", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5SecType", "TC5 Sec Type", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5MetrixExl", "TC5 Metrix", FormatType.DATEFR,null,null,15),
					  new PLMXlsxRptColumn("opTc5SentExl", "TC5 Sent", FormatType.DATEFR,null,null,15),
					  new PLMXlsxRptColumn("opTc5ReplyExl", "TC5 Reply", FormatType.DATEFR,null,null,15),
					  new PLMXlsxRptColumn("opTc5ResubmitExl", "TC5 Resubmit", FormatType.DATEFR,null,null,15),
					  new PLMXlsxRptColumn("opTc5CustStatus", "TC5 Customer Status", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5Customer", "TC5 Customer", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5Supplier", "TC5 Supplier", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5CustFld1", "TC5 Custom Field1", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5CustFld2", "TC5 Custom Field2", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5CustFld3", "TC5 Custom Field3", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5ForApproval", "TC5 for Approval", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5Contractual", "TC5 Contractual", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5Asb", "TC5 ASB", FormatType.TEXT),
					  new PLMXlsxRptColumn("opTc5Pole", "TC5 Pole", FormatType.TEXT)};
			excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, plmCustDocReportData);	
		}
		LOG.info("Exiting downloadExcel Method");
		
	} 	

	public void createDownloadCSV() throws PLMCommonException {
		
		LOG.info("Entering createDownloadCSV Method");
		String reportName = "custDocReportResult";
		String fileName = "custDocReportResult";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		//Export to comma CSV for Customer Document Report

		if(isPgplmFixedFlag() && !isPgplmExhFlag()){
			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					  new PLMCsvRptColumn("opContract", "Contract", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opContractDesc", "Contract Description",FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSEName", "WBSE", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSERev", "WBSE Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSEState", "WBSE State", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPld", "PLD", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPldRev", "PLD Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPldReleaseExl", "PLD Release", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opGenTitle", "General Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDetTitle", "Detailed Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocType", "Doc Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocument", "Document", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocRev", "Doc Rev", FormatTypeCsv.TEXT)};
			csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, plmCustDocReportData, ",");
			
		}else if(isPgplmtcfFixedFlag() && !isPgplmtcfExhFlag()){
			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					  new PLMCsvRptColumn("opContract", "Contract", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opContractDesc", "Contract Description", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSEName", "WBSE", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSERev", "WBSE Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSEState", "WBSE State", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPld", "PLD", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPldRev", "PLD Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPldReleaseExl", "PLD Release", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opGenTitle", "General Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDetTitle", "Detailed Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocType", "Doc Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocument", "Document", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocRev", "Doc Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Label", "TC5 Label", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opLabelRev", "Label Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opLabelReleaseExl", "Label Release", FormatTypeCsv.DATEFR)};
			csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, plmCustDocReportData, ",");
			
		}else if(isTcfFixedFlag() && !isTcfExhFlag()){
			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					  new PLMCsvRptColumn("opContract", "Contract", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opContractDesc", "Contract Description", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocType", "Doc Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocument", "Document", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocRev", "Doc Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Label", "TC5 Label", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opLabelRev", "Label Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opLabelReleaseExl", "Label Release", FormatTypeCsv.DATEFR)};
			csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, plmCustDocReportData, ",");
			
		}else if(isPgplmFixedFlag() && isPgplmExhFlag()){
			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					  new PLMCsvRptColumn("opContract", "Contract", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opContractDesc", "Contract Description", FormatTypeCsv.TEXT),
					  
					  new PLMCsvRptColumn("opWBSEName", "WBSE", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSERev", "WBSE Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSEState", "WBSE State", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPld", "PLD", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPldRev", "PLD Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPldReleaseExl", "PLD Release", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opGenTitle", "General Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDetTitle", "Detailed Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocType", "Doc Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocument", "Document", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocRev", "Doc Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseOriginator", "WBSE Orginator", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseOriginatedExl", "WBSE Orginated", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opWbseModifiedExl", "WBSE Modified", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opWbseOwner", "WBSE Owner", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseMgr", "WBSE Mgr", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseAssignee", "WBSE Assignee", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseProjRole", "WBSE Project Role", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseDueDateExl", "WBSE Due Date", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opWbseEstFinishExl", "WBSE Est. Finish", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opWbseEstStartExl", "WBSE Est. Start", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opWbseLiqDamage", "WBSE Liquidated Damage", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseForDist", "WBSE for Distirb", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbsePldReq", "WBSE PDL Required", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseEid", "WBSE Eid", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseEquipCode", "WBSE Equipment Code", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseFunSys", "WBSE Fnctl System", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseClsfCode", "WBSE Classif Code", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbsePldCode", "WBSE PLD Code", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtdocCode", "WBSE ExtDoc Code", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtRev", "WBSE ExtRev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtFld1", "WBSE ExtField1", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtFld2", "WBSE ExtField2", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtFld3", "WBSE ExtField3", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseRelProj", "WBSE Related Project", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbsePolicy", "WBSE Policy", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseCwbse", "WBSE CWBSE", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseDesc", "WBSE Description", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseTitle", "WBSE Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseNotes", "WBSE Notes", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseSynopsis", "WBSE Synopsis", FormatTypeCsv.TEXT)};
			csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, plmCustDocReportData, ",");
		
		}else if(isPgplmtcfFixedFlag() && isPgplmtcfExhFlag()){
			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					  new PLMCsvRptColumn("opContract", "Contract", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opContractDesc", "Contract Description", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSEName", "WBSE", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSERev", "WBSE Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSEState", "WBSE State", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPld", "PLD", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPldRev", "PLD Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPldReleaseExl", "PLD Release", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opGenTitle", "General Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDetTitle", "Detailed Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocType", "Doc Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocument", "Document", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocRev", "Doc Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Label", "TC5 Label", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opLabelRev", "Label Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opLabelReleaseExl", "Label Release", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opWbseOriginator", "WBSE Orginator", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseOriginatedExl", "WBSE Orginated", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opWbseModifiedExl", "WBSE Modified", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opWbseOwner", "WBSE Owner", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseMgr", "WBSE Mgr", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseAssignee", "WBSE Assignee", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseProjRole", "WBSE Project Role", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseDueDateExl", "WBSE Due Date", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opWbseEstFinishExl", "WBSE Est. Finish", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opWbseEstStartExl", "WBSE Est. Start", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opWbseLiqDamage", "WBSE Liquidated Damage", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseForDist", "WBSE for Distirb", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbsePldReq", "WBSE PDL Required", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseEid", "WBSE Eid", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseEquipCode", "WBSE Equipment Code", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseFunSys", "WBSE Fnctl System", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseClsfCode", "WBSE Classif Code", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbsePldCode", "WBSE PLD Code", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtdocCode", "WBSE ExtDoc Code", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtRev", "WBSE ExtRev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtFld1", "WBSE ExtField1", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtFld2", "WBSE ExtField2", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtFld3", "WBSE ExtField3", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseRelProj", "WBSE Related Project", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbsePolicy", "WBSE Policy", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseCwbse", "WBSE CWBSE", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseDesc", "WBSE Description", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseTitle", "WBSE Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseNotes", "WBSE Notes", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseSynopsis", "WBSE Synopsis", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Status", "TC5 Status", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opSuperseded", "Superseded", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opOfficial", "Official", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5MainType", "TC5 Main Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5SecType", "TC5 Sec Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5MetrixExl", "TC5 Metrix", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opTc5SentExl", "TC5 Sent", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opTc5ReplyExl", "TC5 Reply", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opTc5ResubmitExl", "TC5 Resubmit", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opTc5CustStatus", "TC5 Customer Status", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Customer", "TC5 Customer", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Supplier", "TC5 Supplier", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5CustFld1", "TC5 Custom Field1", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5CustFld2", "TC5 Custom Field2", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5CustFld3", "TC5 Custom Field3", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5ForApproval", "TC5 for Approval", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Contractual", "TC5 Contractual", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Asb", "TC5 ASB", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Pole", "TC5 Pole", FormatTypeCsv.TEXT)};
			csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, plmCustDocReportData, ",");	
		
		}else if(isTcfFixedFlag() && isTcfExhFlag()){
			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					  new PLMCsvRptColumn("opContract", "Contract", FormatTypeCsv.TEXT, null, null, 25),
					  new PLMCsvRptColumn("opContractDesc", "Contract Description", FormatTypeCsv.TEXT, null, null, 36),
					  new PLMCsvRptColumn("opDocType", "Doc Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocument", "Document", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocRev", "Doc Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Label", "TC5 Label", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opLabelRev", "Label Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opLabelReleaseExl", "Label Release", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opTc5Status", "TC5 Status", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opSuperseded", "Superseded", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opOfficial", "Official", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5MainType", "TC5 Main Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5SecType", "TC5 Sec Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5MetrixExl", "TC5 Metrix", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opTc5SentExl", "TC5 Sent", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opTc5ReplyExl", "TC5 Reply", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opTc5ResubmitExl", "TC5 Resubmit", FormatTypeCsv.DATEFR),
					  new PLMCsvRptColumn("opTc5CustStatus", "TC5 Customer Status", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Customer", "TC5 Customer", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Supplier", "TC5 Supplier", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5CustFld1", "TC5 Custom Field1", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5CustFld2", "TC5 Custom Field2", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5CustFld3", "TC5 Custom Field3", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5ForApproval", "TC5 for Approval", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Contractual", "TC5 Contractual", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Asb", "TC5 ASB", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Pole", "TC5 Pole", FormatTypeCsv.TEXT)};
			csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, plmCustDocReportData, ",");
		}

		LOG.info("Exiting createDownloadCSV Method");
		/*PrintWriter pwriter = null;

		try {
			
			FacesContext facesContext = FacesContext.getCurrentInstance();

			HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
			HttpServletRequest resquest = (HttpServletRequest) facesContext.getExternalContext().getRequest();
			
			HttpSession session = resquest.getSession();
			
			response.setHeader("content-disposition","attachment; filename=CustomerDocumentsReport.csv");
			response.setContentType("application/CSV");
			
			pwriter = response.getWriter();
			PLMCustDocReportMB plmCustDocReportMB = (PLMCustDocReportMB) session.getAttribute("plmCustDocReportMB");
			PLMCustDocReportData custDocRptData = (PLMCustDocReportData) plmCustDocReportMB.getPlmCustDocReportData();

			pwriter.write("Project/Contract");
			pwriter.write(",");
			pwriter.write(custDocRptData.getEnteredProjContract());
			pwriter.write("\n");
			pwriter.write("MLI");
			pwriter.write(",");
			pwriter.write(custDocRptData.getEnteredMLI());
			pwriter.write("\n");
			pwriter.write("Functional System");
			pwriter.write(",");
			pwriter.write(custDocRptData.getEnteredFuncSystem());
			pwriter.write("\n");
			pwriter.write("Document Name");
			pwriter.write(",");
			pwriter.write(custDocRptData.getEnteredDocName());
			pwriter.write("\n");

			pwriter.write("\n");

			pwriter.write("Contract");
			pwriter.write(",");
			pwriter.write("Contract Desc");
			if(plmCustDocReportMB.isPgplmtcfFixedFlag() || plmCustDocReportMB.isPgplmFixedFlag()){
				pwriter.write(",");
				pwriter.write("WBSE");
				pwriter.write(",");
				pwriter.write("WBSE Rev");
				pwriter.write(",");
				pwriter.write("WBSE State");
				pwriter.write(",");
				pwriter.write("PLD");
				pwriter.write(",");
				pwriter.write("PLD Rev");
				pwriter.write(",");
				pwriter.write("PLD Release");
				pwriter.write(",");
				pwriter.write("General Title");
				pwriter.write(",");
				pwriter.write("Detailed Title");
			}
			pwriter.write(",");
			pwriter.write("Doc Type");
			pwriter.write(",");
			pwriter.write("Document");
			pwriter.write(",");
			pwriter.write("Doc Rev");
			if(plmCustDocReportMB.isPgplmtcfFixedFlag() || plmCustDocReportMB.isTcfFixedFlag()){
				pwriter.write(",");
				pwriter.write("TC5 Label");
				pwriter.write(",");
				pwriter.write("Label Rev");
				pwriter.write(",");
				pwriter.write("Label Release");
			}

			//Adding Columns for PGPLM Exh Cols
			if(plmCustDocReportMB.isPgplmtcfExhFlag() || plmCustDocReportMB.isPgplmExhFlag()){
				pwriter.write(",");
				pwriter.write("WBSE Originator");
				pwriter.write(",");
				pwriter.write("WBSE Originated");
				pwriter.write(",");
				pwriter.write("WBSE Modified");
				pwriter.write(",");
				pwriter.write("WBSE Owner");
				pwriter.write(",");
				pwriter.write("WBSE Mgr");
				pwriter.write(",");
				pwriter.write("WBSE Assignee");
				pwriter.write(",");
				pwriter.write("WBSE ProjectRole");
				pwriter.write(",");
				pwriter.write("WBSE Due Date");
				pwriter.write(",");
				pwriter.write("WBSE Est. Finish");
				pwriter.write(",");
				pwriter.write("WBSE Est. Start");
				pwriter.write(",");
				pwriter.write("WBSE Liquidated Damage");
				pwriter.write(",");
				pwriter.write("WBSE For Distrib");
				pwriter.write(",");
				pwriter.write("WBSE PLD Required");
				pwriter.write(",");
				pwriter.write("WBSE EID");
				pwriter.write(",");
				pwriter.write("WBSE Equipment Code");
				pwriter.write(",");
				pwriter.write("WBSE Fnctl System");
				pwriter.write(",");
				pwriter.write("WBSE Classif Code");
				pwriter.write(",");
				pwriter.write("WBSE PLD Code");
				pwriter.write(",");
				pwriter.write("WBSE ExtDoc Code");
				pwriter.write(",");
				pwriter.write("WBSE ExtRev");
				pwriter.write(",");
				pwriter.write("WBSE ExtField1");
				pwriter.write(",");
				pwriter.write("WBSE ExtField2");
				pwriter.write(",");
				pwriter.write("WBSE ExtField3");
				pwriter.write(",");
				pwriter.write("WBSE Related Project");
				pwriter.write(",");
				pwriter.write("WBSE Policy");
				pwriter.write(",");
				pwriter.write("WBSE CWBSE");
				pwriter.write(",");
				pwriter.write("WBSE Description");
				pwriter.write(",");
				pwriter.write("WBSE Title");
				pwriter.write(",");
				pwriter.write("WBSE Notes");
				pwriter.write(",");
				pwriter.write("WBSE Synopsis");
			}

			//Adding Columns for TC5 Exh Cols
			if(plmCustDocReportMB.isPgplmtcfExhFlag() || plmCustDocReportMB.isTcfExhFlag()){
				pwriter.write(",");
				pwriter.write("TC5 Status");
				pwriter.write(",");
				pwriter.write("Superseded");
				pwriter.write(",");
				pwriter.write("Official");
				pwriter.write(",");
				pwriter.write("TC5 MainType");
				pwriter.write(",");
				pwriter.write("TC5 Sec. Type");
				pwriter.write(",");
				pwriter.write("TC5 Metrix");
				pwriter.write(",");
				pwriter.write("TC5 Sent");
				pwriter.write(",");
				pwriter.write("TC5 Reply");
				pwriter.write(",");
				pwriter.write("TC5 Resubmit");
				pwriter.write(",");
				pwriter.write("TC5 Customer Status");
				pwriter.write(",");
				pwriter.write("TC5 Customer");
				pwriter.write(",");
				pwriter.write("TC5 Supplier");
				pwriter.write(",");
				pwriter.write("TC5 Custom Field1");
				pwriter.write(",");
				pwriter.write("TC5 Custom Field2");
				pwriter.write(",");
				pwriter.write("TC5 Custom Field3");
				pwriter.write(",");
				pwriter.write("TC5 For Approval");
				pwriter.write(",");
				pwriter.write("TC5 Contractual");
				pwriter.write(",");
				pwriter.write("TC5 ASB");
				pwriter.write(",");
				pwriter.write("TC5 Poles");
			}

			pwriter.write("\n");
			if(!PLMUtils.isEmptyList(plmCustDocReportMB.getSearchResultList())) {	
				for(int i=0; i<plmCustDocReportMB.getSearchResultList().size(); i++) {
					PLMCustDocReportData dataObj = (PLMCustDocReportData)plmCustDocReportMB.getSearchResultList().get(i);

					if(dataObj.getOpContract()!= null){
						pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpContract()));
					}
					pwriter.write(",");

					if(dataObj.getOpContractDesc()!= null){
						pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpContractDesc()));
					}

					if(plmCustDocReportMB.isPgplmtcfFixedFlag() || plmCustDocReportMB.isPgplmFixedFlag()){
						pwriter.write(",");

						if(dataObj.getOpWBSEName()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWBSEName()));
						}
						pwriter.write(",");

						if(dataObj.getOpWBSERev()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWBSERev()+"\""));
						}
						pwriter.write(",");

						if(dataObj.getOpWBSEState()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWBSEState()));
						}
						pwriter.write(",");

						if(dataObj.getOpPld()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpPld()));
						}
						pwriter.write(",");

						if(dataObj.getOpPldRev()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpPldRev()+"\""));
						}
						pwriter.write(",");

						if(dataObj.getOpPldRelease()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpPldRelease()));
						}
						pwriter.write(",");

						if(dataObj.getOpGenTitle()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpGenTitle()+"\""));
						}
						pwriter.write(",");

						if(dataObj.getOpDetTitle()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpDetTitle()+"\""));
						}
					}
					pwriter.write(",");

					if(dataObj.getOpDocType()!= null){
						pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpDocType()));
					}
					pwriter.write(",");

					if(dataObj.getOpDocument()!= null){
						pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpDocument()));
					}
					pwriter.write(",");

					if(dataObj.getOpDocRev()!= null){
						pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpDocRev()+"\""));
					}
					if(plmCustDocReportMB.isPgplmtcfFixedFlag() || plmCustDocReportMB.isTcfFixedFlag()){
						pwriter.write(",");

						if(dataObj.getOpTc5Label()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Label()));
						}
						pwriter.write(",");

						if(dataObj.getOpLabelRev()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpLabelRev()+"\""));
						}
						pwriter.write(",");

						if(dataObj.getOpLabelRelease()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpLabelRelease()));
						}
					}

					//Adding Columns for PGPLM Exh Cols
					if(plmCustDocReportMB.isPgplmtcfExhFlag() || plmCustDocReportMB.isPgplmExhFlag()){
						//LOG.info("WBSE Originator==="+dataObj.getOpWbseOriginator());
						pwriter.write(",");
						if(dataObj.getOpWbseOriginator()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseOriginator()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseOriginated()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseOriginated()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseModified()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseModified()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseOwner()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseOwner()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseMgr()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseMgr()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseAssignee()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseAssignee()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseProjRole()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseProjRole()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseDueDate()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseDueDate()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseEstFinish()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseEstFinish()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseEstStart()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseEstStart()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseLiqDamage()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseLiqDamage()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseForDist()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseForDist()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbsePldReq()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbsePldReq()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseEid()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseEid()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseEquipCode()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseEquipCode()+"\""));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseFunSys()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseFunSys()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseClsfCode()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseClsfCode()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbsePldCode()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbsePldCode()+"\""));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseExtdocCode()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseExtdocCode()+"\""));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseExtRev()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseExtRev()+"\""));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseExtFld1()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseExtFld1()+"\""));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseExtFld2()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseExtFld2()+"\""));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseExtFld3()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseExtFld3()+"\""));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseRelProj()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseRelProj()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbsePolicy()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbsePolicy()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseCwbse()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseCwbse()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseDesc()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseDesc()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseTitle()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseTitle()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseNotes()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseNotes()));
						}
						pwriter.write(",");
						if(dataObj.getOpWbseSynopsis()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseSynopsis()));
						}
					}

					//Adding Columns for TC5 Exh Cols
					if(plmCustDocReportMB.isPgplmtcfExhFlag() || plmCustDocReportMB.isTcfExhFlag()){
						//LOG.info("TC5 Status==="+dataObj.getOpTc5Status());
						pwriter.write(",");
						if(dataObj.getOpTc5Status()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Status()));
						}
						pwriter.write(",");
						if(dataObj.getOpSuperseded()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpSuperseded()));
						}
						pwriter.write(",");
						if(dataObj.getOpOfficial()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpOfficial()));
						}
						pwriter.write(",");
						if(dataObj.getOpTc5MainType()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5MainType()));
						}
						pwriter.write(",");
						if(dataObj.getOpTc5SecType()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5SecType()));
						}
						pwriter.write(",");
						if(dataObj.getOpTc5Metrix()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Metrix()));
						}
						pwriter.write(",");
						if(dataObj.getOpTc5Sent()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Sent()));
						}
						pwriter.write(",");
						if(dataObj.getOpTc5Reply()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Reply()));
						}
						pwriter.write(",");
						if(dataObj.getOpTc5Resubmit()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Resubmit()));
						}
						pwriter.write(",");
						if(dataObj.getOpTc5CustStatus()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5CustStatus()));
						}
						pwriter.write(",");
						if(dataObj.getOpTc5Customer()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpTc5Customer()+"\""));
						}
						pwriter.write(",");
						if(dataObj.getOpTc5Supplier()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpTc5Supplier()+"\""));
						}
						pwriter.write(",");
						if(dataObj.getOpTc5CustFld1()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpTc5CustFld1()+"\""));
						}
						pwriter.write(",");
						if(dataObj.getOpTc5CustFld2()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpTc5CustFld2()+"\""));
						}
						pwriter.write(",");
						if(dataObj.getOpTc5CustFld3()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpTc5CustFld3()+"\""));
						}
						pwriter.write(",");
						if(dataObj.getOpTc5ForApproval()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5ForApproval()));
						}
						pwriter.write(",");
						if(dataObj.getOpTc5Contractual()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Contractual()));
						}
						pwriter.write(",");
						if(dataObj.getOpTc5Asb()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Asb()));
						}
						pwriter.write(",");
						if(dataObj.getOpTc5Pole()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Pole()));
						}
					}

					pwriter.write("\n");
				} 


			}

			pwriter.flush(); 
		} catch (FileNotFoundException e) {
			System.out.println("The exception is : " + e);
		} catch (Exception e1) {
			System.out.println("IOException : " + e1.getMessage());
		} finally {
			try {
				if (pwriter != null) {
					pwriter.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
		}*/
	}

	public void createDownloadFrenchCSV() throws PLMCommonException {

		LOG.info("Entering createDownloadCSV Method");
		String reportName = "custDocReportResult";
		String fileName = "custDocReportResult";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		//Export to semi colon CSV for Customer Document Report

		if(isPgplmFixedFlag() && !isPgplmExhFlag()){
			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					  new PLMCsvRptColumn("opContract", "Contract", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opContractDesc", "Contract Description",FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSEName", "WBSE", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSERev", "WBSE Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSEState", "WBSE State", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPld", "PLD", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPldRev", "PLD Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPldRelease", "PLD Release", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opGenTitle", "General Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDetTitle", "Detailed Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocType", "Doc Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocument", "Document", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocRev", "Doc Rev", FormatTypeCsv.TEXT)};
			csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, plmCustDocReportData, ";");
			
		}else if(isPgplmtcfFixedFlag() && !isPgplmtcfExhFlag()){
			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					  new PLMCsvRptColumn("opContract", "Contract", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opContractDesc", "Contract Description", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSEName", "WBSE", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSERev", "WBSE Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSEState", "WBSE State", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPld", "PLD", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPldRev", "PLD Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPldRelease", "PLD Release", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opGenTitle", "General Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDetTitle", "Detailed Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocType", "Doc Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocument", "Document", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocRev", "Doc Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Label", "TC5 Label", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opLabelRev", "Label Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opLabelRelease", "Label Release", FormatTypeCsv.TEXT)};
			csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, plmCustDocReportData, ";");
			
		}else if(isTcfFixedFlag() && !isTcfExhFlag()){
			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					  new PLMCsvRptColumn("opContract", "Contract", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opContractDesc", "Contract Description", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocType", "Doc Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocument", "Document", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocRev", "Doc Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Label", "TC5 Label", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opLabelRev", "Label Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opLabelRelease", "Label Release", FormatTypeCsv.TEXT)};
			csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, plmCustDocReportData, ";");
			
		}else if(isPgplmFixedFlag() && isPgplmExhFlag()){
			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					  new PLMCsvRptColumn("opContract", "Contract", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opContractDesc", "Contract Description", FormatTypeCsv.TEXT),
					  
					  new PLMCsvRptColumn("opWBSEName", "WBSE", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSERev", "WBSE Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSEState", "WBSE State", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPld", "PLD", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPldRev", "PLD Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPldRelease", "PLD Release", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opGenTitle", "General Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDetTitle", "Detailed Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocType", "Doc Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocument", "Document", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocRev", "Doc Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseOriginator", "WBSE Orginator", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseOriginated", "WBSE Orginated", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseModified", "WBSE Modified", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseOwner", "WBSE Owner", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseMgr", "WBSE Mgr", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseAssignee", "WBSE Assignee", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseProjRole", "WBSE Project Role", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseDueDate", "WBSE Due Date", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseEstFinish", "WBSE Est. Finish", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseEstStart", "WBSE Est. Start", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseLiqDamage", "WBSE Liquidated Damage", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseForDist", "WBSE for Distirb", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbsePldReq", "WBSE PDL Required", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseEid", "WBSE Eid", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseEquipCode", "WBSE Equipment Code", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseFunSys", "WBSE Fnctl System", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseClsfCode", "WBSE Classif Code", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbsePldCode", "WBSE PLD Code", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtdocCode", "WBSE ExtDoc Code", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtRev", "WBSE ExtRev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtFld1", "WBSE ExtField1", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtFld2", "WBSE ExtField2", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtFld3", "WBSE ExtField3", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseRelProj", "WBSE Related Project", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbsePolicy", "WBSE Policy", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseCwbse", "WBSE CWBSE", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseDesc", "WBSE Description", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseTitle", "WBSE Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseNotes", "WBSE Notes", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseSynopsis", "WBSE Synopsis", FormatTypeCsv.TEXT)};
			csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, plmCustDocReportData, ";");
		
		}else if(isPgplmtcfFixedFlag() && isPgplmtcfExhFlag()){
			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					  new PLMCsvRptColumn("opContract", "Contract", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opContractDesc", "Contract Description", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSEName", "WBSE", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSERev", "WBSE Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWBSEState", "WBSE State", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPld", "PLD", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPldRev", "PLD Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opPldRelease", "PLD Release", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opGenTitle", "General Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDetTitle", "Detailed Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocType", "Doc Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocument", "Document", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocRev", "Doc Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Label", "TC5 Label", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opLabelRev", "Label Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opLabelRelease", "Label Release", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseOriginator", "WBSE Orginator", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseOriginated", "WBSE Orginated", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseModified", "WBSE Modified", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseOwner", "WBSE Owner", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseMgr", "WBSE Mgr", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseAssignee", "WBSE Assignee", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseProjRole", "WBSE Project Role", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseDueDate", "WBSE Due Date", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseEstFinish", "WBSE Est. Finish", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseEstStart", "WBSE Est. Start", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseLiqDamage", "WBSE Liquidated Damage", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseForDist", "WBSE for Distirb", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbsePldReq", "WBSE PDL Required", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseEid", "WBSE Eid", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseEquipCode", "WBSE Equipment Code", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseFunSys", "WBSE Fnctl System", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseClsfCode", "WBSE Classif Code", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbsePldCode", "WBSE PLD Code", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtdocCode", "WBSE ExtDoc Code", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtRev", "WBSE ExtRev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtFld1", "WBSE ExtField1", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtFld2", "WBSE ExtField2", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseExtFld3", "WBSE ExtField3", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseRelProj", "WBSE Related Project", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbsePolicy", "WBSE Policy", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseCwbse", "WBSE CWBSE", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseDesc", "WBSE Description", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseTitle", "WBSE Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseNotes", "WBSE Notes", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opWbseSynopsis", "WBSE Synopsis", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Status", "TC5 Status", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opSuperseded", "Superseded", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opOfficial", "Official", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5MainType", "TC5 Main Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5SecType", "TC5 Sec Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Metrix", "TC5 Metrix", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Sent", "TC5 Sent", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Reply", "TC5 Reply", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Resubmit", "TC5 Resubmit", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5CustStatus", "TC5 Customer Status", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Customer", "TC5 Customer", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Supplier", "TC5 Supplier", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5CustFld1", "TC5 Custom Field1", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5CustFld2", "TC5 Custom Field2", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5CustFld3", "TC5 Custom Field3", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5ForApproval", "TC5 for Approval", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Contractual", "TC5 Contractual", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Asb", "TC5 ASB", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Pole", "TC5 Pole", FormatTypeCsv.TEXT)};
			csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, plmCustDocReportData, ";");	
		
		}else if(isTcfFixedFlag() && isTcfExhFlag()){
			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					  new PLMCsvRptColumn("opContract", "Contract", FormatTypeCsv.TEXT, null, null, 25),
					  new PLMCsvRptColumn("opContractDesc", "Contract Description", FormatTypeCsv.TEXT, null, null, 36),
					  new PLMCsvRptColumn("opDocType", "Doc Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocument", "Document", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opDocRev", "Doc Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Label", "TC5 Label", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opLabelRev", "Label Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opLabelRelease", "Label Release", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Status", "TC5 Status", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opSuperseded", "Superseded", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opOfficial", "Official", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5MainType", "TC5 Main Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5SecType", "TC5 Sec Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Metrix", "TC5 Metrix", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Sent", "TC5 Sent", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Reply", "TC5 Reply", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Resubmit", "TC5 Resubmit", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5CustStatus", "TC5 Customer Status", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Customer", "TC5 Customer", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Supplier", "TC5 Supplier", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5CustFld1", "TC5 Custom Field1", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5CustFld2", "TC5 Custom Field2", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5CustFld3", "TC5 Custom Field3", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5ForApproval", "TC5 for Approval", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Contractual", "TC5 Contractual", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Asb", "TC5 ASB", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("opTc5Pole", "TC5 Pole", FormatTypeCsv.TEXT)};
			csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, plmCustDocReportData, ";");
		}

		LOG.info("Exiting createDownloadFrenchCSV Method");
		/*PrintWriter pwriter = null;

		try {
			
			FacesContext facesContext = FacesContext.getCurrentInstance();

			HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
			HttpServletRequest resquest = (HttpServletRequest) facesContext.getExternalContext().getRequest();
			
			HttpSession session = resquest.getSession();
			
			response.setHeader("content-disposition","attachment; filename=CustDocRptFrench.csv");
			response.setContentType("application/CSV");
			
			pwriter = response.getWriter();
			PLMCustDocReportMB plmCustDocReportMB = (PLMCustDocReportMB) session.getAttribute("plmCustDocReportMB");
			PLMCustDocReportData custDocRptData = (PLMCustDocReportData) plmCustDocReportMB.getPlmCustDocReportData();

			pwriter.write("Project/Contract");
			pwriter.write(";");
			pwriter.write(custDocRptData.getEnteredProjContract());
			pwriter.write("\n");
			pwriter.write("MLI");
			pwriter.write(";");
			pwriter.write(custDocRptData.getEnteredMLI());
			pwriter.write("\n");
			pwriter.write("Functional System");
			pwriter.write(";");
			pwriter.write(custDocRptData.getEnteredFuncSystem());
			pwriter.write("\n");
			pwriter.write("Document Name");
			pwriter.write(";");
			pwriter.write(custDocRptData.getEnteredDocName());
			pwriter.write("\n");

			pwriter.write("\n");

			pwriter.write("Contract");
			pwriter.write(";");
			pwriter.write("Contract Desc");
			if(plmCustDocReportMB.isPgplmtcfFixedFlag() || plmCustDocReportMB.isPgplmFixedFlag()){
				pwriter.write(";");
				pwriter.write("WBSE");
				pwriter.write(";");
				pwriter.write("WBSE Rev");
				pwriter.write(";");
				pwriter.write("WBSE State");
				pwriter.write(";");
				pwriter.write("PLD");
				pwriter.write(";");
				pwriter.write("PLD Rev");
				pwriter.write(";");
				pwriter.write("PLD Release");
				pwriter.write(";");
				pwriter.write("General Title");
				pwriter.write(";");
				pwriter.write("Detailed Title");
			}
			pwriter.write(";");
			pwriter.write("Doc Type");
			pwriter.write(";");
			pwriter.write("Document");
			pwriter.write(";");
			pwriter.write("Doc Rev");
			if(plmCustDocReportMB.isPgplmtcfFixedFlag() || plmCustDocReportMB.isTcfFixedFlag()){
				pwriter.write(";");
				pwriter.write("TC5 Label");
				pwriter.write(";");
				pwriter.write("Label Rev");
				pwriter.write(";");
				pwriter.write("Label Release");
			}

			//Adding Columns for PGPLM Exh Cols
			if(plmCustDocReportMB.isPgplmtcfExhFlag() || plmCustDocReportMB.isPgplmExhFlag()){
				pwriter.write(";");
				pwriter.write("WBSE Originator");
				pwriter.write(";");
				pwriter.write("WBSE Originated");
				pwriter.write(";");
				pwriter.write("WBSE Modified");
				pwriter.write(";");
				pwriter.write("WBSE Owner");
				pwriter.write(";");
				pwriter.write("WBSE Mgr");
				pwriter.write(";");
				pwriter.write("WBSE Assignee");
				pwriter.write(";");
				pwriter.write("WBSE ProjectRole");
				pwriter.write(";");
				pwriter.write("WBSE Due Date");
				pwriter.write(";");
				pwriter.write("WBSE Est. Finish");
				pwriter.write(";");
				pwriter.write("WBSE Est. Start");
				pwriter.write(";");
				pwriter.write("WBSE Liquidated Damage");
				pwriter.write(";");
				pwriter.write("WBSE For Distrib");
				pwriter.write(";");
				pwriter.write("WBSE PLD Required");
				pwriter.write(";");
				pwriter.write("WBSE EID");
				pwriter.write(";");
				pwriter.write("WBSE Equipment Code");
				pwriter.write(";");
				pwriter.write("WBSE Fnctl System");
				pwriter.write(";");
				pwriter.write("WBSE Classif Code");
				pwriter.write(";");
				pwriter.write("WBSE PLD Code");
				pwriter.write(";");
				pwriter.write("WBSE ExtDoc Code");
				pwriter.write(";");
				pwriter.write("WBSE ExtRev");
				pwriter.write(";");
				pwriter.write("WBSE ExtField1");
				pwriter.write(";");
				pwriter.write("WBSE ExtField2");
				pwriter.write(";");
				pwriter.write("WBSE ExtField3");
				pwriter.write(";");
				pwriter.write("WBSE Related Project");
				pwriter.write(";");
				pwriter.write("WBSE Policy");
				pwriter.write(";");
				pwriter.write("WBSE CWBSE");
				pwriter.write(";");
				pwriter.write("WBSE Description");
				pwriter.write(";");
				pwriter.write("WBSE Title");
				pwriter.write(";");
				pwriter.write("WBSE Notes");
				pwriter.write(";");
				pwriter.write("WBSE Synopsis");
			}

			//Adding Columns for TC5 Exh Cols
			if(plmCustDocReportMB.isPgplmtcfExhFlag() || plmCustDocReportMB.isTcfExhFlag()){
				pwriter.write(";");
				pwriter.write("TC5 Status");
				pwriter.write(";");
				pwriter.write("Superseded");
				pwriter.write(";");
				pwriter.write("Official");
				pwriter.write(";");
				pwriter.write("TC5 MainType");
				pwriter.write(";");
				pwriter.write("TC5 Sec. Type");
				pwriter.write(";");
				pwriter.write("TC5 Metrix");
				pwriter.write(";");
				pwriter.write("TC5 Sent");
				pwriter.write(";");
				pwriter.write("TC5 Reply");
				pwriter.write(";");
				pwriter.write("TC5 Resubmit");
				pwriter.write(";");
				pwriter.write("TC5 Customer Status");
				pwriter.write(";");
				pwriter.write("TC5 Customer");
				pwriter.write(";");
				pwriter.write("TC5 Supplier");
				pwriter.write(";");
				pwriter.write("TC5 Custom Field1");
				pwriter.write(";");
				pwriter.write("TC5 Custom Field2");
				pwriter.write(";");
				pwriter.write("TC5 Custom Field3");
				pwriter.write(";");
				pwriter.write("TC5 For Approval");
				pwriter.write(";");
				pwriter.write("TC5 Contractual");
				pwriter.write(";");
				pwriter.write("TC5 ASB");
				pwriter.write(";");
				pwriter.write("TC5 Poles");
			}

			pwriter.write("\n");
			if(!PLMUtils.isEmptyList(plmCustDocReportMB.getSearchResultList())) {	
				for(int i=0; i<plmCustDocReportMB.getSearchResultList().size(); i++) {
					PLMCustDocReportData dataObj = (PLMCustDocReportData)plmCustDocReportMB.getSearchResultList().get(i);

					if(dataObj.getOpContract()!= null){
						pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpContract()));
					}
					pwriter.write(";");

					if(dataObj.getOpContractDesc()!= null){
						pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpContractDesc()));
					}

					if(plmCustDocReportMB.isPgplmtcfFixedFlag() || plmCustDocReportMB.isPgplmFixedFlag()){
						pwriter.write(";");

						if(dataObj.getOpWBSEName()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWBSEName()));
						}
						pwriter.write(";");

						if(dataObj.getOpWBSERev()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWBSERev()+"\""));
						}
						pwriter.write(";");

						if(dataObj.getOpWBSEState()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWBSEState()));
						}
						pwriter.write(";");

						if(dataObj.getOpPld()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpPld()));
						}
						pwriter.write(";");

						if(dataObj.getOpPldRev()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpPldRev()+"\""));
						}
						pwriter.write(";");

						if(dataObj.getOpPldRelease()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpPldRelease()));
						}
						pwriter.write(";");

						if(dataObj.getOpGenTitle()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpGenTitle()+"\""));
						}
						pwriter.write(";");

						if(dataObj.getOpDetTitle()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpDetTitle()+"\""));
						}
					}
					pwriter.write(";");

					if(dataObj.getOpDocType()!= null){
						pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpDocType()));
					}
					pwriter.write(";");

					if(dataObj.getOpDocument()!= null){
						pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpDocument()));
					}
					pwriter.write(";");

					if(dataObj.getOpDocRev()!= null){
						pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpDocRev()+"\""));
					}
					if(plmCustDocReportMB.isPgplmtcfFixedFlag() || plmCustDocReportMB.isTcfFixedFlag()){
						pwriter.write(";");

						if(dataObj.getOpTc5Label()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Label()));
						}
						pwriter.write(";");

						if(dataObj.getOpLabelRev()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpLabelRev()+"\""));
						}
						pwriter.write(";");

						if(dataObj.getOpLabelRelease()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpLabelRelease()));
						}
					}

					//Adding Columns for PGPLM Exh Cols
					if(plmCustDocReportMB.isPgplmtcfExhFlag() || plmCustDocReportMB.isPgplmExhFlag()){
						//LOG.info("WBSE Originator==="+dataObj.getOpWbseOriginator());
						pwriter.write(";");
						if(dataObj.getOpWbseOriginator()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseOriginator()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseOriginated()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseOriginated()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseModified()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseModified()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseOwner()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseOwner()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseMgr()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseMgr()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseAssignee()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseAssignee()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseProjRole()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseProjRole()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseDueDate()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseDueDate()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseEstFinish()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseEstFinish()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseEstStart()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseEstStart()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseLiqDamage()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseLiqDamage()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseForDist()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseForDist()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbsePldReq()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbsePldReq()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseEid()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseEid()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseEquipCode()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseEquipCode()+"\""));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseFunSys()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseFunSys()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseClsfCode()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseClsfCode()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbsePldCode()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbsePldCode()+"\""));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseExtdocCode()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseExtdocCode()+"\""));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseExtRev()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseExtRev()+"\""));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseExtFld1()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseExtFld1()+"\""));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseExtFld2()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseExtFld2()+"\""));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseExtFld3()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpWbseExtFld3()+"\""));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseRelProj()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseRelProj()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbsePolicy()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbsePolicy()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseCwbse()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseCwbse()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseDesc()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseDesc()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseTitle()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseTitle()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseNotes()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseNotes()));
						}
						pwriter.write(";");
						if(dataObj.getOpWbseSynopsis()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpWbseSynopsis()));
						}
					}

					//Adding Columns for TC5 Exh Cols
					if(plmCustDocReportMB.isPgplmtcfExhFlag() || plmCustDocReportMB.isTcfExhFlag()){
						//LOG.info("TC5 Status==="+dataObj.getOpTc5Status());
						pwriter.write(";");
						if(dataObj.getOpTc5Status()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Status()));
						}
						pwriter.write(";");
						if(dataObj.getOpSuperseded()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpSuperseded()));
						}
						pwriter.write(";");
						if(dataObj.getOpOfficial()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpOfficial()));
						}
						pwriter.write(";");
						if(dataObj.getOpTc5MainType()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5MainType()));
						}
						pwriter.write(";");
						if(dataObj.getOpTc5SecType()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5SecType()));
						}
						pwriter.write(";");
						if(dataObj.getOpTc5Metrix()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Metrix()));
						}
						pwriter.write(";");
						if(dataObj.getOpTc5Sent()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Sent()));
						}
						pwriter.write(";");
						if(dataObj.getOpTc5Reply()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Reply()));
						}
						pwriter.write(";");
						if(dataObj.getOpTc5Resubmit()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Resubmit()));
						}
						pwriter.write(";");
						if(dataObj.getOpTc5CustStatus()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5CustStatus()));
						}
						pwriter.write(";");
						if(dataObj.getOpTc5Customer()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpTc5Customer()+"\""));
						}
						pwriter.write(";");
						if(dataObj.getOpTc5Supplier()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpTc5Supplier()+"\""));
						}
						pwriter.write(";");
						if(dataObj.getOpTc5CustFld1()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpTc5CustFld1()+"\""));
						}
						pwriter.write(";");
						if(dataObj.getOpTc5CustFld2()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpTc5CustFld2()+"\""));
						}
						pwriter.write(";");
						if(dataObj.getOpTc5CustFld3()!= null){
							pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpTc5CustFld3()+"\""));
						}
						pwriter.write(";");
						if(dataObj.getOpTc5ForApproval()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5ForApproval()));
						}
						pwriter.write(";");
						if(dataObj.getOpTc5Contractual()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Contractual()));
						}
						pwriter.write(";");
						if(dataObj.getOpTc5Asb()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Asb()));
						}
						pwriter.write(";");
						if(dataObj.getOpTc5Pole()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTc5Pole()));
						}
					}

					pwriter.write("\n");
				} 


			}

			pwriter.flush(); 
		} catch (FileNotFoundException e) {
			System.out.println("The exception is : " + e);
		} catch (Exception e1) {
			System.out.println("IOException : " + e1.getMessage());
		} finally {
			try {
				if (pwriter != null) {
					pwriter.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
		}*/
	}

	/**
	 * @return the plmCustDocReportService
	 */
	public PLMCustDocReportServiceIfc getPlmCustDocReportService() {
		return plmCustDocReportService;
	}
	/**
	 * @param plmCustDocReportService the plmCustDocReportService to set
	 */
	public void setPlmCustDocReportService(
			PLMCustDocReportServiceIfc plmCustDocReportService) {
		this.plmCustDocReportService = plmCustDocReportService;
	}

	/**
	 * @return the plmCustDocReportData
	 */
	public PLMCustDocReportData getPlmCustDocReportData() {
		return plmCustDocReportData;
	}

	/**
	 * @param plmCustDocReportData the plmCustDocReportData to set
	 */
	public void setPlmCustDocReportData(PLMCustDocReportData plmCustDocReportData) {
		this.plmCustDocReportData = plmCustDocReportData;
	}


	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}


	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}
	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}
	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}


	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}


	/**
	 * @return the fwdFlag
	 */
	public String getFwdFlag() {
		return fwdFlag;
	}


	/**
	 * @param fwdFlag the fwdFlag to set
	 */
	public void setFwdFlag(String fwdFlag) {
		this.fwdFlag = fwdFlag;
	}


	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}


	/**
	 * @param totalRecCount the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}


	/**
	 * @return the searchResultList
	 */
	public List<PLMCustDocReportData> getSearchResultList() {
		return searchResultList;
	}


	/**
	 * @param searchResultList the searchResultList to set
	 */
	public void setSearchResultList(List<PLMCustDocReportData> searchResultList) {
		this.searchResultList = searchResultList;
	}


	/**
	 * @return the totalRecCountMsg
	 */
	public String getTotalRecCountMsg() {
		return totalRecCountMsg;
	}


	/**
	 * @param totalRecCountMsg the totalRecCountMsg to set
	 */
	public void setTotalRecCountMsg(String totalRecCountMsg) {
		this.totalRecCountMsg = totalRecCountMsg;
	}


	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}


	/**
	 * @param recordCounts the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}





	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}


	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}


	/**
	 * @return the pgplmtcfExhFlag
	 */
	public boolean isPgplmtcfExhFlag() {
		return pgplmtcfExhFlag;
	}


	/**
	 * @param pgplmtcfExhFlag the pgplmtcfExhFlag to set
	 */
	public void setPgplmtcfExhFlag(boolean pgplmtcfExhFlag) {
		this.pgplmtcfExhFlag = pgplmtcfExhFlag;
	}


	/**
	 * @return the pgplmExhFlag
	 */
	public boolean isPgplmExhFlag() {
		return pgplmExhFlag;
	}


	/**
	 * @param pgplmExhFlag the pgplmExhFlag to set
	 */
	public void setPgplmExhFlag(boolean pgplmExhFlag) {
		this.pgplmExhFlag = pgplmExhFlag;
	}


	/**
	 * @return the tcfExhFlag
	 */
	public boolean isTcfExhFlag() {
		return tcfExhFlag;
	}


	/**
	 * @param tcfExhFlag the tcfExhFlag to set
	 */
	public void setTcfExhFlag(boolean tcfExhFlag) {
		this.tcfExhFlag = tcfExhFlag;
	}


	/**
	 * @return the selCrtMsg
	 */
	public String getSelCrtMsg() {
		return selCrtMsg;
	}


	/**
	 * @param selCrtMsg the selCrtMsg to set
	 */
	public void setSelCrtMsg(String selCrtMsg) {
		this.selCrtMsg = selCrtMsg;
	}

	/**
	 * @return the typeOfReport
	 */
	public String getTypeOfReport() {
		return typeOfReport;
	}

	/**
	 * @param typeOfReport the typeOfReport to set
	 */
	public void setTypeOfReport(String typeOfReport) {
		this.typeOfReport = typeOfReport;
	}

	/**
	 * @return the exportToExcelFlag
	 */
	public boolean isExportToExcelFlag() {
		return exportToExcelFlag;
	}

	/**
	 * @param exportToExcelFlag the exportToExcelFlag to set
	 */
	public void setExportToExcelFlag(boolean exportToExcelFlag) {
		this.exportToExcelFlag = exportToExcelFlag;
	}

	/**
	 * @return the pgplmtcfFixedFlag
	 */
	public boolean isPgplmtcfFixedFlag() {
		return pgplmtcfFixedFlag;
	}

	/**
	 * @param pgplmtcfFixedFlag the pgplmtcfFixedFlag to set
	 */
	public void setPgplmtcfFixedFlag(boolean pgplmtcfFixedFlag) {
		this.pgplmtcfFixedFlag = pgplmtcfFixedFlag;
	}

	/**
	 * @return the pgplmFixedFlag
	 */
	public boolean isPgplmFixedFlag() {
		return pgplmFixedFlag;
	}

	/**
	 * @param pgplmFixedFlag the pgplmFixedFlag to set
	 */
	public void setPgplmFixedFlag(boolean pgplmFixedFlag) {
		this.pgplmFixedFlag = pgplmFixedFlag;
	}

	/**
	 * @return the tcfFixedFlag
	 */
	public boolean isTcfFixedFlag() {
		return tcfFixedFlag;
	}

	/**
	 * @param tcfFixedFlag the tcfFixedFlag to set
	 */
	public void setTcfFixedFlag(boolean tcfFixedFlag) {
		this.tcfFixedFlag = tcfFixedFlag;
	}



}
