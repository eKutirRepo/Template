package com.geinfra.geaviation.pwi.dao;

import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupJoinVO;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.model.PWiQueryNoXmlVO;
import com.geinfra.geaviation.pwi.model.PWiQueryVO;
import com.geinfra.geaviation.pwi.model.PWiUserVO;
import com.geinfra.geaviation.pwi.model.QueriesVO;
import com.geinfra.geaviation.pwi.util.ColumnConstants;
import com.geinfra.geaviation.pwi.util.DaoUtil;
import com.geinfra.geaviation.pwi.util.MapperConstants;
import com.geinfra.geaviation.pwi.util.QueryConstants;
import com.geinfra.geaviation.pwi.util.QueryLoader;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 5, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * 
 * Copyright(C) 2013 GE All rights reserved
 * 
 * Description :
 * 
 * Revision Log Aug 5, 2010 | v1.0.
 * --------------------------------------------------------------
 */

public class QueriesDAOImpl extends PWiDAO implements QueriesDAO {
	// TODO refactor up to service level and remove?
	private TransactionTemplate transactionTemplate;

	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}

	public Integer createQuery(final String queryName, final String queryDesc,
			final List<Integer> slctdObjTyps, final String qryKeyWrdTxt,
			final String queryXML,
			final List<PWiQueryGroupVO> selectedQueryGroupsList,
			final String userId, final boolean exportControlled,
			final boolean geOnly, final boolean popular,final boolean active, final Map<String, List<PWiUserVO>> tempGrpUsrMap,final String queryFlag) throws PWiException {
		try {
			return (Integer) transactionTemplate.execute(new TransactionCallback() {
				public Object doInTransaction(TransactionStatus ts) {
					String sql = QueryLoader.getQuery(QueryConstants.PWi_QUERY_INSERT);
					Connection connection = null;
					CallableStatement statement = null;
					try {
						connection = getJdbcTemplate().getDataSource().getConnection();
						statement = connection.prepareCall(sql);
						int idx = 1; // parameter index
						// Set input parameters
						statement.setString(idx++, queryName);
						DaoUtil.getInstance().setXmlType(connection, statement, idx++, queryXML);
						statement.setString(idx++, queryDesc);
						statement.setString(idx++, qryKeyWrdTxt);
						statement.setString(idx++, "Y"); // subscribeable
						statement.setString(idx++, exportControlled ? "Y" : "N");
						statement.setString(idx++, geOnly ? "Y" : "N");
						statement.setString(idx++, popular ? "Y" : "N");
						statement.setString(idx++, active ? "Y" : "N");
						statement.setString(idx++, userId);
						statement.setString(idx++, userId);					
						statement.setString(idx++, queryFlag);
						// Set output parameters
						statement.registerOutParameter(idx, Types.NUMERIC);
						// Execute query
						statement.execute();
						// Retrieve primary key
						Integer queryId = Integer.valueOf(statement.getInt(idx));
						String grpSql = QueryLoader.getQuery(QueryConstants.PWi_GROUP_QUERY_INSERT);
						if (selectedQueryGroupsList.size() > 0) {
							for (PWiQueryGroupVO queryGroupVO2 : selectedQueryGroupsList) {
								Object[] params = new Object[] { queryId,
										queryGroupVO2.getQueryGroupId(), userId, userId };
								getJdbcTemplate().update(grpSql, params);
								String revUserAccSql = QueryLoader.getQuery(QueryConstants.PWi_GROUP_QUERY_USER_INSERT);
								if (tempGrpUsrMap!=null && tempGrpUsrMap.size() > 0) {
									List<PWiUserVO> userList = tempGrpUsrMap.get(queryGroupVO2.getQueryGroupId()+":"+queryGroupVO2.getQueryGroupName());
									if(userList!=null)
									{
									for (PWiUserVO user : userList) {
										if(!user.isUserSelected())
										{
										Object[] paramsUser = new Object[] { queryId,
												queryGroupVO2.getQueryGroupId(), user.getUserId(),userId, userId };
										getJdbcTemplate().update(revUserAccSql, paramsUser);
									}}}}}}
						for (Integer objectTypeId : slctdObjTyps) {
							getJdbcTemplate().update(QueryLoader.getQuery(QueryConstants.PWi_QUERY_OBJECT_INSERT),new Object[] { queryId, objectTypeId, userId, userId });
						}
						return queryId;
					} catch (SQLException e) {
						throw new RuntimeException(e);
					} finally {
						try {
							if ( statement != null) {  statement.close(); }
							if (connection != null) { connection.close(); }
						} catch (SQLException e) {
							throw new RuntimeException(e);
						}}}}); // end anonymous inner TransactionCallback class; max length 60
		} catch (DataAccessException e) {
			throw new PWiException(e, "Exception creating query.");
		}
	}

	@SuppressWarnings("unchecked")
	public QueriesVO searchQuery(Integer queryId, String[] roles)
			throws PWiException {
		try {
			String sql = roles == null ? QueryLoader
					.getQuery(QueryConstants.SEARCH_QUERY) : QueryLoader
					.getQuery(QueryConstants.SEARCH_QUERY_ROLES);

			int inPos = StringUtils.lastIndexOf(sql, "?");
			Object[] params = null;
			if (roles != null) {
				String sub = StringUtils.substring(sql, 0, inPos + 1);
				params = new Object[1 + roles.length];
				params[0] = queryId;
				StringBuffer qMarks = new StringBuffer(sub);
				for (int idx = 0; idx < roles.length; idx++) {
					if (idx + 1 < roles.length)
						qMarks.append(",?");
					params[1 + idx] = roles[idx];
				}

				sql = qMarks.toString() + "))";
			} else {

				params = new Object[] { queryId };
			}
			QuerySearchRowMapper mapper = new QuerySearchRowMapper();
			List<QueriesVO> result = (List<QueriesVO>) getJdbcTemplate().query(
					sql, params, mapper);
			return (result != null && result.size() == 1) ? result.get(0)
					: null;
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}

	}

	/**
	 * Used by AdminQiSettingsBean to get all queries
	 */
	public List<PWiQueryNoXmlVO> getQueries() throws PWiException {
		// Assemble SQL string
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT qry.QRY_SEQ_ID, qry.QRY_NM, qry.QRY_DESC, qry.QRY_KYWRD_TXT");
		sql.append(", qry.QRY_EC_IND, qry.QRY_GE_IND, qry.QRY_TAG_POP,qry.QRY_LOG_ACTIVE");
		sql.append(", grp.QRY_GRP_SEQ_ID, grp.QRY_GRP_DSPLY_NM");
		sql.append(" FROM PLMR.PWi_QUERY qry");
		sql.append(" LEFT OUTER JOIN PLMR.PWi_GROUP_QUERY gr_qr ON qry.Qry_Seq_id = gr_qr.Qry_Seq_id");
		sql.append(" LEFT OUTER JOIN PLMR.PWi_QUERY_GROUP grp ON grp.Qry_Grp_Seq_Id = gr_qr.Qry_Grp_Seq_Id");

		// create row handler
		PWiQueryNoXmlVoRowCallbackHandler rowHandler = new PWiQueryNoXmlVoRowCallbackHandler();

		// execute query
		getJdbcTemplate().query(sql.toString(), rowHandler);

		return rowHandler.getQueries();
	}

	/**
	 * 
	 * 
	 * Used by QI and QueryListBean to get all queries visible to the user,
	 * regardless of whether the user may execute
	 */

	public List<PWiQueryNoXmlVO> getVisibleQueries(List<String> groups)
			throws PWiException {
		return searchVisibleQueries(null, groups);
	}

//	 TODO pH 2013.02: refactor to admin service?
	public List<QueriesVO> getAllQueries() throws PWiException {
		// TODO pH 2013.02: move some of these queries to properties?
		String sql = new StringBuffer("SELECT qry.QRY_SEQ_ID, qry.QRY_NM, qry.QRY_KYWRD_TXT,")
				.append(" qry.QRY_DESC, qry.QRY_EC_IND, qry.QRY_GE_IND,")
				.append(" grp.QRY_GRP_SEQ_ID, grp.QRY_GRP_NM")
				.append(" FROM PLMR.PWi_QUERY qry, PLMR.PWi_GROUP_QUERY grp_qry, PLMR.PWi_QUERY_GROUP grp")
				.append(" WHERE grp_qry.QRY_SEQ_ID(+) = qry.QRY_SEQ_ID")
				.append(" and grp_qry.QRY_GRP_SEQ_ID = grp.QRY_GRP_SEQ_ID(+)").toString();
		final GetAllQueriesMapper rowHandler = new GetAllQueriesMapper();
		try {
			// Execute query
			@SuppressWarnings("unchecked")
			List<QueriesVO> queries = (List<QueriesVO>) getJdbcTemplate()
					.query(sql, rowHandler);

			return queries;
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}

	private static class GetAllQueriesMapper implements
			ParameterizedRowMapper<QueriesVO> {
		public QueriesVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			QueriesVO queryVO = new QueriesVO();
			queryVO.setQueryId(Integer.valueOf(rs
					.getInt(ColumnConstants.QRY_SEQ_ID)));
			queryVO.setQueryName(rs.getString(ColumnConstants.QRY_NM));
			queryVO.setQueryGroupName(rs.getString(ColumnConstants.QRY_GRP_NM));
			queryVO.setQryKeyWrdTxt(rs.getString(ColumnConstants.QRY_KYWRD_TXT));
			queryVO.setQueryDesc(rs.getString(ColumnConstants.QRY_DESC));
			queryVO.setExportControlled("Y".equals(rs
					.getString(ColumnConstants.QRY_EC_IND)));
			queryVO.setGeOnly("Y".equals(rs
					.getString(ColumnConstants.QRY_GE_IND)));
			return queryVO;
		}
	}
	
	
	public List<QueriesVO> getAllDraftQueries(String ssoId) throws PWiException {
		// TODO pH 2013.02: move some of these queries to properties?
		String sql = new StringBuffer(
				"SELECT qry.QRY_SEQ_ID, qry.QRY_NM, qry.QRY_KYWRD_TXT,")
				.append(" qry.QRY_DESC, qry.QRY_EC_IND, qry.QRY_GE_IND,")
				.append(" LISTAGG(grp.QRY_GRP_NM, ', ') WITHIN GROUP (ORDER BY grp.QRY_GRP_NM) QRY_GRP_NM ")
				.append(" FROM PLMR.PWi_QUERY qry, PLMR.PWi_GROUP_QUERY grp_qry, PLMR.PWi_QUERY_GROUP grp")
				.append(" WHERE grp_qry.QRY_SEQ_ID(+) = qry.QRY_SEQ_ID")
				.append(" and grp_qry.QRY_GRP_SEQ_ID = grp.QRY_GRP_SEQ_ID(+)")
				.append(" AND qry.QUERY_FLAG='D' ")
				.append(" AND qry.CRTD_BY=")
				.append(ssoId)
				.append(" group by qry.QRY_SEQ_ID, qry.QRY_NM, qry.QRY_KYWRD_TXT,qry.QRY_DESC, qry.QRY_EC_IND, qry.QRY_GE_IND ")
				.append(" order by qry.QRY_NM ")
				.toString();
		final GetAllDrafQueriesMapper rowHandler = new GetAllDrafQueriesMapper();
		try {
			// Execute query
			@SuppressWarnings("unchecked")
			List<QueriesVO> queries = (List<QueriesVO>) getJdbcTemplate()
					.query(sql, rowHandler);

			return queries;
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}

	private static class GetAllDrafQueriesMapper implements
			ParameterizedRowMapper<QueriesVO> {
		public QueriesVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			QueriesVO queryVO = new QueriesVO();
			queryVO.setQueryId(Integer.valueOf(rs
					.getInt(ColumnConstants.QRY_SEQ_ID)));
			queryVO.setQueryName(rs.getString(ColumnConstants.QRY_NM));
			queryVO.setQueryGroupName(rs.getString(ColumnConstants.QRY_GRP_NM));
			queryVO.setQryKeyWrdTxt(rs.getString(ColumnConstants.QRY_KYWRD_TXT));
			queryVO.setQueryDesc(rs.getString(ColumnConstants.QRY_DESC));
			queryVO.setExportControlled("Y".equals(rs
					.getString(ColumnConstants.QRY_EC_IND)));
			queryVO.setGeOnly("Y".equals(rs
					.getString(ColumnConstants.QRY_GE_IND)));
			return queryVO;
		}
	}	
	
	/**
	 * 
	 * Code review requires JavaDoc comments on all public classes.
	 */

	public static class PWiQueryNoXmlVORowMapper implements
			ParameterizedRowMapper<PWiQueryNoXmlVO> {
		public PWiQueryNoXmlVO mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PWiQueryNoXmlVO query = new PWiQueryNoXmlVO();
			query.setQrySeqId(Integer.valueOf(rs
					.getInt(ColumnConstants.QRY_SEQ_ID)));
			query.setQryNm(rs.getString(ColumnConstants.QRY_NM));
			query.setQryDesc(rs.getString(ColumnConstants.QRY_DESC));
			query.setQryKywrdTxt(rs.getString(ColumnConstants.QRY_KYWRD_TXT));
			query.setExportControlled("Y".equals(rs
					.getString(ColumnConstants.QRY_EC_IND)));
			query.setGeOnly("Y".equals(rs.getString(ColumnConstants.QRY_GE_IND)));

			return query;
		}
	}

	private static class PWiQueryNoXmlVoRowCallbackHandler implements
			RowCallbackHandler {
		Map<Integer, PWiQueryNoXmlVO> queries = new HashMap<Integer, PWiQueryNoXmlVO>();
		Map<Integer, PWiQueryGroupJoinVO> groups = new HashMap<Integer, PWiQueryGroupJoinVO>();

		public List<PWiQueryNoXmlVO> getQueries() {
			return new ArrayList<PWiQueryNoXmlVO>(queries.values());
		}

		public void processRow(ResultSet rs) throws SQLException {
			PWiQueryNoXmlVO query = null;
			Integer queryId = Integer.valueOf(rs
					.getInt(ColumnConstants.QRY_SEQ_ID));

			if (queries.containsKey(queryId)) {
				query = queries.get(queryId);
			} else {
				query = new PWiQueryNoXmlVO();
				query.setQrySeqId(queryId);
				query.setQryNm(rs.getString(ColumnConstants.QRY_NM));
				query.setQryDesc(rs.getString(ColumnConstants.QRY_DESC));
				query.setQryKywrdTxt(rs
						.getString(ColumnConstants.QRY_KYWRD_TXT));
				query.setExportControlled("Y".equals(rs
						.getString(ColumnConstants.QRY_EC_IND)));
				query.setGeOnly("Y".equals(rs
						.getString(ColumnConstants.QRY_GE_IND)));
				query.setPopular("Y".equals(rs
						.getString(ColumnConstants.QRY_TAG_POP)));
				query.setActive("Y".equals(rs
						.getString(ColumnConstants.QRY_LOG_ACTIVE)));

				queries.put(queryId, query);
			}

			String groupIdString = rs
					.getString(PWiQueryGroupJoinVO.QRY_GRP_SEQ_ID);
			if (groupIdString != null) {
				PWiQueryGroupJoinVO group = null;
				Integer groupId = Integer.valueOf(groupIdString);
				if (groups.containsKey(groupId)) {
					group = groups.get(groupId);
				} else {
					group = new PWiQueryGroupJoinVO();
					group.setGroupId(groupId);
					group.setdisplayNm(rs.getString("QRY_GRP_DSPLY_NM"));
					groups.put(groupId, group);
				}

				// Add relations
				query.getGroups().add(group);
				group.getQueries().add(query);
			} // else if groupID == null, this means this is a left outer join
				// row that indicates the query has no groups
		}
	}

	public void updateQuery(PWiQueryVO query, String sso) {

		PreparedStatementCreator psc = new UpdateQueryCreator(query, sso);
		getJdbcTemplate().update(psc);
	}

	private static class UpdateQueryCreator implements PreparedStatementCreator {
		private PWiQueryVO query;
		private String userId;

		public UpdateQueryCreator(PWiQueryVO query, String userId) {
			this.query = query;
			this.userId = userId;
		}

		public PreparedStatement createPreparedStatement(Connection connection)
				throws SQLException {
			String sql = QueryLoader.getQuery(QueryConstants.PWi_QUERY_UPDATE);
			PreparedStatement ps = connection.prepareStatement(sql);

			int idx = 1; // parameter index
			ps.setString(idx++, query.getQryNm());
			DaoUtil.getInstance().setXmlType(connection, ps, idx++,
					query.getQryXml());
			ps.setString(idx++, query.getQryKywrdTxt());
			ps.setString(idx++, query.getQryDesc());
			ps.setString(idx++, query.isExportControlled() ? "Y" : "N");
			ps.setString(idx++, query.isGeOnly() ? "Y" : "N");
			ps.setString(idx++, query.isPopular() ? "Y" : "N");
			ps.setString(idx++, query.isActive() ? "Y" : "N");
			ps.setString(idx++, userId);
			ps.setInt(idx++, query.getQrySeqId().intValue());

			return ps;
		}
	}

	public List<PWiQueryNoXmlVO> searchVisibleQueries(String queryName,
			List<String> groups) {
		// Assemble SQL string
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT qry.QRY_SEQ_ID, qry.QRY_NM, qry.QRY_DESC, qry.QRY_KYWRD_TXT");
		sql.append(", qry.QRY_EC_IND, qry.QRY_GE_IND, qry.QRY_TAG_POP,qry.QRY_LOG_ACTIVE");
		sql.append(", grp.QRY_GRP_SEQ_ID, grp.QRY_GRP_DSPLY_NM");
		sql.append(" FROM PLMR.PWi_QUERY qry");
		sql.append(" LEFT OUTER JOIN PLMR.PWi_GROUP_QUERY gr_qr ON qry.Qry_Seq_id = gr_qr.Qry_Seq_id");
		sql.append(" LEFT OUTER JOIN PLMR.PWi_QUERY_GROUP grp ON grp.Qry_Grp_Seq_Id = gr_qr.Qry_Grp_Seq_Id");
		sql.append(" WHERE");

		// add query name filtering, if applicable
		if (queryName != null) {
			sql.append(" (Lower(Qry.Qry_Nm) LIKE ? OR");
			sql.append(" Lower(Qry_Kywrd_Txt) LIKE ?) AND");
		}

		// Add group filtering
		sql.append(" (grp.ALWYS_SHW = 'Y' OR grp.QRY_GRP_NM in (");
		// sql.append(" grp.QRY_GRP_NM in (");
		for (int i = 0; i < groups.size(); i++) {
			if (i == 0) {
				sql.append("?");
			} else {
				sql.append(",?");
			}
		}
		sql.append("))");
		sql.append(" and qry.QRY_LOG_ACTIVE = 'Y'");

		// Prepared statement setter
		PreparedStatementSetter pss = new SearchVisibleQueriesSetter(queryName,
				groups);

		// create row handler
		PWiQueryNoXmlVoRowCallbackHandler rowHandler = new PWiQueryNoXmlVoRowCallbackHandler();

		// Run query
		getJdbcTemplate().query(sql.toString(), pss, rowHandler);

		return rowHandler.getQueries();
	}

	private static class SearchVisibleQueriesSetter implements
			PreparedStatementSetter {
		private String queryNamePattern;
		private List<String> groups;

		public SearchVisibleQueriesSetter(String qryName, List<String> groups) {
			this.queryNamePattern = qryName;
			this.groups = groups;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			int paramIdx = 1;

			// set query name, if any
			if (queryNamePattern != null) {
				// the pattern is used twice, once for the query name,
				// and once for keywords
				ps.setString(paramIdx++, queryNamePattern);
				ps.setString(paramIdx++, queryNamePattern);
			}

			// set each group name
			for (String group : groups) {
				ps.setString(paramIdx++, group);
			}
		}
	}

	@SuppressWarnings("unchecked")
	public List<String> searchQueryTypeahead(String queryName,
			List<String> roles) {
		String searchQuerySql = QueryLoader
				.getQuery(QueryConstants.SEARCH_QUERY_SQL);

		int inPos = StringUtils.lastIndexOf(searchQuerySql, "?");
		String sub = StringUtils.substring(searchQuerySql, 0, inPos + 1);
		String order = StringUtils.substring(searchQuerySql, inPos + 2);
		String[] params = new String[2 + roles.size()];
		int paramIdx = 0;
		params[paramIdx++] = queryName;
		params[paramIdx++] = queryName;
		StringBuffer sqlBuffer = new StringBuffer(sub);
		for (String role : roles) {
			if (paramIdx > 2) // all roles but one
				sqlBuffer.append(",?");
			params[paramIdx++] = role;
		}
		searchQuerySql = sqlBuffer.append(")").append(order).toString();

		List<String> srchList = getJdbcTemplate().query(searchQuerySql, params,
				MapperConstants.TYPEAHEAD);

		return srchList;
	}

	// TODO move to GroupQueryDAO?
	public List<PWiQueryNoXmlVO> getQueriesForGroupNames(
			final List<String> groups, final Boolean exportControlled,
			final Boolean geOnly) {
		// Assemble SQL string
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT qry.QRY_SEQ_ID, qry.QRY_NM, qry.QRY_DESC, qry.QRY_KYWRD_TXT");
		sql.append(", qry.QRY_EC_IND, qry.QRY_GE_IND, qry.QRY_TAG_POP,qry.QRY_LOG_ACTIVE");
		sql.append(", grp.QRY_GRP_SEQ_ID, grp.QRY_GRP_DSPLY_NM");
		sql.append(" FROM PLMR.PWi_GROUP_QUERY gr_qr");
		sql.append(", PLMR.PWi_QUERY_GROUP grp, PLMR.PWi_QUERY qry");
		sql.append(" WHERE");
		sql.append(" gr_qr.Qry_Seq_id = qry.Qry_Seq_id");
		sql.append(" AND grp.Qry_Grp_Seq_Id = gr_qr.Qry_Grp_Seq_Id");

		// Add group filtering
		sql.append(" AND grp.Qry_Grp_Nm IN (");
		for (int i = 0; i < groups.size(); i++) {
			if (i == 0) {
				sql.append("?");
			} else {
				sql.append(",?");
			}
		}
		sql.append(")");
		sql.append(" AND qry.QRY_LOG_ACTIVE = 'Y'");

		// add export controlled filter
		if (exportControlled != null) {
			sql.append(" AND qry.qry_ec_ind=?");
		}

		// add GE-only filter
		if (geOnly != null) {
			sql.append(" AND qry.qry_ge_ind=?");
		}

		// Prepared statement setter
		PreparedStatementSetter pss = new GetQueriesForGroupNamesSetter(groups,
				exportControlled, geOnly);

		// create row handler
		PWiQueryNoXmlVoRowCallbackHandler rowHandler = new PWiQueryNoXmlVoRowCallbackHandler();

		// execute query
		getJdbcTemplate().query(sql.toString(), pss, rowHandler);

		return rowHandler.getQueries();
	}

	private static class GetQueriesForGroupNamesSetter implements
			PreparedStatementSetter {
		private List<String> groups;
		private Boolean exportControlled;
		private Boolean geOnly;

		public GetQueriesForGroupNamesSetter(List<String> groups,
				Boolean exportControlled, Boolean geOnly) {
			this.groups = groups;
			this.exportControlled = exportControlled;
			this.geOnly = geOnly;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			int parameterIndex = 1;
			for (String group : groups) {
				ps.setString(parameterIndex, group);
				parameterIndex++;
			}

			if (exportControlled != null) {
				ps.setString(parameterIndex,
						exportControlled.booleanValue() ? "Y" : "N");
				parameterIndex++;
			}

			if (geOnly != null) {
				ps.setString(parameterIndex, geOnly.booleanValue() ? "Y" : "N");
			}

		}

	}

	public List<PWiQueryVO> getQueriesForGroupNames(final List<String> groups)
			throws PWiException {
		// Construct SQL
		String userSearchQuerySql = QueryLoader
				.getQuery(QueryConstants.SEARCH_QUERY_FOR_USER);
		int inPos = StringUtils.lastIndexOf(userSearchQuerySql, "?");
		String sub = StringUtils.substring(userSearchQuerySql, 0, inPos);
		StringBuffer qMarks = new StringBuffer(sub);
		for (int i = 0; i < groups.size(); i++) {
			if (i == 0) {
				qMarks.append("?");
			} else {
				qMarks.append(",?");
			}
		}

		userSearchQuerySql = qMarks.append(")").toString();

		// Prepared statement setter
		PreparedStatementSetter pss = new GetQueriesForGroupNamesNoFlagsSetter(
				groups);

		// Run query
		@SuppressWarnings("unchecked")
		List<PWiQueryVO> qryForUser = (List<PWiQueryVO>) getJdbcTemplate()
				.query(userSearchQuerySql, pss,
						MapperConstants.QUERY_ROW_MAPPER);

		return qryForUser;
	}

	private static class GetQueriesForGroupNamesNoFlagsSetter implements
			PreparedStatementSetter {
		private List<String> groups;

		public GetQueriesForGroupNamesNoFlagsSetter(List<String> groups) {
			this.groups = groups;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			int parameterIndex = 1;
			for (String group : groups) {
				ps.setString(parameterIndex, group);
				parameterIndex++;
			}
		}
	}

	@SuppressWarnings("unchecked")
	public int checkQueryNameEdit(String queryName, Integer queryId)
			throws PWiException {
		try {
			final ParameterizedRowMapper<QueriesVO> mapper = new CheckQueryNameMapper();
			List<QueriesVO> result = (List<QueriesVO>) getJdbcTemplate()
					.query(QueryLoader
							.getQuery(QueryConstants.SEARCH_QUERY_EDIT_NAME),
							new Object[] { queryName, queryId }, mapper);
			return result.size();
		} catch (DataAccessException e) {
			throw new PWiException(
					e,
					new StringBuffer(
							"Error checking for query name availability for edit.  query name: ")
							.append(queryName).append(", query ID: ")
							.append(queryId).toString());
		}
	}

	@SuppressWarnings("unchecked")
	public int checkQueryName(String queryName) throws PWiException {
		try {
			final ParameterizedRowMapper<QueriesVO> mapper = new CheckQueryNameMapper();
			List<QueriesVO> result = (List<QueriesVO>) getJdbcTemplate()
					.query(QueryLoader
							.getQuery(QueryConstants.SEARCH_QUERY_WITH_NAME),
							new Object[] { queryName }, mapper);
			return result.size();
		} catch (DataAccessException e) {
			throw new PWiException(e,
					"Error checking for query name availability for new.  query name: "
							+ queryName);
		}
	}

	private static class CheckQueryNameMapper implements
			ParameterizedRowMapper<QueriesVO> {
		public QueriesVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			QueriesVO queryVO = new QueriesVO();
			queryVO.setQueryId(Integer.valueOf(rs.getInt("queryid")));
			queryVO.setQueryName(rs.getString("queryname"));
			return queryVO;
		}
	}

	private static final class QuerySearchRowMapper implements
			ParameterizedRowMapper<QueriesVO> {
		public QueriesVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			QueriesVO queryVO = new QueriesVO();
			queryVO.setQueryName(rs.getString("queryname"));
			queryVO.setQueryId(Integer.valueOf(rs.getInt("queryid")));

			Clob clob = rs.getClob("queryxml");
			if (clob != null) {
				queryVO.setQueryXML(clob.getSubString(1L, (int) clob.length()));
			}

			queryVO.setQueryDesc(rs.getString("qrydesc"));
			queryVO.setQryKeyWrdTxt(rs.getString("kywrdtxt"));
			queryVO.setExportControlled("Y".equals(rs
					.getString(ColumnConstants.QRY_EC_IND)));
			queryVO.setGeOnly("Y".equals(rs
					.getString(ColumnConstants.QRY_GE_IND)));
			queryVO.setPopular("Y".equals(rs
					.getString(ColumnConstants.QRY_TAG_POP)));
			queryVO.setActive("Y".equals(rs
					.getString(ColumnConstants.QRY_LOG_ACTIVE)));
			return queryVO;
		}
	}

	private String getStandardQuerySelect() {
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT qr.QRY_SEQ_ID,qr.QRY_NM");
		builder.append(",XMLSerialize(DOCUMENT qr.QRY_XML_LNG_TXT AS CLOB)QRY_XML_LNG_TXT");
		builder.append(",qr.QRY_DESC,qr.QRY_KYWRD_TXT,qr.QRY_SUBSCRIBEABLE_IND");
		builder.append(",qr.QRY_EC_IND,qr.QRY_GE_IND,qr.CRTN_DT");
		builder.append(",qr.CRTD_BY,qr.LST_UPDT_DT,qr.LST_UPDTD_BY FROM PLMR.PWi_QUERY qr");
		return builder.toString();
	}

	public PWiQueryVO getQueryById(final Integer queryId) {
		String sql = getStandardQuerySelect() + " WHERE QRY_SEQ_ID=?";

		PreparedStatementSetter pss = new GetQueryByIdSetter(queryId);

		@SuppressWarnings("unchecked")
		List<PWiQueryVO> resultList = (List<PWiQueryVO>) getJdbcTemplate()
				.query(sql, pss, MapperConstants.QUERY_ROW_MAPPER);
		if (resultList.size() > 1) {
			throw new IllegalStateException(
					"Multiple rows returned for query id!  query id: "
							+ queryId);
		}
		if (resultList.isEmpty()) {
			return null;
		}
		return resultList.get(0);
	}

	private static class GetQueryByIdSetter implements PreparedStatementSetter {
		private Integer queryId;

		public GetQueryByIdSetter(Integer queryId) {
			this.queryId = queryId;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setInt(1, queryId.intValue());
		}
	}

	public List<PWiQueryVO> getQueriesForObjectType(final String objectTypeName) {
		// Define SQL
		StringBuilder sql = new StringBuilder();
		sql.append(getStandardQuerySelect());
		sql.append(", PWi_QUERY_OBJECT qo, PWi_OBJECT_TYPE ot");
		sql.append(" WHERE upper(ot.obj_typ_nm)=?");
		sql.append(" AND ot.obj_typ_seq_id=qo.obj_typ_seq_id");
		sql.append(" AND qo.qry_seq_id=qr.qry_seq_id");

		// Define prepared statement setter
		PreparedStatementSetter pss = new GetQueriesForObjectTypeSetter(
				objectTypeName);

		// Execute query
		@SuppressWarnings("unchecked")
		List<PWiQueryVO> resultList = (List<PWiQueryVO>) getJdbcTemplate()
				.query(sql.toString(), pss, MapperConstants.QUERY_ROW_MAPPER);

		return resultList;
	}

	private static class GetQueriesForObjectTypeSetter implements
			PreparedStatementSetter {
		private String objectType;

		public GetQueriesForObjectTypeSetter(String objectType) {
			this.objectType = objectType;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setString(1, objectType.toUpperCase(Locale.US));
		}

	}

	@SuppressWarnings("unchecked")
	public List<QueriesVO> getQueriesByGroupId(Integer groupId) {
		Object obj[] = new Object[1];
		obj[0] = groupId;
		List<QueriesVO> queriesInGroup = getJdbcTemplate().query(
				QueryLoader.getQuery(QueryConstants.GET_QRY_IN_GRP), obj,
				MapperConstants.QUERY_MAPPER);
		return queriesInGroup;
	}

	@SuppressWarnings("unchecked")
	public List<QueriesVO> getQueriesNotInGroup(Integer groupId) {
		Object obj[] = new Object[1];
		obj[0] = groupId;
		List<QueriesVO> queriesNotInGroup = getJdbcTemplate().query(
				QueryLoader.getQuery(QueryConstants.GET_AVL_QRY), obj,
				MapperConstants.QUERY_MAPPER);
		return queriesNotInGroup;
	}
	
	public List<PWiQueryGroupVO> getNonVisibleQueries(String sso) {
		// Assemble SQL string
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT QRY_SEQ_ID,QRY_GRP_SEQ_ID");
		sql.append(" FROM PLMR.PWI_GROUP_QUERY_USERS ");
		sql.append(" WHERE QRY_GRP_USER_ID=(select pwi_uid from PLMR.pwi_users where pwi_uname=?)");

		Object obj[] = new Object[1];
		obj[0] = sso;
		List<PWiQueryGroupVO> queriesNotInGroup = getJdbcTemplate().query(sql.toString(), obj,
				MapperConstants.QUERY_ROW_USER_MAPPER);
		return queriesNotInGroup;
		}

		
		
}
