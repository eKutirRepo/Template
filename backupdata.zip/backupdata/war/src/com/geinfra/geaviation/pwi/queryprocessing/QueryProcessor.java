package com.geinfra.geaviation.pwi.queryprocessing;

import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.PWiQueryTimeoutException;
import com.geinfra.geaviation.pwi.common.PWiResultSizeLimitExceededException;
import com.geinfra.geaviation.pwi.model.PWiResultSet;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;

/**
 * Project      : Product Lifecycle Management Intelligence
 * Date Written : Oct 13, 2010
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : QueryProcessor
 * 
 * Revision Log Oct 13, 2010 | v1.0.
 * 2012.12.18 pH  replaced GEAEResultSet with PWiResultSet
 * --------------------------------------------------------------
 */
public interface QueryProcessor {

	/**
	 * Do any necessary pre-processing before executing the query (i.e. adding
	 * necessary columns to retrieve).
	 * 
	 * @param selectedColumns
	 *            The selected columns which will be used to execute the query.
	 * @throws PWiException
	 */
	public void preProcess(SelectedColumns selectedColumns)
			throws PWiException;

	/**
	 * Do any necessary post-processing after the query has executed (i.e.
	 * transforming the results into a pivot table).
	 * 
	 * @param rs
	 *            the results of the query
	 * @param search
	 *            The search criteria used to execute the query
	 * @param selectedColumns
	 *            The selected columns that were used to execute the query
	 * @param queryType
	 *            The query XML definition for the query that was executed
	 * @return the post-processed representation of the results
	 * @throws PWiException
	 * @throws PWiResultSizeLimitExceededException
	 * @throws PWiQueryTimeoutException
	 */
	public PWiResultSet postProcess(PWiResultSet rs, Search search,
			List<String> selectedColumns, QueryType queryType)
			throws PWiException, PWiQueryTimeoutException, PWiResultSizeLimitExceededException;
}
