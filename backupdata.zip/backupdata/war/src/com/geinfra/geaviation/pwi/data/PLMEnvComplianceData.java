/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEnvComplianceData.java
 * @Creation date: 9-Jul-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;

public class PLMEnvComplianceData {
	/**
	 * Holds cntrtNm
	 */
	private String cntrtNm;
	
	/**
	 * Holds projectNm
	 */
	private String projectNm;
	/**
	 * Holds wsdeName
	 */
	private String wsdeName;
	/**
	 * Holds wsdePartName
	 */
	private String wsdePartName;
	/**
	 * Holds cntrtDesc
	 */
	private String cntrtDesc;
	/**
	 * Holds poNum
	 */
	private String poNum;
	/**
	 * Holds purchaseFolderDt
	 */
	private Date purchaseFolderDt;
	/**
	 * Holds supplierName
	 */
	private String supplierName;
	/**
	 * Holds supplierPerson
	 */
	private String supplierPerson;
	/**
	 * Holds supplierEmail
	 */
	private String supplierEmail;
	/**
	 * Holds purchaseFolderNm
	 */
	private String purchaseFolderNm;
	/**
	 * Holds supplierBannCode
	 */
	private String supplierBannCode;
	/**
	 * Holds mliNew
	 */
	private String mliNew;
	/**
	 * Holds contract
	 */
	private String contract;
	/**
	 * Holds mliReference
	 */
	private String mliReference;
	/**
	 * Holds partNum
	 */
	private String partNum;
	/**
	 * Holds partLvl
	 */
	private String partLvl;
	/**
	 * Holds material
	 */
	private String material;
	/**
	 * Holds materialType
	 */
	private String materialType;
	/**
	 * Holds regulation
	 */
	private String regulation;
	/**
	 * Holds subCaseNm
	 */
	private String subCaseNm;
	/**
	 * Holds subName
	 */
	private String subName;
	/**
	 * Holds subName
	 */
	private String chemicalName;
	/**
	 * Holds partAttribute
	 */
	private String partAttribute;
	/**
	 * Holds partRevision
	 */
	
	private String partRevision;
	/**
	 * Holds partTitle
	 */
	private String partTitle;
	/**
	 * Holds partType
	 */
	private String partType;
	/**
	 * Holds rdoName
	 */
	private String rdoName;
	/**
	 * Holds dfsOrder
	 */
	private String dfsOrder;
	
	/**
	 * @return the cntrtNm
	 */
	public String getCntrtNm() {
		return cntrtNm;
	}
	/**
	 * @param cntrtNm the cntrtNm to set
	 */
	public void setCntrtNm(String cntrtNm) {
		this.cntrtNm = cntrtNm;
	}
	/**
	 * @return the projectNm
	 */
	public String getProjectNm() {
		return projectNm;
	}
	/**
	 * @param projectNm the projectNm to set
	 */
	public void setProjectNm(String projectNm) {
		this.projectNm = projectNm;
	}
	/**
	 * @return the wsdeName
	 */
	public String getWsdeName() {
		return wsdeName;
	}
	/**
	 * @param wsdeName the wsdeName to set
	 */
	public void setWsdeName(String wsdeName) {
		this.wsdeName = wsdeName;
	}
	/**
	 * @return the wsdePartName
	 */
	public String getWsdePartName() {
		return wsdePartName;
	}
	/**
	 * @param wsdePartName the wsdePartName to set
	 */
	public void setWsdePartName(String wsdePartName) {
		this.wsdePartName = wsdePartName;
	}
	/**
	 * @return the cntrtDesc
	 */
	public String getCntrtDesc() {
		return cntrtDesc;
	}
	/**
	 * @param cntrtDesc the cntrtDesc to set
	 */
	public void setCntrtDesc(String cntrtDesc) {
		this.cntrtDesc = cntrtDesc;
	}
	/**
	 * @return the poNum
	 */
	public String getPoNum() {
		return poNum;
	}
	/**
	 * @param poNum the poNum to set
	 */
	public void setPoNum(String poNum) {
		this.poNum = poNum;
	}
	/**
	 * @return the purchaseFolderDt
	 */
	public Date getPurchaseFolderDt() {
		Date prchFldrDt = purchaseFolderDt;
		return prchFldrDt;
	}
	/**
	 * @param purchaseFolderDt the purchaseFolderDt to set
	 */
	public void setPurchaseFolderDt(Date purchaseFolderDt) {
		Date prchFldrDt = purchaseFolderDt;
		this.purchaseFolderDt = prchFldrDt;
	}
	/**
	 * @return the supplierName
	 */
	public String getSupplierName() {
		return supplierName;
	}
	/**
	 * @param supplierName the supplierName to set
	 */
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	/**
	 * @return the supplierPerson
	 */
	public String getSupplierPerson() {
		return supplierPerson;
	}
	/**
	 * @param supplierPerson the supplierPerson to set
	 */
	public void setSupplierPerson(String supplierPerson) {
		this.supplierPerson = supplierPerson;
	}
	/**
	 * @return the supplierEmail
	 */
	public String getSupplierEmail() {
		return supplierEmail;
	}
	/**
	 * @param supplierEmail the supplierEmail to set
	 */
	public void setSupplierEmail(String supplierEmail) {
		this.supplierEmail = supplierEmail;
	}
	/**
	 * @return the purchaseFolderNm
	 */
	public String getPurchaseFolderNm() {
		return purchaseFolderNm;
	}
	/**
	 * @param purchaseFolderNm the purchaseFolderNm to set
	 */
	public void setPurchaseFolderNm(String purchaseFolderNm) {
		this.purchaseFolderNm = purchaseFolderNm;
	}
	/**
	 * @return the supplierBannCode
	 */
	public String getSupplierBannCode() {
		return supplierBannCode;
	}
	/**
	 * @param supplierBannCode the supplierBannCode to set
	 */
	public void setSupplierBannCode(String supplierBannCode) {
		this.supplierBannCode = supplierBannCode;
	}
	/**
	 * @return the mliNew
	 */
	public String getMliNew() {
		return mliNew;
	}
	/**
	 * @param mliNew the mliNew to set
	 */
	public void setMliNew(String mliNew) {
		this.mliNew = mliNew;
	}
	/**
	 * @return the contract
	 */
	public String getContract() {
		return contract;
	}
	/**
	 * @param contract the contract to set
	 */
	public void setContract(String contract) {
		this.contract = contract;
	}
	/**
	 * @return the mliReference
	 */
	public String getMliReference() {
		return mliReference;
	}
	/**
	 * @param mliReference the mliReference to set
	 */
	public void setMliReference(String mliReference) {
		this.mliReference = mliReference;
	}
	/**
	 * @return the partNum
	 */
	public String getPartNum() {
		return partNum;
	}
	/**
	 * @param partNum the partNum to set
	 */
	public void setPartNum(String partNum) {
		this.partNum = partNum;
	}
	/**
	 * @return the partLvl
	 */
	public String getPartLvl() {
		return partLvl;
	}
	/**
	 * @param partLvl the partLvl to set
	 */
	public void setPartLvl(String partLvl) {
		this.partLvl = partLvl;
	}
	/**
	 * @return the material
	 */
	public String getMaterial() {
		return material;
	}
	/**
	 * @param material the material to set
	 */
	public void setMaterial(String material) {
		this.material = material;
	}
	/**
	 * @return the materialType
	 */
	public String getMaterialType() {
		return materialType;
	}
	/**
	 * @param materialType the materialType to set
	 */
	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}
	/**
	 * @return the regulation
	 */
	public String getRegulation() {
		return regulation;
	}
	/**
	 * @param regulation the regulation to set
	 */
	public void setRegulation(String regulation) {
		this.regulation = regulation;
	}
	/**
	 * @return the subCaseNm
	 */
	public String getSubCaseNm() {
		return subCaseNm;
	}
	/**
	 * @param subCaseNm the subCaseNm to set
	 */
	public void setSubCaseNm(String subCaseNm) {
		this.subCaseNm = subCaseNm;
	}
	/**
	 * @return the subName
	 */
	public String getSubName() {
		return subName;
	}
	/**
	 * @param subName the subName to set
	 */
	public void setSubName(String subName) {
		this.subName = subName;
	}
	/**
	 * @return the partAttribute
	 */
	public String getPartAttribute() {
		return partAttribute;
	}
	/**
	 * @param partAttribute the partAttribute to set
	 */
	public void setPartAttribute(String partAttribute) {
		this.partAttribute = partAttribute;
	}
	/**
	 * @return the partRevision
	 */
	public String getPartRevision() {
		return partRevision;
	}
	/**
	 * @param partRevision the partRevision to set
	 */
	public void setPartRevision(String partRevision) {
		this.partRevision = partRevision;
	}
	/**
	 * @return the partTitle
	 */
	public String getPartTitle() {
		return partTitle;
	}
	/**
	 * @param partTitle the partTitle to set
	 */
	public void setPartTitle(String partTitle) {
		this.partTitle = partTitle;
	}
	/**
	 * @return the partType
	 */
	public String getPartType() {
		return partType;
	}
	/**
	 * @param partType the partType to set
	 */
	public void setPartType(String partType) {
		this.partType = partType;
	}
	/**
	 * @return the rdoName
	 */
	public String getRdoName() {
		return rdoName;
	}
	/**
	 * @param rdoName the rdoName to set
	 */
	public void setRdoName(String rdoName) {
		this.rdoName = rdoName;
	}
	/**
	 * @return the dfsOrder
	 */
	public String getDfsOrder() {
		return dfsOrder;
	}
	/**
	 * @param dfsOrder the dfsOrder to set
	 */
	public void setDfsOrder(String dfsOrder) {
		this.dfsOrder = dfsOrder;
	}
	/**
	 * @return the chemicalName
	 */
	public String getChemicalName() {
		return chemicalName;
	}
	/**
	 * @param chemicalName the chemicalName to set
	 */
	public void setChemicalName(String chemicalName) {
		this.chemicalName = chemicalName;
	}
	
}
