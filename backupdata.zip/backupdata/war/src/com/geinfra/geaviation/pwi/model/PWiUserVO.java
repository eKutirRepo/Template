package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;

import com.geinfra.geaviation.pwi.json.JsonBuilder;
import com.geinfra.geaviation.pwi.json.Jsonable;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : PWiObjectTypeVO - Object Type object.
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiUserVO extends PWiBaseVO implements Serializable,
		Jsonable {
	private static final long serialVersionUID = 2L;
	private Integer userId;
	private String userNm;
	private String userLastNm;
	private String email;
	private String sso;
	private String roleName;
	private String usPerson;
	private String geEmployee;
	private boolean enabled;
	private Integer selectedGroupId;
	private String userForSelectedGroup;
	private boolean userSelected;
	private String roleId;
	
	/**
	 * @return the roleId
	 */
	public String getRoleId() {
		return roleId;
	}
	/**
	 * @param roleId the roleId to set
	 */
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	/**
	 * @return the selectedGroupId
	 */
	public Integer getSelectedGroupId() {
		return selectedGroupId;
	}
	/**
	 * @param selectedGroupId the selectedGroupId to set
	 */
	public void setSelectedGroupId(Integer selectedGroupId) {
		this.selectedGroupId = selectedGroupId;
	}
	/**
	 * @return the userSelected
	 */
	public boolean isUserSelected() {
		return userSelected;
	}
	/**
	 * @param userSelected the userSelected to set
	 */
	public void setUserSelected(boolean userSelected) {
		this.userSelected = userSelected;
	}
	public String getUserForSelectedGroup() {
		return userForSelectedGroup;
	}
	public void setUserForSelectedGroup(String userForSelectedGroup) {
		this.userForSelectedGroup = userForSelectedGroup;
	}
	public String getUsPerson() {
		return usPerson;
	}
	public void setUsPerson(String usPerson) {
		this.usPerson = usPerson;
	}
	public String getGeEmployee() {
		return geEmployee;
	}
	public void setGeEmployee(String geEmployee) {
		this.geEmployee = geEmployee;
	}
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUserNm() {
		return userNm;
	}

	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}

	public String getUserLastNm() {
		return userLastNm;
	}

	public void setUserLastNm(String userLastNm) {
		this.userLastNm = userLastNm;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSso() {
		return sso;
	}

	public void setSso(String sso) {
		this.sso = sso;
	}

	private StringBuffer groupNames = new StringBuffer();

	public PWiUserVO() {
	}

	public PWiUserVO(Integer userId) {
		this.userId = userId;
	}

	public PWiUserVO(Integer userId, String userNm, String userLastNm,String email,String sso) {
		this.userId = userId;
		this.userNm = userNm;
		this.userLastNm = userLastNm;
		this.email = email;
		this.sso = sso;
	}


	
	public String getGroupNames() {
		return groupNames.toString();
	}
	
	public void clearGroupNames() {
		groupNames = new StringBuffer();
	}
	
	public void addGroupName(String groupName) {
		if (groupNames.length() > 0) {
			// if this is not the first group name, delimit with a line break
			groupNames.append("<br/>");
		}
		// add the new group name
		groupNames.append(groupName != null ? groupName : "");
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (userId != null ? userId.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object instanceof PWiUserVO) {
			PWiUserVO other = (PWiUserVO) object;
			if (this.userId != null && other.userId != null) {
				return this.userId.equals(other.userId);
			}
		}
		return false;
	}

	@Override
	public String toString() {
		return (null != this.getUserNm() ? this.getUserNm() : "");
	}

	public String toJson() {
		JsonBuilder builder = new JsonBuilder();
		builder.startObject();
		builder.addStringProperty("id", userId);
		builder.addStringProperty("name", userNm);
		builder.addStringProperty("userLastNm", userLastNm);
		builder.addStringProperty("email", email);
		builder.addStringProperty("sso", sso);
		builder.endObject();
		return builder.toString();
	}
}
