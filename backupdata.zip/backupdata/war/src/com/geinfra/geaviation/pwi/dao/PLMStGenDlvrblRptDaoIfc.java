/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMStGenDlvrblRptDaoIfc.java
 * @Creation date: 28-May-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import com.geinfra.geaviation.pwi.data.PLMBomSpecPartData;
import com.geinfra.geaviation.pwi.data.PLMMessageData;
import com.geinfra.geaviation.pwi.data.PLMRouteTaskOwnerData;
import com.geinfra.geaviation.pwi.data.PLMSalesOrderData;
import com.geinfra.geaviation.pwi.data.PLMTaskDlvrblData;
import com.geinfra.geaviation.pwi.data.PLMTaskRouteData;

public interface PLMStGenDlvrblRptDaoIfc {

		
	/**
	 * Returns the BOM most recent revision
	 *  @param bomNumber(String)
	 * @return max_revision (String)
	 */
	public abstract String max_revision(List<String> topPartsList);

	/**
	 * Returns Map of tasks deliverables with its ids
	 *  @param projectName(String)
	 * @return tasks_deliverables (List<TaskDeliverable>)
	 */
	public abstract List<PLMTaskDlvrblData> tasks_deliverables(String projectName);
	
	/**
	 * Returns the list of bom parts
	 *  @param bomNumber(String)
	 *  @param maxRevision(String)
	 * @return bom_parts (List<BomSpecPart>)
	 */
	public abstract Map<String, PLMBomSpecPartData> bom_parts(List<String> topPartsList, String genSteamFlag);

	/**
	 * Returns the list of spec parts
	 *  @param bomNumber(String)
	 *  @param maxRevision(String)  
	 * @return spec_parts (List<BomSpecPart>)
	 */
	public abstract Map<String, PLMBomSpecPartData> spec_parts(List<String> topPartsList,String genSteamFlag);

	/**
	 * Returns the list of messages
	 *  @param projectName(String)
	 * @return messages (List<Message>)
	 */
	public abstract List<PLMMessageData> messages(String projectName);
	
	/**
	 * Returns the list route-task owners
	 *  @param projectName(String)
	 * @return routeTaskOwners (List<RouteTaskOwner>)
	 */
	public abstract List<PLMRouteTaskOwnerData> routeTaskOwners(String projectName);

	/**
	 * Returns the list route-task owners
	 *  @param projectName(String)
	 * @return routeTaskOwners (List<RouteTaskOwner>)
	 */
	public abstract List<PLMTaskRouteData> tasks_routes(String projectName);
	
	/**
	 * Returns the list sales_orders owners
	 *  @param projectName(String)
	 * @return sales_orders (List<SalesOrder>)
	 */
	public abstract List<PLMSalesOrderData> sales_orders(String projectName);
		
	/**
	 * Returns the list of getTopPartNames
	 *  @param projectNmLcl(String)
	 * @return String (List<String>)
	 */
	public List<String> getTopPartNames(String projectNmLcl,String genSteamFlag);
	
}
