/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBoilerShopBomReportMB.java
 * @Creation date: 07-Mar-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.UnderlinePatterns;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFStyles;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTHeight;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTJc;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTShd;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTString;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblBorders;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblWidth;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTcPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTrPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTVerticalJc;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STBorder;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STJc;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STShd;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STTblWidth;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STVerticalJc;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMBoilerShipBomReportData;
import com.geinfra.geaviation.pwi.data.PLMBoilerShopBomReportData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMBoilerShippingBomReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMBoilerShopBomReportMB {

	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMBoilerShopBomReportMB.class);
	private List<SelectItem> projectList = new ArrayList<SelectItem>();
	private List<SelectItem> contractNameList = new ArrayList<SelectItem>();
	private List<SelectItem> topLvlPartList = new ArrayList<SelectItem>();
	private List<SelectItem> topLvlPartListReset = new ArrayList<SelectItem>();
	private List<SelectItem> parentAssyNoList = new ArrayList<SelectItem>();
	private List<SelectItem> projectListReset = new ArrayList<SelectItem>();
	private List<SelectItem> projPartList = new ArrayList<SelectItem>();
	private List<SelectItem> projPartListNew = new ArrayList<SelectItem>();
	private PLMBoilerShopBomReportData pwiReportvo = new PLMBoilerShopBomReportData();
	private String alertMessage;
	private boolean allOpenPrjName;
	private boolean allOpenContractName;
	private boolean allOpenTopLvlPart;
	private boolean allOpenParentAssyNumber;
	private List<String> selShipBomProjectName = new ArrayList<String>();
	private String selShipBomCntractName = new String();
	private String selShipBomTopLvlPartName = new String();
	private List<String> selShipBomParentAssyNo = new ArrayList<String>();
	private PLMBoilerShippingBomReportServiceIfc plmBoilerShippingBomReportService = null;
	private PLMCommonMB commonMB;
	private boolean showPartRev;
	private boolean showDocRev;
	/**
	 * Holds user information
	 */
	private PLMPwiUserData userDetails = null;

	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	/**
	 * Holds the resourceBundle
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	
	
	/**
	 * @return the allOpenParentAssyNumber
	 */
	public boolean isAllOpenParentAssyNumber() {
		return allOpenParentAssyNumber;
	}

	/**
	 * @param allOpenParentAssyNumber the allOpenParentAssyNumber to set
	 */
	public void setAllOpenParentAssyNumber(boolean allOpenParentAssyNumber) {
		this.allOpenParentAssyNumber = allOpenParentAssyNumber;
	}

	/**
	 * @return the parentAssyNoList
	 */
	public List<SelectItem> getParentAssyNoList() {
		return parentAssyNoList;
	}

	/**
	 * @param parentAssyNoList the parentAssyNoList to set
	 */
	public void setParentAssyNoList(List<SelectItem> parentAssyNoList) {
		this.parentAssyNoList = parentAssyNoList;
	}

	/**
	 * @return the selShipBomParentAssyNo
	 */
	public List<String> getSelShipBomParentAssyNo() {
		return selShipBomParentAssyNo;
	}

	/**
	 * @param selShipBomParentAssyNo the selShipBomParentAssyNo to set
	 */
	public void setSelShipBomParentAssyNo(List<String> selShipBomParentAssyNo) {
		this.selShipBomParentAssyNo = selShipBomParentAssyNo;
	}

	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return the userDetails
	 */
	public PLMPwiUserData getUserDetails() {
		return userDetails;
	}

	/**
	 * @param userDetails the userDetails to set
	 */
	public void setUserDetails(PLMPwiUserData userDetails) {
		this.userDetails = userDetails;
	}

	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the plmBoilerShippingBomReportService
	 */
	public PLMBoilerShippingBomReportServiceIfc getPlmBoilerShippingBomReportService() {
		return plmBoilerShippingBomReportService;
	}

	/**
	 * @param plmBoilerShippingBomReportService the plmBoilerShippingBomReportService to set
	 */
	public void setPlmBoilerShippingBomReportService(
			PLMBoilerShippingBomReportServiceIfc plmBoilerShippingBomReportService) {
		this.plmBoilerShippingBomReportService = plmBoilerShippingBomReportService;
	}

	/**
	 * @return the projPartList
	 */
	public List<SelectItem> getProjPartList() {
		return projPartList;
	}

	/**
	 * @param projPartList the projPartList to set
	 */
	public void setProjPartList(List<SelectItem> projPartList) {
		this.projPartList = projPartList;
	}
	
	/**
	 * @return the projPartListNew
	 */
	public List<SelectItem> getProjPartListNew() {
		return projPartListNew;
	}

	/**
	 * @param projPartListNew the projPartListNew to set
	 */
	public void setProjPartListNew(List<SelectItem> projPartListNew) {
		this.projPartListNew = projPartListNew;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @return the pwiReportvo
	 */
	public PLMBoilerShopBomReportData getPwiReportvo() {
		return pwiReportvo;
	}

	/**
	 * @param pwiReportvo the pwiReportvo to set
	 */
	public void setPwiReportvo(PLMBoilerShopBomReportData pwiReportvo) {
		this.pwiReportvo = pwiReportvo;
	}

	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the allOpenPrjName
	 */
	public boolean isAllOpenPrjName() {
		return allOpenPrjName;
	}

	/**
	 * @param allOpenPrjName the allOpenPrjName to set
	 */
	public void setAllOpenPrjName(boolean allOpenPrjName) {
		this.allOpenPrjName = allOpenPrjName;
	}

	/**
	 * @return the allOpenContractName
	 */
	public boolean isAllOpenContractName() {
		return allOpenContractName;
	}

	/**
	 * @param allOpenContractName the allOpenContractName to set
	 */
	public void setAllOpenContractName(boolean allOpenContractName) {
		this.allOpenContractName = allOpenContractName;
	}

	/**
	 * @return the allOpenTopLvlPart
	 */
	public boolean isAllOpenTopLvlPart() {
		return allOpenTopLvlPart;
	}

	/**
	 * @param allOpenTopLvlPart the allOpenTopLvlPart to set
	 */
	public void setAllOpenTopLvlPart(boolean allOpenTopLvlPart) {
		this.allOpenTopLvlPart = allOpenTopLvlPart;
	}

	/**
	 * @return the selShipBomProjectName
	 */
	public List<String> getSelShipBomProjectName() {
		return selShipBomProjectName;
	}

	/**
	 * @param selShipBomProjectName the selShipBomProjectName to set
	 */
	public void setSelShipBomProjectName(List<String> selShipBomProjectName) {
		this.selShipBomProjectName = selShipBomProjectName;
	}

	/**
	 * @return the selShipBomCntractName
	 */
	public String getSelShipBomCntractName() {
		return selShipBomCntractName;
	}

	/**
	 * @param selShipBomCntractName the selShipBomCntractName to set
	 */
	public void setSelShipBomCntractName(String selShipBomCntractName) {
		this.selShipBomCntractName = selShipBomCntractName;
	}

	/**
	 * @return the selShipBomTopLvlPartName
	 */
	public String getSelShipBomTopLvlPartName() {
		return selShipBomTopLvlPartName;
	}

	/**
	 * @param selShipBomTopLvlPartName the selShipBomTopLvlPartName to set
	 */
	public void setSelShipBomTopLvlPartName(String selShipBomTopLvlPartName) {
		this.selShipBomTopLvlPartName = selShipBomTopLvlPartName;
	}

	/**
	 * @return the plmBoilerReportService
	 */
	public PLMBoilerShippingBomReportServiceIfc getPlmBoilerReportService() {
		return plmBoilerShippingBomReportService;
	}

	/**
	 * @param plmBoilerReportService the plmBoilerReportService to set
	 */
	public void setPlmBoilerReportService(
			PLMBoilerShippingBomReportServiceIfc plmBoilerShippingBomReportService) {
		this.plmBoilerShippingBomReportService = plmBoilerShippingBomReportService;
	}

	/**
	 * @return the projectList
	 */
	public List<SelectItem> getProjectList() {
		return projectList;
	}

	/**
	 * @param projectList the projectList to set
	 */
	public void setProjectList(List<SelectItem> projectList) {
		this.projectList = projectList;
	}

	/**
	 * @return the contractNameList
	 */
	public List<SelectItem> getContractNameList() {
		return contractNameList;
	}

	/**
	 * @param contractNameList the contractNameList to set
	 */
	public void setContractNameList(List<SelectItem> contractNameList) {
		this.contractNameList = contractNameList;
	}

	/**
	 * @return the topLvlPartList
	 */
	public List<SelectItem> getTopLvlPartList() {
		return topLvlPartList;
	}

	/**
	 * @param topLvlPartList the topLvlPartList to set
	 */
	public void setTopLvlPartList(List<SelectItem> topLvlPartList) {
		this.topLvlPartList = topLvlPartList;
	}
	
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}


	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}


	/**
	 * This method is used for getProjectNameAndContractNameList
	 *  for project name and contract name
	 * 
	 * @return String
	 */
	public String getProjectNameAndContractNameList()
	{
		LOG.info("getProjectNameAndContractNameList() Method");
		String fwdFlag = "";
		alertMessage = "";
		allOpenPrjName=false;
		allOpenContractName=false;
		allOpenTopLvlPart=false;
		allOpenParentAssyNumber=false;
		selShipBomProjectName=new ArrayList<String>();
		selShipBomCntractName=new String();
		selShipBomTopLvlPartName=new String();
		selShipBomParentAssyNo=new ArrayList<String>();
		pwiReportvo.setSelectedPrjName("");
		pwiReportvo.setSelectedCntractName("");
		pwiReportvo.setSelectedTopLvlPartName("");
		pwiReportvo.setSelectedparentAssyNo("");
		pwiReportvo.setContractSelctd(false);
		pwiReportvo.setProjectSelctd(false);
		pwiReportvo.setTaskSelectd(false);
		showPartRev = true;
		showDocRev = true;
		try {
			 commonMB.insertCannedRptRecordHitInfo("Shop BOM Report");
			// Map<String, List<SelectItem>> dropdownlist = plmBoilerShippingBomReportService.getProjectNameAndContractNameList();
			// projectList = (List<SelectItem>) dropdownlist.get("projectnamelist");
			 contractNameList = new ArrayList<SelectItem>();
			 projectListReset=projectList;
			 projectList=new ArrayList<SelectItem>();
			 
			 //topLvlPartList = (List<SelectItem>) dropdownlist.get("topLvlpartlistreset");
			 topLvlPartListReset=topLvlPartList;
			 LOG.info("Task Name List Size while loading"+topLvlPartListReset.size());
			 topLvlPartList=new ArrayList<SelectItem>();
			 parentAssyNoList=new ArrayList<SelectItem>();
			 
			fwdFlag = "backlogShopBomRptHome";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getProjectNameAndContractNameList: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Shop BOM Report");
		} 
		return fwdFlag;
	}
	/**
	 * This method is used for Contract auto complete feature
	 * 
	 * @return String
	 */
/*	public List<String> contractFamilyAutocomplete(Object contractShopBomFamilySuggest) {
		LOG.info("Inside contractFamilyAutocomplete method... PLMBoilerShopBomReportMB");
		String pref = (String) contractShopBomFamilySuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (contractNameList.size() > 0) {
				for (SelectItem item : contractNameList) {
					if (!item.getLabel().equals("")
							&& item.getLabel().startsWith(
									pref.toUpperCase(Locale.getDefault()))) {
						result.add(item.getLabel());
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@contractFamilyAutocomplete in PLMBoilerShopBomReportMB:",
					exception);
		}
		LOG.info("Exit from contractFamilyAutocomplete method... PLMBoilerShopBomReportMB");
		return result;
	}*/
	public void contractFamilyAutocomplete(){
		LOG.info("Entering contractFamilyAutocomplete method");
		try{
			contractNameList=new ArrayList<SelectItem>();
			if(!PLMUtils.isEmpty(pwiReportvo.getSelectedCntractName())){
				contractNameList = plmBoilerShippingBomReportService.contractFamilyAutocomplete(pwiReportvo.getSelectedCntractName().trim());
			if(PLMUtils.isEmptyList(contractNameList)){
				contractNameList=new ArrayList<SelectItem>();
				 alertMessage = "No Contracts Found for the Search";
			}
			}else{
				 alertMessage = "Please type some text in the box";
			}
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting contractFamilyAutocomplete method");
	}
	/**
	 * This method is used for Project auto complete feature
	 * 
	 * @return String
	 */
	public List<String> projectFamilyAutocomplete(Object projectShopBomFamilySuggest) {
		LOG.info("Inside projectFamilyAutocomplete method... PLMBoilerShopBomReportMB");
		String pref = (String) projectShopBomFamilySuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (projectList.size() > 0) {
				for (SelectItem item : projectList) {
					if (!item.getLabel().equals("")
							&& item.getLabel().startsWith(
									pref.toUpperCase(Locale.getDefault()))) {
						result.add(item.getLabel());
						
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@projectFamilyAutocomplete in PLMBoilerShopBomReportMB:",
					exception);
		}
		LOG.info("Exit from projectFamilyAutocomplete method... PLMBoilerShopBomReportMB");
		return result;
	}
	/**
	 * This method is used for Top LVL Part auto complete feature
	 * 
	 * @return String
	 */
	public List<String> topLvlPartFamilyAutocomplete(Object topLvlPartShopBomFamilySuggest) {
		LOG.info("Inside topLvlPartFamilyAutocomplete method... PLMBoilerShopBomReportMB");
		String pref = (String) topLvlPartShopBomFamilySuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (topLvlPartList.size() > 0) {
				for (SelectItem item : topLvlPartList) {
					if (!item.getLabel().equals("") && item.getLabel().startsWith(pref.toUpperCase(Locale.getDefault()))) {
						result.add(item.getValue().toString());
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@topLvlPartFamilyAutocomplete in PLMBoilerShopBomReportMB:",
					exception);
		}
		LOG.info("Exit from topLvlPartFamilyAutocomplete method... PLMBoilerShopBomReportMB");
		return result;
	}
	/**
	 * This method is used for Top LVL Part auto complete feature
	 * 
	 * @return String
	 */
	public List<String> parentAssyNoFamilyAutocomplete(Object parentAssyNoShopBomFamilySuggest) {
		LOG.info("Inside parentAssyNoFamilyAutocomplete method... PLMBoilerShopBomReportMB");
		String pref = (String) parentAssyNoShopBomFamilySuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (parentAssyNoList.size() > 0) {
				for (SelectItem item : parentAssyNoList) {
					if (!item.getLabel().equals("")
							&& item.getLabel().startsWith(
									pref.toUpperCase(Locale.getDefault()))) {
						result.add(item.getValue().toString());
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@parentAssyNoFamilyAutocomplete in PLMBoilerShopBomReportMB:",
					exception);
		}
		LOG.info("Exit from parentAssyNoFamilyAutocomplete method... PLMBoilerShopBomReportMB");
		return result;
	}
	/**
	 * This method is used to get Project Information for Contracts
	 * 
	 * @param event
	 */
	public void fetchProjectList(ActionEvent event){
		LOG.info("Entering fetchProjectList method PLMBoilerShopBomReportMB");
		try{
			topLvlPartList=new ArrayList<SelectItem>();
			 List <PLMBoilerShipBomReportData> projectListData = new ArrayList<PLMBoilerShipBomReportData>();
			 projPartList = new ArrayList<SelectItem>();
			 projectListData = plmBoilerShippingBomReportService.fetchProjectList(selShipBomCntractName);
			 LOG.info("project LIST DATA Size"+projectListData.size());
			 if(projectListData.size()>0)
			 {
				 pwiReportvo.setContractSelctd(true);
			   for(int i=0;i<projectListData.size();i++){
				   projPartList.add(new SelectItem(projectListData.get(i).getProjectName()));
				}
			 }
			   projectList=projPartList;
			  
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting fetchProjectList method PLMBoilerShopBomReportMB");
	}
	/**
	 * This method is used to get Top Lvl Part Information for Projects
	 * 
	 * @param event
	 */
	public void fetchTasktList(ActionEvent event){
		alertMessage="";
		LOG.info("Entering fetchTasktList method PLMBoilerShopBomReportMB");
		try{
			 List <PLMBoilerShipBomReportData> partListData = new ArrayList<PLMBoilerShipBomReportData>();
			 projPartListNew = new ArrayList<SelectItem>();
			 if (allOpenPrjName){
				 if(!PLMUtils.isEmptyList(projectList))
				      {
					 selShipBomProjectName = new ArrayList<String>();
						   for (int i = 0 ; i < projectList.size() ; i++ )
					  	     {
							String requireValue = projectList.get(i).getValue().toString();
							selShipBomProjectName.add(requireValue);
						    }
						   
						   
						   partListData = plmBoilerShippingBomReportService.fetchTasktList(selShipBomProjectName,projectListReset,allOpenPrjName);
							 LOG.info("Task LIST DATA Size"+partListData.size());
							 if(partListData.size()>0){
								 pwiReportvo.setProjectSelctd(true);
							   for(int i=0;i<partListData.size();i++){
								   if(PLMUtils.isEmpty(partListData.get(i).getDescription())){
									   projPartListNew.add(new SelectItem(partListData.get(i).getTopLvlPart(),partListData.get(i).getTopLvlPart()));
								   }else{
									   projPartListNew.add(new SelectItem(partListData.get(i).getTopLvlPart(),partListData.get(i).getTopLvlPart().concat(":").concat(partListData.get(i).getDescription())));  
								   }
								}
							}
							   topLvlPartList =projPartListNew;	   
		
				      }else{
				    	  
				    	  alertMessage = "Please select Contract Name";
				    	  
				      }
			}else{
				   partListData = plmBoilerShippingBomReportService.fetchTasktList(selShipBomProjectName,projectListReset,allOpenPrjName);
					 LOG.info("Task LIST DATA Size"+partListData.size());
					 if(partListData.size()>0){
						 pwiReportvo.setProjectSelctd(true);
					   for(int i=0;i<partListData.size();i++){
						   if(PLMUtils.isEmpty(partListData.get(i).getDescription())){
							   projPartListNew.add(new SelectItem(partListData.get(i).getTopLvlPart(),partListData.get(i).getTopLvlPart()));
						   }else{
							   projPartListNew.add(new SelectItem(partListData.get(i).getTopLvlPart(),partListData.get(i).getTopLvlPart().concat(":").concat(partListData.get(i).getDescription())));  
						   }
						}
					}
					   topLvlPartList =projPartListNew;	   

			}
			 
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting fetchTasktList method PLMBoilerShopBomReportMB");
		
	}
	
	/**
	 * This method is used to get Parent Assembly Number Information for Task
	 * 
	 * @param event
	 */
	public void fetchParentAssyNoList(ActionEvent event){
		LOG.info("Entering fetchParentAssyNoList method PLMBoilerShopBomReportMB");
			try{
			 List <PLMBoilerShipBomReportData> partListData = new ArrayList<PLMBoilerShipBomReportData>();
			 projPartListNew = new ArrayList<SelectItem>();
			 if (allOpenParentAssyNumber){
				 if(!PLMUtils.isEmptyList(parentAssyNoList))
				      {
					 selShipBomParentAssyNo = new ArrayList<String>();
						   for (int i = 0 ; i < parentAssyNoList.size() ; i++ )
					  	     {
							String requireValue = parentAssyNoList.get(i).getValue().toString();
							selShipBomParentAssyNo.add(requireValue);
						    }
				      }
			}
			 partListData = plmBoilerShippingBomReportService.fetchPartAssemblyNumList(selShipBomCntractName, selShipBomProjectName, allOpenPrjName,
					 selShipBomTopLvlPartName);
			 LOG.info("Parent Assembly Number LIST DATA Size"+partListData.size());
			 if(partListData.size()>0){
				 pwiReportvo.setTaskSelectd(true);
			   for(int i=0;i<partListData.size();i++){
				   projPartListNew.add(new SelectItem(partListData.get(i).getPartAssmblyNo(),
						   partListData.get(i).getPartAssmblyNoDesc()));
				}
			}
			   parentAssyNoList =projPartListNew;
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting fetchParentAssyNoList method PLMBoilerShopBomReportMB");
	}
	
	/**
	 * This method is used for generating report on UI
	 * 
	 * @return String
	 * @throws PLMCommonException 
	 */
	public void generateEmailReportForShopBom() throws PWiException, PLMCommonException {
		LOG.info("get data from generateShippingBomAppReport() Method");
		alertMessage = "";
		
			 if (allOpenPrjName){
				 if(!PLMUtils.isEmptyList(projectList))
				      {
					 selShipBomProjectName = new ArrayList<String>();
						   for (int i = 0 ; i < projectList.size() ; i++ )
					  	     {
							String requireValue = projectList.get(i).getValue().toString();
							selShipBomProjectName.add(requireValue);
						    }
				      }
			}
			 
			 if (allOpenParentAssyNumber){
				 if(!PLMUtils.isEmptyList(parentAssyNoList))
				      {
					 selShipBomParentAssyNo = new ArrayList<String>();
						   for (int i = 0 ; i < parentAssyNoList.size() ; i++ )
					  	     {
							String requireValue = parentAssyNoList.get(i).getValue().toString();
							selShipBomParentAssyNo.add(requireValue);
						    }
				      }
			}
			 
			 if (PLMUtils.isEmpty(selShipBomCntractName)) {
					alertMessage = "*Contract Name Input Selection is mandatory";
				}else if(PLMUtils.isEmptyList(selShipBomProjectName)){
					alertMessage = "*Please select atleast one Project Name";
				}else if(PLMUtils.isEmpty(selShipBomTopLvlPartName)){
					alertMessage = "*Task Name Input Selection is mandatory";
				}else if(PLMUtils.isEmptyList(selShipBomParentAssyNo)){
					alertMessage = "*Parent Assembly No Input Selection is mandatory";
				}else{
					userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
					alertMessage = PLMConstants.SHOP_BOM_RPT_MAIL_ALERT_MSG;
					taskExecutor.execute(new DocGenerationThread());
				}
	}
	/**
	 * Background Process Thread
	 */
	private class DocGenerationThread implements Runnable {
		public DocGenerationThread() {
		}
		public void run() {
			sendShopBomRptMail();
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return void
	 * @throws IOException 
	 */
	public void sendShopBomRptMail(){
		LOG.info("Entering sendShopBomRptMail Method");
		
	    String contractNm =selShipBomCntractName;
	    List<String> selProjectNm =selShipBomProjectName;
	    boolean allOpenContract =allOpenContractName;
	    boolean allOpenProjectNm =allOpenPrjName;
	    String selTopLvlNm =selShipBomTopLvlPartName;
		boolean allOpenTopLvl = allOpenTopLvlPart;
		List<String> selParentAssyNm =selShipBomParentAssyNo;
		List<SelectItem> partAssblyNumListLcl =parentAssyNoList;
		boolean allOpenParentAssy = allOpenParentAssyNumber;
		String from = PLMConstants.OMM_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.SHOP_BOM_RPT_SUBJECT;
		String filePathDocx = "";
		String tempPathDocx = "";
		String shopBomRptTempPath = "";
		FileOutputStream fos = null;
		boolean showPartRevision = showPartRev;
		boolean showDocRevision = showDocRev;
		try {
			List<PLMBoilerShopBomReportData> shopBomBoilerReportHeaderList = plmBoilerShippingBomReportService
					.getShopBomHeaderSectionDataList(contractNm,allOpenContract,selProjectNm,allOpenProjectNm,
							selTopLvlNm,allOpenTopLvl,selParentAssyNm,allOpenParentAssy, showPartRevision, showDocRevision);
			List<PLMBoilerShipBomReportData> headerList = plmBoilerShippingBomReportService.getHeaderData(
					contractNm,selProjectNm,allOpenProjectNm,selTopLvlNm,allOpenParentAssy,selParentAssyNm);
			List<PLMBoilerShopBomReportData> shopBomBoilerReportMatlList =new ArrayList<PLMBoilerShopBomReportData>();
			if(!PLMUtils.isEmptyList(shopBomBoilerReportHeaderList)){
				final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
				Date uniqDate = new Date();
				String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
				String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
				filePathDocx = fileDir + resourceBundle.getString("SHOP_BOM_REPORT_NAME") + "_" + uniqTime + ".docx";
				tempPathDocx = fileDir + resourceBundle.getString("SHOP_BOM_REPORT_TEMPLATE_NAME");
				shopBomRptTempPath = fileDir + resourceBundle.getString("SHOP_BOM_REPORT_TEMPLATE");
				StringBuffer mailBody = new StringBuffer().append(toAddressee);
				mailBody.append(PLMConstants.SHOP_BOM_RPT_MAIL_CONTENT)
				.append("Contract Name: "+contractNm);
				 if(!PLMUtils.isEmptyList(selProjectNm)){
					mailBody.append("\n\nSelected Project Names: "+selProjectNm);
				 }
				if(!PLMUtils.isEmpty(selTopLvlNm)){
					mailBody.append("\n\nTask Name: "+selTopLvlNm);
				}
				if(!PLMUtils.isEmptyList(selParentAssyNm)){
					mailBody.append("\n\nParent ASSY No: "+selParentAssyNm);
				}
				mailBody.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				createInputDocument(filePathDocx, tempPathDocx, shopBomRptTempPath, contractNm, selProjectNm, selTopLvlNm,selParentAssyNm);
				 createContractHdrDoc(filePathDocx, tempPathDocx, headerList,selParentAssyNm,partAssblyNumListLcl);
				 createShopBomDoc(filePathDocx, tempPathDocx, shopBomBoilerReportHeaderList, showPartRevision, showDocRevision);
				 List<String> matlCodeList = new ArrayList<String>();
				 for(PLMBoilerShopBomReportData data:shopBomBoilerReportHeaderList){
					 if(!PLMUtils.isEmpty(data.getMatlCodeId())){
						 String temp = data.getMatlCodeId();
						 if (!matlCodeList.contains(temp)) {
							 matlCodeList.add(data.getMatlCodeId());
						 }
					 }
				 }
				if(!PLMUtils.isEmptyList(matlCodeList)){
				 shopBomBoilerReportMatlList  = plmBoilerShippingBomReportService.getShopBomMaterialSectionDataList(matlCodeList);
				}
				 if(!PLMUtils.isEmptyList(shopBomBoilerReportMatlList)){
						createShopBomMaterialListDoc(filePathDocx, tempPathDocx, shopBomBoilerReportMatlList);
					}
				 PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathDocx);
				 LOG.info("Report Attachment Mail sent successfully.");
				
			}else{
				StringBuffer mailNoDataBody = new StringBuffer().append(toAddressee);
				mailNoDataBody.append(PLMConstants.SHOP_BOM_RPT_MAIL_CONTENT_NO_RECORD)
				.append("Contract Name: "+contractNm);
				 if(!PLMUtils.isEmptyList(selProjectNm)){
					 mailNoDataBody.append("\n\nSelected Project Names: "+selProjectNm);
				 }
				if(!PLMUtils.isEmpty(selTopLvlNm)){
					mailNoDataBody.append("\n\nTask Name: "+selTopLvlNm);
				}
				if(!PLMUtils.isEmptyList(selParentAssyNm)){
					mailNoDataBody.append("\n\nParent ASSY No: "+selParentAssyNm);
				}
				mailNoDataBody.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
				LOG.info("Mail sent successfully,But no Doc exists");
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendShopBomRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendShopBomRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} finally {
			try {
				if (fos!=null){
					fos.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			deleteFiles(filePathDocx);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendShopBomRptMail Method");
	}
	
	/**
	 * This method is used to createInputDocument
	 * 
	 * @param FileOutputStream
	 * @param filepathDocx
	 * @param templatePath
	 * @param cntrtSmryTempPath
	 */
	public void createInputDocument(String filePathDocx, String templatePath, String shopBomRptTempPath, String contractNum
			,List<String>selProjectName,String selTopLvlName,List<String> selParentAssyNm) throws Exception {
		LOG.info("Creating New document document -------> " + filePathDocx);
		LOG.info("templatePath------------->" + templatePath);
		//String contractNumInSaverpt = contractNum;
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFDocument doc = new XWPFDocument(new FileInputStream(new File(shopBomRptTempPath)));
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3

		XWPFParagraph titlePara = doc.createParagraph();
		titlePara.setStyle("Heading1"); // 4
		titlePara.setAlignment(ParagraphAlignment.CENTER);
		XWPFRun title = titlePara.createRun();
		title.setColor("000000");
		title.setText("SHOP BILL OF MATERIAL");
		//title.addBreak();

		/*XWPFParagraph titleParaHead2 = doc.createParagraph();
		titleParaHead2.setStyle("Normal"); // 4
		titleParaHead2.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun titleHead2 = titleParaHead2.createRun();
		titleHead2.setColor("000000");
		titleHead2.addBreak();
		titleHead2.setText("Input Filters");
		titleHead2.setBold(true);
		titleHead2.setUnderline(UnderlinePatterns.SINGLE);
		titleHead2.setFontSize(10);
		titleHead2.addBreak();
		
		XWPFParagraph tmpParagraph1 = doc.createParagraph();
		tmpParagraph1.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun boldRun = tmpParagraph1.createRun();
		boldRun.setBold(true);
		boldRun.setFontSize(10);
		XWPFRun unboldRun = tmpParagraph1.createRun();
		unboldRun.setFontSize(10);
		
		XWPFParagraph tmpParagraph2 = doc.createParagraph();
		tmpParagraph2.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun boldRun1 = tmpParagraph2.createRun();
		boldRun1.setBold(true);
		boldRun1.setFontSize(10);
		XWPFRun unboldRun1 = tmpParagraph2.createRun();
		unboldRun1.setFontSize(10);
		
		XWPFParagraph tmpParagraph3 = doc.createParagraph();
		tmpParagraph3.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun boldRun2 = tmpParagraph3.createRun();
		boldRun2.setBold(true);
		boldRun2.setFontSize(10);
		XWPFRun unboldRun2 = tmpParagraph3.createRun();
		unboldRun2.setFontSize(10);

		XWPFParagraph tmpParagraph4 = doc.createParagraph();
		tmpParagraph4.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun boldRun3 = tmpParagraph4.createRun();
		boldRun3.setBold(true);
		boldRun3.setFontSize(10);
		XWPFRun unboldRun3 = tmpParagraph4.createRun();
		unboldRun3.setFontSize(10);
		
		boldRun.setText("Contract Name: ");
		unboldRun.setText(contractNumInSaverpt);
		if (null != selProjectName && selProjectName.size() > 0) {
			boldRun1.setText("Selected Project Names: ");
			StringBuffer projectNms = new StringBuffer();
			for(String prjNm:selProjectName){
				projectNms.append(prjNm);
				projectNms.append(",");
			}
			unboldRun1.setText(projectNms.substring(0, projectNms.length()-1));
		} 
		boldRun2.setText("Task Name: ");
		unboldRun2.setText(selTopLvlName);
		
		boldRun3.setText("Parent ASSY No: ");
		unboldRun3.setText(selParentAssyNm);*/
		
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}

	}
	
	/**
	 * This method is used to createContractHdrDoc
	 * 
	 * @param FileOutputStream
	 * @param filepathDocx
	 * @param List
	 *            <PLMBoilerShipBomReportData>
	 * @param templatepath
	 */
	public void createContractHdrDoc(String filePathDocx, String tempPathDocx, List<PLMBoilerShipBomReportData>shopBomDataList,
			List<String> parentAsmbyNmLcl,List<SelectItem>  selPartAssmbly) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);

		List<PLMBoilerShipBomReportData> shopBomDataListLcl = new ArrayList<PLMBoilerShipBomReportData>();
		for (PLMBoilerShipBomReportData data : shopBomDataList) {
			shopBomDataListLcl.add(data);
		}

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(tempPathDocx))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3
		
		/*XWPFParagraph titlePara = doc.createParagraph();
		titlePara.setStyle("Normal"); // 4
		titlePara.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun title = titlePara.createRun();
		title.setColor("000000");
		title.addBreak();
		title.setText("Header Section");
		title.setBold(true);
		title.setUnderline(UnderlinePatterns.SINGLE);
		title.setFontSize(10);
		title.addBreak();*/
		
		//create table
	      XWPFTable table = doc.createTable();
	      
	      CTTblWidth width = table.getCTTbl().addNewTblPr().addNewTblW();
	      width.setType(STTblWidth.DXA);
	      width.setW(BigInteger.valueOf(15000));
	      
	      CTTblPr tblpro = table.getCTTbl().getTblPr();
	      CTJc jc = (tblpro.isSetJc() ? tblpro.getJc() : tblpro.addNewJc());
		  jc.setVal(STJc.CENTER);
		   
	      CTTblBorders borders = tblpro.addNewTblBorders();
	      borders.addNewBottom().setVal(STBorder.NONE); 
	      borders.addNewLeft().setVal(STBorder.NONE);
	      borders.addNewRight().setVal(STBorder.NONE);
	      borders.addNewTop().setVal(STBorder.NONE);
	      //also inner borders
	      borders.addNewInsideH().setVal(STBorder.NONE);
	      borders.addNewInsideV().setVal(STBorder.NONE);
	      XWPFTableCell cell = null;
	      
	    //create first row
	      XWPFTableRow tableRowOne = table.getRow(0);
          XWPFParagraph paragraph1 = tableRowOne.getCell(0).addParagraph();
          cell =  tableRowOne.getCell(0);
          XWPFRun boldRun1 = paragraph1.createRun();
          boldRun1.setBold(true);
          setRun(boldRun1 , "Geinspira" , 10, "Customer: ", false);
          XWPFRun unBoldRun1 = paragraph1.createRun();
          setRun(unBoldRun1 , "Geinspira" , 10, shopBomDataListLcl.get(0).getCustomer(), false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          XWPFParagraph paragraph11 = tableRowOne.addNewTableCell().addParagraph();
          cell =  tableRowOne.getCell(1);
          XWPFRun boldRun11 = paragraph11.createRun();
          boldRun11.setBold(true);
          setRun(boldRun11 , "Geinspira" , 10, "Contract: ", false);
          XWPFRun unBoldRun11 = paragraph11.createRun();
          setRun(unBoldRun11 , "Geinspira" , 10, shopBomDataListLcl.get(0).getCntName(), false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          //create second row
          XWPFTableRow tableRowTwo = table.getRow(0);
          XWPFParagraph paragraph2 = tableRowTwo.getCell(0).addParagraph();
          cell =  tableRowOne.getCell(0);
          XWPFRun boldRun2 = paragraph2.createRun();
          boldRun2.setBold(true);
          setRun(boldRun2 , "Geinspira" , 10, "Station: ", false);
          XWPFRun unBoldRun2 = paragraph2.createRun();
          setRun(unBoldRun2 , "Geinspira" , 10, shopBomDataListLcl.get(0).getStation() , false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          XWPFParagraph paragraph22 = tableRowTwo.getCell(1).addParagraph();
          cell =  tableRowOne.getCell(1);
          XWPFRun boldRun22 = paragraph22.createRun();
          boldRun22.setBold(true);
          setRun(boldRun22 , "Geinspira" , 10, "Project: ", false);
          XWPFRun unBoldRun22 = paragraph22.createRun();
          setRun(unBoldRun22 , "Geinspira" , 10, shopBomDataListLcl.get(0).getProjectName(), false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          //create third row
          XWPFTableRow tableRowThree = table.getRow(0);
          XWPFParagraph paragraph3 = tableRowThree.getCell(0).addParagraph();
          cell =  tableRowOne.getCell(0);
          XWPFRun boldRun3 = paragraph3.createRun();
          boldRun3.setBold(true);
          setRun(boldRun3 , "Geinspira" , 10, "Unit No: ", false);
          XWPFRun unBoldRun3 = paragraph3.createRun();
          setRun(unBoldRun3 , "Geinspira" , 10, shopBomDataListLcl.get(0).getUnitNo() , false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          XWPFParagraph paragraph33 = tableRowThree.getCell(1).addParagraph();
          cell =  tableRowOne.getCell(1);
          XWPFRun boldRun33 = paragraph33.createRun();
          boldRun33.setBold(true);
          setRun(boldRun33 , "Geinspira" , 10, "WBS No: ", false);
          XWPFRun unBoldRun33 = paragraph33.createRun();
          setRun(unBoldRun33 , "Geinspira" , 10, shopBomDataListLcl.get(0).getWbsNo(), false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
         
          //create fourth row
          XWPFTableRow tableRowFour = table.getRow(0);
          XWPFParagraph paragraph4 = tableRowFour.getCell(0).addParagraph();
          cell =  tableRowOne.getCell(0);
          XWPFRun boldRun4 = paragraph4.createRun();
          boldRun4.setBold(true);
          setRun(boldRun4 , "Geinspira" , 10, "Station Location: ", false);
          XWPFRun unBoldRun4 = paragraph4.createRun();
          setRun(unBoldRun4 , "Geinspira" , 10, shopBomDataListLcl.get(0).getStationLocation(), false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          XWPFParagraph paragraph44 = tableRowFour.getCell(1).addParagraph();
          cell =  tableRowOne.getCell(1);
          XWPFRun boldRun44 = paragraph44.createRun();
          boldRun44.setBold(true);
          setRun(boldRun44 , "Geinspira" , 10,  "WBS (Task) Description: ", false);
          XWPFRun unBoldRun44 = paragraph44.createRun();
          setRun(unBoldRun44 , "Geinspira" , 10, shopBomDataListLcl.get(0).getProductDesc(), false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          //create fifth row
          /*XWPFTableRow tableRowFive = table.getRow(0);
          cell =  tableRowOne.getCell(0);
          XWPFParagraph paragraph5 = tableRowFive.getCell(0).addParagraph();
          XWPFRun boldRun5 = paragraph5.createRun();
          boldRun5.setBold(true);          
          setRun(boldRun5 , "Geinspira" , 10, "Station Location: ", false);
          XWPFRun unBoldRun5 = paragraph5.createRun();
          setRun(unBoldRun5 , "Geinspira" , 10, shopBomDataListLcl.get(0).getStationLocation() , false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          String parentAsmbyDesc="";
	      for(SelectItem item:selPartAssmbly){
	    	  if(item.getValue().equals(parentAsmbyNmLcl)){
	    		  parentAsmbyDesc =item.getLabel();
	    		  break;
	    	  }
	      }
	      
          XWPFParagraph paragraph55 = tableRowFive.getCell(1).addParagraph();
          cell =  tableRowOne.getCell(1);
          XWPFRun boldRun55 = paragraph55.createRun();
          boldRun55.setBold(true);
          setRun(boldRun55 , "Geinspira" , 10,  "Parent Assy No: ", false);
          XWPFRun unBoldRun55 = paragraph55.createRun();
          setRun(unBoldRun55 , "Geinspira" , 10, parentAsmbyDesc, false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          XWPFParagraph paragraph55 = tableRowOne.getCell(0).addParagraph();
          cell =  tableRowOne.getCell(0);
          XWPFRun tmpRun55 = paragraph55.createRun();
          setRun(tmpRun55 , "Geinspira" , 10, "" , false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));*/
          
		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}
	private static void setRun (XWPFRun run , String fontFamily , int fontSize , String text , boolean addBreak) {
        run.setFontFamily(fontFamily);
        run.setFontSize(fontSize);
        run.setText(text);
        if (addBreak) run.addBreak();
    }
	/**
	 * This method is used to createCustomerBomDoc
	 * 
	 * @param FileOutputStream
	 * @param filepathDocx
	 * @param List
	 *            <PLMBoilerShipBomReportData>
	 * @param templatepath
	 */
	public void createShopBomDoc(String filePathDocx, String tempPathDocx, List<PLMBoilerShopBomReportData>shopBomDataList,
			boolean showPartRevision, boolean showDocRevision) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);

		List<PLMBoilerShopBomReportData> shopBomDataListLcl = new ArrayList<PLMBoilerShopBomReportData>();
		for (PLMBoilerShopBomReportData data : shopBomDataList) {
			shopBomDataListLcl.add(data);
		}

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(tempPathDocx))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3
		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setStyle("Normal"); // 4
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		/*XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.addBreak();
		tmpRun.setColor("000000");
		tmpRun.setText("Report Output");
		tmpRun.setUnderline(UnderlinePatterns.SINGLE);
		tmpRun.setBold(true);
		tmpRun.setFontSize(10);
		tmpRun.addBreak();*/
		
		int nRows = shopBomDataListLcl.size() + 1;
		int nCols = 10;
		int index = 0;
		
		if (showPartRevision && showDocRevision) {
			nCols = 11;
		} else if (showPartRevision && !showDocRevision) {
			nCols = 10;
		} else if (!showPartRevision && showDocRevision) {
			nCols = 10;
		} else if (!showPartRevision && !showDocRevision) {
			nCols = 9;
		}
		
		XWPFTable table = doc.createTable(nRows, nCols);
		//table.setWidth(11);
		table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(15000));
		// Set the table style. If the style is not defined, the table style
		// will become "Normal".
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTJc jc = (tblPr.isSetJc() ? tblPr.getJc() : tblPr.addNewJc());
	    jc.setVal(STJc.CENTER);
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("StyledTable");

		// Get a list of the rows in the table
		List<XWPFTableRow> rows = table.getRows();
		int rowCt = 0;
		int colCt = 0;
		for (XWPFTableRow row : rows) {
			// get table row properties (trPr)
			CTTrPr trPr = row.getCtRow().addNewTrPr();
			// set row height; units = twentieth of a point, 360 = 0.25"
			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(10));

			// get the cells in this row
			List<XWPFTableCell> cells = row.getTableCells();
			// add content to each cell
			for (XWPFTableCell cell : cells) {
				// get a table cell properties element (tcPr)
				CTTcPr tcpr = cell.getCTTc().addNewTcPr();
				// set vertical alignment to "center"
				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				// create cell color element
				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {
					// header row
					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {
					// odd row
					ctshd.setFill("EDF2F8");
				}

				// get 1st paragraph in cell's paragraph list
				XWPFParagraph para = cell.getParagraphs().get(0);
				// create a run to contain the content
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");
				// style cell as desired
				/*
				 * if (colCt == nCols - 1) { // last column is 10pt Courier //
				 * rh.setFontSize(10); // rh.setFontFamily("Courier"); }
				 */
				if (rowCt == 0) {
					
					if (showPartRevision && showDocRevision) {
						if (colCt == 0) {
							// header row
							rh.setText("ITEM NO");
						} else if (colCt == 1) {
							rh.setText("PART NO");
						}else if (colCt == 2) {
							rh.setText("REV");
						}else if (colCt == 3) {
							rh.setText("QUANTITY REQUIRED");
						}else if (colCt == 4) {
							rh.setText("U/M");
						}else if (colCt == 5) {
							rh.setText("MATL CODE");
						}else if (colCt == 6) {
							rh.setText("DESCRIPTION");
						}else if (colCt == 7) {
							rh.setText("DRAWING NO");
						}else if (colCt == 8) {
							rh.setText("DRAWING REV");
						}else if (colCt == 9) {
							rh.setText("WEIGHT");
						}else if (colCt == 10) {
							rh.setText("REMARK");
						}
					} else if (showPartRevision && !showDocRevision) {
						if (colCt == 0) {
							// header row
							rh.setText("ITEM NO");
						} else if (colCt == 1) {
							rh.setText("PART NO");
						}else if (colCt == 2) {
							rh.setText("REV");
						}else if (colCt == 3) {
							rh.setText("QUANTITY REQUIRED");
						}else if (colCt == 4) {
							rh.setText("U/M");
						}else if (colCt == 5) {
							rh.setText("MATL CODE");
						}else if (colCt == 6) {
							rh.setText("DESCRIPTION");
						}else if (colCt == 7) {
							rh.setText("DRAWING NO");
						}else if (colCt == 8) {
							rh.setText("WEIGHT");
						}else if (colCt == 9) {
							rh.setText("REMARK");
						}
					} else if (!showPartRevision && showDocRevision) {
						if (colCt == 0) {
							// header row
							rh.setText("ITEM NO");
						} else if (colCt == 1) {
							rh.setText("PART NO");
						}else if (colCt == 2) {
							rh.setText("QUANTITY REQUIRED");
						}else if (colCt == 3) {
							rh.setText("U/M");
						}else if (colCt == 4) {
							rh.setText("MATL CODE");
						}else if (colCt == 5) {
							rh.setText("DESCRIPTION");
						}else if (colCt == 6) {
							rh.setText("DRAWING NO");
						}else if (colCt == 7) {
							rh.setText("DRAWING REV");
						}else if (colCt == 8) {
							rh.setText("WEIGHT");
						}else if (colCt == 9) {
							rh.setText("REMARK");
						}
					} else if (!showPartRevision && !showDocRevision) {
						if (colCt == 0) {
							// header row
							rh.setText("ITEM NO");
						} else if (colCt == 1) {
							rh.setText("PART NO");
						}else if (colCt == 2) {
							rh.setText("QUANTITY REQUIRED");
						}else if (colCt == 3) {
							rh.setText("U/M");
						}else if (colCt == 4) {
							rh.setText("MATL CODE");
						}else if (colCt == 5) {
							rh.setText("DESCRIPTION");
						}else if (colCt == 6) {
							rh.setText("DRAWING NO");
						}else if (colCt == 7) {
							rh.setText("WEIGHT");
						}else if (colCt == 8) {
							rh.setText("REMARK");
						}
					}
					rh.setBold(true);
					ht.setVal(BigInteger.valueOf(600));
					row.setHeight(600);
					para.setAlignment(ParagraphAlignment.CENTER);
					para.setWordWrap(true);
				} else if (rowCt % 2 == 0) {

					index = rowCt;
					index = index - 1;
					
					if (showPartRevision && showDocRevision) {
						if (colCt == 0) {
							if(PLMUtils.isEmpty(shopBomDataListLcl.get(index).getItemNumber())){
								rh.setText("");
							}else{
								rh.setText(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",
										shopBomDataListLcl.get(index).getLevel())+shopBomDataListLcl.get(index).getItemNumber());
							}
						}else if (colCt == 1) {
							rh.setText(shopBomDataListLcl.get(index).getPartNumber());
						}else if (colCt == 2) {
							rh.setText(shopBomDataListLcl.get(index).getDrawingRev());
						}else if (colCt == 3) {
							rh.setText(shopBomDataListLcl.get(index).getQuantity());
						}else if (colCt == 4) {
							rh.setText(shopBomDataListLcl.get(index).getUnitOfMeasure());
						}else if (colCt == 5) {
							rh.setText(shopBomDataListLcl.get(index).getMatlCode());
						}else if (colCt == 6) {
							rh.setText(shopBomDataListLcl.get(index).getProductDesc());
						}else if (colCt == 7) {
							rh.setText(shopBomDataListLcl.get(index).getPartDrawingNumber());
						}else if (colCt == 8) {
							rh.setText(shopBomDataListLcl.get(index).getPartDrawingRev());
						}else if (colCt == 9) {
							rh.setText(shopBomDataListLcl.get(index).getWeight());
						}else if (colCt == 10) {
							rh.setText(shopBomDataListLcl.get(index).getRemarks());
						}
					} else if (showPartRevision && !showDocRevision) {
						if (colCt == 0) {
							if(PLMUtils.isEmpty(shopBomDataListLcl.get(index).getItemNumber())){
								rh.setText("");
							}else{
								rh.setText(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",
										shopBomDataListLcl.get(index).getLevel())+shopBomDataListLcl.get(index).getItemNumber());
							}
						}else if (colCt == 1) {
							rh.setText(shopBomDataListLcl.get(index).getPartNumber());
						}else if (colCt == 2) {
							rh.setText(shopBomDataListLcl.get(index).getDrawingRev());
						}else if (colCt == 3) {
							rh.setText(shopBomDataListLcl.get(index).getQuantity());
						}else if (colCt == 4) {
							rh.setText(shopBomDataListLcl.get(index).getUnitOfMeasure());
						}else if (colCt == 5) {
							rh.setText(shopBomDataListLcl.get(index).getMatlCode());
						}else if (colCt == 6) {
							rh.setText(shopBomDataListLcl.get(index).getProductDesc());
						}else if (colCt == 7) {
							rh.setText(shopBomDataListLcl.get(index).getPartDrawingNumber());
						}else if (colCt == 8) {
							rh.setText(shopBomDataListLcl.get(index).getWeight());
						}else if (colCt == 9) {
							rh.setText(shopBomDataListLcl.get(index).getRemarks());
						}
					} else if (!showPartRevision && showDocRevision) {
						if (colCt == 0) {
							if(PLMUtils.isEmpty(shopBomDataListLcl.get(index).getItemNumber())){
								rh.setText("");
							}else{
								rh.setText(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",
										shopBomDataListLcl.get(index).getLevel())+shopBomDataListLcl.get(index).getItemNumber());
							}
						}else if (colCt == 1) {
							rh.setText(shopBomDataListLcl.get(index).getPartNumber());
						}else if (colCt == 2) {
							rh.setText(shopBomDataListLcl.get(index).getQuantity());
						}else if (colCt == 3) {
							rh.setText(shopBomDataListLcl.get(index).getUnitOfMeasure());
						}else if (colCt == 4) {
							rh.setText(shopBomDataListLcl.get(index).getMatlCode());
						}else if (colCt == 5) {
							rh.setText(shopBomDataListLcl.get(index).getProductDesc());
						}else if (colCt == 6) {
							rh.setText(shopBomDataListLcl.get(index).getPartDrawingNumber());
						}else if (colCt == 7) {
							rh.setText(shopBomDataListLcl.get(index).getPartDrawingRev());
						}else if (colCt == 8) {
							rh.setText(shopBomDataListLcl.get(index).getWeight());
						}else if (colCt == 9) {
							rh.setText(shopBomDataListLcl.get(index).getRemarks());
						}
					} else if (!showPartRevision && !showDocRevision) {
						if (colCt == 0) {
							if(PLMUtils.isEmpty(shopBomDataListLcl.get(index).getItemNumber())){
								rh.setText("");
							}else{
								rh.setText(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",
										shopBomDataListLcl.get(index).getLevel())+shopBomDataListLcl.get(index).getItemNumber());
							}
						}else if (colCt == 1) {
							rh.setText(shopBomDataListLcl.get(index).getPartNumber());
						}else if (colCt == 2) {
							rh.setText(shopBomDataListLcl.get(index).getQuantity());
						}else if (colCt == 3) {
							rh.setText(shopBomDataListLcl.get(index).getUnitOfMeasure());
						}else if (colCt == 4) {
							rh.setText(shopBomDataListLcl.get(index).getMatlCode());
						}else if (colCt == 5) {
							rh.setText(shopBomDataListLcl.get(index).getProductDesc());
						}else if (colCt == 6) {
							rh.setText(shopBomDataListLcl.get(index).getPartDrawingNumber());
						}else if (colCt == 7) {
							rh.setText(shopBomDataListLcl.get(index).getWeight());
						}else if (colCt == 8) {
							rh.setText(shopBomDataListLcl.get(index).getRemarks());
						}
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > shopBomDataListLcl.size()) {
					break;
				} else {

					index = rowCt;
					index = index - 1;
					if (showPartRevision && showDocRevision) {
						if (colCt == 0) {
							if(PLMUtils.isEmpty(shopBomDataListLcl.get(index).getItemNumber())){
								rh.setText("");
							}else{
								rh.setText(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",
										shopBomDataListLcl.get(index).getLevel())+shopBomDataListLcl.get(index).getItemNumber());
							}
						}else if (colCt == 1) {
							rh.setText(shopBomDataListLcl.get(index).getPartNumber());
						}else if (colCt == 2) {
							rh.setText(shopBomDataListLcl.get(index).getDrawingRev());
						}else if (colCt == 3) {
							rh.setText(shopBomDataListLcl.get(index).getQuantity());
						}else if (colCt == 4) {
							rh.setText(shopBomDataListLcl.get(index).getUnitOfMeasure());
						}else if (colCt == 5) {
							rh.setText(shopBomDataListLcl.get(index).getMatlCode());
						}else if (colCt == 6) {
							rh.setText(shopBomDataListLcl.get(index).getProductDesc());
						}else if (colCt == 7) {
							rh.setText(shopBomDataListLcl.get(index).getPartDrawingNumber());
						}else if (colCt == 8) {
							rh.setText(shopBomDataListLcl.get(index).getPartDrawingRev());
						}else if (colCt == 9) {
							rh.setText(shopBomDataListLcl.get(index).getWeight());
						}else if (colCt == 10) {
							rh.setText(shopBomDataListLcl.get(index).getRemarks());
						}
					} else if (showPartRevision && !showDocRevision) {
						if (colCt == 0) {
							if(PLMUtils.isEmpty(shopBomDataListLcl.get(index).getItemNumber())){
								rh.setText("");
							}else{
								rh.setText(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",
										shopBomDataListLcl.get(index).getLevel())+shopBomDataListLcl.get(index).getItemNumber());
							}
						}else if (colCt == 1) {
							rh.setText(shopBomDataListLcl.get(index).getPartNumber());
						}else if (colCt == 2) {
							rh.setText(shopBomDataListLcl.get(index).getDrawingRev());
						}else if (colCt == 3) {
							rh.setText(shopBomDataListLcl.get(index).getQuantity());
						}else if (colCt == 4) {
							rh.setText(shopBomDataListLcl.get(index).getUnitOfMeasure());
						}else if (colCt == 5) {
							rh.setText(shopBomDataListLcl.get(index).getMatlCode());
						}else if (colCt == 6) {
							rh.setText(shopBomDataListLcl.get(index).getProductDesc());
						}else if (colCt == 7) {
							rh.setText(shopBomDataListLcl.get(index).getPartDrawingNumber());
						}else if (colCt == 8) {
							rh.setText(shopBomDataListLcl.get(index).getWeight());
						}else if (colCt == 9) {
							rh.setText(shopBomDataListLcl.get(index).getRemarks());
						}
					} else if (!showPartRevision && showDocRevision) {
						if (colCt == 0) {
							if(PLMUtils.isEmpty(shopBomDataListLcl.get(index).getItemNumber())){
								rh.setText("");
							}else{
								rh.setText(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",
										shopBomDataListLcl.get(index).getLevel())+shopBomDataListLcl.get(index).getItemNumber());
							}
						}else if (colCt == 1) {
							rh.setText(shopBomDataListLcl.get(index).getPartNumber());
						}else if (colCt == 2) {
							rh.setText(shopBomDataListLcl.get(index).getQuantity());
						}else if (colCt == 3) {
							rh.setText(shopBomDataListLcl.get(index).getUnitOfMeasure());
						}else if (colCt == 4) {
							rh.setText(shopBomDataListLcl.get(index).getMatlCode());
						}else if (colCt == 5) {
							rh.setText(shopBomDataListLcl.get(index).getProductDesc());
						}else if (colCt == 6) {
							rh.setText(shopBomDataListLcl.get(index).getPartDrawingNumber());
						}else if (colCt == 7) {
							rh.setText(shopBomDataListLcl.get(index).getPartDrawingRev());
						}else if (colCt == 8) {
							rh.setText(shopBomDataListLcl.get(index).getWeight());
						}else if (colCt == 9) {
							rh.setText(shopBomDataListLcl.get(index).getRemarks());
						}
					} else if (!showPartRevision && !showDocRevision) {
						if (colCt == 0) {
							if(PLMUtils.isEmpty(shopBomDataListLcl.get(index).getItemNumber())){
								rh.setText("");
							}else{
								rh.setText(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",
										shopBomDataListLcl.get(index).getLevel())+shopBomDataListLcl.get(index).getItemNumber());
							}
						}else if (colCt == 1) {
							rh.setText(shopBomDataListLcl.get(index).getPartNumber());
						}else if (colCt == 2) {
							rh.setText(shopBomDataListLcl.get(index).getQuantity());
						}else if (colCt == 3) {
							rh.setText(shopBomDataListLcl.get(index).getUnitOfMeasure());
						}else if (colCt == 4) {
							rh.setText(shopBomDataListLcl.get(index).getMatlCode());
						}else if (colCt == 5) {
							rh.setText(shopBomDataListLcl.get(index).getProductDesc());
						}else if (colCt == 6) {
							rh.setText(shopBomDataListLcl.get(index).getPartDrawingNumber());
						}else if (colCt == 7) {
							rh.setText(shopBomDataListLcl.get(index).getWeight());
						}else if (colCt == 8) {
							rh.setText(shopBomDataListLcl.get(index).getRemarks());
						}
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell

			colCt = 0;
			rowCt++;
		} // for row

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}
	
	/**
	 * This method is used to create Material code list
	 * 
	 * @param FileOutputStream
	 * @param filepathDocx
	 * @param List
	 *            <PLMBoilerShipBomReportData>
	 * @param templatepath
	 */
	public void createShopBomMaterialListDoc(String filePathDocx, String tempPathDocx, List<PLMBoilerShopBomReportData>shopBomDataList) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);

		List<PLMBoilerShopBomReportData> shopBomDataListLcl = new ArrayList<PLMBoilerShopBomReportData>();
		for (PLMBoilerShopBomReportData data : shopBomDataList) {
			shopBomDataListLcl.add(data);
		}

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(tempPathDocx))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3
		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setStyle("Normal"); // 4
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.addBreak();
		tmpRun.setColor("000000");
		tmpRun.setText("Material List");
		tmpRun.setUnderline(UnderlinePatterns.SINGLE);
		tmpRun.setBold(true);
		tmpRun.setFontSize(10);
		tmpRun.addBreak();
		
		int nRows = shopBomDataListLcl.size() + 1;
		int nCols = 8;
		int index = 0;
		XWPFTable table = doc.createTable(nRows, nCols);
		table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(15000));
		// Set the table style. If the style is not defined, the table style
		// will become "Normal".
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTJc jc = (tblPr.isSetJc() ? tblPr.getJc() : tblPr.addNewJc());
		jc.setVal(STJc.CENTER);
		  
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("StyledTable");

		// Get a list of the rows in the table
		List<XWPFTableRow> rows = table.getRows();
		int rowCt = 0;
		int colCt = 0;
		for (XWPFTableRow row : rows) {
			// get table row properties (trPr)
			CTTrPr trPr = row.getCtRow().addNewTrPr();
			// set row height; units = twentieth of a point, 360 = 0.25"
			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(13));
			// get the cells in this row
			List<XWPFTableCell> cells = row.getTableCells();
			// add content to each cell
			for (XWPFTableCell cell : cells) {
				// get a table cell properties element (tcPr)
				CTTcPr tcpr = cell.getCTTc().addNewTcPr();
				// set vertical alignment to "center"
				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				// create cell color element
				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {
					// header row
					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {
					// odd row
					ctshd.setFill("EDF2F8");
				}

				// get 1st paragraph in cell's paragraph list
				XWPFParagraph para = cell.getParagraphs().get(0);
				// create a run to contain the content
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");
				// style cell as desired
				/*
				 * if (colCt == nCols - 1) { // last column is 10pt Courier //
				 * rh.setFontSize(10); // rh.setFontFamily("Courier"); }
				 */
				if (rowCt == 0) {
					if (colCt == 0) {
						// header row
						rh.setText("ITEM");
					} else if (colCt == 1) {
						rh.setText("UNS NO");
					}else if (colCt == 2) {
						rh.setText("COMPOSITION");
					}else if (colCt == 3) {
						rh.setText("SPEC");
					}else if (colCt == 4) {
						rh.setText("GRADE");
					}else if (colCt == 5) {
						rh.setText("PURCH INST");
					}else if (colCt == 6) {
						rh.setText("MATLNOTES SUB");
					}else if (colCt == 7) {
						rh.setText("USAGE REMARKS");
					}
					ht.setVal(BigInteger.valueOf(600));
					row.setHeight(600);
					rh.setBold(true);
					para.setAlignment(ParagraphAlignment.CENTER);
				} else if (rowCt % 2 == 0) {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(shopBomDataListLcl.get(index).getItem());
					}else if (colCt == 1) {
						rh.setText(shopBomDataListLcl.get(index).getUnsNo());
					}else if (colCt == 2) {
						rh.setText(shopBomDataListLcl.get(index).getComposition());
					}else if (colCt == 3) {
						rh.setText(shopBomDataListLcl.get(index).getSpec());
					}else if (colCt == 4) {
						rh.setText(shopBomDataListLcl.get(index).getGrade());
					}else if (colCt == 5) {
						rh.setText(shopBomDataListLcl.get(index).getPurchInst());
					}else if (colCt == 6) {
						rh.setText(shopBomDataListLcl.get(index).getMatlNotesSub());
					}else if (colCt == 7) {
						rh.setText(shopBomDataListLcl.get(index).getUsageRemarks());
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > shopBomDataListLcl.size()) {
					break;
				} else {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(shopBomDataListLcl.get(index).getItem());
					}else if (colCt == 1) {
						rh.setText(shopBomDataListLcl.get(index).getUnsNo());
					}else if (colCt == 2) {
						rh.setText(shopBomDataListLcl.get(index).getComposition());
					}else if (colCt == 3) {
						rh.setText(shopBomDataListLcl.get(index).getSpec());
					}else if (colCt == 4) {
						rh.setText(shopBomDataListLcl.get(index).getGrade());
					}else if (colCt == 5) {
						rh.setText(shopBomDataListLcl.get(index).getPurchInst());
					}else if (colCt == 6) {
						rh.setText(shopBomDataListLcl.get(index).getMatlNotesSub());
					}else if (colCt == 7) {
						rh.setText(shopBomDataListLcl.get(index).getUsageRemarks());
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell

			colCt = 0;
			rowCt++;
		} // for row

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}
	
	/**
	 * This method is used for Deleting docx file
	 * 
	 * @param String
	 */
	public void deleteFiles(String docx) {
		LOG.info("Entering deleteFiles method");
		boolean docxFileExist;
		File docxFile = new File(docx);
		docxFileExist = docxFile.exists();
		if (docxFileExist) {
			boolean deleted = docxFile.delete();
			LOG.info("Successfully deleted docx file : " + deleted);
		}
		LOG.info("Exiting deleteFiles Method");
	}
	/**
	 * reset
	 */
	public void resetShopBomAppReport(){
		alertMessage = "";
		allOpenPrjName=false;
		allOpenContractName=false;
		allOpenTopLvlPart=false;
		allOpenParentAssyNumber=false;
		contractNameList=new ArrayList<SelectItem>();
		projectList=new ArrayList<SelectItem>();;
		topLvlPartList=new ArrayList<SelectItem>();
		parentAssyNoList=new ArrayList<SelectItem>();
		pwiReportvo.setSelectedPrjName("");
		pwiReportvo.setSelectedCntractName("");
		pwiReportvo.setSelectedTopLvlPartName("");
	    pwiReportvo.setSelectedparentAssyNo("");
		selShipBomParentAssyNo = new ArrayList<String>();
		selShipBomCntractName = new String();
		selShipBomProjectName = new ArrayList<String>();
		selShipBomTopLvlPartName = new String();
		pwiReportvo.setContractSelctd(false);
		pwiReportvo.setProjectSelctd(false);
		pwiReportvo.setTaskSelectd(false);
		showPartRev = true;
		showDocRev = true;
	}

	/**
	 * @return
	 */
	public boolean isShowPartRev() {
		return showPartRev;
	}

	/**
	 * @param showPartRev
	 */
	public void setShowPartRev(boolean showPartRev) {
		this.showPartRev = showPartRev;
	}

	/**
	 * @return
	 */
	public boolean isShowDocRev() {
		return showDocRev;
	}

	/**
	 * @param showDocRev
	 */
	public void setShowDocRev(boolean showDocRev) {
		this.showDocRev = showDocRev;
	}
	
	
	
}
