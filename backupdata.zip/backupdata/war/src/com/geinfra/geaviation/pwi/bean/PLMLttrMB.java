/**
 * Copyright (C) 2012 GE Infra. 
 * All rights reserved 
 * @FileName PLMLttrMB.java
 * @Creation date: 27-Mar-2012
 * @version 2.0.1
 * @author : Tech Mahindra (PLMR Team) 
 */

package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormat;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMLttrData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMLttrServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

/**
 * PLMLttrMB is the managed bean class .
 */

public class PLMLttrMB {
	/**
	 * Holds the LOG
	 */
	private static Logger LOG = Logger.getLogger(PLMLttrMB.class);
	/**
	 * Holds the lttrData
	 */
	private PLMLttrData lttrData = null;
	/**
	 * Holds the PLMLttrServiceIfc
	 */
	private PLMLttrServiceIfc plmLttrService  = null;
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	
	/*private PLMLoginData userDataObj = (PLMLoginData) PLMUtils
	.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA);*/
	
	private PLMPwiUserData userDetails = null;

	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendLttrReportThroughMail();
		}
	}
	
	/**
	 * This method is used for Loading LTTR Page
	 * 
	 * @return String
	 */
	public String loadLttrPage() throws PLMCommonException {
		LOG.info("Entering loadLttrPage Method");
		
		commonMB.insertCannedRptRecordHitInfo("LTTR Report");
		
		try {	
			lttrData = new PLMLttrData();
			resetData();
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@loadLttrPage:", exception);
		}
		LOG.info("Exiting loadLttrPage Method");
		return "lttrSearch";
	}

	/**
	 * This method is used for Generating LTTR Report
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String getLttrReport() throws PWiException {
		LOG.info("Entering getLttrReport Method");
		String fwdflag = "lttrSearch";
		String alertMsg = validateLttrInput();
		
		userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		
		if (PLMUtils.isEmpty(alertMsg)) {
			try {
				int mlCount =  plmLttrService.checkForValidMlNo(lttrData.getMlNumLttr());
				if(mlCount == 0) {
					alertMessage = alertMessage + PLMConstants.LTTR_INVALID_ML_NO_ALERT_MSG;
				} else {
					alertMessage = alertMessage + PLMConstants.LTTR_MAIL_ALERT_MSG;
					taskExecutor.execute(new MailThread());
				}
			 } catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getLttrReport: ", exception);
				fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"lttrSearch","LTTR Report");
			}
		}
		LOG.info("Exiting getLttrReport Method");
		return fwdflag;
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return String
	 */
	public void sendLttrReportThroughMail() {
		LOG.info("Entering sendLttrReportThroughMail Method");
		String mlNo = lttrData.getMlNumLttr().toUpperCase(Locale.US);
		String from = PLMConstants.LTTR_MAIL_FROM;

		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		//String signature = PLMConstants.LTTR_MAIL_SIGNATURE;
		String subject = PLMConstants.LTTR_MAIL_SUBJECT + mlNo;
		StringBuffer mailBody = new StringBuffer().append(toAddressee)
		.append(PLMConstants.LTTR_MAIL_CONTENT)
		.append(mlNo)
		.append(".")
		.append(PLMConstants.LTTR_MAIL_SIGNATURE)
		.append(PLMConstants.LTTR_MAIL_FOOTER);
		
		//String mailContent = toAddressee + PLMConstants.LTTR_MAIL_CONTENT + mlNo + "." + PLMConstants.LTTR_MAIL_SIGNATURE;
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("LTTR_REPORT_NAME") +  mlNo + "_" + uniqTime + ".xls";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("LTTR_REPORT_NAME") +  mlNo + "_" + uniqTime + ".zip";
		try {
			List<PLMLttrData> lttrResultList = plmLttrService.getLttrReport(mlNo);
			saveLttrXLSFile(mlNo,lttrResultList,fileDir,filePathXls);
			PLMUtils.generateZipFile(filePathXls,filePathZip);
			PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendLttrReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendLttrReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
		} finally {
			deleteFiles(filePathXls,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendLttrReportThroughMail Method");
	}
	
	/**
	 * This method is used for Deleting zip file and xls file
	 * 
	 * @return void
	 */
	public void deleteFiles(String filePathXls,String filePathZip){
		LOG.info("Entering deleteFiles method");
		boolean zipFileExist;
		boolean xlsFileExist;
		File zipFile = new File(filePathZip);
		zipFileExist = zipFile.exists();
		File xlsFile = new File(filePathXls);
		xlsFileExist = xlsFile.exists();
		if(zipFileExist){
			boolean deleted = zipFile.delete();
			LOG.info("Successfully deleted zip file : " + deleted);
		}
		if(xlsFileExist){
			boolean deleted = xlsFile.delete();
			LOG.info("Successfully deleted xls file : " + deleted);
		}
		LOG.info("Exiting deleteFiles Method");
	}
	
	/**
	 * This method is used for generating zip file
	 * 
	 * @return void
	 */
	/*public void generateZipFile(String filePathXls,String filePathZip) throws IOException {
		LOG.info("Entering generateZipFile method");
		FileOutputStream fileOut = null;
		BufferedOutputStream bufferOut = null;
		ZipOutputStream zipOut = null;
		BufferedInputStream bufferIn = null;
		FileInputStream fileIn = null;
		File xlsFile = new File(filePathXls); 
		try {
			fileOut = new FileOutputStream(filePathZip);
			bufferOut = new BufferedOutputStream(fileOut);
			zipOut = new ZipOutputStream(bufferOut);
			fileIn = new FileInputStream(filePathXls);
			bufferIn = new BufferedInputStream(fileIn);
			int count;
			byte[] data = new byte[1000];
			zipOut.putNextEntry(new ZipEntry(xlsFile.getName()));
			while((count = fileIn.read(data,0,1000)) != -1){  
			zipOut.write(data, 0, count);
			}
			bufferIn.close();
			zipOut.flush();
			zipOut.close();
   		   }catch (FileNotFoundException e) {
			 LOG.log(Level.ERROR, "Exception@generateZipFile: ", e);
			 throw e;
		   }catch (IOException e) {
			 LOG.log(Level.ERROR, "Exception@generateZipFile: ", e);
			 throw e;
		   }finally {
				try {
					if (bufferOut != null) {
						bufferOut.close();
					}
					if (zipOut != null) {
						zipOut.close();
					}
					if (fileOut != null) {
						fileOut.close();
					}
					if (fileIn != null) {
						fileIn.close();
					}
					if (bufferIn != null) {
						bufferIn.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@generateZipFile: ", e);
					throw e;
				}
			}
		LOG.info("Exiting generateZipFile Method");
	}*/
	
	/**
	 * This method is used for Bordering Cell in XLS
	 * 
	 * @return StringBuffer
	 */
	
	private HSSFCellStyle setBorderStyle(HSSFCellStyle style) {
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		return style;
	}
	
	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return StringBuffer
	 */
	
	public void saveLttrXLSFile(String mlNo,List<PLMLttrData> lttrResultList,String fileDir,String filePathXls) throws IOException {
		LOG.info("Entering saveLttrXLSFile Method");
		//SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist = fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXls);
				HSSFWorkbook workbook = new HSSFWorkbook();
				HSSFSheet sheet =  workbook.createSheet(mlNo);
				HSSFCellStyle headerStyle = workbook.createCellStyle();
				
				headerStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
				headerStyle.setFillForegroundColor(HSSFColor.YELLOW.index);
				headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				HSSFFont font = workbook.createFont(); 
				font.setFontName(PLMConstants.EXCEL_FONT_NAME);
				font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headerStyle.setFont(font);
				headerStyle = setBorderStyle(headerStyle);
				
				HSSFCellStyle cellBoldStyle = workbook.createCellStyle();
				cellBoldStyle = setBorderStyle(cellBoldStyle);
				cellBoldStyle.setFont(font);
				
				HSSFFont nonBoldFont = workbook.createFont();
				nonBoldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				HSSFCellStyle contentStyle = workbook.createCellStyle();				
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(nonBoldFont);
				HSSFCellStyle contentDecimalStyle = workbook.createCellStyle();				
				contentDecimalStyle = setBorderStyle(contentDecimalStyle);
				contentDecimalStyle.setFont(nonBoldFont);
				DataFormat format = workbook.createDataFormat();
				contentDecimalStyle.setDataFormat(format.getFormat("0.00000"));
										
				HSSFFont noRecordFont = workbook.createFont(); 
				noRecordFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				noRecordFont.setColor(HSSFColor.RED.index);
				noRecordFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				HSSFCellStyle noRecordCellStyle = workbook.createCellStyle();
				noRecordCellStyle = setBorderStyle(noRecordCellStyle);
				noRecordCellStyle.setFont(noRecordFont);

				CreationHelper createHelper = workbook.getCreationHelper();

				HSSFCellStyle dateStyle = workbook.createCellStyle();
				
				dateStyle.setDataFormat(
			        createHelper.createDataFormat().getFormat("mm/dd/yyyy"));
				
				dateStyle = setBorderStyle(contentStyle);		
				dateStyle.setFont(nonBoldFont);
				
				int rowcount = -1;
				
				if(!PLMUtils.isEmptyList(lttrResultList)) {
					
					String[] colNames = {"BOM_LEVEL", "TREE", "PREFIX", "MLI", "PIN","HPIN", "PARENT_PD_NAME", "PD_NAME","PD_NAME_DESC", "SUFFIX","QTY","UNIT_OF_MEASURE","DOCUMENT_NAME","DOC_REV","DOC_DESC","DOC_TYPE","DOC_STATE","EXPORT_CONTROL","DOC_CLASS","LAST_MONTH_CHANGE","LAST_WEEK_CHANGE","DATE_TO_DATE_CHANGE","MODEL_VALIDATED","ROW_KEY"};
					
					HSSFRow row = sheet.createRow(++rowcount);
					HSSFCell cell = row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					cell.setCellValue(PLMConstants.LTTR_SEARCH_CRITERIA_MLNO);
					cell.setCellStyle(cellBoldStyle);

					cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellValue(mlNo);
					cell.setCellStyle(cellBoldStyle);
					
					row = sheet.createRow(++rowcount);
					row = sheet.createRow(++rowcount);
					
					for ( int i = 0 ; i < colNames.length; i++ ) {
						cell = row.createCell(i);
						cell. setCellValue(colNames[i]);
						cell.setCellStyle(headerStyle);
					}
					
					for(int i = 0; i < lttrResultList.size(); i++) {
						PLMLttrData dataObj = (PLMLttrData) lttrResultList.get(i);
							row = sheet.createRow(++rowcount);

							cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getBomLevel());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellStyle(cellBoldStyle);
							cell.setCellValue(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",dataObj.getBomLevel()));
							
							cell = row.createCell(PLMConstants.EXCEL_COL_TWO);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPrefix());
				
							cell = row.createCell(PLMConstants.EXCEL_COL_THREE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getMli());
				
							cell = row.createCell(PLMConstants.EXCEL_COL_FOUR);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPin());
				
							cell = row.createCell(PLMConstants.EXCEL_COL_FIVE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getHpin());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_SIX);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getParentPdName());

							cell = row.createCell(PLMConstants.EXCEL_COL_SEVEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPdName());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_EIGHT);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPdNameDesc());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_NINE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getSuffix());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_TEN);
							cell.setCellStyle(contentDecimalStyle);
							cell.setCellValue(dataObj.getQty());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getUnitMeasure());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_TWELVE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getDocName());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getDocRev());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getDocDesc());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getDocType());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getDocState());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getExportControl());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_EIGHTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getDocClass());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_NINETEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getMonthChange());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_TWENTY);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getWeekChange());
														
							cell = row.createCell(PLMConstants.EXCEL_COL_TWENTYONE);
							cell.setCellStyle(contentStyle);
							if(dataObj.getDateChange() != null){
								cell.setCellValue(dataObj.getDateChange());
							} else {
								cell.setCellValue("");
							}
							
							cell = row.createCell(PLMConstants.EXCEL_COL_TWENTYTWO);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getModelValidated());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_TWENTYTHREE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getRowKey());
							
					}
					
					row = sheet.createRow(++rowcount);
					row = sheet.createRow(++rowcount);
					
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ONE);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWO);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_THREE);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_FOUR);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_FIVE);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_SIX);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_SEVEN);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_EIGHT);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_NINE);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TEN);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ELEVEN);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWELVE);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_THIRTEEN);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_FOURTEEN);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_FIFTEEN);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_SIXTEEN);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_SEVENTEEN);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_EIGHTEEN);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_NINETEEN);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWENTY);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWENTYONE);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWENTYTWO);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWENTYTHREE);
				} else {
					LOG.info("There is no record found for " + mlNo);
					HSSFRow row = sheet.createRow(++rowcount);
					HSSFCell cell = row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					String noRecordMsg = PLMConstants.LTTR_NO_RECORD_FOUND + mlNo;
					cell.setCellValue(noRecordMsg);
					cell.setCellStyle(noRecordCellStyle);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
				}	
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveLttrXLSFile: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveLttrXLSFile: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveLttrXLSFile: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveLttrXLSFile Method");
	}

	
	/**
	 * This method is used for Validating LTTR User Input
	 * 
	 * @return String
	 */
	public String validateLttrInput() {		
		LOG.info("Entering validateLttrInput Method");
		if(PLMUtils.isEmpty(lttrData.getMlNumLttr())){
			alertMessage = PLMConstants.LTTR_SEARCH_CRITERIA;
		}else if(!PLMUtils.checkForSpecialChars(lttrData.getMlNumLttr())){
			alertMessage = PLMConstants.LTTR_ML_SPLCHAR_CRITERIA;
		}
		LOG.info("Exiting validateLttrInput Method");
		return alertMessage;
	}

	/**
	 * This method is used for Resetting the User input
	 * 
	 * @return String
	 */
	
	public String resetData() {
		LOG.info("Entering Reset Method");
		String fwdflag = "lttrSearch";
		if (lttrData.getMlNumLttr() != null)
			lttrData.setMlNumLttr("");
		LOG.info("Exiting Reset Method");
		return fwdflag;
	}

	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}

	/**
	 * @param log the lOG to set
	 */
	public static void setLOG(Logger log) {
		LOG = log;
	}

	/**
	 * @return the lttrData
	 */
	public PLMLttrData getLttrData() {
		return lttrData;
	}

	/**
	 * @param lttrData the lttrData to set
	 */
	public void setLttrData(PLMLttrData lttrData) {
		this.lttrData = lttrData;
	}

	/**
	 * @return the plmLtttService
	 */
	public PLMLttrServiceIfc getPlmLttrService() {
		return plmLttrService;
	}

	/**
	 * @param plmLttrService the plmLttrService to set
	 */
	public void setPlmLttrService(PLMLttrServiceIfc plmLttrService) {
		this.plmLttrService = plmLttrService;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}
}