package com.geinfra.geaviation.pwi.queryprocessing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.PWiResultSet;
import com.geinfra.geaviation.pwi.model.PWiResultSetColMetaData;
import com.geinfra.geaviation.pwi.queryprocessing.pivot.DataMatrix;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.util.QueryProcessingUtil;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;

/**
 * Project      : Product Lifecycle Management Intelligence
 * Date Written : Oct 13, 2010
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : PivotQueryProcessor
 * 
 * Revision Log Oct 13, 2010 | v1.0.
 * 2012.12.18 pH  replaced GEAEResultSet with PWiResultSet
 * --------------------------------------------------------------
 */
public class PivotQueryProcessor implements QueryProcessor {
	public static final String TYPE = "pivot";
	private static final String PROPERTY_PIVOT_FIELD = "pivotField";
	private static final String PROPERTY_SUMMARY_FIELDS = "summaryFields";
	// XXX Uncomment if support for summators is desired
	// private static final String PROPERTY_SUMMATOR = "summator";
	private static final String PROPERTY_COMPARE_TYPE = "compareType";

	private static final Logger LOGGER = Logger
			.getLogger(PivotQueryProcessor.class);

	private String pivotField;
	private List<String> summaryFields;
	private int compareType;

	public PivotQueryProcessor(Properties properties) {
		// Retrieve pivot field
		pivotField = properties.getProperty(PROPERTY_PIVOT_FIELD).toUpperCase(
				Locale.US);

		// Retrieve summary field(s)
		summaryFields = QueryProcessingUtil
				.getInstance()
				.toUpperCase(
						Arrays
								.asList(properties
										.getProperty(PROPERTY_SUMMARY_FIELDS)
										.split(
												" *, *",
												PWiConstants.SPLIT_GREEDILY_AND_INCLUDE_EMPTY)));

		// XXX Uncomment if support for summators is desired
		// Retrieve summator if specified
		// String summatorProperty = properties.getProperty(PROPERTY_SUMMATOR);
		// if (summatorProperty != null) {
		// Add initialization of supported summators here
		// }

		// Retrieve compareType if specified
		String getCompareType = properties.getProperty(PROPERTY_COMPARE_TYPE);
		if (getCompareType != null) {
			if (getCompareType.equals("Full")) {
				compareType = DataMatrix.COMPARE_FULL;

			}

			else if (getCompareType.equals("Common")) {
				compareType = DataMatrix.COMPARE_COMMON;

			}

			else if (getCompareType.equals("Differences")) {
				compareType = DataMatrix.COMPARE_DIFFERENCES;

			}

		}

	}

	public PWiResultSet postProcess(PWiResultSet resultSet, Search search,
			List<String> selectedColumns, QueryType queryType)
			throws PWiException {
		// Convert selected columns to upper-case for comparison-sake because
		// result set reports column names in upper-case
		List<String> upperCaseSelectedColumns = QueryProcessingUtil
				.getInstance().toUpperCase(selectedColumns);

		// Determine fixed fields
		// A fixed field is chosen as any selected field that is not a pivot or
		// summary field
		List<String> fixedFields = new ArrayList<String>();
		for (String selectedColumn : upperCaseSelectedColumns) {
			// Add field to fixed fields if the field is not a pivot or
			// summary field
			if (!pivotField.equals(selectedColumn)
					&& !summaryFields.contains(selectedColumn)) {
				fixedFields.add(selectedColumn);
			}
		}
		LOGGER.debug("Fixed fields " + fixedFields.toString());

		// Generate pivot
		PWiResultSet pivotResultSet = pivot(resultSet, fixedFields);

		// Sort pivot
		pivotResultSet.sort();

		return pivotResultSet;
	}

	public void preProcess(SelectedColumns selectedColumns)
			throws PWiException {
		// Determine if pivot is already selected. If not, then select it.
		boolean pivotFound = false;
		for (SelectedColumns.Columnref ref : selectedColumns.getColumnref()) {
			if (ref.getRef().equals(pivotField)) {
				pivotFound = true;
			}
		}
		if (!pivotFound) {
			SelectedColumns.Columnref ref = new SelectedColumns.Columnref();
			ref.setRef(pivotField);
			selectedColumns.getColumnref().add(ref);
		}

		// For each summary field, determine if it is already selected. If not,
		// then select it.
		for (String summaryField : summaryFields) {
			boolean summaryFound = false;
			for (SelectedColumns.Columnref ref : selectedColumns.getColumnref()) {
				if (ref.getRef().equals(summaryField)) {
					summaryFound = true;
				}
			}
			if (!summaryFound) {
				SelectedColumns.Columnref ref = new SelectedColumns.Columnref();
				ref.setRef(summaryField);
				selectedColumns.getColumnref().add(ref);
			}
		}
	}

	private PWiResultSet pivot(PWiResultSet resultSet,
			List<String> fixedFields) throws PWiException {
//		try {
			
			// When there are no results, no pivot required.
			if (resultSet.size() == 0) {
				return resultSet;
			}
			
			// Rounding settings
			boolean bRoundOffDecimal = false; // default
			int iRoundOffDecimalToDigits = 2; // default

			LOGGER.debug("got the properties for the pivot ");

			// Determine the indexes of the sum columns in order to create the
			// table model
			int[] sumFieldIndexes = new int[summaryFields.size()];
			for (int scol = 0; scol < summaryFields.size(); scol++) {
				sumFieldIndexes[scol] = resultSet.findColumn(summaryFields
							.get(scol));
				if (sumFieldIndexes[scol] == PWiConstants.UNDEFINED_INDEX) {
					throw new PWiException(new StringBuffer()
							.append("Failed to find summary field in result")
							.append(" set.  summary field: ")
							.append(summaryFields.get(scol)).toString());
				}
			}

			// Create table model from result set using the sum field indices
			TableModel inTable = createTableFromRS(resultSet, sumFieldIndexes);

			// Create pivot table using DataMatrix
			DataMatrix dataMatrix = new DataMatrix();
			dataMatrix.setShowSumFieldName(false);

			// XXX Uncomment if support for summator is desired
			// if (summator != null) {
			// dataMatrix.setObjectSummator(summator);
			// }

			if (compareType != 0) {
				dataMatrix.setCompareType(compareType);
			}

			TableModel outTable = dataMatrix.createDataMatrix(inTable,
					pivotField, fixedFields.toArray(new String[fixedFields
							.size()]), summaryFields
							.toArray(new String[summaryFields.size()]),
					bRoundOffDecimal, iRoundOffDecimalToDigits);

			// Convert table mode to result set
			PWiResultSet pivotResultSet = createRSFromTable(outTable);

			// Set column headings for fixed fields in pivot table
			for (String fixedField : fixedFields) {
				int oldIndex = resultSet.findColumn(fixedField);
				int newIndex = pivotResultSet.findColumn(fixedField);
				pivotResultSet.setColumnHeading(newIndex, resultSet
						.getColumnHeading(oldIndex));
			}

			return pivotResultSet;
//		} catch (SQLException e) {
//			throw new PWiException(e, "Error");
//		}
	}

	/**
	 * Convert a table model to a GE AE result set.
	 * 
	 * @param pivotbl
	 * @return the result set
	 */
	private PWiResultSet createRSFromTable(TableModel pivotbl) {
		int iColCt = pivotbl.getColumnCount();

		// Set up the columns
		HashMap<String, Integer> ht1 = new HashMap<String, Integer>();
		HashMap<Integer, PWiResultSetColMetaData> ht2 =
				new HashMap<Integer, PWiResultSetColMetaData>();
		for (int i = 1; i <= iColCt; i++) {
			PWiResultSetColMetaData PWirscmd = new PWiResultSetColMetaData();
			PWirscmd.colindex = i;
			PWirscmd.colname = pivotbl.getColumnName(i - 1);
			PWirscmd.colheading = PWirscmd.colname;
			PWirscmd.coltype = java.sql.Types.CHAR;
			ht1.put(PWirscmd.colname, Integer.valueOf(i));
			ht2.put(Integer.valueOf(i), PWirscmd);
		}

		// Load up the data
		// Create the table (array of arrays) to set
		int iRowCt = pivotbl.getRowCount();
		ArrayList<ArrayList<String>> allRows = new ArrayList<ArrayList<String>>(
				iRowCt);
		for (int i = 0; i < iRowCt; i++) {
			ArrayList<String> arow = new ArrayList<String>(iColCt);
			for (int j = 0; j < iColCt; j++) {
				// arow.add(j, pivotbl.getValueAt(i,j));
				Object val = pivotbl.getValueAt(i, j);
				if (val == null) {
					arow.add(j, "");
				} else {
					arow.add(j, val.toString());
				}
			}
			allRows.add(arow);
		}

		// Create the result set and set the data
		PWiResultSet rs = new PWiResultSet();
		rs.setData(allRows, ht1, ht2);

		// Return the result set
		return rs;
	}

	/**
	 * Transform a GE AE result set into a table model. sumIndices is used to
	 * apply special handling to summary columns.
	 * 
	 * @param PWiRS
	 *            the result set
	 * @param sumIndexes
	 *            indices of summary columns
	 * 
	 * @return A valid TableModel on success, else null
	 * @throws PWiException
	 */
	public static TableModel createTableFromRS(PWiResultSet PWiRS,
			int[] sumIndexes) throws PWiException {
		
		// When no results to display output a DefaultTableModel.
		// If there are not results in the input set, return an emply table
		if (PWiRS.size() == 0) {
			return new DefaultTableModel();
		}
		
		String trimmed = null;
		String val = null;
		DefaultTableModel table = new DefaultTableModel();
		
		try {
			// Get the column headers
			int iColCt = PWiRS.getColumnCount();
			for (int i = 1; i <= iColCt; ++i) {
				table.addColumn(PWiRS.getColumnName(i));
				LOGGER.debug(PWiRS.getColumnName(i));
			}

			// Get the rows
			Object data[] = new Object[iColCt];
			PWiRS.first();

			do {
				for (int i = 1; i <= iColCt; ++i) {
					// Only stores Integers and Strings. Decimal values are
					// not supported yet since parseDouble() is JDK 1.2
					//
					// data[i-1] = p_PWiRS.getObject(i);
					// 1. get the string value and a trimmed string val
					val = PWiRS.getString(i);
					// 2. is this a sum field index? if so, try to make it
					// numeric
					boolean aSumField = false;
					for (int isum = 0; isum < sumIndexes.length; isum++) {
						if (i == sumIndexes[isum])
							aSumField = true;
					}
					if (aSumField) {
						trimmed = val.trim();
						// 2. test trimmed value for numeric qualities
						// quick scan for numeric-ness 0-9, dot, and dash
						int valsize = trimmed.length();
						if (valsize == 0) {
							data[i - 1] = val;
						} else {
							int decimal_pos = trimmed.indexOf('.');
							if (decimal_pos > PWiConstants.NO_VALUE_FOR_INDEX_OF) {
								try {
									Double dnum = new Double(trimmed);
									data[i - 1] = dnum;
								} catch (NumberFormatException nfe_dbl) {
									data[i - 1] = val;
								}
							} else {
								try {
									Integer inum = Integer.valueOf(trimmed);
									data[i - 1] = inum;
								} catch (NumberFormatException nfe_int) {
									data[i - 1] = val;
								}
							}
						}
					} else {
						// use value as it is
						data[i - 1] = val;
					}
				}
				table.addRow(data);
			} while (PWiRS.next());
		} catch (NumberFormatException nfe) {
			LOGGER.debug("Number format exeception on:  " + "\nOriginal value:"
					+ val + "\nTrimmed value :" + trimmed);
			throw new PWiException(nfe);
//		} catch (SQLException e) {
//			throw new PWiException(e);
		}
		return table;
	}
}
