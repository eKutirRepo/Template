/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCompleteEbomReportDaoIfc.java
 * @Creation date: 06-Apr-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMAeroRptData;
import com.geinfra.geaviation.pwi.data.PLMCompatibilityRulesReportData;
import com.geinfra.geaviation.pwi.data.PLMCompleteEbomReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMCompleteEbomReportDaoIfc {

	/**
	 * This method is used to fetch all project names on load of home page
	 * @return
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getLoadingData() throws PLMCommonException;

	/**
	 * This method is used to fetch Top Part Names for a Project
	 * @param selShipBomProjectName
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMCompleteEbomReportData> fetchTopPartList(
			String selShipBomProjectName) throws PLMCommonException;

	/**
	 * This method is used to generate report on selection criteria
	 * @param selShipBomProjectName
	 * @param selShipBomTopPartName
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMCompleteEbomReportData> generateCompleteEbomAppReport(
			String selShipBomProjectName, List<String> selShipBomTopPartName) throws PLMCommonException;
	
	/**
	 * This method is used to getHardwareProductNames
	 * @return
	 * @throws PLMCommonException
	 */
	public List<SelectItem>getHardwareProductNames() throws PLMCommonException;
	/**
	 * This method is used to getRevisionNames
	 * @return
	 * @throws PLMCommonException
	 */
	public List<SelectItem>getRevisionNames(String hardWarePrdNm) throws PLMCommonException;
	/**
	 * This method is used to get Logical Features
	 * @param hardWarePrd,revision
	 * @return
	 * @throws PLMCommonException
	 */
	public Map<String,Object> getLogicalFeatureData(
			String hardWarePrd,String revision) throws PLMCommonException;
	/**
	 * This method is used to get Configuration Features
	 * @param hardWarePrd,revision
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMAeroRptData> getConfigFeatureData(
			String hardWarePrd,String revision) throws PLMCommonException;
	
	/**
	 * This method is used to generate online report based on select criteria
	 * @param selShipBomHardwareProdName
	 * @param selShipBomRevName
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMCompatibilityRulesReportData> generateCompatibilityRulesAppReport(
			String selShipBomHardwareProdName, String selShipBomRevName) throws PLMCommonException;
	/**
	 * This method is used to generate online report based on select criteria
	 * @param selShipBomHardwareProdName
	 * @param selShipBomRevName
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMCompatibilityRulesReportData> generateMarketingPrefRptAppReport(
			String selShipBomHardwareProdName, String selShipBomRevName) throws PLMCommonException;



}
