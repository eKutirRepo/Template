package com.geinfra.geaviation.pwi.bean;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.service.AdminToolTipService;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

/**
 * 
 * Project : Product Lifecycle Management
 * Date Written : May 31, 2013
 * Security : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : ApplicationParametersBean - Application-scoped bean that
 * provides JSF pages with read access to the application parameters stored in
 * the database.
 * 
 * Revision Log May 31, 2013 | v1.0.
 * --------------------------------------------------------------
 */

public class ToolTipParametersBean extends BaseBean {
	// Dependency-injected service
	private AdminToolTipService adminToolTipService;

	public void setAdminToolTipService(
			AdminToolTipService adminToolTipService) {
		this.adminToolTipService = adminToolTipService;
	}

	public boolean isBatchDisabled() throws PWiException {
		return adminToolTipService.isBatchDisabled();
	}

	public String getHomeToolTip() throws PWiException {
		return adminToolTipService.getHomeToolTip();
	}

	public boolean isAdmin() throws PWiException {
		return UserInfoPortalUtil.getInstance().isAdmin();
	}

	public boolean isPwiUser() throws PWiException {
		return UserInfoPortalUtil.getInstance().isPwiUser();
	}
}
