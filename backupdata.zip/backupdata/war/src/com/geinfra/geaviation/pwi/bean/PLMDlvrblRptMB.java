/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMDlvrblRptMB.java
 * @Creation date: 11-Sept-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

import com.geinfra.geaviation.pwi.data.PLMBomDlvrblData;
import com.geinfra.geaviation.pwi.data.PLMBomDlvrblDiscsnData;
import com.geinfra.geaviation.pwi.data.PLMBomSpecPartData;
import com.geinfra.geaviation.pwi.data.PLMLogData;
import com.geinfra.geaviation.pwi.data.PLMMLIBomDlvrblDiscusnData;
import com.geinfra.geaviation.pwi.data.PLMMessageData;
import com.geinfra.geaviation.pwi.data.PLMPRSData;
import com.geinfra.geaviation.pwi.data.PLMPRSRouteData;
import com.geinfra.geaviation.pwi.data.PLMPRSTaskRouteData;
import com.geinfra.geaviation.pwi.data.PLMRouteTaskOwnerData;
import com.geinfra.geaviation.pwi.data.PLMSalesOrderData;
import com.geinfra.geaviation.pwi.data.PLMTaskDlvrblData;
import com.geinfra.geaviation.pwi.data.PLMTaskRouteData;
import com.geinfra.geaviation.pwi.service.PLMDlvrblRptServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMExcelRptUtil;
import com.geinfra.geaviation.pwi.util.PLMUtils;
public class PLMDlvrblRptMB {
	
	
	// PROPERTIES *************************************************************


	/**
	 * Holds the plmDocGenService
	 */
	private PLMDlvrblRptServiceIfc dlvrblRptService = null;
	
	/**
	 * Logger
	 */
	private static Logger logger = Logger.getLogger(PLMDlvrblRptMB.class);
			
	/**
	 * Holds the commonMB
	 */
	private PLMCommonMB commonMB;
	
	/**
	 * Input project name
	 */
	private String projectName;
	private String projectOwner;
	private String ownerName;
	private String userName = "";
	
	
	/**
	 * PLMPRSData item list
	 */
	private List<PLMPRSData> prs = null;	

	/**
	 * List of bom parts/task deliverables/discussions by mli
	 */
	private List<PLMMLIBomDlvrblDiscusnData> mlisBomDeliverablesDiscussions = null;
	
	/**
	 * List of bom deliverables
	 */
	private List<PLMBomDlvrblData> bom_deliverables = null;
	
	/**
	 * List of tasks-routes
	 */
	private List<PLMTaskRouteData> tasks_routes = null;
	
	/**
	 * List of sales_orders
	 */
	private List<PLMSalesOrderData> sales_orders = null;

	/**
	 * List of prs_routes
	 */
	private List<PLMPRSRouteData> prs_routes = null;
	
	/**
	 * List of prs_route_tasks
	 */
	private List<PLMPRSTaskRouteData> prs_route_tasks = null;
	
	/**
	 * List of log_history
	 */
	private List<PLMLogData> log_history = null;
	
	/**
	 * boolean of projFlag
	 */
	private boolean projFlag;
	/**
	 * Holds the dataTable
	 */
	private HtmlDataTable dataTable = new HtmlDataTable();

	
	// PRIVATE METHODS ********************************************************

	/**
	 * Validates the input string to remove the apostrophes and 
	 * replace the '*' for '%'
	 */

	private String validateString(String projectNameLcl) {
		
		if (projectNameLcl == null || projectNameLcl.equals("")){
			return "";
		}
		/*if (projectNameLcl != null && !projectNameLcl.equals("")){
			int projNameLen = projectNameLcl.length();
			if (projNameLen < 7 || projNameLen > 8){
				return PLMConstants.DELIVERABLE_ERROR;
			} else {
				for (int i = 0; i < projNameLen; i++){
					String chr = projectNameLcl.substring(i,i+1);
					if (i == 0){
							if (!chr.toUpperCase(Locale.getDefault()).equals("F")){
								return PLMConstants.DELIVERABLE_ERROR;
							}
					} else if (i == 1 || i == 2 || i == 3){
							if (!chr.matches("^[A-Z0-9]+$")){
								return PLMConstants.DELIVERABLE_ERROR;
							}
					} else if (i == 4){
						
						if (!chr.matches(".*\\d.*")){
							return PLMConstants.DELIVERABLE_ERROR;
						}
					} else if (i == 5){
							if (!chr.toUpperCase(Locale.getDefault()).equals("G")){
								return PLMConstants.DELIVERABLE_ERROR;
							}
					} else if (i >= 6) {
							if (!chr.matches(".*\\d.*")){
								return PLMConstants.DELIVERABLE_ERROR;
							}							
					}
				}	
			}
			return projectNameLcl;
		} else {
			return "";
		}*/
		return projectNameLcl;
    }	
	
	
	/*private String convertFDMtoBOM(String projectNumber){
		String bomNumber = projectNumber;
		
		String name = bomNumber.replaceAll("F","367A");
		char gTxt = 'G';
		int indexOfG = name.indexOf(gTxt);
		String strName = name.substring(0,indexOfG+1);
		String strGroup = name.substring(indexOfG+1,name.length());
		strName = strName + "000";
		int lenGroup = strGroup.length();
		strName = strName.substring(0,strName.length()-lenGroup);
		bomNumber = strName + strGroup;
		
		return bomNumber;
	}*/
	
	/*private String convertFDMtoBOM(String projectNumber){
		String bomNumber = projectNumber;
		
		try {
			if (bomNumber.startsWith("F")){
				bomNumber = bomNumber.replaceAll("F","367A");
			} else if (bomNumber.startsWith("DLN")){
				//Project Name example --> DLNCONV6BG2
				//BOM Number example --> 367ADLN6BG002 
				bomNumber = "367A" + bomNumber.replaceAll("CONV", "");
			} else if (bomNumber.startsWith("EXT")){
				bomNumber = bomNumber.replaceAll("EXT", "");
				if (bomNumber.indexOf("KG") != -1){
					//Project Name example --> EXT32KG1
					//BOM Number example --> 367A32KIG001
					bomNumber = "367A" + bomNumber.replaceAll("KG", "KIG");
				} else {
					//Project Name example --> EXT32K7EG1
					//BOM Number example --> 367A32K7G001
					bomNumber = "367A" + bomNumber.substring(0, bomNumber.indexOf('K')+2) + bomNumber.substring(bomNumber.indexOf('G'));
				}
			}
			int indexOfG = bomNumber.indexOf('G');
			String strName = bomNumber.substring(0,indexOfG+1);
			String strGroup = bomNumber.substring(indexOfG+1,bomNumber.length());
			strName = strName + "000";
			int lenGroup = strGroup.length();
			strName = strName.substring(0,strName.length()-lenGroup);
			bomNumber = strName + strGroup;
		} catch (Exception e){
			e.printStackTrace();
		}
		
		return bomNumber;
	}*/

	//RECURSIVE METHOD TO GET ALL LEVELS FROM PLMPRSData
	private void getChaptersRequirementsComments(Map<String, PLMPRSData> sons, int level){
		
		if (sons.isEmpty()){
			return;
		}
		int levelLcl = level;	
		levelLcl++; 

		String strIDs = "";
		StringBuffer srtIds = new StringBuffer();
		Iterator iter = sons.entrySet().iterator();
		while (iter.hasNext()){
			Map.Entry<String, PLMPRSData> son = (Map.Entry<String, PLMPRSData>)iter.next();
			//strIDs += "'" + son.getValue().getId() + "',";
			srtIds = srtIds.append("'")
			.append(son.getValue().getId())
			.append("',");
			son.getValue().setLevel(levelLcl);
		}
		//strIDs = strIDs.substring(0, strIDs.length()-1);  //REMOVE TRAILING COMMA
		
		strIDs = srtIds.substring(0, srtIds.length()-1);  //REMOVE TRAILING COMMA
	
		Map<String, PLMPRSData> grandsons = dlvrblRptService.prsChaptersRequirementsComments(strIDs);

		iter = grandsons.entrySet().iterator();
		while (iter.hasNext()){
			Map.Entry<String, PLMPRSData> grandson = (Map.Entry<String, PLMPRSData>)iter.next();
			
			String grandsonFromName = grandson.getValue().getFromName();
			if (sons.containsKey(grandsonFromName)){
				sons.get(grandsonFromName).sons.put(grandson.getKey(), grandson.getValue());
			}
			
		}
		
		this.getChaptersRequirementsComments(grandsons, levelLcl);
		
	}
	
	//RECURSIVE METHOD TO CONVERT MAP TO LIST AND ADD ROW COLOR
	private void convertMapToList(Map<String, PLMPRSData> sons, ArrayList<PLMPRSData> prsList){
		Iterator iter = sons.entrySet().iterator();
		while (iter.hasNext()){
			Map.Entry<String, PLMPRSData> son = (Map.Entry<String, PLMPRSData>)iter.next();
			if (son.getValue().getType().equals("Chapter") ||  son.getValue().getType().equals("Requirement")) {
				son.getValue().setRowColor("tanColor");
			}
			prsList.add(son.getValue());
			if (!son.getValue().sons.isEmpty()){
				convertMapToList(son.getValue().sons,prsList);
			}
		}

	}
	
	// --------------------------------- CREATE PRODUCT REQUIREMENT SPECIFICATION VIEW ------------------------------------------
	private ArrayList<PLMPRSData> createPRS(String project_name){
		PLMPRSData prsData = null;		
		ArrayList<PLMPRSData> prsList = new ArrayList<PLMPRSData>(); 
		
		int level = 1;
		
		prsData = dlvrblRptService.prs(project_name);
		
		if (prsData == null) return prsList;
		
		prsData.setLevel(level);
		prsData.setRowColor("highlighted");
		
		prsList.add(prsData);
		
		Map<String, PLMPRSData> sons = dlvrblRptService.prsChaptersRequirementsComments("'" + prsData.getId() + "'");
		prsData.setSons(sons);

		this.getChaptersRequirementsComments(sons, level);
		
		this.convertMapToList(sons,prsList);
				
		return prsList;
	}
		

	
	// --------------------------------- CREATE BOM/SPEC PARTS VS DELIVERABLES VIEW ------------------------------------------
	private List<PLMBomDlvrblData> createBomDeliverablesTable(String projectNameLcl, String prsId){
				
		//String bomNumber = this.convertFDMtoBOM(projectNameLcl);
		//String maxRevision = dlvrblRptService.max_revision(bomNumber);
		List<String> topParts = dlvrblRptService.getTopLevelPart(projectNameLcl);

		//EXTRACT PLMPRSData CHAPTERS
		List<PLMPRSData> prs_chapters = dlvrblRptService.prs_chapters(projectNameLcl, prsId);
		
		if (prs_chapters == null || prs_chapters.isEmpty())
			return null;

		
		//EXTRACT SPECIFICATION PARTS
		Map<String, PLMBomSpecPartData> spec_parts = new LinkedHashMap<String, PLMBomSpecPartData>();
		//Map<String, PLMBomSpecPartData> spec_parts = dlvrblRptService.spec_parts(topParts);
		
		//EXTRACT BOM PARTS
		Map<String, PLMBomSpecPartData> bom_parts = new LinkedHashMap<String, PLMBomSpecPartData>();
		//Map<String, PLMBomSpecPartData> bom_parts = dlvrblRptService.bom_parts(topParts);

		if (!PLMUtils.isEmptyList(topParts)) {
			logger.info("topParts : " + topParts.size());	
			spec_parts = dlvrblRptService.spec_parts(topParts);
			bom_parts = dlvrblRptService.bom_parts(topParts);
		}
		//EXTRACT TASKS WITH ITS DELIVERABLES
		List<PLMTaskDlvrblData> tasks_deliverables = dlvrblRptService.tasks_deliverables(projectNameLcl);
		
		if (tasks_deliverables.isEmpty()){
			return null;
		}
		
		
		
		//JOIN BOM AND SPEC PARTS INTO A MAP
		Map<String, PLMBomSpecPartData> bomSpecParts = new LinkedHashMap<String, PLMBomSpecPartData>();
		bomSpecParts.putAll(spec_parts);
		bomSpecParts.putAll(bom_parts);
		
		
		//GROUP BOM_SPEC_PARTS INTO A NEW MAP WITH THE LOGICAL INDICATOR AS KEY
		Map<String, Map<String,PLMBomSpecPartData>> mapBomSpecParts = new LinkedHashMap<String, Map<String,PLMBomSpecPartData>>();
		Iterator iter = bomSpecParts.entrySet().iterator();
		while (iter.hasNext()){
			Map.Entry<String, PLMBomSpecPartData> bm_spc_prt = (Map.Entry<String, PLMBomSpecPartData>)iter.next();
			String li = bm_spc_prt.getValue().getLogicalIndicator();
			
			if (mapBomSpecParts.containsKey(li)){
				mapBomSpecParts.get(li).put(li,bm_spc_prt.getValue());
			} else {
				Map<String,PLMBomSpecPartData> bom_spec = new LinkedHashMap<String,PLMBomSpecPartData>();
				bom_spec.put(bm_spc_prt.getKey(), bm_spc_prt.getValue());
				mapBomSpecParts.put(li, bom_spec);
			}
		}


		//GROUP TASK_DELIVERABLES INTO A NEW MAP WITH THE TASK_NAME(MLI) AS KEY
		Map<String, List<PLMTaskDlvrblData>> mapTasks = new LinkedHashMap<String,List<PLMTaskDlvrblData>>();
		for (PLMTaskDlvrblData tsk_del : tasks_deliverables){
			
			String mli = tsk_del.getTaskName();
			
			if (mapTasks.containsKey(mli)){
				mapTasks.get(mli).add(tsk_del);
			} else {
				List<PLMTaskDlvrblData> tsk_dlv = new ArrayList<PLMTaskDlvrblData>();
				tsk_dlv.add(tsk_del);
				mapTasks.put(mli, tsk_dlv);
			}
			
		}
		
		
		//GROUP PLMPRSData CHAPTERS INTO A NEW MAP WITH THE CHAPTER TITLE(MLI) AS KEY
		Map<String, List<PLMPRSData>> mapChapters = new LinkedHashMap<String,List<PLMPRSData>>();
		char emptyChar = ' ';
		for (PLMPRSData chapter : prs_chapters){
			String title = chapter.getTitle();
			if (title.indexOf(emptyChar) > 0){
				title = title.substring(0, title.indexOf(emptyChar));
			}
			if (title.indexOf("0010") < 0 ) { 
				if (mapChapters.containsKey(title)){
					mapChapters.get(title).add(chapter);
				} else {
					List<PLMPRSData> chapters = new ArrayList<PLMPRSData>();
					chapters.add(chapter);
					mapChapters.put(title, chapters);
				}
			}			
		}
		//logger.info("mapChapters >>>>> " + mapChapters.size());
		
		//CREATE BOM/SPEC PARTS - TASKS/DELIVERABLES LIST
		List<PLMBomDlvrblData> bom_tasks = new ArrayList<PLMBomDlvrblData>();
		
		//LOOP THROUGH MAP BOM/SPEC PARTS TO FIND IN THE
		//TASK-DELIVERABLES MAP MLIs THAT MATCHES BOM LOGICAL INDICATOR
		Iterator iterMapBOM = mapBomSpecParts.entrySet().iterator();
		while (iterMapBOM.hasNext()){
			Map.Entry<String, Map<String, PLMBomSpecPartData>> mapBom = (Map.Entry<String, Map<String, PLMBomSpecPartData>>)iterMapBOM.next();
			
			String li = mapBom.getKey();
			if (mapTasks.containsKey(li)){
				
				//IF LI IS FOUND IN THE TASKS THEN
				//EXTRACT THE BOM PARTS OF THAT LOGICAL INDICATOR
				//(NORMALLY IS JUST ONE BUT TO EXTRACT THE VALUE WITHOUT THE KEY YOU NEED TO LOOP THROUGH THE MAP)
				Iterator iterBOM = mapBom.getValue().entrySet().iterator();
				while (iterBOM.hasNext()){
					Map.Entry<String, PLMBomSpecPartData> bom = (Map.Entry<String, PLMBomSpecPartData>)iterBOM.next();
					String deliverable = bom.getKey();
					List<PLMTaskDlvrblData> tsks_dels = mapTasks.get(li);
					PLMTaskDlvrblData tsk = null;
					
					//LOOP THROUGH THE TASKS MAP TO FIND THE DELIVERABLE THAT MATCHES THE BOM PART
					for (PLMTaskDlvrblData tsk_del : tsks_dels){
						if (deliverable.equals(tsk_del.getDeliverableName())){
							tsk = tsk_del;
							break;
						}
					}
					
					//IF THE DELIVERABLE MATCHES THE BOM PART ADD BOTH TO THE BOM-TASKS LIST
					if (tsk != null){
						bom_tasks.add(new PLMBomDlvrblData(bom.getValue(),tsk));
						tsks_dels.remove(tsk);
					} 
					//IF THE BOM PART DOESN'T MATCH ANY TASK DELIVERABLE JUST ADD THE BOM PART TO THE BOM-TASKS LIST
					else {
						PLMBomSpecPartData bm = bom.getValue();
						bom_tasks.add(new PLMBomDlvrblData(
														bm,
														new PLMTaskDlvrblData(null,null,null,null,null,null,null,null,null,null,null,null,null)));
					}
				}
				
				//LOOP THROUGH THE DELIVERABLES THAT DIDN'T MATCH ANY BOM PART AND ADD THEM TO THE BOM-TASKS LIST
				List<PLMTaskDlvrblData> tsks_dels = mapTasks.get(li);
				for (PLMTaskDlvrblData tsk_del : tsks_dels){
					bom_tasks.add(new PLMBomDlvrblData(
											new PLMBomSpecPartData(null,null,null,null,null,null,null),
											tsk_del));
				}
				
				//REMOVE TASK-DELIVERABLE ALREADY COMPARED TO ADD LATER THE TASKS THAT ARE NOT IN THE BOM-PARTS MAP
				mapTasks.remove(li);
				
			} 
			//LI WASN'T FOUND IN THE TASKS MAP THEN LOOK IN THE TASK REVISIONS
			else {
				String newLI = "";
				for (int i = 1; i < 1000; i++){
					
					if (i < 10){ newLI = li+"00"+i;} 
					else if (i < 100){ newLI = li+"0"+i;} 
					else { newLI = String.valueOf(i); }
					
					if (mapTasks.containsKey(newLI)){
						//IF LI IS FOUND IN THE TASKS THEN
						//EXTRACT THE BOM PARTS OF THAT LOGICAL INDICATOR
						//(NORMALLY IS JUST ONE BUT TO EXTRACT THE VALUE WITHOUT THE KEY YOU NEED TO LOOP THROUGH THE MAP)
						Iterator iterBOM = mapBom.getValue().entrySet().iterator();
						while (iterBOM.hasNext()){
							Map.Entry<String, PLMBomSpecPartData> bom = (Map.Entry<String, PLMBomSpecPartData>)iterBOM.next();
							String deliverable = bom.getKey();
							List<PLMTaskDlvrblData> tsks_dels = mapTasks.get(newLI);
							PLMTaskDlvrblData tsk = null;
							
							//LOOP THROUGH THE TASKS MAP TO FIND THE DELIVERABLE THAT MATCHES THE BOM PART
							for (PLMTaskDlvrblData tsk_del : tsks_dels){
								if (deliverable.equals(tsk_del.getDeliverableName())){
									tsk = tsk_del;
									break;
								}
							}
							
							//IF THE DELIVERABLE MATCHES THE BOM PART ADD BOTH TO THE BOM-TASKS LIST
							if (tsk != null){
								bom_tasks.add(new PLMBomDlvrblData(bom.getValue(),tsk));
								tsks_dels.remove(tsk);
							} 
							//IF THE BOM PART DOESN'T MATCH ANY TASK DELIVERABLE JUST ADD THE BOM PART TO THE BOM-TASKS LIST
							else {
								PLMBomSpecPartData bm = bom.getValue();
								bom_tasks.add(new PLMBomDlvrblData(
																bm,
																new PLMTaskDlvrblData(null,null,null,null,null,null,null,null,null,null,null,null,null)));
							}
						}
						
						//LOOP THROUGH THE DELIVERABLES THAT DIDN'T MATCH ANY BOM PART AND ADD THEM TO THE BOM-TASKS LIST
						List<PLMTaskDlvrblData> tsks_dels = mapTasks.get(newLI);
						for (PLMTaskDlvrblData tsk_del : tsks_dels){
							bom_tasks.add(new PLMBomDlvrblData(
													new PLMBomSpecPartData(null,null,null,null,null,null,null),
													tsk_del));
						}
						
						//REMOVE TASK-DELIVERABLE ALREADY COMPARED TO ADD LATER THE TASKS THAT ARE NOT IN THE BOM-PARTS MAP
						mapTasks.remove(newLI);
						break;
					}
					else{
						//ADD NOT FOUND BOM PARTS TO THE BOM-TASKS LIST
						Iterator iterBOM = mapBom.getValue().entrySet().iterator();
						while (iterBOM.hasNext()){
							Map.Entry<String, PLMBomSpecPartData> bom = (Map.Entry<String, PLMBomSpecPartData>)iterBOM.next();
							PLMBomSpecPartData bm = bom.getValue();
							bom_tasks.add(new PLMBomDlvrblData(
															bm,
															new PLMTaskDlvrblData(null,"DIRECT RELEASE",null,null,null,null,null,null,null,null,null,null,null)));
						}
						
						break;
						
					}

				}


			}
						
		}
			
		//ADD MISSING TASKS-DELIVERABLES THAT DIDN'T MATCH ANY BOM PART
		Iterator iterTasks = mapTasks.entrySet().iterator();
		while(iterTasks.hasNext()){
			Map.Entry<String,List<PLMTaskDlvrblData>> mapTask = (Map.Entry<String,List<PLMTaskDlvrblData>>)iterTasks.next();
			for (PLMTaskDlvrblData tsk : mapTask.getValue()){
				bom_tasks.add(new PLMBomDlvrblData(
						new PLMBomSpecPartData(null,null,null,null,null,null,null),
						tsk));
			}
		}
		
		
		//LOOK BOM OR TASK MLI TO MATCH WITH PLMPRSData CHAPTERS
		for (PLMBomDlvrblData item : bom_tasks){
			String strKey =item.getBom_part().getLogicalIndicator();
			if (mapChapters.containsKey(strKey)){
				for (PLMPRSData chapter : mapChapters.get(strKey)){
					item.setChapter(chapter);
				}
				mapChapters.remove(strKey);
			} else if (mapChapters.containsKey(projectNameLcl+"-"+strKey)) {
				for (PLMPRSData chapter : mapChapters.get(projectNameLcl+"-"+strKey)){
					item.setChapter(chapter);
				}
				mapChapters.remove(projectNameLcl+"-"+strKey);
			} else {
				strKey = item.getTask_deliverable().getTaskName();
				if (mapChapters.containsKey(strKey)){
					for (PLMPRSData chapter : mapChapters.get(strKey)){
						item.setChapter(chapter);
					}
					mapChapters.remove(strKey);
				} else if (mapChapters.containsKey(projectNameLcl+"-"+strKey)) {
					for (PLMPRSData chapter : mapChapters.get(projectNameLcl+"-"+strKey)){
						item.setChapter(chapter);
					}
					mapChapters.remove(projectNameLcl+"-"+strKey);
				} else {
					item.setChapter(new PLMPRSData());
				}
			}
		}
		
		//ADD MISSING PLMPRSData CHAPTERS TO LIST
		Iterator iterChapters = mapChapters.entrySet().iterator();
		List<String> missingPRS = new ArrayList<String>();
		while(iterChapters.hasNext()){
			Map.Entry<String,List<PLMPRSData>> prs_chptrs = (Map.Entry<String,List<PLMPRSData>>)iterChapters.next();
			//CHECK FOR CHAPTERS TITLE EXCEPTIONS (TITLES THAT ARE NOT MLIs)
			if (!prs_chptrs.getKey().equals("RequisitionData")){
				for (PLMPRSData chptr : prs_chptrs.getValue()){
					PLMBomDlvrblData BomDeliv = new PLMBomDlvrblData(
													new PLMBomSpecPartData(chptr.getTitle(),"ERROR",null,null,null,null,null),
													new PLMTaskDlvrblData("",null,null,null,null,null,null,null,null,null,null,null,null)
													);
					BomDeliv.setChapter(chptr);
					bom_tasks.add(BomDeliv);
					missingPRS.add(chptr.getTitle());
				}
			}
		}
				
		//Order by Task Name/Logical Indicator
		Collections.sort(bom_tasks, new SortBomDlvrbl());
		
		//SET COLOR TO ROWS BY GROUPING MLIs
		String lastMli = "";
		String lastColor = "whiteColor";
		for (PLMBomDlvrblData bom_del : bom_tasks){
			String mli = (bom_del.getBom_part().getLogicalIndicator() == null)? ((bom_del.getTask_deliverable().getTaskName()==null)? bom_del.getChapter().getTitle() : bom_del.getTask_deliverable().getTaskName()) : bom_del.getBom_part().getLogicalIndicator();
			if (!mli.equals(lastMli)){
				lastColor = (lastColor.equals("whiteColor"))? "tanColor" : "whiteColor";
				lastMli = mli;
			} 
			bom_del.rowColor = lastColor;
			PLMBomSpecPartData temp = bom_del.getBom_part();
			if (!PLMUtils.isEmptyList(missingPRS) && "ERROR".equalsIgnoreCase(temp.getPartName())) {
				//logger.info("temp getLogicalIndicator >>>>>>> "+ temp.getLogicalIndicator());
				for (int j = 0; j < missingPRS.size(); j++) {
					if (temp.getLogicalIndicator().equalsIgnoreCase(missingPRS.get(j))) {
						temp.setLogicalIndicator("");
						missingPRS.remove(temp.getLogicalIndicator());
					}
				}
			}
		}
		
		return bom_tasks;
	}
	
	/**
	 * 
	 * class to sort list of object of type PLMTaskDlvrblData.
	 * 
	 */
	private static class SortBomDlvrbl implements Comparator<PLMBomDlvrblData>, Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		 public int compare(PLMBomDlvrblData one, PLMBomDlvrblData other) {
		    	
		    	int comparison = 0;
		    	
		    	String oneTaskName = one.getTask_deliverable().getTaskName();
		    	String otherTaskName = other.getTask_deliverable().getTaskName();
		    	String oneLI = one.getBom_part().getLogicalIndicator();
		    	String otherLI = other.getBom_part().getLogicalIndicator();
		    	
		    	if (oneTaskName != null && otherTaskName != null) {
		    		
	    			comparison = oneTaskName.compareTo(otherTaskName);
		    		
		    	} else if (oneLI != null && otherLI != null) {
		    		
	    			comparison = oneLI.compareTo(otherLI);
		    		
		    	} else if (oneTaskName != null && otherLI != null) {

		    		comparison = oneTaskName.compareTo(otherLI);

		    	} else if (oneLI != null && otherTaskName != null){
		    		
		    		comparison = oneLI.compareTo(otherTaskName);
		    		
		    	}
		    	
		    	return comparison;
		    }
	}
	
	// --------------------------------- CREATE DELIVERABLES VS DISCUSSIONS VIEW ------------------------------------------
	private List<PLMMLIBomDlvrblDiscusnData> createMLIBomDeliverablesDiscussionsTable(String projectNameLcl, List<PLMBomDlvrblData> bom_tasks){

		if (bom_tasks == null || bom_tasks.isEmpty())
			return null;

		String lastColor = "whiteColor";
		
		List<PLMMLIBomDlvrblDiscusnData> mlisBmDlvrblsDscssns = new ArrayList<PLMMLIBomDlvrblDiscusnData>();
		
		//String str = " projects Site Project Data folder.";
		
		//EXTRACT MESSAGES
		List<PLMMessageData> discussions = dlvrblRptService.messages(projectNameLcl);

		//BOM-TASKS-DELIVERABLES WERE ALREADY EXTRACTED ON THE BOM-DELIVERABLES VIEW
		//SO JUST REUSE THAT LIST BUT EXTRACT THE TASKS WITH DELIVERABLES
		Map<String, List<PLMBomDlvrblData>> mli_bom_dels = new LinkedHashMap<String, List<PLMBomDlvrblData>>();
		for (PLMBomDlvrblData bom_task : bom_tasks){
			PLMTaskDlvrblData tsk_del = bom_task.getTask_deliverable();
			PLMBomSpecPartData bom_part = bom_task.getBom_part();
			if (tsk_del.getDeliverableName() != null || bom_part.getPartName() != null){
				
				String mli = (tsk_del.getTaskName() != null)? tsk_del.getTaskName() : bom_part.getLogicalIndicator();
				if (mli_bom_dels.containsKey(mli)){
					mli_bom_dels.get(mli).add(bom_task);
				} else {
					List<PLMBomDlvrblData> bom_dlv = new ArrayList<PLMBomDlvrblData>();
					bom_dlv.add(bom_task);
					mli_bom_dels.put(mli, bom_dlv);
				}
				
			}
		}
		
		//GROUP DISCUSSIONS BY MLI
		Map<String,List<PLMMessageData>> mli_discs = new LinkedHashMap<String,List<PLMMessageData>>();
		for (PLMMessageData dscsn : discussions){
			String mli = dscsn.getTaskName();
			if (mli_discs.containsKey(mli)){
				mli_discs.get(mli).add(dscsn);
			} else {
				List<PLMMessageData> dscsns = new ArrayList<PLMMessageData>();
				dscsns.add(dscsn);
				mli_discs.put(mli, dscsns);
			}
		}
		
		lastColor = "whiteColor";
		
		//LOOP THROUGH DISCUSSIONS MAPPED BY MLI TO FIND IN THE BOM/DELIVERABLES MAPPED BY
		//TO BUILD A LIST THAT CONTAINS ALL THE BOM PARTS/TASK DELIVERABLES WITH THE DISCUSSIONS
		//THAT SUBSTANTIATE THEM
		int index = 0;
		Iterator iter = mli_discs.entrySet().iterator();
		while (iter.hasNext()){
			
			Map.Entry<String, List<PLMMessageData>> mli_dscssns = (Map.Entry<String, List<PLMMessageData>>)iter.next();
			
			List<PLMMessageData> msgs = mli_dscssns.getValue();
			
			List<PLMBomDlvrblDiscsnData> bom_del_disc_list = new ArrayList<PLMBomDlvrblDiscsnData>();
			
			int bomDelvrblCntr = 0;
			
			
			//GET MLI FROM DISCUSSION MAP
			String mli = mli_dscssns.getKey();
			
			//CHECK IF DISCUSSION MLI IS IN THE BOM/DELIVERABLES MAP
			if (mli_bom_dels.containsKey(mli)){

				//EXTRACT BOM/DELIVERABLES LIST
				List<PLMBomDlvrblData> bom_dels = mli_bom_dels.get(mli);
				
				//LOOP THROUGH ALL BOM/DELIVERABLES
				while (bomDelvrblCntr < bom_dels.size()){
					
					//EXTRACT BOM/SPEC PART
					PLMBomSpecPartData bm_prt = bom_dels.get(bomDelvrblCntr).getBom_part();
					
					//EXTRACT TASK DELIVERABLE
					PLMTaskDlvrblData tsk_dlv = bom_dels.get(bomDelvrblCntr).getTask_deliverable();
					
					PLMMessageData msg = null;

					//CHECK IF THERE ARE MESSAGES IN THE MESSAGE LIST
					//IF THERE ARE EXTRACT THE ONE THAT MATCH THE BOM/DELIVERABLE ROW
					if (bomDelvrblCntr < msgs.size()){
						msg = msgs.get(bomDelvrblCntr);
					}
					//ELSE CREATE A BLANK MESSAGE TO FILL THE BOM/DELIVERABLE ROW
					else {
						msg = new PLMMessageData(null,null,null,null,null,null,null,null,"","","");
					}
					
					//CREATE A NEW BOM/DELIVERABLE/DISCUSSION OBJECT WITH THE DATA FROM THE THREE OBJECTS
					PLMBomDlvrblDiscsnData bom_del_disc = new PLMBomDlvrblDiscsnData(bm_prt,tsk_dlv,msg);
					
					bom_del_disc.rowColor = lastColor;

					//ADD NEW BOM/DELIVERABLE/DISCUSSION TO THE LIST
					bom_del_disc_list.add(bom_del_disc);
					
					bomDelvrblCntr++;
					
				}
				
			}
				
			//AFTER LOOPING ALL BOM/DELIVERABLES CHECK FOR MESSAGES STILL ON THE LIST AND
			//ADD THEM TO THE BOM/DELIVERABLES/DISCUSSIONS SETTING BOM PART AND TASK DELIVERABLE
			//AS BLANKS FOR EACH MESSAGE
			while (bomDelvrblCntr < msgs.size()){
				
				PLMBomDlvrblDiscsnData bom_del_disc = new PLMBomDlvrblDiscsnData(
																	new PLMBomSpecPartData(null,null,null,null,null,null,null),
																	new PLMTaskDlvrblData(null,null,null,null,null,null,null,null,null,null,null,null,null),
																	msgs.get(bomDelvrblCntr)
																	);
				bom_del_disc.rowColor = lastColor;
				
				bom_del_disc_list.add(bom_del_disc);
				
				bomDelvrblCntr++;
				
			}				
			
			//SET COLOR
			lastColor = (lastColor.equals("whiteColor"))? "tanColor" : "whiteColor";

			
			//ADD BOM/DELIVERABLES/DISCUSSIONS LIST TO THE LIST
			mlisBmDlvrblsDscssns.add(new PLMMLIBomDlvrblDiscusnData(index,mli,bom_del_disc_list));
			
			index++;
		}
		
		return mlisBmDlvrblsDscssns;
	}
	
	
	
	
	// --------------------------------- CREATE TASKS VS ROUTES VIEW ------------------------------------------
	private List<PLMTaskRouteData> createTaskRoutesTable(String projectNameLcl){		
		
		//GET OWNERS NAMES FOR EACH TASK-ROUTE
		HashMap<String, String> mapOwnerNames = new LinkedHashMap<String, String>();
		
		List<PLMRouteTaskOwnerData> routeTaskOwners = dlvrblRptService.routeTaskOwners(projectNameLcl);
		StringBuffer namesBfr = new StringBuffer();
		for (PLMRouteTaskOwnerData owner : routeTaskOwners){
			String routeId = owner.getId();
			if (!mapOwnerNames.containsKey(routeId)){
				String names = owner.getOwnerName();
				mapOwnerNames.put(routeId, names);
			} else {
				//String names = mapOwnerNames.get(routeId);
				namesBfr = namesBfr.append("; ").append(owner.getOwnerName());
				//names += "; " + owner.getOwnerName();
				mapOwnerNames.put(routeId, namesBfr.toString());
			}
		}
		
		
		//GET TASKS-ROUTES AND ASSIGN EACH ONE THEIR OWNER AND COLOR
		
		 List<PLMTaskRouteData> tasks_routesData = dlvrblRptService.tasks_routes(projectNameLcl);
		
		for (PLMTaskRouteData task_route : tasks_routesData){
			String routeId = task_route.getRouteId();
			
			if (mapOwnerNames.containsKey(routeId)){
				task_route.setRouteTaskOwner(mapOwnerNames.get(routeId));
			}
			
			String taskState = task_route.getTaskState();
			
			if (taskState.equals("Create") || taskState.equals("Assign") || taskState.equals("Active")){
				task_route.setRowColor("redColor");
			} else if (taskState.equals("Review")) {
				task_route.setRowColor("yellowColor");
			} else if (taskState.equals("Complete")){
				task_route.setRowColor("greenColor");
			}
		}
		
		//ORDER TASKS-ROUTES BY TASK NAME/ROUTE NAME
		Collections.sort(tasks_routesData, new SortTaskRoutes());
		
		return tasks_routesData;

	}
	
	/**
	 * 
	 * class to sort list of object of type PLMTaskDlvrblData.
	 * 
	 */
	private static class SortTaskRoutes implements Comparator<PLMTaskRouteData>, Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		 public int compare(PLMTaskRouteData one, PLMTaskRouteData other) {
		    	
		    	int comparison = 0;
		    	
		    	String oneTaskName = one.getTaskName();
		    	String otherTaskName = other.getTaskName();
		    	String oneRouteName = one.getRouteName();
		    	String otherRouteName = other.getRouteName();
		    	
		    	if (oneTaskName != null && otherTaskName != null) {
		    		comparison = oneTaskName.compareTo(otherTaskName);
		    	} else if (oneRouteName != null && otherRouteName != null) {
		    		comparison = oneRouteName.compareTo(otherRouteName);
		    	} else if (oneTaskName != null && otherRouteName != null) {
		    		comparison = oneTaskName.compareTo(otherRouteName);
		    	} else if (oneRouteName != null && otherTaskName != null){
		    		comparison = oneRouteName.compareTo(otherTaskName);
		    	}
		    	
		    	return comparison;
		    }
	}
	
	// PUBLIC METHODS *********************************************************	
	
	public String loadDeliverableReview(){
		try {
			commonMB.insertCannedRptRecordHitInfo("GT CMU Deliverables Tool");
		} catch (PLMCommonException ex) {
			logger.error("Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		clearProject();
		String fwdFlag = "deliverablesReview";
		return fwdFlag;
	}

	/*public void show_hide(ActionEvent event) {
		Map<String, Object> attributes = event.getComponent().getAttributes();
		String key = "javax.faces.webapp.COMPONENT_IDS";
		List components = (ArrayList)attributes.get(key);
		String componentId = null;
		
		for (Object component : components) {
			if (component.toString().endsWith("Index")) {
				componentId = component.toString();
				break;
			}
		}
		
		UIParameter component = (UIParameter)event.getComponent().findComponent(componentId);
		int index = Integer.parseInt(component.getValue().toString());
		
		if (mlisBomDeliverablesDiscussions != null && !mlisBomDeliverablesDiscussions.isEmpty() && index >= 0) {
			boolean isDisplayed = mlisBomDeliverablesDiscussions.get(index).isDisplayed(); 
			mlisBomDeliverablesDiscussions.get(index).setDisplayed(!isDisplayed);
		}
	}*/
	
	public void show_hide(ActionEvent event) {
		logger.info("Inside show_hide method................");
		
		int indexNew = dataTable.getRowIndex();
		logger.info("Clicked Row==========="+dataTable.getRowIndex());
		
		
		if (mlisBomDeliverablesDiscussions != null && !mlisBomDeliverablesDiscussions.isEmpty() && indexNew >= 0) {
			boolean isDisplayed = mlisBomDeliverablesDiscussions.get(indexNew).isDisplayed(); 
			mlisBomDeliverablesDiscussions.get(indexNew).setDisplayed(!isDisplayed);
		}
	}
	
	
	/**
	 * Creates the report
	 */
	public void report() {
		this.bom_deliverables = new ArrayList<PLMBomDlvrblData>();
		this.mlisBomDeliverablesDiscussions = new ArrayList<PLMMLIBomDlvrblDiscusnData>();
		this.tasks_routes = new ArrayList<PLMTaskRouteData>();
		this.sales_orders = new ArrayList<PLMSalesOrderData>();
		this.prs = new ArrayList<PLMPRSData>();
		this.prs_routes = new ArrayList<PLMPRSRouteData>();
		this.prs_route_tasks = new ArrayList<PLMPRSTaskRouteData>();
		projFlag=true;
		String prj = this.validateString(projectName);
		if (prj.equals("") || prj.equals(PLMConstants.DELIVERABLE_ERROR)) {
			return;
		}		
		
		//EXTRACT IP_ADDRESS
		//this.userName = getIpAddress();
		
		DateFormat df = new SimpleDateFormat("mm:ss.ms");
		long startTime = new Date().getTime();
		
		//EXTRACT PROJECT GRAL DATA
		Map<String, String> project = dlvrblRptService.project_info(projectName);
		this.projectOwner = project.get("PROJECT_OWNER");
		this.ownerName = project.get("OWNER_NAME");
		
		//SET LIST VALUES
		this.prs = this.createPRS(projectName);
		if (!this.prs.isEmpty()){
			String prsId = prs.get(0).getId();
			this.bom_deliverables = createBomDeliverablesTable(projectName, prsId);
			this.mlisBomDeliverablesDiscussions = createMLIBomDeliverablesDiscussionsTable(projectName, bom_deliverables);
			this.tasks_routes = createTaskRoutesTable(projectName);
			this.sales_orders = dlvrblRptService.sales_orders(projectName);
			
			this.prs_routes = dlvrblRptService.prs_routes(projectName);
			this.prs_route_tasks = new ArrayList<PLMPRSTaskRouteData>();
			if (prs_routes != null && !prs_routes.isEmpty()){
				
				String prsRouteIDs = "";
				StringBuffer prsRtsIds = new StringBuffer();
				char commaChar = ',';
				for (PLMPRSRouteData route : prs_routes)
					//prsRouteIDs += "'"+route.getId()+"',";
					prsRtsIds = prsRtsIds.append("'").append(route.getId()).append("',");
					
				
				prsRouteIDs = prsRtsIds.substring(0, prsRtsIds.toString().lastIndexOf(commaChar));
				
				List<PLMPRSTaskRouteData> tasks = dlvrblRptService.prs_route_tasks(prsRouteIDs);
					
				if (tasks != null){ 
					for (PLMPRSTaskRouteData task : tasks){
						for (PLMPRSRouteData route : prs_routes){
							if (task.getRouteName().equals(route.getName())){
								task.setColor(route.getColor());
								break;
							}
						}
					}
					this.prs_route_tasks.addAll(tasks);
				}
			}
			
			long endTime = new Date().getTime();
			
			Date reportTime = new Date();
			reportTime.setTime(endTime-startTime);
			//String strReportTime = df.format(reportTime);
			
			logger.info("report(): Start time: " + df.format(startTime));			
			logger.info("report(): End time: " + df.format(endTime));
			logger.info("report(): Report time: " + df.format(reportTime));
			
			logger.info("report(): done!");
		} else {
			logger.info("Error: PLMPRSData is empty");
		}
	}
	
	/**
	 * Clear Project
	 */
	public void clearProject(){
		this.projectName = "";
		this.bom_deliverables = null;
		this.mlisBomDeliverablesDiscussions = null;
	    this.prs = new ArrayList<PLMPRSData>();		//this.prs = null;
		this.sales_orders = null;
		this.tasks_routes = null;
		this.prs_routes=null;
		this.prs_route_tasks=null;
		projFlag=false;
	}
	
	/**
	 * Exports to Excel
	 */
	public void export() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		PLMExcelRptUtil excelUtil = new PLMExcelRptUtil();
		
		try {
			//facesContext = FacesContext.getCurrentInstance();
			
			StringBuffer excelFileName = new StringBuffer("GT CMU Deliverables-")
			.append(projectName)
			.append(".xls");
			
			
			HttpServletResponse response = 
				(HttpServletResponse)facesContext.getExternalContext().getResponse();
			
			response.setContentType("application/vnd.ms-excel");
			
			response.setHeader("Content-disposition", 
					"attachment; filename="+excelFileName.toString());
			
			OutputStream outputStream = response.getOutputStream();
			
			excelUtil.createWorkbook(mlisBomDeliverablesDiscussions, tasks_routes, bom_deliverables, sales_orders, prs, prs_routes, prs_route_tasks).write(outputStream);
			
			outputStream.flush();
			
			outputStream.close();
			
		} catch (IOException ioex) {
			logger.info("Export IOException: " + ioex.toString());
		} finally {
			facesContext.responseComplete();
		}
		
		//INSERT LOG RECORD
		//insertLog("Exporting to Excel");
	}
	
	/**
	 * Exports to Excel
	 */
	public void export2Excel() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		PLMExcelRptUtil excelUtil = new PLMExcelRptUtil();
		
		try {
			//facesContext = FacesContext.getCurrentInstance();
			
			HttpServletResponse response = 
				(HttpServletResponse)facesContext.getExternalContext().getResponse();
			
			response.setContentType("application/vnd.ms-excel");
			
			response.setHeader("Content-disposition", 
					"attachment; filename=Results.xls");
			
			OutputStream outputStream = response.getOutputStream();
			
			excelUtil.createLogWorkbook(log_history).write(outputStream);
			
			outputStream.flush();
			
			outputStream.close();
			
		} catch (IOException ioex) {
			logger.info("Export IOException: " + ioex.toString());
		} finally {
			facesContext.responseComplete();
		}
		
		//INSERT LOG RECORD
		//insertLog("Exporting to Excel");
	}
	
	// ACCESSOR METHODS *******************************************************
		
	/**
	 * @return Returns the projectName.
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName The projectName to set.
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName.toUpperCase(Locale.getDefault());
	}

	public String getProjectOwner() {
		return projectOwner;
	}


	public void setProjectOwner(String projectOwner) {
		this.projectOwner = projectOwner;
	}


	public String getOwnerName() {
		return ownerName;
	}


	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

		
	/************************************** BANNERS PROCEDURES ****************************/
	
	/** 
	 * Returns the banner for an ArrayList
	 * 
	 * @return banner (String)
	 */
	public String getBanner(int objectSize, String objectName) {
		if (projFlag) {
			if (objectSize!=0) {
				return objectSize + " " + objectName + " found";
			} else {
				return "No " + objectName + " found for the entered search criteria.";
			}
		} else {
			return "";
		}
	}
	
	/**
	 * Returns the Banner Style for an ArrayList
	 * 
	 * @return bannerStyle (String)
	 */
	public String getBannerStyle(int objectsize) {
		if (projFlag) {
			if (objectsize!=0) {
				return "navy";
			} else {
				return "darkRed";
			}
		} else {
			return "";
		}
	}
	
	
	
	/********************************* BANNERS ************************************/

	/**
	 * Returns the banner for the ProjectName
	 * 
	 * @return bannerProjectName (String)
	 */
	public String getBannerProjectName() {
		if (projectName!=null && !projectName.equals("") && projFlag) {
			String prj = this.validateString(projectName);
			logger.info("Checking Prj Value in getBannerProjectName "+prj);
			if (prj.equals(PLMConstants.DELIVERABLE_ERROR) || prj.isEmpty()){
				return "Invalid Input (Please input a single Project Number to search. Format must be FnnnnGnn)";
			} else if (prs.isEmpty() || bom_deliverables == null){
				return "ERROR!!! (Check if PLMPRSData, BOM and Schedule are created on PLM)";
			} else {
				return "";
			}
		} else {
			return "";
		}
	}
	
	/**
	 * Returns the banner for mlisBomDeliverablesDiscussions
	 * 
	 * @return bannerMlisBomDeliverablesDiscussions (String)
	 */
	public String getBannerMlisBomDeliverablesDiscussions(){
		int mlibomDeliver;
		if(mlisBomDeliverablesDiscussions !=null && mlisBomDeliverablesDiscussions.size()>0){
			mlibomDeliver=mlisBomDeliverablesDiscussions.size();
		}
		else{
			mlibomDeliver=0;
		}
		return getBanner(mlibomDeliver, "MLIs");
	}
	
	/**
	 * Returns the banner for bom_deliverables
	 * 
	 * @return bannerBmDlvrbls (String)
	 */
	public String getBannerBmDlvrbls() {
		int bomdeliverables;
		if(bom_deliverables !=null && bom_deliverables.size()>0){
			bomdeliverables=bom_deliverables.size();
		}
		else{
			bomdeliverables=0;
		}
		return getBanner(bomdeliverables, "Bom/Spec Parts - Tasks Deliverables");
	}
	
	/**
	 * Returns the banner for tasks_routes
	 * 
	 * @return bannerTsksRts (String)
	 */
	public String getBannerTsksRts() {
		int tasksroutes;
		if(tasks_routes !=null && tasks_routes.size()>0){
				tasksroutes=tasks_routes.size();
		}
		else{
			tasksroutes=0;
		}
		return getBanner(tasksroutes, "Tasks - Routes");
	}
	
	/** 
	 * Returns the banner for sales_order
	 * 
	 * @return bannerSlsOrdrs (String)
	 */
	public String getBannerSlsOrdrs() {
		int salesorders;
		if(sales_orders !=null && sales_orders.size()>0){
			salesorders=sales_orders.size();
		}
		else{
			salesorders=0;
		}
		return getBanner(salesorders, "Sales Orders");
	}
	

	/** 
	 * Returns the banner for prs
	 * 
	 * @return bannerPRS (String)
	 */
	public String getBannerPRS() {
		int prs1;
		if(prs !=null && prs.size()>0){
				prs1=prs.size();
		}
		else{
			prs1=0;
		}
		
		return getBanner(prs1, "PRS records");
	}
	
	/** 
	 * Returns the banner for PLMPRSData Routes
	 * 
	 * @return bannerPRSRoutes (String)
	 */
	public String getBannerPRSRoutes() {
		int prsroutes;
		if(prs_routes !=null && prs_routes.size()>0){
			prsroutes=prs_routes.size();
		}
		else{
			prsroutes=0;
		}
		return getBanner(prsroutes, "PRS Routes");
	}	

	/** 
	 * Returns the banner for PLMPRSData Route Tasks
	 * 
	 * @return bannerPRSRouteTasks (String)
	 */
	public String getBannerPRSRouteTasks() {
		int prsroute_tasks;
		if(prs_route_tasks !=null && prs_route_tasks.size()>0){
			prsroute_tasks=prs_route_tasks.size();
		}
		else{
			prsroute_tasks=0;
		}
		return getBanner(prsroute_tasks, "PRS Route Tasks");
	}	
	
	
	/********************************* BANNERS STYLES ************************************/
	
	/**
	 * Returns the banner style for the projectName
	 * 
	 * @return bannerProjectNameStyle (String)
	 */
	public String getBannerProjectNameStyle() {
		if (projectName != null && !projectName.equals("")) {
			String prj = this.validateString(projectName);
			logger.info("Checking Prj Value in getBannerProjectNameStyle "+prj);
			if (prj.isEmpty() || prj.equals(PLMConstants.DELIVERABLE_ERROR) || prs.isEmpty() || bom_deliverables == null){
				return "darkRed";
			} else {
				return "navy";
			}
		} else {
			return "";
		}
	}	
	
	/**
	 * Returns the banner style for mlisBomDeliverablesDiscussions 
	 * 
	 * @return bannerMlisBomDeliverablesDiscussionsStyle (String)
	 */
	public String getBannerMlisBomDeliverablesDiscussionsStyle() {
		int mlibomDeliver;
		if(mlisBomDeliverablesDiscussions !=null && mlisBomDeliverablesDiscussions.size()>0){
				mlibomDeliver=mlisBomDeliverablesDiscussions.size();
		}
		else{
			mlibomDeliver=0;
		}
		return getBannerStyle(mlibomDeliver);
	}

	/**
	 * Returns the banner style for bom_deliverables 
	 * 
	 * @return bannerBmDlvrblsStyle (String)
	 */
	public String getBannerBmDlvrblsStyle() {
		int bomdeliverables;
		if(bom_deliverables !=null && bom_deliverables.size()>0){
			 bomdeliverables=bom_deliverables.size();
		}
		else{
			bomdeliverables=0;
		}
		
		return getBannerStyle(bomdeliverables);
	}

	/**
	 * Returns the banner style for tasks_routes
	 * 
	 * @return bannerTsksTrsStyle (String)
	 */
	public String getBannerTsksRtsStyle() {
		int tasksroutes;
		if(tasks_routes !=null && tasks_routes.size()>0){
			tasksroutes=tasks_routes.size();
		}
		else{
			tasksroutes=0;
		}
		return getBannerStyle(tasksroutes);
	}

	/**
	 * Returns the banner style for sales_orders
	 * 
	 * @return bannerSlsOrdrsStyle (String)
	 */
	public String getBannerSlsOrdrsStyle() {
		int salesorders;
		if(sales_orders !=null && sales_orders.size()>0){
			salesorders=sales_orders.size();
		}
		else{
			salesorders=0;
		}
		return getBannerStyle(salesorders);
	}

	/**
	 * Returns the banner style for prs
	 * 
	 * @return bannerPRSStyle (String)
	 */
	public String getBannerPRSStyle() {
		int prs1;
		if(prs !=null && prs.size()>0){
			prs1=prs.size();
		}
		else{
			prs1=0;
		}
		return getBannerStyle(prs1);
	}

	/**
	 * Returns the banner style for PLMPRSData Routes
	 * 
	 * @return bannerPRSRoutesStyle (String)
	 */
	public String getBannerPRSRoutesStyle() {
		int prsroutes;
		if(prs_routes !=null && prs_routes.size()>0){
			prsroutes=prs_routes.size();
		}
		else{
			prsroutes=0;
		}
		return getBannerStyle(prsroutes);
	}
	
	/**
	 * Returns the banner style for PLMPRSData Route Tasks
	 * 
	 * @return bannerPRSRouteTasksStyle (String)
	 */
	public String getBannerPRSRouteTasksStyle() {
		int prsroutetasks;
		if(prs_route_tasks !=null && prs_route_tasks.size()>0){
			prsroutetasks=prs_route_tasks.size();
		}
		else{
			prsroutetasks=0;
		}
		return getBannerStyle(prsroutetasks);
	}

	
	/**
	 * @return the dlvrblRptService
	 */
	public PLMDlvrblRptServiceIfc getDlvrblRptService() {
		return dlvrblRptService;
	}


	/**
	 * @param dlvrblRptService the dlvrblRptService to set
	 */
	public void setDlvrblRptService(PLMDlvrblRptServiceIfc dlvrblRptService) {
		this.dlvrblRptService = dlvrblRptService;
	}

	/**
	 * @return the prs
	 */
	public List<PLMPRSData> getPrs() {
		return prs;
	}


	/**
	 * @param prs the prs to set
	 */
	public void setPrs(List<PLMPRSData> prs) {
		this.prs = prs;
	}


	/**
	 * @return the mlisBomDeliverablesDiscussions
	 */
	public List<PLMMLIBomDlvrblDiscusnData> getMlisBomDeliverablesDiscussions() {
		return mlisBomDeliverablesDiscussions;
	}


	/**
	 * @param mlisBomDeliverablesDiscussions the mlisBomDeliverablesDiscussions to set
	 */
	public void setMlisBomDeliverablesDiscussions(
			List<PLMMLIBomDlvrblDiscusnData> mlisBomDeliverablesDiscussions) {
		this.mlisBomDeliverablesDiscussions = mlisBomDeliverablesDiscussions;
	}


	/**
	 * @return the bom_deliverables
	 */
	public List<PLMBomDlvrblData> getBom_deliverables() {
		return bom_deliverables;
	}


	/**
	 * @param bom_deliverables the bom_deliverables to set
	 */
	public void setBom_deliverables(List<PLMBomDlvrblData> bom_deliverables) {
		this.bom_deliverables = bom_deliverables;
	}


	/**
	 * @return the tasks_routes
	 */
	public List<PLMTaskRouteData> getTasks_routes() {
		return tasks_routes;
	}


	/**
	 * @param tasks_routes the tasks_routes to set
	 */
	public void setTasks_routes(List<PLMTaskRouteData> tasks_routes) {
		this.tasks_routes = tasks_routes;
	}


	/**
	 * @return the sales_orders
	 */
	public List<PLMSalesOrderData> getSales_orders() {
		return sales_orders;
	}


	/**
	 * @param sales_orders the sales_orders to set
	 */
	public void setSales_orders(List<PLMSalesOrderData> sales_orders) {
		this.sales_orders = sales_orders;
	}


	/**
	 * @return the log_history
	 */
	public List<PLMLogData> getLog_history() {
		return log_history;
	}


	/**
	 * @param log_history the log_history to set
	 */
	public void setLog_history(List<PLMLogData> log_history) {
		this.log_history = log_history;
	}


	/**
	 * @return the prs_routes
	 */
	public List<PLMPRSRouteData> getPrs_routes() {
		return prs_routes;
	}


	/**
	 * @param prs_routes the prs_routes to set
	 */
	public void setPrs_routes(List<PLMPRSRouteData> prs_routes) {
		this.prs_routes = prs_routes;
	}


	/**
	 * @return the prs_route_tasks
	 */
	public List<PLMPRSTaskRouteData> getPrs_route_tasks() {
		return prs_route_tasks;
	}


	/**
	 * @param prs_route_tasks the prs_route_tasks to set
	 */
	public void setPrs_route_tasks(List<PLMPRSTaskRouteData> prs_route_tasks) {
		this.prs_route_tasks = prs_route_tasks;
	}
	
	/**
	 * @return the dataTable
	 */
	public HtmlDataTable getDataTable() {
		return dataTable;
	}


	/**
	 * @param dataTable the dataTable to set
	 */
	public void setDataTable(HtmlDataTable dataTable) {
		this.dataTable = dataTable;
	}


	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}


	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	
}
