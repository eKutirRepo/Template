/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBomHealthData.java
 * @Creation date: 15-June-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.data;

public class PLMBomHealthData {
	/**
	  * Holds the mlno
	  */
	private String mlno;
	/**
	  * Holds the defectsbypartnumber
	  */
	private int defectsbypartnumber;
	/**
	  * Holds the defectsbyqpartnumber
	  */
	private int defectsbyqpartnumber;
	/**
	  * Holds the defectsbyppartnumber
	  */
	private int defectsbyppartnumber;
	/**
	  * Holds the opportunites
	  */
	private int opportunites;
	/**
	  * Holds the parentitemnumber
	  */
	private String parentitemnumber;
	/**
	  * Holds the wasitemnumber
	  */
	private String wasitemnumber;
	/**
	  * Holds the isitemnumber
	  */
	private String isitemnumber;
	/**
	  * Holds the isitemquantity
	  */
	private String isitemquantity;
	/**
	  * Holds the wasitemquantity
	  */
	private String wasitemquantity;
	/**
	  * Holds the changetype
	  */
	private String changetype;
	/**
	  * Holds the dcinumber
	  */
	private String dcinumber;
	/**
	  * Holds the actionflag
	  */
	private String actionflag;
	/**
	  * Holds the newitemindicator
	  */
	private String newitemindicator;
	/**
	  * Holds the icnnumber
	  */
	private String icnnumber;
	/**
	  * Holds the rootcause
	  */
	private String rootcause;
	/**
	  * Holds the ordernumber
	  */
	private String ordernumber;
	
	
	/**
	 * @return the mlno
	 */
	public String getMlno() {
		return mlno;
	}
	/**
	 * @param mlno the mlno to set
	 */
	public void setMlno(String mlno) {
		this.mlno = mlno;
	}
	/**
	 * @return the defectsbypartnumber
	 */
	public int getDefectsbypartnumber() {
		return defectsbypartnumber;
	}
	/**
	 * @param defectsbypartnumber the defectsbypartnumber to set
	 */
	public void setDefectsbypartnumber(int defectsbypartnumber) {
		this.defectsbypartnumber = defectsbypartnumber;
	}
	/**
	 * @return the defectsbyqpartnumber
	 */
	public int getDefectsbyqpartnumber() {
		return defectsbyqpartnumber;
	}
	/**
	 * @param defectsbyqpartnumber the defectsbyqpartnumber to set
	 */
	public void setDefectsbyqpartnumber(int defectsbyqpartnumber) {
		this.defectsbyqpartnumber = defectsbyqpartnumber;
	}
	/**
	 * @return the defectsbyppartnumber
	 */
	public int getDefectsbyppartnumber() {
		return defectsbyppartnumber;
	}
	/**
	 * @param defectsbyppartnumber the defectsbyppartnumber to set
	 */
	public void setDefectsbyppartnumber(int defectsbyppartnumber) {
		this.defectsbyppartnumber = defectsbyppartnumber;
	}
	/**
	 * @return the opportunites
	 */
	public int getOpportunites() {
		return opportunites;
	}
	/**
	 * @param opportunites the opportunites to set
	 */
	public void setOpportunites(int opportunites) {
		this.opportunites = opportunites;
	}
	/**
	 * @return the parentitemnumber
	 */
	public String getParentitemnumber() {
		return parentitemnumber;
	}
	/**
	 * @param parentitemnumber the parentitemnumber to set
	 */
	public void setParentitemnumber(String parentitemnumber) {
		this.parentitemnumber = parentitemnumber;
	}
	/**
	 * @return the wasitemnumber
	 */
	public String getWasitemnumber() {
		return wasitemnumber;
	}
	/**
	 * @param wasitemnumber the wasitemnumber to set
	 */
	public void setWasitemnumber(String wasitemnumber) {
		this.wasitemnumber = wasitemnumber;
	}
	/**
	 * @return the isitemnumber
	 */
	public String getIsitemnumber() {
		return isitemnumber;
	}
	/**
	 * @param isitemnumber the isitemnumber to set
	 */
	public void setIsitemnumber(String isitemnumber) {
		this.isitemnumber = isitemnumber;
	}
	/**
	 * @return the isitemquantity
	 */
	public String getIsitemquantity() {
		return isitemquantity;
	}
	/**
	 * @param isitemquantity the isitemquantity to set
	 */
	public void setIsitemquantity(String isitemquantity) {
		this.isitemquantity = isitemquantity;
	}
	/**
	 * @return the wasitemquantity
	 */
	public String getWasitemquantity() {
		return wasitemquantity;
	}
	/**
	 * @param wasitemquantity the wasitemquantity to set
	 */
	public void setWasitemquantity(String wasitemquantity) {
		this.wasitemquantity = wasitemquantity;
	}
	/**
	 * @return the changetype
	 */
	public String getChangetype() {
		return changetype;
	}
	/**
	 * @param changetype the changetype to set
	 */
	public void setChangetype(String changetype) {
		this.changetype = changetype;
	}
	/**
	 * @return the dcinumber
	 */
	public String getDcinumber() {
		return dcinumber;
	}
	/**
	 * @param dcinumber the dcinumber to set
	 */
	public void setDcinumber(String dcinumber) {
		this.dcinumber = dcinumber;
	}
	/**
	 * @return the actionflag
	 */
	public String getActionflag() {
		return actionflag;
	}
	/**
	 * @param actionflag the actionflag to set
	 */
	public void setActionflag(String actionflag) {
		this.actionflag = actionflag;
	}
	/**
	 * @return the newitemindicator
	 */
	public String getNewitemindicator() {
		return newitemindicator;
	}
	/**
	 * @param newitemindicator the newitemindicator to set
	 */
	public void setNewitemindicator(String newitemindicator) {
		this.newitemindicator = newitemindicator;
	}
	/**
	 * @return the icnnumber
	 */
	public String getIcnnumber() {
		return icnnumber;
	}
	/**
	 * @param icnnumber the icnnumber to set
	 */
	public void setIcnnumber(String icnnumber) {
		this.icnnumber = icnnumber;
	}
	/**
	 * @return the rootcause
	 */
	public String getRootcause() {
		return rootcause;
	}
	/**
	 * @param rootcause the rootcause to set
	 */
	public void setRootcause(String rootcause) {
		this.rootcause = rootcause;
	}
	/**
	 * @return the ordernumber
	 */
	public String getOrdernumber() {
		return ordernumber;
	}
	/**
	 * @param ordernumber the ordernumber to set
	 */
	public void setOrdernumber(String ordernumber) {
		this.ordernumber = ordernumber;
	}

}