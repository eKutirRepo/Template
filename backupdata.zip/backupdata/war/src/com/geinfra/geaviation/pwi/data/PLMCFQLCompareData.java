/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCFQLCompareData.java
 * @Creation date: 06-Sept-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.ArrayList;
import java.util.List;

public class PLMCFQLCompareData {
	/**
	 * Holds hwPrdctNm
	 */
	private String hwPrdctNm;
	/**
	 * Holds revNm
	 */
	private String revNm;
	/**
	 * Holds level
	 */
	private String level;
	/**
	 * Holds displayNm
	 */
	private String displayNm;
	/**
	 * Holds confOption
	 */
	private String confOption;
	/**
	 * Holds rev
	 */
	private String rev;
	/**
	 * Holds pegasusCode
	 */
	private String pegasusCode;
	/**
	 * Holds marketingNm
	 */
	private String marketingNm;
	/**
	 * Holds hpMarketingNm
	 */
	private String hpMarketingNm;
	/**
	 * Holds chDisplayNm
	 */
	private String chDisplayNm;
	/**
	 * Holds mfChapter
	 */
	private String mfChapter;
	
	/**
	 * Holds revChapter
	 */
	private String revChapter;
	/**
	 * Holds subType
	 */
	private String subType;
	/**
	 * Holds defaultType
	 */
	private String defaultType;
	/**
	 * Holds sequenceNum
	 */
	private String sequenceNum;
	/**
	 * Holds available
	 */
	private boolean available;

	/**
	 * Holds mktNm
	 */
	private List<String> mktNm;
	
	/**
	 * Holds typeList
	 */
	private List<PLMCFQLCompareData> typeList = new ArrayList<PLMCFQLCompareData>();
	/**
	 * Holds objType
	 */
	private String objType;
	/**
	 * Holds productLine
	 */
	private String productLine;
	/**
	 * Holds model
	 */
	private String model;
	/**
	 * Holds productType
	 */
	private String productType;
	/**
	 * Holds hpState
	 */
	private String hpState;
	/**
	 * Holds pcName
	 */
	private String pcName;
	/**
	 * Holds pcChkList
	 */
	private String[] pcChkList;
	/**
	 * Holds crValList
	 */
	private String[] crValList;
	/**
	 * Holds crName
	 */
	private String crName;
	/**
	 * Holds visitFlag
	 */
	private boolean visitFlag;

	/**
	 * @return the hwPrdctNm
	 */
	public String getHwPrdctNm() {
		return hwPrdctNm;
	}

	/**
	 * @param hwPrdctNm the hwPrdctNm to set
	 */
	public void setHwPrdctNm(String hwPrdctNm) {
		this.hwPrdctNm = hwPrdctNm;
	}

	/**
	 * @return the revNm
	 */
	public String getRevNm() {
		return revNm;
	}

	/**
	 * @param revNm the revNm to set
	 */
	public void setRevNm(String revNm) {
		this.revNm = revNm;
	}

	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}

	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}

	/**
	 * @return the displayNm
	 */
	public String getDisplayNm() {
		return displayNm;
	}

	/**
	 * @param displayNm the displayNm to set
	 */
	public void setDisplayNm(String displayNm) {
		this.displayNm = displayNm;
	}

	/**
	 * @return the confOption
	 */
	public String getConfOption() {
		return confOption;
	}

	/**
	 * @param confOption the confOption to set
	 */
	public void setConfOption(String confOption) {
		this.confOption = confOption;
	}

	/**
	 * @return the rev
	 */
	public String getRev() {
		return rev;
	}

	/**
	 * @param rev the rev to set
	 */
	public void setRev(String rev) {
		this.rev = rev;
	}

	/**
	 * @return the pegasusCode
	 */
	public String getPegasusCode() {
		return pegasusCode;
	}

	/**
	 * @param pegasusCode the pegasusCode to set
	 */
	public void setPegasusCode(String pegasusCode) {
		this.pegasusCode = pegasusCode;
	}

	/**
	 * @return the marketingNm
	 */
	public String getMarketingNm() {
		return marketingNm;
	}

	/**
	 * @param marketingNm the marketingNm to set
	 */
	public void setMarketingNm(String marketingNm) {
		this.marketingNm = marketingNm;
	}

	/**
	 * @return the hpMarketingNm
	 */
	public String getHpMarketingNm() {
		return hpMarketingNm;
	}

	/**
	 * @param hpMarketingNm the hpMarketingNm to set
	 */
	public void setHpMarketingNm(String hpMarketingNm) {
		this.hpMarketingNm = hpMarketingNm;
	}

	/**
	 * @return the chDisplayNm
	 */
	public String getChDisplayNm() {
		return chDisplayNm;
	}

	/**
	 * @param chDisplayNm the chDisplayNm to set
	 */
	public void setChDisplayNm(String chDisplayNm) {
		this.chDisplayNm = chDisplayNm;
	}

	/**
	 * @return the mfChapter
	 */
	public String getMfChapter() {
		return mfChapter;
	}

	/**
	 * @param mfChapter the mfChapter to set
	 */
	public void setMfChapter(String mfChapter) {
		this.mfChapter = mfChapter;
	}

	/**
	 * @return the revChapter
	 */
	public String getRevChapter() {
		return revChapter;
	}

	/**
	 * @param revChapter the revChapter to set
	 */
	public void setRevChapter(String revChapter) {
		this.revChapter = revChapter;
	}

	/**
	 * @return the subType
	 */
	public String getSubType() {
		return subType;
	}

	/**
	 * @param subType the subType to set
	 */
	public void setSubType(String subType) {
		this.subType = subType;
	}

	/**
	 * @return the defaultType
	 */
	public String getDefaultType() {
		return defaultType;
	}

	/**
	 * @param defaultType the defaultType to set
	 */
	public void setDefaultType(String defaultType) {
		this.defaultType = defaultType;
	}

	/**
	 * @return the sequenceNum
	 */
	public String getSequenceNum() {
		return sequenceNum;
	}

	/**
	 * @param sequenceNum the sequenceNum to set
	 */
	public void setSequenceNum(String sequenceNum) {
		this.sequenceNum = sequenceNum;
	}
	
	/**
	 * @return the available
	 */
	public boolean isAvailable() {
		return available;
	}

	/**
	 * @param available the available to set
	 */
	public void setAvailable(boolean available) {
		this.available = available;
	}

	/**
	 * @return the mktNm
	 */
	public List<String> getMktNm() {
		return mktNm;
	}

	/**
	 * @param mktNm the mktNm to set
	 */
	public void setMktNm(List<String> mktNm) {
		this.mktNm = mktNm;
	}

	/**
	 * @return the typeList
	 */
	public List<PLMCFQLCompareData> getTypeList() {
		return typeList;
	}

	/**
	 * @param typeList the typeList to set
	 */
	public void setTypeList(List<PLMCFQLCompareData> typeList) {
		this.typeList = typeList;
	}

	/**
	 * @return the objType
	 */
	public String getObjType() {
		return objType;
	}

	/**
	 * @param objType the objType to set
	 */
	public void setObjType(String objType) {
		this.objType = objType;
	}

	/**
	 * @return the visitFlag
	 */
	public boolean isVisitFlag() {
		return visitFlag;
	}

	/**
	 * @param visitFlag the visitFlag to set
	 */
	public void setVisitFlag(boolean visitFlag) {
		this.visitFlag = visitFlag;
	}

	/**
	 * @return
	 */
	public String getProductLine() {
		return productLine;
	}

	/**
	 * @param productLine
	 */
	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}

	/**
	 * @return
	 */
	public String getModel() {
		return model;
	}

	/**
	 * @param model
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * @return
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return
	 */
	public String getHpState() {
		return hpState;
	}

	/**
	 * @param hpState
	 */
	public void setHpState(String hpState) {
		this.hpState = hpState;
	}

	/**
	 * @return
	 */
	public String getPcName() {
		return pcName;
	}

	/**
	 * @param pcName
	 */
	public void setPcName(String pcName) {
		this.pcName = pcName;
	}

	/**
	 * @return
	 */
	public String getCrName() {
		return crName;
	}

	/**
	 * @param crName
	 */
	public void setCrName(String crName) {
		this.crName = crName;
	}

	/**
	 * @return
	 */
	public String[] getPcChkList() {
		return pcChkList;
	}

	/**
	 * @param pcChkList
	 */
	public void setPcChkList(String[] pcChkList) {
		this.pcChkList = pcChkList;
	}

	/**
	 * @return
	 */
	public String[] getCrValList() {
		return crValList;
	}

	/**
	 * @param crValList
	 */
	public void setCrValList(String[] crValList) {
		this.crValList = crValList;
	}
}
