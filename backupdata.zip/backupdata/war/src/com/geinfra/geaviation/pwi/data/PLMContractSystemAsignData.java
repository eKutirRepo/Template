package com.geinfra.geaviation.pwi.data;

import java.util.ArrayList;
import java.util.List;

public class PLMContractSystemAsignData {
	
	private String systemId;
	private String systemName;
	private String headerName;
	private String headerDesc;
	private String optionName;
	private String optionDesc;
	private String systemNames;
	private String gasStr;
	private String genStr;
	private String steamStr;
	private boolean isGas;
	private boolean isSteam;
	private boolean isGen;
	private List<String> selSysNameList = new ArrayList<String>();
	private List<String> selectedPrdctList = new ArrayList<String>();
	private List<String> sysNameList = new ArrayList<String>();
	
	private boolean sysUnAssigned;
	private boolean sysAssigned;
	
	

	public String getGasStr() {
		return gasStr;
	}


	public void setGasStr(String gasStr) {
		this.gasStr = gasStr;
	}


	public String getGenStr() {
		return genStr;
	}


	public void setGenStr(String genStr) {
		this.genStr = genStr;
	}


	public String getSteamStr() {
		return steamStr;
	}


	public void setSteamStr(String steamStr) {
		this.steamStr = steamStr;
	}

	public String getSystemId() {
		return systemId;
	}
	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	public String getHeaderName() {
		return headerName;
	}
	public void setHeaderName(String headerName) {
		this.headerName = headerName;
	}
	public String getHeaderDesc() {
		return headerDesc;
	}
	public void setHeaderDesc(String headerDesc) {
		this.headerDesc = headerDesc;
	}
	public String getOptionName() {
		return optionName;
	}
	public void setOptionName(String optionName) {
		this.optionName = optionName;
	}
	public String getOptionDesc() {
		return optionDesc;
	}
	public void setOptionDesc(String optionDesc) {
		this.optionDesc = optionDesc;
	}
	public String getSystemNames() {
		return systemNames;
	}
	public void setSystemNames(String systemNames) {
		this.systemNames = systemNames;
	}
	public boolean isGas() {
		return isGas;
	}
	public void setGas(boolean isGas) {
		this.isGas = isGas;
	}
	public boolean isSteam() {
		return isSteam;
	}
	public void setSteam(boolean isSteam) {
		this.isSteam = isSteam;
	}
	public boolean isGen() {
		return isGen;
	}
	public void setGen(boolean isGen) {
		this.isGen = isGen;
	}
	public List<String> getSelSysNameList() {
		return selSysNameList;
	}
	public void setSelSysNameList(List<String> selSysNameList) {
		this.selSysNameList = selSysNameList;
	}
	public List<String> getSelectedPrdctList() {
		return selectedPrdctList;
	}
	public void setSelectedPrdctList(List<String> selectedPrdctList) {
		this.selectedPrdctList = selectedPrdctList;
	}
	public boolean isSysUnAssigned() {
		return sysUnAssigned;
	}
	public void setSysUnAssigned(boolean sysUnAssigned) {
		this.sysUnAssigned = sysUnAssigned;
	}
	public boolean isSysAssigned() {
		return sysAssigned;
	}
	public void setSysAssigned(boolean sysAssigned) {
		this.sysAssigned = sysAssigned;
	}
	public List<String> getSysNameList() {
		return sysNameList;
	}
	public void setSysNameList(List<String> sysNameList) {
		this.sysNameList = sysNameList;
	}	
		
}
