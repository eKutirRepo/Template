package com.geinfra.geaviation.pwi.bean.helpers;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.model.TemplateVO;
import com.geinfra.geaviation.pwi.service.helpers.ExecutionOutputModelConfig;
import com.geinfra.geaviation.pwi.service.helpers.ExecutionOutputTuple;
import com.geinfra.geaviation.pwi.service.vo.ExecutionMode;
import com.geinfra.geaviation.pwi.service.vo.OutputType;

/**
 * 
 * Project : Product Lifecycle Management
 * Date Written : Sep 22, 2011 
 * Security : GE Confidential 
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : 
 * 
 * Revision Log Sep 22, 2011 | v1.0.
 * --------------------------------------------------------------
 */
public class ExecutionOutputViewConfig {
	private List<SelectItem> executionModes;
	private String selectedExecutionMode;
	private Map<String, List<SelectItem>> outputModePerExecutionMode;
	private Map<String, String> defaultOutputModePerExecutionMode;
	private String selectedOutputType;
	private Map<String, OutputType> outputTypeDecoder;
	private Map<String, TemplateVO> templateDecoder;

	public ExecutionOutputViewConfig(ExecutionOutputModelConfig config) {
		List<ExecutionOutputTuple> available = config.getAvailable();
		Map<ExecutionMode, ExecutionOutputTuple> defaults = config
				.getDefaults();
		ExecutionOutputTuple initial = config.getInitial();

		executionModes = ExecutionOutputViewUtil.getInstance()
				.getExecutionModes(available);
		selectedExecutionMode = ExecutionOutputViewUtil.getInstance()
				.getSelectedExecutionMode(initial);
		outputModePerExecutionMode = ExecutionOutputViewUtil.getInstance()
				.getOutputTypesPerExecutionMode(available);
		defaultOutputModePerExecutionMode = ExecutionOutputViewUtil
				.getInstance().getDefaultOutputTypePerExecutionMode(defaults);
		selectedOutputType = ExecutionOutputViewUtil.getInstance()
				.getSelectedOutputType(initial);
		outputTypeDecoder = ExecutionOutputViewUtil.getInstance()
				.getOutputTypeDecoder(available);
		templateDecoder = ExecutionOutputViewUtil.getInstance()
				.getTemplateDecoder(available);
	}

	public List<SelectItem> getExecutionModes() {
		return executionModes;
	}

	public String getSelectedExecutionMode() {
		return selectedExecutionMode;
	}

	public Map<String, List<SelectItem>> getOutputModePerExecutionMode() {
		return outputModePerExecutionMode;
	}

	public Map<String, String> getDefaultOutputModePerExecutionMode() {
		return defaultOutputModePerExecutionMode;
	}

	public String getSelectedOutputType() {
		return selectedOutputType;
	}

	public Map<String, OutputType> getOutputTypeDecoder() {
		return outputTypeDecoder;
	}

	public Map<String, TemplateVO> getTemplateDecoder() {
		return templateDecoder;
	}
}
