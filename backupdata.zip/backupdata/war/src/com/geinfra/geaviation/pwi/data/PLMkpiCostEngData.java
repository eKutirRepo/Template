/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMkpiCostEngData.java
 * @Creation date: 05-Nov-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMkpiCostEngData {
	/**
	 * Hold parentPart
	 */
	private String parentPart;
	/**
	 * Hold partLvl
	 */
	private String partLvl;
	/**
	 * Hold wasPart
	 */
	private String wasPart;
	/**
	 * Hold wasPartRev
	 */
	private String wasPartRev;
	/**
	 * Hold wasPartDesc
	 */
	private String wasPartDesc;
	/**
	 * Hold wasTargetCst
	 */
	private double wasTargetCst;
	/**
	 * Hold isPart
	 */
	private String isPart;
	/**
	 * Hold isPartRev
	 */
	private String isPartRev;
	/**
	 * Hold isPartDesc
	 */
	private String isPartDesc;
	/**
	 * Hold isTargetCst
	 */
	private double isTargetCst;
	/**
	 * Hold isTargetCst
	 */
	private boolean sumTargetFlag;
	/**
	 * Hold ecoecrname
	 */
	private String ecoEcrName;
	
	/**
	 * @return the parentPart
	 */
	public String getParentPart() {
		return parentPart;
	}
	/**
	 * @param parentPart the parentPart to set
	 */
	public void setParentPart(String parentPart) {
		this.parentPart = parentPart;
	}
	/**
	 * @return the partLvl
	 */
	public String getPartLvl() {
		return partLvl;
	}
	/**
	 * @param partLvl the partLvl to set
	 */
	public void setPartLvl(String partLvl) {
		this.partLvl = partLvl;
	}
	/**
	 * @return the wasPart
	 */
	public String getWasPart() {
		return wasPart;
	}
	/**
	 * @param wasPart the wasPart to set
	 */
	public void setWasPart(String wasPart) {
		this.wasPart = wasPart;
	}
	/**
	 * @return the wasPartRev
	 */
	public String getWasPartRev() {
		return wasPartRev;
	}
	/**
	 * @param wasPartRev the wasPartRev to set
	 */
	public void setWasPartRev(String wasPartRev) {
		this.wasPartRev = wasPartRev;
	}
	/**
	 * @return the wasPartDesc
	 */
	public String getWasPartDesc() {
		return wasPartDesc;
	}
	/**
	 * @param wasPartDesc the wasPartDesc to set
	 */
	public void setWasPartDesc(String wasPartDesc) {
		this.wasPartDesc = wasPartDesc;
	}
	/**
	 * @return the wasTargetCst
	 */
	public double getWasTargetCst() {
		return wasTargetCst;
	}
	/**
	 * @param wasTargetCst the wasTargetCst to set
	 */
	public void setWasTargetCst(double wasTargetCst) {
		this.wasTargetCst = wasTargetCst;
	}
	/**
	 * @return the isPart
	 */
	public String getIsPart() {
		return isPart;
	}
	/**
	 * @param isPart the isPart to set
	 */
	public void setIsPart(String isPart) {
		this.isPart = isPart;
	}
	/**
	 * @return the isPartRev
	 */
	public String getIsPartRev() {
		return isPartRev;
	}
	/**
	 * @param isPartRev the isPartRev to set
	 */
	public void setIsPartRev(String isPartRev) {
		this.isPartRev = isPartRev;
	}
	/**
	 * @return the isPartDesc
	 */
	public String getIsPartDesc() {
		return isPartDesc;
	}
	/**
	 * @param isPartDesc the isPartDesc to set
	 */
	public void setIsPartDesc(String isPartDesc) {
		this.isPartDesc = isPartDesc;
	}
	/**
	 * @return the isTargetCst
	 */
	public double getIsTargetCst() {
		return isTargetCst;
	}
	/**
	 * @param isTargetCst the isTargetCst to set
	 */
	public void setIsTargetCst(double isTargetCst) {
		this.isTargetCst = isTargetCst;
	}
	/**
	 * @return the sumTargetFlag
	 */
	public boolean isSumTargetFlag() {
		return sumTargetFlag;
	}
	/**
	 * @param sumTargetFlag the sumTargetFlag to set
	 */
	public void setSumTargetFlag(boolean sumTargetFlag) {
		this.sumTargetFlag = sumTargetFlag;
	}

	/**
	 * @return the ecoEcrName
	 */
	public String getEcoEcrName() {
		return ecoEcrName;
	}
	
	/**
	 * @param ecoEcrName the ecoEcrName to set
	 */
	public void setEcoEcrName(String ecoEcrName) {
		this.ecoEcrName = ecoEcrName;
	}
	
}
