/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMSecurityMatrixData.java
 * @Creation date: 17-Jul-2009
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

/**
 * ICMSecurityMatrixData is the Transfer/Value Object class for ICM
 * Administrator Menu.
 */
public class PLMSecurityMatrixData implements SQLData {
	/**
	 * The String sql_type
	 */
	private String sqlType = "PLMR_SCRTY_MTRX_OBJ";
	/**
	 * The int groupId
	 */
	private int groupId;
	/**
	 * The int screenId
	 */
	private int screenId;
	/**
	 * The int permissionId
	 */
	private int permissionId;
	/**
	 * The String accessInd
	 */
	private String accessInd;
	/**
	 * The String type
	 */
	private String type;
	/**
	 * The String access
	 */
	private String access;
	/**
	 * The boolean checkValue
	 */
	private boolean checkValue;
	/**
	 * The String outputValue
	 */
	private String outputValue;
	/**
	 * The boolean header
	 */
	private boolean header;
	/**
	 * The String displayValue
	 */
	private String displayValue;
	/**
	 * The int accessID
	 */
	private int accessID;
	/**
	 * The int permissionIdNew
	 */
	private int permissionIdNew;

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(String typea) {
		this.type = typea;
	}

	/**
	 * @return the access
	 */
	public String getAccess() {
		return access;
	}

	/**
	 * @param access
	 *            the access to set
	 */
	public void setAccess(String accessa) {
		this.access = accessa;
	}

	/**
	 * @return the checkValue
	 */
	public boolean isCheckValue() {
		return checkValue;
	}

	/**
	 * @param checkValue
	 *            the checkValue to set
	 */
	public void setCheckValue(boolean checkValuea) {
		this.checkValue = checkValuea;
	}

	/**
	 * @return the outputValue
	 */
	public String getOutputValue() {
		return outputValue;
	}

	/**
	 * @param outputValue
	 *            the outputValue to set
	 */
	public void setOutputValue(String outputValuea) {
		this.outputValue = outputValuea;
	}

	/**
	 * @return the header
	 */
	public boolean isHeader() {
		return header;
	}

	/**
	 * @param header
	 *            the header to set
	 */
	public void setHeader(boolean headera) {
		this.header = headera;
	}

	/**
	 * @return the displayValue
	 */
	public String getDisplayValue() {
		return displayValue;
	}

	/**
	 * @param displayValue
	 *            the displayValue to set
	 */
	public void setDisplayValue(String displayValuea) {
		this.displayValue = displayValuea;
	}

	/**
	 * @return the accessID
	 */
	public int getAccessID() {
		return accessID;
	}

	/**
	 * @param accessID
	 *            the accessID to set
	 */
	public void setAccessID(int accessIDa) {
		this.accessID = accessIDa;
	}

	/**
	 * @return the permissionIdNew
	 */
	public int getPermissionIdNew() {
		return permissionIdNew;
	}

	/**
	 * @param permissionIdNew
	 *            the permissionIdNew to set
	 */
	public void setPermissionIdNew(int permissionIDa) {
		this.permissionIdNew = permissionIDa;
	}

	/**
	 * @return the groupId
	 */
	public int getGroupId() {
		return groupId;
	}

	/**
	 * @param groupId
	 *            the groupId to set
	 */
	public void setGroupId(int groupIda) {
		this.groupId = groupIda;
	}

	/**
	 * @return the screenId
	 */
	public int getScreenId() {
		return screenId;
	}

	/**
	 * @param screenId
	 *            the screenId to set
	 */
	public void setScreenId(int screenIda) {
		this.screenId = screenIda;
	}

	/**
	 * @return the permissionId
	 */
	public int getPermissionId() {
		return permissionId;
	}

	/**
	 * @param permissionId
	 *            the permissionId to set
	 */
	public void setPermissionId(int permissionIda) {
		this.permissionId = permissionIda;
	}

	/**
	 * @return the accessInd
	 */
	public String getAccessInd() {
		return accessInd;
	}

	/**
	 * @param accessInd
	 *            the accessInd to set
	 */
	public void setAccessInd(String accessInda) {
		this.accessInd = accessInda;
	}

	/**
	 * To change body of implemented methods use File | Settings | File
	 * Templates.
	 */
	public String getSQLTypeName() throws SQLException {
		return sqlType; // To change body of implemented methods use File |
		// Settings | File Templates.
	}

	/**
	 * Reading sql
	 */
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		sqlType = typeName;

		groupId = stream.readInt();
		screenId = stream.readInt();
		permissionId = stream.readInt();
		accessInd = stream.readString();

	}

	/**
	 * Writing sql
	 */
	public void writeSQL(SQLOutput stream) throws SQLException {

		stream.writeInt(groupId);
		stream.writeInt(screenId);
		stream.writeInt(permissionId);
		stream.writeString(accessInd);

	}

}
