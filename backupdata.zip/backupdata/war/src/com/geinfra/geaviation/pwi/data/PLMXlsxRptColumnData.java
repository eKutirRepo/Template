/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhrUsdSubstncData.java
 * @Creation date: 01-Jan-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.List;

import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;

public class PLMXlsxRptColumnData {
	
	private List<?> data; 
	private PLMXlsxRptColumn[] columns; 
	private boolean criteriaFlag; 
	private PLMXlsxRptColumn[] critcolumns; 
	private Object inputData;
	
	public List<?> getData() {
		return data;
	}
	public void setData(List<?> data) {
		this.data = data;
	}
	public PLMXlsxRptColumn[] getColumns() {
		return columns;
	}
	public void setColumns(PLMXlsxRptColumn[] columns) {
		this.columns = columns;
	}
	
	public boolean isCriteriaFlag() {
		return criteriaFlag;
	}
	public void setCriteriaFlag(boolean criteriaFlag) {
		this.criteriaFlag = criteriaFlag;
	}
	public PLMXlsxRptColumn[] getCritcolumns() {
		return critcolumns;
	}
	public void setCritcolumns(PLMXlsxRptColumn[] critcolumns) {
		this.critcolumns = critcolumns;
	}
	public Object getInputData() {
		return inputData;
	}
	public void setInputData(Object inputData) {
		this.inputData = inputData;
	}
	
	


}
