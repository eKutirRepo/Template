 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileNamePLMPwiUserData.java
 * @Creation date: 16-March-2015
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.data;

import java.io.Serializable;
import java.util.List;


public class PLMPwiRolesData implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7122804327005187827L;

	private int userRoleId;
	
	private String userRoleName;
	
	private String userRoleType;
	
	private List<PLMPwiGroupsData> groupDtlsFrRole;

	public int getUserRoleId() {
		return userRoleId;
	}

	public void setUserRoleId(int userRoleId) {
		this.userRoleId = userRoleId;
	}

	public String getUserRoleName() {
		return userRoleName;
	}

	public void setUserRoleName(String userRoleName) {
		this.userRoleName = userRoleName;
	}

	public String getUserRoleType() {
		return userRoleType;
	}

	public void setUserRoleType(String userRoleType) {
		this.userRoleType = userRoleType;
	}

	public List<PLMPwiGroupsData> getGroupDtlsFrRole() {
		return groupDtlsFrRole;
	}

	public void setGroupDtlsFrRole(List<PLMPwiGroupsData> groupDtlsFrRole) {
		this.groupDtlsFrRole = groupDtlsFrRole;
	}

	


}
