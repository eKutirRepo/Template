/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBomCopicsData.java
 * @Creation date: 15-June-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.data;

import java.util.List;

public class PLMBomCopicsData {
	/**
	  * Holds the level
	  */
	private String level;
	/**
	  * Holds the childPrefix
	  */
	private String childPrefix;
	/**
	  * Holds the parentPrefix
	  */
	private String parentPrefix;
	/**
	  * Holds the parentItem
	  */
	private String parentItem;
	/**
	  * Holds the childItem
	  */
	private String childItem;
	/**
	  * Holds the qty
	  */
	private String qty;
	/**
	  * Holds the resultList
	  */
	private List<PLMBomCopicsData> resultList;
	
	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}
	/**
	 * @return the childPrefix
	 */
	public String getChildPrefix() {
		return childPrefix;
	}
	/**
	 * @param childPrefix the childPrefix to set
	 */
	public void setChildPrefix(String childPrefix) {
		this.childPrefix = childPrefix;
	}
	/**
	 * @return the parentPrefix
	 */
	public String getParentPrefix() {
		return parentPrefix;
	}
	/**
	 * @param parentPrefix the parentPrefix to set
	 */
	public void setParentPrefix(String parentPrefix) {
		this.parentPrefix = parentPrefix;
	}
	/**
	 * @return the parentItem
	 */
	public String getParentItem() {
		return parentItem;
	}
	/**
	 * @param parentItem the parentItem to set
	 */
	public void setParentItem(String parentItem) {
		this.parentItem = parentItem;
	}
	/**
	 * @return the childItem
	 */
	public String getChildItem() {
		return childItem;
	}
	/**
	 * @param childItem the childItem to set
	 */
	public void setChildItem(String childItem) {
		this.childItem = childItem;
	}
	/**
	 * @return the qty
	 */
	public String getQty() {
		return qty;
	}
	/**
	 * @param qty the qty to set
	 */
	public void setQty(String qty) {
		this.qty = qty;
	}
	/**
	 * @return the resultList
	 */
	public List<PLMBomCopicsData> getResultList() {
		return resultList;
	}
	/**
	 * @param resultList the resultList to set
	 */
	public void setResultList(List<PLMBomCopicsData> resultList) {
		this.resultList = resultList;
	}
}