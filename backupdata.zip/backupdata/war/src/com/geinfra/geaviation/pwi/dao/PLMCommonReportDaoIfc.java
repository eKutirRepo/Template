/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCommonReportDaoIfc.java
 * @Creation date: 12-Aug-2011
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */


package com.geinfra.geaviation.pwi.dao;

import com.geinfra.geaviation.pwi.util.PLMCommonException;


/**
 * PLMCommonReportDaoIfc is the DAO interface used for PLM Common functionalities
 */

public interface PLMCommonReportDaoIfc {
	
	/**
	 * This method is used to getLegacyDateStamp
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getLegacyDateStamp () throws PLMCommonException;
	/**
	 * This method is used to getPLMDateStamp
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getPLMDateStamp (String tablename) throws PLMCommonException;
	/**
	 * This method is used to getETLRunDateStamp
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getETLRunDateStamp() throws PLMCommonException;

	//Newly Added method for getting Last Refresh COPICS Date
	/**
	 * This method is used to fetch COPICS Run Date Stamp
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getCOPICSRunDateStamp() throws PLMCommonException;
	
	/**
	 * @param reportName
	 * @return
	 * @throws PLMCommonException
	 */
	public int insertCannedRptRecordHitInfo(String reportName, String sso) throws PLMCommonException;

}
