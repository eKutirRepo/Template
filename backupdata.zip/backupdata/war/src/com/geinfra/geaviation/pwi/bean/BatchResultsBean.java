package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FilenameFilter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.faces.context.FacesContext;

import jxl.common.Logger;

import com.geinfra.geaviation.pwi.bean.HistoryView.HistoryItemBean;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.MinimalQueryExctnEventVO;
import com.geinfra.geaviation.pwi.model.PWiQueryExctnEventVO;
//import com.geinfra.geaviation.pwi.model.ResultFile;
import com.geinfra.geaviation.pwi.service.QuerySubmissionService;
import com.geinfra.geaviation.pwi.service.vo.ExecutionMode;
import com.geinfra.geaviation.pwi.service.vo.OutputType;
import com.geinfra.geaviation.pwi.util.BookmarkableLinkUtil;
import com.geinfra.geaviation.pwi.util.FilePathUtil;
import com.geinfra.geaviation.pwi.util.FileUtil;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.xml.search.util.SearchJaxbUtil;


/**
 * 
 * Project      : Product Lifecycle Management
 * Date Written : Aug 5, 2010
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2013 GE All rights reserved
 * 
 * Description : BatchResultsBean - bean for displaying list of user's batch
 * query results.
 * 
 * Revision Log Aug 5, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class BatchResultsBean extends BaseBean {
	
	private static final Logger LOGGER = Logger
			.getLogger(BatchResultsBean.class);
	// TODO pH 2013.03: replace the following two classes with ....model.ResultFile?
	public static final FilenameFilter FILTER_NOT_HIDDEN = new FilenameFilter() {
		public boolean accept(File dir, String name) {
			// for now, get all files whose name doesn't start with '.'
			return (name != null) && name.split("\\n")[0].matches("^[^\\.].*");
		}
	};

	/**
	 * 
	 * Project      : Product Lifecycle Management
	 * Date Written : Aug 5, 2010
	 * Security     : GE Confidential
	 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
	 * 
	 * Copyright(C) 2013 GE All rights reserved
	 * 
	 * Description : BatchRequest - internal class for displaying individual
	 * batch requests.
	 * 
	 * Revision Log Aug 5, 2010 | v1.0.
	 * --------------------------------------------------------------
	 */
	public static class BatchRequest implements Comparable<BatchRequest> {
		/*private static final SimpleDateFormat DATE_FORMAT =
				new SimpleDateFormat("MM/dd/yyyy', \n' hh:mm a");*/

		private Integer eventId;
		private Integer numResults;
		private String queryName;
		private Date dtExecuted;
		private String executed;
		private String executionMode;
		private String outputType;
		private String searchParameters;
		private String searchParametersLess;
		private String executeLink;
		private String modifyLink;
		private boolean rerunnable;
		private boolean searchParametersToggleNeeded;

		public BatchRequest(PWiQueryExctnEventVO vo)
				throws PWiException  {
			SimpleDateFormat DATE_FORMAT =
								new SimpleDateFormat("MM/dd/yyyy', \n' hh:mm a");
			//rerunnable = Boolean.valueOf(vo.isRerunnable());
			if (vo != null) {
				
				// original Constructor
				eventId = vo.getEventId();
				rerunnable = vo.isRerunnable();
				
				// Initialize execute link
				executeLink = BookmarkableLinkUtil.getInstance()
						.getExecuteHistoryLink(eventId);

				// Initialize modify link
				modifyLink = BookmarkableLinkUtil.getInstance()
						.getModifyHistoryLink(eventId);

				queryName = vo.getQuery().getQryNm();

				dtExecuted = vo.getDateExecuted();
				executed = DATE_FORMAT.format(dtExecuted);
				

				if(vo.getExecutionMode().contains("::"))
				{
				executionMode = ExecutionMode.getById(vo.getExecutionMode().substring(0, vo.getExecutionMode().indexOf("::")))
						.getLabel();
				}
				else
				{
					executionMode = ExecutionMode.getById(vo.getExecutionMode())
							.getLabel();
				}

				//executionMode = ExecutionMode.getById(vo.getExecutionMode()).getLabel();

				outputType = OutputType.getById(vo.getOutputType()).getLabel();

				searchParameters = SearchJaxbUtil.getSearchParametersForDisplay(vo
						.getSearchCriteriaXml());
				searchParametersToggleNeeded = SearchJaxbUtil
						.isSearchParametersLong(searchParameters);
				searchParametersLess = SearchJaxbUtil
						.abbreviatedSearchParameters(searchParameters);
				numResults = vo.getRowCount();
			} else {
				// eachPrivateVar = "" || 0;
				rerunnable = false;
				eventId = 0;
				executeLink = "";
				modifyLink = "";
				queryName = "";
				dtExecuted = new Date(0); // Forces sort to top
				executed = "";
				executionMode = "";
				outputType = "";
				searchParameters = "";
				searchParametersLess = "";
				searchParametersToggleNeeded = false;
				numResults = 0;
			}

		}
		
		public int compareTo(BatchRequest br2) {
			// getTime returns long, but compare returns int.  Simply performing
			// comparison to avoid type conversion or risk of overflow.
			if (this.getDtExecuted().getTime() < br2.getDtExecuted().getTime()) {
				return PWiConstants.COMP_LT;
			} else if (this.getDtExecuted().getTime() > br2.getDtExecuted().getTime()) {
				return PWiConstants.COMP_GT;
			} else {
				return PWiConstants.COMP_EQ;
			}
		}

		public boolean isRerunnable() {
			return rerunnable;
		}

		public Integer getEventId() {
			return eventId;
		}
		
		public String getQueryName() {
			return queryName;
		}

		public String getExecuted() {
			return executed;
		}
		
		public final Date getDtExecuted() {
			
			Date executeDt = null;
			if(dtExecuted!=null)
			{
				executeDt = dtExecuted;
			}
			else
			{
				executeDt = new Date();
			}
			return executeDt;
		}

		public String getExecutionMode() {
			return executionMode;
		}

		public String getOutputType() {
			return outputType;
		}

		public String getSearchParameters() {
			return searchParameters;
		}

		public String getSearchParametersLess() {
			return searchParametersLess;
		}
		
		public String getExecuteLink() throws PWiException {
			return executeLink;
		}

		public String getModifyLink() throws PWiException {
			return modifyLink;
		}

		public boolean isSearchParametersToggleNeeded() {
			return searchParametersToggleNeeded;
		}
		
		public int getNumResults() throws PWiException {
			return numResults;
		}
	}
	
	/**
	 * 
	 * Project      : Product Lifecycle Management
	 * Date Written : Aug 20, 2012
	 * Security     : GE Confidential
	 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
	 * 
	 * Copyright(C) 2013 GE All rights reserved
	 * 
	 * Description : CompletedBatchRequest - extention of BatchRequest to allow
	 * renewal and download of results files.
	 * 
	 * Revision Log Aug 20, 2012 | v1.0.
	 * --------------------------------------------------------------
	 */
	public static class CompletedBatchRequest extends BatchRequest {
		private String fileName;
		private String expirationDate;

		// add a constructor
		public CompletedBatchRequest(PWiQueryExctnEventVO vo, String fn)
			throws PWiException {	
			// call constructor
			super(vo);
			// initialize filename
			fileName = fn;
			
			if (vo != null && vo.getExpirationDate() != null) {
				SimpleDateFormat dateFormat = new SimpleDateFormat(
					"MM/dd/yyyy");
				expirationDate = dateFormat.format(vo.getExpirationDate());
			} else {
				expirationDate = "Today";
			}
		}

		public String getFileName() {
			return fileName;
		}
		
		public String getExpirationDate() {
			return expirationDate;
		}

		public void setExpirationDate(String expirationDate) {
			this.expirationDate = expirationDate;
		}
	}

	// Requests
	private List<HistoryItemBean>  queuedRequests;
	private List<HistoryItemBean> runningRequests;
	private List<CompletedBatchRequest> completedRequests;
	
	// Injected service
	private QuerySubmissionService querySubmissionService;

	public void setQuerySubmissionService(
			QuerySubmissionService querySubmissionService) {
		this.querySubmissionService = querySubmissionService;
	}
	
	// forces refresh of lists of batch requests
	private void refresh() {
		queuedRequests = null;
		runningRequests = null;
		completedRequests = null;
	}
	
	public List<HistoryItemBean> getQueuedBatchRequests()
	throws PWiException {
		if (queuedRequests == null) {
			List<MinimalQueryExctnEventVO> events = querySubmissionService
					.getQueuedBatchRequestsForUser(getSsoId());
			queuedRequests = new ArrayList<HistoryItemBean>();
			for (MinimalQueryExctnEventVO event : events) {
				queuedRequests.add(new HistoryItemBean(event));
			}
		}
		return queuedRequests;
	}

	public List<HistoryItemBean> getRunningBatchRequests()
	throws PWiException {
		if (runningRequests == null) {
			List<MinimalQueryExctnEventVO> events = querySubmissionService
					.getRunningBatchRequestsForUser(getSsoId());
			runningRequests = new ArrayList<HistoryItemBean>();
			for (MinimalQueryExctnEventVO event : events) {
				runningRequests.add(new HistoryItemBean(event));
			}
		}
		return runningRequests;
	}

	// Completed Batch Requests 
	public List<CompletedBatchRequest> getBatchResults() 
			throws PWiException {
		if (completedRequests == null) {
			LOGGER.info("batch path-111- "+FilePathUtil.getInstance().appDataMountPathBatch());
			File ssoDir = new File(FilePathUtil.getInstance().batchModePath(
					FilePathUtil.getInstance().appDataMountPathBatch(),
					getSsoId()));
			if (ssoDir.exists() && ssoDir.isDirectory()) {
				LOGGER.info("batch path-121212-exist ");
				if (ssoDir.isDirectory()) {
					LOGGER.info("batch path-131313-is  a Directory ");
				}
				}
			String[] fileNames = ssoDir.list(FILTER_NOT_HIDDEN);
			if (fileNames == null) {
				fileNames = new String[] {};
			}
			// new array of CompletedBatchRequest
			LOGGER.info("batch path-333-length "+fileNames.length);
			CompletedBatchRequest[] arrCompletedRequests = new CompletedBatchRequest[fileNames.length];
			for ( int i = 0; i < fileNames.length; i++ ) { 
				// getVO(eventID)
				PWiQueryExctnEventVO PWivo;
				try {
					LOGGER.info("batch path-4444-fileName "+fileNames[i]);
					PWivo = querySubmissionService.getExecutionEventById(
							FileUtil.getInstance().
							parseEventIdFromQueryResultFileName(fileNames[i]));
				} catch(NumberFormatException e) {
					// same behavior for an invalid number ("abc") as for an invalid
					// execution event id (no execution event exists with given ID)
					PWivo = null;
				}
				// new CompleteBatchRequest(VO)
				arrCompletedRequests[i] = new CompletedBatchRequest(PWivo, fileNames[i]);
			}
			Arrays.sort(arrCompletedRequests);
			completedRequests = new ArrayList<CompletedBatchRequest>(
					Arrays.asList(arrCompletedRequests));
		}
		return completedRequests;
	}
	
	public void getResultsFile() throws PWiException {
		String fileName = FacesContext.getCurrentInstance()
			.getExternalContext().getRequestParameterMap().get("fileName");
		LOGGER.info("batch path-001- "+FilePathUtil.getInstance().appDataMountPathBatch());
		FileUtil.getInstance().downloadFile(
				fileName,
				FilePathUtil.getInstance().batchModePath(
						FilePathUtil.getInstance().appDataMountPathBatch(),
						getSsoId()), false);
		refresh();
	}

	public void renewExpirationDate() throws PWiException {
		String eventIdString = FacesContext.getCurrentInstance()
			.getExternalContext().getRequestParameterMap().get("eventId");
		// Convert ID to Integer
		Integer eventId = Integer.valueOf(eventIdString);
		// Attempt to renew event
		if (!querySubmissionService.renewFile(eventId)) {
			throw new PWiException("Failed to renew query " + eventIdString);
		}
		refresh();
	}
	

	public void deleteResultsFile() throws PWiException {
		String fileName = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap().get("fileName");
		LOGGER.info("batch path-- "+FilePathUtil.getInstance().appDataMountPathBatch());
		FileUtil.getInstance().deleteFile(
				fileName,
				FilePathUtil.getInstance().batchModePath(
						FilePathUtil.getInstance().appDataMountPathBatch(),
						getSsoId()));
		refresh();
	}

	
	/**
	 * Cancels a queued or running batch request.
	 * 
	 * @return JSF navigation string
	 */
	public String actionCancelBatchRequest() {
		// Get ID of event to cancel
		String eventIdString = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap().get("eventId");

		// Convert ID to Integer
		Integer eventId = Integer.valueOf(eventIdString);

		// Attempt to cancel event
		boolean canceled = querySubmissionService.cancelBatchRequest(eventId);

		// Add message for user for whether request was successfully canceled
		if (canceled) {
			handleFacesInfo("Batch request successfully cancelled.");
		} else {
			handleFacesError(new StringBuffer("Batch request could not be cancelled.")
					.append("  Requests can be cancelled only when in the queue or while running.")
					.append("  The request might have run to completion before attempting to cancel.")
					.toString());
		}

		refresh();
		return PWiConstants.NAV_BATCH_RESULTS;
	}

//	/**
//	 * Re-submits a completed batch request.
//	 * 
//	 * @return JSF navigation string
//	 * @throws PWiException
//	 * @throws QueryAccessException
//	 */
//	public String actionReRequestBatchRequest() throws PWiException,
//			QueryAccessException {
//		// Get name of batch request file
//		String fileName = FacesContext.getCurrentInstance()
//				.getExternalContext().getRequestParameterMap().get("fileName");
//
//		// Parse ID of event from file name
//		Integer eventId = FileUtil.getInstance()
//				.parseEventIdFromQueryResultFileName(fileName);
//
//		// Re-submit query
//		querySubmissionService.submitQueryFromHistory(eventId, getSsoId(),
//				ExecutedFrom.BATCH_RESULTS);
//
//		// Output success message
//		handleFacesInfo("Batch request successfully re-submitted.");
//
//		refresh();
//		return PWiConstants.NAV_BATCH_RESULTS;
//	}
}
