/**
 * Copyright (C) 2014 GE Infra. All rights reserved
 * 
 * @FileName PLMGBomMB.java
 * @Creation date: 17-May-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;

import javax.faces.component.UISelectOne;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.common.usermodel.Hyperlink;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFCreationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFHyperlink;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMCostCatalogData;
import com.geinfra.geaviation.pwi.data.PLMGBomData;
import com.geinfra.geaviation.pwi.service.PLMGBomServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;

public class PLMGBomMB {

	/**
	 * Holds the Loggger
	 */
	private static final Logger LOG = Logger.getLogger(PLMGBomMB.class);


	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;


	/**
	 * Holds the plmGBomService
	 */
	private PLMGBomServiceIfc plmGBomService = null;


	/**
	 * Holds the modelMktNamesList
	 */
	private List<SelectItem> modelMktNamesList;


	/**
	 * Holds the tfDisplayNamesList
	 */
	private List<SelectItem> tfDisplayNamesList;


	/**
	 * Holds the ciNomenNamesList
	 */
	private List<SelectItem> ciNomenNamesList;


	/**
	 * Holds the selectedModelMktNamesList
	 */
	private List<String> selectedModelMktNamesList = new ArrayList<String>();


	/**
	 * Holds the selectedTfDisplayNamesList
	 */
	private List<String> selectedTfDisplayNamesList = new ArrayList<String>();


	/**
	 * Holds the selectedCiNomenNamesList
	 */
	private List<String> selectedCiNomenNamesList = new ArrayList<String>();


	/**
	 * Holds the selectedHwPrdNameList
	 */
	private List<String> selectedHwPrdNameList;


	/**
	 * Holds the hwPrdNameList
	 */
	private List<PLMGBomData> hwPrdNameList;


	/**
	 * Holds the alertMessage
	 */
	private String alertMessage = "";


	/**
	 * Holds the dropDownMapList
	 */
	private Map<String, List<SelectItem>> dropDownMapList = new HashMap<String, List<SelectItem>>();


	/**
	 * Holds the tfDispNameBinding
	 */
	private UISelectOne tfDispNameBinding;


	/**
	 * Holds the headerCFNamesList1
	 */
	private List<String> headerCFNamesList1;


	/**
	 * Holds the headerCFNamesList
	 */
	private List<String> headerCFNamesList;


	/**
	 * Holds the excelHeaderList
	 */
	private List<PLMGBomData> excelHeaderList;


	/**
	 * Holds the gbomDataList
	 */
	private List<PLMGBomData> gbomDataList;


	/**
	 * Holds the gbomDataNewList
	 */
	private List<PLMGBomData> gbomDataNewList;


	// PLMGBomData compValueData = new PLMGBomData();
	/**
	 * Holds the uniqGbomPartSize
	 */
	private int uniqGbomPartSize = 0;


	/**
	 * Holds the hwPrdMap
	 */
	private Map<String, Object> hwPrdMap = new HashMap<String, Object>();


	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = 100;


	/**
	 * Holds the gbomdataCount
	 */
	private int gbomdataCount = 0;


	/**
	 * Holds the gbomDataCount
	 */
	private int gbomDataCount;


	/**
	 * Holds the headerCellStyle
	 */
	private XSSFCellStyle headerCellStyle = null;


	/**
	 * Holds the normalCellStyle
	 */
	private XSSFCellStyle normalCellStyle = null;


	/**
	 * Holds the DATE_FORMAT_PROC
	 */
	private final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");


	/**
	 * Holds the resourceBundle
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");


	// private List<PLMGBomData> gbomDataList;
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;


	// Added for Feature Impact Report
	/**
	 * Holds the productLineList
	 */
	private List<SelectItem> productLineList = new ArrayList<SelectItem>();


	/**
	 * Holds the frameTypeList
	 */
	private List<SelectItem> frameTypeList = new ArrayList<SelectItem>();


	/**
	 * Holds the featureNameListSI
	 */
	private List<SelectItem> featureNameListSI = new ArrayList<SelectItem>();


	/**
	 * Holds the selectedProductLine
	 */
	private String selectedProductLine = "";


	/**
	 * Holds the selectedFrameType
	 */
	private String selectedFrameType = "";


	/**
	 * Holds the selectedFrameType
	 */
	private String selectedFeatDispName = "";


	/**
	 * Holds the featureNameList
	 */
	private List<PLMGBomData> featureNameList = new ArrayList<PLMGBomData>();


	/**
	 * Holds the selectedFeatureName
	 */
	private String selectedFeatureName = "";


	/**
	 * Holds the selectedHwPrdNameList1
	 */
	private List<String> selectedHwPrdNameList1 = new ArrayList<String>();


	/**
	 * Holds the hwPrdMapFirc
	 */
	private Map<String, Object> hwPrdMapFir = new HashMap<String, Object>();


	/**
	 * Holds the featImptReptTab1DataList
	 */
	private List<PLMGBomData> featImptReptTab1DataList = new ArrayList<PLMGBomData>();


	/**
	 * Holds the featImptReptTab2DataList
	 */
	private List<PLMGBomData> featImptReptTab2DataList = new ArrayList<PLMGBomData>();


	/**
	 * Holds the featImptReptTab1DataListNew
	 */
	private List<PLMGBomData> featImptReptTab1DataListNew = new ArrayList<PLMGBomData>();


	/**
	 * Holds the recordCountsFir
	 */
	private int recordCountsFir = 100;


	/**
	 * Holds the firDataCount
	 */
	private int firDataCount = 0;


	/**
	 * Holds the firDataCount1
	 */
	private int firDataCount1 = 0;


	/**
	 * Holds the headerCFNamesList1Fir
	 */
	private List<String> headerCFNamesList1Fir = new ArrayList<String>();


	/**
	 * Holds the headerCFNamesListFir
	 */
	private List<String> headerCFNamesListFir = new ArrayList<String>();


	/**
	 * Holds the excelHeaderListFir
	 */
	private List<PLMGBomData> excelHeaderListFir = new ArrayList<PLMGBomData>();


	/**
	 * Holds the firDataNewList
	 */
	private List<PLMGBomData> firDataNewList = new ArrayList<PLMGBomData>();


	/**
	 * Holds the VT_TABLE_NAME
	 */
	// private String VT_TABLE_NAME = "";
	/**
	 * Holds the tab2InputData
	 */
	private Map<String, Object> tab2InputData = new HashMap<String, Object>();


	/**
	 * Holds the heightPX
	 */
	private String heightPX = "450px";


	/**
	 * Holds the heightPX1
	 */
	private String heightPX1 = "450px";


	/**
	 * Holds the countTab1d
	 */
	private int countTab1 = 0;


	/**
	 * Holds the countTab2
	 */
	private int countTab2 = 0;


	/**
	 * Holds the featName
	 */
	private String featName = "";


	// Newly Added for Part Cost Catalogue Report
	/**
	 * Holds the productLineCatlogList
	 */
	private List<SelectItem> productLineCatlogList = new ArrayList<SelectItem>();


	/**
	 * Holds the frameTypeCatlogList
	 */
	private List<SelectItem> frameTypeCatlogList = new ArrayList<SelectItem>();


	/**
	 * Holds the selProductLineCatalog
	 */
	private String selProductLineCatalog = "";


	/**
	 * Holds the selFrameTypeCatalog
	 */
	private String selFrameTypeCatalog = "";


	/**
	 * Holds the featureCatalogList
	 */
	private List<PLMGBomData> featureCatalogList = new ArrayList<PLMGBomData>();


	/**
	 * Holds the selectedHwPrdCatlogLst
	 */
	private List<String> selectedHwPrdCatlogLst = new ArrayList<String>();


	/**
	 * Holds the partCostCatalogList
	 */
	private List<PLMCostCatalogData> partCostCatalogList = new ArrayList<PLMCostCatalogData>();


	/**
	 * Holds the hardWarePrdRevList
	 */
	private List<PLMCostCatalogData> hardWarePrdRevList = new ArrayList<PLMCostCatalogData>();


	/**
	 * Holds the totalpartCostCatalogMsg
	 */
	private String totalpartCostCatalogMsg;


	/**
	 * Holds the rowpartCostCatalog
	 */
	private int rowpartCostCatalog = 100;


	/**
	 * Holds the totalpartCostCatalog
	 */
	private int totalpartCostCatalog;


	/**
	 * Holds the hardwarePrd
	 */
	private String hardwarePrd;


	/**
	 * Holds the hardwarePrdRev
	 */
	private String hardwarePrdRev;


	/**
	 * Holds the partCostCatalogFilterMsg
	 */
	private String partCostCatalogFilterMsg;


	/**
	 * Holds the tab1Flag
	 */
	private boolean tab1Flag;


	/**
	 * Holds the tab2Flag
	 */
	private boolean tab2Flag;


	/**
	 * Holds the costTypeList
	 */
	private List<SelectItem> costTypeList;


	/**
	 * Holds the selCostType
	 */
	private String selCostType = "";


	private String userEmail;


	private String userName;


	/**
	 * This method is used for Loading GBOM Page
	 * 
	 * @return String
	 */
	public String loadGBomReportSearchPage() {

		LOG.info("Entering loadGBomReportSearchPage Method");
		
		try {
			commonMB.insertCannedRptRecordHitInfo("GBOM Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			alertMessage = "";
			resetGBomValues();
			selectedModelMktNamesList = new ArrayList<String>();
			selectedTfDisplayNamesList = new ArrayList<String>();
			selectedCiNomenNamesList = new ArrayList<String>();
			tfDisplayNamesList = new ArrayList<SelectItem>();
			ciNomenNamesList = new ArrayList<SelectItem>();
			dropDownMapList = plmGBomService.getDropDownData();
			LOG.info("dropDownMapList fetched to MB with size ==" + dropDownMapList.size());
			modelMktNamesList = (List<SelectItem>) dropDownMapList.get("modelMktNamesList");
			LOG.info("modelMktNamesList fetched to MB with size ==" + modelMktNamesList.size());
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@loadGBomReportSearchPage:", exception);
		}
		LOG.info("Exiting loadGBomReportSearchPage Method");
		return "gbomReportSearch";
	}


	/**
	 * This method is used for resetGBomValues
	 * 
	 *
	 */
	public void resetGBomValues() {

		modelMktNamesList = null;
		tfDisplayNamesList = null;
		ciNomenNamesList = null;
	}


	/**
	 * This method is used for resetSearchData
	 * 
	 * @return String
	 */
	public String resetSearchData() {

		LOG.info("Entering resetSearchData");
		String fwdFlag = "";

		setSelectedModelMktNamesList(null);
		setSelectedTfDisplayNamesList(null);
		setSelectedCiNomenNamesList(null);


		try {
			fwdFlag = loadGBomReportSearchPage();
			LOG.info("executed loadGBomReportSearchPage inside resetSearchData");
			LOG.info("SECOND TIME dropDownMapList fetched to MB with size ==" + dropDownMapList.size());
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@resetSearchData PLMGBomMB:", exception);
		}
		LOG.info("Existing resetSearchData");
		return fwdFlag;

	}


	/**
	 * This method is used for valueChangeMMName
	 * 
	 * @param changeEvent
	 */
	public void valueChangeMMName(ValueChangeEvent changeEvent) {

		try {
			LOG.info("Entering valueChangeMMName Method");

			tfDisplayNamesList = (List<SelectItem>) plmGBomService.getDispNameForMMName(selectedModelMktNamesList).get("tfDisplayNamesListForMMName");
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@valueChangeMMName PLMGBomMB:", exception);
		}
		LOG.info("Exiting valueChangeMMName Method");

	}


	// Called in JSP

	/**
	 * This method is used for valueChangeMMName
	 * 
	 *
	 */
	public void valueChangeMMName() {

		try {
			LOG.info("Entering valueChangeMMName Method");

			tfDisplayNamesList = (List<SelectItem>) plmGBomService.getDispNameForMMName(selectedModelMktNamesList).get("tfDisplayNamesListForMMName");
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@valueChangeMMName PLMGBomMB:", exception);
		}
		LOG.info("Exiting valueChangeMMName Method");

	}


	/**
	 * This method is used for valueChangeMMNameDispName
	 * 
	 *
	 */
	public void valueChangeMMNameDispName() {

		try {
			hwPrdMap = new HashMap<String, Object>();
			LOG.info("Entering valueChangeMMName Method");
			selectedHwPrdNameList = new ArrayList<String>();
			hwPrdNameList = plmGBomService.getHwPrdNameList(selectedModelMktNamesList, selectedTfDisplayNamesList);
			for (PLMGBomData hwPrd : hwPrdNameList) {
				selectedHwPrdNameList.add(hwPrd.getModelName());
				hwPrdMap.put(hwPrd.getModelName(), hwPrd.getFrameType());
			}
			Map<String, List<PLMGBomData>> datamap = plmGBomService.getCINomenList(selectedHwPrdNameList);
			List<PLMGBomData> cfList = datamap.get("CINomenList");
			ciNomenNamesList = new ArrayList<SelectItem>();
			for (PLMGBomData data : cfList) {
				String label = data.getCfDispName();
				ciNomenNamesList.add(new SelectItem(label, label));
			}
			Collections.sort(ciNomenNamesList, new PLMUtils.SortListSelItmLbl());
			cfList.clear();
			LOG.info("ciNomenNamesList fetched with size" + ciNomenNamesList.size());
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@valueChangeMMNameDispName PLMGBomMB:", exception);
		}
		LOG.info("Exiting valueChangeMMNameDispName method");

	}


	/**
	 * This method is used for showGBOMReport
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String showGBOMReport() throws PLMCommonException {

		LOG.info("Entering showGBOMReport Method");
		Map<String, Object> varMap = new HashMap<String, Object>();

		try {
			if (!(selectedModelMktNamesList == null) && !(selectedModelMktNamesList.size() == 0) && !(selectedTfDisplayNamesList == null) && !(selectedTfDisplayNamesList.size() == 0)
								&& !(selectedCiNomenNamesList == null) && !(selectedCiNomenNamesList.size() == 0)) {
				varMap.put("selectedModelMktNamesList", selectedModelMktNamesList);
				varMap.put("selectedTfDisplayNamesList", selectedTfDisplayNamesList);
				varMap.put("selectedCiNomenNamesList", selectedCiNomenNamesList);
				varMap.put("selectedHwPrdNameList", selectedHwPrdNameList);

				gbomDataList = plmGBomService.getGBOMData(varMap, hwPrdMap);
				gbomdataCount = gbomDataList.size();
				if (gbomDataList.size() == 0) {
					alertMessage = "No Data Exists for the selected combination of Input..Please try with different input values...";
					LOG.info("GBOM datalist size is Zero...");
					LOG.info(alertMessage);
					return "gbomReportSearch";
				}
				gbomDataCount = gbomDataList.size();
				LOG.info("Inside GBOM MB, fetched gbomDataList with size" + gbomDataList.size());
				for (PLMGBomData gbomdata : gbomDataList) {
					String plinekey = gbomdata.getMktName();
					gbomdata.setProductLine((String) hwPrdMap.get(plinekey));
				}

				if (gbomDataList.size() != 0) {
					headerCFNamesList1 = new ArrayList<String>();
					headerCFNamesList = new ArrayList<String>();
					for (PLMGBomData gbomData : gbomDataList) {
						if (!(PLMUtils.checkNullVal(gbomData.getConfFeatureName())).equals("")) {

							headerCFNamesList1.add(gbomData.getConfFeatureName());

						}
					}
					LOG.info("headerCFNamesList size with duplicates:" + headerCFNamesList1.size());
					Set<String> uniqueCFName = new HashSet<String>();

					for (String cfName : headerCFNamesList1) {
						if (uniqueCFName.add(cfName)) {
							uniqueCFName.add(cfName);
							headerCFNamesList.add(cfName);
						}
					}
				}

				LOG.info("Size of Unique List:" + headerCFNamesList.size());
				if (headerCFNamesList.size() != 0) {
					excelHeaderList = plmGBomService.getExcelHeaderList(headerCFNamesList);
					LOG.info("Inside GBOM MB, fetched excelHeaderList with size" + excelHeaderList.size());
				} else {
					excelHeaderList = new ArrayList<PLMGBomData>();
					PLMGBomData firstColumn = new PLMGBomData();
					firstColumn.setHeaderConfFeature("");
					firstColumn.setHeaderConfOption("Always Applied");
					firstColumn.setHeaderConfOptionDispName("Always Applied");
					excelHeaderList.add(firstColumn);
					LOG.info("First column added.....");
				}
				gbomDataNewList = new ArrayList<PLMGBomData>();
				PLMGBomData gbomDataNew = new PLMGBomData();
				String plineNew = "";
				String plineOld = "";
				String childFeatId = "";
				String ciDispNmNew = "";
				String ciDispNmOld = "";
				String gbomPartId = "";
				String gbomPartNew = "";
				String gbomPartOld = "";
				String[] compValue = new String[excelHeaderList.size()];
				Map<String, PLMGBomData> tempMap = new HashMap<String, PLMGBomData>();

				int rowNum = 0;


				for (PLMGBomData headerdata : excelHeaderList) {
					tempMap.put(rowNum + "", headerdata);
					rowNum++;
				}

				for (PLMGBomData gbomdata : gbomDataList) {
					plineNew = gbomdata.getProductLine();
					childFeatId = gbomdata.getChildFeatId();
					ciDispNmNew = gbomdata.getCiDispName();
					gbomPartId = gbomdata.getGbomPartId();
					gbomPartNew = gbomdata.getGbomPart();

					if (!plineNew.equals(plineOld) || !ciDispNmNew.equals(ciDispNmOld) || !gbomPartNew.equals(gbomPartOld)) {
						if (!"".equals(plineOld)) {
							gbomDataNewList.add(gbomDataNew);
						}
						gbomDataNew = new PLMGBomData();
						compValue = new String[excelHeaderList.size()];
					}

					String confFeat = gbomdata.getConfFeatureName();
					String confOptn = gbomdata.getConfOptnName();

					if (!PLMUtils.checkNullVal(confFeat).equals("")) {
						List<String> keyList = new ArrayList<String>(tempMap.keySet());
						for (String keyVal : keyList) {

							PLMGBomData headerData = (PLMGBomData) tempMap.get(keyVal);
							String headerConfFeat = headerData.getHeaderConfFeature();
							String headerConfOptn = headerData.getHeaderConfOption();

							if (confFeat.equals(headerConfFeat) && confOptn.equals(headerConfOptn)) {
								compValue[Integer.parseInt(keyVal)] = "X";
							}
							if (confFeat.equals(headerConfFeat) && !confOptn.equals(headerConfOptn) && !"X".equalsIgnoreCase(compValue[Integer.parseInt(keyVal)])) {
								compValue[Integer.parseInt(keyVal)] = "O";
							}
						}
						gbomdata.setCompValue(compValue);
						for (int j = 1; j < compValue.length; j++) {
							if (null == compValue[j])
								compValue[j] = "";
						}
					} else {
						compValue[0] = "X";
						for (int j = 1; j < compValue.length; j++) {
							compValue[j] = "";
						}
						gbomdata.setCompValue(compValue);
					}

					if (!plineNew.equals(plineOld) || !ciDispNmNew.equals(ciDispNmOld) || !gbomPartNew.equals(gbomPartOld)) {
						gbomDataNew.setProductLine(plineNew);
						gbomDataNew.setChildFeatId(childFeatId);
						gbomDataNew.setCiDispName(ciDispNmNew);
						gbomDataNew.setGbomPartId(gbomPartId);
						gbomDataNew.setGbomPart(gbomPartNew);
						gbomDataNew.setCompValue(compValue);
					}

					plineOld = plineNew;
					ciDispNmOld = ciDispNmNew;
					gbomPartOld = gbomPartNew;
				}
				if (gbomDataList.size() > 0) {
					gbomDataNewList.add(gbomDataNew);
				}
				LOG.info("gbomDataNewList size >>> " + gbomDataNewList.size());
			} else {
				alertMessage = "Please Select One or more values from Each ListBox...";
				LOG.info(alertMessage);
				return "gbomReportSearch";
			}
		} catch (PLMCommonException exception) {
			String fwdflag = "";
			LOG.log(Level.ERROR, "Exception@showGBOMReport: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(), commonMB, "gbomReportSearch", "GBOM Report");
			return fwdflag;
		}
		LOG.info("Exiting showGBOMReport Method");
		return "gbomSearchResult";
	}


	// Added by Raju
	/**
	 * Background Process Thread
	 */
	private class GBOMEmailThread implements Runnable {

		public GBOMEmailThread() {

		}


		public void run() {

			try {
				generateGBOMEmailReport();
			} catch (Exception exception) {
				LOG.log(Level.ERROR, "Exception@run() of GBOMEmailThread: ", exception);
			}
		}
	}


	/**
	 * This method is used for sendEmail
	 * 
	 * @throws PWiException
	 * 
	 */
	public void sendEmail() throws PWiException {

		if ((!PLMUtils.isEmptyList(selectedModelMktNamesList)) || (!PLMUtils.isEmptyList(selectedCiNomenNamesList)) || (!PLMUtils.isEmptyList(selectedTfDisplayNamesList))) {
			alertMessage = PLMConstants.GBOM_MAIL_ALERT_MSG;
			userName = UserInfoPortalUtil.getInstance().getUserName();
			userEmail = UserInfoPortalUtil.getInstance().getUserEmail();
			taskExecutor.execute(new GBOMEmailThread());
		} else {
			alertMessage = "Please Select One or more values from Each ListBox";
		}
	}


	// End
	/**
	 * This method is used for generateGBOMEmailReport
	 * 
	 * @return String
	 * @throws PWiException
	 * @throws PLMCommonException
	 */
	public String generateGBOMEmailReport() throws PWiException {

		LOG.info("Entering showGBOMReport Method");
		Map<String, Object> varMap = new HashMap<String, Object>();

		String toEmailId = userEmail;
		LOG.info("userEmail >>>>>>>>>>>>>>>>>>>>" + toEmailId);
		String toAddressee = userName;
		LOG.info("userName >>>>>>>>>>>>>>>>>>>>" + toAddressee);

		toAddressee = "Dear " + toAddressee + ", \n\n";
		try {
			// Start
			if ((!PLMUtils.isEmptyList(selectedModelMktNamesList)) || (!PLMUtils.isEmptyList(selectedCiNomenNamesList)) || (!PLMUtils.isEmptyList(selectedTfDisplayNamesList))) {
				LOG.info("Values from all 3 listbox selected..inside if...");
				varMap.put("selectedModelMktNamesList", selectedModelMktNamesList);
				varMap.put("selectedTfDisplayNamesList", selectedTfDisplayNamesList);
				varMap.put("selectedCiNomenNamesList", selectedCiNomenNamesList);
				varMap.put("selectedHwPrdNameList", selectedHwPrdNameList);

				gbomDataList = plmGBomService.getGBOMData(varMap, hwPrdMap);// 1st list
				// if gbomDataList is empty send no data email
				if (!PLMUtils.isEmptyList(gbomDataList)) {
					gbomdataCount = gbomDataList.size();
					LOG.info("Inside GBOM MB, fetched gbomDataList with size" + gbomDataList.size());
					for (PLMGBomData gbomdata : gbomDataList) {
						String plinekey = gbomdata.getMktName();
						gbomdata.setProductLine((String) hwPrdMap.get(plinekey));
					}

					if (gbomDataList.size() != 0) {
						LOG.info("Inside if(gbomDataList.size() != 0)");
						headerCFNamesList1 = new ArrayList<String>();
						headerCFNamesList = new ArrayList<String>();
						for (PLMGBomData gbomData : gbomDataList) {
							if (!(PLMUtils.checkNullVal(gbomData.getConfFeatureName())).equals("")) {
								headerCFNamesList1.add(gbomData.getConfFeatureName());
							}
						}
						LOG.info("headerCFNamesList size with duplicates:" + headerCFNamesList1.size());
						Set<String> uniqueCFName = new HashSet<String>();
						for (String cfName : headerCFNamesList1) {
							if (uniqueCFName.add(cfName)) {
								uniqueCFName.add(cfName);
								headerCFNamesList.add(cfName);

							}
						}
					}

					LOG.info("Size of Unique List:" + headerCFNamesList.size());
					if (headerCFNamesList.size() != 0) {
						excelHeaderList = plmGBomService.getExcelHeaderList(headerCFNamesList);// 2nd
																								// one
					} else {
						excelHeaderList = new ArrayList<PLMGBomData>();
						PLMGBomData firstColumn = new PLMGBomData();
						firstColumn.setHeaderConfFeature("");
						firstColumn.setHeaderConfOption("Always Applied");
						firstColumn.setHeaderConfOptionDispName("Always Applied");
						excelHeaderList.add(firstColumn);
						LOG.info("First column added.....");
					}
					// if excelHeaderList is empty send no data email
					if (!PLMUtils.isEmptyList(gbomDataList)) {
						prepareExcelWorkBook(varMap);
						writeHeaderDataToExcel(varMap, excelHeaderList);
						if (gbomDataList.size() != 0) {
							writeGBOMDataToExcel(varMap, gbomDataList, excelHeaderList);
						}
						writeDataToExcelFile(varMap);
						PLMUtils.generateZipFile((List<String>) varMap.get("filePathXlsLst"), (String) varMap.get("filePathZip"), false);
						sendGBOMMail(varMap);
					} else {
						StringBuffer noDataMailBody = new StringBuffer().append(toAddressee);
						noDataMailBody.append(PLMConstants.GBOM_NO_CONTENT_BODY + "\n");
						noDataMailBody.append("Search Criteria" + "\n");
						noDataMailBody.append("---------------" + "\n");
						noDataMailBody.append("Product Line:" + selectedModelMktNamesList.toString() + "\n");
						noDataMailBody.append("Frame Type:" + selectedTfDisplayNamesList.toString() + "\n\n");
						noDataMailBody.append("CI Nomenclature:" + selectedCiNomenNamesList.toString() + "\n");
						noDataMailBody.append(PLMConstants.GBOM_MAIL_SIGNATURE).append(PLMConstants.GBOM_MAIL_FOOTER);
						PLMUtils.sendMail(PLMConstants.BVS_MAIL_FROM, toEmailId, PLMConstants.GBOM_MAIL_SUBJECT, noDataMailBody.toString());
						LOG.info("excelHeaderList is empty.No data mail has been sent");
					}
				} else {
					StringBuffer noDataMailBody = new StringBuffer().append(toAddressee);
					noDataMailBody.append(PLMConstants.GBOM_NO_CONTENT_BODY + "\n");
					noDataMailBody.append("Search Criteria" + "\n");
					noDataMailBody.append("---------------" + "\n");
					noDataMailBody.append("Product Line:" + selectedModelMktNamesList.toString() + "\n");
					noDataMailBody.append("Frame Type:" + selectedTfDisplayNamesList.toString() + "\n\n");
					noDataMailBody.append("CI Nomenclature:" + selectedCiNomenNamesList.toString() + "\n");
					noDataMailBody.append(PLMConstants.GBOM_MAIL_SIGNATURE).append(PLMConstants.GBOM_MAIL_FOOTER);
					PLMUtils.sendMail(PLMConstants.BVS_MAIL_FROM, toEmailId, PLMConstants.GBOM_MAIL_SUBJECT, noDataMailBody.toString());
					LOG.info("gbomDataList is empty.No data mail has been sent");
				}
			}
			// End

		} catch (IOException ioexception) {
			LOG.log(Level.ERROR, "Exception@sendBVSComparisonReportThroughMail: ", ioexception);
			PLMUtils.checkExceptionAndMail(ioexception.getMessage(), PLMConstants.BVS_MAIL_FROM, toEmailId, PLMConstants.GBOM_MAIL_SUBJECT, toAddressee, PLMConstants.COST_CHG_MAIL_SIGNATURE);
		} catch (PLMCommonException exception) {
			String fwdflag = "";
			LOG.log(Level.ERROR, "Exception@showGBOMReport: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(), commonMB, "gbomReportSearch", "GBOM Report");
			LOG.info("exception.getMessage()---------------->" + exception.getMessage());
			PLMUtils.checkExceptionAndMail(exception.getMessage(), PLMConstants.BVS_MAIL_FROM, toEmailId, PLMConstants.GBOM_MAIL_SUBJECT, toAddressee, PLMConstants.COST_CHG_MAIL_SIGNATURE);
			return fwdflag;
		} finally {
			if (varMap.get("filePathXls") != null || varMap.get("filePathZip") != null) {
				PLMUtils.deleteFiles((String) varMap.get("filePathXls"), (String) varMap.get("filePathZip"));
			}
		}
		LOG.info("Exiting showGBOMReport Method");
		return "gbomReportSearch";
	}



	/**
	 * This method is used for prepareExcelWorkBook
	 * 
	 * @param varMap
	 * @throws IOException
	 */
	private void prepareExcelWorkBook(Map<String, Object> varMap) throws IOException {

		LOG.info("Inside prepareMExcel");
		XSSFWorkbook workbook = null;
		XSSFSheet sheet = null;
		FileInputStream file = null;
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String folderPath = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = folderPath + resourceBundle.getString("GBOM_REPORT_NAME") + "_" + uniqTime + ".xlsx";
		String filePathZip = folderPath + resourceBundle.getString("GBOM_REPORT_NAME") + "_" + uniqTime + ".zip";
		List<String> filePathXlsLst = new ArrayList<String>();
		filePathXlsLst.add(filePathXls);

		String outptFileTemplate = folderPath + resourceBundle.getString("GBOM_TEMPLATE_NAME");
		LOG.info("After Template line");

		file = new FileInputStream(new File(outptFileTemplate));

		LOG.info("file created" + file.toString());


		workbook = new XSSFWorkbook(file);
		LOG.info("workbook created" + workbook);
		sheet = workbook.getSheetAt(0);
		LOG.info("sheet created====");

		short angle = 90;
		headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setRotation(angle);
		headerCellStyle.setWrapText(true);

		normalCellStyle = workbook.createCellStyle();
		normalCellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);

		XSSFFont underLinedFont = (XSSFFont) workbook.createFont();
		underLinedFont.setUnderline(XSSFFont.U_SINGLE);
		underLinedFont.setColor(IndexedColors.BLUE.getIndex());


		XSSFCellStyle headerLinkStyle = (XSSFCellStyle) workbook.createCellStyle();
		headerLinkStyle.setFont(underLinedFont);
		headerLinkStyle.setRotation(angle);
		headerLinkStyle.setWrapText(true);

		XSSFCellStyle hyperLinkStyle = (XSSFCellStyle) workbook.createCellStyle();
		hyperLinkStyle.setFont(underLinedFont);
		hyperLinkStyle.setWrapText(true);


		XSSFCreationHelper helper = (XSSFCreationHelper) workbook.getCreationHelper();


		varMap.put("workbook", workbook);
		varMap.put("sheet", sheet);
		varMap.put("folderPath", folderPath);
		varMap.put("filePathXls", filePathXls);
		varMap.put("filePathZip", filePathZip);
		varMap.put("filePathXlsLst", filePathXlsLst);
		varMap.put("headerLinkStyle", headerLinkStyle);
		varMap.put("hyperLinkStyle", hyperLinkStyle);
		varMap.put("helper", helper);

		LOG.info("Last line of prepareExcel");
	}


	/**
	 * This method is used for writeHeaderDataToExcel
	 * 
	 * @param varMap,excelHeaderListLcl
	 * @throws PLMCommonException
	 */
	private void writeHeaderDataToExcel(Map<String, Object> varMap, List<PLMGBomData> excelHeaderListLcl) throws PLMCommonException {

		LOG.info("Inside writeHeaderDataToExcel()");
		Row row1 = null;
		Row row2 = null;
		Row row3 = null;
		Row row4 = null;
		Cell cell = null;
		XSSFSheet sheet = null;
		LOG.info("inside writeHeaderDataToExcel,, excelHeaderList size:" + excelHeaderListLcl.size());
		sheet = (XSSFSheet) varMap.get("sheet");
		if (excelHeaderListLcl.size() != 0) {
			LOG.info("Size greater than zero...");
			if (excelHeaderListLcl.size() == 1) {
				row1 = sheet.createRow(0);
				row1.setHeight((short) 1500);
				row2 = sheet.createRow(1);
				row2.setHeight((short) 1500);
				row3 = sheet.createRow(2);
				row3.setHeight((short) 2500);
				row4 = sheet.createRow(3);
				row4.setHeight((short) 2500);
			} else {
				row1 = sheet.createRow(0);
				row1.setHeight((short) 1500);
				row2 = sheet.createRow(1);
				row2.setHeight((short) 5000);
				row3 = sheet.createRow(2);
				row3.setHeight((short) 2500);
				row4 = sheet.createRow(3);
				row4.setHeight((short) 9000);
			}
			int headerListSize = excelHeaderListLcl.size();
			int initial = 0;
			int cellno = 0;

			XSSFCellStyle headerLinkStyle = (XSSFCellStyle) varMap.get("headerLinkStyle");
			XSSFCreationHelper helper = (XSSFCreationHelper) varMap.get("helper");

			for (PLMGBomData excelHeader : excelHeaderListLcl) {
				if (initial < headerListSize) {
					cellno = 3 + initial;


					cell = row1.createCell(cellno);
					cell.setCellValue(excelHeader.getHeaderConfFeature());
					XSSFHyperlink url_link = helper.createHyperlink(Hyperlink.LINK_URL);
					url_link.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + excelHeader.getCfId());
					cell.setHyperlink(url_link);
					cell.setCellStyle(headerLinkStyle);

					row2.createCell(cellno).setCellValue(excelHeader.getHeaderConfFeatureDispName());
					row2.getCell(cellno).setCellStyle(headerCellStyle);
					row3.createCell(cellno).setCellValue(excelHeader.getHeaderConfOption());
					row3.getCell(cellno).setCellStyle(headerCellStyle);
					row4.createCell(cellno).setCellValue(excelHeader.getHeaderConfOptionDispName());
					row4.getCell(cellno).setCellStyle(headerCellStyle);
					initial++;
				}
			}
		}

		LOG.info("Existing writeHeaderDataToExcel()");
	}


	/**
	 * This method is used for writeGBOMDataToExcel
	 * 
	 * @param varMap,gbomDataListLcl1,excelHeaderListLcl1
	 * @throws PLMCommonException
	 */
	private void writeGBOMDataToExcel(Map<String, Object> varMap, List<PLMGBomData> gbomDataListLcl1, List<PLMGBomData> excelHeaderListLcl1) throws PLMCommonException {

		LOG.info("Inside writeGBOMDataToExcel()");
		XSSFSheet sheet = null;


		XSSFCellStyle hyperLinkStyle = (XSSFCellStyle) varMap.get("hyperLinkStyle");
		XSSFCreationHelper helper = (XSSFCreationHelper) varMap.get("helper");


		LOG.info("inside writeGBOMDataToExcel,, gbomDataList size:" + gbomDataListLcl1.size());
		sheet = (XSSFSheet) varMap.get("sheet");
		sheet.setColumnWidth(0, 6000);
		sheet.setColumnWidth(1, 6000);
		sheet.setColumnWidth(2, 6000);
		if (gbomDataListLcl1.size() != 0) {
			LOG.info("Size greater than zero...");
			int rowno = 3;
			String newMktName = "";
			String childFeatId = "";
			String newCIDisp = "";
			String gbomPartId = "";
			String newGBOMPart = "";
			String oldMktName = "";
			String oldCIDisp = "";
			String oldGBOMPart = "";

			XSSFRow headerRow = sheet.getRow(3);
			headerRow.createCell(0).setCellValue("Frame(Product Line)");
			headerRow.getCell(0).setCellStyle(normalCellStyle);
			headerRow.createCell(1).setCellValue("CI Display Name");
			headerRow.getCell(1).setCellStyle(normalCellStyle);
			headerRow.createCell(2).setCellValue("GBOM Part");
			headerRow.getCell(2).setCellStyle(normalCellStyle);

			for (PLMGBomData gbomData : gbomDataListLcl1) {
				newMktName = gbomData.getProductLine();
				childFeatId = gbomData.getChildFeatId();
				newCIDisp = gbomData.getCiDispName();
				gbomPartId = gbomData.getGbomPartId();
				newGBOMPart = gbomData.getGbomPart();
				Row row = null;
				Cell cell = null;
				if ((!newMktName.equals(oldMktName)) || (!newCIDisp.equals(oldCIDisp)) || (!newGBOMPart.equals(oldGBOMPart))) {
					rowno++;
					uniqGbomPartSize++;
					row = sheet.createRow(rowno);
					cell = row.createCell(0);

					cell.setCellValue(newMktName);


					cell = row.createCell(1);
					cell.setCellValue(newCIDisp);
					XSSFHyperlink url_link1 = helper.createHyperlink(Hyperlink.LINK_URL);
					url_link1.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + childFeatId);
					cell.setHyperlink(url_link1);
					cell.setCellStyle(hyperLinkStyle);

					cell = row.createCell(2);
					cell.setCellValue(newGBOMPart);
					XSSFHyperlink url_link2 = helper.createHyperlink(Hyperlink.LINK_URL);
					url_link2.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + gbomPartId);
					cell.setHyperlink(url_link2);
					cell.setCellStyle(hyperLinkStyle);

					oldMktName = newMktName;
					oldCIDisp = newCIDisp;
					oldGBOMPart = newGBOMPart;
					// Writing X or O

					int cellNum = 0;
					String cfName = "";
					String coName = "";

					int headerSize = excelHeaderListLcl1.size();

					if (!PLMUtils.checkNullVal(gbomData.getConfFeatureName()).equals("")) {
						cfName = gbomData.getConfFeatureName();

						if (!PLMUtils.checkNullVal(gbomData.getConfOptnName()).equals("")) {
							coName = gbomData.getConfOptnName();

							for (int k = 0; k < headerSize; k++) {
								cellNum = k + 3;
								String headerCFName = sheet.getRow(0).getCell(cellNum).getStringCellValue();
								String headerCOName = sheet.getRow(2).getCell(cellNum).getStringCellValue();
								if (cfName.equals(headerCFName) && coName.equals(headerCOName)) {
									sheet.getRow(rowno).createCell(cellNum).setCellValue("X");
									sheet.getRow(rowno).getCell(cellNum).setCellStyle(normalCellStyle);
								} else if (cfName.equals(headerCFName) && !coName.equals(headerCOName)) {
									if (sheet.getRow(rowno).getCell(cellNum) == null) {
										sheet.getRow(rowno).createCell(cellNum).setCellValue("O");
										sheet.getRow(rowno).getCell(cellNum).setCellStyle(normalCellStyle);
									}
								}

							}

						}
					} else {
						sheet.getRow(rowno).createCell(3).setCellValue("X");
						sheet.getRow(rowno).getCell(3).setCellStyle(normalCellStyle);
					}



				} else {
					int cellNum = 0;
					String cfName = "";
					String coName = "";

					int headerSize = excelHeaderListLcl1.size();

					if (!PLMUtils.checkNullVal(gbomData.getConfFeatureName()).equals("")) {
						cfName = gbomData.getConfFeatureName();

						if (!PLMUtils.checkNullVal(gbomData.getConfOptnName()).equals("")) {
							coName = gbomData.getConfOptnName();

							for (int k = 0; k < headerSize; k++) {
								cellNum = k + 3;
								String headerCFName = sheet.getRow(0).getCell(cellNum).getStringCellValue();
								String headerCOName = sheet.getRow(2).getCell(cellNum).getStringCellValue();
								if (cfName.equals(headerCFName) && coName.equals(headerCOName)) {
									sheet.getRow(rowno).createCell(cellNum).setCellValue("X");
									sheet.getRow(rowno).getCell(cellNum).setCellStyle(normalCellStyle);
								} else if (cfName.equals(headerCFName) && !coName.equals(headerCOName)) {

									if (sheet.getRow(rowno).getCell(cellNum) == null) {
										sheet.getRow(rowno).createCell(cellNum).setCellValue("O");
										sheet.getRow(rowno).getCell(cellNum).setCellStyle(normalCellStyle);
									}
								}
							}

						}
					} else {
						sheet.getRow(rowno).createCell(3).setCellValue("X");
						sheet.getRow(rowno).getCell(3).setCellStyle(normalCellStyle);
					}

				}
			}
		}
		LOG.info("Unique GBOM Part size in Excel:" + uniqGbomPartSize);
		LOG.info("Existing writeGBOMDataToExcel()");

	}


	/**
	 * This method is used for writeDataToExcelFile
	 * 
	 * @param varMap
	 * @throws PLMCommonException
	 */
	private void writeDataToExcelFile(Map<String, Object> varMap) throws IOException, PLMCommonException {

		LOG.info("Inside writeDataToExcelFile()");
		XSSFWorkbook workbook = (XSSFWorkbook) varMap.get("workbook");
		FileOutputStream outFile = null;
		String filePathXls = (String) varMap.get("filePathXls");
		try {
			outFile = new FileOutputStream(new File(filePathXls));
			workbook.write(outFile);
		} catch (IOException ioexception) {
			PLMUtils.checkException(ioexception.getMessage());
			LOG.log(Level.ERROR, "Exception@writeDataToExcelFile: ", ioexception);
		} finally {
			if (outFile != null) {
				try {
					outFile.close();
				} catch (IOException e) {
					PLMUtils.checkException(e.getMessage());
				}
			}
		}
		LOG.info("Existing writeDataToExcelFile()");
	}


	/**
	 * This method is used for sendGBOMMail
	 * 
	 * @param varMap
	 * @throws PLMCommonException
	 * @throws PWiException
	 */
	private void sendGBOMMail(Map<String, Object> varMap) throws PLMCommonException, PWiException {

		LOG.info("Entering sendMail Method");
		String from = PLMConstants.BVS_MAIL_FROM;

		String toEmailId = userEmail;
		LOG.info("userEmail >>>>>>>>>>>>>>>>>>>>" + toEmailId);
		String toAddressee = userName;
		LOG.info("userName >>>>>>>>>>>>>>>>>>>>" + toAddressee);

		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.GBOM_MAIL_SUBJECT;
		StringBuffer mailBody = new StringBuffer().append(toAddressee);

		varMap.put("to", toEmailId);
		varMap.put("toAddressee", toAddressee);
		varMap.put("subject", subject);
		mailBody.append(PLMConstants.GBOM_MAIL_CONTENT + "\n");
		mailBody.append("Search Criteria" + "\n");
		mailBody.append("---------------" + "\n");
		mailBody.append("Product Line:" + selectedModelMktNamesList.toString() + "\n");
		mailBody.append("Frame Type:" + selectedTfDisplayNamesList.toString() + "\n\n");
		mailBody.append("CI Nomenclature:" + selectedCiNomenNamesList.toString() + "\n");
		mailBody.append(PLMConstants.GBOM_MAIL_SIGNATURE).append(PLMConstants.GBOM_MAIL_FOOTER);
		PLMUtils.sendMailWithAttachment(from, toEmailId, subject, mailBody.toString(), (String) varMap.get("filePathZip"));
		LOG.info("Exiting sendMail Method");
	}


	/**
	 * This method is used for recordsPerPageListner
	 * 
	 * @param event
	 * 
	 */
	public void recordsPerPageListner(ActionEvent event) {

		LOG.info("Entering recordsPerPageListner method");
		LOG.info("Action listner called.....--------------------------->" + recordCounts);
		if (recordCounts == 15) {
			LOG.info("15");
			recordCounts = 15;
		} else if (recordCounts == 30) {
			LOG.info("30");
			recordCounts = 30;
		} else if (recordCounts == 50) {
			LOG.info("50");
			recordCounts = 50;
		} else if (recordCounts == 100) {
			LOG.info("100");
			recordCounts = 100;
		} else if (recordCounts == 200) {
			LOG.info("200");
			recordCounts = 200;
		}

		else if (recordCounts == gbomDataCount) {
			LOG.info("All");
			recordCounts = gbomDataCount;
		}
		LOG.info("final value.....--------------------------->" + recordCounts);
	}


	/**
	 * This method is used for splitString
	 * 
	 * @param str
	 * @return String
	 */
	public String splitString(String str) {

		String combined = "";
		if (str != null) {
			// updated for bug fix avoid to Call to equals() with null argument
			if (!PLMUtils.isEmpty(str)) {

				if (str.length() < 11) {
					LOG.info("Length < 11");
					combined = str;
				} else if (str.length() > 11 && str.length() <= 22) {
					LOG.info("Length < 22");
					String part1 = str.substring(0, 10);
					String part2 = str.substring(10);
					combined = part1 + "\n" + part2;
					LOG.info("combined=" + combined);
				} else if (str.length() > 22 && str.length() <= 33) {
					LOG.info("Length < 33");
					String part1 = str.substring(0, 10);
					String part2 = str.substring(10, 21);
					String part3 = str.substring(21);
					combined = part1 + "\n" + part2 + "\n" + part3;
					LOG.info("combined=" + combined);
				} else if (str.length() > 33 && str.length() <= 44) {
					LOG.info("Length < 44");
					String part1 = str.substring(0, 10);
					String part2 = str.substring(10, 21);
					String part3 = str.substring(21, 32);
					String part4 = str.substring(32);
					combined = part1 + "\n" + part2 + "\n" + part3 + "\n" + part4;
					LOG.info("combined=" + combined);
				} else if (str.length() > 44 && str.length() <= 55) {
					LOG.info("Length < 55");
					String part1 = str.substring(0, 10);
					String part2 = str.substring(10, 21);
					String part3 = str.substring(21, 32);
					String part4 = str.substring(32, 43);
					String part5 = str.substring(43);
					combined = part1 + "\n" + part2 + "\n" + part3 + "\n" + part4 + "\n" + part5;
					LOG.info("combined=" + combined);
				} else if (str.length() > 55 && str.length() <= 66) {
					LOG.info("Length < 66");
					String part1 = str.substring(0, 10);
					String part2 = str.substring(10, 21);
					String part3 = str.substring(21, 32);
					String part4 = str.substring(32, 43);
					String part5 = str.substring(43, 54);
					String part6 = str.substring(54);
					combined = part1 + "\n" + part2 + "\n" + part3 + "\n" + part4 + "\n" + part5 + "\n" + part6;
				} else if (str.length() > 66 && str.length() <= 77) {
					LOG.info("Length < 77");
					String part1 = str.substring(0, 10);
					String part2 = str.substring(10, 21);
					String part3 = str.substring(21, 32);
					String part4 = str.substring(32, 43);
					String part5 = str.substring(43, 54);
					String part6 = str.substring(54, 65);
					String part7 = str.substring(65);
					combined = part1 + "\n" + part2 + "\n" + part3 + "\n" + part4 + "\n" + part5 + "\n" + part6 + "\n" + part7;
				} else if (str.length() > 77 && str.length() <= 88) {
					LOG.info("Length < 88");
					String part1 = str.substring(0, 10);
					String part2 = str.substring(10, 21);
					String part3 = str.substring(21, 32);
					String part4 = str.substring(32, 43);
					String part5 = str.substring(43, 54);
					String part6 = str.substring(54, 65);
					String part7 = str.substring(65, 76);
					String part8 = str.substring(76);
					combined = part1 + "\n" + part2 + "\n" + part3 + "\n" + part4 + "\n" + part5 + "\n" + part6 + "\n" + part7 + "\n" + part8;
				} else if (str.length() > 88 && str.length() <= 99) {
					LOG.info("Length < 99");
					String part1 = str.substring(0, 10);
					String part2 = str.substring(10, 21);
					String part3 = str.substring(21, 32);
					String part4 = str.substring(32, 43);
					String part5 = str.substring(43, 54);
					String part6 = str.substring(54, 65);
					String part7 = str.substring(65, 76);
					String part8 = str.substring(76, 87);
					String part9 = str.substring(87);
					combined = part1 + "\n" + part2 + "\n" + part3 + "\n" + part4 + "\n" + part5 + "\n" + part6 + "\n" + part7 + "\n" + part8 + "\n" + part9;
				} else if (str.length() > 99 && str.length() <= 110) {
					LOG.info("Length < 110");
					String part1 = str.substring(0, 10);
					String part2 = str.substring(10, 21);
					String part3 = str.substring(21, 32);
					String part4 = str.substring(32, 43);
					String part5 = str.substring(43, 54);
					String part6 = str.substring(54, 65);
					String part7 = str.substring(65, 76);
					String part8 = str.substring(76, 87);
					String part9 = str.substring(87, 98);
					String part10 = str.substring(98);
					combined = part1 + "\n" + part2 + "\n" + part3 + "\n" + part4 + "\n" + part5 + "\n" + part6 + "\n" + part7 + "\n" + part8 + "\n" + part9 + "\n" + part10;
				} else {
					combined = str;
				}
			}
		} else {
			combined = "";
		}
		return combined;

	}


	// Added for FIR

	public void recordsPerPageListnerFir(ActionEvent event) {

		LOG.info("Entering recordsPerPageListnerFir method");
		LOG.info("FIR Action listner called.....--------------------------->" + recordCountsFir);
		if (recordCountsFir == 15) {
			LOG.info("15");
			recordCountsFir = 15;
		} else if (recordCountsFir == 30) {
			LOG.info("30");
			recordCountsFir = 30;
		} else if (recordCountsFir == 50) {
			LOG.info("50");
			recordCountsFir = 50;
		} else if (recordCountsFir == 100) {
			LOG.info("100");
			recordCountsFir = 100;
		} else if (recordCountsFir == 200) {
			LOG.info("200");
			recordCountsFir = 200;
		}

		else if (recordCountsFir == firDataCount) {
			LOG.info("All");
			recordCountsFir = firDataCount;
		}
		LOG.info("FIR final value.....--------------------------->" + recordCountsFir);
	}


	public String resetFeatImptReptData() {

		LOG.info("Entering resetFeatImptReptData");
		String fwdFlag = "";
		featImptReptTab1DataList.clear();
		featImptReptTab2DataList.clear();
		firDataCount1 = 0;
		headerCFNamesList1Fir.clear();
		headerCFNamesListFir.clear();
		excelHeaderListFir.clear();
		firDataNewList.clear();
		alertMessage = "";
		productLineList.clear();
		frameTypeList.clear();
		featureNameListSI.clear();
		selectedProductLine = "";
		selectedFrameType = "";
		featureNameList.clear();
		selectedHwPrdNameList1.clear();
		featImptReptTab1DataListNew.clear();
		hwPrdMapFir.clear();
		tab2InputData.clear();
		featName = "";
		// VT_TABLE_NAME = "";

		try {
			fwdFlag = loadFeatImptReptSearchPage();
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@resetSearchData PLMGBomMB:", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(), commonMB, "home", "Feature Impact Report");
		}
		LOG.info("Existing resetSearchData");
		return fwdFlag;

	}


	/**
	 * This method is used for Loading Feature Impact Report Page
	 * 
	 * @return String
	 */
	public String loadFeatImptReptSearchPage() {

		LOG.info("Entering loadFeatImptReptSearchPage Method");
		String fwdFlag = "";
		
		try {
			commonMB.insertCannedRptRecordHitInfo("Feature Impact Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			productLineList = new ArrayList<SelectItem>();
			frameTypeList = new ArrayList<SelectItem>();
			featureNameListSI = new ArrayList<SelectItem>();
			selectedProductLine = "";
			selectedFrameType = "";
			featImptReptTab1DataListNew.clear();
			featImptReptTab1DataList.clear();
			featImptReptTab2DataList.clear();
			firDataCount1 = 0;
			headerCFNamesList1Fir.clear();
			headerCFNamesListFir.clear();
			excelHeaderListFir.clear();
			firDataNewList.clear();
			alertMessage = "";
			tab2InputData.clear();
			featName = "";
			// VT_TABLE_NAME = "";
			SelectItem stdText = new SelectItem("stdTxt", "Please select Product Line, Frame Type");
			featureNameListSI.add(stdText);
			productLineList = plmGBomService.getFeatImptReptDrpDwnData();
			Collections.sort(productLineList, new PLMUtils.SortListSelItmLbl());
			LOG.info("productLineList size in MB ==" + productLineList.size());
			fwdFlag = "featImptReptSearch";
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@loadFeatImptReptSearchPage:", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(), commonMB, "home", "Feature Impact Report");
		}
		LOG.info("Exiting loadFeatImptReptSearchPage Method");
		return fwdFlag;
	}


	public void productLineListner(ActionEvent ae) {

		try {
			LOG.info("Entering productLineListner Method");
			frameTypeList.clear();
			featureNameListSI.clear();
			SelectItem stdText = new SelectItem("stdTxt", "Please select Frame Type");
			featureNameListSI.add(stdText);
			frameTypeList = (List<SelectItem>) plmGBomService.getFrameTypeData(selectedProductLine);
			Collections.sort(frameTypeList, new PLMUtils.SortListSelItmLbl());
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@productLineListner:", exception);
		}
		LOG.info("Exiting productLineListner Method");

	}


	public void frameTypeListner(ActionEvent ae) {

		try {
			LOG.info("Entering frameTypeListner Method");
			featureNameList.clear();
			featureNameList = plmGBomService.getFeatureNameList(selectedProductLine, selectedFrameType);
			selectedHwPrdNameList1.clear();
			for (PLMGBomData hwPrd : featureNameList) {
				selectedHwPrdNameList1.add(hwPrd.getModelName());
				hwPrdMapFir.put(hwPrd.getModelName(), hwPrd.getFrameType());
			}

			Map<String, List<PLMGBomData>> datamap = plmGBomService.getCFList(selectedHwPrdNameList1);
			List<PLMGBomData> cfList = datamap.get("CFNameList");

			featureNameListSI = new ArrayList<SelectItem>();
			for (PLMGBomData data : cfList) {
				String label = data.getCfName() + " : " + data.getCfDispName();
				featureNameListSI.add(new SelectItem(data.getCfName(), label));
			}
			Collections.sort(featureNameListSI, new PLMUtils.SortListSelItmLbl());
			cfList.clear();
			LOG.info("featureNameListSI fetched with size" + featureNameListSI.size());
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@frameTypeListner PLMGBomMB:", exception);
		}
		LOG.info("Exiting frameTypeListner method");

	}


	public String showOnScreenFeatImptRept() throws PLMCommonException {

		LOG.info("Entering showOnScreenFeatImptRept Method");
		Map<String, Object> varMap = new HashMap<String, Object>();
		excelHeaderListFir.clear();
		featImptReptTab1DataListNew.clear();
		/*
		 * int var = 0; int var1 =0;
		 */
		try {
			if (!(selectedProductLine == null) && !(selectedFrameType == null) && !(selectedFeatureName == null)) {

				varMap.put("selectedProductLine", selectedProductLine);
				varMap.put("selectedFrameType", selectedFrameType);
				varMap.put("selectedFeatureName", selectedFeatureName);
				varMap.put("selectedHwPrdNameList1", selectedHwPrdNameList1);
				// Map<String ,List<PLMGBomData>> tabMap = new HashMap<String, List<PLMGBomData>>();
				Map<String, List<PLMGBomData>> tabMap = plmGBomService.getFeatImptReptTab1Data(varMap, hwPrdMapFir);

				if (null != tabMap && tabMap.size() > 0) {
					featImptReptTab1DataList = tabMap.get("featImptReptList");
					featImptReptTab2DataList = tabMap.get("featImptReptList1");
				}

				firDataCount = featImptReptTab1DataList.size();
				if (featImptReptTab1DataList.size() == 0 && featImptReptTab2DataList.size() == 0) {
					alertMessage = "No Data Exists for the selected combination of Input..Please try with different input values...";
					LOG.info("featImptReptTab1DataList size is Zero...");
					LOG.info(alertMessage);
					return "featImptReptSearch";
				}
				firDataCount1 = featImptReptTab1DataList.size();
				LOG.info("Inside GBOM MB, fetched featImptReptTab1DataList with size" + featImptReptTab1DataList.size());
				for (PLMGBomData gbomdata : featImptReptTab1DataList) {
					String plinekey = gbomdata.getMktName();
					gbomdata.setProductLine((String) hwPrdMapFir.get(plinekey));
				}

				if (featImptReptTab1DataList.size() != 0) {
					LOG.info("Inside if(featImptReptTab1DataList.size() != 0)");
					headerCFNamesList1Fir = new ArrayList<String>();
					for (PLMGBomData gbomData : featImptReptTab1DataList) {
						if (!(PLMUtils.checkNullVal(gbomData.getConfFeatureName())).equals("")) {
							headerCFNamesList1Fir.add(gbomData.getConfFeatureName());
						}
					}
				}

				if (featImptReptTab2DataList.size() != 0) {
					LOG.info("Inside if(featImptReptTab2DataList() != 0)");
					headerCFNamesList1Fir = new ArrayList<String>();
					for (PLMGBomData gbomData : featImptReptTab2DataList) {
						if (!(PLMUtils.checkNullVal(gbomData.getConfFeatureName())).equals("")) {
							headerCFNamesList1Fir.add(gbomData.getConfFeatureName());
						}
					}

				}

				if (!selectedFeatureName.equals("")) {
					headerCFNamesListFir = new ArrayList<String>();
					LOG.info("selectedFeatureName<<<<<<>>>>>>>. " + selectedFeatureName);
					headerCFNamesListFir.add(selectedFeatureName);
				}

				LOG.info("Size of Unique List:" + headerCFNamesListFir.size());
				if (headerCFNamesListFir.size() != 0) {
					excelHeaderListFir = plmGBomService.getExcelHeaderListFir(headerCFNamesListFir);
					selectedFeatDispName = excelHeaderListFir.get(0).getHeaderConfFeatureDispName();
					LOG.info("Inside GBOM MB, fetched excelHeaderListFir with size" + excelHeaderListFir.size());
				} else {
				}

				firDataNewList.clear();
				PLMGBomData gbomDataNew = new PLMGBomData();
				String plineNew = "";
				String plineOld = "";
				String childFeatId = "";
				String ciDispNmNew = "";
				String ciDispNmOld = "";
				String gbomPartId = "";
				String gbomPartNew = "";
				String gbomPartOld = "";
				LOG.info("excelHeaderListFir.size()------------->" + excelHeaderListFir.size());
				String[] compValue = new String[excelHeaderListFir.size()];
				Map<String, PLMGBomData> tempMap = new HashMap<String, PLMGBomData>();

				int rowNum = 0;
				LOG.info("List of Config Features and Options for GBOM Report$$$$$$$");


				for (PLMGBomData headerdata : excelHeaderListFir) {
					tempMap.put(rowNum + "", headerdata);
					rowNum++;
				}

				for (PLMGBomData gbomdata : featImptReptTab1DataList) {
					plineNew = gbomdata.getProductLine();
					childFeatId = gbomdata.getChildFeatId();
					ciDispNmNew = gbomdata.getCiDispName();
					gbomPartId = gbomdata.getGbomPartId();
					gbomPartNew = gbomdata.getGbomPart();

					if (!plineNew.equals(plineOld) || !ciDispNmNew.equals(ciDispNmOld) || !gbomPartNew.equals(gbomPartOld)) {
						if (!"".equals(plineOld)) {
							featImptReptTab1DataListNew.add(gbomDataNew);
						}
						gbomDataNew = new PLMGBomData();
						compValue = new String[excelHeaderListFir.size()];
					}

					String confFeat = gbomdata.getConfFeatureName();
					String confOptn = gbomdata.getConfOptnName();

					if (!PLMUtils.checkNullVal(confFeat).equals("")) {
						List<String> keyList = new ArrayList<String>(tempMap.keySet());
						for (String keyVal : keyList) {

							PLMGBomData headerData = (PLMGBomData) tempMap.get(keyVal);
							String headerConfFeat = headerData.getHeaderConfFeature();
							String headerConfOptn = headerData.getHeaderConfOption();

							if (confFeat.equals(headerConfFeat) && confOptn.equals(headerConfOptn)) {
								compValue[Integer.parseInt(keyVal)] = "X";
							}
							if (confFeat.equals(headerConfFeat) && !confOptn.equals(headerConfOptn) && !"X".equalsIgnoreCase(compValue[Integer.parseInt(keyVal)])) {
								compValue[Integer.parseInt(keyVal)] = "O";
							}

						}
						gbomdata.setCompValue(compValue);
						for (int j = 1; j < compValue.length; j++) {
							if (null == compValue[j])
								compValue[j] = "";
						}
					} else {
						compValue[0] = "X";
						for (int j = 1; j < compValue.length; j++) {
							compValue[j] = "";
						}
						gbomdata.setCompValue(compValue);
					}

					if (!plineNew.equals(plineOld) || !ciDispNmNew.equals(ciDispNmOld) || !gbomPartNew.equals(gbomPartOld)) {
						gbomDataNew.setProductLine(plineNew);
						gbomDataNew.setChildFeatId(childFeatId);
						gbomDataNew.setCiDispName(ciDispNmNew);
						gbomDataNew.setGbomPartId(gbomPartId);
						gbomDataNew.setGbomPart(gbomPartNew);
						gbomDataNew.setCompValue(compValue);
					}

					plineOld = plineNew;
					ciDispNmOld = ciDispNmNew;
					gbomPartOld = gbomPartNew;
				}
				if (featImptReptTab1DataList.size() > 0) {
					featImptReptTab1DataListNew.add(gbomDataNew);
					heightPX = PLMUtils.getTableHeight(featImptReptTab1DataListNew.size());
					// var = Integer.parseInt(heightPX.substring(0, heightPX.length() - 2)) - 40;
					// var = var - 40;
					countTab1 = featImptReptTab1DataListNew.size();
					LOG.info("featImptReptTab1DataListNew size >>> " + featImptReptTab1DataListNew.size());
				}



				// Adding to Map for for tab2 query
				List<String> coNameList = new ArrayList<String>();
				for (PLMGBomData gbomdata : excelHeaderListFir) {
					coNameList.add(gbomdata.getHeaderConfOption());
				}

				tab2InputData.put("coNameList", coNameList);
				tab2InputData.put("selectedFeatureName", selectedFeatureName);
				tab2InputData.put("selectedHwPrdNameList1", selectedHwPrdNameList1);


				Map<String, List<PLMGBomData>> finalTab2map = plmGBomService.getFeatImptReptTab2Data(tab2InputData);
				List<String> keyList = new ArrayList<String>(finalTab2map.keySet());
				LOG.info("keyList inMB >>>>>>>>>>>>>>>>>>>>> " + keyList);
				for (int j = 0; j < excelHeaderListFir.size(); j++) {

					List<PLMGBomData> tempList = (List<PLMGBomData>) finalTab2map.get(excelHeaderListFir.get(j).getHeaderConfOption());
					if (null != tempList && tempList.size() > 0) {
						PLMGBomData data = tempList.get(j);
						excelHeaderListFir.get(j).setStrAdd(data.getStrAdd());
						excelHeaderListFir.get(j).setStrDel(data.getStrDel());
					}
				}
				boolean hasData = false;
				for (PLMGBomData data : excelHeaderListFir) {
					if ((!PLMUtils.isEmpty(data.getStrAdd()) && data.getStrAdd().length() > 0) || (!PLMUtils.isEmpty(data.getStrDel()) && data.getStrDel().length() > 0)) {
						hasData = true;
						break;
					}
				}

				if (featImptReptTab1DataListNew.size() > 0) {
					tab1Flag = true;
				} else {
					tab1Flag = false;
				}

				if (hasData) {
					tab2Flag = true;
				} else {
					tab2Flag = false;
				}
				countTab2 = excelHeaderListFir.size();
				heightPX1 = PLMUtils.getTableHeight(excelHeaderListFir.size());
				// var1 = Integer.parseInt(heightPX1.substring(0, heightPX1.length() - 2)) - 40;
				// var1 = var1 - 40;

			} else {
				alertMessage = "Please Select value from Each ListBox...";
				LOG.info(alertMessage);
				return "featImptReptSearch";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@showOnScreenFeatImptRept: PLMCommonException", exception);
			String fwdflag = "";
			LOG.log(Level.ERROR, "Exception@showOnScreenFeatImptRept: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(), commonMB, "featImptReptSearch", "Feature Impact Report");
			return fwdflag;
		}
		LOG.info("Exiting showGBOMReport Method");
		return "featImptReptOnScreen";
	}


	public void sendEmailFir() throws PWiException {

		if (!(selectedProductLine == null) && !(selectedFrameType == null) && !(selectedFeatureName == null)) {
			alertMessage = PLMConstants.FIR_MAIL_ALERT_MSG;
			userName = UserInfoPortalUtil.getInstance().getUserName();
			userEmail = UserInfoPortalUtil.getInstance().getUserEmail();
			taskExecutor.execute(new FirEmailThread());
		} else {
			alertMessage = "Please Select One or more values from Each ListBox";
		}
	}


	/**
	 * Background Process Thread
	 */
	private class FirEmailThread implements Runnable {

		public FirEmailThread() {

		}


		public void run() {

			try {
				generateFirEmailReport();
			} catch (Exception exception) {
				LOG.log(Level.ERROR, "Exception@run() of FirEmailThread: ", exception);
			}
		}
	}


	public String generateFirEmailReport() throws PLMCommonException {

		LOG.info("Entering generateFirEmailReport Method");
		Map<String, Object> varMap = new HashMap<String, Object>();
		String toEmailId = userEmail;
		LOG.info("userEmail >>>>>>>>>>>>>>>>>>>>" + toEmailId);
		String toAddressee = userName;
		LOG.info("userName >>>>>>>>>>>>>>>>>>>>" + toAddressee);
		toAddressee = "Dear " + toAddressee + ", \n\n";
		try {
			// Start
			if (!(selectedProductLine == null) && !(selectedFrameType == null) && !(selectedFeatureName == null)) {
				LOG.info("Values from all 3 listbox selected..inside if...");
				varMap.put("selectedProductLine", selectedProductLine);
				varMap.put("selectedFrameType", selectedFrameType);
				varMap.put("selectedFeatureName", selectedFeatureName);
				varMap.put("selectedHwPrdNameList1", selectedHwPrdNameList1);

				Map<String, List<PLMGBomData>> tabMap = plmGBomService.getFeatImptReptTab1Data(varMap, hwPrdMapFir);
				if (null != tabMap && tabMap.size() > 0) {
					featImptReptTab1DataList = tabMap.get("featImptReptList");
					featImptReptTab2DataList = tabMap.get("featImptReptList1");
				}

				// if FIRDataList is empty send no data email
				if (featImptReptTab1DataList.size() != 0 || featImptReptTab2DataList.size() != 0) {
					firDataCount = featImptReptTab1DataList.size();
					LOG.info("Inside GBOM MB, fetched featImptReptTab1DataList with size" + featImptReptTab1DataList.size());
					for (PLMGBomData gbomdata : featImptReptTab1DataList) {
						String plinekey = gbomdata.getMktName();
						gbomdata.setProductLine((String) hwPrdMapFir.get(plinekey));
					}

					if (featImptReptTab1DataList.size() != 0) {
						LOG.info("Inside if(featImptReptTab1DataList.size() != 0)");
						headerCFNamesList1Fir = new ArrayList<String>();
						headerCFNamesListFir = new ArrayList<String>();
						for (PLMGBomData gbomData : featImptReptTab1DataList) {
							if (!(PLMUtils.checkNullVal(gbomData.getConfFeatureName())).equals("")) {
								headerCFNamesList1Fir.add(gbomData.getConfFeatureName());
							}
						}
						LOG.info("headerCFNamesListFir size with duplicates:" + headerCFNamesListFir.size());

						headerCFNamesListFir.add(selectedFeatureName);
					}

					if (featImptReptTab2DataList.size() != 0 && headerCFNamesListFir.size() == 0) {
						LOG.info("Inside if(featImptReptTab2DataList() != 0)");
						headerCFNamesList1Fir = new ArrayList<String>();
						headerCFNamesListFir = new ArrayList<String>();
						for (PLMGBomData gbomData : featImptReptTab2DataList) {
							if (!(PLMUtils.checkNullVal(gbomData.getConfFeatureName())).equals("")) {
								headerCFNamesList1Fir.add(gbomData.getConfFeatureName());
							}
						}
						LOG.info("headerCFNamesListFir size with duplicates:" + headerCFNamesListFir.size());

						headerCFNamesListFir.add(selectedFeatureName);
					}
					LOG.info("Size of Unique List:" + headerCFNamesListFir.size());
					excelHeaderListFir = plmGBomService.getExcelHeaderListFir(headerCFNamesListFir);
					LOG.info("Inside GBOM MB, fetched excelHeaderListFir with size" + excelHeaderListFir.size());

					// Adding to Map for for tab2 query
					List<String> coNameList = new ArrayList<String>();
					for (PLMGBomData gbomdata : excelHeaderListFir) {
						coNameList.add(gbomdata.getHeaderConfOption());
					}

					tab2InputData.put("coNameList", coNameList);
					tab2InputData.put("selectedFeatureName", selectedFeatureName);
					tab2InputData.put("selectedHwPrdNameList1", selectedHwPrdNameList1);


					Map<String, List<PLMGBomData>> finalTab2map = plmGBomService.getFeatImptReptTab2Data(tab2InputData);
					List<String> keyList = new ArrayList<String>(finalTab2map.keySet());
					LOG.info("keyList inMB >>>>>>>>>>>>>>>>>>>>> " + keyList);
					for (int j = 0; j < excelHeaderListFir.size(); j++) {
						List<PLMGBomData> tempList = (List<PLMGBomData>) finalTab2map.get(excelHeaderListFir.get(j).getHeaderConfOption());
						LOG.info("excelHeaderListFir.get(j).getHeaderConfOption() " + excelHeaderListFir.get(j).getHeaderConfOption());
						if (null != tempList && tempList.size() > 0) {
							PLMGBomData data = tempList.get(j);
							excelHeaderListFir.get(j).setStrAdd(data.getStrAdd());
							excelHeaderListFir.get(j).setStrDel(data.getStrDel());
						}
					}
					if (featImptReptTab1DataList.size() != 0 || featImptReptTab2DataList.size() != 0) {
						prepareExcelWorkBookFir(varMap);
						writeFirHeaderDataToExcel(varMap, excelHeaderListFir);
						if (featImptReptTab1DataList.size() != 0 || featImptReptTab2DataList.size() != 0) {
							writeFirDataToExcel(varMap, featImptReptTab1DataList, excelHeaderListFir);
						}
						writeDataToExcelFile(varMap);
						PLMUtils.generateZipFile((List<String>) varMap.get("filePathXlsLst"), (String) varMap.get("filePathZip"), false);
						sendFIRMail(varMap);
					} else {
						StringBuffer noDataMailBody = new StringBuffer().append(toAddressee);
						noDataMailBody.append(PLMConstants.FIR_NO_CONTENT_BODY + "\n");
						noDataMailBody.append("Search Criteria" + "\n");
						noDataMailBody.append("---------------" + "\n");
						noDataMailBody.append("Product Line:" + selectedProductLine + "\n");
						noDataMailBody.append("Frame Type:" + selectedFrameType + "\n\n");
						noDataMailBody.append("CI Nomenclature:" + selectedFeatureName + "\n");
						noDataMailBody.append(PLMConstants.GBOM_MAIL_SIGNATURE).append(PLMConstants.GBOM_MAIL_FOOTER);
						PLMUtils.sendMail(PLMConstants.BVS_MAIL_FROM, toEmailId, PLMConstants.FIR_MAIL_SUBJECT, noDataMailBody.toString());
						LOG.info("featImptReptTab1DataList is empty.No data mail has been sent");
					}
				} else {
					StringBuffer noDataMailBody = new StringBuffer().append(toAddressee);
					noDataMailBody.append(PLMConstants.FIR_NO_CONTENT_BODY + "\n");
					noDataMailBody.append("Search Criteria" + "\n");
					noDataMailBody.append("---------------" + "\n");
					noDataMailBody.append("Product Line:" + selectedProductLine + "\n");
					noDataMailBody.append("Frame Type:" + selectedFrameType + "\n\n");
					noDataMailBody.append("CI Nomenclature:" + selectedFeatureName + "\n");
					noDataMailBody.append(PLMConstants.GBOM_MAIL_SIGNATURE).append(PLMConstants.GBOM_MAIL_FOOTER);
					PLMUtils.sendMail(PLMConstants.BVS_MAIL_FROM, toEmailId, PLMConstants.FIR_MAIL_SUBJECT, noDataMailBody.toString());
					LOG.info("featImptReptTab1DataList is empty.No data mail has been sent");
				}
			}
			// End

		} catch (IOException ioexception) {
			LOG.log(Level.ERROR, "Exception@generateFirEmailReport: ioexception", ioexception);
			PLMUtils.checkExceptionAndMail(ioexception.getMessage(), PLMConstants.BVS_MAIL_FROM, toEmailId, PLMConstants.FIR_MAIL_SUBJECT, toAddressee, PLMConstants.COST_CHG_MAIL_SIGNATURE);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@generateFirEmailReport: PLMCommonException", exception);
			String fwdflag = "";
			LOG.log(Level.ERROR, "Exception@generateFirEmailReport: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(), commonMB, "gbomReportSearch", "GBOM Report");
			LOG.info("exception.getMessage()---------------->" + exception.getMessage());
			PLMUtils.checkExceptionAndMail(exception.getMessage(), PLMConstants.BVS_MAIL_FROM, toEmailId, PLMConstants.FIR_MAIL_SUBJECT, toAddressee, PLMConstants.COST_CHG_MAIL_SIGNATURE);
			return fwdflag;
		} finally {
			if (varMap.get("filePathXls") != null || varMap.get("filePathZip") != null) {
				PLMUtils.deleteFiles((String) varMap.get("filePathXls"), (String) varMap.get("filePathZip"));
			}
		}
		LOG.info("Exiting showGBOMReport Method");
		return "gbomReportSearch";
	}


	private void prepareExcelWorkBookFir(Map<String, Object> varMap) throws IOException {

		LOG.info("Inside prepareExcelWorkBookFir");
		XSSFWorkbook workbook = null;
		XSSFSheet sheet = null;
		XSSFSheet sheet2 = null;
		FileInputStream file = null;
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String folderPath = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = folderPath + resourceBundle.getString("FIR_REPORT_NAME") + "_" + uniqTime + ".xlsx";
		String filePathZip = folderPath + resourceBundle.getString("FIR_REPORT_NAME") + "_" + uniqTime + ".zip";
		List<String> filePathXlsLst = new ArrayList<String>();
		filePathXlsLst.add(filePathXls);

		String outptFileTemplate = folderPath + resourceBundle.getString("FIR_TEMPLATE_NAME");
		LOG.info("After Template line");

		file = new FileInputStream(new File(outptFileTemplate));

		LOG.info("file created" + file.toString());
		workbook = new XSSFWorkbook(file);
		LOG.info("workbook created" + workbook);
		sheet = workbook.getSheetAt(0);
		sheet2 = workbook.getSheetAt(1);
		LOG.info("sheet created====");

		short angle = 90;
		headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setRotation(angle);
		headerCellStyle.setWrapText(true);

		normalCellStyle = workbook.createCellStyle();
		normalCellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);

		XSSFFont underLinedFont = (XSSFFont) workbook.createFont();
		underLinedFont.setUnderline(XSSFFont.U_SINGLE);
		underLinedFont.setColor(IndexedColors.BLUE.getIndex());


		XSSFCellStyle headerLinkStyle = (XSSFCellStyle) workbook.createCellStyle();
		headerLinkStyle.setFont(underLinedFont);
		headerLinkStyle.setRotation(angle);
		headerLinkStyle.setWrapText(true);

		XSSFCellStyle hyperLinkStyle = (XSSFCellStyle) workbook.createCellStyle();
		hyperLinkStyle.setFont(underLinedFont);
		hyperLinkStyle.setWrapText(true);


		XSSFCreationHelper helper = (XSSFCreationHelper) workbook.getCreationHelper();


		varMap.put("workbook", workbook);
		varMap.put("sheet", sheet);
		varMap.put("sheet2", sheet2);
		varMap.put("folderPath", folderPath);
		varMap.put("filePathXls", filePathXls);
		varMap.put("filePathZip", filePathZip);
		varMap.put("filePathXlsLst", filePathXlsLst);
		varMap.put("headerLinkStyle", headerLinkStyle);
		varMap.put("hyperLinkStyle", hyperLinkStyle);
		varMap.put("helper", helper);

		LOG.info("Last line of prepareExcel");
	}



	private void writeFirDataToExcel(Map<String, Object> varMap, List<PLMGBomData> gbomDataListLcl, List<PLMGBomData> excelHeaderListLcl) throws PLMCommonException {

		LOG.info("Inside writeFirDataToExcel()");
		XSSFSheet sheet = null;
		XSSFSheet sheet2 = null;
		LOG.info("inside writeFirDataToExcel,, gbomDataList size:" + gbomDataListLcl.size());
		sheet = (XSSFSheet) varMap.get("sheet");
		sheet2 = (XSSFSheet) varMap.get("sheet2");

		XSSFCellStyle hyperLinkStyle = (XSSFCellStyle) varMap.get("hyperLinkStyle");
		XSSFCreationHelper helper = (XSSFCreationHelper) varMap.get("helper");
		// XSSFHyperlink url_link=helper.createHyperlink(Hyperlink.LINK_URL);

		sheet.setColumnWidth(0, 6000);
		sheet.setColumnWidth(1, 6000);
		sheet.setColumnWidth(2, 6000);
		if (gbomDataListLcl.size() != 0) {
			LOG.info("Size greater than zero...");
			int rowno = 2;

			String newMktName = "";
			String childFeatId = "";
			String newCIDisp = "";
			String gbomPartId = "";
			String newGBOMPart = "";

			String oldMktName = "";
			String oldCIDisp = "";
			String oldGBOMPart = "";

			XSSFRow headerRow = sheet.getRow(2);
			headerRow.createCell(0).setCellValue("Frame(Product Line)");
			headerRow.getCell(0).setCellStyle(normalCellStyle);
			headerRow.createCell(1).setCellValue("CI Display Name");
			headerRow.getCell(1).setCellStyle(normalCellStyle);
			headerRow.createCell(2).setCellValue("GBOM Part");
			headerRow.getCell(2).setCellStyle(normalCellStyle);

			for (PLMGBomData gbomData : gbomDataListLcl) {
				newMktName = gbomData.getProductLine();
				childFeatId = gbomData.getChildFeatId();
				newCIDisp = gbomData.getCiDispName();
				gbomPartId = gbomData.getGbomPartId();
				newGBOMPart = gbomData.getGbomPart();
				Row row = null;
				Cell cell = null;
				if ((!newMktName.equals(oldMktName)) || (!newCIDisp.equals(oldCIDisp)) || (!newGBOMPart.equals(oldGBOMPart))) {
					rowno++;
					uniqGbomPartSize++;

					row = sheet.createRow(rowno);
					cell = row.createCell(0);

					cell.setCellValue(newMktName);


					cell = row.createCell(1);
					cell.setCellValue(newCIDisp);
					XSSFHyperlink url_link = helper.createHyperlink(Hyperlink.LINK_URL);
					url_link.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + childFeatId);
					cell.setHyperlink(url_link);
					cell.setCellStyle(hyperLinkStyle);

					cell = row.createCell(2);
					cell.setCellValue(newGBOMPart);
					XSSFHyperlink url_link1 = helper.createHyperlink(Hyperlink.LINK_URL);
					url_link1.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + gbomPartId);
					cell.setHyperlink(url_link1);
					cell.setCellStyle(hyperLinkStyle);

					oldMktName = newMktName;
					oldCIDisp = newCIDisp;
					oldGBOMPart = newGBOMPart;
					int cellNum = 0;
					String cfName = "";
					String coName = "";

					int headerSize = excelHeaderListLcl.size();

					if (!PLMUtils.checkNullVal(gbomData.getConfFeatureName()).equals("")) {
						cfName = gbomData.getConfFeatureName();

						if (!PLMUtils.checkNullVal(gbomData.getConfOptnName()).equals("")) {
							coName = gbomData.getConfOptnName();

							for (int k = 0; k < headerSize; k++) {
								cellNum = k + 3;
								String headerCFName = sheet.getRow(0).getCell(cellNum).getStringCellValue();
								String headerCOName = sheet.getRow(1).getCell(cellNum).getStringCellValue();
								if (cfName.equals(headerCFName) && coName.equals(headerCOName)) {
									sheet.getRow(rowno).createCell(cellNum).setCellValue("X");
									sheet.getRow(rowno).getCell(cellNum).setCellStyle(normalCellStyle);
								} else if (cfName.equals(headerCFName) && !coName.equals(headerCOName)) {
									if (sheet.getRow(rowno).getCell(cellNum) == null) {
										sheet.getRow(rowno).createCell(cellNum).setCellValue("O");
										sheet.getRow(rowno).getCell(cellNum).setCellStyle(normalCellStyle);
									} else {
										sheet.getRow(rowno).getCell(cellNum).setCellValue("O");
										sheet.getRow(rowno).getCell(cellNum).setCellStyle(normalCellStyle);
									}

								}
							}

						}
					} else {
						sheet.getRow(rowno).createCell(3).setCellValue("X");
						sheet.getRow(rowno).getCell(3).setCellStyle(normalCellStyle);
					}



				} else {
					int cellNum = 0;
					String cfName = "";
					String coName = "";
					int headerSize = excelHeaderListLcl.size();

					if (!PLMUtils.checkNullVal(gbomData.getConfFeatureName()).equals("")) {
						cfName = gbomData.getConfFeatureName();

						if (!PLMUtils.checkNullVal(gbomData.getConfOptnName()).equals("")) {
							coName = gbomData.getConfOptnName();

							for (int k = 0; k < headerSize; k++) {
								cellNum = k + 3;
								String headerCFName = sheet.getRow(0).getCell(cellNum).getStringCellValue();
								String headerCOName = sheet.getRow(1).getCell(cellNum).getStringCellValue();
								if (cfName.equals(headerCFName) && coName.equals(headerCOName)) {
									sheet.getRow(rowno).createCell(cellNum).setCellValue("X");
									sheet.getRow(rowno).getCell(cellNum).setCellStyle(normalCellStyle);
								} else if (cfName.equals(headerCFName) && !coName.equals(headerCOName)) {

									if (sheet.getRow(rowno).getCell(cellNum) == null) {
										sheet.getRow(rowno).createCell(cellNum).setCellValue("O");
										sheet.getRow(rowno).getCell(cellNum).setCellStyle(normalCellStyle);
									}
								}
							}

						}
					} else {
						sheet.getRow(rowno).createCell(3).setCellValue("X");
						sheet.getRow(rowno).getCell(3).setCellStyle(normalCellStyle);
					}

				}
			}
		}
		LOG.info("excelHeaderList.size()>>>>>>>>>>>>>>>((((((((((((()))))))))))))))>>>>>>>" + excelHeaderListLcl.size());
		if (excelHeaderListLcl.size() > 0) {
			int rowcount = -1;
			String[] colNames = {"Selected CF: " + selectedFeatureName, "ADD", "DELETE"};
			XSSFRow row = null;
			XSSFCell cell = null;

			row = sheet2.createRow(++rowcount);
			for (int i = 0; i < colNames.length; i++) {
				cell = row.createCell(i);
				cell.setCellValue(colNames[i]);
			}
			for (int i = 0; i < excelHeaderListFir.size(); i++) {
				PLMGBomData dataObj = (PLMGBomData) excelHeaderListFir.get(i);
				row = sheet2.createRow(++rowcount);

				cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellValue(dataObj.getHeaderConfOption());

				cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellValue(dataObj.getStrAdd());

				cell = row.createCell(PLMConstants.EXCEL_COL_TWO);
				cell.setCellValue(dataObj.getStrDel());
			}

			// row = sheet2.createRow(++rowcount);
			// row = sheet2.createRow(++rowcount);
			short colWidth1 = (short) 6000;
			sheet2.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, colWidth1);
			sheet2.setColumnWidth(PLMConstants.EXCEL_COL_ONE, colWidth1);
			sheet2.setColumnWidth(PLMConstants.EXCEL_COL_TWO, colWidth1);
		}
		LOG.info("Unique GBOM Part size in Excel:" + uniqGbomPartSize);
		LOG.info("Existing writeGBOMDataToExcel()");
	}


	private void sendFIRMail(Map<String, Object> varMap) throws PLMCommonException {

		LOG.info("Entering sendFIRMail Method");
		String from = PLMConstants.BVS_MAIL_FROM;
		String toEmailId = userEmail;
		LOG.info("userEmail >>>>>>>>>>>>>>>>>>>>" + toEmailId);
		String toAddressee = userName;
		LOG.info("userName >>>>>>>>>>>>>>>>>>>>" + toAddressee);
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.FIR_MAIL_SUBJECT;
		StringBuffer mailBody = new StringBuffer().append(toAddressee);

		varMap.put("to", toEmailId);
		varMap.put("toAddressee", toAddressee);
		varMap.put("subject", subject);
		mailBody.append(PLMConstants.FIR_MAIL_BODY + "\n");
		mailBody.append("Search Criteria" + "\n");
		mailBody.append("---------------" + "\n");
		mailBody.append("---------------" + "\n");
		mailBody.append("Product Line:" + selectedProductLine + "\n");
		mailBody.append("Frame Type: " + selectedFrameType + "\n");
		mailBody.append("Feature Name : " + selectedFeatureName + "\n");
		mailBody.append(PLMConstants.GBOM_MAIL_SIGNATURE).append(PLMConstants.GBOM_MAIL_FOOTER);
		PLMUtils.sendMailWithAttachment(from, toEmailId, subject, mailBody.toString(), (String) varMap.get("filePathZip"));

		LOG.info("Exiting sendMail Method");
	}


	private void writeFirHeaderDataToExcel(Map<String, Object> varMap, List<PLMGBomData> excelHeaderListLcl) throws PLMCommonException {

		LOG.info("Inside writeHeaderDataToExcel()");
		Row row1 = null;
		Row row2 = null;
		Row row3 = null;
		Cell cell = null;
		XSSFSheet sheet = null;
		LOG.info("inside writeHeaderDataToExcel,, excelHeaderList size:" + excelHeaderListLcl.size());
		sheet = (XSSFSheet) varMap.get("sheet");
		if (excelHeaderListLcl.size() != 0) {
			LOG.info("Size greater than zero...");
			if (excelHeaderListLcl.size() == 1) {
				row1 = sheet.createRow(0);
				row1.setHeight((short) 1500);
				row2 = sheet.createRow(1);
				row2.setHeight((short) 2500);
				row3 = sheet.createRow(2);
				row3.setHeight((short) 2500);
			} else {
				row1 = sheet.createRow(0);
				row1.setHeight((short) 1500);
				row2 = sheet.createRow(1);
				row2.setHeight((short) 2500);
				row3 = sheet.createRow(2);
				row3.setHeight((short) 9000);
			}
			int headerListSize = excelHeaderListLcl.size();
			int ihdrCtr = 0;
			int cellno = 0;
			XSSFCellStyle headerLinkStyle = (XSSFCellStyle) varMap.get("headerLinkStyle");
			XSSFCreationHelper helper = (XSSFCreationHelper) varMap.get("helper");

			for (PLMGBomData excelHeader : excelHeaderListLcl) {
				if (ihdrCtr < headerListSize) {
					cellno = 3 + ihdrCtr;

					cell = row1.createCell(cellno);
					cell.setCellValue(excelHeader.getHeaderConfFeature());
					XSSFHyperlink url_link = helper.createHyperlink(Hyperlink.LINK_URL);
					url_link.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + excelHeader.getCfId());
					cell.setHyperlink(url_link);
					cell.setCellStyle(headerLinkStyle);

					row2.createCell(cellno).setCellValue(excelHeader.getHeaderConfOption());
					row2.getCell(cellno).setCellStyle(headerCellStyle);
					row3.createCell(cellno).setCellValue(excelHeader.getHeaderConfOptionDispName());
					row3.getCell(cellno).setCellStyle(headerCellStyle);
					ihdrCtr++;
				}
			}
		}
		LOG.info("Existing writeHeaderDataToExcel()");
	}


	public void featNameListner(ActionEvent ae) {

		LOG.info("Entering featNameListner Method");
		featName = "";
		for (SelectItem data : featureNameListSI) {
			if (data.getLabel().equals(selectedFeatureName)) {
				featName = "Selected Feature Display Name : " + data.getDescription();
			}
		}
		LOG.info("Exiting featNameListner Method");

	}


	// Newly Added for Part Cost Catalog Report

	/**
	 * This method is used for Loading Part Cost Catalog Report Search
	 * 
	 * @return String
	 */
	public String loadPartCostCatalogue() {

		LOG.info("Entering loadPartCostCatalogue Method");
		String fwdFlag = "";
		try {
			commonMB.insertCannedRptRecordHitInfo("Part Cost Catalog Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			productLineCatlogList = new ArrayList<SelectItem>();
			costTypeList = new ArrayList<SelectItem>();
			frameTypeCatlogList = new ArrayList<SelectItem>();
			selProductLineCatalog = "";
			selFrameTypeCatalog = "";
			alertMessage = "";
			totalpartCostCatalog = 0;
			rowpartCostCatalog = 100;
			totalpartCostCatalogMsg = "";
			partCostCatalogFilterMsg = "";
			partCostCatalogList = new ArrayList<PLMCostCatalogData>();
			hardWarePrdRevList = new ArrayList<PLMCostCatalogData>();
			featureCatalogList = new ArrayList<PLMGBomData>();
			selCostType = "";
			productLineCatlogList = plmGBomService.getFeatImptReptDrpDwnData();
			costTypeList = plmGBomService.getCostTypeList();
			Collections.sort(productLineCatlogList, new PLMUtils.SortListSelItmLbl());
			LOG.info("productLineCatlogList size in MB ==" + productLineCatlogList.size());
			fwdFlag = "partCostCatalogSearch";
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@loadPartCostCatalogue:", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(), commonMB, "home", "Part Cost Catalogue Report");
		}
		LOG.info("Exiting loadPartCostCatalogue Method");
		return fwdFlag;
	}


	/**
	 * This method is used for reset Part Cost Catalog home page
	 * 
	 *
	 */
	public void resetPartCostCatlogRpt() {

		frameTypeCatlogList = new ArrayList<SelectItem>();
		selProductLineCatalog = "";
		selFrameTypeCatalog = "";
		selCostType = "";
	}


	/**
	 * This method is used for Loading FrameType list
	 * 
	 * @return String
	 */
	public void productLineCatlogListner(ActionEvent ae) {

		try {
			LOG.info("Entering productLineCatlogListner Method");
			frameTypeCatlogList.clear();
			frameTypeCatlogList = (List<SelectItem>) plmGBomService.getFrameTypeData(selProductLineCatalog);
			Collections.sort(frameTypeCatlogList, new PLMUtils.SortListSelItmLbl());
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@productLineCatlogListner:", exception);
		}
		LOG.info("Exiting productLineCatlogListner Method");

	}


	/**
	 * This method is used for Generating Part Cost Catalog Report
	 * 
	 * @return String
	 */
	public String generatePartCostCatlogRpt() {

		LOG.info("Entering generatePartCostCatlogRpt Method");
		String fwdFlag = "";
		rowpartCostCatalog = 100;
		try {
			if (selCostType == null) {
				alertMessage = "Please Select Cost Type to run the Report.";
			} else if (selProductLineCatalog != null && selFrameTypeCatalog != null) {
				featureCatalogList = plmGBomService.getFeatureNameList(selProductLineCatalog, selFrameTypeCatalog);
				selectedHwPrdCatlogLst.clear();
				partCostCatalogList = new ArrayList<PLMCostCatalogData>();
				hardWarePrdRevList = new ArrayList<PLMCostCatalogData>();
				partCostCatalogFilterMsg = "";
				for (PLMGBomData hwPrd : featureCatalogList) {
					selectedHwPrdCatlogLst.add(hwPrd.getModelName());
				}
				partCostCatalogList = plmGBomService.getPartCostCatalogData(selectedHwPrdCatlogLst, selCostType);
				hardWarePrdRevList = plmGBomService.getHardwarePrdRevision(selectedHwPrdCatlogLst);
				if (hardWarePrdRevList.size() > 0) {
					hardwarePrd = hardWarePrdRevList.get(0).getHardwarePrd();
					hardwarePrdRev = hardWarePrdRevList.get(0).getHardwarePrdRev();
				}

				if (partCostCatalogList.size() > 0) {
					String costTypeSelctd = selCostType.replace("~!~", " - ");
					totalpartCostCatalog = partCostCatalogList.size();
					totalpartCostCatalogMsg = "Total Records of  Part Cost Catalogue " + totalpartCostCatalog;
					partCostCatalogFilterMsg =
										"Product Line: " + selProductLineCatalog + " Frame Type: " + selFrameTypeCatalog + " Hardware Product: " + hardwarePrd + " Hardware Product Revision: "
															+ hardwarePrdRev + " Cost Type: " + costTypeSelctd;
					fwdFlag = "partCostCatalogReport";
				} else {
					totalpartCostCatalog = 0;
					fwdFlag = "invalidpartCostCatlg";
				}

			}

			else {
				alertMessage = "Please Select values from both Product Line and Frame Type...";
				LOG.info(alertMessage);
				return "partCostCatalogSearch";
			}
		} catch (PLMCommonException exception) {
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(), commonMB, "partCostCatalogSearch", "Part Cost Catalogue Report");
		}
		LOG.info("Existing generatePartCostCatlogRpt Method");
		return fwdFlag;
	}


	/**
	 * This method is used for changePartCostCatalogListner
	 *
	 * @param event
	 */
	public void changePartCostCatalogListner(ActionEvent event) {

		LOG.info("Action listner called.....--------------------------->" + rowpartCostCatalog);
		if (rowpartCostCatalog == 100) {
			LOG.info("100");
			rowpartCostCatalog = 100;
		} else if (rowpartCostCatalog == 200) {
			LOG.info("200");
			rowpartCostCatalog = 200;
		} else if (rowpartCostCatalog == 500) {
			LOG.info("500");
			rowpartCostCatalog = 500;
		} else if (rowpartCostCatalog == 1000) {
			LOG.info("1000");
			rowpartCostCatalog = 1000;
		} else if (rowpartCostCatalog == 2000) {
			LOG.info("2000");
			rowpartCostCatalog = 2000;
		} else if (rowpartCostCatalog == 5000) {
			LOG.info("5000");
			rowpartCostCatalog = 5000;
		}

		else if (rowpartCostCatalog == totalpartCostCatalog) {
			LOG.info("All");
			rowpartCostCatalog = totalpartCostCatalog;
		}
		LOG.info("final value.....--------------------------->" + rowpartCostCatalog);
	}



	/**
	 * This method is used to download an Excel File
	 * 
	 *
	 */
	public void downloadExcel() throws PLMCommonException {

		LOG.info("Entering downloadExcel Method");
		String reportName = "Part Cost Catalogue";
		try {
			if (partCostCatalogList.size() > 0) {
				generatePartCostCatalogue(partCostCatalogList, reportName);
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@downloadExcel: ", exception);
		}
		LOG.info("Exiting downloadExcel Method");

	}


	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return File
	 */

	public File generatePartCostCatalogue(List<PLMCostCatalogData> partCostCatalogListLcl, String reportName) throws IOException {

		LOG.info("Entering generatePartCostCatalogue Method");
		File flexcelFile = null;
		FileOutputStream fileOut = null;
		InputStream fstream = null;
		BufferedOutputStream bos = null;
		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFCell cell = null;
		try {

			StringBuilder fileNameStr =
								new StringBuilder().append(PLMUtils.getMessage("OFFLINE_RPT_DIR", "com.geinfra.geaviation.pwi.resources.Reports")).append(reportName)
													.append(PLMUtils.getCurrentDateTime()).append(".xls");

			flexcelFile = new File(fileNameStr.toString());
			workbook = new HSSFWorkbook();

			// if (workbook != null){

			sheet = workbook.createSheet(reportName);
			HSSFFont fontstyle = workbook.createFont();
			fontstyle.setFontName(PLMConstants.EXCEL_FONT_NAME);

			HSSFCellStyle headerStyle = workbook.createCellStyle();

			headerStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
			headerStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			HSSFFont font = workbook.createFont();
			font.setFontName(PLMConstants.EXCEL_FONT_NAME);
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			headerStyle.setFont(font);
			headerStyle.setWrapText(true);
			headerStyle.setLocked(true);
			headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
			headerStyle = setBorderStyle(headerStyle);

			HSSFCellStyle fontcellstyle = workbook.createCellStyle();
			fontcellstyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			fontcellstyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			fontcellstyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			fontcellstyle.setBorderTop((HSSFCellStyle.BORDER_THIN));
			fontcellstyle.setFont(fontstyle);
			fontcellstyle.setWrapText(true);
			fontcellstyle.setLocked(false);
			fontcellstyle.setAlignment(CellStyle.ALIGN_CENTER);


			HSSFCellStyle desccellstyle = workbook.createCellStyle();
			desccellstyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			desccellstyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			desccellstyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			desccellstyle.setBorderTop((HSSFCellStyle.BORDER_THIN));
			desccellstyle.setFont(fontstyle);
			desccellstyle.setWrapText(false);
			desccellstyle.setLocked(false);
			desccellstyle.setAlignment(CellStyle.ALIGN_LEFT);


			HSSFCellStyle floatcellstyle = workbook.createCellStyle();
			floatcellstyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			floatcellstyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			floatcellstyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			floatcellstyle.setBorderTop((HSSFCellStyle.BORDER_THIN));
			floatcellstyle.setFont(fontstyle);
			floatcellstyle.setWrapText(true);
			floatcellstyle.setLocked(false);
			floatcellstyle.setAlignment(CellStyle.ALIGN_CENTER);



			HSSFCellStyle labelStyle = workbook.createCellStyle();

			labelStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
			labelStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			labelStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			labelStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			HSSFFont font1 = workbook.createFont();
			font1.setFontName(PLMConstants.EXCEL_FONT_NAME);
			font1.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			labelStyle.setFont(font1);
			labelStyle.setWrapText(true);
			labelStyle.setLocked(true);
			labelStyle.setAlignment(CellStyle.ALIGN_LEFT);
			labelStyle = setBorderStyle(labelStyle);



			HSSFCellStyle textcellstyle = workbook.createCellStyle();
			textcellstyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			textcellstyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			textcellstyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			textcellstyle.setBorderTop((HSSFCellStyle.BORDER_THIN));
			textcellstyle.setFont(fontstyle);
			textcellstyle.setWrapText(true);
			textcellstyle.setLocked(false);
			textcellstyle.setAlignment(CellStyle.ALIGN_LEFT);

			HSSFDataFormat df = workbook.createDataFormat();
			floatcellstyle.setDataFormat(df.getFormat("0"));


			int rowcount = -1;

			if (!PLMUtils.isEmptyList(partCostCatalogListLcl)) {
				String[] colNames =
									{"System Name", "GBOM Part Name", "Part Revsion", "Item Type", "LF Name", "LF Description", "MLI", "PIN", "MSD/F-F", "Quantity", "Total Material Cost",
											"Total Labour Cost", "Total Cost", "Total Labour Hours"};


				HSSFRow row = sheet.createRow(++rowcount);
				cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellValue("Part Cost Catalogue Report");
				cell.setCellStyle(headerStyle);

				row = sheet.createRow(++rowcount);
				row = sheet.createRow(++rowcount);

				cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellValue("Product Line :");
				cell.setCellStyle(labelStyle);

				cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellValue(selProductLineCatalog);
				cell.setCellStyle(textcellstyle);

				row = sheet.createRow(++rowcount);

				cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellValue("Frame Type :");
				cell.setCellStyle(labelStyle);

				cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellValue(selFrameTypeCatalog);
				cell.setCellStyle(textcellstyle);

				row = sheet.createRow(++rowcount);

				cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellValue("HardWare Product :");
				cell.setCellStyle(labelStyle);

				cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellValue(hardwarePrd);
				cell.setCellStyle(textcellstyle);

				row = sheet.createRow(++rowcount);

				cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellValue("HardWare Product Revsion :");
				cell.setCellStyle(labelStyle);

				cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellValue(hardwarePrdRev);
				cell.setCellStyle(textcellstyle);

				row = sheet.createRow(++rowcount);

				cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellValue("Cost Type :");
				cell.setCellStyle(labelStyle);

				String costTypeSelctd = selCostType.replace("~!~", " - ");
				cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellValue(costTypeSelctd);
				cell.setCellStyle(textcellstyle);

				row = sheet.createRow(++rowcount);

				cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellValue("Report Generated On:");
				cell.setCellStyle(labelStyle);

				cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
				Date currenDt = new Date();
				DateFormat dateFormat1 = new SimpleDateFormat("MM/dd/yyyy hh:mm aa");
				cell.setCellValue(dateFormat1.format(currenDt));
				cell.setCellStyle(textcellstyle);



				row = sheet.createRow(++rowcount);
				row = sheet.createRow(++rowcount);
				cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellStyle(headerStyle);

				for (int i = 0; i < colNames.length; i++) {
					cell = row.createCell(i);
					cell.setCellValue(colNames[i]);
					cell.setCellStyle(headerStyle);
					headerStyle = cell.getCellStyle();
					cell.setCellStyle(headerStyle);
				}


				for (int i = 0; i < partCostCatalogListLcl.size(); i++) {
					PLMCostCatalogData dataObj = (PLMCostCatalogData) partCostCatalogListLcl.get(i);
					row = sheet.createRow(++rowcount);

					cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellStyle(desccellstyle);
					cell.setCellValue(dataObj.getSystemName());

					cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(fontcellstyle);
					cell.setCellValue(dataObj.getPartName());

					cell = row.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellStyle(fontcellstyle);
					cell.setCellValue(dataObj.getPartRevision());

					cell = row.createCell(PLMConstants.EXCEL_COL_THREE);
					cell.setCellStyle(fontcellstyle);
					cell.setCellValue(dataObj.getCostItemType());

					cell = row.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell.setCellStyle(fontcellstyle);
					cell.setCellValue(dataObj.getLfName());

					cell = row.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell.setCellStyle(desccellstyle);
					cell.setCellValue(dataObj.getLfDesc());

					cell = row.createCell(PLMConstants.EXCEL_COL_SIX);
					cell.setCellStyle(fontcellstyle);
					cell.setCellValue(dataObj.getMli());


					cell = row.createCell(PLMConstants.EXCEL_COL_SEVEN);
					cell.setCellStyle(fontcellstyle);
					cell.setCellValue(dataObj.getPin());

					cell = row.createCell(PLMConstants.EXCEL_COL_EIGHT);
					cell.setCellStyle(fontcellstyle);
					cell.setCellValue(dataObj.getMsdfLogicCal());

					cell = row.createCell(PLMConstants.EXCEL_COL_NINE);
					cell.setCellStyle(floatcellstyle);
					cell.setCellValue(dataObj.getQuantityExl());

					cell = row.createCell(PLMConstants.EXCEL_COL_TEN);
					cell.setCellStyle(floatcellstyle);
					cell.setCellValue(dataObj.getTotalMaterialCostExl());

					cell = row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
					cell.setCellStyle(floatcellstyle);
					cell.setCellValue(dataObj.getTotalLabourCostExl());

					cell = row.createCell(PLMConstants.EXCEL_COL_TWELVE);
					cell.setCellStyle(floatcellstyle);
					cell.setCellValue(dataObj.getTotalCostExl());

					cell = row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
					cell.setCellStyle(floatcellstyle);
					cell.setCellValue(dataObj.getTotalLabourHoursExl());
				}

				row = sheet.createRow(++rowcount);
				row = sheet.createRow(++rowcount);
				short colWidth = (short) 3000;
				short colWidth1 = (short) 6000;
				short colWidth2 = (short) 12000;
				short colWidth4 = (short) 8000;
				short colWidth3 = (short) 2000;


				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, colWidth4);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, colWidth1);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, colWidth);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE, colWidth3);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR, colWidth);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE, colWidth2);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX, colWidth);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN, colWidth);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT, colWidth);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE, colWidth);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN, colWidth);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN, colWidth);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWELVE, colWidth);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTEEN, colWidth);

			}

			fileOut = new FileOutputStream(flexcelFile);
			workbook.write(fileOut);
			String fileName = flexcelFile.getName();
			FacesContext context = FacesContext.getCurrentInstance();
			HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
			response.setContentType("application/vnd.ms-excel");
			response.setHeader("content-disposition", "attachment; filename=" + fileName);
			os = response.getOutputStream();
			workbook.write(os);
			fileOut.close();
			os.close();
			context.responseComplete();
			LOG.info("test file name" + fileName);
			LOG.info("test report-------" + flexcelFile);

			// }
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@generatePartCostCatalogue: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@generatePartCostCatalogue: ", e);
			throw e;
		} finally {
			try {
				if (bos != null) {
					bos.close();
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "The Exception in generatePartCostCatalogue " + exception);
			}
			try {
				if (os != null) {
					os.close();
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "The Exception in generatePartCostCatalogue " + exception);
			}
			try {
				if (fstream != null) {
					fstream.close();
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "The Exception in generatePartCostCatalogue " + exception);
			}
			try {
				if (flexcelFile != null) {
					PLMUtils.deleteDocument(flexcelFile.getAbsolutePath());
				}
			} catch (Exception exception) {
				LOG.log(Level.ERROR, "The Exception in generatePartCostCatalogue " + exception);
			}
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "The Exception in generatePartCostCatalogue " + exception);
			}

		}
		LOG.info("Exiting generatePartCostCatalogue Method");
		return flexcelFile;

	}


	/**
	 * This method is used for Bordering Cell in XLS
	 * 
	 * @return StringBuffer
	 */

	private HSSFCellStyle setBorderStyle(HSSFCellStyle style) {

		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		return style;
	}


	// Newly Added for BOM Report for GBoM Parts for 4.5 Release
	/**
	 * This method is used for sendBomPartsGBOMEmail
	 * 
	 * @throws PWiException
	 * 
	 */
	public void sendBomPartsGBOMEmail() throws PWiException {

		if (!(selectedModelMktNamesList == null) && (selectedModelMktNamesList.size() == 1) && !(selectedTfDisplayNamesList == null) && (selectedTfDisplayNamesList.size() == 1)
							&& !(selectedCiNomenNamesList == null) && !(selectedCiNomenNamesList.size() == 0)) {
			alertMessage = PLMConstants.BOM_RPT_GBOM_MAIL_ALERT_MSG;
			userName = UserInfoPortalUtil.getInstance().getUserName();
			userEmail = UserInfoPortalUtil.getInstance().getUserEmail();

			taskExecutor.execute(new GenBomPartsGBOMEmailThread());
			taskExecutor.execute(new GBOMEmailThread());
		} else if ((selectedModelMktNamesList != null && selectedModelMktNamesList.size() > 1) || (selectedTfDisplayNamesList != null && selectedTfDisplayNamesList.size() > 1)) {
			alertMessage = "Please select one value only for Product Line and Frame Type...";
			LOG.info(alertMessage);
		} else {
			alertMessage = "Please select atleast one value from each selection List...";
			LOG.info(alertMessage);
		}
	}


	/**
	 * Background Process Thread
	 */
	private class GenBomPartsGBOMEmailThread implements Runnable {

		public GenBomPartsGBOMEmailThread() {

		}


		public void run() {

			try {
				genBomPartsGBOMEmailReport();
			} catch (Exception exception) {
				LOG.log(Level.ERROR, "Exception@run() of genBomPartsGBOMEmailThread: ", exception);
			}
		}
	}


	/**
	 * This method is used for genBomPartsGBOMEmailReport
	 * 
	 * @throws Exception
	 * @throws PLMCommonException
	 */
	public void genBomPartsGBOMEmailReport() {

		LOG.info("Entering genBomPartsGBOMEmailReport Method");
		Map<String, Object> varMap = new HashMap<String, Object>();

		String toEmailId = userEmail;
		LOG.info("userEmail >>>>>>>>>>>>>>>>>>>>" + toEmailId);
		String toAddressee = userName;
		LOG.info("userName >>>>>>>>>>>>>>>>>>>>" + toAddressee);

		toAddressee = "Dear " + toAddressee + ", \n\n";

		varMap.put("selectedModelMktNamesList", selectedModelMktNamesList);
		varMap.put("selectedTfDisplayNamesList", selectedTfDisplayNamesList);
		varMap.put("selectedCiNomenNamesList", selectedCiNomenNamesList);
		varMap.put("selectedHwPrdNameList", selectedHwPrdNameList);

		/*
		 * final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss"); Date
		 * uniqDate = new Date(); String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		 */

		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");

		File file = null;
		// boolean rptSccsFlg = false;
		try {
			// Start
			List<String> csvFlsLst = plmGBomService.gbomPartsBoMReport(selectedHwPrdNameList, selectedCiNomenNamesList, fileDir);

			if (!PLMUtils.isEmptyList(csvFlsLst)) {
				LOG.info("csvFlsLst size " + csvFlsLst.size());
				for (String str : csvFlsLst) {
					LOG.info("Files names " + str);
				}
				if (csvFlsLst.size() == PLMConstants.N_1) {
					String filePathCSV = csvFlsLst.get(0);
					String filePathZip = filePathCSV.substring(0, filePathCSV.indexOf(".csv")) + ".zip";

					LOG.info("BOM Report for GBoM Parts -- filePathCSV --> " + filePathCSV);
					LOG.info("BOM Report for GBoM Parts -- filePathZip --> " + filePathZip);

					PLMUtils.generateZipFile(filePathCSV, filePathZip);
					file = new File(filePathZip);
					// Get the number of bytes in the file
					float sizeInBytes = file.length();
					// transform in MB
					float sizeInMb = sizeInBytes / (1024 * 1024);
					LOG.info("Zip File Size for BOM Report for GBoM Parts " + sizeInMb + " MB");
					LOG.info("After generating the ZIP File........");
					varMap.put("filePathZip", filePathZip);
					sendBOMRptForPartRptMail(varMap, 0);
					PLMUtils.deleteFiles(filePathCSV, filePathZip);
				} else {
					Collections.sort(csvFlsLst);
					// PLMFileUtils.csvAppender(fileDir,filePathCSV);
					for (int i = 0; i < csvFlsLst.size(); i++) {
						String filePathCSV = csvFlsLst.get(i);
						String filePathZip = filePathCSV.substring(0, filePathCSV.indexOf(".csv")) + ".zip";

						LOG.info("BOM Report for GBoM Parts -- filePathCSV --> " + filePathCSV);
						LOG.info("BOM Report for GBoM Parts -- filePathZip --> " + filePathZip);

						PLMUtils.generateZipFile(filePathCSV, filePathZip);
						file = new File(filePathZip);
						// Get the number of bytes in the file
						float sizeInBytes = file.length();
						// transform in MB
						float sizeInMb = sizeInBytes / (1024 * 1024);
						LOG.info("Zip File Size for BOM Report for GBoM Parts " + sizeInMb + " MB");
						LOG.info("After generating the ZIP File........");
						varMap.put("filePathZip", filePathZip);
						sendBOMRptForPartRptMail(varMap, i + 1);
						PLMUtils.deleteFiles(filePathCSV, filePathZip);
					}
				}
				// PLMFileUtils.deleteGBoMFiles(fileDir);
			} else {
				StringBuffer subject = new StringBuffer().append(PLMConstants.BOM_RPT_GBOM_MAIL_SUBJECT);
				StringBuffer noDataMailBody = new StringBuffer().append(toAddressee);
				noDataMailBody.append(PLMConstants.BOM_RPT_GBOM_NO_CONTENT_BODY + "\n");
				noDataMailBody.append("Search Criteria" + "\n");
				noDataMailBody.append("---------------" + "\n");
				noDataMailBody.append("Product Line:" + selectedModelMktNamesList.toString() + "\n");
				noDataMailBody.append("Frame Type:" + selectedTfDisplayNamesList.toString() + "\n\n");
				noDataMailBody.append("CI Nomenclature:" + selectedCiNomenNamesList.toString() + "\n");

				noDataMailBody.append(PLMConstants.GBOM_MAIL_SIGNATURE).append(PLMConstants.GBOM_MAIL_FOOTER);
				PLMUtils.sendMail(PLMConstants.BVS_MAIL_FROM, toEmailId, subject.toString(), noDataMailBody.toString());
				LOG.info("No data mail has been sent");
			}
			// End
		} catch (IOException ioexception) {
			LOG.log(Level.ERROR, "Exception@genBomPartsGBOMEmailReport: ", ioexception);
			PLMUtils.checkExceptionAndMail(ioexception.getMessage(), PLMConstants.BVS_MAIL_FROM, toEmailId, PLMConstants.BOM_RPT_GBOM_MAIL_SUBJECT, toAddressee, PLMConstants.GBOM_MAIL_SIGNATURE);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@genBomPartsGBOMEmailReport: ", exception);
			LOG.info("exception.getMessage()---------------->" + exception.getMessage());
			PLMUtils.checkExceptionAndMail(exception.getMessage(), PLMConstants.BVS_MAIL_FROM, toEmailId, PLMConstants.BOM_RPT_GBOM_MAIL_SUBJECT, toAddressee, PLMConstants.GBOM_MAIL_SIGNATURE);
		}

		LOG.info("Exiting genBomPartsGBOMEmailReport Method");
	}


	/**
	 * This method is used for sendBOMRptForPartRptMail
	 * 
	 * @param varMap
	 * @throws PLMCommonException
	 */
	private void sendBOMRptForPartRptMail(Map<String, Object> varMap, int flCtr) throws PLMCommonException {

		LOG.info("Entering sendBOMRptForPartRptMail Method");
		String from = PLMConstants.BVS_MAIL_FROM;
		String toEmailId = userEmail;
		LOG.info("userEmail >>>>>>>>>>>>>>>>>>>>" + toEmailId);
		String toAddressee = userName;
		LOG.info("userName >>>>>>>>>>>>>>>>>>>>" + toAddressee);
		toAddressee = "Dear " + toAddressee + ", \n\n";
		StringBuffer subject = new StringBuffer();
		if (flCtr == PLMConstants.N_0) {
			subject.append(PLMConstants.BOM_RPT_GBOM_MAIL_SUBJECT);
		} else {
			subject.append(PLMConstants.BOM_RPT_GBOM_MAIL_SUBJECT).append("-" + flCtr);
		}
		StringBuffer mailBody = new StringBuffer().append(toAddressee);

		varMap.put("to", toEmailId);
		varMap.put("toAddressee", toAddressee);
		varMap.put("subject", subject.toString());
		mailBody.append(PLMConstants.BOM_RPT_GBOM_MAIL_CONTENT + "\n");
		mailBody.append("Search Criteria" + "\n");
		mailBody.append("---------------" + "\n");
		mailBody.append("Product Line:" + selectedModelMktNamesList.toString() + "\n");
		mailBody.append("Frame Type:" + selectedTfDisplayNamesList.toString() + "\n\n");
		mailBody.append("CI Nomenclature:" + selectedCiNomenNamesList.toString() + "\n");

		mailBody.append(PLMConstants.GBOM_MAIL_SIGNATURE).append(PLMConstants.GBOM_MAIL_FOOTER);
		PLMUtils.sendMailWithAttachment(from, toEmailId, subject.toString(), mailBody.toString(), (String) varMap.get("filePathZip"));
		LOG.info("Exiting sendBOMRptForPartRptMail Method");
	}


	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {

		return commonMB;
	}


	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {

		this.commonMB = commonMB;
	}


	/**
	 * @return the plmGBomService
	 */
	public PLMGBomServiceIfc getPlmGBomService() {

		return plmGBomService;
	}


	/**
	 * @param plmGBomService the plmGBomService to set
	 */
	public void setPlmGBomService(PLMGBomServiceIfc plmGBomService) {

		this.plmGBomService = plmGBomService;
	}


	/**
	 * @return the modelMktNamesList
	 */
	public List<SelectItem> getModelMktNamesList() {

		return modelMktNamesList;
	}


	/**
	 * @param modelMktNamesList the modelMktNamesList to set
	 */
	public void setModelMktNamesList(List<SelectItem> modelMktNamesList) {

		this.modelMktNamesList = modelMktNamesList;
	}


	/**
	 * @return the tfDisplayNamesList
	 */
	public List<SelectItem> getTfDisplayNamesList() {

		return tfDisplayNamesList;
	}


	/**
	 * @param tfDisplayNamesList the tfDisplayNamesList to set
	 */
	public void setTfDisplayNamesList(List<SelectItem> tfDisplayNamesList) {

		this.tfDisplayNamesList = tfDisplayNamesList;
	}


	/**
	 * @return the ciNomenNamesList
	 */
	public List<SelectItem> getCiNomenNamesList() {

		return ciNomenNamesList;
	}


	/**
	 * @param ciNomenNamesList the ciNomenNamesList to set
	 */
	public void setCiNomenNamesList(List<SelectItem> ciNomenNamesList) {

		this.ciNomenNamesList = ciNomenNamesList;
	}


	/**
	 * @return the selectedModelMktNamesList
	 */
	public List<String> getSelectedModelMktNamesList() {

		return selectedModelMktNamesList;
	}


	/**
	 * @param selectedModelMktNamesList the selectedModelMktNamesList to set
	 */
	public void setSelectedModelMktNamesList(List<String> selectedModelMktNamesList) {

		this.selectedModelMktNamesList = selectedModelMktNamesList;
	}


	/**
	 * @return the selectedTfDisplayNamesList
	 */
	public List<String> getSelectedTfDisplayNamesList() {

		return selectedTfDisplayNamesList;
	}


	/**
	 * @param selectedTfDisplayNamesList the selectedTfDisplayNamesList to set
	 */
	public void setSelectedTfDisplayNamesList(List<String> selectedTfDisplayNamesList) {

		this.selectedTfDisplayNamesList = selectedTfDisplayNamesList;
	}


	/**
	 * @return the selectedCiNomenNamesList
	 */
	public List<String> getSelectedCiNomenNamesList() {

		return selectedCiNomenNamesList;
	}


	/**
	 * @param selectedCiNomenNamesList the selectedCiNomenNamesList to set
	 */
	public void setSelectedCiNomenNamesList(List<String> selectedCiNomenNamesList) {

		this.selectedCiNomenNamesList = selectedCiNomenNamesList;
	}


	/**
	 * @return the selectedHwPrdNameList
	 */
	public List<String> getSelectedHwPrdNameList() {

		return selectedHwPrdNameList;
	}


	/**
	 * @param selectedHwPrdNameList the selectedHwPrdNameList to set
	 */
	public void setSelectedHwPrdNameList(List<String> selectedHwPrdNameList) {

		this.selectedHwPrdNameList = selectedHwPrdNameList;
	}


	/**
	 * @return the hwPrdNameList
	 */
	public List<PLMGBomData> getHwPrdNameList() {

		return hwPrdNameList;
	}


	/**
	 * @param hwPrdNameList the hwPrdNameList to set
	 */
	public void setHwPrdNameList(List<PLMGBomData> hwPrdNameList) {

		this.hwPrdNameList = hwPrdNameList;
	}


	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {

		return alertMessage;
	}


	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {

		this.alertMessage = alertMessage;
	}


	/**
	 * @return the dropDownMapList
	 */
	public Map<String, List<SelectItem>> getDropDownMapList() {

		return dropDownMapList;
	}


	/**
	 * @param dropDownMapList the dropDownMapList to set
	 */
	public void setDropDownMapList(Map<String, List<SelectItem>> dropDownMapList) {

		this.dropDownMapList = dropDownMapList;
	}


	/**
	 * @return the tfDispNameBinding
	 */
	public UISelectOne getTfDispNameBinding() {

		return tfDispNameBinding;
	}


	/**
	 * @param tfDispNameBinding the tfDispNameBinding to set
	 */
	public void setTfDispNameBinding(UISelectOne tfDispNameBinding) {

		this.tfDispNameBinding = tfDispNameBinding;
	}


	/**
	 * @return the headerCFNamesList1
	 */
	public List<String> getHeaderCFNamesList1() {

		return headerCFNamesList1;
	}


	/**
	 * @param headerCFNamesList1 the headerCFNamesList1 to set
	 */
	public void setHeaderCFNamesList1(List<String> headerCFNamesList1) {

		this.headerCFNamesList1 = headerCFNamesList1;
	}


	/**
	 * @return the headerCFNamesList
	 */
	public List<String> getHeaderCFNamesList() {

		return headerCFNamesList;
	}


	/**
	 * @param headerCFNamesList the headerCFNamesList to set
	 */
	public void setHeaderCFNamesList(List<String> headerCFNamesList) {

		this.headerCFNamesList = headerCFNamesList;
	}


	/**
	 * @return the excelHeaderList
	 */
	public List<PLMGBomData> getExcelHeaderList() {

		return excelHeaderList;
	}


	/**
	 * @param excelHeaderList the excelHeaderList to set
	 */
	public void setExcelHeaderList(List<PLMGBomData> excelHeaderList) {

		this.excelHeaderList = excelHeaderList;
	}


	/**
	 * @return the gbomDataList
	 */
	public List<PLMGBomData> getGbomDataList() {

		return gbomDataList;
	}


	/**
	 * @param gbomDataList the gbomDataList to set
	 */
	public void setGbomDataList(List<PLMGBomData> gbomDataList) {

		this.gbomDataList = gbomDataList;
	}


	/**
	 * @return the gbomDataNewList
	 */
	public List<PLMGBomData> getGbomDataNewList() {

		return gbomDataNewList;
	}


	/**
	 * @param gbomDataNewList the gbomDataNewList to set
	 */
	public void setGbomDataNewList(List<PLMGBomData> gbomDataNewList) {

		this.gbomDataNewList = gbomDataNewList;
	}


	/**
	 * @return the uniqGbomPartSize
	 */
	public int getUniqGbomPartSize() {

		return uniqGbomPartSize;
	}


	/**
	 * @param uniqGbomPartSize the uniqGbomPartSize to set
	 */
	public void setUniqGbomPartSize(int uniqGbomPartSize) {

		this.uniqGbomPartSize = uniqGbomPartSize;
	}


	/**
	 * @return the hwPrdMap
	 */
	public Map<String, Object> getHwPrdMap() {

		return hwPrdMap;
	}


	/**
	 * @param hwPrdMap the hwPrdMap to set
	 */
	public void setHwPrdMap(Map<String, Object> hwPrdMap) {

		this.hwPrdMap = hwPrdMap;
	}


	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {

		return recordCounts;
	}


	/**
	 * @param recordCounts the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {

		this.recordCounts = recordCounts;
	}


	/**
	 * @return the gbomdataCount
	 */
	public int getGbomdataCount() {

		return gbomdataCount;
	}


	/**
	 * @param gbomdataCount the gbomdataCount to set
	 */
	public void setGbomdataCount(int gbomdataCount) {

		this.gbomdataCount = gbomdataCount;
	}


	/**
	 * @return the gbomDataCount
	 */
	public int getGbomDataCount() {

		return gbomDataCount;
	}


	/**
	 * @param gbomDataCount the gbomDataCount to set
	 */
	public void setGbomDataCount(int gbomDataCount) {

		this.gbomDataCount = gbomDataCount;
	}


	/**
	 * @return the headerCellStyle
	 */
	public XSSFCellStyle getHeaderCellStyle() {

		return headerCellStyle;
	}


	/**
	 * @param headerCellStyle the headerCellStyle to set
	 */
	public void setHeaderCellStyle(XSSFCellStyle headerCellStyle) {

		this.headerCellStyle = headerCellStyle;
	}


	/**
	 * @return the normalCellStyle
	 */
	public XSSFCellStyle getNormalCellStyle() {

		return normalCellStyle;
	}


	/**
	 * @param normalCellStyle the normalCellStyle to set
	 */
	public void setNormalCellStyle(XSSFCellStyle normalCellStyle) {

		this.normalCellStyle = normalCellStyle;
	}


	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {

		return resourceBundle;
	}


	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {

		this.resourceBundle = resourceBundle;
	}


	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {

		return taskExecutor;
	}


	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {

		this.taskExecutor = taskExecutor;
	}


	/**
	 * @return the log
	 */
	public static Logger getLog() {

		return LOG;
	}


	/**
	 * @return the dATE_FORMAT_PROC
	 */
	public SimpleDateFormat getDATE_FORMAT_PROC() {

		return DATE_FORMAT_PROC;
	}


	/**
	 * @return the productLineList
	 */
	public List<SelectItem> getProductLineList() {

		return productLineList;
	}



	/**
	 * @param productLineList the productLineList to set
	 */
	public void setProductLineList(List<SelectItem> productLineList) {

		this.productLineList = productLineList;
	}



	/**
	 * @return the frameTypeList
	 */
	public List<SelectItem> getFrameTypeList() {

		return frameTypeList;
	}



	/**
	 * @param frameTypeList the frameTypeList to set
	 */
	public void setFrameTypeList(List<SelectItem> frameTypeList) {

		this.frameTypeList = frameTypeList;
	}


	/**
	 * @return the selectedFeatureName
	 */
	public String getSelectedFeatureName() {

		return selectedFeatureName;
	}



	/**
	 * @param selectedFeatureName the selectedFeatureName to set
	 */
	public void setSelectedFeatureName(String selectedFeatureName) {

		this.selectedFeatureName = selectedFeatureName;
	}



	/**
	 * @return the featureNameListSI
	 */
	public List<SelectItem> getFeatureNameListSI() {

		return featureNameListSI;
	}



	/**
	 * @param featureNameListSI the featureNameListSI to set
	 */
	public void setFeatureNameListSI(List<SelectItem> featureNameListSI) {

		this.featureNameListSI = featureNameListSI;
	}



	/**
	 * @return the selectedProductLine
	 */
	public String getSelectedProductLine() {

		return selectedProductLine;
	}



	/**
	 * @param selectedProductLine the selectedProductLine to set
	 */
	public void setSelectedProductLine(String selectedProductLine) {

		this.selectedProductLine = selectedProductLine;
	}



	/**
	 * @return the selectedFrameType
	 */
	public String getSelectedFrameType() {

		return selectedFrameType;
	}



	/**
	 * @param selectedFrameType the selectedFrameType to set
	 */
	public void setSelectedFrameType(String selectedFrameType) {

		this.selectedFrameType = selectedFrameType;
	}



	/**
	 * @return the headerCFNamesList1Fir
	 */
	public List<String> getHeaderCFNamesList1Fir() {

		return headerCFNamesList1Fir;
	}



	/**
	 * @param headerCFNamesList1Fir the headerCFNamesList1Fir to set
	 */
	public void setHeaderCFNamesList1Fir(List<String> headerCFNamesList1Fir) {

		this.headerCFNamesList1Fir = headerCFNamesList1Fir;
	}



	/**
	 * @return the headerCFNamesListFir
	 */
	public List<String> getHeaderCFNamesListFir() {

		return headerCFNamesListFir;
	}



	/**
	 * @param headerCFNamesListFir the headerCFNamesListFir to set
	 */
	public void setHeaderCFNamesListFir(List<String> headerCFNamesListFir) {

		this.headerCFNamesListFir = headerCFNamesListFir;
	}



	/**
	 * @return the featImptReptTab1DataListNew
	 */
	public List<PLMGBomData> getFeatImptReptTab1DataListNew() {

		return featImptReptTab1DataListNew;
	}



	/**
	 * @param featImptReptTab1DataListNew the featImptReptTab1DataListNew to set
	 */
	public void setFeatImptReptTab1DataListNew(List<PLMGBomData> featImptReptTab1DataListNew) {

		this.featImptReptTab1DataListNew = featImptReptTab1DataListNew;
	}



	/**
	 * @return the recordCountsFir
	 */
	public int getRecordCountsFir() {

		return recordCountsFir;
	}



	/**
	 * @param recordCountsFir the recordCountsFir to set
	 */
	public void setRecordCountsFir(int recordCountsFir) {

		this.recordCountsFir = recordCountsFir;
	}



	/**
	 * @return the excelHeaderListFir
	 */
	public List<PLMGBomData> getExcelHeaderListFir() {

		return excelHeaderListFir;
	}



	/**
	 * @param excelHeaderListFir the excelHeaderListFir to set
	 */
	public void setExcelHeaderListFir(List<PLMGBomData> excelHeaderListFir) {

		this.excelHeaderListFir = excelHeaderListFir;
	}



	/**
	 * @return the firDataCount
	 */
	public int getFirDataCount() {

		return firDataCount;
	}



	/**
	 * @param firDataCount the firDataCount to set
	 */
	public void setFirDataCount(int firDataCount) {

		this.firDataCount = firDataCount;
	}


	/**
	 * @return the heightPX
	 */
	public String getHeightPX() {

		return heightPX;
	}


	/**
	 * @param heightPX the heightPX to set
	 */
	public void setHeightPX(String heightPX) {

		this.heightPX = heightPX;
	}


	/**
	 * @return the heightPX1
	 */
	public String getHeightPX1() {

		return heightPX1;
	}


	/**
	 * @param heightPX1 the heightPX1 to set
	 */
	public void setHeightPX1(String heightPX1) {

		this.heightPX1 = heightPX1;
	}


	/**
	 * @return the countTab1
	 */
	public int getCountTab1() {

		return countTab1;
	}


	/**
	 * @param countTab1 the countTab1 to set
	 */
	public void setCountTab1(int countTab1) {

		this.countTab1 = countTab1;
	}


	/**
	 * @return the countTab2
	 */
	public int getCountTab2() {

		return countTab2;
	}


	/**
	 * @param countTab2 the countTab2 to set
	 */
	public void setCountTab2(int countTab2) {

		this.countTab2 = countTab2;
	}


	/**
	 * @return the selectedFeatDispName
	 */
	public String getSelectedFeatDispName() {

		return selectedFeatDispName;
	}


	/**
	 * @param selectedFeatDispName the selectedFeatDispName to set
	 */
	public void setSelectedFeatDispName(String selectedFeatDispName) {

		this.selectedFeatDispName = selectedFeatDispName;
	}


	/**
	 * @return the featName
	 */
	public String getFeatName() {

		return featName;
	}


	/**
	 * @param featName the featName to set
	 */
	public void setFeatName(String featName) {

		this.featName = featName;
	}


	/**
	 * @return the productLineCatlogList
	 */
	public List<SelectItem> getProductLineCatlogList() {

		return productLineCatlogList;
	}


	/**
	 * @param productLineCatlogList the productLineCatlogList to set
	 */
	public void setProductLineCatlogList(List<SelectItem> productLineCatlogList) {

		this.productLineCatlogList = productLineCatlogList;
	}


	/**
	 * @return the frameTypeCatlogList
	 */
	public List<SelectItem> getFrameTypeCatlogList() {

		return frameTypeCatlogList;
	}


	/**
	 * @param frameTypeCatlogList the frameTypeCatlogList to set
	 */
	public void setFrameTypeCatlogList(List<SelectItem> frameTypeCatlogList) {

		this.frameTypeCatlogList = frameTypeCatlogList;
	}


	/**
	 * @return the selProductLineCatalog
	 */
	public String getSelProductLineCatalog() {

		return selProductLineCatalog;
	}


	/**
	 * @param selProductLineCatalog the selProductLineCatalog to set
	 */
	public void setSelProductLineCatalog(String selProductLineCatalog) {

		this.selProductLineCatalog = selProductLineCatalog;
	}


	/**
	 * @return the selFrameTypeCatalog
	 */
	public String getSelFrameTypeCatalog() {

		return selFrameTypeCatalog;
	}


	/**
	 * @param selFrameTypeCatalog the selFrameTypeCatalog to set
	 */
	public void setSelFrameTypeCatalog(String selFrameTypeCatalog) {

		this.selFrameTypeCatalog = selFrameTypeCatalog;
	}


	/**
	 * @return the featureCatalogList
	 */
	public List<PLMGBomData> getFeatureCatalogList() {

		return featureCatalogList;
	}


	/**
	 * @param featureCatalogList the featureCatalogList to set
	 */
	public void setFeatureCatalogList(List<PLMGBomData> featureCatalogList) {

		this.featureCatalogList = featureCatalogList;
	}


	/**
	 * @return the selectedHwPrdCatlogLst
	 */
	public List<String> getSelectedHwPrdCatlogLst() {

		return selectedHwPrdCatlogLst;
	}


	/**
	 * @param selectedHwPrdCatlogLst the selectedHwPrdCatlogLst to set
	 */
	public void setSelectedHwPrdCatlogLst(List<String> selectedHwPrdCatlogLst) {

		this.selectedHwPrdCatlogLst = selectedHwPrdCatlogLst;
	}


	/**
	 * @return the partCostCatalogList
	 */
	public List<PLMCostCatalogData> getPartCostCatalogList() {

		return partCostCatalogList;
	}


	/**
	 * @param partCostCatalogList the partCostCatalogList to set
	 */
	public void setPartCostCatalogList(List<PLMCostCatalogData> partCostCatalogList) {

		this.partCostCatalogList = partCostCatalogList;
	}


	/**
	 * @return the totalpartCostCatalogMsg
	 */
	public String getTotalpartCostCatalogMsg() {

		return totalpartCostCatalogMsg;
	}


	/**
	 * @param totalpartCostCatalogMsg the totalpartCostCatalogMsg to set
	 */
	public void setTotalpartCostCatalogMsg(String totalpartCostCatalogMsg) {

		this.totalpartCostCatalogMsg = totalpartCostCatalogMsg;
	}


	/**
	 * @return the rowpartCostCatalog
	 */
	public int getRowpartCostCatalog() {

		return rowpartCostCatalog;
	}


	/**
	 * @param rowpartCostCatalog the rowpartCostCatalog to set
	 */
	public void setRowpartCostCatalog(int rowpartCostCatalog) {

		this.rowpartCostCatalog = rowpartCostCatalog;
	}


	/**
	 * @return the totalpartCostCatalog
	 */
	public int getTotalpartCostCatalog() {

		return totalpartCostCatalog;
	}


	/**
	 * @param totalpartCostCatalog the totalpartCostCatalog to set
	 */
	public void setTotalpartCostCatalog(int totalpartCostCatalog) {

		this.totalpartCostCatalog = totalpartCostCatalog;
	}


	/**
	 * @return the hardWarePrdRevList
	 */
	public List<PLMCostCatalogData> getHardWarePrdRevList() {

		return hardWarePrdRevList;
	}


	/**
	 * @param hardWarePrdRevList the hardWarePrdRevList to set
	 */
	public void setHardWarePrdRevList(List<PLMCostCatalogData> hardWarePrdRevList) {

		this.hardWarePrdRevList = hardWarePrdRevList;
	}


	/**
	 * @return the hardwarePrd
	 */
	public String getHardwarePrd() {

		return hardwarePrd;
	}


	/**
	 * @param hardwarePrd the hardwarePrd to set
	 */
	public void setHardwarePrd(String hardwarePrd) {

		this.hardwarePrd = hardwarePrd;
	}


	/**
	 * @return the hardwarePrdRev
	 */
	public String getHardwarePrdRev() {

		return hardwarePrdRev;
	}


	/**
	 * @param hardwarePrdRev the hardwarePrdRev to set
	 */
	public void setHardwarePrdRev(String hardwarePrdRev) {

		this.hardwarePrdRev = hardwarePrdRev;
	}


	/**
	 * @return the partCostCatalogFilterMsg
	 */
	public String getPartCostCatalogFilterMsg() {

		return partCostCatalogFilterMsg;
	}


	/**
	 * @param partCostCatalogFilterMsg the partCostCatalogFilterMsg to set
	 */
	public void setPartCostCatalogFilterMsg(String partCostCatalogFilterMsg) {

		this.partCostCatalogFilterMsg = partCostCatalogFilterMsg;
	}


	/**
	 * @return the firDataCount1
	 */
	public int getFirDataCount1() {

		return firDataCount1;
	}


	/**
	 * @param firDataCount1 the firDataCount1 to set
	 */
	public void setFirDataCount1(int firDataCount1) {

		this.firDataCount1 = firDataCount1;
	}


	/**
	 * @return
	 */
	public boolean isTab1Flag() {

		return tab1Flag;
	}


	/**
	 * @param tab1Flag
	 */
	public void setTab1Flag(boolean tab1Flag) {

		this.tab1Flag = tab1Flag;
	}


	/**
	 * @return
	 */
	public boolean isTab2Flag() {

		return tab2Flag;
	}


	/**
	 * @param tab2Flag
	 */
	public void setTab2Flag(boolean tab2Flag) {

		this.tab2Flag = tab2Flag;
	}


	/**
	 * @return the costTypeList
	 */
	public List<SelectItem> getCostTypeList() {

		return costTypeList;
	}


	/**
	 * @param costTypeList the costTypeList to set
	 */
	public void setCostTypeList(List<SelectItem> costTypeList) {

		this.costTypeList = costTypeList;
	}


	/**
	 * @return the selCostType
	 */
	public String getSelCostType() {

		return selCostType;
	}


	/**
	 * @param selCostType the selCostType to set
	 */
	public void setSelCostType(String selCostType) {

		this.selCostType = selCostType;
	}

	public void downloadCSV() throws PLMCommonException {

		LOG.info("Entering downloadCSV Method");
		String fileName = "Part Cost Catalogue";
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		//Export to comma CSV for Part Cost Catalogue
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
								new PLMCsvRptColumn("systemName", "System Name", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("partName", "GBOM Part Name", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("partRevision", "Part Revsion", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("costItemType", "Item Type", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("lfName", "LF Name", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("lfDesc", "LF Description", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("mli", "MLI", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("pin", "PIN", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("msdfLogicCal", "MSD/F-F", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("quantity", "Quantity", FormatTypeCsv.INTEGER),
								new PLMCsvRptColumn("totalMaterialCost", "Total Material Cost", FormatTypeCsv.INTEGER),
								new PLMCsvRptColumn("totalLabourCost", "Total Labour Cost", FormatTypeCsv.INTEGER),
								new PLMCsvRptColumn("totalCost", "Total Cost", FormatTypeCsv.INTEGER),
								new PLMCsvRptColumn("totalLabourHours", "Total Labour Hours", FormatTypeCsv.INTEGER),
						};
		
		csvUtil.exportCsv(partCostCatalogList, reportColumns, fileName, dateFormat, false, null, null, ",");
		LOG.info("Exiting downloadCSV Method");

	}

}
