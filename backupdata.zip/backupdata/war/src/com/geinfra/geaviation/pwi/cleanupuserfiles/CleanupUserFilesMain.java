package com.geinfra.geaviation.pwi.cleanupuserfiles;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.common.MainExecution;

/**
 * 
 * Project : Product Lifecycle Management
 * Date Written : 2012 Oct 16
 * Security : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : CleanupUserFilesMain - Main class for cleaning up result files
 * 
 * Revision Log 2012.10.16 |  pH | v1.0.
 * --------------------------------------------------------------
 */
public class CleanupUserFilesMain {
	private static final Logger LOGGER = Logger
			.getLogger(CleanupUserFilesMain.class);
	private static final String CLEANUP_CONTEXT = "cleanupUserFiles";

	public static void main(String[] args) {
		try {
			// Initialize execution environment
			MainExecution cleanupMain = new MainExecution(CLEANUP_CONTEXT, args);

			// Run job using execution environment
			CleanupJob job = (CleanupJob) cleanupMain
					.getBeanFromContext("cleanupJobBean");
			job.cleanupFiles(cleanupMain);
		} catch (Exception e) {
			LOGGER.fatal("Fatal Exception: ", e);
			System.exit(MainExecution.FAILED_EXIT_STATUS);
		}
		System.exit(MainExecution.SUCCEEDED_EXIT_STATUS);
	}
}
