/*
//  @ Project : PWi
//  @ File Name : PWiUserCustomQueryVO.java
//  @ Date : 5/14/2010
//  @ Author : nisverma
 */

package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : PWiQueryObjectPK - Query Object primary key (for mapping
 * queries to object type)
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiQueryObjectPK implements Serializable {

	private static final long serialVersionUID = -2321501233114254087L;
	private int qrySeqId;
	private int objTypSeqId;

	public PWiQueryObjectPK() {
	}

	public PWiQueryObjectPK(int qrySeqId, int objTypSeqId) {
		this.qrySeqId = qrySeqId;
		this.objTypSeqId = objTypSeqId;
	}

	public int getQrySeqId() {
		return qrySeqId;
	}

	public void setQrySeqId(int qrySeqId) {
		this.qrySeqId = qrySeqId;
	}

	public int getObjTypSeqId() {
		return objTypSeqId;
	}

	public void setObjTypSeqId(int objTypSeqId) {
		this.objTypSeqId = objTypSeqId;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (int) qrySeqId;
		hash += (int) objTypSeqId;
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object instanceof PWiQueryObjectPK) {
			PWiQueryObjectPK other = (PWiQueryObjectPK) object;
			return this.qrySeqId == other.qrySeqId
					&& this.objTypSeqId == other.objTypSeqId;
		}
		return false;
	}

	@Override
	public String toString() {
		return "com.geinfra.geaviation.pwi.model.PWiQueryObjectPK[qrySeqId="
				+ qrySeqId + ", objTypSeqId=" + objTypSeqId + "]";
	}

}
