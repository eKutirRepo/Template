package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.model.PWiQueryNoXmlVO;
import com.geinfra.geaviation.pwi.model.PWiQueryVO;
import com.geinfra.geaviation.pwi.model.PWiUserVO;
import com.geinfra.geaviation.pwi.model.QueriesVO;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 5, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Data access object interface for queries.
 * 
 * Revision Log Aug 5, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public interface QueriesDAO {
	// TODO consider restricting retrieving XML only to queries that need it --
	// ideally only to those that retrieve simply one record as to make the
	// performance cost of XMLSerialize negligible

	public List<QueriesVO> getAllQueries() throws PWiException;
	
	public List<QueriesVO> getAllDraftQueries(String ssoId) throws PWiException;

	public List<PWiQueryNoXmlVO> getQueries() throws PWiException;

	public List<PWiQueryNoXmlVO> getVisibleQueries(List<String> groupNames)
			throws PWiException;

	public PWiQueryVO getQueryById(Integer queryId);

	public List<PWiQueryVO> getQueriesForObjectType(String objectType);

	public int checkQueryName(String queryName) throws PWiException;

	public int checkQueryNameEdit(String queryName, Integer queryId)
			throws PWiException;

	public List<PWiQueryNoXmlVO> searchVisibleQueries(
			String queryName, List<String> roles);

	public List<String> searchQueryTypeahead(
			String queryName, List<String> roles);


	/**
	 * Retrieve all queries associated with the specified group names. That is,
	 * retrieve the list of queries such that each query is associated with at
	 * least one of the specified groups.
	 * 
	 * @param groupNames
	 * @return the queries associated with the specified groups
	 * @throws PWiException
	 */
	public List<PWiQueryVO> getQueriesForGroupNames(List<String> groupNames)
			throws PWiException;

	/**
	 * Retrieve all queries associated with the specified groups and having the
	 * specified access control. That is, retrieve the list of queries such that
	 * each query is associated with at least one of the specified groups and
	 * has the specified access control.
	 * 
	 * @param groupNames
	 * @param exportControlled
	 *            True to retrieve export-controlled queries, false to retrieve
	 *            non-export-controlled queries, null to return both
	 * @param geOnly
	 *            True to retrieve GE-only queries, false to retrieve
	 *            non-GE-only queries, null to return both
	 * @return the queries associated with the specified groups
	 * @throws PWiException
	 */
	public List<PWiQueryNoXmlVO> getQueriesForGroupNames(
			final List<String> groupNames, Boolean exportControlled,
			Boolean geOnly) throws PWiException;

	public QueriesVO searchQuery(Integer queryId, String[] roles)
			throws PWiException;

	public Integer createQuery(String queryName, String queryDesc,
			List<Integer> slctdObjTyps, String qryKeyWrdTxt, String queryXML,
			List<PWiQueryGroupVO> selectedQueryGroupsList, String userId,
			boolean exportControlled, boolean geOnly, boolean popular,boolean active, Map<String, List<PWiUserVO>> tempGrpUsrMap, String queryFlag)
			throws PWiException;

	public void updateQuery(PWiQueryVO query, String sso);

	/**
	 * Retrieves all queries assigned to the group identified by the specified
	 * group ID.
	 * 
	 * @param groupId
	 * @return list of queries
	 */
	public List<QueriesVO> getQueriesByGroupId(Integer groupId);

	/**
	 * Returns all queries not assigned to the specified group.
	 * 
	 * @param groupId
	 * @return list of queries
	 */
	public List<QueriesVO> getQueriesNotInGroup(Integer groupId);
	
	public List<PWiQueryGroupVO> getNonVisibleQueries(String sso);
}
