/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMAdminDaoImpl.java
 * @Creation date: 17-Jul-2009
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.dao;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.transaction.annotation.Transactional;

import com.geinfra.geaviation.pwi.data.PLMAdminData;
import com.geinfra.geaviation.pwi.data.PLMAdminReportsData;
import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.data.PLMReportData;
import com.geinfra.geaviation.pwi.data.PLMRequestData;
import com.geinfra.geaviation.pwi.data.PLMSecurityMatrixData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMGrantAccessProc;
import com.geinfra.geaviation.pwi.util.PLMQueryConstants;
import com.geinfra.geaviation.pwi.util.PLMSecurityMatrixProc;
import com.geinfra.geaviation.pwi.util.PLMSendMailUtil;
import com.geinfra.geaviation.pwi.util.PLMUtils;


/**
 * ICMAdminDaoImpl is the DAO implementation class used for ICM Administrator
 * Menu.
 */
public class PLMAdminDaoImpl extends SimpleJdbcDaoSupport implements
		PLMAdminDaoIfc {
	/**
	 * Holds the Logger.
	 */
	private static final Logger LOG = Logger.getLogger(PLMAdminDaoImpl.class);

	/**
	 * Holds the Request Data object
	 */
	private PLMRequestData userRequestObj;
	/**
	 * Holds the ResourceBundle.
	 */
	private static ResourceBundle rbundle = ResourceBundle
			.getBundle(PLMConstants.ENV_PROP_FILE);

	/**
	 * Handler for ICMGrantAccessProc
	 */
	private PLMGrantAccessProc grantAccessProc;

	/**
	 * Handler for PLMSecurityMatrixProc.
	 */
	private PLMSecurityMatrixProc proc = null;
	/**
	 * mailSend.
	 */
	private JavaMailSenderImpl mailSend;
	/**
	 * mailBean.
	 */
	private PLMSendMailUtil mailBean = new PLMSendMailUtil();

	/**
	 * Person Dao Object
	 */
	private PLMPersonDaoIfc validDao = null;
	
	/**
	 * Person Dao Object
	 */
	private PLMEccnTagDaoIfc plmEccnTagDao = null;

	/**
	 * groupIdReq 
	 */
	private String groupIdReq;
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
		 
	}
	/**
	 * @return the mailSend
	 */
	public JavaMailSenderImpl getMailSend() {
		return mailSend;
	}

	/**
	 * @param mailSend
	 *            the mailSend to set
	 */
	public void setMailSend(JavaMailSenderImpl mailSenda) {
		this.mailSend = mailSenda;
	}

	/**
	 * @return the mailBean
	 */
	public PLMSendMailUtil getMailBean() {
		return mailBean;
	}

	/**
	 * @param mailBean
	 *  the mailBean to set
	 */
	public void setMailBean(PLMSendMailUtil mailBeana) {
		this.mailBean = mailBeana;
	}

	/**
	 * @return the proc
	 */
	public PLMSecurityMatrixProc getProc() {
		return proc;
	}

	/**
	 * @param proc
	 * the proc to set
	 */
	public void setProc(PLMSecurityMatrixProc proc) {
		this.proc = proc;
	}

	/**
	 * @return the grantAccessProc
	 */
	public PLMGrantAccessProc getGrantAccessProc() {
		return grantAccessProc;
	}

	/**
	 * @param grantAccessProc
	 *            the grantAccessProc to set
	 */
	public void setGrantAccessProc(PLMGrantAccessProc grantAccessProca) {
		this.grantAccessProc = grantAccessProca;
	}

	/**
	 * @return the userRequestObj
	 */
	public PLMRequestData getUserRequestData() {
		return userRequestObj;
	}

	/**
	 * @param userRequestObj
	 *            the userRequestObj to set
	 */
	public void setUserRequestData(PLMRequestData userRequestObja) {
		this.userRequestObj = userRequestObja;
	}

	
	/**
	 * @return the validDao
	 */
	public PLMPersonDaoIfc getValidDao() {
		return validDao;
	}

	/**
	 * @param validDao the validDao to set
	 */
	public void setValidDao(PLMPersonDaoIfc validDao) {
		this.validDao = validDao;
	}
	
	
	/**
	 * @return the groupIdReq
	 */
	public String getGroupIdReq() {
		return groupIdReq;
	}

	/**
	 * @param groupIdReq the groupIdReq to set
	 */
	public void setGroupIdReq(String groupIdReqa) {
		this.groupIdReq = groupIdReqa;
	}

	/**
	 * This method is used to get List Of Reports
	 * 
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMAdminData> getListOfReports() throws PLMCommonException {
		List<PLMAdminData> listOfReports = new ArrayList<PLMAdminData>();
		try {
			listOfReports = getSimpleJdbcTemplate().query(PLMQueryConstants.GET_REPORT_DATA,
					new ReportList());
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return listOfReports;
	}

	/**
	 * This method is used to get Reports Data
	 * 
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMAdminReportsData> getReportNames() throws PLMCommonException {

		List<PLMAdminReportsData> homePageReports = null;
		
		homePageReports = getSimpleJdbcTemplate().query(
				PLMQueryConstants.HOME_PAGE_REPORTS, new HpMapper());
		LOG.info("Get Home Query"+PLMQueryConstants.HOME_PAGE_REPORTS);
		if (homePageReports != null && !homePageReports.isEmpty()) {
			LOG.info("Reoprts size---->" + homePageReports.size());
		}
		return homePageReports;
	}

	/**
	 * This method is used to get Reports Data
	 * 
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public String addReportData(PLMAdminReportsData reportData, String sso_id)
			throws PLMCommonException {

		String loginUserSSO = sso_id;
		int successIndicator = 0;
		int sort_order = reportData.getSortOrder();
		String report_name = reportData.getReportName();
		String add_description = reportData.getDescription();
		LOG.info("Add description "+add_description);
		String report_url = reportData.getReportURL();
		/*if (reportData != null) {*/
			successIndicator = getSimpleJdbcTemplate().update(
					PLMQueryConstants.INSERT_REPORT_NAME,
					new Object[] { report_name, report_url, sort_order,add_description,
							loginUserSSO, loginUserSSO });
			LOG.info("Add Report data "+PLMQueryConstants.INSERT_REPORT_NAME);
		/*}*/

		if (successIndicator > 0) {
			return "success";
		}
		return "";
	}

	/**
	 * This method is used to modify Reports Data
	 * @param reportData, oldReportName, sso_id
	 * @return String
	 * @throws PLMCommonException
	 */
	public String modifyReportData(PLMAdminReportsData reportData,
			String oldReportName, String sso_id) throws PLMCommonException {

		String loginUserSSO = sso_id;
		int successIndicator = 0;
		int sort_order = (reportData.getSortOrder());
		String report_name = reportData.getReportName();
		String upd_description = reportData.getDescription();
		LOG.info("upd description "+upd_description);
		String report_url = reportData.getReportURL();
		/*if (reportData != null) {*/
			successIndicator = getSimpleJdbcTemplate().update(
					PLMQueryConstants.MODIFY_REPORT_NAME,
					new Object[] { report_name, report_url, sort_order,upd_description,
							loginUserSSO, oldReportName });
			LOG.info("Update Report data "+PLMQueryConstants.MODIFY_REPORT_NAME);
	/*	}*/
		if (successIndicator > 0) {
			return "success";
		}
		return "";
	}

	/**
	 * This method is used to delete Reports Name
	 * @param reportData
	 * @return String
	 * @throws PLMCommonException
	 */
	public String deleteReportData(String reportData) throws PLMCommonException {
		LOG.info("reportData------->" + reportData);
		int successIndicator = 0;
		String reportSeqId = null;
		StringTokenizer token = new StringTokenizer(reportData, ",");
		try {
			while (token.hasMoreElements()) {
				reportSeqId = token.nextToken();
				LOG.info("reportSeqId------->" + reportSeqId);
				//if (reportSeqId != null) {
					LOG.info("reportSeqId-------->" + reportSeqId);
					successIndicator = getSimpleJdbcTemplate().update(
							PLMQueryConstants.DEL_REPORT_NAME,
							new Object[] { reportSeqId });
					LOG.info("Delete Report data "+PLMQueryConstants.DEL_REPORT_NAME);
				//}
			}
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}

		if (successIndicator > 0) {

			LOG.info(successIndicator);
			return "success";

		}
		return "fail";
	}

	/**
	 * This method is used to validate new user details
	 * 
	 * @param userSSO
	 * @return PLMLoginData
	 * @throws PLMCommonException
	 */
	public PLMLoginData validateUserDetails(String userSSO)
			throws PLMCommonException {
		LOG
				.info("loginUserSSO in validUserDetails of ICMAdminDaoImpl >>>>>>>>>>"
						+ userSSO);
		PLMLoginData userData = null;
		List<PLMLoginData> userDataList = null;
		try {
			userDataList = getSimpleJdbcTemplate().query(
					PLMQueryConstants.VALID_SSODATA, new UserMapper(), userSSO);
			if (userDataList != null && !userDataList.isEmpty()
					&& userDataList.size() > PLMConstants.N_0) {
				userData = userDataList.get(PLMConstants.N_0);
			}
		} finally {
			userDataList = null;
		}
		return userData;
	}

	/**
	 * This method is used to fetch the IDM Person Master Information
	 * 
	 * @param ssoID
	 * @return
	 * @throws PLMCommonException
	 */
	public PLMLoginData fetchIDMData(String ssoID) throws PLMCommonException {
		
		PLMLoginData userData = validDao.validateUser(ssoID);
		return userData;

	}
	
	/**
	 * This method is used to fetch fetchUserGroups Information
	 * @param String
	 * @return List<SelectItem>
	 * @throws PLMCommonException
	 * 
	 */
	public List<SelectItem> fetchUserGroups(String userSSO)
			throws PLMCommonException {
		List<SelectItem> userGroups = null;
		userGroups = getSimpleJdbcTemplate().query(
				PLMQueryConstants.GET_USERGROUPS, new GrpMapper(), userSSO);
		return userGroups;
	}

	/**
	 *  This method is used to get Permission Details
	 * @param userGrp
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMLoginData> getPermissionDetails(String userGrp)
			throws PLMCommonException {
		LOG
				.info("Group in getPermissionDetails of PLMAdminServiceImpl >>>>>>>>>>"
						+ userGrp);
		List<PLMLoginData> permissionData = null;
		permissionData = getSimpleJdbcTemplate().query(
				PLMQueryConstants.GET_PERMISSIONDATA, new PermData(), userGrp);
		return permissionData;
	}
	/**
	 * Author:Sonam
	 * 
	 * @return java.util.List Rowmapper For getting the list of reports.
	 */
	private static final class ReportList implements ParameterizedRowMapper<PLMAdminData>{
//	private static ParameterizedRowMapper<PLMAdminData> reportList = new ParameterizedRowMapper<PLMAdminData>() {
		public PLMAdminData mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PLMAdminData groupItem = new PLMAdminData();
			groupItem.setReportName(rs.getString(PLMConstants.RPT_NM));
			groupItem.setReportURL(rs.getString(PLMConstants.RPT_URL));
			groupItem.setDescription(rs.getString("DESCRIPTION"));

			return groupItem;
		}
//	};
	}
	/**
	 * Added by Anu Gupta
	 */
//	private static ParameterizedRowMapper<PLMAdminReportsData> hpmapper = new ParameterizedRowMapper<PLMAdminReportsData>() {
	private static final class HpMapper implements ParameterizedRowMapper<PLMAdminReportsData>{
		public PLMAdminReportsData mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PLMAdminReportsData reportData = new PLMAdminReportsData();
			reportData.setSortOrder(rs.getInt("SORT_ORDER"));
			reportData.setReportName(PLMUtils.checkNullVal(rs
					.getString("REPORT_NAME")));
			reportData.setDescription(PLMUtils.checkNullVal(rs
					.getString("DESCRIPTION")));
			reportData.setReportURL(PLMUtils.checkNullVal(rs
					.getString("REPORT_URL")));
			reportData.setBiSeqId(rs.getInt("BI_SEQ_ID"));
			return reportData;
		}
//	};
}

	/**
	 * 
	 */
	private static final class PermData implements ParameterizedRowMapper<PLMLoginData>{
//	private static ParameterizedRowMapper<PLMLoginData> permData = new ParameterizedRowMapper<PLMLoginData>() {
		public PLMLoginData mapRow(ResultSet rs, int rowNum) throws SQLException {
			PLMLoginData userData = new PLMLoginData();
			userData.setScreenId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.SCREEN_NAME)));
			userData.setPermissionId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PERM_NAME)));
			return userData;
		}
//	};
	}
	/**
	 * 
	 */
	private static final class GrpMapper implements ParameterizedRowMapper<SelectItem>{
//	private static ParameterizedRowMapper<SelectItem> grpmapper = new ParameterizedRowMapper<SelectItem>() {
		public SelectItem mapRow(ResultSet rs, int rowNum) throws SQLException {
			SelectItem userData = new SelectItem();
			userData.setLabel(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GROUP_NAME)));
			userData.setDescription(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GROUP_DESC)));
			userData.setValue(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GROUP_ID)));
			return userData;
		}
//	};
	}
	/**
	 * 
	 */
	private static final class UserMapper implements ParameterizedRowMapper<PLMLoginData>{
//	private static ParameterizedRowMapper<PLMLoginData> mapper = new ParameterizedRowMapper<PLMLoginData>() {
		public PLMLoginData mapRow(ResultSet rs, int rowNum) throws SQLException {
			PLMLoginData userData = new PLMLoginData();
			userData.setFName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.FIRST_NAME)));
			userData.setLName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.LAST_NAME)));
			userData.setEmail(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.USER_EMAIL_ADD)));
			userData.setActiveInd(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ACTIVE_IND)));
			return userData;
		}
//	};
}

	/**
	 * This Method is used for insert systemLog event
	 * 
	 * @param userSSO
	 * 
	 * @param event
	 * 
	 * @return boolean
	 * 
	 * @throws PLMCommonException
	 */
	@Transactional
	public boolean addSystemLogEvent(String userSSO, String event)
			throws PLMCommonException {
		LOG.info("loginUserSSO in addSystemLogEvent of ICMAdminDaoImpl >>>>"
				+ userSSO);
		boolean isSubmit = false;
		int count = 0;
		count = getSimpleJdbcTemplate().update(
				PLMQueryConstants.SAVE_SYSTEMLOGDATA,
				new Object[] { PLMUtils.checkNullVal(userSSO),
						PLMUtils.checkNullVal(event),
						PLMUtils.checkNullVal(userSSO),
						PLMUtils.checkNullVal(userSSO) });
		if (count > 0) {
			isSubmit = true;
		} else {
			isSubmit = false;
		}
		return isSubmit;
	}

	// Start by Kishore

	/**
	 * loadAppDetails Mapper
	 */
	private static final class LoadAppDetails implements ParameterizedRowMapper<PLMRequestData>{
//	private static ParameterizedRowMapper<PLMRequestData> loadAppDetails = new ParameterizedRowMapper<PLMRequestData>() {
		public PLMRequestData mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PLMRequestData metaData = new PLMRequestData();

			metaData.setScreenId(rs.getString(PLMConstants.WLCM_SCRN_ID));
			metaData.setScreenParentId(rs
					.getString(PLMConstants.WLCM_SCRN_PRNT_ID));
			metaData
					.setFieldName(rs.getString(PLMConstants.WLCM_SCRN_FIELD_NM));
			metaData
					.setFieldVal(rs.getString(PLMConstants.WLCM_SCRN_FIELD_VAL));
			metaData.setFieldType(rs
					.getString(PLMConstants.WLCM_SCRN_FIELD_TYPE));
			metaData.setCreateDate(rs.getString(PLMConstants.CRTN_DT));
			metaData.setCreatedBy(rs.getString(PLMConstants.CRTD_BY));
			metaData.setUpdateDate(rs.getString(PLMConstants.LST_UPDTD_DT));
			metaData.setUpdatedBy(rs.getString(PLMConstants.LST_UPDTD_BY));

			return metaData;
		}
//	};
}
	/**
	 * moduleDetails Mapper
	 */
	private static final class ModuleDetails implements ParameterizedRowMapper<SelectItem>{
//	private static ParameterizedRowMapper<SelectItem> moduleDetails = new ParameterizedRowMapper<SelectItem>() {
		public SelectItem mapRow(ResultSet rs, int rowNum) throws SQLException {
			return new SelectItem(rs.getString(PLMConstants.WLCM_SCRN_ID), rs
					.getString(PLMConstants.WLCM_SCRN_FIELD_VAL));
		}
//	};
}
	/**
	 * groupDetails Mapper
	 */
	private static final class GroupDetails implements ParameterizedRowMapper<SelectItem>{
//	private static ParameterizedRowMapper<SelectItem> groupDetails = new ParameterizedRowMapper<SelectItem>() {
		public SelectItem mapRow(ResultSet rs, int rowNum) throws SQLException {
			return new SelectItem(rs.getString(PLMConstants.GRP_ID), rs
					.getString(PLMConstants.GRP_NM));
		}
//	};
	}
	/**
	 * loadChangedDetails Mapper
	 */
	private static final class LoadChangedDetails implements ParameterizedRowMapper<PLMRequestData>{
//	private static ParameterizedRowMapper<PLMRequestData> loadChangedDetails = new ParameterizedRowMapper<PLMRequestData>() {
		public PLMRequestData mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PLMRequestData metaData = new PLMRequestData();

			metaData
					.setFieldName(rs.getString(PLMConstants.WLCM_SCRN_FIELD_NM));
			metaData
					.setFieldVal(rs.getString(PLMConstants.WLCM_SCRN_FIELD_VAL));

			return metaData;
		}
//	};
	}

	/**
	 * mailListDetails Mapper
	 */
	private static final class MailListDetails implements ParameterizedRowMapper<String>{
//	private static ParameterizedRowMapper<String> mailListDetails = new ParameterizedRowMapper<String>() {
		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			String metaData = (rs.getString(PLMConstants.USER_EMAIL_ADD));

			return metaData;
		}
//	};
	}
	

	/**
	 * retriveListDetails Mapper
	 */
	private static final class RetriveListDetails implements ParameterizedRowMapper<String>{
		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			String metaData = (rs.getString(PLMConstants.PWI_RID));

			return metaData;
		}
	}

	/**
	 * This method is used to get App Details
	 * @return PLMRequestData
	 * @throws PLMCommonException
	 */
	public PLMRequestData getAppDetails() throws PLMCommonException {
		PLMRequestData requestData = new PLMRequestData();
		List moduleValList = null;
		List assetList = null;
		LOG.info("\n\n\n getAppDetails---------ICMAdminDaoImpl------------->");
		assetList = getSimpleJdbcTemplate().query(PLMQueryConstants.SELECT_HOME_DETAILS, new LoadAppDetails());

		moduleValList = (List) getModuleValList();
		requestData.setHomePageList(assetList);
		requestData.setModuleValList(moduleValList);
		return requestData;
	}

	/**
	 * This method is used to request NewUser
	 * @return PLMRequestData
	 * @throws PLMCommonException
	 */
	public PLMRequestData requestNewUser() throws PLMCommonException {
		PLMRequestData requestData = new PLMRequestData();
		LOG.info("\n\n\n requestNewUser---------ICMAdminDaoImpl------------->");
		List groupLst =null;
		groupLst = getSimpleJdbcTemplate().query(PLMQueryConstants.DISPLAY_GROUP_DETAILS, new GroupDetails());
			requestData.setGroupList(groupLst);
		return requestData;
	}

	/**
	 * This method is used to get Changed Details
	 * @return PLMRequestData
	 * @param selectedVal
	 * @throws PLMCommonException
	 */
	public PLMRequestData getChangedDetails(String selectedVal)
			throws PLMCommonException {
		PLMRequestData requestData = new PLMRequestData();
		List assetList = null;
		Object obj[] = new Object[] { selectedVal };
		assetList = getSimpleJdbcTemplate().query(PLMQueryConstants.SELECT_HOME_DETAILS_DD, new LoadChangedDetails(),
				obj);
		requestData.setChangedList(assetList);
		return requestData;
	}

	/**
	 * This method is used to save NewUser Request
	 * @return Map<String, List<String>>
	 * @param requestData
	 * @throws PLMCommonException
	 */
	@Transactional
	public Map<String, List<String>> saveNewUserRequest(
			PLMRequestData requestData,boolean isPwiuser) throws PLMCommonException {
		String ssoId = requestData.getSsoId();
		String frstName = requestData.getLocalUserfname();
		String lstName = requestData.getLocalUserlname();
		String emailAddr = requestData.getEmailId();
		int pwiUserSeq = 0;
		List<String> requestingGrpList = null;
		String createdBy = requestData.getCreatedBy();
		String lastUpdatedBy = requestData.getLastUpdatedBy();
		int ssoCount = 0;
		String activeIndSent = requestData.getActiveIndSent();
		LOG.info("\n\n\n activeIndSent------------> " + activeIndSent);
		Map<String, List<String>> groupMap = null;
		List<String> mailList = null;
		mailList = getSimpleJdbcTemplate().query(PLMQueryConstants.ADMIN_EMAIL, new MailListDetails());

		ssoCount = getJdbcTemplate().queryForInt(
				PLMQueryConstants.GET_COUNT_SSO, new Object[] { ssoId });
		
		groupMap = (Map<String, List<String>>) insertRequestAcount(requestData, ssoId);
		
		
		requestingGrpList = (List<String>) groupMap.get("Requesting");
		LOG.info("Requesting Group List "+requestingGrpList);
		if (!PLMUtils.isEmptyList(requestingGrpList)) {
			if (!(requestData.getReadOnlyAccsGrp() && requestingGrpList.size()==PLMConstants.N_1 && !isPwiuser)) {
				sendEmailOnRequest(groupMap, mailList, requestData);
			}
		}
		return groupMap;
	}

	/**
	 * Grant Auto Access _Search and Read Only Groups - Thread Logic to be used
	 * here
	 * 
	 * @param requestData
	 * @throws PLMCommonException
	 */
	public void grantAutoAccess(PLMRequestData requestData, String groupIdRequest)
			throws PLMCommonException {
		this.setUserRequestData(requestData);
		this.setGroupIdReq(groupIdRequest);
		grantReadAccess();
	}

	/**
	 * @param ssoID
	 * @param frstName
	 * @param lstName
	 * @param emailAddr
	 */
	private synchronized boolean addPWIUser(String ssoID, String frstName, String lstName,
			String emailAddr) {
		
		LOG.info("Inside addPWIUser method ");
		
		LOG.info("Executing Query for getting user info LIST_SSOID_PWI Query "+PLMQueryConstants.LIST_SSOID_PWI);
		
		List<PLMPwiUserData> pwiUsrLst =  getSimpleJdbcTemplate()
		.query(PLMQueryConstants.LIST_SSOID_PWI, new QuerySsoListPwi(), ssoID);
		
		LOG.info("After execution of  LIST_SSOID_PWI Query ");
		
		int pwiUserSeq = 0;
		
		if (!PLMUtils.isEmptyList(pwiUsrLst)) {
					
			int pwiUid = pwiUsrLst.get(0).getUserId();
			List<String> pwiUidRoleLst  = getSimpleJdbcTemplate()
			.query(PLMQueryConstants.LIST_ROLES_SSO, new FetchRolesForSso(), ssoID);
			
			if (PLMUtils.isEmptyList(pwiUidRoleLst)) {			
				getJdbcTemplate().update(PLMQueryConstants.INSERT_PWI_PGPLM_ROLE_MEMBERSHIP, new Object[] {pwiUid, ssoID, ssoID});
				LOG.info("Row inserted to PWI_ROLE_MEMBERSHIP");
				getJdbcTemplate().update(PLMQueryConstants.UPDATE_PWI_ENABLED, new Object[] {pwiUid});
				LOG.info("Updated PWI Enabled for the user ");
				
			}else{
				LOG.info("PWI_USER Role already mapped to SSO. No row inserted.....");
			}
			getJdbcTemplate().update(PLMQueryConstants.DEL_PGPLM_ROLE_REQ, new Object[] {ssoID});
			
		}  else {
			LOG.info("SSO not present in PWI_USERS table,,,,, adding new row.....");
			pwiUserSeq = getSimpleJdbcTemplate().queryForInt(PLMQueryConstants.GET_PWI_UID_SEQ);
			getJdbcTemplate().update(PLMQueryConstants.INSERT_PWI_USERS,new Object[] { pwiUserSeq, ssoID, frstName, lstName, emailAddr, ssoID, ssoID });
			LOG.info("Row inserted to PWI_USER");
			getJdbcTemplate().update(PLMQueryConstants.INSERT_PWI_PGPLM_ROLE_MEMBERSHIP, new Object[] {pwiUserSeq, ssoID, ssoID});
			LOG.info("Row inserted to PWI_ROLE_MEMBERSHIP");
			getJdbcTemplate().update(PLMQueryConstants.UPDATE_PWI_ENABLED, new Object[] {pwiUserSeq});
			LOG.info("Updated PWI Enabled for the user ");
			getJdbcTemplate().update(PLMQueryConstants.DEL_PGPLM_ROLE_REQ, new Object[] {ssoID});
			
		}	
		LOG.info("*********************Ending PWi Table Data Insert Logic***************************");
		return true;
	}
	/**
	 * This method is used to start the Auto-Access process
	 * 
	 * @throws PLMCommonException
	 */
	private synchronized void grantReadAccess() throws PLMCommonException {
		Thread accessThread = new Thread(new Runnable() {
			public void run() {
				boolean autoAccessFlag = false;
				List<String> mailList = getSimpleJdbcTemplate().query(PLMQueryConstants.ADMIN_EMAIL,
						new MailListDetails());
				try {
					LOG
							.info("User Requested Access to _Search and Read Only >>"
									+ getUserRequestData().getReadOnlyAccsGrp());
					autoAccessFlag = addPWIUser(getUserRequestData().getSsoId(), getUserRequestData().getLocalUserfname(),
										getUserRequestData().getLocalUserlname(),getUserRequestData().getEmailId());
								
					if (autoAccessFlag) {
						
							LOG.info("Sending email after auto-access >>"
									+ autoAccessFlag);
							sendAutoAccessEmailNew(getUserRequestData(), mailList);
							
					}
				} catch (PLMCommonException ice) {
					LOG.error("Error in granting auto-access process.");
				}
			}
		});
		accessThread.start();
	}

	/**
	 * This method is used to send email to the Requestor after Auto Access
	 * 
	 * @param requestData
	 * @throws PLMCommonException
	 */
	public void sendAutoAccessEmail(PLMRequestData requestData,
			List<String> mailList) throws PLMCommonException {
		ArrayList<String> toMail = new ArrayList<String>();
		ArrayList<String> ccMail = new ArrayList<String>();
		StringBuffer subject = null;
		StringBuffer body = null;
		subject = new StringBuffer();
		body = new StringBuffer();
		String title = null;
		title = requestData.getLocalUserlname() + ", "
				+ requestData.getLocalUserfname() + "{"
				+ requestData.getSsoId() + "}";
		subject.append(" PLM Reporting Access Granted to - " + " \"" + title + " \"");
		body.append(PLMConstants.HTML_TAG);
		body.append("<body>");
		body.append("<font color='blue'>");
		body
				.append("<table width=\"100%\" border=\"0\" cellpadding=\"4\" cellspacing=\"0\">");
		body.append("<tr>");
		body.append("<br>");
		body.append("Dear PLM Reporting user,");
		body.append("<br>");
		body.append("<br>");
		body.append("Your request for " + " \""
				+ PLMUtils.getMessage(PLMConstants.AUTO_ACCESS_GROUP) + " \""
				+ " Role has been processed.");

		body.append("<br>");
		body.append("<br>");
		body.append("Please login to the ");
		body.append(
				"<a href=" + rbundle.getString(PLMConstants.PLMR_APP_URL) + ">")
				.append("\"" + "PLM Reporting application" + "\"").append("</a>");
		body.append(" and test your access to the application.");
		body.append("<br>");
		body.append("<br>");
		body.append("<br>");
		body.append("This is an auto-generated email. Please do not reply.");
		body.append("</tr>");
		body.append("</table>");
		body.append("</font>");
		body.append("</body>");
		body.append("</html>");
		if (requestData.getEmailId() != null) {
			toMail.add(requestData.getEmailId());
			ccMail.addAll(mailList);
			mailBean.sendMail(toMail, ccMail, subject.toString(), body
					.toString(), mailSend, "test");
		}
	}

	/**
	 * This method is used to send an email upon requesting PLM Reporting App Access
	 * 
	 * @param groupMap
	 * @param mailList
	 * @param requestData
	 * @throws PLMCommonException
	 */
	public void sendEmailOnRequest(Map groupMap, List<String> mailList,
			PLMRequestData requestData) throws PLMCommonException {
		ArrayList<String> toMail = new ArrayList<String>();
		ArrayList<String> ccMail = new ArrayList<String>();
		StringBuffer subject = null;
		StringBuffer body = null;
		subject = new StringBuffer();
		body = new StringBuffer();
		//String linkUrl = null;
		List requestingGroupList = null;
		String title = null;
		title = requestData.getLocalUserlname() + ", "
				+ requestData.getLocalUserfname() + "{"
				+ requestData.getSsoId() + "}";
		requestingGroupList = (List) groupMap.get("Requesting");
		toMail.addAll(mailList);
		subject.append(" \"" + title + "\" requested Power Warehouse Intelligence Application Access");
		body.append(PLMConstants.HTML_TAG);
		body.append("<body>");
		body.append("<font color='blue'>");
		body
				.append("<table width=\"100%\" border=\"0\" cellpadding=\"4\" cellspacing=\"0\">");
		body.append("<tr>");
		body.append("<br>");
		body.append("Dear Admin,");
		body.append("<br>");
		body.append("<br>");
		body
				.append("A request for a new Power Warehouse Intelligence user Account has been raised by \""
						+ title + "\" for the Role(s)");
		for (int i = 0; i < requestingGroupList.size(); i++) {
			if (requestData.getReadOnlyAccsGrp()) {
				if (!requestingGroupList.get(i).toString().equalsIgnoreCase(PLMUtils.getMessage(PLMConstants.AUTO_ACCESS_GROUP))) {
					if (i == PLMConstants.N_0) {
						body.append(" \"" + requestingGroupList.get(i) + "\"");
					} else {
						body.append("," + " \"" + requestingGroupList.get(i) + "\"");
					}
				}
			} else {
				if (i == PLMConstants.N_0) {
					body.append(" \"" + requestingGroupList.get(i) + "\"");
				} else {
					body.append("," + " \"" + requestingGroupList.get(i) + "\"");
				}
			}
		}
		body.append(".");
		body.append("<br>");
		body.append("<br>");
		/*if (requestData.getContactDetails() != null
				&& requestData.getContactDetails().length() > 0) {
			body.append("User Contact Information: "
					+ requestData.getContactDetails());
			body.append("<br>");
			body.append("<br>");
		}*/
		if (requestData.getComments() != null
				&& requestData.getComments().length() > 0) {
			body.append("User Comments: " + requestData.getComments());
			body.append("<br>");
			body.append("<br>");
		}
		body.append("Please login to the ");
		body.append(
				"<a href=" + rbundle.getString(PLMConstants.PLMR_APP_URL) + ">")
				.append("\"" + "Power Warehouse Intelligence application" + "\"").append("</a>");
		body
				.append(" for adding the User using \"Admin -> Users --> Create New User \" function.");
		body.append("<br>");
		body.append("<br>");
		if (requestData.getReadOnlyAccsGrp()) {
			body.append("Note: User has also requested access for the role "+PLMUtils.getMessage(PLMConstants.AUTO_ACCESS_GROUP))
			.append(" and the request is Auto Approved.");
			body.append("<br>");
			body.append("<br>");
		}
		body.append("<br>");
		body.append("This is an auto-generated email. Please do not reply.");
		body.append("</tr>");
		body.append("</table>");
		body.append("</font>");
		body.append("</body>");
		body.append("</html>");
		mailBean.sendMail(toMail, ccMail, subject.toString(), body.toString(),
				mailSend, "test");

	}

	/**
	 * @param requestData
	 * @return
	 */
	@Transactional
	private Map<String, List<String>> insertRequestAcount(
			PLMRequestData requestData, String ssoId) {
		String comments = requestData.getComments();
		List<String> groupSeqId = (List<String>) requestData.getGroupSeqId();
		List<String> groupName = (List<String>) requestData.getGroupNameList();
		List<SelectItem> groupLst = requestData.getGroupList();
		List<String> tempgroupSeqId = null;
		String createdBy = requestData.getCreatedBy();
		String lastUpdatedBy = requestData.getLastUpdatedBy();
		List<String> grpCount = new ArrayList<String>();
		List<String> tempGrpCount = new ArrayList<String>();
		Map groupListMap = null;
		groupListMap = new HashMap();
		Object obj[] = new Object[] { ssoId };
		tempgroupSeqId = getSimpleJdbcTemplate().query(PLMQueryConstants.GET_COUNT,
				new RetriveListDetails(), obj);
		Map groupMap = null;
		groupMap = new HashMap();
		LOG.info("\n\n\n tempgroupSeqId======saveNewUserRequest===Existing===>"
				+ tempgroupSeqId);
		LOG.info("\n\n\n groupSeqId======saveNewUserRequest===Currently===>"
				+ groupSeqId);
		Iterator<SelectItem> itr = groupLst.iterator();
		while (itr.hasNext()) {
			SelectItem val1 = itr.next();
			groupListMap.put(val1.getValue(), val1.getLabel());
		}

		for (String str : groupSeqId) {
			if (tempgroupSeqId.contains(str)) {
				tempGrpCount.add((String) groupListMap.get(str));
				groupMap.put("Requested", tempGrpCount);
			} else {
				getJdbcTemplate().update(
						PLMQueryConstants.INSERT_ACC_REC_RECORD,
						new Object[] { ssoId, str, comments, createdBy, lastUpdatedBy });
				grpCount.add(groupName.get(groupSeqId.indexOf(str)));
				groupMap.put("Requesting", grpCount);
			}
		}

		return groupMap;

	}

	/**
	 * To fetch the module related details
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List getModuleValList() throws PLMCommonException {
		List modNameList = null;
		modNameList = getSimpleJdbcTemplate().query(PLMQueryConstants.SELECT_DD_VALUES, new ModuleDetails());
		return modNameList;
	}

	/**
	 * This method is used to save the Maintain WS details
	 * 
	 * @param requestData
	 * @throws PLMCommonException
	 */
	@Transactional
	public void saveIcmDetails(PLMRequestData requestData)
			throws PLMCommonException {
		// passing from Dao
		String desc = requestData.getMaitnModDesc();
		String link = requestData.getMaitnModLink();
		String presentation = requestData.getMaitnModPresentation();
		String training = requestData.getMaitnModTraining();
		String selectedModId = requestData.getSelectedMaintainName();

		if (!PLMUtils.isNullOrEmpty(desc)
				&& !PLMUtils.isNullOrEmpty(selectedModId)) {
			getJdbcTemplate().update(PLMQueryConstants.UPDATE_DD_REL_DESC,
					new Object[] { desc, selectedModId });
		}
		if (!PLMUtils.isNullOrEmpty(link)
				&& !PLMUtils.isNullOrEmpty(selectedModId)) {
			getJdbcTemplate().update(PLMQueryConstants.UPDATE_DD_REL_LINK,
					new Object[] { link, selectedModId });
		}
		if (!PLMUtils.isNullOrEmpty(presentation)) {
			getJdbcTemplate().update(
					PLMQueryConstants.UPDATE_DD_REL_PRESENTATION,
					new Object[] { presentation });
		}
		if (!PLMUtils.isNullOrEmpty(training)) {
			getJdbcTemplate().update(PLMQueryConstants.UPDATE_DD_REL_USRGUIDE,
					new Object[] { training });
		}
	}

	/**
	 * This method is used to save the Maintain WS details
	 * 
	 * @param requestData
	 * @throws PLMCommonException
	 */
	public void saveAppDetails(PLMRequestData requestData)
			throws PLMCommonException {
		// passing from Dao
		String version = requestData.getMaitnVersionNo();
		String relDate = requestData.getMaitnReleaseDate();
		String relDetails = requestData.getMaitnRelDetails();
		String relDesc = requestData.getMaitnRelDescription();

		if (!PLMUtils.isNullOrEmpty(version)) {
			getJdbcTemplate().update(PLMQueryConstants.UPDATE_DD_REL_VER,
					new Object[] { version });
		}
		if (!PLMUtils.isNullOrEmpty(relDate)) {
			getJdbcTemplate().update(PLMQueryConstants.UPDATE_DD_REL_DATE,
					new Object[] { relDate });
		}
		if (!PLMUtils.isNullOrEmpty(relDetails)) {
			getJdbcTemplate().update(PLMQueryConstants.UPDATE_DD_REL_DETAILS,
					new Object[] { relDetails });
		}
		if (!PLMUtils.isNullOrEmpty(relDesc)) {
			getJdbcTemplate().update(
					PLMQueryConstants.UPDATE_DD_REL_DESCRIPTION,
					new Object[] { relDesc });
		}

	}

	/**
	 * This method is used to save the Maintain WS details
	 * 
	 * @param requestData
	 * @throws PLMCommonException
	 */
	public void saveAncmtDetails(String maitnAnnouncements)
			throws PLMCommonException {
		// passing from Dao
		if (!PLMUtils.isNullOrEmpty(maitnAnnouncements)) {
			getJdbcTemplate().update(PLMQueryConstants.UPDATE_DD_REL_ANCMT,
					new Object[] { maitnAnnouncements });
		}

	}

	// Ended by Kishore

	
	/**
	 * @param beginDate
	 * @param endDate
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMReportData> getSysLogContents(String beginDate,
			String endDate) throws PLMCommonException {
		List<PLMReportData> sysLogList = null;
		try {
			if (beginDate != null && endDate != null) {
				sysLogList = getSimpleJdbcTemplate().query(PLMQueryConstants.SYSLOG_DATA, new SelectedSysLogMapper(),
						new Object[] { beginDate, endDate });
			}
			/*LOG.info("sysLogList is >>>" + sysLogList != null ? sysLogList.size()
					: 0);*/
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return sysLogList;
	}

	
	/**
	 * @return reportBean
	 */
	
	private static final class SelectedSysLogMapper implements ParameterizedRowMapper<PLMReportData>{
//	private static ParameterizedRowMapper<PLMReportData> selectedSysLogMapper = new ParameterizedRowMapper<PLMReportData>() {
		public PLMReportData mapRow(ResultSet rSet, int rowCount)
		throws SQLException {
			PLMReportData reportBean = new PLMReportData();
			reportBean.setLogDate(rSet.getString(PLMConstants.LOG_DATE));
			reportBean.setLogEvent(rSet.getString(PLMConstants.EVNT_NM));
			reportBean.setUserName(rSet.getString(PLMConstants.FULL_NAME));
			reportBean.setUserSsoId(rSet.getString(PLMConstants.LOG_USER_ID));
			return reportBean;
		}
		
	}
	// Start Of Adminusecase
	/**
	 * @return java.util.List For getting the list of groups.
	 */
	public List<PLMAdminData> getListOfGroups() throws PLMCommonException {
		List<PLMAdminData> listOfGroups = new ArrayList<PLMAdminData>();
		try{
		// listOfGroups = new ArrayList<PLMAdminData>();
		listOfGroups = getSimpleJdbcTemplate().query(PLMQueryConstants.GET_GROUP_DATA, new GroupList());
		} catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return listOfGroups;
	}
	
	

	/**
	 * @return java.util.List Rowmapper For getting the list of groups.
	 */
	private static final class GroupList implements ParameterizedRowMapper<PLMAdminData>{
//	private static ParameterizedRowMapper<PLMAdminData> groupList = new ParameterizedRowMapper<PLMAdminData>() {
		public PLMAdminData mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PLMAdminData groupItem = new PLMAdminData();
			groupItem.setGruopId(rs.getString(PLMConstants.GRP_ID));
			groupItem.setGroupName(rs.getString(PLMConstants.GRP_NM));
			groupItem.setGroupDescription(rs.getString(PLMConstants.GRP_DESC));

			return groupItem;
		}
//	};
}

	/**
	 * @return java.util.List For getting the list of groups.
	 */
	public List<SelectItem> getListOfUserGroups() throws PLMCommonException {
		List<SelectItem> listOfGroups = new ArrayList <SelectItem> ();
		try {
			listOfGroups = getSimpleJdbcTemplate().query(
					PLMQueryConstants.GET_GROUP_DETAILS, new QueryListOfUserGroups());
		} catch (DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return listOfGroups;
	}

	/**
	 * @return java.util.List Rowmapper For getting the list of usergroups.
	 */
	private static final class QueryListOfUserGroups implements ParameterizedRowMapper<SelectItem>{
//	private static ParameterizedRowMapper<SelectItem> queryListOfUserGroups = new ParameterizedRowMapper<SelectItem>() {
		public SelectItem mapRow(ResultSet rs, int rowNum) throws SQLException {
			SelectItem selectItem = new SelectItem(rs
					.getString(PLMConstants.GRP_ID), rs
					.getString(PLMConstants.GRP_NM), rs
					.getString(PLMConstants.GRP_DESC));
			return selectItem;
		}
//	};
	}

	/**
	 * @return java.util.List For getting the users related to a particular
	 *         group
	 */
	public List<PLMLoginData> getUserList(String groupID)
			throws PLMCommonException {
		LOG.info("GroupID in DAO" + groupID);
		// List<PLMLoginData> userList = new ArrayList<PLMLoginData>();
		List<PLMLoginData> userList = getSimpleJdbcTemplate().query( PLMQueryConstants.GET_USER_DETAILS,
				new QueryUserList(), groupID);

		return userList;
	}

	/**
	 * @return java.util.List Rowmapper For getting the list of userList.
	 */
	private static final class QueryUserList implements ParameterizedRowMapper<PLMLoginData>{
//	private static ParameterizedRowMapper<PLMLoginData> queryUserList = new ParameterizedRowMapper<PLMLoginData>() {
		public PLMLoginData mapRow(ResultSet rs, int rowNum) throws SQLException {
			PLMLoginData user = new PLMLoginData();
			user.setSsoId(rs.getString(PLMConstants.USER_SS0));
			if (rs.getString(PLMConstants.USER_NAME).trim().equals(",")) {

				user.setUserName(PLMConstants.EMPTY_STRING);
			} else {

				user.setUserName(rs.getString(PLMConstants.USER_NAME));
			}
			user.setEmail(rs.getString(PLMConstants.USER_EMAIL_ADD));
			user.setGroupName(rs.getString(PLMConstants.GRP_NM));
			return user;
		}
//	};
}

	/**
	 * @return PLMLoginData For modifying the user details
	 */
	@Transactional
	public PLMLoginData modifyUser(String ssoID) throws PLMCommonException {
		// List<SelectItem> groups = getListOfUserGroups();
		PLMLoginData user = new PLMLoginData();
		try {
			LOG.info("SSOID..... in DAO" + ssoID);
			// List<PLMLoginData> userInfoList = new ArrayList<PLMLoginData>();
			
			List<PLMLoginData> userInfoList = getSimpleJdbcTemplate().query(
					 PLMQueryConstants.GET_USER_INFORMATION, new QueryModifyUser(), ssoID);
			List<SelectItem> listOfGroups = getSimpleJdbcTemplate().query(
					PLMQueryConstants.GRPNAME_ID, new QueryUserGroups(), ssoID);
			
			// return listOfGroups;
			PLMLoginData selGrp = null;
			selGrp = userInfoList.get(0);
			user.setSsoId(selGrp.getSsoId());
			user.setFirstName(selGrp.getFirstName());
			user.setLastName(selGrp.getLastName());
			user.setEmail(selGrp.getEmail());
			user.setPhone(selGrp.getPhone());
			user.setFax(selGrp.getFax());
			user.setStatus(selGrp.getStatus());
			user.setDepartment(selGrp.getDepartment());
			user.setAddress(selGrp.getAddress());
			user.setCity(selGrp.getCity());
			user.setState(selGrp.getState());
			user.setCountry(selGrp.getCountry());
			user.setZipCode(selGrp.getZipCode());
			user.setListSelectedGrps(listOfGroups);
		} catch (DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return user;
	}

	/**
	 * @return java.util.List Rowmapper For getting the list of usergroups.
	 */
	private static final class QueryUserGroups implements ParameterizedRowMapper<SelectItem>{
//	private static ParameterizedRowMapper<SelectItem> queryUserGroups = new ParameterizedRowMapper<SelectItem>() {
		public SelectItem mapRow(ResultSet rs, int rowNum) throws SQLException {
			SelectItem selectItem = new SelectItem(rs
					.getString(PLMConstants.GRP_ID), rs
					.getString(PLMConstants.GRP_NM));
			return selectItem;

		}
//	};
}
	/**
	 * @return java.util.List Rowmapper For getting the modification of
	 *         userdata.
	 */
//	private static ParameterizedRowMapper<PLMLoginData> queryModifyUser = new ParameterizedRowMapper<PLMLoginData>() {
	private static final class QueryModifyUser implements ParameterizedRowMapper<PLMLoginData>{
		public PLMLoginData mapRow(ResultSet rs, int rowNum) throws SQLException {
			PLMLoginData user = new PLMLoginData();
			user.setSsoId(rs.getString(PLMConstants.USER_SS0));
			user.setFirstName(rs.getString(PLMConstants.USER_FIRST_NAME));
			user.setLastName(rs.getString(PLMConstants.USER_LAST_NAME));
			user.setEmail(rs.getString(PLMConstants.USER_EMAIL_ADD));
			user.setEmailNotification((rs
					.getString(PLMConstants.USER_EMAIL_REQUIRED)));
			user.setPhone(rs.getString(PLMConstants.USER_PHONE));
			user.setFax(rs.getString(PLMConstants.USER_FAX));
			user.setStatus(rs.getString(PLMConstants.USER_STATUS));

			return user;
		}
//	};
} 

	/**
	 * @return PLMLoginData For adding a new user
	 */
	public PLMLoginData addUser() throws PLMCommonException {
		List<SelectItem> groups = getSimpleJdbcTemplate().query(
				PLMQueryConstants.GET_GROUP_DETAILS, new QueryListOfUserGroups());
		PLMLoginData temp = new PLMLoginData();
		temp.setListOfGroups(groups);
		return temp;
	}

	/**
	 * @return java.lang.Boolean For deleting a user
	 */
	@Transactional
	public boolean deleteUser(List<String> ssoID, String groupID)
			throws PLMCommonException {
		try {
			  Map<String, Object> updparams = new HashMap<String, Object>();
			  Map<String, Object> delparams = new HashMap<String, Object>();
				
				if (ssoID != null && !ssoID.isEmpty()) {
					List<String> groupIdList =new ArrayList<String>();
					for (String checkString : ssoID) {
						groupIdList.add(checkString);
					}
					updparams.put("INDR", PLMConstants.NOO);
					updparams.put("SSO", groupIdList);
					delparams.put("SSO", groupIdList);
					getNamedJdbcTemplate().update(PLMQueryConstants.UPDATE_IND,updparams);
					getNamedJdbcTemplate().update(PLMQueryConstants.DEL_USER_GROUP ,delparams);
				}
			} catch (DataAccessException e){
				PLMUtils.checkException(e.getMessage());
			}
			return true;
		}

	/**
	 * @return PLMLoginData Rowmapper For the accessList.
	 */
	private static final class QueryAccLst implements ParameterizedRowMapper<String> {
//	private static ParameterizedRowMapper<String> queryAccLst = new ParameterizedRowMapper<String>() {
		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			return rs.getString(2) + "~" + rs.getString(1);
		}
	}
	/**
	 * @return PLMLoginData Rowmapper For the screenLst.
	 */
	private static final class QueryScrLst implements ParameterizedRowMapper<String>{
//	private static ParameterizedRowMapper<String> queryScrLst = new ParameterizedRowMapper<String>() {
		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			return rs.getString(2) + "~" + rs.getString(1);
		}
}
	/**
	 * @return PLMLoginData Rowmapper For the screenPermissions.
	 */
	private static final class QueryTempListOut implements ParameterizedRowMapper<PLMSecurityMatrixData>{
//	private static ParameterizedRowMapper<PLMSecurityMatrixData> queryTempListOut = new ParameterizedRowMapper<PLMSecurityMatrixData>() {
		public PLMSecurityMatrixData mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PLMSecurityMatrixData data = new PLMSecurityMatrixData();
			data.setType(rs.getString(PLMConstants.SCREN_NAME));
			data.setAccess(rs.getString(PLMConstants.PERMISSION_NAME));
			data.setDisplayValue(PLMConstants.NOT_APPLICABLE);
			data.setCheckValue(false);
			data.setOutputValue(PLMConstants.NOT_APPLICABLE);
			data.setHeader(false);
			data.setAccessID(rs.getInt(PLMConstants.PERMISSION_ID));
			data.setPermissionIdNew(rs.getInt(PLMConstants.SCREEN_IND));
			return data;
		}
}

	/**
	 * @return java.util.List For security matrix for a existing group
	 */
	public List<PLMSecurityMatrixData> getGroupPermissions(String gruopId)
			throws PLMCommonException {
		List<PLMSecurityMatrixData> mainList = new ArrayList<PLMSecurityMatrixData>();
	try {
		List<String> accessList = getSimpleJdbcTemplate().query(
				PLMQueryConstants.ACCESS_LIST_QUERY, new QueryAccLst());

		PLMSecurityMatrixData dataHeader = new PLMSecurityMatrixData();
		dataHeader.setType("  ");
		dataHeader.setAccess("  ");
		dataHeader.setDisplayValue(PLMConstants.SCREEN_PERMISSION_HEADER);
		dataHeader.setCheckValue(false);
		dataHeader.setOutputValue(PLMConstants.NOT_APPLICABLE);
		dataHeader.setHeader(true);
		dataHeader.setAccessID(0);
		dataHeader.setPermissionIdNew(0);
		mainList.add(dataHeader);
		for (String accList : accessList) {
			dataHeader = new PLMSecurityMatrixData();
			dataHeader.setType(accList.substring(0, accList.indexOf('~')));
			dataHeader.setAccess(accList.substring(0, accList.indexOf('~')));
			dataHeader.setDisplayValue(accList.substring(0, accList
					.indexOf('~')));
			dataHeader.setCheckValue(false);
			dataHeader.setOutputValue(PLMConstants.NOT_APPLICABLE);
			dataHeader.setHeader(true);
			int temp = Integer.parseInt(accList.substring(
					accList.indexOf('~') + 1, accList.length()));
			dataHeader.setAccessID(temp);
			mainList.add(dataHeader);
		}
		List<String> screenList = getSimpleJdbcTemplate().query(
				PLMQueryConstants.SCREEN_LIST_QUERY, new QueryScrLst());

		String accessMat = PLMQueryConstants.ACCESS_MAT;

		String inAccessMat = PLMQueryConstants.INACCESS_MAT;

		for (String screen : screenList) {

			PLMSecurityMatrixData data = new PLMSecurityMatrixData();
			data.setType(screen.substring(0, screen.indexOf('~')));
			data.setAccess(screen.substring(0, screen.indexOf('~')));
			data.setDisplayValue(screen.substring(0, screen.indexOf('~')));
			data.setCheckValue(false);
			data.setOutputValue(PLMConstants.NOT_APPLICABLE);
			data.setHeader(false);
			dataHeader.setAccessID(0);
			int temp1 = Integer.parseInt(screen.substring(
					screen.indexOf('~') + 1, screen.length()));
			data.setPermissionIdNew(temp1);
			mainList.add(data);

			List<PLMSecurityMatrixData> tempdata = new ArrayList<PLMSecurityMatrixData>();

			List<PLMSecurityMatrixData> tempListOUT = getSimpleJdbcTemplate()
					.query(inAccessMat, new QueryTempListOut(),
							screen.substring(0, screen.indexOf('~')));

			tempdata.addAll(tempListOUT);

			extractGrpPermisssions(gruopId, accessList, accessMat, screen,
					tempdata, tempListOUT);

			Collections.sort(tempdata, new SortList());
			mainList.addAll(tempdata);
		}
	} catch(DataAccessException e){
		PLMUtils.checkException(e.getMessage());
	}
		LOG.info("In DAOOOOOOO" + gruopId);
		return mainList;
	}

	/**
	 * @return ICMSecurityMatrixrData Rowmapper For the screenPermissions.
	 */
	private static final class QueryTempListIn implements ParameterizedRowMapper<PLMSecurityMatrixData>{
//	private static ParameterizedRowMapper<PLMSecurityMatrixData> queryTempListIn = new ParameterizedRowMapper<PLMSecurityMatrixData>() {
		public PLMSecurityMatrixData mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PLMSecurityMatrixData data = new PLMSecurityMatrixData();
			data.setType(rs.getString(PLMConstants.SCREN_NAME));
			data.setAccess(rs.getString(PLMConstants.PERMISSION_NAME));
			data.setDisplayValue(PLMConstants.NOT_APPLICABLE);
			if ((PLMConstants.YES).equalsIgnoreCase(rs
					.getString(PLMConstants.ACCESS_IND))) {
				data.setCheckValue(true);
			} else {
				data.setCheckValue(false);
			}
			data.setOutputValue(PLMConstants.CHECK_BOX);
			data.setHeader(false);
			data.setAccessID(rs.getInt(PLMConstants.PERMISSION_ID));
			data.setPermissionIdNew(rs.getInt(PLMConstants.SCREEN_IND));
			return data;
		}
}

	/**
	 * @param gruopId
	 * @param accessList
	 * @param AccessMat
	 * @param screen
	 * @param tempdata
	 * @param tempListOUT
	 */
	private void extractGrpPermisssions(String gruopId,
			List<String> accessList, String accessMat, String screen,
			List<PLMSecurityMatrixData> tempdata,
			List<PLMSecurityMatrixData> tempListOUT) throws PLMCommonException {
		PLMSecurityMatrixData data;
		List<PLMSecurityMatrixData> tempListIN = getSimpleJdbcTemplate().query(
				accessMat, new QueryTempListIn(), gruopId,
				screen.substring(0, screen.indexOf('~')));

		tempdata.addAll(tempListIN);

		int out = 0;
		int in = 0;
		int mainSize = 0;
		if (accessList != null && accessList.size() > 0) {
			mainSize = accessList.size();
			if (tempListOUT != null && tempListOUT.size() > 0) {
				out = tempListOUT.size();
			}
			if (tempListIN != null && tempListIN.size() > 0) {
				in = tempListIN.size();
			}
		}
		if (mainSize != (out + in)) {
			for (String accList : accessList) {
				int cout = 0;
				for (PLMSecurityMatrixData matList : tempdata) {
					if (screen.substring(0, screen.indexOf('~'))
							.equalsIgnoreCase(matList.getType())) {
						if (accList.substring(0, accList.indexOf('~'))
								.equalsIgnoreCase(matList.getAccess())) {
							cout = 1;
						}
					}
				}
				if (cout == 0) {
					data = new PLMSecurityMatrixData();
					data.setType(screen.substring(0, screen.indexOf('~')));
					data.setAccess(accList.substring(0, accList.indexOf('~')));
					data.setDisplayValue(PLMConstants.NOT_APPLICABLE);
					data.setCheckValue(false);
					data.setOutputValue(PLMConstants.CHECK_BOX);
					data.setHeader(false);
					int temp = Integer.parseInt(accList.substring(accList
							.indexOf('~') + 1, accList.length()));
					data.setAccessID(temp);
					int temp2 = Integer.parseInt(screen.substring(screen
							.indexOf('~') + 1, screen.length()));
					data.setPermissionIdNew(temp2);
					tempdata.add(data);
				}
			}
		}
	}

	/**
	 * 
	 * class to sort list of object of type selected item.
	 * 
	 */
	private static class SortList implements Comparator<PLMSecurityMatrixData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMSecurityMatrixData aString,
				PLMSecurityMatrixData bString) {
			Integer aStr;
			Integer bStr;
			aStr = aString.getAccessID();
			bStr = bString.getAccessID();
			return aStr.compareTo(bStr);
		}
	}

	/**
	 * @return java.util.List FOr getting security matrix for a new group
	 */
	public List<PLMSecurityMatrixData> addGroup() throws PLMCommonException {
		List<PLMSecurityMatrixData> mainList = new ArrayList<PLMSecurityMatrixData>();
	try {
		List<String> accessList = getSimpleJdbcTemplate().query(
				PLMQueryConstants.ACCESS_LIST_QUERY, new QueryAccLst());

		PLMSecurityMatrixData dataHeader = new PLMSecurityMatrixData();
		dataHeader.setType("  ");
		dataHeader.setAccess("  ");
		dataHeader.setDisplayValue(PLMConstants.SCREEN_PERMISSION_HEADER);
		dataHeader.setCheckValue(false);
		dataHeader.setOutputValue(PLMConstants.NOT_APPLICABLE);
		dataHeader.setHeader(true);
		dataHeader.setAccessID(0);
		dataHeader.setPermissionIdNew(0);
		mainList.add(dataHeader);
		for (String accList : accessList) {
			dataHeader = new PLMSecurityMatrixData();
			dataHeader.setType(accList.substring(0, accList.indexOf('~')));
			dataHeader.setAccess(accList.substring(0, accList.indexOf('~')));
			dataHeader.setDisplayValue(accList.substring(0, accList
					.indexOf('~')));
			dataHeader.setCheckValue(false);
			dataHeader.setOutputValue(PLMConstants.NOT_APPLICABLE);
			dataHeader.setHeader(true);
			int temp = Integer.parseInt(accList.substring(
					accList.indexOf('~') + 1, accList.length()));
			dataHeader.setAccessID(temp);
			mainList.add(dataHeader);
		}
		List<String> screenList = getSimpleJdbcTemplate().query(
				PLMQueryConstants.SCREEN_LIST_QUERY, new QueryScrLst());

		for (String screen : screenList) {

			PLMSecurityMatrixData data = new PLMSecurityMatrixData();
			data.setType(screen.substring(0, screen.indexOf('~')));
			data.setAccess(screen.substring(0, screen.indexOf('~')));
			data.setDisplayValue(screen.substring(0, screen.indexOf('~')));
			data.setCheckValue(false);
			data.setOutputValue(PLMConstants.NOT_APPLICABLE);
			data.setHeader(false);
			dataHeader.setAccessID(0);
			int temp1 = Integer.parseInt(screen.substring(
					screen.indexOf('~') + 1, screen.length()));
			data.setPermissionIdNew(temp1);
			mainList.add(data);

			List<PLMSecurityMatrixData> tempdata = new ArrayList<PLMSecurityMatrixData>();

			List<PLMSecurityMatrixData> tempListOUT = getSimpleJdbcTemplate()
					.query(PLMQueryConstants.INACCESS_MAT, new QueryTempListOut(),
							screen.substring(0, screen.indexOf('~')));
			int out = 0;
			int mainSize = 0;
			if (tempListOUT != null) {
				tempdata.addAll(tempListOUT);
				if (accessList.size() > 0) {
					mainSize = accessList.size();
					if (tempListOUT.size() > 0) {
						out = tempListOUT.size();
					}
				}
			}
			if (mainSize != out) {
				for (String accList : accessList) {
					int cout = 0;
					for (PLMSecurityMatrixData matList : tempdata) {
						if (screen.substring(0, screen.indexOf('~'))
								.equalsIgnoreCase(matList.getType())) {
							if (accList.substring(0, accList.indexOf('~'))
									.equalsIgnoreCase(matList.getAccess())) {
								cout = 1;
							}
						}
					}
					if (cout == 0) {
						data = new PLMSecurityMatrixData();
						data.setType(screen.substring(0, screen.indexOf('~')));
						data.setAccess(accList.substring(0, accList
								.indexOf('~')));
						data.setDisplayValue(PLMConstants.NOT_APPLICABLE);
						data.setCheckValue(false);
						data.setOutputValue(PLMConstants.CHECK_BOX);
						data.setHeader(false);
						int temp = Integer.parseInt(accList.substring(accList
								.indexOf('~') + 1, accList.length()));
						data.setAccessID(temp);
						int temp2 = Integer.parseInt(screen.substring(screen
								.indexOf('~') + 1, screen.length()));
						data.setPermissionIdNew(temp2);
						tempdata.add(data);
					}
				}
			}
			Collections.sort(tempdata, new SortList());
			mainList.addAll(tempdata);
		}
	} catch(DataAccessException e){
		PLMUtils.checkException(e.getMessage());
	}
		return mainList;
	}

	/**
	 * @return java.lang.Boolean For updating the user details
	 */
	@Transactional
	public boolean updateUser(PLMLoginData userDetails,
			List<String> selectedPersons, String loggedUser, boolean flag)
			throws PLMCommonException {
		try {
			String ssoID = userDetails.getSsoId();
			LOG.info("flag.....>>>>>" + flag);
			final List<String> selPersons = selectedPersons;
			final String ssoInd = ssoID;
			final String logUser = loggedUser;
			final int updateCount = selPersons.size();
			
	
			if (!flag) {
				if (selectedPersons.size() == 0) {
					LOG.info("Update active indicator");
					getJdbcTemplate().update(PLMQueryConstants.DELETE_AVAILABLE_GROUPS, new Object[] { ssoID });
	
					getSimpleJdbcTemplate().update(PLMQueryConstants.UPDATE_USER_DETAILS,
							PLMConstants.NOO, userDetails.getPhone(),
							userDetails.getFax(), loggedUser, ssoID);
				} else {
					getJdbcTemplate().update(PLMQueryConstants.DELETE_AVAILABLE_GROUPS, new Object[] { ssoID });
					getJdbcTemplate().batchUpdate(
							PLMQueryConstants.INSERT_PLMR_USER_GROUP,
							new BatchPreparedStatementSetter() {
								public void setValues(PreparedStatement ps, int data)
										throws SQLException {
	
									ps.setString(PLMConstants.N_1, selPersons
											.get(data));
									ps.setString(PLMConstants.N_2, logUser);
									ps.setString(PLMConstants.N_3, logUser);
									ps.setString(PLMConstants.N_4, ssoInd);
								}
	
								public int getBatchSize() {
									return updateCount;
								}
							});
	
					getSimpleJdbcTemplate().update(PLMQueryConstants.UPDATE_USER_DETAILS,
							PLMConstants.YES, userDetails.getPhone(),
							userDetails.getFax(), loggedUser, ssoID);
	
				}
			} else {
				if (selectedPersons.size() == 0) {
					LOG.info("Update active indicator");
					getJdbcTemplate().update(PLMQueryConstants.DELETE_AVAILABLE_GROUPS, new Object[] { ssoID });
	
					getSimpleJdbcTemplate().update(PLMQueryConstants.UPDATE_USER_DETAILS,
							PLMConstants.NOO, userDetails.getPhone(),
							userDetails.getFax(), loggedUser, ssoID);
				} else {
	
					getSimpleJdbcTemplate().update(PLMQueryConstants.UPDATE_USER_DETAILS,
							PLMConstants.YES, userDetails.getPhone(),
							userDetails.getFax(), loggedUser, ssoID);
	
				}
			}
		} catch (DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return true;
	}

	/**
	 * This method is used to insert the Department, Address details and then
	 * update the User Info details accordingly
	 * 
	 * @param userDetails
	 * @param loggedUser
	 * @param ssoID
	 * @throws PLMCommonException
	 */
	@Transactional
	private void extractUpdateUser(PLMLoginData userDetails, String loggedUser,
			String ssoID) throws PLMCommonException {
		getSimpleJdbcTemplate().update( PLMQueryConstants.UPDATE_USER_ACTIVEIND,
				userDetails.getFirstName(), userDetails.getLastName(),
				userDetails.getEmail(), userDetails.getStatus(), 
				loggedUser, ssoID);
	}

	/**
	 * @return java.lang.Boolean For updating the user details
	 */
	@Transactional
	public boolean userAdd(PLMLoginData userDetails, String loggedUser)
			throws PLMCommonException {

		try {
			int usercount = 0;
			String ssoID = userDetails.getSsoId();
			String updateRequestStatus = PLMQueryConstants.UPDATE_REQUEST_STATUS;
			List<String> listOfSSO = getSimpleJdbcTemplate().query(PLMQueryConstants.LIST_SSOID,
					new QuerySsoList(), ssoID);
			String status = userDetails.getStatus();
			String emailReqd = userDetails.getEmailNotification();
	//		String deptname = userDetails.getDepartment();
			List<String> grpInd = userDetails.getGroupInd();
			String frstName = userDetails.getFirstName();
			String lstName = userDetails.getLastName();
			String emailAddr = userDetails.getEmail();
	
			StringBuffer check = new StringBuffer("");
			for (String checkString : grpInd) {
				check.append(check).append(checkString).append(",");
			}
	
			check.append(
					check.toString()
							.substring(0, check.toString().lastIndexOf(',')))
					.append(PLMQueryConstants.AND_UI_SSOID);
	
			if (listOfSSO.contains(ssoID)) {
				
					getSimpleJdbcTemplate().update(PLMQueryConstants.UPDATE_USER_ADD, frstName, lstName, emailAddr, status,
							loggedUser, emailReqd, userDetails.getFax(),
							userDetails.getPhone(), ssoID);
				
				String userGroupList = PLMQueryConstants.GROUP_USER_LIST;
				// List<String> list_SSO = new ArrayList<String>();
				List<String> listSso = getSimpleJdbcTemplate().query(
						userGroupList + check, new QuerySsoList(), ssoID);
				// LOG.info(listSso);
				if (listSso.contains(ssoID)) {
					usercount = 1;
					return false;
				} else {
					String insertIcmGroup = PLMQueryConstants.INSERT_PLMR_USER_GROUP;
					for (String grpId : grpInd) {
						getJdbcTemplate()
								.update(
										insertIcmGroup,
										new Object[] { grpId, loggedUser,
												loggedUser, ssoID });
					}
	
				}
	
			} else {
				// Insert to new record in PLM USER INFO
				insertUserInfo(userDetails, loggedUser, ssoID);
			}
			
			//Added by Shekhar for Inserting into PWi Tables
			
			Map<String, Object> params = new HashMap<String, Object>();
			 
			params.put("GRPID",grpInd);
			
			int grpSelCnt = getNamedJdbcTemplate().queryForInt(PLMQueryConstants.GET_SEL_PLMR_GRPS, params);
			
			if (grpSelCnt > 0) {
				
				addPWIUser(ssoID, frstName, lstName, emailAddr);
				
			} else {
				
				LOG.info("PLMR_SEARCH_USER is NOT Selected... PWI Data Insert Will not be done.........");
			}
			
			//Added by Shekhar for Inserting into PWi Tables
			
			emailRequest(userDetails, usercount, PLMQueryConstants.ACCOUNT_REQUESTS,
					updateRequestStatus, ssoID, userDetails.getGroupInd());
		} catch (DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}

		return true;
	}
	/**
	 * @param userDetails
	 * @param loggedUser
	 * @param usercount
	 * @param accountRequests
	 * @param updateRequestStatus
	 * @param ssoID
	 * @param groupID
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	private void emailRequest(PLMLoginData userDetails, int usercount,
			String accountRequests, String updateRequestStatus, String ssoID,
			List<String> groupID) throws PLMCommonException {
		List<String> listGrps = null;
		List<String> listOfRequests = getSimpleJdbcTemplate().query(
				accountRequests, new QryReqMapper(), ssoID);
		 Map<String, Object> params = new HashMap<String, Object>();
			
		if (listOfRequests.contains(ssoID)) {
			int count = getJdbcTemplate().update(updateRequestStatus,
					new Object[] { ssoID });

			LOG.info("after update" + count);
		}
		List<String> groupIdList =new ArrayList<String>();
		for (String checkString : groupID) {
			groupIdList.add(checkString);
		}
		if (userDetails.getEmailNotification().equals(PLMConstants.YES) && usercount != 1) {
			params.put("GRPID", groupIdList);
			listGrps = getNamedJdbcTemplate().query(PLMQueryConstants.GROUP_NAMES_EMAIL,params,
					new QueryOfGroups());
			if (listGrps.size() > 0) {
				List<String> listAdmEmails = getSimpleJdbcTemplate().query( 
						PLMQueryConstants.ADMIN_EMAIL, new QueryOfGroupName());
				sendUserAddEmailNew(userDetails, listAdmEmails, listGrps);
			}
		}
	}

	/**
	 * This method is used to Insert new User Info record when SSO ID is not
	 * available
	 * 
	 * @param userDetails
	 * @param loggedUser
	 * @param ssoID
	 * @param deptname
	 */
	private void insertUserInfo(PLMLoginData userDetails, String loggedUser,
			String ssoID) throws PLMCommonException {
			
			getJdbcTemplate().update(
					PLMQueryConstants.INSERT_USER_INFO,
					new Object[] { ssoID, userDetails.getFirstName(),
							userDetails.getLastName(), userDetails.getEmail(),
							userDetails.getPhone(), userDetails.getFax(),
							userDetails.getEmailNotification(),
							userDetails.getStatus(),loggedUser,
							loggedUser});
			if (userDetails.getGroupInd() != null) {
				for (String grpId : userDetails.getGroupInd()) {
					getJdbcTemplate()
							.update(
									PLMQueryConstants.INSERT_GROUP,
									new Object[] { grpId, loggedUser,
											loggedUser, ssoID });
				}
			}

	}

	/**
	 * @return java.lang.Boolean For deleting a group
	 */
	@Transactional
	public boolean deleteGroup(String groupID) throws PLMCommonException {
		LOG.info("GroupID in DAO----------->" + groupID);
		boolean retValue = false;
		try {
			int userGroupCnt = getSimpleJdbcTemplate().queryForInt(
					PLMQueryConstants.GROUP_COUNT, groupID);
			if (userGroupCnt < 1) {
	
				getJdbcTemplate().update(PLMQueryConstants.DELETE_SECUTITY_MATRIX,
						new Object[] { groupID });
				getJdbcTemplate().update(PLMQueryConstants.DELETE_GROUP, new Object[] { groupID });
				getJdbcTemplate().update(PLMQueryConstants.DELETE_USER_REQUEST_GROUP,
						new Object[] { groupID });
				getJdbcTemplate().update(PLMQueryConstants.DELETE_USER_USERGROUP, new Object[] { groupID });
				retValue = true;
			} else {
				retValue = false;
			}
		} catch (DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return retValue;
	}

	/**
	 * @return java.lang.Boolean For updating the group details
	 */
	@Transactional
	public boolean updateGroup(String groupName, String groupDesc,
			ArrayList<PLMSecurityMatrixData> securityData, String grpFlag,
			String userSSo) throws PLMCommonException {

		LOG.info("Size of the listin dao " + securityData.size());
		// SecurityMatrixProc proc = new SecurityMatrixProc(getDataSource());
		try {
		Map sResult = proc.executeSecurityMatrixProc(groupName, groupDesc,
				securityData, userSSo, grpFlag);
		LOG.info("result" + sResult.get(PLMConstants.PROCEDURE_OUTPUT));
		} catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return false;

	}

	/**
	 * @return java.util.List Rowmapper For the SsoidList.
	 */
	private static final class QuerySsoList implements ParameterizedRowMapper<String>{
//	private static ParameterizedRowMapper<String> querySsoList = new ParameterizedRowMapper<String>() {
		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			String list = rs.getString(PLMConstants.USER_SS0);

			return list;
		}
//	};
}

	
	/*private static ParameterizedRowMapper<String> queryOfRequests = new ParameterizedRowMapper<String>() {
		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			String list = rs.getString(PLMConstants.USER_SS0);

			return list;
		}
	};*/
	
	/**
	 * @return String ParameterizedRowMapper For the QryReqMapper.
	 */
	private static final class QryReqMapper implements ParameterizedRowMapper<String> {

		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			String list = rs.getString(PLMConstants.USER_SS0);

			return list;
		}
	}
	
	/**
	 * @return java.util.List Rowmapper For the groupList.
	 */
//	private static ParameterizedRowMapper<String> queryOfGroups = new ParameterizedRowMapper<String>() {
	private static final class QueryOfGroups implements ParameterizedRowMapper<String> {
		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			String list = rs.getString(PLMConstants.GRP_NM);
			return list;
		}
	}

	/**
	 * @return java.util.List Rowmapper For the icmSeqList.
	 */
	private static final class QueryOfGroupName implements ParameterizedRowMapper<String> {
//	private static ParameterizedRowMapper<String> queryOfGroupName = new ParameterizedRowMapper<String>() {
		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			String list = rs.getString(PLMConstants.USER_EMAIL_ADD);
			return list;
		}
	}

	/**
	 * @return java.util.List Rowmapper For the grpAdd.
	 */
	private static final class QueryGrpAdd implements ParameterizedRowMapper<String> {
//	private static ParameterizedRowMapper<String> queryGrpAdd = new ParameterizedRowMapper<String>() {
		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			String list = rs.getString(PLMConstants.GRP_NM);

			return list.toUpperCase(Locale.US);
		}
	}

	/**
	 * @return java.lang.Boolean For adding a new group
	 */
	@Transactional
	public boolean groupAdd(String groupName, String groupDesc,
			ArrayList<PLMSecurityMatrixData> securityData, String grpFlag,
			String userSSo) throws PLMCommonException {
		boolean retValue = false;
		try {
			String groupNames = PLMQueryConstants.GROUP_NAMES;
			// List<String> listOfGrpNames = new ArrayList<String>();
		
				List<String> listOfGrpNames = getSimpleJdbcTemplate().query(groupNames,
						new QueryGrpAdd());
				if (listOfGrpNames.contains(groupName.toUpperCase(Locale.US).trim())) {
					retValue =  false;
		
				} else {
		
					LOG.info("Size of the listin dao " + securityData.size());
					// SecurityMatrixProc proc = new
					// SecurityMatrixProc(getDataSource());
		
					Map sResult = proc.executeSecurityMatrixProc(groupName, groupDesc,
							securityData, userSSo, grpFlag);
					LOG.info("result" + sResult.get(PLMConstants.PROCEDURE_OUTPUT));
					retValue = true;
				} 
		} catch (DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return retValue;
	}
	
	
	/**
	 * Used For sending email.
	 * 
	 * @param userEmail
	 * @param adminEmail
	 * @param groupName
	 * @throws PLMCommonException
	 */
	public void sendUserAddEmailNew(PLMLoginData userDetails,
			List<String> adminEmail, List<String> groupName)
			throws PLMCommonException {
		String userEmail = PLMConstants.EMPTY_STRING;
		String userName = PLMConstants.EMPTY_STRING;
		if (userDetails.getEmail() != null) {
			userEmail = userDetails.getEmail();
		}
		if (userDetails.getFirstName() != null
				&& userDetails.getLastName() != null) {
			userName = userDetails.getLastName() + " "
					+ userDetails.getFirstName();
		}

		LOG.info("************** S T A R T ******************");
		ArrayList<String> toMail = new ArrayList<String>();
		ArrayList<String> ccMail = new ArrayList<String>();

		StringBuffer subject = null;
		StringBuffer body = null;
		subject = new StringBuffer();
		toMail.add(userEmail);
		boolean pwiFlag=false;
		LOG.info("cc mails:+++++++++" + adminEmail.size());
		for (String email : adminEmail) {
			LOG.info("cc mails:+++++++++" + email);
			ccMail.add(email);
		}
		LOG.info("Outside mails size :+++++++++" + ccMail.size());
		subject.append("PLM Reporting application access is given to " + userName); 
		body = new StringBuffer();

		body.append("<" + "HTML" + ">");
		body.append("<body>");
		body.append("<font color='black'>");
		body
				.append("<table width=\"100%\" border=\"0\" cellpadding=\"4\" cellspacing=\"0\">");
		body.append("<tr>");
		body.append("<br>");
		body.append("Dear " + userName + ",");
		body.append("<br>");
		body.append("<br>");
		body.append("Thank you for using the External Reporting - EEDW tool, your access for following group(s) has been completed."); 
		body.append("<br>");
		body.append("<br>");
		for (int i = 0; i < groupName.size(); i++) {
			body.append(" " + (i + 1) + ". " + groupName.get(i));
			if(groupName.get(i).equals("PLMR Search Users")){
				pwiFlag=true;
			}
			body.append("<br>");
		}
		if(pwiFlag){
			body.append(groupName.size()+1);
			body.append(". "+"PWI_USER");
		}
		body.append("<br>");		
		body.append("Please bookmark the login page for future reference  ");
		body.append("<font color='blue'>");
		body.append("<a href=" + rbundle.getString(PLMConstants.PLMR_APP_URL) + ">")
				.append(rbundle.getString(PLMConstants.PLMR_APP_URL)).append("</a>");
		body.append("</font>");
		
		body.append("<br>");
		body.append("<br>");
		body.append("You have been also granted access to PWI Tool (Power Warehouse Intelligence) tool with \"PWI-Users\" Role.");
		body.append("<br>");
		body.append("<br>");
		body.append("Please bookmark the PWI URL for future reference  ");
		body.append("<font color='blue'>");
		body.append("<a href=" + rbundle.getString(PLMConstants.PWI_APP_URL) + ">")
				.append(rbundle.getString(PLMConstants.PWI_APP_URL)).append("</a>");
		body.append("</font>");
		
		body.append("<br>");		
		body.append("<br>");
		body.append("The user manual for PWI is located @ ");
		body.append("<font color='blue'>");
		body.append("<a href=" + rbundle.getString(PLMConstants.PWI_LIB_URL) + ">")
				.append(rbundle.getString(PLMConstants.PWI_LIB_URL)).append("</a>");
		body.append("</font>");
		
		body.append("<br>");
		body.append("<br>");
		body.append("If you have any issues contact ");
		body.append("<font color='blue'>");
		body.append("<a href=" + rbundle.getString(PLMConstants.helpDeskURL) + ">")
				.append(rbundle.getString(PLMConstants.helpDeskURL)).append("</a>");
		body.append("</font>");
		body.append("<br>");
		body.append("<br>");
		body.append("When talking to support team or submitting selfhelp incident, please use the keyword ");
		body.append("\"" +PLMConstants.plmrptg +" \"");
		body.append(" and include details of error encountered.");
		body.append("<br>");
		body.append("<br>");
		body.append("We suggest you browse Training materials located within Library ");
		body.append("<font color='blue'>");
		body.append("<a href=" + rbundle.getString(PLMConstants.LibURL) + ">")
				.append(rbundle.getString(PLMConstants.LibURL)).append("</a>");
		body.append("</font>");
		body.append("<br>");
		body.append("<br>");
		body.append("These include detailed screen and field layout for query panels and user interfaces for:");
		body.append("<br>");
		body.append("<br>");
		body.append("-- EEDW PLM External Reporting -- ");
		body.append("<br>");
		body.append("1. Reporting Overview");
		body.append("<br>");
		body.append("2. Searching Tasks");
		body.append("<br>");
		body.append("3. Searching drawing workflow queue");
		body.append("<br>");
		body.append("4. Search ECRs");
		body.append("<br>");
		body.append("5. Search ECOs");
		body.append("<br>");
		body.append("6. PLM Issue Search");
		body.append("<br>");
		body.append("<br>");
		body.append("-- Metrics --");
		body.append("<br>");
		body.append("7. Task Volume");
		body.append("<br>");
		body.append("8. ECO Volume");
		body.append("<br>");
		body.append("9. Percent Part Reuse");
		body.append("<br>");
		body.append("<br>");
		body.append("-- Where Used --");
		body.append("<br>");
		body.append("10. Logical Indicator");
		body.append("<br>");
		body.append("11. Top Level Implosion � Level of Uniqueness");
		body.append("<br>");
		body.append("12. E+MBOM (Enovia + COPICS)");
		body.append("<br>");
		body.append("13. Legacy COPICS (ABIX)");
		body.append("<br>");
		body.append("<br>");
		body.append("-- Power Warehouse Intelligence --");
		body.append("<br>");
		body.append("Power Warehouse Intelligence is an Adhoc reporting tool which allows users to run the reports, power users to create the ")
		.append("report template based on the SQL queries using query generator tool (XLSM). The report templates can be selected to provide ")
		.append("filter conditions and execute a query report template to retrieve data into multiple output options such as CSV, XLS, XLSX, DOC ")
		.append("& PDF format in tabular data format.");
		body.append("<br>");
		body.append("<br>");
		body.append("This is an auto-generated email. Please do not reply.");
		body.append("</tr>");
		body.append("</table>");
		body.append("</font>");
		body.append("</body>");
		body.append("</html>");
		LOG.info("************** D O N E ****************");
		mailBean.sendMail(toMail, ccMail, subject.toString(), body.toString(),
				mailSend, "test");

	}

	/**
	 * Used For sending email.
	 * 
	 * @param userEmail
	 * @param adminEmail
	 * @param groupName
	 * @throws PLMCommonException
	 */
	public void sendUserAddEmail(PLMLoginData userDetails,
			List<String> adminEmail, List<String> groupName)
			throws PLMCommonException {
		String userEmail = PLMConstants.EMPTY_STRING;
		String userName = PLMConstants.EMPTY_STRING;
		if (userDetails.getEmail() != null) {
			userEmail = userDetails.getEmail();
		}
		if (userDetails.getFirstName() != null
				&& userDetails.getLastName() != null) {
			userName = userDetails.getLastName() + " "
					+ userDetails.getFirstName();
		}

		LOG.info("************** S T A R T ******************");
		ArrayList<String> toMail = new ArrayList<String>();
		ArrayList<String> ccMail = new ArrayList<String>();

		StringBuffer subject = null;
		StringBuffer body = null;
		subject = new StringBuffer();
		toMail.add(userEmail);
		LOG.info("cc mails:+++++++++" + adminEmail.size());
		for (String email : adminEmail) {
			LOG.info("cc mails:+++++++++" + email);
			ccMail.add(email);
		}
		LOG.info("Outside mails size :+++++++++" + ccMail.size());
		subject.append("PLM Reporting application access is given to " + userName);
		body = new StringBuffer();

		body.append("<" + "HTML" + ">");
		body.append("<body>");
		body
				.append("<table width=\"100%\" border=\"0\" cellpadding=\"4\" cellspacing=\"0\">");
		body.append("<tr>");
		body.append("<br>");
		body.append("Dear " + userName + ",");
		body.append("<br>");
		body.append("<br>");
		body
				.append("You have been given access to the ");
		body.append(
				"<a href=" + rbundle.getString(PLMConstants.PLMR_APP_URL) + ">")
				.append("\"" + "PLM Reporting application" + "\"").append("</a>");
		body.append(" for the following Group(s) ");
		body.append("<br>");
		body.append("<br>");
		for (int i = 0; i < groupName.size(); i++) {
			body.append(" " + (i + 1) + ". " + groupName.get(i));
			body.append("<br>");
		}
		body.append("<br>");
		body.append(PLMConstants.REFERENCE_CONSTANT);
		body.append("<br>");
		body.append("This is an auto-generated email. Please do not reply.");
		body.append("</tr>");

		body.append("</table>");
		body.append("</body>");
		body.append("</html>");
		LOG.info("************** D O N E ****************");
		mailBean.sendMail(toMail, ccMail, subject.toString(), body.toString(),
				mailSend, "test");

	}

	/**
	 * Method is used to Search the User Information based on Input Keys
	 * 
	 * @param searchSSo
	 * @param searcFname
	 * @param searchLname
	 * @param groupId
	 * @param status
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMLoginData> searchUser(String searchSso, String searchFname,
			String searchLname, String groupId, String status)
			throws PLMCommonException {
		List<PLMLoginData> userData = null;
		try {
			if ((status == null)
					|| (status.equalsIgnoreCase(PLMConstants.PLEASE_SELECT))
					|| (status.equalsIgnoreCase(PLMConstants.YES))) {
				String quer = PLMQueryConstants.SEARCH_Q;
	
				StringBuilder sb = new StringBuilder();
				sb.append(quer);
				if (searchSso != null && !searchSso.equals("")) {
					sb.append(PLMQueryConstants.SSOID_LIKE + searchSso.trim()
							+ PLMQueryConstants.PERCENTILE);
				}
				if (searchFname != null && !searchFname.equals("")) {
					sb.append(PLMQueryConstants.FIRSTNAME_LIKE
							+ searchFname.toUpperCase(Locale.US).trim()
							+ PLMQueryConstants.PERCENTILE);
				}
				if (searchLname != null && !searchLname.equals("")) {
					sb.append(PLMQueryConstants.LASTNAME_LIKE
							+ searchLname.toUpperCase(Locale.US).trim()
							+ PLMQueryConstants.PERCENTILE);
				}
	
				if (groupId != null && !groupId.equals("")
						&& !groupId.equalsIgnoreCase(PLMConstants.PLEASE_SELECT)) {
					sb.append(PLMQueryConstants.GROUP_LIKE + groupId + ")");
				}
				sb.append(PLMQueryConstants.ACTIVEIND_LIKE + "'" + PLMConstants.YES
						+ "'");
				String query1 = PLMQueryConstants.SEARCH_QNE;
				LOG.info("sb-------" + sb);
				sb.append(query1);
				LOG.info("Search Queryyyyyyyyy >>>>>>>>>>>>" + sb.toString());
	
				userData = getSimpleJdbcTemplate().query(sb.toString(),
						new QueryOfGroupUsers());
			} else {
				String quers = PLMQueryConstants.SEARCH_QS;
				StringBuilder sbs = new StringBuilder();
				sbs.append(quers);
				if (searchSso != null && !searchSso.equals("")) {
					sbs.append(PLMQueryConstants.UI_SSOID_LIKE + searchSso.trim()
							+ PLMQueryConstants.PERCENTILE);
				}
				if (searchFname != null && !searchFname.equals("")) {
					sbs.append(PLMQueryConstants.UI_FRSTNM_LIKE
							+ searchFname.toUpperCase(Locale.US).trim()
							+ PLMQueryConstants.PERCENTILE);
				}
				if (searchLname != null && !searchLname.equals("")) {
					sbs.append(PLMQueryConstants.UI_LSTNM_LIKE
							+ searchLname.toUpperCase(Locale.US).trim()
							+ PLMQueryConstants.PERCENTILE);
				}
	
				LOG.info("Search Queryyyyyyyyy >>>>>>>>>>>>" + sbs.toString());
	
				userData = getSimpleJdbcTemplate().query(sbs.toString(),
						new QueryOfGroupUsers());
			}
		} catch (DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return userData;
	}

	/**
	 * @return java.util.List Rowmapper For getting the list of userList.
	 */
	private static final class QueryOfGroupUsers implements ParameterizedRowMapper<PLMLoginData> {
//	private static ParameterizedRowMapper<PLMLoginData> queryOfGroupUsers = new ParameterizedRowMapper<PLMLoginData>() {
		public PLMLoginData mapRow(ResultSet rs, int rowNum) throws SQLException {
			PLMLoginData user = new PLMLoginData();
			user.setSsoId(rs.getString(PLMConstants.SSO_ID));
			if (rs.getString(PLMConstants.USER_NAME).trim().equals(",")) {

				user.setUserName(PLMConstants.EMPTY_STRING);
			} else {

				user.setUserName(rs.getString(PLMConstants.USER_NAME));
			}
			user.setEmail(rs.getString(PLMConstants.USER_EMAIL_ADD));
			user.setGroupName(rs.getString(PLMConstants.GROUPS));

			return user;
		}
	}
	// End Of AdminUsecase
	
	/**
	 * This method is used to send email to the Requestor after Auto Access
	 * 
	 * @param requestData
	 * @throws PLMCommonException
	 */
	public void sendAutoAccessEmailNew(PLMRequestData requestData,
			List<String> mailList) throws PLMCommonException {
		ArrayList<String> toMail = new ArrayList<String>();
		ArrayList<String> ccMail = new ArrayList<String>();
		StringBuffer subject = null;
		StringBuffer body = null;
		subject = new StringBuffer();
		body = new StringBuffer();
		String title = null;
		title = requestData.getLocalUserlname() + ", "
				+ requestData.getLocalUserfname() + "{"
				+ requestData.getSsoId() + "}";
		
		subject.append(" Power Warehouse Intelligence Application Access Granted to - " + " \"" + title + " \"");
		body.append(PLMConstants.HTML_TAG);
		body.append("<body>");
		body.append("<font color='black'>");
		body
				.append("<table width=\"100%\" border=\"0\" cellpadding=\"4\" cellspacing=\"0\">");
		body.append("<tr>");
		body.append("Thank you for using the External Reporting - EEDW tool, your access for " + " \""
				+ PLMUtils.getMessage(PLMConstants.AUTO_ACCESS_GROUP) + " \""
				+ " role has been completed.");
		body.append("<br>");
		body.append("<br>");
		body.append("Please bookmark the login page for future reference  ");
		body.append("<font color='blue'>");
		body.append("<a href=" + rbundle.getString(PLMConstants.PWI_APP_URL) + ">")
				.append(rbundle.getString(PLMConstants.PWI_APP_URL)).append("</a>");
		body.append("</font>");
		
		body.append("<br>");
		body.append("<br>");
		/*body.append("You have been also granted access to PWI Tool (P&W Intelligence) tool with \"PWI-Users\" Role.");
		body.append("<br>");
		body.append("<br>");
		body.append("Please bookmark the PWI URL for future reference  ");
		body.append("<font color='blue'>");
		body.append("<a href=" + rbundle.getString(PLMConstants.PWI_APP_URL) + ">")
				.append(rbundle.getString(PLMConstants.PWI_APP_URL)).append("</a>");
		body.append("</font>");
		
		body.append("<br>");		
		body.append("<br>");
		body.append("The user manual for PWI is located @ ");
		body.append("<font color='blue'>");
		body.append("<a href=" + rbundle.getString(PLMConstants.PWI_LIB_URL) + ">")
				.append(rbundle.getString(PLMConstants.PWI_LIB_URL)).append("</a>");
		body.append("</font>");
		
		body.append("<br>");
		body.append("<br>");*/
		body.append("If you have any issues contact ");
		body.append("<font color='blue'>");
		body.append("<a href=" + rbundle.getString(PLMConstants.helpDeskURL) + ">")
				.append(rbundle.getString(PLMConstants.helpDeskURL)).append("</a>");
		body.append("</font>");
		body.append("<br>");
		body.append("<br>");
		body.append("When talking to support team or submitting selfhelp incident, please use the keyword ");
		body.append("\"" +PLMConstants.pwi +" \"");
		body.append(" and include details of error encountered.");
		body.append("<br>");
		body.append("<br>");
		body.append("We suggest you browse Training materials located within Library ");
		body.append("<font color='blue'>");
		body.append("<a href=" + rbundle.getString(PLMConstants.PWI_LIB_URL) + ">")
				.append(rbundle.getString(PLMConstants.PWI_LIB_URL_LEVEL)).append("</a>");
		body.append("</font>");
		body.append("<br>");
		body.append("<br>");
		body.append("These include detailed screen and field layout for query panels and user interfaces for Power Warehouse Intelligence.");
		body.append("<br>");
		body.append("<br>");
		/*
		 * commented by subrajit
		 * body.append("Note: All Reports in PLM Reporting will be migrated to the P&W Intelligence reporting Tool in different phases before End of 2015.");
		body.append("The Current Reports (excluding the enhancements to the current reports / new reports) in PLMR will continue to function until all the reports are migrated to PWI.");
		body.append("<br>");
		body.append("<br>");*/
		/*body.append("-- P&W Intelligence Canned Reports -- ");
		body.append("<br>");
		body.append("1. Reporting Overview");
		body.append("<br>");
		body.append("2. Searching Tasks");
		body.append("<br>");
		body.append("3. Searching drawing workflow queue");
		body.append("<br>");
		body.append("4. Search ECRs");
		body.append("<br>");
		body.append("5. Search ECOs");
		body.append("<br>");
		body.append("6. PLM Issue Search");
		body.append("<br>");
		body.append("<br>");
		body.append("-- Metrics --");
		body.append("<br>");
		body.append("7. Task Volume");
		body.append("<br>");
		body.append("8. ECO Volume");
		body.append("<br>");
		body.append("9. Percent Part Reuse");
		body.append("<br>");
		body.append("<br>");
		body.append("-- Where Used --");
		body.append("<br>");
		body.append("10. Logical Indicator");
		body.append("<br>");
		body.append("11. Top Level Implosion � Level of Uniqueness");
		body.append("<br>");
		body.append("12. E+MBOM (Enovia + COPICS)");
		body.append("<br>");
		body.append("13. Legacy COPICS (ABIX)");
		body.append("<br>");
		body.append("<br>");
		body.append("-- P&W Intelligence --");
		body.append("<br>");*/
		body.append("Power Warehouse Intelligence is an Adhoc reporting tool which allows users to run the reports, power users to create the ")
		.append("report template based on the SQL queries using query generator tool (XLSM). The report templates can be selected to provide ")
		.append("filter conditions and execute a query report template to retrieve data into multiple output options such as CSV, XLS, XLSX, DOC ")
		.append("& PDF format in tabular data format.");
		body.append("<br>");
		body.append("<br>");
		body.append("This is an auto-generated email. Please do not reply.");
		body.append("</tr>");
		body.append("</table>");
		body.append("</font>");
		body.append("</body>");
		body.append("</html>");
		if (requestData.getEmailId() != null) {
			toMail.add(requestData.getEmailId());
			ccMail.addAll(mailList);			
			mailBean.sendMail(toMail, ccMail, subject.toString(), body
					.toString(), mailSend, "test");
		}
	}
	public PLMEccnTagDaoIfc getPlmEccnTagDao() {
		return plmEccnTagDao;
	}

	public void setPlmEccnTagDao(PLMEccnTagDaoIfc plmEccnTagDao) {
		this.plmEccnTagDao = plmEccnTagDao;
	}
	
	/**
	 * @return java.util.List Rowmapper For the SsoidList.
	 */
	private static final class QuerySsoListPwi implements ParameterizedRowMapper<PLMPwiUserData>{
		public PLMPwiUserData mapRow(ResultSet rs, int rowNum) throws SQLException {
			
			PLMPwiUserData pwiUserObj = new PLMPwiUserData();
			
			pwiUserObj.setUserSSO(rs.getString("PWI_UNAME"));
			pwiUserObj.setUserId(rs.getInt("PWI_UID"));
			
			return pwiUserObj;
		}
	}
	/**
	 * @return java.util.List Rowmapper For the SsoidList.
	 */
	private static final class FetchRolesForSso implements ParameterizedRowMapper<String>{
		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			String list = rs.getString("PWI_UID");
			return list;
		}
}
}
