/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMNewUnitFMIMB.java
 * @Creation date: 12-Aug-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.ResourceBundle;

import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMDocGenFmiData;
import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMDocGenServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMNewUnitFMIMB {
	/**
	 * Holds the Logger object
	 */
	private static final Logger LOG = Logger.getLogger(PLMNewUnitFMIMB.class);
	/**
	 * Holds the plmDocGenService
	 */
	private PLMDocGenServiceIfc plmDocGenService = null;
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor=null;
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
    /**
	 * Holds the contractnumber
	 */
	private String contractnumber="";
	/**
	 * Holds the selProduct
	 */
	 private String selProduct;
	 /**
	 * Holds the selProductList
	 */
    private List<SelectItem> selProductList;
    
    /**
	 * Holds the authorization
	 */
	private String authorization="";
	 /**
	 * Holds the chargeSNcode
	 */
	private String chargeSNcode="";
	
	 /**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the fmiNewUnitdetails
	 */
	private PLMDocGenFmiData fmiNewUnitdetails = new PLMDocGenFmiData();
	/**
	 * Holds the searchResultList
	 */
	private List<PLMDocGenFmiData> searchResultList = new ArrayList<PLMDocGenFmiData>();
	/**
	 * Holds the fmiNewUnitDataList
	 */
	private List<PLMDocGenFmiData> fmiNewUnitDataList = new ArrayList<PLMDocGenFmiData>();
	/**
	 * Holds user information
	 */
	private PLMPwiUserData userDetails = null;
	
	private PLMLoginData userDataObj = (PLMLoginData) PLMUtils
	.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA);
	
	
	
	/**
	 * This method is used for Load Fmi New Unit Search Page
	 * 
	 * @return String
	 */
	public String loadFmiNewUnitPage(){ 
		LOG.info("Entering loadFmiNewUnitPage Method");
		String fwdFlag = "";
		alertMessage="";
		selProductList = new ArrayList<SelectItem>();
		selProduct = "";
		contractnumber = "";
		authorization="";
		chargeSNcode="";
		selProductList.add(new SelectItem("GT","Gas"));
		selProductList.add(new SelectItem("ST","Steam"));
		selProductList.add(new SelectItem("GTG','STG","Gen"));
		selProductList.add(new SelectItem("BOP","BOP"));
		searchResultList =new ArrayList<PLMDocGenFmiData>();
		fmiNewUnitDataList =new ArrayList<PLMDocGenFmiData>();
		fwdFlag = "fmiNewUnitSearch";
		LOG.info("Exiting loadFmiNewUnitPage Method");
		return fwdFlag;	
	}
	
	/**
	 * Background Process Thread
	 */
	private class DocGenerationThread implements Runnable {
		public DocGenerationThread(){}
		public void run() {
			generateFmiNewUnitDoc();
		}
	}
	/**
	 * This method is used for validating contract number
	 * 
	 *@return String
	 */
	public String validationForFMINewUnit(){
		alertMessage = "";
		if (!PLMUtils.checkForSpecialChars(contractnumber)) {
			alertMessage = PLMConstants.FMI_NEW_UNIT_SPL_CHAR;
		} 
		else if (PLMUtils.isEmpty(contractnumber)) {
			alertMessage = PLMConstants.FMI_NEW_UNIT_SEARCH_EMPTY;
		} 
		
		return alertMessage;
	}
	/**
	 * This method is used for retrieving FMI New Unit Details
	 * 
	 *@return String
	 * @throws PWiException 
	 */
	public String getFmiNewUnitDetails() throws PWiException{
		LOG.info("Entering getFmiNewUnitDetails Method");
		String fwdFlag = "fmiNewUnitSearch";
		try {
			alertMessage = validationForFMINewUnit();
			 if(PLMUtils.isEmpty(alertMessage)){
				 fmiNewUnitdetails.setContractnumber(contractnumber.trim());
				 fmiNewUnitdetails.setSelProduct(selProduct);
				 searchResultList = plmDocGenService.fetchCntrInfo(contractnumber);
			      if(!PLMUtils.isEmptyList(searchResultList)){
			    	  alertMessage = PLMConstants.FMI_NEW_UNIT_MAIL_ALERT_MSG;
			    	  userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
			  		  taskExecutor.execute(new DocGenerationThread());
        	      } else{
			       alertMessage = PLMConstants.FMI_NEW_UNIT_SEARCH_VALID;
			      }
			}
		  
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getFmiNewUnitDetails: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"fmiNewUnitSearch","DGT - FMI New Unit Search");
			}
				return fwdFlag;
	}

	/**
	 * This method is used for Generating the Fmi New Unit Doc through Email
	 * 
	 * @return String
	 */
	@SuppressWarnings("unchecked")
	public void generateFmiNewUnitDoc(){
		LOG.info("Entering generateFmiNewUnitDoc Method");
		Hashtable htBookmarks = new Hashtable(100);
		fmiNewUnitdetails.setTemplatepath(resourceBundle.getString("OFFLINE_RPT_DIR"));
		fmiNewUnitdetails.setTemplatename(resourceBundle.getString("FMI_TEMPLATE_NEW_UNIT_NAME"));
		fmiNewUnitdetails.setFullfilepath(fmiNewUnitdetails.getTemplatepath()+ fmiNewUnitdetails.getTemplatename());
		File storedtemplate = new File(fmiNewUnitdetails.getFullfilepath());
		String tempStrTemplate = null;
		
		String toEmailId = userDetails.getUserEmailId();
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		
		toAddressee = "Dear " + toAddressee + ", \n\n";
			if (storedtemplate.exists()) {
				try {
				LOG.info("Fmi Template New Unit Exists");
				LOG.info("Contract Number " + fmiNewUnitdetails.getContractnumber());
				readFmiNewUnitTemplate();
				tempStrTemplate = fmiNewUnitdetails.getStrTemplate();
				LOG.info("Successful Reading of Template ");
				fmiNewUnitDataList = plmDocGenService.getFmiNewUnitDetails(fmiNewUnitdetails);
				htBookmarks = setBookMarks(htBookmarks);
				LOG.info("succesful Setting of Bookmarks ");
				Enumeration enumBookmarks = htBookmarks.keys();
				while (enumBookmarks.hasMoreElements()) {
					String strBoKey = (String) enumBookmarks.nextElement();
					String strBoValue = (String) htBookmarks.get(strBoKey);
					if (tempStrTemplate.indexOf(strBoKey) != -1) {
						tempStrTemplate = tempStrTemplate.substring(0,
								tempStrTemplate.indexOf(strBoKey))
								+ strBoValue
								+ tempStrTemplate.substring(tempStrTemplate
										.indexOf(strBoKey)
										+ strBoKey.length(), tempStrTemplate
										.length());
					}
				}
				LOG.info("Successfully Appended Bookmarks");
				writeFmiTemplate(tempStrTemplate);
				LOG.info("Successful Writing of Output Template");
				LOG.info("Successful Download of Output Template");
				} catch (PLMCommonException exception) {
					LOG.log(Level.ERROR, "Exception@generateFmiDoc: ", exception);
					PLMUtils.checkExceptionAndMail(exception.getMessage(),PLMConstants.BVS_MAIL_FROM,
							toEmailId,PLMConstants.FMI_MAIL_SUBJECT + fmiNewUnitdetails.getContractnumber(),
							toAddressee,PLMConstants.COST_CHG_MAIL_SIGNATURE);
				}			
			} else {
				LOG.info("Template Not Found in Directory");
				alertMessage = PLMConstants.FMI_TEMPLATE_NOT_FOUND;
			}
		LOG.info("Exiting generateFmiDoc Method");
	}

	
	/**
	 * This method is used for Reading the Fmi Unit  Template
	 * 
	 * @return void
	 */
	public void readFmiNewUnitTemplate() throws PLMCommonException {
		LOG.info("Entering readFmiNewUnitTemplate Method");
		FileInputStream inputStreamTemplate = null;
		try {
			inputStreamTemplate = new FileInputStream(fmiNewUnitdetails.getFullfilepath());
			byte[] byteVal = new byte[inputStreamTemplate.available()];
			int retVal = inputStreamTemplate.read(byteVal);
			LOG.info("Read the file " + retVal);
			String strTemplate = new String(byteVal);
			fmiNewUnitdetails.setStrTemplate(strTemplate);
		} catch (FileNotFoundException exception) {
			LOG.log(Level.ERROR, "Exception@readFmiNewUnitTemplate: ", exception);
			PLMUtils.checkException(exception.getMessage());
		}  catch (IOException exception) {
			LOG.log(Level.ERROR, "Exception@readFmiNewUnitTemplate: ", exception);
			PLMUtils.checkException(exception.getMessage());
		} finally {
			try {
				if (inputStreamTemplate != null) {
					inputStreamTemplate.close();
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "Exception@readFmiNewUnitTemplate: ", exception);
				PLMUtils.checkException(exception.getMessage());
			}
		}
		LOG.info("Exiting readFmiNewUnitTemplate Method");
	}
	
	/**
	 * This method is used for Writing the Fmi Template
	 * 
	 * @return void
	 */
	public void writeFmiTemplate(String tempStrTemplate) throws PLMCommonException {
		LOG.info("Entering readFmiTemplate Method");
		BufferedWriter oBufferedWriter = null;
		File oFile = new File(fmiNewUnitdetails.getFullfilepath());
		final SimpleDateFormat DATE_FORMAT_PROC1 = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC1.format(uniqDate);
		File tmpFile = new File(oFile.getParent(), fmiNewUnitdetails.getContractnumber()+"_"+uniqTime+".rtf");
		File tmpFileZip = new File(oFile.getParent(), fmiNewUnitdetails.getContractnumber()+"_"+uniqTime+".zip");
		List<String> tempFilesList = new ArrayList<String>();
		tempFilesList.add(tmpFile.getAbsolutePath());
		String from = PLMConstants.COST_CHG_MAIL_FROM;
		
		String to = userDetails.getUserEmailId();
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.FMI_NEW_UNIT_MAIL_SUBJECT + fmiNewUnitdetails.getContractnumber();
		StringBuffer mailBody = new StringBuffer().append(toAddressee);
		StringBuffer mailNoDataBody = new StringBuffer();
		LOG.info("contractNum>>>>>>>"+fmiNewUnitdetails.getContractnumber());
		if (fmiNewUnitdetails.getContractnumber()!=null) {
		toAddressee = "Dear " + toAddressee + ", \n\n";
		mailBody.append(PLMConstants.FMI_NEW_UNIT_MAIL_CONTENT)
		.append(fmiNewUnitdetails.getContractnumber())
		.append(".")
		.append(PLMConstants.COST_CHG_MAIL_SIGNATURE)
		.append(PLMConstants.COST_CHG_MAIL_FOOTER);
		
		mailNoDataBody.append(toAddressee)
		.append(PLMConstants.FMI_NO_CONTENT_BODY)
		.append(fmiNewUnitdetails.getContractnumber())
		.append(".")
		.append(PLMConstants.COST_CHG_MAIL_SIGNATURE)
		.append(PLMConstants.COST_CHG_MAIL_FOOTER);

		try {
			oBufferedWriter = new BufferedWriter(new FileWriter(tmpFile));
			oBufferedWriter.write(tempStrTemplate);
			oBufferedWriter.newLine();
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "Exception@writeFmiTemplate: ", exception);
				PLMUtils.checkException(exception.getMessage());
			} finally {
				try {
					if (oBufferedWriter != null) {
						oBufferedWriter.close();
					}
				} catch (IOException exception) {
					LOG.log(Level.ERROR, "Exception@writeFmiTemplate: ", exception);
					PLMUtils.checkException(exception.getMessage());
				}
			}
		LOG.info("Getting the Old File Absolute Path" + oFile.getAbsolutePath());
		LOG.info("Getting the Temp File Absolute Path" + tmpFile.getAbsolutePath());

		 try{
		 long sizeInBytes = 0;
		 if(tmpFile!=null){
				sizeInBytes = tmpFile.length();
				}
				if(sizeInBytes > 0){
				LOG.info("File Size for FMI New Unit Doc "+sizeInBytes/1000+"KB");
				PLMUtils.generateZipFile(tempFilesList, tmpFileZip.getAbsolutePath(), false);
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), tmpFileZip.getAbsolutePath());
				LOG.info("Report Attachment Mail sent successfully.");
				}else{
				PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
				LOG.info("No data Mail sent successfully.");
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "Exception@writeFmiTemplate: ", exception);
				PLMUtils.checkException(exception.getMessage());
			} finally{
				PLMUtils.deleteFile(tmpFile);
				PLMUtils.deleteFile(tmpFileZip);
				tempFilesList.clear();

			}
		 
		LOG.info("Exiting readFmiTemplate Method");
	}
	}
	/**
	 * This method is used for Setting the Bookmarks
	 * 
	 * @return Hashtable
	 */
	@SuppressWarnings("unchecked")
	public Hashtable setBookMarks(Hashtable htBookmarks) {
		LOG.info("Entering setBookMarks Method");
		htBookmarks.put("bkmkstart CUSTOMER1}", "bkmkstart CUSTOMER1}"
				+ PLMUtils.checkNullVal(fmiNewUnitDataList.get(0).getCustomer()));
		
		htBookmarks.put("bkmkstart CONTRACT1}", "bkmkstart CONTRACT1}"
				+ fmiNewUnitDataList.get(0).getContractnumber());
		htBookmarks.put("bkmkstart CONTRACT2}", "bkmkstart CONTRACT2}"
				+ fmiNewUnitDataList.get(0).getContractnumber());
		htBookmarks.put("bkmkstart CONTRACT3}", "bkmkstart CONTRACT3}"
				+ fmiNewUnitDataList.get(0).getContractnumber());
	
		htBookmarks.put("bkmkstart CONTRACT_TITLE1}", "bkmkstart CONTRACT_TITLE1}"
				+ PLMUtils.checkNullVal(fmiNewUnitDataList.get(0).getTitle()));
		htBookmarks.put("bkmkstart CONTRACT_TITLE2}", "bkmkstart CONTRACT_TITLE2}"
				+ PLMUtils.checkNullVal(fmiNewUnitDataList.get(0).getTitle()));
		htBookmarks.put("bkmkstart CONTRACT_TITLE3}", "bkmkstart CONTRACT_TITLE3}"
				+ PLMUtils.checkNullVal(fmiNewUnitDataList.get(0).getTitle()));
		
	  if(!PLMUtils.isEmptyList(fmiNewUnitDataList.get(0).getProjectNamesList())){
		htBookmarks.put("bkmkstart PROJECT}", "bkmkstart PROJECT}"
				+ fmiNewUnitDataList.get(0).getProjectNamesList());
	  }
	  
		htBookmarks.put("bkmkstart AUTHRZN}", "bkmkstart AUTHRZN}"
				+ PLMUtils.checkNullVal(authorization));
		htBookmarks.put("bkmkstart CHARGETOSN}", "bkmkstart CHARGETOSN}"
				+ PLMUtils.checkNullVal(chargeSNcode));
		
	  if(!PLMUtils.isEmptyList(fmiNewUnitDataList.get(0).getSerialNoList())){
		htBookmarks.put("bkmkstart SERIAL_NUMBERS1}", "bkmkstart SERIAL_NUMBERS1}"
				+ fmiNewUnitDataList.get(0).getSerialNoList());
	  }

	  if(!PLMUtils.isEmptyList(fmiNewUnitDataList.get(0).getSerialNoList())){
		htBookmarks.put("bkmkstart SERIAL_NUMBERS2}", "bkmkstart SERIAL_NUMBERS2}"
				+ fmiNewUnitDataList.get(0).getSerialNoList());
	  }
		
		String strCurrentDate = DateFormat.getDateInstance().format(new Date());
	
		htBookmarks.put("bkmkstart ISSUED}", "bkmkstart ISSUED}"
				+ strCurrentDate);
		htBookmarks.put("bkmkstart ISSUED2}", "bkmkstart ISSUED2}"
				+ strCurrentDate);
		htBookmarks.put("bkmkstart ISSUED3}", "bkmkstart ISSUED3}"
				+ strCurrentDate);
		
			LOG.info("Exiting setBookMarks Method");
		return htBookmarks;
	}
	public PLMDocGenServiceIfc getPlmDocGenService() {
		return plmDocGenService;
	}

	/**
	 * @param plmDocGenService the plmDocGenService to set
	 */
	public void setPlmDocGenService(PLMDocGenServiceIfc plmDocGenService) {
		this.plmDocGenService = plmDocGenService;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}
	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}
	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}
	/**
	 * @return the contractnumber
	 */
	public String getContractnumber() {
		return contractnumber;
	}
	/**
	 * @param contractnumber the contractnumber to set
	 */
	public void setContractnumber(String contractnumber) {
		this.contractnumber = contractnumber;
	}
	/**
	 * @return the selProduct
	 */
	public String getSelProduct() {
		return selProduct;
	}
	/**
	 * @param selProduct the selProduct to set
	 */
	public void setSelProduct(String selProduct) {
		this.selProduct = selProduct;
	}
	/**
	 * @return the selProductList
	 */
	public List<SelectItem> getSelProductList() {
		return selProductList;
	}
	/**
	 * @param selProductList the selProductList to set
	 */
	public void setSelProductList(List<SelectItem> selProductList) {
		this.selProductList = selProductList;
	}
	/**
	 * @return the authorization
	 */
	public String getAuthorization() {
		return authorization;
	}
	/**
	 * @param authorization the authorization to set
	 */
	public void setAuthorization(String authorization) {
		this.authorization = authorization;
	}
	/**
	 * @return the chargeSNcode
	 */
	public String getChargeSNcode() {
		return chargeSNcode;
	}
	/**
	 * @param chargeSNcode the chargeSNcode to set
	 */
	public void setChargeSNcode(String chargeSNcode) {
		this.chargeSNcode = chargeSNcode;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}
	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the fmiNewUnitdetails
	 */
	public PLMDocGenFmiData getFmiNewUnitdetails() {
		return fmiNewUnitdetails;
	}

	/**
	 * @param fmiNewUnitdetails the fmiNewUnitdetails to set
	 */
	public void setFmiNewUnitdetails(PLMDocGenFmiData fmiNewUnitdetails) {
		this.fmiNewUnitdetails = fmiNewUnitdetails;
	}

	/**
	 * @return the searchResultList
	 */
	public List<PLMDocGenFmiData> getSearchResultList() {
		return searchResultList;
	}

	/**
	 * @param searchResultList the searchResultList to set
	 */
	public void setSearchResultList(List<PLMDocGenFmiData> searchResultList) {
		this.searchResultList = searchResultList;
	}

	/**
	 * @return the fmiNewUnitDataList
	 */
	public List<PLMDocGenFmiData> getFmiNewUnitDataList() {
		return fmiNewUnitDataList;
	}

	/**
	 * @param fmiNewUnitDataList the fmiNewUnitDataList to set
	 */
	public void setFmiNewUnitDataList(List<PLMDocGenFmiData> fmiNewUnitDataList) {
		this.fmiNewUnitDataList = fmiNewUnitDataList;
	}

	  
	
	
	
	
	
	

}
