/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBoilerReportServiceImpl.java
 * @Creation date: 17-Feb-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.service;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.dao.PLMBoilerReportDaoIfc;
import com.geinfra.geaviation.pwi.data.PLMBoilerReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public class PLMBoilerReportServiceImpl implements PLMBoilerReportServiceIfc{
	
	/**
	 * Holds the PLMBoilerReportDaoIfc plmBoilerReportDao
	 */
	private PLMBoilerReportDaoIfc plmBoilerReportDao = null;
	/**
	 * @return the plmBoilerReportDao
	 */
	public PLMBoilerReportDaoIfc getPlmBoilerReportDao() {
		return plmBoilerReportDao;
	}
	/**
	 * @param plmBoilerReportDao the plmBoilerReportDao to set
	 */
	public void setPlmBoilerReportDao(PLMBoilerReportDaoIfc plmBoilerReportDao) {
		this.plmBoilerReportDao = plmBoilerReportDao;
	}

	/**
	 * This method is used to get Project and Task Name
	 * 
	 * @param 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getProjectNameAndTaskList() throws PLMCommonException {
		return  plmBoilerReportDao.getProjectNameAndTaskList();
	}
	/**
	 * This method is used to Generate backlog Report
	 * 
	 * @param selBacklogProjectName
	 * @param allOpenPrjName
	 * @param selBacklogTaskName
	 * @param allOpenTaskName
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerReportData> generateBacklogAppReport(List<String> selBacklogProjectName, boolean allOpenPrjName,List<String> selBacklogTaskName, boolean allOpenTaskName,List<String> selBacklogTaskState
			,List<SelectItem> projectList,List<SelectItem> taskList,String owner)
			throws PLMCommonException {
		return plmBoilerReportDao.generateBacklogAppReport(selBacklogProjectName,allOpenPrjName,selBacklogTaskName,allOpenTaskName,selBacklogTaskState,projectList,taskList,owner);
	}
	/**
	 * This method is used to fetchPCInfo
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerReportData> fetchPCInfo(List<String> cstGrpList,List<SelectItem> projectList,boolean allOpenPrjName) throws PLMCommonException {
		return plmBoilerReportDao.fetchPCInfo(cstGrpList,projectList,allOpenPrjName);
	}
	/**
	 * This method is used to fetchTaskFromTaskState
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerReportData> fetchTaskFromTaskState(List<String> cstGrpList) throws PLMCommonException {
		return plmBoilerReportDao.fetchTaskFromTaskState(cstGrpList);
	}
	
	public List<SelectItem> projectFamilyAutocomplete(String selectedPrjName) throws PLMCommonException {
		return plmBoilerReportDao.projectFamilyAutocomplete(selectedPrjName);
	}
	public List<SelectItem> taskFamilyAutocomplete(String selectedTaskName) throws PLMCommonException {
		return plmBoilerReportDao.taskFamilyAutocomplete(selectedTaskName);
	}
}
