 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileNamePLMCustDocReportData.java
 * @Creation date: 16-March-2015
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;

public class PLMCustDocReportData {
	/**
	 * Holds the enteredProjContract
	 */
	private String enteredProjContract;
	/**
	 * Holds the enteredMLI
	 */
	private String enteredMLI;
	/**
	 * Holds the enteredFuncSystem
	 */
	private String enteredFuncSystem;	
	/**
	 * Holds the enteredDocName
	 */
	private String enteredDocName;
	/**
	* Holds the onlySentDocs
	 */
	private boolean onlySentDocs;
	/**
	 * Holds the sourceOfResult
	 */
	private String sourceOfResult;
	/**
	* Holds the exhaustiveList
	 */
	private boolean exhaustiveList;
	/**
	* Holds the origFromDate
	 */
	private Date origFromDate;
	/**
	* Holds the origToDate
	 */
	private Date origToDate;
	
	/**
	 * Holds the opContract
	 */
	private String opContract;
	/**
	 * Holds the opContractDesc
	 */
	private String opContractDesc;
	/**
	 * Holds the opContract
	 */
	private String opWBSEName;
	/**
	 * Holds the opContract
	 */
	private String opWBSERev;
	/**
	 * Holds the opContract
	 */
	private String opWBSEState;
	/**
	 * Holds the opContract
	 */
	private String opPld;
	/**
	 * Holds the opContract
	 */
	private String opPldRev;
	/**
	 * Holds the opContract
	 */
	private String opPldRelease;
	/**
	 * Holds the opContract
	 */
	private String opGenTitle;
	/**
	 * Holds the opContract
	 */
	private String opDetTitle;
	/**
	 * Holds the opContract
	 */
	private String opDocType;
	/**
	 * Holds the opContract
	 */
	private String opDocument;
	/**
	 * Holds the opContract
	 */
	private String opDocRev;
	/**
	 * Holds the opContract
	 */
	private String opTc5Label;
	/**
	 * Holds the opContract
	 */
	private String opLabelRev;
	/**
	 * Holds the opContract
	 */
	private String opLabelRelease;
	
	/**
	 * Holds the opWbseId
	 */
	private String opWbseId;
	/**
	 * Holds the opPlpId
	 */
	private String opPlpId;
	/**
	 * Holds the opDocumentId
	 */
	private String opDocumentId;
	/**
	 * Holds the opDocumentId
	 */
	private String opGenTitleFlag;
	/**
	 * Holds the opDocumentId
	 */
	private String opDetTitleFlag;
	
	
	private String opWbseOriginator;
	private String opWbseOriginated;
	private String opWbseModified;
	private String opWbseOwner;
	private String opWbseMgr;
	private String opWbseAssignee;
	private String opWbseProjRole;
	private String opWbseDueDate;
	private String opWbseEstFinish;
	private String opWbseEstStart;
	private String opWbseLiqDamage;
	private String opWbseForDist;
	private String opWbsePldReq;
	private String opWbseEid;
	private String opWbseEquipCode;
	private String opWbseFunSys;
	private String opWbseClsfCode;
	private String opWbsePldCode;
	private String opWbseExtdocCode;
	private String opWbseExtRev;
	private String opWbseExtFld1;
	private String opWbseExtFld2;
	private String opWbseExtFld3;
	private String opWbseRelProj;
	private String opWbsePolicy;
	private String opWbseCwbse;
	private String opWbseDesc;
	private String opWbseTitle;
	private String opWbseNotes;
	private String opWbseSynopsis;
	
	private String opTc5Status;
	private String opSuperseded;
	private String opOfficial;
	private String opTc5MainType;
	private String opTc5SecType;
	private String opTc5Metrix;
	private String opTc5Sent;
	private String opTc5Reply;
	private String opTc5Resubmit;
	private String opTc5CustStatus;
	private String opTc5Customer;
	private String opTc5Supplier;
	private String opTc5CustFld1;
	private String opTc5CustFld2;
	private String opTc5CustFld3;
	private String opTc5ForApproval;
	private String opTc5Contractual;
	private String opTc5Asb;
	private String opTc5Pole;
	
	/**
	  * Holds the opPldReleaseExl
	  */
	private Date opPldReleaseExl;
	/**
	  * Holds the opLabelReleaseExl
	  */
	private Date opLabelReleaseExl;
	/**
	  * Holds the opWbseOriginatedExl
	  */
	private Date opWbseOriginatedExl;
	
	/**
	  * Holds the opWbseModifiedExl
	  */
	private Date opWbseModifiedExl;
	
	/**
	  * Holds the opWbseDueDateExl
	  */
	private Date opWbseDueDateExl;
	
	/**
	  * Holds the opWbseEstFinishExl
	  */
	private Date opWbseEstFinishExl;
	
	/**
	  * Holds the opWbseEstStartExl
	  */
	private Date opWbseEstStartExl;
	/**
	  * Holds the opTc5MetrixExl
	  */
	private Date opTc5MetrixExl;
	
	/**
	  * Holds the opTc5SentExl
	  */
	private Date opTc5SentExl;
	
	/**
	  * Holds the opTc5ReplyExl
	  */
	private Date opTc5ReplyExl;
	/**
	  * Holds the opTc5ResubmitExl
	  */
	private Date  opTc5ResubmitExl;
	
	/**
	 * @return the enteredProjContract
	 */
	public String getEnteredProjContract() {
		return enteredProjContract;
	}
	/**
	 * @param enteredProjContract the enteredProjContract to set
	 */
	public void setEnteredProjContract(String enteredProjContract) {
		this.enteredProjContract = enteredProjContract;
	}
	/**
	 * @return the enteredMLI
	 */
	public String getEnteredMLI() {
		return enteredMLI;
	}
	/**
	 * @param enteredMLI the enteredMLI to set
	 */
	public void setEnteredMLI(String enteredMLI) {
		this.enteredMLI = enteredMLI;
	}
	/**
	 * @return the enteredFuncSystem
	 */
	public String getEnteredFuncSystem() {
		return enteredFuncSystem;
	}
	/**
	 * @param enteredFuncSystem the enteredFuncSystem to set
	 */
	public void setEnteredFuncSystem(String enteredFuncSystem) {
		this.enteredFuncSystem = enteredFuncSystem;
	}
	/**
	 * @return the enteredDocName
	 */
	public String getEnteredDocName() {
		return enteredDocName;
	}
	/**
	 * @param enteredDocName the enteredDocName to set
	 */
	public void setEnteredDocName(String enteredDocName) {
		this.enteredDocName = enteredDocName;
	}
	/**
	 * @return the onlySentDocs
	 */
	public boolean isOnlySentDocs() {
		return onlySentDocs;
	}
	/**
	 * @param onlySentDocs the onlySentDocs to set
	 */
	public void setOnlySentDocs(boolean onlySentDocs) {
		this.onlySentDocs = onlySentDocs;
	}
	/**
	 * @return the sourceOfResult
	 */
	public String getSourceOfResult() {
		return sourceOfResult;
	}
	/**
	 * @param sourceOfResult the sourceOfResult to set
	 */
	public void setSourceOfResult(String sourceOfResult) {
		this.sourceOfResult = sourceOfResult;
	}
	/**
	 * @return the exhaustiveList
	 */
	public boolean isExhaustiveList() {
		return exhaustiveList;
	}
	/**
	 * @param exhaustiveList the exhaustiveList to set
	 */
	public void setExhaustiveList(boolean exhaustiveList) {
		this.exhaustiveList = exhaustiveList;
	}
	/**
	 * @return the origFromDate
	 */
	public Date getOrigFromDate() {
		Date temp = null;
		temp = origFromDate;
		return temp;
	}
	/**
	 * @param origFromDate the origFromDate to set
	 */
	public void setOrigFromDate(Date origFromDate) {
		Date temp = null;
		temp = origFromDate;
		this.origFromDate = temp;
	}
	
	/**
	 * @return the origToDate
	 */
	public Date getOrigToDate() {
		Date temp = null;
		temp = origToDate;
		return temp;
	}
	/**
	 * @param origFromDate the origFromDate to set
	 */
	public void setOrigToDate(Date origToDate) {
		Date temp = null;
		temp = origToDate;
		this.origToDate = temp;
	}
	
	/**
	 * @return the opContract
	 */
	public String getOpContract() {
		return opContract;
	}
	/**
	 * @param opContract the opContract to set
	 */
	public void setOpContract(String opContract) {
		this.opContract = opContract;
	}
	/**
	 * @return the opContractDesc
	 */
	public String getOpContractDesc() {
		return opContractDesc;
	}
	/**
	 * @param opContractDesc the opContractDesc to set
	 */
	public void setOpContractDesc(String opContractDesc) {
		this.opContractDesc = opContractDesc;
	}
	/**
	 * @return the opWBSEName
	 */
	public String getOpWBSEName() {
		return opWBSEName;
	}
	/**
	 * @param opWBSEName the opWBSEName to set
	 */
	public void setOpWBSEName(String opWBSEName) {
		this.opWBSEName = opWBSEName;
	}
	/**
	 * @return the opWBSERev
	 */
	public String getOpWBSERev() {
		return opWBSERev;
	}
	/**
	 * @param opWBSERev the opWBSERev to set
	 */
	public void setOpWBSERev(String opWBSERev) {
		this.opWBSERev = opWBSERev;
	}
	/**
	 * @return the opWBSEState
	 */
	public String getOpWBSEState() {
		return opWBSEState;
	}
	/**
	 * @param opWBSEState the opWBSEState to set
	 */
	public void setOpWBSEState(String opWBSEState) {
		this.opWBSEState = opWBSEState;
	}
	/**
	 * @return the opPld
	 */
	public String getOpPld() {
		return opPld;
	}
	/**
	 * @param opPld the opPld to set
	 */
	public void setOpPld(String opPld) {
		this.opPld = opPld;
	}
	/**
	 * @return the opPldRev
	 */
	public String getOpPldRev() {
		return opPldRev;
	}
	/**
	 * @param opPldRev the opPldRev to set
	 */
	public void setOpPldRev(String opPldRev) {
		this.opPldRev = opPldRev;
	}
	/**
	 * @return the opPldRelease
	 */
	public String getOpPldRelease() {
		return opPldRelease;
	}
	/**
	 * @param opPldRelease the opPldRelease to set
	 */
	public void setOpPldRelease(String opPldRelease) {
		this.opPldRelease = opPldRelease;
	}
	/**
	 * @return the opGenTitle
	 */
	public String getOpGenTitle() {
		return opGenTitle;
	}
	/**
	 * @param opGenTitle the opGenTitle to set
	 */
	public void setOpGenTitle(String opGenTitle) {
		this.opGenTitle = opGenTitle;
	}
	/**
	 * @return the opDetTitle
	 */
	public String getOpDetTitle() {
		return opDetTitle;
	}
	/**
	 * @param opDetTitle the opDetTitle to set
	 */
	public void setOpDetTitle(String opDetTitle) {
		this.opDetTitle = opDetTitle;
	}
	/**
	 * @return the opDocType
	 */
	public String getOpDocType() {
		return opDocType;
	}
	/**
	 * @param opDocType the opDocType to set
	 */
	public void setOpDocType(String opDocType) {
		this.opDocType = opDocType;
	}
	/**
	 * @return the opDocument
	 */
	public String getOpDocument() {
		return opDocument;
	}
	/**
	 * @param opDocument the opDocument to set
	 */
	public void setOpDocument(String opDocument) {
		this.opDocument = opDocument;
	}
	/**
	 * @return the opDocRev
	 */
	public String getOpDocRev() {
		return opDocRev;
	}
	/**
	 * @param opDocRev the opDocRev to set
	 */
	public void setOpDocRev(String opDocRev) {
		this.opDocRev = opDocRev;
	}
	/**
	 * @return the opTc5Label
	 */
	public String getOpTc5Label() {
		return opTc5Label;
	}
	/**
	 * @param opTc5Label the opTc5Label to set
	 */
	public void setOpTc5Label(String opTc5Label) {
		this.opTc5Label = opTc5Label;
	}
	/**
	 * @return the opLabelRev
	 */
	public String getOpLabelRev() {
		return opLabelRev;
	}
	/**
	 * @param opLabelRev the opLabelRev to set
	 */
	public void setOpLabelRev(String opLabelRev) {
		this.opLabelRev = opLabelRev;
	}
	/**
	 * @return the opLabelRelease
	 */
	public String getOpLabelRelease() {
		return opLabelRelease;
	}
	/**
	 * @param opLabelRelease the opLabelRelease to set
	 */
	public void setOpLabelRelease(String opLabelRelease) {
		this.opLabelRelease = opLabelRelease;
	}
	/**
	 * @return the opWbseId
	 */
	public String getOpWbseId() {
		return opWbseId;
	}
	/**
	 * @param opWbseId the opWbseId to set
	 */
	public void setOpWbseId(String opWbseId) {
		this.opWbseId = opWbseId;
	}
	/**
	 * @return the opPlpId
	 */
	public String getOpPlpId() {
		return opPlpId;
	}
	/**
	 * @param opPlpId the opPlpId to set
	 */
	public void setOpPlpId(String opPlpId) {
		this.opPlpId = opPlpId;
	}
	/**
	 * @return the opDocumentId
	 */
	public String getOpDocumentId() {
		return opDocumentId;
	}
	/**
	 * @param opDocumentId the opDocumentId to set
	 */
	public void setOpDocumentId(String opDocumentId) {
		this.opDocumentId = opDocumentId;
	}
	/**
	 * @return the opGenTitleFlag
	 */
	public String getOpGenTitleFlag() {
		return opGenTitleFlag;
	}
	/**
	 * @param opGenTitleFlag the opGenTitleFlag to set
	 */
	public void setOpGenTitleFlag(String opGenTitleFlag) {
		this.opGenTitleFlag = opGenTitleFlag;
	}
	/**
	 * @return the opDetTitleFlag
	 */
	public String getOpDetTitleFlag() {
		return opDetTitleFlag;
	}
	/**
	 * @param opDetTitleFlag the opDetTitleFlag to set
	 */
	public void setOpDetTitleFlag(String opDetTitleFlag) {
		this.opDetTitleFlag = opDetTitleFlag;
	}
	/**
	 * @return the opWbseOriginator
	 */
	public String getOpWbseOriginator() {
		return opWbseOriginator;
	}
	/**
	 * @param opWbseOriginator the opWbseOriginator to set
	 */
	public void setOpWbseOriginator(String opWbseOriginator) {
		this.opWbseOriginator = opWbseOriginator;
	}
	/**
	 * @return the opWbseOriginated
	 */
	public String getOpWbseOriginated() {
		return opWbseOriginated;
	}
	/**
	 * @param opWbseOriginated the opWbseOriginated to set
	 */
	public void setOpWbseOriginated(String opWbseOriginated) {
		this.opWbseOriginated = opWbseOriginated;
	}
	/**
	 * @return the opWbseModified
	 */
	public String getOpWbseModified() {
		return opWbseModified;
	}
	/**
	 * @param opWbseModified the opWbseModified to set
	 */
	public void setOpWbseModified(String opWbseModified) {
		this.opWbseModified = opWbseModified;
	}
	/**
	 * @return the opWbseOwner
	 */
	public String getOpWbseOwner() {
		return opWbseOwner;
	}
	/**
	 * @param opWbseOwner the opWbseOwner to set
	 */
	public void setOpWbseOwner(String opWbseOwner) {
		this.opWbseOwner = opWbseOwner;
	}
	/**
	 * @return the opWbseMgr
	 */
	public String getOpWbseMgr() {
		return opWbseMgr;
	}
	/**
	 * @param opWbseMgr the opWbseMgr to set
	 */
	public void setOpWbseMgr(String opWbseMgr) {
		this.opWbseMgr = opWbseMgr;
	}
	/**
	 * @return the opWbseAssignee
	 */
	public String getOpWbseAssignee() {
		return opWbseAssignee;
	}
	/**
	 * @param opWbseAssignee the opWbseAssignee to set
	 */
	public void setOpWbseAssignee(String opWbseAssignee) {
		this.opWbseAssignee = opWbseAssignee;
	}
	/**
	 * @return the opWbseProjRole
	 */
	public String getOpWbseProjRole() {
		return opWbseProjRole;
	}
	/**
	 * @param opWbseProjRole the opWbseProjRole to set
	 */
	public void setOpWbseProjRole(String opWbseProjRole) {
		this.opWbseProjRole = opWbseProjRole;
	}
	/**
	 * @return the opWbseDueDate
	 */
	public String getOpWbseDueDate() {
		return opWbseDueDate;
	}
	/**
	 * @param opWbseDueDate the opWbseDueDate to set
	 */
	public void setOpWbseDueDate(String opWbseDueDate) {
		this.opWbseDueDate = opWbseDueDate;
	}
	/**
	 * @return the opWbseEstFinish
	 */
	public String getOpWbseEstFinish() {
		return opWbseEstFinish;
	}
	/**
	 * @param opWbseEstFinish the opWbseEstFinish to set
	 */
	public void setOpWbseEstFinish(String opWbseEstFinish) {
		this.opWbseEstFinish = opWbseEstFinish;
	}
	/**
	 * @return the opWbseEstStart
	 */
	public String getOpWbseEstStart() {
		return opWbseEstStart;
	}
	/**
	 * @param opWbseEstStart the opWbseEstStart to set
	 */
	public void setOpWbseEstStart(String opWbseEstStart) {
		this.opWbseEstStart = opWbseEstStart;
	}
	/**
	 * @return the opWbseLiqDamage
	 */
	public String getOpWbseLiqDamage() {
		return opWbseLiqDamage;
	}
	/**
	 * @param opWbseLiqDamage the opWbseLiqDamage to set
	 */
	public void setOpWbseLiqDamage(String opWbseLiqDamage) {
		this.opWbseLiqDamage = opWbseLiqDamage;
	}
	/**
	 * @return the opWbseForDist
	 */
	public String getOpWbseForDist() {
		return opWbseForDist;
	}
	/**
	 * @param opWbseForDist the opWbseForDist to set
	 */
	public void setOpWbseForDist(String opWbseForDist) {
		this.opWbseForDist = opWbseForDist;
	}
	/**
	 * @return the opWbsePldReq
	 */
	public String getOpWbsePldReq() {
		return opWbsePldReq;
	}
	/**
	 * @param opWbsePldReq the opWbsePldReq to set
	 */
	public void setOpWbsePldReq(String opWbsePldReq) {
		this.opWbsePldReq = opWbsePldReq;
	}
	/**
	 * @return the opWbseEid
	 */
	public String getOpWbseEid() {
		return opWbseEid;
	}
	/**
	 * @param opWbseEid the opWbseEid to set
	 */
	public void setOpWbseEid(String opWbseEid) {
		this.opWbseEid = opWbseEid;
	}
	/**
	 * @return the opWbseEquipCode
	 */
	public String getOpWbseEquipCode() {
		return opWbseEquipCode;
	}
	/**
	 * @param opWbseEquipCode the opWbseEquipCode to set
	 */
	public void setOpWbseEquipCode(String opWbseEquipCode) {
		this.opWbseEquipCode = opWbseEquipCode;
	}
	/**
	 * @return the opWbseFunSys
	 */
	public String getOpWbseFunSys() {
		return opWbseFunSys;
	}
	/**
	 * @param opWbseFunSys the opWbseFunSys to set
	 */
	public void setOpWbseFunSys(String opWbseFunSys) {
		this.opWbseFunSys = opWbseFunSys;
	}
	/**
	 * @return the opWbseClsfCode
	 */
	public String getOpWbseClsfCode() {
		return opWbseClsfCode;
	}
	/**
	 * @param opWbseClsfCode the opWbseClsfCode to set
	 */
	public void setOpWbseClsfCode(String opWbseClsfCode) {
		this.opWbseClsfCode = opWbseClsfCode;
	}
	/**
	 * @return the opWbsePldCode
	 */
	public String getOpWbsePldCode() {
		return opWbsePldCode;
	}
	/**
	 * @param opWbsePldCode the opWbsePldCode to set
	 */
	public void setOpWbsePldCode(String opWbsePldCode) {
		this.opWbsePldCode = opWbsePldCode;
	}
	/**
	 * @return the opWbseExtdocCode
	 */
	public String getOpWbseExtdocCode() {
		return opWbseExtdocCode;
	}
	/**
	 * @param opWbseExtdocCode the opWbseExtdocCode to set
	 */
	public void setOpWbseExtdocCode(String opWbseExtdocCode) {
		this.opWbseExtdocCode = opWbseExtdocCode;
	}
	/**
	 * @return the opWbseExtRev
	 */
	public String getOpWbseExtRev() {
		return opWbseExtRev;
	}
	/**
	 * @param opWbseExtRev the opWbseExtRev to set
	 */
	public void setOpWbseExtRev(String opWbseExtRev) {
		this.opWbseExtRev = opWbseExtRev;
	}
	/**
	 * @return the opWbseExtFld1
	 */
	public String getOpWbseExtFld1() {
		return opWbseExtFld1;
	}
	/**
	 * @param opWbseExtFld1 the opWbseExtFld1 to set
	 */
	public void setOpWbseExtFld1(String opWbseExtFld1) {
		this.opWbseExtFld1 = opWbseExtFld1;
	}
	/**
	 * @return the opWbseExtFld2
	 */
	public String getOpWbseExtFld2() {
		return opWbseExtFld2;
	}
	/**
	 * @param opWbseExtFld2 the opWbseExtFld2 to set
	 */
	public void setOpWbseExtFld2(String opWbseExtFld2) {
		this.opWbseExtFld2 = opWbseExtFld2;
	}
	/**
	 * @return the opWbseExtFld3
	 */
	public String getOpWbseExtFld3() {
		return opWbseExtFld3;
	}
	/**
	 * @param opWbseExtFld3 the opWbseExtFld3 to set
	 */
	public void setOpWbseExtFld3(String opWbseExtFld3) {
		this.opWbseExtFld3 = opWbseExtFld3;
	}
	/**
	 * @return the opWbseRelProj
	 */
	public String getOpWbseRelProj() {
		return opWbseRelProj;
	}
	/**
	 * @param opWbseRelProj the opWbseRelProj to set
	 */
	public void setOpWbseRelProj(String opWbseRelProj) {
		this.opWbseRelProj = opWbseRelProj;
	}
	/**
	 * @return the opWbsePolicy
	 */
	public String getOpWbsePolicy() {
		return opWbsePolicy;
	}
	/**
	 * @param opWbsePolicy the opWbsePolicy to set
	 */
	public void setOpWbsePolicy(String opWbsePolicy) {
		this.opWbsePolicy = opWbsePolicy;
	}
	/**
	 * @return the opWbseCwbse
	 */
	public String getOpWbseCwbse() {
		return opWbseCwbse;
	}
	/**
	 * @param opWbseCwbse the opWbseCwbse to set
	 */
	public void setOpWbseCwbse(String opWbseCwbse) {
		this.opWbseCwbse = opWbseCwbse;
	}
	/**
	 * @return the opWbseDesc
	 */
	public String getOpWbseDesc() {
		return opWbseDesc;
	}
	/**
	 * @param opWbseDesc the opWbseDesc to set
	 */
	public void setOpWbseDesc(String opWbseDesc) {
		this.opWbseDesc = opWbseDesc;
	}
	/**
	 * @return the opWbseTitle
	 */
	public String getOpWbseTitle() {
		return opWbseTitle;
	}
	/**
	 * @param opWbseTitle the opWbseTitle to set
	 */
	public void setOpWbseTitle(String opWbseTitle) {
		this.opWbseTitle = opWbseTitle;
	}
	/**
	 * @return the opWbseNotes
	 */
	public String getOpWbseNotes() {
		return opWbseNotes;
	}
	/**
	 * @param opWbseNotes the opWbseNotes to set
	 */
	public void setOpWbseNotes(String opWbseNotes) {
		this.opWbseNotes = opWbseNotes;
	}
	/**
	 * @return the opWbseSynopsis
	 */
	public String getOpWbseSynopsis() {
		return opWbseSynopsis;
	}
	/**
	 * @param opWbseSynopsis the opWbseSynopsis to set
	 */
	public void setOpWbseSynopsis(String opWbseSynopsis) {
		this.opWbseSynopsis = opWbseSynopsis;
	}
	/**
	 * @return the opTc5Status
	 */
	public String getOpTc5Status() {
		return opTc5Status;
	}
	/**
	 * @param opTc5Status the opTc5Status to set
	 */
	public void setOpTc5Status(String opTc5Status) {
		this.opTc5Status = opTc5Status;
	}
	/**
	 * @return the opSuperseded
	 */
	public String getOpSuperseded() {
		return opSuperseded;
	}
	/**
	 * @param opSuperseded the opSuperseded to set
	 */
	public void setOpSuperseded(String opSuperseded) {
		this.opSuperseded = opSuperseded;
	}
	/**
	 * @return the opOfficial
	 */
	public String getOpOfficial() {
		return opOfficial;
	}
	/**
	 * @param opOfficial the opOfficial to set
	 */
	public void setOpOfficial(String opOfficial) {
		this.opOfficial = opOfficial;
	}
	/**
	 * @return the opTc5MainType
	 */
	public String getOpTc5MainType() {
		return opTc5MainType;
	}
	/**
	 * @param opTc5MainType the opTc5MainType to set
	 */
	public void setOpTc5MainType(String opTc5MainType) {
		this.opTc5MainType = opTc5MainType;
	}
	/**
	 * @return the opTc5SecType
	 */
	public String getOpTc5SecType() {
		return opTc5SecType;
	}
	/**
	 * @param opTc5SecType the opTc5SecType to set
	 */
	public void setOpTc5SecType(String opTc5SecType) {
		this.opTc5SecType = opTc5SecType;
	}
	/**
	 * @return the opTc5Metrix
	 */
	public String getOpTc5Metrix() {
		return opTc5Metrix;
	}
	/**
	 * @param opTc5Metrix the opTc5Metrix to set
	 */
	public void setOpTc5Metrix(String opTc5Metrix) {
		this.opTc5Metrix = opTc5Metrix;
	}
	/**
	 * @return the opTc5Sent
	 */
	public String getOpTc5Sent() {
		return opTc5Sent;
	}
	/**
	 * @param opTc5Sent the opTc5Sent to set
	 */
	public void setOpTc5Sent(String opTc5Sent) {
		this.opTc5Sent = opTc5Sent;
	}
	/**
	 * @return the opTc5Reply
	 */
	public String getOpTc5Reply() {
		return opTc5Reply;
	}
	/**
	 * @param opTc5Reply the opTc5Reply to set
	 */
	public void setOpTc5Reply(String opTc5Reply) {
		this.opTc5Reply = opTc5Reply;
	}
	/**
	 * @return the opTc5Resubmit
	 */
	public String getOpTc5Resubmit() {
		return opTc5Resubmit;
	}
	/**
	 * @param opTc5Resubmit the opTc5Resubmit to set
	 */
	public void setOpTc5Resubmit(String opTc5Resubmit) {
		this.opTc5Resubmit = opTc5Resubmit;
	}
	/**
	 * @return the opTc5CustStatus
	 */
	public String getOpTc5CustStatus() {
		return opTc5CustStatus;
	}
	/**
	 * @param opTc5CustStatus the opTc5CustStatus to set
	 */
	public void setOpTc5CustStatus(String opTc5CustStatus) {
		this.opTc5CustStatus = opTc5CustStatus;
	}
	/**
	 * @return the opTc5Customer
	 */
	public String getOpTc5Customer() {
		return opTc5Customer;
	}
	/**
	 * @param opTc5Customer the opTc5Customer to set
	 */
	public void setOpTc5Customer(String opTc5Customer) {
		this.opTc5Customer = opTc5Customer;
	}
	/**
	 * @return the opTc5Supplier
	 */
	public String getOpTc5Supplier() {
		return opTc5Supplier;
	}
	/**
	 * @param opTc5Supplier the opTc5Supplier to set
	 */
	public void setOpTc5Supplier(String opTc5Supplier) {
		this.opTc5Supplier = opTc5Supplier;
	}
	/**
	 * @return the opTc5CustFld1
	 */
	public String getOpTc5CustFld1() {
		return opTc5CustFld1;
	}
	/**
	 * @param opTc5CustFld1 the opTc5CustFld1 to set
	 */
	public void setOpTc5CustFld1(String opTc5CustFld1) {
		this.opTc5CustFld1 = opTc5CustFld1;
	}
	/**
	 * @return the opTc5CustFld2
	 */
	public String getOpTc5CustFld2() {
		return opTc5CustFld2;
	}
	/**
	 * @param opTc5CustFld2 the opTc5CustFld2 to set
	 */
	public void setOpTc5CustFld2(String opTc5CustFld2) {
		this.opTc5CustFld2 = opTc5CustFld2;
	}
	/**
	 * @return the opTc5CustFld3
	 */
	public String getOpTc5CustFld3() {
		return opTc5CustFld3;
	}
	/**
	 * @param opTc5CustFld3 the opTc5CustFld3 to set
	 */
	public void setOpTc5CustFld3(String opTc5CustFld3) {
		this.opTc5CustFld3 = opTc5CustFld3;
	}
	/**
	 * @return the opTc5ForApproval
	 */
	public String getOpTc5ForApproval() {
		return opTc5ForApproval;
	}
	/**
	 * @param opTc5ForApproval the opTc5ForApproval to set
	 */
	public void setOpTc5ForApproval(String opTc5ForApproval) {
		this.opTc5ForApproval = opTc5ForApproval;
	}
	/**
	 * @return the opTc5Contractual
	 */
	public String getOpTc5Contractual() {
		return opTc5Contractual;
	}
	/**
	 * @param opTc5Contractual the opTc5Contractual to set
	 */
	public void setOpTc5Contractual(String opTc5Contractual) {
		this.opTc5Contractual = opTc5Contractual;
	}
	/**
	 * @return the opTc5Asb
	 */
	public String getOpTc5Asb() {
		return opTc5Asb;
	}
	/**
	 * @param opTc5Asb the opTc5Asb to set
	 */
	public void setOpTc5Asb(String opTc5Asb) {
		this.opTc5Asb = opTc5Asb;
	}
	/**
	 * @return the opTc5Pole
	 */
	public String getOpTc5Pole() {
		return opTc5Pole;
	}
	/**
	 * @param opTc5Pole the opTc5Pole to set
	 */
	public void setOpTc5Pole(String opTc5Pole) {
		this.opTc5Pole = opTc5Pole;
	}
	/**
	 * @return the opPldReleaseExl
	 */
	public Date getOpPldReleaseExl() {
		Date temp = null;
		temp = opPldReleaseExl;
		return temp;
	}
	/**
	 * @param opPldReleaseExl the opPldReleaseExl to set
	 */
	public void setOpPldReleaseExl(Date opPldReleaseExl) {
		Date temp = null;
		temp = opPldReleaseExl;
		this.opPldReleaseExl = temp;
	}
	/**
	 * @return the opLabelReleaseExl
	 */
	public Date getOpLabelReleaseExl() {
		Date temp = null;
		temp = opLabelReleaseExl;
		return temp;
	}
	/**
	 * @param opLabelReleaseExl the opLabelReleaseExl to set
	 */
	public void setOpLabelReleaseExl(Date opLabelReleaseExl) {
		Date temp = null;
		temp = opLabelReleaseExl;
		this.opLabelReleaseExl = temp;
	}
	/**
	 * @return the opWbseOriginatedExl
	 */
	public Date getOpWbseOriginatedExl() {
		Date temp = null;
		temp = opWbseOriginatedExl;
		return temp;
	}
	/**
	 * @param opWbseOriginatedExl the opWbseOriginatedExl to set
	 */
	public void setOpWbseOriginatedExl(Date opWbseOriginatedExl) {
		Date temp = null;
		temp = opWbseOriginatedExl;
		this.opWbseOriginatedExl = temp;
	}
	/**
	 * @return the opWbseModifiedExl
	 */
	public Date getOpWbseModifiedExl() {
		Date temp = null;
		temp = opWbseModifiedExl;
		return temp;
	}
	/**
	 * @param opWbseModifiedExl the opWbseModifiedExl to set
	 */
	public void setOpWbseModifiedExl(Date opWbseModifiedExl) {
		Date temp = null;
		temp = opWbseModifiedExl;
		this.opWbseModifiedExl = temp;
	}
	/**
	 * @return the opWbseDueDateExl
	 */
	public Date getOpWbseDueDateExl() {
		Date temp = null;
		temp = opWbseDueDateExl;
		return temp;
	}
	/**
	 * @param opWbseDueDateExl the opWbseDueDateExl to set
	 */
	public void setOpWbseDueDateExl(Date opWbseDueDateExl) {
		Date temp = null;
		temp = opWbseDueDateExl;
		this.opWbseDueDateExl = temp;
	}
	/**
	 * @return the opWbseEstFinishExl
	 */
	public Date getOpWbseEstFinishExl() {
		Date temp = null;
		temp = opWbseEstFinishExl;
		return temp;
	}
	/**
	 * @param opWbseEstFinishExl the opWbseEstFinishExl to set
	 */
	public void setOpWbseEstFinishExl(Date opWbseEstFinishExl) {
		Date temp = null;
		temp = opWbseEstFinishExl;
		this.opWbseEstFinishExl = temp;
	}
	/**
	 * @return the opWbseEstStartExl
	 */
	public Date getOpWbseEstStartExl() {
		Date temp = null;
		temp = opWbseEstStartExl;
		return temp;
	}
	/**
	 * @param opWbseEstStartExl the opWbseEstStartExl to set
	 */
	public void setOpWbseEstStartExl(Date opWbseEstStartExl) {
		Date temp = null;
		temp = opWbseEstStartExl;
		this.opWbseEstStartExl = temp;
	}
	/**
	 * @return the opTc5MetrixExl
	 */
	public Date getOpTc5MetrixExl() {
		Date temp = null;
		temp = opTc5MetrixExl;
		return temp;
	}
	/**
	 * @param opTc5MetrixExl the opTc5MetrixExl to set
	 */
	public void setOpTc5MetrixExl(Date opTc5MetrixExl) {
		Date temp = null;
		temp = opTc5MetrixExl;
		this.opTc5MetrixExl = temp;
	}
	/**
	 * @return the opTc5SentExl
	 */
	public Date getOpTc5SentExl() {
		Date temp = null;
		temp = opTc5SentExl;
		return temp;
	}
	/**
	 * @param opTc5SentExl the opTc5SentExl to set
	 */
	public void setOpTc5SentExl(Date opTc5SentExl) {
		Date temp = null;
		temp = opTc5SentExl;
		this.opTc5SentExl = temp;
	}
	/**
	 * @return the opTc5ReplyExl
	 */
	public Date getOpTc5ReplyExl() {
		Date temp = null;
		temp = opTc5ReplyExl;
		return temp;
	}
	/**
	 * @param opTc5ReplyExl the opTc5ReplyExl to set
	 */
	public void setOpTc5ReplyExl(Date opTc5ReplyExl) {
		Date temp = null;
		temp = opTc5ReplyExl;
		this.opTc5ReplyExl = temp;
	}
	/**
	 * @return the opTc5ResubmitExl
	 */
	public Date getOpTc5ResubmitExl() {
		Date temp = null;
		temp = opTc5ResubmitExl;
		return temp;
	}
	/**
	 * @param opTc5ResubmitExl the opTc5ResubmitExl to set
	 */
	public void setOpTc5ResubmitExl(Date opTc5ResubmitExl) {
		Date temp = null;
		temp = opTc5ResubmitExl;
		this.opTc5ResubmitExl = temp;
	}
	
	
}
