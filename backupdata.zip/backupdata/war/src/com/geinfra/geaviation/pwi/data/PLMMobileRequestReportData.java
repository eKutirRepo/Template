/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMMobileRequestReportData.java
 * @Creation date: 16-June-2014
 * @version 1.0
 */

package com.geinfra.geaviation.pwi.data;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="PLMMobileRequestReportData")
public class PLMMobileRequestReportData{
	
	private String reportName = null;
	
	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getReportDesc() {
		return reportDesc;
	}

	public void setReportDesc(String reportDesc) {
		this.reportDesc = reportDesc;
	}

	public String getReportAvailable() {
		return reportAvailable;
	}

	public void setReportAvailable(String reportAvailable) {
		this.reportAvailable = reportAvailable;
	}

	private String reportDesc = null;
	
	private String reportAvailable = null;
	
	private boolean isEmailSent = false;
	
	public boolean isEmailSent() {
		return isEmailSent;
	}

	public void setEmailSent(boolean isEmailSentLcl) {
		this.isEmailSent = isEmailSentLcl;
	}

	public PLMMobileRequestReportData(){
		
	}
	
}