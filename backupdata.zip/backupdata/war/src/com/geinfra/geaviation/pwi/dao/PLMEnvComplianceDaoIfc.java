/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEnvComplianceDaoIfc.java
 * @Creation date: 9-Jul-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.data.PLMEnvComplianceData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMEnvComplianceDaoIfc {
	/**
	 * This method is used to get Classification List
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<String> getClassificationList() throws PLMCommonException;
	/**
	 * This method is used to fetch Contract Info
	 * 
	 * @param cntrtNm
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEnvComplianceData> fetchCntrInfo(String cntrtNm) throws PLMCommonException;
	
	/**
	 * This method is used to get getWBSEReport
	 * 
	 * @param contractName,classification,casNum
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEnvComplianceData> getWBSEReport(String contractName,String classification,String casNum) throws PLMCommonException;
	
	/**
	 * This method is used to get getBOMReport
	 * 
	 * @param contractName,classification,casNum
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEnvComplianceData> getBOMReport(String contractName,String classification,String casNum) throws PLMCommonException;
	
	/**
	 * This method is used to fetchWBSEContract
	 * 
	 * @param cntrtNm
	 * @return int
	 * @throws PLMCommonException
	 */
	public int fetchWBSEContract(String cntrtNm) throws PLMCommonException;
	
	
	/**
	 * This method is used to fetchBOMContract
	 * 
	 * @param cntrtNm
	 * @return int
	 * @throws PLMCommonException
	 */
	public int fetchBOMContract(String cntrtNm) throws PLMCommonException;
	
}
