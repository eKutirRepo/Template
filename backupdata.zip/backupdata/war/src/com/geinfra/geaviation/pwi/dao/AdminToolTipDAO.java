package com.geinfra.geaviation.pwi.dao;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.AdminToolTipVO;

/**
 * 
 * Project : Product Lifecycle Management Date Written : May 19, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Data access object interface for admin settings.
 * 
 * Revision Log May 19, 2010 | v1.0.
 * --------------------------------------------------------------
 */

public interface AdminToolTipDAO {
	public AdminToolTipVO getToolTip(String toolTipName) throws PWiException;

	public void createToolTip(String appparName, String appparVal, String userId)
			throws PWiException;

	public void updateToolTip(String appparName, String appparVal, String userId)
			throws PWiException;
}
