/**
 * Copyright (C) 2012 GE Infra. 
 * All rights reserved 
 * @FileName PLMOmmMBoMRptData.java
 * @Creation date: 26-April-2016
 * @version 2.0.1
 * @author : Tech Mahindra (PLMR Team) 
 */

package com.geinfra.geaviation.pwi.data;

import java.util.Date;



public class PLMOmmMBoMRptData 
{
	/**
	  * Holds the serialNo
	  */
	private String serialNo;
	/**
	  * Holds the projectNo
	  */
	private String projectNo;
	/**
	  * Holds the bomLevel
	  */
	private int bomLevel;
	/**
	  * Holds the logicalIndicator
	  */
	private String logicalIndicator;
	/**
	  * Holds the mli
	  */
	private String mli;
	/**
	  * Holds the pin
	  */
	private String pin;
	/**
	  * Holds the hpin
	  */
	private String hpin;
	/**
	  * Holds the parentMLI
	  */
	private String parentMLI;
	/**
	  * Holds the suffix
	  */
	private String suffix;
	/**
	  * Holds the type
	  */
	private String type;
	/**
	  * Holds the partNo
	  */
	private String partNo;
	/**
	  * Holds the parentName
	  */
	private String parentName;
	/**
	  * Holds the partRev
	  */
	private String partRev;
	/**
	  * Holds the partState
	  */
	private String partState;
	/**
	  * Holds the partDesc
	  */
	private String partDesc;
	/**
	  * Holds the partFamily
	  */
	private String partFamily;
	/**
	  * Holds the partFamilyTitle
	  */
	private String partFamilyTitle;
	/**
	  * Holds the qty
	  */
	private int qty;
	/**
	  * Holds the partUom
	  */
	private String partUom;
	/**
	  * Holds the docName
	  */
	private String docName;
	/**
	  * Holds the docRev
	  */
	private String docRev;
	/**
	  * Holds the docState
	  */
	private String docState;
	/**
	  * Holds the docDesc
	  */
	private String docDesc;
	/**
	  * Holds the securityClass
	  */
	private String securityClass;
	/**
	  * Holds the exportClass
	  */
	private String exportClass;
	/**
	  * Holds the geDwgCriticalCode
	  */
	private String geDwgCriticalCode;
	/**
	  * Holds the recordId
	  */
	private int recordId;
	/**
	  * Holds the pathFlag
	  */
	private String pathFlag;
	/**
	  * Holds the turbineNo
	  */
	private String turbineNo;
	/**
	  * Holds the newItem
	  */
	private String newItem;
	/**
	  * Holds the oldItem
	  */
	private String oldItem;
	/**
	  * Holds the section
	  */
	private String section;
	/**
	  * Holds the revisonNo
	  */
	private String revisonNo;
	/**
	  * Holds the authorization
	  */
	private String authorization;
	/**
	  * Holds the description
	  */
	private String description;
	/**
	  * Holds the dateApplied
	  */
	
	private Date dateApplied;
	/**
	  * Holds the anNum
	  */
	private String anNum;
	/**
	  * Holds the author
	  */
	private String author;
	/**
	  * Holds the authorFn
	  */
	private String authorFn;
	/**
	  * Holds the authorLn
	  */
	private String authorLn;
	/**
	  * Holds the catNo
	  */
	private String catNo;
	/**
	  * Holds the location
	  */
	private String location;
	/**
	  * Holds the parentPin
	  */
	private String parentPin;
	/**
	  * Holds the partType
	  */
	private String partType;
	/**
	  * Holds the docType
	  */
	private String docType;
	/**
	  * Holds the parentId
	  */
	private String parentId;
	/**
	  * Holds the childId
	  */
	private String childId;
	/**
	  * Holds the costGroup
	  */
	private String costGroup;

	//Start Added fields for getting Top parts
	/**
	  * Holds the geSerialNum
	  */
	private String geSerialNum;
	/**
	  * Holds the contract
	  */
	private String contract;
	/**
	  * Holds the hardWarePrd
	  */
	private String hardWarePrd;
	/**
	  * Holds the topPartId
	  */
	private String topPartId;

	/**
	  * Holds the topPart
	  */
	private String topPart;
	//End Added fields for getting Top parts
	
	/**
	 * Holds the findNum
	 */
	private String findNum;
	/**
	 * Holds the partEid
	 */
	private String partEid;
	/**
	 * Holds the eid
	 */
	private String eid;
	/**
	 * Holds the uomDesc
	 */
	private String uomDesc;
	/**
	  * Holds the rowKey
	  */
	private int rowKey;
	
	/**
	 * @return the projectNo
	 */
	public String getProjectNo() {
		return projectNo;
	}
	/**
	 * @param projectNo the projectNo to set
	 */
	public void setProjectNo(String projectNo) {
		this.projectNo = projectNo;
	}
	/**
	 * @return the bomLevel
	 */
	public int getBomLevel() {
		return bomLevel;
	}
	/**
	 * @param bomLevel the bomLevel to set
	 */
	public void setBomLevel(int bomLevel) {
		this.bomLevel = bomLevel;
	}
	/**
	 * @return the logicalIndicator
	 */
	public String getLogicalIndicator() {
		return logicalIndicator;
	}
	/**
	 * @param logicalIndicator the logicalIndicator to set
	 */
	public void setLogicalIndicator(String logicalIndicator) {
		this.logicalIndicator = logicalIndicator;
	}
	/**
	 * @return the mli
	 */
	public String getMli() {
		return mli;
	}
	/**
	 * @param mli the mli to set
	 */
	public void setMli(String mli) {
		this.mli = mli;
	}
	/**
	 * @return the pin
	 */
	public String getPin() {
		return pin;
	}
	/**
	 * @param pin the pin to set
	 */
	public void setPin(String pin) {
		this.pin = pin;
	}
	
	/**
	 * @return the hpin
	 */
	public String getHpin() {
		return hpin;
	}
	/**
	 * @param hpin the hpin to set
	 */
	public void setHpin(String hpin) {
		this.hpin = hpin;
	}
	
	/**
	 * @return the parentMLI
	 */
	public String getParentMLI() {
		return parentMLI;
	}
	/**
	 * @param parentMLI the parentMLI to set
	 */
	public void setParentMLI(String parentMLI) {
		this.parentMLI = parentMLI;
	}
	/**
	 * @return the suffix
	 */
	public String getSuffix() {
		return suffix;
	}
	/**
	 * @param suffix the suffix to set
	 */
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the partNo
	 */
	public String getPartNo() {
		return partNo;
	}
	/**
	 * @param partNo the partNo to set
	 */
	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}
	/**
	 * @return the partRev
	 */
	public String getPartRev() {
		return partRev;
	}
	/**
	 * @param partRev the partRev to set
	 */
	public void setPartRev(String partRev) {
		this.partRev = partRev;
	}
	/**
	 * @return the docName
	 */
	public String getDocName() {
		return docName;
	}
	/**
	 * @param docName the docName to set
	 */
	public void setDocName(String docName) {
		this.docName = docName;
	}
	/**
	 * @return the docRev
	 */
	public String getDocRev() {
		return docRev;
	}
	/**
	 * @param docRev the docRev to set
	 */
	public void setDocRev(String docRev) {
		this.docRev = docRev;
	}
	/**
	 * @return the securityClass
	 */
	public String getSecurityClass() {
		return securityClass;
	}
	/**
	 * @param securityClass the securityClass to set
	 */
	public void setSecurityClass(String securityClass) {
		this.securityClass = securityClass;
	}
	/**
	 * @return the exportClass
	 */
	public String getExportClass() {
		return exportClass;
	}
	/**
	 * @param exportClass the exportClass to set
	 */
	public void setExportClass(String exportClass) {
		this.exportClass = exportClass;
	}
	/**
	 * @return the serialNo
	 */
	public String getSerialNo() {
		return serialNo;
	}
	/**
	 * @param serialNo the serialNo to set
	 */
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	/**
	 * @return the geDwgCriticalCode
	 */
	public String getGeDwgCriticalCode() {
		return geDwgCriticalCode;
	}
	/**
	 * @param geDwgCriticalCode the geDwgCriticalCode to set
	 */
	public void setGeDwgCriticalCode(String geDwgCriticalCode) {
		this.geDwgCriticalCode = geDwgCriticalCode;
	}
	/**
	 * @return the partState
	 */
	public String getPartState() {
		return partState;
	}
	/**
	 * @param partState the partState to set
	 */
	public void setPartState(String partState) {
		this.partState = partState;
	}
	/**
	 * @return the partDesc
	 */
	public String getPartDesc() {
		return partDesc;
	}
	/**
	 * @param partDesc the partDesc to set
	 */
	public void setPartDesc(String partDesc) {
		this.partDesc = partDesc;
	}
	/**
	 * @return the partUom
	 */
	public String getPartUom() {
		return partUom;
	}
	/**
	 * @param partUom the partUom to set
	 */
	public void setPartUom(String partUom) {
		this.partUom = partUom;
	}
	/**
	 * @return the docState
	 */
	public String getDocState() {
		return docState;
	}
	/**
	 * @param docState the docState to set
	 */
	public void setDocState(String docState) {
		this.docState = docState;
	}
	/**
	 * @return the recordId
	 */
	public int getRecordId() {
		return recordId;
	}
	/**
	 * @param recordId the recordId to set
	 */
	public void setRecordId(int recordId) {
		this.recordId = recordId;
	}
	/**
	 * @return the turbineNo
	 */
	public String getTurbineNo() {
		return turbineNo;
	}
	/**
	 * @param turbineNo the turbineNo to set
	 */
	public void setTurbineNo(String turbineNo) {
		this.turbineNo = turbineNo;
	}
	/**
	 * @return the newItem
	 */
	public String getNewItem() {
		return newItem;
	}
	/**
	 * @param newItem the newItem to set
	 */
	public void setNewItem(String newItem) {
		this.newItem = newItem;
	}
	/**
	 * @return the oldItem
	 */
	public String getOldItem() {
		return oldItem;
	}
	/**
	 * @param oldItem the oldItem to set
	 */
	public void setOldItem(String oldItem) {
		this.oldItem = oldItem;
	}
	/**
	 * @return the section
	 */
	public String getSection() {
		return section;
	}
	/**
	 * @param section the section to set
	 */
	public void setSection(String section) {
		this.section = section;
	}
	/**
	 * @return the revisonNo
	 */
	public String getRevisonNo() {
		return revisonNo;
	}
	/**
	 * @param revisonNo the revisonNo to set
	 */
	public void setRevisonNo(String revisonNo) {
		this.revisonNo = revisonNo;
	}
	/**
	 * @return the authorization
	 */
	public String getAuthorization() {
		return authorization;
	}
	/**
	 * @param authorization the authorization to set
	 */
	public void setAuthorization(String authorization) {
		this.authorization = authorization;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the anNum
	 */
	public String getAnNum() {
		return anNum;
	}
	/**
	 * @param anNum the anNum to set
	 */
	public void setAnNum(String anNum) {
		this.anNum = anNum;
	}
	/**
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}
	/**
	 * @param author the author to set
	 */
	public void setAuthor(String author) {
		this.author = author;
	}
	/**
	 * @return the authorFn
	 */
	public String getAuthorFn() {
		return authorFn;
	}
	/**
	 * @param authorFn the authorFn to set
	 */
	public void setAuthorFn(String authorFn) {
		this.authorFn = authorFn;
	}
	/**
	 * @return the authorLn
	 */
	public String getAuthorLn() {
		return authorLn;
	}
	/**
	 * @param authorLn the authorLn to set
	 */
	public void setAuthorLn(String authorLn) {
		this.authorLn = authorLn;
	}
	/**
	 * @return the catNo
	 */
	public String getCatNo() {
		return catNo;
	}
	/**
	 * @param catNo the catNo to set
	 */
	public void setCatNo(String catNo) {
		this.catNo = catNo;
	}
	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}
	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}
	/**
	 * @return the parentPin
	 */
	public String getParentPin() {
		return parentPin;
	}
	/**
	 * @param parentPin the parentPin to set
	 */
	public void setParentPin(String parentPin) {
		this.parentPin = parentPin;
	}
	/**
	 * @return the dateApplied
	 */
	public Date getDateApplied() {
		Date dtApplied =dateApplied;
		return dtApplied;
	}
	/**
	 * @param dateApplied the dateApplied to set
	 */
	public void setDateApplied(Date dateApplied) {
		Date dtApplied =dateApplied;
		this.dateApplied = dtApplied;
	}
	/**
	 * @return the parentName
	 */
	public String getParentName() {
		return parentName;
	}
	/**
	 * @param parentName the parentName to set
	 */
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	/**
	 * @return the pathFlag
	 */
	public String getPathFlag() {
		return pathFlag;
	}
	/**
	 * @param pathFlag the pathFlag to set
	 */
	public void setPathFlag(String pathFlag) {
		this.pathFlag = pathFlag;
	}
	/**
	 * @return the qty
	 */
	public int getQty() {
		return qty;
	}
	/**
	 * @param qty the qty to set
	 */
	public void setQty(int qty) {
		this.qty = qty;
	}
	/**
	 * @return the docDesc
	 */
	public String getDocDesc() {
		return docDesc;
	}
	/**
	 * @param docDesc the docDesc to set
	 */
	public void setDocDesc(String docDesc) {
		this.docDesc = docDesc;
	}
	/**
	 * @return the partType
	 */
	public String getPartType() {
		return partType;
	}
	/**
	 * @param partType the partType to set
	 */
	public void setPartType(String partType) {
		this.partType = partType;
	}
	/**
	 * @return the docType
	 */
	public String getDocType() {
		return docType;
	}
	/**
	 * @param docType the docType to set
	 */
	public void setDocType(String docType) {
		this.docType = docType;
	}
	/**
	 * @return the parentId
	 */
	public String getParentId() {
		return parentId;
	}
	/**
	 * @param parentId the parentId to set
	 */
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	/**
	 * @return the childId
	 */
	public String getChildId() {
		return childId;
	}
	/**
	 * @param childId the childId to set
	 */
	public void setChildId(String childId) {
		this.childId = childId;
	}
	/**
	 * @return Returns the partFamily.
	 */
	public String getPartFamily() {
		return partFamily;
	}
	/**
	 * @param partFamily The partFamily to set.
	 */
	public void setPartFamily(String partFamily) {
		this.partFamily = partFamily;
	}
	/**
	 * @return Returns the costGroup.
	 */
	public String getCostGroup() {
		return costGroup;
	}
	/**
	 * @param custGroup The costGroup to set.
	 */
	public void setCostGroup(String costGroup) {
		this.costGroup = costGroup;
	}
	/**
	 * @return
	 */
	public String getPartFamilyTitle() {
		return partFamilyTitle;
	}
	/**
	 * @param partFamilyTitle
	 */
	public void setPartFamilyTitle(String partFamilyTitle) {
		this.partFamilyTitle = partFamilyTitle;
	}
	/**
	 * @return the geSerialNum
	 */
	public String getGeSerialNum() {
		return geSerialNum;
	}
	/**
	 * @param geSerialNum the geSerialNum to set
	 */
	public void setGeSerialNum(String geSerialNum) {
		this.geSerialNum = geSerialNum;
	}
	/**
	 * @return the contract
	 */
	public String getContract() {
		return contract;
	}
	/**
	 * @param contract the contract to set
	 */
	public void setContract(String contract) {
		this.contract = contract;
	}
	/**
	 * @return the hardWarePrd
	 */
	public String getHardWarePrd() {
		return hardWarePrd;
	}
	/**
	 * @param hardWarePrd the hardWarePrd to set
	 */
	public void setHardWarePrd(String hardWarePrd) {
		this.hardWarePrd = hardWarePrd;
	}
	/**
	 * @return the topPartId
	 */
	public String getTopPartId() {
		return topPartId;
	}
	/**
	 * @param topPartId the topPartId to set
	 */
	public void setTopPartId(String topPartId) {
		this.topPartId = topPartId;
	}
	/**
	 * @return the topPart
	 */
	public String getTopPart() {
		return topPart;
	}
	/**
	 * @param topPart the topPart to set
	 */
	public void setTopPart(String topPart) {
		this.topPart = topPart;
	}
	/**
	 * @return the findNum
	 */
	public String getFindNum() {
		return findNum;
	}
	/**
	 * @param findNum the findNum to set
	 */
	public void setFindNum(String findNum) {
		this.findNum = findNum;
	}
	/**
	 * @return the partEid
	 */
	public String getPartEid() {
		return partEid;
	}
	/**
	 * @param partEid the partEid to set
	 */
	public void setPartEid(String partEid) {
		this.partEid = partEid;
	}
	/**
	 * @return the eid
	 */
	public String getEid() {
		return eid;
	}
	/**
	 * @param eid the eid to set
	 */
	public void setEid(String eid) {
		this.eid = eid;
	}
	/**
	 * @return the uomDesc
	 */
	public String getUomDesc() {
		return uomDesc;
	}
	/**
	 * @param uomDesc the uomDesc to set
	 */
	public void setUomDesc(String uomDesc) {
		this.uomDesc = uomDesc;
	}
	/**
	 * @return the rowKey
	 */
	public int getRowKey() {
		return rowKey;
	}
	/**
	 * @param rowKey the rowKey to set
	 */
	public void setRowKey(int rowKey) {
		this.rowKey = rowKey;
	}
	
	
}