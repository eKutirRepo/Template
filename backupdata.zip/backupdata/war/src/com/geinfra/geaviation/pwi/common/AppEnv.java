package com.geinfra.geaviation.pwi.common;

/**
 * Project : Product Lifecycle Management Date Written : Apr 12, 2011 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : Enumeration of different application environments
 * 
 * Revision Log Apr 12, 2011 | v1.0.
 * --------------------------------------------------------------
 */
public enum AppEnv {
	DEV("dev"), QA("qa"), PROD("prod");

	private String string;

	private AppEnv(String string) {
		this.string = string;
	}

	public static AppEnv fromString(String string) {
		for (AppEnv appEnv : values()) {
			if (appEnv.string.equals(string)) {
				return appEnv;
			}
		}
		return null;
	}

	public String toString() {
		return string;
	}
}
