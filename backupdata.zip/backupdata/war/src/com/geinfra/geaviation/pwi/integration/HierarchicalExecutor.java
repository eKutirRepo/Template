package com.geinfra.geaviation.pwi.integration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.PWiQueryTimeoutException;
import com.geinfra.geaviation.pwi.common.PWiResultSizeLimitExceededException;
import com.geinfra.geaviation.pwi.executors.Executor;
import com.geinfra.geaviation.pwi.model.PWiResultSet;
import com.geinfra.geaviation.pwi.model.PWiResultSetColMetaData;
import com.geinfra.geaviation.pwi.util.QueryProcessingUtil;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.search.util.SearchJaxbUtil;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;

/**
 * Project      : Product Lifecycle Management
 * Date Written : May 18, 2010
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : BaseDAO - Interface for DAO class to execute queries.
 * 
 * Revision Log May 18, 2010 | v1.0.
 * 2012.12.18 pH  replaced GEAEResultSet with PWiResultSet
 * --------------------------------------------------------------
 */
public class HierarchicalExecutor implements Executor {
	private static final String PATH_DELIMITER = " # ";
	private static final int MAX_LEVEL = 15;

	// Config
	private Executor executor;
	private String searchColumnId;
	private String childColumnId;

	// Currently generate all extra columns and rely on selected columns and the
	// query submission service's column filtering to determine whether to
	// ultimately include them in the final result the user sees
	private boolean includeLevelColumn = true;
	private boolean includeLoopColumn = true;
	private boolean includePathColumn = true;

	// Non-config
	private QueryType queryType;
	private Search search;
	private SelectedColumns selectedColumns;
	private String sso;

	public HierarchicalExecutor(Executor executor, String searchColumnId,
			String childColumnId) {
		this.executor = executor;
		this.searchColumnId = searchColumnId;
		this.childColumnId = childColumnId;
	}

	public PWiResultSet execute(QueryType theQueryType, Search aSearch,
			SelectedColumns aSelectedColumns, String aSso, String[] columns,
			List<Object[]> rows) throws PWiException,
			PWiResultSizeLimitExceededException, PWiQueryTimeoutException {
		this.queryType = theQueryType;

		// Copy parameters to member fields
		this.selectedColumns = aSelectedColumns;
		this.sso = aSso;

		// Copy search so we can modify it as we desire
		this.search = SearchJaxbUtil.copySearch(aSearch);

		// Extract ID
		String id = extractId(this.search);

		Result result = findHierarchy(id, new HashSet<String>(),
					new ArrayList<String>(), 1);

		return result.resultSet;
	}

	private String extractId(Search aSearch) throws PWiException {
		// Return value of first search item matching column ref specified for
		// ID
		for (Search.Item item : aSearch.getItem()) {
			if (searchColumnId.equals(item.getColumnref().getRef())) {
				if (SearchJaxbUtil.isEqualsOp(item)) {
					return item.getValue();
				} else {
					throw new PWiException(
							"Unsupported search operator.  Only equals is supported.");
				}
			}
		}
		throw new PWiException(
				"Failed to find value to do hierarchical search over.  Looking for column ref: "
						+ searchColumnId);
	}

	private void replaceIdInSearch(String idValue) throws PWiException {
		// Return value of first search item matching column ref specified for
		// ID
		for (Search.Item item : search.getItem()) {
			if (searchColumnId.equals(item.getColumnref().getRef())) {
				if (SearchJaxbUtil.isEqualsOp(item)) {
					item.setValue(idValue);
					return;
				} else {
					throw new PWiException(
							"Unsupported search operator.  Only equals is supported.");
				}
			}
		}
		throw new PWiException(
				"Failed to find value to do hierarchical search over.  Looking for column ref: "
						+ searchColumnId);
	}

	private static class Result {
		private PWiResultSet resultSet;
		private Set<String> processedIds;

		public Result(PWiResultSet resultSet, Set<String> processedIds) {
			this.resultSet = resultSet;
			this.processedIds = processedIds;
		}
	}

	private Result findHierarchy(String id, Set<String> processedIds,
			List<String> path, int level) throws PWiException,
			PWiResultSizeLimitExceededException, PWiQueryTimeoutException {
		if (level > MAX_LEVEL) {
			return null;
		}

		processedIds.add(id);

		List<String> newPath = new ArrayList<String>(path);
		newPath.add(id);

		String pathAncestorsString = null;
		if (includePathColumn) {
			pathAncestorsString = generatePathString(newPath);
		}

		PWiResultSet results = executeQuery(id);

		// Create augmented result set (to add data to)
		PWiResultSet augmentedResults = generateAugmentedResultSet(results);

		// Recurse -- find descendants of results
		if (results.size() > 0) {
			results.first();
			do {
				ArrayList<String> row = new ArrayList<String>();

				String childId = getChildId(results);

				if (includeLevelColumn) {
					row.add(String.valueOf(level));
				}

				// Include columns from actual query
				for (int columnIndex = 1; columnIndex <= results
						.getColumnCount(); columnIndex++) {
					row.add(results.getString(columnIndex));
				}

				if (includeLoopColumn) {
					// Detect cyclic flag, by looking at path (can't use
					// processIds list since it can contain IDs from other
					// paths)
					if (newPath.contains(childId)) {
						// Mark as cyclic
						row.add("1");
					} else {
						// Mark as non-loop
						row.add("0");
					}
				}

				if (includePathColumn) {
					row.add(pathAncestorsString + PATH_DELIMITER + childId);
				}

				augmentedResults.addRow(row);

				// Recurse if necessary
				if (!processedIds.contains(childId)) {
					// Process child (recurse)
					Result descendantResults = findHierarchy(childId,
							processedIds, newPath, level + 1);

					// Add any results to processed IDs set and append rows to
					// result set
					if (descendantResults != null) {
						// Update processedIds
						processedIds.addAll(descendantResults.processedIds);

						// Add child results to overall result set
						QueryProcessingUtil.getInstance().appendResultSet(
								augmentedResults, descendantResults.resultSet);
					}
				}
			} while (results.next());
		}

		return new Result(augmentedResults, processedIds);
	}

	private String getChildId(PWiResultSet resultSet) {
		String childId = ObjectUtils.toString(resultSet
				.getObject(childColumnId));
		if (StringUtils.isNotEmpty(childId)) {
			return childId;
		}
		return null;
	}

	private PWiResultSet executeQuery(String id) throws PWiException,
			PWiResultSizeLimitExceededException, PWiQueryTimeoutException {
		// Replace ID value in search
		replaceIdInSearch(id);

		// Execute query
		PWiResultSet resultSet = executor.execute(queryType, search,
				selectedColumns, sso, null, null);

		return resultSet;
	}

	public String getExecutedQuery() {
		return "Getting query string is not supported for hierarchical queries";
	}

	private String generatePathString(List<String> path) {
		return StringUtils.join(path.toArray(), PATH_DELIMITER);
	}

	private PWiResultSet generateAugmentedResultSet(PWiResultSet resultSet) {
		PWiResultSet augmentedResultSet = new PWiResultSet();

		// Generate metadata
		HashMap<String, Integer> indexbyName = new HashMap<String, Integer>();
		HashMap<Integer, PWiResultSetColMetaData> metaByIndex = new HashMap<Integer, PWiResultSetColMetaData>();

		// Add level
		if (includeLevelColumn) {
			PWiResultSetColMetaData metaData = new PWiResultSetColMetaData();
			metaData.colheading = "LEVEL";
			metaData.colindex = 1;
			metaData.colname = "LEVEL";

			// Add to meta data to hash tables
			indexbyName.put(metaData.colname, Integer
					.valueOf(metaData.colindex));
			metaByIndex.put(Integer.valueOf(metaData.colindex), metaData);
		}

		// Add meta from actual query results
		for (int columnIndex = 1; columnIndex <= resultSet.getColumnCount(); columnIndex++) {
			// Set meta data
			PWiResultSetColMetaData metaData = new PWiResultSetColMetaData();
			metaData.colheading = resultSet.getColumnHeading(columnIndex);
			// Determine column index based on if level column is included
			metaData.colindex = (includeLevelColumn ? 1 : 0) + columnIndex;
			metaData.colname = resultSet.getColumnName(columnIndex);

			// Add to meta data to hash tables
			indexbyName.put(metaData.colname, Integer
					.valueOf(metaData.colindex));
			metaByIndex.put(Integer.valueOf(metaData.colindex), metaData);
		}

		// Add loop
		if (includeLoopColumn) {
			PWiResultSetColMetaData metaData = new PWiResultSetColMetaData();
			metaData.colheading = "LOOP_IND";
			// Determine column index based on which columns were included
			// previously
			metaData.colindex = (includeLevelColumn ? 1 : 0)
					+ resultSet.getColumnCount() + 1;
			metaData.colname = "LOOP_IND";

			// Add to meta data to hash tables
			indexbyName.put(metaData.colname, Integer
					.valueOf(metaData.colindex));
			metaByIndex.put(Integer.valueOf(metaData.colindex), metaData);
		}

		// Add level
		if (includePathColumn) {
			PWiResultSetColMetaData metaData = new PWiResultSetColMetaData();
			metaData.colheading = "PATH";
			// Determine column index based on which columns were included
			// previously
			metaData.colindex = (includeLevelColumn ? 1 : 0)
					+ resultSet.getColumnCount() + (includeLoopColumn ? 1 : 0)
					+ 1;
			metaData.colname = "PATH";

			// Add to meta data to hash tables
			indexbyName.put(metaData.colname, Integer
					.valueOf(metaData.colindex));
			metaByIndex.put(Integer.valueOf(metaData.colindex), metaData);
		}

		// Leave data empty to be filled in later
		ArrayList<ArrayList<String>> dataTable = new ArrayList<ArrayList<String>>();

		augmentedResultSet.setData(dataTable, indexbyName, metaByIndex);

		return augmentedResultSet;
	}
}
