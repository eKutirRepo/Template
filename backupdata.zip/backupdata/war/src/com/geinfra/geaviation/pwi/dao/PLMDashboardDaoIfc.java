/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMDashboardDaoIfc.java
 * @Creation date: 4-April-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMDwgDashboardData;
import com.geinfra.geaviation.pwi.data.PLMkpiCostEngData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMDashboardDaoIfc {
	/**
	 * This method is used to getDropDownData
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getDropDownData() throws PLMCommonException;
	/**
	 * This method is used to loadDwgDashboardReport
	 * @return List
	 * @param dashboardData, dashboardList, selectedContractNamesList, activeTask
	 * @throws PLMCommonException
	 */
	public List<PLMDwgDashboardData> loadDwgDashboardReport(PLMDwgDashboardData dashboardData,List<PLMDwgDashboardData> dashboardList,List<String> selectedContractNamesList,boolean activeTask) throws PLMCommonException;
	/**
	 * This method is used to loadCLINDwgDashboardReport
	 * @return List
	 * @param dashboardData, dashboardList_clin
	 * @throws PLMCommonException
	 */
	//public List<PLMDwgDashboardData> loadCLINDwgDashboardReport(PLMDwgDashboardData dashboardData,List<PLMDwgDashboardData> dashboardList_clin) throws PLMCommonException;
	/**
	 * This method is used to loadDwgDashboardDetailReport
	 * @return List
	 * @param dashboardData, dashboardDetailList, selectedContractNamesList, activeTask
	 * @throws PLMCommonException
	 */
	public List<PLMDwgDashboardData> loadDwgDashboardDetailReport(PLMDwgDashboardData dashboardData,List<PLMDwgDashboardData> dashboardDetailList,List<String> selectedContractNamesList,boolean activeTask) throws PLMCommonException;
	
	// Newly Added method of 1269 Req for 3.0.10 release
	/**
	 * This method is used to get KPI Cost Eng report details
	 * 
	 * @param dashboardData
	 * @throws PLMCommonException
	 */
	public List<PLMkpiCostEngData> getKPICostEngReport(String ecoEcrName) throws PLMCommonException;


	
}
