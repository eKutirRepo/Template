/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhereUsedMB.java
 * @Creation date: 23-July-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.StringTokenizer;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.common.usermodel.Hyperlink;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFCreationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFHyperlink;
import org.richfaces.event.UploadEvent;
import org.richfaces.model.UploadItem;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.QueryAccessException;
import com.geinfra.geaviation.pwi.data.PLMImpactAnalysisData;
import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.data.PLMWhereUsedData;
import com.geinfra.geaviation.pwi.data.PLMWhereUsedReqData;
import com.geinfra.geaviation.pwi.data.PLMXlsxRptColumnData;
import com.geinfra.geaviation.pwi.service.PLMWhereUsedServiceIfc;
import com.geinfra.geaviation.pwi.servlet.ImpactAnalysisServlet;
import com.geinfra.geaviation.pwi.util.BookmarkableLinkUtil;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

public class PLMWhereUsedMB {
	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMWhereUsedMB.class);
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	/**
	 * Holds the resourceBundle
	 */
	ResourceBundle resourceBundle = ResourceBundle
			.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the plmWhereUsedService
	 */
	private PLMWhereUsedServiceIfc plmWhereUsedService = null;
	/**
	 * Holds the plmWhereUsedData
	 */
	private PLMWhereUsedData plmWhereUsedData = new PLMWhereUsedData();
	/**
	 * Holds the whereUsedLOUSearchList
	 */
	private List<PLMWhereUsedData> whereUsedLOUSearchList = new ArrayList<PLMWhereUsedData>();
	/**
	 * Holds the recordCount
	 */
	private int recordCount;
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the totalRecCountMsg
	 */
	private String totalRecCountMsg;
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage = "";
	/**
	 * Holds the partNumber
	 */
	String partNumber;
	/**
	 * Holds the dropdownlist
	 */
	// private Map<String, List<SelectItem>> dropdownlist;
	/**
	 * Holds the stateListData
	 */
	private List<SelectItem> stateListData;
	/**
	 * Holds the typeListData
	 */
	private List<SelectItem> typeListData;
	/**
	 * Holds the alertMsg
	 */
	private String alertMsgWu;
	/**
	 * Holds the searchResultList
	 */
	private List<PLMWhereUsedData> searchResultList;

	// Newly added method for Where Used Requirement
	/**
	 * Holds the plmWhereUsedReqData
	 */
	private PLMWhereUsedReqData plmWhereUsedReqData = new PLMWhereUsedReqData();
	/**
	 * Holds the whereUsedReqList
	 */
	private List<PLMWhereUsedReqData> whereUsedReqList = new ArrayList<PLMWhereUsedReqData>();
	/**
	 * Holds the totalWhereUSedReportMsg
	 */
	private String totalWhereUSedReportMsg;
	/**
	 * Holds the whereUsedReportCounts
	 */
	private int whereUsedReportCounts = PLMConstants.N_100;
	/**
	 * Holds the whereUsedRprtTotCounts
	 */
	private int whereUsedRprtTotCounts;
	/**
	 * Holds the dropdownframelist
	 */
	private Map<String, List<SelectItem>> dropdownframelist;
	/**
	 * Holds the frameList
	 */
	private List<SelectItem> frameList;
	/**
	 * Holds the selFrameList
	 */
	private String selFrameList;
	/**
	 * Holds the contratStrDt
	 */
	private String contratStrDt;
	/**
	 * Holds the contratEndDt
	 */
	private String contratEndDt;
	/**
	 * Holds the fmiIssStrDt
	 */
	private String fmiIssStrDt;
	/**
	 * Holds the fmiIssEndDt
	 */
	private String fmiIssEndDt;
	/**
	 * Holds the wildCardReqrmnt
	 */
	private String wildCardReqrmnt;
	/**
	 * Holds the wildCardSerlNo
	 */
	private String wildCardSerlNo;
	/**
	 * Holds the tliPartNumber
	 */
	private String tliPartNumber;
	/**
	 * Holds the LcopicsDataList
	 */
	List<PLMWhereUsedData> copicsDataList = new ArrayList<PLMWhereUsedData>();
	/**
	 * Holds the sbomDataList
	 */
	List<PLMWhereUsedData> sbomDataList = new ArrayList<PLMWhereUsedData>();
	/**
	 * Holds the ebomDataList
	 */
	List<PLMWhereUsedData> ebomDataList = new ArrayList<PLMWhereUsedData>();
	
	/**
	 * Holds the RpdmDataList
	 */
	List<PLMWhereUsedData> rpdmDataList = new ArrayList<PLMWhereUsedData>();
	
	
	/**
	 * Holds the strCopics
	 */
	private String strCopics = "";
	/**
	 * Holds the strSbom
	 */
	private String strSbom = "";
	/**
	 * Holds the strEbom
	 */
	private String strEbom = "";
	
	/**
	 * Holds the rpdm
	 */
	private String strrpdm = "";
	
	/**
	 * Holds the recordsCount
	 */
	private int recordsCount = PLMConstants.N_10;
	/**
	 * Holds the blnStrCopics
	 */
	private boolean blnStrCopics;
	/**
	 * Holds the blnShwCpcsTable
	 */
	private boolean blnShwCpcsTable;
	/**
	 * Holds the blnStrSbom
	 */
	private boolean blnStrSbom;
	/**
	 * Holds the blnShwSbomTable
	 */
	private boolean blnShwSbomTable;
	/**
	 * Holds the blnStrEbom
	 */
	private boolean blnStrEbom;
	
	
	
	private boolean blnStrRpdm;
	
	/**
	 * Holds the blnShwEbomTable
	 */
	private boolean blnShwEbomTable;
	
	/**
	 * Holds the blnShwRpdmTable
	 */
	private boolean blnShwRpdmTable;
	
	/**
	 * Holds the strNoRcrdsMsgFrCopics
	 */
	private String strNoRcrdsMsgFrCopics = "";
	/**
	 * Holds the strNoRcrdsMsgFrEbom
	 */
	private String strNoRcrdsMsgFrEbom = "";
	/**
	 * Holds the strNoRcrdsMsgFrSbom
	 */
	private String strNoRcrdsMsgFrSbom = "";
	
	
	/**
	 * Holds the strNoRcrdsMsgFrRpdm
	 */
	private String strNoRcrdsMsgFrRpdm = "";
	
	/**
	 * Holds the showAllTables
	 */
	private boolean showAllTables;
	/**
	 * Holds the detailCopicsCounts
	 */
	private int detailCopicsCounts = PLMConstants.N_100;
	/**
	 * Holds the detailSBoMCounts
	 */
	private int detailSBoMCounts = PLMConstants.N_100;
	/**
	 * Holds the detailEBoMCounts
	 */
	private int detailEBoMCounts = PLMConstants.N_100;
	
	
	
	private int detailRpdmCounts = PLMConstants.N_100;
	
	/**
	 * Holds the copicsCounts
	 */
	private int copicsCounts;
	/**
	 * Holds the sBoMCounts
	 */
	private int sBoMCounts;
	/**
	 * Holds the eBoMCounts
	 */
	private int eBoMCounts;
	
	/**
	 * Holds the rpdmCounts
	 */
	private int rpdmCounts;
	
	/**
	 * Holds the strTotRcrdsMsgFrCopics
	 */
	private String strTotRcrdsMsgFrCopics = "";
	/**
	 * Holds the strTotRcrdsMsgFrEbom
	 */
	private String strTotRcrdsMsgFrEbom = "";
	
	
	/**
	 * Holds the strTotRcrdsMsgFrom Rpdm
	 */
	private String strTotRcrdsMsgFrRpdm = "";
	
	/**
	 * Holds the strTotRcrdsMsgFrSbom
	 */
	private String strTotRcrdsMsgFrSbom = "";
	/**
	 * Holds the LcopicsDataList
	 */
	List<PLMImpactAnalysisData> impactDataLst = new ArrayList<PLMImpactAnalysisData>();
	/**
	 * Holds the impactCnt
	 */
	private int impactCnt;
	/**
	 * Holds the strTotRcrdsMsgFrCopics
	 */
	private String strTotRcrdsMsgFrImpct = "";
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB = null;
	
	 private PLMPwiUserData userDetails = null;

	private PLMLoginData userDataObj = (PLMLoginData) PLMUtils
			.getServletSession(true).getAttribute(
					PLMConstants.SESSION_USER_DATA);
	/**
	 * Holds the impactPageCnt
	 */
	private int impactPageCnt = PLMConstants.N_100;
	/**
	 * Holds the impactPageCnt
	 */
	private List<String> impactPartIdLst = new ArrayList<String>();
	/**
	 * Holds the wuPrtIdLst
	 */
	private List<String> wuPrtIdLst;
	/**
	 * Holds the wuFlag
	 */
	private String wuFlag;
	/**
	 * Holds the impactAnlysMap
	 */
	private Map<String, List<PLMImpactAnalysisData>> impactAnlysMap = new HashMap<String, List<PLMImpactAnalysisData>>();
	/**
	 * Holds the ebomimpactList1
	 */
	private List<PLMImpactAnalysisData> ebomimpactList1 = new ArrayList<PLMImpactAnalysisData>();
	/**
	 * Holds the ebomimpactList2
	 */
	private List<PLMImpactAnalysisData> ebomimpactList2 = new ArrayList<PLMImpactAnalysisData>();
	/**
	 * Holds the ebomimpactList3
	 */
	private List<PLMImpactAnalysisData> ebomimpactList3 = new ArrayList<PLMImpactAnalysisData>();
	/**
	 * Holds the ebomimpactCnt1
	 */
	private int ebomimpactCnt1 = 0;
	/**
	 * Holds the ebomimpactCnt2
	 */
	private int ebomimpactCnt2 = 0;
	/**
	 * Holds the ebomimpactCnt3
	 */
	private int ebomimpactCnt3 = 0;
	/**
	 * Holds the mbomimpactList1
	 */
	private List<PLMImpactAnalysisData> mbomimpactList1 = new ArrayList<PLMImpactAnalysisData>();
	/**
	 * Holds the mbomimpactList2
	 */
	private List<PLMImpactAnalysisData> mbomimpactList2 = new ArrayList<PLMImpactAnalysisData>();
	/**
	 * Holds the mbomimpactList3
	 */
	private List<PLMImpactAnalysisData> mbomimpactList3 = new ArrayList<PLMImpactAnalysisData>();

	/**
	 * Holds the mbomimpactCnt1
	 */
	private int mbomimpactCnt1 = 0;
	/**
	 * Holds the mbomimpactCnt2
	 */
	private int mbomimpactCnt2 = 0;
	/**
	 * Holds the mbomimpactCnt3
	 */
	private int mbomimpactCnt3 = 0;
	/**
	 * Holds the partName1
	 */
	private String partName1;

	/**
	 * Holds the partName2
	 */
	private String partName2;
	/**
	 * Holds the partName3
	 */
	private String partName3;

	/**
	 * Holds the ebomResultMsg1
	 */
	private String ebomResultMsg1;

	/**
	 * Holds the ebomResultMsg2
	 */
	private String ebomResultMsg2;

	/**
	 * Holds the ebomResultMsg3
	 */
	private String ebomResultMsg3;

	/**
	 * Holds the mbomResultMsg1
	 */
	private String mbomResultMsg1;

	/**
	 * Holds the mbomResultMsg2
	 */
	private String mbomResultMsg2;

	/**
	 * Holds the mbomResultMsg3
	 */
	private String mbomResultMsg3;

	/**
	 * Holds the ebomRowCnt1
	 */
	private int ebomRowCnt1= PLMConstants.N_50;
	/**
	 * Holds the mbomRowCnt1
	 */
	private int mbomRowCnt1= PLMConstants.N_50;
	
	/**
	 * Holds the ebomRowCnt2
	 */
	private int ebomRowCnt2= PLMConstants.N_50;
	/**
	 * Holds the mbomRowCnt2
	 */
	private int mbomRowCnt2= PLMConstants.N_50;
	
	/**
	 * Holds the ebomRowCnt3
	 */
	private int ebomRowCnt3= PLMConstants.N_50;
	/**
	 * Holds the mbomRowCnt3
	 */
	private int mbomRowCnt3= PLMConstants.N_50;
	
	/**
	 * Holds the userDataObj1
	 */
	private PLMLoginData userDataObj1 = new PLMLoginData();

	private final static XSSFColor GREEN_LIGHT = new XSSFColor(
			new java.awt.Color(196, 215, 155));
	private final static XSSFColor GRAY = new XSSFColor(new java.awt.Color(191,
			191, 191));
	/**
	 * Holds the partNumList
	 */
	private List<String> partNumList = new ArrayList<String>();
	
	/**
	 * Holds the alertMsgValidWu
	 */
	private String alertMsgValidWu;

	public PLMWhereUsedMB() {

		LOG.info("Bean Initialized----------------------------");
		wuPrtIdLst = new ArrayList<String>();
		String partIdLst = (String) PLMUtils.getServletSession(true)
				.getAttribute("WuPartId");
		LOG.info("Part Id List Passed ---------------------------" + partIdLst);
		if (partIdLst != null) {
			String[] partIdArr = partIdLst.split(",");
			if (partIdArr != null) {
				for (int i = 0; i < partIdArr.length; i++) {
					if (!wuPrtIdLst.contains(partIdArr[i]))
						wuPrtIdLst.add(partIdArr[i]);
				}
			}
		}
		wuFlag = (String) PLMUtils.getServletSession(true).getAttribute(
				"wuFlag");
		LOG.info("WU Part Id List Size ---------------------------- "
				+ wuPrtIdLst.size());
		PLMUtils.getServletSession(true).removeAttribute("WuPartId");
		PLMUtils.getServletSession(true).removeAttribute("wuFlag");
	}

	/**
	 * Level Of Uniqueness Background Process Thread
	 */
	private class LOUMailThread implements Runnable {
		public LOUMailThread() {
		}

		public void run() {
			sendLOUReportThroughMail();
		}
	}

	/**
	 * Generates the Where Used Search List
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String generateWhereUsedBMTIList() throws PLMCommonException {
		LOG.info("Inside WhereUSed Bean - generateWhereUsedBMTIList method");
		String fwdFlag = "";
		String vldtMsg = validateWhereUsedBMTI();
		if (PLMUtils.isEmpty(vldtMsg)) {
			fwdFlag = populateWhereUsedSearchList();
		}
		return fwdFlag;
	}

	/**
	 * This method is used to download excel for Where Used Configuration
	 * Features/Options by Contract report
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */

	public void downloadWhereUsedConfFOCExcel() throws PLMCommonException {

		LOG.info("Entering downloadWhereUsedConfFOCExcel Method");
		String reportName = "ConfFeatureOption";
		String fileName = "ConfFeatureOption";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();

		// Export to Excel for Where used Configuration Option Report

		PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] {
				new PLMXlsxRptColumn("selectedTypeExl", "Select Feature Type",
						FormatType.TEXT),
				new PLMXlsxRptColumn("name", "Name", FormatType.TEXT),
				new PLMXlsxRptColumn("description", "Description",
						FormatType.TEXT),
				new PLMXlsxRptColumn("mftfTypeString", "Type", FormatType.TEXT) };

		PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
				new PLMXlsxRptColumn("contractName", "Contract Name",
						FormatType.TEXT, null, null, 20),
				new PLMXlsxRptColumn("cusName", "Customer Name",
						FormatType.TEXT, null, null, 35),
				new PLMXlsxRptColumn("model", "Model", FormatType.TEXT),
				new PLMXlsxRptColumn("name", "Name", FormatType.TEXT),
				new PLMXlsxRptColumn("mktFeatureNm", "Marketing Name",
						FormatType.TEXT, null, null, 35),
				new PLMXlsxRptColumn("type", "Type", FormatType.TEXT),
				new PLMXlsxRptColumn("rev", "Rev", FormatType.TEXT, null, null,
						8),
				new PLMXlsxRptColumn("description", "Description",
						FormatType.TEXT, null, null, 35),
				new PLMXlsxRptColumn("state", "State", FormatType.TEXT, null,
						null, 20),
				new PLMXlsxRptColumn("qty", "Quantity", FormatType.TEXT, null,
						null, 12),
				new PLMXlsxRptColumn("ruleType", "Rule Type", FormatType.TEXT),
				new PLMXlsxRptColumn("ruleExp", "Rule Expression",
						FormatType.TEXT),
				new PLMXlsxRptColumn("partFamily", "Part Family",
						FormatType.TEXT) };

		excelUtil.export(searchResultList, reportColumns, fileName, fileName,
				true, critcolumns, plmWhereUsedData);
		LOG.info("Exiting downloadWhereUsedConfFOCExcel Method");
	}

	/**
	 * This method is used for Generating Where Used Configuration
	 * Features/Options by Contract Report in CSV
	 * 
	 * @throws PLMCommonException
	 */

	public void createDownloadConfFOCCSV() throws PLMCommonException {

		LOG.info("Entering createDownloadConfFOCCSV Method");
		String reportName = "ConfFeatureOption";
		String fileName = "ConfFeatureOption";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);

		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy",
				Locale.ENGLISH);

		// Export to CSV for Where used Configuration Option Report

		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
				new PLMCsvRptColumn("contractName", "Contract Name",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("cusName", "Customer Name",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("model", "Model", FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("name", "Name", FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("mktFeatureNm", "Marketing Name",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("type", "Type", FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("rev", "Rev", FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("description", "Description",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("state", "State", FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("qty", "Quantity", FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("ruleType", "Rule Type", FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("ruleExp", "Rule Expression",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("partFamily", "Part Family",
						FormatTypeCsv.TEXT) };

		csvUtil.exportCsv(searchResultList, reportColumns, fileName,
				dateFormat, false, null, null, ",");

		LOG.info("Exiting createDownloadConfFOCCSV Method");

	}

	/**
	 * This method is used to download excel for Where Used - Top Level
	 * Implosion report (SBOM tab)
	 * 
	 * @throws PLMCommonException
	 */

	public void downloadWhereUsedSBomExcel() throws PLMCommonException {
		LOG.info("Entering downloadWhereUsedSBomExcel Method");
		String reportName = "whereUsedSBoMExcel";
		String fileName = "whereUsedSBoMExcel";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();

		// Export to Excel for Where used SBOM Report
		PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
				new PLMXlsxRptColumn("turbnNUm", "ML/MPL Number",
						FormatType.TEXT, null, null, 18),
				new PLMXlsxRptColumn("srlNum1", "Serial Number",
						FormatType.TEXT),
				new PLMXlsxRptColumn("mli", "MLI", FormatType.TEXT),
				new PLMXlsxRptColumn("newItem", "New Item", FormatType.TEXT),
				new PLMXlsxRptColumn("oldItem", "Old Item", FormatType.TEXT),
				new PLMXlsxRptColumn("descript", "Description",
						FormatType.TEXT, null, null, 25),
				new PLMXlsxRptColumn("dtent", "Date Entered", FormatType.TEXT),
				new PLMXlsxRptColumn("authen", "Auth ECN", FormatType.TEXT),
				new PLMXlsxRptColumn("qty1", "Quantity", FormatType.TEXT),
				new PLMXlsxRptColumn("orign", "Orign", FormatType.TEXT) };
		excelUtil.export(sbomDataList, reportColumns, fileName, fileName,
				false, null, plmWhereUsedData);
		LOG.info("Exiting downloadWhereUsedSBomExcel Method");
	}

	/**
	 * This method is used to download excel for Where Used - Top Level
	 * Implosion report (EBOM tab)
	 * 
	 * @throws PLMCommonException
	 */

	public void downloadWhereUsedEBomExcel() throws PLMCommonException {
		LOG.info("Entering downloadWhereUsedEBomExcel Method");
		String reportName = "whereUsedEBoMExcel";
		String fileName = "whereUsedEBoMExcel";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();

		// Export to Excel for Where used EBOM Report
		PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
				new PLMXlsxRptColumn("topLvlParentNm", "Top Lvl Parent",
						FormatType.TEXT, null, null, 18),
				new PLMXlsxRptColumn("topLvlParentRev", "Top Lvl Parent Rev",
						FormatType.TEXT),
				new PLMXlsxRptColumn("immediateParent", "Immediate Parent",
						FormatType.TEXT, null, null, 18),
				new PLMXlsxRptColumn("immediateParentRev",
						"Immediate Parent Rev", FormatType.TEXT),
				new PLMXlsxRptColumn("partNm", "Part Name", FormatType.TEXT),
				new PLMXlsxRptColumn("partDesc", " Part Desc", FormatType.TEXT,
						null, null, 25),
				new PLMXlsxRptColumn("lvl", "Level", FormatType.TEXT) };
		excelUtil.export(ebomDataList, reportColumns, fileName, fileName,
				false, null, plmWhereUsedData);
		LOG.info("Exiting downloadWhereUsedEBomExcel Method");
	}
	
	
	
	/**
	 * This method is used to download excel for Where Used - Top Level
	 * Implosion report (RPDM tab)
	 * 
	 * @throws PLMCommonException
	 */
	public void downloadWhereUsedRpdmExcel() throws PLMCommonException {
		LOG.info("Entering downloadWhereUsedEBomExcel Method");
		String reportName = "whereUsedRpdmExcel";
		String fileName = "whereUsedRpdmExcel";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();

		// Export to Excel for Where used EBOM Report
		PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
				new PLMXlsxRptColumn("systemId", "System_id",FormatType.TEXT, null, null, 18),
				new PLMXlsxRptColumn("systemName", "System_name",FormatType.TEXT),
				new PLMXlsxRptColumn("bomLevel", "Bom Level", FormatType.TEXT),
				new PLMXlsxRptColumn("className", "Class Name",FormatType.TEXT, null, null, 18),
				new PLMXlsxRptColumn("relType","Rel Type", FormatType.TEXT),
				new PLMXlsxRptColumn("parentName", "Parent Name", FormatType.TEXT),
				new PLMXlsxRptColumn("parentTextName", "Parent Description", FormatType.TEXT),
				new PLMXlsxRptColumn("childName", "Child Name", FormatType.TEXT),
				new PLMXlsxRptColumn("childRev", "Child Rev", FormatType.TEXT),
				new PLMXlsxRptColumn("textName", "Child Description", FormatType.TEXT),
				new PLMXlsxRptColumn("languageCode", "Language Code", FormatType.TEXT),
				new PLMXlsxRptColumn("t4refPartNumber", "T4 Ref.Part#", FormatType.TEXT) ,
				new PLMXlsxRptColumn("t4refPartRev", "T4 Ref.Part Rev", FormatType.TEXT)};
			excelUtil.export(rpdmDataList, reportColumns, fileName, fileName,
				false, null, plmWhereUsedData);
		LOG.info("Exiting downloadWhereUsedEBomExcel Method");
	}
	
	
	
	

	/**
	 * This method is used to download excel for Where Used - Top Level
	 * Implosion report (COPICS tab)
	 * 
	 * @throws PLMCommonException
	 */

	public void downloadWhereUsedCopicsExcel() throws PLMCommonException {
		LOG.info("Entering downloadWhereUsedCopicsExcel Method");
		String reportName = "WhereUSedCopics";
		String fileName = "WhereUSedCopics";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();

		// Export to Excel for Where used Copics Report

		PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
				new PLMXlsxRptColumn("parentItem1", "Top Lvl Parent",
						FormatType.TEXT),
				new PLMXlsxRptColumn("imdtParentItem", "Immediate Parent",
						FormatType.TEXT),
				new PLMXlsxRptColumn("srlNum", "Serial Number", FormatType.TEXT),
				new PLMXlsxRptColumn("status1", "Status", FormatType.TEXT) };
		excelUtil.export(copicsDataList, reportColumns, fileName, fileName,
				false, null, plmWhereUsedData);

		LOG.info("Exiting downloadWhereUsedCopicsExcel Method");
	}

	/**
	 * This method is used to download excel for Requirements-Where Used(CM&U)
	 * Report
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */

	public void downloadWhereUsedRCMUExcel() throws PLMCommonException {
		LOG.info("Entering downloadWhereUsedRCMUExcel Method");
		String reportName = "Requirements-Where-Used(CM&U)";
		String fileName = "Requirements-Where-Used(CM&U)";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();

		// Export to Excel for Where used Requirement Report

		PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] {
				new PLMXlsxRptColumn("requirementName", "Requirement Name",
						FormatType.TEXT),
				new PLMXlsxRptColumn("userSerialNumber", "Unit Serial Number",
						FormatType.TEXT),
				new PLMXlsxRptColumn("selFrameListDb", "Frame Type",
						FormatType.TEXT),

				new PLMXlsxRptColumn("contractStartDate",
						"Contract Start Date (From)", FormatType.DATE),
				new PLMXlsxRptColumn("contractEndDate",
						"Contract Start Date (To)", FormatType.DATE),
				new PLMXlsxRptColumn("fmissueStrDate",
						"FMI Issued Date (From)", FormatType.DATE),
				new PLMXlsxRptColumn("fmissueEndDate", "FMI Issued Date (To)",
						FormatType.DATE) };

		PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
				new PLMXlsxRptColumn("program", "Program Name",
						FormatType.TEXT, null, null, 27),
				new PLMXlsxRptColumn("contract", "Contract Name",
						FormatType.TEXT),
				new PLMXlsxRptColumn("contractDesc", "Contract Description",
						FormatType.TEXT, null, null, 27),
				new PLMXlsxRptColumn("contractStrDt", "Contract Start Date",
						FormatType.TEXT),
				new PLMXlsxRptColumn("clin", "Hardware CLIN", FormatType.TEXT),
				new PLMXlsxRptColumn("ciDesc", "CI Description",
						FormatType.TEXT),
				new PLMXlsxRptColumn("frameType", "Frame Type", FormatType.TEXT),
				new PLMXlsxRptColumn("fmiIssuDt", "FMI Issued Date",
						FormatType.TEXT),
				new PLMXlsxRptColumn("build", "Build", FormatType.TEXT),
				new PLMXlsxRptColumn("unitSerialNum", "Unit Serial Number",
						FormatType.TEXT),
				new PLMXlsxRptColumn("projectName", "Project Name",
						FormatType.TEXT),
				new PLMXlsxRptColumn("projectState", "Project State",
						FormatType.TEXT),
				new PLMXlsxRptColumn("projectDesc", "Project Description",
						FormatType.TEXT, null, null, 27),
				new PLMXlsxRptColumn("prsName", "PRS Name", FormatType.TEXT),
				new PLMXlsxRptColumn("prsRev", "PRS Rev", FormatType.TEXT),
				new PLMXlsxRptColumn("requireName", "Requirement Name",
						FormatType.TEXT),
				new PLMXlsxRptColumn("requireRev", "Requirement Revision",
						FormatType.TEXT),
				new PLMXlsxRptColumn("reqDesc", "Requirement Description",
						FormatType.TEXT, null, null, 27) ,
				new PLMXlsxRptColumn("salesOrder", "Sales Order",
						FormatType.TEXT, null, null, 27) };

		excelUtil.export(whereUsedReqList, reportColumns, fileName, fileName,
				true, critcolumns, plmWhereUsedReqData);
		LOG.info("Exiting downloadWhereUsedRCMUExcel Method");
	}

	/**
	 * This method is used for Generating Requirements-Where Used(CM&U) Report
	 * in CSV
	 * 
	 * @throws PLMCommonException
	 */

	public void createDownloadRCMUCSV() throws PLMCommonException {
		LOG.info("Entering downloadWhereUsedRCMUExcel Method");
		String reportName = "Requirements-Where-Used(CM&U)";
		String fileName = "Requirements-Where-Used(CM&U)";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);

		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy",
				Locale.ENGLISH);

		// Export to CSV for Where used Requirement Report

		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
				new PLMCsvRptColumn("program", "Program Name",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("contract", "Contract Name",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("contractDesc", "Contract Description",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("contractStrDt", "Contract Start Date",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("clin", "Hardware CLIN", FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("ciDesc", "CI Description",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("frameType", "Frame Type",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("fmiIssuDt", "FMI Issued Date",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("build", "Build", FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("unitSerialNum", "Unit Serial Number",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("projectName", "Project Name",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("projectState", "Project State",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("projectDesc", "Project Description",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("prsName", "PRS Name", FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("prsRev", "PRS Rev", FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("requireName", "Requirement Name",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("requireRev", "Requirement Revision",
						FormatTypeCsv.TEXT),
				new PLMCsvRptColumn("reqDesc", "Requirement Description",
						FormatTypeCsv.TEXT), 
				new PLMCsvRptColumn("salesOrder", "Sales Order",
						FormatTypeCsv.TEXT) };

		csvUtil.exportCsv(whereUsedReqList, reportColumns, fileName,
				dateFormat, false, null, null, ",");

		LOG.info("Exiting downloadWhereUsedRCMUExcel Method");
	}

	/**
	 * Generates the Where Used Search List and sends a mail to the logged in
	 * user.
	 * 
	 * @return String
	 * @throws PLMCommonException
	 * @throws PWiException 
	 */
	public String generateWhereUsedBMTIMail() throws PLMCommonException, PWiException {
		String vldtMsg = validateWhereUsedBMTI();
		if (PLMUtils.isEmpty(vldtMsg)) {
			userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
			alertMessage = alertMessage + PLMConstants.Embom_Mail_Msg;
			taskExecutor.execute(new LOUMailThread());
		}
		return PLMConstants.WHERE_USED_REPORT;
	}

	/**
	 * This method is used for rvalidateWhereUsedBMTI
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String validateWhereUsedBMTI() throws PLMCommonException {
		LOG.info("Inside WhereUSed Bean - validateWhereUsedBMTI method");
		partNumber = plmWhereUsedData.getPartNumber();
		/* try { */
		if (PLMUtils.isEmpty(partNumber)) {
			alertMessage = PLMConstants.ALERT_WHERE_USED_NULL_PARTNUMBER;
			LOG.info("The Alert Message is : " + alertMessage);
		} else if (partNumber.length() < 5) {
			alertMessage = PLMConstants.ALERT_WHERE_USED_PARTNUMBER_LENGTH;
		} else if (!PLMUtils.checkForSpecialCharsInWhereUsed(partNumber)) {
			alertMessage = PLMConstants.ALERT_WHERE_USED_SPECIAL_CHARS;
			;
		} else if (partNumber.contains("*") && partNumber.contains("%")) {
			alertMessage = PLMConstants.ALERT_WHERE_USED_VALIDATION1;
		} else if (partNumber.contains("*")) {
			int index = partNumber.indexOf('*');
			partNumber = partNumber.substring(index + 1);

			if (partNumber.contains("*")) {
				LOG.info("Part Number contains 2nd * !");
				alertMessage = PLMConstants.ALERT_WHERE_USED_VALIDATION2;
				LOG.info("The Alert Message for 2nd * is : " + alertMessage);
			}
		} else if (partNumber.contains("%")) {
			int index = partNumber.indexOf('%');
			partNumber = partNumber.substring(index + 1);
			LOG.info("Part Number sub string: " + partNumber);
			if (partNumber.contains("%")) {
				LOG.info("Part Number contains 2nd %");
				alertMessage = PLMConstants.ALERT_WHERE_USED_VALIDATION3;
			}
		}
		/*
		 * } catch(Exception e) { LOG.log(Level.ERROR,
		 * "Exception in validateWhereUsedBMTI method : ", e); }
		 */
		return alertMessage;
	}

	/**
	 * This method is used for sendLOUReportThroughMail
	 * 
	 */
	public void sendLOUReportThroughMail() {
		String successMsg = "";
		String from = PLMConstants.WHERE_USED_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.WHERE_USED_LOU_MAIL_SUBJECT + partNumber;
		String mailContent = toAddressee
				+ PLMConstants.WHERE_USED_LOU_MAIL_CONTENT + partNumber + "."
				+ PLMConstants.WHERE_USED_LOU_MAIL_SIGNATURE;
		String filePathXLS = resourceBundle.getString("OFFLINE_RPT_DIR")
				+ resourceBundle.getString("WHERUSED_LOU_REPORT_NAME") + " "
				+ partNumber + ".xls";
		String signature = PLMConstants.WHERE_USED_LOU_MAIL_SIGNATURE;
		try {
			whereUsedLOUSearchList = plmWhereUsedService
					.getWhereUsedLOUReport(partNumber);
			saveWhereUsedExcelFile();
			PLMUtils.sendMailWithAttachment(from, to, subject, mailContent,
					filePathXLS);

		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendLOUReportThroughMail: ",
					exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(), from, to,
					subject, toAddressee, signature);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendLOUReportThroughMail: ",
					exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(), from, to,
					subject, toAddressee, signature);
		}
		if (PLMUtils.isEmpty(successMsg)) {
			LOG.info("Mail sent successfully.");
		}
	}

	/**
	 * This method is used for setBorderStyle
	 * 
	 * @param style
	 * @throws HSSFCellStyle
	 */
	private HSSFCellStyle setBorderStyle(HSSFCellStyle style) {
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		return style;
	}

	/**
	 * This method is used for setBorderStyle
	 * 
	 * @param style
	 * @throws HSSFCellStyle
	 */
	public void saveWhereUsedExcelFile() throws Exception {
		String filePath = resourceBundle.getString("OFFLINE_RPT_DIR")
				+ resourceBundle.getString("WHERUSED_LOU_REPORT_NAME") + " "
				+ partNumber + ".xls";
		// String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		FileOutputStream fileOut = null;
		boolean createFileExist;
		boolean sameParentChildFlag = false;
		try {
			/*
			 * File file = new File(fileDir); boolean dirExists = file.exists();
			 * if (!dirExists) { file.mkdir(); }
			 */
			File fileName = new File(filePath);
			boolean fileExist = fileName.exists();
			if (!fileExist) {
				createFileExist = fileName.createNewFile();
				LOG.info("createFileExist>>>>.." + createFileExist);
			}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePath);
				HSSFWorkbook workbook = new HSSFWorkbook();
				HSSFSheet sheet = workbook.createSheet(partNumber);

				HSSFCellStyle headerStyle = workbook.createCellStyle();

				headerStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
				headerStyle.setFillForegroundColor(HSSFColor.YELLOW.index);
				headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

				HSSFFont font = workbook.createFont();
				font.setFontName("GE Inspira");
				font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headerStyle = setBorderStyle(headerStyle);
				headerStyle.setFont(font);

				HSSFCellStyle contentStyle = workbook.createCellStyle();
				HSSFFont nonBoldFont = workbook.createFont();
				font.setFontName("GE Inspira");
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(nonBoldFont);

				HSSFCellStyle cellBoldStyle = workbook.createCellStyle();
				cellBoldStyle = setBorderStyle(cellBoldStyle);
				cellBoldStyle.setFont(font);

				HSSFCellStyle titleStyle = workbook.createCellStyle();
				titleStyle
						.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
				titleStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				HSSFFont colFont = workbook.createFont();
				colFont.setFontName("GE Inspira");
				colFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				colFont.setColor(HSSFColor.DARK_RED.index);
				titleStyle.setFont(colFont);

				int rowcount = -1;

				if (!PLMUtils.isEmptyList(whereUsedLOUSearchList)) {
					String searchCriteria = "Part Number/Document Number : ";
					String searchCriteriaValue = partNumber;
					String[] colNames = { "Dwg #", "Title", "MLI#/TF#/CI#",
							"Parent Pin #", "Qty" };

					HSSFRow row = sheet.createRow(++rowcount);
					HSSFCell cell = row.createCell(0);
					cell.setCellValue(searchCriteria);
					cell.setCellStyle(cellBoldStyle);

					cell = row.createCell(1);
					cell.setCellValue(searchCriteriaValue);
					cell.setCellStyle(cellBoldStyle);

					row = sheet.createRow(++rowcount);
					row = sheet.createRow(++rowcount);

					for (int i = 0; i < colNames.length; i++) {
						cell = row.createCell(i);
						cell.setCellValue(colNames[i]);
						cell.setCellStyle(headerStyle);
					}

					for (int i = 0; i < whereUsedLOUSearchList.size(); i++) {
						PLMWhereUsedData dataObj = (PLMWhereUsedData) whereUsedLOUSearchList
								.get(i);
						HSSFCellStyle cellStyle;
						if (!dataObj.isInvalidData()) {

							if (dataObj.isBomHeader()) {
								cellStyle = titleStyle;
							} else {
								cellStyle = contentStyle;
							}

							row = sheet.createRow(++rowcount);

							if (dataObj.isBomHeader()) {
								cell = row.createCell(0);
								cell.setCellValue("");
								cell.setCellStyle(cellStyle);
								cell = row.createCell(1);
								cell.setCellValue(dataObj.getDwgNo());
								cell.setCellStyle(cellStyle);
								cell = row.createCell(2);
								cell.setCellValue("");
								cell.setCellStyle(cellStyle);
								cell = row.createCell(3);
								cell.setCellValue("");
								cell.setCellStyle(cellStyle);
								cell = row.createCell(4);
								cell.setCellValue("");
								cell.setCellStyle(cellStyle);
								continue;
							} else {
								cell = row.createCell(0);
								cell.setCellValue(dataObj.getDwgNo());
							}

							if (dataObj.getDwgNo() != null
									&& dataObj.getDwgNo().equals(partNumber)) {
								cell.setCellStyle(cellBoldStyle);
							} else {
								cell.setCellStyle(cellStyle);
							}

							cell = row.createCell(1);
							cell.setCellStyle(cellStyle);
							cell.setCellValue(dataObj.getDwgTitle());

							cell = row.createCell(2);
							cell.setCellStyle(cellStyle);
							cell.setCellValue(dataObj.getMliCode());

							cell = row.createCell(3);
							cell.setCellStyle(cellStyle);
							cell.setCellValue(dataObj.getParentPin());

							cell = row.createCell(4);
							cell.setCellStyle(cellStyle);
							cell.setCellValue(dataObj.getQuantity());

						} else {
							sameParentChildFlag = true;
						}
					}

					row = sheet.createRow(++rowcount);
					row = sheet.createRow(++rowcount);

					if (sameParentChildFlag) {
						cell = row.createCell(0);
						cell.setCellValue(PLMConstants.WHERE_USED_CHILD_IS_PARENT_LIST);
						cell.setCellStyle(headerStyle);
						for (int i = 0; i < whereUsedLOUSearchList.size(); i++) {
							PLMWhereUsedData dataObj = (PLMWhereUsedData) whereUsedLOUSearchList
									.get(i);
							if (dataObj.isInvalidData()) {
								if (!PLMUtils.isEmpty(dataObj.getInvalidBom())) {
									row = sheet.createRow(++rowcount);
									cell = row.createCell(0);
									cell.setCellValue(dataObj.getInvalidBom());
									cell.setCellStyle(contentStyle);
								}
							}
						}
					}
					sheet.autoSizeColumn(0);
					sheet.autoSizeColumn(1);
					sheet.autoSizeColumn(2);
					sheet.autoSizeColumn(3);
					sheet.autoSizeColumn(4);
				} else {
					HSSFRow row = sheet.createRow(++rowcount);
					HSSFCell cell = row.createCell(0);
					String noRecordMsg = PLMConstants.WHERE_USED_LOU_NO_RECORD_FOUND
							+ partNumber;
					cell.setCellValue(noRecordMsg);
					cell.setCellStyle(titleStyle);
					sheet.autoSizeColumn(0);
				}
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveWhereUsedExcelFile: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveWhereUsedExcelFile: ", e);
			throw e;
		} finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveWhereUsedExcelFile: ", e);
				throw e;
			}
		}
	}

	/**
	 * Populates the Where Used Search List
	 * 
	 * @return String
	 * @param partNumber
	 * @throws PLMCommonException
	 */
	private String populateWhereUsedSearchList() throws PLMCommonException {
		String fwdflag = "";
		try {
			whereUsedLOUSearchList = plmWhereUsedService
					.getWhereUsedData(partNumber);
			if (PLMUtils.isEmptyList(whereUsedLOUSearchList)) {
				LOG.info("Invalid Where Used Search");
				recordCount = 0;
				totalRecCount = 0;
				fwdflag = PLMConstants.WHERE_USED_NORECORDS;
			} else {
				LOG.info("Valid Where Used Search");
				recordCount = PLMConstants.N_100;
				totalRecCount = whereUsedLOUSearchList.size();
				totalRecCountMsg = "# of Records for Dwg # " + partNumber
						+ " is : " + totalRecCount;
				fwdflag = PLMConstants.WHERE_USED_REPORT;
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@populateWhereUsedSearchList: ",
					exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "whereUsedSearch",
					"Where Used - Top Level Implosion");
		}
		LOG.info("The Total Record Count is : " + totalRecCount);
		return fwdflag;
	}

	/**
	 * Load The Where Used Search Page
	 * 
	 * @return String
	 */
	public String loadWhereUsedPage() {
		LOG.info("Entering into WhereUsedMB loadWhereUsedPage()...");
		String fwdFlag = "";
		alertMsgValidWu="";
		partNumList = new ArrayList<String>();
		plmWhereUsedData = new PLMWhereUsedData();
		fwdFlag = PLMConstants.WHERE_USED_SEARCH;
		resetTopLvlImplosionData();
		try {
			commonMB.insertCannedRptRecordHitInfo("Where Used - Top Level Implosion");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			commonMB.getLegacyDateStamp();
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getLegacyDateStamp: ", exception);
		}
		LOG.info("Exiting from WhereUsedMB loadWhereUsedPage()...");

		return fwdFlag;
	}

	// added by Lakshmi For UseCase-16 Where Used PLM MF/TF Report
	/**
	 * Load The Where Used Search Page
	 * 
	 * @return String
	 */
	public String loadWhereUsedMFTF() {
		LOG.info("Entering into WhereUsedMB loadWhereUsedMFTF()...");
		String fwdFlag = "";
		alertMsgWu = PLMConstants.EMPTY_STRING;
		try {
			commonMB.insertCannedRptRecordHitInfo("Where Used Configuration Features/Options By Contract");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			plmWhereUsedData = new PLMWhereUsedData();
			Map<String, List<SelectItem>> dropdownlist = plmWhereUsedService
					.getMFTFDropDownValues();
			stateListData = ((List<SelectItem>) dropdownlist.get("mftfstate"));
			typeListData = ((List<SelectItem>) dropdownlist.get("mftfType"));
			fwdFlag = PLMConstants.MFTF_SEARCH_PAGE_FORWORD;
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadWhereUsedPage: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "home",
					"Where Used Configuration Features / Options by Contract");
		}
		LOG.info("Exiting from WhereUsedMB loadWhereUsedMFTF()...");
		return fwdFlag;
	}

	/**
	 * This method is used for getMFTFSearchData
	 * 
	 * @return String
	 */
	public String getMFTFSearchData() {
		String fwdFlag = "";
		LOG.info("Entering getMFTFSearchData() method");
		LOG.info("plmWhereUsedData.getMkttchFeatureNm()====> "
				+ plmWhereUsedData.getMkttchFeatureNm());
		alertMsgWu = PLMConstants.EMPTY_STRING;
		alertMsgWu = validateMFTFSearchData();
		/*
		 * if(PLMUtils.isEmpty(alertMsg)){ fwdFlag = "mftfSearchReport"; }
		 */
		try {

			if (PLMUtils.isEmpty(alertMsgWu)) {
				plmWhereUsedData
						.setSelectedTypeExl(plmWhereUsedData
								.getMkttchFeatureNm().equalsIgnoreCase(
										"Marketing") ? "Conf Feature/Option"
								: "HW/SW Feature / CI");
				searchResultList = plmWhereUsedService
						.getMFTFSearchData(plmWhereUsedData);
				if (!PLMUtils.isEmptyList(searchResultList)) {
					LOG.info("valid task Search");
					totalRecCount = searchResultList.size();
					recordCount = PLMConstants.N_100;
					fwdFlag = PLMConstants.MFTF_REPORT_FORWORD;
					totalRecCountMsg = "Total Results Count : " + totalRecCount;
					LOG.info("Total Results Count : " + totalRecCount);
				} else {
					LOG.info("No records");
					fwdFlag = PLMConstants.MFTF_INVALID_FORWORD;
				}
			}

		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getTaskSearchData: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "whereUsedmfTFReportSearch",
					"Where Used Configuration Features / Options by Contract");
		}

		// return fwdFlag;
		return fwdFlag;

	}

	/**
	 * This method is used for validateMFTFSearchData
	 * 
	 * @return String
	 */
	public String validateMFTFSearchData() {
		try {
			if (PLMUtils.isEmpty(plmWhereUsedData.getDescription())
					&& PLMUtils.isEmpty(plmWhereUsedData.getName())
					&& PLMUtils.isEmptyList(plmWhereUsedData.getMfTfTypeList()))

			{
				alertMsgWu = PLMConstants.SEARCH_CRITERIA;
				LOG.info("Please enter any criteria and click on search");
			} else {
				/*
				 * if
				 * (!PLMUtils.checkForSpecialCharsForTaskSearch(plmWhereUsedData
				 * .getMktFeatureNm())) { alertMsg = alertMsg +
				 * PLMConstants.MARKETING_MESSAGE; } if
				 * (!PLMUtils.checkForSpecialCharsForTaskSearch
				 * (plmWhereUsedData.getTchFeatureNm())) { alertMsg = alertMsg +
				 * PLMConstants.TECHINCAL_MESSAGE; }
				 */
				if (!PLMUtils
						.checkForSpecialCharsForTaskSearch(plmWhereUsedData
								.getDescription())) {
					alertMsgWu = alertMsgWu + PLMConstants.DESCRIPTION_MESSAGE;
				}
				if (!PLMUtils
						.checkForSpecialCharsForTaskSearch(plmWhereUsedData
								.getName())) {
					alertMsgWu = alertMsgWu + PLMConstants.CONTRACTOR_MESSAGE;
				}
			}

		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@validateMFTFSearchData: ",
					exception);
			LOG.info("Error :" + exception.getMessage());
		}
		return alertMsgWu;
	}

	// Start added method for Where Used Requirement

	/**
	 * This method is used for whereUsedReqHome
	 * 
	 * @return String
	 * @param PLMCommonException
	 */
	public String whereUsedReqHome() throws PLMCommonException {
		String flgFwd = "whereUsedReqSearch";
		alertMsgWu = "";
		plmWhereUsedReqData = new PLMWhereUsedReqData();
		try {
			commonMB.insertCannedRptRecordHitInfo("CMU Requirements-Where Used(CM&U)");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			dropdownframelist = plmWhereUsedService.getFramTypeList();
			frameList = ((List<SelectItem>) dropdownframelist.get("frame"));
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadWhereUsedReportHome: ",
					exception);
		}
		return flgFwd;

	}

	/**
	 * This method is used for resetWhereUsedReq
	 * 
	 * @return String
	 */
	public String resetWhereUsedReq() {
		String flgFwd = "whereUsedReqSearch";
		contratStrDt = "";
		contratEndDt = "";
		fmiIssStrDt = "";
		fmiIssEndDt = "";
		selFrameList = "";
		alertMsgWu = "";
		wildCardReqrmnt = "";
		wildCardSerlNo = "";
		plmWhereUsedReqData = new PLMWhereUsedReqData();
		return flgFwd;
	}

	/**
	 * This method is used for validateWhereUsedReqData
	 * 
	 * @return String
	 */
	public String validateWhereUsedReqData() throws PLMCommonException {
		alertMsgWu = "";
		final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
				"MM/dd/yyyy");
		// try {
		if (PLMUtils.isEmpty(plmWhereUsedReqData.getRequirementName())
				&& PLMUtils.isEmpty(plmWhereUsedReqData.getUserSerialNumber())
				&& PLMUtils.isEmptyDate(plmWhereUsedReqData
						.getContractStartDate())
				&& PLMUtils.isEmptyDate(plmWhereUsedReqData
						.getContractEndDate())
				&& PLMUtils
						.isEmptyDate(plmWhereUsedReqData.getFmissueStrDate())
				&& PLMUtils
						.isEmptyDate(plmWhereUsedReqData.getFmissueEndDate())
				&& PLMUtils.isEmptyList(plmWhereUsedReqData.getFrameTypeList())) {
			alertMsgWu = PLMConstants.SEARCH_CRITERIA;
			LOG.info("Please enter any criteria and click on search");
		} else if ((!PLMUtils.isEmptyDate(plmWhereUsedReqData
				.getContractStartDate()) && PLMUtils
				.isEmptyDate(plmWhereUsedReqData.getContractEndDate()))
				|| (PLMUtils.isEmptyDate(plmWhereUsedReqData
						.getContractStartDate()) && !PLMUtils
						.isEmptyDate(plmWhereUsedReqData.getContractEndDate()))) {
			alertMsgWu = PLMConstants.WHERE_USED_NULL_CONTRACT_DATE;
		} else if ((!PLMUtils.isEmptyDate(plmWhereUsedReqData
				.getFmissueStrDate()) && PLMUtils
				.isEmptyDate(plmWhereUsedReqData.getFmissueEndDate()))
				|| (PLMUtils.isEmptyDate(plmWhereUsedReqData
						.getFmissueStrDate()) && !PLMUtils
						.isEmptyDate(plmWhereUsedReqData.getFmissueEndDate()))) {
			alertMsgWu = PLMConstants.WHERE_USED_NULL_FMI_DATE;
		}

		else if (PLMUtils.checkForFromAndToDate(
				plmWhereUsedReqData.getContractStartDate(),
				plmWhereUsedReqData.getContractEndDate())) {
			alertMsgWu = PLMConstants.WHERE_USED_DATE;
		} else if (PLMUtils.checkForFromAndToDate(
				plmWhereUsedReqData.getFmissueStrDate(),
				plmWhereUsedReqData.getFmissueEndDate())) {
			alertMsgWu = PLMConstants.WHERE_USED_DATE;
		}

		else if (PLMUtils.checkSplCharsProjSumry(plmWhereUsedReqData
				.getRequirementName())
				|| PLMUtils.checkSplCharsProjSumry(plmWhereUsedReqData
						.getUserSerialNumber())) {
			alertMsgWu = PLMConstants.WHERE_USED_SPL_CRITERIA;
		}

		if (!PLMUtils.isEmptyDate(plmWhereUsedReqData.getContractStartDate())
				&& !PLMUtils.isEmptyDate(plmWhereUsedReqData
						.getContractEndDate())) {
			contratStrDt = SIMPLE_DATE_FORMAT.format(plmWhereUsedReqData
					.getContractStartDate());
			contratEndDt = SIMPLE_DATE_FORMAT.format(plmWhereUsedReqData
					.getContractEndDate());
		}
		if (!PLMUtils.isEmptyDate(plmWhereUsedReqData.getFmissueStrDate())
				&& !PLMUtils.isEmptyDate(plmWhereUsedReqData
						.getFmissueEndDate())) {
			fmiIssStrDt = SIMPLE_DATE_FORMAT.format(plmWhereUsedReqData
					.getFmissueStrDate());
			fmiIssEndDt = SIMPLE_DATE_FORMAT.format(plmWhereUsedReqData
					.getFmissueEndDate());
			// }

		}/*
		 * catch (Exception exception) { LOG.log(Level.ERROR,
		 * "Exception@validateWhereUsedRptData: ", exception);
		 * LOG.info("Error :" + exception.getMessage()); }
		 */
		return alertMsgWu;
	}

	/**
	 * This method is used for getWhereUsedRequirementData
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getWhereUsedRequirementData() {
		String fwdFlag = "";
		alertMsgWu = "";
		plmWhereUsedReqData.setSelFrameListDb("");
		selFrameList = "";
		contratStrDt = "";
		contratEndDt = "";
		fmiIssStrDt = "";
		fmiIssEndDt = "";
		wildCardReqrmnt = "";
		wildCardSerlNo = "";

		try {
			alertMsgWu = validateWhereUsedReqData();

			if (PLMUtils.isEmpty(alertMsgWu)) {
				whereUsedReqList = plmWhereUsedService
						.getWhereUsedReqData(plmWhereUsedReqData);

				if (whereUsedReqList != null) {

					if (plmWhereUsedReqData.getFrameTypeList().size() > 0) {
						selFrameList = getFrameListDtls(whereUsedReqList);
						plmWhereUsedReqData.setSelFrameListDb(selFrameList
								.replace('[', ' ').replace(']', ' ')
								.replace('"', ' '));

					}

					if (plmWhereUsedReqData.getRequirementName() != null
							&& plmWhereUsedReqData.getRequirementName()
									.length() > 0) {
						wildCardReqrmnt = geWilcardReqDtls(plmWhereUsedReqData);
					}

					if (plmWhereUsedReqData.getUserSerialNumber() != null
							&& plmWhereUsedReqData.getUserSerialNumber()
									.length() > 0) {
						wildCardSerlNo = geWilcardUnitSrlDtls(plmWhereUsedReqData);
					}

					whereUsedRprtTotCounts = whereUsedReqList.size();
				} else {
					whereUsedRprtTotCounts = 0;
				}
				totalWhereUSedReportMsg = "Total Records: "
						+ whereUsedRprtTotCounts;
				LOG.info("whereUsedRprtTotCounts::::::::::::::::::"
						+ whereUsedRprtTotCounts);
				if (whereUsedRprtTotCounts == 0) {
					fwdFlag = "invalidWhereUsedReq";
				} else {
					whereUsedReportCounts = PLMConstants.N_100;
					fwdFlag = "whereUsedReqReport";
				}
			} else {
				fwdFlag = "whereUsedReqSearch";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPart: ", exception);
			// throw exception;
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "whereUsedSearch", "whereUsedReqReport");
		}
		return fwdFlag;
	}

	/**
	 * This method is used for getWhereUsedRequirementData
	 * 
	 * @param wildCardReqVal
	 * @return String
	 */
	public String geWilcardReqDtls(PLMWhereUsedReqData wildCardReqVal) {
		StringTokenizer token = new StringTokenizer(
				wildCardReqVal.getRequirementName(), ",");
		List<String> reqValueList = new ArrayList<String>();
		while (token.hasMoreElements()) {
			String reqValue = token.nextToken();
			reqValueList.add(reqValue.trim());
		}

		StringBuilder reqResult = new StringBuilder();

		reqResult.append("\"");
		for (String req : reqValueList) {
			reqResult.append(req);
			reqResult.append(",");
		}
		String finalReqResult = reqResult.length() > 0 ? reqResult.substring(0,
				reqResult.length() - 1) + "\"" : "";

		return finalReqResult;
	}

	/**
	 * This method is used for geWilcardUnitSrlDtls
	 * 
	 * @param wildCardserVal
	 * @return String
	 */

	public String geWilcardUnitSrlDtls(PLMWhereUsedReqData wildCardserVal) {
		StringTokenizer token = new StringTokenizer(
				wildCardserVal.getUserSerialNumber(), ",");
		List<String> serValueList = new ArrayList<String>();
		while (token.hasMoreElements()) {
			String serValue = token.nextToken();
			serValueList.add(serValue.trim());
		}

		StringBuilder serResult = new StringBuilder();

		serResult.append("\"");
		for (String req : serValueList) {
			serResult.append(req);
			serResult.append(",");
		}
		String finalserResult = serResult.length() > 0 ? serResult.substring(0,
				serResult.length() - 1) + "\"" : "";

		return finalserResult;
	}

	/**
	 * This method is used for getFrameListDtls
	 * 
	 * @param whereUsedReqListVal
	 * @return String
	 */
	public String getFrameListDtls(List<PLMWhereUsedReqData> whereUsedReqListVal) {
		Set<String> frameSet = new HashSet<String>();
		List<String> frameListLcl = new ArrayList<String>();

		for (int i = 0; i < whereUsedReqListVal.size(); i++) {
			frameSet.add(whereUsedReqListVal.get(i).getFrameType());
		}
		Iterator<String> itr = frameSet.iterator();

		while (itr.hasNext()) {
			frameListLcl.add(itr.next());
		}
		StringBuilder frameResult = new StringBuilder();

		frameResult.append("\"");
		for (String frm : frameListLcl) {
			frameResult.append(frm);
			frameResult.append(",");
		}
		String finalFrameResult = frameResult.length() > 0 ? frameResult
				.substring(0, frameResult.length() - 1) + "\"" : "";
		return finalFrameResult;
	}

	/**
	 * This method is used for changeWhereUsedReportListner
	 * 
	 * @param event
	 */
	public void changeWhereUsedReportListner(ActionEvent event) {
		LOG.info("Action listner called.....--------------------------->"
				+ whereUsedReportCounts);
		if (whereUsedReportCounts == 100) {
			LOG.info("100");
			whereUsedReportCounts = PLMConstants.N_100;
		} else if (whereUsedReportCounts == 500) {
			LOG.info("500");
			whereUsedReportCounts = 500;
		} else if (whereUsedReportCounts == 1000) {
			LOG.info("1000");
			whereUsedReportCounts = 1000;
		} else if (whereUsedReportCounts == 1500) {
			LOG.info("1500");
			whereUsedReportCounts = 1500;
		} else if (whereUsedReportCounts == 2000) {
			LOG.info("2000");
			whereUsedReportCounts = 2000;
		} else if (whereUsedReportCounts == 3000) {
			LOG.info("3000");
			whereUsedReportCounts = 3000;
		} else if (whereUsedReportCounts == 4000) {
			LOG.info("4000");
			whereUsedReportCounts = 4000;
		} else if (whereUsedReportCounts == 5000) {
			LOG.info("5000");
			whereUsedReportCounts = 5000;
		} else if (whereUsedReportCounts == totalRecCount) {
			LOG.info("All");
			whereUsedReportCounts = totalRecCount;
		}
		LOG.info("final value.....--------------------------->"
				+ whereUsedReportCounts);
	}

	// End added method for Where Used Requirement
	/**
	 * Resets the Part Number
	 * 
	 * @return String
	 */
	public String resetMFTFData() {
		plmWhereUsedData.setMfTfStateList(null);
		plmWhereUsedData.setDescription(PLMConstants.EMPTY);
		plmWhereUsedData.setMfTfTypeList(null);
		plmWhereUsedData.setName(PLMConstants.EMPTY);
		plmWhereUsedData.setMkttchFeatureNm("Marketing");
		alertMsgWu = PLMConstants.EMPTY_STRING;
		return PLMConstants.MFTF_SEARCH_PAGE_FORWORD;
	}

	// end of lakshmi

	// Added by Raju for Where Used - Top Level Implosion
	/**
	 * This method is used for shwWherUsdData
	 * 
	 * @return String
	 */
	public String shwWherUsdData() {
		String fwdFlag = "";
		alertMsgWu = "";
		LOG.info("tliPartNumber----------------->" + tliPartNumber);
		try {
			alertMsgWu = validationForPartNum(tliPartNumber);

			if (PLMUtils.isEmpty(alertMsgWu)) {
				fwdFlag = "whereUsedSearchReport";
				showAllTables = true;
				strCopics = tliPartNumber + " - (COPICS)";
				strSbom = tliPartNumber + "- (SBOM Deviations)";
				strEbom = tliPartNumber + "- (EBOM)";
				strrpdm = tliPartNumber + "- (RPDM SBOM)";
				strNoRcrdsMsgFrCopics = PLMConstants.NO_RECRDS_FOR_COPICS;
				strNoRcrdsMsgFrEbom = PLMConstants.NO_RECRDS_FOR_EBOM;
				strNoRcrdsMsgFrSbom = PLMConstants.NO_RECRDS_FOR_SBOM;
				strNoRcrdsMsgFrRpdm = PLMConstants.NO_RECRDS_FOR_RPDM;
				
				Map<String, List<PLMWhereUsedData>> finalMap = plmWhereUsedService
						.fetchWhrUsdTpLvlImplsnData(tliPartNumber);
				LOG.info("finalMap.size()----------------->" + finalMap.size());
				List<String> keyList = new ArrayList<String>(finalMap.keySet());
				for (int i = 0; i < keyList.size(); i++) {
					if (keyList.get(i).equals("CopicsData")) {
						copicsDataList = finalMap.get(keyList.get(i));
						copicsCounts = copicsDataList.size();
						if (copicsDataList.size() > 0) {
							blnStrCopics = false;
							blnShwCpcsTable = true;
							strTotRcrdsMsgFrCopics = strCopics
									+ " - Total Results : " + copicsCounts;
						} else {
							blnStrCopics = true;
							blnShwCpcsTable = false;
						}
						LOG.info("copicsDataList.size()------------->"
								+ copicsDataList.size());

					}
					if (keyList.get(i).equals("SbomData")) {
						sbomDataList = finalMap.get(keyList.get(i));
						sBoMCounts = sbomDataList.size();
						if (sbomDataList.size() > 0) {
							blnStrSbom = false;
							blnShwSbomTable = true;
							strTotRcrdsMsgFrSbom = strSbom
									+ " - Total Results : " + sBoMCounts;
						} else {
							blnStrSbom = true;
							blnShwSbomTable = false;
						}
						LOG.info("sbomDataList.size()------------->"
								+ sbomDataList.size());
					}
					if (keyList.get(i).equals("ebomData")) {
						ebomDataList = finalMap.get(keyList.get(i));
						eBoMCounts = ebomDataList.size();
						if (ebomDataList.size() > 0) {
							blnStrEbom = false;
							blnShwEbomTable = true;
							strTotRcrdsMsgFrEbom = strEbom
									+ " - Total Results : " + eBoMCounts;
						} else {
							blnStrEbom = true;
							blnShwEbomTable = false;
						}
						LOG.info("ebomDataList.size()------------->"
								+ ebomDataList.size());
					}
					
					if (keyList.get(i).equals("rpdmData")) {
						rpdmDataList = finalMap.get(keyList.get(i));
						rpdmCounts = rpdmDataList.size();
						if (rpdmDataList.size() > 0) {
							blnStrRpdm = false;
							blnShwRpdmTable = true;
							strTotRcrdsMsgFrRpdm = strrpdm
									+ " - Total Results : " + rpdmCounts;
						} else {
							blnStrRpdm = true;
							blnShwRpdmTable = false;
						}
						LOG.info("rpdmDataList.size()------------->"
								+ rpdmDataList.size());
					}
					
					
					
				}
			} else {
				fwdFlag = PLMConstants.WHERE_USED_SEARCH;
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@shwWherUsdData: ", exception);
			LOG.info("Error :" + exception.getMessage());
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "whereUsedSearch",
					"Where Used - Top Level Implosion");
		}
		return fwdFlag;
	}

	public String loadImpactAnalysis() throws PWiException {
		String fwdFlag = "";
		alertMessage = "";

		String partIdLst = (String) PLMUtils.getServletSession(true)
				.getAttribute("WuPartId");
		if (partIdLst != null) {
			String[] partIdArr = partIdLst.split(",");
			if (partIdArr != null) {
				for (int i = 0; i < partIdArr.length; i++) {
					if (!wuPrtIdLst.contains(partIdArr[i]))
						wuPrtIdLst.add(partIdArr[i]);
				}
			}

			wuFlag = (String) PLMUtils.getServletSession(true).getAttribute(
					"wuFlag");
			LOG.info("WU Part Id List Size ---------------------------- "
					+ wuPrtIdLst.size());
			setImpactPartIdLst(wuPrtIdLst);
			PLMUtils.getServletSession(true).removeAttribute("WuPartId");

			LOG.info("impactPartIdLst List Size ---------------------------- "
					+ impactPartIdLst.size());
			if (wuFlag != null && !PLMUtils.isEmpty(wuFlag)) {
				if (impactPartIdLst.size() <= 3) {
					fwdFlag = getImpactAnalysis();
				} else {
					fwdFlag = impctAnlsysOfflnRpt();
					userDataObj1 = (PLMLoginData) PLMUtils.getServletSession(
							true).getAttribute(PLMConstants.SESSION_USER_DATA);
				}
			}
		} else {
			fwdFlag = "invalidImpactReport";
		}
		return fwdFlag;
	}

	public String actionloadImpactAnalysis() throws NumberFormatException,
			PWiException, QueryAccessException {

		String fwdFlag = "";
		alertMessage = "";

		Map<?, ?> parameterMap = BookmarkableLinkUtil.getInstance()
				.getImpactAnalysisParameterMapAttribute(
						FacesContext.getCurrentInstance(), true);

		// Retrieve keyword from parameters
		String partIdLst = BookmarkableLinkUtil.getInstance().getParameter(
				parameterMap, ImpactAnalysisServlet.PARAMETER_SEARCH_PARTID);

		// String partIdLst =
		// (String)PLMUtils.getServletSession(true).getAttribute("WuPartId");
		if (partIdLst != null && partIdLst.length()>0) {
			PLMUtils.getServletSession(true)
					.setAttribute("WuPartId", partIdLst);
			PLMUtils.getServletSession(true).setAttribute("wuFlag", "Y");
			String[] partIdArr = partIdLst.split(",");
			if (partIdArr != null) {
				for (int i = 0; i < partIdArr.length; i++) {
					if (!wuPrtIdLst.contains(partIdArr[i]))
						wuPrtIdLst.add(partIdArr[i]);
				}
			}

			wuFlag = (String) PLMUtils.getServletSession(true).getAttribute(
					"wuFlag");
			LOG.info("WU Part Id List Size ---------------------------- "
					+ wuPrtIdLst.size());
			setImpactPartIdLst(wuPrtIdLst);
			PLMUtils.getServletSession(true).removeAttribute("WuPartId");

			LOG.info("impactPartIdLst List Size ---------------------------- "
					+ impactPartIdLst.size());
			if (wuFlag != null && !PLMUtils.isEmpty(wuFlag)) {
				if (impactPartIdLst.size() <= 3) {
					fwdFlag = getImpactAnalysis();
				} else {
					fwdFlag = impctAnlsysOfflnRpt();
					userDataObj1 = (PLMLoginData) PLMUtils.getServletSession(
							true).getAttribute(PLMConstants.SESSION_USER_DATA);
				}
			}
		} else {
			fwdFlag = "invalidImpactReport";
		}
		return fwdFlag;

	}

	public String getImpactAnalysis() {

		String fwdFlag = "";
		alertMessage = "";
		LOG.info("Inside getImpactAnalysis method of Where Used MB");
		LOG.info("impactPartIdLst ----------------->" + impactPartIdLst);
		impactAnlysMap = new HashMap<String, List<PLMImpactAnalysisData>>();
		ebomimpactList1 = new ArrayList<PLMImpactAnalysisData>();
		ebomimpactList2 = new ArrayList<PLMImpactAnalysisData>();
		ebomimpactList3 = new ArrayList<PLMImpactAnalysisData>();
		mbomimpactList1 = new ArrayList<PLMImpactAnalysisData>();
		mbomimpactList2 = new ArrayList<PLMImpactAnalysisData>();
		mbomimpactList3 = new ArrayList<PLMImpactAnalysisData>();
		ebomimpactCnt1 = 0;
		mbomimpactCnt1 = 0;
		ebomimpactCnt2 = 0;
		mbomimpactCnt2 = 0;
		ebomimpactCnt3 = 0;
		mbomimpactCnt3 = 0;
		List<String> impactPartIdLstLcl = new ArrayList<String>();
		impactPartIdLstLcl.addAll(impactPartIdLst);
		impactPartIdLst.clear();
		wuPrtIdLst.clear();

		try {
			// alertMsgWu = validationForPartNum(tliPartNumber);
			fwdFlag = "impactAnalysisMenuTab";
			// strImpctMsg = "Impact Analysis Report";
			// strImpctNoRecMsg = PLMConstants.NO_RECRDS_FOR_IMPCT;

			if (!PLMUtils.isEmptyList(impactPartIdLstLcl)) {
				impactAnlysMap = plmWhereUsedService
						.getImpactAnalysisForParts(impactPartIdLstLcl);

				for (int i = 0; i < impactPartIdLstLcl.size(); i++) {
					if (i == 0) {
						ebomimpactList1 = impactAnlysMap.get(impactPartIdLstLcl
								.get(i) + "~E");
						mbomimpactList1 = impactAnlysMap.get(impactPartIdLstLcl
								.get(i) + "~M");
						ebomimpactCnt1 = ebomimpactList1.size();
						mbomimpactCnt1 = mbomimpactList1.size();
						ebomResultMsg1 = "EBOM Total Results : "
								+ ebomimpactCnt1;
						mbomResultMsg1 = "MBOM Total Results : "
								+ mbomimpactCnt1;
						 ebomRowCnt1=PLMConstants.N_50;
						 mbomRowCnt1=PLMConstants.N_50;

						if (!PLMUtils.isEmptyList(ebomimpactList1)) {
							partName1 = ebomimpactList1.get(0).getPartNm();
						} else if (!PLMUtils.isEmptyList(mbomimpactList1)) {
							partName1 = mbomimpactList1.get(0).getPartNm();
						}

					} else if (i == 1) {
						ebomimpactList2 = impactAnlysMap.get(impactPartIdLstLcl
								.get(i) + "~E");
						mbomimpactList2 = impactAnlysMap.get(impactPartIdLstLcl
								.get(i) + "~M");
						ebomimpactCnt2 = ebomimpactList2.size();
						mbomimpactCnt2 = mbomimpactList2.size();
						ebomResultMsg2 = "EBOM Total Results : "
								+ ebomimpactCnt2;
						mbomResultMsg2 = "MBOM Total Results : "
								+ mbomimpactCnt2;
						ebomRowCnt2=PLMConstants.N_50;
						mbomRowCnt2=PLMConstants.N_50;
						  
						if (!PLMUtils.isEmptyList(ebomimpactList2)) {
							partName2 = ebomimpactList2.get(0).getPartNm();
						} else if (!PLMUtils.isEmptyList(mbomimpactList2)) {
							partName2 = mbomimpactList2.get(0).getPartNm();
						}
					} else {
						ebomimpactList3 = impactAnlysMap.get(impactPartIdLstLcl
								.get(i) + "~E");
						mbomimpactList3 = impactAnlysMap.get(impactPartIdLstLcl
								.get(i) + "~M");
						ebomimpactCnt3 = ebomimpactList3.size();
						mbomimpactCnt3 = mbomimpactList3.size();
						ebomResultMsg3 = "EBOM Total Results : "
								+ ebomimpactCnt3;
						mbomResultMsg3 = "MBOM Total Results : "
								+ mbomimpactCnt3;
						ebomRowCnt3=PLMConstants.N_50;
						mbomRowCnt3=PLMConstants.N_50;

						if (!PLMUtils.isEmptyList(ebomimpactList3)) {
							partName3 = ebomimpactList3.get(0).getPartNm();
						} else if (!PLMUtils.isEmptyList(mbomimpactList3)) {
							partName3 = mbomimpactList3.get(0).getPartNm();
						}

					}
				}
				if (ebomimpactCnt1 == 0 && ebomimpactCnt2 == 0
						&& ebomimpactCnt3 == 0 && mbomimpactCnt1 == 0
						&& mbomimpactCnt2 == 0 && mbomimpactCnt3 == 0) {
					LOG.info("No EBOM and MBOM Records found for the given Part Ids");
					// alertMessage="No EBOM and MBOM Records found for the given Part Ids";
					fwdFlag = "invalidImpactReport";
				}
				// impactCnt = impactDataLst.size();
				/*
				 * if(impactCnt>0){ strTotRcrdsMsgFrImpct = strImpctMsg
				 * +" - Total Results : " + impactCnt; }else{
				 * strTotRcrdsMsgFrImpct = strImpctNoRecMsg; }
				 * LOG.info("impactDataLst.size()------------->"+impactCnt);
				 * 
				 * } else{ strTotRcrdsMsgFrImpct = strImpctNoRecMsg; }
				 */
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@shwWherUsdData: ", exception);
			LOG.info("Error :" + exception.getMessage());
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "whereUsedSearch", "Impact Analysis Report");
		}
		return fwdFlag;
	}

	public String impctAnlsysOfflnRpt() throws PWiException {
		String fwdFlag = "";
		alertMessage = "";
		LOG.info("Inside impctAnlsysOfflnRpt method of Where Used MB");
		LOG.info("wuPrtIdLst----------------->" + wuPrtIdLst);

		if (!PLMUtils.isEmptyList(impactPartIdLst)) {
			fwdFlag = "impactOffline";
			userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
			//alertMessage = PLMConstants.IMPACTANYIS_ALERT_MAIL;
			taskExecutor.execute(new ImptAnlysThread());
		} else {
			//alertMessage = PLMConstants.IA_MAIL_ERR_MSG;
			fwdFlag = "invalidImpactReport";
		}
		return fwdFlag;
	}

	/**
	 * Level Of Uniqueness Background Process Thread
	 */
	private class ImptAnlysThread implements Runnable {
		public ImptAnlysThread() {
		}

		public void run() {
			sendImpctAnlysRptMail();
		}
	}

	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return String
	 */
	public void sendImpctAnlysRptMail() {
		LOG.info("Entering sendImpctAnlysRptMail Method");
		String from = PLMConstants.IMPACTANYIS_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.IMPACTANYIS_MAIL_FROM_MAIL_SUBJECT;

		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat(
				"yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXlsx = resourceBundle.getString("OFFLINE_RPT_DIR")
				+ resourceBundle.getString("IMPACT_ANALYSIS_RPT_NM") + "_"
				+ uniqTime + ".xlsx";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR")
				+ resourceBundle.getString("IMPACT_ANALYSIS_RPT_NM") + "_"
				+ uniqTime + ".zip";
		File file = null;

		List<String> impactPartIdLstLcl = new ArrayList<String>();
		impactPartIdLstLcl.addAll(impactPartIdLst);
		impactPartIdLst.clear();
		wuPrtIdLst.clear();
		try {
			Map<String, List<PLMImpactAnalysisData>> impactAnlysMapLcl = plmWhereUsedService
					.getImpactAnalysisForParts(impactPartIdLstLcl);
			
			boolean hasRecordsFlg = false;
			if (!PLMUtils.isEmptyMap(impactAnlysMapLcl)) {
				for (Map.Entry<String, List<PLMImpactAnalysisData>>  partData : impactAnlysMapLcl.entrySet()) {
				
					if(partData.getValue().size()>0)
					{
						hasRecordsFlg = true;
					}
				}
			}
			if(hasRecordsFlg)
			{
				StringBuffer mailBody = new StringBuffer().append(toAddressee)
						.append(PLMConstants.IMPACTANYIS_MAIL_FROM_MAIL_CONTENT)
						.append(PLMConstants.IMPACTANYIS_MAIL_SIGNATURE)
						.append(PLMConstants.IMPACTANYIS_MAIL_FOOTER);
				
				saveImpactAnalysisRpt(impactPartIdLstLcl, impactAnlysMapLcl,
						fileDir, filePathXlsx);
				PLMUtils.generateZipFile(filePathXlsx, filePathZip);
				file = new File(filePathZip);
				// Get the number of bytes in the file
				float sizeInBytes = file.length();
				// transform in MB
				float sizeInMb = sizeInBytes / (1024 * 1024);
				LOG.info("Zip File Size for Impact Analysis Report " + sizeInMb
						+ " MB");
				PLMUtils.sendMailWithAttachment(from, to, subject,
						mailBody.toString(), filePathZip);
				LOG.info("Impact Analysis Report Attachment Mail sent successfully.");
			} else {
				
				StringBuffer mailBody = new StringBuffer().append(toAddressee)
						.append(PLMConstants.IMPACTANYIS_NO_REC_MAIL)
						.append(PLMConstants.IMPACTANYIS_MAIL_SIGNATURE)
						.append(PLMConstants.IMPACTANYIS_MAIL_FOOTER);

				PLMUtils.sendMail(from, to, subject,mailBody.toString());
				LOG.info("Impact Analysis Report Blank Mail sent successfully.");
			}

		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendImpctAnlysRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(), from, to,
					subject, toAddressee,
					PLMConstants.IMPACTANYIS_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendImpctAnlysRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(), from, to,
					subject, toAddressee,
					PLMConstants.IMPACTANYIS_MAIL_SIGNATURE);
		} finally {
			deleteFiles(filePathXlsx, filePathZip);
			/*
			 * if (file!=null) file.delete();
			 */
		}
		LOG.info("Exiting sendImpctAnlysRptMail Method");

	}

	/**
	 * This method is used for Deleting zip file and xls file
	 * 
	 * @param filePathXls
	 *            ,filePathZip
	 */
	public void deleteFiles(String filePathXls, String filePathZip) {
		LOG.info("Entering deleteFiles method");
		boolean zipFileExist;
		boolean xlsFileExist;
		File zipFile = new File(filePathZip);
		zipFileExist = zipFile.exists();
		File xlsFile = new File(filePathXls);
		xlsFileExist = xlsFile.exists();
		if (zipFileExist) {
			boolean deleted = zipFile.delete();
			LOG.info("Successfully deleted zip file : " + deleted);
		}
		if (xlsFileExist) {
			boolean deleted = xlsFile.delete();
			LOG.info("Successfully deleted xls file : " + deleted);
		}
		LOG.info("Exiting deleteFiles Method");
	}

	/**
	 * This method is used for Bordering Cell in XLSX
	 * 
	 * @return StringBuffer
	 */
	private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
		style.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style.setBorderRight(XSSFCellStyle.BORDER_THIN);
		return style;
	}

	/**
	 * This method is used for Generating Report in XLSX
	 * 
	 * @param wuPrtIdLstLcl
	 *            ,partIbomSmlrtyRptList,impactAnlysMapLcl,fileDir,filePathXlsx
	 * @throws IOException
	 * @throws PLMCommonException
	 */

	public void saveImpactAnalysisRpt(List<String> wuPrtIdLstLcl,
			Map<String, List<PLMImpactAnalysisData>> impactAnlysMapLcl,
			String fileDir, String filePathXlsx) throws IOException,
			PLMCommonException {
		LOG.info("Entering saveBomSmlrtyFile File Method");
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			/*
			 * File file = new File(fileDir); boolean dirExists = file.exists();
			 * if (!dirExists) { file.mkdir(); }
			 */
			File fileName = new File(filePathXlsx);
			boolean fileExist = fileName.exists();
			if (!fileExist) {
				createFileExist = fileName.createNewFile();
				LOG.info("createFileExist>>>>.." + createFileExist);
			}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXlsx);
				SXSSFWorkbook workbook = new SXSSFWorkbook();

				XSSFFont font = (XSSFFont) workbook.createFont();
				font.setFontName(PLMConstants.EXCEL_FONT_NAME);
				font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				font.setFontHeightInPoints((short) 10);

				XSSFCellStyle cellBoldStyle = (XSSFCellStyle) workbook
						.createCellStyle();
				cellBoldStyle = setBorderStyle(cellBoldStyle);
				cellBoldStyle.setFont(font);
				cellBoldStyle.setAlignment(CellStyle.ALIGN_CENTER);

				XSSFCellStyle mergeStyle = (XSSFCellStyle) workbook
						.createCellStyle();
				mergeStyle = setBorderStyle(mergeStyle);
				mergeStyle.setFont(font);
				mergeStyle.setAlignment(CellStyle.ALIGN_CENTER);
				mergeStyle.setFillForegroundColor(GREEN_LIGHT);
				mergeStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);

				XSSFCellStyle coloumnStyleCenter = (XSSFCellStyle) workbook
						.createCellStyle();
				coloumnStyleCenter = setBorderStyle(coloumnStyleCenter);
				coloumnStyleCenter.setFont(font);
				coloumnStyleCenter.setAlignment(CellStyle.ALIGN_CENTER);
				coloumnStyleCenter.setVerticalAlignment(VerticalAlignment.TOP);
				coloumnStyleCenter.setFillForegroundColor(GRAY);
				coloumnStyleCenter
						.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);

				XSSFFont nonBoldFont = (XSSFFont) workbook.createFont();
				nonBoldFont.setFontHeightInPoints((short) 10);
				nonBoldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);

				XSSFCellStyle contentStyle = (XSSFCellStyle) workbook
						.createCellStyle();
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(nonBoldFont);
				contentStyle.setAlignment(CellStyle.ALIGN_CENTER);

				for (int i = 0; i < wuPrtIdLstLcl.size(); i++) {
					List<PLMImpactAnalysisData> ebomimpactList = impactAnlysMapLcl
							.get(wuPrtIdLstLcl.get(i) + "~E");
					List<PLMImpactAnalysisData> mbomimpactList = impactAnlysMapLcl
							.get(wuPrtIdLstLcl.get(i) + "~M");
					createNewTab(workbook, ebomimpactList, mbomimpactList,
							filePathXlsx, cellBoldStyle, contentStyle,
							mergeStyle, coloumnStyleCenter);
				}
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveEnvComplianceFile File: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveEnvComplianceFile File: ", e);
			throw e;
		} finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveEnvComplianceFile: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveEnvComplianceFile File Method");
	}

	public void createNewTab(SXSSFWorkbook workbook,
			List<PLMImpactAnalysisData> ebomimpactList,
			List<PLMImpactAnalysisData> mbomimpactList, String filePathXlsx,
			XSSFCellStyle cellBoldStyle, XSSFCellStyle contentStyle,
			XSSFCellStyle mergeStyle, XSSFCellStyle coloumnStyleCenter)
			throws PLMCommonException, IOException {

		LOG.info("Entering createNewTab File Method");
		FileOutputStream fileOut = null;
		String partName = "";
		String[] eBomcolumNames = { "Immediate Parent", "Immdt.Parent Rev",
				"Top Level Parent", "Logical Feature", "LF Type",
				"Product Configuration", "Hw Build Name", "Hw Build State",
				"Build Rel. Date", "Plant Name", "Part Name" };
		String[] mBomcolumNames = { "Immediate Parent", "Immdt.Parent Rev",
				"Top Level Parent", "Manufacturing Feature",
				"Product Configuration", "Hw Build Name", "Hw Build State",
				"Build Rel. Date", "Plant Name", "Part Name" };

		try {
			fileOut = new FileOutputStream(filePathXlsx);

			if (!PLMUtils.isEmptyList(ebomimpactList)) {
				partName = ebomimpactList.get(0).getPartNm();
			} else if (!PLMUtils.isEmptyList(mbomimpactList)) {
				partName = mbomimpactList.get(0).getPartNm();
			}

			int rowcount = 0;
			LOG.info("partName" + partName);
			if (!PLMUtils.isEmpty(partName)) {
				SXSSFSheet sheet = (SXSSFSheet) workbook.createSheet(partName);
				SXSSFRow row = (SXSSFRow) sheet.createRow(++rowcount);

				if (!PLMUtils.isEmptyList(ebomimpactList)) {
					SXSSFCell cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellValue("EBOM Total Results: "
							+ ebomimpactList.size());
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_THREE);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_SIX);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_SEVEN);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_EIGHT);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_NINE);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_TEN);
					cell.setCellStyle(mergeStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,
							rowcount, PLMConstants.EXCEL_COL_ZERO,
							PLMConstants.EXCEL_COL_TEN));
					cell.setCellStyle(mergeStyle);
					row = (SXSSFRow) sheet.createRow(++rowcount);
					for (int i = 0; i < eBomcolumNames.length; i++) {
						cell = (SXSSFCell) row.createCell(i);
						cell.setCellValue(eBomcolumNames[i]);
						cell.setCellStyle(coloumnStyleCenter);
					}
					for (int e = 0; e < ebomimpactList.size(); e++) {
						PLMImpactAnalysisData dataObj1 = (PLMImpactAnalysisData) ebomimpactList
								.get(e);
						row = (SXSSFRow) sheet.createRow(++rowcount);

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj1.getImmediateParent());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj1.getImmediateParentRev());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj1.getTopLvlParentNm());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_THREE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj1.getLgclFtrNm());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_FOUR);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj1.getLgclFtrType());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_FIVE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj1.getPrdtCnfgNm());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_SIX);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj1.getHwBldNm());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_SEVEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj1.getHwBldState());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_EIGHT);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj1.getBldRelDate());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_NINE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj1.getPlantNm());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_TEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj1.getPartNm());
					}
					short colWidth4 = (short) 4500;
					short colWidth6 = (short) 6500;
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, colWidth6);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, colWidth6);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, colWidth6);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,
							colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR, colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE, colWidth6);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX, colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,
							colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,
							colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE, colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN, colWidth6);

				} else {
					SXSSFCell cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellValue("No Records Found in EBOM");
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellStyle(mergeStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,
							rowcount, PLMConstants.EXCEL_COL_ZERO,
							PLMConstants.EXCEL_COL_TWO));
					cell.setCellStyle(mergeStyle);
					row = (SXSSFRow) sheet.createRow(++rowcount);
				}

				row = (SXSSFRow) sheet.createRow(++rowcount);
				row = (SXSSFRow) sheet.createRow(++rowcount);

				if (!PLMUtils.isEmptyList(mbomimpactList)) {
					SXSSFCell cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellValue("MBOM Total Results: "
							+ mbomimpactList.size());
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_THREE);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_SIX);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_SEVEN);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_EIGHT);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_NINE);
					cell.setCellStyle(mergeStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,
							rowcount, PLMConstants.EXCEL_COL_ZERO,
							PLMConstants.EXCEL_COL_NINE));
					cell.setCellStyle(mergeStyle);
					row = (SXSSFRow) sheet.createRow(++rowcount);
					for (int i = 0; i < mBomcolumNames.length; i++) {
						cell = (SXSSFCell) row.createCell(i);
						cell.setCellValue(mBomcolumNames[i]);
						cell.setCellStyle(coloumnStyleCenter);
					}
					for (int m = 0; m < mbomimpactList.size(); m++) {
						PLMImpactAnalysisData dataObj2 = (PLMImpactAnalysisData) mbomimpactList
								.get(m);
						row = (SXSSFRow) sheet.createRow(++rowcount);

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj2.getImmediateParent());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj2.getImmediateParentRev());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj2.getTopLvlParentNm());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_THREE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj2.getLgclFtrNm());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_FOUR);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj2.getPrdtCnfgNm());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_FIVE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj2.getHwBldNm());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_SIX);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj2.getHwBldState());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_SEVEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj2.getBldRelDate());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_EIGHT);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj2.getPlantNm());

						cell = (SXSSFCell) row
								.createCell(PLMConstants.EXCEL_COL_NINE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj2.getPartNm());

					}
					short colWidth4 = (short) 4500;
					short colWidth6 = (short) 6500;
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, colWidth6);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, colWidth6);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, colWidth6);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,
							colWidth6);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR, colWidth6);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE, colWidth6);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX, colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,
							colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,
							colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE, colWidth6);
				} else {
					SXSSFCell cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellValue("No Records Found in MBOM");
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(mergeStyle);
					cell = (SXSSFCell) row
							.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellStyle(mergeStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,
							rowcount, PLMConstants.EXCEL_COL_ZERO,
							PLMConstants.EXCEL_COL_TWO));
					cell.setCellStyle(mergeStyle);
					row = (SXSSFRow) sheet.createRow(++rowcount);
				}

			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@createNewTab File: ", e);
			throw e;
		} finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@createNewTab: ", e);
				throw e;
			}
		}
		LOG.info("Exiting createNewTab File Method");
	}

	/**
	 * This method is used for changeImpactRptListner
	 * 
	 * @param event
	 */
	public void changeImpactRptListner(ActionEvent event) {
		LOG.info("Action listner called.....--------------------------->"
				+ impactPageCnt);
		if (impactPageCnt == 100) {
			LOG.info("100");
			impactPageCnt = 100;
		} else if (impactPageCnt == 200) {
			LOG.info("200");
			impactPageCnt = 200;
		} else if (impactPageCnt == 500) {
			LOG.info("500");
			impactPageCnt = 500;
		} else if (impactPageCnt == 1000) {
			LOG.info("1000");
			impactPageCnt = 1000;
		} else if (impactPageCnt == 2000) {
			LOG.info("2000");
			impactPageCnt = 2000;
		}

		else if (impactPageCnt == 5000) {
			LOG.info("5000");
			impactPageCnt = 5000;
		} else if (impactPageCnt == impactCnt) {
			LOG.info("All");
			impactPageCnt = impactCnt;
		}
		LOG.info("final value.....--------------------------->" + impactPageCnt);
	}

	/**
	 * This method is used for resetTopLvlImplosionData
	 * 
	 */
	public void resetTopLvlImplosionData() {
		showAllTables = false;
		copicsDataList = new ArrayList<PLMWhereUsedData>();
		sbomDataList = new ArrayList<PLMWhereUsedData>();
		ebomDataList = new ArrayList<PLMWhereUsedData>();
		tliPartNumber = "";
		blnStrCopics = false;
		blnShwCpcsTable = false;
		blnStrSbom = false;
		blnShwSbomTable = false;
		blnStrEbom = false;
		blnShwEbomTable = false;
		strNoRcrdsMsgFrCopics = "";
		strNoRcrdsMsgFrEbom = "";
		strNoRcrdsMsgFrSbom = "";
		alertMsgWu = "";
	}

	/**
	 * This method is used for validationForPartNum
	 * 
	 * @param tliPartNumberLcl
	 * @return String
	 * 
	 */
	public String validationForPartNum(String tliPartNumberLcl) {
		alertMsgWu = "";
		if (PLMUtils.isEmpty(tliPartNumberLcl)) {
			alertMsgWu = PLMConstants.WHR_USD_TLI_SEARCH_CRITERIA_EMPTY_CHK;
		}
		if (PLMUtils.checkSplCharWhereUsed(tliPartNumberLcl)) {
			alertMsgWu = PLMConstants.WHR_USD_TLI_SEARCH_SPL_CHK;
		}
		return alertMsgWu;
	}

	/**
	 * This method is used for changeDetailCopicsListner
	 * 
	 * @param event
	 */
	public void changeDetailCopicsListner(ActionEvent event) {
		LOG.info("Action listner called.....--------------------------->"
				+ detailCopicsCounts);
		if (detailCopicsCounts == 100) {
			LOG.info("101");
			detailCopicsCounts = PLMConstants.N_100;
		} else if (detailCopicsCounts == 200) {
			LOG.info("200");
			detailCopicsCounts = 200;
		} else if (detailCopicsCounts == 500) {
			LOG.info("500");
			detailCopicsCounts = 500;
		} else if (detailCopicsCounts == 1000) {
			LOG.info("1000");
			detailCopicsCounts = 1000;
		} else if (detailCopicsCounts == 2000) {
			LOG.info("2000");
			detailCopicsCounts = 2000;
		} else if (detailCopicsCounts == 5000) {
			LOG.info("5000");
			detailCopicsCounts = 5000;
		} else if (detailCopicsCounts == copicsCounts) {
			LOG.info("All");
			detailCopicsCounts = copicsCounts;
		}
		LOG.info("final value.....--------------------------->"
				+ detailCopicsCounts);
	}

	/**
	 * This method is used for changeDetailSBoMListner
	 * 
	 * @param event
	 */
	public void changeDetailSBoMListner(ActionEvent event) {
		LOG.info("Action listner called.....--------------------------->"
				+ detailSBoMCounts);
		if (detailSBoMCounts == 100) {
			LOG.info("101");
			detailSBoMCounts = PLMConstants.N_100;
		} else if (detailSBoMCounts == 200) {
			LOG.info("200");
			detailSBoMCounts = 200;
		} else if (detailSBoMCounts == 500) {
			LOG.info("500");
			detailSBoMCounts = 500;
		} else if (detailSBoMCounts == 1000) {
			LOG.info("1000");
			detailSBoMCounts = 1000;
		} else if (detailSBoMCounts == 2000) {
			LOG.info("2000");
			detailSBoMCounts = 2000;
		} else if (detailSBoMCounts == 5000) {
			LOG.info("5000");
			detailSBoMCounts = 5000;
		} else if (detailSBoMCounts == sBoMCounts) {
			LOG.info("All");
			detailSBoMCounts = sBoMCounts;
		}
		LOG.info("final value.....--------------------------->"
				+ detailSBoMCounts);
	}

	/**
	 * This method is used for changeDetailEBoMListner
	 * 
	 * @param event
	 */
	public void changeDetailEBoMListner(ActionEvent event) {
		LOG.info("Action listner called.....--------------------------->"
				+ detailEBoMCounts);
		if (detailEBoMCounts == 100) {
			LOG.info("101");
			detailEBoMCounts = PLMConstants.N_100;
		} else if (detailEBoMCounts == 200) {
			LOG.info("200");
			detailEBoMCounts = 200;
		} else if (detailEBoMCounts == 500) {
			LOG.info("500");
			detailEBoMCounts = 500;
		} else if (detailEBoMCounts == 1000) {
			LOG.info("1000");
			detailEBoMCounts = 1000;
		} else if (detailEBoMCounts == 2000) {
			LOG.info("2000");
			detailEBoMCounts = 2000;
		} else if (detailEBoMCounts == 5000) {
			LOG.info("5000");
			detailEBoMCounts = 5000;
		} else if (detailEBoMCounts == eBoMCounts) {
			LOG.info("All");
			detailEBoMCounts = eBoMCounts;
		}
		LOG.info("final value.....--------------------------->"
				+ detailEBoMCounts);
	}
	
	
	/**
	 * This method is used for changeDetailEBoMListner
	 * 
	 * @param event
	 */
	public void changeDetailRpdmListner(ActionEvent event) {
		LOG.info("Action listner called.....--------------------------->"
				+ detailRpdmCounts);
		if (detailRpdmCounts == 100) {
			LOG.info("101");
			detailRpdmCounts = PLMConstants.N_100;
		} else if (detailRpdmCounts == 200) {
			LOG.info("200");
			detailRpdmCounts = 200;
		} else if (detailRpdmCounts == 500) {
			LOG.info("500");
			detailRpdmCounts = 500;
		} else if (detailRpdmCounts == 1000) {
			LOG.info("1000");
			detailRpdmCounts = 1000;
		} else if (detailRpdmCounts == 2000) {
			LOG.info("2000");
			detailRpdmCounts = 2000;
		} else if (detailRpdmCounts == 5000) {
			LOG.info("5000");
			detailRpdmCounts = 5000;
		} else if (detailRpdmCounts == rpdmCounts) {
			LOG.info("All");
			detailRpdmCounts = rpdmCounts;
		}
		LOG.info("final value.....--------------------------->"
				+ detailRpdmCounts);
	}
	
	
	
	
	

	// End raju

	//Newly Added methods for multiple part Names for Text/CSV upload to generate Email Report	
	/**
	 * Reload FMI Template page. Require to fix IE11 issue with rich:fileUpload
	 * */
	public String refreshFixForRichUploadTemplate() {
		return PLMConstants.WHERE_USED_SEARCH;
	}
	
	/**
	 * This method is used for upload the Fmi Template
	 * 
	 * @return void
	 */
	public void uploadValidFile(UploadEvent event) {
		LOG.info("Entering uploadValidFile Method");
		UploadItem item = event.getUploadItem();
		File srcfile =item.getFile();
		partNumList = new ArrayList<String>();
		alertMsgValidWu ="";
		List<String> partNumListLcl = new ArrayList<String>();
		List<String> partNumComaList = new ArrayList<String>();
		List<String> partNumListtemp = new ArrayList<String>();
		BufferedReader is = null;
		String lineReader;
		String comma = ",";
		String [] partNumArr =null;
	    int copicDataCount=0;
	    int sbomDevDataCount=0;
	    int ebomDataCount=0;
	    int rpdmDataCount=0;
		if (srcfile.exists()) {
			 try {
				is = new BufferedReader(new FileReader(srcfile));
				 while((lineReader = is.readLine()) != null)
				   {
					 if(lineReader.contains(comma)){
						  partNumArr=lineReader.split(comma);
						  partNumComaList =new ArrayList<String>(Arrays.asList(partNumArr));
						  partNumListLcl.addAll(partNumComaList);
				    	}else if(!lineReader.contains(comma)){
				    		partNumListLcl.add(lineReader);
				    	}
				   }
				 for(int i=0;i<partNumListLcl.size();i++){
					 if(!PLMUtils.isEmpty(partNumListLcl.get(i))){
						 partNumListtemp.add(partNumListLcl.get(i).trim());
					 }
				 }
				 alertMsgValidWu=validatePartNumber(partNumListtemp); 
				 LOG.info("partNumListtemp Size>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+partNumListtemp.size());
				 if(PLMUtils.isEmpty(alertMsgValidWu)){
					 try {
						 copicDataCount = plmWhereUsedService.getCopicsDataCount(partNumListtemp);
						 sbomDevDataCount = plmWhereUsedService.getSbomDevDataCount(partNumListtemp);
						 ebomDataCount = plmWhereUsedService.getEbomDataCount(partNumListtemp);
						 rpdmDataCount = plmWhereUsedService.getSbomDevDataCount(partNumListtemp);
						 if(copicDataCount!=0){
							 alertMsgValidWu ="Where Used (COPICS) - Data exists for " +copicDataCount+" out of "+partNumListtemp.size() +" Part Numbers";
						 }else{
							 alertMsgValidWu ="Where Used (COPICS) - No Records Found";
						 }
						 
						 if(sbomDevDataCount!=0){
							 alertMsgValidWu =alertMsgValidWu+"<br/>Where Used (SBOM Deviations) - Data exists for " +sbomDevDataCount+" out of "+partNumListtemp.size() +" Part Numbers";
						 }else{
							 alertMsgValidWu =alertMsgValidWu+"<br/>Where Used (SBOM Deviations) - No Records Found";
						 }
						 
						 if(ebomDataCount!=0){
							 alertMsgValidWu= alertMsgValidWu+"<br/>Where Used (EBOM) - Data exists for " +ebomDataCount+" out of "+partNumListtemp.size() +" Part Numbers";
						 }else{
							 alertMsgValidWu = alertMsgValidWu+"<br/>Where Used (EBOM) - No Records Found";
						 }
						 
						 if(rpdmDataCount!=0){
							 alertMsgValidWu= alertMsgValidWu+"<br/>Where Used (RPDM SBOM) - Data exists for " +rpdmDataCount+" out of "+partNumListtemp.size() +" Part Numbers";
						 }else{
							 alertMsgValidWu = alertMsgValidWu+"<br/>Where Used (RPDM SBOM) - No Records Found";
						 }
						 
						 
						 
						 if(copicDataCount!=0 || sbomDevDataCount!=0 || ebomDataCount!=0 || rpdmDataCount!=0){
							 partNumList.addAll(partNumListtemp);
						 }

					 } catch (PLMCommonException e) {
						e.printStackTrace();
					  }
				 }
				 
				 is.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		LOG.info("Exiting uploadValidFile Method");
	}
	
	/**
	 * This method is used for Validating Part Number Input
	 * 
	 * @return String
	 */
	public String validatePartNumber(List<String> partNumListTemp) {
		LOG.info("Entering validatePartNumber Method");
		String alertMsg = "";
		boolean checkFlag=false;
		for(int i=0;i<partNumListTemp.size();i++){
			 if(!PLMUtils.isEmpty(partNumListTemp.get(i))){
				 String spaceStr[]=partNumListTemp.get(i).split("\\s+");
				  if(spaceStr.length >1){
					  alertMsg = PLMConstants.WHEREUSEDTOPLVL_SPACE_VALIDATION;
					  checkFlag =true;
					  break;
				  }
			 }
		 }
		if(PLMUtils.isEmptyList(partNumListTemp) && !checkFlag){
			alertMsg = PLMConstants.WHEREUSEDTOPLVL_UPLOADFILE;
			checkFlag =true;
		}else if(partNumListTemp.size() > 5000 && !checkFlag){
			alertMsg = PLMConstants.PARTNUM_MORE_5000;
		}
		LOG.info("Exiting validatePartNumber Method");
		return alertMsg;
	}

	/**
	 * This method is used for Generating BOM Defect Report
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String generateWhrUsdImplosionEmail() throws PWiException {
		LOG.info("Entering generateWhrUsdImplosionEmail Method");
		String fwdflag = PLMConstants.WHERE_USED_SEARCH;
		alertMsgWu = "";
		userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		if (!PLMUtils.isEmptyList(partNumList)) {
			alertMsgWu =  PLMConstants.WHEREUSEDTOPLVL_EMAIL_AERT_MSG;
			taskExecutor.execute(new MailThread());
		}else{
			alertMsgWu =  PLMConstants.WHEREUSEDTOPLVL_UPLOADFILE;
		}
		LOG.info("Exiting generateWhrUsdImplosionEmail Method");
		return fwdflag;
	}
	
	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendWhereUsdImplosionRptMail();
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return void
	 */
	public void sendWhereUsdImplosionRptMail() {
		LOG.info("Entering sendWhereUsdImplosionRptMail Method");
		List<String> partNumlistLcl = partNumList;
		String from = PLMConstants.OMM_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.WHEREUSEDTOPLVL_SUBJECT ;
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("WHERE_USED_LVL_IMPLOSION") +  "_" + uniqTime + ".xlsx";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("WHERE_USED_LVL_IMPLOSION") +  "_" + uniqTime + ".zip";
		try {
			Map<String,Object> copicsDataMap = plmWhereUsedService.getCopicsData(partNumlistLcl);
			List<PLMWhereUsedData> copicDataList =(List<PLMWhereUsedData>) copicsDataMap.get("CopicsData");
			int copicsPartCount = (Integer) copicsDataMap.get("partCount");
			int copicsTopPartCount = (Integer) copicsDataMap.get("topPartCount");
			
			Map<String,Object> sbomDataMap = plmWhereUsedService.getSBOMDevData(partNumlistLcl);
			List<PLMWhereUsedData> sbomDevDataList =(List<PLMWhereUsedData>) sbomDataMap.get("SBoMData");
			int sbomPartCount = (Integer) sbomDataMap.get("partCount");
			int sbomTopPartCount = (Integer) sbomDataMap.get("topPartCount");
			
			Map<String,Object> ebomDataMap = plmWhereUsedService.getEBOMData(partNumlistLcl);
			List<PLMWhereUsedData> ebomDataLst =(List<PLMWhereUsedData>) ebomDataMap.get("EBoMData");
			int ebomPartCount = (Integer) ebomDataMap.get("partCount");
			int ebomTopPartCount = (Integer) ebomDataMap.get("topPartCount");
			
			
			
			Map<String,Object> rpdmDataMap = plmWhereUsedService.getRpdmData(partNumlistLcl);
			List<PLMWhereUsedData> rpdmDataLst =(List<PLMWhereUsedData>) rpdmDataMap.get("rpdmData");
			int rpdmPartCount = (Integer) rpdmDataMap.get("partCount");
			int rpdmTopPartCount = (Integer) rpdmDataMap.get("topPartCount");
			
			
			
			
			
			
			StringBuffer mailBody = new StringBuffer().append(toAddressee);
			if(PLMUtils.isEmptyList(copicDataList) && PLMUtils.isEmptyList(sbomDevDataList) && PLMUtils.isEmptyList(ebomDataLst)){
				mailBody.append(PLMConstants.WHEREUSEDTOPLVL_MAIL_CONTENT_NO_RECORD);
				mailBody.append(partNumlistLcl)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				PLMUtils.sendMail(from, to, subject, mailBody.toString());
			} else {
				mailBody.append(PLMConstants.WHEREUSEDTOPLVL_MAIL_CONTENT);
				mailBody.append("Where Used (COPICS)\n")
						.append("-------------------------\n")
						.append("Input Parts Count = "+copicsPartCount+"\n")
						.append("Top level Unit BOM Count = "+copicsTopPartCount+"\n\n");
				
				mailBody.append("Where Used (SBOM Deviations)\n")
						.append("---------------------------------\n")
						.append("Input Parts Count = "+sbomPartCount+"\n")
						.append("Top level Unit BOM Count = "+sbomTopPartCount+"\n\n");
				
				mailBody.append("Where Used (EBOM)\n")
						.append("-----------------------\n")
						.append("Input Parts Count = "+ebomPartCount+"\n")
						.append("Top level Unit BOM Count = "+ebomTopPartCount+"\n\n");
				
				mailBody.append("Where Used (RPDM SBOM)\n")
				.append("-----------------------\n")
				.append("Input Parts Count = "+rpdmPartCount+"\n")
				.append("Top level Unit BOM Count = "+rpdmTopPartCount+"\n\n");
				
				 mailBody.append("Part Numbers - "+partNumlistLcl)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				saveXLSXFile(copicDataList,sbomDevDataList,ebomDataLst,rpdmDataLst,fileDir,filePathXls,copicsPartCount,copicsTopPartCount,
						sbomPartCount,sbomTopPartCount,ebomPartCount,ebomTopPartCount,rpdmPartCount,rpdmTopPartCount);
				PLMUtils.generateZipFile(filePathXls,filePathZip);
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendWhereUsdImplosionRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendWhereUsdImplosionRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} finally {
			PLMUtils.deleteFiles(filePathXls,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendWhereUsdImplosionRptMail Method");
	}

	/**
	 * This method is used for Generating Report in XLS
	 * @param rpdmDataLst 
	 * @param rpdmTopPartCount 
	 * @param rpdmPartCount 
	 * 
	 * @return void
	 */
	
	public void saveXLSXFile(List<PLMWhereUsedData> copicDataList,List<PLMWhereUsedData> sbomDevDataList,
			List<PLMWhereUsedData> ebomDataLst,List<PLMWhereUsedData> rpdmDataLst, String fileDir,String filePathXls,
			int copicsPartCountLcl,int copicsTopPartCountLcl,int sbomPartCountLcl,
			int sbomTopPartCountLcl,int ebomPartCountLcl,int ebomTopPartCountLcl, int rpdmPartCount, int rpdmTopPartCount) throws IOException {
		LOG.info("Entering saveXLSXFile Method");
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXls);
				SXSSFWorkbook workbook = new SXSSFWorkbook();
				
				// Start : POI Styles
				XSSFCellStyle headerStyle = (XSSFCellStyle) workbook.createCellStyle();
				headerStyle.setFillForegroundColor(HSSFColor.BLACK.index);
				headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
				
				XSSFFont headerFont = (XSSFFont) workbook.createFont(); 
				headerFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				headerFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headerFont.setFontHeightInPoints((short)9);
				headerFont.setFontName("GE Inspira");
				headerFont.setColor(IndexedColors.WHITE.getIndex());
				headerStyle.setFont(headerFont);
				
				XSSFCellStyle searchFieldNameStyle = (XSSFCellStyle) workbook.createCellStyle();
				searchFieldNameStyle = setBorderStyle(searchFieldNameStyle);
				searchFieldNameStyle.setAlignment(CellStyle.ALIGN_RIGHT);
				
				XSSFFont boldFont = (XSSFFont) workbook.createFont();
				boldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				boldFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				boldFont.setFontHeightInPoints((short)9);
				boldFont.setFontName("GE Inspira");
				boldFont.setColor(IndexedColors.BLACK.getIndex());
				searchFieldNameStyle.setFont(boldFont);
				
				XSSFFont cellstyleFont = (XSSFFont)workbook.createFont(); 
				cellstyleFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				
				cellstyleFont.setFontHeightInPoints((short)9);
				cellstyleFont.setFontName("GE Inspira");
				cellstyleFont.setColor(IndexedColors.BLACK.getIndex());
				
				XSSFCellStyle contentStyle = (XSSFCellStyle) workbook.createCellStyle();
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(cellstyleFont);
				
				// cell hyper link
				XSSFCreationHelper helper= (XSSFCreationHelper) workbook.getCreationHelper();
				
			    XSSFFont underLinedFont = (XSSFFont) workbook.createFont();
		        underLinedFont.setUnderline(HSSFFont.U_SINGLE);
		        underLinedFont.setColor(IndexedColors.BLUE.getIndex());
				XSSFCellStyle hyperLinkStyle = (XSSFCellStyle) workbook.createCellStyle();				
				hyperLinkStyle = setBorderStyle(hyperLinkStyle);
				hyperLinkStyle.setFont(underLinedFont);
				
				
				XSSFFont font = (XSSFFont) workbook.createFont(); 
				font.setFontName(PLMConstants.EXCEL_FONT_NAME);
				font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				font.setFontHeightInPoints((short)9);
				font.setFontName("GE Inspira");
				
				XSSFCellStyle cellBoldStyle = (XSSFCellStyle) workbook.createCellStyle();
				cellBoldStyle = setBorderStyle(cellBoldStyle);
				cellBoldStyle.setFont(font);
				
				SXSSFRow row = null;
				SXSSFCell cell = null;
				SXSSFSheet sheet =  null;
				
						int rowcount = -1;
						sheet = (SXSSFSheet) workbook.createSheet("Where Used (COPICS)");
							//Header
						if(!PLMUtils.isEmptyList(copicDataList)) {

							String[] copicsColNames = {"Top Lvl Parent","Top Lvl Parent Description","Immediate Parent","Immediate Parent Description",
									"Part Number","Part Description","Part Quantity","Part UOM","Serial Number","Status"};
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell.setCellValue("Input Parts Count");
							cell.setCellStyle(cellBoldStyle);
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellValue(copicsPartCountLcl);
							cell.setCellStyle(cellBoldStyle);
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell.setCellValue("Top level Unit BOM Count");
							cell.setCellStyle(cellBoldStyle);
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellValue(copicsTopPartCountLcl);
							cell.setCellStyle(cellBoldStyle);
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							for ( int i = 0 ; i < copicsColNames.length; i++ ) {
								cell = (SXSSFCell) row.createCell(i);
								cell.setCellStyle(headerStyle);
								cell. setCellValue(copicsColNames[i]);
							}
							//Header
							for(int i = 0; i < copicDataList.size(); i++) {
								PLMWhereUsedData dataObj = (PLMWhereUsedData) copicDataList.get(i);
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getTopLvlParent());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getTopLvlParentDesc());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getImdParent());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getImdParentDesc());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
								/*if(!PLMUtils.isEmpty(dataObj.getPartId())){
									cell.setCellStyle(hyperLinkStyle);
									XSSFHyperlink url_link1 = helper.createHyperlink(Hyperlink.LINK_URL);
									url_link1.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getPartId());
									cell.setHyperlink(url_link1);
									cell.setCellValue(dataObj.getPartNum());
								}else{*/
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getPartNum());
								//}
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartDesc());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getQty());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartUom());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getSerialNumber());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getStatus());
								
						}
						  	sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,8000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,8000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,5000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,8000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,5000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,8000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,4000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,6000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,4000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE,3000);
							sheet.createFreezePane( 0, 4 );

						}else{
							SXSSFRow row1 = (SXSSFRow) sheet.createRow(++rowcount);
							SXSSFCell cell1 = (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell1.setCellValue("No Records Found in Where Used (COPICS)");
							cell1.setCellStyle(contentStyle);
							sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
						}
						
						rowcount = -1;
						sheet = (SXSSFSheet) workbook.createSheet("Where Used (SBOM Deviations)");

						if(!PLMUtils.isEmptyList(sbomDevDataList)) {
								//Header
								String[] sbomDeviationCols = {"ML/MPL Number","Serial Number","MLI","New Item","Old Item","Description","Date Entered","Auth ECN",
										"Quantity","Orign"};
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
								cell.setCellValue("Input Parts Count");
								cell.setCellStyle(cellBoldStyle);
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellValue(sbomPartCountLcl);
								cell.setCellStyle(cellBoldStyle);
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
								cell.setCellValue("Top level Unit BOM Count");
								cell.setCellStyle(cellBoldStyle);
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellValue(sbomTopPartCountLcl);
								cell.setCellStyle(cellBoldStyle);
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								for ( int i = 0 ; i < sbomDeviationCols.length; i++ ) {
									cell = (SXSSFCell) row.createCell(i);
									cell.setCellStyle(headerStyle);
									cell. setCellValue(sbomDeviationCols[i]);
								}
								//Header
								for(int i = 0; i < sbomDevDataList.size(); i++) {
									PLMWhereUsedData dataObj = (PLMWhereUsedData) sbomDevDataList.get(i);
									row = (SXSSFRow) sheet.createRow(++rowcount);
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getTurbnNUm());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getSrlNum1());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getMli());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getNewItem());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getOldItem());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getDescript());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getDtent());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getAuthen());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getQty1());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getOrign());
									
							}
							  	sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,8000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,4000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,2000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,5000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,5000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,8000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,5000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,6000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,4000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE,3000);
								sheet.createFreezePane( 0, 4 );

						}else{
							SXSSFRow row1 = (SXSSFRow) sheet.createRow(++rowcount);
							SXSSFCell cell1 = (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell1.setCellValue("No Records Found in Where Used (SBOM Deviations)");
							cell1.setCellStyle(contentStyle);
							sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
						}
						
						rowcount = -1;
						sheet = (SXSSFSheet) workbook.createSheet("Where Used (EBOM)");

						if(!PLMUtils.isEmptyList(ebomDataLst)) {
								//Header
								String[] ebomCols = {"Top Lvl Parent","Top Lvl Parent Rev","Top Lvl Parent Description","Immediate Parent",
										"Immediate Parent Rev","Immediate Parent Description","Part Number","Part Description","Part Quantity","Part UOM","Level"};
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
								cell.setCellValue("Input Parts Count");
								cell.setCellStyle(cellBoldStyle);
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellValue(ebomPartCountLcl);
								cell.setCellStyle(cellBoldStyle);
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
								cell.setCellValue("Top level Unit BOM Count");
								cell.setCellStyle(cellBoldStyle);
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellValue(ebomTopPartCountLcl);
								cell.setCellStyle(cellBoldStyle);
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								for ( int i = 0 ; i < ebomCols.length; i++ ) {
									cell = (SXSSFCell) row.createCell(i);
									cell.setCellStyle(headerStyle);
									cell. setCellValue(ebomCols[i]);
								}
								//Header
								for(int i = 0; i < ebomDataLst.size(); i++) {
									PLMWhereUsedData dataObj = (PLMWhereUsedData) ebomDataLst.get(i);
									row = (SXSSFRow) sheet.createRow(++rowcount);
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getTopLvlParentNm());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getTopLvlParentRev());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getTopLvlParentDesc());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getImmediateParent());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getImmediateParentRev());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getImdParentDesc());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getPartNm());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getPartDesc());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getQty());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getPartUom());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getLvl());
									
							}
							 	sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,8000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,5000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,8000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,5000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,5000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,8000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,5000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,8000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,4000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE,4000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN,1200);
								sheet.createFreezePane( 0, 4 );

						}else{
							SXSSFRow row1 = (SXSSFRow) sheet.createRow(++rowcount);
							SXSSFCell cell1 = (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell1.setCellValue("No Records Found in Where Used (EBOM)");
							cell1.setCellStyle(contentStyle);
							sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
						}
						
						
						
						rowcount = -1;
						sheet = (SXSSFSheet) workbook.createSheet("Where Used (RPDM SBOM)");

						if(!PLMUtils.isEmptyList(rpdmDataLst)) {
								//Header
								String[] rpdmCols = {"System_id","System_name","Bom Lvl","Class Name","Rel Type",
										"Parent Name","Parent Description","Child Name","Child Rev","Child Description","Language Code","T4 Ref.Part#","T4 Ref.Part Rev"};
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
								cell.setCellValue("Input Parts Count");
								cell.setCellStyle(cellBoldStyle);
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellValue(rpdmPartCount);
								cell.setCellStyle(cellBoldStyle);
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
								cell.setCellValue("Top level Unit BOM Count");
								cell.setCellStyle(cellBoldStyle);
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellValue(rpdmTopPartCount);
								cell.setCellStyle(cellBoldStyle);
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								for ( int i = 0 ; i < rpdmCols.length; i++ ) {
									cell = (SXSSFCell) row.createCell(i);
									cell.setCellStyle(headerStyle);
									cell. setCellValue(rpdmCols[i]);
								}
								//Header
								for(int i = 0; i < rpdmDataLst.size(); i++) {
									PLMWhereUsedData dataObj = (PLMWhereUsedData) rpdmDataLst.get(i);
									row = (SXSSFRow) sheet.createRow(++rowcount);
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getSystemId());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getSystemName());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getBomLevel());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getClassName());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getRelType());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getParentName());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getParentTextName());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getChildName());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getChildRev());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getTextName());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getLanguageCode());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getT4refPartNumber());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWELVE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getT4refPartRev());
									
							}
							 	sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,8000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,5000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,8000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,5000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,5000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,8000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,5000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,8000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,4000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE,4000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN,4000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN,4000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWELVE,4000);
								sheet.createFreezePane( 0, 4 );

						}else{
							SXSSFRow row1 = (SXSSFRow) sheet.createRow(++rowcount);
							SXSSFCell cell1 = (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell1.setCellValue("No Records Found in Where Used (RPDM SBOM)");
							cell1.setCellStyle(contentStyle);
							sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
						}
						
						
						
						
						
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveXLSXFile: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveXLSXFile: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveXLSXFile: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveXLSXFile Method");
	}
	
	
	/**
	 * @return the alertMsgValidWu
	 */
	public String getAlertMsgValidWu() {
		return alertMsgValidWu;
	}
	/**
	 * @param alertMsgValidWu the alertMsgValidWu to set
	 */
	public void setAlertMsgValidWu(String alertMsgValidWu) {
		this.alertMsgValidWu = alertMsgValidWu;
	}

	/**
	 * Resets the Part Number
	 * 
	 * @return String
	 */
	public String resetData() {
		plmWhereUsedData.setPartNumber("");
		return PLMConstants.WHERE_USED_SEARCH;
	}

	/**
	 * @return the plmWhereUsedService
	 */
	public PLMWhereUsedServiceIfc getPlmWhereUsedService() {
		return plmWhereUsedService;
	}

	/**
	 * @param plmWhereUsedService
	 *            the plmWhereUsedService to set
	 */
	public void setPlmWhereUsedService(
			PLMWhereUsedServiceIfc plmWhereUsedService) {
		this.plmWhereUsedService = plmWhereUsedService;
	}

	/**
	 * @return the plmWhereUsedData
	 */
	public PLMWhereUsedData getPlmWhereUsedData() {
		return plmWhereUsedData;
	}

	/**
	 * @param plmWhereUsedData
	 *            the plmWhereUsedData to set
	 */
	public void setPlmWhereUsedData(PLMWhereUsedData plmWhereUsedData) {
		this.plmWhereUsedData = plmWhereUsedData;
	}

	/**
	 * @return the whereUsedSearchList
	 */
	public List<PLMWhereUsedData> getWhereUsedSearchList() {
		return whereUsedLOUSearchList;
	}

	/**
	 * @param whereUsedSearchList
	 *            the whereUsedSearchList to set
	 */
	public void setWhereUsedSearchList(
			List<PLMWhereUsedData> whereUsedSearchList) {
		this.whereUsedLOUSearchList = whereUsedSearchList;
	}

	/**
	 * @return the recordCount
	 */
	public int getRecordCount() {
		return recordCount;
	}

	/**
	 * @param recordCount
	 *            the recordCount to set
	 */
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount
	 *            the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage
	 *            the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}

	/**
	 * @param partNumber
	 *            the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	/**
	 * @return the totalRecCountMsg
	 */
	public String getTotalRecCountMsg() {
		return totalRecCountMsg;
	}

	/**
	 * @param totalRecCountMsg
	 *            the totalRecCountMsg to set
	 */
	public void setTotalRecCountMsg(String totalRecCountMsg) {
		this.totalRecCountMsg = totalRecCountMsg;
	}

	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}

	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor
	 *            the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the dropdownlist
	 */
	/*
	 * public Map<String, List<SelectItem>> getDropdownlist() { return
	 * dropdownlist; }
	 */

	/**
	 * @param dropdownlist
	 *            the dropdownlist to set
	 */
	/*
	 * public void setDropdownlist(Map<String, List<SelectItem>> dropdownlist) {
	 * this.dropdownlist = dropdownlist; }
	 */

	/**
	 * @return the stateListData
	 */
	public List<SelectItem> getStateListData() {
		return stateListData;
	}

	/**
	 * @param stateListData
	 *            the stateListData to set
	 */
	public void setStateListData(List<SelectItem> stateListData) {
		this.stateListData = stateListData;
	}

	/**
	 * @return the typeListData
	 */
	public List<SelectItem> getTypeListData() {
		return typeListData;
	}

	/**
	 * @param typeListData
	 *            the typeListData to set
	 */
	public void setTypeListData(List<SelectItem> typeListData) {
		this.typeListData = typeListData;
	}

	/**
	 * @return the alertMsgWu
	 */
	public String getAlertMsgWu() {
		return alertMsgWu;
	}

	/**
	 * @param alertMsgWu
	 *            the alertMsgWu to set
	 */
	public void setAlertMsgWu(String alertMsgWu) {
		this.alertMsgWu = alertMsgWu;
	}

	/**
	 * @return the searchResultList
	 */
	public List<PLMWhereUsedData> getSearchResultList() {
		return searchResultList;
	}

	/**
	 * @param searchResultList
	 *            the searchResultList to set
	 */
	public void setSearchResultList(List<PLMWhereUsedData> searchResultList) {
		this.searchResultList = searchResultList;
	}

	/**
	 * @return the plmWhereUsedReqData
	 */
	public PLMWhereUsedReqData getPlmWhereUsedReqData() {
		return plmWhereUsedReqData;
	}

	/**
	 * @param plmWhereUsedReqData
	 *            the plmWhereUsedReqData to set
	 */
	public void setPlmWhereUsedReqData(PLMWhereUsedReqData plmWhereUsedReqData) {
		this.plmWhereUsedReqData = plmWhereUsedReqData;
	}

	/**
	 * @return the whereUsedReqList
	 */
	public List<PLMWhereUsedReqData> getWhereUsedReqList() {
		return whereUsedReqList;
	}

	/**
	 * @param whereUsedReqList
	 *            the whereUsedReqList to set
	 */
	public void setWhereUsedReqList(List<PLMWhereUsedReqData> whereUsedReqList) {
		this.whereUsedReqList = whereUsedReqList;
	}

	/**
	 * @return the totalWhereUSedReportMsg
	 */
	public String getTotalWhereUSedReportMsg() {
		return totalWhereUSedReportMsg;
	}

	/**
	 * @param totalWhereUSedReportMsg
	 *            the totalWhereUSedReportMsg to set
	 */
	public void setTotalWhereUSedReportMsg(String totalWhereUSedReportMsg) {
		this.totalWhereUSedReportMsg = totalWhereUSedReportMsg;
	}

	/**
	 * @return the whereUsedReportCounts
	 */
	public int getWhereUsedReportCounts() {
		return whereUsedReportCounts;
	}

	/**
	 * @param whereUsedReportCounts
	 *            the whereUsedReportCounts to set
	 */
	public void setWhereUsedReportCounts(int whereUsedReportCounts) {
		this.whereUsedReportCounts = whereUsedReportCounts;
	}

	/**
	 * @return the whereUsedRprtTotCounts
	 */
	public int getWhereUsedRprtTotCounts() {
		return whereUsedRprtTotCounts;
	}

	/**
	 * @param whereUsedRprtTotCounts
	 *            the whereUsedRprtTotCounts to set
	 */
	public void setWhereUsedRprtTotCounts(int whereUsedRprtTotCounts) {
		this.whereUsedRprtTotCounts = whereUsedRprtTotCounts;
	}

	/**
	 * @return the frameList
	 */
	public List<SelectItem> getFrameList() {
		return frameList;
	}

	/**
	 * @param frameList
	 *            the frameList to set
	 */
	public void setFrameList(List<SelectItem> frameList) {
		this.frameList = frameList;
	}

	/**
	 * @return the dropdownframelist
	 */
	public Map<String, List<SelectItem>> getDropdownframelist() {
		return dropdownframelist;
	}

	/**
	 * @param dropdownframelist
	 *            the dropdownframelist to set
	 */
	public void setDropdownframelist(
			Map<String, List<SelectItem>> dropdownframelist) {
		this.dropdownframelist = dropdownframelist;
	}

	/**
	 * @return the selFrameList
	 */
	public String getSelFrameList() {
		return selFrameList;
	}

	/**
	 * @param selFrameList
	 *            the selFrameList to set
	 */
	public void setSelFrameList(String selFrameList) {
		this.selFrameList = selFrameList;
	}

	/**
	 * @return the contratStrDt
	 */
	public String getContratStrDt() {
		return contratStrDt;
	}

	/**
	 * @param contratStrDt
	 *            the contratStrDt to set
	 */
	public void setContratStrDt(String contratStrDt) {
		this.contratStrDt = contratStrDt;
	}

	/**
	 * @return the contratEndDt
	 */
	public String getContratEndDt() {
		return contratEndDt;
	}

	/**
	 * @param contratEndDt
	 *            the contratEndDt to set
	 */
	public void setContratEndDt(String contratEndDt) {
		this.contratEndDt = contratEndDt;
	}

	/**
	 * @return the fmiIssStrDt
	 */
	public String getFmiIssStrDt() {
		return fmiIssStrDt;
	}

	/**
	 * @param fmiIssStrDt
	 *            the fmiIssStrDt to set
	 */
	public void setFmiIssStrDt(String fmiIssStrDt) {
		this.fmiIssStrDt = fmiIssStrDt;
	}

	/**
	 * @return the fmiIssEndDt
	 */
	public String getFmiIssEndDt() {
		return fmiIssEndDt;
	}

	/**
	 * @param fmiIssEndDt
	 *            the fmiIssEndDt to set
	 */
	public void setFmiIssEndDt(String fmiIssEndDt) {
		this.fmiIssEndDt = fmiIssEndDt;
	}

	/**
	 * @return the wildCardReqrmnt
	 */
	public String getWildCardReqrmnt() {
		return wildCardReqrmnt;
	}

	/**
	 * @param wildCardReqrmnt
	 *            the wildCardReqrmnt to set
	 */
	public void setWildCardReqrmnt(String wildCardReqrmnt) {
		this.wildCardReqrmnt = wildCardReqrmnt;
	}

	/**
	 * @return the wildCardSerlNo
	 */
	public String getWildCardSerlNo() {
		return wildCardSerlNo;
	}

	/**
	 * @param wildCardSerlNo
	 *            the wildCardSerlNo to set
	 */
	public void setWildCardSerlNo(String wildCardSerlNo) {
		this.wildCardSerlNo = wildCardSerlNo;
	}

	/**
	 * @return the tliPartNumber
	 */
	public String getTliPartNumber() {
		return tliPartNumber;
	}

	/**
	 * @param tliPartNumber
	 *            the tliPartNumber to set
	 */
	public void setTliPartNumber(String tliPartNumber) {
		this.tliPartNumber = tliPartNumber;
	}

	/**
	 * @return the copicsDataList
	 */
	public List<PLMWhereUsedData> getCopicsDataList() {
		return copicsDataList;
	}

	/**
	 * @param copicsDataList
	 *            the copicsDataList to set
	 */
	public void setCopicsDataList(List<PLMWhereUsedData> copicsDataList) {
		this.copicsDataList = copicsDataList;
	}

	/**
	 * @return the sbomDataList
	 */
	public List<PLMWhereUsedData> getSbomDataList() {
		return sbomDataList;
	}

	/**
	 * @param sbomDataList
	 *            the sbomDataList to set
	 */
	public void setSbomDataList(List<PLMWhereUsedData> sbomDataList) {
		this.sbomDataList = sbomDataList;
	}

	/**
	 * @return the ebomDataList
	 */
	public List<PLMWhereUsedData> getEbomDataList() {
		return ebomDataList;
	}

	/**
	 * @param ebomDataList
	 *            the ebomDataList to set
	 */
	public void setEbomDataList(List<PLMWhereUsedData> ebomDataList) {
		this.ebomDataList = ebomDataList;
	}
	
	
	/**
	 * @return the rpdmDataList
	 */
	public List<PLMWhereUsedData> getRpdmDataList() {
		return rpdmDataList;
	}

	/**
	 * @param rpdmDataList the rpdmDataList to set
	 */
	public void setRpdmDataList(List<PLMWhereUsedData> rpdmDataList) {
		this.rpdmDataList = rpdmDataList;
	}

	/**
	 * @return the strCopics
	 */
	public String getStrCopics() {
		return strCopics;
	}

	/**
	 * @param strCopics
	 *            the strCopics to set
	 */
	public void setStrCopics(String strCopics) {
		this.strCopics = strCopics;
	}

	/**
	 * @return the strSbom
	 */
	public String getStrSbom() {
		return strSbom;
	}

	/**
	 * @param strSbom
	 *            the strSbom to set
	 */
	public void setStrSbom(String strSbom) {
		this.strSbom = strSbom;
	}

	/**
	 * @return the strEbom
	 */
	public String getStrEbom() {
		return strEbom;
	}
	
	
	

	/**
	 * @return the strrpdm
	 */
	public String getStrrpdm() {
		return strrpdm;
	}

	/**
	 * @param strrpdm the strrpdm to set
	 */
	public void setStrrpdm(String strrpdm) {
		this.strrpdm = strrpdm;
	}

	/**
	 * @param strEbom
	 *            the strEbom to set
	 */
	public void setStrEbom(String strEbom) {
		this.strEbom = strEbom;
	}

	/**
	 * @return the recordsCount
	 */
	public int getRecordsCount() {
		return recordsCount;
	}

	/**
	 * @param recordsCount
	 *            the recordsCount to set
	 */
	public void setRecordsCount(int recordsCount) {
		this.recordsCount = recordsCount;
	}

	/**
	 * @return the blnStrCopics
	 */
	public boolean isBlnStrCopics() {
		return blnStrCopics;
	}

	/**
	 * @param blnStrCopics
	 *            the blnStrCopics to set
	 */
	public void setBlnStrCopics(boolean blnStrCopics) {
		this.blnStrCopics = blnStrCopics;
	}

	/**
	 * @return the blnShwCpcsTable
	 */
	public boolean isBlnShwCpcsTable() {
		return blnShwCpcsTable;
	}

	/**
	 * @param blnShwCpcsTable
	 *            the blnShwCpcsTable to set
	 */
	public void setBlnShwCpcsTable(boolean blnShwCpcsTable) {
		this.blnShwCpcsTable = blnShwCpcsTable;
	}

	/**
	 * @return the strNoRcrdsMsgFrCopics
	 */
	public String getStrNoRcrdsMsgFrCopics() {
		return strNoRcrdsMsgFrCopics;
	}

	/**
	 * @param strNoRcrdsMsgFrCopics
	 *            the strNoRcrdsMsgFrCopics to set
	 */
	public void setStrNoRcrdsMsgFrCopics(String strNoRcrdsMsgFrCopics) {
		this.strNoRcrdsMsgFrCopics = strNoRcrdsMsgFrCopics;
	}

	/**
	 * @return the strNoRcrdsMsgFrEbom
	 */
	public String getStrNoRcrdsMsgFrEbom() {
		return strNoRcrdsMsgFrEbom;
	}

	/**
	 * @param strNoRcrdsMsgFrEbom
	 *            the strNoRcrdsMsgFrEbom to set
	 */
	public void setStrNoRcrdsMsgFrEbom(String strNoRcrdsMsgFrEbom) {
		this.strNoRcrdsMsgFrEbom = strNoRcrdsMsgFrEbom;
	}

	/**
	 * @return the strNoRcrdsMsgFrSbom
	 */
	public String getStrNoRcrdsMsgFrSbom() {
		return strNoRcrdsMsgFrSbom;
	}

	/**
	 * @param strNoRcrdsMsgFrSbom
	 *            the strNoRcrdsMsgFrSbom to set
	 */
	public void setStrNoRcrdsMsgFrSbom(String strNoRcrdsMsgFrSbom) {
		this.strNoRcrdsMsgFrSbom = strNoRcrdsMsgFrSbom;
	}

	/**
	 * @return the blnStrSbom
	 */
	public boolean isBlnStrSbom() {
		return blnStrSbom;
	}

	/**
	 * @param blnStrSbom
	 *            the blnStrSbom to set
	 */
	public void setBlnStrSbom(boolean blnStrSbom) {
		this.blnStrSbom = blnStrSbom;
	}

	/**
	 * @return the blnShwSbomTable
	 */
	public boolean isBlnShwSbomTable() {
		return blnShwSbomTable;
	}

	/**
	 * @param blnShwSbomTable
	 *            the blnShwSbomTable to set
	 */
	public void setBlnShwSbomTable(boolean blnShwSbomTable) {
		this.blnShwSbomTable = blnShwSbomTable;
	}

	/**
	 * @return the blnShwRpdmTable
	 */
	public boolean isBlnShwRpdmTable() {
		return blnShwRpdmTable;
	}

	/**
	 * @param blnShwRpdmTable the blnShwRpdmTable to set
	 */
	public void setBlnShwRpdmTable(boolean blnShwRpdmTable) {
		this.blnShwRpdmTable = blnShwRpdmTable;
	}

	/**
	 * @return the blnStrEbom
	 */
	public boolean isBlnStrEbom() {
		return blnStrEbom;
	}

	/**
	 * @return the blnStrRpdm
	 */
	public boolean isBlnStrRpdm() {
		return blnStrRpdm;
	}

	/**
	 * @param blnStrRpdm the blnStrRpdm to set
	 */
	public void setBlnStrRpdm(boolean blnStrRpdm) {
		this.blnStrRpdm = blnStrRpdm;
	}

	/**
	 * @param blnStrEbom
	 *            the blnStrEbom to set
	 */
	public void setBlnStrEbom(boolean blnStrEbom) {
		this.blnStrEbom = blnStrEbom;
	}

	/**
	 * @return the blnShwEbomTable
	 */
	public boolean isBlnShwEbomTable() {
		return blnShwEbomTable;
	}

	/**
	 * @param blnShwEbomTable
	 *            the blnShwEbomTable to set
	 */
	public void setBlnShwEbomTable(boolean blnShwEbomTable) {
		this.blnShwEbomTable = blnShwEbomTable;
	}

	/**
	 * @return the detailCopicsCounts
	 */
	public int getDetailCopicsCounts() {
		return detailCopicsCounts;
	}

	/**
	 * @param detailCopicsCounts
	 *            the detailCopicsCounts to set
	 */
	public void setDetailCopicsCounts(int detailCopicsCounts) {
		this.detailCopicsCounts = detailCopicsCounts;
	}

	/**
	 * @return the detailSBoMCounts
	 */
	public int getDetailSBoMCounts() {
		return detailSBoMCounts;
	}

	/**
	 * @param detailSBoMCounts
	 *            the detailSBoMCounts to set
	 */
	public void setDetailSBoMCounts(int detailSBoMCounts) {
		this.detailSBoMCounts = detailSBoMCounts;
	}

	/**
	 * @return the detailEBoMCounts
	 */
	public int getDetailEBoMCounts() {
		return detailEBoMCounts;
	}

	/**
	 * @param detailEBoMCounts
	 *            the detailEBoMCounts to set
	 */
	public void setDetailEBoMCounts(int detailEBoMCounts) {
		this.detailEBoMCounts = detailEBoMCounts;
	}

	/**
	 * @return the detailRpdmCounts
	 */
	public int getDetailRpdmCounts() {
		return detailRpdmCounts;
	}

	/**
	 * @param detailRpdmCounts the detailRpdmCounts to set
	 */
	public void setDetailRpdmCounts(int detailRpdmCounts) {
		this.detailRpdmCounts = detailRpdmCounts;
	}

	/**
	 * @return the copicsCounts
	 */
	public int getCopicsCounts() {
		return copicsCounts;
	}

	/**
	 * @param copicsCounts
	 *            the copicsCounts to set
	 */
	public void setCopicsCounts(int copicsCounts) {
		this.copicsCounts = copicsCounts;
	}

	/**
	 * @return the sBoMCounts
	 */
	public int getsBoMCounts() {
		return sBoMCounts;
	}

	/**
	 * @param sBoMCounts
	 *            the sBoMCounts to set
	 */
	public void setsBoMCounts(int sBoMCountsLcl) {
		this.sBoMCounts = sBoMCountsLcl;
	}

	/**
	 * @return the eBoMCounts
	 */
	public int geteBoMCounts() {
		return eBoMCounts;
	}

	/**
	 * @param eBoMCounts
	 *            the eBoMCounts to set
	 */
	public void seteBoMCounts(int eBoMCountsLcl) {
		this.eBoMCounts = eBoMCountsLcl;
	}

	/**
	 * @return the showAllTables
	 */
	public boolean isShowAllTables() {
		return showAllTables;
	}

	/**
	 * @param showAllTables
	 *            the showAllTables to set
	 */
	public void setShowAllTables(boolean showAllTables) {
		this.showAllTables = showAllTables;
	}

	/**
	 * @return the strTotRcrdsMsgFrCopics
	 */
	public String getStrTotRcrdsMsgFrCopics() {
		return strTotRcrdsMsgFrCopics;
	}

	/**
	 * @param strTotRcrdsMsgFrCopics
	 *            the strTotRcrdsMsgFrCopics to set
	 */
	public void setStrTotRcrdsMsgFrCopics(String strTotRcrdsMsgFrCopics) {
		this.strTotRcrdsMsgFrCopics = strTotRcrdsMsgFrCopics;
	}

	/**
	 * @return the strTotRcrdsMsgFrEbom
	 */
	public String getStrTotRcrdsMsgFrEbom() {
		return strTotRcrdsMsgFrEbom;
	}

	/**
	 * @param strTotRcrdsMsgFrEbom
	 *            the strTotRcrdsMsgFrEbom to set
	 */
	public void setStrTotRcrdsMsgFrEbom(String strTotRcrdsMsgFrEbom) {
		this.strTotRcrdsMsgFrEbom = strTotRcrdsMsgFrEbom;
	}

	/**
	 * @return the strTotRcrdsMsgFrSbom
	 */
	public String getStrTotRcrdsMsgFrSbom() {
		return strTotRcrdsMsgFrSbom;
	}

	/**
	 * @param strTotRcrdsMsgFrSbom
	 *            the strTotRcrdsMsgFrSbom to set
	 */
	public void setStrTotRcrdsMsgFrSbom(String strTotRcrdsMsgFrSbom) {
		this.strTotRcrdsMsgFrSbom = strTotRcrdsMsgFrSbom;
	}

	/**
	 * @return the strNoRcrdsMsgFrRpdm
	 */
	public String getStrNoRcrdsMsgFrRpdm() {
		return strNoRcrdsMsgFrRpdm;
	}

	/**
	 * @param strNoRcrdsMsgFrRpdm the strNoRcrdsMsgFrRpdm to set
	 */
	public void setStrNoRcrdsMsgFrRpdm(String strNoRcrdsMsgFrRpdm) {
		this.strNoRcrdsMsgFrRpdm = strNoRcrdsMsgFrRpdm;
	}

	/**
	 * @return the strTotRcrdsMsgFrRpdm
	 */
	public String getStrTotRcrdsMsgFrRpdm() {
		return strTotRcrdsMsgFrRpdm;
	}

	/**
	 * @param strTotRcrdsMsgFrRpdm the strTotRcrdsMsgFrRpdm to set
	 */
	public void setStrTotRcrdsMsgFrRpdm(String strTotRcrdsMsgFrRpdm) {
		this.strTotRcrdsMsgFrRpdm = strTotRcrdsMsgFrRpdm;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB
	 *            the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the impactDataLst
	 */
	public List<PLMImpactAnalysisData> getImpactDataLst() {
		return impactDataLst;
	}

	/**
	 * @param impactDataLst
	 *            the impactDataLst to set
	 */
	public void setImpactDataLst(List<PLMImpactAnalysisData> impactDataLst) {
		this.impactDataLst = impactDataLst;
	}

	/**
	 * @return the impactCnt
	 */
	public int getImpactCnt() {
		return impactCnt;
	}

	/**
	 * @param impactCnt
	 *            the impactCnt to set
	 */
	public void setImpactCnt(int impactCnt) {
		this.impactCnt = impactCnt;
	}

	/**
	 * @return the strTotRcrdsMsgFrImpct
	 */
	public String getStrTotRcrdsMsgFrImpct() {
		return strTotRcrdsMsgFrImpct;
	}

	/**
	 * @param strTotRcrdsMsgFrImpct
	 *            the strTotRcrdsMsgFrImpct to set
	 */
	public void setStrTotRcrdsMsgFrImpct(String strTotRcrdsMsgFrImpct) {
		this.strTotRcrdsMsgFrImpct = strTotRcrdsMsgFrImpct;
	}

	/**
	 * @return the impactPageCnt
	 */
	public int getImpactPageCnt() {
		return impactPageCnt;
	}

	/**
	 * @param impactPageCnt
	 *            the impactPageCnt to set
	 */
	public void setImpactPageCnt(int impactPageCnt) {
		this.impactPageCnt = impactPageCnt;
	}

	/**
	 * @return the impactPartIdLst
	 */
	public List<String> getImpactPartIdLst() {
		return impactPartIdLst;
	}

	/**
	 * @param impactPartIdLst
	 *            the impactPartIdLst to set
	 */
	public void setImpactPartIdLst(List<String> impactPartIdLst) {
		List<String> impctLst = new ArrayList<String>();
		impctLst.addAll(impactPartIdLst);
		this.impactPartIdLst = impctLst;
	}

	/**
	 * @return the wuPrtIdLst
	 */
	public List<String> getWuPrtIdLst() {
		return wuPrtIdLst;
	}

	/**
	 * @param wuPrtIdLst
	 *            the wuPrtIdLst to set
	 */
	public void setWuPrtIdLst(List<String> wuPrtIdLst) {
		this.wuPrtIdLst = wuPrtIdLst;
	}

	/**
	 * @return the wuFlag
	 */
	public String getWuFlag() {
		return wuFlag;
	}

	/**
	 * @param wuFlag
	 *            the wuFlag to set
	 */
	public void setWuFlag(String wuFlag) {
		this.wuFlag = wuFlag;
	}

	/**
	 * @return the ebomimpactList1
	 */
	public List<PLMImpactAnalysisData> getEbomimpactList1() {
		return ebomimpactList1;
	}

	/**
	 * @param ebomimpactList1
	 *            the ebomimpactList1 to set
	 */
	public void setEbomimpactList1(List<PLMImpactAnalysisData> ebomimpactList1) {
		this.ebomimpactList1 = ebomimpactList1;
	}

	/**
	 * @return the ebomimpactList2
	 */
	public List<PLMImpactAnalysisData> getEbomimpactList2() {
		return ebomimpactList2;
	}

	/**
	 * @param ebomimpactList2
	 *            the ebomimpactList2 to set
	 */
	public void setEbomimpactList2(List<PLMImpactAnalysisData> ebomimpactList2) {
		this.ebomimpactList2 = ebomimpactList2;
	}

	/**
	 * @return the ebomimpactList3
	 */
	public List<PLMImpactAnalysisData> getEbomimpactList3() {
		return ebomimpactList3;
	}

	/**
	 * @param ebomimpactList3
	 *            the ebomimpactList3 to set
	 */
	public void setEbomimpactList3(List<PLMImpactAnalysisData> ebomimpactList3) {
		this.ebomimpactList3 = ebomimpactList3;
	}

	/**
	 * @return the ebomimpactCnt1
	 */
	public int getEbomimpactCnt1() {
		return ebomimpactCnt1;
	}

	/**
	 * @param ebomimpactCnt1
	 *            the ebomimpactCnt1 to set
	 */
	public void setEbomimpactCnt1(int ebomimpactCnt1) {
		this.ebomimpactCnt1 = ebomimpactCnt1;
	}

	/**
	 * @return the ebomimpactCnt2
	 */
	public int getEbomimpactCnt2() {
		return ebomimpactCnt2;
	}

	/**
	 * @param ebomimpactCnt2
	 *            the ebomimpactCnt2 to set
	 */
	public void setEbomimpactCnt2(int ebomimpactCnt2) {
		this.ebomimpactCnt2 = ebomimpactCnt2;
	}

	/**
	 * @return the ebomimpactCnt3
	 */
	public int getEbomimpactCnt3() {
		return ebomimpactCnt3;
	}

	/**
	 * @param ebomimpactCnt3
	 *            the ebomimpactCnt3 to set
	 */
	public void setEbomimpactCnt3(int ebomimpactCnt3) {
		this.ebomimpactCnt3 = ebomimpactCnt3;
	}

	/**
	 * @return the mbomimpactList1
	 */
	public List<PLMImpactAnalysisData> getMbomimpactList1() {
		return mbomimpactList1;
	}

	/**
	 * @param mbomimpactList1
	 *            the mbomimpactList1 to set
	 */
	public void setMbomimpactList1(List<PLMImpactAnalysisData> mbomimpactList1) {
		this.mbomimpactList1 = mbomimpactList1;
	}

	/**
	 * @return the mbomimpactList2
	 */
	public List<PLMImpactAnalysisData> getMbomimpactList2() {
		return mbomimpactList2;
	}

	/**
	 * @param mbomimpactList2
	 *            the mbomimpactList2 to set
	 */
	public void setMbomimpactList2(List<PLMImpactAnalysisData> mbomimpactList2) {
		this.mbomimpactList2 = mbomimpactList2;
	}

	/**
	 * @return the mbomimpactList3
	 */
	public List<PLMImpactAnalysisData> getMbomimpactList3() {
		return mbomimpactList3;
	}

	/**
	 * @param mbomimpactList3
	 *            the mbomimpactList3 to set
	 */
	public void setMbomimpactList3(List<PLMImpactAnalysisData> mbomimpactList3) {
		this.mbomimpactList3 = mbomimpactList3;
	}

	/**
	 * @return the mbomimpactCnt1
	 */
	public int getMbomimpactCnt1() {
		return mbomimpactCnt1;
	}

	/**
	 * @param mbomimpactCnt1
	 *            the mbomimpactCnt1 to set
	 */
	public void setMbomimpactCnt1(int mbomimpactCnt1) {
		this.mbomimpactCnt1 = mbomimpactCnt1;
	}

	/**
	 * @return the mbomimpactCnt2
	 */
	public int getMbomimpactCnt2() {
		return mbomimpactCnt2;
	}

	/**
	 * @param mbomimpactCnt2
	 *            the mbomimpactCnt2 to set
	 */
	public void setMbomimpactCnt2(int mbomimpactCnt2) {
		this.mbomimpactCnt2 = mbomimpactCnt2;
	}

	/**
	 * @return the mbomimpactCnt3
	 */
	public int getMbomimpactCnt3() {
		return mbomimpactCnt3;
	}

	/**
	 * @param mbomimpactCnt3
	 *            the mbomimpactCnt3 to set
	 */
	public void setMbomimpactCnt3(int mbomimpactCnt3) {
		this.mbomimpactCnt3 = mbomimpactCnt3;
	}

	/**
	 * @return the partName1
	 */
	public String getPartName1() {
		return partName1;
	}

	/**
	 * @param partName1
	 *            the partName1 to set
	 */
	public void setPartName1(String partName1) {
		this.partName1 = partName1;
	}

	/**
	 * @return the partName2
	 */
	public String getPartName2() {
		return partName2;
	}

	/**
	 * @param partName2
	 *            the partName2 to set
	 */
	public void setPartName2(String partName2) {
		this.partName2 = partName2;
	}

	/**
	 * @return the partName3
	 */
	public String getPartName3() {
		return partName3;
	}

	/**
	 * @param partName3
	 *            the partName3 to set
	 */
	public void setPartName3(String partName3) {
		this.partName3 = partName3;
	}

	/**
	 * @return the ebomResultMsg1
	 */
	public String getEbomResultMsg1() {
		return ebomResultMsg1;
	}

	/**
	 * @param ebomResultMsg1
	 *            the ebomResultMsg1 to set
	 */
	public void setEbomResultMsg1(String ebomResultMsg1) {
		this.ebomResultMsg1 = ebomResultMsg1;
	}

	/**
	 * @return the ebomResultMsg2
	 */
	public String getEbomResultMsg2() {
		return ebomResultMsg2;
	}

	/**
	 * @param ebomResultMsg2
	 *            the ebomResultMsg2 to set
	 */
	public void setEbomResultMsg2(String ebomResultMsg2) {
		this.ebomResultMsg2 = ebomResultMsg2;
	}

	/**
	 * @return the ebomResultMsg3
	 */
	public String getEbomResultMsg3() {
		return ebomResultMsg3;
	}

	/**
	 * @param ebomResultMsg3
	 *            the ebomResultMsg3 to set
	 */
	public void setEbomResultMsg3(String ebomResultMsg3) {
		this.ebomResultMsg3 = ebomResultMsg3;
	}

	/**
	 * @return the mbomResultMsg1
	 */
	public String getMbomResultMsg1() {
		return mbomResultMsg1;
	}

	/**
	 * @param mbomResultMsg1
	 *            the mbomResultMsg1 to set
	 */
	public void setMbomResultMsg1(String mbomResultMsg1) {
		this.mbomResultMsg1 = mbomResultMsg1;
	}

	/**
	 * @return the mbomResultMsg2
	 */
	public String getMbomResultMsg2() {
		return mbomResultMsg2;
	}

	/**
	 * @param mbomResultMsg2
	 *            the mbomResultMsg2 to set
	 */
	public void setMbomResultMsg2(String mbomResultMsg2) {
		this.mbomResultMsg2 = mbomResultMsg2;
	}

	/**
	 * @return the mbomResultMsg3
	 */
	public String getMbomResultMsg3() {
		return mbomResultMsg3;
	}

	/**
	 * @param mbomResultMsg3
	 *            the mbomResultMsg3 to set
	 */
	public void setMbomResultMsg3(String mbomResultMsg3) {
		this.mbomResultMsg3 = mbomResultMsg3;
	}

	/**
	 * @return the userDataObj1
	 */
	public PLMLoginData getUserDataObj1() {
		return userDataObj1;
	}

	/**
	 * @return the ebomRowCnt1
	 */
	public int getEbomRowCnt1() {
		return ebomRowCnt1;
	}

	/**
	 * @param ebomRowCnt1 the ebomRowCnt1 to set
	 */
	public void setEbomRowCnt1(int ebomRowCnt1) {
		this.ebomRowCnt1 = ebomRowCnt1;
	}

	/**
	 * @return the mbomRowCnt1
	 */
	public int getMbomRowCnt1() {
		return mbomRowCnt1;
	}

	/**
	 * @param mbomRowCnt1 the mbomRowCnt1 to set
	 */
	public void setMbomRowCnt1(int mbomRowCnt1) {
		this.mbomRowCnt1 = mbomRowCnt1;
	}

	/**
	 * @return the ebomRowCnt2
	 */
	public int getEbomRowCnt2() {
		return ebomRowCnt2;
	}

	/**
	 * @param ebomRowCnt2 the ebomRowCnt2 to set
	 */
	public void setEbomRowCnt2(int ebomRowCnt2) {
		this.ebomRowCnt2 = ebomRowCnt2;
	}

	/**
	 * @return the mbomRowCnt2
	 */
	public int getMbomRowCnt2() {
		return mbomRowCnt2;
	}

	/**
	 * @param mbomRowCnt2 the mbomRowCnt2 to set
	 */
	public void setMbomRowCnt2(int mbomRowCnt2) {
		this.mbomRowCnt2 = mbomRowCnt2;
	}

	/**
	 * @return the ebomRowCnt3
	 */
	public int getEbomRowCnt3() {
		return ebomRowCnt3;
	}

	/**
	 * @param ebomRowCnt3 the ebomRowCnt3 to set
	 */
	public void setEbomRowCnt3(int ebomRowCnt3) {
		this.ebomRowCnt3 = ebomRowCnt3;
	}

	/**
	 * @return the mbomRowCnt3
	 */
	public int getMbomRowCnt3() {
		return mbomRowCnt3;
	}

	/**
	 * @param mbomRowCnt3 the mbomRowCnt3 to set
	 */
	public void setMbomRowCnt3(int mbomRowCnt3) {
		this.mbomRowCnt3 = mbomRowCnt3;
	}

	/**
	 * @param userDataObj1
	 *            the userDataObj1 to set
	 */
	public void setUserDataObj1(PLMLoginData userDataObj1) {
		this.userDataObj1 = userDataObj1;
	}

	
	
	
	/**
	 * @return the rpdmCounts
	 */
	public int getRpdmCounts() {
		return rpdmCounts;
	}

	/**
	 * @param rpdmCounts the rpdmCounts to set
	 */
	public void setRpdmCounts(int rpdmCounts) {
		this.rpdmCounts = rpdmCounts;
	}

	public void downloadImpactAnalysisTab1Exl() throws PLMCommonException {

		LOG.info("Entering download ImpactAnalysisTab1 Method");
		String reportName = "impactAnalysisTab1";
		String fileName = "impactAnalysisTab1";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		HashMap<String, PLMXlsxRptColumnData> rptColDataMap = new HashMap<String, PLMXlsxRptColumnData>();
		
		PLMXlsxRptColumnData rptColData = new PLMXlsxRptColumnData();
	
		PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
				new PLMXlsxRptColumn("immediateParent", "Immediate Parent",
						FormatType.TEXT, null, null, 20),
				new PLMXlsxRptColumn("immediateParentRev", "Immdt.Parent Rev",
						FormatType.TEXT, null, null, 13),
				new PLMXlsxRptColumn("topLvlParentNm", "Top Level Parent",
						FormatType.TEXT, null, null, 20),
				new PLMXlsxRptColumn("lgclFtrNm", "Logical Feature",
						FormatType.TEXT, null, null, 20),
				new PLMXlsxRptColumn("lgclFtrType", "LF Type", FormatType.TEXT,
						null, null, 20),
				new PLMXlsxRptColumn("prdtCnfgNm", "Product Configuration",
						FormatType.TEXT, null, null, 20),
				new PLMXlsxRptColumn("hwBldNm", "Hw Build Name",
						FormatType.TEXT, null, null, 15),
				new PLMXlsxRptColumn("hwBldState", "Hw Build State",
						FormatType.TEXT, null, null, 15),
				new PLMXlsxRptColumn("bldRelDate", "Build Rel. Date",
						FormatType.TEXT, null, null, 20),
				new PLMXlsxRptColumn("plantNm", "Plant Name", FormatType.TEXT,
						null, null, 20),
				new PLMXlsxRptColumn("partNm", "Part Name", FormatType.TEXT,
						null, null, 20),

		};
		rptColData.setData(ebomimpactList1);
		rptColData.setColumns(reportColumns);
		
		rptColDataMap.put("ebomimpactList1", rptColData);
		
		PLMXlsxRptColumn[] reportColumns1 = new PLMXlsxRptColumn[] {
				new PLMXlsxRptColumn("immediateParent", "Immediate Parent",
						FormatType.TEXT, null, null, 20),
				new PLMXlsxRptColumn("immediateParentRev", "Immdt.Parent Rev",
						FormatType.TEXT, null, null, 13),
				new PLMXlsxRptColumn("topLvlParentNm", "Top Level Parent",
						FormatType.TEXT, null, null, 20),
				new PLMXlsxRptColumn("lgclFtrNm", "Manufacturing Feature",
						FormatType.TEXT, null, null, 20),
				new PLMXlsxRptColumn("prdtCnfgNm", "Product Configuration",
						FormatType.TEXT, null, null, 20),
				new PLMXlsxRptColumn("hwBldNm", "Hw Build Name",
						FormatType.TEXT, null, null, 20),
				new PLMXlsxRptColumn("hwBldState", "Hw Build State",
						FormatType.TEXT, null, null, 15),
				new PLMXlsxRptColumn("bldRelDate", "Build Rel. Date",
						FormatType.TEXT, null, null, 15),
				new PLMXlsxRptColumn("plantNm", "Plant Name", FormatType.TEXT,
						null, null, 20),
				new PLMXlsxRptColumn("partNm", "Part Name", FormatType.TEXT,
						null, null, 20),

		};

		rptColData = new PLMXlsxRptColumnData();
		
		rptColData.setData(mbomimpactList1);
		rptColData.setColumns(reportColumns1);
		
		rptColDataMap.put("mbomimpactList1", rptColData);

		excelUtil.exportList(rptColDataMap, reportName, fileName, false);

	}

	public void downloadImpactAnalysisTab2Exl() throws PLMCommonException {

		LOG.info("Entering download ImpactAnalysisTab2 Method");
		String reportName = "impactAnalysisTab2";
		String fileName = "impactAnalysisTab2";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		HashMap<String, PLMXlsxRptColumnData> rptColDataMap = new HashMap<String, PLMXlsxRptColumnData>();
		
		PLMXlsxRptColumnData rptColData = new PLMXlsxRptColumnData();

		PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
						new PLMXlsxRptColumn("immediateParent", "Immediate Parent",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("immediateParentRev", "Immdt.Parent Rev",
								FormatType.TEXT, null, null, 13),
						new PLMXlsxRptColumn("topLvlParentNm", "Top Level Parent",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("lgclFtrNm", "Logical Feature",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("lgclFtrType", "LF Type", FormatType.TEXT,
								null, null, 20),
						new PLMXlsxRptColumn("prdtCnfgNm", "Product Configuration",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("hwBldNm", "Hw Build Name",
								FormatType.TEXT, null, null, 15),
						new PLMXlsxRptColumn("hwBldState", "Hw Build State",
								FormatType.TEXT, null, null, 15),
						new PLMXlsxRptColumn("bldRelDate", "Build Rel. Date",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("plantNm", "Plant Name", FormatType.TEXT,
								null, null, 20),
						new PLMXlsxRptColumn("partNm", "Part Name", FormatType.TEXT,
								null, null, 20),

				};
		
		rptColData.setData(ebomimpactList2);
		rptColData.setColumns(reportColumns);
		
		rptColDataMap.put("ebomimpactList2", rptColData);
		
		PLMXlsxRptColumn[] reportColumns1 = new PLMXlsxRptColumn[] {
						new PLMXlsxRptColumn("immediateParent", "Immediate Parent",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("immediateParentRev", "Immdt.Parent Rev",
								FormatType.TEXT, null, null, 13),
						new PLMXlsxRptColumn("topLvlParentNm", "Top Level Parent",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("lgclFtrNm", "Manufacturing Feature",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("prdtCnfgNm", "Product Configuration",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("hwBldNm", "Hw Build Name",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("hwBldState", "Hw Build State",
								FormatType.TEXT, null, null, 15),
						new PLMXlsxRptColumn("bldRelDate", "Build Rel. Date",
								FormatType.TEXT, null, null, 15),
						new PLMXlsxRptColumn("plantNm", "Plant Name", FormatType.TEXT,
								null, null, 20),
						new PLMXlsxRptColumn("partNm", "Part Name", FormatType.TEXT,
								null, null, 20),

				};

		rptColData = new PLMXlsxRptColumnData();
		
		rptColData.setData(mbomimpactList2);
		rptColData.setColumns(reportColumns1);
		
		rptColDataMap.put("mbomimpactList2", rptColData);

		excelUtil.exportList(rptColDataMap, reportName, fileName, false);

	}

	public void downloadImpactAnalysisTab3Exl() throws PLMCommonException {

		LOG.info("Entering download ImpactAnalysisTab3 Method");
		String reportName = "ImpactAnalysisTab3";
		String fileName = "ImpactAnalysisTab3";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		HashMap<String, PLMXlsxRptColumnData> rptColDataMap = new HashMap<String, PLMXlsxRptColumnData>();
		
		PLMXlsxRptColumnData rptColData = new PLMXlsxRptColumnData();


		PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
						new PLMXlsxRptColumn("immediateParent", "Immediate Parent",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("immediateParentRev", "Immdt.Parent Rev",
								FormatType.TEXT, null, null, 13),
						new PLMXlsxRptColumn("topLvlParentNm", "Top Level Parent",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("lgclFtrNm", "Logical Feature",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("lgclFtrType", "LF Type", FormatType.TEXT,
								null, null, 20),
						new PLMXlsxRptColumn("prdtCnfgNm", "Product Configuration",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("hwBldNm", "Hw Build Name",
								FormatType.TEXT, null, null, 15),
						new PLMXlsxRptColumn("hwBldState", "Hw Build State",
								FormatType.TEXT, null, null, 15),
						new PLMXlsxRptColumn("bldRelDate", "Build Rel. Date",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("plantNm", "Plant Name", FormatType.TEXT,
								null, null, 20),
						new PLMXlsxRptColumn("partNm", "Part Name", FormatType.TEXT,
								null, null, 20),

				};
		
		rptColData.setData(ebomimpactList3);
		rptColData.setColumns(reportColumns);
		
		rptColDataMap.put("ebomimpactList3", rptColData);
		
		PLMXlsxRptColumn[] reportColumns1 = new PLMXlsxRptColumn[] {
						new PLMXlsxRptColumn("immediateParent", "Immediate Parent",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("immediateParentRev", "Immdt.Parent Rev",
								FormatType.TEXT, null, null, 13),
						new PLMXlsxRptColumn("topLvlParentNm", "Top Level Parent",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("lgclFtrNm", "Manufacturing Feature",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("prdtCnfgNm", "Product Configuration",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("hwBldNm", "Hw Build Name",
								FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("hwBldState", "Hw Build State",
								FormatType.TEXT, null, null, 15),
						new PLMXlsxRptColumn("bldRelDate", "Build Rel. Date",
								FormatType.TEXT, null, null, 15),
						new PLMXlsxRptColumn("plantNm", "Plant Name", FormatType.TEXT,
								null, null, 20),
						new PLMXlsxRptColumn("partNm", "Part Name", FormatType.TEXT,
								null, null, 20),

				};


		rptColData = new PLMXlsxRptColumnData();
		
		rptColData.setData(mbomimpactList3);
		rptColData.setColumns(reportColumns1);
		
		rptColDataMap.put("mbomimpactList3", rptColData);

		excelUtil.exportList(rptColDataMap, reportName, fileName, false);

	}

}