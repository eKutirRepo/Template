/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEBOMPddrDaoIfc.java
 * @Creation date: 05-Dec-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.data.PLMEBOMPddrData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMEBOMPddrDaoIfc {
	/**
	 * This method is used to get drop down values
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEBOMPddrData> getEbomRevisions(String partName)throws PLMCommonException;
	/**
	 * This method is used to get EBOM Pddr Report
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEBOMPddrData> getEBOMPddrReport(String partName,String revisionName)throws PLMCommonException;

}
