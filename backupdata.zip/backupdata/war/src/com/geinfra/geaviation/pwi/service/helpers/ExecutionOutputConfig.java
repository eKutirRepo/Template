/**
 * 
 */
package com.geinfra.geaviation.pwi.service.helpers;

import java.util.List;
import java.util.Map;

import com.geinfra.geaviation.pwi.service.vo.ExecutionMode;

/**
*
* Project      : Product Lifecycle Management Intelligence
* Date Written : September 23, 2011
* Security     : GE Confidential
* Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
* Copyright(C) 2013 GE All rights reserved
*
* Description :
*
* Revision Log September 23, 2011 | v1.0.
* --------------------------------------------------------------
*/
public class ExecutionOutputConfig {
	private List<ExecutionOutputTuple> available;
	private Map<ExecutionMode, ExecutionOutputTuple> defaults;
	private ExecutionOutputTuple initial;

	public ExecutionOutputConfig(List<ExecutionOutputTuple> available,
			Map<ExecutionMode, ExecutionOutputTuple> defaults,
			ExecutionOutputTuple initial) {
		this.available = available;
		this.defaults = defaults;
		this.initial = initial;
	}

	public List<ExecutionOutputTuple> getAvailable() {
		return available;
	}

	public Map<ExecutionMode, ExecutionOutputTuple> getDefaults() {
		return defaults;
	}

	public ExecutionOutputTuple getInitial() {
		return initial;
	}
}