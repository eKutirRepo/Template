/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMAdminServiceIfc.java
 * @Creation date: 17-Jul-2009
 * @version 1.0
 * @author Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMAdminData;
import com.geinfra.geaviation.pwi.data.PLMAdminReportsData;
import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.data.PLMReportData;
import com.geinfra.geaviation.pwi.data.PLMRequestData;
import com.geinfra.geaviation.pwi.data.PLMSecurityMatrixData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;



/**
 * PLMAdminServiceIfc is the Service interface used for PLM Administrator Menu.
 */
public interface PLMAdminServiceIfc {

	/**
	 * This method is used to get list of reports
	 * 
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMAdminData> getListOfReports() throws PLMCommonException;

	/**
	 * This method is used to get the names of the reports
	 * 
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMAdminReportsData> getReportNames() throws PLMCommonException;

	/**
	 * This method is used to add data to the reports
	 * 
	 * @param reportData
	 * @param sso_id
	 * @return String
	 * @throws PLMCommonException
	 */
	public String addReportData(PLMAdminReportsData reportData, String sso_id)
			throws PLMCommonException;

	/**
	 * This method is used to modify report data
	 * 
	 * @param reportData
	 * @param oldReportName
	 * @param sso_id
	 * @return String
	 * @throws PLMCommonException
	 */
	public String modifyReportData(PLMAdminReportsData reportData,
			String oldReportName, String sso_id) throws PLMCommonException;

	/**
	 * This method is used to delete report data
	 * 
	 * @param reportData
	 * @return String
	 * @throws PLMCommonException
	 */
	public String deleteReportData(String reportData) throws PLMCommonException;

	/**
	 * This method is used to validate new user details
	 * 
	 * @param userSSO
	 * @return PLMLoginData
	 * @throws PLMCommonException
	 */
	public PLMLoginData validateUserDetails(String userSSO)
			throws PLMCommonException;

	/**
	 * This method is used to fetch user groups
	 * 
	 * @param userSSO
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<SelectItem> fetchUserGroups(String userSSO)
			throws PLMCommonException;

	/**
	 *This method is used to get permission details
	 *
	 * @param userGrp
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMLoginData> getPermissionDetails(String userGrp)
			throws PLMCommonException;

	/**
	 * This method is used to add system log event
	 * 
	 * @param userSSO
	 * @param event
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean addSystemLogEvent(String userSSO, String event)
			throws PLMCommonException;

	// Added by Kishore

	/**
	 * This method is used to get the application details
	 * 
	 * @return PLMRequestData
	 * @throws PLMCommonException
	 */
	public PLMRequestData getAppDetails() throws PLMCommonException;

	/**
	 * This method is used to request a new user
	 * 
	 * @return PLMRequestData 
	 * @throws PLMCommonException
	 */
	public PLMRequestData requestNewUser() throws PLMCommonException;

	/**
	 * This method is used to save new user data
	 * 
	 * @param requestData
	 * @param groupIdReq
	 * @param isPwiUser 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map saveNewUserRequest(PLMRequestData requestData, String groupIdReq, boolean isPwiUser)
			throws PLMCommonException;

	/**
	 * This method is used to get the change details
	 * 
	 * @param selectedVal
	 * @return PLMRequestData
	 * @throws PLMCommonException
	 */
	public PLMRequestData getChangedDetails(String selectedVal)
			throws PLMCommonException;

	/**
	 * This method is used to save the Maintain WS details
	 * 
	 * @param requestData
	 * @throws PLMCommonException
	 */
	public void saveAppDetails(PLMRequestData requestData)
			throws PLMCommonException;

	/**
	 * This method is used to save the Maintain WS details
	 * 
	 * @param maitnAnnouncements
	 * @throws PLMCommonException
	 */
	public void saveAncmtDetails(String maitnAnnouncements)
			throws PLMCommonException;

	/**
	 * This method is used to save the Maintain WS details
	 * 
	 * @param requestData
	 * @throws PLMCommonException
	 */
	public void saveIcmDetails(PLMRequestData requestData)
			throws PLMCommonException;

	// Ended by Kishore

	
	/**
	 * This method is used to get the system log contents
	 * 
	 * @param beginDate
	 * @param endDate
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMReportData> getSysLogContents(String beginDate,
			String endDate) throws PLMCommonException;

	
	// Start Of Adminusecase

	/**
	 * @return java.util.List
	 */
	public List<PLMAdminData> getListOfGroups() throws PLMCommonException;
	
	
	/**
	 * This method is used to get list of user groups
	 * 
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getListOfUserGroups() throws PLMCommonException;

	/**
	 * This method is used to get list of users
	 * 
	 * @param groupID
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMLoginData> getUserList(String groupID)
			throws PLMCommonException;

	/**
	 * This method is used to modify the users
	 * 
	 * @param ssoID
	 * @return PLMLoginData
	 * @throws PLMCommonException
	 */
	public PLMLoginData modifyUser(String ssoID) throws PLMCommonException;

	/**
	 * This method is used to add the users
	 * 
	 * @return PLMLoginData
	 * @throws PLMCommonException
	 */
	public PLMLoginData addUser() throws PLMCommonException;

	/**
	 * This method is used to validate the users
	 * 
	 * @param ssoID
	 * @return PLMLoginData
	 * @throws PLMCommonException
	 */
	public PLMLoginData validateUser(String ssoID) throws PLMCommonException;

	/**
	 * This method is used to update the users
	 * 
	 * @param userDetails
	 * @param selectedPersons
	 * @param loggedUser
	 * @param flag
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean updateUser(PLMLoginData userDetails,
			List<String> selectedPersons, String loggedUser, boolean flag)
			throws PLMCommonException;

	/**
	 * 
	 * @param userDetails
	 * @param loggedUser
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean userAdd(PLMLoginData userDetails, String loggedUser)
			throws PLMCommonException;

	/**
	 * This method is used to delete users
	 * 
	 * @param ssoID
	 * @param groupID
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean deleteUser(List<String> ssoID, String groupID)
			throws PLMCommonException;

	/**
	 * This method is used to group permissions
	 * 
	 * @param gruopId
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMSecurityMatrixData> getGroupPermissions(String gruopId)
			throws PLMCommonException;

	/**
	 * This method is used to add group
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMSecurityMatrixData> addGroup() throws PLMCommonException;

	/**
	 * This method is used to delete group
	 * 
	 * @param groupID
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean deleteGroup(String groupID) throws PLMCommonException;

	/**
	 * This method is used to update group
	 * 
	 * @param groupName
	 * @param groupDesc
	 * @param securityData
	 * @param grpFlag
	 * @param userSSo
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean updateGroup(String groupName, String groupDesc,
			ArrayList<PLMSecurityMatrixData> securityData, String grpFlag,
			String userSSo) throws PLMCommonException;

	/**
	 * 
	 * @param groupName
	 * @param groupDesc
	 * @param securityData
	 * @param grpFlag
	 * @param userSSo
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean groupAdd(String groupName, String groupDesc,
			ArrayList<PLMSecurityMatrixData> securityData, String grpFlag,
			String userSSo) throws PLMCommonException;

	/**
	 * This method is used to search user
	 * 
	 * @param searchSso
	 * @param searchFname
	 * @param searchLname
	 * @param status
	 * @param searchSso
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMLoginData> searchUser(String searchSso, String searchFname,
			String searchLname, String groupId, String status)
			throws PLMCommonException;

	// End Of Adminusecase Methods
}
