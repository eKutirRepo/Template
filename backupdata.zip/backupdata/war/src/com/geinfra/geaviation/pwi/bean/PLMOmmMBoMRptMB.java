/**
 * Copyright (C) 2012 GE Infra. 
 * All rights reserved 
 * @FileName PLMOmmMBoMRptMB.java
 * @Creation date: 26-April-2016
 * @version 2.0.1
 * @author : Tech Mahindra (PLMR Team) 
 */

package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMOmmMBoMRptData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMOmmMBoMRptServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

/**
 * PLMOmmReportMB is the managed bean class .
 */

@SuppressWarnings("deprecation")
public class PLMOmmMBoMRptMB {
	/**
	 * Holds the LOG
	 */
	private static Logger LOG = Logger.getLogger(PLMOmmMBoMRptMB.class);
	/**
	 * Holds the PLMOmmMBoMRptServiceIfc
	 */
	private PLMOmmMBoMRptServiceIfc plmOmmMBoMRptService  = null;
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the alertMBoMMessage
	 */
	private String alertMBoMMessage;
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	/**
	 * Holds the partNo
	 */
	private String partNo;
	/**
	 * Holds user information
	 */
	private PLMPwiUserData userDetails = null;
	
	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendOmmMBoMReportThroughMail();
		}
	}
	
	/**
	 * This method is used for Loading OMM MBOM Page
	 * 
	 * @return String
	 */
	public String loadOmmMBOMRptPage() {
		LOG.info("Entering loadOmmMBOMRptPage Method");
		try {
			commonMB.insertCannedRptRecordHitInfo("OMM-MBOM ERP Explosion Report");
			alertMBoMMessage = "";
			partNo="";
			} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadOmmMBOMRptPage:", exception);
		}
		LOG.info("Exiting loadOmmMBOMRptPage Method");
		return "ommMBomRptSearch";
	}
	
	/**
	 * This method is used for Generating OMM MBOM Report
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String getOmmMBoMReport() throws PWiException {
		LOG.info("Entering getOmmMBoMReport Method");
		LOG.info("Part Number Entered "+partNo);
		String fwdflag = "";
		alertMBoMMessage = "";
		alertMBoMMessage = validateOmmMBoMInput();
			try {
				if(PLMUtils.isEmpty(alertMBoMMessage)) {
				   int partNumCount =  plmOmmMBoMRptService.checkForValidPartNum(partNo);
				    if(partNumCount == 0) {
					  alertMBoMMessage = PLMConstants.OMM_MBOM_INVALID_SERIAL_NO_ALERT_MSG;
				    }else {
					    alertMBoMMessage = PLMConstants.OMM_MBOM_MAIL_ALERT_MSG;
					    userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
			    	    taskExecutor.execute(new MailThread());
				     }
				}
			 } catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getOmmMBoMReport: ", exception);
				fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"ommMBomRptSearch","OMM MBOM Report");
			}
		LOG.info("Exiting getOmmMBoMReport Method");
		return fwdflag;
	}
	
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return void
	 */
	public void sendOmmMBoMReportThroughMail() {
		LOG.info("Entering sendOmmMBoMReportThroughMail Method");
		String partNoLcl = partNo;
		String from = PLMConstants.OMM_MAIL_FROM;

		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.OMM_MBOM_MAIL_SUBJECT + partNoLcl;
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("OMM_MBOM_EXPLOSION_REPORT_NAME") +  partNoLcl + "_" + uniqTime + ".xlsx";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("OMM_MBOM_EXPLOSION_REPORT_NAME") +  partNoLcl + "_" + uniqTime + ".zip";
		try {
			 List<PLMOmmMBoMRptData> ommMBomExplosionResultList = plmOmmMBoMRptService.getOmmMBomExplosionReport(partNoLcl);
			List<PLMOmmMBoMRptData> ommSbomDeviationResultList = plmOmmMBoMRptService.getOmmSbomDeviationReport(partNoLcl);
			StringBuffer mailBody = new StringBuffer().append(toAddressee);
			if(PLMUtils.isEmptyList(ommMBomExplosionResultList) && PLMUtils.isEmptyList(ommSbomDeviationResultList)){
				mailBody.append(PLMConstants.OMM_MBOM_MAIL_CONTENT_NO_RECORD);
				mailBody.append(partNoLcl)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
			    .append(PLMConstants.OMM_MAIL_FOOTER);
				PLMUtils.sendMail(from, to, subject, mailBody.toString());
			} else {
				mailBody.append(PLMConstants.OMM_MBOM_MAIL_CONTENT);
				mailBody.append(partNoLcl).append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
			    .append(PLMConstants.OMM_MAIL_FOOTER);
				saveOmmXLSFile(partNoLcl,ommMBomExplosionResultList,ommSbomDeviationResultList,fileDir,filePathXls);
				PLMUtils.generateZipFile(filePathXls,filePathZip);
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendOmmMBoMReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendOmmMBoMReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} finally {
			deleteFiles(filePathXls,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendOmmMBoMReportThroughMail Method");
	}
	
	/**
	 * This method is used for Deleting zip file and xls file
	 * 
	 * @return void
	 */
	public void deleteFiles(String filePathXls,String filePathZip){
		LOG.info("Entering deleteFiles method");
		boolean zipFileExist;
		boolean xlsFileExist;
		File zipFile = new File(filePathZip);
		zipFileExist = zipFile.exists();
		File xlsFile = new File(filePathXls);
		xlsFileExist = xlsFile.exists();
		if(zipFileExist){
			boolean deleted = zipFile.delete();
			LOG.info("Successfully deleted zip file : " + deleted);
		}
		if(xlsFileExist){
			boolean deleted = xlsFile.delete();
			LOG.info("Successfully deleted xls file : " + deleted);
		}
		LOG.info("Exiting deleteFiles Method");
	}
	
	/**
	 * This method is used for Bordering Cell in XLS
	 * 
	 * @return XSSFCellStyle
	 */
	
	private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
		style.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style.setBorderRight(XSSFCellStyle.BORDER_THIN);
		return style;
	}
	
	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return void
	 */
	
	public void saveOmmXLSFile(String partNoLcl,
					List<PLMOmmMBoMRptData> ommCustomerDocResultList,
					List<PLMOmmMBoMRptData> ommSbomDeviationResultList,String fileDir,String filePathXls) throws IOException {
		LOG.info("Entering saveOmmXLSFile Method");
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXls);
				SXSSFWorkbook workbook = new SXSSFWorkbook();
				
				// Start : POI Styles
				XSSFFont boldFont = (XSSFFont) workbook.createFont();
				boldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				boldFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				XSSFFont normalFont = (XSSFFont) workbook.createFont();
				normalFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				XSSFFont noRecordFont = (XSSFFont) workbook.createFont(); 
				noRecordFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				noRecordFont.setColor(IndexedColors.RED.getIndex());
				noRecordFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				XSSFCellStyle titleStyle = (XSSFCellStyle) workbook.createCellStyle();
				titleStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
				titleStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
				titleStyle = setBorderStyle(titleStyle);
				titleStyle.setFont(noRecordFont);
				titleStyle.setAlignment(CellStyle.ALIGN_CENTER);
				XSSFCellStyle headerStyle = (XSSFCellStyle) workbook.createCellStyle();
				headerStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
				headerStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
				headerStyle = setBorderStyle(headerStyle);
				headerStyle.setFont(boldFont);
				headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
				XSSFCellStyle searchFieldNameStyle = (XSSFCellStyle) workbook.createCellStyle();
				searchFieldNameStyle = setBorderStyle(searchFieldNameStyle);
				searchFieldNameStyle.setFont(boldFont);
				searchFieldNameStyle.setAlignment(CellStyle.ALIGN_RIGHT);
				XSSFCellStyle cellBoldStyle = (XSSFCellStyle) workbook.createCellStyle();
				cellBoldStyle = setBorderStyle(cellBoldStyle);
				cellBoldStyle.setFont(boldFont);
				XSSFCellStyle contentStyle = (XSSFCellStyle) workbook.createCellStyle();				
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(normalFont);
				XSSFCellStyle noRecordCellStyle = (XSSFCellStyle) workbook.createCellStyle();
				noRecordCellStyle = setBorderStyle(noRecordCellStyle);
				noRecordCellStyle.setFont(noRecordFont);
				// End : POI Styles
				
				SXSSFRow row = null;
				SXSSFCell cell = null;
				SXSSFSheet sheet =  null;
				boolean noSbomDataFlg=false;
				
				int rowcount = -1;
				
				if(!PLMUtils.isEmptyList(ommCustomerDocResultList)) {
						rowcount = -1;
						sheet = (SXSSFSheet) workbook.createSheet(partNoLcl);
						// To display Search Criteria 
						row = (SXSSFRow) sheet.createRow(++rowcount);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						cell.setCellValue(PLMConstants.OMM_MBOM_SEARCH_CRITERIA_SERIAL_NO);
						cell.setCellStyle(searchFieldNameStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellValue(partNoLcl);
						cell.setCellStyle(contentStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellValue("");
						
						// One Row Space
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						// Start : To display MBOM Explosion Records
						// Title
						row = (SXSSFRow) sheet.createRow(++rowcount);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellValue(PLMConstants.OMM_MBOM_REPORT_TITLE_BOM_EXPLOSION);
						cell.setCellStyle(titleStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(titleStyle);
						sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ONE));
						cell.setCellStyle(titleStyle);
						
										
						if(!PLMUtils.isEmptyList(ommCustomerDocResultList)) {
							//Header
							String[] bomColNames = {"BOM Level#", "EID", "MLI", "Parent MLI", "PIN", "HPIN", "SUFFIX","Find Num", "TYPE", "Part#", "Part Rev", "Part State", "Part Desc", "Part Family", "Part Family Title", "Quantity", "Part UOM", "Security Class", "Export Class", "GE Drg Critical Code", "Record Id"};
							row = (SXSSFRow) sheet.createRow(++rowcount);
							for ( int i = 0 ; i < bomColNames.length; i++ ) {
								cell = (SXSSFCell) row.createCell(i);
								cell.setCellStyle(headerStyle);
								cell. setCellValue(bomColNames[i]);
							}
							String preParentMLI = "";
							String preMLI = "";
							//Header
							for(int i = 0; i < ommCustomerDocResultList.size(); i++) {
								PLMOmmMBoMRptData dataObj = (PLMOmmMBoMRptData) ommCustomerDocResultList.get(i);
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
										
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getBomLevel());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEid());
					
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
								cell.setCellStyle(contentStyle);
								if((!PLMUtils.isEmpty(dataObj.getMli()) && !dataObj.getMli().equals(preMLI))||
										(!PLMUtils.isEmpty(preMLI) && !preMLI.equals(dataObj.getMli()))){
									cell.setCellValue(dataObj.getMli());
								}else{
									cell.setCellValue("");
								 }
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getParentMLI());
					
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
								cell.setCellStyle(contentStyle);
								if((!PLMUtils.isEmpty(dataObj.getParentMLI()) && !dataObj.getParentMLI().equals(preParentMLI))||
										(!PLMUtils.isEmpty(preParentMLI) && !preParentMLI.equals(dataObj.getParentMLI()))){
									cell.setCellValue(dataObj.getPin());
								}else{
									cell.setCellValue("");
								 }
					
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getHpin());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getSuffix());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getFindNum());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getType());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartNo());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartRev());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartState());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWELVE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartDesc());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartFamily());						
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartFamilyTitle());		
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
								cell.setCellStyle(contentStyle);
								if(dataObj.getType()!=null && dataObj.getType().toUpperCase(Locale.getDefault()).contains("PART")){
									cell.setCellValue(dataObj.getQty());
								} else {
									cell.setCellValue("");
								}
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartUom());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getSecurityClass());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getExportClass());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINETEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getGeDwgCriticalCode());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWENTY);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(i+1);				    // needs to remove the comment while deployment 
								//cell.setCellValue(dataObj.getRecordId());  // for testing purpose - need to comment while deployment
								
								preParentMLI = dataObj.getParentMLI();
								preMLI = dataObj.getMli();
							}
						}
						else {
							LOG.info("No BOM Explosion Records found");
							row = (SXSSFRow) sheet.createRow(++rowcount);
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell.setCellValue(PLMConstants.OMM_NO_RECORD_FOUND);
							cell.setCellStyle(noRecordCellStyle);
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellStyle(noRecordCellStyle);
							sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ONE));
						}
				}//end of if isEmptyList(ommCustomerDocResultList)
				else {
					rowcount = -1;					
					sheet = (SXSSFSheet) workbook.createSheet(partNoLcl);
					// To display Search Criteria 
					row = (SXSSFRow) sheet.createRow(++rowcount);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					cell.setCellValue(PLMConstants.OMM_MBOM_SEARCH_CRITERIA_SERIAL_NO);
					cell.setCellStyle(searchFieldNameStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellValue(partNoLcl);
					cell.setCellStyle(contentStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellValue("");

					// One Row Space
					row = (SXSSFRow) sheet.createRow(++rowcount);
					
					// Start : To display BOM Explosion Records
					// Title
					row = (SXSSFRow) sheet.createRow(++rowcount);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellValue(PLMConstants.OMM_MBOM_REPORT_TITLE_BOM_EXPLOSION);
					cell.setCellStyle(titleStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(titleStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ONE));
					cell.setCellStyle(titleStyle);
					
					
					LOG.info("No BOM Explosion Records found");
					row = (SXSSFRow) sheet.createRow(++rowcount);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					cell.setCellValue(PLMConstants.OMM_NO_RECORD_FOUND);
					cell.setCellStyle(noRecordCellStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(noRecordCellStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ONE));
				}
				// Three Row Space
				
				//Make sure thata SBOM data is added to First Sheet of Workbook
				
				row = (SXSSFRow) sheet.createRow(++rowcount);
				row = (SXSSFRow) sheet.createRow(++rowcount);
				row = (SXSSFRow) sheet.createRow(++rowcount);
								
				// Start : To display SBOM Deviation Records
				// Title
				row = (SXSSFRow) sheet.createRow(++rowcount);
				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellValue(PLMConstants.OMM_REPORT_TITLE_SBOM_DEVIATIONS);
				cell.setCellStyle(titleStyle);
				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellStyle(titleStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ONE));
				cell.setCellStyle(titleStyle);
								
				if(!PLMUtils.isEmptyList(ommSbomDeviationResultList)) {
					// Header
					String[] sbomColNames = {"TURBINE_NO","PIN","NEW_ITEM","OLD_ITEM","SECTION","REVISION_NO","AUTHORIZATION","DESCRIPTION","DATE_APPLIED","QUANTITY","AN_NO","AUTHOR","AUTHOR_FIRST_NAME","AUTHOR_LAST_NAME","CATEGORY_NO","LOCATION","PARENT_PIN"};
					row = (SXSSFRow) sheet.createRow(++rowcount);
					for ( int i = 0 ; i < sbomColNames.length; i++ ) {
						cell = (SXSSFCell) row.createCell(i);	
						cell. setCellValue(sbomColNames[i]);
						cell.setCellStyle(headerStyle);
					}
					
					
					for(int i = 0; i < ommSbomDeviationResultList.size(); i++) {
						PLMOmmMBoMRptData dataObj = (PLMOmmMBoMRptData) ommSbomDeviationResultList.get(i);
						row = (SXSSFRow) sheet.createRow(++rowcount);

						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getTurbineNo());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getPin());
			
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getNewItem());
			
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getOldItem());
			
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getSection());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getRevisonNo());

						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAuthorization());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getDescription());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
						cell.setCellStyle(contentStyle);
						if(dataObj.getDateApplied() != null){
							cell.setCellValue(dateFormat.format(dataObj.getDateApplied()));
						} else {
							cell.setCellValue("");
						}
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getQty());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAnNum());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAuthor());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWELVE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAuthorFn());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAuthorLn());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getCatNo());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getLocation());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getParentPin());
					}
				} else {
					LOG.info("No SBOM Deviation Records found");
					noSbomDataFlg=true;
					row = (SXSSFRow) sheet.createRow(++rowcount);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					cell.setCellValue(PLMConstants.OMM_NO_RECORD_FOUND);
					cell.setCellStyle(noRecordCellStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(noRecordCellStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ONE));
				}
				// End : To display SBOM Deviation Records
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,5000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,5000);
					
					if(!noSbomDataFlg){
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,5000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,5000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,5000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,5000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,7000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,7000);
					}else{
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,2500);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,3000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,2000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,2000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,3000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,3000);
					}
						
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,7200);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE,5000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN,3000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN, 3000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWELVE, 10000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTEEN, 10000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTEEN,5500);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTEEN,5000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIXTEEN,3500);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVENTEEN, 5500);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHTEEN,5200);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINETEEN,6000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTY,3000);
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveOmmXLSFile: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveOmmXLSFile: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveOmmXLSFile: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveOmmXLSFile Method");
	}

	
	/**
	 * This method is used for Validating OMM User Input
	 * 
	 * @return String
	 */
	public String validateOmmMBoMInput() {
		LOG.info("Entering validateOmmMBoMInput Method");
		LOG.info("Entered Part No : " + partNo);
		String alertMsg = "";
		if(PLMUtils.isEmpty(partNo)){
			alertMsg = PLMConstants.OMM_MBOM_SEARCH_CRITERIA;
		} else if(!PLMUtils.checkForSpecialChars(partNo)){
			alertMsg = PLMConstants.OMM_MBOM_SERIAL_NO_SPLCHAR_CRITERIA;
		}
		LOG.info("Exiting validateOmmMBoMInput Method");
		return alertMsg;
	}

	/**
	 * This method is used for Resetting the User input
	 * 
	 * @return String
	 */
	
	public String resetData() {
		LOG.info("Entering OMM MBoM Reset Method");
		String fwdflag = "ommMBomRptSearch";
			partNo="";
		LOG.info("Exiting OMM MBoM Reset Method");
		return fwdflag;
	}

	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}

	/**
	 * @param log the lOG to set
	 */
	public static void setLOG(Logger log) {
		LOG = log;
	}

	/**
	 * @return the plmOmmMBoMRptService
	 */
	public PLMOmmMBoMRptServiceIfc getPlmOmmMBoMRptService() {
		return plmOmmMBoMRptService;
	}

	/**
	 * @param plmOmmMBoMRptService the plmOmmMBoMRptService to set
	 */
	public void setPlmOmmMBoMRptService(PLMOmmMBoMRptServiceIfc plmOmmMBoMRptService) {
		this.plmOmmMBoMRptService = plmOmmMBoMRptService;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return the setAlertMBoMMessage
	 */
	public String getAlertMBoMMessage() {
		return alertMBoMMessage;
	}

	/**
	 * @param alertMBoMMessage the alertMBoMMessage to set
	 */
	public void setAlertMBoMMessage(String alertMBoMMessage) {
		this.alertMBoMMessage = alertMBoMMessage;
	}

	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the partNo
	 */
	public String getPartNo() {
		return partNo;
	}

	/**
	 * @param partNo the partNo to set
	 */
	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

}