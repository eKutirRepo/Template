/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMSearchDaoImpl.java
 * @Creation date: 26-Oct-2010
 * @version 1.0
 */

package com.geinfra.geaviation.pwi.dao;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMCostChngData;
import com.geinfra.geaviation.pwi.data.PLMDrawingSearchData;
import com.geinfra.geaviation.pwi.data.PLMSearchData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

/**
 * PLMSearchDaoImpl is the DAO implementation class.
 */
public class PLMSearchDaoImpl extends SimpleJdbcDaoSupport implements
		PLMSearchDaoIfc {

	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMSearchDaoImpl.class);
	/**
	 * Holds the simple data foramt.
	 */
	/*private static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
			"yyyy-MM-dd");*/
	
	@SuppressWarnings("unchecked")
	/**
	 * This method is used for getStateDropDownvalues
	 * 
	 * @param searchResultsQry
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getStateDropDownvalues()
			throws PLMCommonException {
		LOG.info ("Entering getStateDropDownvalues method ");
		Map<String, List<SelectItem>> stateDropDownList = null;
		try{
		stateDropDownList = new HashMap<String, List<SelectItem>>();
		List<SelectItem> stateList = null;
		LOG.info("State Query is : " + PLMSearchQueries.GET_DOCUMENT_STATE);
		stateList = getJdbcTemplate().query(PLMSearchQueries.GET_DOCUMENT_STATE,new StateMapper());
		stateDropDownList.put("documentstate", stateList);
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info ("Exiting getStateDropDownvalues method ");
		return stateDropDownList;
	}
	/**
	 * Mapper for the getting the State values
	 */
	//private static ParameterizedRowMapper<SelectItem> stateMapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class StateMapper implements 	ParameterizedRowMapper<SelectItem>{
	public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
			SelectItem selectItem = new SelectItem(rs.getString(PLMConstants.DOC_STATE));
			return selectItem;
		}
	//	};
	}
	
	
	/**
	 * This method is used for getSearchDetails
	 * 
	 * @param searchData
	 * @return ICMSearchData
	 * @throws PLMCommonException
	 */
	public List<PLMSearchData> getSearchDetails(PLMSearchData searchData)
			throws PLMCommonException {
		LOG.info("Entering getSearchDetails() method.");
		
		List<PLMSearchData> searchResultList = null;
		boolean whereFlag = false;
		try{
		StringBuffer searchResultsQry = new StringBuffer();
		searchResultsQry.append(PLMSearchQueries.GET_DOCUMENT_DETAILS);
		
		if (searchData.getName() != null) {
			searchData.setName(searchData.getName().trim());
		}
		if (searchData.getRev() != null) {
			searchData.setRev(searchData.getRev().trim());
		}
		if (searchData.getOwner() != null) {
			searchData.setOwner(searchData.getOwner().trim());
		}
		if (searchData.getDesc() != null) {
			searchData.setDesc(searchData.getDesc().trim());
		}
		if (searchData.getRdo() != null) {
			searchData.setRdo(searchData.getRdo().trim());
		}
		if (searchData.getStateListData() != null) {
			searchData.setStateExcel(PLMUtils.setListForQuery(searchData.getStateListData()));
		}
			
		if (searchData.getName() != null && searchData.getName().length() > 0) {
			whereFlag = true;
			searchResultsQry.append(" WHERE ");
			searchResultsQry.append(PLMUtils.generateQueryWhereClause(PLMConstants.DOC_NAME, searchData.getName()));
		}
		
		if (searchData.getRev() != null && searchData.getRev().length() > 0) {
			if (whereFlag) {
				searchResultsQry.append(" AND ");
			} else {
				searchResultsQry.append(" WHERE ");
				whereFlag = true;
			}
			searchResultsQry.append(PLMUtils.generateQueryWhereClause(PLMConstants.DOC_REV, searchData.getRev()));
		}
		
		if (searchData.getOwner() != null && searchData.getOwner().length() > 0) {
			if (whereFlag) {
				searchResultsQry.append(" AND ");
			} else {
				searchResultsQry.append(" WHERE ");
				whereFlag = true;
			}
			searchResultsQry.append(PLMUtils.generateQueryWhereClause(PLMConstants.DOC_OWNER, searchData.getOwner()));
		}
		
		if (searchData.getDesc() != null && searchData.getDesc().length() > 0) {
			if (whereFlag) {
				searchResultsQry.append(" AND ");
			} else {
				searchResultsQry.append(" WHERE ");
				whereFlag = true;
			}
			searchResultsQry.append(PLMUtils.generateQueryWhereClause(PLMConstants.DOC_DESC, searchData.getDesc()));
		}
		
		if (searchData.getRdo() != null && searchData.getRdo().length() > 0) {
			if (whereFlag) {
				searchResultsQry.append(" AND ");
			} else {
				searchResultsQry.append(" WHERE ");
				whereFlag = true;
			}
			searchResultsQry.append(PLMUtils.generateQueryWhereClause(PLMConstants.DOC_RDO, searchData.getRdo()));
		}
		
		if (searchData.getStateListData() != null
				&& searchData.getStateListData().size() > 0) {

			if (whereFlag) {
				searchResultsQry.append(" AND ");
			} else {
				searchResultsQry.append(" WHERE ");
				whereFlag = true;
			}
			searchResultsQry.append(PLMConstants.DOC_STATE);
			searchResultsQry.append(" IN ");
			searchResultsQry.append("(");
			searchResultsQry.append(PLMUtils.setListForQuery(searchData.getStateListData()) + ")");
		}
		
		LOG.info("Document Search Query is : " + searchResultsQry);
		searchResultList = getSimpleJdbcTemplate().query(searchResultsQry.toString(), new SearchResultsMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return searchResultList;

	}

	/**
	 * This procedure is for getting item Details
	 * 
	 * @param docname
	 * @param docrev
	 * @param docdesc
	 * @return PLMSearchData
	 * @throws PLMCommonException
	 */

	/*public PLMSearchData itemDetails(String docname, String docrev,
			String docdesc) throws PLMCommonException {
		LOG.info("Entered into the Dao for itemDetails---------");
		PLMSearchData plmDataPopup = new PLMSearchData();
		StringBuffer searchResultsQry = new StringBuffer();
		searchResultsQry.append(PLMQueryConstants.GET_RELATED_DETAILS1);
		searchResultsQry.append("'DOC_NAME='");
		searchResultsQry.append(docname);
		searchResultsQry.append("'");
		searchResultsQry.append("'AND DOC_REV='");
		searchResultsQry.append(docrev);
		searchResultsQry.append("'");
		searchResultsQry.append("'AND DOC_DESC='");
		searchResultsQry.append(docdesc);
		searchResultsQry.append("'");
		LOG.info("searchResultsQry finally is ::" + searchResultsQry + ":::::");
		List<PLMSearchData> popupDetails = getSimpleJdbcTemplate().query(
				searchResultsQry.toString(), getPopup);
		if (popupDetails != null && popupDetails.size() > 0) {
			plmDataPopup = (PLMSearchData) popupDetails.get(0);
		}
		return plmDataPopup;
	}*/

	/**
	 * Mapper for Getting Search results
	 */
	//private static ParameterizedRowMapper<PLMSearchData> searchResultsMapper = new ParameterizedRowMapper<PLMSearchData>() {
	private static final class SearchResultsMapper implements ParameterizedRowMapper<PLMSearchData>{	
	public PLMSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			PLMSearchData searchData = new PLMSearchData();
			searchData.setName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOC_NAME)));
			searchData.setRev(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOC_REV)));
			searchData.setRdo(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOC_RDO)));
			searchData.setLastupd(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOC_LASTUPDATE)));
			searchData.setDesc(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOC_DESC)));
			searchData.setOwner(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOC_OWNER)));
			searchData.setState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOC_STATE)));
			searchData.setIpClass(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOC_IPCLASS)));
			searchData.setExpCntrl(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOC_EXPORTCONT)));
			searchData.setGeSheet(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOC_GE_SHEET)));
			searchData.setEcoName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOC_ECO_NAME)));
			searchData.setEcoRde(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOC_ECO_RESP)));
			searchData.setEcoDesc(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOC_ECO_DESC)));
			searchData.setEcoState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOC_ECO_STATE)));

			return searchData;

		}
	//	};
	}

	
	/**
	 * This method is used for getDrawingData
	 * 
	 * @param searchData
	 * @return ICMSearchData
	 * @throws ICMCommonException
	 */
	public List<PLMDrawingSearchData> getDrawingData(
			PLMDrawingSearchData searchData) throws PLMCommonException {
		LOG.info("Entered into getDrawingData() method");
		StringBuffer createVtQry = new StringBuffer();
		StringBuffer insertVtQry1 = new StringBuffer();
		StringBuffer insertVtQry2 = new StringBuffer();
		StringBuffer appendVtQryCond = new StringBuffer();
		StringBuffer searchResultsQry = new StringBuffer();
		boolean rtTaskFlg = false;
		List<PLMDrawingSearchData> searchResultList = new ArrayList<PLMDrawingSearchData>();
		String timeStamp = null;
		String WF_QUE_VT_QRY = null;
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(
		"MM/dd/yyyy");
		try{
			timeStamp = PLMUtils.volTableFormatDate();
			
			WF_QUE_VT_QRY = PLMConstants.WF_QUE_VT.concat(timeStamp);
			
			boolean whereFlag = false;
			if (searchData.getTask_owner() != null) {
				searchData.setTask_owner(searchData.getTask_owner().trim());
			}
			
			if (searchData.getRdoNamesList().size() >0) {
				searchData.setRdoNamesList(searchData.getRdoNamesList());
			}
			
			if (searchData.getAssignee() != null) {
				searchData.setAssignee(searchData.getAssignee().trim());
			}
			
			if (searchData.getAssigneeManager() != null) {
				searchData.setAssigneeManager(searchData.getAssigneeManager().trim());
			}
			if (searchData.getItemTypeList().size() >0) {
				searchData.setItemTypeList(searchData.getItemTypeList());
			}
			
			if (searchData.getApproveStList().size() >0) {
				searchData.setApproveStList(searchData.getApproveStList());
			}
			
			
			if (searchData.getTask_owner() != null && searchData.getTask_owner().length() > 0) {
				whereFlag = true;
				appendVtQryCond.append(" WHERE ");
				appendVtQryCond.append("(");
				if (PLMUtils.isInteger(searchData.getTask_owner())) {
					appendVtQryCond.append(PLMUtils.generateQueryWhereClause(
							PLMConstants.Task_Owner, searchData.getTask_owner()));
				} else {
					appendVtQryCond.append(PLMUtils.generateQueryWhereClause(
							PLMConstants.TASK_FNAME, searchData.getTask_owner()));
					appendVtQryCond.append(" OR ");
					appendVtQryCond.append(PLMUtils.generateQueryWhereClause(
							PLMConstants.TASK_LNAME, searchData.getTask_owner()));
				}	
				appendVtQryCond.append(")");
			}		
			
			if (searchData.getAssignee() != null
					&& searchData.getAssignee().length() > 0) {
				if (whereFlag) {
					appendVtQryCond.append(" AND (");
				} else {
					appendVtQryCond.append(" WHERE (");
					whereFlag = true;
				}
				StringTokenizer token = new StringTokenizer(searchData.getAssignee(), ",");
				List<String> taskassigneeList = new ArrayList<String>();
				
				while (token.hasMoreElements()) {
					taskassigneeList.add(token.nextToken().trim());
				}
				
				List<String> assigneeSSOList = new ArrayList<String>();
				List<String> assigneeFnLnList = new ArrayList<String>();
				
				for(int i=0;i<taskassigneeList.size();i++){
					String assignee = taskassigneeList.get(i);
					if (PLMUtils.isInteger(assignee)){
						assigneeSSOList.add(assignee);
					} else {
						assigneeFnLnList.add(assignee);
					}
			  }
				if(assigneeSSOList.size()>0){
					appendVtQryCond.append(PLMConstants.TASK_ASSIGNEE+" IN ("+ PLMUtils.setListForQuery(assigneeSSOList)+") ");
						if(assigneeFnLnList.size()>0){
							appendVtQryCond.append(" OR ");
						}				
				}			if(assigneeFnLnList.size()>0){
					appendVtQryCond.append(PLMConstants.TASK_ASSIGNEE);
					appendVtQryCond.append(" IN ");
					appendVtQryCond.append("(");
					appendVtQryCond.append(PLMSearchQueries.GET_SSO_NAMES + " ");
				for (int i = 0; i < assigneeFnLnList.size(); i++) {
					String assigneeValue = assigneeFnLnList.get(i);
					appendVtQryCond.append(PLMConstants.FIRST_NAME + " LIKE '"  + assigneeValue + "%'");
					appendVtQryCond.append(" OR ");
					appendVtQryCond.append(PLMConstants.LAST_NAME + " LIKE '"  + assigneeValue + "%'");
		    	 	if (i < assigneeFnLnList.size() - 1) {
		    	 		appendVtQryCond.append(" OR ");
		    	 	}
				}
				appendVtQryCond.append(")");
				}
				appendVtQryCond.append(")");
			}
					
			if (searchData.getAssigneeManager() != null
					&& searchData.getAssigneeManager().length() > 0) {
				if (whereFlag) {
					appendVtQryCond.append(" AND (");
				} else {
					appendVtQryCond.append(" WHERE (");
					whereFlag = true;
				}
				StringTokenizer token = new StringTokenizer(searchData.getAssigneeManager(), ",");
				List<String> taskassigneeManagerList = new ArrayList<String>();
				while (token.hasMoreElements()) {
					taskassigneeManagerList.add(token.nextToken().trim());
				}
				List<String> assigneeManagerSSOList = new ArrayList<String>();
				List<String> assigneeManagerFnLnList = new ArrayList<String>();
				for(int i=0;i < taskassigneeManagerList.size();i++){
					String assigneeManager = taskassigneeManagerList.get(i);
					if (PLMUtils.isInteger(assigneeManager)){
						assigneeManagerSSOList.add(assigneeManager);
					} else {
						assigneeManagerFnLnList.add(assigneeManager);
					}
				}
				if(assigneeManagerSSOList.size()>0){
					appendVtQryCond.append(PLMConstants.TASK_ASSIGNEE_MANAGER +" IN ("+ PLMUtils.setListForQuery(assigneeManagerSSOList)+") ");
						if(assigneeManagerFnLnList.size()>0){
							appendVtQryCond.append(" OR ");
						}				
				}
				if(assigneeManagerFnLnList.size()>0){
					appendVtQryCond.append(PLMConstants.TASK_ASSIGNEE_MANAGER);
					appendVtQryCond.append(" IN ");
					appendVtQryCond.append("(");
					appendVtQryCond.append(PLMSearchQueries.GET_SSO_NAMES + " ");
					for (int i = 0; i < assigneeManagerFnLnList.size(); i++) {
						String assigneeManagerValue = assigneeManagerFnLnList.get(i);
						appendVtQryCond.append(PLMConstants.FIRST_NAME + " LIKE '"  + assigneeManagerValue + "%'");
						appendVtQryCond.append(" OR ");
						appendVtQryCond.append(PLMConstants.LAST_NAME + " LIKE '"  + assigneeManagerValue + "%'");
			    	 	if (i < assigneeManagerFnLnList.size() - 1) {
			    	 		appendVtQryCond.append(" OR ");
			    	 	}
					}
					appendVtQryCond.append(")");
				}
				appendVtQryCond.append(")");
			}
			
			if (searchData.getItemTypeList().size()>0) {
			  if (whereFlag) {
				  appendVtQryCond.append(" AND ");
			  }else {
				  appendVtQryCond.append(" WHERE ");
				whereFlag = true;
			 }
			  appendVtQryCond.append("AFCTD_ITEM_TYPE  IN (" +PLMUtils.setListForQuery(searchData.getItemTypeList())+ ")");
		   }
			
			if(searchData.getApproveStList().size()>0) {
			 if(whereFlag) {
				 appendVtQryCond.append(" AND ");
			  }else {
				  appendVtQryCond.append(" WHERE ");
				whereFlag = true;
			  }
			 appendVtQryCond.append("APPROVAL_STATUS  IN (" +PLMUtils.setListForQuery(searchData.getApproveStList())+ ")");
		  }
		
		 if (searchData.getRdoNamesList().size()>0) {
			 if(whereFlag) {
				 appendVtQryCond.append(" AND ");
			  }else {
				  appendVtQryCond.append(" WHERE ");
					whereFlag = true;
			  }
			 appendVtQryCond.append(" RDO IN (" +PLMUtils.setListForQuery(searchData.getRdoNamesList())+ ")");
		 }
			
		 if (searchData.getRouteCrtFrmDt() != null && searchData.getRouteCrtToDt() != null) {
				LOG.info("Route Task  From Date: " + DATE_FORMAT.format(searchData.getRouteCrtFrmDt()) +" To Date"+DATE_FORMAT.format(searchData.getRouteCrtToDt()));
				rtTaskFlg = true;
				 if(whereFlag) {
					 appendVtQryCond.append(" AND ");
				  }else {
					  appendVtQryCond.append(" WHERE ");
						whereFlag = true;
				  }
				appendVtQryCond.append("(ROUTE_TSK_CRT_DT IS NOT NULL AND ROUTE_TSK_CRT_DT BETWEEN CAST('");
				appendVtQryCond.append(DATE_FORMAT.format(searchData.getRouteCrtFrmDt())+ "' AS DATE FORMAT 'MM/DD/YYYY') AND ");
				appendVtQryCond.append(" CAST('");
				appendVtQryCond.append(DATE_FORMAT.format(searchData.getRouteCrtToDt())+ "' AS DATE FORMAT 'MM/DD/YYYY'))");
		}
			
		if (searchData.getTaskCompltFrmDt() != null && searchData.getTaskCompltToDt()!=null) {
				LOG.info("Task Completion From Datae: " + DATE_FORMAT.format(searchData.getTaskCompltFrmDt()) +" To Date"+DATE_FORMAT.format(searchData.getTaskCompltToDt()));
				 if(whereFlag) {
					 appendVtQryCond.append(" AND ");
				  }else {
					  appendVtQryCond.append(" WHERE ");
						whereFlag = true;
				  }
				appendVtQryCond.append("(COMPLETION_DATE IS NOT NULL AND COMPLETION_DATE BETWEEN CAST('");
				appendVtQryCond.append(DATE_FORMAT.format(searchData.getTaskCompltFrmDt())+ "' AS DATE FORMAT 'MM/DD/YYYY') AND ");
				appendVtQryCond.append(" CAST('");
				appendVtQryCond.append(DATE_FORMAT.format(searchData.getTaskCompltToDt())+ "' AS DATE FORMAT 'MM/DD/YYYY'))");
		}
		if (searchData.isCheckIboxTsk()) {
			 if(whereFlag) {
				 appendVtQryCond.append(" AND ");
			  }else {
				  appendVtQryCond.append(" WHERE ");
					whereFlag = true;
			  }
			appendVtQryCond.append(" COMPLETION_DATE IS NULL ");
		}

		 LOG.info("Executing for Creating CREATE_WF_QUE_VT Query : " + PLMSearchQueries.CREATE_WF_QUE_VT.replace(PLMConstants.WF_QUE_VT, WF_QUE_VT_QRY));
		 createVtQry.append(PLMSearchQueries.CREATE_WF_QUE_VT.replace(PLMConstants.WF_QUE_VT, WF_QUE_VT_QRY));
		 getJdbcTemplate().execute(createVtQry.toString());
		 
		 
		 insertVtQry1.append(PLMSearchQueries.INSERT1_WF_QUE_VT.replace(PLMConstants.WF_QUE_VT, WF_QUE_VT_QRY));
		 insertVtQry1.append(appendVtQryCond);
		 
		 LOG.info("Executing for Insert INSERT1_WF_QUE_VT Query : " + insertVtQry1);
		 getJdbcTemplate().execute(insertVtQry1.toString());
		 
		 if (!rtTaskFlg) {
			 
			 insertVtQry2.append(PLMSearchQueries.INSERT2_WF_QUE_VT.replace(PLMConstants.WF_QUE_VT, WF_QUE_VT_QRY));
			 insertVtQry2.append(appendVtQryCond);
			 
			 LOG.info("Executing for Insert INSERT2_WF_QUE_VT Query : " + insertVtQry2);
			 getJdbcTemplate().execute(insertVtQry2.toString());
			 
		 }
		 

		 LOG.info("Executing Collect Status for WF_QUE_VT Query : " + PLMSearchQueries.WF_QUE_VT_COL_STATS.replace(PLMConstants.WF_QUE_VT, WF_QUE_VT_QRY));
		 getJdbcTemplate().execute(PLMSearchQueries.WF_QUE_VT_COL_STATS.replace(PLMConstants.WF_QUE_VT, WF_QUE_VT_QRY));
	 	
		 searchResultsQry.append(PLMSearchQueries.GET_WF_QUE_VT.replace(PLMConstants.WF_QUE_VT, WF_QUE_VT_QRY));
		 LOG.info("Executing for getting WF_QUE_VT0 Query : " + searchResultsQry);
		 searchResultList = getSimpleJdbcTemplate().query(searchResultsQry.toString(), new DrawingMapper());
		 
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
	  } 
		
		if (!PLMUtils.isEmptyList(searchResultList))
			Collections.sort(searchResultList, new SortListDwg());
		
		return searchResultList;
	}

	
	/**
	 * 
	 * class to sort list of object of type selected item.
	 * 
	 */
	private static class SortListDwg implements Comparator<PLMDrawingSearchData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMDrawingSearchData aString,
				PLMDrawingSearchData bString) {
			return aString.getTaskName().compareTo(bString.getTaskName());
			
		}
	}
	/**
	 * Mapper for Getting Drawing Search Results
	 */
	private static final class DrawingMapper implements ParameterizedRowMapper<PLMDrawingSearchData>{	
	public PLMDrawingSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
		PLMDrawingSearchData searchData = new PLMDrawingSearchData();
		SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
				"MM/dd/yyyy");
		
		searchData.setTaskName(PLMUtils.checkNullVal(rs.getString("TASK_NAME")));
		searchData.setApprovalStatus(PLMUtils.checkNullVal(rs.getString("APPROVAL_STATUS")));
		
		Date routeTaskDt = rs.getDate("ROUTE_TSK_CRT_DT");
		if (routeTaskDt != null) {
			String strrouteTaskDt = SIMPLE_DATE_FORMAT.format(routeTaskDt);
			searchData.setRouteTskCrtDt(strrouteTaskDt);
			searchData.setRouteTskCrtDtExl(routeTaskDt);
		} 	
		
		searchData.setTaskComments(PLMUtils.checkNullVal(rs.getString("TASK_COMMENTS")));
		searchData.setTaskOwner(PLMUtils.checkNullVal(rs.getString("TASK_OWNER")));
		searchData.setTaskOwnerNm(PLMUtils.checkNullVal(rs.getString("TASK_OWNER_NAME")));
		searchData.setTaskAssign(PLMUtils.checkNullVal(rs.getString("TASK_ASSIGNEE")));
		searchData.setTaskAssignNm(PLMUtils.checkNullVal(rs.getString("TASK_ASSGN_NAME")));
		searchData.setTaskAssignMngr(PLMUtils.checkNullVal(rs.getString("TASK_ASSIGNEE_MANAGER")));
		searchData.setTaskAssignMngrNm(PLMUtils.checkNullVal(rs.getString("TASK_ASSIGNEE_MANAGER_NAME")));
		
		Date scheduleDt = rs.getDate("SCHEDULED_DTE");
		if (scheduleDt != null) {
			String strScheduleDt = SIMPLE_DATE_FORMAT.format(scheduleDt);
			searchData.setScheduleDt(strScheduleDt);
			searchData.setScheduleDtExl(scheduleDt);
		} 	
		
		Date completeDt = rs.getDate("COMPLETION_DATE");
		if (completeDt != null) {
			String strCompleteDt = SIMPLE_DATE_FORMAT.format(completeDt);
			searchData.setCompleteDt(strCompleteDt);
			searchData.setCompleteDtExl(completeDt);
		} 	
		
		searchData.setAffectedId(PLMUtils.checkNullVal(rs.getString("AFCTD_ITEM_ID")));
		searchData.setAffectedNm(PLMUtils.checkNullVal(rs.getString("AFCTD_ITEM_NM")));
		searchData.setAffectedType(PLMUtils.checkNullVal(rs.getString("AFCTD_ITEM_TYPE")));
		searchData.setAffectedRev(PLMUtils.checkNullVal(rs.getString("AFCTD_ITEM_REV")));
		searchData.setRelDwgEco(PLMUtils.checkNullVal(rs.getString("RELATED_ECO")));
		searchData.setRelEcoPolicy(PLMUtils.checkNullVal(rs.getString("RELATED_ECO_POLICY")));
		searchData.setEcoDesc(PLMUtils.checkNullVal(rs.getString("ECO_DESC")));
		searchData.setEcoLfCycleSt(PLMUtils.checkNullVal(rs.getString("ECO_LIFECYCLE_STATE")));
		searchData.setRdo(PLMUtils.checkNullVal(rs.getString("RDO")));
		
		searchData.setRouteOwner(PLMUtils.checkNullVal(rs.getString("ROUTE_OWNR_SSO")));
		searchData.setRouteOwnerName(PLMUtils.checkNullVal(rs.getString("ROUTE_OWNR_NM")));
		
		Date ecoRelDt = rs.getDate("ECO_RELEASE_DATE");
		if (ecoRelDt != null) {
			String ecoRelDtStr = SIMPLE_DATE_FORMAT.format(ecoRelDt);
			searchData.setEcoRelDt(ecoRelDtStr);
			searchData.setEcoRelDtExl(ecoRelDt);
		} 	
		
		return searchData;

	}
	//	};
	}
	/**
	 * This method is used for getSearchDetails
	 * 
	 * @param searchData
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMDrawingSearchData> getSearchDetails(
			PLMDrawingSearchData searchData) throws PLMCommonException {
		// TODO Auto-generated method stub
		return null;
	}

	//private static ParameterizedRowMapper<PLMCostChngData> dtlContrSrchMapper = new ParameterizedRowMapper<PLMCostChngData>() {
	private static final class DtlContrSrchMapper implements ParameterizedRowMapper<PLMCostChngData>{	
	public PLMCostChngData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			
			PLMCostChngData plmCostChngData = new PLMCostChngData();
			
			
			plmCostChngData.setContract(PLMUtils.checkNullVal(rs
					.getString("CONTRACT")));
			
			plmCostChngData.setContractDesc(PLMUtils.checkNullVal(rs
					.getString("CONTRACT_DESCRIPTION")));;

			
			return plmCostChngData;
		}
	//	};
	}
	/**
	 * This method is used for getValidContractData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMCostChngData> getValidContractData(String contractNameList) throws PLMCommonException{
		List<PLMCostChngData> costChngDescList = null;
		try{
			LOG.info("Entering getValidContractData of PLMSearchServiceImpl");
			StringBuffer searchResultsQry = new StringBuffer();
			searchResultsQry.append(PLMOfflineQueries.GET_PRJ_CONTRACT_DESC_DATA);
			boolean whereFlag = false;
				if (whereFlag) {
					searchResultsQry.append(" AND (");
				} else {
					searchResultsQry.append(" WHERE (");
					whereFlag = true;
				}
				searchResultsQry.append(PLMUtils.generatePrjQuryForMultipleNames("CONTRACT" ,contractNameList));
				
				searchResultsQry.append(")");
				searchResultsQry.append(PLMOfflineQueries.GET_PRJ_CHNG_HDR_DATA1);
				LOG.info("searchResultsQry     >"+searchResultsQry);
			costChngDescList = getSimpleJdbcTemplate().query(
					searchResultsQry.toString(), new DtlContrSrchMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return costChngDescList;
	}

	/**
	 *  This method is used for getCostChngReport
	 *  
	 * @param contractName
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMCostChngData> getCostChngReport(String contractName) 
			throws PLMCommonException{
		 
		  LOG.info("Entering getCostChngReport Method");
		  
		  List<PLMCostChngData> costChngDataList = new ArrayList<PLMCostChngData>();
		  
//		  List<PLMCostChngData> costChngDataList2 = new ArrayList<PLMCostChngData>();
			
			boolean GTT1Executed = false;
			boolean GTT2Executed = false;
			boolean GTT3Executed = false;
			
			try{
				LOG.info("Query for INSERT INTO CDR_GTT_CST_PRNTLVL : " + PLMOfflineQueries.INSERT_COST_CHNG_DATA1);
							
				getJdbcTemplate().update(PLMOfflineQueries.INSERT_COST_CHNG_DATA1,new Object[]{contractName});
				
				GTT1Executed = true;
				
				if (GTT1Executed) {
					LOG.info("Query for Collect STATS CDR_GTT_CST_PRNTLVL : " + PLMOfflineQueries.COST_CHNG_DATA1_COL_STATS1);
					getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA1_COL_STATS1);
				}
				
				int prntCount = getJdbcTemplate().queryForInt(PLMOfflineQueries.COST_CHNG_DATA1_CNT);
				
				if (prntCount >0) {
					
					LOG.info("Query for INSERT into CDR_GTT_CST_BOM : " + PLMOfflineQueries.INSERT_COST_CHNG_DATA2);
					
					getJdbcTemplate().execute(PLMOfflineQueries.INSERT_COST_CHNG_DATA2);
					GTT2Executed = true;
					
					if (GTT2Executed) {
						LOG.info("Query for Collect STATS CDR_GTT_CST_BOM 1 : " + PLMOfflineQueries.COST_CHNG_DATA2_COL_STATS1);
						getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA2_COL_STATS1);
						LOG.info("Query for Collect STATS CDR_GTT_CST_BOM 2 : " + PLMOfflineQueries.COST_CHNG_DATA2_COL_STATS2);
						getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA2_COL_STATS2);
						LOG.info("Query for Collect STATS CDR_GTT_CST_BOM 3 : " + PLMOfflineQueries.COST_CHNG_DATA2_COL_STATS3);
						getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA2_COL_STATS3);
						LOG.info("Query for Collect STATS CDR_GTT_CST_BOM 4 : " + PLMOfflineQueries.COST_CHNG_DATA2_COL_STATS4);
						getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA2_COL_STATS4);
					}
					
					
					int bomCount = getJdbcTemplate().queryForInt(PLMOfflineQueries.COST_CHNG_DATA2_CNT);
					
					if (bomCount>0) {					

						LOG.info("Query for INSERT into CDR_GTT_CST_BOM_CHLDCHNG : " + PLMOfflineQueries.INSERT_COST_CHNG_DATA3);
						
						getJdbcTemplate().execute(PLMOfflineQueries.INSERT_COST_CHNG_DATA3);
						GTT3Executed = true;
						
						if (GTT3Executed) {
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 1 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS1);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS1);
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 2 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS2);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS2);
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 3 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS3);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS3);
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 4 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS4);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS4);
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 5 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS5);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS5);
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 6 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS6);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS6);
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 7 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS7);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS7);
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 8 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS8);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS8);
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 9 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS9);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS9);
						}
						
						LOG.info("Query for UPDATE to CDR_GTT_CST_BOM_CHLDCHNG : " + PLMOfflineQueries.UPDATE_COST_CHNG_DATA);
						getJdbcTemplate().execute(PLMOfflineQueries.UPDATE_COST_CHNG_DATA);
												
						final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("HHmmss");
						Date uniqDate = new Date();
						String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
						
						StringBuffer tblName =  new StringBuffer().append(PLMConstants.VT_PARENT_CHANGES)
						.append(uniqTime);
						
						String parentChngQry = PLMOfflineQueries.PARENT_CHANGES.replace(PLMConstants.VT_PARENT_CHANGES, tblName);
						
						LOG.info("Query to create PARENT_CHANGES table : " + parentChngQry);
						getJdbcTemplate().execute(parentChngQry);				
						
						LOG.info("Query for INSERT to INSERT_PARENT_CHANGES : " + PLMOfflineQueries.INSERT_PARENT_CHANGES.replace(PLMConstants.VT_PARENT_CHANGES, tblName));
						getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PARENT_CHANGES.replace(PLMConstants.VT_PARENT_CHANGES, tblName));
						LOG.info("Query for INSERT to INSERT_PARENT_CHANGES1 : " + PLMOfflineQueries.INSERT_PARENT_CHANGES1.replace(PLMConstants.VT_PARENT_CHANGES, tblName));
						getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PARENT_CHANGES1.replace(PLMConstants.VT_PARENT_CHANGES, tblName));
						LOG.info("Query for INSERT to INSERT_PARENT_CHANGES2 : " + PLMOfflineQueries.INSERT_PARENT_CHANGES2.replace(PLMConstants.VT_PARENT_CHANGES, tblName));
						getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PARENT_CHANGES2.replace(PLMConstants.VT_PARENT_CHANGES, tblName));
						
						LOG.info("Query for SELECT output from COST_CHNG_SMRY_DATA_SEL : " + PLMOfflineQueries.COST_CHNG_SMRY_DATA_SEL);
						
						costChngDataList = getJdbcTemplate().query(PLMOfflineQueries.COST_CHNG_SMRY_DATA_SEL,new CostChngDataMapper());
						LOG.info("The Cost Change summary costChngDataList size "+costChngDataList.size());
						
						LOG.info("Query for SELECT output from COST_CHNG_SMRY_DATA_SEL1 : " + PLMOfflineQueries.COST_CHNG_SMRY_DATA_SEL1.replace(PLMConstants.VT_PARENT_CHANGES, tblName));
						
						List<PLMCostChngData> costChngDataList2 = getJdbcTemplate().query(PLMOfflineQueries.COST_CHNG_SMRY_DATA_SEL1.replace(PLMConstants.VT_PARENT_CHANGES, tblName), new CostChngDataMapper1());
						if(costChngDataList2.size()>0){
						LOG.info("The Cost Change summary costChngDataList2 size "+costChngDataList2.size());
						 }
						costChngDataList.addAll(costChngDataList2);
						
						if(costChngDataList.size()>0){
						LOG.info("The Cost Change summary Result Total count "+costChngDataList.size());
							 }
						
						// add new select query for Parent Changes 
					}	
				}
			} catch(DataAccessException e){
				PLMUtils.checkException(e.getMessage());
			} finally {
				try {
					if (GTT1Executed) {
						LOG.info("Query for Delete COST_CHNG_SMRY_DATA1_DEL  : " + PLMOfflineQueries.COST_CHNG_SMRY_DATA1_DEL);
						getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_SMRY_DATA1_DEL);
					}
					if (GTT2Executed) {
						LOG.info("Query for Delete COST_CHNG_SMRY_DATA2_DEL : " + PLMOfflineQueries.COST_CHNG_SMRY_DATA2_DEL);
						getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_SMRY_DATA2_DEL);
					}
					if (GTT3Executed) {
						LOG.info("Query for Delete COST_CHNG_SMRY_DATA3_DEL : " + PLMOfflineQueries.COST_CHNG_SMRY_DATA3_DEL);
						getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_SMRY_DATA3_DEL);
					}
				} catch(DataAccessException e) {
					LOG.info("Exception occurred while deleting data " +
							"from GTT tables in getCostChngReport method : " + e.getMessage());
					PLMUtils.checkException(e.getMessage());
				}
			}
			LOG.info("Exiting getCostChngReport Method");
			if (costChngDataList.size()>0)
				Collections.sort(costChngDataList, new SortList());
			return costChngDataList;
		}
	/**
	 * Mapper for Getting costChngDataMapper
	 */
	//private static ParameterizedRowMapper<PLMCostChngData> costChngDataMapper = new ParameterizedRowMapper<PLMCostChngData>() {
	private static final class CostChngDataMapper implements ParameterizedRowMapper<PLMCostChngData>{	
	public PLMCostChngData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMCostChngData tempData = new PLMCostChngData();
			tempData.setTopLevelparent(PLMUtils.checkNullVal(rs.getString("TOP_LEVEL_PARENT_NAME")));
			tempData.setLvlOneParentName(PLMUtils.checkNullVal(rs.getString("LVL_ONE_PARENT_NAME")));
			tempData.setLvlOneParentRev(PLMUtils.checkNullVal(rs.getString("LVL_ONE_PARENT_REV")));
			tempData.setAffectItmLvl(PLMUtils.checkNullVal(rs.getString("AFFCT_ITEM_LVL")));
			tempData.setAffectItmName(PLMUtils.checkNullVal(rs.getString("AFFCT_ITEM_NAME")));
			tempData.setAffectItmType(PLMUtils.checkNullVal(rs.getString("AFFCT_ITEM_PART_TYPE")));
			tempData.setAffectItmDesc(PLMUtils.checkNullVal(rs.getString("AFFCT_ITEM_PART_DESC")));
			tempData.setAffectItmRev(PLMUtils.checkNullVal(rs.getString("AFFCT_ITEM_REV")));
			tempData.setParentName(PLMUtils.checkNullVal(rs.getString("PARENT_NAME")));
			tempData.setBomPrefix(PLMUtils.checkNullVal(rs.getString("BOM_PREFIX")));
			tempData.setIsPartName(PLMUtils.checkNullVal(rs.getString("IS_PART_NAME")));
			tempData.setIsPartRev(PLMUtils.checkNullVal(rs.getString("IS_PART_REV")));
			tempData.setIsEstCost(PLMUtils.checkNullVal(PLMUtils.convertCostFlt(rs.getString("IS_ESTIMATED_COST"))));
			tempData.setIsTargetCost(PLMUtils.checkNullVal(PLMUtils.convertCostFlt(rs.getString("IS_TARGET_COST"))));
			tempData.setIsErpTotCostAE(PLMUtils.checkNullVal(rs.getString("IS_AE_TOTAL_COST")));
			tempData.setIsErpTotCostAG(PLMUtils.checkNullVal(rs.getString("IS_AG_TOTAL_COST")));
			tempData.setIsErpTotCostSE(PLMUtils.checkNullVal(rs.getString("IS_SE_TOTAL_COST")));
			tempData.setIsErpTotCostSG(PLMUtils.checkNullVal(rs.getString("IS_SG_TOTAL_COST")));
			tempData.setIsErpTotCostHBAE(PLMUtils.checkNullVal(rs.getString("IS_HB_AE_TOTAL_COST")));
			tempData.setIsErpTotCostHBAG(PLMUtils.checkNullVal(rs.getString("IS_HB_AG_TOTAL_COST")));
			tempData.setWasPartName(PLMUtils.checkNullVal(rs.getString("WAS_PART_NAME")));
			tempData.setWasPartRev(PLMUtils.checkNullVal(rs.getString("WAS_PART_REV")));
			tempData.setWasEstCost(PLMUtils.checkNullVal(PLMUtils.convertCostFlt(rs.getString("WAS_ESTIMATED_COST"))));
			tempData.setWasTargetCost(PLMUtils.checkNullVal(PLMUtils.convertCostFlt(rs.getString("WAS_TARGET_COST"))));
			tempData.setWasErpTotCostAE(PLMUtils.checkNullVal(rs.getString("WAS_AE_TOTAL_COST")));
			tempData.setWasErpTotCostAG(PLMUtils.checkNullVal(rs.getString("WAS_AG_TOTAL_COST")));
			tempData.setWasErpTotCostSE(PLMUtils.checkNullVal(rs.getString("WAS_SE_TOTAL_COST")));
			tempData.setWasErpTotCostSG(PLMUtils.checkNullVal(rs.getString("WAS_SG_TOTAL_COST")));
			tempData.setWasErpTotCostHBAE(PLMUtils.checkNullVal(rs.getString("WAS_HB_AE_TOTAL_COST")));
			tempData.setWasErpTotCostHBAG(PLMUtils.checkNullVal(rs.getString("WAS_HB_AG_TOTAL_COST")));
			tempData.setEcrName(PLMUtils.checkNullVal(rs.getString("ECR_NAME")));
			tempData.setEcrDescCst(PLMUtils.checkNullVal(rs.getString("ECR_DESCRIPTION")));
			tempData.setEcoName(PLMUtils.checkNullVal(rs.getString("ECO_NAME")));
			tempData.setEcoCtgryChng(PLMUtils.checkNullVal(rs.getString("CATEGORY_OF_CHANGE")));
			tempData.setEcoSeverity(PLMUtils.checkNullVal(rs.getString("ECO_SEVERITY")));
			tempData.setEcoSubstant(PLMUtils.checkNullVal(rs.getString("ECO_SUBSTANTIATION")));
			tempData.setEcoDesc(PLMUtils.checkNullVal(rs.getString("ECO_DESCRIPTION")));
			tempData.setEcoFastTrack(PLMUtils.checkNullVal(rs.getString("ECO_FAST_TRACK")));
			tempData.setEcrStatus(PLMUtils.checkNullVal(rs.getString("ECR_STATUS")));
			tempData.setEcrCompleteDate(rs.getTimestamp("ECR_STATE_LAST_UPDATE"));
			tempData.setEcoStatus(PLMUtils.checkNullVal(rs.getString("ECO_STATUS")));	
			tempData.setEcoCompleteDate(rs.getTimestamp("ECO_STATE_LAST_UPDATE"));
			tempData.setReqstChng(PLMUtils.checkNullVal(rs.getString("REQSTD_CHNG")));
			tempData.setDisposInFeild(PLMUtils.checkNullVal(rs.getString("DISPOSITION_IN_FIELD")));
			tempData.setDisposInProcess(PLMUtils.checkNullVal(rs.getString("DISPOSITION_IN_PROCESS")));
			tempData.setDisposInStock(PLMUtils.checkNullVal(rs.getString("DISPOSITION_IN_STOCK")));
			tempData.setDisposOnOrder(PLMUtils.checkNullVal(rs.getString("DISPOSITION_ON_ORDER")));
			tempData.setEcoPolicy(PLMUtils.checkNullVal(rs.getString("ECO_POLICY")));
			tempData.setClsIimpactTxt(PLMUtils.checkNullVal(rs.getString("CLS_I_IMPACT_STMT_TXT")));
			tempData.setBomMarkup(PLMUtils.checkNullVal(rs.getString("BOM_MARKUP")));
			tempData.setBomMarkupType(PLMUtils.checkNullVal(rs.getString("BOM_MARKUP_TYPE")));
			tempData.setDfsOrder(PLMUtils.checkNullVal(rs.getString("DFSORDER")));
			tempData.setIsCopicsParent(PLMUtils.checkNullVal(rs.getString("IS_COPICS_PARENT")));
			tempData.setIsBomQuantity(PLMUtils.checkNullVal(rs.getString("IS_BOM_QUANTITY")));
			tempData.setWasCopicsParent(PLMUtils.checkNullVal(rs.getString("WAS_COPICS_PARENT")));
			tempData.setWasBomQuantity(PLMUtils.checkNullVal(rs.getString("WAS_BOM_QUANTITY")));return tempData;
		}
	//	};
	}
	/**
	 * Mapper for Getting costChngDataMapper1
	 */
//private static ParameterizedRowMapper<PLMCostChngData> costChngDataMapper1 = new ParameterizedRowMapper<PLMCostChngData>() {
	private static final class CostChngDataMapper1 implements ParameterizedRowMapper<PLMCostChngData>{
	public PLMCostChngData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMCostChngData tempData = new PLMCostChngData();
			tempData.setTopLevelparent(PLMUtils.checkNullVal(rs.getString("TOP_LEVEL_PARENT_NAME")));
			tempData.setLvlOneParentName(PLMUtils.checkNullVal(rs.getString("LVL_ONE_PARENT_NAME")));
			tempData.setLvlOneParentRev(PLMUtils.checkNullVal(rs.getString("LVL_ONE_PARENT_REV")));
			tempData.setAffectItmLvl(PLMUtils.checkNullVal(rs.getString("AFFCT_ITEM_LVL")));
			tempData.setAffectItmName(PLMUtils.checkNullVal(rs.getString("AFFCT_ITEM_NAME")));
			tempData.setAffectItmType(PLMUtils.checkNullVal(rs.getString("AFFCT_ITEM_PART_TYPE")));
			tempData.setAffectItmDesc(PLMUtils.checkNullVal(rs.getString("AFFCT_ITEM_PART_DESC")));
			tempData.setAffectItmRev(PLMUtils.checkNullVal(rs.getString("AFFCT_ITEM_REV")));
			tempData.setParentName(PLMUtils.checkNullVal(rs.getString("PARENT_NAME")));
			tempData.setBomPrefix(PLMUtils.checkNullVal(rs.getString("GE_BOM_PREFIX")));
			tempData.setIsPartName(PLMUtils.checkNullVal(rs.getString("IS_PART_NAME")));
			tempData.setIsPartRev(PLMUtils.checkNullVal(rs.getString("IS_PART_REV")));
			tempData.setIsEstCost(PLMUtils.checkNullVal(PLMUtils.convertCostFlt(rs.getString("IS_ESTIMATED_COST"))));
			tempData.setIsTargetCost(PLMUtils.checkNullVal(PLMUtils.convertCostFlt(rs.getString("IS_TARGET_COST"))));
			tempData.setIsErpTotCostAE(PLMUtils.checkNullVal(rs.getString("IS_AE_TOTAL_COST")));
			tempData.setIsErpTotCostAG(PLMUtils.checkNullVal(rs.getString("IS_AG_TOTAL_COST")));
			tempData.setIsErpTotCostSE(PLMUtils.checkNullVal(rs.getString("IS_SE_TOTAL_COST")));
			tempData.setIsErpTotCostSG(PLMUtils.checkNullVal(rs.getString("IS_SG_TOTAL_COST")));
			tempData.setIsErpTotCostHBAE(PLMUtils.checkNullVal(rs.getString("IS_HB_AE_TOTAL_COST")));
			tempData.setIsErpTotCostHBAG(PLMUtils.checkNullVal(rs.getString("IS_HB_AG_TOTAL_COST")));
			tempData.setWasPartName(PLMUtils.checkNullVal(rs.getString("WAS_PART_NAME")));
			tempData.setWasPartRev(PLMUtils.checkNullVal(rs.getString("WAS_PART_REV")));
			tempData.setWasEstCost(PLMUtils.checkNullVal(PLMUtils.convertCostFlt(rs.getString("WAS_ESTIMATED_COST"))));
			tempData.setWasTargetCost(PLMUtils.checkNullVal(PLMUtils.convertCostFlt(rs.getString("WAS_TARGET_COST"))));
			tempData.setWasErpTotCostAE(PLMUtils.checkNullVal(rs.getString("WAS_AE_TOTAL_COST")));
			tempData.setWasErpTotCostAG(PLMUtils.checkNullVal(rs.getString("WAS_AG_TOTAL_COST")));
			tempData.setWasErpTotCostSE(PLMUtils.checkNullVal(rs.getString("WAS_SE_TOTAL_COST")));
			tempData.setWasErpTotCostSG(PLMUtils.checkNullVal(rs.getString("WAS_SG_TOTAL_COST")));
			tempData.setWasErpTotCostHBAE(PLMUtils.checkNullVal(rs.getString("WAS_HB_AE_TOTAL_COST")));
			tempData.setWasErpTotCostHBAG(PLMUtils.checkNullVal(rs.getString("WAS_HB_AG_TOTAL_COST")));
			tempData.setEcrName(PLMUtils.checkNullVal(rs.getString("ECR_NAME")));
			tempData.setEcrDescCst(PLMUtils.checkNullVal(rs.getString("ECR_DESCRIPTION")));
			tempData.setEcoName(PLMUtils.checkNullVal(rs.getString("ECO_NAME")));
			tempData.setEcoCtgryChng(PLMUtils.checkNullVal(rs.getString("CATEGORY_OF_CHANGE")));
			tempData.setEcoSeverity(PLMUtils.checkNullVal(rs.getString("ECO_SEVERITY")));
			tempData.setEcoSubstant(PLMUtils.checkNullVal(rs.getString("ECO_SUBSTANTIATION")));
			tempData.setEcoDesc(PLMUtils.checkNullVal(rs.getString("ECO_DESCRIPTION")));
			tempData.setEcoFastTrack(PLMUtils.checkNullVal(rs.getString("ECO_FAST_TRACK")));
			tempData.setEcrStatus(PLMUtils.checkNullVal(rs.getString("ECR_STATUS")));
			tempData.setEcrCompleteDate(rs.getTimestamp("ECR_STATE_LAST_UPDATE"));
			tempData.setEcoStatus(PLMUtils.checkNullVal(rs.getString("ECO_STATUS")));	
			tempData.setEcoCompleteDate(rs.getTimestamp("ECO_STATE_LAST_UPDATE"));
			tempData.setReqstChng(PLMUtils.checkNullVal(rs.getString("REQSTD_CHNG")));
			tempData.setDisposInFeild(PLMUtils.checkNullVal(rs.getString("DISPOSITION_IN_FIELD")));
			tempData.setDisposInProcess(PLMUtils.checkNullVal(rs.getString("DISPOSITION_IN_PROCESS")));
			tempData.setDisposInStock(PLMUtils.checkNullVal(rs.getString("DISPOSITION_IN_STOCK")));
			tempData.setDisposOnOrder(PLMUtils.checkNullVal(rs.getString("DISPOSITION_ON_ORDER")));
			tempData.setEcoPolicy(PLMUtils.checkNullVal(rs.getString("ECO_POLICY")));
			tempData.setClsIimpactTxt(PLMUtils.checkNullVal(rs.getString("CLS_I_IMPACT_STMT_TXT")));
			tempData.setBomMarkup(PLMUtils.checkNullVal(rs.getString("BOM_MARKUP")));
			tempData.setBomMarkupType(PLMUtils.checkNullVal(rs.getString("BOM_MARKUP_TYPE")));
			tempData.setDfsOrder(PLMUtils.checkNullVal(rs.getString("DFSORDER")));
			tempData.setIsCopicsParent(PLMUtils.checkNullVal(rs.getString("IS_COPICS_PARENT")));
			tempData.setIsBomQuantity(PLMUtils.checkNullVal(rs.getString("IS_BOM_QUANTITY")));
			tempData.setWasCopicsParent(PLMUtils.checkNullVal(rs.getString("WAS_COPICS_PARENT")));
			tempData.setWasBomQuantity(PLMUtils.checkNullVal(rs.getString("WAS_BOM_QUANTITY")));return tempData;
		}
	//	};
	}


	/**
	 * @return the getPopup
	 */
	/*public static ParameterizedRowMapper<PLMSearchData> getGetPopup() {
		return getPopup;
	}
	 */
	/**
	 * @param getPopup
	 *            the getPopup to set
	 */
	/*public static void setGetPopup(
			ParameterizedRowMapper<PLMSearchData> getPopup) {
		PLMSearchDaoImpl.getPopup = getPopup;
	}*/

	

	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}

	/**
	 * @return the sIMPLE_DATE_FORMAT
	 */
	/*public static SimpleDateFormat getSIMPLE_DATE_FORMAT() {
		return SIMPLE_DATE_FORMAT;
	}*/

	/**
	 * 
	 * class to sort list of object of type selected item.
	 * 
	 */
	private static class SortList implements Comparator<PLMCostChngData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMCostChngData aString,
				PLMCostChngData bString) {
			/*String aStr;
			String bStr;
			aStr = aString.getTopLevelparent();
			bStr = bString.getTopLevelparent();
			return aStr.compareTo(bStr);*/			
			int result = aString.getTopLevelparent().compareTo(bString.getTopLevelparent());
			if (result != 0)
		    {
				return result;
		    }
			return aString.getDfsOrder().compareTo(bString.getDfsOrder());
			
		}
	}
	
	/**
	 * This method is used to display selected Items
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> displaySelectedItems() throws PLMCommonException{
		Map<String, List<SelectItem>> selectedMaplist = new HashMap<String, List<SelectItem>>();
		try{
		LOG.info("Query to get RDO dropdown list : " + PLMSearchQueries.GET_DRAWING_RDO_QRY);
		List<SelectItem> rdoList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_DRAWING_RDO_QRY, new RdoListMapper());
		Collections.sort(rdoList, new PLMUtils.SortListSelItem());
		
		LOG.info("Query to get Affective Item type dropdown list : " + PLMSearchQueries.GET_DRAWING_AFFCTITEM_QRY);
		List<SelectItem> itemTypeList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_DRAWING_AFFCTITEM_QRY, new ItemTypeListMapper());

		LOG.info("Query to get Approve Status dropdown list : " + PLMSearchQueries.GET_DRAWING_APPROVESTATUS_QRY);
		List<SelectItem> approveStsList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_DRAWING_APPROVESTATUS_QRY, new ApproveStatusListMapper());

		selectedMaplist.put("rdoList", rdoList);
		selectedMaplist.put("itemTypeList", itemTypeList);
		selectedMaplist.put("approveStsList", approveStsList);
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return selectedMaplist;
	}

	/**
	 * Row mapper for getting RdoListMapper
	 */
	private static final class RdoListMapper implements ParameterizedRowMapper<SelectItem>{	
		public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
		SelectItem selectItem = new SelectItem(rs.getString("FROM_NAME"));	
		return selectItem;
		}
	};
	
	/**
	 * Row mapper for getting ItemTypeListMapperc
	 */
	private static final class ItemTypeListMapper implements ParameterizedRowMapper<SelectItem>{	
		public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
		SelectItem selectItem = new SelectItem(rs.getString("FROM_TYPE"));	
		return selectItem;
		}
	};
	
	/**
	 * Row mapper for getting ApproveStatusListMapper
	 */
	private static final class ApproveStatusListMapper implements ParameterizedRowMapper<SelectItem>{	
		public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
		SelectItem selectItem = new SelectItem(rs.getString("APPROVAL_STATUS"));	
		return selectItem;
		}
	};
	
}
// Ended by SHRAVAN

