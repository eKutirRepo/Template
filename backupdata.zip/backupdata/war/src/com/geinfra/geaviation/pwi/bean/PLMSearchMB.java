/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMSearchMB.java
 * @Creation date: 18-Oct-2010
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMCostChngData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.data.PLMSearchData;
import com.geinfra.geaviation.pwi.service.PLMSearchServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

/**
 * PLMSearchMB is the managed bean class .
 */
public class PLMSearchMB extends PLMSearchData {
	
	/**
	 * Holds the plmSearchService
	 */
	private PLMSearchServiceIfc plmSearchService = null;
	/**
	 * Holds the stateDropDownList
	 */
	private Map<String, List<SelectItem>> stateDropDownList;
	/**
	 * Holds the stateList
	 */
	private List<SelectItem> stateList;
	/**
	 * Holds the searchResultList
	 */
	private List<PLMSearchData> searchResultList;
	/**
	 * Holds the searchDetails
	 */
	private PLMSearchData searchDetails = null;
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB=null;
	/**
	 * Holds the count
	 */
	private int count;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the totalRecCountMsg
	 */
	private String totalRecCountMsg = null;
	/**
	 * Holds the fieldName
	 */
	private String fieldName;
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	
	/**
	 * Holds the contractNum
	 */
	private String contractNum;
	
	/**
	 * Holds the contract Selected
	 */
	private String contractSel;
	
	/**
	 * Holds the lttrData
	 */
	private PLMCostChngData costChngData = null;
	
	/**
	 * Holds the Project Change Header Data
	 */
	private List<PLMCostChngData> costChngList=new ArrayList<PLMCostChngData>();
	
	/**
	 * Holds the totcostChgCount
	 */
	private int totcostChgCount=0;

	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor =null;
	
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	
	
	/**
	 * Holds the Logger object to the messages.
	 */
	

	private static final Logger LOG = Logger.getLogger(PLMSearchMB.class);
	
	/**
	 * Holds user details
	 */
	private PLMPwiUserData userDetails;
	
	/*private PLMLoginData userDataObj = (PLMLoginData) PLMUtils
	.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA);*/

	/**
	 * This method is used for Load Document Search
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String loadSearch() {
		String fwdFlag = "";
		alertMessage = "";
		try {
			commonMB.insertCannedRptRecordHitInfo("Document Search");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			LOG.info("Entering loadSearch method");
			searchDetails = new PLMSearchData();
			stateDropDownList = plmSearchService.getStateDropDownvalues();
			stateList = (List<SelectItem>)stateDropDownList.get("documentstate");
			resetSearchData();
			fwdFlag = "plmsearch";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadSearch: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Document Search");
		} 
		
		/*try {
			commonMB.getPLMDateStamp(PLMConstants.ECO_TABLE);
		 } catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPLMDateStamp: ", exception);
		 }*/ 
		LOG.info("Exiting loadSearch method");
		return fwdFlag;
	}

	/**
	 * This method is used to download excel
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	
	public void downloadDocSrchExcel() throws PLMCommonException {
		
		LOG.info("Entering downloadDocumentSearchExcel Method");
		String reportName="searchResultExcelDoc";
		String fileName="Doc-Search Report";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("name", "Name", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("rev", "REV", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("lastupd", "Last Updated date", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("owner", "Owner", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("desc", "Description", FormatType.TEXT, null, null, 35),
                    new PLMXlsxRptColumn("rdo", "RDO", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("state", "State", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("ipClass", "IP Class", FormatType.TEXT, null, null, 13),
                    new PLMXlsxRptColumn("expCntrl", "Export Controlled", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("geSheet", "GE Sheet", FormatType.TEXT, null, null, 11),
                    new PLMXlsxRptColumn("ecoName", "ECO Name", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("ecoRde", "ECO RDE", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("ecoDesc", "ECO Description", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("ecoState", "ECO State", FormatType.TEXT, null, null, 15)
                    
						};


		PLMXlsxRptColumn[] critcolumns =
						new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("name", "Name", FormatType.TEXT),
								new PLMXlsxRptColumn("rev", "REV", FormatType.TEXT), new PLMXlsxRptColumn("owner", "Owner", FormatType.TEXT),
								new PLMXlsxRptColumn("desc", "Description", FormatType.TEXT), new PLMXlsxRptColumn("rdo", "RDO", FormatType.TEXT),
								new PLMXlsxRptColumn("stateExcel", "State", FormatType.TEXT)

						};

		excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, searchDetails);
		
	}
	
	/**
	 * This method is used for Generating Report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadDocSrchCSV() throws PLMCommonException {
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
                new PLMCsvRptColumn("name", "Name", FormatTypeCsv.TEXT, null, null, 15),
                new PLMCsvRptColumn("rev", "REV", FormatTypeCsv.TEXT, null, null, 20),
                new PLMCsvRptColumn("lastupd", "Last Updated date", FormatTypeCsv.TEXT, null, null, 15),
                new PLMCsvRptColumn("owner", "Owner", FormatTypeCsv.TEXT, null, null, 10),
                new PLMCsvRptColumn("desc", "Description", FormatTypeCsv.TEXT, null, null, 35),
                new PLMCsvRptColumn("rdo", "RDO", FormatTypeCsv.TEXT, null, null, 20),
                new PLMCsvRptColumn("state", "State", FormatTypeCsv.TEXT, null, null, 15),
                new PLMCsvRptColumn("ipClass", "IP Class", FormatTypeCsv.TEXT, null, null, 13),
                new PLMCsvRptColumn("expCntrl", "Export Controlled", FormatTypeCsv.TEXT, null, null, 20),
                new PLMCsvRptColumn("geSheet", "GE Sheet", FormatTypeCsv.TEXT, null, null, 11),
                new PLMCsvRptColumn("ecoName", "ECO Name", FormatTypeCsv.TEXT, null, null, 15),
                new PLMCsvRptColumn("ecoRde", "ECO RDE", FormatTypeCsv.TEXT, null, null, 15),
                new PLMCsvRptColumn("ecoDesc", "ECO Description", FormatTypeCsv.TEXT, null, null, 20),
                new PLMCsvRptColumn("ecoState", "ECO State", FormatTypeCsv.TEXT, null, null, 15)
                
				};

		csvUtil.exportCsv(searchResultList, reportColumns, "Doc-Search Report", dateFormat, false, null, null, ",");

		/*PrintWriter pwriter = null;
		OutputStream os = null;

		try {  
		   	
			FacesContext facesContext = FacesContext.getCurrentInstance();

			HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
			HttpServletRequest resquest = (HttpServletRequest) facesContext.getExternalContext().getRequest();
			
			HttpSession session = resquest.getSession();
			
			response.setHeader("content-disposition","attachment; filename=SearchResults.csv");
			response.setContentType("application/CSV");
			
		   	pwriter = response.getWriter();
		   
		   	PLMSearchMB searchMB = (PLMSearchMB)session.getAttribute("plmsearchMB");
	 			pwriter.write("Name");
	 			pwriter.write(",");
	 			pwriter.write("REV");
	 			pwriter.write(",");
	 			pwriter.write("Last Updated Date");
	 			pwriter.write(",");
	 			pwriter.write("Owner");
	 			pwriter.write(",");
	 			pwriter.write("Description");
	 			pwriter.write(",");
	 			pwriter.write("RDO");
	 			pwriter.write(",");
	 			pwriter.write("State");
	 			pwriter.write(",");
	  			pwriter.write("IP Class");
	 			pwriter.write(",");
	 			pwriter.write("Export Controlled");
	 			pwriter.write(",");
	 			pwriter.write("GE Sheet");
	 			pwriter.write(",");
	 			pwriter.write("ECO Name");
	 			pwriter.write(",");
	 			pwriter.write("ECO RDE");
	 			pwriter.write(",");
	 			pwriter.write("ECO Description");
	 			pwriter.write(",");
	 			pwriter.write("EcoState");
	 			pwriter.write("\n");
	 			
		   if(searchMB != null && searchMB.getSearchResultList() != null &&  searchMB.getSearchResultList().size() > 0) {
		   		for(int i=0; i<searchMB.getSearchResultList().size(); i++) {
		   			PLMSearchData dataObj = (PLMSearchData)searchMB.getSearchResultList().get(i);
		   			
		   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getName()));
		   			pwriter.write(","); 
		   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRev()));
		   			pwriter.write(","); 
		   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getLastupd()));
		   			pwriter.write(","); 
		   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOwner()));
		   			pwriter.write(","); 
		   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDesc()));
		   			pwriter.write(","); 
		   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRdo()));
		   			pwriter.write(","); 
		   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getState()));
		   			pwriter.write(","); 
		   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getIpClass()));
		   			pwriter.write(","); 
		   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getExpCntrl()));
		   			pwriter.write(","); 
		   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getGeSheet()));
		   			pwriter.write(","); 
		   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoName()));
		   			pwriter.write(","); 
		   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoRde()));
		   			pwriter.write(","); 
		   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoDesc()));
		   			pwriter.write(","); 
		   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoState()));
		   			pwriter.write("\n");
		   		}
		  }
		  pwriter.flush(); 
		} catch (FileNotFoundException e) {
			System.out.println("The exception is : " + e);
		} catch (Exception e1) {
			System.out.println("IOException : " + e1.getMessage());
		} finally {
			try {
				if (pwriter != null) {
					pwriter.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
			try {
				if (os != null) {
					os.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
		}*/
	}
	
	/**
	 * This method is used for Load Search Data
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getResultData() {
		
		String fwdFlag = "";
		totalRecCount = 0;		
		LOG.info("plmSearchService...." + plmSearchService);
		if (PLMUtils.isEmpty(searchDetails.getName())
				&& PLMUtils.isEmpty(searchDetails.getRev())
				&& PLMUtils.isEmpty(searchDetails.getOwner())
				&& PLMUtils.isEmpty(searchDetails.getDesc())
				&& PLMUtils.isEmpty(searchDetails.getRdo())
				&& PLMUtils.isEmptyList(searchDetails.getStateListData())) {
			LOG.info("i am in inside if " + getName());
			fieldName = PLMConstants.UI_DRAWING_SEARCH;
			alertMessage = PLMConstants.HEADER_SRCH_CRIT;
		}
		else{
			String ownerWithOutAsterisk = null;
						
			if (!PLMUtils.isEmpty(searchDetails.getOwner())) {
				ownerWithOutAsterisk = PLMUtils.removeAsteriskAndSpaceFromSSOFields(searchDetails.getOwner());
			}
			String name = searchDetails.getName();
			if(!PLMUtils.isEmpty(searchDetails.getName()) && name.length() < 3){
				alertMessage = alertMessage + PLMConstants.MIN_CHAR_ALERT;
				fwdFlag = "plmsearch";
			}
			if (!PLMUtils.checkForSpecialChars(searchDetails.getName())) {
				LOG.info("inside the special characters condition");
				alertMessage = alertMessage + PLMConstants.DOCUMENT_NAME_ALERT;
				fwdFlag = "plmsearch";
			}
			if (!PLMUtils.checkForSpecialChars(searchDetails.getRev())) {
				LOG.info("inside the special characters condition");
				alertMessage = alertMessage + PLMConstants.DOCUMENT_REV_ALERT;
				fwdFlag = "plmsearch";
			}
			if (!PLMUtils.checkForSpecialChars(searchDetails.getOwner())) {
				alertMessage = alertMessage + PLMConstants.DOCUMENT_OWNER_ALERT;
				fwdFlag = "plmsearch";
			} else if(PLMUtils.isInteger(ownerWithOutAsterisk)) {
				if(ownerWithOutAsterisk.length() != 9)
					alertMessage = alertMessage + PLMConstants.OWNER_DIGT_MESSAGE;
				fwdFlag = "plmsearch";
			}
			if (!PLMUtils.checkForSpecialChars(searchDetails.getDesc())) {
				alertMessage = alertMessage + PLMConstants.DOCUMENT_DESC_ALERT;
				fwdFlag = "plmsearch";
			}
			if (!PLMUtils.checkForSpecialChars(searchDetails.getRdo())) {
				alertMessage = alertMessage + PLMConstants.DOCUMENT_RDO_ALERT;
				fwdFlag = "plmsearch";
			}		
		}
		if (PLMUtils.isEmpty(alertMessage)) {
			try {
				searchResultList = plmSearchService
				.getSearchDetails(searchDetails);
				if (searchResultList != null) {
					totalRecCount = searchResultList.size();
				} else {
					totalRecCount = 0;
				}
				totalRecCountMsg = "Total Results Count : " + totalRecCount;
				LOG.info("totalRecCount::::::::::::::::::" + totalRecCount);
				if (totalRecCount == 0) {

					fwdFlag = "norecords";
				} else {
					recordCounts = PLMConstants.N_100;
					fwdFlag = "searchresult";
				}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getResultData: ", exception);
				fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"plmsearch","Document Search");
			} 
		}
		LOG.info("message" + alertMessage);
		return fwdFlag;
		
	}
	
	/**
	 * This method is used for resetSearchData
	 * 
	 * @return String
	 */

	public String resetSearchData() {
		String fwdFlag = "plmsearch";
		searchDetails = new PLMSearchData();
		if (searchDetails.getName() != null) {
			searchDetails.setName("");
		}
		if (searchDetails.getRev() != null) {
			searchDetails.setRev("");
		}
		if (searchDetails.getOwner() != null) {
			searchDetails.setOwner("");
		}
		if (searchDetails.getDesc() != null) {
			searchDetails.setDesc("");
		}
		if (searchDetails.getRdo() != null) {
			searchDetails.setRdo("");
		}
		searchDetails.setStateListData(null);
		return fwdFlag;
	}

	//Newly added for Cost change Summary
	/**
	 * This method is used for getcostChngHome
	 * 
	 * @return String
	 */
	public String getcostChngHome(){
		LOG.info("Entering getcostChngHome method");
		try {
			commonMB.insertCannedRptRecordHitInfo("Cost Change Summary");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		String fwdFlag = "costchngSearch";
		contractNum ="";
		alertMessage="";
		totcostChgCount=0;
		return fwdFlag;
	}
	
	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendCostChngReportThroughMail();
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return String
	 */
	public void sendCostChngReportThroughMail() {
		LOG.info("Entering sendCostChngReportThroughMail Method");
		
		LOG.info("contractNum>>>>>>>"+contractNum);
		if (contractNum!=null) {
		String from = PLMConstants.COST_CHG_MAIL_FROM;
		
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.COST_CHG_MAIL_SUBJECT + contractSel;
		StringBuffer mailBody = new StringBuffer().append(toAddressee)
		.append(PLMConstants.COST_CHG_MAIL_CONTENT)
		.append(contractSel)
		.append(".")
		.append(PLMConstants.COST_CHG_MAIL_SIGNATURE)
		.append(PLMConstants.COST_CHG_MAIL_FOOTER);
		
		StringBuffer mailNoDataBody = new StringBuffer()
		.append(toAddressee)
		.append(PLMConstants.COST_CHNG_NO_CONTENT_BODY)
		.append(contractSel)
		.append(".")
		.append(PLMConstants.COST_CHG_MAIL_SIGNATURE)
		.append(PLMConstants.COST_CHG_MAIL_FOOTER);
		
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXlsx = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("COST_CHG_REPORT_NAME") +  contractSel + "_" + uniqTime + ".xlsx";
		//String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("COST_CHG_REPORT_NAME") +  contractNum + "_" + uniqTime + ".xls";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("COST_CHG_REPORT_NAME") +  contractSel + "_" + uniqTime + ".zip";
		File file = null;
		try {
			List<PLMCostChngData> costChngResultList = plmSearchService.getCostChngReport(contractSel);
			
			if (costChngResultList!=null && costChngResultList.size()>0) {
				saveCostChngXLSXFile(contractSel,costChngResultList,fileDir,filePathXlsx);
				//saveCostChngXLSFile(contractNum,costChngResultList,fileDir,filePathXls);
				//saveCostChngCSVFile(contractSel,costChngResultList,fileDir,filePathXls);
				PLMUtils.generateZipFile(filePathXlsx,filePathZip);
				file = new File(filePathZip);
				// Get the number of bytes in the file
				float sizeInBytes = file.length();
				//transform in MB
				float sizeInMb = sizeInBytes / (1024 * 1024);
				LOG.info("Zip File Size for Cost Chng Report "+sizeInMb+" MB");
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
				LOG.info("Report Attachment Mail sent successfully.");
				costChngResultList.clear();
			} else {				
				PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
				LOG.info("No data Mail sent successfully.");
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendCostChngReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.COST_CHG_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendCostChngReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.COST_CHG_MAIL_SIGNATURE);
		} finally {
			deleteFiles(filePathXlsx,filePathZip);
			/*if (file!=null)
				file.delete();*/
		}
		LOG.info("Exiting sendCostChngReportThroughMail Method");
		} else {
			LOG.info("Not able to generate the report. The Contract Number selected is "+contractSel);
		}
	}
	
	/**
	 * This method is used for Bordering Cell in XLS
	 * 
	 * @return StringBuffer
	 */
	
	private HSSFCellStyle setBorderStyle(HSSFCellStyle style) {
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		return style;
	}
	/**
	 * This method is used for Bordering Cell in XLSX
	 * 
	 * @return StringBuffer
	 */
	private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
		style.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style.setBorderRight(XSSFCellStyle.BORDER_THIN);
		return style;
	}
	
	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @param contractNumLcl,costChgResultList,fileDir,filePathXls
	 * @return StringBuffer
	 * @throws IOException
	 */
	
	public void saveCostChngXLSFile(String contractNumLcl,List<PLMCostChngData> costChgResultList,String fileDir,String filePathXls) throws IOException {
		LOG.info("Entering saveCostChngXLSFile Method");
		//SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXls);
				HSSFWorkbook workbook = new HSSFWorkbook();
				HSSFSheet sheet =  workbook.createSheet("Full Report");
				HSSFCellStyle headerStyle = workbook.createCellStyle();
				
				headerStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
				headerStyle.setFillForegroundColor(HSSFColor.YELLOW.index);
				headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				HSSFFont font = workbook.createFont(); 
				font.setFontName(PLMConstants.EXCEL_FONT_NAME);
				font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headerStyle.setFont(font);
				headerStyle = setBorderStyle(headerStyle);
				
				HSSFCellStyle cellBoldStyle = workbook.createCellStyle();
				cellBoldStyle = setBorderStyle(cellBoldStyle);
				cellBoldStyle.setFont(font);
				
				HSSFFont nonBoldFont = workbook.createFont();
				nonBoldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				HSSFCellStyle contentStyle = workbook.createCellStyle();				
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(nonBoldFont);
				HSSFCellStyle contentDecimalStyle = workbook.createCellStyle();				
				contentDecimalStyle = setBorderStyle(contentDecimalStyle);
				contentDecimalStyle.setFont(nonBoldFont);
				DataFormat format = workbook.createDataFormat();
				contentDecimalStyle.setDataFormat(format.getFormat("0.00000"));
										
				HSSFFont noRecordFont = workbook.createFont(); 
				noRecordFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				noRecordFont.setColor(HSSFColor.RED.index);
				noRecordFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				HSSFCellStyle noRecordCellStyle = workbook.createCellStyle();
				noRecordCellStyle = setBorderStyle(noRecordCellStyle);
				noRecordCellStyle.setFont(noRecordFont);

				CreationHelper createHelper = workbook.getCreationHelper();

				HSSFCellStyle dateStyle = workbook.createCellStyle();
				
				dateStyle.setDataFormat(
			        createHelper.createDataFormat().getFormat("mm/dd/yyyy"));
				
				dateStyle = setBorderStyle(contentStyle);		
				dateStyle.setFont(nonBoldFont);
				HSSFCellStyle contentCurrencyStyle = workbook.createCellStyle();				
				contentCurrencyStyle = setBorderStyle(contentCurrencyStyle);
				contentCurrencyStyle.setFont(nonBoldFont);
				contentCurrencyStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("$#,##0.00"));
				
				HSSFCellStyle currencyStyle = workbook.createCellStyle();
			    HSSFDataFormat df = workbook.createDataFormat();
			    currencyStyle.setDataFormat(df.getFormat("$#,##0.00"));
			    currencyStyle = setBorderStyle(currencyStyle);		
			    currencyStyle.setFont(nonBoldFont);
			    
				int rowcount = -1;
				
				if(!PLMUtils.isEmptyList(costChgResultList)) {
					
					String[] colNames = {"TOP_LEVEL_PARENT_NAME","LVL_ONE_PARENT_NAME",
							"LVL_ONE_PARENT_REV","AFFCT_ITEM_LVL","ECR_NAME","ECR_DESCRIPTION",
							"ECR_STATUS","ECR_STATUS_DATE","AFFCT_ITEM_NAME","AFFCT_ITEM_PART_TYPE",
							//"IS_ERP_TOTAL_COST",
							"AFFCT_ITEM_PART_DESC",
							"AFFCT_ITEM_REV",
							"WAS_PART_NAME",
							"WAS_PART_REV",
							"WAS_ERP_TOTAL_COST_HB-AE","WAS_ERP_TOTAL_COST_HB-AG",
							"WAS_ESTIMATED_COST","WAS_TARGET_COST",
							//"WAS_ERP_TOTAL_COST",
							"WAS_ERP_TOTAL_COST (AG)",
							"WAS_ERP_TOTAL_COST (SG)",
							"WAS_ERP_TOTAL_COST (AE)",
							"ECO_NAME",
							"ECO_STATUS",
							"ECO_STATUS_DATE","ECO_FAST_TRACK","IS_PART_NAME","IS_PART_REV",
							"IS_PART_STATE","IS_ESTIMATED_COST","IS_TARGET_COST","IS_ERP_TOTAL_COST (AE)",
							"IS_ERP_TOTAL_COST (AG)","IS_ERP_TOTAL_COST_HB-AE","IS_ERP_TOTAL_COST_HB-AG",
							"IS_ERP_TOTAL_COST (SG)","CATEGORY_OF_CHANGE","ECO_SEVERITY",
							"ECO_SUBSTANTIATION","ECO_DESCRIPTION","REQSTD_CHNG","DISPOSITION_IN_FIELD",
							"DISPOSITION_IN_PROCESS","DISPOSITION_IN_STOCK","DISPOSITION_ON_ORDER",
							"ECO_POLICY","CLS_I_IMPACT_STMT_TXT (ECR)","BOM_MARKUP","BOM_MARKUP_TYPE",
							"DFSORDER"};						
					
					HSSFRow row = sheet.createRow(++rowcount);
					HSSFCell cell = row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					cell.setCellValue(PLMConstants.COST_CHG_SEARCH_CRITERIA_MLNO);
					cell.setCellStyle(cellBoldStyle);

					cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellValue(contractNumLcl);
					cell.setCellStyle(cellBoldStyle);
					
					row = sheet.createRow(++rowcount);
					row = sheet.createRow(++rowcount);
					
					for ( int i = 0 ; i < colNames.length; i++ ) {
						cell = row.createCell(i);
						cell. setCellValue(colNames[i]);
						cell.setCellStyle(headerStyle);
					}
					for(int i = 0; i < costChgResultList.size(); i++) {
						PLMCostChngData dataObj = (PLMCostChngData) costChgResultList.get(i);
						row =  sheet.createRow(++rowcount);
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getTopLevelparent());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(cellBoldStyle);
						cell.setCellValue(dataObj.getLvlOneParentName());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getLvlOneParentRev());
			
						cell =   row.createCell(PLMConstants.EXCEL_COL_THREE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAffectItmLvl());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_FOUR);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcrName());
							
						cell =   row.createCell(PLMConstants.EXCEL_COL_FIVE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcrDescCst());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_SIX);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcrStatus());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_SEVEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcrCompleteDate());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_EIGHT);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAffectItmName());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_NINE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAffectItmType());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_TEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAffectItmDesc());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAffectItmRev());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_TWELVE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getWasPartName());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getWasPartRev());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
						if (!PLMUtils.isEmpty(dataObj.getWasErpTotCostHBAE())) {
							double wasErpTotCost = Double.parseDouble(dataObj.getWasErpTotCostHBAE());
							cell.setCellValue(wasErpTotCost);
						} else {
							cell.setCellValue(dataObj.getWasErpTotCostHBAE());
						}
						cell.setCellStyle(currencyStyle);
						
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
						if (!PLMUtils.isEmpty(dataObj.getWasErpTotCostHBAG())) {
							double wasErpTotCost = Double.parseDouble(dataObj.getWasErpTotCostHBAG());
							cell.setCellValue(wasErpTotCost);
						} else {
							cell.setCellValue(dataObj.getWasErpTotCostHBAG());
						}
						cell.setCellStyle(currencyStyle);
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
						if (!PLMUtils.isEmpty(dataObj.getWasEstCost())) {
							double wasEstCost = Double.parseDouble(dataObj.getWasEstCost());
							if(dataObj.getWasPartName().equals("")){
                                   cell.setCellValue("");
                            } else{
                               	cell.setCellValue(wasEstCost);
                            }	
						} else {
							cell.setCellValue(dataObj.getWasEstCost());
						}
						cell.setCellStyle(currencyStyle);
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
						if (!PLMUtils.isEmpty(dataObj.getWasTargetCost())) {
							double wasTgtCost = Double.parseDouble(dataObj.getWasTargetCost());
							if(dataObj.getWasPartName().equals("")){
                                   cell.setCellValue("");
                            } else{
                               	cell.setCellValue(wasTgtCost);
                            }	
						} else {
							cell.setCellValue(dataObj.getWasTargetCost());
						}
						cell.setCellStyle(currencyStyle);
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_EIGHTEEN);
						if (!PLMUtils.isEmpty(dataObj.getWasErpTotCostAG())) {
							double wasErpTotCost = Double.parseDouble(dataObj.getWasErpTotCostAG());
							cell.setCellValue(wasErpTotCost);
						} else {
							cell.setCellValue(dataObj.getWasErpTotCostAG());
						}
						cell.setCellStyle(currencyStyle);
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_NINETEEN);
						if (!PLMUtils.isEmpty(dataObj.getWasErpTotCostSG())) {
							double wasErpTotCost = Double.parseDouble(dataObj.getWasErpTotCostSG());
							cell.setCellValue(wasErpTotCost);
						} else {
							cell.setCellValue(dataObj.getWasErpTotCostSG());
						}
						cell.setCellStyle(currencyStyle);
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_TWENTY);
						if (!PLMUtils.isEmpty(dataObj.getWasErpTotCostAE())) {
							double wasErpTotCost = Double.parseDouble(dataObj.getWasErpTotCostAE());
							cell.setCellValue(wasErpTotCost);
						} else {
							cell.setCellValue(dataObj.getWasErpTotCostAE());
						}
						cell.setCellStyle(currencyStyle);
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_TWENTYONE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoName());
						
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_TWENTYTWO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoStatus());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_TWENTYTHREE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoCompleteDate());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_TWENTYFOUR);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoFastTrack());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_TWENTYFIVE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getIsPartName());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_TWENTYSIX);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getIsPartRev());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_TWENTYSEVEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getIsPartState());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_TWENTYEIGHT);
						if (!PLMUtils.isEmpty(dataObj.getIsEstCost())) {
							double isEstCost = Double.parseDouble(dataObj.getIsEstCost()); 		
                            if(dataObj.getIsPartName().equals("")){
                                cell.setCellValue("");
                            } else{
                            	cell.setCellValue(isEstCost);
                            }					
						} else {
							cell.setCellValue(dataObj.getIsEstCost());
						}
						cell.setCellStyle(currencyStyle);
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_TWENTYNINE);
						if (!PLMUtils.isEmpty(dataObj.getIsTargetCost())) {
							double isTgtCost = Double.parseDouble(dataObj.getIsTargetCost()); 
							if(dataObj.getIsPartName().equals("")){
                                   cell.setCellValue("");
                            } else{
                               	cell.setCellValue(isTgtCost);
                            }	
						} else {
							cell.setCellValue(dataObj.getIsTargetCost());
						}
						cell.setCellStyle(currencyStyle);
						
										
						cell =   row.createCell(PLMConstants.EXCEL_COL_THIRTY);
						if (!PLMUtils.isEmpty(dataObj.getIsErpTotCostAE())) {
							double isErpTotCost = Double.parseDouble(dataObj.getIsErpTotCostAE()); 
							cell.setCellValue(isErpTotCost);
						} else {
							cell.setCellValue(dataObj.getIsErpTotCostAE());
						}
						cell.setCellStyle(currencyStyle);
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_THIRTYONE);
						if (!PLMUtils.isEmpty(dataObj.getIsErpTotCostAG())) {
							double isErpTotCost = Double.parseDouble(dataObj.getIsErpTotCostAG()); 
							cell.setCellValue(isErpTotCost);
						} else {
							cell.setCellValue(dataObj.getIsErpTotCostAG());
						}
						cell.setCellStyle(currencyStyle);
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_THIRTYTWO);
						if (!PLMUtils.isEmpty(dataObj.getIsErpTotCostHBAE())) {
							double isErpTotCost = Double.parseDouble(dataObj.getIsErpTotCostHBAE()); 
							cell.setCellValue(isErpTotCost);
						} else {
							cell.setCellValue(dataObj.getIsErpTotCostHBAE());
						}
						cell.setCellStyle(currencyStyle);
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_THIRTYTHREE);
						if (!PLMUtils.isEmpty(dataObj.getIsErpTotCostHBAG())) {
							double isErpTotCost = Double.parseDouble(dataObj.getIsErpTotCostHBAG()); 
							cell.setCellValue(isErpTotCost);
						} else {
							cell.setCellValue(dataObj.getIsErpTotCostHBAG());
						}
						cell.setCellStyle(currencyStyle);
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_THIRTYFOUR);
						if (!PLMUtils.isEmpty(dataObj.getIsErpTotCostSG())) {
							double isErpTotCost = Double.parseDouble(dataObj.getIsErpTotCostSG()); 
							cell.setCellValue(isErpTotCost);
						} else {
							cell.setCellValue(dataObj.getIsErpTotCostSG());
						}
						cell.setCellStyle(currencyStyle);
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_THIRTYFIVE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoCtgryChng());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_THIRTYSIX);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoSeverity());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_THIRTYSEVEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoSubstant());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_THIRTYEIGHT);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoDesc());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_THIRTYNINE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getReqstChng());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_FOURTY);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getDisposInFeild());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_FOURTYONE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getDisposInProcess());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_FOURTYTWO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getDisposInStock());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_FOURTYTHREE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getDisposOnOrder());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_FOURTYFOUR);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoPolicy());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_FOURTYFIVE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getClsIimpactTxt());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_FOURTYSIX);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getBomMarkup());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_FOURTYSEVEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getBomMarkupType());
						
						cell =   row.createCell(PLMConstants.EXCEL_COL_FOURTYEIGHT);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getDfsOrder());
						
					}
					
					row =  sheet.createRow(++rowcount);
					row =  sheet.createRow(++rowcount);
				short colWidth = (short)6400;
				short colWidth1 = (short)6700;
				short colWidth2 = (short)7000;
				short colWidth3 = (short)7200;
				short colWidth4 = (short)7900;
				short colWidth5 = (short)8600;
								
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,colWidth1);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWELVE,colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTEEN,colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTEEN,colWidth5);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTEEN,colWidth5);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIXTEEN,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVENTEEN,colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHTEEN,colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINETEEN,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTY,colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYONE,colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYTWO,colWidth5);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYTHREE,colWidth5);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYFOUR,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYFIVE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYSIX,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYSEVEN,colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYEIGHT,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYNINE,colWidth1);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTY,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYONE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYTWO,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYTHREE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYFOUR,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYFIVE,colWidth1);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYSIX,colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYSEVEN,colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYEIGHT,colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYNINE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTY,colWidth5);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYONE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYTWO,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYTHREE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYFOUR,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYFIVE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYSIX,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYSEVEN,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYEIGHT,colWidth);

					//Added by Raju
					createSmryTabXLS(workbook,costChgResultList,filePathXls);
				
				} else {
					LOG.info("There is no record found for " + contractNumLcl);
					HSSFRow row = sheet.createRow(++rowcount);
					HSSFCell cell = row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					String noRecordMsg = PLMConstants.COST_CHG_NO_RECORD_FOUND + contractNumLcl;
					cell.setCellValue(noRecordMsg);
					cell.setCellStyle(noRecordCellStyle);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
				}	
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveCostChngXLSFile: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveCostChngXLSFile: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveCostChngXLSFile: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveCostChngXLSFile Method");
	}
	
	
	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @param  contractNumLcl1,costChgResultList,fileDir,filePathXlsx
	 * @throws IOException
	 */
	
	public void saveCostChngXLSXFile(String contractNumLcl1,
			List<PLMCostChngData> costChgResultList,
			String fileDir,String filePathXlsx) throws IOException {
		LOG.info("Entering saveCostChngXLSX File Method");
		//SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy HH:MM",Locale.ENGLISH);
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathXlsx);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXlsx);
				SXSSFWorkbook workbook = new SXSSFWorkbook();
				SXSSFSheet sheet =  (SXSSFSheet) workbook.createSheet("Full Report");
				XSSFCellStyle headerStyle = (XSSFCellStyle) workbook.createCellStyle();
				
				headerStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
				headerStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex()); 
				headerStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
				XSSFFont font = (XSSFFont) workbook.createFont(); 
				font.setFontName(PLMConstants.EXCEL_FONT_NAME);
				font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				font.setFontHeightInPoints((short)10);
				headerStyle.setFont(font);
				headerStyle = setBorderStyle(headerStyle);
				
				XSSFCellStyle cellBoldStyle = (XSSFCellStyle) workbook.createCellStyle();
				cellBoldStyle = setBorderStyle(cellBoldStyle);
				cellBoldStyle.setFont(font);
				
				XSSFFont nonBoldFont = (XSSFFont) workbook.createFont();
				nonBoldFont.setFontHeightInPoints((short)10);
				nonBoldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				XSSFCellStyle contentStyle = (XSSFCellStyle) workbook.createCellStyle();				
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(nonBoldFont);
				XSSFCellStyle contentDecimalStyle = (XSSFCellStyle) workbook.createCellStyle();				
				contentDecimalStyle = setBorderStyle(contentDecimalStyle);
				contentDecimalStyle.setFont(nonBoldFont);
				DataFormat format = workbook.createDataFormat();
				contentDecimalStyle.setDataFormat(format.getFormat("0.00000"));
						
				XSSFFont noRecordFont = (XSSFFont) workbook.createFont(); 
				noRecordFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				noRecordFont.setColor(Font.COLOR_RED);
				noRecordFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				noRecordFont.setFontHeightInPoints((short)10);
				XSSFCellStyle noRecordCellStyle = (XSSFCellStyle) workbook.createCellStyle();
				noRecordCellStyle = setBorderStyle(noRecordCellStyle);
				noRecordCellStyle.setFont(noRecordFont);

				CreationHelper createHelper = workbook.getCreationHelper();

				XSSFCellStyle dateStyle = (XSSFCellStyle) workbook.createCellStyle();
				
				dateStyle.setDataFormat(
			        createHelper.createDataFormat().getFormat("mm/dd/yyyy"));
				
				dateStyle = setBorderStyle(contentStyle);		
				dateStyle.setFont(nonBoldFont);
				
				XSSFCellStyle currencyStyle = (XSSFCellStyle) workbook.createCellStyle();
			    XSSFDataFormat df = (XSSFDataFormat) workbook.createDataFormat();
			    currencyStyle.setDataFormat(df.getFormat("$#,##0.00"));
			    currencyStyle = setBorderStyle(currencyStyle);		
			    currencyStyle.setFont(nonBoldFont);

			    XSSFCellStyle dateStyle1 = (XSSFCellStyle) workbook.createCellStyle();
				dateStyle1.setDataFormat(createHelper.createDataFormat().getFormat("m/d/yy h:mm"));
				dateStyle1 = setBorderStyle(contentStyle);
				dateStyle1.setFont(nonBoldFont);
				
				int rowcount = -1;
				
				if(!PLMUtils.isEmptyList(costChgResultList)) {
					
					String[] colNames = {"TOP_LEVEL_PARENT_NAME","LVL_ONE_PARENT_NAME",
							"LVL_ONE_PARENT_REV","AFFCT_ITEM_LVL","ECR_NAME","ECR_DESCRIPTION",
							"ECR_STATUS","ECR_STATUS_DATE","AFFCT_ITEM_NAME","AFFCT_ITEM_PART_TYPE",
							//"IS_ERP_TOTAL_COST",
							"AFFCT_ITEM_PART_DESC",
							"AFFCT_ITEM_REV",
							"PARENT_NAME",
							"GE_BOM_PREFIX",
							"WAS_PART_NAME",
							"WAS_PART_REV",
							"WAS_ERP_TOTAL_COST_HB-AE","WAS_ERP_TOTAL_COST_HB-AG",
							"WAS_ESTIMATED_COST","WAS_TARGET_COST",
							//"WAS_ERP_TOTAL_COST",
							"WAS_ERP_TOTAL_COST (AG)",
							"WAS_ERP_TOTAL_COST (SG)",
							"WAS_ERP_TOTAL_COST (AE)",
							"WAS_GE_COPICS_PARENT",//21
							"WAS_BOM_QUANTITY",//22
							"ECO_NAME",
							"ECO_STATUS",
							"ECO_STATUS_DATE","ECO_FAST_TRACK","IS_PART_NAME","IS_PART_REV",
							"IS_PART_STATE","IS_ESTIMATED_COST","IS_TARGET_COST","IS_ERP_TOTAL_COST (AE)",
							"IS_ERP_TOTAL_COST (AG)","IS_ERP_TOTAL_COST_HB-AE","IS_ERP_TOTAL_COST_HB-AG",
							"IS_ERP_TOTAL_COST (SG)",
							"IS_GE_COPICS_PARENT ",//37
							"IS_BOM_QUANTITY",//38
							"CATEGORY_OF_CHANGE","ECO_SEVERITY",
							"ECO_SUBSTANTIATION","ECO_DESCRIPTION","REQSTD_CHNG","DISPOSITION_IN_FIELD",
							"DISPOSITION_IN_PROCESS","DISPOSITION_IN_STOCK","DISPOSITION_ON_ORDER",
							"ECO_POLICY","CLS_I_IMPACT_STMT_TXT (ECR)","BOM_MARKUP","BOM_MARKUP_TYPE",
							"DFSORDER"};						
					
					SXSSFRow row = (SXSSFRow)sheet.createRow(++rowcount);
					SXSSFCell cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					cell.setCellValue(PLMConstants.COST_CHG_SEARCH_CRITERIA_MLNO);
					cell.setCellStyle(cellBoldStyle);

					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellValue(contractNumLcl1);
					cell.setCellStyle(cellBoldStyle);
					
					row = (SXSSFRow) sheet.createRow(++rowcount);
					row = (SXSSFRow) sheet.createRow(++rowcount);
					
					for ( int i = 0 ; i < colNames.length; i++ ) {
						cell = (SXSSFCell)  row.createCell(i);
						cell. setCellValue(colNames[i]);
						cell.setCellStyle(headerStyle);
					}
					for(int i = 0; i < costChgResultList.size(); i++) {
						PLMCostChngData dataObj = (PLMCostChngData) costChgResultList.get(i);
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getTopLevelparent());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getLvlOneParentName());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getLvlOneParentRev());
			
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THREE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAffectItmLvl());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOUR);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcrName());
							
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIVE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcrDescCst());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SIX);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcrStatus());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SEVEN);
						cell.setCellStyle(dateStyle1);
						
						DateFormat dateFormat1 = new SimpleDateFormat("MM/dd/yyyy HH:mm");
						if(dataObj.getEcrCompleteDate()!=null){
							cell.setCellValue(dateFormat1.format(dataObj.getEcrCompleteDate()));
						}else{
							cell.setCellValue("");
						}
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_EIGHT);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAffectItmName());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_NINE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAffectItmType());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAffectItmDesc());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAffectItmRev());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWELVE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getParentName());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getBomPrefix());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getWasPartName());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getWasPartRev());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
						if (!PLMUtils.isEmpty(dataObj.getWasErpTotCostHBAE())) {
							double wasErpTotCost = Double.parseDouble(dataObj.getWasErpTotCostHBAE());
							cell.setCellValue(wasErpTotCost);
						} else {
							cell.setCellValue(dataObj.getWasErpTotCostHBAE());
						}
						cell.setCellStyle(currencyStyle);
						
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
						if (!PLMUtils.isEmpty(dataObj.getWasErpTotCostHBAG())) {
							double wasErpTotCost = Double.parseDouble(dataObj.getWasErpTotCostHBAG());
							cell.setCellValue(wasErpTotCost);
						} else {
							cell.setCellValue(dataObj.getWasErpTotCostHBAG());
						}
						cell.setCellStyle(currencyStyle);
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_EIGHTEEN);
						if (!PLMUtils.isEmpty(dataObj.getWasEstCost())) {
							double wasEstCost = Double.parseDouble(dataObj.getWasEstCost());
							if(dataObj.getWasPartName().equals("")){
                                   cell.setCellValue("");
                            } else{
                               	cell.setCellValue(wasEstCost);
                            }	
						} else {
							cell.setCellValue(dataObj.getWasEstCost());
						}
						cell.setCellStyle(currencyStyle);
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_NINETEEN);
						if (!PLMUtils.isEmpty(dataObj.getWasTargetCost())) {
							double wasTgtCost = Double.parseDouble(dataObj.getWasTargetCost());
							if(dataObj.getWasPartName().equals("")){
                                   cell.setCellValue("");
                            } else{
                               	cell.setCellValue(wasTgtCost);
                            }	
						} else {
							cell.setCellValue(dataObj.getWasTargetCost());
						}
						cell.setCellStyle(currencyStyle);
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTY);
						if (!PLMUtils.isEmpty(dataObj.getWasErpTotCostAG())) {
							double wasErpTotCost = Double.parseDouble(dataObj.getWasErpTotCostAG());
							cell.setCellValue(wasErpTotCost);
						} else {
							cell.setCellValue(dataObj.getWasErpTotCostAG());
						}
						cell.setCellStyle(currencyStyle);
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYONE);
						if (!PLMUtils.isEmpty(dataObj.getWasErpTotCostSG())) {
							double wasErpTotCost = Double.parseDouble(dataObj.getWasErpTotCostSG());
							cell.setCellValue(wasErpTotCost);
						} else {
							cell.setCellValue(dataObj.getWasErpTotCostSG());
						}
						cell.setCellStyle(currencyStyle);
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYTWO);
						if (!PLMUtils.isEmpty(dataObj.getWasErpTotCostAE())) {
							double wasErpTotCost = Double.parseDouble(dataObj.getWasErpTotCostAE());
							cell.setCellValue(wasErpTotCost);
						} else {
							cell.setCellValue(dataObj.getWasErpTotCostAE());
						}
						cell.setCellStyle(currencyStyle);
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYTHREE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getWasCopicsParent());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYFOUR);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getWasBomQuantity());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYFIVE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoName());
						
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYSIX);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoStatus());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYSEVEN);
						cell.setCellStyle(dateStyle1);
						
						if(dataObj.getEcoCompleteDate()!=null){
							cell.setCellValue(dateFormat1.format(dataObj.getEcoCompleteDate()));
						}else{
							cell.setCellValue("");
						}
					
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYEIGHT);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoFastTrack());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYNINE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getIsPartName());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTY);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getIsPartRev());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYONE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getIsPartState());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYTWO);
						if (!PLMUtils.isEmpty(dataObj.getIsEstCost())) {
							double isEstCost = Double.parseDouble(dataObj.getIsEstCost()); 		
                            if(dataObj.getIsPartName().equals("")){
                                cell.setCellValue("");
                            } else{
                            	cell.setCellValue(isEstCost);
                            }					
						} else {
							cell.setCellValue(dataObj.getIsEstCost());
						}
						cell.setCellStyle(currencyStyle);
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYTHREE);
						if (!PLMUtils.isEmpty(dataObj.getIsTargetCost())) {
							double isTgtCost = Double.parseDouble(dataObj.getIsTargetCost()); 
							if(dataObj.getIsPartName().equals("")){
                                   cell.setCellValue("");
                            } else{
                               	cell.setCellValue(isTgtCost);
                            }	
						} else {
							cell.setCellValue(dataObj.getIsTargetCost());
						}
						cell.setCellStyle(currencyStyle);
						
										
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYFOUR);
						if (!PLMUtils.isEmpty(dataObj.getIsErpTotCostAE())) {
							double isErpTotCost = Double.parseDouble(dataObj.getIsErpTotCostAE()); 
							cell.setCellValue(isErpTotCost);
						} else {
							cell.setCellValue(dataObj.getIsErpTotCostAE());
						}
						cell.setCellStyle(currencyStyle);
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYFIVE);
						if (!PLMUtils.isEmpty(dataObj.getIsErpTotCostAG())) {
							double isErpTotCost = Double.parseDouble(dataObj.getIsErpTotCostAG()); 
							cell.setCellValue(isErpTotCost);
						} else {
							cell.setCellValue(dataObj.getIsErpTotCostAG());
						}
						cell.setCellStyle(currencyStyle);
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYSIX);
						if (!PLMUtils.isEmpty(dataObj.getIsErpTotCostHBAE())) {
							double isErpTotCost = Double.parseDouble(dataObj.getIsErpTotCostHBAE()); 
							cell.setCellValue(isErpTotCost);
						} else {
							cell.setCellValue(dataObj.getIsErpTotCostHBAE());
						}
						cell.setCellStyle(currencyStyle);
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYSEVEN);
						if (!PLMUtils.isEmpty(dataObj.getIsErpTotCostHBAG())) {
							double isErpTotCost = Double.parseDouble(dataObj.getIsErpTotCostHBAG()); 
							cell.setCellValue(isErpTotCost);
						} else {
							cell.setCellValue(dataObj.getIsErpTotCostHBAG());
						}
						cell.setCellStyle(currencyStyle);
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYEIGHT);
						if (!PLMUtils.isEmpty(dataObj.getIsErpTotCostSG())) {
							double isErpTotCost = Double.parseDouble(dataObj.getIsErpTotCostSG()); 
							cell.setCellValue(isErpTotCost);
						} else {
							cell.setCellValue(dataObj.getIsErpTotCostSG());
						}
						cell.setCellStyle(currencyStyle);
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYNINE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getIsCopicsParent());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTY);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getIsBomQuantity());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTYONE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoCtgryChng());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTYTWO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoSeverity());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTYTHREE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoSubstant());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTYFOUR);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoDesc());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTYFIVE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getReqstChng());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTYSIX);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getDisposInFeild());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTYSEVEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getDisposInProcess());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTYEIGHT);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getDisposInStock());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTYNINE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getDisposOnOrder());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIFTY);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getEcoPolicy());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIFTYONE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getClsIimpactTxt());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIFTYTWO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getBomMarkup());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIFTYTHREE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getBomMarkupType());
						
						cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIFTYFOUR);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getDfsOrder());
						
					}
					
					row = (SXSSFRow) sheet.createRow(++rowcount);
					row = (SXSSFRow) sheet.createRow(++rowcount);
				short colWidth = (short)6400;
				short colWidth1 = (short)6700;
				short colWidth2 = (short)7000;
				short colWidth3 = (short)7200;
				short colWidth4 = (short)7900;
				short colWidth5 = (short)8600;
								
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,colWidth1);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWELVE,colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTEEN,colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTEEN,colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTEEN,colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIXTEEN,colWidth5);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVENTEEN,colWidth5);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHTEEN,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINETEEN,colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTY,colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYONE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYTWO,colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYTHREE,colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYFOUR,colWidth5);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYFIVE,colWidth5);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYSIX,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYSEVEN,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYEIGHT,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYNINE,colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTY,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYONE,colWidth1);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYTWO,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYTHREE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYFOUR,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYFIVE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYSIX,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYSEVEN,colWidth1);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYEIGHT,colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYNINE,colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTY,colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYONE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYTWO,colWidth5);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYTHREE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYFOUR,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYFIVE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYSIX,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYSEVEN,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYEIGHT,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYNINE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTY,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTYONE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTYTWO,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTYTHREE,colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTYFOUR,colWidth);

					//Added by Raju
					createSmryTabXLSX(workbook,costChgResultList,filePathXlsx);
				
				} else {
					LOG.info("There is no record found for " + contractNumLcl1+" in method saveCostChngXLSX File");
					SXSSFRow row = (SXSSFRow) sheet.createRow(++rowcount);
					SXSSFCell cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					String noRecordMsg = PLMConstants.COST_CHG_NO_RECORD_FOUND + contractNumLcl1;
					cell.setCellValue(noRecordMsg);
					cell.setCellStyle(noRecordCellStyle);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
				}	
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveCostChngXLSX File: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveCostChngXLSX File: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveCostChngXLSFile: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveCostChngXLSX File Method");
	}
	//Raju Start
	/**
	 * This method is used for createSmryTabXLSX
	 * 
	 * @param  workbookLocal, costChgResultListLocal,filePathXlsx
	 * @throws IOException
	 */
	public void createSmryTabXLSX(SXSSFWorkbook workbookLocal, List<PLMCostChngData> costChgResultListLocal,String filePathXlsx)
	throws IOException {
		LOG.info("Entering createSummaryReportTab File Method");
		//sheet Creation and creating styles
		FileOutputStream fileOut = null;
		try{
		File fileName = new File(filePathXlsx);
		if (fileName.exists()) {
		fileOut = new FileOutputStream(filePathXlsx);
		SXSSFSheet sheet =  (SXSSFSheet) workbookLocal.createSheet("Summary Report");
		XSSFCellStyle headerStyle = (XSSFCellStyle) workbookLocal.createCellStyle();
		
		headerStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		headerStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		headerStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		headerStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		headerStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex()); 
		headerStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
		XSSFFont font = (XSSFFont) workbookLocal.createFont(); 
		font.setFontName(PLMConstants.EXCEL_FONT_NAME);
		font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		font.setFontHeightInPoints((short)10);
		
		headerStyle.setFont(font);
		headerStyle = setBorderStyle(headerStyle);
		
		XSSFCellStyle cellBoldStyle = (XSSFCellStyle) workbookLocal.createCellStyle();
		cellBoldStyle = setBorderStyle(cellBoldStyle);
		cellBoldStyle.setFont(font);
		
		XSSFFont nonBoldFont = (XSSFFont) workbookLocal.createFont();
		nonBoldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
		nonBoldFont.setFontHeightInPoints((short)10);
		
		XSSFCellStyle contentStyle = (XSSFCellStyle) workbookLocal.createCellStyle();				
		contentStyle = setBorderStyle(contentStyle);
		contentStyle.setFont(nonBoldFont);
		XSSFCellStyle contentDecimalStyle = (XSSFCellStyle) workbookLocal.createCellStyle();				
		contentDecimalStyle = setBorderStyle(contentDecimalStyle);
		contentDecimalStyle.setFont(nonBoldFont);
		DataFormat format = workbookLocal.createDataFormat();
		contentDecimalStyle.setDataFormat(format.getFormat("0.00000"));
				
		XSSFFont noRecordFont = (XSSFFont) workbookLocal.createFont(); 
		noRecordFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		noRecordFont.setColor(Font.COLOR_RED);
		noRecordFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
		noRecordFont.setFontHeightInPoints((short)10);
		XSSFCellStyle noRecordCellStyle = (XSSFCellStyle) workbookLocal.createCellStyle();
		noRecordCellStyle = setBorderStyle(noRecordCellStyle);
		noRecordCellStyle.setFont(noRecordFont);

		CreationHelper createHelper = workbookLocal.getCreationHelper();

		XSSFCellStyle dateStyle = (XSSFCellStyle) workbookLocal.createCellStyle();
		
		dateStyle.setDataFormat(
	        createHelper.createDataFormat().getFormat("mm/dd/yyyy"));
		
		dateStyle = setBorderStyle(contentStyle);		
		dateStyle.setFont(nonBoldFont);
		
		XSSFCellStyle currencyStyle = (XSSFCellStyle) workbookLocal.createCellStyle();
	    XSSFDataFormat df = (XSSFDataFormat) workbookLocal.createDataFormat();
	    currencyStyle.setDataFormat(df.getFormat("$#,##0.00"));
	    currencyStyle = setBorderStyle(currencyStyle);		
	    currencyStyle.setFont(nonBoldFont);
	    
	    XSSFCellStyle dateStyle1 = (XSSFCellStyle) workbookLocal.createCellStyle();
		dateStyle1.setDataFormat(createHelper.createDataFormat().getFormat("m/d/yy h:mm"));
		dateStyle1 = setBorderStyle(contentStyle);
		dateStyle1.setFont(nonBoldFont);
		
	  //End sheet Creation and creating styles
		
		int rowcount = -1;
		
		if(!PLMUtils.isEmptyList(costChgResultListLocal)) {
			
			String[] colNames = {"TOP_LEVEL_PARENT_NAME","LVL_ONE_PARENT_NAME",
					"ECR_NAME",
					"ECR_DESCRIPTION","ECR_STATUS","ECR_STATUS_DATE",
					"WAS_PART_NAME","WAS_PART_REV","WAS_ERP_TOTAL_COST_HB-AE","WAS_ERP_TOTAL_COST_HB-AG",
					"WAS_ESTIMATED_COST",
					"WAS_ERP_TOTAL_COST_AE",
					"IS_PART_NAME",
					"IS_PART_REV",
					"IS_PART_STATE","IS_ESTIMATED_COST","IS_ERP_TOTAL_COST (AE)","CATEGORY_OF_CHANGE"};						
			
			SXSSFRow row = (SXSSFRow)sheet.createRow(++rowcount);
			SXSSFCell cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
			cell.setCellValue(PLMConstants.COST_CHG_SEARCH_CRITERIA_MLNO);
			cell.setCellStyle(cellBoldStyle);

			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(contractNum);
			cell.setCellStyle(cellBoldStyle);
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
			for ( int i = 0 ; i < colNames.length; i++ ) {
				cell = (SXSSFCell)  row.createCell(i);
				cell. setCellValue(colNames[i]);
				cell.setCellStyle(headerStyle);
			}
			for(int i = 0; i < costChgResultListLocal.size(); i++) {
				PLMCostChngData dataObj = (PLMCostChngData) costChgResultListLocal.get(i);
				row = (SXSSFRow) sheet.createRow(++rowcount);
				
				

					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getTopLevelparent());
					
					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getLvlOneParentName());		
	
					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getEcrName());
		
					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THREE);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getEcrDescCst());
					
					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getEcrStatus());
					
					DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");
					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell.setCellStyle(dateStyle1);
					if(dataObj.getEcrCompleteDate()!=null){
						cell.setCellValue(dateFormat.format(dataObj.getEcrCompleteDate()));
					}else{
						cell.setCellValue("");
					}

					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SIX);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getWasPartName());
					
					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SEVEN);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getWasPartRev());
					
									
					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_EIGHT);
					if (!PLMUtils.isEmpty(dataObj.getWasErpTotCostHBAE())) {
						double wasErpTotCost = Double.parseDouble(dataObj.getWasErpTotCostHBAE());
						cell.setCellValue(wasErpTotCost);
					} else {
						cell.setCellValue(dataObj.getWasErpTotCostHBAE());
					}
					cell.setCellStyle(currencyStyle);
					
					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_NINE);
					if (!PLMUtils.isEmpty(dataObj.getWasErpTotCostHBAG())) {
						double wasErpTotCost = Double.parseDouble(dataObj.getWasErpTotCostHBAG());
						cell.setCellValue(wasErpTotCost);
					} else {
						cell.setCellValue(dataObj.getWasErpTotCostHBAG());
					}
					cell.setCellStyle(currencyStyle);
					
					
					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TEN);
					if (!PLMUtils.isEmpty(dataObj.getWasEstCost())) {
						double wasEstCost = Double.parseDouble(dataObj.getWasEstCost());
						cell.setCellValue(wasEstCost);
                        }	 
					   else {
						cell.setCellValue(dataObj.getWasEstCost());
					}
					cell.setCellStyle(currencyStyle);
					
					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
					if (!PLMUtils.isEmpty(dataObj.getWasErpTotCostAE())) {
						double wasErpTotCost = Double.parseDouble(dataObj.getWasErpTotCostAE());
						cell.setCellValue(wasErpTotCost);
					} else {
						cell.setCellValue(dataObj.getWasErpTotCostAE());
					}
					cell.setCellStyle(currencyStyle);
					
					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWELVE);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getIsPartName());
					
					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getIsPartRev());
					
					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getIsPartState());
						
					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
					if (!PLMUtils.isEmpty(dataObj.getIsEstCost())) {
						double isEstCost = Double.parseDouble(dataObj.getIsEstCost()); 		
                       	cell.setCellValue(isEstCost);			
					} else {
						cell.setCellValue(dataObj.getIsEstCost());
					}
					cell.setCellStyle(currencyStyle);
					
					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
					if (!PLMUtils.isEmpty(dataObj.getIsErpTotCostAE())) {
						double isErpTotCost = Double.parseDouble(dataObj.getIsErpTotCostAE()); 
						cell.setCellValue(isErpTotCost);
					} else {
						cell.setCellValue(dataObj.getIsErpTotCostAE());
					}
					cell.setCellStyle(currencyStyle);

					cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getEcoCtgryChng());
										
			}
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			row = (SXSSFRow) sheet.createRow(++rowcount);
		short colWidth = (short)6400;
		short colWidth1 = (short)6700;
		short colWidth2 = (short)7000;
		short colWidth3 = (short)7200;
		short colWidth4 = (short)7900;
		short colWidth5 = (short)8600;
						
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,colWidth4);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,colWidth2);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,colWidth1);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,colWidth);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,colWidth2);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,colWidth2);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,colWidth3);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,colWidth);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,colWidth);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE,colWidth);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN,colWidth);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN,colWidth);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWELVE,colWidth3);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTEEN,colWidth3);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTEEN,colWidth5);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTEEN,colWidth5);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIXTEEN,colWidth);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVENTEEN,colWidth2);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHTEEN,colWidth2);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINETEEN,colWidth);	
		
		} 
	}
		}
		catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@createSummaryReportTab File: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@createSummaryReportTab: ", e);
				throw e;
			}
		}
		LOG.info("Exiting createSummaryReportTab File Method");
	}
	//Raju End
	
	// Summary Report XLS Start
	/**
	 * This method is used for createSmryTabXLS
	 * 
	 * @param  workbookLocal, costChgResultListLocal,filePathXlsx
	 * @throws IOException
	 */
	public void createSmryTabXLS(HSSFWorkbook workbookLocal, List<PLMCostChngData> costChgResultListLocal,String filePathXls)
	throws IOException {
		LOG.info("Entering createSmryTabXLS File Method");
		//sheet Creation and creating styles
		FileOutputStream fileOut = null;
		try{
		File fileName = new File(filePathXls);
		if (fileName.exists()) {
		fileOut = new FileOutputStream(filePathXls);
		HSSFSheet sheet =  workbookLocal.createSheet("Summary Report");
		HSSFCellStyle headerStyle = workbookLocal.createCellStyle();
		
		headerStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
		headerStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
		headerStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex()); 
		headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		HSSFFont font = workbookLocal.createFont(); 
		font.setFontName(PLMConstants.EXCEL_FONT_NAME);
		font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		font.setFontHeightInPoints((short)10);
		headerStyle.setFont(font);
		headerStyle = setBorderStyle(headerStyle);
		
		HSSFCellStyle cellBoldStyle = workbookLocal.createCellStyle();
		cellBoldStyle = setBorderStyle(cellBoldStyle);
		cellBoldStyle.setFont(font);
		
		HSSFFont nonBoldFont = workbookLocal.createFont();
		nonBoldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
		HSSFCellStyle contentStyle = workbookLocal.createCellStyle();				
		contentStyle = setBorderStyle(contentStyle);
		contentStyle.setFont(nonBoldFont);
		HSSFCellStyle contentDecimalStyle = workbookLocal.createCellStyle();				
		contentDecimalStyle = setBorderStyle(contentDecimalStyle);
		contentDecimalStyle.setFont(nonBoldFont);
		DataFormat format = workbookLocal.createDataFormat();
		contentDecimalStyle.setDataFormat(format.getFormat("0.00000"));
				
		HSSFFont noRecordFont = workbookLocal.createFont(); 
		noRecordFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		noRecordFont.setColor(Font.COLOR_RED);
		noRecordFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
		noRecordFont.setFontHeightInPoints((short)10);

		HSSFCellStyle noRecordCellStyle = workbookLocal.createCellStyle();
		noRecordCellStyle = setBorderStyle(noRecordCellStyle);
		noRecordCellStyle.setFont(noRecordFont);

		CreationHelper createHelper = workbookLocal.getCreationHelper();

		HSSFCellStyle dateStyle = workbookLocal.createCellStyle();
		
		dateStyle.setDataFormat(
	        createHelper.createDataFormat().getFormat("mm/dd/yyyy"));
		
		dateStyle = setBorderStyle(contentStyle);		
		dateStyle.setFont(nonBoldFont);
		
		HSSFCellStyle currencyStyle = workbookLocal.createCellStyle();
	    HSSFDataFormat df = workbookLocal.createDataFormat();
	    currencyStyle.setDataFormat(df.getFormat("$#,##0.00"));
	    currencyStyle = setBorderStyle(currencyStyle);		
	    currencyStyle.setFont(nonBoldFont);
	  //End sheet Creation and creating styles
		
		int rowcount = -1;
		
		if(!PLMUtils.isEmptyList(costChgResultListLocal)) {
			
			String[] colNames = {"TOP_LEVEL_PARENT_NAME","LVL_ONE_PARENT_NAME",
					"ECR_NAME",
					"ECR_DESCRIPTION","ECR_STATUS","ECR_STATUS_DATE",
					"WAS_PART_NAME","WAS_PART_REV","WAS_ERP_TOTAL_COST_HB-AE","WAS_ERP_TOTAL_COST_HB-AG",
					"WAS_ESTIMATED_COST",
					"WAS_ERP_TOTAL_COST_AE",
					"IS_PART_NAME",
					"IS_PART_REV",
					"IS_PART_STATE","IS_ESTIMATED_COST","IS_ERP_TOTAL_COST (AE)","CATEGORY_OF_CHANGE"};						
			
			HSSFRow row = sheet.createRow(++rowcount);
			HSSFCell cell = row.createCell(PLMConstants.EXCEL_COL_ZERO); 
			cell.setCellValue(PLMConstants.COST_CHG_SEARCH_CRITERIA_MLNO);
			cell.setCellStyle(cellBoldStyle);

			cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(contractNum);
			cell.setCellStyle(cellBoldStyle);
			
			row = sheet.createRow(++rowcount);
			row = sheet.createRow(++rowcount);
			
			for ( int i = 0 ; i < colNames.length; i++ ) {
				cell = row.createCell(i);
				cell. setCellValue(colNames[i]);
				cell.setCellStyle(headerStyle);
			}
			for(int i = 0; i < costChgResultListLocal.size(); i++) {
				PLMCostChngData dataObj = (PLMCostChngData) costChgResultListLocal.get(i);
				row = sheet.createRow(++rowcount);
				
				

					cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getTopLevelparent());
					
					cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(cellBoldStyle);
					cell.setCellValue(dataObj.getLvlOneParentName());		
	
					cell = row.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getEcrName());
		
					cell = row.createCell(PLMConstants.EXCEL_COL_THREE);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getEcrDescCst());
					
					cell = row.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getEcrStatus());
					
					cell = row.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getEcrCompleteDate());

					cell = row.createCell(PLMConstants.EXCEL_COL_SIX);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getWasPartName());
					
					cell = row.createCell(PLMConstants.EXCEL_COL_SEVEN);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getWasPartRev());
					
									
					cell = row.createCell(PLMConstants.EXCEL_COL_EIGHT);
					if (!PLMUtils.isEmpty(dataObj.getWasErpTotCostHBAE())) {
						double wasErpTotCost = Double.parseDouble(dataObj.getWasErpTotCostHBAE());
						cell.setCellValue(wasErpTotCost);
					} else {
						cell.setCellValue(dataObj.getWasErpTotCostHBAE());
					}
					cell.setCellStyle(currencyStyle);
					
					cell = row.createCell(PLMConstants.EXCEL_COL_NINE);
					if (!PLMUtils.isEmpty(dataObj.getWasErpTotCostHBAG())) {
						double wasErpTotCost = Double.parseDouble(dataObj.getWasErpTotCostHBAG());
						cell.setCellValue(wasErpTotCost);
					} else {
						cell.setCellValue(dataObj.getWasErpTotCostHBAG());
					}
					cell.setCellStyle(currencyStyle);
					
					
					cell = row.createCell(PLMConstants.EXCEL_COL_TEN);
					if (!PLMUtils.isEmpty(dataObj.getWasEstCost())) {
						double wasEstCost = Double.parseDouble(dataObj.getWasEstCost());
						cell.setCellValue(wasEstCost);
                        }	 
					   else {
						cell.setCellValue(dataObj.getWasEstCost());
					}
					cell.setCellStyle(currencyStyle);
					
					cell = row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
					if (!PLMUtils.isEmpty(dataObj.getWasErpTotCostAE())) {
						double wasErpTotCost = Double.parseDouble(dataObj.getWasErpTotCostAE());
						cell.setCellValue(wasErpTotCost);
					} else {
						cell.setCellValue(dataObj.getWasErpTotCostAE());
					}
					cell.setCellStyle(currencyStyle);
					
					cell = row.createCell(PLMConstants.EXCEL_COL_TWELVE);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getIsPartName());
					
					cell = row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getIsPartRev());
					
					cell = row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getIsPartState());
						
					cell = row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
					if (!PLMUtils.isEmpty(dataObj.getIsEstCost())) {
						double isEstCost = Double.parseDouble(dataObj.getIsEstCost()); 		
                       	cell.setCellValue(isEstCost);			
					} else {
						cell.setCellValue(dataObj.getIsEstCost());
					}
					cell.setCellStyle(currencyStyle);
					
					cell = row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
					if (!PLMUtils.isEmpty(dataObj.getIsErpTotCostAE())) {
						double isErpTotCost = Double.parseDouble(dataObj.getIsErpTotCostAE()); 
						cell.setCellValue(isErpTotCost);
					} else {
						cell.setCellValue(dataObj.getIsErpTotCostAE());
					}
					cell.setCellStyle(currencyStyle);

					cell = row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
					cell.setCellStyle(contentStyle);
					cell.setCellValue(dataObj.getEcoCtgryChng());
										
			}
			
			row = sheet.createRow(++rowcount);
			row = sheet.createRow(++rowcount);
		short colWidth = (short)6400;
		short colWidth1 = (short)6700;
		short colWidth2 = (short)7000;
		short colWidth3 = (short)7200;
		short colWidth4 = (short)7900;
		short colWidth5 = (short)8600;
						
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,colWidth4);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,colWidth2);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,colWidth1);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,colWidth);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,colWidth2);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,colWidth2);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,colWidth3);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,colWidth);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,colWidth);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE,colWidth);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN,colWidth);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN,colWidth);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWELVE,colWidth3);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTEEN,colWidth3);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTEEN,colWidth5);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTEEN,colWidth5);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIXTEEN,colWidth);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVENTEEN,colWidth2);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHTEEN,colWidth2);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINETEEN,colWidth);	
		
		} 
	}
		}
		catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@createSmryTabXLS method: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@createSmryTabXLS method: ", e);
				throw e;
			}
		}
		LOG.info("Exiting createSmryTabXLS File Method");
	}
	//Summary Report XLS End
	/**
	 * This method is used for saveCostChngCSVFile
	 * 
	 * @param  contractNumLcl2, costChgResultList,fileDir,filePathXlsx
	 * @throws Exception
	 */
	public void saveCostChngCSVFile(String contractNumLcl2,List<PLMCostChngData> costChgResultList,String fileDir,String filePathXls) throws Exception {
		LOG.info("Entering saveCostChngCSVFile Method");
		FileOutputStream fileOut = null;
		PrintWriter pwriter =null;
		boolean createFileExist;
		try {
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
					fileOut = new FileOutputStream(filePathXls);
					pwriter =  new PrintWriter( new FileWriter(filePathXls));
					
					
						pwriter.write("Contract Number : ");
						pwriter.write(",");
						pwriter.write(contractNumLcl2);
						pwriter.write("\n");
					
					    pwriter.write("\n");
		 			
					  	pwriter.write("TOP_LEVEL_PARENT_NAME");
			 			pwriter.write(",");
			 			pwriter.write("LVL_ONE_PARENT_NAME");
			 			pwriter.write(",");
			 			pwriter.write("LVL_ONE_PARENT_REV");
			 			pwriter.write(",");
			 			pwriter.write("AFFCT_ITEM_LVL");
			 			pwriter.write(",");
			 			pwriter.write("AFFCT_ITEM_NAME");
			 			pwriter.write(",");
			  			pwriter.write("AFFCT_ITEM_PART_TYPE");
			 			pwriter.write(",");
			 			pwriter.write("AFFCT_ITEM_PART_DESC");
			 			pwriter.write(",");
			 			pwriter.write("AFFCT_ITEM_REV");
			 			pwriter.write(",");
			 			pwriter.write("IS_PART_NAME");
			 			pwriter.write(",");
			 			pwriter.write("IS_PART_REV");
			 			pwriter.write(",");
			 			pwriter.write("IS_ESTIMATED_COST");
			 			pwriter.write(",");
			 			pwriter.write("IS_TARGET_COST");
			 			pwriter.write(",");
			 			/*pwriter.write("IS_ERP_TOTAL_COST");
			 			pwriter.write(",");*/
			 			pwriter.write("WAS_PART_NAME");
			 			pwriter.write(",");
			 			pwriter.write("WAS_PART_REV");
			 			pwriter.write(",");
			 			pwriter.write("WAS_ESTIMATED_COST");
			 			pwriter.write(",");
			 			pwriter.write("WAS_TARGET_COST");
			 			pwriter.write(",");
			 			/*pwriter.write("WAS_ERP_TOTAL_COST");
			 			pwriter.write(",");*/
			 			pwriter.write("ECR_NAME");
			 			pwriter.write(",");
			 			pwriter.write("ECR_DESCRIPTION");
			 			pwriter.write(",");
			 			pwriter.write("ECO_NAME");
			 			pwriter.write(",");
			 			pwriter.write("ECO_FAST_TRACK");
			 			pwriter.write(",");
			 			pwriter.write("CATEGORY_OF_CHANGE");
			 			pwriter.write(",");
			 			pwriter.write("ECO_SEVERITY");
			 			pwriter.write(",");
			 			pwriter.write("ECO_SUBSTANTIATION");
			 			pwriter.write(",");
			 			pwriter.write("ECO_DESCRIPTION");
			 			pwriter.write(",");
			 			pwriter.write("ECR_STATUS");
			 			pwriter.write(",");
			 			pwriter.write("ECO_STATUS");
			 			pwriter.write(",");
			 			pwriter.write("REQSTD_CHNG");
			 			pwriter.write(",");
			 			pwriter.write("DISPOSITION_IN_FIELD");
			 			pwriter.write(",");
			 			pwriter.write("DISPOSITION_IN_PROCESS");
			 			pwriter.write(",");
			 			pwriter.write("DISPOSITION_IN_STOCK");
			 			pwriter.write(",");
			 			pwriter.write("DISPOSITION_ON_ORDER");
			 			pwriter.write(",");
			 			pwriter.write("ECO_POLICY");
			 			pwriter.write(",");
			 			pwriter.write("CLS_I_IMPACT_STMT_TXT");
			 			pwriter.write(",");
			 			pwriter.write("BOM_MARKUP");
			 			pwriter.write(",");
			 			pwriter.write("BOM_MARKUP_TYPE");
			 			pwriter.write(",");
			 			pwriter.write("DFSORDER");
			 		
								 			
			 			pwriter.write("\n");
			 			
			 			if(costChgResultList != null &&  costChgResultList.size() > 0) {
		 		     		
					   		for(int i=0; i<costChgResultList.size(); i++) {
					   			PLMCostChngData dataObj = (PLMCostChngData)costChgResultList.get(i);
					
					   			if(dataObj.getTopLevelparent()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTopLevelparent()));
						   			}
					   			pwriter.write(",");
					   			if(dataObj.getLvlOneParentName()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getLvlOneParentName()));
								}
								pwriter.write(",");
								if(dataObj.getLvlOneParentRev()!= null){
									pwriter.write("=\""+dataObj.getLvlOneParentRev()+"\"");
								}
								pwriter.write(",");
								if(dataObj.getAffectItmLvl()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getAffectItmLvl()));
								}
								pwriter.write(",");
								if(dataObj.getAffectItmName()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getAffectItmName()));
								}
								pwriter.write(",");
					   			if(dataObj.getAffectItmType()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getAffectItmType()));
						   		}
					   			pwriter.write(",");
					   			if(dataObj.getAffectItmDesc()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getAffectItmDesc()));
						   		}
					   			pwriter.write(",");
					   			if(dataObj.getAffectItmRev()!= null){
					   			   pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getAffectItmRev()+"\""));
								}
								pwriter.write(",");
					   			if(dataObj.getIsPartName()!= null){
					   	   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getIsPartName()));
							   	}
					   			pwriter.write(",");
								if(dataObj.getIsPartRev()!= null){
								 pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getIsPartRev()+"\""));
								}
								pwriter.write(",");
								if(dataObj.getIsEstCost()!= null){
									pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getIsEstCost()+"\""));
								}
								pwriter.write(",");
								if(dataObj.getIsTargetCost()!= null){
									pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getIsTargetCost()+"\""));
								}
								pwriter.write(",");
								/*if(dataObj.getIsErpTotCost()!= null){
									pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getIsErpTotCost()+"\""));
								}
								pwriter.write(",");*/
								if(dataObj.getWasPartName()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getWasPartName()));
								}
								pwriter.write(",");
								if(dataObj.getWasPartRev()!= null){
									pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getWasPartRev()+"\""));
								}
								pwriter.write(",");
								if(dataObj.getWasEstCost()!= null){
									pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getWasEstCost()+"\""));
								}
								pwriter.write(",");
								if(dataObj.getWasTargetCost()!= null){
									pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getWasTargetCost()+"\""));
								}
								pwriter.write(",");
								/*if(dataObj.getWasErpTotCost()!= null){
									pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getWasErpTotCost()+"\""));
								}
								pwriter.write(",");*/
								if(dataObj.getEcrName()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrName()));
								}
								pwriter.write(",");
								if(dataObj.getEcrDescCst()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrDescCst()));
								}
								pwriter.write(",");
								if(dataObj.getEcoName()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoName()));
								}
								pwriter.write(",");
								if(dataObj.getEcoFastTrack()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoFastTrack()));
								}
								pwriter.write(",");
								if(dataObj.getEcoCtgryChng()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoCtgryChng()));
								}
								pwriter.write(",");
								if(dataObj.getEcoSeverity()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoSeverity()));
								}
								pwriter.write(",");
								if(dataObj.getEcoSubstant()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoSubstant()));
								}
								pwriter.write(",");
								if(dataObj.getEcoDesc()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoDesc()));
								}
								pwriter.write(",");
								if(dataObj.getEcrStatus()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrStatus()));
								}
								pwriter.write(",");
								if(dataObj.getEcoStatus()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoStatus()));
								}
								pwriter.write(",");
								if(dataObj.getReqstChng()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getReqstChng()));
								}	
								pwriter.write(",");
								if(dataObj.getDisposInFeild()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDisposInFeild()));
								}	
								pwriter.write(",");
								if(dataObj.getDisposInProcess()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDisposInProcess()));
								}	
								pwriter.write(",");
								if(dataObj.getDisposInStock()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDisposInStock()));
								}
								pwriter.write(",");
								if(dataObj.getDisposOnOrder()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDisposOnOrder()));
								}
								pwriter.write(",");
								if(dataObj.getEcoPolicy()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoPolicy()));
								}
								pwriter.write(",");
								if(dataObj.getClsIimpactTxt()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getClsIimpactTxt()));
								}
								pwriter.write(",");
								if(dataObj.getBomMarkup()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getBomMarkup()));
								}
								pwriter.write(",");
								if(dataObj.getBomMarkupType()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getBomMarkupType()));
								}
								pwriter.write(",");
								if(dataObj.getDfsOrder()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDfsOrder()));
								}
													
					   			pwriter.write("\n");
					   		}
			 			}	
					  
				}
				
			} catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@saveCostChngCSVFile: ", e);
				throw e;
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveCostChngCSVFile: ", e);
				throw e;
			}  finally {
				try {
					if (pwriter !=null) {
						pwriter.close();
					}
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@saveCostChngCSVFile: ", e);
					throw e;
				}
			}
			LOG.info("Exiting saveCostChngCSVFile Method");
		}
		


	
	
	/**
	 * This method is used for Deleting zip file and xls file
	 * 
	 * @param filePathXls,filePathZip
	 */
	public void deleteFiles(String filePathXls,String filePathZip){
		LOG.info("Entering deleteFiles method");
		boolean zipFileExist;
		boolean xlsFileExist;
		File zipFile = new File(filePathZip);
		zipFileExist = zipFile.exists();
		File xlsFile = new File(filePathXls);
		xlsFileExist = xlsFile.exists();
		if(zipFileExist){
			boolean deleted = zipFile.delete();
			LOG.info("Successfully deleted zip file : " + deleted);
		}
		if(xlsFileExist){
			boolean deleted = xlsFile.delete();
			LOG.info("Successfully deleted xls file : " + deleted);
		}
		LOG.info("Exiting deleteFiles Method");
	}
	
	/**
	 * This method is used for generating zip file
	 * 
	 * @param filePathXls,filePathZip
	 * @throws IOException
	 */
	/*public void generateZipFile(String filePathXls,String filePathZip) throws IOException {
		LOG.info("Entering generateZipFile method");
		FileOutputStream fileOut = null;
		BufferedOutputStream bufferOut = null;
		ZipOutputStream zipOut = null;
		BufferedInputStream bufferIn = null;
		FileInputStream fileIn = null;
		File xlsFile = new File(filePathXls); 
		try {
			fileOut = new FileOutputStream(filePathZip);
			bufferOut = new BufferedOutputStream(fileOut);
			zipOut = new ZipOutputStream(bufferOut);
			fileIn = new FileInputStream(filePathXls);
			bufferIn = new BufferedInputStream(fileIn);
			int count1;
			byte[] data = new byte[1000];
			zipOut.putNextEntry(new ZipEntry(xlsFile.getName()));
			while((count1 = fileIn.read(data,0,1000)) != -1){  
			zipOut.write(data, 0, count1);
			}
			bufferIn.close();
			zipOut.flush();
			zipOut.close();
   		   }catch (FileNotFoundException e) {
			 LOG.log(Level.ERROR, "Exception@generateZipFile: ", e);
			 throw e;
		   }catch (IOException e) {
			 LOG.log(Level.ERROR, "Exception@generateZipFile: ", e);
			 throw e;
		   }finally {
				try {
					if (bufferOut != null) {
						bufferOut.close();
					}
					if (zipOut != null) {
						zipOut.close();
					}
					if (fileOut != null) {
						fileOut.close();
					}
					if (fileIn != null) {
						fileIn.close();
					}
					if (bufferIn != null) {
						bufferIn.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@generateZipFile: ", e);
					throw e;
				}
			}
		LOG.info("Exiting generateZipFile Method");
	}*/
	
	/**
	 * This method is used for getcostChngReport
	 * 
	 * @return String
	 * @throws PLMCommonException
	 * @throws PWiException 
	 */
	public String getcostChngReport() throws PLMCommonException, PWiException{
		LOG.info("Entering getcostChngReport Method");
		String fwdFlag = "costchngSearch";
		
		 if(totcostChgCount==1){
			LOG.info("if totcostChgCount is single record" );
			contractSel = costChngList.get(0).getContract();
			LOG.info("contractSel  single record"+contractSel);
		  }
		     if(contractSel.equals("")){
		    	 contractSel =  contractNum;
			LOG.info("contractSel>>>>>>>"+contractSel);
			}
			LOG.info("contractNum>>>>>>>"+contractNum);
			   if(totcostChgCount !=0) {
				 alertMessage =  PLMConstants.COST_CHG_MAIL_ALERT_MSG;
				 
				 userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
				 
				taskExecutor.execute(new MailThread());
			     } 
	 	
		LOG.info("Exiting getcostChngReport Method");
		return fwdFlag;
	}
	
	/**
	 * This method is used for getContractListDetails
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getContractListDetails() throws PLMCommonException{
		String fwdFlag = "costchngSearch";
		alertMessage = "";
		totcostChgCount =0;
		contractSel="";
		costChngList= new ArrayList<PLMCostChngData>();
		try {
		
			alertMessage = validateCostChgInput();
	 		 if (PLMUtils.isEmpty(alertMessage)) {
			costChngList =  plmSearchService.getValidContractData(contractNum);
			totcostChgCount = costChngList.size();
			LOG.info("The number of results from Contract Search Query"+totcostChgCount);
			recordCounts = PLMConstants.N_100;
			if(totcostChgCount==0){
			   	alertMessage =  PLMConstants.COST_CHG_NO_RECORD_FOUND+contractNum;
			  }
		 	}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPart: ", exception);
			throw exception;
		} 
		fwdFlag = PLMConstants.EMPTY;
		return fwdFlag;
	}
	
	
	/**
	 * This method is used for Validating 
	 * 
	 * @return String
	 */
	public String validateCostChgInput() {		
		alertMessage ="";
		LOG.info("Entering validateCostChgInput Method");
		if (PLMUtils.checkSplCharsProjSumry(contractNum)) {
			alertMessage = PLMConstants.PRJ_SMRY_SPL_CRITERIA;
		} 
		LOG.info("Exiting validateCostChgInput Method");
		return alertMessage;
	}
	
	/**
	 * This method is used for getTrimValue 
	 * 
	 * @param value
	 *            .
	 * @return String
	 */
	public String getTrimValue(String value) {
		String retStr = null;
		if (!PLMUtils.isEmpty(value)) {
			retStr = value.trim();
		}
		return retStr;

	}

	public void setRecordCounts(int recordCounts) {
		LOG.info("::::::::::::::::::" + recordCounts);
		PLMUtils.getServletSession(true).setAttribute("RecDropDown",
				recordCounts);
		this.recordCounts = recordCounts;
	}

	/**
	 * @return the plmSearchService
	 */
	public PLMSearchServiceIfc getPlmSearchService() {
		return plmSearchService;
	}

	/**
	 * @param plmSearchService
	 *            the plmSearchService to set
	 */
	public void setPlmSearchService(PLMSearchServiceIfc plmSearchService) {
		this.plmSearchService = plmSearchService;
	}

	/**
	 * @return the searchResultList
	 */
	public List<PLMSearchData> getSearchResultList() {
		return searchResultList;
	}

	/**
	 * @param searchResultList
	 *            the searchResultList to set
	 */
	public void setSearchResultList(List<PLMSearchData> searchResultList) {
		this.searchResultList = searchResultList;
	}

	/**
	 * @return the searchDetails
	 */
	public PLMSearchData getSearchDetails() {
		return searchDetails;
	}

	/**
	 * @param searchDetails
	 *            the searchDetails to set
	 */
	public void setSearchDetails(PLMSearchData searchDetails) {
		this.searchDetails = searchDetails;
	}

	/**
	 * @return the count
	 */
	public int getCount() {
		return count;
	}

	/**
	 * @param count
	 *            the count to set
	 */
	public void setCount(int count) {
		this.count = count;
	}

	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount
	 *            the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/**
	 * @return the totalRecCountMsg
	 */
	public String getTotalRecCountMsg() {
		return totalRecCountMsg;
	}

	/**
	 * @param totalRecCountMsg
	 *            the totalRecCountMsg to set
	 */
	public void setTotalRecCountMsg(String totalRecCountMsg) {
		this.totalRecCountMsg = totalRecCountMsg;
	}

	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * @param fieldName
	 *            the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage
	 *            the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the stateDropDownList
	 */
	public Map<String, List<SelectItem>> getStateDropDownList() {
		return stateDropDownList;
	}

	/**
	 * @param stateDropDownList the stateDropDownList to set
	 */
	public void setStateDropDownList(Map<String, List<SelectItem>> stateDropDownList) {
		this.stateDropDownList = stateDropDownList;
	}

	/**
	 * @return the stateList
	 */
	public List<SelectItem> getStateList() {
		return stateList;
	}

	/**
	 * @param stateList the stateList to set
	 */
	public void setStateList(List<SelectItem> stateList) {
		this.stateList = stateList;
	}

	/**
	 * @return the contractNum
	 */
	public String getContractNum() {
		return contractNum;
	}

	/**
	 * @param contractNum the contractNum to set
	 */
	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}

	/**
	 * @return the contractSel
	 */
	public String getContractSel() {
		return contractSel;
	}

	/**
	 * @param contractSel the contractSel to set
	 */
	public void setContractSel(String contractSel) {
		this.contractSel = contractSel;
	}

	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return the costChngData
	 */
	public PLMCostChngData getCostChngData() {
		return costChngData;
	}

	/**
	 * @param costChngData the costChngData to set
	 */
	public void setCostChngData(PLMCostChngData costChngData) {
		this.costChngData = costChngData;
	}

	/**
	 * @return the costChngList
	 */
	public List<PLMCostChngData> getCostChngList() {
		return costChngList;
	}

	/**
	 * @param costChngList the costChngList to set
	 */
	public void setCostChngList(List<PLMCostChngData> costChngList) {
		this.costChngList = costChngList;
	}

	/**
	 * @return the totcostChgCount
	 */
	public int getTotcostChgCount() {
		return totcostChgCount;
	}

	/**
	 * @param totcostChgCount the totcostChgCount to set
	 */
	public void setTotcostChgCount(int totcostChgCount) {
		this.totcostChgCount = totcostChgCount;
	}
	
	
}