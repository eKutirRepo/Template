/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMTrendReportDaoIfc.java
 * @Creation date: 15-June-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMMbomTrendData;
import com.geinfra.geaviation.pwi.data.PLMPartTrendsData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMTrendReportDaoIfc {

	/**
	 * This method is used for getPartDropDownvalues
	 * 
	 * @return Map
	 * @param searchResultsQry
	 * @throws PLMCommonException
	 */
	Map<String, List<SelectItem>> getPartDropDownvalues(StringBuffer searchResultsQry) throws PLMCommonException;
	/**
	 * This method is used for getpartTrendSearchData
	 * 
	 * @return List
	 * @param searchResultsQry
	 * @throws PLMCommonException
	 */
	List<PLMPartTrendsData> getpartTrendSearchData(StringBuffer searchResultsQry)throws PLMCommonException;
	/**
	 * This method is used for getMbomTrendReport
	 * 
	 * @return List
	 * @param mlno
	 * @throws PLMCommonException
	 */
	public List<PLMMbomTrendData> getMbomTrendReport(String mlno)throws PLMCommonException;
	
}
