/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCompleteEbomReportDaoImpl.java
 * @Creation date: 06-Apr-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMAeroRptData;
import com.geinfra.geaviation.pwi.data.PLMCompatibilityRulesReportData;
import com.geinfra.geaviation.pwi.data.PLMCompleteEbomReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMCompleteEbomReportDaoImpl extends SimpleJdbcDaoSupport implements PLMCompleteEbomReportDaoIfc{

	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMCompleteEbomReportDaoImpl.class);
	/**
	 * This method is used for getting all distinct project names
	 * @return Map
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public Map<String, List<SelectItem>> getLoadingData()
			throws PLMCommonException {

		LOG.info("Inside getLoadingData method of PLMCompleteEbomReportDaoImpl class");
		Map<String, List<SelectItem>> dropdownlist = new HashMap<String, List<SelectItem>>();		
		List<SelectItem> projectNameList = null;
		try {			
			
			LOG.info("Query for getting distinct Project Name List : " + PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_PROJECT_FOR_AERO_COMPLETE_EBOM);
			projectNameList = getJdbcTemplate().query(PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_PROJECT_FOR_AERO_COMPLETE_EBOM,new DstnctPrjMapper());	
			Collections.sort(projectNameList, new PLMUtils.SortListSelItem());
			LOG.info("size of  Project Name List : " + projectNameList.size());
			
			dropdownlist.put("projectnamelist", projectNameList);
		
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return dropdownlist;
	}
	/**
	 * Row mapper for getting DISTINCT PROJECTS
	 */
	private static final class DstnctPrjMapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(rs
					.getString("NAME").toUpperCase());

			return selectItem;

		}
	}
	@SuppressWarnings("unchecked")
	public List<PLMCompleteEbomReportData> fetchTopPartList(String selShipBomProjectName) throws PLMCommonException {
		StringBuffer searchQuery =new StringBuffer();
		searchQuery.append(PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_TOP_PART_FROM_PROJECT);
		if(!PLMUtils.isEmpty(selShipBomProjectName)){
		searchQuery.append(selShipBomProjectName);
		searchQuery.append("'");
		}
		LOG.info("Executing QRY_FOR_GETTING_DSTNCT_TOP_PART_FROM_PROJECT : " + searchQuery.toString() + "\n");
		return getJdbcTemplate().query(searchQuery.toString(), new ProjInfoMapper());
	}
	/**
	 * @return PLMBoilerShipBomReportData objects.
	 */
	private static final class ProjInfoMapper implements ParameterizedRowMapper<PLMCompleteEbomReportData> {
		public PLMCompleteEbomReportData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCompleteEbomReportData data = new PLMCompleteEbomReportData();
			data.setTopPartName(PLMUtils.checkNullVal(rs.getString("TO_NAME")).toUpperCase());
			return data;
		}
	}
	@SuppressWarnings("unchecked")
	public List<PLMCompleteEbomReportData> generateCompleteEbomAppReport(
			String selShipBomProjectName, List<String> selShipBomTopPartName)
			throws PLMCommonException {

		LOG.info("Entering into  generateCompleteEbomAppReport");
		LOG.info("Entering into  selShipBomProjectName"+selShipBomProjectName+" selShipBomTopPartName"+selShipBomTopPartName);
		List <PLMCompleteEbomReportData> fmiappReportList= new ArrayList <PLMCompleteEbomReportData>();
		StringBuffer sqlQuery = new StringBuffer();
		boolean whereFlag=false;
		 try {
				
				sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_AERO_COMPLETE_EBOM_REPORT_FIRST);
				if(!PLMUtils.isEmpty(selShipBomProjectName)){
					sqlQuery.append(" WHERE FROM_NAME = '"+selShipBomProjectName+"'"); 
					whereFlag=true;
				}
				if(whereFlag==true && !PLMUtils.isEmptyList(selShipBomTopPartName)){
					sqlQuery.append(" and to_name in(");
					sqlQuery.append(PLMUtils.convertListToStringWithQuotes(selShipBomTopPartName));
					sqlQuery.append(")");
				}
				sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_AERO_COMPLETE_EBOM_REPORT_SECOND);	
				if(!PLMUtils.isEmpty(selShipBomProjectName)){
					sqlQuery.append(" WHERE A.NAME = '"+selShipBomProjectName+"'"); 
				}
				sqlQuery.append(" ORDER BY 21,9 ");
				LOG.info("Final Query for Aero Complete EBOM report:: "+sqlQuery);
				fmiappReportList =  getJdbcTemplate().query(sqlQuery.toString(), new CompleteEbomMapper());	
				LOG.info("Aero Complete EBOM Record Count:: "+fmiappReportList.size());
					
			} catch (DataAccessException e) {
				PLMUtils.checkException(e.getMessage());
			}catch (Exception e) {
				PLMUtils.checkException(e.getMessage());
			}
			return fmiappReportList;
	
	}
	/**
	 * @return PLMBoilerShipBomReportData objects.
	 */
	private static final class CompleteEbomMapper implements ParameterizedRowMapper<PLMCompleteEbomReportData> {
		public PLMCompleteEbomReportData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMCompleteEbomReportData tempData =new PLMCompleteEbomReportData();
			tempData.setLevel(PLMUtils.checkNullVal(rs.getString("LVL")));
			tempData.setName(PLMUtils.checkNullVal(rs.getString("CHILD_NAME")));
			tempData.setType(PLMUtils.checkNullVal(rs.getString("PART_TYPE")));
			tempData.setRev(PLMUtils.checkNullVal(rs.getString("REVISION")));
			tempData.setPolicy(PLMUtils.checkNullVal(rs.getString("POLICY")));
			tempData.setFindNum(PLMUtils.checkNullVal(rs.getString("FIND_NUM")));
			tempData.setRefDesignator(PLMUtils.checkNullVal(rs.getString("REF_DESIGNATOR")));
			tempData.setComponentLocation(PLMUtils.checkNullVal(rs.getString("COMPONENT_LOCATION")));
			tempData.setDescription(PLMUtils.checkNullVal(rs.getString("DESCRIPTION")));
			tempData.setState(PLMUtils.checkNullVal(rs.getString("STATE")));
			tempData.setQuantity(PLMUtils.checkNullVal(rs.getString("QUANTITY")));
			tempData.setUnitOfMeasure(PLMUtils.checkNullVal(rs.getString("UNIT_MEASURE")));
			tempData.setUsage(PLMUtils.checkNullVal(rs.getString("USAGE")));
			tempData.setPartFamily(PLMUtils.checkNullVal(rs.getString("PART_FAMILY")));
			
			return tempData;
		}
	}
	/**
	 * This method is used to getHardwareProductNames
	 * @return
	 * @throws PLMCommonException
	 */
	public List<SelectItem>getHardwareProductNames() throws PLMCommonException{
		LOG.info("Entering getHardwareProductNames");
		List<SelectItem> plantNameList = new ArrayList<SelectItem>();
		try {
			LOG.info("Executed Query for getting Hardware Product Names list"+PLMSearchQueries.GET_HARDWARE_NAMES);
			plantNameList =getSimpleJdbcTemplate().query(
					PLMSearchQueries.GET_HARDWARE_NAMES, new HardWareProdNmMapper());
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getHardwareProductNames");
		return plantNameList;
	}
	/**
	 * Row mapper for getting dropMapper
	 */
	
	private static final class HardWareProdNmMapper implements ParameterizedRowMapper<SelectItem>{ 	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(rs.getString("NAME"));
			return selectItem;
		}
   }

	/**
	 * This method is used to getRevisionNames
	 * @return
	 * @throws PLMCommonException
	 */
	public List<SelectItem>getRevisionNames(String hardWarePrdNm) throws PLMCommonException{
		LOG.info("Entering getRevisionNames");
		List<SelectItem> plantNameList = new ArrayList<SelectItem>();
		try {
			LOG.info("Executed Query for getting Revision Names list"+PLMSearchQueries.GET_REVISIONS);
			plantNameList =getSimpleJdbcTemplate().query(
					PLMSearchQueries.GET_REVISIONS, new RevisionNmMapper(),hardWarePrdNm);
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getRevisionNames");
		return plantNameList;
	
	}
	/**
	 * Row mapper for getting dropMapper
	 */
	
	private static final class RevisionNmMapper implements ParameterizedRowMapper<SelectItem>{ 	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(rs.getString("REVISION"));
			return selectItem;
		}
   }

	/**
	 * This method is used to get Logical Features
	 * @param hardWarePrd,revision
	 * @return
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public Map<String,Object> getLogicalFeatureData(
			String hardWarePrd,String revision) throws PLMCommonException{
		LOG.info("Entering into  getLogicalFeatureData");
		LOG.info("Entering into  HardWare Product Nm>> "+hardWarePrd+" Revision>> "+revision);
		Map<String,Object> logicaFeatureMap = new HashMap<String,Object>();
		List <PLMAeroRptData> logicaFeaturesList= new ArrayList <PLMAeroRptData>();
		String timeStamp = PLMUtils.volTableFormatDate();
		String AERO_LOGICAL = PLMConstants.AERO_LOGICAL.concat(timeStamp);
		String AERO_PART = PLMConstants.AERO_PART.concat(timeStamp);
		StringBuffer sqlQuery = new StringBuffer();
		int maxLvl =0;
		 try {
			 if(!PLMUtils.isEmpty(hardWarePrd) && !PLMUtils.isEmpty(revision)){
				 
				 sqlQuery.append(PLMSearchQueries.CREATE_AERO_LOGICAL_VT.replace("AERO_LOGICAL", AERO_LOGICAL)
						 .replace("?", "'"+hardWarePrd+"'").replace("#", "'"+revision+"'"));
					LOG.info("Executing Query for CREATE_AERO_LOGICAL_VT:: "+sqlQuery);
					getJdbcTemplate().execute(sqlQuery.toString());
					
					LOG.info("Executing Query for CREATE_AERO_PART_VT:: "+PLMSearchQueries.CREATE_AERO_PART_VT.replace("AERO_LOGICAL", AERO_LOGICAL)
							 .replace("AERO_PART",AERO_PART));
					getJdbcTemplate().execute(PLMSearchQueries.CREATE_AERO_PART_VT.replace("AERO_LOGICAL", AERO_LOGICAL)
							 .replace("AERO_PART",AERO_PART));
				
					LOG.info("Final Query for Logical Features:: "+PLMSearchQueries.GET_FINAL_AERO_LOGICAL_FTR_DATA.replace("AERO_LOGICAL", AERO_LOGICAL)
							 .replace("AERO_PART",AERO_PART));
					logicaFeaturesList =  getJdbcTemplate().query(PLMSearchQueries.GET_FINAL_AERO_LOGICAL_FTR_DATA.replace("AERO_LOGICAL", AERO_LOGICAL)
							 .replace("AERO_PART",AERO_PART), new LogicalFeatureMapper());
					
					LOG.info("Query for Max Level count:: "+PLMSearchQueries.GET_MAX_LVL_LOGICAL_FTR_DATA.replace("AERO_LOGICAL", AERO_LOGICAL)
							 .replace("AERO_PART",AERO_PART));
					maxLvl = getJdbcTemplate().queryForInt(PLMSearchQueries.GET_MAX_LVL_LOGICAL_FTR_DATA.replace("AERO_LOGICAL", AERO_LOGICAL)
							 .replace("AERO_PART",AERO_PART));
					
					logicaFeatureMap.put("logicalFeaturesList", logicaFeaturesList);
					logicaFeatureMap.put("maxLvl", maxLvl);
			 }
					
			} catch (DataAccessException e) {
				PLMUtils.checkException(e.getMessage());
			}catch (Exception e) {
				PLMUtils.checkException(e.getMessage());
			}
			return logicaFeatureMap;
	
	}
	/**
	 * Row mapper for getting LogicalFeatureMapper
	 */
	private static final class LogicalFeatureMapper implements ParameterizedRowMapper<PLMAeroRptData>{
		public PLMAeroRptData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMAeroRptData data = new PLMAeroRptData();
			data.setLevel(rs.getInt("LVL"));
			data.setDisplayNm(PLMUtils.checkNullVal(rs.getString("DSP_NM"))+" "+PLMUtils.checkNullVal(rs.getString("TO_REVISION")));
			data.setChildName(PLMUtils.checkNullVal(rs.getString("CHILD_NAME"))+" "+PLMUtils.checkNullVal(rs.getString("TO_REVISION")));
			data.setType(PLMUtils.checkNullVal(rs.getString("TO_TYPE")));
			data.setDisplayText(PLMUtils.checkNullVal(rs.getString("DSP_TEXT")));
			data.setOwner(PLMUtils.checkNullVal(rs.getString("OWNER")));
			data.setDesignResponse(PLMUtils.checkNullVal(rs.getString("DESIGN_RESPONSIBILITY")));
			data.setState(PLMUtils.checkNullVal(rs.getString("STATE")));
			data.setFindNum(PLMUtils.checkNullVal(rs.getString("FIND_NUM")));
			data.setQuantity(PLMUtils.checkNullVal(rs.getString("QUANTITY")));
			data.setReferenceDesign(PLMUtils.checkNullVal(rs.getString("REF_DESIGNATOR")));
			data.setComponentLoc(PLMUtils.checkNullVal(rs.getString("COMPONENT_LOCATION")));
			data.setUsage(PLMUtils.checkNullVal(rs.getString("USAGE")));
			data.setRuleType(PLMUtils.checkNullVal(rs.getString("RULE_TYPE")));
			return data;
		}
	}
	/**
	 * This method is used to get Configuration Features
	 * @param hardWarePrd,revision
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMAeroRptData> getConfigFeatureData(
			String hardWarePrd,String revision) throws PLMCommonException{
		LOG.info("Entering into  getConfigFeatureData");
		LOG.info("Entering into  HardWare Product Nm>> "+hardWarePrd+" Revision>> "+revision);
		List <PLMAeroRptData> configFeaturesList= new ArrayList <PLMAeroRptData>();
		List <PLMAeroRptData> finalConfigFeaturesList= new ArrayList <PLMAeroRptData>();
		 try {
			 if(!PLMUtils.isEmpty(hardWarePrd) && !PLMUtils.isEmpty(revision)){
					LOG.info("Query for Configuration Features:: "+PLMSearchQueries.GET_AERO_CONFIIG_FTR_DATA);
					configFeaturesList =  getSimpleJdbcTemplate().query(PLMSearchQueries.GET_AERO_CONFIIG_FTR_DATA, new ConfigFeatureMapper(),
							new Object[] {hardWarePrd,revision});
					if(configFeaturesList.size()>0){
						  PLMAeroRptData tempData = new PLMAeroRptData();
						  tempData.setLevel(1);
						  tempData.setConfDisplyNmRev(configFeaturesList.get(0).getHardWrNmRev());
						  tempData.setConfName(configFeaturesList.get(0).getHardWrName());
						  tempData.setConfType(configFeaturesList.get(0).getHardWrType());
						  tempData.setConfState(configFeaturesList.get(0).getHardWrState());
						  tempData.setConfOwner(configFeaturesList.get(0).getHardWrOwner());
						  tempData.setConfDesignResp(configFeaturesList.get(0).getHardWrDesgnRes());
						  finalConfigFeaturesList.add(tempData);
						  
						  String confFeatureName="";
						  
						  for(int i=0;i<configFeaturesList.size();i++){
							  
							  tempData = new PLMAeroRptData();
							  if(!confFeatureName.equals(configFeaturesList.get(i).getConfFeatureName())){
							  tempData.setLevel(2);
							  tempData.setConfDisplyNmRev(configFeaturesList.get(i).getConfFeatureRev());
							  tempData.setConfName(configFeaturesList.get(i).getConfFeatureName());
							  tempData.setConfType(configFeaturesList.get(i).getConfFeatureType());
							  tempData.setConfState(configFeaturesList.get(i).getConfFeatureState());
							  tempData.setConfdisplayTxt(configFeaturesList.get(i).getConfFeatureDispTxt());
							  tempData.setSeqNo(configFeaturesList.get(i).getConfFeatureSeqNo());
							  tempData.setDefaultSel(configFeaturesList.get(i).getConfFeatureDefaultSel());
							  tempData.setSingleMultiple(configFeaturesList.get(i).getConfFeatureSingleMultiple());
							  tempData.setMustMay(configFeaturesList.get(i).getConfFeatureMustMay());
							  tempData.setKeyinType(configFeaturesList.get(i).getConfFeaturekeyinType());
							  tempData.setConfRuleType(configFeaturesList.get(i).getConfFeatureRuleType());
							  tempData.setListPrice(configFeaturesList.get(i).getConfFeaturelistPrice());
							  tempData.setMinQty(configFeaturesList.get(i).getConfFeatureMinQty());
							  tempData.setMaxQty(configFeaturesList.get(i).getConfFeatureMaxQty());
							  tempData.setConfOwner(configFeaturesList.get(i).getConfFeatureOwner());
							  finalConfigFeaturesList.add(tempData);
							  }
							  confFeatureName =configFeaturesList.get(i).getConfFeatureName();
							  
							  tempData = new PLMAeroRptData();
							  tempData.setLevel(3);
							  tempData.setConfDisplyNmRev(configFeaturesList.get(i).getConfOptionRev());
							  tempData.setConfName(configFeaturesList.get(i).getConfOptionName());
							  tempData.setConfType(configFeaturesList.get(i).getConfOptionType());
							  tempData.setConfState(configFeaturesList.get(i).getConfOptionState());
							  tempData.setConfdisplayTxt(configFeaturesList.get(i).getConfOptionDispTxt());
							  tempData.setSeqNo(configFeaturesList.get(i).getConfOptionSeqNo());
							  tempData.setDefaultSel(configFeaturesList.get(i).getConfOptionDefaultSel());
							  tempData.setSingleMultiple(configFeaturesList.get(i).getConfOptionSingleMultiple());
							  tempData.setConfRuleType(configFeaturesList.get(i).getConfOptionRuleType());
							  tempData.setListPrice(configFeaturesList.get(i).getConfFeaturelistPrice());
							  tempData.setMinQty(configFeaturesList.get(i).getConfOptionMinQty());
							  tempData.setMaxQty(configFeaturesList.get(i).getConfOptionMaxQty());
							  tempData.setConfOwner(configFeaturesList.get(i).getConfOptionOwner());
							  tempData.setConfDesignResp(configFeaturesList.get(i).getConfDesignResp());
							  finalConfigFeaturesList.add(tempData);

						  }
					}
					
			 }
					
			} catch (DataAccessException e) {
				PLMUtils.checkException(e.getMessage());
			}catch (Exception e) {
				PLMUtils.checkException(e.getMessage());
			}
			return finalConfigFeaturesList;
	
	}
	/**
	 * Row mapper for getting ConfigFeatureMapper
	 */
	private static final class ConfigFeatureMapper implements ParameterizedRowMapper<PLMAeroRptData>{
		public PLMAeroRptData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMAeroRptData data = new PLMAeroRptData();
			data.setHardWrNmRev(PLMUtils.checkNullVal(rs.getString("HW_NAME_REV")));
			data.setHardWrName(PLMUtils.checkNullVal(rs.getString("HW_NAME")));
			data.setHardWrType(PLMUtils.checkNullVal(rs.getString("HW_TYPE")));
			data.setHardWrState(PLMUtils.checkNullVal(rs.getString("HW_STATE")));
			data.setHardWrOwner(PLMUtils.checkNullVal(rs.getString("HW_OWNER")));
			data.setHardWrDesgnRes(PLMUtils.checkNullVal(rs.getString("HW_Design_Responsibility")));
			
			data.setConfFeatureRev(PLMUtils.checkNullVal(rs.getString("CNF_FEATURE_NAME_REV")));
			data.setConfFeatureName(PLMUtils.checkNullVal(rs.getString("CNF_FEATURE_NAME")));
			data.setConfFeatureType(PLMUtils.checkNullVal(rs.getString("CNF_FEATURE_TYPE")));
			data.setConfFeatureState(PLMUtils.checkNullVal(rs.getString("CNF_FEATURE_STATE")));
			data.setConfFeatureDispTxt(PLMUtils.checkNullVal(rs.getString("CNF_FEATURE_DISPLAY_TEXT")));
			data.setConfFeatureSeqNo(PLMUtils.checkNullVal(rs.getString("CNF_FEATURE_SEQ_ORDER")));
			data.setConfFeatureDefaultSel(PLMUtils.checkNullVal(rs.getString("CNF_FEATURE_DEFAULT_SEL")));
			data.setConfFeatureSingleMultiple(PLMUtils.checkNullVal(rs.getString("CNF_FEATURE_SEL_TYPE")));
			data.setConfFeatureMustMay(PLMUtils.checkNullVal(rs.getString("CNF_FEATURE_SEL_CRITERIA")));
			data.setConfFeaturekeyinType(PLMUtils.checkNullVal(rs.getString("CNF_FEATURE_KEY_IN_TYPE")));
			data.setConfFeatureRuleType(PLMUtils.checkNullVal(rs.getString("CNF_FEATURE_RULE_TYPE")));
			data.setConfFeaturelistPrice(PLMUtils.checkNullVal(rs.getString("CNF_FEATURE_LIST_PRICE")));
			data.setConfFeatureMinQty(PLMUtils.checkNullVal(rs.getString("CNF_FEATURE_MIN_QTY")));
			data.setConfFeatureMaxQty(PLMUtils.checkNullVal(rs.getString("CNF_FEATURE_MAX_QTY")));
			data.setConfFeatureOwner(PLMUtils.checkNullVal(rs.getString("CNF_FEATURE_OWNER")));
			
			data.setConfOptionRev(PLMUtils.checkNullVal(rs.getString("CNF_OPTION_NAME_REV")));
			data.setConfOptionName(PLMUtils.checkNullVal(rs.getString("CNF_OPTION_NAME")));
			data.setConfOptionType(PLMUtils.checkNullVal(rs.getString("CNF_OPTION_TYPE")));
			data.setConfOptionState(PLMUtils.checkNullVal(rs.getString("CNF_OPTION_STATE")));
			data.setConfOptionDispTxt(PLMUtils.checkNullVal(rs.getString("CNF_OPTION_DISPLAY_TEXT")));
			data.setConfOptionSeqNo(PLMUtils.checkNullVal(rs.getString("CNF_OPTION_SEQ_ORDER")));
			data.setConfOptionDefaultSel(PLMUtils.checkNullVal(rs.getString("CNF_OPTION_DEFAULT_SEL")));
			data.setConfOptionSingleMultiple(PLMUtils.checkNullVal(rs.getString("CNF_OPTION_SEL_TYPE")));
			data.setConfOptionRuleType(PLMUtils.checkNullVal(rs.getString("CNF_OPTION_RULE_TYPE")));
			data.setConfOptionlistPrice(PLMUtils.checkNullVal(rs.getString("CNF_OPTION_LIST_PRICE")));
			data.setConfOptionMinQty(PLMUtils.checkNullVal(rs.getString("CNF_OPTION_MIN_QTY")));
			data.setConfOptionMaxQty(PLMUtils.checkNullVal(rs.getString("CNF_OPTION_MAX_QTY")));
			data.setConfOptionOwner(PLMUtils.checkNullVal(rs.getString("CNF_OPTION_OWNER")));
			data.setConfDesignResp(PLMUtils.checkNullVal(rs.getString("CO_Design_Responsibility")));
			return data;
		}
	}

	/**
	 * @return PLMBoilerShipBomReportData objects.
	 */
	private static final class CompatibilityRulesMapper implements ParameterizedRowMapper<PLMCompatibilityRulesReportData> {
		public PLMCompatibilityRulesReportData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMCompatibilityRulesReportData tempData =new PLMCompatibilityRulesReportData();
			tempData.setLevel(1);
			tempData.setName(PLMUtils.checkNullVal(rs.getString("NAME")));
			tempData.setLeftExpression(PLMUtils.checkNullVal(rs.getString("LEFT_EXPRESSION")));
			tempData.setCompatibility(PLMUtils.checkNullVal(rs.getString("COMPARISON_OPERATOR")));
			tempData.setRightExpression(PLMUtils.checkNullVal(rs.getString("RIGHT_EXPRESSION")));
			tempData.setErrorMessage(PLMUtils.checkNullVal(rs.getString("ERROR_MSG")));
			tempData.setMandatory(PLMUtils.checkNullVal(rs.getString("MANDATORY_RULE")));
			tempData.setDesignResp(PLMUtils.checkNullVal(rs.getString("DESIGN_RESPONSIBILITY")));
			tempData.setOwner(PLMUtils.checkNullVal(rs.getString("OWNER")));
		
			return tempData;
		}
	}
	/**
	 * @return PLMBoilerShipBomReportData objects.
	 */
	private static final class MarketingPrefMapper implements ParameterizedRowMapper<PLMCompatibilityRulesReportData> {
		public PLMCompatibilityRulesReportData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMCompatibilityRulesReportData tempData =new PLMCompatibilityRulesReportData();
			tempData.setLevel(1);
			tempData.setName(PLMUtils.checkNullVal(rs.getString("NAME")));
			tempData.setMandatory(PLMUtils.checkNullVal(rs.getString("MANDATORY_RULE")));
			tempData.setInherited(PLMUtils.checkNullVal(rs.getString("INHERITED")));
			tempData.setDesignResp(PLMUtils.checkNullVal(rs.getString("DESIGN_RESPONSIBILITY")));
			tempData.setOwner(PLMUtils.checkNullVal(rs.getString("OWNER_SSO")));
			
			return tempData;
		}
	}
	
	/**
	 * This method is used to generate online report based on select criteria
	 * @param selShipBomHardwareProdName
	 * @param selShipBomRevName
	 * @return
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMCompatibilityRulesReportData> generateCompatibilityRulesAppReport(
			String selShipBomHardwareProdName, String selShipBomRevName)
			throws PLMCommonException {

		LOG.info("Entering into  generateCompatibilityRulesAppReport");
		LOG.info("Entering into  selShipBomHardwareProdName"+selShipBomHardwareProdName+" selShipBomRevName"+selShipBomRevName);
		List <PLMCompatibilityRulesReportData> fmiappReportList= new ArrayList <PLMCompatibilityRulesReportData>();
		StringBuffer sqlQuery = new StringBuffer();
		boolean whereFlag=false;
		 try {
				
				sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_COMPATIBILITY_RULES_REPORT);
				if(!PLMUtils.isEmpty(selShipBomHardwareProdName)){
					sqlQuery.append(" where HW_PRD.NAME = '"+selShipBomHardwareProdName+"'"); 
					whereFlag=true;
				}
				if(whereFlag==true && !PLMUtils.isEmpty(selShipBomRevName)){
					sqlQuery.append(" and HW_PRD.REVISION = '");
					sqlQuery.append(selShipBomRevName);
					sqlQuery.append("'");
				}
				
				LOG.info("Final Query for Aero Compatibility Rules report:: "+sqlQuery);
				fmiappReportList =  getJdbcTemplate().query(sqlQuery.toString(), new CompatibilityRulesMapper());	
				LOG.info("Aero Compatibility Rules Record Count:: "+fmiappReportList.size());
					
			} catch (DataAccessException e) {
				PLMUtils.checkException(e.getMessage());
			}catch (Exception e) {
				PLMUtils.checkException(e.getMessage());
			}
			return fmiappReportList;
	
	
	}
	/**
	 * This method is used to generate online report based on select criteria
	 * @param selShipBomHardwareProdName
	 * @param selShipBomRevName
	 * @return
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMCompatibilityRulesReportData> generateMarketingPrefRptAppReport(
			String selShipBomHardwareProdName, String selShipBomRevName)
			throws PLMCommonException {

		LOG.info("Entering into  generateMarketingPrefRptAppReport");
		LOG.info("Entering into  selShipBomHardwareProdName"+selShipBomHardwareProdName+" selShipBomRevName"+selShipBomRevName);
		List <PLMCompatibilityRulesReportData> fmiappReportList= new ArrayList <PLMCompatibilityRulesReportData>();
		StringBuffer sqlQuery = new StringBuffer();
		boolean whereFlag=false;
		 try {
				
				sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_MARKETING_PREF_REPORT);
				if(!PLMUtils.isEmpty(selShipBomHardwareProdName)){
					sqlQuery.append(" where HW_PRD.NAME = '"+selShipBomHardwareProdName+"'"); 
					whereFlag=true;
				}
				if(whereFlag==true && !PLMUtils.isEmpty(selShipBomRevName)){
					sqlQuery.append(" and HW_PRD.REVISION = '");
					sqlQuery.append(selShipBomRevName);
					sqlQuery.append("'");
				}
				
				LOG.info("Final Query for Aero Marketing Preferences report:: "+sqlQuery);
				fmiappReportList =  getJdbcTemplate().query(sqlQuery.toString(), new MarketingPrefMapper());	
				LOG.info("Aero Marketing Preferences report Record Count:: "+fmiappReportList.size());
					
			} catch (DataAccessException e) {
				PLMUtils.checkException(e.getMessage());
			}catch (Exception e) {
				PLMUtils.checkException(e.getMessage());
			}
			return fmiappReportList;
	
	}
}
