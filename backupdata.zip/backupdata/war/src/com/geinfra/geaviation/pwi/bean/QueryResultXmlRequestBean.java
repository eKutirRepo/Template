package com.geinfra.geaviation.pwi.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.mail.MessagingException;
import javax.xml.bind.JAXBException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.richfaces.component.UIMenuItem;

import com.geinfra.geaviation.pwi.bean.QueryResultViewBean.Data;
import com.geinfra.geaviation.pwi.bean.util.BeanUtil;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.QueryAccessException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.context.PWiContext;
import com.geinfra.geaviation.pwi.json.JsonUtil;
import com.geinfra.geaviation.pwi.model.PWiObjectTypeVO;
import com.geinfra.geaviation.pwi.model.PWiQueryExctnEventVO;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.model.PWiQueryNoXmlVO;
import com.geinfra.geaviation.pwi.model.PWiQueryObjectTypeVO;
import com.geinfra.geaviation.pwi.model.PWiQueryVO;
import com.geinfra.geaviation.pwi.model.QueryResult;
import com.geinfra.geaviation.pwi.model.QueryResult.ResultStatus;
import com.geinfra.geaviation.pwi.model.QueryResultColumn;
import com.geinfra.geaviation.pwi.model.RptTypeRelationVo;
import com.geinfra.geaviation.pwi.model.TemplateVO;
import com.geinfra.geaviation.pwi.service.CustomQueryService;
import com.geinfra.geaviation.pwi.service.HistoryService;
import com.geinfra.geaviation.pwi.service.ObjectTypeService;
import com.geinfra.geaviation.pwi.service.QueriesService;
import com.geinfra.geaviation.pwi.service.QueryGroupService;
import com.geinfra.geaviation.pwi.service.QueryObjectTypeService;
import com.geinfra.geaviation.pwi.service.QuerySubmissionService;
import com.geinfra.geaviation.pwi.service.QuerySubmissionService.WriteResult;
import com.geinfra.geaviation.pwi.service.QuerySubmissionService.WriteResult.WriteResultStatus;
import com.geinfra.geaviation.pwi.service.vo.ExecutedFrom;
import com.geinfra.geaviation.pwi.service.vo.OutputType;
import com.geinfra.geaviation.pwi.service.vo.QuerySubmissionResult;
import com.geinfra.geaviation.pwi.util.BookmarkableLinkUtil;
import com.geinfra.geaviation.pwi.util.LoadProps;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.util.PWiMailMessage;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;
import com.geinfra.geaviation.pwi.xml.QueryXmlReader;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.query.util.QueryJaxbUtil;

/**
 * Project : Product Lifecycle Management Inteligence Date Written : May 21,
 * 2010 Security : GE Confidential Restrictions : GE PROPRIETARY INFORMATION,
 * FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Request-scoped backing bean for the query results page.
 * 
 * Revision Log May 8, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class QueryResultXmlRequestBean extends BaseBean {
	private static final Logger LOGGER = Logger
			.getLogger(QueryResultXmlRequestBean.class);

	// Admin security role
	private static final String ADMIN_ROLE = "PWi_Admin";
	private static final String SESSION_ATTRIBUTE_SUBMISSION_CNTR_BEAN = "submissionCntrlBean";
	private static final String SESSION_ATTRIBUTE_SESSION_BEAN_CACHE = "pwi.QueryResultBean";
	// Dependency-injected service
	private QueriesService queriesService;
	private QuerySubmissionService querySubmissionService;
	private HistoryService historyService;
	private CustomQueryService customQueryService;
	private ObjectTypeService objectTypeService;
	private QueryObjectTypeService queryObjectTypeService;
	private QueryGroupService queryGroupService;

	// Conversation ID
	private String conversationId;

	// The cache ID for this request's view bean
	private Integer cacheId;

	// Store page state for a particular request intended to be cached so it can
	// be restored to process any request originating from this request
	private QueryResultViewBean viewBean = new QueryResultViewBean();

	// Page properties
	private String queryLinkObjectValue;
	private String queryLinkObjectType;
	private Integer queryLinkQueryId;

	private String queriesJson;
	private String objectTypesJson;
	private String queryObjectTypesJson;
	// TODO AF&pH 05.2012: private String queryResultJson;

	private QueryBuilderBean queryBuilderBean;
	private boolean genNewRptTemp = true;

	public void setQueryGroupService(QueryGroupService queryGroupService) {
		this.queryGroupService = queryGroupService;
	}

	/**
	 * Stores the most recently used states of query result page requests.
	 * 
	 * @author NH8OFWT
	 */
	public static class QueryResultViewBeanCache {
		Map<Integer, QueryResultViewBean> queryResultsMap = new HashMap<Integer, QueryResultViewBean>();
		List<Integer> cacheIds = new LinkedList<Integer>();
		int cacheSize = 1;
		int nextCacheId;

		public void clear() {
			queryResultsMap = new HashMap<Integer, QueryResultViewBean>();
			cacheIds = new LinkedList<Integer>();
			cacheSize = 1;
			nextCacheId = 0;
		}

		public Integer put(QueryResultViewBean queryResultViewBean) {
			// Get next cache ID
			Integer cacheId = Integer.valueOf(nextCacheId++);

			// Insert as most recently used
			queryResultsMap.put(cacheId, queryResultViewBean);

			// Add to front (most recently used)
			cacheIds.add(0, cacheId);

			// If cache size is exceeded, remove last (least recently used)
			while (cacheIds.size() > cacheSize) {
				Integer eventId = cacheIds.remove(cacheIds.size() - 1);
				queryResultsMap.remove(eventId);
			}

			return cacheId;
		}

		public QueryResultViewBean get(Integer cacheId) {
			// Get bean
			QueryResultViewBean bean = queryResultsMap.get(cacheId);

			// If not found, return null
			if (bean == null) {
				return null;
			}

			// Otherwise, promote to front (most recently used)
			cacheIds.remove(cacheId);
			cacheIds.add(0, cacheId);
			return bean;
		}
	}

	public void setQueriesService(QueriesService queriesService) {
		this.queriesService = queriesService;
	}
	
	public QueriesService getQueriesService() {
		return queriesService;
	}

	public void setQueryObjectTypeService(
			QueryObjectTypeService queryObjectTypeService) {
		this.queryObjectTypeService = queryObjectTypeService;
	}

	public void setQuerySubmissionService(
			QuerySubmissionService querySubmissionService) {
		this.querySubmissionService = querySubmissionService;
	}

	public void setHistoryService(HistoryService historyService) {
		this.historyService = historyService;
	}

	public void setCustomQueryService(CustomQueryService customQueryService) {
		this.customQueryService = customQueryService;
	}

	public void setObjectTypeService(ObjectTypeService objectTypeService) {
		this.objectTypeService = objectTypeService;
	}

	public boolean isGenNewRptTemp() {
		return genNewRptTemp;
	}

	public void setGenNewRptTemp(boolean genNewRptTemp) {
		this.genNewRptTemp = genNewRptTemp;
	}

	/**
	 * Ensure view bean is properly initialized based on the request (and then
	 * cached).
	 */
	@PostConstruct
	public void postConstruct() {
		try {
			String prevConversationId = FacesContext.getCurrentInstance()
					.getExternalContext().getRequestParameterMap()
					.get("conversationId");
			if (prevConversationId != null) {
				// Postback
				// Parse cache ID and event ID from conversation ID
				String[] parsed = StringUtils.split("000.000", '.');
				Integer cachedId = Integer.valueOf(parsed[0]);
				Integer eventId = Integer.valueOf(parsed[1]);
				// Get session bean from cache
				QueryResultViewBean cachedViewBean = BeanUtil.getInstance()
						.getConversationBeanCache().get(cachedId);
				if (cachedViewBean != null) {
					// Copy cached view bean for use in new request
					viewBean = new QueryResultViewBean(cachedViewBean);
				}
			}
			/*
			 * } else { // Session expired or user has more query result pages
			 * than // we allow storing in cache, re-run query and re-initialize
			 * // from scratch QuerySubmissionResult querySubmissionResult =
			 * querySubmissionService .submitQueryFromHistory(eventId,
			 * getSsoId(), ExecutedFrom.EXPIRED_RESULT_VIEW); // correct
			 * executedFrom? // Get query to pass to init PWiQueryExctnEventVO
			 * event = historyService
			 * .getExecutionEventById(querySubmissionResult
			 * .getExecutedQueryId()); PWiQueryVO query =
			 * queriesService.getQueryById(event .getQueryId()); // Create new
			 * view bean viewBean = new QueryResultViewBean(); // Initialize
			 * init(query, querySubmissionResult, true); } } else {
			 */
			QuerySubmissionControllerBean bean = BeanUtil.getInstance()
					.getQuerySubmissionControllerBean();
			if (bean != null && bean.getQuery() != null
					&& bean.getQuerySubmissionResult() != null) {
				// Create new session bean
				viewBean = new QueryResultViewBean();

				// Initial request
				init(bean.getQuery(), bean.getQuerySubmissionResult(), false);
				genNewRptTemp = queryBuilderBean.getRptTypeRelSetBean()
						.getRpttyperelationbean().isGenNewRptTemp();
				cacheViewBean();
				/*
				 * } else { // Note: Throwing RuntimeException because
				 * PostConstruct // annotation doesn't support checked
				 * exceptions throw new RuntimeException(
				 * "Invalid request received for query result bean."); }
				 */
			}
			/*QuerySubmissionControllerBean subbean = (QuerySubmissionControllerBean) FacesContext.getCurrentInstance().getExternalContext()
			.getSessionMap().get(SESSION_ATTRIBUTE_SUBMISSION_CNTR_BEAN);
			if (subbean != null && subbean.getQuery() != null
					&& subbean.getQuerySubmissionResult() != null) {
				// Create new session bean
				viewBean = new QueryResultViewBean();

				// Initial request
				init(subbean.getQuery(), subbean.getQuerySubmissionResult(), false);
				genNewRptTemp = queryBuilderBean.getRptTypeRelSetBean()
						.getRpttyperelationbean().isGenNewRptTemp();
				cacheViewBean();
				
				 * } else { // Note: Throwing RuntimeException because
				 * PostConstruct // annotation doesn't support checked
				 * exceptions throw new RuntimeException(
				 * "Invalid request received for query result bean."); }
				 
			}*/
		} catch (QueryAccessException e) {
			// Throw RuntimeException because PostConstruct annotation doesn't
			// support checked exceptions
			throw new RuntimeException("Error post-constructing", e);
		} catch (PWiException e) {
			// Throw RuntimeException because PostConstruct annotation doesn't
			// support checked exceptions
			throw new RuntimeException("Error post-constructing", e);
		}
	}

	/**
	 * ID containing information necessary to service a postback
	 * 
	 * This is necessary because the query result page is designed to be able to
	 * have many different instances of itself being viewed by a user at any
	 * given time (different query results, in multiple windows). This is a
	 * result of the query link functionality that will run a new query and
	 * display results in a new window. With multiple windows of the query
	 * result page are open, we need a way to distinguish the requests from each
	 * to know how to handle the request (for instance, which query results to
	 * reference).
	 * 
	 * This ID allows us to identify the cached state for each query result page
	 * that was requested as well as provides an event ID that allows us to
	 * rerun the query and re-initialize the page should the cached state have
	 * expired.
	 * 
	 * @return conversation.
	 */
	public String getConversationId() {
		if (conversationId == null) {
			conversationId = cacheId + "." + viewBean.getEventId();
		}
		return conversationId;
	}

	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}

	public void handleQueryFailure(QuerySubmissionResult querySubmissionResult) {
		ResultStatus resultStatus = querySubmissionResult.getQueryResult()
				.getResultStatus();
		if (resultStatus != ResultStatus.SUCCESS) {
			StringBuilder builder = new StringBuilder();
			if (resultStatus == ResultStatus.ERROR_TIMEOUT) {
				builder.append("The query you executed took longer to run than supported by online mode.");
				builder.append(" Please modify the query or run it in batch mode by selecting Batch from the Execution Mode dropdown at the bottom of the query builder.");
				handleFacesInfo(builder.toString());
			} else if (resultStatus == ResultStatus.ERROR_RESULT_SIZE) {
				builder.append("The query you executed returned more results than supported by online mode.");
				builder.append(" Please modify the query or run it in batch mode by selecting Batch from the Execution Mode dropdown at the bottom of the query builder.");
				handleFacesInfo(builder.toString());
			} else if (resultStatus == ResultStatus.ERROR_INVALID_EXEC_OUT) {
				builder.append("The execution mode and output type requested is no longer valid for the query.  Try clicking \"Modify Query\" to rebuild the query.");
				handleFacesInfo(builder.toString());
			} else {// resultStatus == ResultStatus.ERROR_MISC
				builder.append(PWiConstants.ERROR_COM_01);
				ExecutedFrom executedFrom = querySubmissionResult
						.getExecutedFrom();
				if (executedFrom == ExecutedFrom.BOOKMARK_HISTORY) {
					builder.append(" This error occurred when trying to reexecute a query from Query History.");
					builder.append(" Note that if an administrator changed the design of a query,");
					builder.append(" it is possible that reexecution of a query");
					builder.append(" that was run before the change will no longer work.");
					builder.append(" Please click \"Modify Query\" to rebuild the query,");
					builder.append(" and then resave it as a new Favorite if you would like.");
				} else if (executedFrom == ExecutedFrom.BOOKMARK_FAVORITE) {
					builder.append(" This error occurred when trying to reexecute a query from a Favorite.");
					builder.append(" Note that if an administrator changed the design of a query,");
					builder.append(" it is possible that reexecution of a favorite");
					builder.append(" that was saved before the change will no longer work.");
					builder.append(" Please click \"Modify Query\" to rebuild the query,");
					builder.append(" and then resave it as a new Favorite if you would like.");
				} else {
					// Do nothing, leave it at the generic message
				}
				handleFacesError(builder.toString());
			}

			viewBean.setDisplayingWeb(false);
			viewBean.setDisplayingDownload(false);
			viewBean.setAutoDownload(false);
		}
	}

	/**
	 * Initializes this bean to be able to display the query results page.
	 * 
	 * @param query
	 *            Query that was run
	 * @param querySubmissionResult
	 *            the results
	 * @param postback
	 * @throws PWiException
	 * @throws QueryAccessException
	 */
	public void init(PWiQueryVO query,
			QuerySubmissionResult querySubmissionResult, boolean postback)
			throws PWiException, QueryAccessException {
		viewBean.setEventId(querySubmissionResult.getExecutedQueryId());

		viewBean.setQuery(query);
		viewBean.setQuerySubmissionResult(querySubmissionResult);

		// Set flag for determining whether to display results for web
		// output type and whether to auto download
		if (OutputType.WEB.getId().equals(
				querySubmissionResult.getQueryUserOptions().getOutputTypeId())) {
			viewBean.setDisplayingWeb(true);
			viewBean.setDisplayingDownload(false);
			viewBean.setAutoDownload(false);
		} else {
			viewBean.setDisplayingWeb(false);
			viewBean.setDisplayingDownload(true);

			boolean autoDownload = true;
			if (postback) {
				// Auto download should only be enabled from an initial request
				// or an action method.
				autoDownload = false;
			}
			viewBean.setAutoDownload(autoDownload);
		}

		// If query failed, generate faces error to display
		handleQueryFailure(querySubmissionResult);

		// Store submission output type and template ID as those being
		// displayed
		viewBean.setDisplayingOutputType(querySubmissionResult
				.getQueryUserOptions().getOutputTypeId());
		viewBean.setDisplayingTemplateId(querySubmissionResult
				.getQueryUserOptions().getTemplateId());

		// Get query definition
		QueryType queryType = new QueryXmlReader().translateXml(query
				.getQryXml());

		// Build search parameter string
		viewBean.setShowParameters(QueryJaxbUtil
				.getInstance()
				.buildParamString(
						querySubmissionResult.getQueryUserOptions().getSearch(),
						queryType));

		// Set the results into the view fields
		createResultMesssage(querySubmissionResult.getQueryResult());

		// Default favorite name to query name
		viewBean.setFavoriteName(query.getQryNm());

		// Initialize query links
		List<String> objectTypeNames = getObjectTypeNamesForColumns(
				querySubmissionResult, queryType);

		// Initialize tab row list
		// Note: Originally, since menu IDs and column labels exist per
		// column, they were stored in a caption object and then referenced
		// using the "columns" tag. However, referencing "columns" tag
		// properties outside of the "columns" tag facet resulted in poor
		// performance. So instead, the menu-specific data is now stored in
		// each data cell. (A trade-off of space for performance.)
		viewBean.setTabRowList(new ArrayList<List<Data>>());
		for (List<String> row : querySubmissionResult.getQueryResult()
				.getData()) {
			List<Data> newRow = new ArrayList<Data>();
			for (int index = 0; index < row.size(); index++) {
				newRow.add(new Data(row.get(index), objectTypeNames.get(index),
						querySubmissionResult.getQueryResult().getColumns()
								.get(index).getLabel()));
			}

			viewBean.getTabRowList().add(newRow);
		}
		// Initialize output options
		initOutputOptions(query);

		// Initialize number of results to display
		viewBean.setNumRowsToDisplay("50");

		// Initialize bookmarkable link
		viewBean.setExecuteLink(BookmarkableLinkUtil.getInstance()
				.getExecuteHistoryLink(
						querySubmissionResult.getExecutedQueryId()));
		viewBean.setModifyLink(BookmarkableLinkUtil.getInstance()
				.getModifyHistoryLink(
						querySubmissionResult.getExecutedQueryId()));
		// Write file if auto download is set
		if (viewBean.isAutoDownload()) {
			WriteResult writeResult = querySubmissionService.writeQueryResults(
					viewBean.getQuerySubmissionResult().getQueryResult()
							.getColumns(), viewBean.getQuerySubmissionResult()
							.getQueryResult().getData(), viewBean
							.getQuerySubmissionResult(), viewBean.getQuery()
							.getQryNm(), viewBean.getDisplayingOutputType(),
					viewBean.getDisplayingTemplateId(),viewBean);

			if (writeResult.getWriteStatus() == WriteResultStatus.XLSX_SUBSTITUTION) {
				handleFacesInfo(PWiConstants.INFO_XLSX_SUBSTITUTION);
			}

			viewBean.setQueryResultsFile(writeResult.getFile());
		}

		// Ensure filter is cleared
		viewBean.setFilterString(null);
		viewBean.setFilteredResults(null);
	}

	private void initOutputOptions(PWiQueryVO query) throws PWiException,
			QueryAccessException {
		// Get output options for query
		/*
		 * ExecutionOutputModelConfig modelConfig = querySubmissionService
		 * .getExecutionOutputModelConfig(query.getQrySeqId(), null);
		 * 
		 * ExecutionOutputViewConfig viewConfig = new ExecutionOutputViewConfig(
		 * modelConfig);
		 */
		List<SelectItem> lsoutPtTyp = new ArrayList<SelectItem>();
		lsoutPtTyp.add(new SelectItem("online", "Online"));
		viewBean.setOutputTypeOptions(lsoutPtTyp);
		viewBean.setOutputOptionId("online");
		Map<String, OutputType> outputTypeIdMap = new HashMap<String, OutputType>();
		outputTypeIdMap.put("web", OutputType.WEB);

		viewBean.setOutputTypeIdMap(outputTypeIdMap);
		viewBean.setTemplateIdMap(new HashMap<String, TemplateVO>());
	}

	private List<String> getObjectTypeNamesForColumns(
			QuerySubmissionResult querySubmissionResult, QueryType queryType)
			throws PWiException {
		// Get query link object type for each column ID
		Map<String, String> objectTypeNamesByColumnId = QueryJaxbUtil
				.getInstance().getQueryLinkObjectTypeNamesForColumnIds(
						queryType, objectTypeService.getAllPWiObjectTypes());

		// specify object type associated with each column
		List<String> objectTypeNames = new ArrayList<String>();
		for (QueryResultColumn column : querySubmissionResult.getQueryResult()
				.getColumns()) {
			// If object type defined for column, look into adding a menu
			String objectTypeName = objectTypeNamesByColumnId.get(column
					.getId().toUpperCase(Locale.US));
			objectTypeNames.add(objectTypeName);
		}
		return objectTypeNames;
	}

	private void createResultMesssage(QueryResult resultSetData)
			throws PWiException {
		if (resultSetData != null) {
			// Determine result message
			StringBuilder resultMessageBuilder = new StringBuilder();
			// Include error message if exists
			if (StringUtils.isNotBlank(resultSetData.getErrorMessage())) {
				resultMessageBuilder.append(resultSetData.getErrorMessage()
						+ "\n");
			}
			// Include SQL if exists and user is admin
			if (StringUtils.isNotBlank(resultSetData.getSql())
					&& UserInfoPortalUtil.getInstance()
							.isUserInRole(ADMIN_ROLE)) {
				resultMessageBuilder.append("Query string: "
						+ resultSetData.getSql());
			}

			viewBean.setResultMessage(resultMessageBuilder.toString());
		}
	}

	/**
	 * Action that responds to AJAX request fired on page load of result page to
	 * download the results of a query.
	 * 
	 * @return a4j command status.
	 * @throws PWiException
	 */
	public String actionDownloadResults() throws PWiException {
		// Clear auto download so any subsequent loads of the result page
		// don't trigger auto download
		viewBean.setAutoDownload(false);

		// Download results
		querySubmissionService.downloadResults(viewBean.getQueryResultsFile());

		return "";
	}

	/**
	 * Filter the results based on a filter string from the user.
	 * 
	 * @return JSF navigation string
	 */
	public String actionFilterResults() {
		// Create filtered result list and add all rows that match search
		// criteria
		List<List<Data>> filteredResults = new ArrayList<List<Data>>();
		String filterString = viewBean.getFilterString();
		for (List<Data> row : viewBean.getTabRowList()) {
			for (Data data : row) {

				if (data.getData().toUpperCase(Locale.getDefault()).contains(// Added
																				// Locale
																				// on
																				// 31-Oct-2014
																				// as
																				// per
																				// Nimble
																				// report
						filterString.toUpperCase(Locale.getDefault()))) {
					// Match found, so include row
					filteredResults.add(row);

					// Break to next row
					break;
				}
			}
		}
		// Add filtered row to view bean to make filtering official
		viewBean.setFilteredResults(filteredResults);

		// Return to same page
		return null;
	}

	public String actionClearFilter() {
		// Simply set filtered results to null to clear the filter
		viewBean.setFilteredResults(null);
		viewBean.setFilterString(null);

		// Return to same page
		return null;
	}

	/**
	 * Action listener called when a query link menu item is selected which will
	 * extract the object type and query ID associated with the clicked menu
	 * item.
	 * 
	 * @param actionEvent
	 */
	public void actionListenerExecuteQueryLink(ActionEvent actionEvent) {
		Object source = actionEvent.getSource();
		if (source instanceof UIMenuItem) {
			UIMenuItem item = (UIMenuItem) source;
			Object dataObject = item.getData();
			if (dataObject instanceof String[]) {
				String[] data = (String[]) dataObject;
				queryLinkObjectType = data[0];
				queryLinkQueryId = Integer.valueOf(data[1]);
			}
		}
	}

	public String actionExecuteQueryLink() throws PWiException,
			QueryAccessException {
		// Get query
		PWiQueryVO query = queriesService.getQueryById(queryLinkQueryId);

		// Submit query
		QuerySubmissionResult querySubmissionResult = querySubmissionService
				.submitObjectTypeQuery(query, queryLinkObjectType,
						queryLinkObjectValue, getSsoId(),
						ExecutedFrom.QUERY_LINK, OutputType.WEB);

		// Create new session bean
		viewBean = new QueryResultViewBean();

		// Initial request
		init(query, querySubmissionResult, false);

		// Cache view bean
		cacheViewBean();

		// Process result
		return PWiConstants.NAV_QUERY_RESULT;
	}

	private void cacheViewBean() {
		// Note: Except when auto download is true because that means the
		// request is from an AJAX request that is going to be redirected
		// (to download the file) and because of the redirect the components
		// on the page can't get the updated conversationId, so we need to
		// leave the cache alone.
		String autoDownload = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap()
				.get("autoDownload");
		if (autoDownload == null) {
			com.geinfra.geaviation.pwi.bean.QueryResultRequestBean.QueryResultViewBeanCache cache = BeanUtil
					.getInstance().getConversationBeanCache();
			cacheId = cache.put(viewBean);
		}
	}

	/**
	 * Handles a request for the query builder page from the results screen.
	 * Will preserve any existing search criteria or selected columns.
	 * 
	 * @return JSF navigation string
	 * @throws PWiException
	 * @throws JAXBException
	 * @throws QueryAccessException
	 */
	public String actionQueryBuilderFromResultsScreen() throws PWiException,
			JAXBException, QueryAccessException {
		// Initialize query builder bean
		QueryBuilderBean qryBldrBean = (QueryBuilderBean) FacesContext
				.getCurrentInstance()
				.getApplication()
				.getELResolver()
				.getValue(FacesContext.getCurrentInstance().getELContext(),
						null, "queryBuilderBean");
		qryBldrBean.init(viewBean.getQuery().getQrySeqId(), viewBean
				.getQuerySubmissionResult().getQueryUserOptions());

		return PWiConstants.NAV_QUERY_BUILDER;
	}

	/**
	 * Saves the query that the user is viewing the results for as a favorite.
	 * 
	 * @return JSF navigation string
	 * @throws PWiException
	 * @throws QueryAccessException
	 */
	public String actionSaveAsFavorite() throws PWiException,
			QueryAccessException {
		if (StringUtils.isBlank(viewBean.getFavoriteName())) {
			handleFacesError(PWiConstants.ERROR_COM_14,
					FacesContext.getCurrentInstance());
		} else {
			if (customQueryService.createFavorite(viewBean.getQuery()
					.getQrySeqId(), viewBean.getFavoriteName(), viewBean
					.getQuerySubmissionResult().getQueryUserOptions()) > 0) {
				handleFacesInfo(
						PWiConstants.INFO_FAVORITE_ADDED.replace("#", "'"
								+ viewBean.getFavoriteName() + "'"),
						FacesContext.getCurrentInstance());
			} else {
				handleFacesError(PWiConstants.ERROR_COM_01);
				LOGGER.error("Service tier failed to create favorite.");
			}
		}
		return "";
	}

	public String actionSaveUpdateTemplateQuery() throws PWiException {
		if (queryBuilderBean.getRptTypeRelSetBean().getRpttyperelationbean()
				.isGenNewRptTemp()) {
			actionSaveTemplateQuery();
		} else {
			actionUpdateRptTemplate();
		}
		// queryBuilderBean.getRptTypeRelSetBean().getRpttyperelationbean().prevTabFromTab1();
		return PWiConstants.NAV_QUERY_LIST_DRAFT_QUERIES;
	}

	public String actionSaveTemplateQuery() throws PWiException {
		try {
			boolean popular = false;
			boolean active = false;
			boolean exportControlled = false;
			boolean geOnly = false;
			String queryFlag = "D";
			List<Integer> slctdObjTyps = new ArrayList<Integer>();
			String queryName = viewBean.getQuery().getQryNm();
			String queryInfo = viewBean.getQuery().getQryDesc();
			String queryXml = viewBean.getQuery().getQryXml();
			String qryKeyWrdTxt = viewBean.getQuery().getQryDesc();
			// Check for validation errors
			boolean valid = queriesService.validateQuery(queryName, queryInfo,
					queryXml, qryKeyWrdTxt);
			if (queriesService.checkQueryName(queryName) > 0) {
				handleFacesError(PWiConstants.ERROR_DUPLICATE_NAME);
				valid = false;
			}
			if (valid) {
				List<PWiQueryGroupVO> usrQueryGroupList = new ArrayList<PWiQueryGroupVO>();
				usrQueryGroupList = (List<PWiQueryGroupVO>) queryGroupService
						.getUserQueryGroups(getSsoId());
				// Persist new query
				int saveCount = queriesService.createNewQuery(queryName,
						queryInfo, slctdObjTyps, qryKeyWrdTxt, queryXml,
						usrQueryGroupList, getSsoId(), exportControlled,
						geOnly, popular, active,null, queryFlag);
				if (saveCount > 0) {
					// sendSuccessMail(viewBean.getQuery().getQryNm(),getSsoId());
					handleFacesInfo("Query " + queryName
							+ " created successfully.");

				}

			}
		} catch (Exception ex) {
			throw new PWiException(
					"queriesService instance was not initiated.." + ex);
		} finally {
			queryBuilderBean.getRptTypeRelSetBean().setTableTypeMap(
					new HashMap<String, Map<String, RptTypeRelationVo>>());
			FacesContext
			.getCurrentInstance().getExternalContext().getSessionMap().put(
					SESSION_ATTRIBUTE_SESSION_BEAN_CACHE,null);
		}
		return null;
	}

	public String actionUpdateRptTemplate() throws PWiException {
		try {
			boolean popular = false;
			boolean active = false;
			boolean exportControlled = false;
			boolean geOnly = false;
			String queryName = viewBean.getQuery().getQryNm();
			String queryInfo = viewBean.getQuery().getQryDesc();
			String queryXml = viewBean.getQuery().getQryXml();
			String qryKeyWrdTxt = viewBean.getQuery().getQryDesc();
			int queryId = queryBuilderBean.getRptTypeRelSetBean()
					.getRpttyperelationbean().getRptTempQuryId();

			List<Integer> slctdObjTyps = new ArrayList<Integer>();
			// Check for validation errors
			boolean valid = queriesService.validateQuery(queryName, queryInfo,
					queryXml, qryKeyWrdTxt);
			if (queriesService.checkQueryNameForEdit(queryName, queryId) > 0) {
				handleFacesError(PWiConstants.ERROR_DUPLICATE_NAME);
				valid = false;
			}
			if (!valid) {
				// Validation errors exist, return to same page to display
				// validation error messages
				return PWiConstants.NAV_ADMIN_QUERY_EDITOR;
			}

			String userId = getSsoId();

			// Initialize query
			PWiQueryVO query = new PWiQueryVO();
			query.setQrySeqId(queryId);
			query.setQryNm(queryName);
			query.setQryXml(queryXml);
			query.setQryDesc(queryInfo);
			query.setQryKywrdTxt(qryKeyWrdTxt);
			query.setExportControlled(exportControlled);
			query.setGeOnly(geOnly);
			query.setPopular(popular);
			query.setActive(active);
			List<PWiQueryGroupVO> usrQueryGroupList = new ArrayList<PWiQueryGroupVO>();
			usrQueryGroupList = (List<PWiQueryGroupVO>) queryGroupService
					.getUserQueryGroups(getSsoId());
			List<Integer> selectedGroupIds = new ArrayList<Integer>();
			for (PWiQueryGroupVO group : usrQueryGroupList) {
				selectedGroupIds.add(group.getQueryGroupId());
			}

			// Persist updated query
			queriesService.updateQuery(query, selectedGroupIds,
					slctdObjTyps, userId,null,null);

			handleFacesInfo("Query " + queryName + " updated successfully.");

		} catch (Exception ex) {
			throw new PWiException(
					"queriesService/templateService/selectedQueryGroupsList instance was not initiated.."
							+ ex);
		} finally {
			queryBuilderBean.getRptTypeRelSetBean().setTableTypeMap(
					new HashMap<String, Map<String, RptTypeRelationVo>>());
			FacesContext
			.getCurrentInstance().getExternalContext().getSessionMap().put(
					SESSION_ATTRIBUTE_SESSION_BEAN_CACHE,null);
		}

		return null;
	}

	private void sendSuccessMail(String queryName, String sso)
			throws MessagingException {
		// Get email postfix
		String emailPostfix = LoadProps.getInstance().loadProps(
				PWiConstants.MAIL_ADDRESS);

		// Create subject
		String subject = "Power Warehouse Intelligence - Subscription Results - "
				+ queryName;
		/*
		 * if (AppEnv.DEV.equals(mainExecution.getAppEnv())) { subject = subject
		 * + " (Dev)"; } else if (AppEnv.QA.equals(mainExecution.getAppEnv())) {
		 * subject = subject + " (QA)"; }
		 */
		String body = "";
		// Create body
		// String body = getSuccessEmailBody(parameters, diffMap,
		// mainExecution.getToolsUrl());

		// Create sender
		String sender = sso + emailPostfix;

		// Create recipients
		List<String> recipients = new ArrayList<String>();
		recipients.add(sender);
		/*
		 * if (mainExecution.isSendAdminAllEmail()) {
		 * recipients.addAll(mainExecution.getAdminEmails()); }
		 */

		// Send email
		PWiMailMessage.sendAsHtml(sender, recipients, subject, body);
	}

	/*
	 * public String actionSaveTemplateQuery() throws PWiException,
	 * QueryAccessException { //viewBean
	 * queryBuilderBean.actionSaveTemplateQuery(); return
	 * PWiConstants.NAV_QUERY_RESULT_EXEC; }
	 */

	public String actionReDownloadAll() throws PWiException {
		// TODO actionClearFilter();
		return reDownloadHelper(viewBean.getTabRowList());
	}

	public String actionReDownload() throws PWiException {
		return reDownloadHelper(getTabRowList());
	}

	private String reDownloadHelper(List<List<Data>> dataData)
			throws PWiException {
		if (OutputType.WEB.getId().equals(viewBean.getDisplayingOutputType())) {
			viewBean.setDisplayingWeb(true);
			viewBean.setDisplayingDownload(false);
			viewBean.setAutoDownload(false);
		} else {
			viewBean.setDisplayingWeb(false);
			viewBean.setDisplayingDownload(true);
			viewBean.setAutoDownload(true);
		}

		// Write file if auto download is set
		if (viewBean.isAutoDownload()) {
			List<List<String>> stringData = getDataToWrite(dataData);
			WriteResult writeResult = querySubmissionService.writeQueryResults(
					viewBean.getQuerySubmissionResult().getQueryResult()
							.getColumns(), stringData, viewBean
							.getQuerySubmissionResult(), viewBean.getQuery()
							.getQryNm(), viewBean.getDisplayingOutputType(),
					viewBean.getDisplayingTemplateId(),null);

			if (writeResult.getWriteStatus() == WriteResultStatus.XLSX_SUBSTITUTION) {
				handleFacesInfo(PWiConstants.INFO_XLSX_SUBSTITUTION);
			}

			viewBean.setQueryResultsFile(writeResult.getFile());
		}

		return PWiConstants.NAV_QUERY_RESULT;
	}

	/**
	 * Action that responds to requests to view results on the result page as
	 * another output type.
	 * 
	 * @return JSF navigation
	 * @throws PWiException
	 */
	public String actionViewAsOutputType() throws PWiException {
		viewBean.setDisplayingOutputType(viewBean.getOutputTypeIdMap()
				.get(viewBean.getOutputOptionId()).getId());
		TemplateVO template = viewBean.getTemplateIdMap().get(
				viewBean.getOutputOptionId());
		String templateId = null;
		if (template != null) {
			templateId = template.getTemplateId().toString();
		}
		viewBean.setDisplayingTemplateId(templateId);

		if (OutputType.WEB.getId().equals(viewBean.getDisplayingOutputType())) {
			viewBean.setDisplayingWeb(true);
			viewBean.setDisplayingDownload(false);
			viewBean.setAutoDownload(false);
		} else {
			viewBean.setDisplayingWeb(false);
			viewBean.setDisplayingDownload(true);
			viewBean.setAutoDownload(true);
		}

		PWiQueryExctnEventVO eventVO = historyService
				.getExecutionEventById(viewBean.getQuerySubmissionResult()
						.getExecutedQueryId());

		// Insert new event that is the same as original event but has new
		// output type (so bookmark on page will correspond to event with
		// the new output type)
		Integer eventId = querySubmissionService
				.insertExecutionEventWithOtherOutputType(eventVO,
						viewBean.getDisplayingOutputType(),
						viewBean.getDisplayingTemplateId(),
						ExecutedFrom.RESULTS_CHANGE_VIEW);

		// Update event ID for view
		viewBean.setEventId(eventId);

		// Update bookmarks
		viewBean.setExecuteLink(BookmarkableLinkUtil.getInstance()
				.getExecuteHistoryLink(viewBean.getEventId()));
		viewBean.setModifyLink(BookmarkableLinkUtil.getInstance()
				.getModifyHistoryLink(viewBean.getEventId()));

		// Write file if auto download is set
		if (viewBean.isAutoDownload()) {
			List<List<String>> data = getDataToWrite(getTabRowList());

			WriteResult writeResult = querySubmissionService.writeQueryResults(
					viewBean.getQuerySubmissionResult().getQueryResult()
							.getColumns(), data, viewBean
							.getQuerySubmissionResult(), viewBean.getQuery()
							.getQryNm(), viewBean.getDisplayingOutputType(),
					viewBean.getDisplayingTemplateId(),viewBean);

			if (writeResult.getWriteStatus() == WriteResultStatus.XLSX_SUBSTITUTION) {
				handleFacesInfo(PWiConstants.INFO_XLSX_SUBSTITUTION);
			}

			viewBean.setQueryResultsFile(writeResult.getFile());
		}

		return PWiConstants.NAV_QUERY_RESULT;
	}

	private List<List<String>> getDataToWrite(List<List<Data>> data) {
		List<List<String>> dataToWrite = new ArrayList<List<String>>();
		if (data != null) {
			for (List<Data> row : data) {
				List<String> rowToWrite = new ArrayList<String>();
				for (Data cell : row) {
					rowToWrite.add(cell.getData());
				}
				dataToWrite.add(rowToWrite);
			}
		}
		return dataToWrite;
	}

	public String getOutputOptionId() {
		return viewBean.getOutputOptionId();
	}

	public void setOutputOptionId(String outputOptionId) {
		viewBean.setOutputOptionId(outputOptionId);
	}

	/**
	 * @return the queryName
	 */
	public String getQueryName() {
		if (viewBean != null && viewBean.getQuery()!=null) {
			return viewBean.getQuery().getQryNm();
		} else {
			return "";
		}
	}

	public boolean isFilteredResults() {
		return viewBean.getFilteredResults() != null;
	}

	public List<List<Data>> getTabRowList() {
		if (isFilteredResults()) {
			// If filtered results exist, return those
			return viewBean.getFilteredResults();
		}

		return viewBean.getTabRowList();
	}

	public List<QueryResultColumn> getCaptionList() {
		if (viewBean.getQuerySubmissionResult() != null) {
			return viewBean.getQuerySubmissionResult().getQueryResult()
					.getColumns();
		}

		return new ArrayList<QueryResultColumn>();
	}

	/**
	 * @return the showParameters
	 */
	public String getShowParameters() {
		return viewBean.getShowParameters();
	}

	/**
	 * Displays a limited output of input parameters for the query. If the input
	 * parameters are too long in leng)th it will be cut off to preserve screen
	 * space.
	 * 
	 * @return the showParameters
	 */
	public String getShowParametersLess() {
		String params = getShowParameters();

		// Check whether string exceeds QUERY_SEARCH_PARAMETER_CHAR_LIMIT
		// characters
		if (params != null
				&& params.length() > PWiConstants.QUERY_SEARCH_PARAMETER_CHAR_LIMIT) {
			// Trim to first QUERY_SEARCH_PARAMETER_CHAR_LIMIT characters
			params = params.substring(0,
					PWiConstants.QUERY_SEARCH_PARAMETER_CHAR_LIMIT);
		}
		return params;
	}

	/**
	 * Determines whether the show parameters string is long enough that we'll
	 * need to provide users the means to view the rest.
	 * 
	 * @return the showParameters
	 */
	public boolean isShowParametersToggle() {
		String params = getShowParameters();
		return params != null
				&& params.length() > PWiConstants.QUERY_SEARCH_PARAMETER_CHAR_LIMIT;
	}

	public String getResultMessage() {
		return viewBean.getResultMessage();
	}

	// Writable because used in hidden field
	public void setResultMessage(String resultMessage) {
		viewBean.setResultMessage(resultMessage);
	}

	public String getFilteredResultsMessage() {
		StringBuilder message = new StringBuilder();
		List<List<Data>> filteredResults = viewBean.getFilteredResults();
		if (filteredResults != null) {
			message.append("Showing ");
			message.append(String.valueOf(filteredResults.size()));
			message.append((filteredResults.size() == 1 ? " result"
					: " results"));
			message.append(" matching \"");
			message.append(getFilterString());
			message.append("\".");
		}
		return message.toString();
	}

	public String getQueryResultMessage() {
		StringBuilder message = new StringBuilder();

		List<List<Data>> tabRowList = viewBean.getTabRowList();
		if (tabRowList != null) {
			message.append(String.valueOf(tabRowList.size()));
			message.append((tabRowList.size() == 1 ? " result " : " results "));
			message.append("found.");
		}

		return message.toString();
	}

	public List<SelectItem> getOutputTypeOptions() {
		return viewBean.getOutputTypeOptions();
	}

	/**
	 * Retrieves the options for how many results to display on the query result
	 * page.
	 * 
	 * @return the options
	 */
	public List<SelectItem> getNumRowsToDisplayOptions() {
		SelectItem display50 = new SelectItem("50", "50");
		SelectItem display100 = new SelectItem("100", "100");
		SelectItem displayAll = new SelectItem(String.valueOf(getTabRowList()
				.size()), "All");

		List<SelectItem> items = new ArrayList<SelectItem>();
		items.add(display50);
		items.add(display100);
		items.add(displayAll);

		return items;
	}

	public String getNumRowsToDisplay() {
		return viewBean.getNumRowsToDisplay();
	}

	public void setNumRowsToDisplay(String numRowsToDisplay) {
		viewBean.setNumRowsToDisplay(numRowsToDisplay);
	}

	public boolean isQueryFailed() {
		if (viewBean.getQuerySubmissionResult() != null) {
			return viewBean.getQuerySubmissionResult().getQueryResult()
					.getResultStatus() != ResultStatus.SUCCESS;
		} else {
			return false;
		}

	}

	public boolean isAutoDownload() {
		return viewBean.isAutoDownload();
	}

	public boolean isDisplayingWeb() {
		return viewBean.isDisplayingWeb();
	}

	public boolean isDisplayingDownload() {
		return viewBean.isDisplayingDownload();
	}

	public void setQueryLinkObjectValue(String queryLinkObjectValue) {
		this.queryLinkObjectValue = queryLinkObjectValue;
	}

	public void setFavoriteName(String favoriteName) {
		viewBean.setFavoriteName(favoriteName);
	}

	public String getFavoriteName() {
		return viewBean.getFavoriteName();
	}

	public String getExecuteLink() {
		return viewBean.getExecuteLink();
	}

	public String getModifyLink() {
		return viewBean.getModifyLink();
	}

	public void setFilterString(String filterString) {
		viewBean.setFilterString(filterString);
	}

	public String getFilterString() {
		return viewBean.getFilterString();
	}

	public String getObjectTypesJson() throws PWiException {
		if (objectTypesJson == null) {
			List<PWiObjectTypeVO> objectTypes = objectTypeService
					.getAllPWiObjectTypes();
			objectTypesJson = JsonUtil.queryResusts(objectTypes);
		}
		return objectTypesJson;
	}

	public String getQueriesJson() throws PWiException {
		if (queriesJson == null) {
			String sso = PWiContext.getCurrentInstance().getUserSso();
			List<PWiQueryNoXmlVO> queries = queriesService
					.getQueriesForUser(sso);
			queriesJson = JsonUtil.queryResusts(queries);
		}
		return queriesJson;
	}

	public String getQueryObjectTypesJson() throws PWiException {
		if (queryObjectTypesJson == null) {
			List<PWiQueryObjectTypeVO> queryObjectTypes = queryObjectTypeService
					.getQueryObjectTypes();
			queryObjectTypesJson = JsonUtil.queryResusts(queryObjectTypes);
		}
		return queryObjectTypesJson;
	}

	public QueryBuilderBean getQueryBuilderBean() {
		return queryBuilderBean;
	}

	public void setQueryBuilderBean(QueryBuilderBean queryBuilderBean) {
		this.queryBuilderBean = queryBuilderBean;
	}

	// TODO AF&pH 05.2012:
	// /**
	// *
	// * @return A JSon String representing the query results, containing:
	// * column headings, object types for each column, and data
	// * @throws PWiException
	// */
	// public String getQueryResultJson() throws PWiException {
	// if (queryResultJson == null){
	// // TODO: Would it help to get a PWiQueryVO
	// queriesService.getQueryById(queryLinkQueryID)?
	// // TODO: column headings
	// List<PWiQueryObjectVO> PWiQueryObjectVOList =
	// objectTypeService.getSelectedObjectTypes(queryLinkQueryId);
	// // TODO^^: or would I rather getQueryObjectTypes from
	// queryObjectTypeService?
	// // TODO: data
	// // TODO: initialize query result string
	// queryResultJson = "TODO: Finish getQueryResultJson";
	// }
	// return queryResultJson;
	// }
}