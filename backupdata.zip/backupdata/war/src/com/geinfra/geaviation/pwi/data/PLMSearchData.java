/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMSearchData.java
 * @Creation date: 12-Oct-2010
 * @version 1.0
 * @author :Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.List;

/**
 * @author KK85514
 * 
 */
public class PLMSearchData {
	/**
	  * Holds the name
	  */
	private String name;
	/**
	  * Holds the rev
	  */
	private String rev;
	/**
	  * Holds the owner
	  */
	private String owner;
	/**
	  * Holds the desc
	  */
	private String desc;
	/**
	  * Holds the rdo
	  */
	private String rdo;
	/**
	  * Holds the state
	  */
	private String state;
	/**
	  * Holds the stateListData
	  */
	private List<String> stateListData;
	/**
	  * Holds the stateExcel
	  */
	private String stateExcel;
	/**
	  * Holds the lastupd
	  */
	private String lastupd;
	/**
	  * Holds the ipClass
	  */
	private String ipClass;
	/**
	  * Holds the expCntrl
	  */
	private String expCntrl;
	/**
	  * Holds the geSheet
	  */
	private String geSheet;
	/**
	  * Holds the ecoName
	  */
	private String ecoName;
	/**
	  * Holds the ecoRde
	  */
	private String ecoRde;
	/**
	  * Holds the ecoDesc
	  */
	private String ecoDesc;
	/**
	  * Holds the ecoState
	  */
	private String ecoState;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the rev
	 */
	public String getRev() {
		return rev;
	}

	/**
	 * @param rev
	 *            the rev to set
	 */
	public void setRev(String rev) {
		this.rev = rev;
	}

	/**
	 * @return the owner
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * @param owner
	 *            the owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}

	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param desc
	 *            the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}

	/**
	 * @return the rdo
	 */
	public String getRdo() {
		return rdo;
	}

	/**
	 * @param rdo
	 *            the rdo to set
	 */
	public void setRdo(String rdo) {
		this.rdo = rdo;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state
	 *            the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the stateListData
	 */
	public List<String> getStateListData() {
		return stateListData;
	}

	/**
	 * @param stateListData the stateListData to set
	 */
	public void setStateListData(List<String> stateListData) {
		this.stateListData = stateListData;
	}

	/**
	 * @return the stateExcel
	 */
	public String getStateExcel() {
		return stateExcel;
	}

	/**
	 * @param stateExcel the stateExcel to set
	 */
	public void setStateExcel(String stateExcel) {
		this.stateExcel = stateExcel;
	}

	/**
	 * @return the lastupd
	 */
	public String getLastupd() {
		return lastupd;
	}

	/**
	 * @param lastupd
	 *            the lastupd to set
	 */
	public void setLastupd(String lastupd) {
		this.lastupd = lastupd;
	}

	/**
	 * @return the ipClass
	 */
	public String getIpClass() {
		return ipClass;
	}

	/**
	 * @param ipClass
	 *            the ipClass to set
	 */
	public void setIpClass(String ipClass) {
		this.ipClass = ipClass;
	}

	/**
	 * @return the expCntrl
	 */
	public String getExpCntrl() {
		return expCntrl;
	}

	/**
	 * @param expCntrl
	 *            the expCntrl to set
	 */
	public void setExpCntrl(String expCntrl) {
		this.expCntrl = expCntrl;
	}

	/**
	 * @return the geSheet
	 */
	public String getGeSheet() {
		return geSheet;
	}

	/**
	 * @param geSheet
	 *            the geSheet to set
	 */
	public void setGeSheet(String geSheet) {
		this.geSheet = geSheet;
	}

	/**
	 * @return the ecoName
	 */
	public String getEcoName() {
		return ecoName;
	}

	/**
	 * @param ecoName
	 *            the ecoName to set
	 */
	public void setEcoName(String ecoName) {
		this.ecoName = ecoName;
	}

	/**
	 * @return the ecoRde
	 */
	public String getEcoRde() {
		return ecoRde;
	}

	/**
	 * @param ecoRde
	 *            the ecoRde to set
	 */
	public void setEcoRde(String ecoRde) {
		this.ecoRde = ecoRde;
	}

	/**
	 * @return the ecoDesc
	 */
	public String getEcoDesc() {
		return ecoDesc;
	}

	/**
	 * @param ecoDesc
	 *            the ecoDesc to set
	 */
	public void setEcoDesc(String ecoDesc) {
		this.ecoDesc = ecoDesc;
	}

	/**
	 * @return the ecoState
	 */
	public String getEcoState() {
		return ecoState;
	}

	/**
	 * @param ecoState
	 *            the ecoState to set
	 */
	public void setEcoState(String ecoState) {
		this.ecoState = ecoState;
	}
}
