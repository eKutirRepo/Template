/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMInterfaceAttrData.java
 * @Creation date: 29-Aug-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.ArrayList;
import java.util.List;

public class PLMInterfaceAttrData {
	
	/**
	 * Holds the selectedPartFamily
	 */
	private String selectedPartFamily;
	/**
	 * Holds the selectedAttributeName
	 */
	private String selectedAttributeName;
	/**
	 * Holds the selectedPartNum
	 */
	private String selectedPartNum;
	/**
	 * Holds the selectedCurrPrevRev
	 */
	private boolean selectedCurrPrevRev;
	/**
	 * Holds the selectedInProcessStates
	 */
	private ArrayList<String> selectedInProcessStates;
	/**
	 * Holds the selectedPartType
	 */
	private ArrayList<String> selectedPartType;
	
	/**
	 * Holds the partName
	 */
	private String partName;
	/**
	 * Holds the partTitle
	 */
	private String partTitle;
	/**
	 * Holds the revision
	 */
	private String revision;
	/**
	 * Holds the rdo
	 */
	private String rdo;
	/**
	 * Holds the partType
	 */
	private String partType;
	/**
	 * Holds the partState
	 */
	private String partState;
	/**
	 * Holds the partStateDate
	 */
	private String partStateDate;
	/**
	 * Holds the partFamilyNm
	 */
	private String partFamilyNm;
	/**
	 * Holds the partFamilyDescription
	 */
	private String partFamilyDescription;
	/**
	 * Holds the interfaceName
	 */
	private String interfaceName;
	/**
	 * Holds the attributeGroup
	 */
	private String attributeGroup;
	/**
	 * Holds the attributeNm
	 */
	private String attributeNm;
	/**
	 * Holds the attributeValue
	 */
	private String attributeValue;
	
	private String partId;
	/**
	 * Holds the prodStatus
	 */
	private String prodStatus;
	/**
	 * Holds the geShowinPddr
	 */
	private String geShowinPddr;
	/**
	 * Holds attributeListData
	 */
	private List<PLMInterfaceAttrData> attributeListData =new ArrayList<PLMInterfaceAttrData>();
	/**
	  * Holds the attributeValArr
	  */
	private String[] attributeValArr;
	/**
	  * Holds the prodMakeBuyCd
	  */
	private String prodMakeBuyCd;
	/**
	  * Holds the designPurchase
	  */
	private String 	designPurchase;
	/**
	  * Holds the sparePart
	  */
	private String sparePart;
	/**
	  * Holds the materialCatgry
	  */
	private String 	materialCatgry;
	/**
	  * Holds the orign
	  */
	private String orign;
	/**
	  * Holds the sourceModifiedDt
	  */
	private String 	sourceModifiedDt;
	/**
	  * Holds the sourceOriginatedDt
	  */
	private String sourceOriginatedDt;
	/**
	  * Holds the unitMeasure
	  */
	private String unitMeasure;
	/**
	  * Holds the targetCost
	  */
	private String targetCost;
	/**
	  * Holds the estimatedCost
	  */
	private String estimatedCost;
	/**
	  * Holds the weight
	  */
	private String weight;
	/**
	  * Holds the endItem
	  */
	private String endItem;
	/**
	  * Holds the partClsf
	  */
	private String partClsf;
	/**
	  * Holds the serviceMakeBuyCd
	  */
	private String serviceMakeBuyCd;
	/**
	  * Holds the geChemicalCode
	  */
	private String geChemicalCode;
	/**
	  * Holds the geBaseDwgNm
	  */
	private String geBaseDwgNm;
	/**
	  * Holds the gePartMaterialSpec
	  */
	private String gePartMaterialSpec;
	/**
	  * Holds the gePartCmplcStatus
	  */
	private String gePartCmplcStatus;
	/**
	  * Holds the endItemOverideEnbl
	  */
	private String endItemOverideEnbl;
	/**
	  * Holds the effectivityDt
	  */
	private String effectivityDt;
	/**
	  * Holds the geSyncDpoStatus
	  */
	private String geSyncDpoStatus;
	/**
	  * Holds the leadTime
	  */
	private String leadTime;
	/**
	  * Holds the ebaseDwgNumNm
	  */
	private String ebaseDwgNumNm;
	/**
	  * Holds the isAccountable
	  */
	private String isAccountable;
	/**
	  * Holds the isSerializable
	  */
	private String isSerializable;
	/**
	  * Holds the allLvlMbomGenerate
	  */
	private String allLvlMbomGenerate;
	/**
	  * Holds the partNumlist
	  */
	private List<String> partNumlist;

	/**
	 * @return the selectedPartFamily
	 */
	public String getSelectedPartFamily() {
		return selectedPartFamily;
	}
	/**
	 * @param selectedPartFamily the selectedPartFamily to set
	 */
	public void setSelectedPartFamily(String selectedPartFamily) {
		this.selectedPartFamily = selectedPartFamily;
	}
	/**
	 * @return the selectedAttributeName
	 */
	public String getSelectedAttributeName() {
		return selectedAttributeName;
	}
	/**
	 * @param selectedAttributeName the selectedAttributeName to set
	 */
	public void setSelectedAttributeName(String selectedAttributeName) {
		this.selectedAttributeName = selectedAttributeName;
	}
	
	/**
	 * @return the selectedPartNum
	 */
	public String getSelectedPartNum() {
		return selectedPartNum;
	}
	/**
	 * @param selectedPartNum the selectedPartNum to set
	 */
	public void setSelectedPartNum(String selectedPartNum) {
		this.selectedPartNum = selectedPartNum;
	}
	
	/**
	 * @return the selectedCurrPrevRev
	 */
	public boolean isSelectedCurrPrevRev() {
		return selectedCurrPrevRev;
	}
	/**
	 * @param selectedCurrPrevRev the selectedCurrPrevRev to set
	 */
	public void setSelectedCurrPrevRev(boolean selectedCurrPrevRev) {
		this.selectedCurrPrevRev = selectedCurrPrevRev;
	}
	
	/**
	 * @return the selectedInProcessStates
	 */
	public ArrayList<String> getSelectedInProcessStates() {
		return selectedInProcessStates;
	}
	/**
	 * @param selectedInProcessStates the selectedInProcessStates to set
	 */
	public void setSelectedInProcessStates(ArrayList<String> selectedInProcessStates) {
		this.selectedInProcessStates = selectedInProcessStates;
	}
	/**
	 * @return the selectedPartType
	 */
	public ArrayList<String> getSelectedPartType() {
		return selectedPartType;
	}
	/**
	 * @param selectedPartType the selectedPartType to set
	 */
	public void setSelectedPartType(ArrayList<String> selectedPartType) {
		this.selectedPartType = selectedPartType;
	}
	/**
	 * @return the partName
	 */
	public String getPartName() {
		return partName;
	}
	/**
	 * @param partName the partName to set
	 */
	public void setPartName(String partName) {
		this.partName = partName;
	}
	/**
	 * @return the partTitle
	 */
	public String getPartTitle() {
		return partTitle;
	}
	/**
	 * @param partTitle the partTitle to set
	 */
	public void setPartTitle(String partTitle) {
		this.partTitle = partTitle;
	}
	/**
	 * @return the revision
	 */
	public String getRevision() {
		return revision;
	}
	/**
	 * @param revision the revision to set
	 */
	public void setRevision(String revision) {
		this.revision = revision;
	}
	/**
	 * @return the rdo
	 */
	public String getRdo() {
		return rdo;
	}
	/**
	 * @param rdo the rdo to set
	 */
	public void setRdo(String rdo) {
		this.rdo = rdo;
	}
	
	/**
	 * @return the partType
	 */
	public String getPartType() {
		return partType;
	}
	/**
	 * @param partType the partType to set
	 */
	public void setPartType(String partType) {
		this.partType = partType;
	}
	/**
	 * @return the partState
	 */
	public String getPartState() {
		return partState;
	}
	/**
	 * @param partState the partState to set
	 */
	public void setPartState(String partState) {
		this.partState = partState;
	}
	/**
	 * @return the partStateDate
	 */
	public String getPartStateDate() {
		return partStateDate;
	}
	/**
	 * @param partStateDate the partStateDate to set
	 */
	public void setPartStateDate(String partStateDate) {
		this.partStateDate = partStateDate;
	}
	/**
	 * @return the partFamilyNm
	 */
	public String getPartFamilyNm() {
		return partFamilyNm;
	}
	/**
	 * @param partFamilyNm the partFamilyNm to set
	 */
	public void setPartFamilyNm(String partFamilyNm) {
		this.partFamilyNm = partFamilyNm;
	}
	/**
	 * @return the partFamilyDescription
	 */
	public String getPartFamilyDescription() {
		return partFamilyDescription;
	}
	/**
	 * @param partFamilyDescription the partFamilyDescription to set
	 */
	public void setPartFamilyDescription(String partFamilyDescription) {
		this.partFamilyDescription = partFamilyDescription;
	}
	/**
	 * @return the interfaceName
	 */
	public String getInterfaceName() {
		return interfaceName;
	}
	/**
	 * @param interfaceName the interfaceName to set
	 */
	public void setInterfaceName(String interfaceName) {
		this.interfaceName = interfaceName;
	}
	/**
	 * @return the attributeGroup
	 */
	public String getAttributeGroup() {
		return attributeGroup;
	}
	/**
	 * @param attributeGroup the attributeGroup to set
	 */
	public void setAttributeGroup(String attributeGroup) {
		this.attributeGroup = attributeGroup;
	}
	/**
	 * @return the attributeNm
	 */
	public String getAttributeNm() {
		return attributeNm;
	}
	/**
	 * @param attributeNm the attributeNm to set
	 */
	public void setAttributeNm(String attributeNm) {
		this.attributeNm = attributeNm;
	}
	/**
	 * @return the attributeValue
	 */
	public String getAttributeValue() {
		return attributeValue;
	}
	/**
	 * @param attributeValue the attributeValue to set
	 */
	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}
	
	public String getPartId() {
		return partId;
	}
	
	public void setPartId(String partId) {
		this.partId = partId;
	}
	/**
	 * @return the prodStatus
	 */
	public String getProdStatus() {
		return prodStatus;
	}
	/**
	 * @param prodStatus the prodStatus to set
	 */
	public void setProdStatus(String prodStatus) {
		this.prodStatus = prodStatus;
	}
	/**
	 * @return the geShowinPddr
	 */
	public String getGeShowinPddr() {
		return geShowinPddr;
	}
	/**
	 * @param geShowinPddr the geShowinPddr to set
	 */
	public void setGeShowinPddr(String geShowinPddr) {
		this.geShowinPddr = geShowinPddr;
	}
	/**
	 * @return the attributeListData
	 */
	public List<PLMInterfaceAttrData> getAttributeListData() {
		return attributeListData;
	}
	/**
	 * @param attributeListData the attributeListData to set
	 */
	public void setAttributeListData(List<PLMInterfaceAttrData> attributeListData) {
		this.attributeListData = attributeListData;
	}
	/**
	 * @return the attributeValArr
	 */
	public String[] getAttributeValArr() {
		String[]attributeVal=attributeValArr;
		return attributeVal;
	}
	/**
	 * @param attributeValArr the attributeValArr to set
	 */
	public void setAttributeValArr(String[] attributeValArr) {
		String[]attributeVal=attributeValArr;
		this.attributeValArr = attributeVal;
	}
	/**
	 * @return the prodMakeBuyCd
	 */
	public String getProdMakeBuyCd() {
		return prodMakeBuyCd;
	}
	/**
	 * @param prodMakeBuyCd the prodMakeBuyCd to set
	 */
	public void setProdMakeBuyCd(String prodMakeBuyCd) {
		this.prodMakeBuyCd = prodMakeBuyCd;
	}
	/**
	 * @return the designPurchase
	 */
	public String getDesignPurchase() {
		return designPurchase;
	}
	/**
	 * @param designPurchase the designPurchase to set
	 */
	public void setDesignPurchase(String designPurchase) {
		this.designPurchase = designPurchase;
	}
	/**
	 * @return the sparePart
	 */
	public String getSparePart() {
		return sparePart;
	}
	/**
	 * @param sparePart the sparePart to set
	 */
	public void setSparePart(String sparePart) {
		this.sparePart = sparePart;
	}
	/**
	 * @return the materialCatgry
	 */
	public String getMaterialCatgry() {
		return materialCatgry;
	}
	/**
	 * @param materialCatgry the materialCatgry to set
	 */
	public void setMaterialCatgry(String materialCatgry) {
		this.materialCatgry = materialCatgry;
	}
	/**
	 * @return the orign
	 */
	public String getOrign() {
		return orign;
	}
	/**
	 * @param orign the orign to set
	 */
	public void setOrign(String orign) {
		this.orign = orign;
	}
	/**
	 * @return the sourceModifiedDt
	 */
	public String getSourceModifiedDt() {
		return sourceModifiedDt;
	}
	/**
	 * @param sourceModifiedDt the sourceModifiedDt to set
	 */
	public void setSourceModifiedDt(String sourceModifiedDt) {
		this.sourceModifiedDt = sourceModifiedDt;
	}
	/**
	 * @return the sourceOriginatedDt
	 */
	public String getSourceOriginatedDt() {
		return sourceOriginatedDt;
	}
	/**
	 * @param sourceOriginatedDt the sourceOriginatedDt to set
	 */
	public void setSourceOriginatedDt(String sourceOriginatedDt) {
		this.sourceOriginatedDt = sourceOriginatedDt;
	}
	/**
	 * @return the unitMeasure
	 */
	public String getUnitMeasure() {
		return unitMeasure;
	}
	/**
	 * @param unitMeasure the unitMeasure to set
	 */
	public void setUnitMeasure(String unitMeasure) {
		this.unitMeasure = unitMeasure;
	}
	/**
	 * @return the targetCost
	 */
	public String getTargetCost() {
		return targetCost;
	}
	/**
	 * @param targetCost the targetCost to set
	 */
	public void setTargetCost(String targetCost) {
		this.targetCost = targetCost;
	}
	/**
	 * @return the estimatedCost
	 */
	public String getEstimatedCost() {
		return estimatedCost;
	}
	/**
	 * @param estimatedCost the estimatedCost to set
	 */
	public void setEstimatedCost(String estimatedCost) {
		this.estimatedCost = estimatedCost;
	}
	/**
	 * @return the weight
	 */
	public String getWeight() {
		return weight;
	}
	/**
	 * @param weight the weight to set
	 */
	public void setWeight(String weight) {
		this.weight = weight;
	}
	/**
	 * @return the endItem
	 */
	public String getEndItem() {
		return endItem;
	}
	/**
	 * @param endItem the endItem to set
	 */
	public void setEndItem(String endItem) {
		this.endItem = endItem;
	}
	/**
	 * @return the partClsf
	 */
	public String getPartClsf() {
		return partClsf;
	}
	/**
	 * @param partClsf the partClsf to set
	 */
	public void setPartClsf(String partClsf) {
		this.partClsf = partClsf;
	}
	/**
	 * @return the serviceMakeBuyCd
	 */
	public String getServiceMakeBuyCd() {
		return serviceMakeBuyCd;
	}
	/**
	 * @param serviceMakeBuyCd the serviceMakeBuyCd to set
	 */
	public void setServiceMakeBuyCd(String serviceMakeBuyCd) {
		this.serviceMakeBuyCd = serviceMakeBuyCd;
	}
	/**
	 * @return the geChemicalCode
	 */
	public String getGeChemicalCode() {
		return geChemicalCode;
	}
	/**
	 * @param geChemicalCode the geChemicalCode to set
	 */
	public void setGeChemicalCode(String geChemicalCode) {
		this.geChemicalCode = geChemicalCode;
	}
	/**
	 * @return the geBaseDwgNm
	 */
	public String getGeBaseDwgNm() {
		return geBaseDwgNm;
	}
	/**
	 * @param geBaseDwgNm the geBaseDwgNm to set
	 */
	public void setGeBaseDwgNm(String geBaseDwgNm) {
		this.geBaseDwgNm = geBaseDwgNm;
	}
	/**
	 * @return the gePartMaterialSpec
	 */
	public String getGePartMaterialSpec() {
		return gePartMaterialSpec;
	}
	/**
	 * @param gePartMaterialSpec the gePartMaterialSpec to set
	 */
	public void setGePartMaterialSpec(String gePartMaterialSpec) {
		this.gePartMaterialSpec = gePartMaterialSpec;
	}
	/**
	 * @return the gePartCmplcStatus
	 */
	public String getGePartCmplcStatus() {
		return gePartCmplcStatus;
	}
	/**
	 * @param gePartCmplcStatus the gePartCmplcStatus to set
	 */
	public void setGePartCmplcStatus(String gePartCmplcStatus) {
		this.gePartCmplcStatus = gePartCmplcStatus;
	}
	/**
	 * @return the endItemOverideEnbl
	 */
	public String getEndItemOverideEnbl() {
		return endItemOverideEnbl;
	}
	/**
	 * @param endItemOverideEnbl the endItemOverideEnbl to set
	 */
	public void setEndItemOverideEnbl(String endItemOverideEnbl) {
		this.endItemOverideEnbl = endItemOverideEnbl;
	}
	/**
	 * @return the effectivityDt
	 */
	public String getEffectivityDt() {
		return effectivityDt;
	}
	/**
	 * @param effectivityDt the effectivityDt to set
	 */
	public void setEffectivityDt(String effectivityDt) {
		this.effectivityDt = effectivityDt;
	}
	/**
	 * @return the geSyncDpoStatus
	 */
	public String getGeSyncDpoStatus() {
		return geSyncDpoStatus;
	}
	/**
	 * @param geSyncDpoStatus the geSyncDpoStatus to set
	 */
	public void setGeSyncDpoStatus(String geSyncDpoStatus) {
		this.geSyncDpoStatus = geSyncDpoStatus;
	}
	/**
	 * @return the leadTime
	 */
	public String getLeadTime() {
		return leadTime;
	}
	/**
	 * @param leadTime the leadTime to set
	 */
	public void setLeadTime(String leadTime) {
		this.leadTime = leadTime;
	}
	/**
	 * @return the ebaseDwgNumNm
	 */
	public String getEbaseDwgNumNm() {
		return ebaseDwgNumNm;
	}
	/**
	 * @param ebaseDwgNumNm the ebaseDwgNumNm to set
	 */
	public void setEbaseDwgNumNm(String ebaseDwgNumNm) {
		this.ebaseDwgNumNm = ebaseDwgNumNm;
	}
	/**
	 * @return the isAccountable
	 */
	public String getIsAccountable() {
		return isAccountable;
	}
	/**
	 * @param isAccountable the isAccountable to set
	 */
	public void setIsAccountable(String isAccountable) {
		this.isAccountable = isAccountable;
	}
	/**
	 * @return the isSerializable
	 */
	public String getIsSerializable() {
		return isSerializable;
	}
	/**
	 * @param isSerializable the isSerializable to set
	 */
	public void setIsSerializable(String isSerializable) {
		this.isSerializable = isSerializable;
	}
	/**
	 * @return the allLvlMbomGenerate
	 */
	public String getAllLvlMbomGenerate() {
		return allLvlMbomGenerate;
	}
	/**
	 * @param allLvlMbomGenerate the allLvlMbomGenerate to set
	 */
	public void setAllLvlMbomGenerate(String allLvlMbomGenerate) {
		this.allLvlMbomGenerate = allLvlMbomGenerate;
	}
	/**
	 * @return the partNumlist
	 */
	public List<String> getPartNumlist() {
		return partNumlist;
	}
	/**
	 * @param partNumlist the partNumlist to set
	 */
	public void setPartNumlist(List<String> partNumlist) {
		this.partNumlist = partNumlist;
	}
	
	
}
