/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMFmiAppReportData.java
 * @Creation date: 04-Oct-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMFmiAppReportData {
	/**
	  * Holds the fmiReqName
	  */
	private String fmiReqName;
	/**
	  * Holds the fmiReqDesc
	  */
	private String fmiReqDesc;
	
	/**
	  * Holds the FrameTypeValue
	  */
	private String[] frameTypeValue;

	

	/**
	 * @return the fmiReqName
	 */
	public String getFmiReqName() {
		return fmiReqName;
	}
	/**
	 * @param fmiReqName the fmiReqName to set
	 */
	public void setFmiReqName(String fmiReqName) {
		this.fmiReqName = fmiReqName;
	}
	/**
	 * @return the fmiReqDesc
	 */
	public String getFmiReqDesc() {
		return fmiReqDesc;
	}
	/**
	 * @param fmiReqDesc the fmiReqDesc to set
	 */
	public void setFmiReqDesc(String fmiReqDesc) {
		this.fmiReqDesc = fmiReqDesc;
	}
	/**
	 * @return the frameTypeValue
	 */
	public String[] getFrameTypeValue() {
		String[]frameTypeVal=frameTypeValue;
		return frameTypeVal;
	}
	/**
	 * @param frameTypeValue
	 */
	public void setFrameTypeValue(String[] frameTypeValue) {
		String[]frameTypeVal=frameTypeValue;
		this.frameTypeValue = frameTypeVal;
	}

}
