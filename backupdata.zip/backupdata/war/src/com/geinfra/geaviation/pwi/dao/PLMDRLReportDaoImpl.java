/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMDRLReportDaoImpl.java
 * @Creation date: 05-Nov-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMDRLReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMDRLReportDaoImpl extends SimpleJdbcDaoSupport implements PLMDRLReportDaoIfc{
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMInterfaceAttrDaoImpl.class);
	/**
	 * Holds the SIMPLE_DATE_FORMAT
	 */
	private static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy");
	
	/**
	 * This method is used to get Result List
	 * 
	 * @param plmDRLReportData
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMDRLReportData> getDRLReportResult(PLMDRLReportData plmDRLReportData) throws PLMCommonException {
		
		List<PLMDRLReportData> resultList = new ArrayList<PLMDRLReportData>();
		String timeStamp = null;
		String DRL_VT1 = null;
		String DRL_VT2 = null;
		String DRL_VT3 = null;
		String DRL_VT4 = null;
		
		try{
			timeStamp = PLMUtils.volTableFormatDate();
			LOG.info("The timeStamp for the DRL Report "+timeStamp);
			
			DRL_VT1 = PLMConstants.DRL_VT1.concat(timeStamp);
			DRL_VT2 = PLMConstants.DRL_VT2.concat(timeStamp);
			DRL_VT3 = PLMConstants.DRL_VT3.concat(timeStamp);
			DRL_VT4 = PLMConstants.DRL_VT4.concat(timeStamp); 
			
			StringBuffer query1 = new StringBuffer();
			query1.append(PLMSearchQueries.CREATE_DRL_VT1_1);
			
			if (plmDRLReportData.getEnteredContractNum() != null && !plmDRLReportData.getEnteredContractNum().equals("")) {
				query1.append(" AND CONTRACT_NAME = ").append("'"+plmDRLReportData.getEnteredContractNum()+"'");
			}
			if (plmDRLReportData.getEnteredProjName() != null && !plmDRLReportData.getEnteredProjName().equals("")) {
				query1.append(" AND PRJ_NAME = ").append("'"+plmDRLReportData.getEnteredProjName()+"' ");
			}
			String strQry = query1.append(PLMSearchQueries.CREATE_DRL_VT1_2).toString();
			
			LOG.info("Query for Creating DRL_VT1 : " + strQry.replace(PLMConstants.DRL_VT1, DRL_VT1)
					.replace("?", plmDRLReportData.getEnteredDrlName()));
			getJdbcTemplate().execute(strQry.replace(PLMConstants.DRL_VT1, DRL_VT1)
					.replace("?", plmDRLReportData.getEnteredDrlName()));
			
			LOG.info("Query for Collect STATS DRL_VT1 : " + PLMSearchQueries.COLLECT_STATS_DRL_VT1.replace(PLMConstants.DRL_VT1, DRL_VT1));
			getJdbcTemplate().execute(PLMSearchQueries.COLLECT_STATS_DRL_VT1.replace(PLMConstants.DRL_VT1, DRL_VT1));
			
			LOG.info("Query for Creating DRL_VT2 : " + PLMSearchQueries.CREATE_DRL_VT2.replace(PLMConstants.DRL_VT2, DRL_VT2)
					.replace(PLMConstants.DRL_VT1, DRL_VT1));
			getJdbcTemplate().execute(PLMSearchQueries.CREATE_DRL_VT2.replace(PLMConstants.DRL_VT2, DRL_VT2)
					.replace(PLMConstants.DRL_VT1, DRL_VT1));
		
			LOG.info("Query for Collect STATS DRL_VT2 : " + PLMSearchQueries.COLLECT_STATS_DRL_VT2.replace(PLMConstants.DRL_VT2, DRL_VT2));
			getJdbcTemplate().execute(PLMSearchQueries.COLLECT_STATS_DRL_VT2.replace(PLMConstants.DRL_VT2, DRL_VT2));
			
			LOG.info("Query for Creating DRL_VT3 : " + PLMSearchQueries.CREATE_DRL_VT3.replace(PLMConstants.DRL_VT3, DRL_VT3)
					.replace(PLMConstants.DRL_VT1, DRL_VT1));
			getJdbcTemplate().execute(PLMSearchQueries.CREATE_DRL_VT3.replace(PLMConstants.DRL_VT3, DRL_VT3)
					.replace(PLMConstants.DRL_VT1, DRL_VT1));
			
			LOG.info("Query for Collect STATS DRL_VT3 : " + PLMSearchQueries.COLLECT_STATS_DRL_VT3.replace(PLMConstants.DRL_VT3, DRL_VT3));
			getJdbcTemplate().execute(PLMSearchQueries.COLLECT_STATS_DRL_VT3.replace(PLMConstants.DRL_VT3, DRL_VT3));
			
			LOG.info("Query for Creating DRL_VT4 : " + PLMSearchQueries.CREATE_DRL_VT4.replace(PLMConstants.DRL_VT4, DRL_VT4)
					.replace(PLMConstants.DRL_VT1, DRL_VT1));
			getJdbcTemplate().execute(PLMSearchQueries.CREATE_DRL_VT4.replace(PLMConstants.DRL_VT4, DRL_VT4)
					.replace(PLMConstants.DRL_VT1, DRL_VT1));
			
			LOG.info("Query for Collect STATS DRL_VT4 : " + PLMSearchQueries.COLLECT_STATS_DRL_VT4.replace(PLMConstants.DRL_VT4, DRL_VT4));
			getJdbcTemplate().execute(PLMSearchQueries.COLLECT_STATS_DRL_VT4.replace(PLMConstants.DRL_VT4, DRL_VT4));
			
			LOG.info("Query for Getting GET_DRL_DATA : " + PLMSearchQueries.GET_DRL_DATA.
					replace(PLMConstants.DRL_VT1, DRL_VT1).replace(PLMConstants.DRL_VT2, DRL_VT2)
					.replace(PLMConstants.DRL_VT3, DRL_VT3).replace(PLMConstants.DRL_VT4, DRL_VT4));
			
			resultList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_DRL_DATA.
					replace(PLMConstants.DRL_VT1, DRL_VT1).replace(PLMConstants.DRL_VT2, DRL_VT2)
					.replace(PLMConstants.DRL_VT3, DRL_VT3).replace(PLMConstants.DRL_VT4, DRL_VT4), new DRLReportResultMapper());
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
	}
	return resultList;
	}
	
	/**
	 * @return 
	 */
	private static final class DRLReportResultMapper implements ParameterizedRowMapper<PLMDRLReportData> {
		public PLMDRLReportData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMDRLReportData resultList = new PLMDRLReportData();
			
			resultList.setContractName((PLMUtils.checkNullVal(rs.getString("CONTRACT_NAME"))));
			resultList.setPrjName(PLMUtils.checkNullVal(rs.getString("PRJ_NAME")));
			resultList.setPrjDesc(PLMUtils.checkNullVal(rs.getString("PRJ_DESC")));
			resultList.setDrlName("");
			resultList.setSubmittalName(PLMUtils.checkNullVal(rs.getString("SUBMITTAL_NAME")));
			resultList.setSubmittalRev(PLMUtils.checkNullVal(rs.getString("SUBMITTAL_REV")));
			resultList.setSubmittalStatus(PLMUtils.checkNullVal(rs.getString("SUBMITTAL_STATUS")));
			if(!PLMUtils.isEmpty(rs.getString("SUBMITTAL_DATE"))){
				resultList.setSubmittalDate(SIMPLE_DATE_FORMAT.format(rs.getDate("SUBMITTAL_DATE")));
				}
				else {
					resultList.setSubmittalDate("");
				}
			//resultList.setSubmittalDate(PLMUtils.checkNullVal(rs.getString("SUBMITTAL_DATE")));
			resultList.setConcernedEquipt(PLMUtils.checkNullVal(rs.getString("CONCERNED_EQUIPT")));
			resultList.setConcernedEquiptDesc(PLMUtils.checkNullVal(rs.getString("CONCERNED_EQUIPT_DESC")));
			resultList.setConcernedDiscipline(PLMUtils.checkNullVal(rs.getString("CONCERNED_DISCIPLINE")));
			resultList.setDocName(PLMUtils.checkNullVal(rs.getString("DOCUMENT_NAME")));
			resultList.setDocRev(PLMUtils.checkNullVal(rs.getString("DOCUMENT_REV")));
			resultList.setDocType(PLMUtils.checkNullVal(rs.getString("DOCUMENT_TYPE")));
			resultList.setDocCriticalCode(PLMUtils.checkNullVal(rs.getString("CRIT_INDR")));
			resultList.setDocTitle(PLMUtils.checkNullVal(rs.getString("DOCUMENT_TITLE")));
			resultList.setFrenchTitle(PLMUtils.checkNullVal(rs.getString("FRENCH_TITLE")));
			resultList.setPldDocName(PLMUtils.checkNullVal(rs.getString("PLD_DOC_NAME")));
			resultList.setPldDocRev(PLMUtils.checkNullVal(rs.getString("PLD_DOC_REV")));
			resultList.setCustomerCode(PLMUtils.checkNullVal(rs.getString("CUSTOMER_CODE")));
			resultList.setCustomerCodeRev(PLMUtils.checkNullVal(rs.getString("CUSTOMER_CODE_REV")));
			resultList.setDistributionCode(PLMUtils.checkNullVal(rs.getString("DISTRIBUTION_CODE")));
			resultList.setClusterNm(PLMUtils.checkNullVal(rs.getString("CLUSTER_NM")));
			resultList.setClusterRev(PLMUtils.checkNullVal(rs.getString("CLUSTER_REV")));
			resultList.setClusterState(PLMUtils.checkNullVal(rs.getString("CLUSTER_STATE")));
			resultList.setWbseName(PLMUtils.checkNullVal(rs.getString("WBSE_NAME")));
			resultList.setWbseRev(PLMUtils.checkNullVal(rs.getString("WBSE_REV")));
			resultList.setDstbLstName(PLMUtils.checkNullVal(rs.getString("DSTB_LST_NAME")));
			resultList.setRouteName(PLMUtils.checkNullVal(rs.getString("ROUTE_NAME")));
			resultList.setRouteState(PLMUtils.checkNullVal(rs.getString("ROUTE_STATE")));
			
			if(!PLMUtils.isEmpty(rs.getString("ROUTE_START_DATE"))){
				resultList.setRouteStartDate(SIMPLE_DATE_FORMAT.format(rs.getDate("ROUTE_START_DATE")));
				}
				else {
					resultList.setRouteStartDate("");
				}
			//resultList.setRouteStartDate(PLMUtils.checkNullVal(rs.getString("ROUTE_START_DATE")));
			
		return resultList;
		}
	}

}
