/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMDocGenFmiData.java
 * @Creation date: 14-June-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.data;

import java.util.List;

public class PLMDocGenFmiData {

	// File Data
	/**
	  * Holds the templatepath
	  */
	private String templatepath;
	/**
	  * Holds the templatename
	  */
	private String templatename;
	/**
	  * Holds the fullfilepath
	  */
	private String fullfilepath;
	/**
	  * Holds the strTemplate
	  */
	private String strTemplate;

	// FDM Data //
	/**
	  * Holds the contractnumber
	  */
	private String contractnumber;
	/**
	  * Holds the title
	  */
	private String title;
	/**
	  * Holds the model
	  */
	private String model;
	/**
	  * Holds the customer
	  */
	private String customer;
	/**
	  * Holds the reqeng
	  */
	private String reqeng;
	/**
	  * Holds the appunits
	  */
	private String appunits;
	/**
	  * Holds the appicns
	  */
	private String appicns;
	/**
	  * Holds the partNumber
	  */
	private String partNumber;

	// Bookmarks
	/**
	  * Holds the splnotestext
	  */
	private String splnotestext;
	/**
	  * Holds the issued
	  */
	private String issued;
	/**
	  * Holds the address
	  */
	private String address;
	/**
	  * Holds the city
	  */
	private String city;
	/**
	  * Holds the country
	  */
	private String country;
	/**
	  * Holds the dialcom
	  */
	private String dialcom;
	/**
	  * Holds the distaddrcpmb
	  */
	private String distaddrcpmb;
	/**
	  * Holds the distaddrcpm
	  */
	private String distaddrcpm;
	/**
	  * Holds the distcpm
	  */
	private String distcpm;
	/**
	  * Holds the distcpmSSO
	  */
	
	private String distcpmSSO;
	/**
	  * Holds the distribution
	  */
	private String distribution;
	/**
	  * Holds the distributionSSO
	  */
	private String distributionSSO;
	/**
	  * Holds the distaddress
	  */
	private String distaddress;
	/**
	  * Holds the disadddressb
	  */
	private String disadddressb;
	/**
	  * Holds the dte
	  */
	private String dte;
	/**
	  * Holds the geitable
	  */
	
	private String geitable;
	/**
	  * Holds the icn
	  */
	private String icn;
	/**
	  * Holds the icnnumbers
	  */
	private String icnnumbers;
	/**
	  * Holds the infs
	  */
	private String infs;
	/**
	  * Holds the inrs
	  */
	private String inrs;
	/**
	  * Holds the mobile
	  */
	private String mobile;
	/**
	  * Holds the mlilist
	  */
	private String mlilist;
	/**
	  * Holds the mlitable
	  */
	private String mlitable;
	/**
	  * Holds the mlitable1
	  */
	private String mlitable1;
	/**
	  * Holds the msmail
	  */
	private String msmail;
	/**
	  * Holds the phone
	  */
	private String phone;
	/**
	  * Holds the qlcodes
	  */
	private String qlcodes;
	/**
	  * Holds the qldesc
	  */
	private String qldesc;
	/**
	  * Holds the reqenglocation
	  */
	private String reqenglocation;
	/**
	  * Holds the serialnumbers
	  */
	private String serialnumbers;
	/**
	  * Holds the state
	  */
	private String state;
	/**
	  * Holds the tsn
	  */
	private String tsn;
	/**
	  * Holds the zip
	  */
	private String zip;
	/**
	  * Holds the mlino
	  */
	private String mlino;
	/**
	  * Holds the drawingno
	  */
	private String drawingno;
	/**
	  * Holds the qty
	  */
	private String qty;
	/**
	  * Holds the nomenclature
	  */
	private String nomenclature;
	/**
	  * Holds the note
	  */
	private String note;
	/**
	  * Holds the partno
	  */
	private String partNum;
	/**
	  * Holds the revision
	  */
	private String revision;
	/**
	  * Holds the comdocno
	  */
	private String comdocno;
	//Added by Kishore
	/**
	  * Holds the partRevision
	  */
	private String partRevision;
	/**
	  * Holds the partState
	  */
	private String partState;
	/**
	  * Holds the partQuantity
	  */
	private String partQuantity;
	/**
	  * Holds the uom
	  */
	private String uom;
	/**
	  * Holds the docName
	  */
	private String docName;
	/**
	  * Holds the docState
	  */
	private String docState;
	/**
	  * Holds the docDesc
	  */
	private String docDesc;
	/**
	  * Holds the docRev
	  */
	private String docRev;
	//Ended by Kishore
	
	//Added by srinivas
	/**
	  * Holds the serialNoList
	  */
	private List<String> serialNoList;
	/**
	  * Holds the partAssign
	  */
	private String partAssign;
	/**
	  * Holds the titl
	  */

	private String titl;
	
	
	//Added by Raju for Ebom data in FMI doc
	/**
	  * Holds the parentId
	  */
	private String parentId;
	/**
	  * Holds the parentName1
	  */
	private String parentName1;
	/**
	  * Holds the parentRev
	  */
	private String parentRev;
	/**
	  * Holds the childId
	  */
	private String childId;
	/**
	  * Holds the childName
	  */
	private String childName;
	/**
	  * Holds the childRev
	  */
	private String childRev;
	/**
	  * Holds the childDesc
	  */
	private String childDesc;
	/**
	  * Holds the level
	  */
	private String level;
	/**
	  * Holds the dfsOrder
	  */
	private String dfsOrder;
	/**
	  * Holds the quantity1
	  */
	private String quantity1;
	/**
	  * Holds the geBomPrefix
	  */
	private String geBomPrefix;
	/**
	  * Holds the uom1
	  */
	private String uom1;
	/**
	  * Holds the drpDwnLvl
	  */
	
	private String drpDwnLvl;
	/**
	  * Holds the ebomTable
	  */
	
	private String ebomTable;

	//Get ReqData
	private String cntrctNm;
	private String reqNm;
	private String reqRev;
	private String srcBkType;
	
	//Get CEI Data
	private String cntrctNm1;
	private String ciNum;
	private String ciDisplayName;
	
	//Get Req Desc
	private String fmiSeqId;
	private String fmiReqNm;
	private String fmiReqDesc;
	
	//Get FMI Text
	private String fmiCeiNm;
	private String fmiReqNm1;
	private String fmiSpTools;
	private String fmiMdfctnDsc;
	private String fmiFmiSplNts;
	private String fmiSrvcDocs;
	private String fmiRprTxt;
	private String fmiFldTxtVal;
	private String fmiTxtVal;
	
	//Get Text val for MLI
	private String fmiCeiNm1;
	private String fmiReqNm2;
	private String fmiMliNm;
	private String fmiTxtVal1;
	
	private List<String> mliList;
	private List<String> reqList;
	private List<String> ceiList;
	
	private String strReqDescList;
	private String strCeiReqSptlsList;
	private String strCeiReqModDescList;
	private String strCeiReqMliFmiTxtList;
	private String strCeiReqSpNtsList;
	private String strCeiReqSerDcsList;
	private String strCeiReqRepTxtList;
	private String strCeiReqFldTxtList;
	
	List<PLMDocGenFmiData> tempMlidetailslist;
	List<PLMDocGenFmiData> tempCeiDataList;
	
	private String project;
	
	private List<String> projectNamesList;

	/**
	 * Holds the selProduct
	 */
	 private String selProduct;
	//newly added by srinivas for 3.0.7 Realease
	 /**
	 * Holds the materialContract
	 */
	 private String materialContract;
	 /**
	 * Holds the materialOrder
	 */
	 private String materialOrder;
	 /**
	 * Holds the materialMli
	 */
	 private String materialMli;
	 /**
	  * Holds the materialPartName
	  */
	 private String materialPartName;
	 /**
	  * Holds the materialPartDesc
	  */
	 private String materialPartDesc;
	 /**
	  * Holds the materialErpLineNum
	  */
	 private int materialErpLineNum;
	 /**
	  * Holds the materialQty
	  */
	 private int materialQty;
	 /**
	  * Holds the materialLineStatus
	  */
	 private String materialLineStatus;
	 /**
	  * Holds the materialDelivery
	  */
	 private String materialDelivery;
	 /**
	  * Holds the materialPromiseDttm
	  */
	 private String materialPromiseDttm;
	 /**
	  * Holds the materialErpStatus
	  */
	 private String materialErpStatus;
	 /**
	  * Holds the materialWayBill
	  */
	 private String materialWayBill;
	 /**
	  * Holds the materialShipDttm
	  */
	 private String materialShipDttm;
	 /**
	  * Holds the materialShipDttm
	  */
	 private String materialShipTable;
	 /**
	  * Holds the modifcationDesc
	  */
	 private String modifcationDesc;

	 /**
	  * Holds the partName
	  */
	 private String partName;
	 
	 /**
	  * Holds the partDesc
	  */
	 private String partDesc;
	 
	 
	 /**
	  * Holds the LineNumber
	  */
	 private String LineNumber;


	 /**
	 * @return the templatepath
	 */
	public String getTemplatepath() {
		return templatepath;
	}

	/**
	 * @param templatepath
	 *            the templatepath to set
	 */
	public void setTemplatepath(String templatepath) {
		this.templatepath = templatepath;
	}

	/**
	 * @return the templatename
	 */
	public String getTemplatename() {
		return templatename;
	}

	/**
	 * @param templatename
	 *            the templatename to set
	 */
	public void setTemplatename(String templatename) {
		this.templatename = templatename;
	}

	/**
	 * @return the fullfilepath
	 */
	public String getFullfilepath() {
		return fullfilepath;
	}

	/**
	 * @param fullfilepath
	 *            the fullfilepath to set
	 */
	public void setFullfilepath(String fullfilepath) {
		this.fullfilepath = fullfilepath;
	}

	/**
	 * @return the strTemplate
	 */
	public String getStrTemplate() {
		return strTemplate;
	}

	/**
	 * @param strTemplate
	 *            the strTemplate to set
	 */
	public void setStrTemplate(String strTemplate) {
		this.strTemplate = strTemplate;
	}

	/**
	 * @return the revision
	 */
	public String getRevision() {
		return revision;
	}

	/**
	 * @param revision
	 *            the revision to set
	 */
	public void setRevision(String revision) {
		this.revision = revision;
	}

	/**
	 * @return the issued
	 */
	public String getIssued() {
		return issued;
	}

	/**
	 * @param issued
	 *            the issued to set
	 */
	public void setIssued(String issued) {
		this.issued = issued;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address
	 *            the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city
	 *            the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country
	 *            the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the dialcom
	 */
	public String getDialcom() {
		return dialcom;
	}

	/**
	 * @param dialcom
	 *            the dialcom to set
	 */
	public void setDialcom(String dialcom) {
		this.dialcom = dialcom;
	}

	/**
	 * @return the distaddrcpmb
	 */
	public String getDistaddrcpmb() {
		return distaddrcpmb;
	}

	/**
	 * @param distaddrcpmb
	 *            the distaddrcpmb to set
	 */
	public void setDistaddrcpmb(String distaddrcpmb) {
		this.distaddrcpmb = distaddrcpmb;
	}

	/**
	 * @return the distaddrcpm
	 */
	public String getDistaddrcpm() {
		return distaddrcpm;
	}

	/**
	 * @param distaddrcpm
	 *            the distaddrcpm to set
	 */
	public void setDistaddrcpm(String distaddrcpm) {
		this.distaddrcpm = distaddrcpm;
	}

	/**
	 * @return the distcpm
	 */
	public String getDistcpm() {
		return distcpm;
	}

	/**
	 * @param distcpm
	 *            the distcpm to set
	 */
	public void setDistcpm(String distcpm) {
		this.distcpm = distcpm;
	}

	/**
	 * @return the distribution
	 */
	public String getDistribution() {
		return distribution;
	}

	/**
	 * @param distribution
	 *            the distribution to set
	 */
	public void setDistribution(String distribution) {
		this.distribution = distribution;
	}

	/**
	 * @return the distaddress
	 */
	public String getDistaddress() {
		return distaddress;
	}

	/**
	 * @param distaddress
	 *            the distaddress to set
	 */
	public void setDistaddress(String distaddress) {
		this.distaddress = distaddress;
	}

	/**
	 * @return the disadddressb
	 */
	public String getDisadddressb() {
		return disadddressb;
	}

	/**
	 * @param disadddressb
	 *            the disadddressb to set
	 */
	public void setDisadddressb(String disadddressb) {
		this.disadddressb = disadddressb;
	}

	/**
	 * @return the dte
	 */
	public String getDte() {
		return dte;
	}

	/**
	 * @param dte
	 *            the dte to set
	 */
	public void setDte(String dte) {
		this.dte = dte;
	}

	/**
	 * @return the geitable
	 */
	public String getGeitable() {
		return geitable;
	}

	/**
	 * @param geitable
	 *            the geitable to set
	 */
	public void setGeitable(String geitable) {
		this.geitable = geitable;
	}

	/**
	 * @return the icn
	 */
	public String getIcn() {
		return icn;
	}

	/**
	 * @param icn
	 *            the icn to set
	 */
	public void setIcn(String icn) {
		this.icn = icn;
	}

	/**
	 * @return the icnnumbers
	 */
	public String getIcnnumbers() {
		return icnnumbers;
	}

	/**
	 * @param icnnumbers
	 *            the icnnumbers to set
	 */
	public void setIcnnumbers(String icnnumbers) {
		this.icnnumbers = icnnumbers;
	}

	/**
	 * @return the infs
	 */
	public String getInfs() {
		return infs;
	}

	/**
	 * @param infs
	 *            the infs to set
	 */
	public void setInfs(String infs) {
		this.infs = infs;
	}

	/**
	 * @return the inrs
	 */
	public String getInrs() {
		return inrs;
	}

	/**
	 * @param inrs
	 *            the inrs to set
	 */
	public void setInrs(String inrs) {
		this.inrs = inrs;
	}
	
	/**
	 * @return the mlilist
	 */
	public String getMlilist() {
		return mlilist;
	}

	/**
	 * @param mlilist
	 *            the mlilist to set
	 */
	public void setMlilist(String mlilist) {
		this.mlilist = mlilist;
	}

	/**
	 * @return the mlitable
	 */
	public String getMlitable() {
		return mlitable;
	}

	/**
	 * @param mlitable
	 *            the mlitable to set
	 */
	public void setMlitable(String mlitable) {
		this.mlitable = mlitable;
	}

	/**
	 * @return the mlitable1
	 */
	public String getMlitable1() {
		return mlitable1;
	}

	/**
	 * @param mlitable1
	 *            the mlitable1 to set
	 */
	public void setMlitable1(String mlitable1) {
		this.mlitable1 = mlitable1;
	}

	/**
	 * @return the msmail
	 */
	public String getMsmail() {
		return msmail;
	}

	/**
	 * @param msmail
	 *            the msmail to set
	 */
	public void setMsmail(String msmail) {
		this.msmail = msmail;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @param phone
	 *            the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * @return the qlcodes
	 */
	public String getQlcodes() {
		return qlcodes;
	}

	/**
	 * @param qlcodes
	 *            the qlcodes to set
	 */
	public void setQlcodes(String qlcodes) {
		this.qlcodes = qlcodes;
	}

	/**
	 * @return the qldesc
	 */
	public String getQldesc() {
		return qldesc;
	}

	/**
	 * @param qldesc
	 *            the qldesc to set
	 */
	public void setQldesc(String qldesc) {
		this.qldesc = qldesc;
	}

	/**
	 * @return the reqenglocation
	 */
	public String getReqenglocation() {
		return reqenglocation;
	}

	/**
	 * @param reqenglocation
	 *            the reqenglocation to set
	 */
	public void setReqenglocation(String reqenglocation) {
		this.reqenglocation = reqenglocation;
	}

	/**
	 * @return the serialnumbers
	 */
	public String getSerialnumbers() {
		return serialnumbers;
	}

	/**
	 * @param serialnumbers
	 *            the serialnumbers to set
	 */
	public void setSerialnumbers(String serialnumbers) {
		this.serialnumbers = serialnumbers;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state
	 *            the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the titl
	 */
	public String getTitl() {
		return titl;
	}

	/**
	 * @param titl
	 *            the titl to set
	 */
	public void setTitl(String titl) {
		this.titl = titl;
	}

	/**
	 * @return the tsn
	 */
	public String getTsn() {
		return tsn;
	}

	/**
	 * @param tsn
	 *            the tsn to set
	 */
	public void setTsn(String tsn) {
		this.tsn = tsn;
	}

	/**
	 * @return the zip
	 */
	public String getZip() {
		return zip;
	}

	/**
	 * @param zip
	 *            the zip to set
	 */
	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getSplnotestext() {
		return splnotestext;
	}

	public void setSplnotestext(String splnotestext) {
		this.splnotestext = splnotestext;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getReqeng() {
		return reqeng;
	}

	public void setReqeng(String reqeng) {
		this.reqeng = reqeng;
	}

	public String getAppunits() {
		return appunits;
	}

	public void setAppunits(String appunits) {
		this.appunits = appunits;
	}

	public String getAppicns() {
		return appicns;
	}

	public void setAppicns(String appicns) {
		this.appicns = appicns;
	}

	public String getContractnumber() {
		return contractnumber;
	}

	public void setContractnumber(String contractnumber) {
		this.contractnumber = contractnumber;
	}

	/**
	 * @return the mlino
	 */
	public String getMlino() {
		return mlino;
	}

	/**
	 * @param mlino
	 *            the mlino to set
	 */
	public void setMlino(String mlino) {
		this.mlino = mlino;
	}

	
	/**
	 * @return the mlino
	 */
	/*public String getPartno() {
		return partno;
	}*/

	/**
	 * @param mlino
	 *            the mlino to set
	 */
	/*public void setPartno(String partno) {
		this.partno = partno;
	}*/

	/**
	 * @return the partNum
	 */
	public String getPartNum() {
		return partNum;
	}

	/**
	 * @param partNum the partNum to set
	 */
	public void setPartNum(String partNum) {
		this.partNum = partNum;
	}

	/**
	 * @return the drawingno
	 */
	public String getDrawingno() {
		return drawingno;
	}

	/**
	 * @param drawingno
	 *            the drawingno to set
	 */
	public void setDrawingno(String drawingno) {
		this.drawingno = drawingno;
	}

	/**
	 * @return the comdocno
	 */
	public String getComdocno() {
		return comdocno;
	}

	/**
	 * @param comdocno
	 *            the comdocno to set
	 */
	public void setComdocno(String comdocno) {
		this.comdocno = comdocno;
	}

	/**
	 * @return the qty
	 */
	public String getQty() {
		return qty;
	}

	/**
	 * @param qty the qty to set
	 */
	public void setQty(String qty) {
		this.qty = qty;
	}

	/**
	 * @return the nomenclature
	 */
	public String getNomenclature() {
		return nomenclature;
	}

	/**
	 * @param nomenclature the nomenclature to set
	 */
	public void setNomenclature(String nomenclature) {
		this.nomenclature = nomenclature;
	}

	/**
	 * @return the note
	 */
	public String getNote() {
		return note;
	}

	/**
	 * @param note the note to set
	 */
	public void setNote(String note) {
		this.note = note;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPartRevision() {
		return partRevision;
	}

	public void setPartRevision(String partRevision) {
		this.partRevision = partRevision;
	}

	public String getPartState() {
		return partState;
	}

	public void setPartState(String partState) {
		this.partState = partState;
	}

	public String getPartQuantity() {
		return partQuantity;
	}

	public void setPartQuantity(String partQuantity) {
		this.partQuantity = partQuantity;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public String getDocState() {
		return docState;
	}

	public void setDocState(String docState) {
		this.docState = docState;
	}

	public String getDocDesc() {
		return docDesc;
	}

	public void setDocDesc(String docDesc) {
		this.docDesc = docDesc;
	}

	public String getDocRev() {
		return docRev;
	}

	public void setDocRev(String docRev) {
		this.docRev = docRev;
	}

	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}

	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	
	/**
	 * @return the serialNoList
	 */
	public List<String> getSerialNoList() {
		return serialNoList;
	}

	/**
	 * @param serialNoList the serialNoList to set
	 */
	public void setSerialNoList(List<String> serialNoList) {
		this.serialNoList = serialNoList;
	}

	/**
	 * @return the partAssign
	 */
	public String getPartAssign() {
		return partAssign;
	}

	/**
	 * @param partAssign the partAssign to set
	 */
	public void setPartAssign(String partAssign) {
		this.partAssign = partAssign;
	}

	/**
	 * @return the distcpmSSO
	 */
	public String getDistcpmSSO() {
		return distcpmSSO;
	}

	/**
	 * @param distcpmSSO the distcpmSSO to set
	 */
	public void setDistcpmSSO(String distcpmSSO) {
		this.distcpmSSO = distcpmSSO;
	}

	/**
	 * @return the distributionSSO
	 */
	public String getDistributionSSO() {
		return distributionSSO;
	}

	/**
	 * @param distributionSSO the distributionSSO to set
	 */
	public void setDistributionSSO(String distributionSSO) {
		this.distributionSSO = distributionSSO;
	}

	/**
	 * @return the parentId
	 */
	public String getParentId() {
		return parentId;
	}

	/**
	 * @param parentId the parentId to set
	 */
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	/**
	 * @return the parentName1
	 */
	public String getParentName1() {
		return parentName1;
	}

	/**
	 * @param parentName1 the parentName1 to set
	 */
	public void setParentName1(String parentName1) {
		this.parentName1 = parentName1;
	}

	/**
	 * @return the parentRev
	 */
	public String getParentRev() {
		return parentRev;
	}

	/**
	 * @param parentRev the parentRev to set
	 */
	public void setParentRev(String parentRev) {
		this.parentRev = parentRev;
	}

	/**
	 * @return the childId
	 */
	public String getChildId() {
		return childId;
	}

	/**
	 * @param childId the childId to set
	 */
	public void setChildId(String childId) {
		this.childId = childId;
	}

	/**
	 * @return the childName
	 */
	public String getChildName() {
		return childName;
	}

	/**
	 * @param childName the childName to set
	 */
	public void setChildName(String childName) {
		this.childName = childName;
	}

	/**
	 * @return the childRev
	 */
	public String getChildRev() {
		return childRev;
	}

	/**
	 * @param childRev the childRev to set
	 */
	public void setChildRev(String childRev) {
		this.childRev = childRev;
	}

	/**
	 * @return the childDesc
	 */
	public String getChildDesc() {
		return childDesc;
	}

	/**
	 * @param childDesc the childDesc to set
	 */
	public void setChildDesc(String childDesc) {
		this.childDesc = childDesc;
	}

	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}

	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}

	/**
	 * @return the dfsOrder
	 */
	public String getDfsOrder() {
		return dfsOrder;
	}

	/**
	 * @param dfsOrder the dfsOrder to set
	 */
	public void setDfsOrder(String dfsOrder) {
		this.dfsOrder = dfsOrder;
	}

	/**
	 * @return the quantity1
	 */
	public String getQuantity1() {
		return quantity1;
	}

	/**
	 * @param quantity1 the quantity1 to set
	 */
	public void setQuantity1(String quantity1) {
		this.quantity1 = quantity1;
	}

	/**
	 * @return the geBomPrefix
	 */
	public String getGeBomPrefix() {
		return geBomPrefix;
	}

	/**
	 * @param geBomPrefix the geBomPrefix to set
	 */
	public void setGeBomPrefix(String geBomPrefix) {
		this.geBomPrefix = geBomPrefix;
	}

	/**
	 * @return the uom1
	 */
	public String getUom1() {
		return uom1;
	}

	/**
	 * @param uom1 the uom1 to set
	 */
	public void setUom1(String uom1) {
		this.uom1 = uom1;
	}

	/**
	 * @return the drpDwnLvl
	 */
	public String getDrpDwnLvl() {
		return drpDwnLvl;
	}

	/**
	 * @param drpDwnLvl the drpDwnLvl to set
	 */
	public void setDrpDwnLvl(String drpDwnLvl) {
		this.drpDwnLvl = drpDwnLvl;
	}

	/**
	 * @return the ebomTable
	 */
	public String getEbomTable() {
		return ebomTable;
	}

	/**
	 * @param ebomTable the ebomTable to set
	 */
	public void setEbomTable(String ebomTable) {
		this.ebomTable = ebomTable;
	}

	/**
	 * @return the cntrctNm
	 */
	public String getCntrctNm() {
		return cntrctNm;
	}

	/**
	 * @param cntrctNm the cntrctNm to set
	 */
	public void setCntrctNm(String cntrctNm) {
		this.cntrctNm = cntrctNm;
	}

	/**
	 * @return the reqNm
	 */
	public String getReqNm() {
		return reqNm;
	}

	/**
	 * @param reqNm the reqNm to set
	 */
	public void setReqNm(String reqNm) {
		this.reqNm = reqNm;
	}

	/**
	 * @return the reqRev
	 */
	public String getReqRev() {
		return reqRev;
	}

	/**
	 * @param reqRev the reqRev to set
	 */
	public void setReqRev(String reqRev) {
		this.reqRev = reqRev;
	}

	/**
	 * @return the srcBkType
	 */
	public String getSrcBkType() {
		return srcBkType;
	}

	/**
	 * @param srcBkType the srcBkType to set
	 */
	public void setSrcBkType(String srcBkType) {
		this.srcBkType = srcBkType;
	}

	/**
	 * @return the cntrctNm1
	 */
	public String getCntrctNm1() {
		return cntrctNm1;
	}

	/**
	 * @param cntrctNm1 the cntrctNm1 to set
	 */
	public void setCntrctNm1(String cntrctNm1) {
		this.cntrctNm1 = cntrctNm1;
	}

	/**
	 * @return the ciNum
	 */
	public String getCiNum() {
		return ciNum;
	}

	/**
	 * @param ciNum the ciNum to set
	 */
	public void setCiNum(String ciNum) {
		this.ciNum = ciNum;
	}

	/**
	 * @return the fmiSeqId
	 */
	public String getFmiSeqId() {
		return fmiSeqId;
	}

	/**
	 * @param fmiSeqId the fmiSeqId to set
	 */
	public void setFmiSeqId(String fmiSeqId) {
		this.fmiSeqId = fmiSeqId;
	}

	/**
	 * @return the fmiReqNm
	 */
	public String getFmiReqNm() {
		return fmiReqNm;
	}

	/**
	 * @param fmiReqNm the fmiReqNm to set
	 */
	public void setFmiReqNm(String fmiReqNm) {
		this.fmiReqNm = fmiReqNm;
	}

	/**
	 * @return the fmiReqDesc
	 */
	public String getFmiReqDesc() {
		return fmiReqDesc;
	}

	/**
	 * @param fmiReqDesc the fmiReqDesc to set
	 */
	public void setFmiReqDesc(String fmiReqDesc) {
		this.fmiReqDesc = fmiReqDesc;
	}

	/**
	 * @return the fmiCeiNm
	 */
	public String getFmiCeiNm() {
		return fmiCeiNm;
	}

	/**
	 * @param fmiCeiNm the fmiCeiNm to set
	 */
	public void setFmiCeiNm(String fmiCeiNm) {
		this.fmiCeiNm = fmiCeiNm;
	}

	/**
	 * @return the fmiReqNm1
	 */
	public String getFmiReqNm1() {
		return fmiReqNm1;
	}

	/**
	 * @param fmiReqNm1 the fmiReqNm1 to set
	 */
	public void setFmiReqNm1(String fmiReqNm1) {
		this.fmiReqNm1 = fmiReqNm1;
	}

	/**
	 * @return the fmiSpTools
	 */
	public String getFmiSpTools() {
		return fmiSpTools;
	}

	/**
	 * @param fmiSpTools the fmiSpTools to set
	 */
	public void setFmiSpTools(String fmiSpTools) {
		this.fmiSpTools = fmiSpTools;
	}

	/**
	 * @return the fmiMdfctnDsc
	 */
	public String getFmiMdfctnDsc() {
		return fmiMdfctnDsc;
	}

	/**
	 * @param fmiMdfctnDsc the fmiMdfctnDsc to set
	 */
	public void setFmiMdfctnDsc(String fmiMdfctnDsc) {
		this.fmiMdfctnDsc = fmiMdfctnDsc;
	}

	/**
	 * @return the fmiFmiSplNts
	 */
	public String getFmiFmiSplNts() {
		return fmiFmiSplNts;
	}

	/**
	 * @param fmiFmiSplNts the fmiFmiSplNts to set
	 */
	public void setFmiFmiSplNts(String fmiFmiSplNts) {
		this.fmiFmiSplNts = fmiFmiSplNts;
	}

	/**
	 * @return the fmiSrvcDocs
	 */
	public String getFmiSrvcDocs() {
		return fmiSrvcDocs;
	}

	/**
	 * @param fmiSrvcDocs the fmiSrvcDocs to set
	 */
	public void setFmiSrvcDocs(String fmiSrvcDocs) {
		this.fmiSrvcDocs = fmiSrvcDocs;
	}

	/**
	 * @return the fmiRprTxt
	 */
	public String getFmiRprTxt() {
		return fmiRprTxt;
	}

	/**
	 * @param fmiRprTxt the fmiRprTxt to set
	 */
	public void setFmiRprTxt(String fmiRprTxt) {
		this.fmiRprTxt = fmiRprTxt;
	}

	/**
	 * @return the fmiTxtVal
	 */
	public String getFmiTxtVal() {
		return fmiTxtVal;
	}

	/**
	 * @param fmiTxtVal the fmiTxtVal to set
	 */
	public void setFmiTxtVal(String fmiTxtVal) {
		this.fmiTxtVal = fmiTxtVal;
	}

	/**
	 * @return the fmiCeiNm1
	 */
	public String getFmiCeiNm1() {
		return fmiCeiNm1;
	}

	/**
	 * @param fmiCeiNm1 the fmiCeiNm1 to set
	 */
	public void setFmiCeiNm1(String fmiCeiNm1) {
		this.fmiCeiNm1 = fmiCeiNm1;
	}

	/**
	 * @return the fmiReqNm2
	 */
	public String getFmiReqNm2() {
		return fmiReqNm2;
	}

	/**
	 * @param fmiReqNm2 the fmiReqNm2 to set
	 */
	public void setFmiReqNm2(String fmiReqNm2) {
		this.fmiReqNm2 = fmiReqNm2;
	}

	/**
	 * @return the fmiMliNm
	 */
	public String getFmiMliNm() {
		return fmiMliNm;
	}

	/**
	 * @param fmiMliNm the fmiMliNm to set
	 */
	public void setFmiMliNm(String fmiMliNm) {
		this.fmiMliNm = fmiMliNm;
	}

	/**
	 * @return the fmiTxtVal1
	 */
	public String getFmiTxtVal1() {
		return fmiTxtVal1;
	}

	/**
	 * @param fmiTxtVal1 the fmiTxtVal1 to set
	 */
	public void setFmiTxtVal1(String fmiTxtVal1) {
		this.fmiTxtVal1 = fmiTxtVal1;
	}

	/**
	 * @return the mliList
	 */
	public List<String> getMliList() {
		return mliList;
	}

	/**
	 * @param mliList the mliList to set
	 */
	public void setMliList(List<String> mliList) {
		this.mliList = mliList;
	}

	/**
	 * @return the reqList
	 */
	public List<String> getReqList() {
		return reqList;
	}

	/**
	 * @param reqList the reqList to set
	 */
	public void setReqList(List<String> reqList) {
		this.reqList = reqList;
	}

	/**
	 * @return the ceiList
	 */
	public List<String> getCeiList() {
		return ceiList;
	}

	/**
	 * @param ceiList the ceiList to set
	 */
	public void setCeiList(List<String> ceiList) {
		this.ceiList = ceiList;
	}

	/**
	 * @return the strReqDescList
	 */
	public String getStrReqDescList() {
		return strReqDescList;
	}

	/**
	 * @param strReqDescList the strReqDescList to set
	 */
	public void setStrReqDescList(String strReqDescList) {
		this.strReqDescList = strReqDescList;
	}

	/**
	 * @return the strCeiReqSptlsList
	 */
	public String getStrCeiReqSptlsList() {
		return strCeiReqSptlsList;
	}

	/**
	 * @param strCeiReqSptlsList the strCeiReqSptlsList to set
	 */
	public void setStrCeiReqSptlsList(String strCeiReqSptlsList) {
		this.strCeiReqSptlsList = strCeiReqSptlsList;
	}

	/**
	 * @return the strCeiReqModDescList
	 */
	public String getStrCeiReqModDescList() {
		return strCeiReqModDescList;
	}

	/**
	 * @param strCeiReqModDescList the strCeiReqModDescList to set
	 */
	public void setStrCeiReqModDescList(String strCeiReqModDescList) {
		this.strCeiReqModDescList = strCeiReqModDescList;
	}

	/**
	 * @return the strCeiReqMliFmiTxtList
	 */
	public String getStrCeiReqMliFmiTxtList() {
		return strCeiReqMliFmiTxtList;
	}

	/**
	 * @param strCeiReqMliFmiTxtList the strCeiReqMliFmiTxtList to set
	 */
	public void setStrCeiReqMliFmiTxtList(String strCeiReqMliFmiTxtList) {
		this.strCeiReqMliFmiTxtList = strCeiReqMliFmiTxtList;
	}

	/**
	 * @return the strCeiReqSpNtsList
	 */
	public String getStrCeiReqSpNtsList() {
		return strCeiReqSpNtsList;
	}

	/**
	 * @param strCeiReqSpNtsList the strCeiReqSpNtsList to set
	 */
	public void setStrCeiReqSpNtsList(String strCeiReqSpNtsList) {
		this.strCeiReqSpNtsList = strCeiReqSpNtsList;
	}

	/**
	 * @return the strCeiReqSerDcsList
	 */
	public String getStrCeiReqSerDcsList() {
		return strCeiReqSerDcsList;
	}

	/**
	 * @param strCeiReqSerDcsList the strCeiReqSerDcsList to set
	 */
	public void setStrCeiReqSerDcsList(String strCeiReqSerDcsList) {
		this.strCeiReqSerDcsList = strCeiReqSerDcsList;
	}

	/**
	 * @return the strCeiReqRepTxtList
	 */
	public String getStrCeiReqRepTxtList() {
		return strCeiReqRepTxtList;
	}

	/**
	 * @param strCeiReqRepTxtList the strCeiReqRepTxtList to set
	 */
	public void setStrCeiReqRepTxtList(String strCeiReqRepTxtList) {
		this.strCeiReqRepTxtList = strCeiReqRepTxtList;
	}

	/**
	 * @return the strCeiReqFldTxtList
	 */
	public String getStrCeiReqFldTxtList() {
		return strCeiReqFldTxtList;
	}

	/**
	 * @param strCeiReqFldTxtList the strCeiReqFldTxtList to set
	 */
	public void setStrCeiReqFldTxtList(String strCeiReqFldTxtList) {
		this.strCeiReqFldTxtList = strCeiReqFldTxtList;
	}

	/**
	 * @return the tempMlidetailslist
	 */
	public List<PLMDocGenFmiData> getTempMlidetailslist() {
		return tempMlidetailslist;
	}

	/**
	 * @param tempMlidetailslist the tempMlidetailslist to set
	 */
	public void setTempMlidetailslist(List<PLMDocGenFmiData> tempMlidetailslist) {
		this.tempMlidetailslist = tempMlidetailslist;
	}

	/**
	 * @return the ciDisplayName
	 */
	public String getCiDisplayName() {
		return ciDisplayName;
	}

	/**
	 * @param ciDisplayName the ciDisplayName to set
	 */
	public void setCiDisplayName(String ciDisplayName) {
		this.ciDisplayName = ciDisplayName;
	}

	/**
	 * @return the tempCeiDataList
	 */
	public List<PLMDocGenFmiData> getTempCeiDataList() {
		return tempCeiDataList;
	}

	/**
	 * @param tempCeiDataList the tempCeiDataList to set
	 */
	public void setTempCeiDataList(List<PLMDocGenFmiData> tempCeiDataList) {
		this.tempCeiDataList = tempCeiDataList;
	}

	public String getFmiFldTxtVal() {
		return fmiFldTxtVal;
	}

	public void setFmiFldTxtVal(String fmiFldTxtVal) {
		this.fmiFldTxtVal = fmiFldTxtVal;
	}

	/**
	 * @return the project
	 */
	public String getProject() {
		return project;
	}

	/**
	 * @param project the project to set
	 */
	public void setProject(String project) {
		this.project = project;
	}

	/**
	 * @return the projectNamesList
	 */
	public List<String> getProjectNamesList() {
		return projectNamesList;
	}

	/**
	 * @param projectNamesList the projectNamesList to set
	 */
	public void setProjectNamesList(List<String> projectNamesList) {
		this.projectNamesList = projectNamesList;
	}

	/**
	 * @return the selProduct
	 */
	public String getSelProduct() {
		return selProduct;
	}

	/**
	 * @param selProduct the selProduct to set
	 */
	public void setSelProduct(String selProduct) {
		this.selProduct = selProduct;
	}

	/**
	 * @return the materialContract
	 */
	public String getMaterialContract() {
		return materialContract;
	}

	/**
	 * @param materialContract the materialContract to set
	 */
	public void setMaterialContract(String materialContract) {
		this.materialContract = materialContract;
	}

	/**
	 * @return the materialOrder
	 */
	public String getMaterialOrder() {
		return materialOrder;
	}

	/**
	 * @param materialOrder the materialOrder to set
	 */
	public void setMaterialOrder(String materialOrder) {
		this.materialOrder = materialOrder;
	}

	/**
	 * @return the materialMli
	 */
	public String getMaterialMli() {
		return materialMli;
	}

	/**
	 * @param materialMli the materialMli to set
	 */
	public void setMaterialMli(String materialMli) {
		this.materialMli = materialMli;
	}

	/**
	 * @return the materialPartName
	 */
	public String getMaterialPartName() {
		return materialPartName;
	}

	/**
	 * @param materialPartName the materialPartName to set
	 */
	public void setMaterialPartName(String materialPartName) {
		this.materialPartName = materialPartName;
	}

	/**
	 * @return the materialPartDesc
	 */
	public String getMaterialPartDesc() {
		return materialPartDesc;
	}

	/**
	 * @param materialPartDesc the materialPartDesc to set
	 */
	public void setMaterialPartDesc(String materialPartDesc) {
		this.materialPartDesc = materialPartDesc;
	}

	/**
	 * @return the materialErpLineNum
	 */
	public int getMaterialErpLineNum() {
		return materialErpLineNum;
	}

	/**
	 * @param materialErpLineNum the materialErpLineNum to set
	 */
	public void setMaterialErpLineNum(int materialErpLineNum) {
		this.materialErpLineNum = materialErpLineNum;
	}

	/**
	 * @return the materialQty
	 */
	public int getMaterialQty() {
		return materialQty;
	}

	/**
	 * @param materialQty the materialQty to set
	 */
	public void setMaterialQty(int materialQty) {
		this.materialQty = materialQty;
	}

	/**
	 * @return the materialLineStatus
	 */
	public String getMaterialLineStatus() {
		return materialLineStatus;
	}

	/**
	 * @param materialLineStatus the materialLineStatus to set
	 */
	public void setMaterialLineStatus(String materialLineStatus) {
		this.materialLineStatus = materialLineStatus;
	}

	/**
	 * @return the materialDelivery
	 */
	public String getMaterialDelivery() {
		return materialDelivery;
	}

	/**
	 * @param materialDelivery the materialDelivery to set
	 */
	public void setMaterialDelivery(String materialDelivery) {
		this.materialDelivery = materialDelivery;
	}

	/**
	 * @return the materialPromiseDttm
	 */
	public String getMaterialPromiseDttm() {
		return materialPromiseDttm;
	}

	/**
	 * @param materialPromiseDttm the materialPromiseDttm to set
	 */
	public void setMaterialPromiseDttm(String materialPromiseDttm) {
		this.materialPromiseDttm = materialPromiseDttm;
	}

	/**
	 * @return the materialErpStatus
	 */
	public String getMaterialErpStatus() {
		return materialErpStatus;
	}

	/**
	 * @param materialErpStatus the materialErpStatus to set
	 */
	public void setMaterialErpStatus(String materialErpStatus) {
		this.materialErpStatus = materialErpStatus;
	}

	/**
	 * @return the materialWayBill
	 */
	public String getMaterialWayBill() {
		return materialWayBill;
	}

	/**
	 * @param materialWayBill the materialWayBill to set
	 */
	public void setMaterialWayBill(String materialWayBill) {
		this.materialWayBill = materialWayBill;
	}

	/**
	 * @return the materialShipDttm
	 */
	public String getMaterialShipDttm() {
		return materialShipDttm;
	}

	/**
	 * @param materialShipDttm the materialShipDttm to set
	 */
	public void setMaterialShipDttm(String materialShipDttm) {
		this.materialShipDttm = materialShipDttm;
	}

	/**
	 * @return the materialShipTable
	 */
	public String getMaterialShipTable() {
		return materialShipTable;
	}

	/**
	 * @param materialShipTable the materialShipTable to set
	 */
	public void setMaterialShipTable(String materialShipTable) {
		this.materialShipTable = materialShipTable;
	}

	/**
	 * @return the modifcationDesc
	 */
	public String getModifcationDesc() {
		return modifcationDesc;
	}

	/**
	 * @param modifcationDesc the modifcationDesc to set
	 */
	public void setModifcationDesc(String modifcationDesc) {
		this.modifcationDesc = modifcationDesc;
	}

	/**
	 * @return the partName
	 */
	public String getPartName() {
		return partName;
	}

	/**
	 * @param partName the partName to set
	 */
	public void setPartName(String partName) {
		this.partName = partName;
	}

	/**
	 * @return the partDesc
	 */
	public String getPartDesc() {
		return partDesc;
	}

	/**
	 * @param partDesc the partDesc to set
	 */
	public void setPartDesc(String partDesc) {
		this.partDesc = partDesc;
	}

	/**
	 * @return the lineNumber
	 */
	public String getLineNumber() {
		return LineNumber;
	}

	/**
	 * @param lineNumber the lineNumber to set
	 */
	public void setLineNumber(String lineNumber) {
		LineNumber = lineNumber;
	}

	

}