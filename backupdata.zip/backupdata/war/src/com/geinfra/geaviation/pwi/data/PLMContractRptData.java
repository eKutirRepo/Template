/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMContractRptData.java
 * @Creation date: 12-Aug-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMContractRptData {

	/**
	 * Holds cntrtNm
	 */
	private String cntrtNm;
	/**
	 * Holds cntrtDesc
	 */
	private String cntrtDesc;
	
	/**
	 * Holds mlmplId
	 */
	private String mlmplId;
	/**
	 * Holds mlmplNm
	 */
	private String mlmplNm;
	/**
	 * Holds geSerialNum
	 */
	private String geSerialNum;
	/**
	 * Holds projectIdNm
	 */
	private String projectIdNm;
		
	/**
	 * Holds projectId
	 */
	private String projectId;
	
	/**
	 * Holds projectName
	 */
	private String projectName;

	/**
	 * Holds productId
	 */
	private String productId;
	/**
	 * Holds hdWareProduct
	 */
	private String hdWareProduct;
		
	/**
	 * Holds prsId
	 */
	private String prsId;
	/**
	 * Holds prsName
	 */
	private String prsName;
	
	/**
	 * Holds crdId
	 */
	private String crsId;
	/**
	 * Holds crsName
	 */
	private String crsName;
	/**
	 * Holds shopOrder
	 */
	private String shopOrder;
	
	/**
	 * Holds workSpaceId
	 */
	private String workSpaceId;
	
	/**
	 * Holds workSpaceFldr
	 */
	private String workSpaceFldr;
	//Newly Added for Project Sumary Report
	/**
	 * Holds workSpaceFldr
	 */
	private String projectNm;
	/**
	 * Holds workSpaceFldr
	 */
	private String projectDesc;
	/**
	 * Holds saferId
	 */
	private String saferId;
	
	/**
	 * @return the cntrtNm
	 */
	public String getCntrtNm() {
		return cntrtNm;
	}
	/**
	 * @param cntrtNm the cntrtNm to set
	 */
	public void setCntrtNm(String cntrtNm) {
		this.cntrtNm = cntrtNm;
	}
	/**
	 * @return the cntrtDesc
	 */
	public String getCntrtDesc() {
		return cntrtDesc;
	}
	/**
	 * @param cntrtDesc the cntrtDesc to set
	 */
	public void setCntrtDesc(String cntrtDesc) {
		this.cntrtDesc = cntrtDesc;
	}
	/**
	 * @return the mlmplId
	 */
	public String getMlmplId() {
		return mlmplId;
	}
	/**
	 * @param mlmplId the mlmplId to set
	 */
	public void setMlmplId(String mlmplId) {
		this.mlmplId = mlmplId;
	}
	/**
	 * @return the mlmplNm
	 */
	public String getMlmplNm() {
		return mlmplNm;
	}
	/**
	 * @param mlmplNm the mlmplNm to set
	 */
	public void setMlmplNm(String mlmplNm) {
		this.mlmplNm = mlmplNm;
	}
	/**
	 * @return the geSerialNum
	 */
	public String getGeSerialNum() {
		return geSerialNum;
	}
	/**
	 * @param geSerialNum the geSerialNum to set
	 */
	public void setGeSerialNum(String geSerialNum) {
		this.geSerialNum = geSerialNum;
	}
	
	
	
	/**
	 * @return the projectId
	 */
	public String getProjectId() {
		return projectId;
	}
	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}
	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return the hdWareProduct
	 */
	public String getHdWareProduct() {
		return hdWareProduct;
	}
	/**
	 * @param hdWareProduct the hdWareProduct to set
	 */
	public void setHdWareProduct(String hdWareProduct) {
		this.hdWareProduct = hdWareProduct;
	}
	/**
	 * @return the prsId
	 */
	public String getPrsId() {
		return prsId;
	}
	/**
	 * @param prsId the prsId to set
	 */
	public void setPrsId(String prsId) {
		this.prsId = prsId;
	}
	/**
	 * @return the prsName
	 */
	public String getPrsName() {
		return prsName;
	}
	/**
	 * @param prsName the prsName to set
	 */
	public void setPrsName(String prsName) {
		this.prsName = prsName;
	}
	/**
	 * @return the crsId
	 */
	public String getCrsId() {
		return crsId;
	}
	/**
	 * @param crsId the crsId to set
	 */
	public void setCrsId(String crsId) {
		this.crsId = crsId;
	}
	/**
	 * @return the crsName
	 */
	public String getCrsName() {
		return crsName;
	}
	/**
	 * @param crsName the crsName to set
	 */
	public void setCrsName(String crsName) {
		this.crsName = crsName;
	}
	/**
	 * @return the projectIdNm
	 */
	public String getProjectIdNm() {
		return projectIdNm;
	}
	/**
	 * @param projectIdNm the projectIdNm to set
	 */
	public void setProjectIdNm(String projectIdNm) {
		this.projectIdNm = projectIdNm;
	}
	/**
	 * @return the shopOrder
	 */
	public String getShopOrder() {
		return shopOrder;
	}
	/**
	 * @param shopOrder the shopOrder to set
	 */
	public void setShopOrder(String shopOrder) {
		this.shopOrder = shopOrder;
	}
	/**
	 * @return the workSpaceId
	 */
	public String getWorkSpaceId() {
		return workSpaceId;
	}
	/**
	 * @param workSpaceId the workSpaceId to set
	 */
	public void setWorkSpaceId(String workSpaceId) {
		this.workSpaceId = workSpaceId;
	}
	/**
	 * @return the workSpaceFldr
	 */
	public String getWorkSpaceFldr() {
		return workSpaceFldr;
	}
	/**
	 * @param workSpaceFldr the workSpaceFldr to set
	 */
	public void setWorkSpaceFldr(String workSpaceFldr) {
		this.workSpaceFldr = workSpaceFldr;
	}
	/**
	 * @return the projectNm
	 */
	public String getProjectNm() {
		return projectNm;
	}
	/**
	 * @param projectNm the projectNm to set
	 */
	public void setProjectNm(String projectNm) {
		this.projectNm = projectNm;
	}
	/**
	 * @return the projectDesc
	 */
	public String getProjectDesc() {
		return projectDesc;
	}
	/**
	 * @param projectDesc the projectDesc to set
	 */
	public void setProjectDesc(String projectDesc) {
		this.projectDesc = projectDesc;
	}
	/**
	 * @return the saferId
	 */
	public String getSaferId() {
		return saferId;
	}
	/**
	 * @param saferId the saferId to set
	 */
	public void setSaferId(String saferId) {
		this.saferId = saferId;
	}
	
	
		
}
