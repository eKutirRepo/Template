/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBoilerShopBomReportData.java
 * @Creation date: 07-Mar-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;


public class PLMBoilerShopBomReportData {

	private String cntName;
	private String projectName;
	private String topLvlPart;
	private String selectedPrjName;
	private String selectedCntractName;
	private String selectedTopLvlPartName;
	private String selectedparentAssyNo;
	private String station;
	private String stationLocation;
	private String customer;
	private String unitNo;
	private String wbsNo;
	private String wbsName;
	private String parentAssyNo;
	private String itemNumber;
	private int level;
	private String partNumber;
	private String drawingRev;
	private String quantity;
	private String unitOfMeasure;
	private String matlCode;
	private String matlCodeId;
	private String productDesc;
	private String drawingNumber;
	private String partDrawingNumber;
	private String partDrawingRev;
	private String weight;
	private String remarks;
	private String item;
	private String itemName;
	private String unsNo;
	private String composition;
	private String spec;
	private String grade;
	private String purchInst;
	private String matlNotesSub;
	private String usageRemarks;
	
	private boolean contractSelctd;
	private boolean projectSelctd;
	private boolean taskSelectd;
	
	
	/**
	 * @return the selectedparentAssyNo
	 */
	public String getSelectedparentAssyNo() {
		return selectedparentAssyNo;
	}
	/**
	 * @param selectedparentAssyNo the selectedparentAssyNo to set
	 */
	public void setSelectedparentAssyNo(String selectedparentAssyNo) {
		this.selectedparentAssyNo = selectedparentAssyNo;
	}
	/**
	 * @return the partDrawingNumber
	 */
	public String getPartDrawingNumber() {
		return partDrawingNumber;
	}
	/**
	 * @param partDrawingNumber the partDrawingNumber to set
	 */
	public void setPartDrawingNumber(String partDrawingNumber) {
		this.partDrawingNumber = partDrawingNumber;
	}
	/**
	 * @return the wbsName
	 */
	public String getWbsName() {
		return wbsName;
	}
	/**
	 * @param wbsName the wbsName to set
	 */
	public void setWbsName(String wbsName) {
		this.wbsName = wbsName;
	}
	/**
	 * @return the parentAssyNo
	 */
	public String getParentAssyNo() {
		return parentAssyNo;
	}
	/**
	 * @param parentAssyNo the parentAssyNo to set
	 */
	public void setParentAssyNo(String parentAssyNo) {
		this.parentAssyNo = parentAssyNo;
	}
	/**
	 * @return the matlCode
	 */
	public String getMatlCode() {
		return matlCode;
	}
	/**
	 * @param matlCode the matlCode to set
	 */
	public void setMatlCode(String matlCode) {
		this.matlCode = matlCode;
	}
	/**
	 * @return the item
	 */
	public String getItem() {
		return item;
	}
	/**
	 * @param item the item to set
	 */
	public void setItem(String item) {
		this.item = item;
	}
	/**
	 * @return the itemName
	 */
	public String getItemName() {
		return itemName;
	}
	/**
	 * @param itemName the itemName to set
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	/**
	 * @return the unsNo
	 */
	public String getUnsNo() {
		return unsNo;
	}
	/**
	 * @param unsNo the unsNo to set
	 */
	public void setUnsNo(String unsNo) {
		this.unsNo = unsNo;
	}
	/**
	 * @return the composition
	 */
	public String getComposition() {
		return composition;
	}
	/**
	 * @param composition the composition to set
	 */
	public void setComposition(String composition) {
		this.composition = composition;
	}
	/**
	 * @return the spec
	 */
	public String getSpec() {
		return spec;
	}
	/**
	 * @param spec the spec to set
	 */
	public void setSpec(String spec) {
		this.spec = spec;
	}
	/**
	 * @return the grade
	 */
	public String getGrade() {
		return grade;
	}
	/**
	 * @param grade the grade to set
	 */
	public void setGrade(String grade) {
		this.grade = grade;
	}
	/**
	 * @return the purchInst
	 */
	public String getPurchInst() {
		return purchInst;
	}
	/**
	 * @param purchInst the purchInst to set
	 */
	public void setPurchInst(String purchInst) {
		this.purchInst = purchInst;
	}
	/**
	 * @return the matlNotesSub
	 */
	public String getMatlNotesSub() {
		return matlNotesSub;
	}
	/**
	 * @param matlNotesSub the matlNotesSub to set
	 */
	public void setMatlNotesSub(String matlNotesSub) {
		this.matlNotesSub = matlNotesSub;
	}
	/**
	 * @return the usageRemarks
	 */
	public String getUsageRemarks() {
		return usageRemarks;
	}
	/**
	 * @param usageRemarks the usageRemarks to set
	 */
	public void setUsageRemarks(String usageRemarks) {
		this.usageRemarks = usageRemarks;
	}
	/**
	 * @return the cntName
	 */
	public String getCntName() {
		return cntName;
	}
	/**
	 * @param cntName the cntName to set
	 */
	public void setCntName(String cntName) {
		this.cntName = cntName;
	}
	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}
	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	/**
	 * @return the topLvlPart
	 */
	public String getTopLvlPart() {
		return topLvlPart;
	}
	/**
	 * @param topLvlPart the topLvlPart to set
	 */
	public void setTopLvlPart(String topLvlPart) {
		this.topLvlPart = topLvlPart;
	}
	/**
	 * @return the selectedPrjName
	 */
	public String getSelectedPrjName() {
		return selectedPrjName;
	}
	/**
	 * @param selectedPrjName the selectedPrjName to set
	 */
	public void setSelectedPrjName(String selectedPrjName) {
		this.selectedPrjName = selectedPrjName;
	}
	/**
	 * @return the selectedCntractName
	 */
	public String getSelectedCntractName() {
		return selectedCntractName;
	}
	/**
	 * @param selectedCntractName the selectedCntractName to set
	 */
	public void setSelectedCntractName(String selectedCntractName) {
		this.selectedCntractName = selectedCntractName;
	}
	/**
	 * @return the selectedTopLvlPartName
	 */
	public String getSelectedTopLvlPartName() {
		return selectedTopLvlPartName;
	}
	/**
	 * @param selectedTopLvlPartName the selectedTopLvlPartName to set
	 */
	public void setSelectedTopLvlPartName(String selectedTopLvlPartName) {
		this.selectedTopLvlPartName = selectedTopLvlPartName;
	}
	/**
	 * @return the station
	 */
	public String getStation() {
		return station;
	}
	/**
	 * @param station the station to set
	 */
	public void setStation(String station) {
		this.station = station;
	}
	/**
	 * @return the stationLocation
	 */
	public String getStationLocation() {
		return stationLocation;
	}
	/**
	 * @param stationLocation the stationLocation to set
	 */
	public void setStationLocation(String stationLocation) {
		this.stationLocation = stationLocation;
	}
	/**
	 * @return the customer
	 */
	public String getCustomer() {
		return customer;
	}
	/**
	 * @param customer the customer to set
	 */
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	/**
	 * @return the unitNo
	 */
	public String getUnitNo() {
		return unitNo;
	}
	/**
	 * @param unitNo the unitNo to set
	 */
	public void setUnitNo(String unitNo) {
		this.unitNo = unitNo;
	}
	/**
	 * @return the wbsNo
	 */
	public String getWbsNo() {
		return wbsNo;
	}
	/**
	 * @param wbsNo the wbsNo to set
	 */
	public void setWbsNo(String wbsNo) {
		this.wbsNo = wbsNo;
	}
	/**
	 * @return the productDesc
	 */
	public String getProductDesc() {
		return productDesc;
	}
	/**
	 * @param productDesc the productDesc to set
	 */
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	/**
	 * @return the drawingNumber
	 */
	public String getDrawingNumber() {
		return drawingNumber;
	}
	/**
	 * @param drawingNumber the drawingNumber to set
	 */
	public void setDrawingNumber(String drawingNumber) {
		this.drawingNumber = drawingNumber;
	}
	/**
	 * @return the drawingRev
	 */
	public String getDrawingRev() {
		return drawingRev;
	}
	/**
	 * @param drawingRev the drawingRev to set
	 */
	public void setDrawingRev(String drawingRev) {
		this.drawingRev = drawingRev;
	}
	/**
	 * @return the itemNumber
	 */
	public String getItemNumber() {
		return itemNumber;
	}
	/**
	 * @param itemNumber the itemNumber to set
	 */
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	/**
	 * @return the level
	 */
	public int getLevel() {
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(int level) {
		this.level = level;
	}
	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}
	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	/**
	 * @return the quantity
	 */
	public String getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return the unitOfMeasure
	 */
	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}
	/**
	 * @param unitOfMeasure the unitOfMeasure to set
	 */
	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}
	
	/**
	 * @return the weight
	 */
	public String getWeight() {
		return weight;
	}
	/**
	 * @param weight the weight to set
	 */
	public void setWeight(String weight) {
		this.weight = weight;
	}
	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}
	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	/**
	 * @return
	 */
	public boolean isContractSelctd() {
		return contractSelctd;
	}
	/**
	 * @param contractSelctd
	 */
	public void setContractSelctd(boolean contractSelctd) {
		this.contractSelctd = contractSelctd;
	}
	/**
	 * @return
	 */
	public boolean isProjectSelctd() {
		return projectSelctd;
	}
	/**
	 * @param projectSelctd
	 */
	public void setProjectSelctd(boolean projectSelctd) {
		this.projectSelctd = projectSelctd;
	}
	/**
	 * @return
	 */
	public boolean isTaskSelectd() {
		return taskSelectd;
	}
	/**
	 * @param taskSelectd
	 */
	public void setTaskSelectd(boolean taskSelectd) {
		this.taskSelectd = taskSelectd;
	}
	/**
	 * @return
	 */
	public String getMatlCodeId() {
		return matlCodeId;
	}
	/**
	 * @param matlCodeId
	 */
	public void setMatlCodeId(String matlCodeId) {
		this.matlCodeId = matlCodeId;
	}
	/**
	 * @return
	 */
	public String getPartDrawingRev() {
		return partDrawingRev;
	}
	/**
	 * @param partDrawingRev
	 */
	public void setPartDrawingRev(String partDrawingRev) {
		this.partDrawingRev = partDrawingRev;
	}
	
	
}
