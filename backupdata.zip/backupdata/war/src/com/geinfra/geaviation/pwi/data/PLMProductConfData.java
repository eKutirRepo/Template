/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMProductConfData.java
 * @Creation date: 11-April-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.List;

public class PLMProductConfData {

	/**
	  * Holds the allOpenPrdCnf
	  */
	private boolean allOpenPrdCnf;
	/**
	  * Holds the selPrdConfList
	  */
	 private List<String> selPrdConfList;
		/**
	  * Holds the cfname
	  */
   
	 private String cfnameCns;
		/**
	  * Holds the cfdesc
	  */
	 private String cfdesc;
		/**
	  * Holds the coname
	  */
	 private String conameCns;
		/**
	  * Holds the codesc
	  */
	 private String codescPcnf;
		/**
	  * Holds the cfseqorder
	  */
	 private String cfseqorder;
		/**
	  * Holds the seqorder
	  */
	 private String seqorder;
		/**
	  * Holds the coseqorder
	  */
	private String coseqorder;
	/**
	  * Holds the crid
	  */
	 private String crIdCns;
		/**
	  * Holds the crtitle
	  */
	 private String crTitleCns;
		/**
	  * Holds the crdesc
	  */
	 private String crDescCns;
		/**
	  * Holds the level
	  */
	 private String level;
		/**
	  * Holds the cfId
	  */
	 private String cfId;
		/**
	  * Holds the coId
	  */
	 private String coId;
		/**
	  * Holds the custId
	  */
	 private String custId;
	/**
	 * @return the allOpenPrdCnf
	 */
	public boolean isAllOpenPrdCnf() {
		return allOpenPrdCnf;
	}
	/**
	 * @param allOpenPrdCnf the allOpenPrdCnf to set
	 */
	public void setAllOpenPrdCnf(boolean allOpenPrdCnf) {
		this.allOpenPrdCnf = allOpenPrdCnf;
	}
	/**
	 * @return the selPrdConfList
	 */
	public List<String> getSelPrdConfList() {
		return selPrdConfList;
	}
	/**
	 * @param selPrdConfList the selPrdConfList to set
	 */
	public void setSelPrdConfList(List<String> selPrdConfList) {
		this.selPrdConfList = selPrdConfList;
	}
	
	/**
	 * @return the cfnameCns
	 */
	public String getCfnameCns() {
		return cfnameCns;
	}
	/**
	 * @param cfnameCns the cfnameCns to set
	 */
	public void setCfnameCns(String cfnameCns) {
		this.cfnameCns = cfnameCns;
	}
	/**
	 * @return the cfname
	 */
	/*public String getCfname() {
		return cfname;
	}*/
	/**
	 * @param cfname the cfname to set
	 */
	/*public void setCfname(String cfname) {
		this.cfname = cfname;
	}*/
	/**
	 * @return the cfdesc
	 */
	public String getCfdesc() {
		return cfdesc;
	}
	/**
	 * @param cfdesc the cfdesc to set
	 */
	public void setCfdesc(String cfdesc) {
		this.cfdesc = cfdesc;
	}
	/**
	 * @return the coname
	 */
	public String getConameCns() {
		return conameCns;
	}
	/**
	 * @param coname the coname to set
	 */
	public void setConameCns(String conameCns) {
		this.conameCns = conameCns;
	}
	
	/**
	 * @return the codescPcnf
	 */
	public String getCodescPcnf() {
		return codescPcnf;
	}
	/**
	 * @param codescPcnf the codescPcnf to set
	 */
	public void setCodescPcnf(String codescPcnf) {
		this.codescPcnf = codescPcnf;
	}
	
	/**
	 * @return the crIdCns
	 */
	public String getCrIdCns() {
		return crIdCns;
	}
	/**
	 * @param crIdCns the crIdCns to set
	 */
	public void setCrIdCns(String crIdCns) {
		this.crIdCns = crIdCns;
	}
	/**
	 * @return the crid
	 */
	/*public String getCrid() {
		return crid;
	}*/
	/**
	 * @param crid the crid to set
	 */
	/*public void setCrid(String crid) {
		this.crid = crid;
	}*/
	/**
	 * @return the crtitle
	 */
	/*public String getCrtitle() {
		return crtitle;
	}*/
	/**
	 * @param crtitle the crtitle to set
	 */
	/*public void setCrtitle(String crtitle) {
		this.crtitle = crtitle;
	}*/
	
	/**
	 * @return the crTitleCns
	 */
	public String getCrTitleCns() {
		return crTitleCns;
	}
	/**
	 * @param crTitleCns the crTitleCns to set
	 */
	public void setCrTitleCns(String crTitleCns) {
		this.crTitleCns = crTitleCns;
	}
	/**
	 * @return the crDescCns
	 */
	public String getCrDescCns() {
		return crDescCns;
	}
	/**
	 * @param crDescCns the crDescCns to set
	 */
	public void setCrDescCns(String crDescCns) {
		this.crDescCns = crDescCns;
	}
	/**
	 * @return the crdesc
	 */
	/*public String getCrdesc() {
		return crdesc;
	}*/
	/**
	 * @param crdesc the crdesc to set
	 */
	/*public void setCrdesc(String crdesc) {
		this.crdesc = crdesc;
	}*/
	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}
	/**
	 * @return the cfId
	 */
	public String getCfId() {
		return cfId;
	}
	/**
	 * @param cfId the cfId to set
	 */
	public void setCfId(String cfId) {
		this.cfId = cfId;
	}
	/**
	 * @return the coId
	 */
	public String getCoId() {
		return coId;
	}
	/**
	 * @param coId the coId to set
	 */
	public void setCoId(String coId) {
		this.coId = coId;
	}
	/**
	 * @return the custId
	 */
	public String getCustId() {
		return custId;
	}
	/**
	 * @param custId the custId to set
	 */
	public void setCustId(String custId) {
		this.custId = custId;
	}
	/**
	 * @return the seqorder
	 */
	public String getSeqorder() {
		return seqorder;
	}
	/**
	 * @param seqorder the seqorder to set
	 */
	public void setSeqorder(String seqorder) {
		this.seqorder = seqorder;
	}
	 /**
	 * @return the cfseqorder
	 */
	public String getCfseqorder() {
		return cfseqorder;
	}
	/**
	 * @param cfseqorder the cfseqorder to set
	 */
	public void setCfseqorder(String cfseqorder) {
		this.cfseqorder = cfseqorder;
	}
	/**
	 * @return the coseqorder
	 */
	public String getCoseqorder() {
		return coseqorder;
	}
	/**
	 * @param coseqorder the coseqorder to set
	 */
	public void setCoseqorder(String coseqorder) {
		this.coseqorder = coseqorder;
	}	 
	 
}
