/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhereUsedReqData.java
 * @Creation date: 10-March-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.data;

import java.util.Date;
import java.util.List;

public class PLMWhereUsedReqData {
	/**
	  * Holds the requirementName
	  */
 private String requirementName;
	/**
  * Holds the userSerialNumber
  */
 private String userSerialNumber;
	/**
  * Holds the contractStartDate
  */
 private Date contractStartDate;
	/**
  * Holds the contractEndDate
  */
 private Date contractEndDate;
	/**
  * Holds the fmissueStrDate
  */
 private Date fmissueStrDate;
	/**
  * Holds the fmissueEndDate
  */
 private Date fmissueEndDate;
	/**
  * Holds the frame
  */
 
 private String frame;
	/**
  * Holds the frameTypeList
  */
 private List<String> frameTypeList;
	/**
  * Holds the selframeList
  */
 private String selFrameListDb;
	/**
  * Holds the program
  */
 private String program;
	/**
  * Holds the contract
  */
 private String contract;
	/**
  * Holds the contractDesc
  */
 private String contractDesc;
	/**
  * Holds the contractStrDt
  */
 private String contractStrDt;
	/**
  * Holds the clin
  */
 private String clin;
	/**
  * Holds the ciDesc
  */
 private String ciDesc;
	/**
  * Holds the frameType
  */
 private String frameType;
	/**
  * Holds the fmiIssuDt
  */
 private String fmiIssuDt;
	/**
  * Holds the build
  */
 private String build;
	/**
  * Holds the unitSerialNum
  */
  private String unitSerialNum;
	/**
	  * Holds the projectName
	  */
 private String projectName;
	/**
  * Holds the projectDesc
  */
 private String projectDesc;
	/**
  * Holds the projectState
  */
 private String projectState;
	/**
  * Holds the requireName
  */
 private String requireName;
	/**
  * Holds the requireRev
  */
 private String requireRev;
	/**
  * Holds the requireType
  */
 private String requireType;
	/**
  * Holds the prsName
  */
 private String prsName;
	/**
  * Holds the prsRev
  */
 private String prsRev;
	/**
  * Holds the prsType
  */

 private String prsType;
	/**
	 * Holds the reqDesc
	 */
 private String reqDesc;
	
 private String salesOrder;
 
/**
 * @return the requirementName
 */
public String getRequirementName() {
	return requirementName;
}
/**
 * @param requirementName the requirementName to set
 */
public void setRequirementName(String requirementName) {
	this.requirementName = requirementName;
}
/**
 * @return the userSerialNumber
 */
public String getUserSerialNumber() {
	return userSerialNumber;
}
/**
 * @param userSerialNumber the userSerialNumber to set
 */
public void setUserSerialNumber(String userSerialNumber) {
	this.userSerialNumber = userSerialNumber;
}
/**
 * @return the contractStartDate
 */
public Date getContractStartDate() {
	Date contractStrtdt = contractStartDate;
	return contractStrtdt;
}
/**
 * @param contractStartDate the contractStartDate to set
 */
public void setContractStartDate(Date contractStartDate) {
	Date contractStrtdt = contractStartDate;
	this.contractStartDate = contractStrtdt;
}
/**
 * @return the contractEndDate
 */
public Date getContractEndDate() {
	Date contractEnddt = contractEndDate;
	return contractEnddt;
}
/**
 * @param contractEndDate the contractEndDate to set
 */
public void setContractEndDate(Date contractEndDate) {
	Date contractEnddt = contractEndDate;
	this.contractEndDate = contractEnddt;
}
/**
 * @return the fmissueStrDate
 */
public Date getFmissueStrDate() {
	Date fmissueStrDt = fmissueStrDate;
	return fmissueStrDt;
}
/**
 * @param fmissueStrDate the fmissueStrDate to set
 */
public void setFmissueStrDate(Date fmissueStrDate) {
	Date fmissueStrDt = fmissueStrDate;
	this.fmissueStrDate = fmissueStrDt;
}
/**
 * @return the fmissueEndDate
 */
public Date getFmissueEndDate() {
	Date fmissueEndDt = fmissueEndDate;
	return fmissueEndDt;
}
/**
 * @param fmissueEndDate the fmissueEndDate to set
 */
public void setFmissueEndDate(Date fmissueEndDate) {
	Date fmissueEndDt = fmissueEndDate;
	this.fmissueEndDate = fmissueEndDt;
}
/**
 * @return the frame
 */
public String getFrame() {
	return frame;
}
/**
 * @param frame the frame to set
 */
public void setFrame(String frame) {
	this.frame = frame;
}
/**
 * @return the frameTypeList
 */
public List<String> getFrameTypeList() {
	return frameTypeList;
}
/**
 * @param frameTypeList the frameTypeList to set
 */
public void setFrameTypeList(List<String> frameTypeList) {
	this.frameTypeList = frameTypeList;
}

/**
 * @return the selFrameListDb
 */
public String getSelFrameListDb() {
	return selFrameListDb;
}
/**
 * @param selFrameListDb the selFrameListDb to set
 */
public void setSelFrameListDb(String selFrameListDb) {
	this.selFrameListDb = selFrameListDb;
}
/**
 * @return the selframeList
 */
/*public String getSelframeList() {
	return selframeList;
}*/
/**
 * @param selframeList the selframeList to set
 */
/*public void setSelframeList(String selframeList) {
	this.selframeList = selframeList;
}*/
/**
 * @return the program
 */
public String getProgram() {
	return program;
}
/**
 * @param program the program to set
 */
public void setProgram(String program) {
	this.program = program;
}
/**
 * @return the contract
 */
public String getContract() {
	return contract;
}
/**
 * @param contract the contract to set
 */
public void setContract(String contract) {
	this.contract = contract;
}
/**
 * @return the contractDesc
 */
public String getContractDesc() {
	return contractDesc;
}
/**
 * @param contractDesc the contractDesc to set
 */
public void setContractDesc(String contractDesc) {
	this.contractDesc = contractDesc;
}
/**
 * @return the contractStrDt
 */
public String getContractStrDt() {
	return contractStrDt;
}
/**
 * @param contractStrDt the contractStrDt to set
 */
public void setContractStrDt(String contractStrDt) {
	this.contractStrDt = contractStrDt;
}
/**
 * @return the clin
 */
public String getClin() {
	return clin;
}
/**
 * @param clin the clin to set
 */
public void setClin(String clin) {
	this.clin = clin;
}
/**
 * @return the ciDesc
 */
public String getCiDesc() {
	return ciDesc;
}
/**
 * @param ciDesc the ciDesc to set
 */
public void setCiDesc(String ciDesc) {
	this.ciDesc = ciDesc;
}
/**
 * @return the frameType
 */
public String getFrameType() {
	return frameType;
}
/**
 * @param frameType the frameType to set
 */
public void setFrameType(String frameType) {
	this.frameType = frameType;
}
/**
 * @return the fmiIssuDt
 */
public String getFmiIssuDt() {
	return fmiIssuDt;
}
/**
 * @param fmiIssuDt the fmiIssuDt to set
 */
public void setFmiIssuDt(String fmiIssuDt) {
	this.fmiIssuDt = fmiIssuDt;
}
/**
 * @return the build
 */
public String getBuild() {
	return build;
}
/**
 * @param build the build to set
 */
public void setBuild(String build) {
	this.build = build;
}
/**
 * @return the unitSerialNum
 */
public String getUnitSerialNum() {
	return unitSerialNum;
}
/**
 * @param unitSerialNum the unitSerialNum to set
 */
public void setUnitSerialNum(String unitSerialNum) {
	this.unitSerialNum = unitSerialNum;
}
/**
 * @return the projectName
 */
public String getProjectName() {
	return projectName;
}
/**
 * @param projectName the projectName to set
 */
public void setProjectName(String projectName) {
	this.projectName = projectName;
}
/**
 * @return the projectDesc
 */
public String getProjectDesc() {
	return projectDesc;
}
/**
 * @param projectDesc the projectDesc to set
 */
public void setProjectDesc(String projectDesc) {
	this.projectDesc = projectDesc;
}
/**
 * @return the projectState
 */
public String getProjectState() {
	return projectState;
}
/**
 * @param projectState the projectState to set
 */
public void setProjectState(String projectState) {
	this.projectState = projectState;
}
/**
 * @return the requireName
 */
public String getRequireName() {
	return requireName;
}
/**
 * @param requireName the requireName to set
 */
public void setRequireName(String requireName) {
	this.requireName = requireName;
}
/**
 * @return the requireRev
 */
public String getRequireRev() {
	return requireRev;
}
/**
 * @param requireRev the requireRev to set
 */
public void setRequireRev(String requireRev) {
	this.requireRev = requireRev;
}
/**
 * @return the requireType
 */
public String getRequireType() {
	return requireType;
}
/**
 * @param requireType the requireType to set
 */
public void setRequireType(String requireType) {
	this.requireType = requireType;
}
/**
 * @return the prsName
 */
public String getPrsName() {
	return prsName;
}
/**
 * @param prsName the prsName to set
 */
public void setPrsName(String prsName) {
	this.prsName = prsName;
}
/**
 * @return the prsRev
 */
public String getPrsRev() {
	return prsRev;
}
/**
 * @param prsRev the prsRev to set
 */
public void setPrsRev(String prsRev) {
	this.prsRev = prsRev;
}
/**
 * @return the prsType
 */
public String getPrsType() {
	return prsType;
}
/**
 * @param prsType the prsType to set
 */
public void setPrsType(String prsType) {
	this.prsType = prsType;
}
/**
 * @return the reqDesc
 */
public String getReqDesc() {
	return reqDesc;
}
/**
 * @param reqDesc the reqDesc to set
 */
public void setReqDesc(String reqDesc) {
	this.reqDesc = reqDesc;
}
 /**
 * @return
 */
public String getSalesOrder() {
	return salesOrder;
}
/**
 * @param salesOrder
 */
public void setSalesOrder(String salesOrder) {
	this.salesOrder = salesOrder;
}
 
}
