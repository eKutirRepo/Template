/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMMessageData.java
 * @Creation date: 11-Sept-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PLMMessageData {

	
	// PROPERTIES *************************************************************
	
	/**
	 * GEEDW_PLM_ODS_BULK_V.MT_PLM_KPI_TASK.PROJECT_NAME
	 */
	private String projectName;
	
	/**
	 * GEEDW_PLM_ODS_BULK_V.MT_PLM_KPI_TASK.TASK_NAME
	 */
	private String taskName;
	
	/**
	 * GEEDW_PLM_ODS_BULK_V.CDR_ODS_T_MESSAGE.ID 
	 */
	private String id;	
	/**
	 * GEEDW_PLM_ODS_BULK_V.CDR_ODS_T_MESSAGE.NM 
	 */
	private String name;
	
	/**
	 * GEEDW_PLM_ODS_BULK_V.CDR_ODS_T_MESSAGE.SUBJECT
	 */
	private String subject;

	/**
	 * GEEDW_PLM_ODS_BULK_V.CDR_ODS_T_MESSAGE.DESCRIPTION
	 */
	private String description;
	
	/**
	 * GEEDW_PLM_ODS_BULK_V.CDR_ODS_T_MESSAGE.SOURCE_ORIGINATED_DATE
	 */
	private String date;

	/**
	 * GEEDW_PLM_ODS_BULK_V.CDR_ODS_T_MESSAGE.OWNR
	 */
	private String ownerSSO;
	
	/**
	 * GEEDW_PLM_ODS_BULK_V.CDR_ODS_T_PERSON.LAST_NM + ", " + 
	 * GEEDW_PLM_ODS_BULK_V.CDR_ODS_T_PERSON.FIRST_NM
	 */
	private String ownerName;
	
	/**
	 * GEEDW_PLM_ODS_BULK_V.CDR_ODS_T_PERSON.EMAIL_ADDR 
	 */
	private String ownerMail;
	
	
	// CONSTRUCTOR ************************************************************

	/**
	 * Creates a new instance of the class Message
	 * 
	 * @param projectName(String)
	 * @param taskName(String)
	 * @param id(String)
	 * @param name(String)
	 * @param subject(String)
	 * @param description(String)
	 * @param date(Date)
	 * @param ownerSSO(String)
	 * @param ownerLastName (String)
	 * @param ownerFirstName (String)
	 * @param ownerMail(String)
	 */
	public PLMMessageData (String projectName, String taskName, String id, String name, 
			String subject, String description, String date, String ownerSSO,
			String ownerLastName, String ownerFirstName, 
			String ownerMail) {  

		String dateLcl = date;
		if (dateLcl != null) {
			try{
				Date msg_date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S").parse(dateLcl);
				dateLcl = new SimpleDateFormat("MMM dd, yyyy", Locale.US).format(msg_date);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		
		this.projectName = projectName;
		this.taskName = taskName;
		this.id = id;
		this.name = name;
		this.subject = subject;
		this.description = description;
		this.date = dateLcl;
		this.ownerSSO = ownerSSO;		
		this.ownerName = ownerLastName + ", " + ownerFirstName;
		this.ownerMail = ownerMail;
	}
	
	// PUBLIC METHODS *********************************************************
	
	/**
	 * Returns a list of strings with the information of the Message object
	 * 
	 * @return messageInfo (List<String>)
	 */
	public List<Object> getMessageInfoList() {
		List<Object> messageInfo = new ArrayList<Object>();
		
		messageInfo.add((projectName == null)? "" : projectName);
		messageInfo.add((taskName == null)? "" : taskName);
		messageInfo.add((id == null)? "" : id);
		messageInfo.add((name == null)? "" : name);
		messageInfo.add((subject == null)? "" : subject);
		messageInfo.add((description == null)? "" : description);
		messageInfo.add((date == null)? "" : date);
		messageInfo.add((ownerSSO == null)? "" : ownerSSO);
		messageInfo.add((ownerName == null)? "" : ownerName);
		messageInfo.add((ownerMail == null)? "" : ownerMail);

		return messageInfo;
	}
	
	// ACCESSOR METHODS *******************************************************

	/**
	 * Returns the projectName
	 * 
	 * @return projectName (String)
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * Returns the taskName
	 * 
	 * @return taskName (String)
	 */
	public String getTaskName() {
		return taskName;
	}

	/**
	 * @return Returns the id.
	 */
	public String getId() {
		return id;
	}
	/**
	 * @return Returns the name.
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return Returns the description.
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * @return Returns the date.
	 */
	public String getDate() {
		return date;
	}	
	
	/**
	 * @return Returns the ownerMail.
	 */
	public String getOwnerMail() {
		return ownerMail;
	}

	/**
	 * @return Returns the ownerName.
	 */
	public String getOwnerName() {
		return ownerName;
	}

	/**
	 * @return Returns the ownerSSO.
	 */
	public String getOwnerSSO() {
		return ownerSSO;
	}

	/**
	 * @return Returns the subject.
	 */
	public String getSubject() {
		return subject;
	}
	
	// OVERRIDEN METHODS ******************************************************

	/**
	 * Returns the message information as a string
	 * 
	 * @return messageStr (String)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer messageStr = new StringBuffer();

		messageStr.append(projectName).append(" ")
					.append(name).append(" ")
					.append(description).append(" ")
					.append(date).append(" ");
		
		return messageStr.toString();
	}


	
}
