/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMAdminDaoIfc.java
 * @Creation date: 18-Aug-2009
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMAdminData;
import com.geinfra.geaviation.pwi.data.PLMAdminReportsData;
import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.data.PLMReportData;
import com.geinfra.geaviation.pwi.data.PLMRequestData;
import com.geinfra.geaviation.pwi.data.PLMSecurityMatrixData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;


/**
 * PLMAdminDaoIfc is the DAO interface used for PLM Administrator Menu.
 */
public interface PLMAdminDaoIfc {
	/**
	 * This method is used to get List Of Reports
	 * 
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMAdminData> getListOfReports() throws PLMCommonException;

	/**
	 * This method is used to get Reports Data
	 * 
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMAdminReportsData> getReportNames() throws PLMCommonException;

	/**
	 * This method is used to add Reports Data
	 * @param reportData, sso_id
	 * @return String
	 * @throws PLMCommonException
	 */
	public String addReportData(PLMAdminReportsData reportData, String sso_id)
			throws PLMCommonException;

	/**
	 * This method is used to modify Reports Data
	 * @param reportData, oldReportName, sso_id
	 * @return String
	 * @throws PLMCommonException
	 */
	public String modifyReportData(PLMAdminReportsData reportData, 
			String oldReportName, String sso_id) throws PLMCommonException;

	/**
	 * This method is used to delete Reports Name
	 * @param reportData
	 * @return String
	 * @throws PLMCommonException
	 */
	public String deleteReportData(String reportData) throws PLMCommonException;
	/**
	 * This method is used to validate new user details
	 * 
	 * @param userSSO
	 * @return PLMLoginData
	 * @throws PLMCommonException
	 */
	public PLMLoginData validateUserDetails(String userSSO)
			throws PLMCommonException;

	/**
	 * This method is used to fetch User Groups
	 * @param userSSO
	 * @return
	 * @throws PLMCommonException
	 */
	public List<SelectItem> fetchUserGroups(String userSSO)
			throws PLMCommonException;

	/**
	 *  This method is used to get Permission Details
	 * @param userGrp
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMLoginData> getPermissionDetails(String userGrp)
			throws PLMCommonException;

	/**
	 * This method is used to add System Log Event
	 * @param userSSO
	 * @param event
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean addSystemLogEvent(String userSSO, String event)
			throws PLMCommonException;

	/**
	 * This method is used to get App Details
	 * @return PLMRequestData
	 * @throws PLMCommonException
	 */
	public PLMRequestData getAppDetails() throws PLMCommonException;

	/**
	 * This method is used to request NewUser
	 * @return PLMRequestData
	 * @throws PLMCommonException
	 */
	public PLMRequestData requestNewUser() throws PLMCommonException;

	/**
	 * This method is used to save NewUser Request
	 * @return Map<String, List<String>>
	 * @param requestData
	 * @param isPwiUser 
	 * @throws PLMCommonException
	 */
	public Map<String, List<String>> saveNewUserRequest(PLMRequestData requestData, boolean isPwiUser)
			throws PLMCommonException;

	/**
	 * This method is used to get Changed Details
	 * @return PLMRequestData
	 * @param selectedVal
	 * @throws PLMCommonException
	 */
	public PLMRequestData getChangedDetails(String selectedVal)
			throws PLMCommonException;

	/**
	 * This method is used to save the Maintain WS details
	 * 
	 * @param requestData
	 * @throws PLMCommonException
	 */
	public void saveIcmDetails(PLMRequestData requestData)
			throws PLMCommonException;

	/**
	 * This method is used to save the Maintain WS details
	 * 
	 * @param requestData
	 * @throws PLMCommonException
	 */
	public void saveAppDetails(PLMRequestData requestData)
			throws PLMCommonException;

	/**
	 * This method is used to save the Maintain WS details
	 * 
	 * @param requestData
	 * @throws PLMCommonException
	 */
	public void saveAncmtDetails(String maitnAnnouncements)
			throws PLMCommonException;

	
	/**
	 *  This method is used to get System Log Contents
	 * @param beginDate
	 * @param endDate
	 * @return java.util.List
	 */
	public List<PLMReportData> getSysLogContents(String beginDate,
			String endDate) throws PLMCommonException;

	/**
	 * This method is used to get List Of Groups
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMAdminData> getListOfGroups() throws PLMCommonException;
	
		
	
	/**
	 * This method is used to get List Of User Groups
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getListOfUserGroups() throws PLMCommonException;

	/**
	 * This method is used to get User List
	 * @param groupID
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMLoginData> getUserList(String groupID)
			throws PLMCommonException;

	/**
	 * This method is used to modify User
	 * @param ssoID
	 * @return PLMLoginData
	 * @throws PLMCommonException
	 */
	public PLMLoginData modifyUser(String ssoID) throws PLMCommonException;

	/**
	 * This method is used to add User
	 * @return PLMLoginData
	 * @throws PLMCommonException
	 */
	public PLMLoginData addUser() throws PLMCommonException;

	/**
	 * This method is used to update User
	 * @param userDetails, selectedPersons, loggedUser, flag
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean updateUser(PLMLoginData userDetails,
			List<String> selectedPersons, String loggedUser, boolean flag)
			throws PLMCommonException;

	/**
	 * This method is used to Add User
	 * @param userDetails, loggedUser
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean userAdd(PLMLoginData userDetails, String loggedUser)
			throws PLMCommonException;

	/**
	 * This method is used to delete User
	 * @param ssoID
	 * @param groupID
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean deleteUser(List<String> ssoID, String groupID)
			throws PLMCommonException;

	/**
	 * This method is used to get Group Permissions
	 * @param gruopId
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMSecurityMatrixData> getGroupPermissions(String gruopId)
			throws PLMCommonException;

	/**
	 * This method is used to add Group
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMSecurityMatrixData> addGroup() throws PLMCommonException;

	/**
	 * This method is used to delete Group
	 * @param groupID
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean deleteGroup(String groupID) throws PLMCommonException;

	/**
	 * This method is used to update Group
	 * @param groupName
	 * @param groupDesc
	 * @param securityData
	 * @param grpFlag
	 * @param userSSo
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean updateGroup(String groupName, String groupDesc,
			ArrayList<PLMSecurityMatrixData> securityData, String grpFlag,
			String userSSo) throws PLMCommonException;

	/**
	 * This method is used to Add Group
	 * @param groupName
	 * @param groupDesc
	 * @param securityData
	 * @param grpFlag
	 * @param userSSo
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean groupAdd(String groupName, String groupDesc,
			ArrayList<PLMSecurityMatrixData> securityData, String grpFlag,
			String userSSo) throws PLMCommonException;

	/**
	 * This method is used to search User
	 * @param searchSso
	 * @param searchFname
	 * @param searchLname
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMLoginData> searchUser(String searchSso, String searchFname,
			String searchLname, String groupId, String status)
			throws PLMCommonException;
	
	/**
	 * This method is used to fetch the IDM Person Master Information
	 * 
	 * @param ssoID
	 * @return
	 * @throws PLMCommonException
	 */
	public PLMLoginData fetchIDMData(String ssoID)throws PLMCommonException;
	
	/**
	 * Grant Auto Access _Search and Read Only Groups - Thread Logic to be used here 
	 * 
	 * @param requestData
	 * @throws PLMCommonException
	 */
	public void grantAutoAccess(PLMRequestData requestData, String groupIdReq) throws PLMCommonException;

}
