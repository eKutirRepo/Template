/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBoilerShippingBomReportServiceImpl.java
 * @Creation date: 21-Feb-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.service;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.dao.PLMBoilerShippingBomReportDaoIfc;
import com.geinfra.geaviation.pwi.data.PLMBoilerShipBomReportData;
import com.geinfra.geaviation.pwi.data.PLMBoilerShopBomReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public class PLMBoilerShippingBomReportServiceImpl implements PLMBoilerShippingBomReportServiceIfc{
	/**
	 * Holds the PLMBoilerReportDaoIfc plmBoilerReportDao
	 */
	private PLMBoilerShippingBomReportDaoIfc plmBoilerShippingBomReportDao = null;
	
	
	/**
	 * @return the plmBoilerShippingBomReportDao
	 */
	public PLMBoilerShippingBomReportDaoIfc getPlmBoilerShippingBomReportDao() {
		return plmBoilerShippingBomReportDao;
	}


	/**
	 * @param plmBoilerShippingBomReportDao the plmBoilerShippingBomReportDao to set
	 */
	public void setPlmBoilerShippingBomReportDao(
			PLMBoilerShippingBomReportDaoIfc plmBoilerShippingBomReportDao) {
		this.plmBoilerShippingBomReportDao = plmBoilerShippingBomReportDao;
	}


	/**
	 * This method is used to get Project and Task Name
	 * 
	 * @param 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getProjectNameAndContractNameList() throws PLMCommonException {
		return  plmBoilerShippingBomReportDao.getProjectNameAndContractNameList();
	}

	/**
	 * This method is  fetchProjectList for contracts
	 * 
	 * @param 
	 * @return list
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerShipBomReportData> fetchProjectList(String selShipBomCntractName) throws PLMCommonException {
		return plmBoilerShippingBomReportDao.fetchProjectList(selShipBomCntractName);
	}

	/**
	 * This method is fetchTasktList for projects
	 * 
	 * @param 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerShipBomReportData> fetchTasktList(List<String> selShipBomProjectName,List<SelectItem> projectList,boolean allOpenPrjName) throws PLMCommonException {
		return plmBoilerShippingBomReportDao.fetchTasktList(selShipBomProjectName,projectList,allOpenPrjName);
	}


	/**
	 * This method is generateShippingBomAppReport 
	 * 
	 * @param List<String> selShipBomCntractName
	 * @param boolean allOpenContractName
	 * @param List<String> selShipBomProjectName
	 * @param boolean allOpenPrjName
	 * @param List<String> selShipBomTopLvlPartName
	 * @param boolean allOpenTopLvlPart
	 * @param showDocRev
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerShipBomReportData> generateShippingBomAppReport(
			String selShipBomCntractName, boolean allOpenContractName,
			List<String> selShipBomProjectName, boolean allOpenPrjName,
			List<String> selShipBomTopLvlPartName, boolean allOpenTopLvlPart,List<SelectItem>projectList,List<SelectItem>taskList, boolean showDocRev)
			throws PLMCommonException {
		return plmBoilerShippingBomReportDao.generateShippingBomAppReport(selShipBomCntractName,allOpenContractName,selShipBomProjectName,allOpenPrjName,selShipBomTopLvlPartName,allOpenTopLvlPart
				,projectList,taskList, showDocRev);
	}
	
	//Added for Customer BOM Report
	/**
	 * This method is used to generate report
	 * @param selContractNm
	 * @param selProjectList
	 * @param allOpenPrjName
	 * @param selTaskName
	 * @param allAssyNo
	 * @param selPartAssmblyNum
	 * @param showPartRev
	 * @param showDocRev
	 * @return
	 */
	public List<PLMBoilerShipBomReportData> getCustomerBOMRptData(
			String selContractNm,List<String> selProjectList, 
			boolean allOpenPrjName,String selTaskName, boolean allAssyNo, List<String> selPartAssmblyNumList,
			boolean showPartRev, boolean showDocRev) throws PLMCommonException{
		return plmBoilerShippingBomReportDao.getCustomerBOMRptData(selContractNm,selProjectList, 
				allOpenPrjName,selTaskName,allAssyNo, selPartAssmblyNumList, showPartRev, showDocRev);
	}

	//Added for Shop BOM Report
	/**
	 * @param selShipBomCntractName
	 * @param allOpenContractName
	 * @param selShipBomProjectName
	 * @param allOpenPrjName
	 * @param selShipBomTopLvlPartName
	 * @param allOpenTopLvlPart
	 * @param selShipBomParentAssyNo
	 * @param allOpenParentAssy
	 * @param showPartRev
	 * @param showDocRev
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerShopBomReportData> getShopBomHeaderSectionDataList(
			String selShipBomCntractName, boolean allOpenContractName,
			List<String> selShipBomProjectName, boolean allOpenPrjName,
			String selShipBomTopLvlPartName, boolean allOpenTopLvlPart,List<String> selShipBomParentAssyNo, boolean allOpenParentAssy,
			boolean showPartRev, boolean showDocRev) throws PLMCommonException {
		return plmBoilerShippingBomReportDao.getShopBomHeaderSectionDataList(selShipBomCntractName,allOpenContractName,selShipBomProjectName,allOpenPrjName,selShipBomTopLvlPartName,allOpenTopLvlPart
				,selShipBomParentAssyNo,allOpenParentAssy,showPartRev, showDocRev);
	}


	/**
	 * This method is getShopBomMaterialSectionDataList 
	 * 
	 * @param List<String> matlCodeList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerShopBomReportData> getShopBomMaterialSectionDataList(
			List<String> matlCodeList) throws PLMCommonException {
		return plmBoilerShippingBomReportDao.getShopBomMaterialSectionDataList(matlCodeList);
	}
	
	/**
	 * This method is used to fetch Part Assembly Numbers
	 * @param taskName
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerShipBomReportData> fetchPartAssemblyNumList(String selContractNm,List<String> selProjectList, 
			boolean allOpenPrjName, String selTaskName) throws PLMCommonException{
		return plmBoilerShippingBomReportDao.fetchPartAssemblyNumList(selContractNm, selProjectList, allOpenPrjName, selTaskName);
	}


	@Override
	public List<SelectItem> contractFamilyAutocomplete(String contract)
			throws PLMCommonException {
		return plmBoilerShippingBomReportDao.contractFamilyAutocomplete(contract);
	}

	/**
	 * @param selContractNm
	 * @param selProjectList
	 * @param allOpenPrjName
	 * @param selTaskName
	 * @param allAssyNo
	 * @param selPartAssmblyNumList
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerShipBomReportData> getHeaderData(
			String selContractNm,List<String> selProjectList, 
			boolean allOpenPrjName,String selTaskName, boolean allAssyNo, List<String> selPartAssmblyNumList) throws PLMCommonException{
		return plmBoilerShippingBomReportDao.getHeaderData(selContractNm,selProjectList, 
				allOpenPrjName,selTaskName,allAssyNo, selPartAssmblyNumList);
	}
	
	
	/**
	 * @param selContractNm
	 * @param selProjectList
	 * @param allOpenPrjName
	 * @param selTaskName
	 * @param allOpenTopLvlPart
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerShipBomReportData> getShippingHeaderData(
			String selContractNm, List<String> selProjectList, 
			boolean allOpenPrjName,List<String> selTaskName, boolean allOpenTopLvlPart) throws PLMCommonException{
		return plmBoilerShippingBomReportDao.getShippingHeaderData(
				selContractNm, selProjectList, allOpenPrjName,selTaskName, allOpenTopLvlPart);
	}
}