/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMRouteTaskOwnerData.java
 * @Creation date: 11-Sept-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMRouteTaskOwnerData {

	
	// PROPERTIES *************************************************************
	
	private String id;
	private String ownerName;
	
	// CONSTRUCTOR ************************************************************

	/**
	 * Creates a new instance of the class Deliverable
	 * 
	 * @param projectName(String)
	 * @param taskName(String)
	 * @param name(String)
	 * @param subject(String)
	 * @param revision(String)
	 * @param description(String)
	 */
	public PLMRouteTaskOwnerData (String id, String ownerName) {  
		this.id = id;
		this.ownerName = ownerName;		
	}
	
	// ACCESSOR METHODS *******************************************************

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	
	// OVERRIDEN METHODS ******************************************************

	/**
	 * Returns the Deliverable information as a String
	 * 
	 * @return type (String) 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer strRouteTaskOwner = new StringBuffer();
		
		strRouteTaskOwner.append(id).append(" ").append(ownerName);
		
		return strRouteTaskOwner.toString();
	}
	
}
