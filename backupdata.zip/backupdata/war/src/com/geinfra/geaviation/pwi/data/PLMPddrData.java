/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMPddrData.java
 * @Creation date: 22-May-2014
 * @version 3.0.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.data;

import java.io.Serializable;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

/**
 * PLMPddrData is the Transfer/Value Object class for SBoM and Add/Update use
 * case.
 */
public class PLMPddrData implements SQLData, Serializable {
	/**
	  * Holds the topPartName
	  */
	private String topPartName;
	/**
	  * Holds the topPartRev
	  */
	private String topPartRev;
	/**
	  * Holds the parentPartName
	  */
	private String parentPartName;
	/**
	  * Holds the parentPartRev
	  */
	private String parentPartRev;
	/**
	  * Holds the parentPartType
	  */
	private String parentPartType;
	/**
	  * Holds the childPartId
	  */
	private String childPartId;
	/**
	  * Holds the childPartName
	  */
	private String childPartName;
	/**
	  * Holds the childPartRev
	  */
	private String childPartRev;
	/**
	  * Holds the childPartType
	  */
	private String childPartType;
	/**
	  * Holds the childPartState
	  */
	private String childPartState;
	/**
	  * Holds the childPartDesc
	  */
	private String childPartDesc;
	/**
	  * Holds the bomLevel
	  */
	private int bomLevel;
	/**
	  * Holds the logicalIndicator
	  */
	private String logicalIndicator;
	/**
	  * Holds the documentName
	  */
	private String documentName;
	/**
	  * Holds the documentRev
	  */
	private String documentRev;
	/**
	  * Holds the documentType
	  */
	private String documentType;
	/**
	  * Holds the documentState
	  */
	private String documentState;
	/**
	  * Holds the documentDesc
	  */
	private String documentDesc;
	/**
	  * Holds the typeofDoc
	  */
	private String typeofDoc;
	/**
	  * Holds the partFamilyName
	  */
	private String partFamilyName;
	/**
	  * Holds the partCount
	  */
	private int partCount;
	/**
	  * Holds the state
	  */
	private String state;
	/**
	  * Holds the serialVersionUID
	  */
	
	private static final long serialVersionUID = -8277292687899220249L;
	/**
	  * Holds the partFamily
	  */
	private String partFamily = "-";
	/**
	  * Holds the partDesc
	  */
	private String partDesc = "-";
	/**
	  * Holds the partState
	  */
	private String partState = "-";
	/**
	  * Holds the partOwnerSso
	  */
	private String partOwnerSso = "-";
	/**
	  * Holds the partOwnerName
	  */
	private String partOwnerName = "-";
	/**
	  * Holds the partBaseNum
	  */
	private String partBaseNum = "-";
	/**
	  * Holds the partRDO
	  */
	private String partRDO = "-";
	/**
	  * Holds the partSrcOrgDate
	  */
	private String partSrcOrgDate = "-";
	/**
	  * Holds the partSrcModDate
	  */
	private String partSrcModDate = "-";
	/**
	  * Holds the partEEDWUpdateDate
	  */
	private String partEEDWUpdateDate = "-";
	/**
	  * Holds the count
	  */
	private int count;
	/**
	  * Holds the filePathXls
	  */
	private List filePathXls;
	/**
	  * Holds the filePathZip
	  */
	private String filePathZip;
	/**
	  * Holds the folderPath
	  */
	private String folderPath;
	/**
	  * Holds the type
	  */

	private String type;
	/**
	  * Holds the quantity
	  */
	private String quantity;
	/**
	  * Holds the description
	  */
	private String description;
	/**
	  * Holds the childInd
	  */
	private String childInd;
	/**
	 * The String sbomID
	 */
	private String sbomID;
	/**
	 * The String parentItem
	 */
	private String parentItem;
	/**
	 * The String childItem
	 */
	private String childItem;
	/**
	 * The String childItemPrefix
	 */
	private String childItemPrefix;
	/**
	 * The String itemEffectivityStartDT
	 */
	private String itemEffectivityStartDT;
	/**
	 * The Date itemEffStartDT
	 */
	private java.util.Date itemEffStartDT;
	/**
	 * The String itemAddRevision
	 */
	private String itemAddRevision;
	/**
	 * The String addEcn
	 */
	private String addEcn;
	/**
	 * The String itemEffectivityRetireDT
	 */
	private String itemEffectivityRetireDT;
	/**
	 * The Date itemEffRetireDT
	 */
	private java.util.Date itemEffRetireDT; // toedit
	/**
	 * The String itemDeleteRevision
	 */
	private String itemDeleteRevision;
	/**
	 * The String delEcn
	 */
	private String delEcn;
	/**
	 * The String srceTypeCD
	 */
	private String srceTypeCD;
	/**
	 * The String level
	 */
	private int level;
	/**
	 * The String partStatus
	 */
	private String partStatus; // toedit
	/**
	 * The String confidStatus
	 */
	private String configStatus; // toedit
	/**
	 * The String topLevelParentItem
	 */
	private String topLevelParentItem;
	/**
	 * The List<SelectItem> statusList
	 */
	private List<SelectItem> statusList = new ArrayList<SelectItem>();
	/**
	 * The List<SelectItem> confidList
	 */
	private List<SelectItem> confidList = new ArrayList<SelectItem>();
	/**
	 * The boolean toUpdate
	 */
	private boolean toUpdate;
	/**
	 * The String publishValue
	 */
	private String publishValue;

	/**
	 * Holds the Param for sqltype
	 */
	private String sqltype = "ICM_SBOM_DATA_OBJ";

	/**
	 * Holds the Param for bomPublishStatId
	 */
	private String bomPublishStatId;

	/**
	 * The String stdCtntSeqId
	 */
	private String stdCtntSeqId;

	/**
	 * The String partStatusValue
	 */
	private String partStatusValue;

	/**
	 * The String configStatusValue
	 */
	private String configStatusValue;
	
	/**
	 * boolean nodeHighlight Flag
	 */
	private boolean nodeHighlightFlag;
	
	/**
	 * String pathFlag
	 */
	private String pathFlag;
	
	/*
	 * Newly added fields
	 */
	/**
	 * String pin
	 */
	private String pin;
	/**
	 * String hpin
	 */
	private String hpin;
	/**
	 * String mli
	 */
	private String mli;
	/**
	 * String suffix
	 */
	private String suffix;
	/**
	 * String qty
	 */
	private double qty;
	/**
	 * String unitMeasure
	 */
	private String unitMeasure;
	/**
	 * String dateChange
	 */
	private String dateChange;
	/**
	 * String docName
	 */
	private String docName;
	/**
	 * String docRev
	 */
	private String docRev;
	/**
	 * String docDesc
	 */
	private String docDesc;
	/**
	 * String docType
	 */
	private String docType;
	/**
	 * String exportControl
	 */
	private String exportControl;
	/**
	 * String docClass
	 */
	private String docClass;
	/**
	 * String pdNameDesc
	 */
	private String pdNameDesc;
	/**
	 * int rowKey
	 */
	private int rowKey;
	/**
	 * String weekChange
	 */
	private String weekChange;
	/**
	 * String monthChange
	 */
	private String monthChange;
	
	/**
	 * Map compressedFilesWithSize
	 */
	private Map<String,Double> compressedFilesWithSize;

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the childInd
	 */
	public String getChildInd() {
		return childInd;
	}

	/**
	 * @param childInd
	 *            the childInd to set
	 */
	public void setChildInd(String childInd) {
		this.childInd = childInd;
	}

	/**
	 * @return bomPublishStatId
	 */
	public String getBomPublishStatId() {
		return bomPublishStatId;
	}

	/**
	 * @param strBomPublishStatId
	 *            the bomPublishStatId to set
	 */
	public void setBomPublishStatId(String strBomPublishStatId) {
		this.bomPublishStatId = strBomPublishStatId;
	}

	/**
	 * @return the sbomID
	 */
	public String getSbomID() {
		return sbomID;
	}

	/**
	 * @param sbomIDP
	 *            the sbomID to set
	 */
	public void setSbomID(String sbomIDP) {
		this.sbomID = sbomIDP;
	}

	/**
	 * @return the parentItem
	 */
	public String getParentItem() {
		return parentItem;
	}

	/**
	 * @param parentItemP
	 *            the parentItem to set
	 */
	public void setParentItem(String parentItemP) {
		this.parentItem = parentItemP;
	}

	/**
	 * @return the childItem
	 */
	public String getChildItem() {
		return childItem;
	}

	/**
	 * @param childItemP
	 *            the childItem to set
	 */
	public void setChildItem(String childItemP) {
		this.childItem = childItemP;
	}

	/**
	 * @return the childItemPrefix
	 */
	public String getChildItemPrefix() {
		return childItemPrefix;
	}

	/**
	 * @param childItemPrefixP
	 *            the childItemPrefix to set
	 */
	public void setChildItemPrefix(String childItemPrefixP) {
		this.childItemPrefix = childItemPrefixP;
	}

	/**
	 * @return the itemEffectivityStartDT
	 */
	public String getItemEffectivityStartDT() {
		return itemEffectivityStartDT;
	}

	/**
	 * @param itemEffectivityStartDTP
	 *            the itemEffectivityStartDT to set
	 */
	public void setItemEffectivityStartDT(String itemEffectivityStartDTP) {
		this.itemEffectivityStartDT = itemEffectivityStartDTP;
	}

	/**
	 * @return the itemAddRevision
	 */
	public String getItemAddRevision() {
		return itemAddRevision;
	}

	/**
	 * @param itemAddRevisionP
	 *            the itemAddRevision to set
	 */
	public void setItemAddRevision(String itemAddRevisionP) {
		this.itemAddRevision = itemAddRevisionP;
	}

	/**
	 * @return the addEcn
	 */
	public String getAddEcn() {
		return addEcn;
	}

	/**
	 * @param addEcnP
	 *            the addEcn to set
	 */
	public void setAddEcn(String addEcnP) {
		this.addEcn = addEcnP;
	}

	/**
	 * @return the itemEffectivityRetireDT
	 */
	public String getItemEffectivityRetireDT() {
		return itemEffectivityRetireDT;
	}

	/**
	 * @param itemEffectivityRetireDTP
	 *            the itemEffectivityRetireDT to set
	 */
	public void setItemEffectivityRetireDT(String itemEffectivityRetireDTP) {
		this.itemEffectivityRetireDT = itemEffectivityRetireDTP;
	}

	/**
	 * @return the itemDeleteRevision
	 */
	public String getItemDeleteRevision() {
		return itemDeleteRevision;
	}

	/**
	 * @param itemDeleteRevisionP
	 *            the itemDeleteRevision to set
	 */
	public void setItemDeleteRevision(String itemDeleteRevisionP) {
		this.itemDeleteRevision = itemDeleteRevisionP;
	}

	/**
	 * @return the delEcn
	 */
	public String getDelEcn() {
		return delEcn;
	}

	/**
	 * @param delEcnP
	 *            the delEcn to set
	 */
	public void setDelEcn(String delEcnP) {
		this.delEcn = delEcnP;
	}

	/**
	 * @return the srceTypeCD
	 */
	public String getSrceTypeCD() {
		return srceTypeCD;
	}

	/**
	 * @param srceTypeCDP
	 *            the srceTypeCD to set
	 */
	public void setSrceTypeCD(String srceTypeCDP) {
		this.srceTypeCD = srceTypeCDP;
	}

	/**
	 * @return the level
	 */
	public int getLevel() {
		return level;
	}

	/**
	 * @param levelP
	 *            the level to set
	 */
	public void setLevel(int levelP) {
		this.level = levelP;
	}

	/**
	 * @return the partStatus
	 */
	public String getPartStatus() {
		return partStatus;
	}

	/**
	 * @param partStatusP
	 *            the partStatus to set
	 */
	public void setPartStatus(String partStatusP) {
		this.partStatus = partStatusP;
	}

	/**
	 * @return the confidStatus
	 */
	public String getConfigStatus() {
		return configStatus;
	}

	/**
	 * @param confidStatusP
	 *            the confidStatus to set
	 */
	public void setConfigStatus(String confidStatusP) {
		this.configStatus = confidStatusP;
	}

	/**
	 * @return the topLevelParentItem
	 */
	public String getTopLevelParentItem() {
		return topLevelParentItem;
	}

	/**
	 * @param topLevelParentItemP
	 *            the topLevelParentItem to set
	 */
	public void setTopLevelParentItem(String topLevelParentItemP) {
		this.topLevelParentItem = topLevelParentItemP;
	}

	/**
	 * @return the statusList
	 */
	public List<SelectItem> getStatusList() {
		return statusList;
	}

	/**
	 * @param statusListP
	 *            the statusList to set
	 */
	public void setStatusList(List<SelectItem> statusListP) {
		this.statusList = statusListP;
	}

	/**
	 * @return the confidList
	 */
	public List<SelectItem> getConfidList() {
		return confidList;
	}

	/**
	 * @param confidListP
	 *            the confidList to set
	 */
	public void setConfidList(List<SelectItem> confidListP) {
		this.confidList = confidListP;
	}

	/**
	 * @return the toUpdate
	 */
	public boolean isToUpdate() {
		return toUpdate;
	}

	/**
	 * @param toUpdateP
	 *            the toUpdate to set
	 */
	public void setToUpdate(boolean toUpdateP) {
		this.toUpdate = toUpdateP;
	}

	/**
	 * @return the itemEffStartDT
	 */
	public java.util.Date getItemEffStartDT() {
		java.util.Date temp = itemEffStartDT;
		return temp;
	}

	/**
	 * @param itemEffStartDTP
	 *            the itemEffStartDT to set
	 */
	public void setItemEffStartDT(java.util.Date itemEffStartDTP) {
		java.util.Date temp = itemEffStartDTP;
		this.itemEffStartDT = temp;
	}

	/**
	 * @return the itemEffRetireDT
	 */
	public java.util.Date getItemEffRetireDT() {
		java.util.Date temp = itemEffRetireDT;
		return temp;
	}

	/**
	 * @param itemEffRetireDTP
	 *            the itemEffRetireDT to set
	 */
	public void setItemEffRetireDT(java.util.Date itemEffRetireDTP) {
		java.util.Date temp = itemEffRetireDTP;
		this.itemEffRetireDT = temp;
	}

	/**
	 * @return the publishValue
	 */
	public String getPublishValue() {
		return publishValue;
	}

	/**
	 * @param publishValue
	 *            the publishValue to set
	 */
	public void setPublishValue(String publishValueP) {
		this.publishValue = publishValueP;
	}

	/**
	 * @return the partStatusValue
	 */
	public String getPartStatusValue() {
		return partStatusValue;
	}

	/**
	 * @param partStatusValue
	 *            the partStatusValue to set
	 */
	public void setPartStatusValue(String partStatusValueP) {
		this.partStatusValue = partStatusValueP;
	}

	/**
	 * @return the configStatusValue
	 */
	public String getConfigStatusValue() {
		return configStatusValue;
	}

	/**
	 * @param configStatusValue
	 *            the configStatusValue to set
	 */
	public void setConfigStatusValue(String configStatusValueP) {
		this.configStatusValue = configStatusValueP;
	}

	/**
	 * @return the quantity
	 */
	public String getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity
	 *            the quantity to set
	 */
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @param stream
	 * @throws SQLException
	 */
	public void writeSQL(SQLOutput stream) throws SQLException {

		stream.writeString(sbomID);
		stream.writeString(childItem);
		stream.writeString(parentItem);
		stream.writeString(topLevelParentItem);
		stream.writeString(childItemPrefix);
		stream.writeString(itemEffectivityStartDT);
		stream.writeString(addEcn);
		stream.writeString(itemAddRevision);
		stream.writeString(delEcn);
		stream.writeString(itemDeleteRevision);
		stream.writeString(itemEffectivityRetireDT);
		stream.writeInt(level);
		stream.writeString(partStatus);
		stream.writeString(configStatus);
		stream.writeString(bomPublishStatId);
	}

	/**
	 * @return sqltype
	 * @throws SQLException
	 */
	public String getSQLTypeName() throws SQLException {
		return sqltype; // To change body of implemented methods use File |
		// Settings | File Templates.
	}

	/**
	 * @param stream
	 * @param typeName
	 * @throws SQLException
	 */
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		sqltype = typeName;
		sbomID = stream.readString();
		childItem = stream.readString();
		parentItem = stream.readString();
		topLevelParentItem = stream.readString();
		childItemPrefix = stream.readString();
		itemEffectivityStartDT = stream.readString();
		addEcn = stream.readString();
		itemAddRevision = stream.readString();
		delEcn = stream.readString();
		itemDeleteRevision = stream.readString();
		itemEffectivityRetireDT = stream.readString();
		level = stream.readInt();
		partStatus = stream.readString();
		configStatus = stream.readString();
		bomPublishStatId = stream.readString();
	}

	/**
	 * @return the stdCtntSeqId
	 */
	public String getStdCtntSeqId() {
		return stdCtntSeqId;
	}

	/**
	 * @param stdCtntSeqIdP
	 *            the stdCtntSeqId to set
	 */
	public void setStdCtntSeqId(String stdCtntSeqIdP) {
		this.stdCtntSeqId = stdCtntSeqIdP;
	}

	/**
	 * @return the nodeHighlightFlag
	 */
	public boolean isNodeHighlightFlag() {
		return nodeHighlightFlag;
	}

	/**
	 * @param nodeHighlightFlag the nodeHighlightFlag to set
	 */
	public void setNodeHighlightFlag(boolean nodeHighlightFlag) {
		this.nodeHighlightFlag = nodeHighlightFlag;
	}
	/**
	 * @return the pathFlag
	 */
	public String getPathFlag() {
		return pathFlag;
	}

	/**
	 * @param pathFlag the pathFlag to set
	 */
	public void setPathFlag(String pathFlag) {
		this.pathFlag = pathFlag;
	}

	/**
	 * @return the sqltype
	 */
	public String getSqltype() {
		return sqltype;
	}

	/**
	 * @param sqltype the sqltype to set
	 */
	public void setSqltype(String sqltype) {
		this.sqltype = sqltype;
	}

	/**
	 * @return the pin
	 */
	public String getPin() {
		return pin;
	}

	/**
	 * @param pin the pin to set
	 */
	public void setPin(String pin) {
		this.pin = pin;
	}

	/**
	 * @return the hpin
	 */
	public String getHpin() {
		return hpin;
	}

	/**
	 * @param hpin the hpin to set
	 */
	public void setHpin(String hpin) {
		this.hpin = hpin;
	}

	/**
	 * @return the prefix
	 */
	public String getMli() {
		return mli;
	}

	/**
	 * @param prefix the prefix to set
	 */
	public void setMli(String mli) {
		this.mli = mli;
	}

	/**
	 * @return the suffix
	 */
	public String getSuffix() {
		return suffix;
	}

	/**
	 * @param suffix the suffix to set
	 */
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	/**
	 * @return the qty
	 */
	public double getQty() {
		return qty;
	}

	/**
	 * @param qty the qty to set
	 */
	public void setQty(double qty) {
		this.qty = qty;
	}

	/**
	 * @return the unitMeasure
	 */
	public String getUnitMeasure() {
		return unitMeasure;
	}

	/**
	 * @param unitMeasure the unitMeasure to set
	 */
	public void setUnitMeasure(String unitMeasure) {
		this.unitMeasure = unitMeasure;
	}

	

	
	/**
	 * @return the docName
	 */
	public String getDocName() {
		return docName;
	}

	/**
	 * @param docName the docName to set
	 */
	public void setDocName(String docName) {
		this.docName = docName;
	}

	/**
	 * @return the docRev
	 */
	public String getDocRev() {
		return docRev;
	}

	/**
	 * @param docRev the docRev to set
	 */
	public void setDocRev(String docRev) {
		this.docRev = docRev;
	}

	/**
	 * @return the docDesc
	 */
	public String getDocDesc() {
		return docDesc;
	}

	/**
	 * @param docDesc the docDesc to set
	 */
	public void setDocDesc(String docDesc) {
		this.docDesc = docDesc;
	}

	/**
	 * @return the docType
	 */
	public String getDocType() {
		return docType;
	}

	/**
	 * @param docType the docType to set
	 */
	public void setDocType(String docType) {
		this.docType = docType;
	}

	/**
	 * @return the exportControl
	 */
	public String getExportControl() {
		return exportControl;
	}

	/**
	 * @param exportControl the exportControl to set
	 */
	public void setExportControl(String exportControl) {
		this.exportControl = exportControl;
	}

	/**
	 * @return the docClass
	 */
	public String getDocClass() {
		return docClass;
	}

	/**
	 * @param docClass the docClass to set
	 */
	public void setDocClass(String docClass) {
		this.docClass = docClass;
	}

	/**
	 * @return the pdNameDesc
	 */
	public String getPdNameDesc() {
		return pdNameDesc;
	}

	/**
	 * @param pdNameDesc the pdNameDesc to set
	 */
	public void setPdNameDesc(String pdNameDesc) {
		this.pdNameDesc = pdNameDesc;
	}

	/**
	 * @return the weekChange
	 */
	public String getWeekChange() {
		return weekChange;
	}

	/**
	 * @param weekChange the weekChange to set
	 */
	public void setWeekChange(String weekChange) {
		this.weekChange = weekChange;
	}

	/**
	 * @return the monthChange
	 */
	public String getMonthChange() {
		return monthChange;
	}

	/**
	 * @param monthChange the monthChange to set
	 */
	public void setMonthChange(String monthChange) {
		this.monthChange = monthChange;
	}

	/**
	 * @return the rowKey
	 */
	public int getRowKey() {
		return rowKey;
	}

	/**
	 * @param rowKey the rowKey to set
	 */
	public void setRowKey(int rowKey) {
		this.rowKey = rowKey;
	}

	/**
	 * @return the dateChange
	 */
	public String getDateChange() {
		return dateChange;
	}

	/**
	 * @param dateChange the dateChange to set
	 */
	public void setDateChange(String dateChange) {
		this.dateChange = dateChange;
	}

	

	/**
	 * @return the topPartName
	 */
	public String getTopPartName() {
		return topPartName;
	}

	/**
	 * @param topPartName the topPartName to set
	 */
	public void setTopPartName(String topPartName) {
		this.topPartName = topPartName;
	}

	/**
	 * @return the topPartRev
	 */
	public String getTopPartRev() {
		return topPartRev;
	}

	/**
	 * @param topPartRev the topPartRev to set
	 */
	public void setTopPartRev(String topPartRev) {
		this.topPartRev = topPartRev;
	}

	/**
	 * @return the parentPartName
	 */
	public String getParentPartName() {
		return parentPartName;
	}

	/**
	 * @param parentPartName the parentPartName to set
	 */
	public void setParentPartName(String parentPartName) {
		this.parentPartName = parentPartName;
	}

	/**
	 * @return the parentPartRev
	 */
	public String getParentPartRev() {
		return parentPartRev;
	}

	/**
	 * @param parentPartRev the parentPartRev to set
	 */
	public void setParentPartRev(String parentPartRev) {
		this.parentPartRev = parentPartRev;
	}

	/**
	 * @return the parentPartType
	 */
	public String getParentPartType() {
		return parentPartType;
	}

	/**
	 * @param parentPartType the parentPartType to set
	 */
	public void setParentPartType(String parentPartType) {
		this.parentPartType = parentPartType;
	}

	/**
	 * @return the childPartId
	 */
	public String getChildPartId() {
		return childPartId;
	}

	/**
	 * @param childPartId the childPartId to set
	 */
	public void setChildPartId(String childPartId) {
		this.childPartId = childPartId;
	}

	/**
	 * @return the childPartName
	 */
	public String getChildPartName() {
		return childPartName;
	}

	/**
	 * @param childPartName the childPartName to set
	 */
	public void setChildPartName(String childPartName) {
		this.childPartName = childPartName;
	}

	/**
	 * @return the childPartRev
	 */
	public String getChildPartRev() {
		return childPartRev;
	}

	/**
	 * @param childPartRev the childPartRev to set
	 */
	public void setChildPartRev(String childPartRev) {
		this.childPartRev = childPartRev;
	}

	/**
	 * @return the childPartType
	 */
	public String getChildPartType() {
		return childPartType;
	}

	/**
	 * @param childPartType the childPartType to set
	 */
	public void setChildPartType(String childPartType) {
		this.childPartType = childPartType;
	}

	/**
	 * @return the childPartState
	 */
	public String getChildPartState() {
		return childPartState;
	}

	/**
	 * @param childPartState the childPartState to set
	 */
	public void setChildPartState(String childPartState) {
		this.childPartState = childPartState;
	}

	/**
	 * @return the childPartDesc
	 */
	public String getChildPartDesc() {
		return childPartDesc;
	}

	/**
	 * @param childPartDesc the childPartDesc to set
	 */
	public void setChildPartDesc(String childPartDesc) {
		this.childPartDesc = childPartDesc;
	}

	/**
	 * @return the bomLevel
	 */
	public int getBomLevel() {
		return bomLevel;
	}

	/**
	 * @param bomLevel the bomLevel to set
	 */
	public void setBomLevel(int bomLevel) {
		this.bomLevel = bomLevel;
	}

	/**
	 * @return the logicalIndicator
	 */
	public String getLogicalIndicator() {
		return logicalIndicator;
	}

	/**
	 * @param logicalIndicator the logicalIndicator to set
	 */
	public void setLogicalIndicator(String logicalIndicator) {
		this.logicalIndicator = logicalIndicator;
	}

	/**
	 * @return the documentName
	 */
	public String getDocumentName() {
		return documentName;
	}

	/**
	 * @param documentName the documentName to set
	 */
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	/**
	 * @return the documentRev
	 */
	public String getDocumentRev() {
		return documentRev;
	}

	/**
	 * @param documentRev the documentRev to set
	 */
	public void setDocumentRev(String documentRev) {
		this.documentRev = documentRev;
	}

	/**
	 * @return the documentType
	 */
	public String getDocumentType() {
		return documentType;
	}

	/**
	 * @param documentType the documentType to set
	 */
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	/**
	 * @return the documentState
	 */
	public String getDocumentState() {
		return documentState;
	}

	/**
	 * @param documentState the documentState to set
	 */
	public void setDocumentState(String documentState) {
		this.documentState = documentState;
	}

	/**
	 * @return the documentDesc
	 */
	public String getDocumentDesc() {
		return documentDesc;
	}

	/**
	 * @param documentDesc the documentDesc to set
	 */
	public void setDocumentDesc(String documentDesc) {
		this.documentDesc = documentDesc;
	}

	/**
	 * @return the typeofDoc
	 */
	public String getTypeofDoc() {
		return typeofDoc;
	}

	/**
	 * @param typeofDoc the typeofDoc to set
	 */
	public void setTypeofDoc(String typeofDoc) {
		this.typeofDoc = typeofDoc;
	}

	/**
	 * @return the partFamilyName
	 */
	public String getPartFamilyName() {
		return partFamilyName;
	}

	/**
	 * @param partFamilyName the partFamilyName to set
	 */
	public void setPartFamilyName(String partFamilyName) {
		this.partFamilyName = partFamilyName;
	}

	/**
	 * @return the partCount
	 */
	public int getPartCount() {
		return partCount;
	}

	/**
	 * @param partCount the partCount to set
	 */
	public void setPartCount(int partCount) {
		this.partCount = partCount;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the partFamily
	 */
	public String getPartFamily() {
		return partFamily;
	}

	/**
	 * @param partFamily the partFamily to set
	 */
	public void setPartFamily(String partFamily) {
		this.partFamily = partFamily;
	}

	/**
	 * @return the partDesc
	 */
	public String getPartDesc() {
		return partDesc;
	}

	/**
	 * @param partDesc the partDesc to set
	 */
	public void setPartDesc(String partDesc) {
		this.partDesc = partDesc;
	}

	/**
	 * @return the partState
	 */
	public String getPartState() {
		return partState;
	}

	/**
	 * @param partState the partState to set
	 */
	public void setPartState(String partState) {
		this.partState = partState;
	}

	/**
	 * @return the partOwnerSso
	 */
	public String getPartOwnerSso() {
		return partOwnerSso;
	}

	/**
	 * @param partOwnerSso the partOwnerSso to set
	 */
	public void setPartOwnerSso(String partOwnerSso) {
		this.partOwnerSso = partOwnerSso;
	}

	/**
	 * @return the partOwnerName
	 */
	public String getPartOwnerName() {
		return partOwnerName;
	}

	/**
	 * @param partOwnerName the partOwnerName to set
	 */
	public void setPartOwnerName(String partOwnerName) {
		this.partOwnerName = partOwnerName;
	}

	/**
	 * @return the partBaseNum
	 */
	public String getPartBaseNum() {
		return partBaseNum;
	}

	/**
	 * @param partBaseNum the partBaseNum to set
	 */
	public void setPartBaseNum(String partBaseNum) {
		this.partBaseNum = partBaseNum;
	}

	/**
	 * @return the partRDO
	 */
	public String getPartRDO() {
		return partRDO;
	}

	/**
	 * @param partRDO the partRDO to set
	 */
	public void setPartRDO(String partRDO) {
		this.partRDO = partRDO;
	}

	/**
	 * @return the partSrcOrgDate
	 */
	public String getPartSrcOrgDate() {
		return partSrcOrgDate;
	}

	/**
	 * @param partSrcOrgDate the partSrcOrgDate to set
	 */
	public void setPartSrcOrgDate(String partSrcOrgDate) {
		this.partSrcOrgDate = partSrcOrgDate;
	}

	/**
	 * @return the partSrcModDate
	 */
	public String getPartSrcModDate() {
		return partSrcModDate;
	}

	/**
	 * @param partSrcModDate the partSrcModDate to set
	 */
	public void setPartSrcModDate(String partSrcModDate) {
		this.partSrcModDate = partSrcModDate;
	}

	/**
	 * @return the partEEDWUpdateDate
	 */
	public String getPartEEDWUpdateDate() {
		return partEEDWUpdateDate;
	}

	/**
	 * @param partEEDWUpdateDate the partEEDWUpdateDate to set
	 */
	public void setPartEEDWUpdateDate(String partEEDWUpdateDate) {
		this.partEEDWUpdateDate = partEEDWUpdateDate;
	}

	/**
	 * @return the count
	 */
	public int getCount() {
		return count;
	}

	/**
	 * @param count the count to set
	 */
	public void setCount(int count) {
		this.count = count;
	}

	/**
	 * @return the filePathXls
	 */
	public List getFilePathXls() {
		return filePathXls;
	}

	/**
	 * @param filePathXls the filePathXls to set
	 */
	public void setFilePathXls(List filePathXls) {
		this.filePathXls = filePathXls;
	}

	/**
	 * @return the filePathZip
	 */
	public String getFilePathZip() {
		return filePathZip;
	}

	/**
	 * @param filePathZip the filePathZip to set
	 */
	public void setFilePathZip(String filePathZip) {
		this.filePathZip = filePathZip;
	}

	/**
	 * @return the folderPath
	 */
	public String getFolderPath() {
		return folderPath;
	}

	/**
	 * @param folderPath the folderPath to set
	 */
	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @return Returns the compressedFilesWithSize.
	 */
	public Map<String, Double> getCompressedFilesWithSize() {
		return compressedFilesWithSize;
	}

	/**
	 * @param compressedFilesWithSize The compressedFilesWithSize to set.
	 */
	public void setCompressedFilesWithSize(
			Map<String, Double> compressedFilesWithSize) {
		this.compressedFilesWithSize = compressedFilesWithSize;
	}
	
}
