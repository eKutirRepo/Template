/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCntrtSmryRptData.java
 * @Creation date: 4-April-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.data;

import java.util.Date;
import java.util.List;

public class PLMCntrtSmryRptData {
	
	private List<String> component;
	private boolean checkSelBox = true;
	
	private String projectName;
	private String projectTitle;
	private String hardwareProduct;
	private String productConfiguration;
	
	private String empName;
	private String empRole;
	
	private String clinNameParent;
	private String sowParagraph;
	private Date clinInitialDeliveryDate;
	private String clinDesc;
	private String clinStatus;
	private String satisfiedByTask;
	private String ciNumber;
	private String clinTasking;
	private String ceiQuantity;
	private String clinIndicator;
	
	
	private String prdtRqmntSpecNm;
	private String prdtRqmntSpecDesc;
	private String prdtRqmntSpecTitleCol;
	private String prdtRqmntSpecNotes;
	
	private String crsName;
	private String crsTitle;
	private String crsRevision;
	private String crsState;
	private String crsLevel;
	
	
	private String hbldNm;
	private String hbldType;
	private String hbldState;
	private String hbSrlNum;
	private Date hbActBldDt;
	private Date hbDtShpd;
	private String hbCstmr;
	private String hbPartNum;
	private String hbClinNm;
	
	private String PLPName;
	
	
	
	private String prsId;
	private String prsParentName;
	private String prsParentType;
	private String prsName;
	private String prsReqDesc;
	private String prsTitleCol;
	private String prsReqNotes;
	private String childName;
	private String childType;
	private String prsLevel;
	private String indicator;
	private String uom;
	private String reqmtValue;
	private String childDesc;
	private String childTitle;
	private String dfsOrder;
	
	//crs recursive
	private String crsrLevel;
	private String crsrId;
	private String crsrName;
	private String crsrTitle;
	private String crsrRevision;
	private String crsrtoType;
	
	
	private String fromName;
	private String fromType;
	private String toName;
	private String toType;
	
	
	//Product Configuration
	private String pcName;
	private String pcDesc;
	private String pcBasedOn;
	private String pcState;
	private String pcParentPc;
	private String pcTopLevelParent;
	private String pcDerviedFrom;
	private String pcPurpose;
	
	//Configuration Features
	private String cfName;
	private String cfDisplyName;
	private String cfConfigOption;
	private String cfConfOptDispName;
	
	//Logical Features
	private String lfLevel;
	private String lfFeatDsplName;
	private String lfFeatName;
	private String lfFeatDesc;

	//Configuration End Items
	private String ceLevel;
	private String ceDispName;
	private String ceName;
	private String ceDesc;
	
	
	private String ceHwClNum;
	private String ceSWClNum;
	
	//Customer Requirements
	private String crName;
	private String crTitle;
	private String crState;
	private String crSatisfiedBy;
	private String crEntrpIdnFr;
	
	//Cost Objects
	private String coName;
	private String coCrName;
	
	//TOP LVL PART NAME
	private String topName;
	
	private String pathFlag;
	private String prsFlag;
	private boolean hasChild;
	private String cfLevel;
	
	
	private String cntrtNm;
	private String cntrtDesc;
	
	private String hwPrdctNm;
	private String prdtConfigNm;
	private String prdtConfigDesc;
	private String isOption;
	
	private List<String> selCstGrpList;
	private List<String> selPcList;
	private String cfId;
	private String cfConfId;
	private String crId;
	//Newly Added fields for contract summary report
	private String ceId;
	private String lfFeatId;
	private String coId;
	private String coState;
	private String coCrId;
	private String coCrState;
	private String coFeatName;
	private String coDesc;
	private String sso;
	//Newly added fields by srinivas
	private String reqId;
	private String reqName;
	private String reqDesc;
	private String feqSeqOrder;
	private String crFlag;	
	private String shpOrdrNum;	
    private String optSubType;
	private String crsrDesc;
	private String legacyFACode;

	//newly Added for 4.6 Release
	private String prsChildId;
	private boolean prsReqFlag;
	private boolean topPrsLvlFlag;
	private boolean topCrsLvlFlag;
	private boolean prsChapterFlg;
	private boolean crsChapterFlg;
	private boolean crsReqFlg;
	
	private String contractExcel;
	private String projectNameExcel;
	private String pcNameExl;
	private boolean systemFlag;
	private String systemName;
	private boolean vistFlag;
	
	//added by Ananta for mapping the keyinvalue
    private String keyInValue;
    
    

	/**
	 * @return the keyInValue
	 */
	public String getKeyInValue() {
		return keyInValue;
	}
	/**
	 * @param keyInValue the keyInValue to set
	 */
	public void setKeyInValue(String keyInValue) {
		this.keyInValue = keyInValue;
	}
	/**
	 * Holds pcCstGrp
	 */
	private String pcCstGrp;


	/**
	 * @return
	 */
	public String getCfLevel() {
		return cfLevel;
	}
	/**
	 * @param cfLevel
	 */
	public void setCfLevel(String cfLevel) {
		this.cfLevel = cfLevel;
	}
	/**
	 * @return
	 */
	public boolean isHasChild() {
		return hasChild;
	}
	/**
	 * @param hasChild
	 */
	public void setHasChild(boolean hasChild) {
		this.hasChild = hasChild;
	}
	/**
	 * @return the hardwareProduct
	 */
	public String getHardwareProduct() {
		return hardwareProduct;
	}
	/**
	 * @param hardwareProduct the hardwareProduct to set
	 */
	public void setHardwareProduct(String hardwareProduct) {
		this.hardwareProduct = hardwareProduct;
	}
	/**
	 * @return the productConfiguration
	 */
	public String getProductConfiguration() {
		return productConfiguration;
	}
	/**
	 * @param productConfiguration the productConfiguration to set
	 */
	public void setProductConfiguration(String productConfiguration) {
		this.productConfiguration = productConfiguration;
	}
	
	/**
	 * @return the checkSelBox
	 */
	public boolean isCheckSelBox() {
		return checkSelBox;
	}
	/**
	 * @param checkSelBox the checkSelBox to set
	 */
	public void setCheckSelBox(boolean checkSelBox) {
		this.checkSelBox = checkSelBox;
	}
	/**
	 * @return the component
	 */
	public List<String> getComponent() {
		return component;
	}
	/**
	 * @param component the component to set
	 */
	public void setComponent(List<String> component) {
		this.component = component;
	}
	/**
	 * @return the empName
	 */
	public String getEmpName() {
		return empName;
	}
	/**
	 * @param empName the empName to set
	 */
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	/**
	 * @return the empRole
	 */
	public String getEmpRole() {
		return empRole;
	}
	/**
	 * @param empRole the empRole to set
	 */
	public void setEmpRole(String empRole) {
		this.empRole = empRole;
	}
	/**
	 * @return the clinNameParent
	 */
	public String getClinNameParent() {
		return clinNameParent;
	}
	/**
	 * @param clinNameParent the clinNameParent to set
	 */
	public void setClinNameParent(String clinNameParent) {
		this.clinNameParent = clinNameParent;
	}
	/**
	 * @return the sowParagraph
	 */
	public String getSowParagraph() {
		return sowParagraph;
	}
	/**
	 * @param sowParagraph the sowParagraph to set
	 */
	public void setSowParagraph(String sowParagraph) {
		this.sowParagraph = sowParagraph;
	}
	/**
	 * @return the clinInitialDeliveryDate
	 */
	public Date getClinInitialDeliveryDate() {
		Date clinInitialDeliveryDt=clinInitialDeliveryDate;
		return clinInitialDeliveryDt;
	}
	/**
	 * @param clinInitialDeliveryDate the clinInitialDeliveryDate to set
	 */
	public void setClinInitialDeliveryDate(Date clinInitialDeliveryDate) {
		if(clinInitialDeliveryDate!=null){
			 this.clinInitialDeliveryDate = (Date)clinInitialDeliveryDate.clone();
		}else{
			 this.clinInitialDeliveryDate =null; 
		 }
	}
	/**
	 * @return the clinDesc
	 */
	public String getClinDesc() {
		return clinDesc;
	}
	/**
	 * @param clinDesc the clinDesc to set
	 */
	public void setClinDesc(String clinDesc) {
		this.clinDesc = clinDesc;
	}
	/**
	 * @return the clinStatus
	 */
	public String getClinStatus() {
		return clinStatus;
	}
	/**
	 * @param clinStatus the clinStatus to set
	 */
	public void setClinStatus(String clinStatus) {
		this.clinStatus = clinStatus;
	}
	/**
	 * @return the satisfiedByTask
	 */
	public String getSatisfiedByTask() {
		return satisfiedByTask;
	}
	/**
	 * @param satisfiedByTask the satisfiedByTask to set
	 */
	public void setSatisfiedByTask(String satisfiedByTask) {
		this.satisfiedByTask = satisfiedByTask;
	}
	/**
	 * @return the ciNumber
	 */
	public String getCiNumber() {
		return ciNumber;
	}
	/**
	 * @param ciNumber the ciNumber to set
	 */
	public void setCiNumber(String ciNumber) {
		this.ciNumber = ciNumber;
	}
	/**
	 * @return the clinTasking
	 */
	public String getClinTasking() {
		return clinTasking;
	}
	/**
	 * @param clinTasking the clinTasking to set
	 */
	public void setClinTasking(String clinTasking) {
		this.clinTasking = clinTasking;
	}
	/**
	 * @return the prdtRqmntSpecNm
	 */
	public String getPrdtRqmntSpecNm() {
		return prdtRqmntSpecNm;
	}
	/**
	 * @param prdtRqmntSpecNm the prdtRqmntSpecNm to set
	 */
	public void setPrdtRqmntSpecNm(String prdtRqmntSpecNm) {
		this.prdtRqmntSpecNm = prdtRqmntSpecNm;
	}
	/**
	 * @return the prdtRqmntSpecDesc
	 */
	public String getPrdtRqmntSpecDesc() {
		return prdtRqmntSpecDesc;
	}
	/**
	 * @param prdtRqmntSpecDesc the prdtRqmntSpecDesc to set
	 */
	public void setPrdtRqmntSpecDesc(String prdtRqmntSpecDesc) {
		this.prdtRqmntSpecDesc = prdtRqmntSpecDesc;
	}
	/**
	 * @return the prdtRqmntSpecTitleCol
	 */
	public String getPrdtRqmntSpecTitleCol() {
		return prdtRqmntSpecTitleCol;
	}
	/**
	 * @param prdtRqmntSpecTitleCol the prdtRqmntSpecTitleCol to set
	 */
	public void setPrdtRqmntSpecTitleCol(String prdtRqmntSpecTitleCol) {
		this.prdtRqmntSpecTitleCol = prdtRqmntSpecTitleCol;
	}
	/**
	 * @return the prdtRqmntSpecNotes
	 */
	public String getPrdtRqmntSpecNotes() {
		return prdtRqmntSpecNotes;
	}
	/**
	 * @param prdtRqmntSpecNotes the prdtRqmntSpecNotes to set
	 */
	public void setPrdtRqmntSpecNotes(String prdtRqmntSpecNotes) {
		this.prdtRqmntSpecNotes = prdtRqmntSpecNotes;
	}
	/**
	 * @return the crsName
	 */
	public String getCrsName() {
		return crsName;
	}
	/**
	 * @param crsName the crsName to set
	 */
	public void setCrsName(String crsName) {
		this.crsName = crsName;
	}
	/**
	 * @return the crsTitle
	 */
	public String getCrsTitle() {
		return crsTitle;
	}
	/**
	 * @param crsTitle the crsTitle to set
	 */
	public void setCrsTitle(String crsTitle) {
		this.crsTitle = crsTitle;
	}
	/**
	 * @return the crsRevision
	 */
	public String getCrsRevision() {
		return crsRevision;
	}
	/**
	 * @param crsRevision the crsRevision to set
	 */
	public void setCrsRevision(String crsRevision) {
		this.crsRevision = crsRevision;
	}
	/**
	 * @return the crsState
	 */
	public String getCrsState() {
		return crsState;
	}
	/**
	 * @param crsState the crsState to set
	 */
	public void setCrsState(String crsState) {
		this.crsState = crsState;
	}
	
	/**
	 * @return the hbldNm
	 */
	public String getHbldNm() {
		return hbldNm;
	}
	/**
	 * @param hbldNm the hbldNm to set
	 */
	public void setHbldNm(String hbldNm) {
		this.hbldNm = hbldNm;
	}
	
	/**
	 * @return the hbldType
	 */
	public String getHbldType() {
		return hbldType;
	}
	/**
	 * @param hbldType the hbldType to set
	 */
	public void setHbldType(String hbldType) {
		this.hbldType = hbldType;
	}
	
	/**
	 * @return the hbldState
	 */
	public String getHbldState() {
		return hbldState;
	}
	/**
	 * @param hbldState the hbldState to set
	 */
	public void setHbldState(String hbldState) {
		this.hbldState = hbldState;
	}
	/**
	 * @return the hBState
	 */
	/*public String getHBState() {
		return hBState;
	}*/
	/**
	 * @param hBState the hBState to set
	 */
	/*public void setHBState(String hBState) {
		this.hBState = hBState;
	}*/
	
	/**
	 * @return the hbSrlNum
	 */
	public String getHbSrlNum() {
		return hbSrlNum;
	}
	/**
	 * @param hbSrlNum the hbSrlNum to set
	 */
	public void setHbSrlNum(String hbSrlNum) {
		this.hbSrlNum = hbSrlNum;
	}
	
	
	/**
	 * @return the hbActBldDt
	 */
	public Date getHbActBldDt() {
		Date hBActualBuildDt = hbActBldDt;
		return hBActualBuildDt;
	}
	/**
	 * @param hbActBldDt the hbActBldDt to set
	 */
	public void setHbActBldDt(Date hbActBldDt) {
		if(hbActBldDt!=null){
			 this.hbActBldDt = (Date)hbActBldDt.clone();
		}else{
			 this.hbActBldDt =null; 
		 }
	}
	
	/**
	 * @return the hbDtShpd
	 */
	public Date getHbDtShpd() {
		Date hBDtShipped =hbDtShpd;
		return hBDtShipped;
	}
	/**
	 * @param hbDtShpd the hbDtShpd to set
	 */
	public void setHbDtShpd(Date hbDtShpd) {
		if(hbDtShpd!=null){
			 this.hbDtShpd = (Date)hbDtShpd.clone();
		}else{
			 this.hbDtShpd =null; 
		 }
	}
	/**
	 * @return the hBDateShipped
	 */
	/*public Date getHBDateShipped() {
		Date hBDtShipped =hBDateShipped;
		return hBDtShipped;
	}*/
	/**
	 * @param hBDateShipped the hBDateShipped to set
	 */
	/*public void setHBDateShipped(Date hBDateShipped) {
		Date hBDtShipped =hBDateShipped;
		this.hBDateShipped = hBDtShipped;
	}*/
	
	/**
	 * @return the hbCstmr
	 */
	public String getHbCstmr() {
		return hbCstmr;
	}
	/**
	 * @param hbCstmr the hbCstmr to set
	 */
	public void setHbCstmr(String hbCstmr) {
		this.hbCstmr = hbCstmr;
	}
	/**
	 * @return the hbPartNum
	 */
	public String getHbPartNum() {
		return hbPartNum;
	}
	/**
	 * @param hbPartNum the hbPartNum to set
	 */
	public void setHbPartNum(String hbPartNum) {
		this.hbPartNum = hbPartNum;
	}
	/**
	 * @return the hbClinNm
	 */
	public String getHbClinNm() {
		return hbClinNm;
	}
	/**
	 * @param hbClinNm the hbClinNm to set
	 */
	public void setHbClinNm(String hbClinNm) {
		this.hbClinNm = hbClinNm;
	}
	/**
	 * @return the pLPName
	 */
	public String getPLPName() {
		return PLPName;
	}
	/**
	 * @param pLPName the pLPName to set
	 */
	public void setPLPName(String pLPName) {
		PLPName = pLPName;
	}
	/**
	 * @return the prsId
	 */
	public String getPrsId() {
		return prsId;
	}
	/**
	 * @param prsId the prsId to set
	 */
	public void setPrsId(String prsId) {
		this.prsId = prsId;
	}
	/**
	 * @return the prsName
	 */
	public String getPrsName() {
		return prsName;
	}
	/**
	 * @param prsName the prsName to set
	 */
	public void setPrsName(String prsName) {
		this.prsName = prsName;
	}
	/**
	 * @return the prsReqDesc
	 */
	public String getPrsReqDesc() {
		return prsReqDesc;
	}
	/**
	 * @param prsReqDesc the prsReqDesc to set
	 */
	public void setPrsReqDesc(String prsReqDesc) {
		this.prsReqDesc = prsReqDesc;
	}
	/**
	 * @return the prsTitleCol
	 */
	public String getPrsTitleCol() {
		return prsTitleCol;
	}
	/**
	 * @param prsTitleCol the prsTitleCol to set
	 */
	public void setPrsTitleCol(String prsTitleCol) {
		this.prsTitleCol = prsTitleCol;
	}
	/**
	 * @return the prdReqNotes
	 */
	public String getPrdReqNotes() {
		return prsReqNotes;
	}
	/**
	 * @param prdReqNotes the prdReqNotes to set
	 */
	public void setPrdReqNotes(String prdReqNotes) {
		this.prsReqNotes = prdReqNotes;
	}
	/**
	 * @return the childName
	 */
	public String getChildName() {
		return childName;
	}
	/**
	 * @param childName the childName to set
	 */
	public void setChildName(String childName) {
		this.childName = childName;
	}
	/**
	 * @return the childType
	 */
	public String getChildType() {
		return childType;
	}
	/**
	 * @param childType the childType to set
	 */
	public void setChildType(String childType) {
		this.childType = childType;
	}
	
	/**
	 * @return the indicator
	 */
	public String getIndicator() {
		return indicator;
	}
	/**
	 * @param indicator the indicator to set
	 */
	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}
	/**
	 * @return the uom
	 */
	public String getUom() {
		return uom;
	}
	/**
	 * @param uom the uom to set
	 */
	public void setUom(String uom) {
		this.uom = uom;
	}
	/**
	 * @return the reqmtValue
	 */
	public String getReqmtValue() {
		return reqmtValue;
	}
	/**
	 * @param reqmtValue the reqmtValue to set
	 */
	public void setReqmtValue(String reqmtValue) {
		this.reqmtValue = reqmtValue;
	}
	/**
	 * @return the prsLevel
	 */
	public String getPrsLevel() {
		return prsLevel;
	}
	/**
	 * @param prsLevel the prsLevel to set
	 */
	public void setPrsLevel(String prsLevel) {
		this.prsLevel = prsLevel;
	}
	/**
	 * @return the fromName
	 */
	public String getFromName() {
		return fromName;
	}
	/**
	 * @param fromName the fromName to set
	 */
	public void setFromName(String fromName) {
		this.fromName = fromName;
	}
	/**
	 * @return the fromType
	 */
	public String getFromType() {
		return fromType;
	}
	/**
	 * @param fromType the fromType to set
	 */
	public void setFromType(String fromType) {
		this.fromType = fromType;
	}
	/**
	 * @return the toName
	 */
	public String getToName() {
		return toName;
	}
	/**
	 * @param toName the toName to set
	 */
	public void setToName(String toName) {
		this.toName = toName;
	}
	/**
	 * @return the toType
	 */
	public String getToType() {
		return toType;
	}
	/**
	 * @param toType the toType to set
	 */
	public void setToType(String toType) {
		this.toType = toType;
	}
	/**
	 * @return the crsLevel
	 */
	public String getCrsLevel() {
		return crsLevel;
	}
	/**
	 * @param crsLevel the crsLevel to set
	 */
	public void setCrsLevel(String crsLevel) {
		this.crsLevel = crsLevel;
	}
	/**
	 * @return the pcName
	 */
	public String getPcName() {
		return pcName;
	}
	/**
	 * @param pcName the pcName to set
	 */
	public void setPcName(String pcName) {
		this.pcName = pcName;
	}
	/**
	 * @return the pcDesc
	 */
	public String getPcDesc() {
		return pcDesc;
	}
	/**
	 * @param pcDesc the pcDesc to set
	 */
	public void setPcDesc(String pcDesc) {
		this.pcDesc = pcDesc;
	}
	/**
	 * @return the pcBasedOn
	 */
	public String getPcBasedOn() {
		return pcBasedOn;
	}
	/**
	 * @param pcBasedOn the pcBasedOn to set
	 */
	public void setPcBasedOn(String pcBasedOn) {
		this.pcBasedOn = pcBasedOn;
	}
	/**
	 * @return the pcState
	 */
	public String getPcState() {
		return pcState;
	}
	/**
	 * @param pcState the pcState to set
	 */
	public void setPcState(String pcState) {
		this.pcState = pcState;
	}
	/**
	 * @return the pcParentPc
	 */
	public String getPcParentPc() {
		return pcParentPc;
	}
	/**
	 * @param pcParentPc the pcParentPc to set
	 */
	public void setPcParentPc(String pcParentPc) {
		this.pcParentPc = pcParentPc;
	}
	/**
	 * @return the pcTopLevelParent
	 */
	public String getPcTopLevelParent() {
		return pcTopLevelParent;
	}
	/**
	 * @param pcTopLevelParent the pcTopLevelParent to set
	 */
	public void setPcTopLevelParent(String pcTopLevelParent) {
		this.pcTopLevelParent = pcTopLevelParent;
	}
	/**
	 * @return the pcDerviedFrom
	 */
	public String getPcDerviedFrom() {
		return pcDerviedFrom;
	}
	/**
	 * @param pcDerviedFrom the pcDerviedFrom to set
	 */
	public void setPcDerviedFrom(String pcDerviedFrom) {
		this.pcDerviedFrom = pcDerviedFrom;
	}
	/**
	 * @return the pcPurpose
	 */
	public String getPcPurpose() {
		return pcPurpose;
	}
	/**
	 * @param pcPurpose the pcPurpose to set
	 */
	public void setPcPurpose(String pcPurpose) {
		this.pcPurpose = pcPurpose;
	}
	/**
	 * @return the cfName
	 */
	public String getCfName() {
		return cfName;
	}
	/**
	 * @param cfName the cfName to set
	 */
	public void setCfName(String cfName) {
		this.cfName = cfName;
	}
	/**
	 * @return the cfDisplyName
	 */
	public String getCfDisplyName() {
		return cfDisplyName;
	}
	/**
	 * @param cfDisplyName the cfDisplyName to set
	 */
	public void setCfDisplyName(String cfDisplyName) {
		this.cfDisplyName = cfDisplyName;
	}
	/**
	 * @return the cfConfigOption
	 */
	public String getCfConfigOption() {
		return cfConfigOption;
	}
	/**
	 * @param cfConfigOption the cfConfigOption to set
	 */
	public void setCfConfigOption(String cfConfigOption) {
		this.cfConfigOption = cfConfigOption;
	}
	/**
	 * @return the cfConfOptDispName
	 */
	public String getCfConfOptDispName() {
		return cfConfOptDispName;
	}
	/**
	 * @param cfConfOptDispName the cfConfOptDispName to set
	 */
	public void setCfConfOptDispName(String cfConfOptDispName) {
		this.cfConfOptDispName = cfConfOptDispName;
	}
	/**
	 * @return the lfLevel
	 */
	public String getLfLevel() {
		return lfLevel;
	}
	/**
	 * @param lfLevel the lfLevel to set
	 */
	public void setLfLevel(String lfLevel) {
		this.lfLevel = lfLevel;
	}
	/**
	 * @return the lfFeatDsplName
	 */
	public String getLfFeatDsplName() {
		return lfFeatDsplName;
	}
	/**
	 * @param lfFeatDsplName the lfFeatDsplName to set
	 */
	public void setLfFeatDsplName(String lfFeatDsplName) {
		this.lfFeatDsplName = lfFeatDsplName;
	}
	/**
	 * @return the lfFeatName
	 */
	public String getLfFeatName() {
		return lfFeatName;
	}
	/**
	 * @param lfFeatName the lfFeatName to set
	 */
	public void setLfFeatName(String lfFeatName) {
		this.lfFeatName = lfFeatName;
	}
	/**
	 * @return the lfFeatDesc
	 */
	public String getLfFeatDesc() {
		return lfFeatDesc;
	}
	/**
	 * @param lfFeatDesc the lfFeatDesc to set
	 */
	public void setLfFeatDesc(String lfFeatDesc) {
		this.lfFeatDesc = lfFeatDesc;
	}
	
	/**
	 * @return the ceLevel
	 */
	public String getCeLevel() {
		return ceLevel;
	}
	/**
	 * @param ceLevel the ceLevel to set
	 */
	public void setCeLevel(String ceLevel) {
		this.ceLevel = ceLevel;
	}
	/**
	 * @return the ceHwClNum
	 */
	public String getCeHwClNum() {
		return ceHwClNum;
	}
	/**
	 * @param ceHwClNum the ceHwClNum to set
	 */
	public void setCeHwClNum(String ceHwClNum) {
		this.ceHwClNum = ceHwClNum;
	}
	
	/**
	 * @return the ceSWClNum
	 */
	public String getCeSWClNum() {
		return ceSWClNum;
	}
	/**
	 * @param ceSWClNum the ceSWClNum to set
	 */
	public void setCeSWClNum(String ceSWClNum) {
		this.ceSWClNum = ceSWClNum;
	}
	/**
	 * @return the crName
	 */
	public String getCrName() {
		return crName;
	}
	/**
	 * @param crName the crName to set
	 */
	public void setCrName(String crName) {
		this.crName = crName;
	}
	/**
	 * @return the crTitle
	 */
	public String getCrTitle() {
		return crTitle;
	}
	/**
	 * @param crTitle the crTitle to set
	 */
	public void setCrTitle(String crTitle) {
		this.crTitle = crTitle;
	}
	/**
	 * @return the crState
	 */
	public String getCrState() {
		return crState;
	}
	/**
	 * @param crState the crState to set
	 */
	public void setCrState(String crState) {
		this.crState = crState;
	}
	/**
	 * @return the crSatisfiedBy
	 */
	public String getCrSatisfiedBy() {
		return crSatisfiedBy;
	}
	/**
	 * @param crSatisfiedBy the crSatisfiedBy to set
	 */
	public void setCrSatisfiedBy(String crSatisfiedBy) {
		this.crSatisfiedBy = crSatisfiedBy;
	}
	/**
	 * @return the crEntrpIdnFr
	 */
	public String getCrEntrpIdnFr() {
		return crEntrpIdnFr;
	}
	/**
	 * @param crEntrpIdnFr the crEntrpIdnFr to set
	 */
	public void setCrEntrpIdnFr(String crEntrpIdnFr) {
		this.crEntrpIdnFr = crEntrpIdnFr;
	}
	/**
	 * @return the coName
	 */
	public String getCoName() {
		return coName;
	}
	/**
	 * @param coName the coName to set
	 */
	public void setCoName(String coName) {
		this.coName = coName;
	}
	/**
	 * @return the coCrName
	 */
	public String getCoCrName() {
		return coCrName;
	}
	/**
	 * @param coCrName the coCrName to set
	 */
	public void setCoCrName(String coCrName) {
		this.coCrName = coCrName;
	}
	/**
	 * @return the pathFlag
	 */
	public String getPathFlag() {
		return pathFlag;
	}
	/**
	 * @param pathFlag the pathFlag to set
	 */
	public void setPathFlag(String pathFlag) {
		this.pathFlag = pathFlag;
	}
	/**
	 * @return the prsParentName
	 */
	public String getPrsParentName() {
		return prsParentName;
	}
	/**
	 * @param prsParentName the prsParentName to set
	 */
	public void setPrsParentName(String prsParentName) {
		this.prsParentName = prsParentName;
	}
	/**
	 * @return the prsParentType
	 */
	public String getPrsParentType() {
		return prsParentType;
	}
	/**
	 * @param prsParentType the prsParentType to set
	 */
	public void setPrsParentType(String prsParentType) {
		this.prsParentType = prsParentType;
	}
	/**
	 * @return the prsReqNotes
	 */
	public String getPrsReqNotes() {
		return prsReqNotes;
	}
	/**
	 * @param prsReqNotes the prsReqNotes to set
	 */
	public void setPrsReqNotes(String prsReqNotes) {
		this.prsReqNotes = prsReqNotes;
	}
	/**
	 * @return the childDesc
	 */
	public String getChildDesc() {
		return childDesc;
	}
	/**
	 * @param childDesc the childDesc to set
	 */
	public void setChildDesc(String childDesc) {
		this.childDesc = childDesc;
	}
	/**
	 * @return the childTitle
	 */
	public String getChildTitle() {
		return childTitle;
	}
	/**
	 * @param childTitle the childTitle to set
	 */
	public void setChildTitle(String childTitle) {
		this.childTitle = childTitle;
	}
	/**
	 * @return the dfsOrder
	 */
	public String getDfsOrder() {
		return dfsOrder;
	}
	/**
	 * @param dfsOrder the dfsOrder to set
	 */
	public void setDfsOrder(String dfsOrder) {
		this.dfsOrder = dfsOrder;
	}
	/**
	 * @return the crsrLevel
	 */
	public String getCrsrLevel() {
		return crsrLevel;
	}
	/**
	 * @param crsrLevel the crsrLevel to set
	 */
	public void setCrsrLevel(String crsrLevel) {
		this.crsrLevel = crsrLevel;
	}
	/**
	 * @return the crsrName
	 */
	public String getCrsrName() {
		return crsrName;
	}
	/**
	 * @param crsrName the crsrName to set
	 */
	public void setCrsrName(String crsrName) {
		this.crsrName = crsrName;
	}
	/**
	 * @return the crsrTitle
	 */
	public String getCrsrTitle() {
		return crsrTitle;
	}
	/**
	 * @param crsrTitle the crsrTitle to set
	 */
	public void setCrsrTitle(String crsrTitle) {
		this.crsrTitle = crsrTitle;
	}
	/**
	 * @return the crsrRevision
	 */
	public String getCrsrRevision() {
		return crsrRevision;
	}
	/**
	 * @param crsrRevision the crsrRevision to set
	 */
	public void setCrsrRevision(String crsrRevision) {
		this.crsrRevision = crsrRevision;
	}
	/**
	 * @return the crsrtoType
	 */
	public String getCrsrtoType() {
		return crsrtoType;
	}
	/**
	 * @param crsrtoType the crsrtoType to set
	 */
	public void setCrsrtoType(String crsrtoType) {
		this.crsrtoType = crsrtoType;
	}
	/**
	 * @return the ceiQuantity
	 */
	public String getCeiQuantity() {
		return ceiQuantity;
	}
	/**
	 * @param ceiQuantity the ceiQuantity to set
	 */
	public void setCeiQuantity(String ceiQuantity) {
		this.ceiQuantity = ceiQuantity;
	}
	/**
	 * @return the clinIndicator
	 */
	public String getClinIndicator() {
		return clinIndicator;
	}
	/**
	 * @param clinIndicator the clinIndicator to set
	 */
	public void setClinIndicator(String clinIndicator) {
		this.clinIndicator = clinIndicator;
	}
	/**
	 * @return the ceDispName
	 */
	public String getCeDispName() {
		return ceDispName;
	}
	/**
	 * @param ceDispName the ceDispName to set
	 */
	public void setCeDispName(String ceDispName) {
		this.ceDispName = ceDispName;
	}
	/**
	 * @return the ceName
	 */
	public String getCeName() {
		return ceName;
	}
	/**
	 * @param ceName the ceName to set
	 */
	public void setCeName(String ceName) {
		this.ceName = ceName;
	}
	/**
	 * @return the ceDesc
	 */
	public String getCeDesc() {
		return ceDesc;
	}
	/**
	 * @param ceDesc the ceDesc to set
	 */
	public void setCeDesc(String ceDesc) {
		this.ceDesc = ceDesc;
	}
	/**
	 * @return the topName
	 */
	public String getTopName() {
		return topName;
	}
	/**
	 * @param topName the topName to set
	 */
	public void setTopName(String topName) {
		this.topName = topName;
	}
	/**
	 * @return the prsFlag
	 */
	public String getPrsFlag() {
		return prsFlag;
	}
	/**
	 * @param prsFlag the prsFlag to set
	 */
	public void setPrsFlag(String prsFlag) {
		this.prsFlag = prsFlag;
	}
	
	/**
	 * @return
	 */
	public String getProjectName() {
		return projectName;
	}
	/**
	 * @param projectName
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	/**
	 * @return
	 */
	public String getProjectTitle() {
		return projectTitle;
	}
	/**
	 * @param projectTitle
	 */
	public void setProjectTitle(String projectTitle) {
		this.projectTitle = projectTitle;
	}
	/**
	 * @return the cntrtNm
	 */
	public String getCntrtNm() {
		return cntrtNm;
	}
	/**
	 * @param cntrtNm the cntrtNm to set
	 */
	public void setCntrtNm(String cntrtNm) {
		this.cntrtNm = cntrtNm;
	}
	/**
	 * @return the cntrtDesc
	 */
	public String getCntrtDesc() {
		return cntrtDesc;
	}
	/**
	 * @param cntrtDesc the cntrtDesc to set
	 */
	public void setCntrtDesc(String cntrtDesc) {
		this.cntrtDesc = cntrtDesc;
	}
	/**
	 * @return the hwPrdctNm
	 */
	public String getHwPrdctNm() {
		return hwPrdctNm;
	}
	/**
	 * @param hwPrdctNm the hwPrdctNm to set
	 */
	public void setHwPrdctNm(String hwPrdctNm) {
		this.hwPrdctNm = hwPrdctNm;
	}
	/**
	 * @return the prdtConfigNm
	 */
	public String getPrdtConfigNm() {
		return prdtConfigNm;
	}
	/**
	 * @param prdtConfigNm the prdtConfigNm to set
	 */
	public void setPrdtConfigNm(String prdtConfigNm) {
		this.prdtConfigNm = prdtConfigNm;
	}
	/**
	 * @return the prdtConfigDesc
	 */
	public String getPrdtConfigDesc() {
		return prdtConfigDesc;
	}
	/**
	 * @param prdtConfigDesc the prdtConfigDesc to set
	 */
	public void setPrdtConfigDesc(String prdtConfigDesc) {
		this.prdtConfigDesc = prdtConfigDesc;
	}
	/**
	 * @return the selCstGrpList
	 */
	public List<String> getSelCstGrpList() {
		return selCstGrpList;
	}
	/**
	 * @param selCstGrpList the selCstGrpList to set
	 */
	public void setSelCstGrpList(List<String> selCstGrpList) {
		this.selCstGrpList = selCstGrpList;
	}
	/**
	 * @return the selPcList
	 */
	public List<String> getSelPcList() {
		return selPcList;
	}
	/**
	 * @param selPcList the selPcList to set
	 */
	public void setSelPcList(List<String> selPcList) {
		this.selPcList = selPcList;
	}
	/**
	 * @return the cfId
	 */
	public String getCfId() {
		return cfId;
	}
	/**
	 * @param cfId the cfId to set
	 */
	public void setCfId(String cfId) {
		this.cfId = cfId;
	}
	/**
	 * @return the cfConfId
	 */
	public String getCfConfId() {
		return cfConfId;
	}
	/**
	 * @param cfConfId the cfConfId to set
	 */
	public void setCfConfId(String cfConfId) {
		this.cfConfId = cfConfId;
	}
	/**
	 * @return the crId
	 */
	public String getCrId() {
		return crId;
	}
	/**
	 * @param crId the crId to set
	 */
	public void setCrId(String crId) {
		this.crId = crId;
	}
	/**
	 * @return the crsrId
	 */
	public String getCrsrId() {
		return crsrId;
	}
	/**
	 * @param crsrId the crsrId to set
	 */
	public void setCrsrId(String crsrId) {
		this.crsrId = crsrId;
	}
		/**
	 * @return the ceId
	 */
	public String getCeId() {
		return ceId;
	}
	/**
	 * @param ceId the ceId to set
	 */
	public void setCeId(String ceId) {
		this.ceId = ceId;
	}
	/**
	 * @return the lfFeatId
	 */
	public String getLfFeatId() {
		return lfFeatId;
	}
	/**
	 * @param lfFeatId the lfFeatId to set
	 */
	public void setLfFeatId(String lfFeatId) {
		this.lfFeatId = lfFeatId;
	}
	/**
	 * @return the sso
	 */
	public String getSso() {
		return sso;
	}
	/**
	 * @param sso the sso to set
	 */
	public void setSso(String sso) {
		this.sso = sso;
	}
	/**
	 * @return the coId
	 */
	public String getCoId() {
		return coId;
	}
	/**
	 * @param coId the coId to set
	 */
	public void setCoId(String coId) {
		this.coId = coId;
	}
	/**
	 * @return the coState
	 */
	public String getCoState() {
		return coState;
	}
	/**
	 * @param coState the coState to set
	 */
	public void setCoState(String coState) {
		this.coState = coState;
	}
	/**
	 * @return the coCrId
	 */
	public String getCoCrId() {
		return coCrId;
	}
	/**
	 * @param coCrId the coCrId to set
	 */
	public void setCoCrId(String coCrId) {
		this.coCrId = coCrId;
	}
	/**
	 * @return the coCrState
	 */
	public String getCoCrState() {
		return coCrState;
	}
	/**
	 * @param coCrState the coCrState to set
	 */
	public void setCoCrState(String coCrState) {
		this.coCrState = coCrState;
	}
	/**
	 * @return the coFeatName
	 */
	public String getCoFeatName() {
		return coFeatName;
	}
	/**
	 * @param coFeatName the coFeatName to set
	 */
	public void setCoFeatName(String coFeatName) {
		this.coFeatName = coFeatName;
	}
	/**
	 * @return the coDesc
	 */
	public String getCoDesc() {
		return coDesc;
	}
	/**
	 * @param coDesc the coDesc to set
	 */
	public void setCoDesc(String coDesc) {
		this.coDesc = coDesc;
	}
	/**
	 * @return the reqId
	 */
	public String getReqId() {
		return reqId;
	}
	/**
	 * @param reqId the reqId to set
	 */
	public void setReqId(String reqId) {
		this.reqId = reqId;
	}
	/**
	 * @return the reqName
	 */
	public String getReqName() {
		return reqName;
	}
	/**
	 * @param reqName the reqName to set
	 */
	public void setReqName(String reqName) {
		this.reqName = reqName;
	}
	/**
	 * @return the reqDesc
	 */
	public String getReqDesc() {
		return reqDesc;
	}
	/**
	 * @param reqDesc the reqDesc to set
	 */
	public void setReqDesc(String reqDesc) {
		this.reqDesc = reqDesc;
	}
	/**
	 * @return the feqSeqOrder
	 */
	public String getFeqSeqOrder() {
		return feqSeqOrder;
	}
	/**
	 * @param feqSeqOrder the feqSeqOrder to set
	 */
	public void setFeqSeqOrder(String feqSeqOrder) {
		this.feqSeqOrder = feqSeqOrder;
	}
	/**
	 * @return the crFlag
	 */
	public String getCrFlag() {
		return crFlag;
	}
	/**
	 * @param crFlag the crFlag to set
	 */
	public void setCrFlag(String crFlag) {
		this.crFlag = crFlag;
	}
	/**
	 * @return the shpOrdrNum
	 */
	public String getShpOrdrNum() {
		return shpOrdrNum;
	}
	/**
	 * @param shpOrdrNum the shpOrdrNum to set
	 */
	public void setShpOrdrNum(String shpOrdrNum) {
		this.shpOrdrNum = shpOrdrNum;
	}
	/**
	 * @return the optSubType
	 */
	public String getOptSubType() {
		return optSubType;
	}
	/**
	 * @param optSubType the optSubType to set
	 */
	public void setOptSubType(String optSubType) {
		this.optSubType = optSubType;
	}
	/**
	 * @return the crsrDesc
	 */
	public String getCrsrDesc() {
		return crsrDesc;
	}
	/**
	 * @param crsrDesc the crsrDesc to set
	 */
	public void setCrsrDesc(String crsrDesc) {
		this.crsrDesc = crsrDesc;
	}
	/**
	 * @return
	 */
	public String getIsOption() {
		return isOption;
	}
	/**
	 * @param isOption
	 */
	public void setIsOption(String isOption) {
		this.isOption = isOption;
	}
	/**
	 * @return the legacyFACode
	 */
	public String getLegacyFACode() {
		return legacyFACode;
	}
	/**
	 * @param legacyFACode the legacyFACode to set
	 */
	public void setLegacyFACode(String legacyFACode) {
		this.legacyFACode = legacyFACode;
	}
	/**
	 * @return the prsChildId
	 */
	public String getPrsChildId() {
		return prsChildId;
	}
	/**
	 * @param prsChildId the prsChildId to set
	 */
	public void setPrsChildId(String prsChildId) {
		this.prsChildId = prsChildId;
	}
	/**
	 * @return the prsReqFlag
	 */
	public boolean isPrsReqFlag() {
		return prsReqFlag;
	}
	/**
	 * @param prsReqFlag the prsReqFlag to set
	 */
	public void setPrsReqFlag(boolean prsReqFlag) {
		this.prsReqFlag = prsReqFlag;
	}
	/**
	 * @return the topPrsLvlFlag
	 */
	public boolean isTopPrsLvlFlag() {
		return topPrsLvlFlag;
	}
	/**
	 * @param topPrsLvlFlag the topPrsLvlFlag to set
	 */
	public void setTopPrsLvlFlag(boolean topPrsLvlFlag) {
		this.topPrsLvlFlag = topPrsLvlFlag;
	}
	/**
	 * @return the topCrsLvlFlag
	 */
	public boolean isTopCrsLvlFlag() {
		return topCrsLvlFlag;
	}
	/**
	 * @param topCrsLvlFlag the topCrsLvlFlag to set
	 */
	public void setTopCrsLvlFlag(boolean topCrsLvlFlag) {
		this.topCrsLvlFlag = topCrsLvlFlag;
	}
	/**
	 * @return the prsChapterFlg
	 */
	public boolean isPrsChapterFlg() {
		return prsChapterFlg;
	}
	/**
	 * @param prsChapterFlg the prsChapterFlg to set
	 */
	public void setPrsChapterFlg(boolean prsChapterFlg) {
		this.prsChapterFlg = prsChapterFlg;
	}
	/**
	 * @return the crsChapterFlg
	 */
	public boolean isCrsChapterFlg() {
		return crsChapterFlg;
	}
	/**
	 * @param crsChapterFlg the crsChapterFlg to set
	 */
	public void setCrsChapterFlg(boolean crsChapterFlg) {
		this.crsChapterFlg = crsChapterFlg;
	}
	/**
	 * @return the contractExcel
	 */
	public String getContractExcel() {
		return contractExcel;
	}
	/**
	 * @param contractExcel the contractExcel to set
	 */
	public void setContractExcel(String contractExcel) {
		this.contractExcel = contractExcel;
	}
	/**
	 * @return the projectNameExcel
	 */
	public String getProjectNameExcel() {
		return projectNameExcel;
	}
	/**
	 * @param projectNameExcel the projectNameExcel to set
	 */
	public void setProjectNameExcel(String projectNameExcel) {
		this.projectNameExcel = projectNameExcel;
	}
	
	/**
	 * @return the pcNameExl
	 */
	public String getPcNameExl() {
		return pcNameExl;
	}
	
	/**
	 * @param pcNameExl the pcNameExl to set
	 */
	public void setPcNameExl(String pcNameExl) {
		this.pcNameExl = pcNameExl;
	}
	
	/**
	 * @return the crsReqFlg
	 */
	public boolean isCrsReqFlg() {
		return crsReqFlg;
	}
	
	/**
	 * @param crsReqFlg the crsReqFlg to set
	 */
	public void setCrsReqFlg(boolean crsReqFlg) {
		this.crsReqFlg = crsReqFlg;
	}
	
	/**
	 * @return the pcCstGrp
	 */
	public String getPcCstGrp() {
		return pcCstGrp;
	}
	
	/**
	 * @param pcCstGrp the pcCstGrp to set
	 */
	public void setPcCstGrp(String pcCstGrp) {
		this.pcCstGrp = pcCstGrp;
	}
	/**
	 * @return the systemFlag
	 */
	public boolean isSystemFlag() {
		return systemFlag;
	}
	/**
	 * @param systemFlag the systemFlag to set
	 */
	public void setSystemFlag(boolean systemFlag) {
		this.systemFlag = systemFlag;
	}
	/**
	 * @return the systemName
	 */
	public String getSystemName() {
		return systemName;
	}
	/**
	 * @param systemName the systemName to set
	 */
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	/**
	 * @return the vistFlag
	 */
	public boolean isVistFlag() {
		return vistFlag;
	}
	/**
	 * @param vistFlag the vistFlag to set
	 */
	public void setVistFlag(boolean vistFlag) {
		this.vistFlag = vistFlag;
	}
	
	
	
}
