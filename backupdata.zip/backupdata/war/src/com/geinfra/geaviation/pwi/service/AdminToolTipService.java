package com.geinfra.geaviation.pwi.service;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.context.PWiContext;
import com.geinfra.geaviation.pwi.dao.AdminToolTipDAO;
import com.geinfra.geaviation.pwi.model.AdminToolTipVO;

/**
 * 
 * Project : Product Lifecycle Management Date Written : May 19, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : AdminSettingsService
 * 
 * Revision Log May 19, 2010 | v1.0.
 * --------------------------------------------------------------
 */

public class AdminToolTipService {
	public static final String SETTING_BATCH_DISABLED = "BatchDisabled";
	public static final String SETTING_ToolTip_TEXT = "ToolTipText";
	// Injected
	private AdminToolTipDAO adminToolTipDAO;

	private AdminToolTipVO getToolTip(String settingName) throws PWiException {
		return adminToolTipDAO.getToolTip(settingName);
	}

	private void createToolTip(String name, String value) throws PWiException {
		adminToolTipDAO.createToolTip(name, value,
				PWiContext.getCurrentInstance().getUserSso());
	}

	private void updateToolTip(String name, String value) throws PWiException {
		adminToolTipDAO.updateToolTip(name, value,
				PWiContext.getCurrentInstance().getUserSso());
	}

	public boolean isBatchDisabled() throws PWiException {
		AdminToolTipVO setting = adminToolTipDAO
				.getToolTip(AdminToolTipService.SETTING_BATCH_DISABLED);
		if (setting == null) {
			return false;
		}
		return Boolean.parseBoolean(setting.getTlTpParVal());
	}
	public String getHomeToolTip() throws PWiException {

		AdminToolTipVO setting = adminToolTipDAO
				.getToolTip(AdminToolTipService.SETTING_ToolTip_TEXT);

		return setting != null ? setting.getTlTpParVal() : "";
	}

	public void setHomeToolTip(String homeToolTipText) throws PWiException {
		if (getToolTip(SETTING_ToolTip_TEXT) == null) {
			createToolTip(SETTING_ToolTip_TEXT, homeToolTipText);
		} else {
			updateToolTip(SETTING_ToolTip_TEXT, homeToolTipText);
		}
	}
	/**
	 * @param adminSettingsDAO
	 *            the adminSettingsDAO to set
	 */
	public void setAdminToolTipDAO(AdminToolTipDAO adminToolTipDAO) {
		this.adminToolTipDAO = adminToolTipDAO;
	}

}