/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMPartFamAttrDaoIfc.java
 * @Creation date: 24-Feb-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMInterfaceAttrData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMPartFamAttrDaoIfc {
	/**
	 * This method is used to getDropDownData
	 * @return java.util.Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getPartFamilyDropDownData() throws PLMCommonException;
	/**
	 * This method is used to get Attribute name for part family
	 * 
	 * @param selectedPartFamily
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getAttrNameForPartFamily(String selectedPartFamily) throws PLMCommonException;
	/**
	 * This method is to get count for Part Family
	 * 
	 * @param partFamily
	 * @return int
	 * @throws PLMCommonException
	 */
	public int getPartFamilyCount(String partFamily)throws PLMCommonException;
	/**
	 * This method is to get part family Master result
	 * 
	 * @param object,string,boolean
	 * @return map
	 * @throws PLMCommonException
	 */
	public Map<String,String> getPartFamilyAttrMasterResultList(PLMInterfaceAttrData partFamilyIntAttrData,String optionType,boolean hyperLinkFlag
			,boolean partAttribFlag,boolean partFamilyAttribFlag) throws PLMCommonException;

}
