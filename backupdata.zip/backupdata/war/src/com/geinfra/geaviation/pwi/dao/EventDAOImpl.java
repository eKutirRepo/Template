package com.geinfra.geaviation.pwi.dao;

import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.List;

import jxl.common.Logger;

import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.MinimalQueryExctnEventVO;
import com.geinfra.geaviation.pwi.model.PWiQueryExctnEventVO;
import com.geinfra.geaviation.pwi.model.PWiQueryVO;
import com.geinfra.geaviation.pwi.service.QuerySubmissionService.EventStatus;
import com.geinfra.geaviation.pwi.service.vo.ExecutionMode;
import com.geinfra.geaviation.pwi.service.vo.OutputType;
import com.geinfra.geaviation.pwi.util.ColumnConstants;
import com.geinfra.geaviation.pwi.util.DaoUtil;
import com.geinfra.geaviation.pwi.util.MapperConstants;
import com.geinfra.geaviation.pwi.util.QueryConstants;
import com.geinfra.geaviation.pwi.util.QueryLoader;

/**
 * Project : Product Lifecycle Management Date Written : Apr 12, 2011 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : EventDAOImpl
 * 
 * Revision Log Apr 12, 2011 | v1.0.
 * --------------------------------------------------------------
 */
public class EventDAOImpl implements EventDAO {
	private static final Logger LOGGER = Logger.getLogger(EventDAOImpl.class);

	// Injected
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public Integer insertExecutionEvent(final PWiQueryExctnEventVO event)
			throws PWiException {
		String sql = QueryLoader
				.getQuery(QueryConstants.INSERT_EXECUTION_EVENT);

		Connection connection = null;
		CallableStatement statement = null;
		try {
			connection = jdbcTemplate.getDataSource().getConnection();
			statement = connection.prepareCall(sql);
			int index = 1;

			// Set input parameters
			statement.setString(index++, event.getExecutedBy()); // exctd_by_emply_sso_id
			statement.setInt(index++, event.getQueryId().intValue()); // qry_seq_id
			statement.setInt(index++, event.getColumnCount()); // qry_otpt_col_cnt
			statement.setInt(index++, event.getRowCount()); // qry_otpt_rows_cnt
			DaoUtil.getInstance().setXmlType(statement.getConnection(),
					statement, index++, event.getSelectedColumnsXml()); // qry_slctd_col_nm
			DaoUtil.getInstance().setXmlType(statement.getConnection(),
					statement, index++, event.getSearchCriteriaXml()); // qry_srch_crtr_txt
			statement.setLong(index++, event.getExecutionDuration()); // qry_exctn_scnds_drtn
			statement.setString(index++, event.getExecutionStatus()); // qry_exctn_sccs_ind
			statement.setString(index++, event.getErrorMessage()); // qry_err_msg_txt
			statement.setString(index++, event.getExecutedBy()); // crtd_by
			statement.setString(index++, event.getExecutedBy()); // updtd_by
			if (event.getCustomId() != null) {
				statement.setInt(index++, event.getCustomId().intValue()); // PRTY_CSTM_QRY_SEQ_ID
			} else {
				statement.setNull(index++, Types.INTEGER); // PRTY_CSTM_QRY_SEQ_ID
			}
			statement.setString(index++, event.getQueryProcessorName()); // qry_processor_nm
			statement.setString(index++, event.getExecutionMode()); // qry_exctn_mode
			statement.setString(index++, event.getOutputType()); // qry_output_type
			statement.setString(index++, event.getTemplateId()); // qry_template_id
			statement.setString(index++, event.getExecutedFrom()); // qry_executed_from
			// Set output parameters
			int outputIndex = index;
			statement.registerOutParameter(outputIndex, Types.NUMERIC);

			// Execute query
			
			statement.execute();

			// Retrieve primary key
			int id = statement.getInt(outputIndex);

			return Integer.valueOf(id);
		} catch (SQLException e) {
			throw new PWiException(e);
		} finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
					LOGGER.warn(
							"Failed to close statement when inserting event.",
							e);
				}
			}

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					LOGGER.warn(
							"Failed to close connection when inserting event.",
							e);
				}
			}
		}
	}

	/**
	 * public boolean updateExecutionEventStatus
	 * 
	 * Records the Execution Event's Status as well as other metadata for a
	 * successful execution
	 * 
	 * @param status String representation of the execution status
	 * @param eventSeqId Integer unique to this execution event
	 * @param colCnt number of columns returned by the query
	 * @param rowCnt number of rows returned by the query
	 * @param duration number of milliseconds it took to execute the query
	 */
	public boolean updateExecutionEventStatus(String status,
			Integer eventSeqId, Integer colCnt, Integer rowCnt, long duration) {
		Object[] params = null;
		String sql = QueryConstants.UPDATE_EXECUTION_EVENT_STATUS_SUCCESS;
		params = new Object[5];
		params[0] = status;
		params[1] = colCnt;
		params[2] = rowCnt;
		params[3] = Long.valueOf(duration);
		params[4] = eventSeqId;
		// Note: "last updated by" column not updated because executed from
		// appworx

		int upd = jdbcTemplate.update(QueryLoader.getQuery(sql), params);
		boolean success = false;
		if (upd > 0)
			success = true;
		return success;
	}

	/**
	 * public boolean updateExecutionEventStatus
	 *
	 * Updates only the execution event status; not necessarily success 
	 *
	 * @param status String representation of the execution status
	 * @param eventSeqId Integer unique to this execution event
	 */
	public boolean updateExecutionEventStatus(String status, Integer eventSeqId) {
		Object[] params = null;
		String sql = QueryConstants.UPDATE_EXECUTION_EVENT_STATUS;
		params = new Object[2];
		params[0] = status;
		params[1] = eventSeqId;
		// Note: "last updated by" column not updated because executed from
		// appworx

		int upd = jdbcTemplate.update(QueryLoader.getQuery(sql), params);
		boolean success = false;
		if (upd > 0)
			success = true;
		return success;
	}
	
	public boolean renewQry(Integer eventSeqId) {
		Object[] params = null;
		String sql = QueryConstants.RENEW_QRY;
		params = new Object[1];
		params[0] = eventSeqId;
		
		int upd = jdbcTemplate.update(QueryLoader.getQuery(sql), params);
		boolean success = false;
		if (upd > 0)
			success = true;
		return success;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<MinimalQueryExctnEventVO> getExecutionEventsRunSince(
			final String ssoId, final Date dateRunSince) {
		// Generate SQL
		String sql = getMinimalExecutionEventSelect()
				+ " AND evt.EXCTD_BY_EMPLY_SSO_ID=? AND evt.QRY_EXCTN_DTTM >= ? ORDER BY evt.QRY_EXCTN_DTTM DESC";

		// Set parameters
		PreparedStatementSetter pss = new GetExecutionEventsRunSinceSetter(
				ssoId, dateRunSince);

		// Execute query
		@SuppressWarnings("unchecked")
		List<MinimalQueryExctnEventVO> events = jdbcTemplate.query(sql, pss,
				new MinimalExecutionEventRowMapper());

		return events;
	}

	private static class GetExecutionEventsRunSinceSetter implements
			PreparedStatementSetter {
		private String ssoId;
		private Date dateRunSince;

		public GetExecutionEventsRunSinceSetter(String ssoId, Date dateRunSince) {
			this.ssoId = ssoId;
			this.dateRunSince = dateRunSince;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setString(1, ssoId);
			ps.setTimestamp(2, new Timestamp(dateRunSince.getTime()));
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public List<MinimalQueryExctnEventVO> getExecutionEvents(
			final String ssoId, final int limit) {
		// Generate SQL
		String sql = new StringBuffer("SELECT * FROM (")
				.append(getMinimalExecutionEventSelect())
				.append(" AND evt.EXCTD_BY_EMPLY_SSO_ID=?")
				.append(" ORDER BY evt.QRY_EXCTN_DTTM DESC) WHERE rownum<=?")
				.toString();

		// Set parameters
		PreparedStatementSetter pss = new GetExecutionEventsSetter(ssoId, limit);

		// Execute query
		@SuppressWarnings("unchecked")
		List<MinimalQueryExctnEventVO> events = jdbcTemplate.query(sql, pss,
				new MinimalExecutionEventRowMapper());

		return events;
	}

	private static class GetExecutionEventsSetter implements
			PreparedStatementSetter {
		private String ssoId;
		private int limit;

		public GetExecutionEventsSetter(String ssoId, int limit) {
			this.ssoId = ssoId;
			this.limit = limit;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setString(1, ssoId);
			ps.setInt(2, limit);
		}
	}

	public PWiQueryExctnEventVO getNextBatchExecutionQuery() {
		PWiQueryExctnEventVO batchQuery = null;
		try {
			Object res = jdbcTemplate.queryForObject(QueryLoader
					.getQuery(QueryConstants.GET_NEXT_BATCH_QRY),
					new ExecutionEventRowMapper());
			if (res != null) {
				batchQuery = (PWiQueryExctnEventVO) res;
			}
		} catch (IncorrectResultSizeDataAccessException e) {
			batchQuery = null;
		}
		return batchQuery;
	}

	// TODO pH 2013.03: add another to return by ID with exp dt
	public List<MinimalQueryExctnEventVO> getExecutionEventForUserByStatus(
			String sso, EventStatus eventStatus) {
		StringBuilder builder = new StringBuilder();
		builder.append(getMinimalExecutionEventSelect());
		builder.append(" AND evt.");
		builder.append(PWiQueryExctnEventVO.EXCTD_BY_EMPLY_SSO_ID);
		builder.append("=?");
		if("B".equals(String.valueOf(eventStatus)))
		{
		builder.append(" AND ( evt.");
		builder.append(PWiQueryExctnEventVO.QRY_EXCTN_SCCS_IND);
		builder.append("=?");
		builder.append(" OR  evt.");
		builder.append(PWiQueryExctnEventVO.QRY_EXCTN_SCCS_IND);
		builder.append("='F' )");
		}
		else{
			builder.append(" AND evt.");
			builder.append(PWiQueryExctnEventVO.QRY_EXCTN_SCCS_IND);
			builder.append("=?");
		}
		builder.append(" ORDER BY evt.QRY_EXCTN_DTTM DESC");

		// Set parameters
		PreparedStatementSetter pss = new GetExecutionEventForUserByStatus(sso,
				eventStatus);

		// Execute query
		@SuppressWarnings("unchecked")
		List<MinimalQueryExctnEventVO> events = jdbcTemplate.query(builder
				.toString(), pss, new MinimalExecutionEventRowMapper());

		return events;
	}

	private static class GetExecutionEventForUserByStatus implements
			PreparedStatementSetter {
		private String sso;
		private EventStatus eventStatus;

		public GetExecutionEventForUserByStatus(String sso,
				EventStatus eventStatus) {
			this.sso = sso;
			this.eventStatus = eventStatus;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setString(1, sso);
			ps.setString(2, eventStatus.toString());
		}
	}

	public PWiQueryExctnEventVO getExecutionEventById(final Integer eventId) {
		String sql = getStandardExecutionEventSelect()
				+ " AND evt.QRY_EXCTN_EVNT_SEQ_ID=?";

		PreparedStatementSetter pss = new GetExecutionEventByIdSetter(eventId);

		@SuppressWarnings("unchecked")
		List<PWiQueryExctnEventVO> resultList = (List<PWiQueryExctnEventVO>) jdbcTemplate
				.query(sql, pss, new ExecutionEventRowMapper());
		if (resultList.size() > 1) {
			throw new IllegalStateException(
					"Multiple rows returned for event id!  event id: "
							+ eventId);
		}
		if (resultList.isEmpty()) {
			return null;
		}
		return resultList.get(0);
	}

	private static class GetExecutionEventByIdSetter implements
			PreparedStatementSetter {
		private Integer eventId;

		public GetExecutionEventByIdSetter(Integer eventId) {
			this.eventId = eventId;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setInt(1, eventId.intValue());
		}
	}

	/**
	 * Standard event row mapper which maps an event from the event table along
	 * with the associated query from the query table.
	 */
	private static class ExecutionEventRowMapper implements RowMapper {
		public PWiQueryExctnEventVO mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			// Map fields from execution event table
			PWiQueryExctnEventVO eventVo = new PWiQueryExctnEventVO();
			eventVo.setEventId(Integer.valueOf(rs
					.getInt(PWiQueryExctnEventVO.QRY_EXCTN_EVNT_SEQ_ID)));
			eventVo.setQueryId(Integer.valueOf(rs
					.getInt(PWiQueryExctnEventVO.QRY_SEQ_ID)));
			int customId = rs
					.getInt(PWiQueryExctnEventVO.PRTY_CSTM_QRY_SEQ_ID);
			eventVo.setCustomId(customId == 0 ? null : Integer
					.valueOf(customId));
			eventVo.setExecutedBy(rs
					.getString(PWiQueryExctnEventVO.EXCTD_BY_EMPLY_SSO_ID));
			eventVo.setDateExecuted(rs
					.getTimestamp(PWiQueryExctnEventVO.QRY_EXCTN_DTTM));
			eventVo.setExecutionDuration(rs
					.getLong(PWiQueryExctnEventVO.QRY_EXCTN_SCNDS_DRTN));
			eventVo.setColumnCount(rs
					.getInt(PWiQueryExctnEventVO.QRY_OTPT_COL_CNT));
			eventVo.setRowCount(rs
					.getInt(PWiQueryExctnEventVO.QRY_OTPT_ROWS_CNT));
			eventVo.setExecutionStatus(rs
					.getString(PWiQueryExctnEventVO.QRY_EXCTN_SCCS_IND));
			eventVo.setErrorMessage(rs
					.getString(PWiQueryExctnEventVO.QRY_ERR_MSG_TXT));

			Clob selectedColumnsClob = rs
					.getClob(PWiQueryExctnEventVO.QRY_SLCTD_COL_NM);
			if (selectedColumnsClob != null) {
				String xml = selectedColumnsClob.getSubString(1L,
						(int) selectedColumnsClob.length());
				eventVo.setSelectedColumnsXml(xml);
			}
			Clob searchCriteriaClob = rs
					.getClob(PWiQueryExctnEventVO.QRY_SRCH_CRTR_TXT);
			if (searchCriteriaClob != null) {
				String xml = searchCriteriaClob.getSubString(1L,
						(int) searchCriteriaClob.length());
				eventVo.setSearchCriteriaXml(xml);
			}

			eventVo.setQueryProcessorName(rs
					.getString(PWiQueryExctnEventVO.QRY_PROCESSOR_NM));
			String execMode = rs
					.getString(PWiQueryExctnEventVO.QRY_EXCTN_MODE);
			if (execMode == null) {
				execMode = ExecutionMode.ONLINE.getId();
			}
			eventVo.setExecutionMode(execMode);
			String outputType = rs
					.getString(PWiQueryExctnEventVO.QRY_OUTPUT_TYPE);
			if (outputType == null) {
				outputType = OutputType.WEB.getId();
			}
			eventVo.setOutputType(outputType);
			eventVo.setTemplateId(rs
					.getString(PWiQueryExctnEventVO.QRY_TEMPLATE_ID));
			eventVo.setExecutedFrom(rs
					.getString(PWiQueryExctnEventVO.QRY_EXECUTED_FROM));
			eventVo.setRerunnable("Y".equals(rs
					.getString(PWiQueryExctnEventVO.QRY_RERUNNABLE)));
			eventVo.setExpirationDate(rs
					.getTimestamp(PWiQueryExctnEventVO.QRY_EXP_DT));

			// Map fields from query table
			PWiQueryVO query = MapperConstants.QUERY_ROW_MAPPER
					.mapRow(rs, rowNum);
			eventVo.setQuery(query);

			return eventVo;
		}
	}
	
	

	/**
	 * Event row mapper for returning multiple history items. Extracts the
	 * minimal amount of data necessary in order to improve performance,
	 * particularly with XML columns which are expensive to extract.
	 */
	private static class MinimalExecutionEventRowMapper implements RowMapper {
		public MinimalQueryExctnEventVO mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			// Map fields from execution event table
			MinimalQueryExctnEventVO eventVo = new MinimalQueryExctnEventVO();
			eventVo.setEventId(Integer.valueOf(rs
					.getInt(PWiQueryExctnEventVO.QRY_EXCTN_EVNT_SEQ_ID)));
			eventVo.setDateExecuted(rs
					.getTimestamp(PWiQueryExctnEventVO.QRY_EXCTN_DTTM));
			eventVo.setRowCount(rs
					.getInt(PWiQueryExctnEventVO.QRY_OTPT_ROWS_CNT));

			Clob searchCriteriaClob = rs
					.getClob(PWiQueryExctnEventVO.QRY_SRCH_CRTR_TXT);
			if (searchCriteriaClob != null) {
				String xml = searchCriteriaClob.getSubString(1L,
						(int) searchCriteriaClob.length());
				eventVo.setSearchCriteriaXml(xml);
			}

			String execMode = rs
					.getString(PWiQueryExctnEventVO.QRY_EXCTN_MODE);
			if (execMode == null) {
				execMode = ExecutionMode.ONLINE.getId();
			}
			else if(execMode.contains("sftp"))
			{
				execMode = ExecutionMode.SFTP.getId();
			}
			eventVo.setExecutionMode(execMode);
			String outputType = rs
					.getString(PWiQueryExctnEventVO.QRY_OUTPUT_TYPE);
			if (outputType == null) {
				outputType = OutputType.WEB.getId();
			}
			eventVo.setOutputType(outputType);
			eventVo.setRerunnable("Y".equals(rs
					.getString(PWiQueryExctnEventVO.QRY_RERUNNABLE)));

			eventVo.setQueryName(rs.getString(ColumnConstants.QRY_NM));

			return eventVo;
		}
	}

	private String getStandardExecutionEventSelect() {
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT evt.QRY_EXCTN_EVNT_SEQ_ID,evt.PRTY_CSTM_QRY_SEQ_ID");
		builder.append(",evt.EXCTD_BY_EMPLY_SSO_ID,evt.QRY_EXCTN_DTTM");
		builder.append(",evt.QRY_EXCTN_SCNDS_DRTN,evt.QRY_OTPT_COL_CNT");
		builder.append(",evt.QRY_OTPT_ROWS_CNT,evt.QRY_EXCTN_SCCS_IND,evt.QRY_ERR_MSG_TXT");
		builder.append(",XMLSerialize(DOCUMENT QRY_SLCTD_COL_NM AS CLOB)QRY_SLCTD_COL_NM");
		builder.append(",XMLSerialize(DOCUMENT QRY_SRCH_CRTR_TXT AS CLOB)QRY_SRCH_CRTR_TXT");
		builder.append(",evt.QRY_PROCESSOR_NM,evt.QRY_EXCTN_MODE,evt.QRY_OUTPUT_TYPE");
		builder.append(",evt.QRY_TEMPLATE_ID,evt.QRY_EXECUTED_FROM");
		builder.append(",evt.QRY_RERUNNABLE,evt.QRY_EXP_DT,qr.QRY_SEQ_ID,qr.QRY_NM");
		builder.append(",XMLSerialize(DOCUMENT qr.QRY_XML_LNG_TXT AS CLOB)QRY_XML_LNG_TXT");
		builder.append(", qr.QRY_KYWRD_TXT, qr.QRY_DESC, qr.QRY_EC_IND, qr.QRY_GE_IND");
		builder.append(" FROM PLMR.PWi_QUERY_EXCTN_EVENT evt, PLMR.PWi_QUERY qr");
		builder.append(" WHERE qr.QRY_SEQ_ID = evt.QRY_SEQ_ID and qr.QRY_LOG_ACTIVE = 'Y'");
		return builder.toString();
	}

	private String getMinimalExecutionEventSelect() {
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT evt.QRY_EXCTN_EVNT_SEQ_ID");
		builder.append(",evt.QRY_EXCTN_DTTM");
		builder.append(",evt.QRY_OTPT_ROWS_CNT");
		builder.append(",XMLSerialize(DOCUMENT QRY_SRCH_CRTR_TXT AS CLOB)QRY_SRCH_CRTR_TXT");
		builder.append(",evt.QRY_EXCTN_MODE");
		builder.append(",evt.QRY_OUTPUT_TYPE");
		builder.append(",evt.QRY_RERUNNABLE, qr.QRY_NM");
		builder.append(" FROM PLMR.PWi_QUERY_EXCTN_EVENT evt, PLMR.PWi_QUERY qr");
		builder.append(" WHERE qr.QRY_SEQ_ID = evt.QRY_SEQ_ID and qr.QRY_LOG_ACTIVE = 'Y'");
		return builder.toString();
	}

	@Override
	public int getNoOfQueryInPipe() {
		// Generate SQL
		String sql = "select count(*) from pwi_query_exctn_event where QRY_EXCTN_SCCS_IND = 'B' OR QRY_EXCTN_SCCS_IND = 'F' OR QRY_EXCTN_SCCS_IND = 'E'";

		// Set parameters
		int noOfQuery = jdbcTemplate.queryForInt(sql);

		return noOfQuery;
	}
	
	
}
