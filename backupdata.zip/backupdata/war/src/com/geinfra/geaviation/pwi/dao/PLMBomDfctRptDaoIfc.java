/**
 * Copyright (C) 2014 GE Infra. All rights reserved
 * 
 * @FileName PLMBomDfctRptDaoIfc.java
 * @Creation date: 15-July-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.data.PLMBomDfctRptData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMBomDfctRptDaoIfc {
	
	/**
	 * This method is used to check for valid partNumber.
	 * 
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<String> checkForValidPartNum(String partNumber)throws PLMCommonException;
	/**
	 * This method is used to get BOM Defect report
	 * 
	 * @param partId
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomDfctRptData> getBomDefectRpt(String partId) throws PLMCommonException;

}
