package com.geinfra.geaviation.pwi.context;

import java.util.Date;

/**
 * Project : Product Lifecycle Management Date Written : Security : GE
 * Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : Provides access to application-scope data for P&Wi.
 * 
 * Revision Log --------------------------------------------------------------
 */
public class PWiApplicationContext {
	public static final String ATTRIBUTE_NAME = "PWiApplicationContext";
	
	private String applicationContextTimestamp;

	public PWiApplicationContext() {
		this.applicationContextTimestamp = String.valueOf(new Date().getTime());
	}

	public String getApplicationContextTimestamp() {
		return applicationContextTimestamp;
	}
}
