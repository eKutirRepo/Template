/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMMBOMPddrMB.java
 * @Creation date: 14-March-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormat;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMMBOMPddrData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMMBOMPddrServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMMBOMPddrMB {
	/**
	 * Holds the Logger.
	 */
	private static final Logger LOG = Logger.getLogger(PLMMBOMPddrMB.class);
	/**
	 *  Holds the PLMMBOMPddrServiceIfc
	 */
	private PLMMBOMPddrServiceIfc plmMBOMPddrService = null;
	/**
	 *  Holds the alertMsgPddrRpt
	 */
	private String alertMsgPddrRpt;
	
	/**
	 * Holds the PLMMBOMPddrData
	 */
	private PLMMBOMPddrData plmMBOMPddrData = null;
	/**
	 * Holds the partName
	 */
	private String partName;
	/**
	 * Holds the showFlag
	 */
	private boolean showFlag;
	/**
	 * Holds the editFlag
	 */
	private boolean editFlag;
	/**
	 * Holds the revisionList
	 */
	private List<SelectItem> revisionList = new ArrayList<SelectItem>();
	/**
	 * Holds the plantNameList
	 */
	private List<SelectItem> plantNameList = new ArrayList<SelectItem>();

	/**
	 * Holds the plmMBOMPddrDataList
	 */
	private List <PLMMBOMPddrData> plmMBOMPddrDataList = new ArrayList<PLMMBOMPddrData>();
	/**
	 * Holds the totalRecCountMsg
	 */
	private String totalRecCountMsg;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;

	/**
	 * Holds the commonMB
	 */
	private PLMCommonMB commonMB = null;
	
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;

	private PLMPwiUserData userDetails = null;

	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");

	/**
	 * This method is used for Loading MBOM PDDR Home Page
	 * 
	 * @return String
	 */
	public String loadMBOMPDDRHome() {
		LOG.info("Entering loadMBOMPDDRHome Method");
		try {
			commonMB.insertCannedRptRecordHitInfo("MBOM PDDR Report");
			
			plmMBOMPddrData = new PLMMBOMPddrData();
			partName="";
			showFlag=false;
			editFlag=false;
			alertMsgPddrRpt = "";
			revisionList = new ArrayList<SelectItem>();
			plantNameList = new ArrayList<SelectItem>();
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@loadMBOMPDDRHome:", exception);
		}
		LOG.info("Exiting loadMBOMPDDRHome Method");
		return "mbomPddrSearch";
	}
	
	/**
	 * This method is used for Reset Data
	 * 
	 * @return String
	 */
	public String resetData(){
		partName="";
		plmMBOMPddrData.setSelectRevision("");
		plmMBOMPddrData.setSelectPlantName("");
		showFlag=false;
		editFlag=false;
		alertMsgPddrRpt = "";
		revisionList = new ArrayList<SelectItem>();
		plantNameList = new ArrayList<SelectItem>();
		return "mbomPddrSearch";
	}
	
	
	/**
	 * This method is used for getRevisionsDropDown
	 * 
	 * @return String
	 */
	public String getRevisionsDropDown() {
		LOG.info("Entering getRevisionsDropDown() Method");
		revisionList = new ArrayList<SelectItem>();
		alertMsgPddrRpt = "";
		String fwdFlag = "mbomPddrSearch";
		int count=0;
		try {
			if(!PLMUtils.isEmpty(partName)){
				
				revisionList = plmMBOMPddrService.getRevisions(partName);

				if(revisionList.size()>0){
				 LOG.info("revisionList size :"+revisionList.size());
				 count =plmMBOMPddrService.getPlantNamesCount(partName);
				   if(count>0){
				      showFlag=true;
				      editFlag=true;
				   }else{
					   alertMsgPddrRpt="Plant Names does not Exist for this Part Name";
						showFlag=false;
						editFlag=false;  
				   }
				 }else{
					alertMsgPddrRpt="Part Name does not Exist..please enter valid Part Name";
					showFlag=false;
					editFlag=false;
				}
			}else{
				alertMsgPddrRpt="Please Enter a Part Name";
				showFlag=false;
				editFlag=false;
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getRevisionsDropDown: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","MBOM PDDR Report");
		} 
		LOG.info("Exiting getRevisionsDropDown() Method");
		return fwdFlag;
	}
	
	/**
	 * This method is used for getDropDownvalues
	 * 
	 */
	public String getPlantNamesDropDown() {
		LOG.info("Entering getPlantNamesDropDown() Method");
		plantNameList = new ArrayList<SelectItem>();
		alertMsgPddrRpt = "";
		String fwdflag = "mbomPddrSearch";
		try {
			if(!PLMUtils.isEmpty(plmMBOMPddrData.getSelectRevision())){
				String[] revisionNameId =  plmMBOMPddrData.getSelectRevision()
						.split("~");
				String revisionName = revisionNameId[1];
				plantNameList = plmMBOMPddrService.getPlantNames(partName,revisionName);
				
				if(plantNameList.size()>0){
				 LOG.info("plantNameList size :"+plantNameList.size());
				}else{
					alertMsgPddrRpt="Plant Names does not exist for this Revision.. Please select another Revision";
				}
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPlantNamesDropDown: ", exception);
		} 
		LOG.info("Exiting getPlantNamesDropDown() Method");
		return fwdflag;
	}
	
	/**
	 * This method is used for Generating MBOM PDDR Report
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String generateEmailReport() throws PWiException {
		LOG.info("Entering generateEmailReport Method");
		String fwdflag = "mbomPddrSearch";
		userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		
		if(!PLMUtils.isEmpty(plmMBOMPddrData.getSelectPlantName()) && !PLMUtils.isEmpty(plmMBOMPddrData.getSelectRevision())){
			alertMsgPddrRpt = PLMConstants.MBOM_MAIL_ALERT_MSG;
			taskExecutor.execute(new MailThread());
			}else if(PLMUtils.isEmpty(plmMBOMPddrData.getSelectRevision())){
			  alertMsgPddrRpt="Please select a Revision";
			  fwdflag = "mbomPddrSearch";
			 }else if(PLMUtils.isEmpty(plmMBOMPddrData.getSelectPlantName())){
			  alertMsgPddrRpt="Please select a Plant Name";
			  fwdflag = "mbomPddrSearch";
			  }
		
		LOG.info("Exiting generateEmailReport Method");
		return fwdflag;
	}

	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendMBOMPDDRReportThroughMail();
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return String
	 */
	public void sendMBOMPDDRReportThroughMail() {
		LOG.info("Entering sendMBOMPDDRReportThroughMail Method");
		String partNameLcl = partName;
		String[] revisionNameId =  plmMBOMPddrData.getSelectRevision()
				.split("~");
		String revisionId = revisionNameId[0];
		String revisionName = revisionNameId[1];
		String plantName = plmMBOMPddrData.getSelectPlantName();
		Date date = new Date();
		String reportDate = String.format(" %tc", date );
		
		String from = PLMConstants.LTTR_MAIL_FROM;

		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.MBOM_MAIL_SUBJECT + partNameLcl;
		StringBuffer mailBody = new StringBuffer().append(toAddressee)
		.append(PLMConstants.MBOM_MAIL_CONTENT)
		.append(partNameLcl)
		.append(".")
		.append(PLMConstants.LTTR_MAIL_SIGNATURE)
		.append(PLMConstants.LTTR_MAIL_FOOTER);
		
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("MBOM_PDDR_REPORT_NAME") +  partNameLcl + "_" + uniqTime + ".xls";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("MBOM_PDDR_REPORT_NAME") +  partNameLcl + "_" + uniqTime + ".zip";
		try {
			List<PLMMBOMPddrData> mbompddrList = plmMBOMPddrService.getMBOMPddrReport(partNameLcl,plantName,revisionName,revisionId);
			saveMBomPddrXls(partNameLcl,revisionName,reportDate,mbompddrList,fileDir,filePathXls);
			PLMUtils.generateZipFile(filePathXls,filePathZip);
			PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendMBOMPDDRReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendMBOMPDDRReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
		} finally {
			deleteFiles(filePathXls,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendMBOMPDDRReportThroughMail Method");
	}

	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return StringBuffer
	 */
	
	public void saveMBomPddrXls(String partNmLcl,String revisionLcl,String reportDateLcl,List<PLMMBOMPddrData> mbompddrList,String fileDir,String filePathXls) throws IOException {
		LOG.info("Entering saveMBomPddrXls Method");
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist = fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXls);
				HSSFWorkbook workbook = new HSSFWorkbook();
				HSSFSheet sheet =  workbook.createSheet(partNmLcl);
				HSSFCellStyle headerStyle = workbook.createCellStyle();
				
				headerStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
				headerStyle.setFillForegroundColor(HSSFColor.YELLOW.index);
				headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				HSSFFont font = workbook.createFont(); 
				font.setFontName(PLMConstants.EXCEL_FONT_NAME);
				font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headerStyle.setFont(font);
				headerStyle = setBorderStyle(headerStyle);
				
				HSSFCellStyle cellBoldStyle = workbook.createCellStyle();
				cellBoldStyle = setBorderStyle(cellBoldStyle);
				cellBoldStyle.setFont(font);
				
				HSSFFont nonBoldFont = workbook.createFont();
				nonBoldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				HSSFCellStyle contentStyle = workbook.createCellStyle();				
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(nonBoldFont);
				HSSFCellStyle contentDecimalStyle = workbook.createCellStyle();				
				contentDecimalStyle = setBorderStyle(contentDecimalStyle);
				contentDecimalStyle.setFont(nonBoldFont);
				DataFormat format = workbook.createDataFormat();
				contentDecimalStyle.setDataFormat(format.getFormat("0.00000"));
										
				HSSFFont noRecordFont = workbook.createFont(); 
				noRecordFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				noRecordFont.setColor(HSSFColor.RED.index);
				noRecordFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				HSSFCellStyle noRecordCellStyle = workbook.createCellStyle();
				noRecordCellStyle = setBorderStyle(noRecordCellStyle);
				noRecordCellStyle.setFont(noRecordFont);

				CreationHelper createHelper = workbook.getCreationHelper();

				HSSFCellStyle dateStyle = workbook.createCellStyle();
				
				dateStyle.setDataFormat(
			        createHelper.createDataFormat().getFormat("mm/dd/yyyy"));
				
				dateStyle = setBorderStyle(contentStyle);		
				dateStyle.setFont(nonBoldFont);
				
				int rowcount = -1;
				
				if(!PLMUtils.isEmptyList(mbompddrList)) {
					
					String[] colNames = {"Level","F/N","BOM Prefix","Part Number","Part Rev","Qty","UOM","Function Code","EID","Doc Name","Doc Rev","Description","Type","State","Original / Replacement Part","Part Attributes"};
					
					HSSFRow row = sheet.createRow(++rowcount);
					HSSFCell cell = row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					cell.setCellValue("MBOM Part Name");
					cell.setCellStyle(cellBoldStyle);

					cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellValue(partNmLcl);
					cell.setCellStyle(cellBoldStyle);
					
					row = sheet.createRow(++rowcount);
					
					cell = row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					cell.setCellValue("Revision");
					cell.setCellStyle(cellBoldStyle);

					cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellValue(revisionLcl);
					cell.setCellStyle(cellBoldStyle);
					
					row = sheet.createRow(++rowcount);
					
					cell = row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					cell.setCellValue("Report Generation");
					cell.setCellStyle(cellBoldStyle);

					cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellValue(reportDateLcl);
					cell.setCellStyle(cellBoldStyle);
					
					row = sheet.createRow(++rowcount);
					row = sheet.createRow(++rowcount);
					
					for ( int i = 0 ; i < colNames.length; i++ ) {
						cell = row.createCell(i);
						cell. setCellValue(colNames[i]);
						cell.setCellStyle(headerStyle);
					}
					
					for(int i = 0; i < mbompddrList.size(); i++) {
						PLMMBOMPddrData dataObj = (PLMMBOMPddrData) mbompddrList.get(i);
							row = sheet.createRow(++rowcount);

							cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getLevel());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getFn());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_TWO);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getBomPrefix());
				
							cell = row.createCell(PLMConstants.EXCEL_COL_THREE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartNumber());
				
							cell = row.createCell(PLMConstants.EXCEL_COL_FOUR);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartRev());
				
							cell = row.createCell(PLMConstants.EXCEL_COL_FIVE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getQty());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_SIX);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getUom());

							cell = row.createCell(PLMConstants.EXCEL_COL_SEVEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getFunctionCode());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_EIGHT);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getEid());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_NINE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getDocName());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_TEN);
							cell.setCellStyle(contentDecimalStyle);
							cell.setCellValue(dataObj.getDocRev());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getDescription());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_TWELVE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getType());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getState());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getOrgReplcPart());
							
							cell = row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartAttribute());
							
							
					}
					
					row = sheet.createRow(++rowcount);
					row = sheet.createRow(++rowcount);
					
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ONE);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWO);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_THREE);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_FOUR);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_FIVE);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_SIX);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_SEVEN);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_EIGHT);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_NINE);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TEN);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ELEVEN);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWELVE);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_THIRTEEN);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_FOURTEEN);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_FIFTEEN);
				} else {
					LOG.info("There is no record found for " + partNmLcl);
					HSSFRow row = sheet.createRow(++rowcount);
					HSSFCell cell = row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					String noRecordMsg = PLMConstants.MBOM_NO_RECORD_FOUND + partNmLcl;
					cell.setCellValue(noRecordMsg);
					cell.setCellStyle(noRecordCellStyle);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
				}	
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveMBomPddrXls: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveMBomPddrXls: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveMBomPddrXls: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveMBomPddrXls Method");
	}

	/**
	 * This method is used for Bordering Cell in XLS
	 * 
	 * @return StringBuffer
	 */
	
	private HSSFCellStyle setBorderStyle(HSSFCellStyle style) {
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		return style;
	}

	
	/**
	 * This method is used for Deleting zip file and xls file
	 * 
	 * @return void
	 */
	public void deleteFiles(String filePathXls,String filePathZip){
		LOG.info("Entering deleteFiles method");
		boolean zipFileExist;
		boolean xlsFileExist;
		File zipFile = new File(filePathZip);
		zipFileExist = zipFile.exists();
		File xlsFile = new File(filePathXls);
		xlsFileExist = xlsFile.exists();
		if(zipFileExist){
			boolean deleted = zipFile.delete();
			LOG.info("Successfully deleted zip file : " + deleted);
		}
		if(xlsFileExist){
			boolean deleted = xlsFile.delete();
			LOG.info("Successfully deleted xls file : " + deleted);
		}
		LOG.info("Exiting deleteFiles Method");
	}

	/**
	 * @return the plmMBOMPddrService
	 */
	public PLMMBOMPddrServiceIfc getPlmMBOMPddrService() {
		return plmMBOMPddrService;
	}

	/**
	 * @param plmMBOMPddrService the plmMBOMPddrService to set
	 */
	public void setPlmMBOMPddrService(PLMMBOMPddrServiceIfc plmMBOMPddrService) {
		this.plmMBOMPddrService = plmMBOMPddrService;
	}

	/**
	 * @return the alertMsgPddrRpt
	 */
	public String getAlertMsgPddrRpt() {
		return alertMsgPddrRpt;
	}

	/**
	 * @param alertMsgPddrRpt the alertMsgPddrRpt to set
	 */
	public void setAlertMsgPddrRpt(String alertMsgPddrRpt) {
		this.alertMsgPddrRpt = alertMsgPddrRpt;
	}

	/**
	 * @return the plmMBOMPddrData
	 */
	public PLMMBOMPddrData getPlmMBOMPddrData() {
		return plmMBOMPddrData;
	}

	/**
	 * @param plmMBOMPddrData the plmMBOMPddrData to set
	 */
	public void setPlmMBOMPddrData(PLMMBOMPddrData plmMBOMPddrData) {
		this.plmMBOMPddrData = plmMBOMPddrData;
	}

	/**
	 * @return the partName
	 */
	public String getPartName() {
		return partName;
	}

	/**
	 * @param partName the partName to set
	 */
	public void setPartName(String partName) {
		this.partName = partName;
	}
	
	/**
	 * @return the showFlag
	 */
	public boolean isShowFlag() {
		return showFlag;
	}

	/**
	 * @param showFlag the showFlag to set
	 */
	public void setShowFlag(boolean showFlag) {
		this.showFlag = showFlag;
	}

	/**
	 * @return the editFlag
	 */
	public boolean isEditFlag() {
		return editFlag;
	}

	/**
	 * @param editFlag the editFlag to set
	 */
	public void setEditFlag(boolean editFlag) {
		this.editFlag = editFlag;
	}

	/**
	 * @return the revisionList
	 */
	public List<SelectItem> getRevisionList() {
		return revisionList;
	}

	/**
	 * @param revisionList the revisionList to set
	 */
	public void setRevisionList(List<SelectItem> revisionList) {
		this.revisionList = revisionList;
	}

	/**
	 * @return the plantNameList
	 */
	public List<SelectItem> getPlantNameList() {
		return plantNameList;
	}

	/**
	 * @param plantNameList the plantNameList to set
	 */
	public void setPlantNameList(List<SelectItem> plantNameList) {
		this.plantNameList = plantNameList;
	}

	/**
	 * @return the plmMBOMPddrDataList
	 */
	public List<PLMMBOMPddrData> getPlmMBOMPddrDataList() {
		return plmMBOMPddrDataList;
	}

	/**
	 * @param plmMBOMPddrDataList the plmMBOMPddrDataList to set
	 */
	public void setPlmMBOMPddrDataList(List<PLMMBOMPddrData> plmMBOMPddrDataList) {
		this.plmMBOMPddrDataList = plmMBOMPddrDataList;
	}

	/**
	 * @return the totalRecCountMsg
	 */
	public String getTotalRecCountMsg() {
		return totalRecCountMsg;
	}

	/**
	 * @param totalRecCountMsg the totalRecCountMsg to set
	 */
	public void setTotalRecCountMsg(String totalRecCountMsg) {
		this.totalRecCountMsg = totalRecCountMsg;
	}

	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @param recordCounts the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	
	
	
}
