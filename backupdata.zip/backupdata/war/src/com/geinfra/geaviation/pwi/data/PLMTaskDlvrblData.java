/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMTaskDlvrblData.java
 * @Creation date: 11-Sept-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PLMTaskDlvrblData {

	
	// PROPERTIES *************************************************************
	
	private String to_id;
	
	private String deliverableName;
	
	private String deliverableRev;
	
	private String deliverableDescription;
	
	private String deliverableType;
	
	private String deliverableState;
	
	private String taskId;
	
	private String taskName;
	
	private String taskState;
	
	private String taskEstimatedFinish;
	
	private Date tskEstimatedFinishDate;
	
	private String taskActualFinish;
	
	private Date tskActualFinishDate;
	
	private String taskOwner;
	
	private String projectOwner;

	
	// CONSTRUCTOR ************************************************************

	/**
	 * Creates a new instance of the class TaskDeliverable
	 */
	public PLMTaskDlvrblData (String to_id, String deliverableName, String deliverableRev, String deliverableDescription, String deliverableType, String deliverableState,
							String taskId, String taskName, String taskState, String taskEstimatedFinish, String taskActualFinish, String taskOwner, String projectOwner) {  
			    
		String taskEstFinishDt = taskEstimatedFinish;
		String taskActFinishDt = taskActualFinish;
		if (taskEstFinishDt != null) {
			try{
				
				Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S").parse(taskEstFinishDt);
				this.tskEstimatedFinishDate = date;
				taskEstFinishDt = new SimpleDateFormat("MMM dd, yyyy", Locale.US).format(date);
				/*
				DateFormat df;
				int style = DateFormat.MEDIUM;
				df = DateFormat.getDateInstance(style, Locale.US);
				taskEstimatedFinish = df.format(date);
				*/
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		
		if (taskActFinishDt != null) {
			try{
				Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S").parse(taskActFinishDt);
				this.tskActualFinishDate = date;
				taskActFinishDt = new SimpleDateFormat("MMM dd, yyyy", Locale.US).format(date);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		
		this.to_id = to_id;
		this.deliverableName = deliverableName;
		this.deliverableRev = deliverableRev;
		this.deliverableDescription = deliverableDescription;
		this.deliverableType = deliverableType;
		this.deliverableState = deliverableState;
		this.taskId = taskId;
		this.taskName = taskName;		
		this.taskState = taskState;
		this.taskEstimatedFinish = taskEstFinishDt;
		this.taskActualFinish = taskActFinishDt;
		this.taskOwner = taskOwner;
		this.projectOwner = projectOwner;
	}
	
	
	// ACCESSOR METHODS *******************************************************

	public String getTo_id() {
		return to_id;
	}


	public void setTo_id(String to_id) {
		this.to_id = to_id;
	}


	public String getDeliverableName() {
		return deliverableName;
	}

	public void setDeliverableName(String deliverableName) {
		this.deliverableName = deliverableName;
	}

	public String getDeliverableRev() {
		return deliverableRev;
	}

	public void setDeliverableRev(String deliverableRev) {
		this.deliverableRev = deliverableRev;
	}


	public String getDeliverableDescription() {
		return deliverableDescription;
	}


	public void setDeliverableDescription(String deliverableDescription) {
		this.deliverableDescription = deliverableDescription;
	}


	public String getDeliverableType() {
		return deliverableType;
	}

	public void setDeliverableType(String deliverableType) {
		this.deliverableType = deliverableType;
	}

	public String getDeliverableState() {
		return deliverableState;
	}

	public void setDeliverableState(String deliverableState) {
		this.deliverableState = deliverableState;
	}

	public String getTaskId() {
		return taskId;
	}


	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}


	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getTaskState() {
		return taskState;
	}

	public void setTaskState(String taskState) {
		this.taskState = taskState;
	}

	public String getTaskEstimatedFinish() {
		return taskEstimatedFinish;
	}


	public void setTaskEstimatedFinish(String taskEstimatedFinish) {
		this.taskEstimatedFinish = taskEstimatedFinish;
	}


	public Date getTskEstimatedFinishDate() {
		Date tskEstFnshDt = tskEstimatedFinishDate;
		return tskEstFnshDt;
	}


	public void setTskEstimatedFinishDate(Date tskEstimatedFinishDate) {
		Date tskEstFnshDt = tskEstimatedFinishDate;
		this.tskEstimatedFinishDate = tskEstFnshDt;
	}


	public String getTaskActualFinish() {
		return taskActualFinish;
	}


	public void setTaskActualFinish(String taskActualFinish) {
		this.taskActualFinish = taskActualFinish;
	}
	
	public Date getTskActualFinishDate() {
		Date tskActlFnshDt = tskActualFinishDate;
		return tskActlFnshDt;
	}


	public void setTskActualFinishDate(Date tskActualFinishDate) {
		Date tskActlFnshDt = tskActualFinishDate;
		this.tskActualFinishDate = tskActlFnshDt;
	}


	public String getTaskOwner() {
		return taskOwner;
	}

	public void setTaskOwner(String taskOwner) {
		this.taskOwner = taskOwner;
	}

	public String getProjectOwner() {
		return projectOwner;
	}

	public void setProjectOwner(String projectOwner) {
		this.projectOwner = projectOwner;
	}

	
	// OVERRIDEN METHODS ******************************************************

	/**
	 * Returns the Deliverable information as a String
	 * 
	 * @return type (String) 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer strTaskDeliverable = new StringBuffer();
		
		strTaskDeliverable
			.append(deliverableName).append(" ")
			.append(deliverableRev).append(" ")
			.append(deliverableDescription).append(" ")
			.append(deliverableType).append(" ")
			.append(deliverableState).append(" ")
			.append(taskId).append(" ")
			.append(taskName).append(" ")
			.append(taskState).append(" ")
			.append(taskEstimatedFinish).append(" ")
			.append(taskActualFinish).append(" ")
			.append(taskOwner).append(" ")
			.append(projectOwner);
		
		return strTaskDeliverable.toString();
	}


	
}
