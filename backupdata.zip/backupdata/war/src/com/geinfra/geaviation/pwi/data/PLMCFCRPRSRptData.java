/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCFCRPRSRptData.java
 * @Creation date: 30-July-2015
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMCFCRPRSRptData {
	/**
	 * Holds hwPrdctNm
	 */
	private String hwPrdctNm;
	/**
	 * Holds prdtConfigNm
	 */
	private String prdtConfigNm;
	/**
	 * Holds prdtConfigDesc
	 */
	private String prdtConfigDesc;
	/**
	 * Holds isOption
	 */
	private String isOption;
	
	//Start Fields for CF Compare Report Data
	/**
	 * Holds pcName
	 */
	private String pcName;
	/**
	 * Holds pcDesc
	 */
	private String pcDesc;
	/**
	 * Holds level
	 */
	private String level;
	/**
	 * Holds cfId
	 */
	private String cfId;
	/**
	 * Holds cfName
	 */
	private String cfName;
	/**
	 * Holds coId
	 */
	private String coId;
	/**
	 * Holds coName
	 */
	private String coName;
	/**
	 * Holds cfoId
	 */
	private String cfoId;
	/**
	 * Holds cfoName
	 */
	private String cfoName;
	/**
	 * Holds cfDisplayNm
	 */
	private String cfDisplayNm;
	/**
	 * Holds coDisplayNm
	 */
	private String coDisplayNm;
	/**
	 * Holds displayNm
	 */
	private String displayNm;
	/**
	 * Holds featureType
	 */
	private String featureType;
	/**
	 * Holds cfType
	 */
	private String cfType;
	/**
	 * Holds coType
	 */
	private String coType;
	/**
	 * Holds pc1
	 */
	private String pc1;
	/**
	 * Holds pc2
	 */
	private String pc2;
	/**
	 * Holds pc3
	 */
	private String pc3;
	//End Fields for CF Compare Report Data
	

	//Start Fields for CR Compare Report Data
	/**
	 * Holds contract
	 */
	private String contract;
	/**
	 * Holds mli
	 */
	private String mli;
	/**
	 * Holds crId
	 */
	private String crId;
	/**
	 * Holds crNm
	 */
	private String crNm;
	/**
	 * Holds crTitile
	 */
	private String crTitile;
	/**
	 * Holds coNm
	 */
	private String coNm;
	
	/**
	 * Holds crId1
	 */
	private String crId1;
	/**
	 * Holds crNm1
	 */
	private String crNm1;
	/**
	 * Holds crTitile1
	 */
	private String crTitile1;
	/**
	 * Holds coId1
	 */
	private String coId1;
	/**
	 * Holds coNm1
	 */
	private String coNm1;
	/**
	 * Holds crId2
	 */
	private String crId2;
	/**
	 * Holds crNm2
	 */
	private String crNm2;
	/**
	 * Holds crTitile2
	 */
	private String crTitile2;
	/**
	 * Holds coId1
	 */
	private String coId2;
	/**
	 * Holds coNm2
	 */
	private String coNm2;
	/**
	 * Holds crId3
	 */
	private String crId3;
	/**
	 * Holds crNm3
	 */
	private String crNm3;
	/**
	 * Holds crTitile3
	 */
	private String crTitile3;
	/**
	 * Holds coId3
	 */
	private String coId3;
	/**
	 * Holds coNm3
	 */
	private String coNm3;
	/**
	 * Holds lfName
	 */
	private String lfName;
	/**
	 * Holds lfName1
	 */
	private String lfName1;
	/**
	 * Holds lfName2
	 */
	private String lfName2;
	/**
	 * Holds lfName3
	 */
	private String lfName3;
	/**
	 * Holds lfDesc
	 */
	private String lfDesc;
	/**
	 * Holds lfDesc1
	 */
	private String lfDesc1;
	/**
	 * Holds lfDesc2
	 */
	private String lfDesc2;
	/**
	 * Holds lfDesc3
	 */
	private String lfDesc3;
	/**
	 * Holds lfRev
	 */
	private String lfRev;
	/**
	 * Holds lfRev1
	 */
	private String lfRev1;
	/**
	 * Holds lfRev2
	 */
	private String lfRev2;
	/**
	 * Holds lfRev3
	 */
	private String lfRev3;
	/**
	 * Holds crPcName
	 */
	private String crPcName;
	/**
	 * Holds pcName1
	 */
	private String pcName1;
	/**
	 * Holds pcName2
	 */
	private String pcName2;
	/**
	 * Holds pcName3
	 */
	private String pcName3;
	/**
	 * Holds costGrp
	 */
	private String costGrp;
	/**
	 * Holds costGrp1
	 */
	private String costGrp1;
	/**
	 * Holds costGrp2
	 */
	private String costGrp2;
	/**
	 * Holds costGrp3
	 */
	private String costGrp3;
	
	//End Fields for CR Compare Report Data
	
	//Start Fields for PRS Compare Report Data
	/**
	 * Holds prsContract
	 */
	private String prsContract;
	/**
	 * Holds prsId
	 */
	private String prsId;
	/**
	 * Holds prsName
	 */
	private String prsName;
	/**
	 * Holds prsId1
	 */
	private String prsId1;
	/**
	 * Holds prsName1
	 */
	private String prsName1;
	/**
	 * Holds prsId2
	 */
	private String prsId2;
	/**
	 * Holds prsName2
	 */
	private String prsName2;
	/**
	 * Holds prsId3
	 */
	private String prsId3;
	/**
	 * Holds prsName3
	 */
	private String prsName3;
	//End Fields for PRS Compare Report Data
	/**
	 * @return the hwPrdctNm
	 */
	public String getHwPrdctNm() {
		return hwPrdctNm;
	}
	/**
	 * @param hwPrdctNm the hwPrdctNm to set
	 */
	public void setHwPrdctNm(String hwPrdctNm) {
		this.hwPrdctNm = hwPrdctNm;
	}
	/**
	 * @return the prdtConfigNm
	 */
	public String getPrdtConfigNm() {
		return prdtConfigNm;
	}
	/**
	 * @param prdtConfigNm the prdtConfigNm to set
	 */
	public void setPrdtConfigNm(String prdtConfigNm) {
		this.prdtConfigNm = prdtConfigNm;
	}
	/**
	 * @return the prdtConfigDesc
	 */
	public String getPrdtConfigDesc() {
		return prdtConfigDesc;
	}
	/**
	 * @param prdtConfigDesc the prdtConfigDesc to set
	 */
	public void setPrdtConfigDesc(String prdtConfigDesc) {
		this.prdtConfigDesc = prdtConfigDesc;
	}
	/**
	 * @return the isOption
	 */
	public String getIsOption() {
		return isOption;
	}
	/**
	 * @param isOption the isOption to set
	 */
	public void setIsOption(String isOption) {
		this.isOption = isOption;
	}
	/**
	 * @return the pcName
	 */
	public String getPcName() {
		return pcName;
	}
	/**
	 * @param pcName the pcName to set
	 */
	public void setPcName(String pcName) {
		this.pcName = pcName;
	}
	/**
	 * @return the pcDesc
	 */
	public String getPcDesc() {
		return pcDesc;
	}
	/**
	 * @param pcDesc the pcDesc to set
	 */
	public void setPcDesc(String pcDesc) {
		this.pcDesc = pcDesc;
	}
	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}
	/**
	 * @return the cfId
	 */
	public String getCfId() {
		return cfId;
	}
	/**
	 * @param cfId the cfId to set
	 */
	public void setCfId(String cfId) {
		this.cfId = cfId;
	}
	/**
	 * @return the cfName
	 */
	public String getCfName() {
		return cfName;
	}
	/**
	 * @param cfName the cfName to set
	 */
	public void setCfName(String cfName) {
		this.cfName = cfName;
	}
	/**
	 * @return the coId
	 */
	public String getCoId() {
		return coId;
	}
	/**
	 * @param coId the coId to set
	 */
	public void setCoId(String coId) {
		this.coId = coId;
	}
	/**
	 * @return the coName
	 */
	public String getCoName() {
		return coName;
	}
	/**
	 * @param coName the coName to set
	 */
	public void setCoName(String coName) {
		this.coName = coName;
	}
	/**
	 * @return the cfoId
	 */
	public String getCfoId() {
		return cfoId;
	}
	/**
	 * @param cfoId the cfoId to set
	 */
	public void setCfoId(String cfoId) {
		this.cfoId = cfoId;
	}
	/**
	 * @return the cfoName
	 */
	public String getCfoName() {
		return cfoName;
	}
	/**
	 * @param cfoName the cfoName to set
	 */
	public void setCfoName(String cfoName) {
		this.cfoName = cfoName;
	}
	/**
	 * @return the cfDisplayNm
	 */
	public String getCfDisplayNm() {
		return cfDisplayNm;
	}
	/**
	 * @param cfDisplayNm the cfDisplayNm to set
	 */
	public void setCfDisplayNm(String cfDisplayNm) {
		this.cfDisplayNm = cfDisplayNm;
	}
	/**
	 * @return the coDisplayNm
	 */
	public String getCoDisplayNm() {
		return coDisplayNm;
	}
	/**
	 * @param coDisplayNm the coDisplayNm to set
	 */
	public void setCoDisplayNm(String coDisplayNm) {
		this.coDisplayNm = coDisplayNm;
	}
	/**
	 * @return the displayNm
	 */
	public String getDisplayNm() {
		return displayNm;
	}
	/**
	 * @param displayNm the displayNm to set
	 */
	public void setDisplayNm(String displayNm) {
		this.displayNm = displayNm;
	}
	/**
	 * @return the featureType
	 */
	public String getFeatureType() {
		return featureType;
	}
	/**
	 * @param featureType the featureType to set
	 */
	public void setFeatureType(String featureType) {
		this.featureType = featureType;
	}
	/**
	 * @return the cfType
	 */
	public String getCfType() {
		return cfType;
	}
	/**
	 * @param cfType the cfType to set
	 */
	public void setCfType(String cfType) {
		this.cfType = cfType;
	}
	/**
	 * @return the coType
	 */
	public String getCoType() {
		return coType;
	}
	/**
	 * @param coType the coType to set
	 */
	public void setCoType(String coType) {
		this.coType = coType;
	}
	/**
	 * @return the pc1
	 */
	public String getPc1() {
		return pc1;
	}
	/**
	 * @param pc1 the pc1 to set
	 */
	public void setPc1(String pc1) {
		this.pc1 = pc1;
	}
	/**
	 * @return the pc2
	 */
	public String getPc2() {
		return pc2;
	}
	/**
	 * @param pc2 the pc2 to set
	 */
	public void setPc2(String pc2) {
		this.pc2 = pc2;
	}
	/**
	 * @return the pc3
	 */
	public String getPc3() {
		return pc3;
	}
	/**
	 * @param pc3 the pc3 to set
	 */
	public void setPc3(String pc3) {
		this.pc3 = pc3;
	}
	/**
	 * @return the contract
	 */
	public String getContract() {
		return contract;
	}
	/**
	 * @param contract the contract to set
	 */
	public void setContract(String contract) {
		this.contract = contract;
	}
	/**
	 * @return the mli
	 */
	public String getMli() {
		return mli;
	}
	/**
	 * @param mli the mli to set
	 */
	public void setMli(String mli) {
		this.mli = mli;
	}
	/**
	 * @return the crId
	 */
	public String getCrId() {
		return crId;
	}
	/**
	 * @param crId the crId to set
	 */
	public void setCrId(String crId) {
		this.crId = crId;
	}
	/**
	 * @return the crNm
	 */
	public String getCrNm() {
		return crNm;
	}
	/**
	 * @param crNm the crNm to set
	 */
	public void setCrNm(String crNm) {
		this.crNm = crNm;
	}
	/**
	 * @return the crTitile
	 */
	public String getCrTitile() {
		return crTitile;
	}
	/**
	 * @param crTitile the crTitile to set
	 */
	public void setCrTitile(String crTitile) {
		this.crTitile = crTitile;
	}
	/**
	 * @return the coNm
	 */
	public String getCoNm() {
		return coNm;
	}
	/**
	 * @param coNm the coNm to set
	 */
	public void setCoNm(String coNm) {
		this.coNm = coNm;
	}
	/**
	 * @return the crId1
	 */
	public String getCrId1() {
		return crId1;
	}
	/**
	 * @param crId1 the crId1 to set
	 */
	public void setCrId1(String crId1) {
		this.crId1 = crId1;
	}
	/**
	 * @return the crNm1
	 */
	public String getCrNm1() {
		return crNm1;
	}
	/**
	 * @param crNm1 the crNm1 to set
	 */
	public void setCrNm1(String crNm1) {
		this.crNm1 = crNm1;
	}
	/**
	 * @return the crTitile1
	 */
	public String getCrTitile1() {
		return crTitile1;
	}
	/**
	 * @param crTitile1 the crTitile1 to set
	 */
	public void setCrTitile1(String crTitile1) {
		this.crTitile1 = crTitile1;
	}
	/**
	 * @return the coId1
	 */
	public String getCoId1() {
		return coId1;
	}
	/**
	 * @param coId1 the coId1 to set
	 */
	public void setCoId1(String coId1) {
		this.coId1 = coId1;
	}
	/**
	 * @return the coNm1
	 */
	public String getCoNm1() {
		return coNm1;
	}
	/**
	 * @param coNm1 the coNm1 to set
	 */
	public void setCoNm1(String coNm1) {
		this.coNm1 = coNm1;
	}
	/**
	 * @return the crId2
	 */
	public String getCrId2() {
		return crId2;
	}
	/**
	 * @param crId2 the crId2 to set
	 */
	public void setCrId2(String crId2) {
		this.crId2 = crId2;
	}
	/**
	 * @return the crNm2
	 */
	public String getCrNm2() {
		return crNm2;
	}
	/**
	 * @param crNm2 the crNm2 to set
	 */
	public void setCrNm2(String crNm2) {
		this.crNm2 = crNm2;
	}
	/**
	 * @return the crTitile2
	 */
	public String getCrTitile2() {
		return crTitile2;
	}
	/**
	 * @param crTitile2 the crTitile2 to set
	 */
	public void setCrTitile2(String crTitile2) {
		this.crTitile2 = crTitile2;
	}
	/**
	 * @return the coId2
	 */
	public String getCoId2() {
		return coId2;
	}
	/**
	 * @param coId2 the coId2 to set
	 */
	public void setCoId2(String coId2) {
		this.coId2 = coId2;
	}
	/**
	 * @return the coNm2
	 */
	public String getCoNm2() {
		return coNm2;
	}
	/**
	 * @param coNm2 the coNm2 to set
	 */
	public void setCoNm2(String coNm2) {
		this.coNm2 = coNm2;
	}
	/**
	 * @return the crId3
	 */
	public String getCrId3() {
		return crId3;
	}
	/**
	 * @param crId3 the crId3 to set
	 */
	public void setCrId3(String crId3) {
		this.crId3 = crId3;
	}
	/**
	 * @return the crNm3
	 */
	public String getCrNm3() {
		return crNm3;
	}
	/**
	 * @param crNm3 the crNm3 to set
	 */
	public void setCrNm3(String crNm3) {
		this.crNm3 = crNm3;
	}
	/**
	 * @return the crTitile3
	 */
	public String getCrTitile3() {
		return crTitile3;
	}
	/**
	 * @param crTitile3 the crTitile3 to set
	 */
	public void setCrTitile3(String crTitile3) {
		this.crTitile3 = crTitile3;
	}
	/**
	 * @return the coId3
	 */
	public String getCoId3() {
		return coId3;
	}
	/**
	 * @param coId3 the coId3 to set
	 */
	public void setCoId3(String coId3) {
		this.coId3 = coId3;
	}
	/**
	 * @return the coNm3
	 */
	public String getCoNm3() {
		return coNm3;
	}
	/**
	 * @param coNm3 the coNm3 to set
	 */
	public void setCoNm3(String coNm3) {
		this.coNm3 = coNm3;
	}
	/**
	 * @return the lfName
	 */
	public String getLfName() {
		return lfName;
	}
	/**
	 * @param lfName the lfName to set
	 */
	public void setLfName(String lfName) {
		this.lfName = lfName;
	}
	/**
	 * @return the lfName1
	 */
	public String getLfName1() {
		return lfName1;
	}
	/**
	 * @param lfName1 the lfName1 to set
	 */
	public void setLfName1(String lfName1) {
		this.lfName1 = lfName1;
	}
	/**
	 * @return the lfName2
	 */
	public String getLfName2() {
		return lfName2;
	}
	/**
	 * @param lfName2 the lfName2 to set
	 */
	public void setLfName2(String lfName2) {
		this.lfName2 = lfName2;
	}
	/**
	 * @return the lfName3
	 */
	public String getLfName3() {
		return lfName3;
	}
	/**
	 * @param lfName3 the lfName3 to set
	 */
	public void setLfName3(String lfName3) {
		this.lfName3 = lfName3;
	}
	/**
	 * @return the lfDesc
	 */
	public String getLfDesc() {
		return lfDesc;
	}
	/**
	 * @param lfDesc the lfDesc to set
	 */
	public void setLfDesc(String lfDesc) {
		this.lfDesc = lfDesc;
	}
	/**
	 * @return the lfDesc1
	 */
	public String getLfDesc1() {
		return lfDesc1;
	}
	/**
	 * @param lfDesc1 the lfDesc1 to set
	 */
	public void setLfDesc1(String lfDesc1) {
		this.lfDesc1 = lfDesc1;
	}
	/**
	 * @return the lfDesc2
	 */
	public String getLfDesc2() {
		return lfDesc2;
	}
	/**
	 * @param lfDesc2 the lfDesc2 to set
	 */
	public void setLfDesc2(String lfDesc2) {
		this.lfDesc2 = lfDesc2;
	}
	/**
	 * @return the lfDesc3
	 */
	public String getLfDesc3() {
		return lfDesc3;
	}
	/**
	 * @param lfDesc3 the lfDesc3 to set
	 */
	public void setLfDesc3(String lfDesc3) {
		this.lfDesc3 = lfDesc3;
	}
	/**
	 * @return the lfRev
	 */
	public String getLfRev() {
		return lfRev;
	}
	/**
	 * @param lfRev the lfRev to set
	 */
	public void setLfRev(String lfRev) {
		this.lfRev = lfRev;
	}
	/**
	 * @return the lfRev1
	 */
	public String getLfRev1() {
		return lfRev1;
	}
	/**
	 * @param lfRev1 the lfRev1 to set
	 */
	public void setLfRev1(String lfRev1) {
		this.lfRev1 = lfRev1;
	}
	/**
	 * @return the lfRev2
	 */
	public String getLfRev2() {
		return lfRev2;
	}
	/**
	 * @param lfRev2 the lfRev2 to set
	 */
	public void setLfRev2(String lfRev2) {
		this.lfRev2 = lfRev2;
	}
	/**
	 * @return the lfRev3
	 */
	public String getLfRev3() {
		return lfRev3;
	}
	/**
	 * @param lfRev3 the lfRev3 to set
	 */
	public void setLfRev3(String lfRev3) {
		this.lfRev3 = lfRev3;
	}
	/**
	 * @return the crPcName
	 */
	public String getCrPcName() {
		return crPcName;
	}
	/**
	 * @param crPcName the crPcName to set
	 */
	public void setCrPcName(String crPcName) {
		this.crPcName = crPcName;
	}
	/**
	 * @return the pcName1
	 */
	public String getPcName1() {
		return pcName1;
	}
	/**
	 * @param pcName1 the pcName1 to set
	 */
	public void setPcName1(String pcName1) {
		this.pcName1 = pcName1;
	}
	/**
	 * @return the pcName2
	 */
	public String getPcName2() {
		return pcName2;
	}
	/**
	 * @param pcName2 the pcName2 to set
	 */
	public void setPcName2(String pcName2) {
		this.pcName2 = pcName2;
	}
	/**
	 * @return the pcName3
	 */
	public String getPcName3() {
		return pcName3;
	}
	/**
	 * @param pcName3 the pcName3 to set
	 */
	public void setPcName3(String pcName3) {
		this.pcName3 = pcName3;
	}
	/**
	 * @return the costGrp
	 */
	public String getCostGrp() {
		return costGrp;
	}
	/**
	 * @param costGrp the costGrp to set
	 */
	public void setCostGrp(String costGrp) {
		this.costGrp = costGrp;
	}
	/**
	 * @return the costGrp1
	 */
	public String getCostGrp1() {
		return costGrp1;
	}
	/**
	 * @param costGrp1 the costGrp1 to set
	 */
	public void setCostGrp1(String costGrp1) {
		this.costGrp1 = costGrp1;
	}
	/**
	 * @return the costGrp2
	 */
	public String getCostGrp2() {
		return costGrp2;
	}
	/**
	 * @param costGrp2 the costGrp2 to set
	 */
	public void setCostGrp2(String costGrp2) {
		this.costGrp2 = costGrp2;
	}
	/**
	 * @return the costGrp3
	 */
	public String getCostGrp3() {
		return costGrp3;
	}
	/**
	 * @param costGrp3 the costGrp3 to set
	 */
	public void setCostGrp3(String costGrp3) {
		this.costGrp3 = costGrp3;
	}
	/**
	 * @return the prsContract
	 */
	public String getPrsContract() {
		return prsContract;
	}
	/**
	 * @param prsContract the prsContract to set
	 */
	public void setPrsContract(String prsContract) {
		this.prsContract = prsContract;
	}
	/**
	 * @return the prsId
	 */
	public String getPrsId() {
		return prsId;
	}
	/**
	 * @param prsId the prsId to set
	 */
	public void setPrsId(String prsId) {
		this.prsId = prsId;
	}
	/**
	 * @return the prsName
	 */
	public String getPrsName() {
		return prsName;
	}
	/**
	 * @param prsName the prsName to set
	 */
	public void setPrsName(String prsName) {
		this.prsName = prsName;
	}
	/**
	 * @return the prsId1
	 */
	public String getPrsId1() {
		return prsId1;
	}
	/**
	 * @param prsId1 the prsId1 to set
	 */
	public void setPrsId1(String prsId1) {
		this.prsId1 = prsId1;
	}
	/**
	 * @return the prsName1
	 */
	public String getPrsName1() {
		return prsName1;
	}
	/**
	 * @param prsName1 the prsName1 to set
	 */
	public void setPrsName1(String prsName1) {
		this.prsName1 = prsName1;
	}
	/**
	 * @return the prsId2
	 */
	public String getPrsId2() {
		return prsId2;
	}
	/**
	 * @param prsId2 the prsId2 to set
	 */
	public void setPrsId2(String prsId2) {
		this.prsId2 = prsId2;
	}
	/**
	 * @return the prsName2
	 */
	public String getPrsName2() {
		return prsName2;
	}
	/**
	 * @param prsName2 the prsName2 to set
	 */
	public void setPrsName2(String prsName2) {
		this.prsName2 = prsName2;
	}
	/**
	 * @return the prsId3
	 */
	public String getPrsId3() {
		return prsId3;
	}
	/**
	 * @param prsId3 the prsId3 to set
	 */
	public void setPrsId3(String prsId3) {
		this.prsId3 = prsId3;
	}
	/**
	 * @return the prsName3
	 */
	public String getPrsName3() {
		return prsName3;
	}
	/**
	 * @param prsName3 the prsName3 to set
	 */
	public void setPrsName3(String prsName3) {
		this.prsName3 = prsName3;
	}
	


}
