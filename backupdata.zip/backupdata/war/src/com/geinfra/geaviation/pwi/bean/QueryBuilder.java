package com.geinfra.geaviation.pwi.bean;

/**
 * 
 * Project        :   Product Lifecycle Management
 * Date Written   :   Aug 5, 2010
 * Security       :   GE Confidential
 * Restrictions   :   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 * Copyright(C) 2010 GE 
 * All rights reserved
 *
 * Description    :  QueryBuilder - display representation of a query builder parameter.
 *
 * Revision Log Aug 5, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class QueryBuilder {

	private String objType;
	private String outputColumn;
	private String searchOption;
	private String parameter;

	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	public String getOutputColumn() {
		return outputColumn;
	}

	public void setOutputColumn(String outputColumn) {
		this.outputColumn = outputColumn;
	}

	public String getSearchOption() {
		return searchOption;
	}

	public void setSearchOption(String searchOption) {
		this.searchOption = searchOption;
	}

	public String getParameter() {
		return parameter;
	}

	public void setParameter(String parameter) {
		this.parameter = parameter;
	}

}
