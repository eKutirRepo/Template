/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCycleTimeReportDaoIfc.java
 * @Creation date: 05-Dec-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMCycleTimeReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMCycleTimeReportDaoIfc {
	/**
	 * This methods is used for getDropDownvalues
	 * 
	 * @return Map
	 * throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getDropDownvalues() throws PLMCommonException;
	
	/**
	 * This method is used to get Result List
	 * 
	 * @param plmDRLReportData
	 * @return List
	 * @throws PLMCommonException
	 */
	public PLMCycleTimeReportData getCycleTimeReportResult(PLMCycleTimeReportData plmCycleTimeReportData) throws PLMCommonException;
	
	//Newly Added for Cycle Time part by Production Line
	
	/**
	 * This methods is used for getProductLines
	 * 
	 * @return List
	 * throws PLMCommonException
	 */
	public List<SelectItem> getProductLines() throws PLMCommonException;

	/**
	 * This method is used to get FrameType
	 * 
	 * @param selProductLn
	 * @return lsit
	 * @throws PLMCommonException 
	 */
	public List <SelectItem> getFrameTypeLst(String selProductLn) throws PLMCommonException;
	
	/**
	 * This method is used to get HardWares
	 * 
	 * @param selProductLn
	 * @return list
	 * @throws PLMCommonException
	 */
	public List <PLMCycleTimeReportData> getHardWareLst(String selProductLn,List<String> selFrameType) throws PLMCommonException;

	/**
	 * This method is used to get Result List by product
	 * 
	 * @param PLMCycleTimeReportData
	 * @return hardwareLst,releaseFrmDt,releaseToDt
	 * @throws PLMCommonException
	 */
	public List<PLMCycleTimeReportData> getCycleTimePartProduct(List<String> selFrameType, List<PLMCycleTimeReportData> hardwareObjLst,Date releaseFrmDt, Date releaseToDt) throws PLMCommonException;

	/**
	 * This method is used to get Result List by product detials
	 * 
	 * @param list
	 * @return hardwareLst,releaseFrmDt,releaseToDt
	 * @throws PLMCommonException
	 */
	public List<PLMCycleTimeReportData>  getCycleTimeProductDetials(List<String> hardwareLst,String state,Date releaseFrmDt, Date releaseToDt) throws PLMCommonException;


}
