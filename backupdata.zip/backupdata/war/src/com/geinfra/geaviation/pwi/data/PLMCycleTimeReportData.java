/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCycleTimeReportData.java
 * @Creation date: 05-Dec-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;


public class PLMCycleTimeReportData {
	/**
	 * Holds the enteredPartName
	 */
	private String enteredPartName="";
	
	/**
	 * Holds the enteredOwner
	 */
	private String enteredOwner="";
	
	/**
	 * Holds the enteredPartFamily
	 */
	private String enteredPartFamily="";
	
	/**
	 * Holds the enteredRdo
	 */
	private String enteredRdo="";
	
	/**
	 * Holds the enteredPartType
	 */
	private String enteredPartType="";
	
	
	/**
	 * Holds the enteredPartType
	 */
	private int reviewCount;
	/**
	 * Holds the enteredPartType
	 */
	private double reviewSum;
	/**
	 * Holds the enteredPartType
	 */
	private int approvedCount;
	/**
	 * Holds the enteredPartType
	 */
	private double approvedSum=0;
	/**
	 * Holds the enteredPartType
	 */
	private int releaseCount;
	/**
	 * Holds the enteredPartType
	 */
	private double releaseSum=0;
	/**
	 * Holds the enteredPartType
	 */
	private double reviewCycleTime=0;
	/**
	 * Holds the enteredPartType
	 */
	private double approvedCycleTime=0;
	/**
	 * Holds the enteredPartType
	 */
	private double releaseCycleTime=0;
	
	//Newly added for Cycle Time part by Product
	/**
	 * Holds the enteredPartType
	 */
	private String partName;
	/**
	 * Holds the partRev
	 */
	private String partRev;
	
	/**
	 * Holds the partType
	 */
	private String partType;
	
	/**
	 * Holds the partState
	 */
	private String partState;
	
	/**
	 * Holds the releaseDt
	 */
	private String releaseDt;
	
	/**
	 * Holds the hwPrdtNm
	 */
	private String hwPrdtNm;
	
	/**
	 * Holds the productLine
	 */
	private String productLine;
	
	/**
	 * Holds the frameType
	 */
	private String frameType;
	
	/**
	 * @return the enteredPartName
	 */
	public String getEnteredPartName() {
		return enteredPartName;
	}

	/**
	 * @param enteredPartName the enteredPartName to set
	 */
	public void setEnteredPartName(String enteredPartName) {
		this.enteredPartName = enteredPartName;
	}

	/**
	 * @return the enteredOwner
	 */
	public String getEnteredOwner() {
		return enteredOwner;
	}

	/**
	 * @param enteredOwner the enteredOwner to set
	 */
	public void setEnteredOwner(String enteredOwner) {
		this.enteredOwner = enteredOwner;
	}

	/**
	 * @return the enteredPartFamily
	 */
	public String getEnteredPartFamily() {
		return enteredPartFamily;
	}

	/**
	 * @param enteredPartFamily the enteredPartFamily to set
	 */
	public void setEnteredPartFamily(String enteredPartFamily) {
		this.enteredPartFamily = enteredPartFamily;
	}

	/**
	 * @return the enteredRdo
	 */
	public String getEnteredRdo() {
		return enteredRdo;
	}

	/**
	 * @param enteredRdo the enteredRdo to set
	 */
	public void setEnteredRdo(String enteredRdo) {
		this.enteredRdo = enteredRdo;
	}

	/**
	 * @return the enteredPartType
	 */
	public String getEnteredPartType() {
		return enteredPartType;
	}

	/**
	 * @param enteredPartType the enteredPartType to set
	 */
	public void setEnteredPartType(String enteredPartType) {
		this.enteredPartType = enteredPartType;
	}

	/**
	 * @return the reviewCount
	 */
	public int getReviewCount() {
		return reviewCount;
	}

	/**
	 * @param reviewCount the reviewCount to set
	 */
	public void setReviewCount(int reviewCount) {
		this.reviewCount = reviewCount;
	}

	/**
	 * @return the reviewSum
	 */
	public double getReviewSum() {
		return reviewSum;
	}

	/**
	 * @param reviewSum the reviewSum to set
	 */
	public void setReviewSum(double reviewSum) {
		this.reviewSum = reviewSum; 
	}

	/**
	 * @return the approvedCount
	 */
	public int getApprovedCount() {
		return approvedCount;
	}

	/**
	 * @param approvedCount the approvedCount to set
	 */
	public void setApprovedCount(int approvedCount) {
		this.approvedCount = approvedCount;
	}

	/**
	 * @return the approvedSum
	 */
	public double getApprovedSum() {
		return approvedSum;
	}

	/**
	 * @param approvedSum the approvedSum to set
	 */
	public void setApprovedSum(double approvedSum) {
		this.approvedSum = approvedSum;
	}

	/**
	 * @return the releaseCount
	 */
	public int getReleaseCount() {
		return releaseCount;
	}

	/**
	 * @param releaseCount the releaseCount to set
	 */
	public void setReleaseCount(int releaseCount) {
		this.releaseCount = releaseCount;
	}

	/**
	 * @return the releaseSum
	 */
	public double getReleaseSum() {
		return releaseSum;
	}

	/**
	 * @param releaseSum the releaseSum to set
	 */
	public void setReleaseSum(double releaseSum) {
		this.releaseSum = releaseSum;
	}

	/**
	 * @return the reviewCycleTime
	 */
	public double getReviewCycleTime() {
		return reviewCycleTime;
	}

	/**
	 * @param reviewCycleTime the reviewCycleTime to set
	 */
	public void setReviewCycleTime(double reviewCycleTime) {
		this.reviewCycleTime = reviewCycleTime;
	}

	/**
	 * @return the approvedCycleTime
	 */
	public double getApprovedCycleTime() {
		return approvedCycleTime;
	}

	/**
	 * @param approvedCycleTime the approvedCycleTime to set
	 */
	public void setApprovedCycleTime(double approvedCycleTime) {
		this.approvedCycleTime = approvedCycleTime;
	}

	/**
	 * @return the releaseCycleTime
	 */
	public double getReleaseCycleTime() {
		return releaseCycleTime;
	}

	/**
	 * @param releaseCycleTime the releaseCycleTime to set
	 */
	public void setReleaseCycleTime(double releaseCycleTime) {
		this.releaseCycleTime = releaseCycleTime;
	}

	/**
	 * @return the partName
	 */
	public String getPartName() {
		return partName;
	}

	/**
	 * @param partName the partName to set
	 */
	public void setPartName(String partName) {
		this.partName = partName;
	}

	/**
	 * @return the partRev
	 */
	public String getPartRev() {
		return partRev;
	}

	/**
	 * @param partRev the partRev to set
	 */
	public void setPartRev(String partRev) {
		this.partRev = partRev;
	}

	/**
	 * @return the partType
	 */
	public String getPartType() {
		return partType;
	}

	/**
	 * @param partType the partType to set
	 */
	public void setPartType(String partType) {
		this.partType = partType;
	}

	/**
	 * @return the partState
	 */
	public String getPartState() {
		return partState;
	}

	/**
	 * @param partState the partState to set
	 */
	public void setPartState(String partState) {
		this.partState = partState;
	}

	/**
	 * @return the releaseDt
	 */
	public String getReleaseDt() {
		return releaseDt;
	}

	/**
	 * @param releaseDt the releaseDt to set
	 */
	public void setReleaseDt(String releaseDt) {
		this.releaseDt = releaseDt;
	}

	/**
	 * @return the hwPrdtNm
	 */
	public String getHwPrdtNm() {
		return hwPrdtNm;
	}

	/**
	 * @param hwPrdtNm the hwPrdtNm to set
	 */
	public void setHwPrdtNm(String hwPrdtNm) {
		this.hwPrdtNm = hwPrdtNm;
	}

	/**
	 * @return the productLine
	 */
	public String getProductLine() {
		return productLine;
	}

	/**
	 * @param productLine the productLine to set
	 */
	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}

	/**
	 * @return the frameType
	 */
	public String getFrameType() {
		return frameType;
	}

	/**
	 * @param frameType the frameType to set
	 */
	public void setFrameType(String frameType) {
		this.frameType = frameType;
	}
}
