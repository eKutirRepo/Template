package com.geinfra.geaviation.pwi.json;

import java.util.List;

/**
 * 
 * Project      : Product Lifecycle Management Intelligence
 * Date Written : Jan 6, 2012
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : helps build and escape JSON (JavaScript Object Notation -
 *               strings representing objects to communicate between Java and
 *               JavaScript)
 * 
 * Revision Log Jan 6, 2012 | v1.0.
 * --------------------------------------------------------------
 */
public class JsonUtil {
	private static final JsonUtil INSTANCE = new JsonUtil();
	
	private JsonUtil () {
		// nothing to do
		// private b/c singleton
	}
	
	public static JsonUtil getInstance() {
		return INSTANCE;
	}

	public String listToJson(List<? extends Jsonable> list) {
		JsonBuilder builder = new JsonBuilder();
		
		builder.startArray();
		for (Jsonable jsonable : list) {
			builder.addRawJsonElement(jsonable.toJson());
		}
		builder.endArray();
		
		return builder.toString();
	}
	public static String listToJsonStatic(List<? extends Jsonable> list) {
		JsonBuilder builder = new JsonBuilder();
		
		builder.startArray();
		for (Jsonable jsonable : list) {
			builder.addRawJsonElement(jsonable.toJson());
		}
		builder.endArray();
		
		return builder.toString();
	}
	public static String queryResusts(List<? extends Jsonable> list) {
		JsonBuilder builder = new JsonBuilder();
		
		builder.startArray();
		for (Jsonable jsonable : list) {
			builder.addRawJsonElement(jsonable.toJson());
		}
		builder.endArray();
		
		return builder.toString();
	}
}
