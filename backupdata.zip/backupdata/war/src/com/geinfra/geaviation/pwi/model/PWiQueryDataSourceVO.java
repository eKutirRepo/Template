/*
//  @ Project : PWi
//  @ File Name : PWiUserCustomQueryVO.java
//  @ Date : 5/14/2010
//  @ Author : nisverma
 */

package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : PWiQueryDataSourceVO - Query Data Source object
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiQueryDataSourceVO extends PWiBaseVO implements Serializable {
	private static final long serialVersionUID = 1L;
	protected PWiQueryDataSourcePKVO PWiQueryDataSourcePK;
	private PWiDataSourceSystemVO PWiDataSourceSystem;
	private PWiQueryVO PWiQuery;

	public PWiQueryDataSourceVO() {
	}

	public PWiQueryDataSourceVO(PWiQueryDataSourcePKVO PWiQueryDataSourcePK) {
		this.PWiQueryDataSourcePK = PWiQueryDataSourcePK;
	}

	public PWiQueryDataSourceVO(PWiQueryDataSourcePKVO PWiQueryDataSourcePK,
			Date crtnDt, String crtdBy, Date lstUpdtDt, String lstUpdtdBy) {
		super(crtnDt, crtdBy, lstUpdtDt, lstUpdtdBy);
		this.PWiQueryDataSourcePK = PWiQueryDataSourcePK;
	}

	public PWiQueryDataSourceVO(int dataSrcSysSeqId, int qrySeqId) {
		this.PWiQueryDataSourcePK = new PWiQueryDataSourcePKVO(
				dataSrcSysSeqId, qrySeqId);
	}

	public PWiQueryDataSourcePKVO getPWiQueryDataSourcePK() {
		return PWiQueryDataSourcePK;
	}

	public void setPWiQueryDataSourcePK(
			PWiQueryDataSourcePKVO PWiQueryDataSourcePK) {
		this.PWiQueryDataSourcePK = PWiQueryDataSourcePK;
	}

	public PWiDataSourceSystemVO getPWiDataSourceSystem() {
		return PWiDataSourceSystem;
	}

	public void setPWiDataSourceSystem(
			PWiDataSourceSystemVO PWiDataSourceSystem) {
		this.PWiDataSourceSystem = PWiDataSourceSystem;
	}

	public PWiQueryVO getPWiQuery() {
		return PWiQuery;
	}

	public void setPWiQuery(PWiQueryVO PWiQuery) {
		this.PWiQuery = PWiQuery;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (PWiQueryDataSourcePK != null ? PWiQueryDataSourcePK
				.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object instanceof PWiQueryDataSourceVO) {
			PWiQueryDataSourceVO other = (PWiQueryDataSourceVO) object;
			if (this.PWiQueryDataSourcePK != null
					&& other.PWiQueryDataSourcePK != null) {
				return this.PWiQueryDataSourcePK
						.equals(other.PWiQueryDataSourcePK);
			}
		}
		return false;
	}

	@Override
	public String toString() {
		return "com.geinfra.geaviation.pwi.model.PWiQueryDataSource[PWiQueryDataSourcePK="
				+ PWiQueryDataSourcePK + "]";
	}

}
