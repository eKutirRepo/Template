/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEBOMPddrDaoImpl.java
 * @Creation date: 05-Dec-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMEBOMPddrData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMEBOMPddrDaoImpl extends SimpleJdbcDaoSupport implements PLMEBOMPddrDaoIfc {
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMEBOMPddrDaoImpl.class);

	/**
	 * This method is used to get drop down values
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEBOMPddrData> getEbomRevisions(String partName)throws PLMCommonException{
		LOG.info("Entering getRevisions method");
		List<PLMEBOMPddrData> revisionDataList = new ArrayList<PLMEBOMPddrData>();
		try {
			LOG.info("Executed Query for Revisons list"+PLMOfflineQueries.GET_EBOM_REVISIONS);
			revisionDataList =getSimpleJdbcTemplate().query(
					PLMOfflineQueries.GET_EBOM_REVISIONS, new RevisionsListMapper(), partName);
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getRevisions method");
		return revisionDataList;
	}

	/**
	 * Row mapper for getting dropMapper
	 */
	
	/**
	 * Row mapper for getting PddrMapper
	 */
	private static final class RevisionsListMapper implements ParameterizedRowMapper<PLMEBOMPddrData>{	
	public PLMEBOMPddrData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMEBOMPddrData tempData = new PLMEBOMPddrData();
		tempData.setRevision(PLMUtils.checkNullVal(rs.getString("REVISION")));
		tempData.setState(PLMUtils.checkNullVal(rs.getString("STATE")));
		tempData.setProdStatus(PLMUtils.checkNullVal(rs.getString("PRODUCTION_STATUS")));
		return tempData;
		}
	}
	
	/**
	 * This method is used to get EBOM Pddr Report
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEBOMPddrData> getEBOMPddrReport(String partName,String revisionName)throws PLMCommonException{
		LOG.info("Entering getEBOMPddrReport method");
		List<PLMEBOMPddrData> ebomPddrList = new ArrayList<PLMEBOMPddrData>();
		String timeStamp = null;
		String VTEBOM_ALL_PARTS = null;
		String VT_EBOM_PART_DATA = null;
		String VTEBOM_TO_DOC = null;
		String VTEBOM_GE_DOC = null;
		String VTEBOM_PRT_DOC = null;
		String VTEBOM_MTR_DOC = null;
		String VTEBOM_ALL_DOC = null;
		String VTEBOM_PF_ATTR = null;
		String VTEBOM_PF_DATA = null;
		String VTEBOM_ALT_PART = null;
		String VTEBOM_PDDR =null;
		LOG.info("partName>> "+partName);
		LOG.info("revisionName>> "+revisionName);
		try {
			timeStamp = PLMUtils.volTableFormatDate();
			LOG.info("The timeStamp for the Report "+timeStamp);
			
			VTEBOM_ALL_PARTS = PLMConstants.VTEBOM_ALL_PARTS.concat(timeStamp);
			VT_EBOM_PART_DATA = PLMConstants.VT_EBOM_PART_DATA.concat(timeStamp);
			VTEBOM_TO_DOC = PLMConstants.VTEBOM_TO_DOC.concat(timeStamp);
			VTEBOM_GE_DOC = PLMConstants.VTEBOM_GE_DOC.concat(timeStamp);
			VTEBOM_PRT_DOC = PLMConstants.VTEBOM_PRT_DOC.concat(timeStamp);
			VTEBOM_MTR_DOC = PLMConstants.VTEBOM_MTR_DOC.concat(timeStamp);
			VTEBOM_ALL_DOC = PLMConstants.VTEBOM_ALL_DOC.concat(timeStamp);
			VTEBOM_PF_ATTR = PLMConstants.VTEBOM_PF_ATTR.concat(timeStamp);
			VTEBOM_PF_DATA = PLMConstants.VTEBOM_PF_DATA.concat(timeStamp);
			VTEBOM_ALT_PART = PLMConstants.VTEBOM_ALT_PART.concat(timeStamp);
			VTEBOM_PDDR = PLMConstants.VTEBOM_PDDR.concat(timeStamp);
		
			LOG.info("Query for Creating VTEBOM_ALL_PARTS : " + PLMOfflineQueries.CREATE_VTEBOM_ALL_PARTS.replace(PLMConstants.VTEBOM_ALL_PARTS, VTEBOM_ALL_PARTS));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VTEBOM_ALL_PARTS.replace(PLMConstants.VTEBOM_ALL_PARTS, VTEBOM_ALL_PARTS));
			
			LOG.info("Query for Creating VT_EBOM_PART_DATA : " + PLMOfflineQueries.CREATE_VTEBOM_PART_DATA.replace(PLMConstants.VT_EBOM_PART_DATA, VT_EBOM_PART_DATA)
					.replace("?", partName).replace("#", revisionName));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VTEBOM_PART_DATA.replace(PLMConstants.VT_EBOM_PART_DATA, VT_EBOM_PART_DATA)
					.replace("?", partName).replace("#", revisionName));
		
			LOG.info("Query for Collect STATS VT_EBOM_PART_DATA " + PLMOfflineQueries.COLLECT_STAT_VTEBOM_PART_DATA.replace(PLMConstants.VT_EBOM_PART_DATA, VT_EBOM_PART_DATA));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STAT_VTEBOM_PART_DATA.replace(PLMConstants.VT_EBOM_PART_DATA, VT_EBOM_PART_DATA));

			LOG.info("Query for Creating VTEBOM_TO_DOC : " + PLMOfflineQueries.CREATE_VTEBOM_TO_DOC.replace(PLMConstants.VTEBOM_TO_DOC, VTEBOM_TO_DOC)
					.replace(PLMConstants.VT_EBOM_PART_DATA, VT_EBOM_PART_DATA));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VTEBOM_TO_DOC.replace(PLMConstants.VTEBOM_TO_DOC, VTEBOM_TO_DOC)
					.replace(PLMConstants.VT_EBOM_PART_DATA, VT_EBOM_PART_DATA));
			
			LOG.info("Query for Creating VTEBOM_GE_DOC : " + PLMOfflineQueries.CREATE_VTEBOM_GE_DOC.replace(PLMConstants.VTEBOM_GE_DOC, VTEBOM_GE_DOC)
					.replace(PLMConstants.VTEBOM_TO_DOC, VTEBOM_TO_DOC));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VTEBOM_GE_DOC.replace(PLMConstants.VTEBOM_GE_DOC, VTEBOM_GE_DOC)
					.replace(PLMConstants.VTEBOM_TO_DOC, VTEBOM_TO_DOC));

			LOG.info("Query for Creating VTEBOM_PRT_DOC : " + PLMOfflineQueries.CREATE_VTEBOM_PRT_DOC.replace(PLMConstants.VTEBOM_PRT_DOC, VTEBOM_PRT_DOC)
					.replace(PLMConstants.VTEBOM_GE_DOC, VTEBOM_GE_DOC).replace(PLMConstants.VTEBOM_TO_DOC, VTEBOM_TO_DOC));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VTEBOM_PRT_DOC.replace(PLMConstants.VTEBOM_PRT_DOC, VTEBOM_PRT_DOC)
					.replace(PLMConstants.VTEBOM_GE_DOC, VTEBOM_GE_DOC).replace(PLMConstants.VTEBOM_TO_DOC, VTEBOM_TO_DOC));

			LOG.info("Query for Collect STATS VTEBOM_PRT_DOC 1 " + PLMOfflineQueries.COLLECT_STAT_VTEBOM_PRT_DOC_1.replace(PLMConstants.VTEBOM_PRT_DOC, VTEBOM_PRT_DOC));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STAT_VTEBOM_PRT_DOC_1.replace(PLMConstants.VTEBOM_PRT_DOC, VTEBOM_PRT_DOC));
			
			LOG.info("Query for Collect STATS VTEBOM_PRT_DOC 2 " + PLMOfflineQueries.COLLECT_STAT_VTEBOM_PRT_DOC_2.replace(PLMConstants.VTEBOM_PRT_DOC, VTEBOM_PRT_DOC));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STAT_VTEBOM_PRT_DOC_2.replace(PLMConstants.VTEBOM_PRT_DOC, VTEBOM_PRT_DOC));
			
			LOG.info("Query for Collect STATS VTEBOM_PRT_DOC 3 " + PLMOfflineQueries.COLLECT_STAT_VTEBOM_PRT_DOC_3.replace(PLMConstants.VTEBOM_PRT_DOC, VTEBOM_PRT_DOC));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STAT_VTEBOM_PRT_DOC_3.replace(PLMConstants.VTEBOM_PRT_DOC, VTEBOM_PRT_DOC));
	
			LOG.info("Query for Creating VTEBOM_MTR_DOC : " + PLMOfflineQueries.CREATE_VTEBOM_MTR_DOC.replace(PLMConstants.VTEBOM_MTR_DOC, VTEBOM_MTR_DOC)
					.replace(PLMConstants.VT_EBOM_PART_DATA, VT_EBOM_PART_DATA));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VTEBOM_MTR_DOC.replace(PLMConstants.VTEBOM_MTR_DOC, VTEBOM_MTR_DOC)
					.replace(PLMConstants.VT_EBOM_PART_DATA, VT_EBOM_PART_DATA));

			LOG.info("Query for Creating VTEBOM_ALL_DOC : " + PLMOfflineQueries.CREATE_VTEBOM_ALL_DOC.replace(PLMConstants.VTEBOM_ALL_DOC, VTEBOM_ALL_DOC)
					.replace(PLMConstants.VTEBOM_PRT_DOC, VTEBOM_PRT_DOC).replace(PLMConstants.VTEBOM_MTR_DOC, VTEBOM_MTR_DOC)
					.replace(PLMConstants.VT_EBOM_PART_DATA, VT_EBOM_PART_DATA));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VTEBOM_ALL_DOC.replace(PLMConstants.VTEBOM_ALL_DOC, VTEBOM_ALL_DOC)
					.replace(PLMConstants.VTEBOM_PRT_DOC, VTEBOM_PRT_DOC).replace(PLMConstants.VTEBOM_MTR_DOC, VTEBOM_MTR_DOC)
					.replace(PLMConstants.VT_EBOM_PART_DATA, VT_EBOM_PART_DATA));
			
			LOG.info("Query for Creating VTEBOM_PF_ATTR : " + PLMOfflineQueries.CREATE_VTEBOM_PF_ATTR.replace(PLMConstants.VTEBOM_PF_ATTR, VTEBOM_PF_ATTR)
					.replace(PLMConstants.VT_EBOM_PART_DATA, VT_EBOM_PART_DATA));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VTEBOM_PF_ATTR.replace(PLMConstants.VTEBOM_PF_ATTR, VTEBOM_PF_ATTR)
					.replace(PLMConstants.VT_EBOM_PART_DATA, VT_EBOM_PART_DATA));
			
			LOG.info("Query for Collect STATS VTEBOM_PF_ATTR 1 " + PLMOfflineQueries.COLLECT_STAT_VTEBOM_PF_ATTR_1.replace(PLMConstants.VTEBOM_PF_ATTR, VTEBOM_PF_ATTR));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STAT_VTEBOM_PF_ATTR_1.replace(PLMConstants.VTEBOM_PF_ATTR, VTEBOM_PF_ATTR));
			
			LOG.info("Query for Collect STATS VTEBOM_PF_ATTR 2 " + PLMOfflineQueries.COLLECT_STAT_VTEBOM_PF_ATTR_2.replace(PLMConstants.VTEBOM_PF_ATTR, VTEBOM_PF_ATTR));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STAT_VTEBOM_PF_ATTR_2.replace(PLMConstants.VTEBOM_PF_ATTR, VTEBOM_PF_ATTR));
			
			LOG.info("Query for Collect STATS VTEBOM_PF_ATTR 3 " + PLMOfflineQueries.COLLECT_STAT_VTEBOM_PF_ATTR_3.replace(PLMConstants.VTEBOM_PF_ATTR, VTEBOM_PF_ATTR));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STAT_VTEBOM_PF_ATTR_3.replace(PLMConstants.VTEBOM_PF_ATTR, VTEBOM_PF_ATTR));
			
			LOG.info("Query for Creating VTEBOM_PF_DATA : " + PLMOfflineQueries.CREATE_VTEBOM_PF_DATA.replace(PLMConstants.VTEBOM_PF_DATA, VTEBOM_PF_DATA)
					.replace(PLMConstants.VTEBOM_PF_ATTR, VTEBOM_PF_ATTR));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VTEBOM_PF_DATA.replace(PLMConstants.VTEBOM_PF_DATA, VTEBOM_PF_DATA)
					.replace(PLMConstants.VTEBOM_PF_ATTR, VTEBOM_PF_ATTR));
			
			LOG.info("Query for Collect STATS VTEBOM_PF_DATA 1 " + PLMOfflineQueries.COLLECT_STAT_VTEBOM_PF_DATA_1.replace(PLMConstants.VTEBOM_PF_DATA, VTEBOM_PF_DATA));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STAT_VTEBOM_PF_DATA_1.replace(PLMConstants.VTEBOM_PF_DATA, VTEBOM_PF_DATA));
			
			LOG.info("Query for Collect STATS VTEBOM_PF_DATA 2 " + PLMOfflineQueries.COLLECT_STAT_VTEBOM_PF_DATA_2.replace(PLMConstants.VTEBOM_PF_DATA, VTEBOM_PF_DATA));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STAT_VTEBOM_PF_DATA_2.replace(PLMConstants.VTEBOM_PF_DATA, VTEBOM_PF_DATA));
			
			LOG.info("Query for Collect STATS VTEBOM_PF_DATA 3 " + PLMOfflineQueries.COLLECT_STAT_VTEBOM_PF_DATA_3.replace(PLMConstants.VTEBOM_PF_DATA, VTEBOM_PF_DATA));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STAT_VTEBOM_PF_DATA_3.replace(PLMConstants.VTEBOM_PF_DATA, VTEBOM_PF_DATA));

			LOG.info("Query for Creating VTEBOM_ALT_PART : " + PLMOfflineQueries.CREATE_VTEBOM_ALT_PART.replace(PLMConstants.VTEBOM_ALT_PART, VTEBOM_ALT_PART)
					.replace(PLMConstants.VT_EBOM_PART_DATA, VT_EBOM_PART_DATA).replace(PLMConstants.VTEBOM_ALL_PARTS, VTEBOM_ALL_PARTS));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VTEBOM_ALT_PART.replace(PLMConstants.VTEBOM_ALT_PART, VTEBOM_ALT_PART)
					.replace(PLMConstants.VT_EBOM_PART_DATA, VT_EBOM_PART_DATA).replace(PLMConstants.VTEBOM_ALL_PARTS, VTEBOM_ALL_PARTS));
			
			LOG.info("Query for Creating VTEBOM_PDDR : " + PLMOfflineQueries.CREATE_VTEBOM_PDDR.replace(PLMConstants.VTEBOM_PDDR, VTEBOM_PDDR)
					.replace(PLMConstants.VTEBOM_ALL_DOC, VTEBOM_ALL_DOC).replace(PLMConstants.VTEBOM_PF_DATA, VTEBOM_PF_DATA)
					.replace(PLMConstants.VTEBOM_ALT_PART, VTEBOM_ALT_PART));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VTEBOM_PDDR.replace(PLMConstants.VTEBOM_PDDR, VTEBOM_PDDR)
					.replace(PLMConstants.VTEBOM_ALL_DOC, VTEBOM_ALL_DOC).replace(PLMConstants.VTEBOM_PF_DATA, VTEBOM_PF_DATA)
					.replace(PLMConstants.VTEBOM_ALT_PART, VTEBOM_ALT_PART));

			
			LOG.info("Query for Executing final VTEBOM_PDDR_Data : " + PLMOfflineQueries.GET_EBOM_PDDR_DATA.replace(PLMConstants.VTEBOM_PDDR, VTEBOM_PDDR));
			ebomPddrList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_EBOM_PDDR_DATA.replace(PLMConstants.VTEBOM_PDDR, VTEBOM_PDDR)
					,new EBomPddrMapper());
			LOG.info("Result Size : " + ebomPddrList.size());
			
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getEBOMPddrReport method");
		return ebomPddrList;
	}

	
	/**
	 * Row mapper for getting PddrMapper
	 */
	private static final class EBomPddrMapper implements ParameterizedRowMapper<PLMEBOMPddrData>{	
	public PLMEBOMPddrData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMEBOMPddrData tempData = new PLMEBOMPddrData();
		tempData.setLevel(PLMUtils.checkNullVal(rs.getString("LVL")));
		tempData.setFn(PLMUtils.checkNullVal(rs.getString("FIND_NUM")));
		tempData.setBomPrefix(PLMUtils.checkNullVal(rs.getString("GE_BOM_PREFIX")));
		tempData.setPartNumber(PLMUtils.checkNullVal(rs.getString("CHILD_NAME")));
		tempData.setPartRev(PLMUtils.checkNullVal(rs.getString("CHILD_REVISION")));
		tempData.setQty(PLMUtils.checkNullVal(rs.getString("QUANTITY")).trim());
		tempData.setUom(PLMUtils.checkNullVal(rs.getString("UOM")));
		tempData.setEid(PLMUtils.checkNullVal(rs.getString("EID")));
		tempData.setDocName(PLMUtils.checkNullVal(rs.getString("DOC_NAME")));
		tempData.setDocRev(PLMUtils.checkNullVal(rs.getString("DOC_REV")));
		tempData.setDescription(PLMUtils.checkNullVal(rs.getString("DESCRIPTION")));
		tempData.setType(PLMUtils.checkNullVal(rs.getString("_TYPE")));
		tempData.setState(PLMUtils.checkNullVal(rs.getString("STATE")));
		tempData.setOrgReplcPart(PLMUtils.checkNullVal(rs.getString("ALT_PART_NEW")));
		tempData.setModelValidated(PLMUtils.checkNullVal(rs.getString("MODEL_VALIDATED")));
		tempData.setPartAttribute(PLMUtils.splitSemicolonSymbol(rs.getString("PF_ATTRIBUTE_VAL_NEW")));
		return tempData;
		}
	}

}
