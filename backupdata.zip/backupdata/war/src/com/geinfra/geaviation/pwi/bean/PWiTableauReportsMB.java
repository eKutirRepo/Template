 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PWiTableauReportsMB.java
 * @Creation date: 26-April-2016
 * @version 1.0
 * @author : Karunesh. S 
 */

package com.geinfra.geaviation.pwi.bean;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.PWiTableauReportsVO;
import com.geinfra.geaviation.pwi.service.PWiTableauReportsServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

/**
 * PWiTableauReportsMB is the managed bean class .
 */

@SuppressWarnings("unused")
public class PWiTableauReportsMB extends BaseBean implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private static Logger LOG = Logger.getLogger(PWiTableauReportsMB.class);
	
	boolean showViewFlag = false;
	boolean showValFlag = false;
	
	private String format = "1";
	private String showValMessage;
	private String displayName;
	private String description;
	private String serverURL;
	private String site;
	private String reportName;
	private String selectedReportView;	
	private String reportsJSON;
	private String allReportsJSON;
	
	List<SelectItem> reportItems = new ArrayList<SelectItem>();
	
	private List<PWiTableauReportsVO> pwitableaureports;
	
	private List<PWiTableauReportsVO> uniquepwitableaureports;

	private PWiTableauReportsServiceIfc tableauReportsServiceIfc; 
	
	public String fetchTableauReports(Integer id) throws PLMCommonException, PWiException, JsonGenerationException, JsonMappingException, IOException{
		pwitableaureports = tableauReportsServiceIfc.getTableauReports(id);
		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		return ow.writeValueAsString(pwitableaureports);
	}
	
	public void fetchAllTableauReports() throws PLMCommonException, PWiException, JsonGenerationException, JsonMappingException, IOException{
		uniquepwitableaureports = tableauReportsServiceIfc.getAllTableauReports(Integer.parseInt(getSsoId()));
		reportItems = new ArrayList<SelectItem>();
		if(uniquepwitableaureports.size() > 0){
			showViewFlag = false;
			for (int i=0; i<uniquepwitableaureports.size(); i++) {
				reportItems.add(new SelectItem(uniquepwitableaureports.get(i).getId(), uniquepwitableaureports.get(i).getName()));
			}
		} else {
			showViewFlag = true;
			reportItems.add(new SelectItem(0, "No Reports Available"));
		}
	}
	
	public String saveTableauReportView() throws NumberFormatException, PLMCommonException, PWiException{
		return tableauReportsServiceIfc.createTableauMapping(Integer.parseInt(getSsoId()), Integer.parseInt(selectedReportView));
	}
	
	public String saveTableauReportConf() throws NumberFormatException, PLMCommonException, PWiException{
		
		if(displayName == null || serverURL == null){
			showValFlag = true;
			showValMessage = "All fields are mandatory.";
			return "tableauReports";
		}
		
		if(reportName == null || reportName == "") reportName = "NA";
		
		String returnString = tableauReportsServiceIfc.createTableauConf(displayName, description, serverURL, reportName, format, site);
		displayName = "";
		description = "";
		serverURL = "";
		reportName = "";
		format = "1";
		site = "";
		return returnString;
	}
	
	public String deleteTableauReportView() throws NumberFormatException, PLMCommonException, PWiException{
		return tableauReportsServiceIfc.deleteTableauMapping(Integer.parseInt(selectedReportView));
	}
	
	public String deleteTableauReportConf() throws NumberFormatException, PLMCommonException, PWiException{
		return tableauReportsServiceIfc.deleteTableauConf(Integer.parseInt(selectedReportView));
	}
	
	public static Logger getLOG() {
		return LOG;
	}

	public static void setLOG(Logger lOG) {
		LOG = lOG;
	}

	public List<PWiTableauReportsVO> getPwitableaureports() {
		return pwitableaureports;
	}

	public void setPwitableaureports(List<PWiTableauReportsVO> pwitableaureports) {
		this.pwitableaureports = pwitableaureports;
	}

	public List<PWiTableauReportsVO> getUniquepwitableaureports() {
		return uniquepwitableaureports;
	}

	public void setUniquepwitableaureports(
			List<PWiTableauReportsVO> uniquepwitableaureports) {
		this.uniquepwitableaureports = uniquepwitableaureports;
	}

	public String getReportsJSON() throws NumberFormatException, PWiException, JsonGenerationException, JsonMappingException, PLMCommonException, IOException {
		Integer id = Integer.parseInt(getSsoId());
		return fetchTableauReports(id);
	}

	public void setReportsJSON(String reportsJSON) {
		this.reportsJSON = reportsJSON;
	}

	public PWiTableauReportsServiceIfc getTableauReportsServiceIfc() {
		return tableauReportsServiceIfc;
	}

	public void setTableauReportsServiceIfc(
			PWiTableauReportsServiceIfc tableauReportsServiceIfc) {
		this.tableauReportsServiceIfc = tableauReportsServiceIfc;
	}

	public void setAllReportsJSON(String allReportsJSON) {
		this.allReportsJSON = allReportsJSON;
	}

	public String getSelectedReportView() throws JsonGenerationException, JsonMappingException, PLMCommonException, PWiException, IOException {
		fetchAllTableauReports();
		return selectedReportView;
	}

	public void setSelectedReportView(String selectedReportView) {
		this.selectedReportView = selectedReportView;
	}

	public List<SelectItem> getReportItems() {
		return reportItems;
	}

	public void setReportItems(List<SelectItem> reportItems) {
		this.reportItems = reportItems;
	}

	public String getAllReportsJSON() {
		return allReportsJSON;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getServerURL() {
		return serverURL;
	}

	public void setServerURL(String serverURL) {
		this.serverURL = serverURL;
	}
	
	public String getSite() {
		return site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public boolean isShowViewFlag() {
		return showViewFlag;
	}

	public void setShowViewFlag(boolean showViewFlag) {
		this.showViewFlag = showViewFlag;
	}

	public boolean isShowValFlag() {
		return showValFlag;
	}

	public void setShowValFlag(boolean showValFlag) {
		this.showValFlag = showValFlag;
	}

	public String getShowValMessage() {
		return showValMessage;
	}

	public void setShowValMessage(String showValMessage) {
		this.showValMessage = showValMessage;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

}