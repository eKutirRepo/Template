/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMTrendReportMB.java
 * @Creation date: 15-June-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.bean;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.richfaces.event.UploadEvent;
import org.richfaces.model.UploadItem;

import com.geinfra.geaviation.pwi.data.PLMABITData;
import com.geinfra.geaviation.pwi.data.PLMMbomTrendData;
import com.geinfra.geaviation.pwi.data.PLMPartTrendsData;
import com.geinfra.geaviation.pwi.service.PLMTrendReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

public class PLMTrendReportMB {
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMTrendReportMB.class);
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB=null;
	/**
	 * Holds the alert messages
	 */
	private String alertMessage;
	/**
	 * Holds the field name
	 */
	private String fieldName;
	/**
	 * Holds the total records fetched for given search criteria.
	 */
	private int totalRecCount;
	/**
	 * Holds the Pagination Initial Value .
	 */
	private int parttotalRecCount = PLMConstants.N_100;
	/**
	 * Holds the Message for total count result.
	 */
	private String totalCountString;
	/**
	 * Holds the dropdownlist
	 */
	Map<String, List<SelectItem>> dropdownlist;
	/**
	 * Holds the partdropdownlist
	 */
	Map<String, List<SelectItem>> partdropdownlist;
	/**
	 * Holds the rdoListData
	 */
	private List<SelectItem> rdoListData;
	/**
	 * Holds the rdoPartListData
	 */
	private List<SelectItem> rdoPartListData;
	/**
	 * Holds the trendReportService
	 */
	private PLMTrendReportServiceIfc trendReportService = null;
	/**
	 * Holds the plmTrendsObj
	 */
	private PLMPartTrendsData plmTrendsObj = new PLMPartTrendsData();
	/**
	 * Holds the reportCiretiraMsg
	 */
	private String reportCiretiraMsg;
	/**
	 * Holds the mbomTrendData
	 */
	private PLMMbomTrendData mbomTrendData = new PLMMbomTrendData();
	/**
	 * Holds the mbomSearchResultList
	 */
	private List<PLMMbomTrendData> mbomSearchResultList;
	/**
	 * Holds the mbomAlertMessage
	 */
	private String mbomAlertMessage;
	/**
	 * Holds the mbomRecCountMsg
	 */
	private String mbomRecCountMsg;
	/**
	 * Holds the mbomRecCounts
	 */
	private int mbomRecCounts = PLMConstants.N_100;
	/**
	 * Holds the rdoNamesList
	 */
	private List<String> rdoNamesList;
	/**
	 * Holds the searchListPart
	 */
	private List<PLMPartTrendsData> searchListPart;
	 /**
	 * The ResourceBundle resourceBundle.
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * List of PLMABITData.
	 */
	private List<PLMABITData> listOfNasFlts = new ArrayList<PLMABITData>();
	/**
	 * boolean of nasFlstFlag
	 */
	private boolean nasFlstFlag;
	/**
	 * int of totnasFlst
	 */
	private int totnasFlst;
	/**
	 * Holds the fileexists
	 */
	private String fileexists = "notexists";
	
	private String fileNmsNas;
	
	private String selFileName="";
	/**
	 * This method is used for Load Mbom Trend Page
	 * 
	 * @return String
	 */
	public String loadMbomTrendPage() {
		LOG.info("Entering loadMbomTrendPage Method ");
		String fwdFlag = "";
		mbomTrendData = new PLMMbomTrendData();
		fwdFlag = "mbomtrendsearch";
		try {
			commonMB.insertCannedRptRecordHitInfo("MBOM Trends");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		try {
			commonMB.getLegacyDateStamp();
			} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getLegacyDateStamp: ", exception);
		} 
		LOG.info("Exiting loadMbomTrendPage Method ");
		return fwdFlag;
	}
	/**
	 * This method is used for Load Mbom Trend Report
	 * 
	 * @return String
	 */
	public String getMbomTrendReport() {
		LOG.info("Entering getMbomTrendReport Method ");
		String fwdflag = "";
		try {
			if (PLMUtils.isEmpty(mbomTrendData.getMlNumTrnd())) {
				alertMessage = PLMConstants.MBOM_SEARCH_CRITERIA;
			}
			else if (!PLMUtils.checkForSpecialChars(mbomTrendData.getMlNumTrnd())) {
				alertMessage = alertMessage + PLMConstants.MBOM_SEARCH_SPLCHAR_CRITERIA;
			}
			else
			{
			mbomSearchResultList = trendReportService.getMbomTrendReport(mbomTrendData);
			if (mbomSearchResultList != null) {
				totalRecCount = mbomSearchResultList.size();
			} else {
				totalRecCount = 0;
			}
			if (totalRecCount == 0)
				{
				fwdflag = "invalidmbomtrendsearch";
			}else {
				mbomRecCounts = PLMConstants.N_100;
				fwdflag = "mbomtrendreport";
				mbomRecCountMsg = "Total Results Count : " + totalRecCount;
			}
			LOG.info("Total Results Count" + totalRecCount);
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getMbomTrendReport: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"mbomtrendsearch","BOM Trends - MBOM Trends");
		} 
		LOG.info("Exiting getMbomTrendReport Method ");
		return fwdflag;
	}
	
	/**
	 * This method is used for Resetting the Form Data
	 * 
	 * @return String
	 */
	public String resetMbomData() {
		LOG.info("Entering resetMbomData Method");
		String fwdflag = "mbomtrendsearch";
		if (mbomTrendData.getMlNumTrnd() != null)
			mbomTrendData.setMlNumTrnd("");
		LOG.info("Exiting resetMbomData Method");
		return fwdflag;
	}
	
	 /**
	 * This method is used to load the parttrendsearch page
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String loadPartTrendSearch() throws PLMCommonException {
		LOG.info("Inside the loadPartTrendSearch method");
		String fwdflag = "";
		rdoNamesList = new ArrayList<String>();
		plmTrendsObj = new PLMPartTrendsData();
	
		try {
			dropdownlist = trendReportService.getPartDropDownvalues();
			rdoListData = (List<SelectItem>) dropdownlist.get("rdolist");
			LOG.info("listSize==" + rdoListData.size());
			fwdflag = "partTrendSearch";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadPartTrendSearch: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Part Trends");
		} 
		
		try {
			commonMB.insertCannedRptRecordHitInfo("Part Trends");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			commonMB.getPLMDateStamp(PLMConstants.ECO_TABLE);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPLMDateStamp: ", exception);
		} 
		
		return fwdflag;
	}
	/**
	 * This method is used to get data for given search criteria
	 * 
	 * @return String 
	 */
	public String getPartTrendsData() {
		LOG.info("Inside the getPartTrendsData method Base on search Criteria");
		searchListPart = new ArrayList<PLMPartTrendsData>();
		reportCiretiraMsg="";
		boolean continueFlag = false;
		String fwdFlag = "";
		LOG.info("countinue Flag==" + continueFlag);
		try {
			continueFlag = validateSearchParams();
			if (continueFlag) {
				LOG.info("countinue Flag in if==" + continueFlag);
				if (PLMUtils.isEmpty(plmTrendsObj.getReportCriteria())) {
					reportCiretiraMsg = "";
				}
				else {
					reportCiretiraMsg = PLMConstants.PART_DISPLAY_CRITERIA
							+ plmTrendsObj.getReportCriteria();
				}

				plmTrendsObj.setRdoNamesList(rdoNamesList);
				plmTrendsObj.setRdonames(PLMUtils.setListForQuery(rdoNamesList));
				LOG.info("size of the RDOlist=="
						+ plmTrendsObj.getRdoNamesList().size());
				searchListPart = new ArrayList<PLMPartTrendsData>();
				searchListPart = trendReportService
						.getpartTrendSearchData(plmTrendsObj);
				LOG.info("size of the Searchlist==" + searchListPart.size());
				if (PLMUtils.isEmptyList(searchListPart)) {
					LOG.info("in no records of Bean Class");
					fwdFlag = "partTrendsInvalidSearch";
				} else {
					fwdFlag = "partTrendReport";
					LOG.info("in records Bean Class");
					totalRecCount = searchListPart.size();
					totalCountString = PLMConstants.TOTAL_COUNT_PERCENT
							+ totalRecCount;
					if (PLMUtils.getServletSession(true).getAttribute(
							"RecDropDown") != null
							&& !"".equals((PLMUtils.getServletSession(true)
									.getAttribute("RecDropDown")).toString()
									.trim())) {
						if (!PLMUtils
								.setNewDropDownValue(Integer.parseInt(PLMUtils
										.getServletSession(true).getAttribute(
												"RecDropDown").toString()))) {
							parttotalRecCount = Integer.parseInt(PLMUtils
									.getServletSession(true).getAttribute(
											"RecDropDown").toString());
						} else {
							parttotalRecCount = totalRecCount;
						}
					} else {
						parttotalRecCount = PLMConstants.N_100;
						fwdFlag = "partTrendReport";
					}

				}        

			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadPartTrendSearch: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"partTrendSearch","Part Trends");
		} 
		return fwdFlag;
	}
	/**
	 * This method is used to validate the page
	 * 
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean validateSearchParams() throws PLMCommonException {
		LOG.info("in validateParams");
		boolean isValidated = true;
		// LOG.info("validate===>>"+getRdoNamesList().size()+"Report\n"+PLMUtils.isEmpty(plmTrendsObj.getReportCriteria())+"\n"+PLMUtils.isEmptyList(getRdoNamesList())+"\n"+PLMUtils.isEmpty(plmTrendsObj.getReportCriteria()));
		if (PLMUtils.isEmptyList(getRdoNamesList())) {
			alertMessage = alertMessage + PLMConstants.PART_SEARCH_CRITERIA1 + "\n";
			isValidated = false;
		}
		if (PLMUtils.isEmpty(plmTrendsObj.getReportCriteria())) {
			alertMessage = alertMessage + PLMConstants.PART_SEARCH_CRITERIA + "\n";
			isValidated = false;
		}
		
		
		return isValidated;
	}
	/**
	 * This method is used to reset the form data
	 * 
	 * @return String
	 */
	public String resetData() {
		String fwdflag = "partTrendSearch";
		rdoNamesList = new ArrayList<String>();
		plmTrendsObj = new PLMPartTrendsData();
		totalCountString = null;
		return fwdflag;
	}
	
	/**
	 * This method is used for retrieving set of folder files
	 * 
	 * @return String
	 */
	
	public String retreiveNasStrFiles(){
		fileexists = "notexists";
		nasFlstFlag=false;
		String nasDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		 File dir = new File(nasDir);
		 File[] listOfFiles = dir.listFiles();
		 List<String> nasFlsList = new ArrayList<String>();
		 if (listOfFiles!=null){
			 Arrays.sort(listOfFiles, new SortFileNames());
		 
			 listOfNasFlts=new ArrayList<PLMABITData>();
			 LOG.info("Entering in to retreiveNasStrFiles");
			 if(listOfFiles.length >0){ 
			  for (int i = 0; i < listOfFiles.length; i++) {
				 PLMABITData nasFltdata = new PLMABITData();
				 nasFltdata.setNasFileName(listOfFiles[i].getName());
				 Date creationdate = new Date(listOfFiles[i].lastModified());
				 nasFltdata.setFileCreation(creationdate);
				 if (listOfFiles[i].isDirectory()){
					 nasFltdata.setFileType("Folder"); 
				 } else {
					 nasFltdata.setFileType("File"); 
				 }
				 listOfNasFlts.add(nasFltdata);
				 nasFlsList.add(listOfFiles[i].getName());
			   }
			     nasFlstFlag=true;
			 }
		 }
		 fileNmsNas = PLMUtils.joinList(nasFlsList, "~@~");
		 totnasFlst=listOfNasFlts.size();
		 LOG.info("File Names on NAS --- > "+fileNmsNas);
		 LOG.info("Exiting  in to retreiveNasStrFiles");
		 return "nsFlLst";
	}
	
	
	/**
	 * 
	 * class to sort list of object of type PLMTaskDlvrblData.
	 * 
	 */
	private static class SortFileNames implements Comparator<File>, Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		 public int compare(File f1, File f2)
		   {
		       return Long.valueOf(f2.lastModified()).compareTo(f1.lastModified());
		       //return Long.compare(f2.lastModified(), f1.lastModified());
		   }
	}
	/**
	 * This method is used for deleting set of folder files
	 * 
	 * @return String
	 */
	public String deleteNasStrFiles(){
		String nasDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		 File dir = new File(nasDir);
		 File[] listOfFiles = dir.listFiles();
		 LOG.info("Entering in to deleteNasStrFiles");
		 if(listOfFiles!=null) {
		  for (int i = 0; i < listOfFiles.length; i++) {
			  for(int j=0;j<listOfNasFlts.size();j++){
				  if(listOfNasFlts.get(j).isCheckFile() 
						  && listOfFiles[i].getName().equals(listOfNasFlts.get(j).getNasFileName())){
					  deleteDir(listOfFiles[i]); 
				  }
			  }
		   }
		 }
		  retreiveNasStrFiles();
		 LOG.info("Exiting  in to deleteNasStrFiles");
		 return "nsFlLst";
	}
	/**
	 * @param dir
	 * @return
	 */
	public static boolean deleteDir(File dir) {
		if (dir.isDirectory()) {
			String[] children = dir.list();
			if (children!=null) {
				for (int i = 0; i < children.length; i++) {
					boolean success = deleteDir(new File(dir, children[i]));
					if (!success) {
						return false;
					}
				}
			}
		}
		return dir.delete();
	}
	/**
	 * This method is used for upload the File NS store Template
	 * 
	 * @return void
	 */
	public void uploadNsFlstTemplate(UploadEvent event) {
		LOG.info("Entering uploadNsFlstTemplate Method");
		UploadItem item = event.getUploadItem();
		File srcFile =item.getFile();
		String upFlPath=item.getFileName();
		/*LOG.info("item.getFileName() ---> "+item.getFileName());
		File dir = new File(item.getFileName());
		
		try {
			LOG.info(" Get File path from Directory dir.getCanonicalFile().getName() --> "+dir.getCanonicalFile().getName());
			upFlPath=dir.getCanonicalFile().getName(); 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LOG.info(" Get File path from Directory dir.getPath() --> "+dir.getPath());
		//File path = new File(dir.getPath());
		//upFlPath=path.getName();
		LOG.info(" Get File Name from path --> "+upFlPath);*/
			
		upFlPath = upFlPath.substring(upFlPath.lastIndexOf(resourceBundle.getString("FOLDER_SEPERATOR"))+1,upFlPath.length());
		String storagePath=resourceBundle.getString("OFFLINE_RPT_DIR");
		String outputFile = storagePath+upFlPath;
		LOG.info(" Uploaded File Name --> "+upFlPath);
		LOG.info(" storagePath --> "+storagePath);
		LOG.info(" outputFile --> "+outputFile);
		
		File storedfile = new File(outputFile);
		if (storedfile.exists()) {
			fileexists = "exists";
		} else {
			fileexists = "notexists";
		}
				
		if (srcFile.exists()) {
				FileInputStream fileInputStream = null;
				FileOutputStream fileOutputStream = null;
				try {
					fileInputStream = new FileInputStream(srcFile);
					fileOutputStream = new FileOutputStream(outputFile);
					byte[] buffer = new byte[1024];
					int bytesread;
					while ((bytesread = fileInputStream.read(buffer)) != -1) {
						fileOutputStream.write(buffer, 0, bytesread);
					}
					fileOutputStream.flush();
					fileOutputStream.close();
				} catch (FileNotFoundException ex) {
					LOG.error(ex.getMessage());
					ex.printStackTrace();
				} catch (IOException ex1) {
					LOG.error(ex1.getMessage());
					ex1.printStackTrace();
				} finally {
					if (fileInputStream != null) {
						try {
							fileInputStream.close();
						}catch (IOException ex) {
							LOG.error("Exception in Cloing fileInputStream" + ex.getMessage());
						}
					}
					if (fileOutputStream != null) {
						try {
							fileOutputStream.close();
						} catch (IOException ex) {
							LOG.error("Exception in Cloing fileOutputStream " + ex.getMessage());
						}
					}
				}
			
		}
		LOG.info("Exiting uploadNsFlstTemplate Method");
	}
	
	public String downloadFile() {
		LOG.info("Entering downloadFmiTemplate Method");
		String fwdflag = "";
		LOG.info(" File Name Selected  ------------->"+selFileName);
		String storagePath=resourceBundle.getString("OFFLINE_RPT_DIR");
		String outputFile = storagePath+selFileName;
		File storedfile = new File(outputFile);
		if (storedfile.exists()) {
			BufferedInputStream bufferedInputStream = null;
			String documentname = storedfile.getName();
			HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
			int length = 0;
			byte[] buf = new byte[1024];
			try {
				bufferedInputStream = new BufferedInputStream(new FileInputStream(storedfile));
				ServletOutputStream ouputStream = response.getOutputStream();
				while ((length = bufferedInputStream.read(buf)) != -1) {
					ouputStream.write(buf, 0, (int) length);
				}
				response.setContentType("application/force-download");
				response.setHeader("Content-Disposition",
						"attachment; filename=" + documentname);
				FacesContext.getCurrentInstance().responseComplete();
			} catch (FileNotFoundException ex) {
				LOG.error("Exception : File Not Found : " + ex.getMessage());
			} catch (IOException ex1) {
				LOG.error("Exception : Error in Reading : " + ex1.getMessage());
			}
			finally {
				try {
					if (bufferedInputStream != null) {
						bufferedInputStream.close();
					}
				} catch (IOException e) {
					LOG.error("Exception in closing the bufferedInputStream : " + e.getMessage());
				}
			}
		} else {
			alertMessage = PLMConstants.FMI_TEMPLATE_NOT_FOUND;
		}
		LOG.info("Exiting downloadFmiTemplate Method");
		return fwdflag;
	}
	
	/**
	 * This method is used to download excel
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	
	public void downloadMBOMTreandExcel() throws PLMCommonException {
		
		LOG.info("Entering downloadMBOMTreandExcel Method");
		String reportName="MbomTrendReportExcelDoc";
		String fileName="MbomTrendReport";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("mfgrespcode", "CHILD ITEM PREFIX", FormatType.TEXT, null, null, 17),
                    new PLMXlsxRptColumn("totalnoparts", "Total # of Parts on BOM", FormatType.INTEGER, null, null, 22),
                    new PLMXlsxRptColumn("noofchangerevision", "#of Change REV (AN)", FormatType.INTEGER, null, null, 19)
			};

		PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] {
				new PLMXlsxRptColumn("mlNumTrnd", "ML/MPL #:", FormatType.TEXT)
		};

		excelUtil.export(mbomSearchResultList, reportColumns, fileName, fileName, true, critcolumns, mbomTrendData);
		
	}
	
	/**
	 * This method is used for Generating Report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadMBOMTreandCSV() throws PLMCommonException {
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
				new PLMCsvRptColumn("mfgrespcode", "CHILD ITEM PREFIX", FormatTypeCsv.TEXT, null, null, 17),
                new PLMCsvRptColumn("totalnoparts", "Total # of Parts on BOM", FormatTypeCsv.INTEGER, null, null, 22),
                new PLMCsvRptColumn("noofchangerevision", "#of Change REV (AN)", FormatTypeCsv.INTEGER, null, null, 19)
		};

		csvUtil.exportCsv(mbomSearchResultList, reportColumns, "mbomtrendreport", dateFormat, false, null, null, ",");
		
	}

	/**
	 * This method is used to download excel
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	
	public void downloadPartsTrendExcel() throws PLMCommonException {
		
		LOG.info("Entering downloadPartsTrendExcel Method");
		String reportName="PartSearchResultsDoc";
		String fileName="PartSearchResults";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("rdoName", "RDO Name", FormatType.TEXT, null, null, 32),
                    new PLMXlsxRptColumn("newPart", "New Part", FormatType.INTEGER, null, null, 36),
                    new PLMXlsxRptColumn("issueAgainstPart", "Issue Against Part", FormatType.INTEGER, null, null, 16),
                    new PLMXlsxRptColumn("partChangeInitiation", "Parts Change Initiation", FormatType.INTEGER, null, null, 21),
                    new PLMXlsxRptColumn("partChangeRevision", "Parts Change REV", FormatType.INTEGER, null, null, 16)
			};

		PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] {
				new PLMXlsxRptColumn("reportCriteria", "Report Criteria", FormatType.TEXT),
				new PLMXlsxRptColumn("rdonames", "RDO", FormatType.TEXT)
		};

		excelUtil.export(searchListPart, reportColumns, fileName, fileName, true, critcolumns, plmTrendsObj);
		
	}
	
	/**
	 * This method is used for Generating Report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadPartsTrendCSV() throws PLMCommonException {
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
				new PLMCsvRptColumn("rdoName", "RDO Name", FormatTypeCsv.TEXT, null, null, 32),
                new PLMCsvRptColumn("newPart", "New Part", FormatTypeCsv.INTEGER, null, null, 36),
                new PLMCsvRptColumn("issueAgainstPart", "Issue Against Part", FormatTypeCsv.INTEGER, null, null, 16),
                new PLMCsvRptColumn("partChangeInitiation", "Parts Change Initiation", FormatTypeCsv.INTEGER, null, null, 21),
                new PLMCsvRptColumn("partChangeRevision", "Parts Change REV", FormatTypeCsv.INTEGER, null, null, 16)
		};

		csvUtil.exportCsv(searchListPart, reportColumns, "PartSearchResults", dateFormat, false, null, null, ",");
		
	}
	
	/**
	 * @return the listOfNasFlts
	 */
	public List<PLMABITData> getListOfNasFlts() {
		return listOfNasFlts;
	}

	/**
	 * @param listOfNasFlts the listOfNasFlts to set
	 */
	public void setListOfNasFlts(List<PLMABITData> listOfNasFlts) {
		this.listOfNasFlts = listOfNasFlts;
	}

	/**
	 * @return the nasFlstFlag
	 */
	public boolean isNasFlstFlag() {
		return nasFlstFlag;
	}

	/**
	 * @param nasFlstFlag the nasFlstFlag to set
	 */
	public void setNasFlstFlag(boolean nasFlstFlag) {
		this.nasFlstFlag = nasFlstFlag;
	}


	/**
	 * @return the totnasFlst
	 */
	public int getTotnasFlst() {
		return totnasFlst;
	}


	/**
	 * @param totnasFlst the totnasFlst to set
	 */
	public void setTotnasFlst(int totnasFlst) {
		this.totnasFlst = totnasFlst;
	}

	/**
	 * @return the fileexists
	 */
	public String getFileexists() {
		return fileexists;
	}

	/**
	 * @param fileexists the fileexists to set
	 */
	public void setFileexists(String fileexists) {
		this.fileexists = fileexists;
	}

	/**
	 * @return the fileNmsNas
	 */
	public String getFileNmsNas() {
		return fileNmsNas;
	}

	/**
	 * @param fileNmsNas the fileNmsNas to set
	 */
	public void setFileNmsNas(String fileNmsNas) {
		this.fileNmsNas = fileNmsNas;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}
	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}
	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}
	/**
	 * @param fieldName the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}
	/**
	 * @param totalRecCount the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}
	/**
	 * @return the parttotalRecCount
	 */
	public int getParttotalRecCount() {
		return parttotalRecCount;
	}
	/**
	 * @param parttotalRecCount the parttotalRecCount to set
	 */
	public void setParttotalRecCount(int parttotalRecCount) {
		this.parttotalRecCount = parttotalRecCount;
	}
	/**
	 * @return the totalCountString
	 */
	public String getTotalCountString() {
		return totalCountString;
	}
	/**
	 * @param totalCountString the totalCountString to set
	 */
	public void setTotalCountString(String totalCountString) {
		this.totalCountString = totalCountString;
	}
	/**
	 * @return the dropdownlist
	 */
	public Map<String, List<SelectItem>> getDropdownlist() {
		return dropdownlist;
	}
	/**
	 * @param dropdownlist the dropdownlist to set
	 */
	public void setDropdownlist(Map<String, List<SelectItem>> dropdownlist) {
		this.dropdownlist = dropdownlist;
	}
	/**
	 * @return the partdropdownlist
	 */
	public Map<String, List<SelectItem>> getPartdropdownlist() {
		return partdropdownlist;
	}
	/**
	 * @param partdropdownlist the partdropdownlist to set
	 */
	public void setPartdropdownlist(Map<String, List<SelectItem>> partdropdownlist) {
		this.partdropdownlist = partdropdownlist;
	}
	/**
	 * @return the rdoListData
	 */
	public List<SelectItem> getRdoListData() {
		return rdoListData;
	}
	/**
	 * @param rdoListData the rdoListData to set
	 */
	public void setRdoListData(List<SelectItem> rdoListData) {
		this.rdoListData = rdoListData;
	}
	/**
	 * @return the rdoPartListData
	 */
	public List<SelectItem> getRdoPartListData() {
		return rdoPartListData;
	}
	/**
	 * @param rdoPartListData the rdoPartListData to set
	 */
	public void setRdoPartListData(List<SelectItem> rdoPartListData) {
		this.rdoPartListData = rdoPartListData;
	}
	/**
	 * @return the trendReportService
	 */
	public PLMTrendReportServiceIfc getTrendReportService() {
		return trendReportService;
	}
	/**
	 * @param trendReportService the trendReportService to set
	 */
	public void setTrendReportService(PLMTrendReportServiceIfc trendReportService) {
		this.trendReportService = trendReportService;
	}
	/**
	 * @return the plmTrendsObj
	 */
	public PLMPartTrendsData getPlmTrendsObj() {
		return plmTrendsObj;
	}
	/**
	 * @param plmTrendsObj the plmTrendsObj to set
	 */
	public void setPlmTrendsObj(PLMPartTrendsData plmTrendsObj) {
		this.plmTrendsObj = plmTrendsObj;
	}
	/**
	 * @return the reportCiretiraMsg
	 */
	public String getReportCiretiraMsg() {
		return reportCiretiraMsg;
	}
	/**
	 * @param reportCiretiraMsg the reportCiretiraMsg to set
	 */
	public void setReportCiretiraMsg(String reportCiretiraMsg) {
		this.reportCiretiraMsg = reportCiretiraMsg;
	}
	/**
	 * @return the mbomTrendData
	 */
	public PLMMbomTrendData getMbomTrendData() {
		return mbomTrendData;
	}
	/**
	 * @param mbomTrendData the mbomTrendData to set
	 */
	public void setMbomTrendData(PLMMbomTrendData mbomTrendData) {
		this.mbomTrendData = mbomTrendData;
	}
	/**
	 * @return the mbomSearchResultList
	 */
	public List<PLMMbomTrendData> getMbomSearchResultList() {
		return mbomSearchResultList;
	}
	/**
	 * @param mbomSearchResultList the mbomSearchResultList to set
	 */
	public void setMbomSearchResultList(List<PLMMbomTrendData> mbomSearchResultList) {
		this.mbomSearchResultList = mbomSearchResultList;
	}
	/**
	 * @return the mbomAlertMessage
	 */
	public String getMbomAlertMessage() {
		return mbomAlertMessage;
	}
	/**
	 * @param mbomAlertMessage the mbomAlertMessage to set
	 */
	public void setMbomAlertMessage(String mbomAlertMessage) {
		this.mbomAlertMessage = mbomAlertMessage;
	}
	/**
	 * @return the mbomRecCountMsg
	 */
	public String getMbomRecCountMsg() {
		return mbomRecCountMsg;
	}
	/**
	 * @param mbomRecCountMsg the mbomRecCountMsg to set
	 */
	public void setMbomRecCountMsg(String mbomRecCountMsg) {
		this.mbomRecCountMsg = mbomRecCountMsg;
	}
	/**
	 * @return the mbomRecCounts
	 */
	public int getMbomRecCounts() {
		return mbomRecCounts;
	}
	/**
	 * @param mbomRecCounts the mbomRecCounts to set
	 */
	public void setMbomRecCounts(int mbomRecCounts) {
		this.mbomRecCounts = mbomRecCounts;
	}
	/**
	 * @return the rdoNamesList
	 */
	public List<String> getRdoNamesList() {
		return rdoNamesList;
	}
	/**
	 * @param rdoNamesList the rdoNamesList to set
	 */
	public void setRdoNamesList(List<String> rdoNamesList) {
		this.rdoNamesList = rdoNamesList;
	}
	/**
	 * @return the searchListPart
	 */
	public List<PLMPartTrendsData> getSearchListPart() {
		return searchListPart;
	}
	/**
	 * @param searchListPart the searchListPart to set
	 */
	public void setSearchListPart(List<PLMPartTrendsData> searchListPart) {
		this.searchListPart = searchListPart;
	}
	/**
	 * @return the selFileName
	 */
	public String getSelFileName() {
		return selFileName;
	}
	/**
	 * @param selFileName the selFileName to set
	 */
	public void setSelFileName(String selFileName) {
		this.selFileName = selFileName;
	}

	
}
