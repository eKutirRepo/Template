package com.geinfra.geaviation.pwi.bean;

import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.QueryAccessException;
import com.geinfra.geaviation.pwi.json.JsonBuilder;
import com.geinfra.geaviation.pwi.json.JsonUtil;
import com.geinfra.geaviation.pwi.model.PWiObjectTypeVO;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.model.PWiQueryNoXmlVO;
import com.geinfra.geaviation.pwi.model.QiOptionsVO;
import com.geinfra.geaviation.pwi.service.ObjectTypeService;
import com.geinfra.geaviation.pwi.service.QiService;
import com.geinfra.geaviation.pwi.service.QueriesService;
import com.geinfra.geaviation.pwi.service.QueryGroupService;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Jan 31, 2012 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : backing bean for the admin default qi options page.
 * --------------------------------------------------------------
 */
public class AdminQiSettingsBean {
	// injected services
	private ObjectTypeService objectTypeService;
	private QueriesService queriesService;
	private QueryGroupService queryGroupService;
	private QiService qiService;

	private String qiOptionsJson;
	private String queriesJson;
	private String userInfoJson;
	private List<PWiObjectTypeVO> objectTypes;
	private List<PWiQueryGroupVO> groups;
	private String selectedObjectTypeId;

	public void setObjectTypeService(ObjectTypeService objectTypeService) {
		this.objectTypeService = objectTypeService;
	}

	public void setQueriesService(QueriesService queriesService) {
		this.queriesService = queriesService;
	}

	public void setQueryGroupService(QueryGroupService queryGroupService) {
		this.queryGroupService = queryGroupService;
	}

	public void setQiService(QiService qiService) {
		this.qiService = qiService;
	}

	public String getQiOptionsJson() throws PWiException, QueryAccessException {
		if (qiOptionsJson == null && qiService != null) {
			List<QiOptionsVO> qiOptions = qiService.getAdminQiOptions();
			this.qiOptionsJson = JsonUtil.getInstance().listToJson(qiOptions);
		}
		return qiOptionsJson;
	}

	public String getSelectedObjectTypeId() throws PWiException {
		if (selectedObjectTypeId == null) {
			// default to first object type
			selectedObjectTypeId = getObjectTypes().get(0).getObjTypSeqId()
					.toString();
		}

		JsonBuilder builder = new JsonBuilder();
		builder.startObject();
		builder.addStringProperty("id", selectedObjectTypeId);
		builder.endObject();
		return builder.toString();
	}

	public String getQueriesJson() throws PWiException {
		if (queriesJson == null && queriesService != null) {
			List<PWiQueryNoXmlVO> queries = queriesService.getQueries();
			queriesJson = JsonUtil.getInstance().listToJson(queries);
		}
		return queriesJson;
	}

	private List<PWiObjectTypeVO> getObjectTypes() throws PWiException {
		if (objectTypes == null) {
			objectTypes = objectTypeService != null ? objectTypeService.getPWiQiObjectTypes() : null;
		}
		return objectTypes;
	}

	public String getObjectTypesJson() throws PWiException {
		List<PWiObjectTypeVO> theObjectTypes = getObjectTypes();
		return JsonUtil.getInstance().listToJson(theObjectTypes);
	}

	private List<PWiQueryGroupVO> getGroups() {
		if (groups == null) {
			groups = queryGroupService != null ? queryGroupService.getAllQueryGroups() : null;
		}
		return groups;
	}

	public String getGroupsJson() throws PWiException {
		return JsonUtil.getInstance().listToJson(getGroups());
	}

	public String getUserInfoJson() throws PWiException {
		if (userInfoJson == null) {
			JsonBuilder builder = new JsonBuilder();
			builder.startObject();
			builder.startArrayProperty("groupIds");
			for (PWiQueryGroupVO group : getGroups()) {
				Integer groupId = group.getQueryGroupId();
				builder.addStringElement(groupId);
			}
			builder.endArray();
			builder.addBooleanProperty("usPerson", true);
			builder.addBooleanProperty("geEmployee", true);
			builder.endObject();

			userInfoJson = builder.toString();
		}
		return userInfoJson;
	}
}
