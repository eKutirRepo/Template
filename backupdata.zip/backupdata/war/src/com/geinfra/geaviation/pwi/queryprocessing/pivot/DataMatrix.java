package com.geinfra.geaviation.pwi.queryprocessing.pivot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import jxl.common.Logger;

import com.geinfra.geaviation.pwi.util.ListUtil;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.util.QueryProcessingUtil;

/**
 * The DataMatrix class is designed to manipulate a table into a form that will
 * more coherently display the data. The class is designed to involve only the
 * manipulation of the data and in no way is connected with the presentation of
 * the data. All sorting, renaming or other features should and can be applied
 * after the DataMatrix returns the table it creates. The standard JDK
 * TableModel is the interface through which the DataMatrix accesses and returns
 * data. <BR>
 * <BR>
 * The functionality of a DataMatrix is similar to that of an Excel pivot table.
 * The DataMatrix creates a "sub-table" from a large table based on three key
 * values:
 * <ul>
 * <li>the pivot field</li>
 * <li>the fixed fields</li>
 * <li>the summary or summation fields</li>
 * </ul>
 * <BR>
 * The pivot field is the field that determines the focus of the data matrix. In
 * the source table, the pivot field can be any one of the column names. The
 * DataMatrix then generates a list of all distinct values under that column,
 * and uses these values to generate the new table columns. <BR>
 * <BR>
 * The fixed fields are columns names that are used to define the rows of the
 * output table. Each set of distinct values for each of the fixed fields is
 * given its own row. The example below clarifies this concept. <BR>
 * <BR>
 * The summary or summation fields are one or more column names. All rows that
 * have the same value in each of the fixed fields, and have the same pivot
 * value are summed together. How they are summed to together depends on the
 * type of the data. Generally Strings are concatenated together and numbers are
 * added, however this custom behavior can be overriden using the
 * setObjectSummator() method. <BR>
 * <BR>
 * Example: (Input table) <table BORDER COLS=4 WIDTH="60%" NOSAVE>
 * <tr>
 * <td>Computer</td>
 * <td>User </td>
 * <td>Hours</td>
 * <td>Week</td>
 * </tr>
 * <tr>
 * <td>1000 </td>
 * <td>Henry </td>
 * <td>12 </td>
 * <td>1 </td>
 * </tr>
 * <tr>
 * <td>1010 </td>
 * <td>Henry </td>
 * <td>10 </td>
 * <td>2 </td>
 * </tr>
 * <tr>
 * <td>1010 </td>
 * <td>Henry </td>
 * <td>10 </td>
 * <td>3 </td>
 * </tr>
 * <tr>
 * <td>1000 </td>
 * <td>David </td>
 * <td> 5 </td>
 * <td>1 </td>
 * </tr>
 * <tr>
 * <td>1000 </td>
 * <td>David </td>
 * <td> 4 </td>
 * <td>2 </td>
 * </tr>
 * <tr>
 * <td>1000 </td>
 * <td>David </td>
 * <td> 6 </td>
 * <td>3 </td>
 * </tr>
 * <tr>
 * <td>1010 </td>
 * <td>Carl </td>
 * <td> 8 </td>
 * <td>2 </td>
 * </tr>
 * </table> <BR>
 * <BR>
 * (Output with pivot field = Week, fixed fields = Computer, summary fields =
 * Hours) <table BORDER COLS=4 WIDTH="60%" NOSAVE>
 * <tr>
 * <td>Computer</td>
 * <td>Hours/Week #1</td>
 * <td>Hours/Week #2</td>
 * <td>Hours/Week #3</td>
 * </tr>
 * <tr>
 * <td>1000 </td>
 * <td>17.0 </td>
 * <td>4.0 </td>
 * <td>6.0 </td>
 * </tr>
 * <tr>
 * <td>1010 </td>
 * <td>0.0 </td>
 * <td>10.0 </td>
 * <td>12.0 </td>
 * </tr>
 * </table> <BR>
 * (Output with pivot field = Computer, fixed fields = Week, summary fields =
 * User ) <table BORDER COLS=3 WIDTH="60%" NOSAVE>
 * <tr>
 * <td>Week</td>
 * <td>Users of 1000</td>
 * <td>Users of 1010</td>
 * </tr>
 * <tr>
 * <td>1 </td>
 * <td>Henry, David </td>
 * <td>No one </td>
 * </tr>
 * <tr>
 * <td>2 </td>
 * <td>David </td>
 * <td>Henry, Carl </td>
 * </tr>
 * <tr>
 * <td>3 </td>
 * <td>David </td>
 * <td>Henry </td>
 * </tr>
 * </table> <BR>
 * <BR>
 * Various options, such as setting the DataMatrix to output "No one" rather
 * than the default of <i>null</i> are provided by the set methods of the
 * class. See individual method description for a summary of its capabilities.
 * <BR>
 * <BR>
 * Basic overview:<BR>
 * pivotValues can be set to use only a subset of all distinct values, to reduce
 * the size of the table. nullReplacement can be used to replace blank cells
 * with a more meaningfull value than null. columnNameSeparator can be used to
 * change the String that is inserted between the summary fields and pivot
 * values in the column names of the output table. showSumColumnName determines
 * where or not to include the summary field name as part of the output column
 * name. If this is false, then only the pivot value will be displayed as the
 * column name. Note that will in effect cause only one summary field and all
 * summary fields indicated will have their values collectively summated. The
 * markedValue can be used to change the default "X" in the mode where no
 * summary fields are indicated. <BR>
 * <BR>
 * For more comprehensive examples, see the TestDataMatrix class and associated
 * test files. <BR>
 * <BR>
 * 
 * <PRE>
 * &lt;b&gt;
 * *************************************************************
 * ****       COPYRIGHT 1999 WITH ALL RIGHTS RESERVED       ****
 * ****             GENERAL ELECTRIC COMPANY                ****
 * *************************************************************
 * &lt;/b&gt;
 * </PRE>
 * 
 * @author Ben Cronin
 * @version 1.0.0
 * @see TableModel
 */
/**
 * Project : Product Lifecycle Management Date Written : Apr 12, 2011 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : DataMatrix
 * 
 * Revision Log Apr 12, 2011 | v1.0.
 * --------------------------------------------------------------
 */
public class DataMatrix implements ObjectSummator {
	/** Displays all rows, regardless of missing data */
	public static final int COMPARE_FULL = 1;

	/** Displays only rows with no missing elements */
	public static final int COMPARE_COMMON = 2;

	/** Displays only rows with missing elements */
	public static final int COMPARE_DIFFERENCES = 3;

	private static final Logger LOGGER = Logger.getLogger(DataMatrix.class);

	// === E s s e n t i a l D a t a F i e l d s
	// ==================================//

	/** This is the data to analyze */
	protected TableModel inTable;

	/** This is the analyzed data summarized in a new table */
	protected DefaultTableModel outTable;

	/** This is the field to use as the pivot field */
	protected String pivotField;

	/** These are the fixed fields - they are displayed but not summated */
	protected String[] fixedFields;

	/** These are the fields that are added together using the ObjectSummator */
	protected String[] sumFields;

	// === O p t i o n a l F i e l d s
	// ==============================================//

	/**
	 * Independent sum fields are fields that are totaled together for each
	 * fixed field value combination, regardless of the associated pivot value
	 */
	protected String[] indSumFields;

	/**
	 * This string is inserted between the sum field name and the pivot field
	 * value when creating the column name for the output table.
	 */
	protected String pfSeparator = "-";

	/**
	 * The summateObjects method of this class is called to determine how two
	 * objects should be added. This allows customization of the addition
	 * process.
	 */
	protected ObjectSummator objSummator = this;

	/**
	 * When an output table is finished, all nulls will be replaced by this
	 * Object, the default being no change - a null will replace a null.
	 */
	protected Object nullReplacement;

	/**
	 * These are the pivotValues to use when generating the table. The default
	 * is to use all distinct values for the pivot field.
	 */
	protected Object[] pivotValues;

	/**
	 * Determines if the summary field name should be displayed with the fixed
	 * field value. Example: Items - Week #3 vs Week #3
	 */
	protected boolean showSumFieldName = true;

	/**
	 * Used when no summary fields are indicated. In this mode, each fixed field
	 * is "checked off" or marked as either containing or not containing the
	 * individual pivot values. The value of this variable is the "check" for
	 * example "X" could be used or Boolean(true).
	 */
	protected Object markedValue = "X";

	/** This is the type of display to use. See below for optional values */
	protected int compareType = COMPARE_FULL;

	// === U t i l i t y F i e l d s
	// ===============================================//

	/** Look-up tables to provide easier name->index access */
	protected Map<String, Integer> inNameToIndex;

	/** Look-up tables to provide easier name->index access */
	protected Map<String, Integer> outNameToIndex;

	/** There is only use for an output lookup */
	protected Map<String, Integer> outRowNameToIndex;

	// === C r e a t e M e t h o d
	// ==================================================//

	/**
	 * This function analyzes a data table and produces a TableModel similar to
	 * an Excel pivot table.
	 * 
	 * @param theInTable
	 *            the TableModel to use as the source of the info
	 * @param thePivotField
	 *            the name of the column in the inTable to use as the pivot
	 *            field.
	 * @param theFixedFields
	 *            an array of column names to use as the fixed fields in the
	 *            pivot table.
	 * @param theSumFields
	 *            an array of column names of the data to summate - in the case
	 *            of numbers, addition occurs, in the case of strings they are
	 *            concatenated with a "," delimiter
	 * @param bRoundOffDecimal
	 * @param iRoundOffDecimalToDigits
	 * @return A TableModel that contains the processed data
	 * @throws IllegalArgumentException
	 *             This will be thrown if there is no column with the name
	 *             passed as an argument or any other illogical argument.
	 */
	public TableModel createDataMatrix(TableModel theInTable,
			String thePivotField, String[] theFixedFields,
			String[] theSumFields, boolean bRoundOffDecimal,
			int iRoundOffDecimalToDigits) throws IllegalArgumentException {
		// Allocate the data matrix table
		//
		// indexes of the additional columns generated

		int iPivotColumnsStartIndex = 0;

		outTable = new DefaultTableModel();

		this.inTable = theInTable; // Set the data needed
		this.pivotField = thePivotField; // to make a pivot table
		this.fixedFields = ListUtil.getInstance().copyArray(theFixedFields);
		this.sumFields = ListUtil.getInstance().copyArray(theSumFields);

		inNameToIndex = createColumnIndexLookup(theInTable);

		// Make sure the arguments are okay. If not throw an exception.
		// See method for details on what exactly is checked
		checkForValidFields(); // 

		// If the user has not indicated which pivot values to generate the
		// table from, find all distinct pivot values, and use those
		findPivotValues(theInTable, thePivotField);

		// 2003-07-23 CLN: try to sort the pivotValues
		java.util.Arrays.sort(pivotValues);
		// end CLN
		// Create the table to store the data matrix, one column per field, per
		// value
		//

		// Add fixed field columns
		addFixedFieldColumns(theFixedFields);

		// Mark index following fixed fields
		iPivotColumnsStartIndex = outTable.getColumnCount();

		// Add summary field columns
		addSummaryFieldColumns();

		// Add pivot value columns
		addPivotValueColumns(theSumFields);

		outNameToIndex = createColumnIndexLookup(outTable);
		outRowNameToIndex = new HashMap<String, Integer>();

		// Now cycle through the data source, adding to the output table
		//
		for (int inRow = 0; inRow < theInTable.getRowCount(); inRow++) {
			// ------------------------------------------------------------ //
			// Step #1: Based on the fixed fields, determine which row //
			// of the output table the values from the input table belong //
			// to. If a row with that particular fixed field value //
			// combination does not exist, create one. //
			// ------------------------------------------------------------ //
			int outputRow = step1(theInTable, theFixedFields, inRow);

			// ----------------------------------------------------------------
			// //
			// Step #2: //
			// Add the independent summation fields together. This value is //
			// the total for a fixed field value combination, regardless of the
			// //
			// associated pivot value. //
			// ----------------------------------------------------------------
			// //
			step2(theInTable, inRow, outputRow);

			// ----------------------------------------------------------------
			// //
			// Step #3: Based on the fixed field information, the destination //
			// row is known. Now step through every column that is supposed //
			// to be summated and add them to the appropriate //
			// sum field/pivot value combination in the output table //
			// ----------------------------------------------------------------
			// //
			step3(theInTable, thePivotField, theSumFields, inRow, outputRow);
		}

		// ----------------------------------------------------------------- //
		// STEP #4: //
		// The table is complete. Check if the occurrences of null should be //
		// replaced with something else. If so, recurse the whole table and //
		// make the replacement. Also check the compareType value and //
		// remove rows as necessary. //
		// ----------------------------------------------------------------- //
		checkNullsAndCompareType();

		// Round off data if required
		roundData(bRoundOffDecimal, iRoundOffDecimalToDigits,
				iPivotColumnsStartIndex);

		return outTable;
	}

	private void findPivotValues(TableModel theInTable, String thePivotField) {
		if (pivotValues == null) {
			pivotValues = getDistinctValues(theInTable,
					inColIndex(thePivotField));

			// Trim the values to only those actually in the table, if the user
			// manually
			// set them.
			//
		} else {
			pivotValues = validPivotValues();
		}
	}

	private void addFixedFieldColumns(String[] theFixedFields) {
		for (int i = 0; i < theFixedFields.length; i++) {
			outTable.addColumn(theFixedFields[i]);
		}
	}

	private void addSummaryFieldColumns() {
		if (indSumFields != null) {
			for (int i = 0; i < indSumFields.length; i++) {
				outTable.addColumn(indSumFields[i]);
			}
		}
	}

	private void addPivotValueColumns(String[] theSumFields) {
		if (theSumFields != null) {
			for (int field = 0; field < theSumFields.length; field++) {
				for (int value = 0; value < pivotValues.length; value++) {
					if (!showSumFieldName) {
						outTable.addColumn(pivotValues[value]);
					} else {
						outTable.addColumn(theSumFields[field] + pfSeparator
								+ pivotValues[value]);
					}
				}
			}
		} else {
			for (int value = 0; value < pivotValues.length; value++) {
				outTable.addColumn(pivotValues[value]);
			}
		}
	}

	private void step3(TableModel theInTable, String thePivotField,
			String[] theSumFields, int inRow, int outputRow) {
		if (theSumFields != null) {
			for (int sum = 0; sum < theSumFields.length; sum++) {
				/* Get the column name of this sum/ pivot value combo */

				Object pivotVal = theInTable.getValueAt(inRow,
						inColIndex(thePivotField));

				boolean isValidPivotValue = false;
				for (int i = 0; i < pivotValues.length; i++) {
					if (pivotValues[i].equals(pivotVal))
						isValidPivotValue = true;
				}
				if (!isValidPivotValue) {
					continue;
				}

				int inCol = inColIndex(theSumFields[sum]);
				int outCol;
				if (!showSumFieldName) {
					outCol = outColIndex(pivotVal.toString());
				} else {
					outCol = outColIndex(theSumFields[sum] + pfSeparator
							+ pivotVal);
				}

				/*
				 * Get the two values that are being added and call the
				 * appropriate
				 */
				/*
				 * ObjectSummator interface, or set the data if the old value is
				 * null.
				 */

				Object oldValue = outTable.getValueAt(outputRow, outCol);
				Object addValue = theInTable.getValueAt(inRow, inCol);

				if (oldValue == null) {
					outTable.setValueAt(addValue, outputRow, outCol);
				} else {
					Object newValue = objSummator.summateObjects(
							theSumFields[sum], oldValue, addValue);
					outTable.setValueAt(newValue, outputRow, outCol);
				}

			}

			/*
			 * In the case that no sum fields exists, check if each fixed field
			 * combination
			 */
			/* contains or does not contain the pivot values */
		} else {
			for (int i = 0; i < pivotValues.length; i++) {
				Object pivotVal = theInTable.getValueAt(inRow,
						inColIndex(thePivotField));
				int outCol = outColIndex(pivotVal.toString());

				outTable.setValueAt(markedValue, outputRow, outCol);
			}
		}
	}

	private void step2(TableModel theInTable, int inRow, int outputRow) {
		if (indSumFields != null) {
			for (int isum = 0; isum < indSumFields.length; isum++) {
				int inCol = inColIndex(indSumFields[isum]);
				int outCol = outColIndex(indSumFields[isum]);

				/*
				 * Get the two values that are being added and call the
				 * appropriate
				 */
				/*
				 * ObjectSummator interface, or set the data if the old value is
				 * null.
				 */

				Object oldValue = outTable.getValueAt(outputRow, outCol);
				Object addValue = theInTable.getValueAt(inRow, inCol);

				if (oldValue == null) {
					outTable.setValueAt(addValue, outputRow, outCol);
				} else {
					Object newValue = objSummator.summateObjects(
							indSumFields[isum], oldValue, addValue);
					outTable.setValueAt(newValue, outputRow, outCol);
				}

			}
		}
	}

	private int step1(TableModel theInTable, String[] theFixedFields, int inRow) {
		Object values[] = new Object[theFixedFields.length];
		for (int field = 0; field < theFixedFields.length; field++) {
			int col = inColIndex(theFixedFields[field]);
			values[field] = theInTable.getValueAt(inRow, col);
		}

		int outputRow = getOutRowIndex(theFixedFields, values);
		if (outputRow == PWiConstants.UNDEFINED_INDEX) {
			outputRow = outTable.getRowCount();
			outTable.addRow(new Vector<Object>());

			// Set the field values so this row is identifiable
			//
			StringBuilder lookupId = new StringBuilder();
			for (int field = 0; field < theFixedFields.length; field++) {
				lookupId.append("|");
				lookupId.append(values[field]);
				outTable.setValueAt(values[field], outputRow, field);
			}

			outRowNameToIndex.put(lookupId.toString(), Integer
					.valueOf(outputRow));
		}
		return outputRow;
	}

	private void checkNullsAndCompareType() {
		if (nullReplacement != null || compareType != COMPARE_FULL) {

			for (int row = 0; row < outTable.getRowCount(); row++) {
				// Keep track if this row has missing elements.
				//
				boolean rowHasNull = false;

				for (int col = 0; col < outTable.getColumnCount(); col++) {
					if (outTable.getValueAt(row, col) == null) {
						outTable.setValueAt(nullReplacement, row, col);
						rowHasNull = true;
					}

				}

				// Now do any compare removals, changing the looping index
				// accordingly
				//
				switch (compareType) {
				case COMPARE_COMMON:
					if (rowHasNull) {
						outTable.removeRow(row);
						row--;
					}
					break;
				case COMPARE_DIFFERENCES:
					if (!rowHasNull) {
						outTable.removeRow(row);
						row--;
					}
					break;
				default:
					// do nothing
				}

			} // end for(row)
		}
	}

	private void roundData(boolean bRoundOffDecimal,
			int iRoundOffDecimalToDigits, int iPivotColumnsStartIndex) {
		for (int row = 0; row < outTable.getRowCount(); row++) {
			for (int col = 0; col < outTable.getColumnCount(); col++) {
				if (col >= iPivotColumnsStartIndex - 1
						&& outTable.getValueAt(row, col) != null) {
					String val = outTable.getValueAt(row, col).toString();
					if (bRoundOffDecimal
							&& QueryProcessingUtil.getInstance().isNumeric(val)) {
						String res = QueryProcessingUtil.getInstance()
								.roundOff(val, iRoundOffDecimalToDigits);
						LOGGER.debug("-------input--" + val + " ---output----"
								+ res);
						outTable.setValueAt(res, row, col);
					}
				}
			}
		}
	}

	// === O p t i o n M e t h o d s
	// ===============================================//

	/**
	 * Set the pivot values that should be used when generating the table. If
	 * invalid values are used, then all distinct values will be used. Such a
	 * replacement occurs in the valid data check method.
	 * 
	 * @param values
	 *            These are values to use. Note it is an object array, not a
	 *            string array. It is the user's responsibility to get the type
	 *            right.
	 */
	public void setPivotValues(Object[] values) {
		this.pivotValues = ListUtil.getInstance().copyArray(values);
	}

	/**
	 * Independent sum fields are fields that are totaled together for each
	 * fixed field value combination, regardless of the associated pivot value
	 * 
	 * @param localIndSumFields
	 */
	public void setIndependentSumFields(String[] localIndSumFields) {
		this.indSumFields = ListUtil.getInstance().copyArray(localIndSumFields);
	}

	/**
	 * Sets the compare type. See the individual variables for details.
	 * 
	 * @param compareType
	 *            The type of compare to use.
	 * @see #COMPARE_FULL
	 * @see #COMPARE_COMMON
	 * @see #COMPARE_DIFFERENCES
	 */
	public void setCompareType(int compareType) {
		if (compareType >= COMPARE_FULL && compareType <= COMPARE_DIFFERENCES)
			this.compareType = compareType;
	}

	/**
	 * Sets the output table separator String for column names. A default is
	 * provided.
	 * 
	 * @param separator
	 *            Any valid string will work, null will not.
	 */
	public void setColumnNameSeparator(String separator) {
		if (separator != null)
			pfSeparator = separator;
	}

	/**
	 * Sets the class to call when attempting to add two table values together.
	 * A default is provided.
	 * 
	 * @param localObjSummator
	 *            Calls the summateObjects() method of this interface every time
	 *            two objects need to be added. Can not equal null.
	 */
	public void setObjectSummator(ObjectSummator localObjSummator) {
		if (localObjSummator != null) {
			this.objSummator = localObjSummator;
		}
	}

	/**
	 * When the table is made, any columns that end up being null will be
	 * replaced by the Object set by this function
	 * 
	 * @param insteadOfNull
	 *            uses this object to replace any occurances of null in the
	 *            output table. Passing null will cause no replacement to occur.
	 */
	public void setNullReplacement(Object insteadOfNull) {
		nullReplacement = insteadOfNull;
	}

	/**
	 * Determines if the summary field name should be displayed with the fixed
	 * field value. Example: Items - Week #3 vs Week #3
	 * 
	 * @param showSumFieldName
	 */
	public void setShowSumFieldName(boolean showSumFieldName) {
		this.showSumFieldName = showSumFieldName;
	}

	/**
	 * Used when no summary fields are indicated. In the mode, each fixed field
	 * is "checked off" or marked as either containing or not containing the
	 * individual pivot values. The value of this variable is the "check" for
	 * example "X" could be used or Boolean(true).
	 * 
	 * @param markedValue
	 *            Can be anything other than null. (null would cause
	 *            unpredictable behavior since the "unchecked" marker is null ).
	 */
	public void setMarkedValue(Object markedValue) {
		this.markedValue = markedValue;
	}

	// === U t i l i t y M e t h o d s
	// =============================================//

	/**
	 * This is the default implementation of the ObjectSummator class. This
	 * class is used to define how two Objects are added. In this default
	 * implementation, if they are numbers, sum as Integer or Double,
	 * depending if either has decimal points, of the added value is returned.
	 * Otherwise a String addition is used. The string addition is of Strings
	 * addes only unique Strings, delimiting them with a "|". Some formating
	 * will probably be necessary after the table is returned to replace the "|"
	 * with a more appropriate delimiter. If the objects are not Strings or
	 * Numbers, then the objects are summed using toString() and delimiting them
	 * with the "|". However, uniqueness is not checked for as it is with the
	 * String objects.
	 * 
	 * A custom version can be used instead of this default by using
	 * setObjectSummator().
	 * 
	 * @param columnName
	 *            This is the column name under which new object is located
	 * @param oldValue
	 *            The old value
	 * @param newValue
	 *            The value being overlayed on a
	 * @return The summation of the two objects
	 * 
	 */
	public Object summateObjects(String columnName, Object oldValue,
			Object newValue) {
		Object result = null;
		if (oldValue instanceof Number && newValue instanceof Number) {
			// if the Objects are both Numbers, return the arithmetic sum
			if (oldValue instanceof Integer && newValue instanceof Integer) {
				int total = ((Integer) oldValue).intValue()
						+ ((Integer) newValue).intValue();
				result = Integer.valueOf(total);
			} else {
				double total = ((Number) oldValue).doubleValue()
						+ ((Number) newValue).doubleValue();
				result = Double.valueOf(total);
			}
		} else if (oldValue instanceof String && newValue instanceof String) {
			// if the Objects are both Strings, perform some checks
			if (oldValue.equals(newValue)) {
				return oldValue; // added by C. New, July 18, 2003
			}

			// Check if newValue already exists as a list item in oldValue
			boolean unique = true;
			for (String token : ((String) oldValue).split("\\|",
					PWiConstants.SPLIT_GREEDILY_AND_INCLUDE_EMPTY)) {
				if (newValue.equals(token)) {
					unique = false;
				}
			}

			result = oldValue;
			if (unique) {
				result = new StringBuffer().append(oldValue)
						.append("|").append(newValue).toString();
			}
		} else {
			result = new StringBuffer().append(oldValue)
					.append("|").append(newValue).toString();
		}
		return result;
	}

	/**
	 * Utility function to avoid confusing casting by directly using the
	 * hashtable look-ups
	 */
	protected int inColIndex(String name) throws IllegalArgumentException {
		if (!inNameToIndex.containsKey(name))
			throw new IllegalArgumentException(
					"inColIndex: Source table does not have a column: " + name
							+ ".");

		return inNameToIndex.get(name).intValue();
	}

	/**
	 * Utility function to avoid confusing casting by directly using the
	 * hashtable look-ups
	 */
	protected int outColIndex(String name) throws IllegalArgumentException {
		if (!outNameToIndex.containsKey(name))
			throw new IllegalArgumentException(
					"outColIndex: Output table does not have a column: " + name
							+ ".");

		return ((Integer) outNameToIndex.get(name)).intValue();
	}

	/**
	 * Checks all the preliminary data that is needed to create a pivot table.
	 * Things such as the output look-up must be checked later as they are
	 * created.
	 * 
	 * @return false if the arguments are not valid for creating a pivot table -
	 *         otherwise true
	 * @throws IllegalArgumentException
	 *             On invalid data, an exception describing the error is thrown.
	 */
	protected boolean checkForValidFields() throws IllegalArgumentException {

		// Valid source?
		if (inTable == null) {
			throw new IllegalArgumentException(
					"TableModel passed as source is null");
		}

		if (inNameToIndex == null) {
			throw new IllegalArgumentException(
					"Failed to create source column look-up table.");
		}

		// Valid pivot field?
		if (!inNameToIndex.containsKey(pivotField)) {
			throw new IllegalArgumentException("Can't find pivot field: "
					+ pivotField + " in source table.");
		}

		// Valid fixed fields?
		for (int field = 0; field < fixedFields.length; field++) {
			if (!inNameToIndex.containsKey(fixedFields[field])) {
				throw new IllegalArgumentException("Can't find fixed field: "
						+ fixedFields[field] + " in source table.");
			}
		}

		// Valid summation fields?
		if (sumFields != null)
			for (int field = 0; field < sumFields.length; field++) {
				if (!inNameToIndex.containsKey(sumFields[field])) {
					throw new IllegalArgumentException(
							"Can't find summation field: " + sumFields[field]
									+ " in source table.");
				}
			}

		// Valid independent summation fields?
		if (indSumFields != null)
			for (int field = 0; field < indSumFields.length; field++) {
				if (!inNameToIndex.containsKey(indSumFields[field])) {
					throw new IllegalArgumentException(
							"Can't find independent summation field: "
									+ indSumFields[field] + " in source table.");
				}
			}

		// Valid pivotValues? (null is ok...it means generate it later)
		// Make sure at least one of the indicated values exists or throw an
		// exception
		if (pivotValues != null) {
			Object[] allValues = getDistinctValues(inTable,
					inColIndex(pivotField));

			boolean oneExists = false;
			for (int i = 0; i < pivotValues.length; i++) {
				for (int n = 0; n < allValues.length; n++)
					if (pivotValues[i].equals(allValues[n]))
						oneExists = true;
			}

			if (!oneExists)
				throw new IllegalArgumentException(
						"Invalid pivot field values, none exist: "
								+ Arrays.toString(pivotValues));
		}

		return true;
	}

	/**
	 * Creates a new array of pivot values by removing indicated values that are
	 * not in this table.
	 * 
	 * @return Returns the intersection of the pivot values in the table and the
	 *         pivot values selected to display.
	 */
	protected Object[] validPivotValues() {
		if (pivotValues == null)
			return new Object[0];

		Object[] allValues = getDistinctValues(inTable, inColIndex(pivotField));
		List<Object> vector = new Vector<Object>();

		for (int i = 0; i < pivotValues.length; i++) {
			for (int n = 0; n < allValues.length; n++) {
				if (pivotValues[i].equals(allValues[n]))
					if (!vector.contains(pivotValues[i]))
						vector.add(pivotValues[i]);
			}
		}

		Object[] valid = new Object[vector.size()];
		for (int i = 0; i < valid.length; i++) {
			valid[i] = vector.get(i);
		}
		return valid;
	}

	/**
	 * Creates a hashtable where the key is the String name of the column and
	 * the Value is an Integer equal to the column's index. Note: a TableModel
	 * with two column's with the same name will cause unpredictable behavior.
	 * 
	 * @param table
	 *            The table from which to build the look-up hashtable
	 * @return See above for details on how to use the look-up.
	 */
	protected static Map<String, Integer> createColumnIndexLookup(
			TableModel table) {
		if (table == null)
			return null;

		Map<String, Integer> lookupIndex = new HashMap<String, Integer>();

		for (int i = 0; i < table.getColumnCount(); i++)
			lookupIndex.put(table.getColumnName(i), Integer.valueOf(i));

		return lookupIndex;
	}

	/**
	 * This is an internal method that using the row look-up table
	 * 
	 * @param columnNames
	 *            the names of the columns that must have the <i>values</i>
	 * @param values
	 *            the values in the corresponding columns
	 * @return the index - should never fail since the data is verified prior to
	 *         any call, but PWiConstants.UNDEFINED_INDEX if it somehow fails.
	 */
	protected final int getOutRowIndex(String columnNames[], Object values[]) {
		StringBuilder lookupId = new StringBuilder();
		for (int i = 0; i < values.length; i++) {
			lookupId.append("|");
			lookupId.append(values[i]);
		}
		Integer index = (Integer) outRowNameToIndex.get(lookupId.toString());
		if (index != null)
			return index.intValue();

		return PWiConstants.UNDEFINED_INDEX;
	}

	/**
	 * This is a utility function that finds all the distinct values in a Table
	 * under a certain column.
	 * 
	 * @param table
	 *            The source table to analyze
	 * @param column
	 *            The column of the table to recurse
	 * @return An array of all distinct objects
	 */
	protected static Object[] getDistinctValues(TableModel table, int column) {
		List<Object> vector = new Vector<Object>();

		// Put all distinct values in a temporary vector
		// that will be converted to an array
		//
		for (int i = 0; i < table.getRowCount(); i++) {
			Object cellValue = table.getValueAt(i, column);
			if (!vector.contains(cellValue))
				vector.add(cellValue);
		}

		return vector.toArray();
	}

	/**
	 * This is a utility function that finds all the distinct values in an array
	 * of Objects
	 * 
	 * @param array
	 *            The array to pick the distinct values out of
	 * @return An array of all distinct objects
	 */
	protected static Object[] getDistinctValues(Object[] array) {
		List<Object> vector = new ArrayList<Object>();

		// Put all distinct values in a temporary vector
		// that will be converted to an array
		//
		for (int i = 0; i < array.length; i++) {
			if (!vector.contains(array[i]))
				vector.add(array[i]);
		}

		return vector.toArray();
	}

}
