/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMTC5MliRptData.java
 * @Creation date: 27-April-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMTC5MliRptData {
	/**
	 * Holds the enteredSNProjIPSTC5
	 */
	private String enteredSNProjIPSTC5;
	/**
	 * Holds the enteredConDesc
	 */
	private String enteredConDesc;
	/**
	 * Holds the enteredMLI
	 */
	private String enteredMLI;
	/**
	 * Holds the enteredRadioValue
	 */
	private String enteredRadioValue;
	
	
	
	/**
	 * Holds the opMLI
	 */
	private String opMLI;
	/**
	 * Holds the opObjName
	 */
	private String opObjName;
	/**
	 * Holds the opObjEnvId
	 */
	private String opObjEnvId;
	/**
	 * Holds the opObjCss
	 */
	private String opObjCss;
	/**
	 * Holds the opObjRev
	 */
	private String opObjRev;
	/**
	 * Holds the opFRDesc
	 */
	private String opFRDesc;
	/**
	 * Holds the opENDesc
	 */
	private String opENDesc;
	/**
	 * Holds the opQty
	 */
	private String opQty;
	/**
	 * Holds the opUomDocType
	 */
	private String opUomDocType;
	/**
	 * Holds the opSect
	 */
	private String opSect;
	/**
	 * Holds the opItemName
	 */
	private String opItemName;
	/**
	 * Holds the opItemEnvId
	 */
	private String opItemEnvId;
	/**
	 * Holds the opItemCss
	 */
	private String opItemCss;
	/**
	 * Holds the opItemRev
	 */
	private String opItemRev;
	/**
	 * Holds the opSN
	 */
	private String opSN;
	/**
	 * Holds the opTmTot
	 */
	private String opTmTot;
	/**
	 * Holds the opTmTotEnvId
	 */
	private String opTmTotEnvId;
	/**
	 * Holds the opTmTotCss
	 */
	private String opTmTotCss;
	/**
	 * Holds the opProject
	 */
	private String opProject;
	/**
	 * Holds the opContract
	 */
	private String opContract;
	/**
	 * Holds the opConDesc
	 */
	private String opConDesc;
	
	
	
	
	/**
	 * @return the enteredSNProjIPSTC5
	 */
	public String getEnteredSNProjIPSTC5() {
		return enteredSNProjIPSTC5;
	}
	/**
	 * @param enteredSNProjIPSTC5 the enteredSNProjIPSTC5 to set
	 */
	public void setEnteredSNProjIPSTC5(String enteredSNProjIPSTC5) {
		this.enteredSNProjIPSTC5 = enteredSNProjIPSTC5;
	}
	/**
	 * @return the enteredConDesc
	 */
	public String getEnteredConDesc() {
		return enteredConDesc;
	}
	/**
	 * @param enteredConDesc the enteredConDesc to set
	 */
	public void setEnteredConDesc(String enteredConDesc) {
		this.enteredConDesc = enteredConDesc;
	}
	/**
	 * @return the enteredMLI
	 */
	public String getEnteredMLI() {
		return enteredMLI;
	}
	/**
	 * @param enteredMLI the enteredMLI to set
	 */
	public void setEnteredMLI(String enteredMLI) {
		this.enteredMLI = enteredMLI;
	}
	/**
	 * @return the enteredRadioValue
	 */
	public String getEnteredRadioValue() {
		return enteredRadioValue;
	}
	/**
	 * @param enteredRadioValue the enteredRadioValue to set
	 */
	public void setEnteredRadioValue(String enteredRadioValue) {
		this.enteredRadioValue = enteredRadioValue;
	}
	/**
	 * @return the opMLI
	 */
	public String getOpMLI() {
		return opMLI;
	}
	/**
	 * @param opMLI the opMLI to set
	 */
	public void setOpMLI(String opMLI) {
		this.opMLI = opMLI;
	}
	/**
	 * @return the opObjName
	 */
	public String getOpObjName() {
		return opObjName;
	}
	/**
	 * @param opObjName the opObjName to set
	 */
	public void setOpObjName(String opObjName) {
		this.opObjName = opObjName;
	}
	/**
	 * @return the opObjRev
	 */
	public String getOpObjRev() {
		return opObjRev;
	}
	/**
	 * @param opObjRev the opObjRev to set
	 */
	public void setOpObjRev(String opObjRev) {
		this.opObjRev = opObjRev;
	}
	/**
	 * @return the opFRDesc
	 */
	public String getOpFRDesc() {
		return opFRDesc;
	}
	/**
	 * @param opFRDesc the opFRDesc to set
	 */
	public void setOpFRDesc(String opFRDesc) {
		this.opFRDesc = opFRDesc;
	}
	/**
	 * @return the opENDesc
	 */
	public String getOpENDesc() {
		return opENDesc;
	}
	/**
	 * @param opENDesc the opENDesc to set
	 */
	public void setOpENDesc(String opENDesc) {
		this.opENDesc = opENDesc;
	}
	/**
	 * @return the opQty
	 */
	public String getOpQty() {
		return opQty;
	}
	/**
	 * @param opQty the opQty to set
	 */
	public void setOpQty(String opQty) {
		this.opQty = opQty;
	}
	/**
	 * @return the opUomDocType
	 */
	public String getOpUomDocType() {
		return opUomDocType;
	}
	/**
	 * @param opUomDocType the opUomDocType to set
	 */
	public void setOpUomDocType(String opUomDocType) {
		this.opUomDocType = opUomDocType;
	}
	/**
	 * @return the opSect
	 */
	public String getOpSect() {
		return opSect;
	}
	/**
	 * @param opSect the opSect to set
	 */
	public void setOpSect(String opSect) {
		this.opSect = opSect;
	}
	/**
	 * @return the opItemName
	 */
	public String getOpItemName() {
		return opItemName;
	}
	/**
	 * @param opItemName the opItemName to set
	 */
	public void setOpItemName(String opItemName) {
		this.opItemName = opItemName;
	}
	/**
	 * @return the opItemRev
	 */
	public String getOpItemRev() {
		return opItemRev;
	}
	/**
	 * @param opItemRev the opItemRev to set
	 */
	public void setOpItemRev(String opItemRev) {
		this.opItemRev = opItemRev;
	}
	/**
	 * @return the opSN
	 */
	public String getOpSN() {
		return opSN;
	}
	/**
	 * @param opSN the opSN to set
	 */
	public void setOpSN(String opSN) {
		this.opSN = opSN;
	}
	/**
	 * @return the opTmTot
	 */
	public String getOpTmTot() {
		return opTmTot;
	}
	/**
	 * @param opTmTot the opTmTot to set
	 */
	public void setOpTmTot(String opTmTot) {
		this.opTmTot = opTmTot;
	}
	/**
	 * @return the opProject
	 */
	public String getOpProject() {
		return opProject;
	}
	/**
	 * @param opProject the opProject to set
	 */
	public void setOpProject(String opProject) {
		this.opProject = opProject;
	}
	/**
	 * @return the opContract
	 */
	public String getOpContract() {
		return opContract;
	}
	/**
	 * @param opContract the opContract to set
	 */
	public void setOpContract(String opContract) {
		this.opContract = opContract;
	}
	/**
	 * @return the opConDesc
	 */
	public String getOpConDesc() {
		return opConDesc;
	}
	/**
	 * @param opConDesc the opConDesc to set
	 */
	public void setOpConDesc(String opConDesc) {
		this.opConDesc = opConDesc;
	}
	/**
	 * @return the opObjEnvId
	 */
	public String getOpObjEnvId() {
		return opObjEnvId;
	}
	/**
	 * @param opObjEnvId the opObjEnvId to set
	 */
	public void setOpObjEnvId(String opObjEnvId) {
		this.opObjEnvId = opObjEnvId;
	}
	/**
	 * @return the opObjCss
	 */
	public String getOpObjCss() {
		return opObjCss;
	}
	/**
	 * @param opObjCss the opObjCss to set
	 */
	public void setOpObjCss(String opObjCss) {
		this.opObjCss = opObjCss;
	}
	/**
	 * @return the opItemEnvId
	 */
	public String getOpItemEnvId() {
		return opItemEnvId;
	}
	/**
	 * @param opItemEnvId the opItemEnvId to set
	 */
	public void setOpItemEnvId(String opItemEnvId) {
		this.opItemEnvId = opItemEnvId;
	}
	/**
	 * @return the opItemCss
	 */
	public String getOpItemCss() {
		return opItemCss;
	}
	/**
	 * @param opItemCss the opItemCss to set
	 */
	public void setOpItemCss(String opItemCss) {
		this.opItemCss = opItemCss;
	}
	/**
	 * @return the opTmTotEnvId
	 */
	public String getOpTmTotEnvId() {
		return opTmTotEnvId;
	}
	/**
	 * @param opTmTotEnvId the opTmTotEnvId to set
	 */
	public void setOpTmTotEnvId(String opTmTotEnvId) {
		this.opTmTotEnvId = opTmTotEnvId;
	}
	/**
	 * @return the opTmTotCss
	 */
	public String getOpTmTotCss() {
		return opTmTotCss;
	}
	/**
	 * @param opTmTotCss the opTmTotCss to set
	 */
	public void setOpTmTotCss(String opTmTotCss) {
		this.opTmTotCss = opTmTotCss;
	}
	
	
	
	
}
