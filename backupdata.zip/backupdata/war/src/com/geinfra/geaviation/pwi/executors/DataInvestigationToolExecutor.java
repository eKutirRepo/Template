/**
 * Module:       DataInvestigationTool.java
 * Author:       Cecil L. New
 * Project:      Tool to analyze part usage history
 * Date Written: May, 2011
 * Security:     Unclassified
 * Restrictions: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 *     ****************************************************
 *     *  Copyright (2012) with all rights reserved       *
 *     *          General Electric Company                *
 *     ****************************************************
 *
 * Description:  This class allows a specification, drawing,
 * or part to be researched by analyzing its usage history.
 *
 * Revision Log  (mm/dd/yy initials description)
 * 2011-05-06 CLN: Initial creation.
 * 2012.12.18 pH : replaced GEAEResultSet with PWiResultSet
 * --------------------------------------------------------------
 */

package com.geinfra.geaviation.pwi.executors;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.PWiQueryTimeoutException;
import com.geinfra.geaviation.pwi.common.PWiResultSizeLimitExceededException;
import com.geinfra.geaviation.pwi.model.PWiResultSet;
import com.geinfra.geaviation.pwi.model.PWiResultSetColMetaData;
import com.geinfra.geaviation.pwi.util.QueryProcessingUtil;
import com.geinfra.geaviation.pwi.xml.query.ColumnType;
import com.geinfra.geaviation.pwi.xml.query.DataInvestigationToolExecutorXml;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.query.util.InputEditRulesUtil;
import com.geinfra.geaviation.pwi.xml.query.util.QueryJaxbUtil;
import com.geinfra.geaviation.pwi.xml.query.util.QueryJaxbUtil.InputEditRule;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.search.util.SearchJaxbUtil;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;

/**
 * Project      : Product Lifecycle Management
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 * Copyright(C) 2012 GE All rights reserved
 *
 * @version 1.0
 * @author Cecil New
 */
public class DataInvestigationToolExecutor implements Executor {
	private static final String NO_USAGE = "NO USAGE";
	// The Data Investigation Tool (Part Where Used with History) returns 11
	// initial columns, plus GROUP_SIZE columns for each level of recursion:
	// MnRev, MxRev, LatestRev, IntroCID, IntroDte, RemoCID, RemoDte, Assembly.
	// So MAX_ROW_SIZE = 11 + GROUP_SIZE * MAX_DEPTH
	private static final int GROUP_SIZE = 8;
	private static final int MAX_DEPTH = 11;
	private static final int MAX_ROW_SIZE = 99; // 11 + 8*11
	// pH 2013.02: successful executions returned the this many results:
	//   Median:            148
	//   90th Percentile:  6020
	//   95th Percentile: 16222
	//   Maximum:        398104
	// The implementation of List we use (ArrayList) will increase capacity by
	// 50% if overflow occurs, so over 95% of all queries will never hit this
	// limit, and the largest query on record so far was enlarged and copied
	// 8 times.  We currently require this query be run in batch mode, as it
	// would time out in online mode over 60% of the time.
	private static final int ENSURE_TABLE_SIZE = 20480;


	// Helper stacks for recursive processing
	// Assumes depth of product structure does not exceed 15
	private String[] earliestDate = new String[MAX_DEPTH];
	private String[] earliestCID = new String[MAX_DEPTH];
	private String[] latestDate = new String[MAX_DEPTH];
	private String[] latestCID = new String[MAX_DEPTH];
	private String[] historyInd = new String[MAX_DEPTH];

	private int queryTimeoutSecs;
	private int resultSizeLimit;

	// SQL and data sources
	private String getPartsDsn;
	private String getPartsSql;
	private String addNhaDsn;
	private String addNhaSql;
	private String getTopPartsDsn;
	private String getTopPartsSql;
	private String addModelDsn;
	private String addModelSql;

	public DataInvestigationToolExecutor(int queryTimeoutSecs,
			int resultSizeLimit, DataInvestigationToolExecutorXml executorXml) {
		this.queryTimeoutSecs = queryTimeoutSecs;
		this.resultSizeLimit = resultSizeLimit;

		getPartsDsn = executorXml.getGetPartsSql().getDsn();
		getPartsSql = executorXml.getGetPartsSql().getValue();

		getTopPartsDsn = executorXml.getHwpToTopPartsSql().getDsn();
		getTopPartsSql = executorXml.getHwpToTopPartsSql().getValue();

		addNhaDsn = executorXml.getAddNhaSql().getDsn();
		addNhaSql = executorXml.getAddNhaSql().getValue();

		addModelDsn = executorXml.getAddModelSql().getDsn();
		addModelSql = executorXml.getAddModelSql().getValue();
	}

	public PWiResultSet execute(QueryType queryType, Search search,
			SelectedColumns selectedColumns, String sso, String[] columns,
			List<Object[]> rows) throws PWiException,
			PWiResultSizeLimitExceededException, PWiQueryTimeoutException {
		// Get input list from search
		List<String> inputList = getInputList(search, queryType);

		// Run query
		ArrayList<ArrayList<String>> table = run(inputList);

		// Convert table to PWiResultSet
		PWiResultSet resultSet = tableToPWiResultSet(table, queryType);

		return resultSet;
	}

	private List<String> getInputList(Search search, QueryType queryType)
			throws PWiException {
		List<String> inputList = null;
		Search.Item item = search.getItem().get(0);
		if (SearchJaxbUtil.isEqualsOp(item)) {
			inputList = new ArrayList<String>();
			inputList.add(item.getValue());
		} else if (SearchJaxbUtil.isListOp(item)) {
			// Parse multiple values from user
			inputList = SearchJaxbUtil.parseListFromUser(item.getValue());
		} else {
			throw new PWiException(
					"Unsupported operator for data investigation tool.");
		}

		ColumnType columnType = QueryJaxbUtil.getInstance().getColumnForId(
				queryType, item.getColumnref().getRef());

		// Prepare search values for querying (trim and apply input edit rules
		// etc.)
		List<String> result = new ArrayList<String>();
		for (String value : inputList) {
			String newValue = prepareSearchValue(columnType, value);
			result.add(newValue);
		}

		return result;
	}

	private PWiResultSet tableToPWiResultSet(ArrayList<ArrayList<String>> table,
			QueryType queryType) {
		PWiResultSet resultSet = new PWiResultSet();

		// Note: Index starts at one to skip first column which is the search
		// column. Also, meta data columns happens to use one-based indexing, so
		// it works out that there's no need to convert from zero-based
		// indexing.
		HashMap<String, Integer> ht1 = new HashMap<String, Integer>();
		HashMap<Integer, PWiResultSetColMetaData> ht2 =
				new HashMap<Integer, PWiResultSetColMetaData>();
		List<ColumnType> columns = queryType.getQuerydefinition()
				.getColumnlist().getColumn();
		for (int index = 1; index < columns.size(); index++) {
			ColumnType column = columns.get(index);

			PWiResultSetColMetaData geaersmd = new PWiResultSetColMetaData();
			geaersmd.colindex = index;
			geaersmd.colname = column.getId().toUpperCase(Locale.US);
			geaersmd.coltype = Types.VARCHAR;
			geaersmd.colheading = column.getDisplayname();

			ht2.put(Integer.valueOf(index), geaersmd);
			ht1.put(geaersmd.colname, Integer.valueOf(index));
		}

		resultSet.setData(table, ht1, ht2);

		return resultSet;
	}

	public String getExecutedQuery() {
		return "Getting query string is not supported for data investigation tool queries";
	}

	private ArrayList<ArrayList<String>> run(List<String> parts)
			throws PWiResultSizeLimitExceededException, PWiException,
			PWiQueryTimeoutException {
		List<InputStackElement> inputStack = getParts(parts);
		List<PartStackElement> partStack = processInputStack(inputStack);
		partStack = processPartStack(partStack);
		List<ModelStackElement> modelStack = processModelStack(partStack);
		ArrayList<ArrayList<String>> table = asTable(inputStack, partStack,
				modelStack);

		return table;
	}

	private List<InputStackElement> getParts(List<String> inputList)
			throws PWiResultSizeLimitExceededException, PWiException,
			PWiQueryTimeoutException {
		List<InputStackElement> inputStack = new ArrayList<InputStackElement>();

		// Load all the initial input
		for (String inputItem : inputList) {
			List<Object> parameterValues = new ArrayList<Object>();
			parameterValues.add(inputItem);
			parameterValues.add(inputItem);

			PWiResultSet rs = QueryProcessingUtil.getInstance().executeQuery(
					getPartsDsn, getPartsSql, parameterValues, null,
					queryTimeoutSecs, resultSizeLimit);

			try {
				while (rs.next()) {
					InputStackElement ise = new InputStackElement();
					ise.inputval = rs.getString(1);
					ise.inputdraw = rs.getString(2);
					ise.inputpart = rs.getString(3);
					inputStack.add(ise);
				}
			} catch (IndexOutOfBoundsException e) {
				throw new PWiException(e, "Failed to get parts for item: "
						+ inputItem);
			}
		}

		return inputStack;
	}

	private ArrayList<ArrayList<String>> asTable(List<InputStackElement> inputStack,
			List<PartStackElement> partStack, List<ModelStackElement> modelStack) throws PWiException {
		// This query can return a lot of results, so ensure the initial table is BIG
		ArrayList<ArrayList<String>> table = new ArrayList<ArrayList<String>>(ENSURE_TABLE_SIZE);

		for (int i = 0; i < inputStack.size(); i++) {
			InputStackElement ise = inputStack.get(i);
			// depth first recursion
			List<String> row = new ArrayList<String>(MAX_ROW_SIZE);
			row.add(ise.inputval);
			row.add(ise.inputdraw);
			row.add(ise.inputpart);
			table = recurse(table, ise.inputpart, row, partStack, modelStack, 0);
		}

		// Ensure each row has length of 99 (Cecil skipped this step)
		String emptyString = "";
		for (List<String> row : table) {
			// Add empty items necessary to reach size of 99
			int numItemsToAdd = MAX_ROW_SIZE - row.size();
			while (numItemsToAdd > 0) {
				row.add(emptyString);
				numItemsToAdd--;
			}
		}

		return table;
	}

	private ArrayList<ArrayList<String>> recurse(ArrayList<ArrayList<String>> table,
			String part, List<String> row, List<PartStackElement> partStack,
			List<ModelStackElement> modelStack, int depth) throws PWiException {

		// do direct model connections for parts
		// just one time
		boolean directPartModel = false;

		for (int i = 0; i < partStack.size(); i++) {
			PartStackElement pse = partStack.get(i);
			if (pse.part.equals(part)) {
				if (pse.part.equals(pse.assembly)) {
					throw new PWiException(
							"Found a part that lists itself as its assembly! Bad data?  part: "
									+ pse.part);
				}

				if (pse.assembly.equals(NO_USAGE)) {

					// No usage for part, so just add any model info existing
					// for it
					addModelInfos(table, part, row, modelStack, depth);
				} else {
					/*
					 * Even if a part has a next higher, it may still be
					 * associated to a model (typically an M10 engine list); so
					 * try this first, before continuing to recurse
					 */
					boolean rowsAdded = false;
					if (!directPartModel) {
						rowsAdded = addModelInfos(table, part, row, modelStack,
								depth);
					}

					if (rowsAdded) {
						directPartModel = true;
					}

					//
					// now recurse
					//
					row.add(pse.minRev);
					row.add(pse.maxRev);
					row.add(pse.latestRev);
					row.add(pse.introECO);
					row.add(pse.introDate);
					row.add(pse.removeECO);
					row.add(pse.removeDate);
					row.add(pse.assembly);

					// prepare next level depth information
					if (pse.isHistory())
						historyInd[depth] = "HI";
					earliestDate[depth] = pse.introDate;
					earliestCID[depth] = pse.introECO;
					latestDate[depth] = pse.removeDate;
					latestCID[depth] = pse.removeECO;
					recurse(table, pse.assembly, row, partStack, modelStack,
							depth + 1);
					earliestDate[depth] = "";
					earliestCID[depth] = "";
					latestDate[depth] = "";
					latestCID[depth] = "";
					historyInd[depth] = "";

					// remove last 8 from row since they're done
					if (row.size() > GROUP_SIZE) {
						for (int x = 0; x < GROUP_SIZE; x++) {
							row.remove(row.size() - 1);
						}
					}
				}
			}
		}
		return table;
	}

	private boolean addModelInfos(List<ArrayList<String>> table, String part,
			List<String> row, List<ModelStackElement> modelStack, int depth) {
		int rowsAdded = 0;
		for (int m = 0; m < modelStack.size(); m++) {
			ModelStackElement mse = modelStack.get(m);
			if (mse.part.equals(part)) {
				table.add(getModelInfo(part, row, depth, mse));
				rowsAdded++;
			}
		}

		return rowsAdded > 0;
	}

	private ArrayList<String> getModelInfo(String part, List<String> row, int depth,
			ModelStackElement mse) {
		ArrayList<String> modelinfo = new ArrayList<String>(5 + row.size());

		// first four columns will be:
		// 1) model
		// 2) business segment of model
		// 3) earliest intro date on row
		// 4) "HI" if any level is not current; "IS"
		// otherwise

		modelinfo.add(mse.model);
		modelinfo.add(mse.busseg);
		modelinfo.add(part); // end item connected to part

		// earliest intro date on path
		String[] earliest = getEarliestIntroDate(depth);
		modelinfo.add(earliest[0]);
		modelinfo.add(earliest[1]);

		// latest cutoff date on path
		String[] latest = getLatestCutoffDate(depth);
		modelinfo.add(latest[0]);
		modelinfo.add(latest[1]);

		modelinfo.add(getHistoryIndicator(depth));

		modelinfo.addAll(row);

		return modelinfo;
	}

	private String[] getEarliestIntroDate(int depth) {
		// earliest intro date found for this path/row
		// The earliest intro date for a path is the
		// *latest intro date* above in it along the path
		String latestIntro = "0000-00-00"; // fake low date
		String latestCidSoFar = "";
		for (int eid = 0; eid < depth; eid++) {
			if (latestIntro.compareTo(earliestDate[eid]) < 0) {
				latestIntro = earliestDate[eid];
				latestCidSoFar = earliestCID[eid];
			}
		}
		if ("0000-00-00".equals(latestIntro)) {
			latestIntro = "#NOCIDS#";
		}
		// return latestIntro;
		String[] rc = new String[2];
		rc[0] = latestIntro;
		rc[1] = latestCidSoFar;
		return rc;
	}

	private String[] getLatestCutoffDate(int depth) {
		// latest cutoff date found for this path/row
		// The latest cutoff date for a path is the
		// *earliest cutoff date* above in it along the path
		String earliestCutoff = "9999-99-99"; // fake high date
		String earliestCidSoFar = "";
		for (int lcd = 0; lcd < depth; lcd++) {
			if ("CURR".equals(latestCID[lcd]))
				continue;
			if (earliestCutoff.compareTo(latestDate[lcd]) > 0) {
				earliestCutoff = latestDate[lcd];
				earliestCidSoFar = latestCID[lcd];
			}
		}
		if ("9999-99-99".equals(earliestCutoff)) {
			earliestCutoff = "#CURR#";
		}
		// return earlist cutoff;
		String[] rc = new String[2];
		rc[0] = earliestCutoff;
		rc[1] = earliestCidSoFar;
		return rc;
	}

	private String getHistoryIndicator(int depth) {
		// add history indicator if any component is no longer current
		String hiSet = "";
		for (int hsub = 0; hsub < depth; hsub++) {
			if ("HI".equals(historyInd[hsub])) {
				hiSet = "HI";
				break; // no need to search further
			}
		}
		if ("".equals(hiSet))
			hiSet = "IS";
		return hiSet;
	}

	private List<PartStackElement> processInputStack(
			List<InputStackElement> inputStack) throws PWiException,
			PWiResultSizeLimitExceededException, PWiQueryTimeoutException {
		List<PartStackElement> partStack = new ArrayList<PartStackElement>();

		// this loop walks up the part structure
		for (int i = 0; i < inputStack.size(); i++) {
			InputStackElement ise = inputStack.get(i);

			List<Object> parameterValues = new ArrayList<Object>();
			parameterValues.add(ise.inputpart);
			parameterValues.add(ise.inputpart);
			parameterValues.add(ise.inputpart);

			PWiResultSet rs = QueryProcessingUtil.getInstance().executeQuery(
					addNhaDsn, addNhaSql, parameterValues, null,
					queryTimeoutSecs, resultSizeLimit);

			try {
				while (rs.next()) {
					PartStackElement newpse = new PartStackElement();

					newpse.part = ise.inputpart;
					newpse.minRev = rs.getString(1);
					newpse.maxRev = rs.getString(2);
					newpse.latestRev = rs.getString(3);
					newpse.introECO = rs.getString(4);
					newpse.introDate = rs.getString(5);
					newpse.removeECO = rs.getString(6);
					newpse.removeDate = rs.getString(7);
					newpse.assembly = rs.getString(8);

					partStack.add(newpse);
				}
			} catch (IndexOutOfBoundsException e) {
				throw new PWiException(e,
						"Failed to process input stack for item index " + i);
			}
		}

		return partStack;
	}

	private List<PartStackElement> processPartStack(
			List<PartStackElement> partStack)
			throws PWiResultSizeLimitExceededException, PWiException,
			PWiQueryTimeoutException {
		List<String> visitedStack = new ArrayList<String>();

		// this loop walks up the part structure
		while (true) {
			int processcount = 0;
			for (int i = 0; i < partStack.size(); i++) {
				PartStackElement pse = partStack.get(i);
				if (pse.assembly.equals(NO_USAGE)) {
					continue;
				}

				if (visitedStack.contains(pse.assembly)) {
					continue;
				}

				visitedStack.add(pse.assembly);
				processcount++;

				List<Object> parameterValues = new ArrayList<Object>();
				parameterValues.add(pse.assembly);
				parameterValues.add(pse.assembly);
				parameterValues.add(pse.assembly);

				PWiResultSet rs = QueryProcessingUtil.getInstance()
						.executeQuery(addNhaDsn, addNhaSql, parameterValues,
								null, queryTimeoutSecs, resultSizeLimit);
				try {
					while (rs.next()) {
						PartStackElement newpse = new PartStackElement();

						newpse.part = pse.assembly;
						newpse.minRev = rs.getString(1);
						newpse.maxRev = rs.getString(2);
						newpse.latestRev = rs.getString(3);
						newpse.introECO = rs.getString(4);
						newpse.introDate = rs.getString(5);
						newpse.removeECO = rs.getString(6);
						newpse.removeDate = rs.getString(7);
						newpse.assembly = rs.getString(8);

						partStack.add(newpse);
					}
				} catch (IndexOutOfBoundsException e) {
					throw new PWiException(e,
							"Failed to process part stack at item index " + i);
				}
			}
			if (processcount == 0)
				break;
		}

		return partStack;
	}

	private List<ModelStackElement> processModelStack(
			List<PartStackElement> partStack)
			throws PWiResultSizeLimitExceededException, PWiException,
			PWiQueryTimeoutException {
		List<ModelStackElement> modelStack = new ArrayList<ModelStackElement>();

		PWiResultSet rs = QueryProcessingUtil.getInstance().executeQuery(
				getTopPartsDsn, getTopPartsSql, null, null, queryTimeoutSecs,
				resultSizeLimit);

		try {
			while (rs.next()) {
				ModelStackElement mse = new ModelStackElement();
				mse.part = rs.getString(1);
				mse.model = rs.getString(2);
				mse.busseg = rs.getString(3);
				modelStack.add(mse);
			}
		} catch (IndexOutOfBoundsException e) {
			throw new PWiException(e,
					"Failed to process results of top parts query for processing model stack.");
		}

		// models are found by looking for "no usage"
		// parts in the part stack. These parts may be
		// end item assemblies. If so, then they will
		// roll up to a model. The SQL takes of the
		// differences in how to do the roll up between
		// production and development assemblies.
		List<String> mseParts = new ArrayList<String>();
		for (int j=0;j< modelStack.size();j++) {
			mseParts.add(((ModelStackElement)modelStack.get(j)).part);
		}

		for (int i = 0; i < partStack.size(); i++) {
			PartStackElement pse = partStack.get(i);
			if (!pse.assembly.equals(NO_USAGE))
				continue;
			
			if (mseParts.contains(pse.part))
				continue;

			List<Object> parameterValues = new ArrayList<Object>();
			parameterValues.add(pse.part);
			parameterValues.add(pse.part);

			PWiResultSet rs2 = QueryProcessingUtil.getInstance().executeQuery(
					addModelDsn, addModelSql, parameterValues, null,
					queryTimeoutSecs, resultSizeLimit);

			try {
				while (rs2.next()) {
					ModelStackElement mse = new ModelStackElement();
					mse.part = pse.part;
					mse.model = rs2.getString(1);
					mse.busseg = rs2.getString(2);
					modelStack.add(mse);
				}
			} catch (IndexOutOfBoundsException e) {
				throw new PWiException(e,
						"Failed to process model stack at item index " + i);
			}
		}

		return modelStack;
	}

	private static class InputStackElement {
		public String inputpart; // input part number
		public String inputdraw; // input dwg number
		public String inputval; // input spec number
	}

	private static class PartStackElement {
		/*
		 * The component part for this element; used in a next higher assembly
		 * query to create the min, max, assembly part, and the latest revision
		 * of the assembly part
		 */
		public String part;
		public String minRev;
		public String maxRev;
		public String latestRev;
		public String introECO;
		public String introDate;
		public String removeECO;
		public String removeDate;
		public String assembly;

		public boolean isHistory() {
			int maxrev = Integer.valueOf(maxRev);
			int latrev = Integer.valueOf(latestRev);
			if (maxrev == latrev)
				return false;
			return true;
		}

		public boolean equals(Object obj) {
			if (obj == null || !(obj instanceof PartStackElement)) {
				return false;
			}
			PartStackElement pse = (PartStackElement) obj;
			if (pse.part.equals(this.part)
					&& pse.assembly.equals(this.assembly)) {
				return true;
			}
			return false;
		}

		public int hashCode() {
			return assembly.hashCode();
		}
	}

	private static class ModelStackElement {
		public String part;
		public String model;
		public String busseg;

		public boolean equals(Object obj) {
			if (obj == null || !(obj instanceof ModelStackElement)) {
				return false;
			}
			ModelStackElement mse = (ModelStackElement) obj;
			if (mse.part.equals(this.part)) {
				return true;
			}
			return false;
		}

		public int hashCode() {
			return part.hashCode();
		}
	}

	// TODO eventually refactor to use InputEditRulesUtil for DRY
	private String prepareSearchValue(ColumnType columnType, String value) {
		// Always right trim values
		String newValue = org.springframework.util.StringUtils
				.trimTrailingWhitespace(value);

		// Get input edit rules for column
		List<InputEditRule> inputEditRules = QueryJaxbUtil.getInstance()
				.translateInputEditRules(columnType);

		// Apply input edit rules to search value
		for (InputEditRule inputEditRule : inputEditRules) {
			newValue = InputEditRulesUtil.getInstance().applyRuleToColumnValue(
					newValue, inputEditRule);
		}

		return newValue;
	}
}
