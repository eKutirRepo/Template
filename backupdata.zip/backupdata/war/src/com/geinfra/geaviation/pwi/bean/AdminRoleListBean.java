package com.geinfra.geaviation.pwi.bean;

import java.util.List;

import org.richfaces.component.html.HtmlDataTable;

import com.geinfra.geaviation.pwi.bean.util.BeanUtil;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.PWiRoleVO;
import com.geinfra.geaviation.pwi.service.RoleService;
import com.geinfra.geaviation.pwi.util.PWiConstants;

/**
 * 
 * Project : Product Lifecycle Management Intelligence
 * Date Written : Aug 12, 2014
 * Security : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2013 GE All rights reserved
 * 
 * Description : Managed backing bean for admin page which lists all object
 * types defined in the system.
 * 
 * Revision Log Aug 12, 2014 | v1.0.
 * --------------------------------------------------------------
 */
public class AdminRoleListBean extends BaseBean {
	// Injected service
	private RoleService roleService;

	private HtmlDataTable roleTable = new HtmlDataTable();
	private List<PWiRoleVO> roleVOList;
	
	/*
	 */
	 private HtmlDataTable odsTable = new HtmlDataTable();
	 	 

	public void setRoleService(RoleService roleService) {
		this.roleService = roleService;
	}

	/**
	 * Action method that responds to requests to edit an object type
	 * 
	 * @return Faces navigation outcome
	 * @throws PWiException
	 * @throws NumberFormatException
	 */
	
	public String actionEditRole() throws NumberFormatException, PWiException {
		return BeanUtil.getInstance().getAdminRoleEditorBean().initEdit(
				((PWiRoleVO) roleTable.getRowData()).getRoleSeqId());
	}

	/**
	 * Action method that responds to requests for creating an object type
	 * 
	 * @return Faces navigation outcome
	 * @throws PWiException
	 */
	public String actionCreateRole() throws PWiException {
		return BeanUtil.getInstance().getAdminRoleEditorBean().initCreate();
	}
 
	
	/* end */ 

	public HtmlDataTable getRoleTable() {
		return roleTable;
	}

	public void setRoleTable(HtmlDataTable roleTable) {
		this.roleTable = roleTable;
	}
	
	
	
	
	
	/* By Chandana "getAllPWiRoles()" shows all the Roles in LIST */ 
	public List<PWiRoleVO> getRoleVOList() throws PWiException {
		if (roleVOList == null && roleService != null) {
			roleVOList = roleService.getAllPWiRoles();
		}
		return roleVOList;
	}
	/* end */ 

	
	public void setRoleVOList(List<PWiRoleVO> roleVOList) {
		this.roleVOList = roleVOList;
	}

	public HtmlDataTable getOdsTable() {
		return odsTable;
	}

	public void setOdsTable(HtmlDataTable odsTable) {
		this.odsTable = odsTable;
	}
	
	
	public String actionDeleteRole() throws NumberFormatException, PWiException {
		if(roleService!=null)
		{
			roleService.deleteRole(((PWiRoleVO) roleTable.getRowData()).getRoleSeqId());
		}
		return PWiConstants.NAV_ADMIN_ROLE_LIST;
	}
}