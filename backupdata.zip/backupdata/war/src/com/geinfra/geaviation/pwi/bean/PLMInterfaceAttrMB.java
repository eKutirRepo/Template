/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMInterfaceAttrMB.java
 * @Creation date: 29-Aug-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.geinfra.geaviation.pwi.data.PLMInterfaceAttrData;
import com.geinfra.geaviation.pwi.service.PLMInterfaceAttrServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMInterfaceAttrMB {

	/**
	 * Holds the Loggger
	 */
	private static final Logger LOG = Logger
			.getLogger(PLMInterfaceAttrMB.class);
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;

	/**
	 * Holds the plmPartFamilyIntAttrService
	 */
	private PLMInterfaceAttrServiceIfc interfaceAttrService = null;

	/**
	 * Holds the alertMessage
	 */
	private String alertMessage = "";
	/**
	 * Holds the partFamilyIntAttrData
	 */
	private PLMInterfaceAttrData partFamilyIntAttrData = null;
	/**
	 * Holds the contractDDList
	 */
	private List<SelectItem> partFamilyDDList = new ArrayList<SelectItem>();
	/**
	 * Holds the contractDDList
	 */
	private List<SelectItem> attributeNameDDList = new ArrayList<SelectItem>();
	/**
	 * Holds the dropDownMapList
	 */
	private Map<String, List<SelectItem>> dropDownMapList = new HashMap<String, List<SelectItem>>();
	/**
	 * Holds the resultList
	 */
	private List<PLMInterfaceAttrData> resultList = null;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = 50;
	/**
	 * Holds the resultListCount
	 */
	private int resultListCount = 0;
	/**
	 * Holds the resultListCountMsg
	 */
	private String resultListCountMsg = "";

	/**
	 * This method is used for Loading GBOM Page
	 * 
	 * @return String
	 */
	public String loadPartFamilyIntAttrSearchPage() {
		LOG.info("Entering loadPartFamilyIntAttrSearchPage Method");
		try {
			commonMB.insertCannedRptRecordHitInfo("Part Interface Attributes Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo:",ex);
		}
		partFamilyDDList = new ArrayList<SelectItem>();
		attributeNameDDList = new ArrayList<SelectItem>();
		partFamilyIntAttrData = new PLMInterfaceAttrData();
		try {
			// resetPartFamilyIntAttrValues();

			SelectItem stdText = new SelectItem("stdTxt",
					"Please select Part Family to see corresponding Attribute Names");
			attributeNameDDList.add(stdText);

			dropDownMapList = interfaceAttrService.getPartFamilyDropDownData();
			LOG.info("dropDownMapList fetched to MB with size =="
					+ dropDownMapList.size());

			partFamilyDDList = (List<SelectItem>) dropDownMapList
					.get("partFamilyDDList");
			LOG.info("partFamilyDDList fetched to MB with size =="
					+ partFamilyDDList.size());

			Collections
					.sort(partFamilyDDList, new PLMUtils.SortListSelItmLbl());

		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@loadGBomReportSearchPage:",
					exception);
		}
		LOG.info("Exiting loadPartFamilyIntAttrSearchPage Method");
		return "partFamilyIntAttrSearch";
	}

	/**
	 * This method is used for resetGBomValues
	 * 
	 * 
	 */
	public void resetPartFamilyIntAttrValues() {
		LOG.info("Entering resetPartFamilyIntAttrValues Method");
		partFamilyIntAttrData.setSelectedPartFamily("");
		partFamilyIntAttrData.setSelectedAttributeName("");
		partFamilyDDList.clear();
		LOG.info("Exiting resetPartFamilyIntAttrValues Method");
	}

	/**
	 * This method is used for valueChangeMMName
	 * 
	 * 
	 */
	public void valueChangePartFamily() {

		try {
			LOG.info("Entering valueChangePartFamily Method");
			String selectedPartFamily = partFamilyIntAttrData
					.getSelectedPartFamily();
			LOG.info("Selected Part Family is :" + selectedPartFamily);
			attributeNameDDList = new ArrayList<SelectItem>();
			attributeNameDDList = (List<SelectItem>) interfaceAttrService
					.getAttrNameForPartFamily(selectedPartFamily).get(
							"attrNameForPartFamily");
			LOG.info("attributeNameDDList fetched with size :"
					+ attributeNameDDList.size());
			if (attributeNameDDList.size() == 0) {
				alertMessage = PLMConstants.SELECT_ANOTHER_PARTFAMILY;
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@valueChangePartFamily PLMInterfaceAttrMB:",
					exception);
		}
		LOG.info("Exiting valueChangePartFamily Method");

	}

	/**
	 * This method is used for Generating CostCycleSmry Report for Contract
	 * 
	 * @return String
	 */
	public String onscreenPartFamilyReport() {
		LOG.info("Entering onscreenPartFamilyReport Method");
		String fwdflag = "";

		try {
			String selectedPartFamily = partFamilyIntAttrData
					.getSelectedPartFamily();
			String selectedAttributeName = partFamilyIntAttrData
					.getSelectedAttributeName();
			LOG.info("partFamilyIntAttrData.getSelectedPartFamily()=="
					+ partFamilyIntAttrData.getSelectedPartFamily());
			LOG.info("partFamilyIntAttrData.selectedAttributeName()=="
					+ partFamilyIntAttrData.getSelectedAttributeName());
			// LOG.info("partFamilyIntAttrData.selectedPartNum()=="+partFamilyIntAttrData.getSelectedPartNum());
			LOG.info("partFamilyIntAttrData.selectedCurrPrevRev()=="
					+ partFamilyIntAttrData.isSelectedCurrPrevRev());
			LOG.info("partFamilyIntAttrData.selectedInProcessState()=="
					+ partFamilyIntAttrData.getSelectedInProcessStates());
			LOG.info("partFamilyIntAttrData.selectedPartType()=="
					+ partFamilyIntAttrData.getSelectedPartType());

			if (PLMUtils.isEmpty(partFamilyIntAttrData.getSelectedPartFamily())
					&& PLMUtils.isEmpty(partFamilyIntAttrData
							.getSelectedAttributeName())
					&& PLMUtils.isEmpty(partFamilyIntAttrData
							.getSelectedPartNum())
					&& PLMUtils.isEmptyList(partFamilyIntAttrData
							.getSelectedInProcessStates())
					&& PLMUtils.isEmptyList(partFamilyIntAttrData
							.getSelectedPartType())

			) {
				// if(1 == 0){
				LOG.info("No Input criteria Selected.........");
				alertMessage = PLMConstants.SELECT_INPUT_CRITERIA_INT_ATTR;
				return "partFamilyIntAttrSearch";
			} else {
				LOG.info("Some Input Criteria Selected.........");
				// Added for Part Number validation
				if (!PLMUtils.isEmpty(partFamilyIntAttrData
						.getSelectedPartNum())) {
					LOG.info("part num is not empty...");
					if (!PLMUtils
							.checkForSpecialCharsForTaskSearch(partFamilyIntAttrData
									.getSelectedPartNum())) {
						LOG.info("Special characters exist in part number...");
						alertMessage = PLMConstants.INVALID_PARTNUM;
						return "partFamilyIntAttrSearch";
					}
				}
				LOG.info("Starting part num count check...");
				boolean partNumMore100 = false;
				partNumMore100 = PLMUtils
						.checkPartNumCountPFIA(partFamilyIntAttrData
								.getSelectedPartNum());
				LOG.info("Ended part num count check...");
				if (!partNumMore100) {
					LOG.info("More than 100 part numbers entered...");
					alertMessage = PLMConstants.PARTNUM_MORE_100;
					return "partFamilyIntAttrSearch";
				} else {
					LOG.info("Less than or equals to 100 part numbers entered...");
				}

				// (End Of)Added for Part Number validation
				LOG.info("Selected Part Family and Attribute Name are "
						+ selectedPartFamily + " , " + selectedAttributeName);
				resultList = new ArrayList<PLMInterfaceAttrData>();
				resultList = interfaceAttrService
						.getPartFamilyResultList(partFamilyIntAttrData);
				LOG.info("Fetched Part Family ResultList with size: "
						+ resultList.size());
				resultListCount = resultList.size();
				resultListCountMsg = "Total Results Count : " + resultListCount;

				if (resultList.size() == 0) {
					LOG.info("Result List has no data.Forwarding to invalid page");
					fwdflag = "invalidPartCycle";
					return fwdflag;
				}
				fwdflag = "partFamilyIntAttrResult";
			}

		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@onscreenPartFamilyReport: ",
					exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "partFamilyIntAttrSearch",
					"Part Family Interface Attribute");
		}

		LOG.info("Exiting onscreenPartFamilyReport Method");
		return fwdflag;
	}

	/**
	 * This method is used for resetSearchData
	 * 
	 * @return String
	 */
	public String resetSearchData() {
		LOG.info("Entering resetSearchData");
		String fwdFlag = "partFamilyIntAttrSearch";
		try {
			partFamilyIntAttrData.setSelectedAttributeName("");
			partFamilyIntAttrData.setSelectedPartFamily("");
			partFamilyIntAttrData.setSelectedPartNum("");
			partFamilyIntAttrData.setSelectedCurrPrevRev(false);
			partFamilyIntAttrData.setSelectedInProcessStates(null);
			partFamilyIntAttrData.setSelectedPartType(null);
			attributeNameDDList = new ArrayList<SelectItem>();
			SelectItem stdText = new SelectItem("stdTxt",
					"Please select Part Family to see corresponding Attribute Names");
			attributeNameDDList.add(stdText);

			LOG.info("executed resetSearchData inside resetSearchData");

		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@resetSearchData PLMInterfaceAttrMB:", exception);
		}
		LOG.info("Existing resetSearchData");
		return fwdFlag;

	}

	/**
	 * This method is used for auto complete feature
	 * 
	 * @return String
	 */
	public List<String> partFamilyAutocomplete(Object partFamilySuggest) {
		LOG.info("Inside partFamilyAutocomplete method...");
		String pref = (String) partFamilySuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (partFamilyDDList.size() > 0) {
				for (SelectItem item : partFamilyDDList) {
					if (!item.getLabel().equals("")
							&& item.getLabel().startsWith(
									pref.toUpperCase(Locale.getDefault()))) {
						// LOG.info("Added=="+item.getLabel());
						result.add(item.getLabel());
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@partFamilyAutocomplete in PLMPartFamilyIntAttrMB:",
					exception);
		}
		LOG.info("Existing partFamilyAutocomplete method...");
		return result;
	}

	/**
	 * This method is used for auto complete feature
	 * 
	 * @return String
	 */
	public void clearPartFamily() {
		LOG.info("Inside clearPartFamily method...");
		try {

		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@partFamilyAutocomplete in PLMPartFamilyIntAttrMB:",
					exception);
		}

	}

	/**
	 * This method is used to download an Excel File
	 * 
	 * 
	 */
	public void downloadExcel() throws PLMCommonException {
		LOG.info("Entering downloadExcel Method");
		String reportName = "PartFamily-InterfaceAttribute";
		try {

			if (resultList != null && resultList.size() > 0) {
				generatePartFamilyExcel(resultList, reportName);
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@downloadExcel: ", exception);
		}
		LOG.info("Exiting downloadExcel Method");

	}
	
	/**
	 * This method is used for download Excel sheet for each report
	 * 
	 * @return String
	 */
	public void downloadCSV() throws PLMCommonException {
		LOG.info("Entering downloadCSV Method");
		String reportName = "InterfaceAttribute";
		String fileName = "Interface Attribute Report";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		// Export to CSV for Interface Attribue Report
			PLMCsvRptColumn[] reportColumns =
					new PLMCsvRptColumn[] {new PLMCsvRptColumn("partName", "Part Name", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("partTitle", "Part Description", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("revision", "Revision", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("interfaceName", "Interface Name", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("attributeGroup", "Attribute Group", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("attributeNm", "Attribute Name", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("attributeValue", "Attribute Value", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("rdo", "RDO", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("partType", "Part Type", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("partState", "Part State", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("partFamilyNm", "Part Family Name", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("partFamilyDescription", "Part Family Description", FormatTypeCsv.TEXT)};

			csvUtil.exportCsv(resultList, reportColumns, fileName, dateFormat, false, null, null, ",");
			
			LOG.info("Exiting downloadCSV Method");
	}

	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return File
	 */

	public File generatePartFamilyExcel(
			List<PLMInterfaceAttrData> resultListLcl, String reportName)
			throws IOException {
		LOG.info("Entering generatePartFamilyExcel Method");
		File flexcelFile = null;
		FileOutputStream fileOut = null;
		InputStream fstream = null;
		BufferedOutputStream bos = null;
		OutputStream os = null;
		XSSFWorkbook workbook = null;
		XSSFSheet sheet = null;
		XSSFCell cell = null;
		try {

			StringBuilder fileNameStr = new StringBuilder()
					.append(PLMUtils.getMessage("OFFLINE_RPT_DIR", "Reports"))
					.append(reportName).append(PLMUtils.getCurrentDateTime())
					.append(".xlsx");

			flexcelFile = new File(fileNameStr.toString());
			workbook = new XSSFWorkbook();

			if (workbook != null) {

				sheet = workbook.createSheet(reportName);
				sheet.createFreezePane(0, 1);
				XSSFFont fontstyle = workbook.createFont();
				fontstyle.setFontName(PLMConstants.EXCEL_FONT_NAME);

				XSSFCellStyle unLockedTextStyle = workbook.createCellStyle();
				unLockedTextStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				unLockedTextStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				unLockedTextStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
				unLockedTextStyle.setBorderTop((HSSFCellStyle.BORDER_THIN));
				unLockedTextStyle.setFont(fontstyle);
				unLockedTextStyle.setWrapText(true);
				unLockedTextStyle.setLocked(false);
				unLockedTextStyle.setAlignment(CellStyle.ALIGN_CENTER);

				/*
				 * HSSFCellStyle lockedTextStyle = workbook.createCellStyle();
				 * lockedTextStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				 * lockedTextStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				 * lockedTextStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
				 * lockedTextStyle.setBorderTop((HSSFCellStyle.BORDER_THIN));
				 * lockedTextStyle.setFont(fontstyle);
				 * lockedTextStyle.setWrapText(true);
				 * lockedTextStyle.setLocked(true);
				 * lockedTextStyle.setAlignment(CellStyle.ALIGN_CENTER);
				 */

				XSSFCellStyle headerStyle = workbook.createCellStyle();

				headerStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
				XSSFFont font = workbook.createFont();
				font.setFontName(PLMConstants.EXCEL_FONT_NAME);
				font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headerStyle.setFont(font);
				headerStyle.setWrapText(true);
				headerStyle.setLocked(true);
				headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
				headerStyle = setBorderStyle(headerStyle);

				int rowcount = -1;

				if (!PLMUtils.isEmptyList(resultListLcl)) {
					String[] colNames = { "Part Name", "Part Title",
							"Revision", "RDO", "Part State", "Part State Date",
							"Part Family Name", "Part Family Description",
							"Interface Name", "Attribute Group",
							"Attribute Name", "Attribute Value" };
					XSSFRow row = sheet.createRow(++rowcount);

					cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
					XSSFCellStyle cellStyle = cell.getCellStyle();
					cellStyle.setLocked(true);
					cell.setCellStyle(unLockedTextStyle);

					for (int i = 0; i < colNames.length; i++) {
						cell = row.createCell(i);
						cell.setCellValue(colNames[i]);
						cell.setCellStyle(headerStyle);
						headerStyle = cell.getCellStyle();
						cell.setCellStyle(headerStyle);
					}

					// sheet.getRow(0).getCell(0).getCellStyle().setLocked(true);
					// sheet.getRow(0).getCell(0).setCellStyle(lockedTextStyle);

					for (int i = 0; i < resultListLcl.size(); i++) {
						PLMInterfaceAttrData dataObj = (PLMInterfaceAttrData) resultListLcl
								.get(i);
						row = sheet.createRow(++rowcount);

						cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(dataObj.getPartName());

						cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(dataObj.getPartTitle());

						cell = row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(dataObj.getRevision());

						cell = row.createCell(PLMConstants.EXCEL_COL_THREE);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(dataObj.getRdo());

						cell = row.createCell(PLMConstants.EXCEL_COL_FOUR);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(dataObj.getPartState());

						cell = row.createCell(PLMConstants.EXCEL_COL_FIVE);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(dataObj.getPartStateDate());

						cell = row.createCell(PLMConstants.EXCEL_COL_SIX);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(dataObj.getPartFamilyNm());

						cell = row.createCell(PLMConstants.EXCEL_COL_SEVEN);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(dataObj.getPartFamilyDescription());

						cell = row.createCell(PLMConstants.EXCEL_COL_EIGHT);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(dataObj.getInterfaceName());

						cell = row.createCell(PLMConstants.EXCEL_COL_NINE);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(dataObj.getAttributeGroup());

						cell = row.createCell(PLMConstants.EXCEL_COL_TEN);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(dataObj.getAttributeNm());

						cell = row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(dataObj.getAttributeValue());

					}

					row = sheet.createRow(++rowcount);
					row = sheet.createRow(++rowcount);
					short colWidth = (short) 6400;
					short colWidth1 = (short) 6700;
					short colWidth2 = (short) 7000;
					short colWidth3 = (short) 7200;
					short colWidth4 = (short) 7900;

					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, colWidth1);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE, colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX, colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,
							colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,
							colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE, colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN, colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN,
							colWidth3);

				}
				/*
				 * for(int i=0;i<reqCeiMliNamesListLcl.size();i++){ for(int
				 * j=0;j<16;j++){ if(j==7 || j==8 || j==9 || j==10 || j==11 ||
				 * j==12 || j==13 || j==14){
				 * sheet.getRow(i+1).getCell(j).getCellStyle().setLocked(false);
				 * } else{
				 * sheet.getRow(i+1).getCell(j).getCellStyle().setLocked(true);
				 * } }
				 * 
				 * }
				 */

				// sheet.protectSheet("plmrlatest");

				fileOut = new FileOutputStream(flexcelFile);
				workbook.write(fileOut);
				String fileName = flexcelFile.getName();
				FacesContext context = FacesContext.getCurrentInstance();
				HttpServletResponse response = (HttpServletResponse) context
						.getExternalContext().getResponse();
				response.setContentType("application/vnd.ms-excel");
				response.setHeader("content-disposition",
						"attachment; filename=" + fileName);
				os = response.getOutputStream();
				workbook.write(os);
				fileOut.close();
				os.close();
				context.responseComplete();
				LOG.info("test file name" + fileName);
				LOG.info("test report-------" + flexcelFile);

			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@generateFMIManageTxt: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@generateFMIManageTxt: ", e);
			throw e;
		} finally {
			try {
				if (bos != null) {
					bos.close();
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "The Exception in generateFMIManageTxt "
						+ exception);
			}
			try {
				if (os != null) {
					os.close();
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "The Exception in generateFMIManageTxt "
						+ exception);
			}
			try {
				if (fstream != null) {
					fstream.close();
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "The Exception in generateFMIManageTxt "
						+ exception);
			}
			try {
				if (flexcelFile != null) {
					PLMUtils.deleteDocument(flexcelFile.getAbsolutePath());
				}
			} catch (Exception exception) {
				LOG.log(Level.ERROR, "The Exception in generateFMIManageTxt "
						+ exception);
			}
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "The Exception in generateFMIManageTxt "
						+ exception);
			}

		}
		LOG.info("Exiting generateFMIManageTxt Method");
		return flexcelFile;

	}

	/**
	 * This method is used for Bordering Cell in XLS
	 * 
	 * @return StringBuffer
	 */

	private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		return style;
	}

	/**
	 * This method is used for recordsPerPageListner
	 * 
	 * @param event
	 * 
	 */
	public void recordsPerPageListner(ActionEvent event) {
		LOG.info("Entering recordsPerPageListner method");
		LOG.info("Action listner called.....--------------------------->"
				+ recordCounts);
		if (recordCounts == 15) {
			LOG.info("15");
			recordCounts = 15;
		} else if (recordCounts == 30) {
			LOG.info("30");
			recordCounts = 30;
		} else if (recordCounts == 50) {
			LOG.info("50");
			recordCounts = 50;
		} else if (recordCounts == 100) {
			LOG.info("100");
			recordCounts = 100;
		} else if (recordCounts == 200) {
			LOG.info("200");
			recordCounts = 200;
		}

		else if (recordCounts == resultListCount) {
			LOG.info("All");
			recordCounts = resultListCount;
		}
		LOG.info("final value.....--------------------------->" + recordCounts);
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB
	 *            the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return LOG;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage
	 *            the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the partFamilyDDList
	 */
	public List<SelectItem> getPartFamilyDDList() {
		return partFamilyDDList;
	}

	/**
	 * @param partFamilyDDList
	 *            the partFamilyDDList to set
	 */
	public void setPartFamilyDDList(List<SelectItem> partFamilyDDList) {
		this.partFamilyDDList = partFamilyDDList;
	}

	/**
	 * @return the attributeNameDDList
	 */
	public List<SelectItem> getAttributeNameDDList() {
		return attributeNameDDList;
	}

	/**
	 * @param attributeNameDDList
	 *            the attributeNameDDList to set
	 */
	public void setAttributeNameDDList(List<SelectItem> attributeNameDDList) {
		this.attributeNameDDList = attributeNameDDList;
	}

	/**
	 * @return the dropDownMapList
	 */
	public Map<String, List<SelectItem>> getDropDownMapList() {
		return dropDownMapList;
	}

	/**
	 * @param dropDownMapList
	 *            the dropDownMapList to set
	 */
	public void setDropDownMapList(Map<String, List<SelectItem>> dropDownMapList) {
		this.dropDownMapList = dropDownMapList;
	}

	/**
	 * @return the interfaceAttrService
	 */
	public PLMInterfaceAttrServiceIfc getInterfaceAttrService() {
		return interfaceAttrService;
	}

	/**
	 * @param interfaceAttrService
	 *            the interfaceAttrService to set
	 */
	public void setInterfaceAttrService(
			PLMInterfaceAttrServiceIfc interfaceAttrService) {
		this.interfaceAttrService = interfaceAttrService;
	}

	/**
	 * @return the partFamilyIntAttrData
	 */
	public PLMInterfaceAttrData getPartFamilyIntAttrData() {
		return partFamilyIntAttrData;
	}

	/**
	 * @param partFamilyIntAttrData
	 *            the partFamilyIntAttrData to set
	 */
	public void setPartFamilyIntAttrData(
			PLMInterfaceAttrData partFamilyIntAttrData) {
		this.partFamilyIntAttrData = partFamilyIntAttrData;
	}

	/**
	 * @return the resultList
	 */
	public List<PLMInterfaceAttrData> getResultList() {
		return resultList;
	}

	/**
	 * @param resultList
	 *            the resultList to set
	 */
	public void setResultList(List<PLMInterfaceAttrData> resultList) {
		this.resultList = resultList;
	}

	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @param recordCounts
	 *            the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}

	/**
	 * @return the resultListCount
	 */
	public int getResultListCount() {
		return resultListCount;
	}

	/**
	 * @param resultListCount
	 *            the resultListCount to set
	 */
	public void setResultListCount(int resultListCount) {
		this.resultListCount = resultListCount;
	}

	/**
	 * @return the resultListCountMsg
	 */
	public String getResultListCountMsg() {
		return resultListCountMsg;
	}

	/**
	 * @param resultListCountMsg
	 *            the resultListCountMsg to set
	 */
	public void setResultListCountMsg(String resultListCountMsg) {
		this.resultListCountMsg = resultListCountMsg;
	}

}
