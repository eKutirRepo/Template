package com.geinfra.geaviation.pwi.bean;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import jxl.common.Logger;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.model.QueriesVO;
import com.geinfra.geaviation.pwi.service.QueriesService;
import com.geinfra.geaviation.pwi.service.QueryGroupService;
import com.geinfra.geaviation.pwi.util.PWiConstants;

/**
 * 
 * Project : Product Lifecycle Management Date Written : May 19, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : QueryGroupBean
 * This bean backs both the admin-group and admin-createupdategroup jsf pages.
 * 
 * Revision Log May 19, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class QueryGroupBean extends BaseBean {
	private static final Logger LOGGER = Logger.getLogger(QueryGroupBean.class);

	// Injected services
	private QueryGroupService queryGroupService;
	private QueriesService qryService;

	private List<PWiQueryGroupVO> queryGroupVOList;
	private List<SelectItem> rolesList;
	private List<QueriesVO> allQueriesList;
	private List<QueriesVO> selectedQueriesList;
	private PWiQueryGroupVO queryGroupVO;
	private boolean renderCreateButton;
	private boolean renderUpdateButton;
	private Integer selectedRowId;

	public void setQueryGroupService(QueryGroupService queryGroupService) {
		this.queryGroupService = queryGroupService;
	}

	public void setQryService(QueriesService qryService) {
		this.qryService = qryService;
	}

	public Integer getSelectedRowId() {
		return selectedRowId;
	}

	public void setSelectedRowId(Integer selectedRowId) {
		this.selectedRowId = selectedRowId;
	}

	public List<QueriesVO> fetchQueryGroupDetails(Integer groupId) {
		List<QueriesVO> queriesInGroup = qryService.getQueriesInGroup(groupId);
		return queriesInGroup;
	}

	public String createQueryGroup() throws SQLException {
		String str = null;

		if (getQueryGroupVO().getQueryGroupName().equals("Select")) {

			FacesContext.getCurrentInstance().addMessage(
					PWiConstants.ERROR_SELECT_QRY_GRP_NAME,
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							PWiConstants.ERROR_SELECT_QRY_GRP_NAME,
							PWiConstants.ERROR_SELECT_QRY_GRP_NAME));
			str = "error";
			LOGGER.info(PWiConstants.INVALID_GROUP_NAME_LOG_MESSAGE);
		} else {
			boolean duplicateGroup = false;
			List<PWiQueryGroupVO> allgroups = getQueryGroupVOList();
			for (Iterator<PWiQueryGroupVO> i = allgroups.iterator(); i.hasNext();) {
				PWiQueryGroupVO qryGrp = i.next();
				if (getQueryGroupVO().getQueryGroupName().equals(
						qryGrp.getQueryGroupName())) {
					duplicateGroup = true;

				}
			}
			if (duplicateGroup) {
				str = "error";
				FacesContext.getCurrentInstance().addMessage(
						PWiConstants.ERROR_GRP_ALRDY_EXSTS,
						new FacesMessage(FacesMessage.SEVERITY_ERROR,
								PWiConstants.ERROR_GRP_ALRDY_EXSTS,
								PWiConstants.ERROR_GRP_ALRDY_EXSTS));

			} else {
				qryService.validateQueryParamName(getQueryGroupVO().getQueryGroupName());				
				getQueryGroupVO().setQueriesList(selectedQueriesList);
				getQueryGroupService().createQueryGroup(getQueryGroupVO());
				str = "created";
				LOGGER.info("Group " + getQueryGroupVO().getQueryGroupName()
						+ " Created");
				FacesContext.getCurrentInstance().addMessage(
						null,
						new FacesMessage(FacesMessage.SEVERITY_INFO, "Group "
								+ getQueryGroupVO().getQueryGroupName()
								+ " Created Succesfully", "Group "
								+ getQueryGroupVO().getQueryGroupName()
								+ " Created Succesfully"));
			}
		}
		return str;
	}

	public String updateQueryGroup() {
		getQueryGroupVO().setQueriesList(selectedQueriesList);
		getQueryGroupService().updateQueryGroup(getQueryGroupVO());
		FacesContext.getCurrentInstance().addMessage(
				null,
				new FacesMessage("Group "
						+ getQueryGroupVO().getQueryGroupName()
						+ " Updated Succesfully"));
		LOGGER.info("Group " + getQueryGroupVO().getQueryGroupName()
				+ " Updated");
		return "updated";
	}

	public List<PWiQueryGroupVO> getQueryGroupVOList() {
		queryGroupVOList = getQueryGroupService().getAllQueryGroups();
		return queryGroupVOList;
	}

	public void setQueryGroupVOList(List<PWiQueryGroupVO> queryGroupVOList) {
		this.queryGroupVOList = queryGroupVOList;
	}

	public List<SelectItem> getRolesList() throws PWiException {
		if (renderCreateButton) {
			List<String> retroleslist = getQueryGroupService().getUnmappedRolesList();
			rolesList = new ArrayList<SelectItem>();
			rolesList.add(new SelectItem("Select", "Select Role Name"));
			for (Iterator<String> i = retroleslist.iterator(); i.hasNext();) {
				String str = i.next();
				rolesList.add(new SelectItem(str, str));
			}
		}
		if (renderUpdateButton) {

			rolesList = new ArrayList<SelectItem>();
			String str = getQueryGroupVO().getQueryGroupName();
			rolesList.add(new SelectItem(str, str));

		}
		return rolesList;
	}

	public void setRolesList(List<SelectItem> rolesList) {
		this.rolesList = rolesList;
	}

	public List<QueriesVO> getAllQueriesList() {

		return allQueriesList;
	}

	public void setAllQueriesList(List<QueriesVO> allQueriesList) {
		this.allQueriesList = allQueriesList;
	}

	public List<QueriesVO> getSelectedQueriesList() {

		return selectedQueriesList;
	}

	public void setSelectedQueriesList(List<QueriesVO> selectedQueriesList) {
		this.selectedQueriesList = selectedQueriesList;
	}

	public PWiQueryGroupVO getQueryGroupVO() {
		return queryGroupVO;
	}

	public void setQueryGroupVO(PWiQueryGroupVO queryGroupVO) {
		this.queryGroupVO = queryGroupVO;
	}

	public List<QueriesVO> getAvlblQueriesList(Integer groupId) {
		return qryService.getAvlblQueriesList(groupId);
	}

	private QueryGroupService getQueryGroupService() {
		return queryGroupService;
	}

	public boolean isRenderCreateButton() {
		return renderCreateButton;
	}

	public void setRenderCreateButton(boolean renderCreateButton) {
		this.renderCreateButton = renderCreateButton;
	}

	public boolean isRenderUpdateButton() {
		return renderUpdateButton;
	}

	public void setRenderUpdateButton(boolean renderUpdateButton) {
		this.renderUpdateButton = renderUpdateButton;
	}

	public String onClickEdit() {
		selectedQueriesList = fetchQueryGroupDetails(getSelectedRowId());
		allQueriesList = getAvlblQueriesList(getSelectedRowId());
		for (PWiQueryGroupVO q : getQueryGroupVOList()) {
			if (q.getQueryGroupId().equals(getSelectedRowId())) {

				setQueryGroupVO(q);
			}
		}
		renderCreateButton = false;
		renderUpdateButton = true;
		return "update";
	}

	public String actionInitCreateGroupEditor() throws PWiException {
		getQueryGroupVO().setQueryGroupDescription("");
		getQueryGroupVO().setAlwaysShow(true);
		getQueryGroupVO().setGroupDisplayName("");
		selectedQueriesList = new ArrayList<QueriesVO>();
		// Getting available queries for "no group" rather than getting all
		// queries will avoid getting duplicate queries for duplicately-assigned
		// queries.  Performance is a non-concern, because this is called only
		// when creating a brand-new group, which happens infrequentnly.
		allQueriesList = getAvlblQueriesList(Integer.valueOf(PWiConstants.NO_VALUE));
		renderCreateButton = true;
		renderUpdateButton = false;
		return "createUpdateGroup";
	}

	public void cancel() {
		FacesContext.getCurrentInstance().getApplication()
				.getNavigationHandler().handleNavigation(
						FacesContext.getCurrentInstance(), null, "cancel");

	}
}
