/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMSalesOrderData.java
 * @Creation date: 11-Sept-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMSalesOrderData {

	
	// PROPERTIES *************************************************************

	private String id;
	
	private String name;
	
	private String description;
	
	private String lifecycle;
	
	private String erp_order_status;

	private String order_administrator;
	
	private String customer;
	
	private String unit_serial_number;
		
	private String icn;
	
	
	// CONSTRUCTOR ************************************************************
	public PLMSalesOrderData (String id, 
						String name,
						String description, 
						String lifecycle, 
						String erp_order_status, 
						String order_administrator, 
						String customer,
						String unit_serial_number,
						String icn) {  
		this.id = id;
		this.name = name;
		this.description = description;
		this.lifecycle = lifecycle;
		this.erp_order_status = erp_order_status;
		this.order_administrator = order_administrator;
		this.customer = customer;
		this.unit_serial_number = unit_serial_number;
		this.icn = icn;
	}
	
	// ACCESSOR METHODS *******************************************************
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLifecycle() {
		return lifecycle;
	}

	public void setLifecycle(String lifecycle) {
		this.lifecycle = lifecycle;
	}

	public String getErp_order_status() {
		return erp_order_status;
	}

	public void setErp_order_status(String erp_order_status) {
		this.erp_order_status = erp_order_status;
	}

	public String getOrder_administrator() {
		return order_administrator;
	}

	public void setOrder_administrator(String order_administrator) {
		this.order_administrator = order_administrator;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getUnit_serial_number() {
		return unit_serial_number;
	}

	public void setUnit_serial_number(String unit_serial_number) {
		this.unit_serial_number = unit_serial_number;
	}

	public String getIcn() {
		return icn;
	}

	public void setIcn(String icn) {
		this.icn = icn;
	}


	
	// OVERRIDEN METHODS ******************************************************

	/**
	 * Returns the SalesOrder information as a String
	 * 
	 * @return type (String) 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer strSalesOrder = new StringBuffer();
		
		strSalesOrder
			.append(id).append(" ")
			.append(name).append(" ")
			.append(description).append(" ")
			.append(lifecycle).append(" ")
			.append(erp_order_status)
			.append(order_administrator)
			.append(customer)
			.append(unit_serial_number)
			.append(icn)
			;
		
		return strSalesOrder.toString();
	}
	
}
