/**
 * Copyright (C) 2015 GE Infra. 
 * All rights reserved 
 * @FileName PLMConfigFeatOptRptData.java
 * @Creation date: 18-Aug-2015
 * @version 1.0
  * @author : Tech Mahindra
 */

package com.geinfra.geaviation.pwi.data;

import java.util.Date;
import java.util.List;

public class PLMConfigFeatOptRptData {
	
	/**
	  * Holds the ipOwner
	  */
	private String ipOwner;
	/**
	  * Holds the ipName
	  */
	private String ipName;
	/**
	  * Holds the ipState
	  */
	private List<String> ipState;
	/**
	  * Holds the ipOriginator
	  */
	private String ipOriginator;
	/**
	  * Holds the ipVault
	  */
	private String ipVault;
	/**
	  * Holds the ipRevision
	  */
	private String ipRevision;
	/**
	  * Holds the ipTitle
	  */
	private String ipTitle;
	/**
	  * Holds the ipDescription
	  */
	private String ipDescription;
	/**
	  * Holds the ipDisplayName
	  */
	private String ipDisplayName;
	/**
	  * Holds the ipIndicator
	  */
	private String ipIndicator;
	/**
	  * Holds the ipOrigFromDate
	  */
	private Date ipOrigFromDate;
	/**
	  * Holds the ipOriToDate
	  */
	private Date ipOrigToDate;
	/**
	  * Holds the ipModFromDate
	  */
	private Date ipModFromDate;
	/**
	  * Holds the ipModToDate
	  */
	private Date ipModToDate;
	
	
	
	/**
	  * Holds the coId
	  */
	private String coId;
	/**
	  * Holds the coName
	  */
	private String coName;
	/**
	  * Holds the geIndr
	  */
	private String geIndr;
	/**
	  * Holds the frsId
	  */
	private String frsId;
	/**
	  * Holds the frsName
	  */
	private String frsName;
	/**
	  * Holds the displayText
	  */
	private String displayText;
	/**
	  * Holds the displayName
	  */
	private String displayName;
	/**
	  * Holds the coRevision
	  */
	private String coRevision;
	/**
	  * Holds the coState
	  */
	private String coState;
	/**
	  * Holds the parentCf
	  */
	private String parentCf;
	/**
	  * Holds the rNum
	  */
	private String rNum;
	/**
	  * Holds the ownerSso
	  */
	private String ownerSso;
	/**
	  * Holds the ownerName
	  */
	private String ownerName;
	/**
	  * Holds the origDate
	  */
	private String origDate;
	/**
	  * Holds the cfgnSelType
	  */
	private String cfgnSelType;
	
	/**
	  * Holds the cfgnSelType
	  */
	private String confFtrStateExcl;
	
	
	/**
	 * @return the ipOwner
	 */
	public String getIpOwner() {
		return ipOwner;
	}
	/**
	 * @param ipOwner the ipOwner to set
	 */
	public void setIpOwner(String ipOwner) {
		this.ipOwner = ipOwner;
	}
	/**
	 * @return the ipName
	 */
	public String getIpName() {
		return ipName;
	}
	/**
	 * @param ipName the ipName to set
	 */
	public void setIpName(String ipName) {
		this.ipName = ipName;
	}
	/**
	 * @return the ipState
	 */
	public List<String> getIpState() {
		return ipState;
	}
	/**
	 * @param ipState the ipState to set
	 */
	public void setIpState(List<String> ipState) {
		this.ipState = ipState;
	}
	/**
	 * @return the ipOriginator
	 */
	public String getIpOriginator() {
		return ipOriginator;
	}
	/**
	 * @param ipOriginator the ipOriginator to set
	 */
	public void setIpOriginator(String ipOriginator) {
		this.ipOriginator = ipOriginator;
	}
	/**
	 * @return the ipVault
	 */
	public String getIpVault() {
		return ipVault;
	}
	/**
	 * @param ipVault the ipVault to set
	 */
	public void setIpVault(String ipVault) {
		this.ipVault = ipVault;
	}
	/**
	 * @return the ipRevision
	 */
	public String getIpRevision() {
		return ipRevision;
	}
	/**
	 * @param ipRevision the ipRevision to set
	 */
	public void setIpRevision(String ipRevision) {
		this.ipRevision = ipRevision;
	}
	/**
	 * @return the ipTitle
	 */
	public String getIpTitle() {
		return ipTitle;
	}
	/**
	 * @param ipTitle the ipTitle to set
	 */
	public void setIpTitle(String ipTitle) {
		this.ipTitle = ipTitle;
	}
	/**
	 * @return the ipDescription
	 */
	public String getIpDescription() {
		return ipDescription;
	}
	/**
	 * @param ipDescription the ipDescription to set
	 */
	public void setIpDescription(String ipDescription) {
		this.ipDescription = ipDescription;
	}
	/**
	 * @return the ipDisplayName
	 */
	public String getIpDisplayName() {
		return ipDisplayName;
	}
	/**
	 * @param ipDisplayName the ipDisplayName to set
	 */
	public void setIpDisplayName(String ipDisplayName) {
		this.ipDisplayName = ipDisplayName;
	}
	/**
	 * @return the ipIndicator
	 */
	public String getIpIndicator() {
		return ipIndicator;
	}
	/**
	 * @param ipIndicator the ipIndicator to set
	 */
	public void setIpIndicator(String ipIndicator) {
		this.ipIndicator = ipIndicator;
	}
	/**
	 * @return the ipOrigFromDate
	 */
	public Date getIpOrigFromDate() {
		return ipOrigFromDate;
	}
	/**
	 * @param ipOrigFromDate the ipOrigFromDate to set
	 */
	public void setIpOrigFromDate(Date ipOrigFromDate) {
		this.ipOrigFromDate = ipOrigFromDate;
	}
	/**
	 * @return the ipOrigToDate
	 */
	public Date getIpOrigToDate() {
		return ipOrigToDate;
	}
	/**
	 * @param ipOrigToDate the ipOrigToDate to set
	 */
	public void setIpOrigToDate(Date ipOrigToDate) {
		this.ipOrigToDate = ipOrigToDate;
	}
	/**
	 * @return the ipModFromDate
	 */
	public Date getIpModFromDate() {
		return ipModFromDate;
	}
	/**
	 * @param ipModFromDate the ipModFromDate to set
	 */
	public void setIpModFromDate(Date ipModFromDate) {
		this.ipModFromDate = ipModFromDate;
	}
	/**
	 * @return the ipModToDate
	 */
	public Date getIpModToDate() {
		return ipModToDate;
	}
	/**
	 * @param ipModToDate the ipModToDate to set
	 */
	public void setIpModToDate(Date ipModToDate) {
		this.ipModToDate = ipModToDate;
	}
	/**
	 * @return the coId
	 */
	public String getCoId() {
		return coId;
	}
	/**
	 * @param coId the coId to set
	 */
	public void setCoId(String coId) {
		this.coId = coId;
	}
	/**
	 * @return the coName
	 */
	public String getCoName() {
		return coName;
	}
	/**
	 * @param coName the coName to set
	 */
	public void setCoName(String coName) {
		this.coName = coName;
	}
	/**
	 * @return the geIndr
	 */
	public String getGeIndr() {
		return geIndr;
	}
	/**
	 * @param geIndr the geIndr to set
	 */
	public void setGeIndr(String geIndr) {
		this.geIndr = geIndr;
	}
	/**
	 * @return the frsId
	 */
	public String getFrsId() {
		return frsId;
	}
	/**
	 * @param frsId the frsId to set
	 */
	public void setFrsId(String frsId) {
		this.frsId = frsId;
	}
	/**
	 * @return the frsName
	 */
	public String getFrsName() {
		return frsName;
	}
	/**
	 * @param frsName the frsName to set
	 */
	public void setFrsName(String frsName) {
		this.frsName = frsName;
	}
	/**
	 * @return the displayText
	 */
	public String getDisplayText() {
		return displayText;
	}
	/**
	 * @param displayText the displayText to set
	 */
	public void setDisplayText(String displayText) {
		this.displayText = displayText;
	}
	/**
	 * @return the coRevision
	 */
	public String getCoRevision() {
		return coRevision;
	}
	/**
	 * @param coRevision the coRevision to set
	 */
	public void setCoRevision(String coRevision) {
		this.coRevision = coRevision;
	}
	/**
	 * @return the coState
	 */
	public String getCoState() {
		return coState;
	}
	/**
	 * @param coState the coState to set
	 */
	public void setCoState(String coState) {
		this.coState = coState;
	}
	/**
	 * @return the parentCf
	 */
	public String getParentCf() {
		return parentCf;
	}
	/**
	 * @param parentCf the parentCf to set
	 */
	public void setParentCf(String parentCf) {
		this.parentCf = parentCf;
	}
	/**
	 * @return the rNum
	 */
	public String getrNum() {
		return rNum;
	}
	/**
	 * @param rNum the rNum to set
	 */
	public void setrNum(String rNum) {
		this.rNum = rNum;
	}
	/**
	 * @return the ownerSso
	 */
	public String getOwnerSso() {
		return ownerSso;
	}
	/**
	 * @param ownerSso the ownerSso to set
	 */
	public void setOwnerSso(String ownerSso) {
		this.ownerSso = ownerSso;
	}
	/**
	 * @return the ownerName
	 */
	public String getOwnerName() {
		return ownerName;
	}
	/**
	 * @param ownerName the ownerName to set
	 */
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	/**
	 * @return the origDate
	 */
	public String getOrigDate() {
		return origDate;
	}
	/**
	 * @param origDate the origDate to set
	 */
	public void setOrigDate(String origDate) {
		this.origDate = origDate;
	}
	/**
	 * @return the cfgnSelType
	 */
	public String getCfgnSelType() {
		return cfgnSelType;
	}
	/**
	 * @param cfgnSelType the cfgnSelType to set
	 */
	public void setCfgnSelType(String cfgnSelType) {
		this.cfgnSelType = cfgnSelType;
	}
	/**
	 * @return the displayName
	 */
	public String getDisplayName() {
		return displayName;
	}
	/**
	 * @param displayName the displayName to set
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	/**
	 * @return the confFtrStateExcl
	 */
	public String getConfFtrStateExcl() {
		return confFtrStateExcl;
	}
	/**
	 * @param confFtrStateExcl the confFtrStateExcl to set
	 */
	public void setConfFtrStateExcl(String confFtrStateExcl) {
		this.confFtrStateExcl = confFtrStateExcl;
	}
	
	
	
	
	

}
