/**
 * Copyright (C) 2012 GE Infra. 
 * All rights reserved 
 * @FileName PLMOmmReportMB.java
 * @Creation date: 14-June-2012
 * @version 2.0.1
 * @author : Tech Mahindra (PLMR Team) 
 */

package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMOmmReportData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMOmmReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

/**
 * PLMOmmReportMB is the managed bean class .
 */

@SuppressWarnings("deprecation")
public class PLMOmmReportMB {
	/**
	 * Holds the LOG
	 */
	private static Logger LOG = Logger.getLogger(PLMOmmReportMB.class);
	/**
	 * Holds the ommReportData
	 */
	private PLMOmmReportData ommReportData = null;
	/**
	 * Holds the PLMOmmReportServiceIfc
	 */
	private PLMOmmReportServiceIfc plmOmmReportService  = null;
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	
	/**
	 * Holds user information
	 */
	private PLMPwiUserData userDetails = null;
	
	/**
	 * Holds the topPartListCount
	 */
	private int topPartListCount;
	
	/**
	 * Holds the topPartList
	 */
	private List<PLMOmmReportData> topPartList = new ArrayList<PLMOmmReportData>();
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;
	
	private String topPartId;
	

	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendOmmReportThroughMail();
		}
	}
	
	/**
	 * This method is used for Loading OMM Page
	 * 
	 * @return String
	 */
	public String loadOmmReportPage() {
		LOG.info("Entering loadOmmReportPage Method");
		try {
			commonMB.insertCannedRptRecordHitInfo("OMM-EBOM Explosion Report");
			alertMessage = "";
			topPartId = "";
			ommReportData = new PLMOmmReportData();
			topPartList.clear();
			} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadOmmReportPage:", exception);
		}
		LOG.info("Exiting loadOmmReportPage Method");
		return "ommReportSearch";
	}
	
	/**
	 * This method is used for Generating OMM Report
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String getOmmReport() throws PWiException {
		LOG.info("Entering getOmmReport Method");
		LOG.info("Serial Number Entered "+ommReportData.getSerialNo());
		String fwdflag = "";
		alertMessage = "";
		topPartId = "";
		topPartList.clear();
		alertMessage = validateOmmInput();
		if (PLMUtils.isEmpty(alertMessage)) {
			try {
				int serialCount =  plmOmmReportService.checkForValidSerialNo(ommReportData.getSerialNo());
				if(serialCount == 0) {
					alertMessage = PLMConstants.OMM_INVALID_SERIAL_NO_ALERT_MSG;
					topPartListCount = topPartList.size();
				} else {
					if (PLMUtils.isEmpty(alertMessage)) {
					topPartList =  plmOmmReportService.getTopPartsList(ommReportData.getSerialNo());
		 			topPartListCount = topPartList.size();
				    LOG.info("The number of results from Top Part List >> "+topPartList.size());
				    recordCounts = PLMConstants.N_100;
				    
					    if(topPartListCount==0){
							alertMessage =  PLMConstants.OMM_BOM_INVALID_NO_ALERT_MSG;
					    }else if(topPartListCount==1){
							topPartId=topPartList.get(0).getTopPartId();
							LOG.info("topPartId of Single record >> "+topPartId);
						}
					}
				    
				}
			 } catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getOmmReport: ", exception);
				fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"ommReportSearch","OMM Report");
			}
		}
		LOG.info("Exiting getOmmReport Method");
		return fwdflag;
	}
	
	
	public String runOmmReport() throws PWiException {
		LOG.info("Entering runOmmReport Method");
		String fwdflag = "ommReportSearch";
		  if (!PLMUtils.isEmpty(topPartId)) {
			  alertMessage = PLMConstants.OMM_MAIL_ALERT_MSG;
			  userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
	    	  taskExecutor.execute(new MailThread());
		  } else {
			  alertMessage = PLMConstants.OMM_SEARCH_CRITERIA;
		  }
		
		LOG.info("Exiting runOmmReport Method");
		return fwdflag;
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return void
	 */
	public void sendOmmReportThroughMail() {
		LOG.info("Entering sendOmmReportThroughMail Method");
		String serialNo = ommReportData.getSerialNo();
		String[] topPartIdNmArr = topPartId.split("~");
		String topPartIdLcl = topPartIdNmArr[0];
		String topPartNmLcl = topPartIdNmArr[1];
		String contractLcl = topPartIdNmArr[2];
		String from = PLMConstants.OMM_MAIL_FROM;

		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.OMM_MAIL_SUBJECT + serialNo;
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("OMM_BOM_EXPLOSION_REPORT_NAME") +  serialNo + "_" + uniqTime + ".xlsx";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("OMM_BOM_EXPLOSION_REPORT_NAME") +  serialNo + "_" + uniqTime + ".zip";
		try {
			//String contractNo = plmOmmReportService.getContractNo(serialNo);			
			 Map<String, List<PLMOmmReportData>> ommBomExplosionResultMap = plmOmmReportService.getOmmBomExplosionReport(topPartIdLcl,topPartNmLcl);
			//List<PLMOmmReportData> ommCustomerDocResultList = plmOmmReportService.getOmmCustomerDocReport(serialNo);
			List<PLMOmmReportData> ommCustomerDocResultList = new ArrayList<PLMOmmReportData>();
			List<PLMOmmReportData> ommSbomDeviationResultList = plmOmmReportService.getOmmSbomDeviationReport(serialNo);
			StringBuffer mailBody = new StringBuffer().append(toAddressee);
			if(PLMUtils.isEmptyMap(ommBomExplosionResultMap) && PLMUtils.isEmptyList(ommSbomDeviationResultList)){
				mailBody.append(PLMConstants.OMM_MAIL_CONTENT_NO_RECORD);
				mailBody.append(serialNo)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				PLMUtils.sendMail(from, to, subject, mailBody.toString());
			} else {
				mailBody.append(PLMConstants.OMM_MAIL_CONTENT);
				mailBody.append(serialNo)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				saveOmmXLSFile(serialNo,contractLcl,topPartNmLcl,ommBomExplosionResultMap,ommCustomerDocResultList,ommSbomDeviationResultList,fileDir,filePathXls);
				PLMUtils.generateZipFile(filePathXls,filePathZip);
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendOmmReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendOmmReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} finally {
			deleteFiles(filePathXls,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendOmmReportThroughMail Method");
	}
	
	/**
	 * This method is used for Deleting zip file and xls file
	 * 
	 * @return void
	 */
	public void deleteFiles(String filePathXls,String filePathZip){
		LOG.info("Entering deleteFiles method");
		boolean zipFileExist;
		boolean xlsFileExist;
		File zipFile = new File(filePathZip);
		zipFileExist = zipFile.exists();
		File xlsFile = new File(filePathXls);
		xlsFileExist = xlsFile.exists();
		if(zipFileExist){
			boolean deleted = zipFile.delete();
			LOG.info("Successfully deleted zip file : " + deleted);
		}
		if(xlsFileExist){
			boolean deleted = xlsFile.delete();
			LOG.info("Successfully deleted xls file : " + deleted);
		}
		LOG.info("Exiting deleteFiles Method");
	}
	
	/**
	 * This method is used for generating zip file
	 * 
	 * @return void
	 */
	/*public void generateZipFile(String filePathXls,String filePathZip) throws IOException {
		LOG.info("Entering generateZipFile method");
		FileOutputStream fileOut = null;
		BufferedOutputStream bufferOut = null;
		ZipOutputStream zipOut = null;
		BufferedInputStream bufferIn = null;
		FileInputStream fileIn = null;
		File xlsFile = new File(filePathXls); 
		try {
			fileOut = new FileOutputStream(filePathZip);
			bufferOut = new BufferedOutputStream(fileOut);
			zipOut = new ZipOutputStream(bufferOut);
			fileIn = new FileInputStream(filePathXls);
			bufferIn = new BufferedInputStream(fileIn);
			int count;
			byte[] data = new byte[1000];
			zipOut.putNextEntry(new ZipEntry(xlsFile.getName()));
			while((count = fileIn.read(data,0,1000)) != -1){  
			zipOut.write(data, 0, count);
			}
			bufferIn.close();
			zipOut.flush();
			zipOut.close();
   		   }catch (FileNotFoundException e) {
			 LOG.log(Level.ERROR, "Exception@generateZipFile: ", e);
			 throw e;
		   }catch (IOException e) {
			 LOG.log(Level.ERROR, "Exception@generateZipFile: ", e);
			 throw e;
		   }finally {
				try {
					if (bufferOut != null) {
						bufferOut.close();
					}
					if (zipOut != null) {
						zipOut.close();
					}
					if (fileOut != null) {
						fileOut.close();
					}
					if (fileIn != null) {
						fileIn.close();
					}
					if (bufferIn != null) {
						bufferIn.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@generateZipFile: ", e);
					throw e;
				}
			}
		LOG.info("Exiting generateZipFile Method");
	}*/
	
	/**
	 * This method is used for Bordering Cell in XLS
	 * 
	 * @return XSSFCellStyle
	 */
	
	private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
		style.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style.setBorderRight(XSSFCellStyle.BORDER_THIN);
		return style;
	}
	
	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return void
	 */
	
	public void saveOmmXLSFile(String serialNo,String contractNo,String topPartNm,
					Map<String, List<PLMOmmReportData>> ommBomExplosionResultMap,
					List<PLMOmmReportData> ommCustomerDocResultList,
					List<PLMOmmReportData> ommSbomDeviationResultList,String fileDir,String filePathXls) throws IOException {
		LOG.info("Entering saveOmmXLSFile Method");
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			List<PLMOmmReportData> ommBomExplosionResultList = new ArrayList<PLMOmmReportData>();
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXls);
				SXSSFWorkbook workbook = new SXSSFWorkbook();
				
				// Start : POI Styles
				XSSFFont boldFont = (XSSFFont) workbook.createFont();
				boldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				boldFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				XSSFFont normalFont = (XSSFFont) workbook.createFont();
				normalFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				XSSFFont noRecordFont = (XSSFFont) workbook.createFont(); 
				noRecordFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				noRecordFont.setColor(IndexedColors.RED.getIndex());
				noRecordFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				XSSFCellStyle titleStyle = (XSSFCellStyle) workbook.createCellStyle();
				titleStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
				titleStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
				titleStyle = setBorderStyle(titleStyle);
				titleStyle.setFont(noRecordFont);
				titleStyle.setAlignment(CellStyle.ALIGN_CENTER);
				XSSFCellStyle headerStyle = (XSSFCellStyle) workbook.createCellStyle();
				headerStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
				headerStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
				headerStyle = setBorderStyle(headerStyle);
				headerStyle.setFont(boldFont);
				headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
				XSSFCellStyle searchFieldNameStyle = (XSSFCellStyle) workbook.createCellStyle();
				searchFieldNameStyle = setBorderStyle(searchFieldNameStyle);
				searchFieldNameStyle.setFont(boldFont);
				searchFieldNameStyle.setAlignment(CellStyle.ALIGN_RIGHT);
				XSSFCellStyle cellBoldStyle = (XSSFCellStyle) workbook.createCellStyle();
				cellBoldStyle = setBorderStyle(cellBoldStyle);
				cellBoldStyle.setFont(boldFont);
				XSSFCellStyle contentStyle = (XSSFCellStyle) workbook.createCellStyle();				
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(normalFont);
				XSSFCellStyle noRecordCellStyle = (XSSFCellStyle) workbook.createCellStyle();
				noRecordCellStyle = setBorderStyle(noRecordCellStyle);
				noRecordCellStyle.setFont(noRecordFont);
				XSSFCellStyle contentDecimalStyle = (XSSFCellStyle) workbook.createCellStyle();				
				contentDecimalStyle = setBorderStyle(contentDecimalStyle);
				contentDecimalStyle.setFont(normalFont);
				DataFormat format = workbook.createDataFormat();
				contentDecimalStyle.setDataFormat(format.getFormat("0.00000"));
				// End : POI Styles
				
				SXSSFRow row = null;
				SXSSFCell cell = null;
				SXSSFSheet sheet =  null;
				boolean noSbomDataFlg=false;
				
				int rowcount = -1;
				int sheetCount = 0;
				int maxCol;
				
				
				if(!PLMUtils.isEmptyMap(ommBomExplosionResultMap)) {
					for (Map.Entry<String, List<PLMOmmReportData>> bomExplosionMap : ommBomExplosionResultMap.entrySet()) {
						ommBomExplosionResultList  = bomExplosionMap.getValue();	
						sheetCount++;
						rowcount = -1;
						//sheet = workbook.createSheet(serialNo);
						sheet = (SXSSFSheet) workbook.createSheet(serialNo + " - " + bomExplosionMap.getKey());
						// To display Search Criteria 
						row = (SXSSFRow) sheet.createRow(++rowcount);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						cell.setCellValue(PLMConstants.OMM_SEARCH_CRITERIA_SERIAL_NO);
						cell.setCellStyle(searchFieldNameStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellValue(serialNo);
						cell.setCellStyle(contentStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellValue("");
						row = (SXSSFRow) sheet.createRow(++rowcount);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						cell.setCellValue(PLMConstants.OMM_SEARCH_CRITERIA_CONTRACT_NAME);
						cell.setCellStyle(searchFieldNameStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellValue(contractNo);
						cell.setCellStyle(contentStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellValue("");
						row = (SXSSFRow) sheet.createRow(++rowcount);
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						cell.setCellValue(PLMConstants.OMM_SEARCH_PLANT_PART);
						cell.setCellStyle(searchFieldNameStyle);
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellValue(topPartNm);
						cell.setCellStyle(contentStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellValue("");
	
						// One Row Space
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						// Start : To display BOM Explosion Records
						// Title
						row = (SXSSFRow) sheet.createRow(++rowcount);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellValue(PLMConstants.OMM_REPORT_TITLE_BOM_EXPLOSION);
						cell.setCellStyle(titleStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(titleStyle);
						sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ONE));
						cell.setCellStyle(titleStyle);
						
										
						if(!PLMUtils.isEmptyList(ommBomExplosionResultList)) {
							//Header
							String[] bomColNames = {"BOM Level#", "Logical Indicator", "MLI", "Parent MLI", "PIN", "HPIN", "SUFFIX", "TYPE", "Part#", "Part Rev", "Part State", "Part Desc", "Part Family", "Part Family Title", "Quantity", "Part UOM", "Security Class", "Export Class", "GE Drg Critical Code", "Record Id"};
							row = (SXSSFRow) sheet.createRow(++rowcount);
							for ( int i = 0 ; i < bomColNames.length; i++ ) {
								cell = (SXSSFCell) row.createCell(i);
								cell. setCellValue(bomColNames[i]);
								cell.setCellStyle(headerStyle);
							}
							String pin = "";
							String parentMLI = "";
							String hPIN = "";
							int bomLvl = 0;
							boolean flag = true;
							String parentName = "";
							String prevparentName = "";
							boolean prevFlag = true;
							//Header
							for(int i = 0; i < ommBomExplosionResultList.size(); i++) {
								PLMOmmReportData dataObj = (PLMOmmReportData) ommBomExplosionResultList.get(i);
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								bomLvl = dataObj.getBomLevel();
								parentName = dataObj.getParentName();
								
								if (bomLvl == 1) {
									flag = false;
									parentMLI = "";
									hPIN = "";
								} else if (bomLvl == 2 && dataObj.getPartFamily().equalsIgnoreCase(resourceBundle.getString("OMM_PF_EXCLUSION"))) {
									flag = false;
									parentMLI = "";
									hPIN = "";
									prevFlag = flag;
								} else if (bomLvl > 2 || (bomLvl == 2 
										&& !dataObj.getPartFamily().equalsIgnoreCase(resourceBundle.getString("OMM_PF_EXCLUSION")))) {
									flag = true;
								}
									
								if (flag) {
									
									if(!pin.equals(dataObj.getPin()) && !dataObj.getPin().equals("")){
											parentMLI = dataObj.getMli();
											hPIN = dataObj.getPin();
									}
									
									if (!prevFlag) {
										if (prevparentName.equals(parentName)) {
											parentMLI = "";
											hPIN = "";
										} else {
											prevFlag = true;
										}
									}
								}
								
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getBomLevel());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getLogicalIndicator());
					
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getMli());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(parentMLI);
					
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPin());
					
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(hPIN);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getSuffix());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getType());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartNo());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartRev());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartState());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartDesc());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWELVE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartFamily());						
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartFamilyTitle());		
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
								cell.setCellStyle(contentStyle);
								if(dataObj.getType()!=null && dataObj.getType().toUpperCase(Locale.getDefault()).contains("PART")){
									cell.setCellValue(dataObj.getQty());
								} else {
									cell.setCellValue("");
								}
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartUom());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getSecurityClass());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getExportClass());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getGeDwgCriticalCode());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINETEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(i+1);				    // needs to remove the comment while deployment 
								//cell.setCellValue(dataObj.getRecordId());  // for testing purpose - need to comment while deployment
								
								pin = dataObj.getPin();
								prevparentName = dataObj.getParentName();
							}
						}
						else {
							LOG.info("No BOM Explosion Records found");
							row = (SXSSFRow) sheet.createRow(++rowcount);
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell.setCellValue(PLMConstants.OMM_NO_RECORD_FOUND);
							cell.setCellStyle(noRecordCellStyle);
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellStyle(noRecordCellStyle);
							sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ONE));
						}
					}//end of for loop ommBomExplosionResultMap
				}//end of if isEmptyMap(ommBomExplosionResultMap)
				else {
					sheetCount ++;
					rowcount = -1;					
					sheet = (SXSSFSheet) workbook.createSheet(serialNo);
					// To display Search Criteria 
					row = (SXSSFRow) sheet.createRow(++rowcount);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					cell.setCellValue(PLMConstants.OMM_SEARCH_CRITERIA_SERIAL_NO);
					cell.setCellStyle(searchFieldNameStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellValue(serialNo);
					cell.setCellStyle(contentStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellValue("");
					row = (SXSSFRow) sheet.createRow(++rowcount);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					cell.setCellValue(PLMConstants.OMM_SEARCH_CRITERIA_CONTRACT_NAME);
					cell.setCellStyle(searchFieldNameStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellValue(contractNo);
					cell.setCellStyle(contentStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellValue("");

					// One Row Space
					row = (SXSSFRow) sheet.createRow(++rowcount);
					
					// Start : To display BOM Explosion Records
					// Title
					row = (SXSSFRow) sheet.createRow(++rowcount);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellValue(PLMConstants.OMM_REPORT_TITLE_BOM_EXPLOSION);
					cell.setCellStyle(titleStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(titleStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ONE));
					cell.setCellStyle(titleStyle);
					
					
					LOG.info("No BOM Explosion Records found");
					row = (SXSSFRow) sheet.createRow(++rowcount);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					cell.setCellValue(PLMConstants.OMM_NO_RECORD_FOUND);
					cell.setCellStyle(noRecordCellStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(noRecordCellStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ONE));
				}
				// End : To display BOM Explosion Records
				/*
				// Three Row Space
				row = sheet.createRow(++rowcount);
				row = sheet.createRow(++rowcount);
				row = sheet.createRow(++rowcount);
				
				// Start : To display Customer Document Records
				// Title
				row = sheet.createRow(++rowcount);
				cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellValue(PLMConstants.OMM_REPORT_TITLE_CUSTOMER_DOCUMENTS);
				cell.setCellStyle(titleStyle);
				cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellStyle(titleStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ONE));
				cell.setCellStyle(titleStyle);

				if(!PLMUtils.isEmptyList(ommCustomerDocResultList)) {
					// Header
					String[] customerDocColNames = {"Doc Name","Doc Revision","Doc State","Doc Description"};
					row = sheet.createRow(++rowcount);
					for ( int i = 0 ; i < customerDocColNames.length; i++ ) {
						cell = row.createCell(i);
						cell. setCellValue(customerDocColNames[i]);
						cell.setCellStyle(headerStyle);
					}
					for(int i = 0; i < ommCustomerDocResultList.size(); i++) {
						PLMOmmReportData dataObj = (PLMOmmReportData) ommCustomerDocResultList.get(i);
						row = sheet.createRow(++rowcount);
						
						cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getDocName());
						
						cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getDocRev());
						
						cell = row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getDocState());
						
						cell = row.createCell(PLMConstants.EXCEL_COL_THREE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getDocDesc());
					}
				} else {
					LOG.info("No Customer Document Records found");
					row = sheet.createRow(++rowcount);
					cell = row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					cell.setCellValue(PLMConstants.OMM_NO_RECORD_FOUND);
					cell.setCellStyle(noRecordCellStyle);
					cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(noRecordCellStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ONE));
				}
				// End : To display Customer Document Records
				*/
				// Three Row Space
				
				//Make sure thata SBOM data is added to First Sheet of Workbook
				int sheetSize = workbook.getNumberOfSheets();
				for (int x = 0; x < sheetSize; x++ ) {
				sheet =   (SXSSFSheet) workbook.getSheetAt(x);				
				rowcount = sheet.getLastRowNum();				
				 
				
				row = (SXSSFRow) sheet.createRow(++rowcount);
				row = (SXSSFRow) sheet.createRow(++rowcount);
				row = (SXSSFRow) sheet.createRow(++rowcount);
								
				// Start : To display SBOM Deviation Records
				// Title
				row = (SXSSFRow) sheet.createRow(++rowcount);
				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellValue(PLMConstants.OMM_REPORT_TITLE_SBOM_DEVIATIONS);
				cell.setCellStyle(titleStyle);
				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellStyle(titleStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ONE));
				cell.setCellStyle(titleStyle);
								
				if(!PLMUtils.isEmptyList(ommSbomDeviationResultList)) {
					// Header
					String[] sbomColNames = {"TURBINE_NO","PIN","NEW_ITEM","OLD_ITEM","SECTION","REVISION_NO","AUTHORIZATION","DESCRIPTION","DATE_APPLIED","QUANTITY","AN_NO","AUTHOR","AUTHOR_FIRST_NAME","AUTHOR_LAST_NAME","CATEGORY_NO","LOCATION","PARENT_PIN"};
					row = (SXSSFRow) sheet.createRow(++rowcount);
					for ( int i = 0 ; i < sbomColNames.length; i++ ) {
						cell = (SXSSFCell) row.createCell(i);	
						cell. setCellValue(sbomColNames[i]);
						cell.setCellStyle(headerStyle);
					}
					
					for(int i = 0; i < ommSbomDeviationResultList.size(); i++) {
						PLMOmmReportData dataObj = (PLMOmmReportData) ommSbomDeviationResultList.get(i);
						row = (SXSSFRow) sheet.createRow(++rowcount);

						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getTurbineNo());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getPin());
			
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getNewItem());
			
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getOldItem());
			
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getSection());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getRevisonNo());

						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAuthorization());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getDescription());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
						cell.setCellStyle(contentStyle);
						if(dataObj.getDateApplied() != null){
							cell.setCellValue(dateFormat.format(dataObj.getDateApplied()));
						} else {
							cell.setCellValue("");
						}
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getQty());
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAnNum());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAuthor());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWELVE);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAuthorFn());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getAuthorLn());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getCatNo());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getLocation());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
						cell.setCellStyle(contentStyle);
						cell.setCellValue(dataObj.getParentPin());
					}
				} else {
					LOG.info("No SBOM Deviation Records found");
					noSbomDataFlg=true;
					row = (SXSSFRow) sheet.createRow(++rowcount);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					cell.setCellValue(PLMConstants.OMM_NO_RECORD_FOUND);
					cell.setCellStyle(noRecordCellStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(noRecordCellStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ONE));
				}
				// End : To display SBOM Deviation Records
				
			}
				// Setting Autofit and Width
				/*if(!PLMUtils.isEmptyList(ommSbomDeviationResultList)){
					maxCol = PLMConstants.EXCEL_COL_SIXTEEN;
				} else if (!PLMUtils.isEmptyList(ommBomExplosionResultList)){
					maxCol = PLMConstants.EXCEL_COL_FIFTEEN;
				} else if (!PLMUtils.isEmptyList(ommCustomerDocResultList)){
					maxCol = PLMConstants.EXCEL_COL_THREE;
				} else {
					maxCol = PLMConstants.EXCEL_COL_ONE;
				}*/
				maxCol = PLMConstants.EXCEL_COL_NINETEEN;
				for (int i = 0; i < sheetCount; i++) {					
					sheet = (SXSSFSheet) workbook.getSheetAt(i);
					for (int colIndex = 0 ; colIndex <= maxCol; colIndex ++) {
						sheet.autoSizeColumn(colIndex);
					}
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, 5000);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, 5000);
					if(!noSbomDataFlg){
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,5000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,5000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,5000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,5000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,7000);
					}else{
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,2500);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,3000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,2000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,2000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,3000);
					}
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN, 7200);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT, 5000);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE, 3000);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN, 3000);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN, 10000);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWELVE, 10000);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTEEN, 5500);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTEEN, 5000);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTEEN, 3000);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIXTEEN, 5500);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVENTEEN, 5200);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHTEEN, 6000);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINETEEN, 3000);
				}
				
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveOmmXLSFile: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveOmmXLSFile: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveOmmXLSFile: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveOmmXLSFile Method");
	}

	
	/**
	 * This method is used for Validating OMM User Input
	 * 
	 * @return String
	 */
	public String validateOmmInput() {
		LOG.info("Entering validateOmmInput Method");
		LOG.info("Entered Serial No : " + ommReportData.getSerialNo());
		String alertMsg = "";
		if(PLMUtils.isEmpty(ommReportData.getSerialNo())){
			alertMsg = PLMConstants.OMM_SEARCH_CRITERIA;
		} else if(!PLMUtils.checkForSpecialChars(ommReportData.getSerialNo())){
			alertMsg = PLMConstants.OMM_SERIAL_NO_SPLCHAR_CRITERIA;
		}
		LOG.info("Exiting validateOmmInput Method");
		return alertMsg;
	}

	/**
	 * This method is used for Resetting the User input
	 * 
	 * @return String
	 */
	
	public String resetData() {
		LOG.info("Entering OMM Reset Method");
		String fwdflag = "ommReportSearch";
		if (ommReportData.getSerialNo() != null)
			ommReportData.setSerialNo("");
		LOG.info("Exiting OMM Reset Method");
		return fwdflag;
	}

	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}

	/**
	 * @param log the lOG to set
	 */
	public static void setLOG(Logger log) {
		LOG = log;
	}

	/**
	 * @return the ommReportData
	 */
	public PLMOmmReportData getOmmReportData() {
		return ommReportData;
	}

	/**
	 * @param ommReportData the ommReportData to set
	 */
	public void setOmmReportData(PLMOmmReportData ommReportData) {
		this.ommReportData = ommReportData;
	}

	/**
	 * @return the plmOmmReportService
	 */
	public PLMOmmReportServiceIfc getPlmOmmReportService() {
		return plmOmmReportService;
	}

	/**
	 * @param plmOmmReportService the plmOmmReportService to set
	 */
	public void setPlmOmmReportService(PLMOmmReportServiceIfc plmOmmReportService) {
		this.plmOmmReportService = plmOmmReportService;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the topPartListCount
	 */
	public int getTopPartListCount() {
		return topPartListCount;
	}

	/**
	 * @param topPartListCount the topPartListCount to set
	 */
	public void setTopPartListCount(int topPartListCount) {
		this.topPartListCount = topPartListCount;
	}

	/**
	 * @return the topPartList
	 */
	public List<PLMOmmReportData> getTopPartList() {
		return topPartList;
	}

	/**
	 * @param topPartList the topPartList to set
	 */
	public void setTopPartList(List<PLMOmmReportData> topPartList) {
		this.topPartList = topPartList;
	}
	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}
	
	public void setRecordCounts(int recordCounts) {
		LOG.info("::::::::::::::::::" + recordCounts);
		PLMUtils.getServletSession(true).setAttribute("RecDropDown",
				recordCounts);
		this.recordCounts = recordCounts;
	}

	/**
	 * @return the topPartId
	 */
	public String getTopPartId() {
		return topPartId;
	}
	/**
	 * @param topPartId the topPartId to set
	 */
	public void setTopPartId(String topPartId) {
		this.topPartId = topPartId;
	}

	
	
}