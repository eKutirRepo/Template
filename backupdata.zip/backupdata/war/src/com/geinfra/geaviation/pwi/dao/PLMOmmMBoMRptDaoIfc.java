/**
 * Copyright (C) 2012 GE Infra. 
 * All rights reserved 
 * @FileName PLMOmmMBoMRptDaoIfc.java
 * @Creation date: 26-April-2016
 * @version 2.0.1
 * @author : Tech Mahindra (PLMR Team) 
 */



package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.data.PLMOmmMBoMRptData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMOmmMBoMRptDaoIfc {
	/**
	 * This method is used for checkForValidPartNum
	 * 
	 * @param partNo
	 * @return int
	 * @throws PLMCommonException
	 */
	public int checkForValidPartNum(String partNo) throws PLMCommonException;
	/**
	 * This method is used for getOmmMBomExplosionReport
	 * 
	 * @param topPartId
	 * @return partNo
	 * @throws PLMCommonException
	 */
	public List<PLMOmmMBoMRptData> getOmmMBomExplosionReport(String partNo) throws PLMCommonException;
	/**
	 * This method is used for getOmmSbomDeviationReport
	 * 
	 * @param partNo
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMOmmMBoMRptData> getOmmSbomDeviationReport(String partNo) throws PLMCommonException;
	
}