/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMTrendReportDaoImpl.java
 * @Creation date: 15-June-2011
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMMbomTrendData;
import com.geinfra.geaviation.pwi.data.PLMPartTrendsData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMMetricsQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMTrendReportDaoImpl extends SimpleJdbcDaoSupport implements
		PLMTrendReportDaoIfc {

	/**
	 * Holds the Logger
	 */
	private static final Logger LOG = Logger.getLogger(PLMTrendReportDaoImpl.class);
	/**
	 * This method is used for getMbomTrendReport
	 * 
	 * @param mlno
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMMbomTrendData> getMbomTrendReport(String mlno)throws PLMCommonException {
		LOG.info("Entering getMbomTrendReport Method");
		List<PLMMbomTrendData> searchResultList = new ArrayList<PLMMbomTrendData>();
		try{
		LOG.info("MBOM Child Item Prefix Query : " + PLMMetricsQueries.MBOM_TREND1);
		List<PLMMbomTrendData> searchResultList1 = getSimpleJdbcTemplate().query(PLMMetricsQueries.MBOM_TREND1, new MbomPartMapper1(), mlno);
		LOG.info("Total Results : " + searchResultList1.size());
		LOG.info("MBOM Is Item Prefix Query : " + PLMMetricsQueries.MBOM_TREND2);
		List<PLMMbomTrendData> searchResultList2 = getSimpleJdbcTemplate().query(PLMMetricsQueries.MBOM_TREND2, new MbomPartMapper2(), mlno);
		LOG.info("Total Results : " + searchResultList2.size());
		
		if(!PLMUtils.isEmptyList(searchResultList1) && !PLMUtils.isEmptyList(searchResultList2)) {
			for(int i=0;i<searchResultList1.size();i++) {
				for(int j = 0; j < searchResultList2.size(); j++) {
					if(searchResultList1.get(i).getMfgrespcode().equalsIgnoreCase(searchResultList2.get(j).getMfgrespcode())) {
						searchResultList1.get(i).setNoofchangerevision(searchResultList2.get(j).getNoofchangerevision());
						searchResultList2.remove(j);
					}
				}
			}
			searchResultList.addAll(searchResultList1);
			searchResultList.addAll(searchResultList2);
		} else if (!PLMUtils.isEmptyList(searchResultList1)) { 
			searchResultList.addAll(searchResultList1);
		} else {
			searchResultList.addAll(searchResultList2);
		}		
		LOG.info("Exiting getMbomTrendReport Method");
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return searchResultList;
	}	

	/**
	 * Mapper for Getting mbom part Data1
	 */
	//private static ParameterizedRowMapper<PLMMbomTrendData> mbomPartMapper1 = new ParameterizedRowMapper<PLMMbomTrendData>() {
	private static final class MbomPartMapper1 implements ParameterizedRowMapper<PLMMbomTrendData>{ 	
	public PLMMbomTrendData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMMbomTrendData tempPartData = new PLMMbomTrendData();
			tempPartData.setMfgrespcode(PLMUtils.checkNullVal(rs.getString("CHILD_ITEM_PREFIX")));
			tempPartData.setTotalnoparts(rs.getInt("TOTAL_BOM_COUNT"));
			return tempPartData;
		}
	//	};
	}
	
	/**
	 * Mapper for Getting mbom part Data2
	 */

	//private static ParameterizedRowMapper<PLMMbomTrendData> mbomPartMapper2 = new ParameterizedRowMapper<PLMMbomTrendData>() {
	private static final class MbomPartMapper2	implements ParameterizedRowMapper<PLMMbomTrendData>{
	public PLMMbomTrendData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMMbomTrendData tempPartData = new PLMMbomTrendData();
			tempPartData.setMfgrespcode(PLMUtils.checkNullVal(rs.getString("IS_ITEM_PREFIX")));
			tempPartData.setNoofchangerevision(rs.getInt("COUNT_OF_CHANGES"));
			return tempPartData;
		}
	//	};
	}
	/**
	 * Mapper for Getting part Data
	 */
	//private static ParameterizedRowMapper<PLMPartTrendsData> partDataMapper = new ParameterizedRowMapper<PLMPartTrendsData>() {
	private static final class PartDataMapper implements ParameterizedRowMapper<PLMPartTrendsData>{	
	public PLMPartTrendsData mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PLMPartTrendsData result = new PLMPartTrendsData();
			result.setRdoName(rs.getString(PLMUtils.checkNullVal(PLMConstants.FINAL_RDO)));
			result.setNewPart(rs.getInt(PLMConstants.NEW_PART));
			result.setPartChangeInitiation(rs.getInt(PLMConstants.PART_CHANGE_INITIATION));
			result.setPartChangeRevision(rs.getInt(PLMConstants.PART_CHANGE_REVISION));
			result.setIssueAgainstPart(rs.getInt(PLMConstants.ISSUE_AGAINST_PART));
			return result;
		}
	//	};
	}
	
	/**
	 * This method is used for getpartTrendSearchData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMPartTrendsData> getpartTrendSearchData(StringBuffer searchResultsQry) throws PLMCommonException {
		LOG.info("Entering getpartTrendSearchData Method");
		LOG.info("Query for Part Trend Search : " + searchResultsQry.toString());
		List<PLMPartTrendsData> searchResultPart = null;
		try{
		searchResultPart = getSimpleJdbcTemplate().query(searchResultsQry.toString(),new PartDataMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getpartTrendSearchData Method");
		return searchResultPart;
	}
	/**
	 * This method is used for getPartDropDownvalues
	 * 
	 * @param searchResultsQry
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getPartDropDownvalues(StringBuffer searchResultsQry) throws PLMCommonException {
		LOG.info("Entering getPartDropDownvalues Method");
		Map<String, List<SelectItem>> dropdownlist = new HashMap<String, List<SelectItem>>();
		List<SelectItem> rdolist = null;
		try{
		LOG.info("Query for RDO MultiSelect Dropdown List : " + searchResultsQry.toString());
		rdolist = getSimpleJdbcTemplate().query(searchResultsQry.toString(),new DropMapper());
		dropdownlist.put("rdolist", rdolist);
		LOG.info("Exiting getPartDropDownvalues Method");
		}catch(DataAccessException e){
		PLMUtils.checkException(e.getMessage());
		}
		return dropdownlist;
	}
	/**
	 * Mapper for Getting RDO Names
	 */
	//private static ParameterizedRowMapper<SelectItem> dropMapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class DropMapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs.getString(PLMConstants.RDO_NAME));
			return selectItem;
		}
	//	};
	}
}