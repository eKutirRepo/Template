package com.geinfra.geaviation.pwi.bean.util;

import javax.faces.context.FacesContext;

import com.geinfra.geaviation.pwi.bean.AdminObjectTypeEditorBean;
import com.geinfra.geaviation.pwi.bean.AdminQueryEditorBean;
import com.geinfra.geaviation.pwi.bean.AdminRoleEditorBean;
import com.geinfra.geaviation.pwi.bean.AdminUserEditorBean;
import com.geinfra.geaviation.pwi.bean.AdminUserListBean;
import com.geinfra.geaviation.pwi.bean.ApplicationParametersBean;
import com.geinfra.geaviation.pwi.bean.FavoriteFromHistoryDialogBean;
import com.geinfra.geaviation.pwi.bean.PLMReportsMB;
import com.geinfra.geaviation.pwi.bean.PLMWhereUsedMB;
import com.geinfra.geaviation.pwi.bean.QiBean;
import com.geinfra.geaviation.pwi.bean.QueriesBean;
import com.geinfra.geaviation.pwi.bean.QueryBuilderBean;
import com.geinfra.geaviation.pwi.bean.QueryListBean;
import com.geinfra.geaviation.pwi.bean.QueryResultRequestBean;
import com.geinfra.geaviation.pwi.bean.QueryResultRequestBean.QueryResultViewBeanCache;
import com.geinfra.geaviation.pwi.bean.QuerySubmissionControllerBean;
import com.geinfra.geaviation.pwi.bean.RptTypeRelationBean;

/**
 * Project : Product Lifecycle Management Date Written : Apr 12, 2011 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : Provides convenience methods for working with backing beans
 * 
 * Revision Log Apr 12, 2011 | v1.0.
 * --------------------------------------------------------------
 */
public class BeanUtil {
	private static final String SESSION_ATTRIBUTE_SESSION_BEAN_CACHE = "pwi.QueryResultBean";

	private static final BeanUtil INSTANCE = new BeanUtil();

	private BeanUtil() {
		// private because singleton
		// nothing to do
	}

	public static BeanUtil getInstance() {
		// Implementing utility class as a singleton rather than using static
		// methods because classes with only static methods are flagged as
		// a violation in the SQDB code review (specifically the PMD Report).
		// Getting an exception might be possible, but would have to be
		// gotten every time there is a code review.
		return INSTANCE;
	}

	public AdminQueryEditorBean getAdminQueryEditorBean() {
		return (AdminQueryEditorBean) FacesContext.getCurrentInstance()
				.getApplication().getELResolver().getValue(
						FacesContext.getCurrentInstance().getELContext(), null,
						"adminQueryEditorBean");
	}

	public AdminObjectTypeEditorBean getAdminObjectTypeEditorBean() {
		return (AdminObjectTypeEditorBean) FacesContext.getCurrentInstance()
				.getApplication().getELResolver().getValue(
						FacesContext.getCurrentInstance().getELContext(), null,
						"adminObjectTypeEditorBean");
	}
	
	public QueryListBean getQueryListBean() {
			return (QueryListBean) FacesContext.getCurrentInstance()
				.getApplication().getELResolver().getValue(
						FacesContext.getCurrentInstance().getELContext(), null,
						"queryListBean");
	}

	public QueryBuilderBean getQueryBuilderBean() {
		return (QueryBuilderBean) FacesContext.getCurrentInstance()
				.getApplication().getELResolver().getValue(
						FacesContext.getCurrentInstance().getELContext(), null,
						"queryBuilderBean");
	}

	public QueriesBean getQueriesBean() {
		return (QueriesBean) FacesContext.getCurrentInstance().getApplication()
				.getELResolver().getValue(
						FacesContext.getCurrentInstance().getELContext(), null,
						"queriesBean");
	}
	
	public RptTypeRelationBean getRptTypeRelationBean() {
		return (RptTypeRelationBean) FacesContext.getCurrentInstance().getApplication()
				.getELResolver().getValue(
						FacesContext.getCurrentInstance().getELContext(), null,
						"rpttyperelationbean");
	}
	
	public QueryResultRequestBean getQueryResultBean() {
		return (QueryResultRequestBean) FacesContext.getCurrentInstance()
				.getApplication().getELResolver().getValue(
						FacesContext.getCurrentInstance().getELContext(), null,
						"queryResultBean");
	}

	public FavoriteFromHistoryDialogBean getFavoriteFromHistoryDialogBean() {
		return (FavoriteFromHistoryDialogBean) FacesContext
				.getCurrentInstance().getApplication().getELResolver()
				.getValue(FacesContext.getCurrentInstance().getELContext(),
						null, "favoriteFromHistoryDialogBean");
	}

	// TODO remove old QI beans? (and other request-scoped beans?)
	public QiBean getQiBean() {
		return (QiBean) FacesContext.getCurrentInstance().getApplication()
				.getELResolver().getValue(
						FacesContext.getCurrentInstance().getELContext(), null,
						"qiBean");
	}
	public QuerySubmissionControllerBean getQuerySubmissionControllerBean() {
		return (QuerySubmissionControllerBean) FacesContext
				.getCurrentInstance().getApplication().getELResolver()
				.getValue(FacesContext.getCurrentInstance().getELContext(),
						null, "querySubmissionControllerBean");
	}
	
	public QueryResultViewBeanCache getConversationBeanCache() {
		
		QueryResultViewBeanCache cache = (QueryResultViewBeanCache) FacesContext
				.getCurrentInstance().getExternalContext().getSessionMap().get(
						SESSION_ATTRIBUTE_SESSION_BEAN_CACHE);
		if (cache == null) {
			cache = new QueryResultViewBeanCache();
			FacesContext.getCurrentInstance().getExternalContext()
					.getSessionMap().put(SESSION_ATTRIBUTE_SESSION_BEAN_CACHE,
							cache);
		}
		return cache;
	}
	public AdminRoleEditorBean getAdminRoleEditorBean() {
		return (AdminRoleEditorBean) FacesContext.getCurrentInstance()
				.getApplication().getELResolver().getValue(
						FacesContext.getCurrentInstance().getELContext(), null,
						"adminRoleEditorBean");
	}
	public AdminUserEditorBean getAdminUserEditorBean() {
		return (AdminUserEditorBean) FacesContext.getCurrentInstance()
				.getApplication().getELResolver().getValue(
						FacesContext.getCurrentInstance().getELContext(), null,
						"adminUserEditorBean");
	}
	
	public ApplicationParametersBean getApplicationParametersBean() {
		return (ApplicationParametersBean) FacesContext.getCurrentInstance()
				.getApplication().getELResolver().getValue(
						FacesContext.getCurrentInstance().getELContext(), null,
						"applicationParametersBean");
	}
	
	public PLMWhereUsedMB getPLMWhereUsedMB() {
		return (PLMWhereUsedMB) FacesContext.getCurrentInstance()
			.getApplication().getELResolver().getValue(
					FacesContext.getCurrentInstance().getELContext(), null,
					"plmWhereUsedMB");
	}

	public AdminUserListBean getAdminUserListBean() {
		return (AdminUserListBean) FacesContext.getCurrentInstance()
				.getApplication().getELResolver().getValue(
						FacesContext.getCurrentInstance().getELContext(), null,
						"adminUserListBean");
	}

	public PLMReportsMB getSysLogMB() {
		return (PLMReportsMB) FacesContext.getCurrentInstance()
				.getApplication().getELResolver().getValue(
						FacesContext.getCurrentInstance().getELContext(), null,
						"syslogBean");
	}

}
