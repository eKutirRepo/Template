/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMPddrSearchData.java
 * @Creation date: 29-Sep-2009
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.data;

import java.util.Date;
import java.util.List;

import javax.faces.model.ListDataModel;
import javax.faces.model.SelectItem;

/**
 * PLMPddrSearchData is the Transfer/Value Object class for ICM search.
 */
public class PLMPddrSearchData {

	// Added by Kishore
	/**
	 * The String itemType.
	 */
	private String itemType;
	/**
	 * The String mliText.
	 */
	private String mliText;
	/**
	 * The String authEc.
	 */
	private String authEc;
	/**
	 * The String radioType.
	 */
	private String radioType;
	/**
	 * The String productLineSD.
	 */
	private String productLineSD;
	/**
	 * The String mplMLnumberSD.
	 */
	private String mplMLnumberSD;
	/**
	 * The String serialNumberSD.
	 */
	private String serialNumberSD;
	/**
	 * The String designNumberSD.
	 */
	private String designNumberSD;
	/**
	 * The int sectionSD.
	 */
	private String sectionSD;
	/**
	 * The String customerNameSD.
	 */
	private String customerNameSD;
	/**
	 * The String siteLocationSD.
	 */
	private String siteLocationSD;
	/**
	 * The String siteLocationHD.
	 */
	private String siteLocationHD;
	/**
	 * The int stateOfPartSD.
	 */
	private int stateOfPartSD;
	/**
	 * The int confStatusSD.
	 */
	private int confStatusSD;
	/**
	 * The int shippableSD.
	 */
	private int shippableSD;
	/**
	 * The String shipFromDateSD.
	 */
	private String shipFromDateSD;
	/**
	 * The String shipToDateSD.
	 */
	private String shipToDateSD;

	// Header information
	/**
	 * The String mplMLnumberHD.
	 */
	private String mplMLnumberHD;
	/**
	 * The String pinHD.
	 */
	private String pinHD;
	/**
	 * The String serialHD.
	 */
	private String serialHD;
	/**
	 * The String customerHD.
	 */
	private String customerHD;
	/**
	 * The String designHD.
	 */
	private String designHD;
	/**
	 * The String sectionHD.
	 */
	private String sectionHD;
	/**
	 * The Date smipBTHD.
	 */
	private Date smipBTHD;
	/**
	 * The String headerCommentsHD.
	 */
	private String headerCommentsHD;
	/**
	 * The List <SelectItem> searchMplSelect.
	 */
	private List<SelectItem> searchMplSelect;
	/**
	 * The List <ICMSearchData> displayHeader.
	 */
	private List<PLMPddrSearchData> displayHeader;

	/**
	 * The String requestorName.
	 */
	private String requestorName;
	/**
	 * The String machineType.
	 */
	private String machineType;
	/**
	 * The String business.
	 */
	private String business;
	/**
	 * The String orderNumber.
	 */
	//private String orderNumber;
	/**
	 * The String model.
	 */
	private String model;
	/**
	 * The String mliCostCode.
	 */
	private String mliCostCode;
	/**
	 * The String source.
	 */
	private String source;
	/**
	 * The String region.
	 */
	private String region;
	/**
	 * The String designMemo.
	 */
	private String designMemo;
	/**
	 * The Date shipDate.
	 */
	private Date shipDate;
	/**
	 * The String shipDt.
	 */
	private String shipDt;

	/**
	 * The String frameSize.
	 */
	private String frameSize;

	// Detail information

	/**
	 * The ListDataModel detailDataModel.
	 */
	private ListDataModel detailDataModel;
	/**
	 * The String mplNum.
	 */
	private String mplNum;
	/**
	 * Holds the State Of Parts List
	 */
	private List<SelectItem> stateOfPartsData;
	/**
	 * Holds the Config Status List
	 */
	private List<SelectItem> configStatusData;
	/**
	 * Holds the Section Status List
	 */
	private List<SelectItem> sectionData;
	/**
	 * Holds the Shippable Data List
	 */
	private List<SelectItem> shippableData;
	/**
	 * Holds the Ship date
	 */
	private String shipDate1;
	/**
	 * Holds the sourceHD
	 */
	private String sourceHD;
	/**
	 * Holds the custDet
	 */
	private String custDet;
	/**
	 * Holds the locDet
	 */
	private String locDet;
	/**
	 * Holds the productLineHD
	 */
	private String productLineHD;
	// Added by Kishore
	/**
	 * Holds the Configuration Item Authorization ID
	 */
	private String authrznid;
	/**
	 * The String description.
	 */
	private String description;
	/**
	 * The String authEC.
	 */
	private String authEC;
	/**
	 * The String pin.
	 */
	private String pin;
	/**
	 * The String quantity.
	 */
	private String quantity;
	/**
	 * The String entryDt.
	 */
	private String entryDt;
	/**
	 * The String ursData.
	 */
	private String ursData;
	/**
	 * The String suffixData.
	 */
	private String suffixData;
	
	private String libraryName;
	
	

	/**
	 * @return the libraryName
	 */
	public String getLibraryName() {
		return libraryName;
	}

	/**
	 * @param libraryName the libraryName to set
	 */
	public void setLibraryName(String libraryName) {
		this.libraryName = libraryName;
	}

	/**
	 * @return
	 */
	public String getMplNum() {
		return mplNum;
	}

	/**
	 * @return List <SelectItem> getStateOfPartsData
	 */
	public List<SelectItem> getStateOfPartsData() {
		return stateOfPartsData;
	}

	/**
	 * @param stateOfPartsData
	 */
	public void setStateOfPartsData(List<SelectItem> stateOfPartsData1) {
		stateOfPartsData = stateOfPartsData1;
	}

	/**
	 * @return List <SelectItem> getConfigStatusData
	 */
	public List<SelectItem> getConfigStatusData() {
		return configStatusData;
	}

	/**
	 * @param configStatusData
	 */
	public void setConfigStatusData(List<SelectItem> configStatusData1) {
		configStatusData = configStatusData1;
	}

	/**
	 * @return List <SelectItem> getSectionData
	 */
	public List<SelectItem> getSectionData() {
		return sectionData;
	}

	/**
	 * @param configStatusData
	 */
	public void setSectionData(List<SelectItem> sectionData1) {
		sectionData = sectionData1;
	}

	/**
	 * @return List <SelectItem> getShippableData
	 */
	public List<SelectItem> getShippableData() {
		return shippableData;
	}

	/**
	 * @param shippableData
	 */
	public void setShippableData(List<SelectItem> shippableData1) {
		shippableData = shippableData1;
	}

	/**
	 * @param mplNum
	 */
	public void setMplNum(String mplNum1) {
		mplNum = mplNum1;
	}

	/**
	 * @return the detailDataModel
	 */
	public ListDataModel getDetailDataModel() {
		return detailDataModel;
	}

	/**
	 * @param detailDataModel
	 *            the detailDataModel to set
	 */
	public void setDetailDataModel(ListDataModel detailDataModel1) {
		detailDataModel = detailDataModel1;
	}

	/**
	 * @return the requestorName
	 */
	public String getRequestorName() {
		return requestorName;
	}

	/**
	 * @param requestorName
	 *            the requestorName to set
	 */
	public void setRequestorName(String requestorName1) {
		requestorName = requestorName1;
	}

	/**
	 * @return the machineType
	 */
	public String getMachineType() {
		return machineType;
	}

	/**
	 * @param machineType
	 *            the machineType to set
	 */
	public void setMachineType(String machineType1) {
		machineType = machineType1;
	}

	/**
	 * @return the business
	 */
	public String getBusiness() {
		return business;
	}

	/**
	 * @param business
	 *            the business to set
	 */
	public void setBusiness(String business1) {
		business = business1;
	}

	/**
	 * @return the orderNumber
	 */
	/*public String getOrderNumber() {
		return orderNumber;
	}*/

	/**
	 * @param orderNumber
	 *            the orderNumber to set
	 */
	/*public void setOrderNumber(String orderNumber1) {
		orderNumber = orderNumber1;
	}*/

	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * @param model
	 *            the model to set
	 */
	public void setModel(String model1) {
		model = model1;
	}

	/**
	 * @return the mliCostCode
	 */
	public String getMliCostCode() {
		return mliCostCode;
	}

	/**
	 * @param mliCostCode
	 *            the mliCostCode to set
	 */
	public void setMliCostCode(String mliCostCode1) {
		mliCostCode = mliCostCode1;
	}

	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}

	/**
	 * @param source
	 *            the source to set
	 */
	public void setSource(String source1) {
		source = source1;
	}

	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * @param region
	 *            the region to set
	 */
	public void setRegion(String region1) {
		region = region1;
	}

	/**
	 * @return the designMemo
	 */
	public String getDesignMemo() {
		return designMemo;
	}

	/**
	 * @param designMemo
	 */
	public void setDesignMemo(String designMemo1) {
		designMemo = designMemo1;
	}

	/**
	 * @return the shipDate
	 */
	public Date getShipDate() {
		Date temp = null;
		temp = shipDate;
		return temp;
	}

	/**
	 * @param shipDate
	 *            the shipDate to set
	 */
	public void setShipDate(Date shipDate2) {
		Date temp = null;
		temp = shipDate2;
		shipDate = temp;
	}

	/**
	 * @return the frameSize
	 */
	public String getFrameSize() {
		return frameSize;
	}

	/**
	 * @param frameSize
	 *            the frameSize to set
	 */
	public void setFrameSize(String frameSize1) {
		frameSize = frameSize1;
	}

	/**
	 * @return the _productLineSD
	 */
	public String getProductLineSD() {
		return productLineSD;
	}

	/**
	 * @param lineSD
	 *            the _productLineSD to set
	 */
	public void setProductLineSD(String lineSD) {
		productLineSD = lineSD;
	}

	/**
	 * @return the _mplMLnumberSD
	 */
	public String getMplMLnumberSD() {
		return mplMLnumberSD;
	}

	/**
	 * @param lnumberSD
	 *            the _mplMLnumberSD to set
	 */
	public void setMplMLnumberSD(String lnumberSD) {
		mplMLnumberSD = lnumberSD;
	}

	/**
	 * @return the _serialNumberSD
	 */
	public String getSerialNumberSD() {
		return serialNumberSD;
	}

	/**
	 * @param numberSD
	 *            the _serialNumberSD to set
	 */
	public void setSerialNumberSD(String numberSD) {
		serialNumberSD = numberSD;
	}

	/**
	 * @return the _designNumberSD
	 */
	public String getDesignNumberSD() {
		return designNumberSD;
	}

	/**
	 * @param numberSD
	 *            the _designNumberSD to set
	 */
	public void setDesignNumberSD(String numberSD) {
		designNumberSD = numberSD;
	}

	/**
	 * @return the _customerNameSD
	 */
	public String getCustomerNameSD() {
		return customerNameSD;
	}

	/**
	 * @param nameSD
	 *            the _customerNameSD to set
	 */
	public void setCustomerNameSD(String nameSD) {
		customerNameSD = nameSD;
	}

	/**
	 * @return the _siteLocationSD
	 */
	public String getSiteLocationSD() {
		return siteLocationSD;
	}

	/**
	 * @param locationSD
	 *            the _siteLocationSD to set
	 */
	public void setSiteLocationSD(String locationSD) {
		siteLocationSD = locationSD;
	}

	/**
	 * @return the _mplMLnumberHD
	 */
	public String getMplMLnumberHD() {
		return mplMLnumberHD;
	}

	/**
	 * @param lnumberHD
	 *            the _mplMLnumberHD to set
	 */
	public void setMplMLnumberHD(String lnumberHD) {
		mplMLnumberHD = lnumberHD;
	}

	/**
	 * @return the _pinHD
	 */
	public String getPinHD() {
		return pinHD;
	}

	/**
	 * @param _pinhd
	 *            the _pinHD to set
	 */
	public void setPinHD(String pinhd) {
		pinHD = pinhd;
	}

	/**
	 * @return the _serialHD
	 */
	public String getSerialHD() {
		return serialHD;
	}

	/**
	 * @param _serialhd
	 *            the _serialHD to set
	 */
	public void setSerialHD(String serialhd) {
		serialHD = serialhd;
	}

	/**
	 * @return the _customerHD
	 */
	public String getCustomerHD() {
		return customerHD;
	}

	/**
	 * @param _customerhd
	 *            the _customerHD to set
	 */
	public void setCustomerHD(String customerhd) {
		customerHD = customerhd;
	}

	/**
	 * @return the _designHD
	 */
	public String getDesignHD() {
		return designHD;
	}

	/**
	 * @param _designhd
	 *            the _designHD to set
	 */
	public void setDesignHD(String designhd) {
		designHD = designhd;
	}

	/**
	 * @return the _sectionHD
	 */
	public String getSectionHD() {
		return sectionHD;
	}

	/**
	 * @param _sectionhd
	 *            the _sectionHD to set
	 */
	public void setSectionHD(String sectionhd) {
		sectionHD = sectionhd;
	}

	/**
	 * @return the _headerCommentsHD
	 */
	public String getHeaderCommentsHD() {
		return headerCommentsHD;
	}

	/**
	 * @param commentsHD
	 *            the _headerCommentsHD to set
	 */
	public void setHeaderCommentsHD(String commentsHD) {
		headerCommentsHD = commentsHD;
	}

	/**
	 * @return the _shipFromDateSD
	 */
	public String getShipFromDateSD() {
		return shipFromDateSD;
	}

	/**
	 * @param fromDateSD
	 *            the _shipFromDateSD to set
	 */
	public void setShipFromDateSD(String fromDateSD) {
		shipFromDateSD = fromDateSD;
	}

	/**
	 * @return the _shipToDateSD
	 */
	public String getShipToDateSD() {
		return shipToDateSD;
	}

	/**
	 * @param toDateSD
	 *            the _shipToDateSD to set
	 */
	public void setShipToDateSD(String toDateSD) {
		shipToDateSD = toDateSD;
	}

	/**
	 * @return the _searchMplSelect
	 */
	public List<SelectItem> getSearchMplSelect() {
		return searchMplSelect;
	}

	/**
	 * @param mplSelect
	 *            the _searchMplSelect to set
	 */
	public void setSearchMplSelect(List<SelectItem> mplSelect) {
		searchMplSelect = mplSelect;
	}

	/**
	 * @return the _displayHeader
	 */
	public List<PLMPddrSearchData> getDisplayHeader() {
		return displayHeader;
	}

	/**
	 * @param header
	 *            the _displayHeader to set
	 */
	public void setDisplayHeader(List<PLMPddrSearchData> header) {
		displayHeader = header;
	}

	/**
	 * @return the _smipBTHD
	 */
	public Date getSmipBTHD() {
		Date temp = null;
		temp = smipBTHD;
		return temp;
	}

	/**
	 * @param _smipbthd
	 *            the _smipBTHD to set
	 */
	public void setSmipBTHD(Date smipbthdt) {
		Date temp = null;
		temp = smipbthdt;
		smipBTHD = temp;
	}

	/**
	 * @return String
	 */
	public String getShipDate1() {
		return shipDate1;
	}

	/**
	 * @param date1
	 */
	public void setShipDate1(String date1) {
		shipDate1 = date1;
	}

	/**
	 * @return the _stateOfPartSD
	 */
	public int getStateOfPartSD() {
		return stateOfPartSD;
	}

	/**
	 * @param ofPartSD
	 *            the _stateOfPartSD to set
	 */
	public void setStateOfPartSD(int ofPartSD) {
		stateOfPartSD = ofPartSD;
	}

	/**
	 * @return the _confStatusSD
	 */
	public int getConfStatusSD() {
		return confStatusSD;
	}

	/**
	 * @param statusSD
	 *            the _confStatusSD to set
	 */
	public void setConfStatusSD(int statusSD) {
		confStatusSD = statusSD;
	}

	/**
	 * @return the _shippableSD
	 */
	public int getShippableSD() {
		return shippableSD;
	}

	/**
	 * @param _shippablesd
	 *            the _shippableSD to set
	 */
	public void setShippableSD(int shippablesd) {
		shippableSD = shippablesd;
	}

	/**
	 * @return shipDt
	 */
	public String getShipDt() {
		return shipDt;
	}

	/**
	 * @param shipDt1
	 */
	public void setShipDt(String shipDt1) {
		shipDt = shipDt1;
	}

	/**
	 * @return the sourceHD
	 */
	public String getSourceHD() {
		return sourceHD;
	}

	/**
	 * @param sourceHD
	 *            the sourceHD to set
	 */
	public void setSourceHD(String sourceHD1) {
		sourceHD = sourceHD1;
	}

	/**
	 * @return the productLineHD
	 */
	public String getProductLineHD() {
		return productLineHD;
	}

	/**
	 * @param productLineHD
	 *            the productLineHD to set
	 */
	public void setProductLineHD(String productLineHD1) {
		if (productLineHD1.equalsIgnoreCase("~~~~")
				|| productLineHD1.equalsIgnoreCase("BLANK")) {
			productLineHD = "";
		} else {
			productLineHD = productLineHD1;
		}
	}

	/**
	 * @return the siteLocationHD
	 */
	public String getSiteLocationHD() {
		return siteLocationHD;
	}

	/**
	 * @param siteLocationHD
	 *            the siteLocationHD to set
	 */
	public void setSiteLocationHD(String siteLocationHD1) {
		siteLocationHD = siteLocationHD1;
	}

	/**
	 * @return the custDet
	 */
	public String getCustDet() {
		return custDet;
	}

	/**
	 * @param custDet
	 *            the custDet to set
	 */
	public void setCustDet(String custDet1) {
		custDet = custDet1;
	}

	/**
	 * @return the locDet
	 */
	public String getLocDet() {
		return locDet;
	}

	/**
	 * @param locDet
	 *            the locDet to set
	 */
	public void setLocDet(String locDet1) {
		locDet = locDet1;
	}

	/**
	 * @return the sectionSD
	 */
	public String getSectionSD() {
		return sectionSD;
	}

	/**
	 * @param sectionSD
	 *            the sectionSD to set
	 */
	public void setSectionSD(String sectionSD1) {
		sectionSD = sectionSD1;
	}

	/**
	 * @return the authrznid
	 */
	public String getAuthrznid() {
		return authrznid;
	}

	/**
	 * @param authrznid
	 *            the authrznid to set
	 */
	public void setAuthrznid(String authrznid1) {
		this.authrznid = authrznid1;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description1) {
		this.description = description1;
	}

	/**
	 * @return the authEC
	 */
	public String getAuthEC() {
		return authEC;
	}

	/**
	 * @param authEC
	 *            the authEC to set
	 */
	public void setAuthEC(String authEC1) {
		this.authEC = authEC1;
	}

	/**
	 * @return the pin
	 */
	public String getPin() {
		return pin;
	}

	/**
	 * @param pin
	 *            the pin to set
	 */
	public void setPin(String pin1) {
		this.pin = pin1;
	}

	/**
	 * @return the quantity
	 */
	public String getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity
	 *            the quantity to set
	 */
	public void setQuantity(String quantity1) {
		this.quantity = quantity1;
	}

	/**
	 * @return the entryDt
	 */
	public String getEntryDt() {
		return entryDt;
	}

	/**
	 * @param entryDt
	 *            the entryDt to set
	 */
	public void setEntryDt(String entryDt1) {
		this.entryDt = entryDt1;
	}

	/**
	 * @return the ursData
	 */
	public String getUrsData() {
		return ursData;
	}

	/**
	 * @param ursData
	 *            the ursData to set
	 */
	public void setUrsData(String ursData1) {
		this.ursData = ursData1;
	}

	/**
	 * @return the suffixData
	 */
	public String getSuffixData() {
		return suffixData;
	}

	/**
	 * @param suffixData
	 *            the suffixData to set
	 */
	public void setSuffixData(String suffixData1) {
		this.suffixData = suffixData1;
	}

	/**
	 * @return the itemType
	 */
	public String getItemType() {
		return itemType;
	}

	/**
	 * @param itemType
	 *            the itemType to set
	 */
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	/**
	 * @return the mliText
	 */
	public String getMliText() {
		return mliText;
	}

	/**
	 * @param mliText
	 *            the mliText to set
	 */
	public void setMliText(String mliText) {
		this.mliText = mliText;
	}

	/**
	 * @return the authEc
	 */
	public String getAuthEc() {
		return authEc;
	}

	/**
	 * @param authEc
	 *            the authEc to set
	 */
	public void setAuthEc(String authEc) {
		this.authEc = authEc;
	}

	/**
	 * @return the radioType
	 */
	public String getRadioType() {
		return radioType;
	}

	/**
	 * @param radioType
	 *            the radioType to set
	 */
	public void setRadioType(String radioType) {
		this.radioType = radioType;
	}
}
