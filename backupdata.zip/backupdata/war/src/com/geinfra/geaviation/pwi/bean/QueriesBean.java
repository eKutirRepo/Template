package com.geinfra.geaviation.pwi.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.context.FacesContext;
//import javax.faces.model.SelectItem; // XXX Subscription

import jxl.common.Logger;

import org.apache.commons.lang.StringUtils;

import com.geinfra.geaviation.pwi.bean.util.BeanUtil;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.QueryAccessException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
//import com.geinfra.geaviation.pwi.model.PWiFrequencyTypeVO; // XXX Subscription
import com.geinfra.geaviation.pwi.model.PWiQueryExctnEventVO;
import com.geinfra.geaviation.pwi.model.PWiQueryNoXmlVO;
import com.geinfra.geaviation.pwi.model.PWiQueryVO;
//import com.geinfra.geaviation.pwi.model.PWiQueryVO; // XXX Subscription
import com.geinfra.geaviation.pwi.model.PWiUserCustomQueryVO;
import com.geinfra.geaviation.pwi.service.CustomQueryService;
import com.geinfra.geaviation.pwi.service.HistoryService;
import com.geinfra.geaviation.pwi.service.QueriesService;
import com.geinfra.geaviation.pwi.service.QuerySubmissionService;
import com.geinfra.geaviation.pwi.service.vo.ExecutedFrom;
import com.geinfra.geaviation.pwi.service.vo.ExecutionMode;
//import com.geinfra.geaviation.pwi.service.vo.OutputType; // XXX Subscription
import com.geinfra.geaviation.pwi.service.vo.OutputType;
import com.geinfra.geaviation.pwi.service.vo.QuerySubmission;
import com.geinfra.geaviation.pwi.service.vo.QuerySubmissionResult;
import com.geinfra.geaviation.pwi.service.vo.QueryUserOptions;
import com.geinfra.geaviation.pwi.util.BookmarkableLinkServlet;
import com.geinfra.geaviation.pwi.util.BookmarkableLinkServlet.BookmarkAction;
import com.geinfra.geaviation.pwi.util.BookmarkableLinkServlet.BookmarkType;
import com.geinfra.geaviation.pwi.util.BookmarkableLinkUtil;
//import com.geinfra.geaviation.pwi.util.DateUtil; // XXX Subscription
import com.geinfra.geaviation.pwi.util.LoadProps;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.util.RoleInfoUtil;

/**
 * 
 * Project : Product Lifecycle Management Intelligence
 * Date Written : May 21, 2010
 * Security : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : QueriesBean - "catch-all" bean that handles functionality for
 * multiple pages. Really should probably be broken into multiple beans specific
 * to each page (has already been done for the QueryBuilder and QueryResult
 * pages) and maybe retain only any general UI functionality used by multiple
 * pages.
 * 
 * Revision Log May 8, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class QueriesBean extends BaseBean {
	private static final Logger LOGGER = Logger.getLogger(QueriesBean.class);

	// Dependency-injected services
	private QueriesService qryService;
	private QuerySubmissionService querySubmissionService;
	private HistoryService historyService;
	private CustomQueryService customQueryService;
	//private QueriesService queriesService;
	

//	private List<PWiFrequencyTypeVO> subscriptionFrequencyList;
//	private PWiUserCustomQueryVO selectedCustQry; // XXX Subscription
//	private List<SelectItem> radioItems;
//	private String selectedSubscriptionType;

	public void setQryService(QueriesService qryService) {
		this.qryService = qryService;
	}

	public void setQuerySubmissionService(
			QuerySubmissionService querySubmissionService) {
		this.querySubmissionService = querySubmissionService;
	}

	public void setHistoryService(HistoryService historyService) {
		this.historyService = historyService;
	}

	public void setCustomQueryService(CustomQueryService customQueryService) {
		this.customQueryService = customQueryService;
	}
	
	/*
	 * Commented on 31-Oct-2014 as per Nimble report - never used */
	private QuerySubmission querySubmission;
	
	public void setQuerySubmission(QuerySubmission querySubmission) {
		this.querySubmission = querySubmission;
	}

	/**
	 * Searches for queries based on the specified search criteria and navigates
	 * to the appropriate screen.
	 * 
	 * If exactly one query is found, navigate to the query builder screen.
	 * Otherwise, navigate to the query list screen.
	 * 
	 * @param searchCriteria
	 * @return JSF navigation screen
	 * @throws NumberFormatException
	 * @throws PWiException
	 * @throws QueryAccessException
	 */
	public String querySearch(String searchCriteria)
	throws PWiException {
List<PWiQueryNoXmlVO> srchQueriesList = getQuerySearchResults(searchCriteria);
if (searchCriteria == null || srchQueriesList == null) {
	// No search criteria was entered (or an error made srchQueriesList null)
	// Initialize the query list bean with a null list; this will cause
	// all available queries to be fetched when the page is loaded.
	return BeanUtil.getInstance().getQueryListBean()
			.init(searchCriteria, null);
} else if(srchQueriesList.size() == 1) {
	// Initialize the the query list bean (in case the user wants to
	// return to this search result without remembering what was typed)
	BeanUtil.getInstance().getQueryListBean()
			.init(searchCriteria, srchQueriesList);
	try {
		// Initialize query builder bean
		BeanUtil.getInstance().getQueryBuilderBean()
				.init(srchQueriesList.get(0).getQrySeqId(), null);
		return PWiConstants.NAV_QUERY_BUILDER;
	} catch (QueryAccessException e) {
		e.printStackTrace();
		LOGGER.error("QueryAccessException for query search", e);
		handleFacesError(PWiConstants.ERROR_COM_01);
						// return  PWiConstants.NAV_QUERY_LIST (immediately following)
	}
	// the only way we get here is if a QueryAccessException is thrown,
	// so we redirect to the search page and show the one, inaccessible
	// result.
	
	return PWiConstants.NAV_QUERY_LIST;
} else {
				// Initialize query list bean (we found multiple or 0 results to a search)
	return BeanUtil.getInstance().getQueryListBean()
			.init(searchCriteria, srchQueriesList);
}
}

	/**
	 * Searches for and returns queries containing the specified search
	 * criteria.
	 * 
	 * @param searchCriteria
	 * @return list of queries
	 * @throws PWiException
	 */
	public List<PWiQueryNoXmlVO> getQuerySearchResults(String searchCriteria)
			throws PWiException {
		if (searchCriteria != null && searchCriteria.length() > 0) {
			List<PWiQueryNoXmlVO> resultList = qryService.searchQuery(
					surroundWithWildcards(searchCriteria),
					RoleInfoUtil.getInstance().getRolesForUser(getSsoId()));
			return resultList;
		}
		return new ArrayList<PWiQueryNoXmlVO>(0);
	}
	
	/**
	 * Finds only the names of queries matching the specified search criteria.
	 * This is useful for typeahead boxes.
	 * 
	 * @param searchCriteria
	 * @return list of queries
	 * @throws PWiException
	 */
	public List<String> getQuerySearchTypeahead(String searchCriteria)
			throws PWiException {
		if (searchCriteria != null && searchCriteria.length() > 0) {
			List<String> resultList = qryService.searchQueryTypeahead(
					surroundWithWildcards(searchCriteria), 
					RoleInfoUtil.getInstance().getRolesForUser(getSsoId()));
			return resultList;
		}
		return new ArrayList<String>(0);
	}
	
	/**
	 * Surrounds search critera with wildcards and converts to lowercase
	 * 
	 * @param root
	 * @return root, converted to lowercase and surrounded with wildcards
	 */
	private String surroundWithWildcards(String root) {
		return new StringBuffer("%").append(root.trim().toLowerCase(Locale.US))
				.append("%").toString();
	}

//	// XXX REFERENCED ON SUBSCRIBE OPTIONS PAGE
//	public List<SelectItem> getRadioItems() throws PWiException {
//		this.subscriptionFrequencyList = customQueryService
//				.getAllSubscrictionFrequencies();
//		this.radioItems = listToSelectItemList(subscriptionFrequencyList);
//		return radioItems;
//	}
//
//	// XXX REFERENCED ON SUBSCRIBE OPTIONS PAGE
//	public void setRadioItems(List<SelectItem> radioItems) {
//		this.radioItems = radioItems;
//	}

//	private List<SelectItem> listToSelectItemList(
//			List<PWiFrequencyTypeVO> objectList) {
//		List<SelectItem> slctitmList = new ArrayList<SelectItem>();
//		if (null != objectList && !objectList.isEmpty()) {
//			for (PWiFrequencyTypeVO vo : objectList) {
//				SelectItem item = new SelectItem(vo.getFrqncyTypSeqId(), vo
//						.getFrqncyTypNm());
//				slctitmList.add(item);
//			}
//		}
//		return slctitmList;
//	}

//	// XXX REFERENCED ON SUBSCRIBE OPTIONS PAGE
//	public String getSelectedSubscriptionType() {
//		// TODO retrieve frequency for subscription from service
//		// if (null != this.selectedCustQry
//		// && null != this.selectedCustQry.getQryExctnFrqncy()) {
//		// selectedSubscriptionType = selectedCustQry.getQryExctnFrqncy()
//		// .getFrqncyTypSeqId().toString();
//		// }
//		return selectedSubscriptionType;
//	}
//
//	// XXX REFERENCED ON SUBSCRIBE OPTIONS PAGE
//	public void setSelectedSubscriptionType(String selectedSubscriptionType) {
//		this.selectedSubscriptionType = selectedSubscriptionType;
//	}

//	// XXX REFERENCED ON SUBSCRIBE OPTIONS PAGE
//	public String modifySubscrptnFavoriteQueriesforUser() throws PWiException {
//		int obj;
//		Integer intSubsId = Integer.valueOf(this.selectedSubscriptionType);
//		obj = customQueryService.modifySubscrptnFavoriteQueriesforUser(
//				getSsoId(), selectedCustQry.getPrtyCstmQrySeqId(), intSubsId,
//				DateUtil.getInstance().nextExeDate(intSubsId), selectedCustQry
//						.getCurrQryRsltFlPthTxt(), selectedCustQry
//						.getPrrQryRsltFlPthTxt());
//		String subs = null;
//		int intSubIdIntValue = intSubsId.intValue();
//		if (intSubIdIntValue == 1) {
//			subs = "Daily";
//		} else if (intSubIdIntValue == 2) {
//			subs = "Weekly";
//		} else if (intSubIdIntValue == 3) {
//			subs = "Monthly";
//		}
//		if (obj > 0) {
//			String message = PWiConstants.ERROR_COM_21.replace("#", "'"
//					+ selectedCustQry.getCstmQryNm() + "'");
//			message = message.replace("$", subs);
//			handleFacesInfo(message, FacesContext.getCurrentInstance());
//		}
//		return "cancel";
//	}

	// For online execution, caches options and directs to Results page for
	// execution; for batch execution, direct to Results page (or _fast-loading_
	// QueryBuilder page) to show user what was executed and allow modification)
	
	public String processQuerySubmissionResult(PWiQueryVO queryVo,
			QuerySubmissionResult result) throws PWiException,
			QueryAccessException {
		if (ExecutionMode.ONLINE.getId().equals(
				result.getQueryUserOptions().getExecutionModeId())) {
			// Stored result state in third-party request-scoped bean for the
			// result bean to retrieve. Can't pass it directly to result bean
			// because the bean doesn't have a way to distinguish an initial
			// request from an invalid request.
			QuerySubmissionControllerBean querySubmissionControllerBean = BeanUtil
					.getInstance().getQuerySubmissionControllerBean();
			querySubmissionControllerBean.setQuery(queryVo);
			querySubmissionControllerBean.setQuerySubmissionResult(result);

			return PWiConstants.NAV_QUERY_RESULT;
		} else if (ExecutionMode.BATCH.getId().equals(
				result.getQueryUserOptions().getExecutionModeId())) {
			handleFacesInfo(PWiConstants.MESSAGE_INFO_BATCH_QUEUED_SUCCESS);

			// Initialize query builder bean
			QueryBuilderBean queryBuilderBean = BeanUtil.getInstance()
					.getQueryBuilderBean();
			queryBuilderBean.init(queryVo.getQrySeqId(), result
					.getQueryUserOptions());

			return PWiConstants.NAV_QUERY_BUILDER;
		}
		else if (ExecutionMode.SFTP.getId().equals(
				result.getQueryUserOptions().getExecutionModeId().substring(0, result.getQueryUserOptions().getExecutionModeId().indexOf("::")))) {
			handleFacesInfo(PWiConstants.MESSAGE_INFO_SFTP_QUEUED_SUCCESS);

			// Initialize query builder bean
			QueryBuilderBean queryBuilderBean = BeanUtil.getInstance()
					.getQueryBuilderBean();
			queryBuilderBean.init(queryVo.getQrySeqId(), result
					.getQueryUserOptions());

			return PWiConstants.NAV_QUERY_BUILDER;
		}
		throw new PWiException(
				"Unrecognized execution mode.  execution mode: "
						+ result.getQueryUserOptions().getExecutionModeId()
						+ (result.getQueryResult() != null ? ", event id: "
								+ result.getExecutedQueryId() : ""));
	}
	
	
	/*
	 *Commented on 31-Oct-2014 as per Nimble report 
	 * private String prepareForQuerySubmission(Integer queryId,
			QueryUserOptions queryUserOptions, Integer favoriteId,
			ExecutedFrom executedFrom) throws PWiException,
			QueryAccessException {
		if (ExecutionMode.ONLINE.getId().equals(
				queryUserOptions.getExecutionModeId())) {
			
			// Stored result state in third-party request-scoped bean for the
			// result bean to retrieve. Can't pass it directly to result bean
			// because the bean doesn't have a way to distinguish an initial
			// request from an invalid request.
			querySubmission.init(qryService.getQueryById(queryId),
					queryUserOptions,  executedFrom);
			
			QuerySubmissionControllerBean querySubmissionControllerBean = BeanUtil
			.getInstance().getQuerySubmissionControllerBean();
			querySubmissionControllerBean.setQuery(qryService.getQueryById(queryId));
			
			return PWiConstants.NAV_QUERY_RESULT;
		} else if (ExecutionMode.BATCH.getId().equals(
				queryUserOptions.getExecutionModeId())) {
			// Queue batch query (TODO pH 2013.06: switch to new batch method, when written
			querySubmissionService.submitQueryFromScratch(queryId,
					queryUserOptions, getSsoId(), favoriteId, executedFrom);

			// display success message
			handleFacesInfo(PWiConstants.MESSAGE_INFO_BATCH_QUEUED_SUCCESS);

			// Initialize query builder bean
			QueryBuilderBean queryBuilderBean = BeanUtil.getInstance()
					.getQueryBuilderBean();
			queryBuilderBean.init(queryId, queryUserOptions);

			return PWiConstants.NAV_QUERY_BUILDER;
		}
		throw new PWiException(
				"Unrecognized execution mode.  execution mode: "
						+ queryUserOptions.getExecutionModeId());
	}*/
	
	// Favorite, history, qi, objectType
	/**
	 * Processes favorite bookmark link requests (execute and modify).
	 * Called by actionProcessBookmarkableLink()
	 * 
	 * @return JSF navigation outcome
	 * @throws PWiException
	 * @throws QueryAccessException
	 */
	private String processFavoriteLink(Map<?,?> parameterMap,
			BookmarkAction bookmarkAction) throws PWiException,
			QueryAccessException {
		String nav = null;
		try {
			// Extract favorite ID from parameters
			Integer favoriteId = Integer.valueOf(BookmarkableLinkUtil
					.getInstance().getParameter(parameterMap,
							BookmarkableLinkServlet.PARAMETER_FAVORITE_ID));
	
			// Retrieve favorite
			PWiUserCustomQueryVO favorite = customQueryService
					.getFavoriteById(favoriteId);
	
			Integer qryId = favorite.getQueryId();
			// Get query user options, if any
			QueryUserOptions options = null;
			if (!StringUtils.isBlank(favorite.getQrySrchCrtrTxt())) {
				options = querySubmissionService
						.getQueryUserOptionsFromFavorite(favorite);
			}
			if (BookmarkAction.EXECUTE.equals(bookmarkAction)) {
				// Run favorite if it has search criteria defined; otherwise,
				// prepare query builder
					if (options == null && qryId != null) {
					// Initialize query builder bean
					QueryBuilderBean queryBuilderBean = BeanUtil
							.getInstance().getQueryBuilderBean();
					queryBuilderBean.init(qryId, null);
					return PWiConstants.NAV_QUERY_BUILDER;
				} else {
					// Prepare for execution
					/*
					nav = prepareForQuerySubmission(qryId, options,
							favoriteId, ExecutedFrom.BOOKMARK_FAVORITE);*/
					QuerySubmissionResult result = querySubmissionService
					.submitQueryFromFavorite(favorite, 
							getSsoId(),
							ExecutedFrom.BOOKMARK_FAVORITE);

			nav = processQuerySubmissionResult(qryService.getQueryById(qryId), result);
					
				}
			} else if (BookmarkAction.MODIFY.equals(bookmarkAction)) {
				// Initialize query builder bean
				QueryBuilderBean queryBuilderBean = BeanUtil.getInstance()
						.getQueryBuilderBean();
				queryBuilderBean.init(qryId, options);
	
				nav = PWiConstants.NAV_QUERY_BUILDER;
			} else {
				throw new PWiException(
						"Failed to recognize bookmark action, bookmark action: "
								+ bookmarkAction);
			}
		} catch (NullPointerException npe) {
			nav = PWiConstants.NAV_QUERY_LIST;
			LOGGER.error("NullPointerException for favorite bookmark", npe);
			StringBuilder sbErr = new StringBuilder(PWiConstants.ERROR_COM_01)
                	.append(" This error occurred while trying to load a query from a Favorite.")
                	.append(" Note that if an administrator changed the design of a query,")
                	.append(" it is possible that reloading a favorite")
                	.append(" that was saved before the change will no longer work.")
					.append(" Please locate the query below and rebuild the query;")
                	.append(" then, resave it as a new Favorite if you would like.")
					.append(" We apologize for the inconvenience.");
			handleFacesError(sbErr.toString(), npe);
		}
		return nav;
	}
	
	/**
	 * Processes favorite history link requests (execute and modify).
	 * Called by actionProcessBookmarkableLink()
	 * 
	 * @return JSF navigation outcome
	 * @throws PWiException
	 */
	private String processHistoryLink(Map<?,?> parameterMap,
			BookmarkAction bookmarkAction) throws PWiException,
			QueryAccessException {
		String nav = null;
		try {
			// Extract history ID from parameters
			Integer historyId = Integer.valueOf(BookmarkableLinkUtil
					.getInstance().getParameter(parameterMap,
							BookmarkableLinkServlet.PARAMETER_HISTORY_ID));

			// Get event
			PWiQueryExctnEventVO eventVo = historyService
					.getExecutionEventById(historyId);

			// Get query user options
			QueryUserOptions options = querySubmissionService
					.getQueryUserOptionsFromHistory(eventVo);

			if (BookmarkAction.EXECUTE.equals(bookmarkAction)) {
			/*	nav = prepareForQuerySubmission(eventVo.getQueryId(),
						options, null, ExecutedFrom.BOOKMARK_HISTORY);*/
				QuerySubmissionResult result = querySubmissionService
				.submitQueryFromHistory(historyId, 
						getSsoId(),
						ExecutedFrom.BOOKMARK_HISTORY);

		nav = processQuerySubmissionResult(qryService.getQueryById(eventVo.getQueryId()), result);
				
			} else if (BookmarkAction.MODIFY.equals(bookmarkAction)) {
				// Initialize query builder bean
				QueryBuilderBean queryBuilderBean = BeanUtil.getInstance()
						.getQueryBuilderBean();
				queryBuilderBean.init(eventVo.getQueryId(), options);

				nav = PWiConstants.NAV_QUERY_BUILDER;
			} else {
				throw new PWiException(
						"Failed to recognize bookmark action, bookmark action: "
								+ bookmarkAction);
			}
		} catch (NullPointerException npe) {
			nav = PWiConstants.NAV_QUERY_LIST;
			LOGGER.error("NullPointerException for history bookmark", npe);
			StringBuilder sbErr = new StringBuilder(PWiConstants.ERROR_COM_01)
                	.append(" This error occurred while trying to load a query from Query History.")
                	.append(" Note that if an administrator changed the design of a query,")
                	.append(" it is possible that reloading a query")
                	.append(" that was run before the change will no longer work.")
					.append(" Please locate the query below and rebuild the query;")
                	.append(" then, resave it as a new Favorite if you would like.")
					.append(" We apologize for the inconvenience.");
        	handleFacesError(sbErr.toString(), npe);
		}
		return nav;
	}
	
	/**
	 * Processes query builder link request.  This allows a user to build a
	 * query from scratch (by selecting from the search queries page).
	 * Called by actionProcessBookmarkableLink()
	 * 
	 * @return JSF navigation outcome
	 * @throws PWiException
	 */
	private String processQueryBuilderLink(Map<?,?> parameterMap)
			throws PWiException, QueryAccessException {
		String nav = null;
		try {
			// Get query ID
			String queryId = BookmarkableLinkUtil.getInstance()
					.getParameter(parameterMap,
							BookmarkableLinkServlet.PARAMETER_QUERY_ID);

			// Initialize query builder bean
			QueryBuilderBean queryBuilderBean = BeanUtil.getInstance()
					.getQueryBuilderBean();
			queryBuilderBean.init(Integer.valueOf(queryId), null);
			nav = PWiConstants.NAV_QUERY_BUILDER;
		} catch (NullPointerException npe) {
			LOGGER.error("NullPointerException for Query Builder bookmark", npe);
			StringBuilder sbErr = new StringBuilder(PWiConstants.ERROR_COM_01)
                	.append(" This error occurred while trying to execute a query")
                	.append(" from the Query Builder page.");
			handleFacesError(sbErr.toString(), npe);
		}

		// navigate to query builder page
		return nav;
	}
	
	/**
	 * Processes quick intelligence link requests (favorites and click-through
	 * from query results).  These links run multiple queries on a single value
	 * and display results on the Quick Intelligence page.
	 * Called by actionProcessBookmarkableLink()
	 * 
	 * @return JSF navigation outcome
	 * @throws PWiException
	 */
	private String processQuickIntelligenceLink(Map<?,?> parameterMap)
			throws PWiException, QueryAccessException {
		try {
			// Get query IDs
			List<String> queryIds = BookmarkableLinkUtil.getInstance()
					.getParameterArray(parameterMap,
							BookmarkableLinkServlet.PARAMETER_QUERY_ID);

			// Get collapse result options
			List<String> collapseResults = BookmarkableLinkUtil
					.getInstance()
					.getParameterArray(
							parameterMap,
							BookmarkableLinkServlet.PARAMETER_COLLAPSE_RESULT);

			// Extract object type from parameters
			String objectType = BookmarkableLinkUtil.getInstance()
					.getParameter(parameterMap,
							BookmarkableLinkServlet.PARAMETER_OBJECT_TYPE);

			// Extract object value from parameters
			String objectValue = BookmarkableLinkUtil.getInstance()
					.getParameter(parameterMap,
							BookmarkableLinkServlet.PARAMETER_OBJECT_VALUE);

			// initialize quick intelligence page's backing bean
			QiBean qiBean = BeanUtil.getInstance().getQiBean();
			qiBean.init(objectType, objectValue, queryIds, collapseResults);
		} catch (NullPointerException npe) {
			LOGGER.error("NullPointerException for Quick Intelligence bookmark", npe);
			StringBuilder sbErr = new StringBuilder(PWiConstants.ERROR_COM_01)
                	.append(" This error occurred while trying to execute a query")
                	.append(" from a Quick Intelligence bookmark or right-click menu.");
			handleFacesError(sbErr.toString(), npe);
		}

		// navigate to quick intelligence page
		return PWiConstants.NAV_QUICK_INTELLIGENCE;
	}
	
	/**
	 * Processes object type link requests (click-through from query results).
	 * These links run a single query on a single value and display results on
	 * the Query Results page.
	 * Called by actionProcessBookmarkableLink()
	 * 
	 * @return JSF navigation outcome
	 * @throws PWiException
	 */
	private String processObjectTypeLink(Map<?,?> parameterMap)
			throws PWiException, QueryAccessException {
		String nav = null;
		try {
			// Get query ID
			Integer queryId = Integer.valueOf(BookmarkableLinkUtil
					.getInstance().getParameter(parameterMap,
							BookmarkableLinkServlet.PARAMETER_QUERY_ID));
			// Extract object type from parameters
			String objectType = BookmarkableLinkUtil.getInstance()
					.getParameter(parameterMap,
							BookmarkableLinkServlet.PARAMETER_OBJECT_TYPE);
			// Extract object value from parameters
			String objectValue = BookmarkableLinkUtil.getInstance()
					.getParameter(parameterMap,
							BookmarkableLinkServlet.PARAMETER_OBJECT_VALUE);
			// Create query user options
			/*Commented on 31-Oct-2014 as per Nimble report - never used
			 * QueryUserOptions queryUserOptions = querySubmissionService
					.getQueryUserOptionsFromObjectTypeQuery(
							qryService.getQueryById(queryId), objectType,
							objectValue, OutputType.WEB);*/
			// Cache options for submission from the Results page
			/*nav = prepareForQuerySubmission(queryId, queryUserOptions, null,
					ExecutedFrom.BOOKMARK_OBJECT_TYPE);*/
			QuerySubmissionResult result = querySubmissionService
			.submitObjectTypeQuery(qryService.getQueryById(queryId), objectType, objectValue,  
					 getSsoId(),
                     ExecutedFrom.QUERY_LINK, OutputType.WEB);

			nav = processQuerySubmissionResult(qryService.getQueryById(queryId), result);
			
		} catch (NullPointerException npe) {
			nav = PWiConstants.NAV_QUERY_LIST;
			LOGGER.error("NullPointerException for Object Type bookmark", npe);
			StringBuilder sbErr = new StringBuilder(PWiConstants.ERROR_COM_01)
	            	.append(" This error occurred while trying to execute a query from a right-click menu.")
					.append(" Please locate the query below and rebuild the query.");
			handleFacesError(sbErr.toString(), npe);
		}
		return nav;
	}

	/**
	 * Processes all bookmarkable link requests. Will be triggered by the
	 * bookmarkable link phase listener.
	 * 
	 * @return JSF navigation outcome
	 * @throws PWiException
	 */
	public String actionProcessBookmarkableLink() throws PWiException {
		String nav = null;
		// Retrieve parameter map (removing in the process)
		Map<?, ?> parameterMap = BookmarkableLinkUtil.getInstance()
				.getBookmarkableLinkParameterMapAttribute(
						FacesContext.getCurrentInstance(), true);

		// Retrieve bookmark type from parameters
		BookmarkType bookmarkType = BookmarkType
				.fromString(BookmarkableLinkUtil
						.getInstance()
						.getParameter(
								parameterMap,
								BookmarkableLinkServlet.PARAMETER_BOOKMARK_TYPE));

		// Retrieve bookmark action from parameters
		String bookmarkActionString = BookmarkableLinkUtil.getInstance()
				.getParameter(parameterMap,
						BookmarkableLinkServlet.PARAMETER_BOOKMARK_ACTION);
		BookmarkAction bookmarkAction = null;
		if (bookmarkActionString != null) {
			bookmarkAction = BookmarkAction
					.fromString(bookmarkActionString);
		} else {
			// default to execute
			bookmarkAction = BookmarkAction.EXECUTE;
		}
		try {
			// Get user options and query ID
			if (BookmarkType.FAVORITE.equals(bookmarkType)) {
				nav = processFavoriteLink(parameterMap, bookmarkAction);
			} else if (BookmarkType.HISTORY.equals(bookmarkType)) {
				nav = processHistoryLink(parameterMap, bookmarkAction);
			} else if (BookmarkType.QUERY_BUILDER.equals(bookmarkType)) {
				nav = processQueryBuilderLink(parameterMap);
			} else if (BookmarkType.QI.equals(bookmarkType)) {
				nav = processQuickIntelligenceLink(parameterMap);
			} else if (BookmarkType.OBJECT_TYPE.equals(bookmarkType)) {
				nav = processObjectTypeLink(parameterMap);
			} else {
				throw new PWiException(
						"Failed to recognize bookmark type, bookmark type: "
								+ bookmarkType);
			}
		} catch (QueryAccessException qae) {
			nav = PWiConstants.NAV_HOME;
			LOGGER.error("QueryAccessException for bookmark", qae);
			handleFacesError(LoadProps.getInstance().loadProps("idmMessage"), qae);
		} catch (PWiException pe) {
			nav = PWiConstants.NAV_ERROR;
			LOGGER.error("PWiException for bookmark", pe);
			handleFacesError(PWiConstants.ERROR_COM_01);
		}
		return nav;
	}
}