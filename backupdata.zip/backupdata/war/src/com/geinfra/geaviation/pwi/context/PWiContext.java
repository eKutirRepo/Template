package com.geinfra.geaviation.pwi.context;

import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.common.PWiException;

/**
 * Project : Product Lifecycle Management Date Written : Dec 12, 2011 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : Provides Portlet and Faces-independent access to request state.
 * 
 * Revision Log Dec 12, 2011 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiContext {
	private static final Logger LOGGER = Logger.getLogger(PWiContext.class);

	/**
	 * <p>
	 * The <code>ThreadLocal</code> variable used to record the
	 * {@link PWiContext} instance for each processing thread.
	 * </p>
	 */
	private static ThreadLocal<PWiContext> instance = new ThreadLocal<PWiContext>() {
		protected PWiContext initialValue() {
			return (null);
		}
	};

	private PWiRequest request;

	private PWiContext(PWiRequest request) {
		this.request = request;
	}

	/**
	 * Initialize PWiContext for the current request.
	 * 
	 * @param request
	 * @return the PWiContext for the current request
	 */
	public static PWiContext init(PWiRequest request) {
		PWiContext context = instance.get();
		if (context == null) {
			context = new PWiContext(request);
			setCurrentInstance(context);
		} else {
			context.request = request;
		}
		return context;
	}

	/**
	 * <p>
	 * Return the {@link PWiContext} instance for the request that is being
	 * processed by the current thread, if any.
	 * </p>
	 * 
	 * @return {@link PWiContext} for the current thread
	 */
	public static PWiContext getCurrentInstance() {
		PWiContext context = instance.get();
		if (context == null) {
			Thread thread = Thread.currentThread();
			throw new RuntimeException(
					"Failed to get PWiContext for current thread: (id, name)"
							+ thread.getId() + ", " + thread.getName());
		}
		return context;
	}

	/**
	 * <p>
	 * Set the {@link FacesContext} instance for the request that is being
	 * processed by the current thread.
	 * </p>
	 * 
	 * @param context
	 *            The {@link FacesContext} instance for the current thread, or
	 *            <code>null</code> if this thread no longer has a
	 *            <code>FacesContext</code> instance.
	 * 
	 */
	protected static void setCurrentInstance(PWiContext context) {
		Thread thread = Thread.currentThread();
		if (context == null) {
			instance.remove();
			// TODO: debugging
			/*LOGGER.info("PWiContext removed for thread with (id, name): "
					+ thread.getId() + ", " + thread.getName());*/
		} else {
			instance.set(context);
			// TODO: debugging
			/*LOGGER.info("PWiContext set for thread with (id, name): "
					+ thread.getId() + ", " + thread.getName());	*/		

		}
	}

	public PWiRequest getRequest() {
		return request;
	}

	/*public String getUserSso() throws PWiException {
		
		String sso = (String) request.getParameter("ssoId");
		
		if (sso == null){
			sso = (String)FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("ssoId");
		}
		if (sso == null) {
			
				throw new PWiException("Failed to get user sso.");
		}
		
		return sso;
	}*/
	
	public String getUserSso() throws PWiException {
		String sso = (String) request.getSsoId();
		
		//sso="502310630";
		if (sso == null){
			
			
		 sso = (String)request.getSession().getAttribute("ssoId");
			
			if (sso == null) {
				
				//sso = FacesContext.getCurrentInstance().getExternalContext().getRemoteUser();
				sso = (String)FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("ssoId");
			}
			if (sso == null) {
				throw new PWiException("Failed to get user sso.");
			}
			
		}
	
		
		return sso;
	}
}