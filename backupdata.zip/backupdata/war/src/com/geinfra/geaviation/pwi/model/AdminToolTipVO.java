/**
 * Project        :   Product Lifecycle Management 
 * Date Written   :   ${date} 
 * Security       :   GE Confidential 
 * Restrictions   :   GE PROPRIETARY INFORMATION, FOR GE USE ONLY 
 * 
 * Copyright(C) ${year} GE 
 * All rights reserved 
 * 
 * Description    :  AdminSettingsVO 
 * 
 * Revision Log May 20, 2010 | v1.0. 
 * -------------------------------------------------------------- 

 */

package com.geinfra.geaviation.pwi.model;

import com.geinfra.geaviation.pwi.common.model.BaseVO;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : AdminSettingsVO - Object representing Admin Settings text.
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class AdminToolTipVO extends BaseVO {
	private String toolTipText;
	private String tlTpSeqId;
	private String tlTpPrmNm;
	private String tlTpParVal;
	private boolean tlTpShwInd;

	/**
	 * @return the settingsText
	 */
	public String getToolTipText() {
		return toolTipText;
	}

	/**
	 * @param settingsText
	 *            the settingsText to set
	 */
	public void setToolTipText(String toolTipText) {
		this.toolTipText = toolTipText;
	}

	/**
	 * @return the appSeqId
	 */
	public String tlTpSeqId() {
		return tlTpSeqId;
	}

	/**
	 * @param appSeqId
	 *            the appSeqId to set
	 */
	public void setTlTpSeqId(String tlTpSeqId) {
		this.tlTpSeqId = tlTpSeqId;
	}

	/**
	 * @return the appPrmNm
	 */
	public String getTlTpPrmNm() {
		return tlTpPrmNm;
	}

	/**
	 * @param appPrmNm
	 *            the appPrmNm to set
	 */
	public void setTlTpPrmNm(String tlTpPrmNm) {
		this.tlTpPrmNm = tlTpPrmNm;
	}

	/**
	 * @return the appParVal
	 */
	public String getTlTpParVal() {
		return tlTpParVal;
	}

	/**
	 * @param appParVal
	 *            the appParVal to set
	 */
	public void setTlTpParVal(String tlTpParVal) {
		this.tlTpParVal = tlTpParVal;
	}

	/**
	 * @return the crtrssoid
	 */
	public boolean getTlTpShwInd() {
		return tlTpShwInd;
	}

	/**
	 * @param crtrSsoid 
	 *            the crtrssoid to set
	 */
	public void setTlTpShwInd(boolean string) {
		this.tlTpShwInd = string;
	}

}
