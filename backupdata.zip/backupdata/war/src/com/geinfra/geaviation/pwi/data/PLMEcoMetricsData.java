/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEcoMetricsData.java
 * @Creation date: 02-July-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
 
package com.geinfra.geaviation.pwi.data;

import java.util.List;

public class PLMEcoMetricsData {
	/**
	  * Holds the name
	  */
	private String name;
	/**
	  * Holds the sso
	  */
	private String sso;
	/**
	  * Holds the selectedsso
	  */
	private String selectedsso;
	/**
	  * Holds the level
	  */
	private String level;
	/**
	  * Holds the criteria
	  */
	private String criteria;
	/**
	  * Holds the expand
	  */
	private boolean expand;
	/**
	  * Holds the collapse
	  */
	private boolean collapse;
	/**
	  * Holds the owner
	  */
	private boolean owner;
	/**
	  * Holds the vpIndex
	  */
	private int vpIndex;
	/**
	  * Holds the gmIndex
	  */
	private int gmIndex;
	/**
	  * Holds the fmIndex
	  */
	private int fmIndex;
	/**
	  * Holds the mgr4index
	  */
	private int mgr4index;
	/**
	  * Holds the mgr3index
	  */
	private int mgr3index;
	/**
	  * Holds the mgr2index
	  */
	private int mgr2index;
	/**
	  * Holds the mgr1index
	  */
	private int mgr1index;
	/**
	  * Holds the ownerindex
	  */
	private int ownerindex;
	/**
	  * Holds the rowIndex
	  */
	private int rowIndex;
	/**
	  * Holds the gmTable
	  */
	private List<PLMEcoMetricsData> gmTable;
	/**
	  * Holds the fmTable
	  */
	private List<PLMEcoMetricsData> fmTable;
	/**
	  * Holds the mgr4table
	  */
	private List<PLMEcoMetricsData> mgr4table;
	/**
	  * Holds the mgr3table
	  */
	private List<PLMEcoMetricsData> mgr3table;
	/**
	  * Holds the mgr2table
	  */
	private List<PLMEcoMetricsData> mgr2table;
	/**
	  * Holds the mgr1table
	  */
	private List<PLMEcoMetricsData> mgr1table;
	/**
	  * Holds the ownertable
	  */
	private List<PLMEcoMetricsData> ownertable;
	/**
	  * Holds the missingreqerror
	  */
	private int missingreqerror;
	/**
	  * Holds the productimprovement
	  */
	private int productimprovement;
	/**
	  * Holds the unassigned
	  */
	private int unassigned;
	/**
	  * Holds the initialrelease
	  */
	private int initialrelease;
	/**
	  * Holds the customerchange
	  */
	private int customerchange;
	/**
	  * Holds the backlog
	  */
	private int backlog;
	/**
	  * Holds the dueWeek
	  */
	private int dueWeek;
	/**
	  * Holds the dueMonth
	  */
	private int dueMonth;
	/**
	  * Holds the dueYear
	  */
	private int dueYear;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the sso
	 */
	public String getSso() {
		return sso;
	}
	/**
	 * @param sso the sso to set
	 */
	public void setSso(String sso) {
		this.sso = sso;
	}
	/**
	 * @return the selectedsso
	 */
	public String getSelectedsso() {
		return selectedsso;
	}
	/**
	 * @param selectedsso the selectedsso to set
	 */
	public void setSelectedsso(String selectedsso) {
		this.selectedsso = selectedsso;
	}
	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}
	/**
	 * @return the criteria
	 */
	public String getCriteria() {
		return criteria;
	}
	/**
	 * @param criteria the criteria to set
	 */
	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}
	/**
	 * @return the expand
	 */
	public boolean isExpand() {
		return expand;
	}
	/**
	 * @param expand the expand to set
	 */
	public void setExpand(boolean expand) {
		this.expand = expand;
	}
	/**
	 * @return the collapse
	 */
	public boolean isCollapse() {
		return collapse;
	}
	/**
	 * @param collapse the collapse to set
	 */
	public void setCollapse(boolean collapse) {
		this.collapse = collapse;
	}
	/**
	 * @return the owner
	 */
	public boolean isOwner() {
		return owner;
	}
	/**
	 * @param owner the owner to set
	 */
	public void setOwner(boolean owner) {
		this.owner = owner;
	}
	/**
	 * @return the vpIndex
	 */
	public int getVpIndex() {
		return vpIndex;
	}
	/**
	 * @param vpindex the vpIndex to set
	 */
	public void setVpIndex(int vpIndex) {
		this.vpIndex = vpIndex;
	}
	/**
	 * @return the gmIndex
	 */
	public int getGmIndex() {
		return gmIndex;
	}
	/**
	 * @param gmIndex the gmIndex to set
	 */
	public void setGmIndex(int gmIndex) {
		this.gmIndex = gmIndex;
	}
	/**
	 * @return the fmIndex
	 */
	public int getFmIndex() {
		return fmIndex;
	}
	/**
	 * @param fmIndex the fmIndex to set
	 */
	public void setFmIndex(int fmIndex) {
		this.fmIndex = fmIndex;
	}
	/**
	 * @return the mgr4index
	 */
	public int getMgr4index() {
		return mgr4index;
	}
	/**
	 * @param mgr4index the mgr4index to set
	 */
	public void setMgr4index(int mgr4index) {
		this.mgr4index = mgr4index;
	}
	/**
	 * @return the mgr3index
	 */
	public int getMgr3index() {
		return mgr3index;
	}
	/**
	 * @param mgr3index the mgr3index to set
	 */
	public void setMgr3index(int mgr3index) {
		this.mgr3index = mgr3index;
	}
	/**
	 * @return the mgr2index
	 */
	public int getMgr2index() {
		return mgr2index;
	}
	/**
	 * @param mgr2index the mgr2index to set
	 */
	public void setMgr2index(int mgr2index) {
		this.mgr2index = mgr2index;
	}
	/**
	 * @return the mgr1index
	 */
	public int getMgr1index() {
		return mgr1index;
	}
	/**
	 * @param mgr1index the mgr1index to set
	 */
	public void setMgr1index(int mgr1index) {
		this.mgr1index = mgr1index;
	}
	/**
	 * @return the ownerindex
	 */
	public int getOwnerindex() {
		return ownerindex;
	}
	/**
	 * @param ownerindex the ownerindex to set
	 */
	public void setOwnerindex(int ownerindex) {
		this.ownerindex = ownerindex;
	}
	/**
	 * @return the rowIndex
	 */
	public int getRowIndex() {
		return rowIndex;
	}
	/**
	 * @param rowIndex the rowIndex to set
	 */
	public void setRowIndex(int rowIndex) {
		this.rowIndex = rowIndex;
	}
	/**
	 * @return the gmTable
	 */
	public List<PLMEcoMetricsData> getGmTable() {
		return gmTable;
	}
	/**
	 * @param gmTable the gmTable to set
	 */
	public void setGmTable(List<PLMEcoMetricsData> gmTable) {
		this.gmTable = gmTable;
	}
	/**
	 * @return the fmTable
	 */
	public List<PLMEcoMetricsData> getFmTable() {
		return fmTable;
	}
	/**
	 * @param fmTable the fmTable to set
	 */
	public void setFmTable(List<PLMEcoMetricsData> fmTable) {
		this.fmTable = fmTable;
	}
	/**
	 * @return the mgr4table
	 */
	public List<PLMEcoMetricsData> getMgr4table() {
		return mgr4table;
	}
	/**
	 * @param mgr4table the mgr4table to set
	 */
	public void setMgr4table(List<PLMEcoMetricsData> mgr4table) {
		this.mgr4table = mgr4table;
	}
	/**
	 * @return the mgr3table
	 */
	public List<PLMEcoMetricsData> getMgr3table() {
		return mgr3table;
	}
	/**
	 * @param mgr3table the mgr3table to set
	 */
	public void setMgr3table(List<PLMEcoMetricsData> mgr3table) {
		this.mgr3table = mgr3table;
	}
	/**
	 * @return the mgr2table
	 */
	public List<PLMEcoMetricsData> getMgr2table() {
		return mgr2table;
	}
	/**
	 * @param mgr2table the mgr2table to set
	 */
	public void setMgr2table(List<PLMEcoMetricsData> mgr2table) {
		this.mgr2table = mgr2table;
	}
	/**
	 * @return the mgr1table
	 */
	public List<PLMEcoMetricsData> getMgr1table() {
		return mgr1table;
	}
	/**
	 * @param mgr1table the mgr1table to set
	 */
	public void setMgr1table(List<PLMEcoMetricsData> mgr1table) {
		this.mgr1table = mgr1table;
	}
	/**
	 * @return the ownertable
	 */
	public List<PLMEcoMetricsData> getOwnertable() {
		return ownertable;
	}
	/**
	 * @param ownertable the ownertable to set
	 */
	public void setOwnertable(List<PLMEcoMetricsData> ownertable) {
		this.ownertable = ownertable;
	}
	/**
	 * @return the missingreqerror
	 */
	public int getMissingreqerror() {
		return missingreqerror;
	}
	/**
	 * @param missingreqerror the missingreqerror to set
	 */
	public void setMissingreqerror(int missingreqerror) {
		this.missingreqerror = missingreqerror;
	}
	/**
	 * @return the productimprovement
	 */
	public int getProductimprovement() {
		return productimprovement;
	}
	/**
	 * @param productimprovement the productimprovement to set
	 */
	public void setProductimprovement(int productimprovement) {
		this.productimprovement = productimprovement;
	}
	/**
	 * @return the unassigned
	 */
	public int getUnassigned() {
		return unassigned;
	}
	/**
	 * @param unassigned the unassigned to set
	 */
	public void setUnassigned(int unassigned) {
		this.unassigned = unassigned;
	}
	/**
	 * @return the initialrelease
	 */
	public int getInitialrelease() {
		return initialrelease;
	}
	/**
	 * @param initialrelease the initialrelease to set
	 */
	public void setInitialrelease(int initialrelease) {
		this.initialrelease = initialrelease;
	}
	/**
	 * @return the customerchange
	 */
	public int getCustomerchange() {
		return customerchange;
	}
	/**
	 * @param customerchange the customerchange to set
	 */
	public void setCustomerchange(int customerchange) {
		this.customerchange = customerchange;
	}
	/**
	 * @return the backlog
	 */
	public int getBacklog() {
		return backlog;
	}
	/**
	 * @param backlog the backlog to set
	 */
	public void setBacklog(int backlog) {
		this.backlog = backlog;
	}
	/**
	 * @return the dueWeek
	 */
	public int getDueWeek() {
		return dueWeek;
	}
	/**
	 * @param dueWeek the dueWeek to set
	 */
	public void setDueWeek(int dueWeek) {
		this.dueWeek = dueWeek;
	}
	/**
	 * @return the dueMonth
	 */
	public int getDueMonth() {
		return dueMonth;
	}
	/**
	 * @param dueMonth the dueMonth to set
	 */
	public void setDueMonth(int dueMonth) {
		this.dueMonth = dueMonth;
	}
	/**
	 * @return the dueYear
	 */
	public int getDueYear() {
		return dueYear;
	}
	/**
	 * @param dueyear the dueYear to set
	 */
	public void setDueYear(int dueYear) {
		this.dueYear = dueYear;
	}
}
