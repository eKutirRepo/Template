/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBoilerBacklogReportMB.java
 * @Creation date: 17-Feb-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;

import com.geinfra.geaviation.pwi.data.PLMBoilerReportData;
import com.geinfra.geaviation.pwi.service.PLMBoilerReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

public class PLMBoilerBacklogReportMB {

	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMBoilerBacklogReportMB.class);
	private List<SelectItem> projectNameList = new ArrayList<SelectItem>();
	private List<SelectItem> taskNameList = new ArrayList<SelectItem>();
	private List<SelectItem> taskStateList = new ArrayList<SelectItem>();
	private List<SelectItem> taskNameListReset = new ArrayList<SelectItem>();
	private String totalRecordBacklogAptMsg;
	private int recordCounts = PLMConstants.N_15;
	private PLMBoilerReportData pwiReportvo=new PLMBoilerReportData();
	private List<SelectItem> pcInfoList1 = new ArrayList<SelectItem>();
	private String selPcName1;
	private String ownerName;
	
	
	/**
	 * @return the ownerName
	 */
	public String getOwnerName() {
		return ownerName;
	}

	/**
	 * @param ownerName the ownerName to set
	 */
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	/**
	 * @return the pcInfoList1
	 */
	public List<SelectItem> getPcInfoList1() {
		return pcInfoList1;
	}

	/**
	 * @param pcInfoList1 the pcInfoList1 to set
	 */
	public void setPcInfoList1(List<SelectItem> pcInfoList1) {
		this.pcInfoList1 = pcInfoList1;
	}

	/**
	 * @return the selPcName1
	 */
	public String getSelPcName1() {
		return selPcName1;
	}

	/**
	 * @param selPcName1 the selPcName1 to set
	 */
	public void setSelPcName1(String selPcName1) {
		this.selPcName1 = selPcName1;
	}

	/**
	 * @return the pwiReportvo
	 */
	public PLMBoilerReportData getPwiReportvo() {
		return pwiReportvo;
	}

	/**
	 * @param pwiReportvo the pwiReportvo to set
	 */
	public void setPwiReportvo(PLMBoilerReportData pwiReportvo) {
		this.pwiReportvo = pwiReportvo;
	}

	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @param recordCounts the recordCounts to set
	 */
	
	public void setRecordCounts(int recordCounts) {
		LOG.info("::::::::::::::::::" + recordCounts);
		PLMUtils.getServletSession(true).setAttribute("RecDropDown",
				recordCounts);
		this.recordCounts = recordCounts;
	}
	/**
	 * @return the totalRecordBacklogAptMsg
	 */
	public String getTotalRecordBacklogAptMsg() {
		return totalRecordBacklogAptMsg;
	}

	/**
	 * @param totalRecordBacklogAptMsg the totalRecordBacklogAptMsg to set
	 */
	public void setTotalRecordBacklogAptMsg(String totalRecordBacklogAptMsg) {
		this.totalRecordBacklogAptMsg = totalRecordBacklogAptMsg;
	}

	/**
	 * Holds the allOpenPrjName
	 */
	private boolean allOpenPrjName;
	
	/**
	 * Holds the allOpenTaskName
	 */
	private boolean allOpenTaskName;
	/**
	 * Holds the allOpenTaskState
	 */
	private boolean allOpenTaskState;
	/**
	 * Holds the projectNameList
	 */
	private List<String> selBacklogProjectName = new ArrayList<String>();
	/**
	 * Holds the taskStateList
	 */
	private List<String> selTaskStateForBacklogRpt = new ArrayList<String>();
	private	List <PLMBoilerReportData> backlogBoilerReportList= new ArrayList <PLMBoilerReportData>();
	/**
	 * Holds the taskNameList
	 */
	private List<String> selBacklogTaskName = new ArrayList<String>();
	private PLMBoilerReportServiceIfc plmBoilerReportService = null;
	
	
	/**
	 * @return the backlogBoilerReportList
	 */
	public List<PLMBoilerReportData> getBacklogBoilerReportList() {
		return backlogBoilerReportList;
	}

	/**
	 * @param backlogBoilerReportList the backlogBoilerReportList to set
	 */
	public void setBacklogBoilerReportList(
			List<PLMBoilerReportData> backlogBoilerReportList) {
		this.backlogBoilerReportList = backlogBoilerReportList;
	}

	/**
	 * @return the allOpenPrjName
	 */
	public boolean isAllOpenPrjName() {
		return allOpenPrjName;
	}

	/**
	 * @param allOpenPrjName the allOpenPrjName to set
	 */
	public void setAllOpenPrjName(boolean allOpenPrjName) {
		this.allOpenPrjName = allOpenPrjName;
	}

	/**
	 * @return the allOpenTaskName
	 */
	public boolean isAllOpenTaskName() {
		return allOpenTaskName;
	}

	/**
	 * @param allOpenTaskName the allOpenTaskName to set
	 */
	public void setAllOpenTaskName(boolean allOpenTaskName) {
		this.allOpenTaskName = allOpenTaskName;
	}
	
	/**
	 * @return the allOpenTaskState
	 */
	public boolean isAllOpenTaskState() {
		return allOpenTaskState;
	}

	/**
	 * @param allOpenTaskState the allOpenTaskState to set
	 */
	public void setAllOpenTaskState(boolean allOpenTaskState) {
		this.allOpenTaskState = allOpenTaskState;
	}

	/**
	 * @return the selTaskStateForBacklogRpt
	 */
	public List<String> getSelTaskStateForBacklogRpt() {
		return selTaskStateForBacklogRpt;
	}

	/**
	 * @param selTaskStateForBacklogRpt the selTaskStateForBacklogRpt to set
	 */
	public void setSelTaskStateForBacklogRpt(List<String> selTaskStateForBacklogRpt) {
		this.selTaskStateForBacklogRpt = selTaskStateForBacklogRpt;
	}

	/**
	 * @return the selBacklogProjectName
	 */
	public List<String> getSelBacklogProjectName() {
		return selBacklogProjectName;
	}

	/**
	 * @param selBacklogProjectName the selBacklogProjectName to set
	 */
	public void setSelBacklogProjectName(List<String> selBacklogProjectName) {
		this.selBacklogProjectName = selBacklogProjectName;
	}

	/**
	 * @return the selBacklogTaskName
	 */
	public List<String> getSelBacklogTaskName() {
		return selBacklogTaskName;
	}

	/**
	 * @param selBacklogTaskName the selBacklogTaskName to set
	 */
	public void setSelBacklogTaskName(List<String> selBacklogTaskName) {
		this.selBacklogTaskName = selBacklogTaskName;
	}

	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	
	
	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the projectNameList
	 */
	public List<SelectItem> getProjectNameList() {
		return projectNameList;
	}
	/**
	 * @param projectNameList the projectNameList to set
	 */
	public void setProjectNameList(List<SelectItem> projectNameList) {
		this.projectNameList = projectNameList;
	}
	/**
	 * @return the taskNameList
	 */
	public List<SelectItem> getTaskNameList() {
		return taskNameList;
	}
	/**
	 * @param taskNameList the taskNameList to set
	 */
	public void setTaskNameList(List<SelectItem> taskNameList) {
		this.taskNameList = taskNameList;
	}
	/**
	 * @return the taskStateList
	 */
	public List<SelectItem> getTaskStateList() {
		return taskStateList;
	}

	/**
	 * @param taskStateList the taskStateList to set
	 */
	public void setTaskStateList(List<SelectItem> taskStateList) {
		this.taskStateList = taskStateList;
	}

	/**
	 * @return the plmBoilerReportService
	 */
	public PLMBoilerReportServiceIfc getPlmBoilerReportService() {
		return plmBoilerReportService;
	}
	/**
	 * @param plmBoilerReportService the plmBoilerReportService to set
	 */
	public void setPlmBoilerReportService(
			PLMBoilerReportServiceIfc plmBoilerReportService) {
		this.plmBoilerReportService = plmBoilerReportService;
	}
	/**
	 * This method is used to get Task Information for projects
	 * 
	 * @param event
	 */
	public void fetchPrdouctConf1(ActionEvent event){
		LOG.info("Entering fetchPrdouctConf1 method");
		try{
			selPcName1="";
			 List <PLMBoilerReportData> pcInfoList = new ArrayList<PLMBoilerReportData>();
			  pcInfoList1 = new ArrayList<SelectItem>();
			  pcInfoList = plmBoilerReportService.fetchPCInfo(selBacklogProjectName,projectNameList,allOpenPrjName);
			  
			   for(int i=0;i<pcInfoList.size();i++){
				   pcInfoList1.add(new SelectItem(pcInfoList.get(i).getTaskName()));
				}
			taskNameList=pcInfoList1;
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting fetchPrdouctConf1 method");
	}
	/**
	 * This method is used to get Task Information for projects
	 * 
	 * @param event
	 */
	public void fetchTaskFromTaskState(ActionEvent event){
		LOG.info("Entering fetchTaskFromTaskState method");
		try{
			selPcName1="";
			 List <PLMBoilerReportData> pcInfoList = new ArrayList<PLMBoilerReportData>();
			  pcInfoList1 = new ArrayList<SelectItem>();
			  pcInfoList = plmBoilerReportService.fetchTaskFromTaskState(selTaskStateForBacklogRpt);
			  
			   for(int i=0;i<pcInfoList.size();i++){
				   pcInfoList1.add(new SelectItem(pcInfoList.get(i).getTaskName()));
				}
			taskNameList=pcInfoList1;
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting fetchTaskFromTaskState method");
	}
	/**
	 * This method is used for getProjectNameAndTaskList for project name and task names
	 * 
	 * @return String
	 */
	public String getProjectNameAndTaskList()
	{
		LOG.info("getProjectNameAndTaskList() Method");
		String fwdFlag = "";
		alertMessage = "";
		allOpenPrjName=false;
		allOpenTaskName=false;
		allOpenTaskState=false;
		selBacklogProjectName=new ArrayList<String>();
		selBacklogTaskName=new ArrayList<String>();
		selTaskStateForBacklogRpt = new ArrayList<String>();
		pwiReportvo.setSelectedPrjName("");
		pwiReportvo.setSelectedTaskName("");
		pwiReportvo.setSelectedTaskState("");
		try {
			commonMB.insertCannedRptRecordHitInfo("Backlog Report");
			if (PLMUtils.isEmptyList(pcInfoList1)) {
				pcInfoList1 = new ArrayList<SelectItem>();
			} else {
				pcInfoList1.clear();
			}
			 Map<String, List<SelectItem>> dropdownlist = plmBoilerReportService.getProjectNameAndTaskList();
			 taskNameList = (List<SelectItem>) dropdownlist.get("tasknamelist");
			 taskStateList = (List<SelectItem>) dropdownlist.get("taskstatelist");
			 taskNameListReset=taskNameList;
			 projectNameList=new ArrayList<SelectItem>();
			 taskNameList=new ArrayList<SelectItem>();
			fwdFlag = "backlogRptHome";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getProjectNameAndTaskList: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Backlog Report");
		} 
		return fwdFlag;
	}

	/**
	 * This method is used for getDropDownvalues for requirement and frameType
	 * 
	 * @return String
	 */
	public String generateBacklogAppReport() {
		LOG.info("get data from generateBacklogAppReport() Method");
		String fwdFlag = "";
				alertMessage = "";
				totalRecordBacklogAptMsg="";
		try { 
			 if (allOpenPrjName){
				 if(!PLMUtils.isEmptyList(projectNameList))
				      {
					 selBacklogProjectName = new ArrayList<String>();
						   for (int i = 0 ; i < projectNameList.size() ; i++ )
					  	     {
							String requireValue = projectNameList.get(i).getValue().toString();
							selBacklogProjectName.add(requireValue);
						    }
				      }
			}
			
			if (allOpenTaskName){
				 if(!PLMUtils.isEmptyList(taskNameList))
				      {
					 selBacklogTaskName = new ArrayList<String>();
						   for (int i = 0 ; i < taskNameList.size() ; i++ )
					  	     {
							String frameValue = taskNameList.get(i).getValue().toString();
							selBacklogTaskName.add(frameValue);
						    }
				      }
			}
			if (allOpenTaskState){
			 if(!PLMUtils.isEmptyList(taskStateList))
		      {
			 selTaskStateForBacklogRpt = new ArrayList<String>();
				   for (int i = 0 ; i < taskStateList.size() ; i++ )
			  	     {
					String requireValue = taskStateList.get(i).getValue().toString();
					selTaskStateForBacklogRpt.add(requireValue);
				    }
		      }
			}
		alertMessage = validateBacklogAptReport();
			 if (PLMConstants.EMPTY.equals(alertMessage)) {
				
				 backlogBoilerReportList = plmBoilerReportService.generateBacklogAppReport(selBacklogProjectName,allOpenPrjName,selBacklogTaskName,allOpenTaskName,selTaskStateForBacklogRpt,projectNameList,taskNameListReset,ownerName);
				 if(backlogBoilerReportList.size()>0){
					 totalRecordBacklogAptMsg="Total Records of Backlog Report:: "+backlogBoilerReportList.size();
					 recordCounts = PLMConstants.N_15;
	     		  fwdFlag = "backlogRptHomeDetails";
				 }
				 else{
					 alertMessage = "No Records Found for the Selected combination";
					 fwdFlag = "backlogRptHome";
				 }
			 }
			 else{
				 fwdFlag = "backlogRptHome";
			 }
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@generateBacklogAppReport: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Backlog Report");
		} 
		
		return fwdFlag;
	}

	/**
	 * This method is used for export to Excel of Back log Report
	 * 
	 */
	public void downloadBacklogSrchExcel1() throws PLMCommonException {
		
		LOG.info("Entering downloadBacklogSrchExcel Method");
		String reportName="Backlog Report_".concat(new SimpleDateFormat().format(new Date()));
		String fileName="Backlog Report";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					new PLMXlsxRptColumn("projectName", "Project Number", FormatType.TEXT, null, null, 15),
					new PLMXlsxRptColumn("prjState", "Project State", FormatType.TEXT, null, null, 15),
					new PLMXlsxRptColumn("taskName", "Task Name", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("taskState", "Task State", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("prjOwner", "Owner", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("taskCrtnDateNew", "Creation Date", FormatType.DATE, null, null, 20),
                    new PLMXlsxRptColumn("taskEstdFinishDateNew", "Estimated Finish Date", FormatType.DATE, null, null, 20),
                    new PLMXlsxRptColumn("cstmrName", "Customer Name", FormatType.TEXT, null, null, 30),
                    new PLMXlsxRptColumn("taskDescription", "Product Detail", FormatType.TEXT, null, null, 25),
                    new PLMXlsxRptColumn("cntName", "Contract No", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("taskDuration", "Est_Hours", FormatType.TEXT, null, null, 15),
			};
			
			/*PLMXlsxRptColumn[] critcolumns =
					new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("projectName", "Project Name", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("taskName", "Task Name", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("taskState", "Task State", FormatType.TEXT),
					new PLMXlsxRptColumn("ownerName", "Owner Name", FormatType.TEXT)
					};
			String testPrj="";
			String testTsk="";
			String testTskState="";
			if(!PLMUtils.isEmptyList(selBacklogProjectName)){
				testPrj=PLMUtils.convertListToString(selBacklogProjectName);
			}
			if(!PLMUtils.isEmptyList(selBacklogTaskName)){
				testTsk=PLMUtils.convertListToString(selBacklogTaskName);
			}
			if(!PLMUtils.isEmptyList(selTaskStateForBacklogRpt)){
				testTskState=PLMUtils.convertListToString(selTaskStateForBacklogRpt);
			}
			
			if(allOpenPrjName){
				pwiReportvo.setProjectName("Selected All");
			}else{
				pwiReportvo.setProjectName(testPrj);
			}
			
			if(allOpenTaskName){
				pwiReportvo.setTaskName("Selected All");
			}else{
				pwiReportvo.setTaskName(testTsk);
			}
			
			if(allOpenTaskState){
				pwiReportvo.setTaskState("Selected All");
			}else{
				pwiReportvo.setTaskState(testTskState);
			}
			pwiReportvo.setOwnerName(ownerName);
			
			excelUtil.export(backlogBoilerReportList, reportColumns, reportName, fileName, true, critcolumns, pwiReportvo);*/
			
			excelUtil.export(backlogBoilerReportList, reportColumns, reportName, fileName, false, null, pwiReportvo);
	 }
	
	/**
	 * This method is used for download Excel sheet for CR report
	 * 
	 */
	public void downloadBacklogSrchExcel() throws PLMCommonException {
		LOG.info("Entering downloadBacklogSrchExcel Method");
		FacesContext facesContext = FacesContext.getCurrentInstance();
	  	try {
			HttpServletResponse response = 
				(HttpServletResponse)facesContext.getExternalContext().getResponse();
			
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			
			response.setHeader("Content-disposition", 
					"attachment; filename="+"backlogReport.xlsx");
			
			OutputStream outputStream = response.getOutputStream();
			
			SXSSFWorkbook workbook = new SXSSFWorkbook();
			
			XSSFFont font = headerFont(workbook, 10);
			
			// Header Style
			XSSFCellStyle headerStyle = headerCell(workbook, font, HSSFColor.PALE_BLUE.index, true);

			XSSFFont cellfont = normalFont(workbook, 10);
			// Cell Style
			XSSFCellStyle cellStyle = normalCell(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
			
			SXSSFSheet sheet = (SXSSFSheet) workbook.createSheet("Backlog Report");
			
			int rowcount = 0;
			
			SXSSFCell cell=null;
		    
		    SXSSFRow row = (SXSSFRow) sheet.createRow(rowcount);
		    String[] columns = {"Project Number","Project State","Task Name","Task State","Owner","Creation Date","Estimated Finish Date","Customer Name","Product Detail",
		    		"Contract No","Est_Hours",};
			
        	for ( int i = 0 ; i < columns.length; i++ ) {
				cell = (SXSSFCell)row.createCell(i);
				cell. setCellValue(columns[i]);
				cell.setCellStyle(headerStyle);
			}
            	
				for(int i=0;i<backlogBoilerReportList.size();i++){
				
					PLMBoilerReportData dataObj = (PLMBoilerReportData) backlogBoilerReportList.get(i);
					
					row = (SXSSFRow) sheet.createRow(++rowcount);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getProjectName());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getPrjState());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getTaskName());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getTaskState());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getPrjOwner());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell.setCellStyle(cellStyle);
					if(!PLMUtils.isEmpty(dataObj.getTaskCrtnDate())){
						cell.setCellValue(dataObj.getTaskCrtnDate());
					}else{
						cell.setCellValue("");
					}
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_SIX);
					cell.setCellStyle(cellStyle);
					if(!PLMUtils.isEmpty(dataObj.getTaskEstdFinishDate())){
						cell.setCellValue(dataObj.getTaskEstdFinishDate());
					}else{
						cell.setCellValue("");
					}
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_SEVEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getCstmrName());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_EIGHT);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getTaskDescription());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_NINE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getCntName());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getTaskDuration());

					
		  	   }
			
             	row = (SXSSFRow) sheet.createRow(++rowcount);
             	row = (SXSSFRow) sheet.createRow(++rowcount);
             	
			    XSSFCellStyle ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
			    ftrStyle.setFont(font);
			    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
			    cell.setCellStyle(ftrStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_TWO));

				sheet.setColumnWidth(0,15*256);
				sheet.setColumnWidth(1,15*256);
				sheet.setColumnWidth(2,15*256);
				sheet.setColumnWidth(3,15*256);
				sheet.setColumnWidth(4,15*256);
				sheet.setColumnWidth(5,15*256);
				sheet.setColumnWidth(6,15*256);
				sheet.setColumnWidth(7,15*256);
				sheet.setColumnWidth(8,15*256);
				sheet.setColumnWidth(9,15*256);
				sheet.setColumnWidth(10,15*256);
				
				rowcount =0;
				sheet = (SXSSFSheet) workbook.createSheet("Input Filters");
				 row = (SXSSFRow) sheet.createRow(rowcount);
				    String[] columns1 = {"Project Name","Task State","Task Name"};
		        	for ( int i = 0 ; i < columns1.length; i++ ) {
						cell = (SXSSFCell)row.createCell(i);
						cell. setCellValue(columns1[i]);
						cell.setCellStyle(headerStyle);
					}
		        	
		         	for (int i = 0; i < selBacklogProjectName.size() || i < selBacklogTaskName.size() || i < selTaskStateForBacklogRpt.size(); i++) {
		         		row = (SXSSFRow) sheet.createRow(++rowcount);
						
		         		if (i < selBacklogProjectName.size()) {
		         			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
							cell.setCellStyle(cellStyle);
							cell.setCellValue(selBacklogProjectName.get(i));
						 }
						 if (i < selTaskStateForBacklogRpt.size()) {
							 cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellStyle(cellStyle);
								cell.setCellValue(selTaskStateForBacklogRpt.get(i));
						 }
						 if (i < selBacklogTaskName.size()) {
							 cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
							 cell.setCellStyle(cellStyle);
							 cell.setCellValue(selBacklogTaskName.get(i));
						 }
					}
		         	row = (SXSSFRow) sheet.createRow(++rowcount);
	             	row = (SXSSFRow) sheet.createRow(++rowcount);
	             	
				    ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
				    ftrStyle.setFont(font);
				    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
				    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
				    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
				    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
				    cell.setCellStyle(ftrStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_TWO));

					sheet.setColumnWidth(0,15*256);
					sheet.setColumnWidth(1,15*256);
					sheet.setColumnWidth(2,15*256);
            workbook.write(outputStream);
			
			outputStream.flush();
			
			outputStream.close();
			
		} catch (IOException ioex) {
			ioex.printStackTrace();
		} finally {
			facesContext.responseComplete();
	  	}
	  	LOG.info("Exiting downloadBacklogSrchExcel Method");
	} 	
	
	 private XSSFFont headerFont(SXSSFWorkbook wb, int size){
			XSSFFont font = (XSSFFont) wb.createFont();
			font.setFontName(PLMConstants.EXCEL_FONT_NAME);
			font.setFontHeightInPoints((short)size);
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			return font;
		}
		
		private XSSFFont normalFont(SXSSFWorkbook wb, int size){
			XSSFFont font = (XSSFFont) wb.createFont();
			font.setFontName(PLMConstants.EXCEL_FONT_NAME);
			font.setFontHeightInPoints((short)size);
			return font;
		}
		
		private XSSFCellStyle headerCell(SXSSFWorkbook wb, XSSFFont font, short bgcolor, boolean wrap){
			XSSFCellStyle hCell = normalCell(wb, font, XSSFCellStyle.SOLID_FOREGROUND, wrap);
			//FONT
			hCell.setFont(font);
			
			//HORIZONTAL ALIGNMENT
			hCell.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			
			//COLOR
			hCell.setFillForegroundColor(bgcolor);
			return hCell;
		}
		
		private XSSFCellStyle normalCell(SXSSFWorkbook wb, XSSFFont font, short fillPattern, boolean wrap){
			// Cell Style
			XSSFCellStyle cellStyle = (XSSFCellStyle)wb.createCellStyle();
			
			//Set Font
			cellStyle.setFont(font);
			//WRAP TEXT
			cellStyle.setWrapText(wrap);
			
			//VERTICAL ALIGNMENT
			cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			
			//BORDERS
			cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			
			//FILL PATTERN
			cellStyle.setFillPattern(fillPattern);
			return cellStyle;
		}
		/**
		 * This method is used for Bordering Cell in XLS
		 * 
		 * @return StringBuffer
		 */
		private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
			style.setBorderTop(XSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			style.setBorderRight(XSSFCellStyle.BORDER_THIN);
			return style;
		}

	/**
	 * This method is used for validateBacklogAptReport
	 * 
	 * @return String
	 */
	public String  validateBacklogAptReport(){
		alertMessage ="";
		if (PLMUtils.isEmptyList(selBacklogProjectName) && PLMUtils.isEmptyList(selBacklogTaskName)  && PLMUtils.isEmptyList(selTaskStateForBacklogRpt)) {
			alertMessage = "Please Select atleast one Task State";
		}if(!PLMUtils.isValidOwner(ownerName)){
			alertMessage = "Owner Name only accepts Numbers separated by comma";
		}if(!PLMUtils.isEmpty(ownerName) && ownerName.matches("^[,]*"))
			alertMessage = "Owner Name should not contain only commas";
		
		return alertMessage;
	}
	public void resetBacklogAppReport(){
		alertMessage = "";
		ownerName="";
		allOpenPrjName=false;
		allOpenTaskName=false;
		allOpenTaskState=false;
		projectNameList=new ArrayList<SelectItem>();
		taskNameList=new ArrayList<SelectItem>();
		totalRecordBacklogAptMsg="";
		pwiReportvo.setSelectedPrjName("");
		pwiReportvo.setSelectedTaskName("");
		selBacklogProjectName = new ArrayList<String>();
		selBacklogTaskName = new ArrayList<String>();
		selTaskStateForBacklogRpt = new ArrayList<String>();
	}
	/**
	 * This method is used for auto complete feature
	 * 
	 * @return String
	 */
	/*public List<String> projectFamilyAutocomplete(Object projectFamilySuggest) {
		LOG.info("Inside projectFamilyAutocomplete method... PLMBoilerBacklogReportMB");
		String pref = (String) projectFamilySuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (projectNameList.size() > 0) {
				for (SelectItem item : projectNameList) {
					if (!item.getLabel().equals("")
							&& item.getLabel().startsWith(
									pref.toUpperCase(Locale.getDefault()))) {
						result.add(item.getLabel());
						
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@projectFamilyAutocomplete in PLMBoilerBacklogReportMB:",
					exception);
		}
		LOG.info("Existing projectFamilyAutocomplete method... PLMBoilerBacklogReportMB");
		return result;
	}*/
	public void projectFamilyAutocomplete(){
		LOG.info("Entering projectFamilyAutocomplete method");
		try{
			projectNameList=new ArrayList<SelectItem>();
			if(!PLMUtils.isEmpty(pwiReportvo.getSelectedPrjName())){
			projectNameList = plmBoilerReportService.projectFamilyAutocomplete(pwiReportvo.getSelectedPrjName().trim());
			if(PLMUtils.isEmptyList(projectNameList)){
				projectNameList=new ArrayList<SelectItem>();
				 alertMessage = "No Projects Found for the Search";
			}
			}else{
				 alertMessage = "Please type some text in the box";
			}
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting projectFamilyAutocomplete method");
	}
	/**
	 * This method is used for auto complete feature
	 * 
	 * @return String
	 */
	/*public List<String> taskFamilyAutocomplete(Object partFamilySuggest) {
		LOG.info("Inside taskFamilyAutocomplete method... PLMBoilerBacklogReportMB");
		String pref = (String) partFamilySuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (taskNameList.size() > 0) {
				for (SelectItem item : taskNameList) {
					if (!item.getLabel().equals("")
							&& item.getLabel().startsWith(
									pref.toUpperCase(Locale.getDefault()))) {
						result.add(item.getLabel());
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@taskFamilyAutocomplete in PLMBoilerBacklogReportMB:",
					exception);
		}
		LOG.info("Existing taskFamilyAutocomplete method... PLMBoilerBacklogReportMB");
		return result;
	}*/	
	public void taskFamilyAutocomplete(){
		LOG.info("Entering taskFamilyAutocomplete method");
		try{
			taskNameList=new ArrayList<SelectItem>();
			if(!PLMUtils.isEmpty(pwiReportvo.getSelectedTaskName())){
				taskNameList = plmBoilerReportService.taskFamilyAutocomplete(pwiReportvo.getSelectedTaskName().trim());
				if(PLMUtils.isEmptyList(taskNameList)){
					taskNameList=new ArrayList<SelectItem>();
					 alertMessage = "No Tasks Found for the Search";
				}
				}else{
					 alertMessage = "Please type some text in the box";
				}
			
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting taskFamilyAutocomplete method");
	}
}
