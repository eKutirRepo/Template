/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMPRSTaskRouteData.java
 * @Creation date: 11-Sept-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMPRSTaskRouteData {

	
	// PROPERTIES *************************************************************

	private String routeName;
	
	private String id;
	
	private String name;
	
	private String title;
	
	private String order;
	
	private String revision;
	
	private String state;
	
	private String asignee;
	
	private String action;
	
	private String approvalStatus;

	private String dueDate;
	
	private String comments;
	
	private String completedDate;
	
	private String color;
	
	
	// CONSTRUCTOR ************************************************************
	public PLMPRSTaskRouteData (String routeName,
						String id, 
						String name,
						String title, 
						String order, 
						String revision,
						String state,
						String asignee,
						String action,
						String approvalStatus,
						String dueDate,
						String comments,
						String completedDate) {  
		this.routeName = routeName;
		this.id = id;
		this.name = name;
		this.title = title;
		this.order = order;
		this.revision = revision;
		this.state = state;
		this.action = action;
		this.asignee = asignee;
		this.approvalStatus = approvalStatus;
		this.dueDate = dueDate;
		this.comments = comments;
		this.completedDate = completedDate;
	}
	
	// ACCESSOR METHODS *******************************************************
	
	public String getRouteName() {
		return routeName;
	}

	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

	public String getRevision() {
		return revision;
	}

	public void setRevision(String revision) {
		this.revision = revision;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getAsignee() {
		return asignee;
	}

	public void setAsignee(String asignee) {
		this.asignee = asignee;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getCompletedDate() {
		return completedDate;
	}

	public void setCompletedDate(String completedDate) {
		this.completedDate = completedDate;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	// OVERRIDEN METHODS ******************************************************
	/**
	 * Returns the SalesOrder information as a String
	 * 
	 * @return type (String) 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer strSalesOrder = new StringBuffer();
		
		strSalesOrder
			.append(routeName).append(" ")
			.append(id).append(" ")
			.append(name).append(" ")
			.append(title).append(" ")
			.append(order).append(" ")
			.append(revision).append(" ")
			.append(state).append(" ")
			.append(asignee).append(" ")
			.append(action).append(" ")
			.append(approvalStatus).append(" ")
			.append(dueDate).append(" ")
			.append(comments).append(" ")
			.append(completedDate).append(" ")
			;
		
		return strSalesOrder.toString();
	}
	
}
