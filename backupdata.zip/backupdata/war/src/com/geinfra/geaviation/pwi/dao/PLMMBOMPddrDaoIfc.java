/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMMBOMPddrDaoIfc.java
 * @Creation date: 14-March-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMMBOMPddrData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMMBOMPddrDaoIfc {
	/**
	 * This method is used to get drop down values
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getRevisions(String partName)throws PLMCommonException;

	/**
	 * This method is used to get drop down values
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getPlantNames(String partName,String revision)throws PLMCommonException;
	
	
	/**
	 * This method is used to get MBOM Pddr Report
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMMBOMPddrData> getMBOMPddrReport(String partName,String plantId,String revisionName,String revisionId)throws PLMCommonException;
	
	/**
	 * This method is used to get Plant Name count
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public int getPlantNamesCount(String partName)throws PLMCommonException;


}
