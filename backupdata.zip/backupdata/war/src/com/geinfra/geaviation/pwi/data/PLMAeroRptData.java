/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMAeroRptData.java
 * @Creation date: 06-Apr-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMAeroRptData {
	//Logical Features
	/**
	 * Holds the level
	 */
	private int level;
	/**
	 * Holds the displayNm
	 */
	private String displayNm;

	/**
	 * Holds the revision
	 */
	private String revision;

	/**
	 * Holds the childName
	 */
	private String childName;
	/**
	 * Holds the type
	 */
	private String type;
	/**
	 * Holds the displayText
	 */
	private String displayText;
	/**
	 * Holds the owner
	 */
	private String owner;
	/**
	 * Holds the alertAeroMessage
	 */
	private String designResponse;
	/**
	 * Holds the state
	 */
	private String state;
	/**
	 * Holds the findNum
	 */
	private String findNum;
	/**
	 * Holds the findNum
	 */
	private String quantity;
	/**
	 * Holds the referenceDesign
	 */
	private String referenceDesign;
	/**
	 * Holds the componentLoc
	 */
	private String componentLoc;
	/**
	 * Holds the usage
	 */
	private String usage;
	/**
	 * Holds the ruleType
	 */
	private String ruleType;
	
	//Configuration Features
	/**
	 * Holds the hardWrNmRev
	 */
	private String hardWrNmRev;
	/**
	 * Holds the confFeatureRev
	 */
	private String confFeatureRev;
	/**
	 * Holds the confOptionRev
	 */
	private String confOptionRev;
	/**
	 * Holds the confDisplyNmRev
	 */
	private String confDisplyNmRev;
	/**
	 * Holds the hardWrName
	 */
	private String hardWrName;
	/**
	 * Holds the confFeatureName
	 */
	private String confFeatureName;
	/**
	 * Holds the confOptionName
	 */
	private String confOptionName;
	/**
	 * Holds the confName
	 */
	private String confName;
	/**
	 * Holds the hardWrType
	 */
	private String hardWrType;
	/**
	 * Holds the confFeatureType
	 */
	private String confFeatureType;
	/**
	 * Holds the confOptionType
	 */
	private String confOptionType;
	/**
	 * Holds the confType
	 */
	private String confType;
	/**
	 * Holds the hardWrState
	 */
	private String hardWrState;
	/**
	 * Holds the confFeatureState
	 */
	private String confFeatureState;
	/**
	 * Holds the confOptionState
	 */
	private String confOptionState;
	/**
	 * Holds the confState
	 */
	private String confState;
	/**
	 * Holds the confFeatureState
	 */
	private String confFeatureDispTxt;
	/**
	 * Holds the confOptionState
	 */
	private String confOptionDispTxt;
	/**
	 * Holds the confdisplayTxt
	 */
	private String confdisplayTxt;
	/**
	 * Holds the confFeatureSeqNo
	 */
	private String confFeatureSeqNo;
	/**
	 * Holds the confOptionSeqNo
	 */
	private String confOptionSeqNo;
	/**
	 * Holds the seqNo
	 */
	private String seqNo;
	/**
	 * Holds the confFeatureDefaultSel
	 */
	private String confFeatureDefaultSel;
	/**
	 * Holds the confOptionDefaultSel
	 */
	private String confOptionDefaultSel;
	/**
	 * Holds the defaultSel
	 */
	private String defaultSel;
	/**
	 * Holds the confFeatureSingleMultiple
	 */
	private String confFeatureSingleMultiple;
	/**
	 * Holds the confOptionSingleMultiple
	 */
	private String confOptionSingleMultiple;
	/**
	 * Holds the singleMultiple
	 */
	private String singleMultiple;
	/**
	 * Holds the confFeatureMustMay
	 */
	private String confFeatureMustMay;
	/**
	 * Holds the confOptionMustMay
	 */
	private String confOptionMustMay;
	/**
	 * Holds the mustMay
	 */
	private String mustMay;
	/**
	 * Holds the confFeaturekeyinType
	 */
	private String confFeaturekeyinType;
	/**
	 * Holds the confOptionkeyinType
	 */
	private String confOptionkeyinType;
	/**
	 * Holds the keyinType
	 */
	private String keyinType;
	/**
	 * Holds the confFeatureRuleType
	 */
	private String confFeatureRuleType;
	/**
	 * Holds the confOptionRuleType
	 */
	private String confOptionRuleType;
	/**
	 * Holds the confRuleType
	 */
	private String confRuleType;
	/**
	 * Holds the mandatory
	 */
	private String mandatory;
	/**
	 * Holds the confFeatureInhertnc
	 */
	private String confFeatureInhertnc;
	/**
	 * Holds the confOptionInhertnc
	 */
	private String confOptionInhertnc;
	/**
	 * Holds the inheritance
	 */
	private String inheritance;
	/**
	 * Holds the confFeaturelistPrice
	 */
	private String confFeaturelistPrice;
	/**
	 * Holds the confOptionlistPrice
	 */
	private String confOptionlistPrice;
	/**
	 * Holds the listPrice
	 */
	private String listPrice;
	/**
	 * Holds the confFeatureMinQty
	 */
	private String confFeatureMinQty;
	/**
	 * Holds the confOptionMinQty
	 */
	private String confOptionMinQty;
	/**
	 * Holds the minQty
	 */
	private String minQty;
	/**
	 * Holds the confFeatureMaxQty
	 */
	private String confFeatureMaxQty;
	/**
	 * Holds the confOptionMaxQty
	 */
	private String confOptionMaxQty;
	/**
	 * Holds the maxQty
	 */
	private String maxQty;
	/**
	 * Holds the hardWrOwner
	 */
	private String hardWrOwner;
	/**
	 * Holds the confFeatureOwner
	 */
	private String confFeatureOwner;
	/**
	 * Holds the confOptionOwner
	 */
	private String confOptionOwner;
	/**
	 * Holds the confOwner
	 */
	private String confOwner;
	/**
	 * Holds the hardWrDesgnRes
	 */
	private String hardWrDesgnRes;
	/**
	 * Holds the confOptionDesgnRes
	 */
	private String confOptionDesgnRes;
	/**
	 * Holds the confDesignResp
	 */
	private String confDesignResp;
	/**
	 * @return the level
	 */
	public int getLevel() {
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(int level) {
		this.level = level;
	}
	/**
	 * @return the displayNm
	 */
	public String getDisplayNm() {
		return displayNm;
	}
	/**
	 * @param displayNm the displayNm to set
	 */
	public void setDisplayNm(String displayNm) {
		this.displayNm = displayNm;
	}
	/**
	 * @return the revision
	 */
	public String getRevision() {
		return revision;
	}
	/**
	 * @param revision the revision to set
	 */
	public void setRevision(String revision) {
		this.revision = revision;
	}
	/**
	 * @return the childName
	 */
	public String getChildName() {
		return childName;
	}
	/**
	 * @param childName the childName to set
	 */
	public void setChildName(String childName) {
		this.childName = childName;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the displayText
	 */
	public String getDisplayText() {
		return displayText;
	}
	/**
	 * @param displayText the displayText to set
	 */
	public void setDisplayText(String displayText) {
		this.displayText = displayText;
	}
	/**
	 * @return the owner
	 */
	public String getOwner() {
		return owner;
	}
	/**
	 * @param owner the owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}
	/**
	 * @return the designResponse
	 */
	public String getDesignResponse() {
		return designResponse;
	}
	/**
	 * @param designResponse the designResponse to set
	 */
	public void setDesignResponse(String designResponse) {
		this.designResponse = designResponse;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the findNum
	 */
	public String getFindNum() {
		return findNum;
	}
	/**
	 * @param findNum the findNum to set
	 */
	public void setFindNum(String findNum) {
		this.findNum = findNum;
	}
	/**
	 * @return the quantity
	 */
	public String getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return the referenceDesign
	 */
	public String getReferenceDesign() {
		return referenceDesign;
	}
	/**
	 * @param referenceDesign the referenceDesign to set
	 */
	public void setReferenceDesign(String referenceDesign) {
		this.referenceDesign = referenceDesign;
	}
	/**
	 * @return the componentLoc
	 */
	public String getComponentLoc() {
		return componentLoc;
	}
	/**
	 * @param componentLoc the componentLoc to set
	 */
	public void setComponentLoc(String componentLoc) {
		this.componentLoc = componentLoc;
	}
	/**
	 * @return the usage
	 */
	public String getUsage() {
		return usage;
	}
	/**
	 * @param usage the usage to set
	 */
	public void setUsage(String usage) {
		this.usage = usage;
	}
	/**
	 * @return the ruleType
	 */
	public String getRuleType() {
		return ruleType;
	}
	/**
	 * @param ruleType the ruleType to set
	 */
	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}
	/**
	 * @return the hardWrNmRev
	 */
	public String getHardWrNmRev() {
		return hardWrNmRev;
	}
	/**
	 * @param hardWrNmRev the hardWrNmRev to set
	 */
	public void setHardWrNmRev(String hardWrNmRev) {
		this.hardWrNmRev = hardWrNmRev;
	}
	/**
	 * @return the confFeatureRev
	 */
	public String getConfFeatureRev() {
		return confFeatureRev;
	}
	/**
	 * @param confFeatureRev the confFeatureRev to set
	 */
	public void setConfFeatureRev(String confFeatureRev) {
		this.confFeatureRev = confFeatureRev;
	}
	/**
	 * @return the confOptionRev
	 */
	public String getConfOptionRev() {
		return confOptionRev;
	}
	/**
	 * @param confOptionRev the confOptionRev to set
	 */
	public void setConfOptionRev(String confOptionRev) {
		this.confOptionRev = confOptionRev;
	}
	/**
	 * @return the confDisplyNmRev
	 */
	public String getConfDisplyNmRev() {
		return confDisplyNmRev;
	}
	/**
	 * @param confDisplyNmRev the confDisplyNmRev to set
	 */
	public void setConfDisplyNmRev(String confDisplyNmRev) {
		this.confDisplyNmRev = confDisplyNmRev;
	}
	/**
	 * @return the hardWrName
	 */
	public String getHardWrName() {
		return hardWrName;
	}
	/**
	 * @param hardWrName the hardWrName to set
	 */
	public void setHardWrName(String hardWrName) {
		this.hardWrName = hardWrName;
	}
	/**
	 * @return the confFeatureName
	 */
	public String getConfFeatureName() {
		return confFeatureName;
	}
	/**
	 * @param confFeatureName the confFeatureName to set
	 */
	public void setConfFeatureName(String confFeatureName) {
		this.confFeatureName = confFeatureName;
	}
	/**
	 * @return the confOptionName
	 */
	public String getConfOptionName() {
		return confOptionName;
	}
	/**
	 * @param confOptionName the confOptionName to set
	 */
	public void setConfOptionName(String confOptionName) {
		this.confOptionName = confOptionName;
	}
	/**
	 * @return the confName
	 */
	public String getConfName() {
		return confName;
	}
	/**
	 * @param confName the confName to set
	 */
	public void setConfName(String confName) {
		this.confName = confName;
	}
	/**
	 * @return the hardWrType
	 */
	public String getHardWrType() {
		return hardWrType;
	}
	/**
	 * @param hardWrType the hardWrType to set
	 */
	public void setHardWrType(String hardWrType) {
		this.hardWrType = hardWrType;
	}
	/**
	 * @return the confFeatureType
	 */
	public String getConfFeatureType() {
		return confFeatureType;
	}
	/**
	 * @param confFeatureType the confFeatureType to set
	 */
	public void setConfFeatureType(String confFeatureType) {
		this.confFeatureType = confFeatureType;
	}
	/**
	 * @return the confOptionType
	 */
	public String getConfOptionType() {
		return confOptionType;
	}
	/**
	 * @param confOptionType the confOptionType to set
	 */
	public void setConfOptionType(String confOptionType) {
		this.confOptionType = confOptionType;
	}
	/**
	 * @return the confType
	 */
	public String getConfType() {
		return confType;
	}
	/**
	 * @param confType the confType to set
	 */
	public void setConfType(String confType) {
		this.confType = confType;
	}
	/**
	 * @return the hardWrState
	 */
	public String getHardWrState() {
		return hardWrState;
	}
	/**
	 * @param hardWrState the hardWrState to set
	 */
	public void setHardWrState(String hardWrState) {
		this.hardWrState = hardWrState;
	}
	/**
	 * @return the confFeatureState
	 */
	public String getConfFeatureState() {
		return confFeatureState;
	}
	/**
	 * @param confFeatureState the confFeatureState to set
	 */
	public void setConfFeatureState(String confFeatureState) {
		this.confFeatureState = confFeatureState;
	}
	/**
	 * @return the confOptionState
	 */
	public String getConfOptionState() {
		return confOptionState;
	}
	/**
	 * @param confOptionState the confOptionState to set
	 */
	public void setConfOptionState(String confOptionState) {
		this.confOptionState = confOptionState;
	}
	/**
	 * @return the confState
	 */
	public String getConfState() {
		return confState;
	}
	/**
	 * @param confState the confState to set
	 */
	public void setConfState(String confState) {
		this.confState = confState;
	}
	/**
	 * @return the confFeatureDispTxt
	 */
	public String getConfFeatureDispTxt() {
		return confFeatureDispTxt;
	}
	/**
	 * @param confFeatureDispTxt the confFeatureDispTxt to set
	 */
	public void setConfFeatureDispTxt(String confFeatureDispTxt) {
		this.confFeatureDispTxt = confFeatureDispTxt;
	}
	/**
	 * @return the confOptionDispTxt
	 */
	public String getConfOptionDispTxt() {
		return confOptionDispTxt;
	}
	/**
	 * @param confOptionDispTxt the confOptionDispTxt to set
	 */
	public void setConfOptionDispTxt(String confOptionDispTxt) {
		this.confOptionDispTxt = confOptionDispTxt;
	}
	/**
	 * @return the confdisplayTxt
	 */
	public String getConfdisplayTxt() {
		return confdisplayTxt;
	}
	/**
	 * @param confdisplayTxt the confdisplayTxt to set
	 */
	public void setConfdisplayTxt(String confdisplayTxt) {
		this.confdisplayTxt = confdisplayTxt;
	}
	/**
	 * @return the confFeatureSeqNo
	 */
	public String getConfFeatureSeqNo() {
		return confFeatureSeqNo;
	}
	/**
	 * @param confFeatureSeqNo the confFeatureSeqNo to set
	 */
	public void setConfFeatureSeqNo(String confFeatureSeqNo) {
		this.confFeatureSeqNo = confFeatureSeqNo;
	}
	/**
	 * @return the confOptionSeqNo
	 */
	public String getConfOptionSeqNo() {
		return confOptionSeqNo;
	}
	/**
	 * @param confOptionSeqNo the confOptionSeqNo to set
	 */
	public void setConfOptionSeqNo(String confOptionSeqNo) {
		this.confOptionSeqNo = confOptionSeqNo;
	}
	/**
	 * @return the seqNo
	 */
	public String getSeqNo() {
		return seqNo;
	}
	/**
	 * @param seqNo the seqNo to set
	 */
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}
	/**
	 * @return the confFeatureDefaultSel
	 */
	public String getConfFeatureDefaultSel() {
		return confFeatureDefaultSel;
	}
	/**
	 * @param confFeatureDefaultSel the confFeatureDefaultSel to set
	 */
	public void setConfFeatureDefaultSel(String confFeatureDefaultSel) {
		this.confFeatureDefaultSel = confFeatureDefaultSel;
	}
	/**
	 * @return the confOptionDefaultSel
	 */
	public String getConfOptionDefaultSel() {
		return confOptionDefaultSel;
	}
	/**
	 * @param confOptionDefaultSel the confOptionDefaultSel to set
	 */
	public void setConfOptionDefaultSel(String confOptionDefaultSel) {
		this.confOptionDefaultSel = confOptionDefaultSel;
	}
	/**
	 * @return the defaultSel
	 */
	public String getDefaultSel() {
		return defaultSel;
	}
	/**
	 * @param defaultSel the defaultSel to set
	 */
	public void setDefaultSel(String defaultSel) {
		this.defaultSel = defaultSel;
	}
	/**
	 * @return the confFeatureSingleMultiple
	 */
	public String getConfFeatureSingleMultiple() {
		return confFeatureSingleMultiple;
	}
	/**
	 * @param confFeatureSingleMultiple the confFeatureSingleMultiple to set
	 */
	public void setConfFeatureSingleMultiple(String confFeatureSingleMultiple) {
		this.confFeatureSingleMultiple = confFeatureSingleMultiple;
	}
	/**
	 * @return the confOptionSingleMultiple
	 */
	public String getConfOptionSingleMultiple() {
		return confOptionSingleMultiple;
	}
	/**
	 * @param confOptionSingleMultiple the confOptionSingleMultiple to set
	 */
	public void setConfOptionSingleMultiple(String confOptionSingleMultiple) {
		this.confOptionSingleMultiple = confOptionSingleMultiple;
	}
	/**
	 * @return the singleMultiple
	 */
	public String getSingleMultiple() {
		return singleMultiple;
	}
	/**
	 * @param singleMultiple the singleMultiple to set
	 */
	public void setSingleMultiple(String singleMultiple) {
		this.singleMultiple = singleMultiple;
	}
	/**
	 * @return the confFeatureMustMay
	 */
	public String getConfFeatureMustMay() {
		return confFeatureMustMay;
	}
	/**
	 * @param confFeatureMustMay the confFeatureMustMay to set
	 */
	public void setConfFeatureMustMay(String confFeatureMustMay) {
		this.confFeatureMustMay = confFeatureMustMay;
	}
	/**
	 * @return the confOptionMustMay
	 */
	public String getConfOptionMustMay() {
		return confOptionMustMay;
	}
	/**
	 * @param confOptionMustMay the confOptionMustMay to set
	 */
	public void setConfOptionMustMay(String confOptionMustMay) {
		this.confOptionMustMay = confOptionMustMay;
	}
	/**
	 * @return the mustMay
	 */
	public String getMustMay() {
		return mustMay;
	}
	/**
	 * @param mustMay the mustMay to set
	 */
	public void setMustMay(String mustMay) {
		this.mustMay = mustMay;
	}
	/**
	 * @return the confFeaturekeyinType
	 */
	public String getConfFeaturekeyinType() {
		return confFeaturekeyinType;
	}
	/**
	 * @param confFeaturekeyinType the confFeaturekeyinType to set
	 */
	public void setConfFeaturekeyinType(String confFeaturekeyinType) {
		this.confFeaturekeyinType = confFeaturekeyinType;
	}
	/**
	 * @return the confOptionkeyinType
	 */
	public String getConfOptionkeyinType() {
		return confOptionkeyinType;
	}
	/**
	 * @param confOptionkeyinType the confOptionkeyinType to set
	 */
	public void setConfOptionkeyinType(String confOptionkeyinType) {
		this.confOptionkeyinType = confOptionkeyinType;
	}
	/**
	 * @return the keyinType
	 */
	public String getKeyinType() {
		return keyinType;
	}
	/**
	 * @param keyinType the keyinType to set
	 */
	public void setKeyinType(String keyinType) {
		this.keyinType = keyinType;
	}
	/**
	 * @return the confFeatureRuleType
	 */
	public String getConfFeatureRuleType() {
		return confFeatureRuleType;
	}
	/**
	 * @param confFeatureRuleType the confFeatureRuleType to set
	 */
	public void setConfFeatureRuleType(String confFeatureRuleType) {
		this.confFeatureRuleType = confFeatureRuleType;
	}
	/**
	 * @return the confOptionRuleType
	 */
	public String getConfOptionRuleType() {
		return confOptionRuleType;
	}
	/**
	 * @param confOptionRuleType the confOptionRuleType to set
	 */
	public void setConfOptionRuleType(String confOptionRuleType) {
		this.confOptionRuleType = confOptionRuleType;
	}
	/**
	 * @return the confRuleType
	 */
	public String getConfRuleType() {
		return confRuleType;
	}
	/**
	 * @param confRuleType the confRuleType to set
	 */
	public void setConfRuleType(String confRuleType) {
		this.confRuleType = confRuleType;
	}
	/**
	 * @return the mandatory
	 */
	public String getMandatory() {
		return mandatory;
	}
	/**
	 * @param mandatory the mandatory to set
	 */
	public void setMandatory(String mandatory) {
		this.mandatory = mandatory;
	}
	/**
	 * @return the confFeatureInhertnc
	 */
	public String getConfFeatureInhertnc() {
		return confFeatureInhertnc;
	}
	/**
	 * @param confFeatureInhertnc the confFeatureInhertnc to set
	 */
	public void setConfFeatureInhertnc(String confFeatureInhertnc) {
		this.confFeatureInhertnc = confFeatureInhertnc;
	}
	/**
	 * @return the confOptionInhertnc
	 */
	public String getConfOptionInhertnc() {
		return confOptionInhertnc;
	}
	/**
	 * @param confOptionInhertnc the confOptionInhertnc to set
	 */
	public void setConfOptionInhertnc(String confOptionInhertnc) {
		this.confOptionInhertnc = confOptionInhertnc;
	}
	/**
	 * @return the inheritance
	 */
	public String getInheritance() {
		return inheritance;
	}
	/**
	 * @param inheritance the inheritance to set
	 */
	public void setInheritance(String inheritance) {
		this.inheritance = inheritance;
	}
	/**
	 * @return the confFeaturelistPrice
	 */
	public String getConfFeaturelistPrice() {
		return confFeaturelistPrice;
	}
	/**
	 * @param confFeaturelistPrice the confFeaturelistPrice to set
	 */
	public void setConfFeaturelistPrice(String confFeaturelistPrice) {
		this.confFeaturelistPrice = confFeaturelistPrice;
	}
	/**
	 * @return the confOptionlistPrice
	 */
	public String getConfOptionlistPrice() {
		return confOptionlistPrice;
	}
	/**
	 * @param confOptionlistPrice the confOptionlistPrice to set
	 */
	public void setConfOptionlistPrice(String confOptionlistPrice) {
		this.confOptionlistPrice = confOptionlistPrice;
	}
	/**
	 * @return the listPrice
	 */
	public String getListPrice() {
		return listPrice;
	}
	/**
	 * @param listPrice the listPrice to set
	 */
	public void setListPrice(String listPrice) {
		this.listPrice = listPrice;
	}
	/**
	 * @return the confFeatureMinQty
	 */
	public String getConfFeatureMinQty() {
		return confFeatureMinQty;
	}
	/**
	 * @param confFeatureMinQty the confFeatureMinQty to set
	 */
	public void setConfFeatureMinQty(String confFeatureMinQty) {
		this.confFeatureMinQty = confFeatureMinQty;
	}
	/**
	 * @return the confOptionMinQty
	 */
	public String getConfOptionMinQty() {
		return confOptionMinQty;
	}
	/**
	 * @param confOptionMinQty the confOptionMinQty to set
	 */
	public void setConfOptionMinQty(String confOptionMinQty) {
		this.confOptionMinQty = confOptionMinQty;
	}
	/**
	 * @return the minQty
	 */
	public String getMinQty() {
		return minQty;
	}
	/**
	 * @param minQty the minQty to set
	 */
	public void setMinQty(String minQty) {
		this.minQty = minQty;
	}
	/**
	 * @return the confFeatureMaxQty
	 */
	public String getConfFeatureMaxQty() {
		return confFeatureMaxQty;
	}
	/**
	 * @param confFeatureMaxQty the confFeatureMaxQty to set
	 */
	public void setConfFeatureMaxQty(String confFeatureMaxQty) {
		this.confFeatureMaxQty = confFeatureMaxQty;
	}
	/**
	 * @return the confOptionMaxQty
	 */
	public String getConfOptionMaxQty() {
		return confOptionMaxQty;
	}
	/**
	 * @param confOptionMaxQty the confOptionMaxQty to set
	 */
	public void setConfOptionMaxQty(String confOptionMaxQty) {
		this.confOptionMaxQty = confOptionMaxQty;
	}
	/**
	 * @return the maxQty
	 */
	public String getMaxQty() {
		return maxQty;
	}
	/**
	 * @param maxQty the maxQty to set
	 */
	public void setMaxQty(String maxQty) {
		this.maxQty = maxQty;
	}
	/**
	 * @return the hardWrOwner
	 */
	public String getHardWrOwner() {
		return hardWrOwner;
	}
	/**
	 * @param hardWrOwner the hardWrOwner to set
	 */
	public void setHardWrOwner(String hardWrOwner) {
		this.hardWrOwner = hardWrOwner;
	}
	/**
	 * @return the confFeatureOwner
	 */
	public String getConfFeatureOwner() {
		return confFeatureOwner;
	}
	/**
	 * @param confFeatureOwner the confFeatureOwner to set
	 */
	public void setConfFeatureOwner(String confFeatureOwner) {
		this.confFeatureOwner = confFeatureOwner;
	}
	/**
	 * @return the confOptionOwner
	 */
	public String getConfOptionOwner() {
		return confOptionOwner;
	}
	/**
	 * @param confOptionOwner the confOptionOwner to set
	 */
	public void setConfOptionOwner(String confOptionOwner) {
		this.confOptionOwner = confOptionOwner;
	}
	/**
	 * @return the confOwner
	 */
	public String getConfOwner() {
		return confOwner;
	}
	/**
	 * @param confOwner the confOwner to set
	 */
	public void setConfOwner(String confOwner) {
		this.confOwner = confOwner;
	}
	/**
	 * @return the hardWrDesgnRes
	 */
	public String getHardWrDesgnRes() {
		return hardWrDesgnRes;
	}
	/**
	 * @param hardWrDesgnRes the hardWrDesgnRes to set
	 */
	public void setHardWrDesgnRes(String hardWrDesgnRes) {
		this.hardWrDesgnRes = hardWrDesgnRes;
	}
	/**
	 * @return the confOptionDesgnRes
	 */
	public String getConfOptionDesgnRes() {
		return confOptionDesgnRes;
	}
	/**
	 * @param confOptionDesgnRes the confOptionDesgnRes to set
	 */
	public void setConfOptionDesgnRes(String confOptionDesgnRes) {
		this.confOptionDesgnRes = confOptionDesgnRes;
	}
	/**
	 * @return the confDesignResp
	 */
	public String getConfDesignResp() {
		return confDesignResp;
	}
	/**
	 * @param confDesignResp the confDesignResp to set
	 */
	public void setConfDesignResp(String confDesignResp) {
		this.confDesignResp = confDesignResp;
	}


}
