/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMMBOMPddrData.java
 * @Creation date: 14-March-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMMBOMPddrData {
	/**
	 *  Holds the partId
	 */
	private String partId;
	/**
	 *  Holds the partName
	 */
	private String partName;
	
	/**
	 *  Holds the selectRevision
	 */
	private String selectRevision="";
	/**
	 *  Holds the selectPlantName
	 */
	private String selectPlantName="";
	
	/**
	 *  Holds the level
	 */
	private String level;
	/**
	 *  Holds the fn
	 */
	private String fn;
	/**
	 *  Holds the bomPrefix
	 */
	private String bomPrefix;
	/**
	 *  Holds the partNumber
	 */
	private String partNumber;
	/**
	 *  Holds the partRev
	 */
	private String partRev;
	/**
	 *  Holds the qty
	 */
	private String qty;
	/**
	 *  Holds the uom
	 */
	private String uom;
	/**
	 *  Holds the functionCode
	 */
	private String functionCode;
	/**
	 *  Holds the eid
	 */
	private String eid;
	/**
	 *  Holds the docName
	 */
	private String docName;
	/**
	 *  Holds the docRev
	 */
	private String docRev;
	/**
	 *  Holds the description
	 */
	private String description;
	/**
	 *  Holds the type
	 */
	private String type;
	/**
	 *  Holds the state
	 */
	private String state;
	/**
	 *  Holds the orgReplcPart
	 */
	private String orgReplcPart;
	/**
	 *  Holds the partAttribute
	 */
	private String partAttribute;
	/**
	 *  Holds the reportGenDt
	 */
	private String reportGenDt;
	/**
	  * Holds the pathFlag
	  */
	private String pathFlag;
	/**
	  * Holds the rowKey
	  */
	private int rowKey;
	/**
	  * Holds the relationId
	  */
	private String relationId;
	/**
	  * Holds the topLevelParentId
	  */
	private String topLevelParentId;
	/**
	  * Holds the topLevelParentName
	  */
	private String topLevelParentName;
	/**
	  * Holds the topLevelParentRev
	  */
	private String topLevelParentRev;

	/**
	  * Holds the parentId
	  */
	private String parentId;
	/**
	  * Holds the parentName
	  */
	private String parentName;
	/**
	  * Holds the parentRev
	  */
	private String parentRev;
	/**
	  * Holds the childId
	  */
	private String childId;
	/**
	  * Holds the bomLevel
	  */
	private int bomLevel;
	/**
	  * Holds the findNumAd
	  */
	private String findNumAd;
	/**
	  * Holds the geBomPrfixAd
	  */
	private String geBomPrfixAd;
	/**
	  * Holds the childName
	  */
	private String childName;
	/**
	  * Holds the childRev
	  */
	private String childRev;
	/**
	  * Holds the qtyAdd
	  */
	private String qtyAdd;
	/**
	  * Holds the uomAdd
	  */
	private String uomAdd;
	/**
	  * Holds the funcCodeAd
	  */
	private String funcCodeAd;
	/**
	  * Holds the partDescAdd
	  */
	private String partDescAd;
	
	/**
	  * Holds the partTypeAd
	  */
	private String partTypeAd;
	/**
	  * Holds the partStateAd
	  */
	private String partStateAd;

	/**
	  * Holds the dfsOrder
	  */
	private String dfsOrder;

	/**
	 * @return the partId
	 */
	public String getPartId() {
		return partId;
	}
	/**
	 * @param partId the partId to set
	 */
	public void setPartId(String partId) {
		this.partId = partId;
	}
	/**
	 * @return the partName
	 */
	public String getPartName() {
		return partName;
	}
	/**
	 * @param partName the partName to set
	 */
	public void setPartName(String partName) {
		this.partName = partName;
	}
	/**
	 * @return the selectRevision
	 */
	public String getSelectRevision() {
		return selectRevision;
	}
	/**
	 * @param selectRevision the selectRevision to set
	 */
	public void setSelectRevision(String selectRevision) {
		this.selectRevision = selectRevision;
	}
	/**
	 * @return the selectPlantName
	 */
	public String getSelectPlantName() {
		return selectPlantName;
	}
	/**
	 * @param selectPlantName the selectPlantName to set
	 */
	public void setSelectPlantName(String selectPlantName) {
		this.selectPlantName = selectPlantName;
	}
	
	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}
	/**
	 * @return the fn
	 */
	public String getFn() {
		return fn;
	}
	/**
	 * @param fn the fn to set
	 */
	public void setFn(String fn) {
		this.fn = fn;
	}
	/**
	 * @return the bomPrefix
	 */
	public String getBomPrefix() {
		return bomPrefix;
	}
	/**
	 * @param bomPrefix the bomPrefix to set
	 */
	public void setBomPrefix(String bomPrefix) {
		this.bomPrefix = bomPrefix;
	}
	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}
	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	/**
	 * @return the partRev
	 */
	public String getPartRev() {
		return partRev;
	}
	/**
	 * @param partRev the partRev to set
	 */
	public void setPartRev(String partRev) {
		this.partRev = partRev;
	}
	/**
	 * @return the qty
	 */
	public String getQty() {
		return qty;
	}
	/**
	 * @param qty the qty to set
	 */
	public void setQty(String qty) {
		this.qty = qty;
	}
	/**
	 * @return the uom
	 */
	public String getUom() {
		return uom;
	}
	/**
	 * @param uom the uom to set
	 */
	public void setUom(String uom) {
		this.uom = uom;
	}
	/**
	 * @return the functionCode
	 */
	public String getFunctionCode() {
		return functionCode;
	}
	/**
	 * @param functionCode the functionCode to set
	 */
	public void setFunctionCode(String functionCode) {
		this.functionCode = functionCode;
	}
	/**
	 * @return the eid
	 */
	public String getEid() {
		return eid;
	}
	/**
	 * @param eid the eid to set
	 */
	public void setEid(String eid) {
		this.eid = eid;
	}
	/**
	 * @return the docName
	 */
	public String getDocName() {
		return docName;
	}
	/**
	 * @param docName the docName to set
	 */
	public void setDocName(String docName) {
		this.docName = docName;
	}
	/**
	 * @return the docRev
	 */
	public String getDocRev() {
		return docRev;
	}
	/**
	 * @param docRev the docRev to set
	 */
	public void setDocRev(String docRev) {
		this.docRev = docRev;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the orgReplcPart
	 */
	public String getOrgReplcPart() {
		return orgReplcPart;
	}
	/**
	 * @param orgReplcPart the orgReplcPart to set
	 */
	public void setOrgReplcPart(String orgReplcPart) {
		this.orgReplcPart = orgReplcPart;
	}
	/**
	 * @return the partAttribute
	 */
	public String getPartAttribute() {
		return partAttribute;
	}
	/**
	 * @param partAttribute the partAttribute to set
	 */
	public void setPartAttribute(String partAttribute) {
		this.partAttribute = partAttribute;
	}
	/**
	 * @return the reportGenDt
	 */
	public String getReportGenDt() {
		return reportGenDt;
	}
	/**
	 * @param reportGenDt the reportGenDt to set
	 */
	public void setReportGenDt(String reportGenDt) {
		this.reportGenDt = reportGenDt;
	}
	/**
	 * @return the pathFlag
	 */
	public String getPathFlag() {
		return pathFlag;
	}
	/**
	 * @param pathFlag the pathFlag to set
	 */
	public void setPathFlag(String pathFlag) {
		this.pathFlag = pathFlag;
	}
	
	/**
	 * @return the rowKey
	 */
	public int getRowKey() {
		return rowKey;
	}
	/**
	 * @param rowKey the rowKey to set
	 */
	public void setRowKey(int rowKey) {
		this.rowKey = rowKey;
	}
	/**
	 * @return the relationId
	 */
	public String getRelationId() {
		return relationId;
	}
	/**
	 * @param relationId the relationId to set
	 */
	public void setRelationId(String relationId) {
		this.relationId = relationId;
	}
	/**
	 * @return the topLevelParentId
	 */
	public String getTopLevelParentId() {
		return topLevelParentId;
	}
	/**
	 * @param topLevelParentId the topLevelParentId to set
	 */
	public void setTopLevelParentId(String topLevelParentId) {
		this.topLevelParentId = topLevelParentId;
	}
	/**
	 * @return the topLevelParentName
	 */
	public String getTopLevelParentName() {
		return topLevelParentName;
	}
	/**
	 * @param topLevelParentName the topLevelParentName to set
	 */
	public void setTopLevelParentName(String topLevelParentName) {
		this.topLevelParentName = topLevelParentName;
	}
	
	/**
	 * @return the topLevelParentRev
	 */
	public String getTopLevelParentRev() {
		return topLevelParentRev;
	}
	/**
	 * @param topLevelParentRev the topLevelParentRev to set
	 */
	public void setTopLevelParentRev(String topLevelParentRev) {
		this.topLevelParentRev = topLevelParentRev;
	}
	/**
	 * @return the parentId
	 */
	public String getParentId() {
		return parentId;
	}
	/**
	 * @param parentId the parentId to set
	 */
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	/**
	 * @return the parentName
	 */
	public String getParentName() {
		return parentName;
	}
	/**
	 * @param parentName the parentName to set
	 */
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	/**
	 * @return the parentRev
	 */
	public String getParentRev() {
		return parentRev;
	}
	/**
	 * @param parentRev the parentRev to set
	 */
	public void setParentRev(String parentRev) {
		this.parentRev = parentRev;
	}
	/**
	 * @return the childId
	 */
	public String getChildId() {
		return childId;
	}
	/**
	 * @param childId the childId to set
	 */
	public void setChildId(String childId) {
		this.childId = childId;
	}
	/**
	 * @return the bomLevel
	 */
	public int getBomLevel() {
		return bomLevel;
	}
	/**
	 * @param bomLevel the bomLevel to set
	 */
	public void setBomLevel(int bomLevel) {
		this.bomLevel = bomLevel;
	}
	/**
	 * @return the findNumAd
	 */
	public String getFindNumAd() {
		return findNumAd;
	}
	/**
	 * @param findNumAd the findNumAd to set
	 */
	public void setFindNumAd(String findNumAd) {
		this.findNumAd = findNumAd;
	}
	/**
	 * @return the geBomPrfixAd
	 */
	public String getGeBomPrfixAd() {
		return geBomPrfixAd;
	}
	/**
	 * @param geBomPrfixAd the geBomPrfixAd to set
	 */
	public void setGeBomPrfixAd(String geBomPrfixAd) {
		this.geBomPrfixAd = geBomPrfixAd;
	}
	/**
	 * @return the childName
	 */
	public String getChildName() {
		return childName;
	}
	/**
	 * @param childName the childName to set
	 */
	public void setChildName(String childName) {
		this.childName = childName;
	}
	/**
	 * @return the childRev
	 */
	public String getChildRev() {
		return childRev;
	}
	/**
	 * @param childRev the childRev to set
	 */
	public void setChildRev(String childRev) {
		this.childRev = childRev;
	}
	/**
	 * @return the qtyAdd
	 */
	public String getQtyAdd() {
		return qtyAdd;
	}
	/**
	 * @param qtyAdd the qtyAdd to set
	 */
	public void setQtyAdd(String qtyAdd) {
		this.qtyAdd = qtyAdd;
	}
	/**
	 * @return the uomAdd
	 */
	public String getUomAdd() {
		return uomAdd;
	}
	/**
	 * @param uomAdd the uomAdd to set
	 */
	public void setUomAdd(String uomAdd) {
		this.uomAdd = uomAdd;
	}
	/**
	 * @return the funcCodeAd
	 */
	public String getFuncCodeAd() {
		return funcCodeAd;
	}
	/**
	 * @param funcCodeAd the funcCodeAd to set
	 */
	public void setFuncCodeAd(String funcCodeAd) {
		this.funcCodeAd = funcCodeAd;
	}
	/**
	 * @return the partDescAd
	 */
	public String getPartDescAd() {
		return partDescAd;
	}
	/**
	 * @param partDescAd the partDescAd to set
	 */
	public void setPartDescAd(String partDescAd) {
		this.partDescAd = partDescAd;
	}
	/**
	 * @return the partTypeAd
	 */
	public String getPartTypeAd() {
		return partTypeAd;
	}
	/**
	 * @param partTypeAd the partTypeAd to set
	 */
	public void setPartTypeAd(String partTypeAd) {
		this.partTypeAd = partTypeAd;
	}
	/**
	 * @return the partStateAd
	 */
	public String getPartStateAd() {
		return partStateAd;
	}
	/**
	 * @param partStateAd the partStateAd to set
	 */
	public void setPartStateAd(String partStateAd) {
		this.partStateAd = partStateAd;
	}
	/**
	 * @return the dfsOrder
	 */
	public String getDfsOrder() {
		return dfsOrder;
	}
	/**
	 * @param dfsOrder the dfsOrder to set
	 */
	public void setDfsOrder(String dfsOrder) {
		this.dfsOrder = dfsOrder;
	}
	
	
}
