/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMContractRptDaoImpl.java
 * @Creation date: 12-Aug-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMContractRptData;
import com.geinfra.geaviation.pwi.data.PLMContractSystemAsignData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMQueryConstants;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMContractRptDaoImpl extends SimpleJdbcDaoSupport implements PLMContractRptDaoIfc{
	/**
	 *  Holds the lOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMContractRptDaoImpl.class);
	

	/**
	 * This method is used to fetch Contract Info
	 * 
	 * @param cntrtNm
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMContractRptData> fetchCntrInfo(String cntrtNm) throws PLMCommonException{
		LOG.info("Entering into fetchCntrInfo");
		LOG.info("Executing GET_CNTRT_INFO Query : " + PLMSearchQueries.GET_CNTRT_INFO_RPT + "\n");
		LOG.info("Contract Name in DAO------------->"+cntrtNm);
		return getSimpleJdbcTemplate().query(PLMSearchQueries.GET_CNTRT_INFO_RPT, new CntrInfoMapper(),new Object[]{cntrtNm});
		
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class CntrInfoMapper implements ParameterizedRowMapper<PLMContractRptData> {
		public PLMContractRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMContractRptData data = new PLMContractRptData();
			data.setCntrtNm(rs.getString("NM"));
			data.setCntrtDesc(rs.getString("DESCRIPTION"));
			return data;
		}
	}
	
	/**
	 * This method is used to getContractInfoRpt
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<PLMContractRptData>> getContractInfoRpt(String cntrtNm)	throws PLMCommonException{
		LOG.info("Entering into getContractInfoRpt");
		Map<String, List<PLMContractRptData>> contractInfoRptMap = new HashMap<String, List<PLMContractRptData>>(); 
		List<PLMContractRptData> finalProjectInfoList = new ArrayList<PLMContractRptData>();
		Map<String,PLMContractRptData> projValMap = new HashMap<String,PLMContractRptData>();
		//try{
			LOG.info("Query to getMlMplListt=="+PLMSearchQueries.GET_RELATED_ML_PL);
			List<PLMContractRptData> getMlMplList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_RELATED_ML_PL,new MlMplMapper(),new Object[] {cntrtNm});
			
			LOG.info("Query to getProjectInfoList=="+PLMSearchQueries.GET_RELATED_PROJECTS);
			List<PLMContractRptData> getProjectInfoList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_RELATED_PROJECTS,new ProjectMapper(),new Object[] {cntrtNm});
			
			String projectId="";
			
				for(int i=0;i<getProjectInfoList.size();i++){
				  if(!projectId.equals(getProjectInfoList.get(i).getProjectId())){
					
					  	PLMContractRptData tempData = new PLMContractRptData();
						tempData.setProjectIdNm(getProjectInfoList.get(i).getProjectIdNm());
						tempData.setWorkSpaceId(getProjectInfoList.get(i).getWorkSpaceId());
						tempData.setProjectId(getProjectInfoList.get(i).getProjectId());
						tempData.setProjectName(getProjectInfoList.get(i).getProjectName());
						
						projValMap.put(getProjectInfoList.get(i).getProjectId(), tempData);
						//LOG.info("If -- Adding Project Id"+getProjectInfoList.get(i).getProjectIdNm()+" for "+getProjectInfoList.get(i).getWorkSpaceFldr());
					 } else {
						 if (getProjectInfoList.get(i).getWorkSpaceFldr().equals("Customer and Construction Documents")) {

							PLMContractRptData tempData = new PLMContractRptData();
							tempData.setProjectIdNm(getProjectInfoList.get(i).getProjectIdNm());
							tempData.setWorkSpaceId(getProjectInfoList.get(i).getWorkSpaceId());
							tempData.setProjectId(getProjectInfoList.get(i).getProjectId());
							tempData.setProjectName(getProjectInfoList.get(i).getProjectName());
							
							projValMap.put(getProjectInfoList.get(i).getProjectId(), tempData);
						 }
						//LOG.info("Else -- Checking Project Id"+getProjectInfoList.get(i).getProjectIdNm()+" for "+getProjectInfoList.get(i).getWorkSpaceFldr());
							 
					}
					projectId=getProjectInfoList.get(i).getProjectId();
				}
			Set<String> projValKeys = projValMap.keySet();
			Iterator<String> projItr = projValKeys.iterator();
			
			while(projItr.hasNext()) {
				PLMContractRptData tempData = (PLMContractRptData)projValMap.get((String)projItr.next());
				finalProjectInfoList.add(tempData);
			}
			Collections.sort(finalProjectInfoList, new SortProjList());
				
			LOG.info("Query to fetch getProductList=="+PLMSearchQueries.GET_RELATED_PRODUCTS);
			List<PLMContractRptData> getProductList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_RELATED_PRODUCTS,new ProductMapper(),new Object[] {cntrtNm});
			
			LOG.info("Query to getPRSList=="+PLMSearchQueries.GET_RELATED_PRS);
			List<PLMContractRptData> getPRSList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_RELATED_PRS,new PrsMapper(),new Object[] {cntrtNm});
			
			LOG.info("Query to getCRSList=="+PLMSearchQueries.GET_RELATED_CRS);
			List<PLMContractRptData> getCRSList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_RELATED_CRS,new CrsMapper(),new Object[] {cntrtNm});
		 	
			contractInfoRptMap.put("MLMPL", getMlMplList);
			contractInfoRptMap.put("PROJECT", finalProjectInfoList);
			contractInfoRptMap.put("PRODUCT", getProductList);
			contractInfoRptMap.put("PRS", getPRSList);
			contractInfoRptMap.put("CRS", getCRSList);
	
	   /*}catch (Exception e) {
			PLMUtils.checkException(e.getMessage());
		}*/
	   LOG.info("Exiting into getContractInfoRpt");
		return contractInfoRptMap;
		
	}
	/**
	 * 
	 * class to sort list of object of type PLMDocGenFmiData.
	 * 
	 */
	private static class SortProjList implements Comparator<PLMContractRptData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMContractRptData aString, PLMContractRptData bString) {
            return aString.getProjectIdNm().compareTo(bString.getProjectIdNm());
        }

	}
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class MlMplMapper implements ParameterizedRowMapper<PLMContractRptData> {
		public PLMContractRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMContractRptData data = new PLMContractRptData();
			data.setMlmplId(PLMUtils.checkNullVal(rs.getString("ML_MPL_ID")));
			data.setMlmplNm(PLMUtils.checkNullVal(rs.getString("ML_MPL_NUM")));
			data.setGeSerialNum(PLMUtils.checkNullVal(rs.getString("GE_ORIGINAL_SERIAL_NUM")));
			data.setShopOrder(PLMUtils.checkNullVal(rs.getString("SHOP_ORDER_NUM")));
			return data;
		}
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class ProjectMapper implements ParameterizedRowMapper<PLMContractRptData> {
		public PLMContractRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMContractRptData data = new PLMContractRptData();
			String projectId = PLMUtils.checkNullVal(rs.getString("PROJECT_ID"));
			String projectNm = PLMUtils.checkNullVal(rs.getString("PROJECT_NAME"));
			String workSpaceId = PLMUtils.checkNullVal(rs.getString("WSF_ID"));
			String workSpaceFldr = PLMUtils.checkNullVal(rs.getString("WSF_NAME"));
			
			data.setProjectIdNm(workSpaceId+"~"+projectId+"~"+projectNm);
			data.setWorkSpaceId(workSpaceId);
			data.setWorkSpaceFldr(workSpaceFldr);
			data.setProjectId(projectId);
			data.setProjectName(projectNm);
			
			
			return data;
		}
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class ProductMapper implements ParameterizedRowMapper<PLMContractRptData> {
		public PLMContractRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMContractRptData data = new PLMContractRptData();
			data.setProductId(PLMUtils.checkNullVal(rs.getString("HW_PRD_ID")));
			data.setHdWareProduct(PLMUtils.checkNullVal(rs.getString("HARDWARE_PRODUCT")));
			return data;
		}
	}
	
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class PrsMapper implements ParameterizedRowMapper<PLMContractRptData> {
		public PLMContractRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMContractRptData data = new PLMContractRptData();
			data.setPrsId(PLMUtils.checkNullVal(rs.getString("PRS_ID")));
			data.setPrsName(PLMUtils.checkNullVal(rs.getString("PRS_NAME")));
			return data;
		}
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class CrsMapper implements ParameterizedRowMapper<PLMContractRptData> {
		public PLMContractRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMContractRptData data = new PLMContractRptData();
			data.setCrsId(PLMUtils.checkNullVal(rs.getString("CRS_ID")));
			data.setCrsName(PLMUtils.checkNullVal(rs.getString("CRS_NAME")));
			return data;
		}
	}
	
	//Newly Added for Project Summary Report
	/**
	 * This method is used to fetch Project Info
	 * 
	 * @param projectNm
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMContractRptData> fetchProjectInfo(String projectNm) throws PLMCommonException{
		LOG.info("Entering into fetchProjectInfo");
		LOG.info("Executing fetchProjectInfo Query : " + PLMSearchQueries.GET_PROJECT_INFO_RPT + "\n");
		LOG.info("Contract Name in DAO------------->"+projectNm);
		return getSimpleJdbcTemplate().query(PLMSearchQueries.GET_PROJECT_INFO_RPT, new PrjInfoMapper(),new Object[]{projectNm});
		
	}
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class PrjInfoMapper implements ParameterizedRowMapper<PLMContractRptData> {
		public PLMContractRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMContractRptData data = new PLMContractRptData();
			data.setProjectNm(rs.getString("NM"));
			data.setProjectDesc(rs.getString("DESCRIPTION"));
			return data;
		}
	}
	/**
	 * This method is used to getProjectInfoRpt
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<PLMContractRptData>> getProjectInfoRpt(String projectNm)throws PLMCommonException{
		LOG.info("Entering into getProjectInfoRpt");
		Map<String, List<PLMContractRptData>> projectInfoRptMap = new HashMap<String, List<PLMContractRptData>>(); 
		List<PLMContractRptData> finalProjectInfoList = new ArrayList<PLMContractRptData>();
		Map<String,PLMContractRptData> projValMap = new HashMap<String,PLMContractRptData>();
		List<PLMContractRptData> getprjMlMplList  =new ArrayList<PLMContractRptData>();
		//try{
		
			LOG.info("Query for getting Contract for Associated Project=="+PLMSearchQueries.GET_ASSOIATE_CNTRT_PRJ);
			List<String> contractNmList  = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_ASSOIATE_CNTRT_PRJ ,new ContractNmMapper(),new Object[] {projectNm});
			
			if(!PLMUtils.isEmptyList(contractNmList)){
				String contractNm =contractNmList.get(0).toString();
				LOG.info("Query to getprjMlMplListt=="+PLMSearchQueries.GET_PRJ_RELATED_ML_PL);
				getprjMlMplList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_PRJ_RELATED_ML_PL,new PrjMlMplMapper(),new Object[] {contractNm});
			}
			
			LOG.info("Query to getProjectInfoList=="+PLMSearchQueries.GET_PRJ_RELATED_PROJECTS);
			List<PLMContractRptData> getprjProjectInfoList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_PRJ_RELATED_PROJECTS,new PrjProjectMapper(),new Object[] {projectNm});
			 
			String projectId="";
			
				for(int i=0;i<getprjProjectInfoList.size();i++){
				  if(!projectId.equals(getprjProjectInfoList.get(i).getProjectId())){
					
					  	PLMContractRptData tempData = new PLMContractRptData();
						tempData.setProjectIdNm(getprjProjectInfoList.get(i).getProjectIdNm());
						tempData.setWorkSpaceId(getprjProjectInfoList.get(i).getWorkSpaceId());
						tempData.setProjectId(getprjProjectInfoList.get(i).getProjectId());
						tempData.setProjectName(getprjProjectInfoList.get(i).getProjectName());
						tempData.setSaferId(getprjProjectInfoList.get(i).getSaferId());
						
						projValMap.put(getprjProjectInfoList.get(i).getProjectId(), tempData);
						//LOG.info("If -- Adding Project Id"+getProjectInfoList.get(i).getProjectIdNm()+" for "+getProjectInfoList.get(i).getWorkSpaceFldr());
					 } else {
						 if (getprjProjectInfoList.get(i).getWorkSpaceFldr().equals("Customer and Construction Documents")) {

							PLMContractRptData tempData = new PLMContractRptData();
							tempData.setProjectIdNm(getprjProjectInfoList.get(i).getProjectIdNm());
							tempData.setWorkSpaceId(getprjProjectInfoList.get(i).getWorkSpaceId());
							tempData.setProjectId(getprjProjectInfoList.get(i).getProjectId());
							tempData.setProjectName(getprjProjectInfoList.get(i).getProjectName());
							tempData.setSaferId(getprjProjectInfoList.get(i).getSaferId());
							
							projValMap.put(getprjProjectInfoList.get(i).getProjectId(), tempData);
						 }
						//LOG.info("Else -- Checking Project Id"+getProjectInfoList.get(i).getProjectIdNm()+" for "+getProjectInfoList.get(i).getWorkSpaceFldr());
							 
					}
					projectId=getprjProjectInfoList.get(i).getProjectId();
				}
			Set<String> projValKeys = projValMap.keySet();
			Iterator<String> projItr = projValKeys.iterator();
			
			while(projItr.hasNext()) {
				PLMContractRptData tempData = (PLMContractRptData)projValMap.get((String)projItr.next());
				finalProjectInfoList.add(tempData);
			}
			Collections.sort(finalProjectInfoList, new SortProjList());
				
			LOG.info("Query to fetch getPrjProductList=="+PLMSearchQueries.GET_PRJ_RELATED_PRODUCTS);
			List<PLMContractRptData> getPrjProductList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_PRJ_RELATED_PRODUCTS,new PrjProductMapper(),new Object[] {projectNm});
			
			LOG.info("Query to getprjPRSList=="+PLMSearchQueries.GET_PRJ_RELATED_PRS);
			List<PLMContractRptData> getprjPRSList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_PRJ_RELATED_PRS,new PrjPrsMapper(),new Object[] {projectNm,projectNm});
			
			LOG.info("Query to getprjCRSList=="+PLMSearchQueries.GET_PRJ_RELATED_CRS);
			List<PLMContractRptData> getprjCRSList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_PRJ_RELATED_CRS,new PrjCrsMapper(),new Object[] {projectNm,projectNm});
		 	
			projectInfoRptMap.put("MLMPL", getprjMlMplList);
			projectInfoRptMap.put("PROJECT", finalProjectInfoList);
			projectInfoRptMap.put("PRODUCT", getPrjProductList);
			projectInfoRptMap.put("PRS", getprjPRSList);
			projectInfoRptMap.put("CRS", getprjCRSList);
	
	   /*}catch (Exception e) {
			PLMUtils.checkException(e.getMessage());
		}*/
	   LOG.info("Exiting into getProjectInfoRpt");
		return projectInfoRptMap;
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class ContractNmMapper implements ParameterizedRowMapper<String> {
		public String mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			String contractNm =PLMUtils.checkNullVal(rs.getString("CONTRACT"));
			return contractNm;
		}
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class PrjMlMplMapper implements ParameterizedRowMapper<PLMContractRptData> {
		public PLMContractRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMContractRptData data = new PLMContractRptData();
			data.setMlmplId(PLMUtils.checkNullVal(rs.getString("ML_MPL_ID")));
			data.setMlmplNm(PLMUtils.checkNullVal(rs.getString("ML_MPL_NUM")));
			data.setGeSerialNum(PLMUtils.checkNullVal(rs.getString("GE_ORIGINAL_SERIAL_NUM")));
			data.setShopOrder(PLMUtils.checkNullVal(rs.getString("SHOP_ORDER_NUM")));
			return data;
		}
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class PrjProjectMapper implements ParameterizedRowMapper<PLMContractRptData> {
		public PLMContractRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMContractRptData data = new PLMContractRptData();
			String projectId = PLMUtils.checkNullVal(rs.getString("PROJECT_ID"));
			String projectNm = PLMUtils.checkNullVal(rs.getString("PROJECT_NAME"));
			String workSpaceId = PLMUtils.checkNullVal(rs.getString("WSF_ID"));
			String workSpaceFldr = PLMUtils.checkNullVal(rs.getString("WSF_NAME"));
			
			data.setProjectIdNm(workSpaceId+"~"+projectId+"~"+projectNm);
			data.setWorkSpaceId(workSpaceId);
			data.setWorkSpaceFldr(workSpaceFldr);
			data.setProjectId(projectId);
			data.setProjectName(projectNm);
			data.setSaferId(PLMUtils.checkNullVal(rs.getString("SAFER_ID")));
			
			return data;
		}
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class PrjProductMapper implements ParameterizedRowMapper<PLMContractRptData> {
		public PLMContractRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMContractRptData data = new PLMContractRptData();
			data.setProductId(PLMUtils.checkNullVal(rs.getString("HW_PRD_ID")));
			data.setHdWareProduct(PLMUtils.checkNullVal(rs.getString("HARDWARE_PRODUCT")));
			return data;
		}
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class PrjPrsMapper implements ParameterizedRowMapper<PLMContractRptData> {
		public PLMContractRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMContractRptData data = new PLMContractRptData();
			data.setPrsId(PLMUtils.checkNullVal(rs.getString("PRS_ID")));
			data.setPrsName(PLMUtils.checkNullVal(rs.getString("PRS_NAME")));
			return data;
		}
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class PrjCrsMapper implements ParameterizedRowMapper<PLMContractRptData> {
		public PLMContractRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMContractRptData data = new PLMContractRptData();
			data.setCrsId(PLMUtils.checkNullVal(rs.getString("CRS_ID")));
			data.setCrsName(PLMUtils.checkNullVal(rs.getString("CRS_NAME")));
			return data;
		}
	}

	@Override
	public List<PLMContractSystemAsignData> searchSystemNames(String systemWithWildcards)
			throws PLMCommonException {
		LOG.info("Query for fetch system name : "+PLMQueryConstants.SEARCH_SYSTEM_NAME + " With Value "+systemWithWildcards); ;

		List<PLMContractSystemAsignData> srchList =  getSimpleJdbcTemplate().query(PLMQueryConstants.SEARCH_SYSTEM_NAME,
				new SystemNameMapper());
		return srchList;
	}
	@Override
	public List<PLMContractSystemAsignData> fetchAssignSystemDataList(List<String> systemWithWildcards)
			throws PLMCommonException {
		LOG.info("Query for fetch system name in fetchAssignSystemDataList method : "+PLMQueryConstants.SEARCH_SYSTEM_NAME + " With Value "+systemWithWildcards); ;
		StringBuffer sb = new StringBuffer();
		sb.append(PLMQueryConstants.SEARCH_SYSTEM_NAME);
		sb.append("WHERE ");
		int i=0;
		if(!PLMUtils.isEmptyList(systemWithWildcards)){
			if(systemWithWildcards.contains("Gas")){
				sb.append(" GAS IN 1 ");
				i=1;
			}if(systemWithWildcards.contains("Gen")){
				if(i==1){
					sb.append(" OR GEN IN 1 ");
					i=2;
				}else{
					sb.append(" GEN IN 1 ");
					i=1;
				}
				
			}if(systemWithWildcards.contains("Steam")){
				if(i==0){
					sb.append(" STEAM IN 1 ");
					i=1;
				}else{
					sb.append(" OR STEAM IN 1 ");
					i=i+1;
				}
			}if(systemWithWildcards.contains("PLANT")){
				if(i==0){
					sb.append(" STEAM IN 2 ");
					i=1;
				}else{
					sb.append(" OR STEAM IN 2 ");
					i=i+1;
				}
			}
		}
		List<PLMContractSystemAsignData> srchList =  getSimpleJdbcTemplate().query(sb.toString(),
				new SystemNameMapper());
		return srchList;
	}
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class SystemNameMapper implements ParameterizedRowMapper<PLMContractSystemAsignData> {
		public PLMContractSystemAsignData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMContractSystemAsignData data = new PLMContractSystemAsignData();
			data.setSystemId(PLMUtils.checkNullVal(rs.getString("SYSTEM_ID")));
			data.setSystemName(PLMUtils.checkNullVal(rs.getString("SYSTEM_NAME")));
			data.setGasStr(PLMUtils.checkNullVal(rs.getString("GAS")).trim());
			data.setGenStr(PLMUtils.checkNullVal(rs.getString("GEN")).trim());
			data.setSteamStr(PLMUtils.checkNullVal(rs.getString("STEAM")).trim());
			return data;
		}
	}
	
	@Override
	public boolean addSystemNames(String systemName, String hdnSystmId,boolean gasId,boolean genId,boolean steamId){
		
		LOG.info("Query for fetch system name : "+PLMQueryConstants.INSERT_SYSTEM_NAME + " With Value "+systemName); ;
		int upateVal=0;
		String gasIdStr=(gasId)?"1":"0";
		String genIdStr=(genId)?"1":"0";
		String steamIdStr=(steamId)?"1":"0";
		
		try {
			if(hdnSystmId!=null && !hdnSystmId.trim().equals(""))
			{
				upateVal = getJdbcTemplate().update(PLMQueryConstants.UPDATE_SYSTEM_NAME,new Object[] {systemName,gasIdStr,genIdStr,steamIdStr,UserInfoPortalUtil.getInstance().getUserSSO(),hdnSystmId});
			}
			else
			{
				upateVal = getJdbcTemplate().update(PLMQueryConstants.INSERT_SYSTEM_NAME,new Object[] {systemName,gasIdStr,genIdStr,steamIdStr,UserInfoPortalUtil.getInstance().getUserSSO(),UserInfoPortalUtil.getInstance().getUserSSO()});
			}
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (PWiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(upateVal>0)
		{
			return true;
		}
		return false;
	}
	
	public boolean deleteSystemName(String systemName) {
		
		LOG.info("Query for fetch system name mapping delete : "+PLMQueryConstants.DELETE_SYSTEM_MAPPING + " With Value "+systemName); 
		LOG.info("Query for fetch system name delete: "+PLMQueryConstants.DELETE_SYSTEM_NAME + " With Value "+systemName); ;

		int upateVal =  getJdbcTemplate().update(PLMQueryConstants.DELETE_SYSTEM_MAPPING,new Object[] {systemName});
		
		if(upateVal>=0)
		{
			upateVal =  getJdbcTemplate().update(PLMQueryConstants.DELETE_SYSTEM_NAME,new Object[] {systemName});
			
			if(upateVal>0)
			{
			return true;
			}
		}
		return false;
	}
	
	@Override
	public List<PLMContractSystemAsignData> searchAssignSystems(PLMContractSystemAsignData assignData) throws PLMCommonException {
	
		StringBuffer searchQry = new StringBuffer();
		boolean whereClause = false;
		searchQry.append(PLMQueryConstants.SEARCH_ASSIGN_SYSTEM_NAME);
		if(!(assignData.isSysAssigned() && assignData.isSysUnAssigned()))
		{
			if(assignData.isSysUnAssigned())
			{
				if(whereClause){
					searchQry.append(" AND CFGN_OPTION.NM NOT IN (SELECT OPTION_NAME FROM GEEDW_OLTP_BULK_V.CDR_FEATURE_MASTER_DATA)");
				}
				else
				{
					searchQry.append(" WHERE CFGN_OPTION.NM NOT IN (SELECT OPTION_NAME FROM GEEDW_OLTP_BULK_V.CDR_FEATURE_MASTER_DATA)");
					whereClause=true;
				}
				
			}
			if(assignData.isSysAssigned())
			{
				String selSystList = PLMUtils.convertListToString(assignData.getSysNameList());
				
				if (selSystList.length() > 0) {
					if(whereClause){
						searchQry.append(" AND SYS_FEAT.SYSTEM_ID IN ( " + selSystList +" )");
					}
					else
					{
						searchQry.append(" WHERE SYS_FEAT.SYSTEM_ID IN ( " + selSystList +" )");
						whereClause=true;
					}
				}
			}
			
		}
		
		if(assignData.getSelSysNameList()!=null && assignData.getSelSysNameList().size()>0)
		{
			String selSystList = PLMUtils.convertListToString(assignData.getSelSysNameList());
			if(whereClause){
				searchQry.append(" AND SYS_FEAT.SYSTEM_ID IN ( "+ selSystList + " )");
			}
			else
			{
				searchQry.append(" WHERE SYS_FEAT.SYSTEM_ID IN ( "+ selSystList + " )");
				whereClause=true;
			}
		}
		
		boolean gasSel = false;
		boolean genSel = false;
		boolean steamSel = false;
		if(assignData.getSelectedPrdctList()!=null && assignData.getSelectedPrdctList().size()>0)
		{
			String selPrdctList = PLMUtils.convertListToStringWithQuotes(assignData.getSelectedPrdctList());
			LOG.info("SEL PRD LIST" + selPrdctList);
			for (int i=0; i < assignData.getSelectedPrdctList().size(); i++) {
				
				if ("Gas".equalsIgnoreCase(assignData.getSelectedPrdctList().get(i))) {
					gasSel = true;
				}
				
				if ("Gen".equalsIgnoreCase(assignData.getSelectedPrdctList().get(i))) {
					genSel = true;
				}
				
				if ("Steam".equalsIgnoreCase(assignData.getSelectedPrdctList().get(i))) {
					steamSel = true;
				}
				
			}
			
			if(whereClause){
				searchQry.append(" AND HP.PRODUCT_LINE IN ( "+ selPrdctList + " )");
				
				if (gasSel || genSel || steamSel) {
					searchQry.append(" AND (");
				
				
					if (gasSel) {
						searchQry.append("SYS.GAS = 1 ");
					} 
					
					if (genSel && gasSel) {
						searchQry.append("OR SYS.GEN = 1 ");
					} else if (genSel) {
						searchQry.append("SYS.GEN = 1 ");
					}
					
					if (steamSel && (genSel || gasSel)) {
						searchQry.append("OR SYS.STEAM = 1 ");				
					} else if (steamSel) {
						searchQry.append("SYS.STEAM = 1 ");
					}
					
					searchQry.append(" ) ");
				}
			}
			else
			{
				searchQry.append(" WHERE HP.PRODUCT_LINE IN ( "+ selPrdctList + " )");
				if (gasSel || genSel || steamSel) {
					searchQry.append(" AND (");
				
				
					if (gasSel) {
						searchQry.append("SYS.GAS = 1 ");
					} 
					
					if (genSel && gasSel) {
						searchQry.append("OR SYS.GEN = 1 ");
					} else if (genSel) {
						searchQry.append("SYS.GEN = 1 ");
					}
					
					if (steamSel && (genSel || gasSel)) {
						searchQry.append("OR SYS.STEAM = 1 ");				
					} else if (steamSel) {
						searchQry.append("SYS.STEAM = 1 ");
					}
					
					searchQry.append(" ) ");
				}
				
				whereClause=true;
			}
		}
		
		LOG.info("Query for fetch system name : "+searchQry ); 
		
		List<PLMContractSystemAsignData> srchList =  getSimpleJdbcTemplate().query(searchQry.toString(),
				new AssignSystemNameMapper());
		return srchList;
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class AssignSystemNameMapper implements ParameterizedRowMapper<PLMContractSystemAsignData> {
		public PLMContractSystemAsignData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMContractSystemAsignData data = new PLMContractSystemAsignData();
			data.setOptionName(PLMUtils.checkNullVal(rs.getString("OPTION_NAME")));
			data.setOptionDesc(PLMUtils.checkNullVal(rs.getString("OPTION_DESC")));
			return data;
		}
	}
	
	@Override
	public  List<PLMContractSystemAsignData> getAssignOptionData(String selOption) throws PLMCommonException {
		LOG.info("Query for fetch system name : "+PLMQueryConstants.SEARCH_OPTION_SYSTEM_MAP_DETAILS ); 
		
		String timeStamp = PLMUtils.volTableFormatDate();
		String VT_FEAT_DT = PLMConstants.VT_FEAT.concat(timeStamp);
		StringBuffer query = new StringBuffer();
		query.append(PLMOfflineQueries.CREATE_FEAT_OPTION_VT1);
	
		String str = query.toString().replace("?", selOption).replace(PLMConstants.VT_FEAT, VT_FEAT_DT);
		LOG.info("Executing CREATE_VT_CRS Query : " + str + "\n");
		getJdbcTemplate().execute(str);

		query = new StringBuffer();
		query.append(PLMOfflineQueries.CREATE_FEAT_OPTION_VT2);
		str = query.toString().replace("?", selOption).replace(PLMConstants.VT_FEAT, VT_FEAT_DT);
		LOG.info("Executing CREATE_VT_CRS Query : " + str + "\n");
		getJdbcTemplate().execute(str);
		
		String VT_OPTION_DT = PLMConstants.VT_OPTION.concat(timeStamp);
		query = new StringBuffer();
		query.append(PLMOfflineQueries.CREATE_FEAT_OPTION_VT3);
	
		str = query.toString().replace("?", selOption).replace(PLMConstants.VT_FEAT, VT_FEAT_DT).replace(PLMConstants.VT_OPTION, VT_OPTION_DT);
		LOG.info("Executing CREATE_VT_CRS Query : " + str + "\n");
		getJdbcTemplate().execute(str);
		
		String VT_SYS_DT = PLMConstants.VT_SYS.concat(timeStamp);
		query = new StringBuffer();
		query.append(PLMOfflineQueries.CREATE_FEAT_OPTION_VT4);
	
		str = query.toString().replace("?", selOption).replace(PLMConstants.VT_FEAT, VT_FEAT_DT).replace(PLMConstants.VT_OPTION, VT_OPTION_DT).replace(PLMConstants.VT_SYS, VT_SYS_DT);
		LOG.info("Executing CREATE_VT_CRS Query : " + str + "\n");
		getJdbcTemplate().execute(str);
		
		
		str = PLMQueryConstants.SEARCH_OPTION_SYSTEM_MAP_DETAILS.replace("?", selOption).replace(PLMConstants.VT_FEAT, VT_FEAT_DT).replace(PLMConstants.VT_OPTION, VT_OPTION_DT).replace(PLMConstants.VT_SYS, VT_SYS_DT);

		 List<PLMContractSystemAsignData> srchAssigOptionDtl =  getSimpleJdbcTemplate().query(str,
				new AssignOptionSystemNameMapper());
		return srchAssigOptionDtl;
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class AssignOptionSystemNameMapper implements ParameterizedRowMapper<PLMContractSystemAsignData> {
		public PLMContractSystemAsignData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMContractSystemAsignData data = new PLMContractSystemAsignData();
			data.setOptionName(PLMUtils.checkNullVal(rs.getString("OPTION_NAME")));
			data.setOptionDesc(PLMUtils.checkNullVal(rs.getString("OPTION_DESC")));
			data.setHeaderName(PLMUtils.checkNullVal(rs.getString("PRNT_OPTION_NAME")));
			data.setHeaderDesc(PLMUtils.checkNullVal(rs.getString("PRNT_OPTION_DESC")));
			data.setSystemName(PLMUtils.checkNullVal(rs.getString("SYSTEM_NAME")));
			List<String> selctdSystemData = new ArrayList<String>();
			String[] sysId = data.getSystemName().split(",");
			for(String sysIds:sysId)
			{
				selctdSystemData.add(sysIds);
			}
			data.setSelSysNameList(selctdSystemData);
			data.setSystemId(PLMUtils.checkNullVal(rs.getString("SEQUENCE_ID")));
			data.setGas(PLMUtils.checkNullVal(rs.getString("GAS")).trim().equals("1")? true : false);
			data.setGen(PLMUtils.checkNullVal(rs.getString("GEN")).trim().equals("1")? true : false);
			data.setSteam(PLMUtils.checkNullVal(rs.getString("STEAM")).trim().equals("1")? true : false);
			return data;
		}
	}
	
	@Override
	public  String assignSystemMapping(List<PLMContractSystemAsignData> popUpOptionMapList,String assign) throws PLMCommonException {
		LOG.info("Query for fetch system name : "+PLMQueryConstants.SEARCH_SYSTEM_NAME ); 
		int result[] = null;
		int count=0;
		String finalResult = "";
		final List<PLMContractSystemAsignData> contrctAssignData = new ArrayList<PLMContractSystemAsignData>();
		PLMContractSystemAsignData assignContractData = null;
		for(String assignData :popUpOptionMapList.get(0).getSelSysNameList())
		{
			assignContractData = new PLMContractSystemAsignData();
			assignContractData.setOptionName(popUpOptionMapList.get(0).getOptionName());
			assignContractData.setSystemName(assignData);
			assignContractData.setGas(popUpOptionMapList.get(0).isGas());
			assignContractData.setGen(popUpOptionMapList.get(0).isGen());
			assignContractData.setSteam(popUpOptionMapList.get(0).isSteam());
			contrctAssignData.add(assignContractData);
		}
		
		//assignToSiblingMapping start code
		if(assign.equalsIgnoreCase("assignToSiblingMapping")){
		StringBuffer sb=new StringBuffer();
		StringBuffer optionNames = new StringBuffer();
		sb.append(PLMQueryConstants.SEARCH_SIBLING_OPTION_NAME);
		String headerNameFinal=PLMUtils.chkNull(popUpOptionMapList.get(0).getHeaderName()).replaceAll("\\|","\\','");
		sb.append(headerNameFinal);
		sb.append("')");
		List<String> childOptionList =  getSimpleJdbcTemplate().query(sb.toString(),
				new AssignSiblingNameMapper());
		for(String optionName:childOptionList){
			optionNames.append(optionName).append(", ");
			final String optName = optionName;
			int optionCnt = getSimpleJdbcTemplate().queryForInt("SELECT COUNT(OPTION_NAME) FROM GEEDW_OLTP_BULK_V.CDR_FEATURE_MASTER_DATA WHERE OPTION_NAME= ? ", optionName);
			if(optionCnt>0)
			{
				getSimpleJdbcTemplate().update("DELETE FROM GEEDW_OLTP_BULK_V.CDR_FEATURE_MASTER_DATA WHERE OPTION_NAME= ? ", optionName);
			}
			String sql = "INSERT INTO GEEDW_OLTP_BULK_V.CDR_FEATURE_MASTER_DATA " +
					"(OPTION_NAME,SYSTEM_ID, GAS,GEN,STEAM,DW_LOAD_DTTM) VALUES (?,?,?,?,?,CURRENT_TIMESTAMP(0))";
			result =  getJdbcTemplate().batchUpdate(sql, new BatchPreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					PLMContractSystemAsignData opMapList = contrctAssignData.get(i);
					ps.setString(1, optName);
					ps.setInt(2, Integer.parseInt(opMapList.getSystemName()));
					ps.setInt(3, opMapList.isGas() ? 1 : 0);
					ps.setInt(4, opMapList.isGen() ? 1 : 0);
					ps.setInt(5, opMapList.isSteam() ? 1 : 0 );
				}

				@Override
				public int getBatchSize() {
					return contrctAssignData.size();
				}
			  });
			if(result.length>0){
				count=count+1;
			}
		}
		LOG.info("Count after Sibling updation : "+count);
		if(count>0){
			if(headerNameFinal!="" || headerNameFinal!="" || optionNames.length() > 0){
				//finalResult="true".concat("|").concat(headerNameFinal);
				finalResult="true".concat("|").concat(optionNames.substring(0, optionNames.length() - 2));
			}else{
				finalResult="true";
			}
			
		}else{
			finalResult="";
		}

		}	
		else if(assign.equalsIgnoreCase("assignSystemMapping")){
		int optionCnt = getSimpleJdbcTemplate().queryForInt("SELECT COUNT(OPTION_NAME) FROM GEEDW_OLTP_BULK_V.CDR_FEATURE_MASTER_DATA WHERE OPTION_NAME= ? ", popUpOptionMapList.get(0).getOptionName());
		
		if(optionCnt>0)
		{
			getSimpleJdbcTemplate().update("DELETE FROM GEEDW_OLTP_BULK_V.CDR_FEATURE_MASTER_DATA WHERE OPTION_NAME= ? ", popUpOptionMapList.get(0).getOptionName());
		}
		
		String sql = "INSERT INTO GEEDW_OLTP_BULK_V.CDR_FEATURE_MASTER_DATA " +
				"(OPTION_NAME,SYSTEM_ID, GAS,GEN,STEAM,DW_LOAD_DTTM) VALUES (?,?, ?,?,?,CURRENT_TIMESTAMP(0))";	

		result =  getJdbcTemplate().batchUpdate(sql, new BatchPreparedStatementSetter() {

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					PLMContractSystemAsignData opMapList = contrctAssignData.get(i);
					ps.setString(1, opMapList.getOptionName());
					ps.setInt(2, Integer.parseInt(opMapList.getSystemName()));
					ps.setInt(3, opMapList.isGas() ? 1 : 0);
					ps.setInt(4, opMapList.isGen() ? 1 : 0);
					ps.setInt(5, opMapList.isSteam() ? 1 : 0 );
				}

				@Override
				public int getBatchSize() {
					return contrctAssignData.size();
				}
			  });
		if(result.length>0){
			finalResult="true";
		}else{
			finalResult="";
		}
		
		}
		return finalResult;
	}
	private static final class AssignSiblingNameMapper implements ParameterizedRowMapper<String> {
		public String mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			String str = PLMUtils.checkNullVal(rs.getString("TO_NAME"));
			return str;
		}
	}
	
	
}
