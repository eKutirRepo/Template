/**
 * Copyright (C) 2012 GE Infra. 
 * All rights reserved 
 * @FileName PLMLttrDaoIfc.java
 * @Creation date: 27-Mar-2012
 * @version 2.0.1
 * @author : Tech Mahindra (PLMR Team)
 */


package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.data.PLMLttrData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMLttrDaoIfc {
	/**
	 * This method is used for checkForValidMlNo
	 * 
	 * @param mlNo
	 * @return int
	 * @throws PLMCommonException
	 */
	public int checkForValidMlNo(String mlNo) throws PLMCommonException;
	/**
	 * This method is used for getTdLttrResult
	 * 
	 * @param mlNo
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMLttrData> getTdLttrResult(String mlNo) throws PLMCommonException;
}