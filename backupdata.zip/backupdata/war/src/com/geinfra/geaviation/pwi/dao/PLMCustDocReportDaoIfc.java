 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileNamePLMCustDocReportDaoIfc.java
 * @Creation date: 16-March-2015
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.data.PLMCustDocReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMCustDocReportDaoIfc {
	/**
	 * This methods is used for getIssuesData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * throws PLMCommonException
	 */
	public List<PLMCustDocReportData> getCustDocReport(String finalQuery, PLMCustDocReportData searchData)
			throws PLMCommonException;
}
