/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMMetricsDaoImpl.java
 * @Creation date: 15-June-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMBomCopicsData;
import com.geinfra.geaviation.pwi.data.PLMBomHealthData;
import com.geinfra.geaviation.pwi.data.PLMIswasParts;
import com.geinfra.geaviation.pwi.data.PLMPercentPartData;
import com.geinfra.geaviation.pwi.data.PLMProductConfData;
import com.geinfra.geaviation.pwi.data.PLMProjChngData;
import com.geinfra.geaviation.pwi.data.PLMProjChngDtlData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMMetricsDaoIfc {
	/**
	 * This method is used for getBomHealthReport
	 * 
	 * @param mlno
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomHealthData> getBomHealthReport(String mlno)
			throws PLMCommonException;
	/**
	 * This method is used for getPartReport
	 * 
	 * @param mlno
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomHealthData> getPartReport(String mlno)
			throws PLMCommonException;
	/**
	 * This method is used for getQPartReport
	 * 
	 * @param mlno
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomHealthData> getQPartReport(String mlno)
			throws PLMCommonException;
	/**
	 * This method is used for getPPartReport
	 * 
	 * @param mlno
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomHealthData> getPPartReport(String mlno)
			throws PLMCommonException;
	/**
	 * This method is used for getPercentReuseDataFromDB
	 * 
	 * @param mlno,prodLine
	 * @return List
	 * @throws PLMCommonException
	 */
	List<PLMPercentPartData> getPercentReuseDataFromDB(String mlNumber, String prodLine)
			throws PLMCommonException;
	/**
	 * This method is used for getBomCopicsComparisonReport
	 * 
	 * @param copicsInputList,plmInputList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomCopicsData> getBomCopicsComparisonReport(List<String> copicsInputList,List<String> plmInputList)
			throws PLMCommonException;
	/**
	 * This method is used for getProjChngHdr
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMProjChngData> getProjChngHdr() throws PLMCommonException;
	/**
	 * This method is used for getProjChngDtls
	 * 
	 * @param contract,prjChngDtlData
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMProjChngDtlData> getProjChngDtls(String contract,PLMProjChngDtlData prjChngDtlData) throws PLMCommonException;
	
	//Newly added for Project summary
	/**
	 * This method is used for getPrjSumryReport
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMProjChngData> getPrjSumryReport(StringBuffer searchResultsQry) throws PLMCommonException;
	
	//Newly added for Project summary
	/**
	 * This method is used for getprjContractDescdata
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMProjChngData> getprjContractDescdata(StringBuffer searchResultsQry) throws PLMCommonException;
	/**
	 * This method is used for getprjChangeList
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getprjChangeList() throws PLMCommonException;

	//newly Added for Contract summary report
	/**
	 * This method is used for getProductCnfgDesc
	 * 
	 * @param contractNameList
	 * @return Map
	 * @throws PLMCommonException
	 */
	public  Map<String, List<SelectItem>> getProductCnfgDesc(String contractNameList) throws PLMCommonException;
	/**
	 * This method is used for getProductCnfgSummary
	 * 
	 * @param conSummRepData
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<PLMProductConfData>>  getProductCnfgSummary(PLMProductConfData conSummRepData) throws PLMCommonException;
	
	///newly Added for IS/Was Parts Reports
	/**
	 * This method is used for getIsWasPartsReport
	 * 
	 * @param contractName
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMIswasParts> getIsWasPartsReport(String contractName) throws PLMCommonException;
	
}
