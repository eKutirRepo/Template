package com.geinfra.geaviation.pwi.bean;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.model.PWiRoleVO;
import com.geinfra.geaviation.pwi.service.QueryGroupService;
import com.geinfra.geaviation.pwi.service.RoleService;
import com.geinfra.geaviation.pwi.util.PWiConstants;

/**
 * 
 * Project : Product Lifecycle Management Intelligence Date Written : May 21,
 * 2010 Security : GE Confidential Restrictions : GE PROPRIETARY INFORMATION,
 * FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Backing managed bean for the admin page to create/edit queries.
 * 
 * Revision Log May 8, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class AdminRoleEditorBean extends BaseBean {

	// Dependency-injected services
	private RoleService roleService;

	private QueryGroupService queryGroupService;

	private Integer roleId;

	private String roleName;

	private String roleDesc;

	private String roleType;

	private List<PWiRoleVO> allRoleList;

	private boolean renderCreateButton;

	private boolean renderUpdateButton;

	private List<PWiQueryGroupVO> selectedQueryGroupsList;

	private List<PWiQueryGroupVO> availableQueryGroupList;

	private List<PWiQueryGroupVO> originalSelectedGroups;
	
	private List<SelectItem> roleTypeList;

	public boolean isRenderCreateButton() {

		return renderCreateButton;
	}

	public void setRenderCreateButton(boolean renderCreateButton) {

		this.renderCreateButton = renderCreateButton;
	}

	public boolean isRenderUpdateButton() {

		return renderUpdateButton;
	}

	public void setRenderUpdateButton(boolean renderUpdateButton) {

		this.renderUpdateButton = renderUpdateButton;
	}

	public void setRoleService(RoleService roleService) {

		this.roleService = roleService;
	}

	public Integer getRoleSequenceId() {

		return roleId;
	}

	public void setRoleSequenceId(Integer roleId1) {

		this.roleId = roleId1;
	}

	public String getRoleDesc() {

		return roleDesc;
	}

	public void setRoleDesc(String roleDescription) {

		this.roleDesc = roleDescription;
	}

	public String getRoleName() {

		return roleName;
	}

	public void setRoleName(String roleName) {

		this.roleName = roleName;
	}

	public String getRoleType() {

		return roleType;
	}

	public void setRoleType(String roleType) {

		this.roleType = roleType;
	}

	public List<PWiRoleVO> getAllRoleList() {

		return allRoleList;
	}

	public void setAllRoleList(List<PWiRoleVO> allRoleList) {

		this.allRoleList = allRoleList;
	}

	/**
	 * @return the selectedQueryGroupsList
	 */
	public List<PWiQueryGroupVO> getSelectedQueryGroupsList() {

		return selectedQueryGroupsList;
	}

	/**
	 * @param selectedQueryGroupsList
	 *            the selectedQueryGroupsList to set
	 */
	public void setSelectedQueryGroupsList(
			List<PWiQueryGroupVO> selectedQueryGroupsList) {

		this.selectedQueryGroupsList = selectedQueryGroupsList;
	}

	/**
	 * @return the availableQueryGroupList
	 */
	public List<PWiQueryGroupVO> getAvailableQueryGroupList() {

		return availableQueryGroupList;
	}

	/**
	 * @param availableQueryGroupList
	 *            the availableQueryGroupList to set
	 */
	public void setAvailableQueryGroupList(
			List<PWiQueryGroupVO> availableQueryGroupList) {

		this.availableQueryGroupList = availableQueryGroupList;
	}

	public void setQueryGroupService(QueryGroupService queryGroupService) {

		this.queryGroupService = queryGroupService;
	}

	// -----------------METHOD DECLARATION FOR EDIT ----------------------
	public String initEdit(Integer theRoleSequenceId) throws PWiException {

		this.roleId = theRoleSequenceId;
		if (roleService != null) {
			// Initialize object type-related state
			PWiRoleVO resultRole = roleService.getRoleById(this.roleId);
			this.roleName = resultRole.getRoleNm();
			this.roleDesc = resultRole.getRoleDesc();
			this.roleType = resultRole.getRoleType();
			renderCreateButton = false;
			renderUpdateButton = true;

			// Initialize group-related state
			this.originalSelectedGroups = queryGroupService
					.findSelectedGroupsForRole(theRoleSequenceId);
			this.selectedQueryGroupsList = new ArrayList<PWiQueryGroupVO>();
			this.selectedQueryGroupsList.addAll(this.originalSelectedGroups);
			this.availableQueryGroupList = (List<PWiQueryGroupVO>) queryGroupService
					.getAllQueryGroups();
			this.availableQueryGroupList.removeAll(selectedQueryGroupsList);

			return PWiConstants.NAV_ADMIN_ROLE_EDITOR;
			// return "NAV_ADMIN_ROLE_EDITOR";
		} else
			throw new PWiException("roleService instance not created..");
	}

	// -----------------METHOD FOR UPDATING THE CHANGES IN DB
	// ----------------------
	public String actionUpdateRole() throws PWiException {

		try {
			String userId = getSsoId();
			// Check for validation errors
			boolean valid = roleService.validateName(this.roleName,
					this.roleDesc);
			if (roleService.checkNamesForEdit(this.roleName, this.roleDesc,
					this.roleId) > 0) {
				handleFacesError(PWiConstants.ERROR_DUPLICATE_NAME);
				valid = false;
			}

			if (!valid) {
				// Validation errors exist, return to same page to display
				// validation error messages
				return PWiConstants.NAV_ADMIN_ROLE_EDITOR;
				// return "NAV_ADMIN_ROLE_EDITOR";
			}
			// Initialize query
			PWiRoleVO role = new PWiRoleVO();
			role.setRoleSeqId(roleId);
			role.setRoleNm(roleName);
			role.setRoleDesc(roleDesc);
			role.setRoleType(roleType);

			List<Integer> selectedGroupIds = new ArrayList<Integer>();
			for (PWiQueryGroupVO group : selectedQueryGroupsList) {
				selectedGroupIds.add(group.getQueryGroupId());
			}

			// Persist updated object type
			roleService.updateRole(role, selectedGroupIds, userId);
			handleFacesInfo("Role " + this.roleName + " updated successfully.");
			return PWiConstants.NAV_ADMIN_ROLE_LIST;
			// return "NAV_ADMIN_ROLE_EDITOR";
		} catch (Exception ex) {
			throw new PWiException("roleService instance was not initiated.."
					+ ex);
		}
	}

	// -----------------METHOD FOR CANCELING THE CHANGES ----------------------

	public String actionCancel() {

		return PWiConstants.NAV_ADMIN_ROLE_LIST;
		// return "NAV_ADMIN_ROLE_EDITOR";
	}

	// -------------------------------------------------------------------------

	public String actionSaveNewRole() throws PWiException {

		try {
			// Check for validation errors
			boolean valid = roleService.validateName(roleName, roleDesc);
			if (roleService.checkNames(roleName, roleDesc) > 0) {
				handleFacesError(PWiConstants.ERROR_DUPLICATE_NAME);
				valid = false;
			}

			if (!valid) {
				// Validation errors exist, return to same page to display
				// validation error messages
				return PWiConstants.NAV_ADMIN_ROLE_EDITOR;
				// return "NAV_ADMIN_ROLE_EDITOR";
			}

			List<Integer> selectedGroupIds = new ArrayList<Integer>();
			for (PWiQueryGroupVO group : selectedQueryGroupsList) {
				selectedGroupIds.add(group.getQueryGroupId());
			}

			// Persist new role
			this.roleId = roleService.createNewRole(roleName, roleDesc,
					roleType, selectedGroupIds, getSsoId());

			handleFacesInfo("Role " + this.roleName + " created successfully.");

			// return "NAV_ADMIN_ROLE_EDITOR";
			return PWiConstants.NAV_ADMIN_ROLE_LIST;
		} catch (Exception ex) {
			throw new PWiException("roleService instance was not initiated.."
					+ ex);
		}
	}

	public String initCreate() {

		// Initialize object type-related state
		this.roleId = null;
		this.roleName = null;
		this.roleDesc = null;

		renderCreateButton = true;
		renderUpdateButton = false;

		// Initialize group-related state
		this.originalSelectedGroups = new ArrayList<PWiQueryGroupVO>();
		this.selectedQueryGroupsList = new ArrayList<PWiQueryGroupVO>();
		this.availableQueryGroupList = (queryGroupService != null) ? (List<PWiQueryGroupVO>) queryGroupService
				.getAllQueryGroups() : null;

		return PWiConstants.NAV_ADMIN_ROLE_EDITOR;
		// return "NAV_ADMIN_ROLE_EDITOR";
	}
	
	public List<SelectItem> getRoleTypeList() throws PWiException {
		if (renderCreateButton) {
			List<String> roleTypelist = roleService.getRoleTypelistList();
			roleType = "";
			roleTypeList = new ArrayList<SelectItem>();
			roleTypeList.add(new SelectItem("Select", "Select Role Name"));
			for (Iterator<String> i = roleTypelist.iterator(); i.hasNext();) {
				String str = i.next();
				roleTypeList.add(new SelectItem(str, str));
			}
		}
		if (renderUpdateButton) {

			List<String> roleTypelist = roleService.getRoleTypelistList();
			roleTypeList = new ArrayList<SelectItem>();
			//roleTypeList.add(new SelectItem(roleType,roleType));
			for (Iterator<String> i = roleTypelist.iterator(); i.hasNext();) {
				String str = i.next();
				roleTypeList.add(new SelectItem(str, str));
			}

		}
		return roleTypeList;
	}

	public void setRolesList(List<SelectItem> rolesList) {
		this.roleTypeList = rolesList;
	}
}
