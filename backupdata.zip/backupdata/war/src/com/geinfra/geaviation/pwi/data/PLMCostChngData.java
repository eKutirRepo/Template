/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCostChngData.java
 * @Creation date: 2-March-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.data;

import java.util.Date;



public class PLMCostChngData {
	/**
	  * Holds the contract
	  */
	private String contract;
	/**
	  * Holds the contractDesc
	  */
	private String contractDesc;
	/**
	  * Holds the topLevelparent
	  */
	private String topLevelparent;
	/**
	  * Holds the lvlOneParentName
	  */
	private String lvlOneParentName;
	/**
	  * Holds the lvlOneParentRev
	  */
	private String lvlOneParentRev;
	/**
	  * Holds the affectItmLvl
	  */
	private String affectItmLvl;
	/**
	  * Holds the affectItmName
	  */
	private String affectItmName;
	/**
	  * Holds the affectItmType
	  */
	private String affectItmType;
	/**
	  * Holds the affectItmDesc
	  */
	private String affectItmDesc;
	/**
	  * Holds the affectItmRev
	  */
	private String affectItmRev;
	/**
	  * Holds the parentName
	  */
	private String parentName;
	/**
	  * Holds the bomPrefix
	  */
	private String bomPrefix;
	/**
	  * Holds the isPartName
	  */
	private String isPartName;
	/**
	  * Holds the isPartRev
	  */
	private String isPartRev;
	/**
	  * Holds the isEstCost
	  */
	private String isEstCost;
	/**
	  * Holds the isTargetCost
	  */
	private String isTargetCost;
	/**
	  * Holds the isErpTotCostAE
	  */
	//private String isErpTotCost;
	private String isErpTotCostAE;
	/**
	  * Holds the isErpTotCostAG
	  */
	private String isErpTotCostAG;
	/**
	  * Holds the isErpTotCostSE
	  */
	private String isErpTotCostSE;
	/**
	  * Holds the isErpTotCostSG
	  */
	private String isErpTotCostSG;
	/**
	  * Holds the isErpTotCostHBAE
	  */
	private String isErpTotCostHBAE;
	/**
	  * Holds the isErpTotCostHBAG
	  */
	private String isErpTotCostHBAG;
	/**
	  * Holds the wasPartName
	  */
	
	
	private String wasPartName;
	/**
	  * Holds the wasPartRev
	  */
	private String wasPartRev;
	/**
	  * Holds the wasEstCost
	  */
	private String wasEstCost;
	/**
	  * Holds the wasTargetCost
	  */
	private String wasTargetCost;
	//private String wasErpTotCost;
	/**
	  * Holds the wasErpTotCostAE
	  */
	private String wasErpTotCostAE;
	/**
	  * Holds the wasErpTotCostAG
	  */
	private String wasErpTotCostAG;
	/**
	  * Holds the wasErpTotCostSE
	  */
	private String wasErpTotCostSE;
	/**
	  * Holds the wasErpTotCostSG
	  */
	private String wasErpTotCostSG;
	/**
	  * Holds the wasErpTotCostHBAE
	  */
	private String wasErpTotCostHBAE;
	/**
	  * Holds the wasErpTotCostHBAG
	  */
	private String wasErpTotCostHBAG;
	/**
	  * Holds the ecrName
	  */
	
	private String ecrName;
	/**
	  * Holds the ecrDesc
	  */
	private String ecrDescCst;
	/**
	  * Holds the ecoName
	  */
	private String ecoName;
	/**
	  * Holds the ecoCtgryChng
	  */
	private String ecoCtgryChng;
	/**
	  * Holds the ecoSeverity
	  */
	private String ecoSeverity;
	/**
	  * Holds the ecoSubstant
	  */
	private String ecoSubstant;
	/**
	  * Holds the ecoDesc
	  */
	
    private String ecoDesc;
	/**
	  * Holds the ecoFastTrack
	  */
    private String ecoFastTrack;
	/**
	  * Holds the ecoStatus
	  */
    private String ecoStatus;
	/**
	  * Holds the ecrStatus
	  */
    private String ecrStatus;
	/**
	  * Holds the reqstChng
	  */
    private String reqstChng;
	/**
	  * Holds the disposInFeild
	  */
    private String disposInFeild;
	/**
	  * Holds the disposInProcess
	  */
    private String disposInProcess;
	/**
	  * Holds the disposInStock
	  */
    private String disposInStock;
	/**
	  * Holds the disposOnOrder
	  */
    private String disposOnOrder;
	/**
	  * Holds the ecoPolicy
	  */
    private String ecoPolicy;
	/**
	  * Holds the clsIimpactTxt
	  */
    private String clsIimpactTxt;
	/**
	  * Holds the bomMarkup
	  */
    private String bomMarkup;
	/**
	  * Holds the bomMarkupType
	  */
    private String bomMarkupType;
	/**
	  * Holds the dfsOrder
	  */
    private String dfsOrder;
	/**
	  * Holds the ecrCompleteDate
	  */
    private Date ecrCompleteDate;
	/**
	  * Holds the ecoCompleteDate
	  */
    private Date ecoCompleteDate;
	/**
	  * Holds the isPartState
	  */
    private String isPartState;
	/**
	  * Holds the isCopicsParent
	  */
    private String isCopicsParent;
	/**
	  * Holds the isBomQuantity
	  */
    private String isBomQuantity;
	/**
	  * Holds the wasCopicsParent
	  */
    private String wasCopicsParent;
	/**
	  * Holds the wasBomQuantity
	  */
    private String wasBomQuantity;
    
    
	/**
	 * @return the contract
	 */
	public String getContract() {
		return contract;
	}
	/**
	 * @param contract the contract to set
	 */
	public void setContract(String contract) {
		this.contract = contract;
	}
	/**
	 * @return the contractDesc
	 */
	public String getContractDesc() {
		return contractDesc;
	}
	/**
	 * @param contractDesc the contractDesc to set
	 */
	public void setContractDesc(String contractDesc) {
		this.contractDesc = contractDesc;
	}
	/**
	 * @return the topLevelparent
	 */
	public String getTopLevelparent() {
		return topLevelparent;
	}
	/**
	 * @param topLevelparent the topLevelparent to set
	 */
	public void setTopLevelparent(String topLevelparent) {
		this.topLevelparent = topLevelparent;
	}
	/**
	 * @return the lvlOneParentName
	 */
	public String getLvlOneParentName() {
		return lvlOneParentName;
	}
	/**
	 * @param lvlOneParentName the lvlOneParentName to set
	 */
	public void setLvlOneParentName(String lvlOneParentName) {
		this.lvlOneParentName = lvlOneParentName;
	}
	/**
	 * @return the lvlOneParentRev
	 */
	public String getLvlOneParentRev() {
		return lvlOneParentRev;
	}
	/**
	 * @param lvlOneParentRev the lvlOneParentRev to set
	 */
	public void setLvlOneParentRev(String lvlOneParentRev) {
		this.lvlOneParentRev = lvlOneParentRev;
	}
	/**
	 * @return the affectItmLvl
	 */
	public String getAffectItmLvl() {
		return affectItmLvl;
	}
	/**
	 * @param affectItmLvl the affectItmLvl to set
	 */
	public void setAffectItmLvl(String affectItmLvl) {
		this.affectItmLvl = affectItmLvl;
	}
	/**
	 * @return the affectItmName
	 */
	public String getAffectItmName() {
		return affectItmName;
	}
	/**
	 * @param affectItmName the affectItmName to set
	 */
	public void setAffectItmName(String affectItmName) {
		this.affectItmName = affectItmName;
	}
	/**
	 * @return the affectItmType
	 */
	public String getAffectItmType() {
		return affectItmType;
	}
	/**
	 * @param affectItmType the affectItmType to set
	 */
	public void setAffectItmType(String affectItmType) {
		this.affectItmType = affectItmType;
	}
	/**
	 * @return the affectItmDesc
	 */
	public String getAffectItmDesc() {
		return affectItmDesc;
	}
	/**
	 * @param affectItmDesc the affectItmDesc to set
	 */
	public void setAffectItmDesc(String affectItmDesc) {
		this.affectItmDesc = affectItmDesc;
	}
	/**
	 * @return the affectItmRev
	 */
	public String getAffectItmRev() {
		return affectItmRev;
	}
	/**
	 * @param affectItmRev the affectItmRev to set
	 */
	public void setAffectItmRev(String affectItmRev) {
		this.affectItmRev = affectItmRev;
	}
	/**
	 * @return the isPartName
	 */
	public String getIsPartName() {
		return isPartName;
	}
	/**
	 * @param isPartName the isPartName to set
	 */
	public void setIsPartName(String isPartName) {
		this.isPartName = isPartName;
	}
	/**
	 * @return the isPartRev
	 */
	public String getIsPartRev() {
		return isPartRev;
	}
	/**
	 * @param isPartRev the isPartRev to set
	 */
	public void setIsPartRev(String isPartRev) {
		this.isPartRev = isPartRev;
	}
	/**
	 * @return the isEstCost
	 */
	public String getIsEstCost() {
		return isEstCost;
	}
	/**
	 * @param isEstCost the isEstCost to set
	 */
	public void setIsEstCost(String isEstCost) {
		this.isEstCost = isEstCost;
	}
	/**
	 * @return the isTargetCost
	 */
	public String getIsTargetCost() {
		return isTargetCost;
	}
	/**
	 * @param isTargetCost the isTargetCost to set
	 */
	public void setIsTargetCost(String isTargetCost) {
		this.isTargetCost = isTargetCost;
	}
	
	/**
	 * @return the wasPartName
	 */
	public String getWasPartName() {
		return wasPartName;
	}
	/**
	 * @param wasPartName the wasPartName to set
	 */
	public void setWasPartName(String wasPartName) {
		this.wasPartName = wasPartName;
	}
	/**
	 * @return the wasPartRev
	 */
	public String getWasPartRev() {
		return wasPartRev;
	}
	/**
	 * @param wasPartRev the wasPartRev to set
	 */
	public void setWasPartRev(String wasPartRev) {
		this.wasPartRev = wasPartRev;
	}
	/**
	 * @return the wasEstCost
	 */
	public String getWasEstCost() {
		return wasEstCost;
	}
	/**
	 * @param wasEstCost the wasEstCost to set
	 */
	public void setWasEstCost(String wasEstCost) {
		this.wasEstCost = wasEstCost;
	}
	/**
	 * @return the wasTargetCost
	 */
	public String getWasTargetCost() {
		return wasTargetCost;
	}
	/**
	 * @param wasTargetCost the wasTargetCost to set
	 */
	public void setWasTargetCost(String wasTargetCost) {
		this.wasTargetCost = wasTargetCost;
	}
	
	/**
	 * @return the ecrName
	 */
	public String getEcrName() {
		return ecrName;
	}
	/**
	 * @param ecrName the ecrName to set
	 */
	public void setEcrName(String ecrName) {
		this.ecrName = ecrName;
	}
	
	/**
	 * @return the ecrDescCst
	 */
	public String getEcrDescCst() {
		return ecrDescCst;
	}
	/**
	 * @param ecrDescCst the ecrDescCst to set
	 */
	public void setEcrDescCst(String ecrDescCst) {
		this.ecrDescCst = ecrDescCst;
	}
	/**
	 * @return the ecrDesc
	 */
	/*public String getEcrDesc() {
		return ecrDesc;
	}*/
	/**
	 * @param ecrDesc the ecrDesc to set
	 */
	/*public void setEcrDesc(String ecrDesc) {
		this.ecrDesc = ecrDesc;
	}*/
	/**
	 * @return the ecoName
	 */
	public String getEcoName() {
		return ecoName;
	}
	/**
	 * @param ecoName the ecoName to set
	 */
	public void setEcoName(String ecoName) {
		this.ecoName = ecoName;
	}
	/**
	 * @return the ecoCtgryChng
	 */
	public String getEcoCtgryChng() {
		return ecoCtgryChng;
	}
	/**
	 * @param ecoCtgryChng the ecoCtgryChng to set
	 */
	public void setEcoCtgryChng(String ecoCtgryChng) {
		this.ecoCtgryChng = ecoCtgryChng;
	}
	/**
	 * @return the ecoSeverity
	 */
	public String getEcoSeverity() {
		return ecoSeverity;
	}
	/**
	 * @param ecoSeverity the ecoSeverity to set
	 */
	public void setEcoSeverity(String ecoSeverity) {
		this.ecoSeverity = ecoSeverity;
	}
	/**
	 * @return the ecoSubstant
	 */
	public String getEcoSubstant() {
		return ecoSubstant;
	}
	/**
	 * @param ecoSubstant the ecoSubstant to set
	 */
	public void setEcoSubstant(String ecoSubstant) {
		this.ecoSubstant = ecoSubstant;
	}
	/**
	 * @return the ecoDesc
	 */
	public String getEcoDesc() {
		return ecoDesc;
	}
	/**
	 * @param ecoDesc the ecoDesc to set
	 */
	public void setEcoDesc(String ecoDesc) {
		this.ecoDesc = ecoDesc;
	}
	/**
	 * @return the ecoFastTrack
	 */
	public String getEcoFastTrack() {
		return ecoFastTrack;
	}
	/**
	 * @param ecoFastTrack the ecoFastTrack to set
	 */
	public void setEcoFastTrack(String ecoFastTrack) {
		this.ecoFastTrack = ecoFastTrack;
	}
	/**
	 * @return the ecoStatus
	 */
	public String getEcoStatus() {
		return ecoStatus;
	}
	/**
	 * @param ecoStatus the ecoStatus to set
	 */
	public void setEcoStatus(String ecoStatus) {
		this.ecoStatus = ecoStatus;
	}
	/**
	 * @return the ecrStatus
	 */
	public String getEcrStatus() {
		return ecrStatus;
	}
	/**
	 * @param ecrStatus the ecrStatus to set
	 */
	public void setEcrStatus(String ecrStatus) {
		this.ecrStatus = ecrStatus;
	}
	/**
	 * @return the reqstChng
	 */
	public String getReqstChng() {
		return reqstChng;
	}
	/**
	 * @param reqstChng the reqstChng to set
	 */
	public void setReqstChng(String reqstChng) {
		this.reqstChng = reqstChng;
	}
	/**
	 * @return the disposInFeild
	 */
	public String getDisposInFeild() {
		return disposInFeild;
	}
	/**
	 * @param disposInFeild the disposInFeild to set
	 */
	public void setDisposInFeild(String disposInFeild) {
		this.disposInFeild = disposInFeild;
	}
	/**
	 * @return the disposInProcess
	 */
	public String getDisposInProcess() {
		return disposInProcess;
	}
	/**
	 * @param disposInProcess the disposInProcess to set
	 */
	public void setDisposInProcess(String disposInProcess) {
		this.disposInProcess = disposInProcess;
	}
	/**
	 * @return the disposInStock
	 */
	public String getDisposInStock() {
		return disposInStock;
	}
	/**
	 * @param disposInStock the disposInStock to set
	 */
	public void setDisposInStock(String disposInStock) {
		this.disposInStock = disposInStock;
	}
	/**
	 * @return the disposOnOrder
	 */
	public String getDisposOnOrder() {
		return disposOnOrder;
	}
	/**
	 * @param disposOnOrder the disposOnOrder to set
	 */
	public void setDisposOnOrder(String disposOnOrder) {
		this.disposOnOrder = disposOnOrder;
	}
	/**
	 * @return the ecoPolicy
	 */
	public String getEcoPolicy() {
		return ecoPolicy;
	}
	/**
	 * @param ecoPolicy the ecoPolicy to set
	 */
	public void setEcoPolicy(String ecoPolicy) {
		this.ecoPolicy = ecoPolicy;
	}
	/**
	 * @return the clsIimpactTxt
	 */
	public String getClsIimpactTxt() {
		return clsIimpactTxt;
	}
	/**
	 * @param clsIimpactTxt the clsIimpactTxt to set
	 */
	public void setClsIimpactTxt(String clsIimpactTxt) {
		this.clsIimpactTxt = clsIimpactTxt;
	}
	/**
	 * @return the bomMarkup
	 */
	public String getBomMarkup() {
		return bomMarkup;
	}
	/**
	 * @param bomMarkup the bomMarkup to set
	 */
	public void setBomMarkup(String bomMarkup) {
		this.bomMarkup = bomMarkup;
	}
	/**
	 * @return the bomMarkupType
	 */
	public String getBomMarkupType() {
		return bomMarkupType;
	}
	/**
	 * @param bomMarkupType the bomMarkupType to set
	 */
	public void setBomMarkupType(String bomMarkupType) {
		this.bomMarkupType = bomMarkupType;
	}
	/**
	 * @return the dfsOrder
	 */
	public String getDfsOrder() {
		return dfsOrder;
	}
	/**
	 * @param dfsOrder the dfsOrder to set
	 */
	public void setDfsOrder(String dfsOrder) {
		this.dfsOrder = dfsOrder;
	}
	/**
	 * @return the isErpTotCostAE
	 */
	public String getIsErpTotCostAE() {
		return isErpTotCostAE;
	}
	/**
	 * @param isErpTotCostAE the isErpTotCostAE to set
	 */
	public void setIsErpTotCostAE(String isErpTotCostAE) {
		this.isErpTotCostAE = isErpTotCostAE;
	}
	/**
	 * @return the isErpTotCostAG
	 */
	public String getIsErpTotCostAG() {
		return isErpTotCostAG;
	}
	/**
	 * @param isErpTotCostAG the isErpTotCostAG to set
	 */
	public void setIsErpTotCostAG(String isErpTotCostAG) {
		this.isErpTotCostAG = isErpTotCostAG;
	}
	/**
	 * @return the isErpTotCostHBAE
	 */
	public String getIsErpTotCostHBAE() {
		return isErpTotCostHBAE;
	}
	/**
	 * @param isErpTotCostHBAE the isErpTotCostHBAE to set
	 */
	public void setIsErpTotCostHBAE(String isErpTotCostHBAE) {
		this.isErpTotCostHBAE = isErpTotCostHBAE;
	}
	/**
	 * @return the isErpTotCostHBAG
	 */
	public String getIsErpTotCostHBAG() {
		return isErpTotCostHBAG;
	}
	/**
	 * @param isErpTotCostHBAG the isErpTotCostHBAG to set
	 */
	public void setIsErpTotCostHBAG(String isErpTotCostHBAG) {
		this.isErpTotCostHBAG = isErpTotCostHBAG;
	}
	/**
	 * @return the wasErpTotCostAE
	 */
	public String getWasErpTotCostAE() {
		return wasErpTotCostAE;
	}
	/**
	 * @param wasErpTotCostAE the wasErpTotCostAE to set
	 */
	public void setWasErpTotCostAE(String wasErpTotCostAE) {
		this.wasErpTotCostAE = wasErpTotCostAE;
	}
	/**
	 * @return the wasErpTotCostAG
	 */
	public String getWasErpTotCostAG() {
		return wasErpTotCostAG;
	}
	/**
	 * @param wasErpTotCostAG the wasErpTotCostAG to set
	 */
	public void setWasErpTotCostAG(String wasErpTotCostAG) {
		this.wasErpTotCostAG = wasErpTotCostAG;
	}
	/**
	 * @return the wasErpTotCostHBAE
	 */
	public String getWasErpTotCostHBAE() {
		return wasErpTotCostHBAE;
	}
	/**
	 * @param wasErpTotCostHBAE the wasErpTotCostHBAE to set
	 */
	public void setWasErpTotCostHBAE(String wasErpTotCostHBAE) {
		this.wasErpTotCostHBAE = wasErpTotCostHBAE;
	}
	/**
	 * @return the wasErpTotCostHBAG
	 */
	public String getWasErpTotCostHBAG() {
		return wasErpTotCostHBAG;
	}
	/**
	 * @param wasErpTotCostHBAG the wasErpTotCostHBAG to set
	 */
	public void setWasErpTotCostHBAG(String wasErpTotCostHBAG) {
		this.wasErpTotCostHBAG = wasErpTotCostHBAG;
	}
	/**
	 * @return the isPartState
	 */
	public String getIsPartState() {
		return isPartState;
	}
	/**
	 * @param isPartState the isPartState to set
	 */
	public void setIsPartState(String isPartState) {
		this.isPartState = isPartState;
	}
	/**
	 * @return the isErpTotCostSE
	 */
	public String getIsErpTotCostSE() {
		return isErpTotCostSE;
	}
	/**
	 * @param isErpTotCostSE the isErpTotCostSE to set
	 */
	public void setIsErpTotCostSE(String isErpTotCostSE) {
		this.isErpTotCostSE = isErpTotCostSE;
	}
	/**
	 * @return the isErpTotCostSG
	 */
	public String getIsErpTotCostSG() {
		return isErpTotCostSG;
	}
	/**
	 * @param isErpTotCostSG the isErpTotCostSG to set
	 */
	public void setIsErpTotCostSG(String isErpTotCostSG) {
		this.isErpTotCostSG = isErpTotCostSG;
	}
	/**
	 * @return the wasErpTotCostSE
	 */
	public String getWasErpTotCostSE() {
		return wasErpTotCostSE;
	}
	/**
	 * @param wasErpTotCostSE the wasErpTotCostSE to set
	 */
	public void setWasErpTotCostSE(String wasErpTotCostSE) {
		this.wasErpTotCostSE = wasErpTotCostSE;
	}
	/**
	 * @return the wasErpTotCostSG
	 */
	public String getWasErpTotCostSG() {
		return wasErpTotCostSG;
	}
	/**
	 * @param wasErpTotCostSG the wasErpTotCostSG to set
	 */
	public void setWasErpTotCostSG(String wasErpTotCostSG) {
		this.wasErpTotCostSG = wasErpTotCostSG;
	}
	/**
	 * @return the isCopicsParent
	 */
	public String getIsCopicsParent() {
		return isCopicsParent;
	}
	/**
	 * @param isCopicsParent the isCopicsParent to set
	 */
	public void setIsCopicsParent(String isCopicsParent) {
		this.isCopicsParent = isCopicsParent;
	}
	/**
	 * @return the isBomQuantity
	 */
	public String getIsBomQuantity() {
		return isBomQuantity;
	}
	/**
	 * @param isBomQuantity the isBomQuantity to set
	 */
	public void setIsBomQuantity(String isBomQuantity) {
		this.isBomQuantity = isBomQuantity;
	}
	/**
	 * @return the wasCopicsParent
	 */
	public String getWasCopicsParent() {
		return wasCopicsParent;
	}
	/**
	 * @param wasCopicsParent the wasCopicsParent to set
	 */
	public void setWasCopicsParent(String wasCopicsParent) {
		this.wasCopicsParent = wasCopicsParent;
	}
	/**
	 * @return the wasBomQuantity
	 */
	public String getWasBomQuantity() {
		return wasBomQuantity;
	}
	/**
	 * @param wasBomQuantity the wasBomQuantity to set
	 */
	public void setWasBomQuantity(String wasBomQuantity) {
		this.wasBomQuantity = wasBomQuantity;
	}
	/**
	 * @return the parentName
	 */
	public String getParentName() {
		return parentName;
	}
	/**
	 * @param parentName the parentName to set
	 */
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	/**
	 * @return the bomPrefix
	 */
	public String getBomPrefix() {
		return bomPrefix;
	}
	/**
	 * @param bomPrefix the bomPrefix to set
	 */
	public void setBomPrefix(String bomPrefix) {
		this.bomPrefix = bomPrefix;
	}
	/**
	 * @return the ecrCompleteDate
	 */
	public Date getEcrCompleteDate() {
		Date ecrCompleteDt=ecrCompleteDate;
		return ecrCompleteDt;
	}
	/**
	 * @param ecrCompleteDate the ecrCompleteDate to set
	 */
	public void setEcrCompleteDate(Date ecrCompleteDate) {
		Date ecrCompleteDt=ecrCompleteDate;
		this.ecrCompleteDate = ecrCompleteDt;
	}
	/**
	 * @return the ecoCompleteDate
	 */
	public Date getEcoCompleteDate() {
		Date ecoCompleteDt=ecoCompleteDate;
		return ecoCompleteDt;
	}
	/**
	 * @param ecoCompleteDate the ecoCompleteDate to set
	 */
	public void setEcoCompleteDate(Date ecoCompleteDate) {
		Date ecoCompleteDt=ecoCompleteDate;
		this.ecoCompleteDate = ecoCompleteDt;
	}
	
	
	
}