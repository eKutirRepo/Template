package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.QiOptionsVO;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 5, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Data access object for object types.
 * 
 * Revision Log Aug 5, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public interface DefaultQiOptionsDAO {

	/**
	 * Get list of default query options for the specified SSO.
	 * 
	 * @param sso
	 * @return list of default query options for the specified SSO
	 * @throws PWiException
	 */
	public List<QiOptionsVO> getDefaultQiOptions(String sso) throws PWiException;

	/**
	 * Insert a query as one of the defaults for the specified user for the
	 * specified object type.
	 * 
	 * @param sso
	 * @param objectTypeId
	 * @param queryId
	 * @param orderIndex
	 * @param querySelected
	 * @param collapseResult
	 * @return primary key of newly inserted record
	 * @throws PWiException
	 */
	public int createDefaultQuery(String sso, int objectTypeId, int queryId,
			int orderIndex, boolean querySelected, boolean collapseResult)
			throws PWiException;
	
	/**
	 * Updates the specified qi option.
	 * 
	 * @param id
	 * @param sso
	 * @param objectTypeId
	 * @param queryId
	 * @param orderIndex
	 * @param querySelected
	 * @param collapseResult
	 * @return the number of rows affected (should be 1)
	 */
	public int updateDefaultQiOption(int id, String sso, int objectTypeId,
			int queryId, int orderIndex, boolean querySelected,
			boolean collapseResult);
	
	/**
	 * Delete all options for the specified query IDs for the specified object
	 * types.
	 * 
	 * @param queryId
	 * @param objectTypeIds
	 */
	public void deleteOptionsForQueryObject(Integer queryId,
			List<Integer> objectTypeIds);
}
