/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEcoSearchData.java
 * @Creation date: 11-Feb-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;
import java.util.List;

public class PLMEcoSearchData {
	/**
	  * Holds the ecoName
	  */
	private String ecoName;
	/**
	  * Holds the ecoRev
	  */
	private String ecoRev;
	/**
	  * Holds the ecoOwner
	  */
	private String ecoOwner;
	/**
	  * Holds the ecoOwnerName
	  */
	private String ecoOwnerName;
	/**
	  * Holds the ecoDesc
	  */
	private String ecoDesc;
	/**
	  * Holds the ecoState
	  */
	private String ecoState;
	/**
	  * Holds the ecoStateList
	  */
	private List<String> ecoStateList;
	/**
	  * Holds the ecoStateExcel
	  */
	private String ecoStateExcel;
	/**
	  * Holds the ecoCateg
	  */
	private String ecoCateg;
	/**
	  * Holds the ecoCategList
	  */
	private List<String> ecoCategList;
	/**
	  * Holds the ecoCategExcel
	  */
	private String ecoCategExcel;
	/**
	  * Holds the ecoSev
	  */
	private String ecoSev;
	/**
	  * Holds the ecoSevList
	  */
	private List<String> ecoSevList;
	/**
	  * Holds the ecoSevExcel
	  */
	private String ecoSevExcel;
	/**
	  * Holds the ecoDesginEngr
	  */
	private String ecoDesginEngr;
	/**
	  * Holds the ecoDesignEngrName
	  */
	private String ecoDesignEngrName;
	/**
	  * Holds the ecoMfgEngr
	  */
	private String ecoMfgEngr;
	/**
	  * Holds the ecoMfgEngrName
	  */
	private String ecoMfgEngrName;
	/**
	  * Holds the routeName
	  */
	private String routeName;
	/**
	  * Holds the routeType
	  */
	private String routeType;
	/**
	  * Holds the routeOwner
	  */
	private String routeOwner;
	/**
	  * Holds the routeLastUp
	  */
	private Date routeLastUp;
	/**
	  * Holds the from_routeLastUp
	  */
	private Date from_routeLastUp;
	/**
	  * Holds the to_routeLastUp
	  */
	private Date to_routeLastUp;
	/**
	  * Holds the routeState
	  */
	private String routeState;
	/**
	  * Holds the routeStatus
	  */
	private String routeStatus;
	/**
	  * Holds the taskName
	  */
	private String taskName;
	/**
	  * Holds the taskCreation
	  */
	private Date taskCreation;
	/**
	  * Holds the from_taskCreation
	  */
	
	private Date from_taskCreation;
	/**
	  * Holds the to_taskCreation
	  */
	private Date to_taskCreation;
	/**
	  * Holds the taskOwner
	  */
	private String taskOwner;
	/**
	  * Holds the taskOwnerFN
	  */
	private String taskOwnerFN;
	/**
	  * Holds the taskOwnerLN
	  */
	private String taskOwnerLN;
	/**
	  * Holds the taskState
	  */
	private String taskState;
	/**
	  * Holds the approvalStat
	  */
	
	private String approvalStat;
	/**
	  * Holds the scheCompDate
	  */
	private Date scheCompDate;
	/**
	  * Holds the from_scheCompDate
	  */
	private Date from_scheCompDate;
	/**
	  * Holds the to_scheCompDate
	  */
	private Date to_scheCompDate;
	/**
	  * Holds the actCompDate
	  */
	private Date actCompDate;
	/**
	  * Holds the from_actCompDate
	  */
	private Date from_actCompDate;
	/**
	  * Holds the to_actCompDate
	  */
	private Date to_actCompDate;
	/**
	  * Holds the dwgName
	  */
	private String dwgName;
	/**
	  * Holds the dwgRev
	  */
	
	private String dwgRev;
	/**
	  * Holds the dwgOriginator
	  */
	private String dwgOriginator;
	/**
	  * Holds the dwgOriginatorName
	  */
	private String dwgOriginatorName;
	/**
	  * Holds the dwgCreateDate
	  */
	private Date dwgCreateDate;
	/**
	  * Holds the from_dwgCreateDate
	  */
	private Date from_dwgCreateDate;
	/**
	  * Holds the to_dwgCreateDate
	  */
	private Date to_dwgCreateDate;
	/**
	  * Holds the dwgRelDate
	  */
	private Date dwgRelDate;
	/**
	  * Holds the from_dwgRelDate
	  */
	private Date from_dwgRelDate;
	/**
	  * Holds the to_dwgRelDate
	  */
	private Date to_dwgRelDate;
	/**
	  * Holds the dwgCycletime
	  */
	private String dwgCycletime;
	/**
	  * Holds the eco_rel_date
	  */
	private String eco_rel_date;
	/**
	  * Holds the eco_orig_date
	  */
	
	private Date eco_orig_date;
	/**
	  * Holds the frmEco_orig_date
	  */
	private Date frmEco_orig_date;
	/**
	  * Holds the frmEco_orig_date_excel
	  */
	private Date frmEco_orig_date_excel;
	/**
	  * Holds the toEco_orig_date
	  */
	private Date toEco_orig_date;
	/**
	  * Holds the toEco_orig_date_excel
	  */
	private Date toEco_orig_date_excel;
	/**
	  * Holds the eco_age_in_days
	  */
	private String eco_age_in_days;
	/**
	  * Holds the ecoOriginator
	  */
	private String ecoOriginator;
	/**
	  * Holds the ecoOriginatorName
	  */
	private String ecoOriginatorName;
	/**
	  * Holds the rdo
	  */
	private String rdo;
	/**
	  * Holds the task_count
	  */
	private String task_count;
	/**
	  * Holds the route_count
	  */
	private String route_count;
	/**
	  * Holds the dwg_count
	  */
	private String dwg_count;
	/**
	  * Holds the seteconame
	  */
	private String seteconame;
	/**
	  * Holds the ecoCycle
	  */
	private String ecoCycle;
//	Added for Fast Track Eco
	private String fastTrackEco;
	
	/**
	  * Holds the ecoReldateExl
	  */
	private Date ecoReldateExl;
	
	/* Added for ECO Rpt Modification */
	private Date frmEcoReleaseDT;	
	private Date toEcoReleaseDT;
	private Date frmEcoReleaseDTExcel;	
	private Date toEcoReleaseDTExcel;
	private String rdecoProdStatus;
	
	private String xlecoCategChng;
	private Date xlecoRlseDt;
	private int xldpoCount;
	private int xlugModelCount;
	private int xlprodParts;
	private int xldevParts;
	
	private List<String> ecoRdoList;
	
	/**
	  * Holds the ecoStateExcel
	  */
	private String ecoRdoExcel;
	/**
	  * Holds the ecoStateExcel
	  */
	
	private String mbpdPartCount;
	/**
	  * Holds the route_count
	  */
	private String mbpdModelCount;
	
	private int mbpdPartCnt;
	/**
	  * Holds the route_count
	  */
	private int mbpdModelCnt;
	
	/* Getter - Setter Mathods Start */
	

	/**
	 * @return the ecoName
	 */
	public String getEcoName() {
		return ecoName;
	}

	
	/**
	 * @param ecoName the ecoName to set
	 */
	public void setEcoName(String ecoName) {
		this.ecoName = ecoName;
	}

	/**
	 * @return the ecoRev
	 */
	public String getEcoRev() {
		return ecoRev;
	}

	/**
	 * @param ecoRev the ecoRev to set
	 */
	public void setEcoRev(String ecoRev) {
		this.ecoRev = ecoRev;
	}

	/**
	 * @return the ecoOwner
	 */
	public String getEcoOwner() {
		return ecoOwner;
	}

	/**
	 * @param ecoOwner the ecoOwner to set
	 */
	public void setEcoOwner(String ecoOwner) {
		this.ecoOwner = ecoOwner;
	}

	/**
	 * @return the ecoDesc
	 */
	public String getEcoDesc() {
		return ecoDesc;
	}

	/**
	 * @param ecoDesc the ecoDesc to set
	 */
	public void setEcoDesc(String ecoDesc) {
		this.ecoDesc = ecoDesc;
	}

	/**
	 * @return the ecoState
	 */
	public String getEcoState() {
		return ecoState;
	}

	/**
	 * @param ecoState the ecoState to set
	 */
	public void setEcoState(String ecoState) {
		this.ecoState = ecoState;
	}

	/**
	 * @return the ecoStateList
	 */
	public List<String> getEcoStateList() {
		return ecoStateList;
	}

	/**
	 * @param ecoStateList the ecoStateList to set
	 */
	public void setEcoStateList(List<String> ecoStateList) {
		this.ecoStateList = ecoStateList;
	}

	/**
	 * @return the ecoStateExcel
	 */
	public String getEcoStateExcel() {
		return ecoStateExcel;
	}

	/**
	 * @param ecoStateExcel the ecoStateExcel to set
	 */
	public void setEcoStateExcel(String ecoStateExcel) {
		this.ecoStateExcel = ecoStateExcel;
	}

	public String getEcoCateg() {
		return ecoCateg;
	}

	public void setEcoCateg(String ecoCateg) {
		this.ecoCateg = ecoCateg;
	}

	/**
	 * @return the ecoCategList
	 */
	public List<String> getEcoCategList() {
		return ecoCategList;
	}

	/**
	 * @param ecoCategList the ecoCategList to set
	 */
	public void setEcoCategList(List<String> ecoCategList) {
		this.ecoCategList = ecoCategList;
	}

	/**
	 * @return the ecoCategExcel
	 */
	public String getEcoCategExcel() {
		return ecoCategExcel;
	}

	/**
	 * @param ecoCategExcel the ecoCategExcel to set
	 */
	public void setEcoCategExcel(String ecoCategExcel) {
		this.ecoCategExcel = ecoCategExcel;
	}

	public String getEcoSev() {
		return ecoSev;
	}

	public void setEcoSev(String ecoSev) {
		this.ecoSev = ecoSev;
	}

	/**
	 * @return the ecoSevList
	 */
	public List<String> getEcoSevList() {
		return ecoSevList;
	}

	/**
	 * @param ecoSevList the ecoSevList to set
	 */
	public void setEcoSevList(List<String> ecoSevList) {
		this.ecoSevList = ecoSevList;
	}

	/**
	 * @return the ecoSevExcel
	 */
	public String getEcoSevExcel() {
		return ecoSevExcel;
	}

	/**
	 * @param ecoSevExcel the ecoSevExcel to set
	 */
	public void setEcoSevExcel(String ecoSevExcel) {
		this.ecoSevExcel = ecoSevExcel;
	}

	

	/**
	 * @return the ecoDesginEngr
	 */
	public String getEcoDesginEngr() {
		return ecoDesginEngr;
	}

	/**
	 * @param ecoDesginEngr the ecoDesginEngr to set
	 */
	public void setEcoDesginEngr(String ecoDesginEngr) {
		this.ecoDesginEngr = ecoDesginEngr;
	}

	/**
	 * @return the ecoMfgEngr
	 */
	public String getEcoMfgEngr() {
		return ecoMfgEngr;
	}

	/**
	 * @param ecoMfgEngr the ecoMfgEngr to set
	 */
	public void setEcoMfgEngr(String ecoMfgEngr) {
		this.ecoMfgEngr = ecoMfgEngr;
	}

	/**
	 * @return the routeName
	 */
	public String getRouteName() {
		return routeName;
	}

	/**
	 * @param routeName the routeName to set
	 */
	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}

	/**
	 * @return the routeType
	 */
	public String getRouteType() {
		return routeType;
	}

	/**
	 * @param routeType the routeType to set
	 */
	public void setRouteType(String routeType) {
		this.routeType = routeType;
	}

	/**
	 * @return the routeOwner
	 */
	public String getRouteOwner() {
		return routeOwner;
	}

	/**
	 * @param routeOwner the routeOwner to set
	 */
	public void setRouteOwner(String routeOwner) {
		this.routeOwner = routeOwner;
	}

	/**
	 * @return the routeLastUp
	 */
	public Date getRouteLastUp() {
		Date temp = null;
		temp = routeLastUp;
		return temp;
	}

	/**
	 * @param routeLastUp
	 *            the routeLastUp to set
	 */
	public void setRouteLastUp(Date routeLastUp) {
		Date temp = null;
		temp = routeLastUp;
		this.routeLastUp = temp;
	}

	/**
	 * @return the from_routeLastUp
	 */
	public Date getFrom_routeLastUp() {
		Date temp = null;
		temp = from_routeLastUp;
		return temp;
	}

	/**
	 * @param from_routeLastUp
	 *            the from_routeLastUp to set
	 */
	public void setFrom_routeLastUp(Date from_routeLastUp) {
		Date temp = null;
		temp = from_routeLastUp;
		this.from_routeLastUp = temp;
	}

	/**
	 * @return the to_routeLastUp
	 */
	public Date getTo_routeLastUp() {
		Date temp = null;
		temp = to_routeLastUp;
		return temp;
	}

	/**
	 * @param to_routeLastUp
	 *            the to_routeLastUp to set
	 */
	public void setTo_routeLastUp(Date to_routeLastUp) {
		Date temp = null;
		temp = to_routeLastUp;
		this.to_routeLastUp = temp;
	}

	/**
	 * @return the taskCreation
	 */
	public Date getTaskCreation() {
		Date temp = null;
		temp = taskCreation;
		return temp;
	}

	/**
	 * @param taskCreation
	 *            the taskCreation to set
	 */
	public void setTaskCreation(Date taskCreation) {
		Date temp = null;
		temp = taskCreation;
		this.taskCreation = temp;
	}

	/**
	 * @return the from_taskCreation
	 */
	public Date getFrom_taskCreation() {
		Date temp = null;
		temp = from_taskCreation;
		return temp;
	}

	/**
	 * @param from_taskCreation
	 *            the from_taskCreation to set
	 */
	public void setFrom_taskCreation(Date from_taskCreation) {
		Date temp = null;
		temp = from_taskCreation;
		this.from_taskCreation = temp;
	}

	/**
	 * @return the to_taskCreation
	 */
	public Date getTo_taskCreation() {
		Date temp = null;
		temp = to_taskCreation;
		return temp;
	}

	/**
	 * @param to_taskCreation
	 *            the to_taskCreation to set
	 */
	public void setTo_taskCreation(Date to_taskCreation) {
		Date temp = null;
		temp = to_taskCreation;
		this.to_taskCreation = temp;
	}

	

	/**
	 * @return the routeState
	 */
	public String getRouteState() {
		return routeState;
	}

	/**
	 * @param routeState the routeState to set
	 */
	public void setRouteState(String routeState) {
		this.routeState = routeState;
	}

	/**
	 * @return the routeStatus
	 */
	public String getRouteStatus() {
		return routeStatus;
	}

	/**
	 * @param routeStatus the routeStatus to set
	 */
	public void setRouteStatus(String routeStatus) {
		this.routeStatus = routeStatus;
	}

	/**
	 * @return the taskName
	 */
	public String getTaskName() {
		return taskName;
	}

	/**
	 * @param taskName the taskName to set
	 */
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	/**
	 * @return the taskOwner
	 */
	public String getTaskOwner() {
		return taskOwner;
	}

	/**
	 * @param taskOwner the taskOwner to set
	 */
	public void setTaskOwner(String taskOwner) {
		this.taskOwner = taskOwner;
	}

	/**
	 * @return the taskOwnerFN
	 */
	public String getTaskOwnerFN() {
		return taskOwnerFN;
	}

	/**
	 * @param taskOwnerFN the taskOwnerFN to set
	 */
	public void setTaskOwnerFN(String taskOwnerFN) {
		this.taskOwnerFN = taskOwnerFN;
	}

	/**
	 * @return the taskOwnerLN
	 */
	public String getTaskOwnerLN() {
		return taskOwnerLN;
	}

	/**
	 * @param taskOwnerLN the taskOwnerLN to set
	 */
	public void setTaskOwnerLN(String taskOwnerLN) {
		this.taskOwnerLN = taskOwnerLN;
	}

	/**
	 * @return the taskState
	 */
	public String getTaskState() {
		return taskState;
	}

	/**
	 * @param taskState the taskState to set
	 */
	public void setTaskState(String taskState) {
		this.taskState = taskState;
	}

	/**
	 * @return the approvalStat
	 */
	public String getApprovalStat() {
		return approvalStat;
	}

	/**
	 * @param approvalStat the approvalStat to set
	 */
	public void setApprovalStat(String approvalStat) {
		this.approvalStat = approvalStat;
	}

	/**
	 * @return the dwgName
	 */
	public String getDwgName() {
		return dwgName;
	}

	/**
	 * @param dwgName the dwgName to set
	 */
	public void setDwgName(String dwgName) {
		this.dwgName = dwgName;
	}

	/**
	 * @return the dwgRev
	 */
	public String getDwgRev() {
		return dwgRev;
	}

	/**
	 * @param dwgRev the dwgRev to set
	 */
	public void setDwgRev(String dwgRev) {
		this.dwgRev = dwgRev;
	}

	/**
	 * @return the dwgOriginator
	 */
	public String getDwgOriginator() {
		return dwgOriginator;
	}

	/**
	 * @param dwgOriginator the dwgOriginator to set
	 */
	public void setDwgOriginator(String dwgOriginator) {
		this.dwgOriginator = dwgOriginator;
	}

	/**
	 * @return the scheCompDate
	 */
	public Date getScheCompDate() {
		Date temp = null;
		temp = scheCompDate;
		return temp;
	}

	/**
	 * @param scheCompDate
	 *            the scheCompDate to set
	 */
	public void setScheCompDate(Date scheCompDate) {
		Date temp = null;
		temp = scheCompDate;
		this.scheCompDate = temp;
	}

	/**
	 * @return the actCompDate
	 */
	public Date getActCompDate() {
		Date temp = null;
		temp = actCompDate;
		return temp;
	}

	/**
	 * @param actCompDate
	 *            the actCompDate to set
	 */
	public void setActCompDate(Date actCompDate) {
		Date temp = null;
		temp = actCompDate;
		this.actCompDate = temp;
	}

	/**
	 * @return the dwgCreateDate
	 */
	public Date getDwgCreateDate() {
		Date temp = null;
		temp = dwgCreateDate;		
		return temp;
	}

	/**
	 * @param dwgCreateDate
	 *            the dwgCreateDate to set
	 */
	public void setDwgCreateDate(Date dwgCreateDate) {
		Date temp = null;
		temp = dwgCreateDate;
		this.dwgCreateDate = temp;
	}

	/**
	 * @return the dwgRelDate
	 */
	public Date getDwgRelDate() {
		Date temp = null;
		temp = dwgRelDate;
		return temp;
	}

	/**
	 * @param dwgRelDate
	 *            the dwgRelDate to set
	 */
	public void setDwgRelDate(Date dwgRelDate) {
		Date temp = null;
		temp = dwgRelDate;
		this.dwgRelDate = temp;
	}

	public String getDwgCycletime() {
		return dwgCycletime;
	}

	public void setDwgCycletime(String dwgCycletime) {
		this.dwgCycletime = dwgCycletime;
	}

	/**
	 * @return the from_scheCompDate
	 */
	public Date getFrom_scheCompDate() {
		Date temp = null;
		temp = from_scheCompDate;
		return temp;
	}

	/**
	 * @param from_scheCompDate
	 *            the from_scheCompDate to set
	 */
	public void setFrom_scheCompDate(Date from_scheCompDate) {
		Date temp = null;
		temp = from_scheCompDate;
		this.from_scheCompDate = temp;
	}

	/**
	 * @return the to_scheCompDate
	 */
	public Date getTo_scheCompDate() {
		Date temp = null;
		temp = to_scheCompDate;
		return temp;
	}

	/**
	 * @param to_scheCompDate
	 *            the to_scheCompDate to set
	 */
	public void setTo_scheCompDate(Date to_scheCompDate) {
		Date temp = null;
		temp = to_scheCompDate;
		this.to_scheCompDate = temp;
	}

	/**
	 * @return the from_actCompDate
	 */
	public Date getFrom_actCompDate() {
		Date temp = null;
		temp = from_actCompDate;
		return temp;
	}

	/**
	 * @param from_actCompDate
	 *            the from_actCompDate to set
	 */
	public void setFrom_actCompDate(Date from_actCompDate) {
		Date temp = null;
		temp = from_actCompDate;
		this.from_actCompDate = temp;
	}

	/**
	 * @return the to_actCompDate
	 */
	public Date getTo_actCompDate() {
		Date temp = null;
		temp = to_actCompDate;
		return temp;
	}

	/**
	 * @param to_actCompDate
	 *            the to_actCompDate to set
	 */
	public void setTo_actCompDate(Date to_actCompDate) {
		Date temp = null;
		temp = to_actCompDate;
		this.to_actCompDate = temp;
	}

	/**
	 * @return the from_dwgCreateDate
	 */
	public Date getFrom_dwgCreateDate() {
		Date temp = null;
		temp = from_dwgCreateDate;
		return temp;
	}

	/**
	 * @param from_dwgCreateDate
	 *            the from_dwgCreateDate to set
	 */
	public void setFrom_dwgCreateDate(Date from_dwgCreateDate) {
		Date temp = null;
		temp = from_dwgCreateDate;
		this.from_dwgCreateDate = temp;
	}

	/**
	 * @return the to_dwgCreateDate
	 */
	public Date getTo_dwgCreateDate() {
		Date temp = null;
		temp = to_dwgCreateDate;
		return temp;
	}

	/**
	 * @param to_dwgCreateDate
	 *            the to_dwgCreateDate to set
	 */
	public void setTo_dwgCreateDate(Date to_dwgCreateDate) {
		Date temp = null;
		temp = to_dwgCreateDate;
		this.to_dwgCreateDate = temp;
	}

	/**
	 * @return the from_dwgRelDate
	 */
	public Date getFrom_dwgRelDate() {
		Date temp = null;
		temp = from_dwgRelDate;
		return temp;
	}

	/**
	 * @param from_dwgRelDate
	 *            the from_dwgRelDate to set
	 */
	public void setFrom_dwgRelDate(Date from_dwgRelDate) {
		Date temp = null;
		temp = from_dwgRelDate;
		this.from_dwgRelDate = temp;
	}

	/**
	 * @return the to_dwgRelDate
	 */
	public Date getTo_dwgRelDate() {
		Date temp = null;
		temp = to_dwgRelDate;
		return temp;
	}

	/**
	 * @param to_dwgRelDate
	 *            the to_dwgRelDate to set
	 */
	public void setTo_dwgRelDate(Date to_dwgRelDate) {
		Date temp = null;
		temp = to_dwgRelDate;
		this.to_dwgRelDate = temp;
	}

	/**
	 * @return the eco_rel_date
	 */
	public String getEco_rel_date() {
		return eco_rel_date;
	}

	/**
	 * @param eco_rel_date
	 *            the eco_rel_date to set
	 */
	public void setEco_rel_date(String eco_rel_date) {
		this.eco_rel_date = eco_rel_date;
	}

	/**
	 * @return the eco_orig_date
	 */
	public Date getEco_orig_date() {
		Date temp = null;
		temp = eco_orig_date;
		return temp;
	}

	/**
	 * @param eco_orig_date
	 *            the eco_orig_date to set
	 */
	public void setEco_orig_date(Date eco_orig_date) {
		Date temp = null;
		temp = eco_orig_date;
		this.eco_orig_date = temp;
	}

	/**
	 * @return the frmEco_orig_date
	 */
	public Date getFrmEco_orig_date() {
		Date temp = null; 
		temp = frmEco_orig_date;
		return temp;
	}

	/**
	 * @param frmEco_orig_date
	 *            the frmEco_orig_date to set
	 */
	public void setFrmEco_orig_date(Date frmEco_orig_date) {
		Date temp = null;
		temp = frmEco_orig_date;
		this.frmEco_orig_date = temp;
	}

	/**
	 * @return the toEco_orig_date
	 */
	public Date getToEco_orig_date() {
		Date temp = null; 
		temp = toEco_orig_date;
		return temp;
	}

	/**
	 * @param toEco_orig_date
	 *            the toEco_orig_date to set
	 */
	public void setToEco_orig_date(Date toEco_orig_date) {
		Date temp = null;
		temp = toEco_orig_date;
		this.toEco_orig_date = temp;
	}

	/**
	 * @return the eco_age_in_days
	 */
	public String getEco_age_in_days() {
		return eco_age_in_days;
	}

	/**
	 * @param eco_age_in_days
	 *            the eco_age_in_days to set
	 */
	public void setEco_age_in_days(String eco_age_in_days) {
		this.eco_age_in_days = eco_age_in_days;
	}

	/**
	 * @return the ecoOriginator
	 */
	public String getEcoOriginator() {
		return ecoOriginator;
	}

	/**
	 * @param ecoOriginator
	 *            the ecoOriginator to set
	 */
	public void setEcoOriginator(String ecoOriginator) {
		this.ecoOriginator = ecoOriginator;
	}

	/**
	 * @return the rdo
	 */
	public String getRdo() {
		return rdo;
	}

	/**
	 * @param rdo
	 *            the rdo to set
	 */
	public void setRdo(String rdo) {
		this.rdo = rdo;
	}

	/**
	 * @return the task_count
	 */
	public String getTask_count() {
		return task_count;
	}

	/**
	 * @param task_count
	 *            the task_count to set
	 */
	public void setTask_count(String task_count) {
		this.task_count = task_count;
	}

	/**
	 * @return the route_count
	 */
	public String getRoute_count() {
		return route_count;
	}

	/**
	 * @param route_count
	 *            the route_count to set
	 */
	public void setRoute_count(String route_count) {
		this.route_count = route_count;
	}

	/**
	 * @return the dwg_count
	 */
	public String getDwg_count() {
		return dwg_count;
	}

	/**
	 * @param dwg_count
	 *            the dwg_count to set
	 */
	public void setDwg_count(String dwg_count) {
		this.dwg_count = dwg_count;
	}

	/**
	 * @return the seteconame
	 */
	public String getSeteconame() {
		return seteconame;
	}

	/**
	 * @param seteconame
	 *            the seteconame to set
	 */
	public void setSeteconame(String seteconame) {
		this.seteconame = seteconame;
	}

	/**
	 * @return the ecoCycle
	 */
	public String getEcoCycle() {
		return ecoCycle;
	}

	/**
	 * @param ecoCycle
	 *            the ecoCycle to set
	 */
	public void setEcoCycle(String ecoCycle) {
		this.ecoCycle = ecoCycle;
	}

	/**
	 * @return the ecoOwnerName
	 */
	public String getEcoOwnerName() {
		return ecoOwnerName;
	}

	/**
	 * @param ecoOwnerName the ecoOwnerName to set
	 */
	public void setEcoOwnerName(String ecoOwnerName) {
		this.ecoOwnerName = ecoOwnerName;
	}

	/**
	 * @return the ecoDesignEngrName
	 */
	public String getEcoDesignEngrName() {
		return ecoDesignEngrName;
	}

	/**
	 * @param ecoDesignEngrName the ecoDesignEngrName to set
	 */
	public void setEcoDesignEngrName(String ecoDesignEngrName) {
		this.ecoDesignEngrName = ecoDesignEngrName;
	}

	/**
	 * @return the ecoMfgEngrName
	 */
	public String getEcoMfgEngrName() {
		return ecoMfgEngrName;
	}

	/**
	 * @param ecoMfgEngrName the ecoMfgEngrName to set
	 */
	public void setEcoMfgEngrName(String ecoMfgEngrName) {
		this.ecoMfgEngrName = ecoMfgEngrName;
	}

	/**
	 * @return the dwgOriginatorName
	 */
	public String getDwgOriginatorName() {
		return dwgOriginatorName;
	}

	/**
	 * @param dwgOriginatorName the dwgOriginatorName to set
	 */
	public void setDwgOriginatorName(String dwgOriginatorName) {
		this.dwgOriginatorName = dwgOriginatorName;
	}

	/**
	 * @return the ecoOriginatorName
	 */
	public String getEcoOriginatorName() {
		return ecoOriginatorName;
	}

	/**
	 * @param ecoOriginatorName the ecoOriginatorName to set
	 */
	public void setEcoOriginatorName(String ecoOriginatorName) {
		this.ecoOriginatorName = ecoOriginatorName;
	}

	/**
	 * @return the frmEco_orig_date_excel
	 */
	public Date getFrmEco_orig_date_excel() {
		return frmEco_orig_date_excel;
	}

	/**
	 * @param frmEco_orig_date_excel the frmEco_orig_date_excel to set
	 */
	public void setFrmEco_orig_date_excel(Date frmEco_orig_date_excel) {
		this.frmEco_orig_date_excel = frmEco_orig_date_excel;
	}

	/**
	 * @return the toEco_orig_date_excel
	 */
	public Date getToEco_orig_date_excel() {
		return toEco_orig_date_excel;
	}

	/**
	 * @param toEco_orig_date_excel the toEco_orig_date_excel to set
	 */
	public void setToEco_orig_date_excel(Date toEco_orig_date_excel) {
		this.toEco_orig_date_excel = toEco_orig_date_excel;
	}
//	Added for Fast Track Eco
	public String getFastTrackEco() {
		return fastTrackEco;
	}

	public void setFastTrackEco(String fastTrackEco) {
		this.fastTrackEco = fastTrackEco;
	}

	/**
	 * @return the ecoReldateExl
	 */
	public Date getEcoReldateExl() {
		Date temp = null;
		temp = ecoReldateExl;
		return temp;
	}

	/**
	 * @param ecoReldateExl the ecoReldateExl to set
	 */
	public void setEcoReldateExl(Date ecoReldateExl) {
		Date temp = null;
		temp = ecoReldateExl;
		this.ecoReldateExl = temp;
	}
	
//	Added for Fast Track Eco
	
	/*-- Added by chandana for ECO release date --*/
	
	
	/**
	 * @return the frmEcoReleaseDT
	 */
	public Date getFrmEcoReleaseDT() {
		Date temp = null;
		temp = frmEcoReleaseDT;
		return temp;
	}


	/**
	 * @param frmEcoReleaseDT the frmEcoReleaseDT to set
	 */
	public void setFrmEcoReleaseDT(Date frmEcoReleaseDT) {
		Date temp = null;
		temp = frmEcoReleaseDT;
		this.frmEcoReleaseDT = temp;
	}


	/**
	 * @return the toEcoReleaseDT
	 */
	public Date getToEcoReleaseDT() {
		Date temp = null;
		temp = toEcoReleaseDT;
		return temp;
	}


	/**
	 * @param toEcoReleaseDT the toEcoReleaseDT to set
	 */
	public void setToEcoReleaseDT(Date toEcoReleaseDT) {
		Date temp = null;
		temp = toEcoReleaseDT;
		this.toEcoReleaseDT = temp;
	}


	/**
	 * @return the rdecoProdStatus
	 */
	public String getRdecoProdStatus() {
		return rdecoProdStatus;
	}


	/**
	 * @param rdecoProdStatus the rdecoProdStatus to set
	 */
	public void setRdecoProdStatus(String rdecoProdStatus) {
		this.rdecoProdStatus = rdecoProdStatus;
	}


	/**
	 * @return the xlecoCategChng
	 */
	public String getXlecoCategChng() {
		return xlecoCategChng;
	}


	/**
	 * @param xlecoCategChng the xlecoCategChng to set
	 */
	public void setXlecoCategChng(String xlecoCategChng) {
		this.xlecoCategChng = xlecoCategChng;
	}


	/**
	 * @return the xlecoRlseDt
	 */
	public Date getXlecoRlseDt() {
		Date temp = null;
		temp = xlecoRlseDt;
		return temp;
	}


	/**
	 * @param xlecoRlseDt the xlecoRlseDt to set
	 */
	public void setXlecoRlseDt(Date xlecoRlseDt) {
		Date temp = null;
		temp = xlecoRlseDt;
		this.xlecoRlseDt = temp;
	}

	/**
	 * @return the xldpoCount
	 */
	public int getXldpoCount() {
		return xldpoCount;
	}


	/**
	 * @param xldpoCount the xldpoCount to set
	 */
	public void setXldpoCount(int xldpoCount) {
		this.xldpoCount = xldpoCount;
	}


	/**
	 * @return the xlugModelCount
	 */
	public int getXlugModelCount() {
		return xlugModelCount;
	}


	/**
	 * @param xlugModelCount the xlugModelCount to set
	 */
	public void setXlugModelCount(int xlugModelCount) {
		this.xlugModelCount = xlugModelCount;
	}


	/**
	 * @return the xlprodParts
	 */
	public int getXlprodParts() {
		return xlprodParts;
	}


	/**
	 * @param xlprodParts the xlprodParts to set
	 */
	public void setXlprodParts(int xlprodParts) {
		this.xlprodParts = xlprodParts;
	}


	/**
	 * @return the xldevParts
	 */
	public int getXldevParts() {
		return xldevParts;
	}


	/**
	 * @param xldevParts the xldevParts to set
	 */
	public void setXldevParts(int xldevParts) {
		this.xldevParts = xldevParts;
	}
	
	/**
	 * @return the frmEcoReleaseDTExcel
	 */
	public Date getFrmEcoReleaseDTExcel() {
		Date temp = null;
		temp = frmEcoReleaseDTExcel;
		return temp;
	}


	/**
	 * @param frmEcoReleaseDTExcel the frmEcoReleaseDTExcel to set
	 */
	public void setFrmEcoReleaseDTExcel(Date frmEcoReleaseDTExcel) {
		Date temp = null;
		temp = frmEcoReleaseDTExcel;
		this.frmEcoReleaseDTExcel = temp;
	}


	/**
	 * @return the toEcoReleaseDTExcel
	 */
	public Date getToEcoReleaseDTExcel() {
		Date temp = null;
		temp = toEcoReleaseDTExcel;
		return temp;
	}


	/**
	 * @param toEcoReleaseDTExcel the toEcoReleaseDTExcel to set
	 */
	public void setToEcoReleaseDTExcel(Date toEcoReleaseDTExcel) {
		Date temp = null;
		temp = toEcoReleaseDTExcel;
		this.toEcoReleaseDTExcel = temp;
	}


	public List<String> getEcoRdoList() {
		return ecoRdoList;
	}


	public void setEcoRdoList(List<String> ecoRdoList) {
		this.ecoRdoList = ecoRdoList;
	}


	public String getEcoRdoExcel() {
		return ecoRdoExcel;
	}


	public void setEcoRdoExcel(String ecoRdoExcel) {
		this.ecoRdoExcel = ecoRdoExcel;
	}


	public String getMbpdPartCount() {
		return mbpdPartCount;
	}


	public void setMbpdPartCount(String mbpdPartCount) {
		this.mbpdPartCount = mbpdPartCount;
	}


	public String getMbpdModelCount() {
		return mbpdModelCount;
	}


	public void setMbpdModelCount(String mbpdModelCount) {
		this.mbpdModelCount = mbpdModelCount;
	}


	public int getMbpdPartCnt() {
		return mbpdPartCnt;
	}


	public void setMbpdPartCnt(int mbpdPartCnt) {
		this.mbpdPartCnt = mbpdPartCnt;
	}


	public int getMbpdModelCnt() {
		return mbpdModelCnt;
	}


	public void setMbpdModelCnt(int mbpdModelCnt) {
		this.mbpdModelCnt = mbpdModelCnt;
	}

	
	
	
}