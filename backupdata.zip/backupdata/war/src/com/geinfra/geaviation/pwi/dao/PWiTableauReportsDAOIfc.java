/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PWiTableauReportsDAOIfc.java
 * @Creation date: 26-April-2016
 * @version 1.0
 * @author : Karunesh. S
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.PWiTableauReportsVO;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PWiTableauReportsDAOIfc {
	/**
	 * This method is used to get Tableau reports list for user
	 * 
	 * @return List
	 * @throws PLMCommonException
	 * @throws PWiException 
	 */
	public List<PWiTableauReportsVO> getTableauReports(Integer id) throws PLMCommonException, PWiException;
	/**
	 * This method is used to create Tableau report instance
	 * 
	 * @return String
	 * @throws PLMCommonException
	 * @throws PWiException 
	 */
	public String createTableauConf(String name, String description, String confServer, String confReportName, String params, String site) throws PLMCommonException, PWiException;
	/**
	 * This method is used to get all Tableau reports list
	 * 
	 * @return List
	 * @throws PLMCommonException
	 * @throws PWiException 
	 */
	public List<PWiTableauReportsVO> getAllTableauReports(Integer id) throws PLMCommonException, PWiException;
	/**
	 * This method is used to map Tableau report
	 * 
	 * @return String
	 * @throws PLMCommonException
	 * @throws PWiException 
	 */
	public String createTableauMapping(Integer userId, Integer reportId)
			throws PLMCommonException, PWiException;
	/**
	 * This method is used to edit Tableau report instance
	 * 
	 * @return String
	 * @throws PLMCommonException
	 * @throws PWiException 
	 */
	public String editTableauConf(String name, String description, String confServer, String confReportName, Integer id) throws PLMCommonException, PWiException;
	/**
	 * This method is used to delete Tableau report mapping
	 * 
	 * @return String
	 * @throws PLMCommonException
	 * @throws PWiException 
	 */
	public String deleteTableauMapping(Integer id) throws PLMCommonException, PWiException;
	/**
	 * This method is used to delete Tableau report
	 * 
	 * @return String
	 * @throws PLMCommonException
	 * @throws PWiException 
	 */
	public String deleteTableauConf(Integer id) throws PLMCommonException,
			PWiException;

}
