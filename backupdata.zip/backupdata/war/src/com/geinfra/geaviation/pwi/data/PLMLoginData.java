/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMLoginData.java
 * @Creation date: 11-Oct-2010
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.io.Serializable;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

public class PLMLoginData implements Serializable {
	/**
	 * The String familyName_LD
	 */
	private String familyName_LD;
	/**
	 * The String givenName_LD
	 */
	private String givenName_LD;
	/**
	 * The String ssoID_LD
	 */

	
	/**
	  * Holds the docSearchAccess
	  */
	private boolean docSearchAccess;
	/**
	  * Holds the drwnWorkFlow
	  */
	private boolean drwnWorkFlow;
	/**
	  * Holds the ecosearch
	  */
	private boolean ecosearch;
	/**
	  * Holds the ecrsearch
	  */
	private boolean ecrsearch;
	/**
	  * Holds the issuessearch
	  */
	private boolean issuessearch;

	public boolean isDocSearchAccess() {
		return docSearchAccess;
	}

	public void setDocSearchAccess(boolean docSearchAccess) {
		this.docSearchAccess = docSearchAccess;
	}

	public boolean isDrwnWorkFlow() {
		return drwnWorkFlow;
	}

	public void setDrwnWorkFlow(boolean drwnWorkFlow) {
		this.drwnWorkFlow = drwnWorkFlow;
	}

	public String getFamilyName_LD() {
		return familyName_LD;
	}

	public void setFamilyName_LD(String familyName_LD) {
		this.familyName_LD = familyName_LD;
	}

	public String getGivenName_LD() {
		return givenName_LD;
	}

	public void setGivenName_LD(String givenName_LD) {
		this.givenName_LD = givenName_LD;
	}

	/**
	 * @return the ecosearch
	 */
	public boolean isEcosearch() {
		return ecosearch;
	}

	/**
	 * @param ecosearch
	 *            the ecosearch to set
	 */
	public void setEcosearch(boolean ecosearch) {
		this.ecosearch = ecosearch;
	}

	/**
	 * @return the ecrsearch
	 */
	public boolean isEcrsearch() {
		return ecrsearch;
	}

	/**
	 * @param ecrsearch
	 *            the ecrsearch to set
	 */
	public void setEcrsearch(boolean ecrsearch) {
		this.ecrsearch = ecrsearch;
	}

	/**
	 * @return the issuessearch
	 */
	public boolean isIssuessearch() {
		return issuessearch;
	}

	/**
	 * @param issuessearch
	 *            the issuessearch to set
	 */
	public void setIssuessearch(boolean issuessearch) {
		this.issuessearch = issuessearch;
	}

	/**
	 * default serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Holds the Param for sqltype
	 */
	private String sqltype = "ICM_ADD_AUTHOR_OBJ";

	/**
	 * The String groupID
	 */
	private String groupId;
	/**
	 * The String groupName
	 */
	private String groupName;
	/**
	 * The String screenId
	 */
	private String screenId;
	/**
	 * The String fName
	 */
	private String fName;
	/**
	 * The String lName
	 */
	private String lName;
	/**
	 * The String userEmail
	 */
	private String userEmail;
	/**
	 * The String userSSOId
	 */
	private String userSsoId;
	/**
	 * The String permissionId
	 */
	private String permissionId;
	/**
	 * The Map securityMatrix
	 */
	private Map<String, List<String>> securityMatrix;
	// Start Of Adminusecase
	/**
	 * The String ssoId
	 */
	private String ssoId;
	/**
	 * The String firstName
	 */
	private String firstName;
	/**
	 * The String lastName
	 */
	private String lastName;
	/**
	 * The String userName
	 */
	private String userName;
	/**
	 * The String email
	 */
	private String email;
	/**
	 * The String phone
	 */
	private String phone;
	/**
	 * The String fax
	 */
	private String fax;
	/**
	 * The String department
	 */
	private String department;
	/**
	 * The Boolean isAdmin
	 */
	private Boolean isAdmin;
	/**
	 * The List of selectItems listOfGroups
	 */
	private List<SelectItem> listOfGroups;
	/**
	 * The String status
	 */
	private String status;
	/**
	 * The String emailNotification
	 */
	private String emailNotification;
	/**
	 * The String comments
	 */
	private String comments;
	/**
	 * The String gropid
	 */
	private String gropid;
	/**
	 * The String city
	 */
	private String city;
	/**
	 * The String state
	 */
	private String state;
	/**
	 * The String country
	 */
	private String country;
	/**
	 * The String address
	 */
	private String address;
	/**
	 * The String zipCode
	 */
	private String zipCode;
	/**
	 * The String activeInd
	 */
	private String activeInd;
	/**
	 * The boolean check
	 */
	private boolean check;
	/**
	 * The List of String groupInd
	 */
	private List<String> groupInd = new ArrayList<String>();
	/**
	 * list of listSelectedGrps.
	 */
	private List<SelectItem> listSelectedGrps;

	/**
	 * @return the check
	 */
	public boolean isCheck() {
		return check;
	}

	/**
	 * @param check
	 *            the check to set
	 */
	public void setCheck(boolean checka) {
		this.check = checka;
	}

	/**
	 * 
	 * @return
	 */
	public String getFName() {
		return fName;
	}

	/**
	 * 
	 * @param name
	 */
	public void setFName(String name) {
		fName = name;
	}

	/**
	 * 
	 * @return
	 */
	public Map<String, List<String>> getSecurityMatrix() {
		return securityMatrix;
	}

	/**
	 * 
	 * @param securityMatrix
	 */
	public void setSecurityMatrix(Map<String, List<String>> securityMatrixa) {
		this.securityMatrix = securityMatrixa;
	}

	/**
	 * 
	 * @return
	 */
	public String getLName() {
		return lName;
	}

	/**
	 * 
	 * @param name
	 */
	public void setLName(String name) {
		lName = name;
	}

	/**
	 * 
	 * @return
	 */
	public String getUserEmail() {
		return userEmail;
	}

	/**
	 * 
	 * @param userEmail
	 */
	public void setUserEmail(String userEmaila) {
		this.userEmail = userEmaila;
	}

	/**
	 * 
	 * @return
	 */
	public String getGroupId() {
		return groupId;
	}

	/**
	 * 
	 * @param groupId
	 */
	public void setGroupId(String groupIda) {
		this.groupId = groupIda;
	}

	/**
	 * 
	 * @return
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * 
	 * @param groupName
	 */
	public void setGroupName(String groupNamea) {
		this.groupName = groupNamea;
	}

	/**
	 * 
	 * @return
	 */
	public String getScreenId() {
		return screenId;
	}

	/**
	 * 
	 * @param screenId
	 */
	public void setScreenId(String screenIda) {
		this.screenId = screenIda;
	}

	/**
	 * 
	 * @return
	 */
	public String getPermissionId() {
		return permissionId;
	}

	/**
	 * 
	 * @param permissionId
	 */
	public void setPermissionId(String permissionIda) {
		this.permissionId = permissionIda;
	}

	/**
	 * @return the ssoId
	 */
	public String getSsoId() {
		return ssoId;
	}

	/**
	 * @param ssoId
	 *            the ssoId to set
	 */
	public void setSsoId(String ssoIda) {
		this.ssoId = ssoIda;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstNamea) {
		this.firstName = firstNamea;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastNamea) {
		this.lastName = lastNamea;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @param phone
	 *            the phone to set
	 */
	public void setPhone(String phonea) {
		this.phone = phonea;
	}

	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * @param department
	 *            the department to set
	 */
	public void setDepartment(String departmenta) {
		this.department = departmenta;
	}

	/**
	 * @return the isAdmin
	 */
	public Boolean getIsAdmin() {
		return isAdmin;
	}

	/**
	 * @param isAdmin
	 *            the isAdmin to set
	 */
	public void setIsAdmin(Boolean isAdmina) {
		this.isAdmin = isAdmina;
	}

	/**
	 * @return the listOfGroups
	 */
	public List<SelectItem> getListOfGroups() {
		return listOfGroups;
	}

	/**
	 * @param listOfGroups
	 *            the listOfGroups to set
	 */
	public void setListOfGroups(List<SelectItem> listOfGroupsa) {
		this.listOfGroups = listOfGroupsa;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String statusa) {
		this.status = statusa;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments
	 *            the comments to set
	 */
	public void setComments(String commentsa) {
		this.comments = commentsa;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String emaila) {
		this.email = emaila;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName
	 *            the userName to set
	 */
	public void setUserName(String userNamea) {
		this.userName = userNamea;
	}

	/**
	 * @return the fax
	 */
	public String getFax() {
		return fax;
	}

	/**
	 * @param fax
	 *            the fax to set
	 */
	public void setFax(String faxa) {
		this.fax = faxa;
	}

	/**
	 * @return the emailNotification
	 */
	public String getEmailNotification() {
		return emailNotification;
	}

	/**
	 * @param emailNotification
	 *            the emailNotification to set
	 */
	public void setEmailNotification(String emailNotificationa) {
		this.emailNotification = emailNotificationa;
	}

	/**
	 * @return the gropid
	 */
	public String getGropid() {
		return gropid;
	}

	/**
	 * @param gropid
	 *            the gropid to set
	 */
	public void setGropid(String gropida) {
		this.gropid = gropida;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city
	 *            the city to set
	 */
	public void setCity(String citya) {
		this.city = citya;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state
	 *            the state to set
	 */
	public void setState(String statea) {
		this.state = statea;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address
	 *            the address to set
	 */
	public void setAddress(String addressa) {
		this.address = addressa;
	}

	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * @param zipCode
	 *            the zipCode to set
	 */
	public void setZipCode(String zipCodea) {
		this.zipCode = zipCodea;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country
	 *            the country to set
	 */
	public void setCountry(String countrya) {
		this.country = countrya;
	}

	/**
	 * @return the activeInd
	 */
	public String getActiveInd() {
		return activeInd;
	}

	/**
	 * @param activeInd1
	 *            the activeInd to set
	 */
	public void setActiveInd(String activeInd1) {
		this.activeInd = activeInd1;
	}

	/**
	 * @return the userSsoId
	 */
	public String getUserSsoId() {
		return userSsoId;
	}

	/**
	 * @param userSsoId
	 *            the userSsoId to set
	 */
	public void setUserSsoId(String userSsoId1) {
		this.userSsoId = userSsoId1;
	}

	/**
	 * @return the groupInd
	 */
	public List<String> getGroupInd() {
		return groupInd;
	}

	/**
	 * @param groupInd
	 *            the groupInd to set
	 */
	public void setGroupInd(List<String> groupInda) {
		this.groupInd = groupInda;
	}

	/**
	 * @return the listSelectedGrps
	 */
	public List<SelectItem> getListSelectedGrps() {
		return listSelectedGrps;
	}

	/**
	 * @param listSelectedGrps
	 *            the listSelectedGrps to set
	 */
	public void setListSelectedGrps(List<SelectItem> listSelectedGrpsa) {
		this.listSelectedGrps = listSelectedGrpsa;
	}

	/**
	 * Writing sql
	 */
	public void writeSQL(SQLOutput stream) throws SQLException {

		stream.writeString(getSsoId());
		stream.writeString(getFirstName());
		stream.writeString(getLastName());
		stream.writeString(getEmail());
		stream.writeString(getPhone());
		stream.writeString(getFax());
		stream.writeString(getDepartment());
		stream.writeString(getAddress());
		stream.writeString(getStatus());
		stream.writeString(getCity());
		stream.writeString(getState());
		stream.writeString(getCountry());
		stream.writeString(getZipCode());

	}

	/**
	 * To change body of implemented methods use File | Settings | File
	 * Templates.
	 */
	public String getSQLTypeName() throws SQLException {
		return sqltype; // To change body of implemented methods use File |
		// Settings | File Templates.
	}

	/**
	 * Reading sql
	 */
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		sqltype = typeName;
		ssoId = stream.readString();
	}
}
