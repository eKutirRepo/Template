/**
 * Copyright (C) 2014 GE Infra. All rights reserved
 * 
 * @FileName PLMBomDfctRptData.java
 * @Creation date: 15-July-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMBomDfctRptData {
	/**
	  * Holds the level
	  */
	private String level;
	/**
	  * Holds the partName
	  */
	private String partName;
	/**
	  * Holds the partRev
	  */
	private String partRev;
	/**
	  * Holds the eid
	  */
	private String eid;
	/**
	  * Holds the quantity
	  */
	private String quantity;
	/**
	  * Holds the prodStatus
	  */
	private String prodStatus;
	/**
	  * Holds the plmUoM
	  */
	private String plmUoM;
	/**
	  * Holds the partDesc
	  */
	private String partDesc;
	/**
	  * Holds the plmState
	  */
	private String plmState;
	/**
	  * Holds the erpItmStaus
	  */
	private String erpItmStaus;
	/**
	  * Holds the erpUoM
	  */
	private String erpUoM;
	/**
	  * Holds the plmChmclCode
	  */
	private String plmChmclCode;
	/**
	  * Holds the errorText
	  */
	private String errorText;
	/**
	  * Holds the alternatePart
	  */
	private String alternatePart;
	
	private String supercededTo;
	
	
	private String findNum;
	
	private String geApplicationNotes;
	
	private String gePreferedReplacement;
	private String itemCost;
	
	private String erpTotalCycle;
	
	
	
	
	
	/**
	 * @return the findNum
	 */
	public String getFindNum() {
		return findNum;
	}
	/**
	 * @param findNum the findNum to set
	 */
	public void setFindNum(String findNum) {
		this.findNum = findNum;
	}
	/**
	 * @return the geApplicationNotes
	 */
	public String getGeApplicationNotes() {
		return geApplicationNotes;
	}
	/**
	 * @param geApplicationNotes the geApplicationNotes to set
	 */
	public void setGeApplicationNotes(String geApplicationNotes) {
		this.geApplicationNotes = geApplicationNotes;
	}
	/**
	 * @return the gePreferedReplacement
	 */
	public String getGePreferedReplacement() {
		return gePreferedReplacement;
	}
	/**
	 * @param gePreferedReplacement the gePreferedReplacement to set
	 */
	public void setGePreferedReplacement(String gePreferedReplacement) {
		this.gePreferedReplacement = gePreferedReplacement;
	}
	/**
	 * @return the itemCost
	 */
	public String getItemCost() {
		return itemCost;
	}
	/**
	 * @param itemCost the itemCost to set
	 */
	public void setItemCost(String itemCost) {
		this.itemCost = itemCost;
	}
	/**
	 * @return the erpTotalCycle
	 */
	public String getErpTotalCycle() {
		return erpTotalCycle;
	}
	/**
	 * @param erpTotalCycle the erpTotalCycle to set
	 */
	public void setErpTotalCycle(String erpTotalCycle) {
		this.erpTotalCycle = erpTotalCycle;
	}
	/**
	 * @return the alternatePart
	 */
	public String getAlternatePart() {
		return alternatePart;
	}
	/**
	 * @param level the alternatePart to set
	 */
	public void setAlternatePart(String alternatePart) {
		this.alternatePart = alternatePart;
	}
	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}
	/**
	 * @return the partName
	 */
	public String getPartName() {
		return partName;
	}
	/**
	 * @param partName the partName to set
	 */
	public void setPartName(String partName) {
		this.partName = partName;
	}
	/**
	 * @return the partRev
	 */
	public String getPartRev() {
		return partRev;
	}
	/**
	 * @param partRev the partRev to set
	 */
	public void setPartRev(String partRev) {
		this.partRev = partRev;
	}
	/**
	 * @return the eid
	 */
	public String getEid() {
		return eid;
	}
	/**
	 * @param eid the eid to set
	 */
	public void setEid(String eid) {
		this.eid = eid;
	}
	/**
	 * @return the quantity
	 */
	public String getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return the prodStatus
	 */
	public String getProdStatus() {
		return prodStatus;
	}
	/**
	 * @param prodStatus the prodStatus to set
	 */
	public void setProdStatus(String prodStatus) {
		this.prodStatus = prodStatus;
	}
	/**
	 * @return the plmUoM
	 */
	public String getPlmUoM() {
		return plmUoM;
	}
	/**
	 * @param plmUoM the plmUoM to set
	 */
	public void setPlmUoM(String plmUoM) {
		this.plmUoM = plmUoM;
	}
	/**
	 * @return the partDesc
	 */
	public String getPartDesc() {
		return partDesc;
	}
	/**
	 * @param partDesc the partDesc to set
	 */
	public void setPartDesc(String partDesc) {
		this.partDesc = partDesc;
	}
	/**
	 * @return the plmState
	 */
	public String getPlmState() {
		return plmState;
	}
	/**
	 * @param plmState the plmState to set
	 */
	public void setPlmState(String plmState) {
		this.plmState = plmState;
	}
	/**
	 * @return the erpItmStaus
	 */
	public String getErpItmStaus() {
		return erpItmStaus;
	}
	/**
	 * @param erpItmStaus the erpItmStaus to set
	 */
	public void setErpItmStaus(String erpItmStaus) {
		this.erpItmStaus = erpItmStaus;
	}
	/**
	 * @return the erpUoM
	 */
	public String getErpUoM() {
		return erpUoM;
	}
	/**
	 * @param erpUoM the erpUoM to set
	 */
	public void setErpUoM(String erpUoM) {
		this.erpUoM = erpUoM;
	}
	/**
	 * @return the plmChmclCode
	 */
	public String getPlmChmclCode() {
		return plmChmclCode;
	}
	/**
	 * @param plmChmclCode the plmChmclCode to set
	 */
	public void setPlmChmclCode(String plmChmclCode) {
		this.plmChmclCode = plmChmclCode;
	}
	/**
	 * @return the errorText
	 */
	public String getErrorText() {
		return errorText;
	}
	/**
	 * @param errorText the errorText to set
	 */
	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}
	
	public String getSupercededTo() {
		return supercededTo;
	}
	
	public void setSupercededTo(String supercededTo) {
		this.supercededTo = supercededTo;
	}
	

}
