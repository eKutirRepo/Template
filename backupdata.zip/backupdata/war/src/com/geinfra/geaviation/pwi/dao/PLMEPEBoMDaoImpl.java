/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEPEBoMDaoImpl.java
 * @Creation date: 05-Nov-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMEPEBoMData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMEPEBoMDaoImpl extends SimpleJdbcDaoSupport implements PLMEPEBoMDaoIfc{
	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMEPEBoMDaoImpl.class);

	/**
	 * This method is used to get List of Top Lvl parts.
	 * 
	 * @param topLvlPart
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEPEBoMData> getTopLvlPartList(String topLvlPart)throws PLMCommonException{	
		LOG.info("Entering getTopLvlPartList Method");
		List<PLMEPEBoMData> topLvlPartList =new ArrayList<PLMEPEBoMData>();
		try{
			LOG.info("top Level Part Input  #  : " + topLvlPart);
			StringBuffer searchProjectNmQry = new StringBuffer();
			searchProjectNmQry.append(PLMOfflineQueries.GET_EPE_TOP_LVL_SEARCH);
			searchProjectNmQry.append(" WHERE (");
			searchProjectNmQry.append(PLMUtils.generatePrjQuryForMultipleNames("FROM_NAME" ,topLvlPart));
			searchProjectNmQry.append(")");
			LOG.info("Executing TOP Level Part Query  > "+searchProjectNmQry);
			topLvlPartList = getSimpleJdbcTemplate().query(searchProjectNmQry.toString(), new TopLvlPartsMapper());
			LOG.info("Size of  TOP Level Part  > "+topLvlPartList.size());
	   		} catch(DataAccessException e){
				PLMUtils.checkException(e.getMessage());
			}
		LOG.info("Exiting getTopLvlPartList Method");
		return topLvlPartList;
	}
	
	
	/**
	 * 
	 * This mapper is used to get the TopLvlPartsMapper
	 *
	 */
	private static class TopLvlPartsMapper implements ParameterizedRowMapper<PLMEPEBoMData> {
		public PLMEPEBoMData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMEPEBoMData tempData = new PLMEPEBoMData();
			tempData.setPartId(PLMUtils.checkNullVal(rs.getString("PART_ID"))+"~"+PLMUtils.checkNullVal(rs.getString("PART_NAME")));
			tempData.setPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
			tempData.setPartRev(PLMUtils.checkNullVal(rs.getString("PART_REV")));
			tempData.setPartDesc(PLMUtils.checkNullVal(rs.getString("PART_DESC")));
			tempData.setPartType(PLMUtils.checkNullVal(rs.getString("PART_TYPE")));
		return tempData; 
		}
	}
	
	/**
	 * This method is used to get EPE BA BOM report
	 * 
	 * @param mlNo
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, Object> getEpeBaBoMReport(String partId) throws PLMCommonException{
		LOG.info("Entering getEpeBaBoMReport Method");
		Map<String, Object> epaBaBomResultMap = new HashMap<String, Object>(); 
		//List<PLMEPEBoMData> partDocIdList =new ArrayList<PLMEPEBoMData>();
		Map<String,List<PLMEPEBoMData>> docRecMap =new HashMap<String,List<PLMEPEBoMData>>();
		String timeStamp = null;
		String ELTTR_VT1 = null;
		String ELTTR_VT2 = null;
		String ELTTR_VT3 = null;
		String ELTTR_VT4 = null;
		//String ELTTR_VT5 = null;
		String ELTTR_VT6 = null;
		String ELTTR_VT7 = null;
		String ELTTR_VT8 = null;
		String ELTTR_VT9 = null;
		
		try{
			timeStamp = PLMUtils.volTableFormatDate();
			LOG.info("The timeStamp for the Report "+timeStamp);
			
			ELTTR_VT1 = PLMConstants.ELTTR_VT1.concat(timeStamp);
			ELTTR_VT2 = PLMConstants.ELTTR_VT2.concat(timeStamp);
			ELTTR_VT3 = PLMConstants.ELTTR_VT3.concat(timeStamp);
			ELTTR_VT4 = PLMConstants.ELTTR_VT4.concat(timeStamp); 
			//ELTTR_VT5 = PLMConstants.ELTTR_VT5.concat(timeStamp);
			ELTTR_VT6 = PLMConstants.ELTTR_VT6.concat(timeStamp);
			ELTTR_VT7 = PLMConstants.ELTTR_VT7.concat(timeStamp);
			ELTTR_VT8 = PLMConstants.ELTTR_VT8.concat(timeStamp);
			ELTTR_VT9 = PLMConstants.ELTTR_VT9.concat(timeStamp);
			
			LOG.info("Query for Creating ELTTR_VT1 : "+PLMOfflineQueries.CREATE_EPE_ELTTR_VT1.replace(PLMConstants.ELTTR_VT1, ELTTR_VT1)
					.replace("?", partId));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_EPE_ELTTR_VT1.replace(PLMConstants.ELTTR_VT1, ELTTR_VT1).replace("?", "'"+partId+"'"));
			
			LOG.info("Query for Collect STATS ELTTR_VT1 : " + PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT1.replace(PLMConstants.ELTTR_VT1, ELTTR_VT1));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT1.replace(PLMConstants.ELTTR_VT1, ELTTR_VT1));
			
			LOG.info("Query for Creating ELTTR_VT2 : " + PLMOfflineQueries.CREATE_EPE_ELTTR_VT2.replace(PLMConstants.ELTTR_VT2, ELTTR_VT2)
						.replace(PLMConstants.ELTTR_VT1, ELTTR_VT1));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_EPE_ELTTR_VT2.replace(PLMConstants.ELTTR_VT2, ELTTR_VT2)
						.replace(PLMConstants.ELTTR_VT1, ELTTR_VT1));
			
			LOG.info("Query for Collect STATS ELTTR_VT2 : " + PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT2.replace(PLMConstants.ELTTR_VT2, ELTTR_VT2));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT2.replace(PLMConstants.ELTTR_VT2, ELTTR_VT2));
			
			LOG.info("Query for Creating ELTTR_VT3 : " + PLMOfflineQueries.CREATE_EPE_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_EPE_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
		
			LOG.info("Query for Collect STATS ELTTR_VT3 : " + PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			
			LOG.info("Query for First INSERT ELTTR_VT3 : " + PLMOfflineQueries.INSERT_EPE_ONE_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.INSERT_EPE_ONE_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
		
			LOG.info("Query for Collect STATS ELTTR_VT3 : " + PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			
			LOG.info("Query for Second INSERT ELTTR_VT3 : " + PLMOfflineQueries.INSERT_EPE_TWO_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.INSERT_EPE_TWO_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
		
			LOG.info("Query for Collect STATS ELTTR_VT3 : " + PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));

			LOG.info("Query for Third INSERT ELTTR_VT3 : " + PLMOfflineQueries.INSERT_EPE_THREE_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.INSERT_EPE_THREE_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
		
			LOG.info("Query for Collect STATS ELTTR_VT3 : " + PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT3.replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));

			LOG.info("Query for Creating ELTTR_VT4 : " + PLMOfflineQueries.CREATE_EPE_ELTTR_VT4.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4)
					.replace(PLMConstants.ELTTR_VT2, ELTTR_VT2).replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_EPE_ELTTR_VT4.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4)
					.replace(PLMConstants.ELTTR_VT2, ELTTR_VT2).replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
		
			LOG.info("Query for INSERT ELTTR_VT4 : " + PLMOfflineQueries.INSERT_EPE_ELTTR_VT4.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4)
					.replace(PLMConstants.ELTTR_VT2, ELTTR_VT2));
			getJdbcTemplate().execute(PLMOfflineQueries.INSERT_EPE_ELTTR_VT4.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4)
					.replace(PLMConstants.ELTTR_VT2, ELTTR_VT2));
		
			LOG.info("Query for Collect STATS ELTTR_VT4 : " + PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT4.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT4.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4));
					
			/*LOG.info("Query for Creating ELTTR_VT5 : " + PLMOfflineQueries.CREATE_ELTTR_VT5.replace(PLMConstants.ELTTR_VT5, ELTTR_VT5)
					.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4).replace(PLMConstants.ELTTR_VT2, ELTTR_VT2));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_ELTTR_VT5.replace(PLMConstants.ELTTR_VT5, ELTTR_VT5)
					.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4).replace(PLMConstants.ELTTR_VT2, ELTTR_VT2));
		
			LOG.info("Query for Collect STATS ELTTR_VT5 : " + PLMOfflineQueries.COLLECT_STATS_ELTTR_VT5.replace(PLMConstants.ELTTR_VT5, ELTTR_VT5));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ELTTR_VT5.replace(PLMConstants.ELTTR_VT5, ELTTR_VT5));*/
		
			
			LOG.info("Query for Creating ELTTR_VT6 : " + PLMOfflineQueries.CREATE_EPE_ELTTR_VT6.replace(PLMConstants.ELTTR_VT6, ELTTR_VT6)
					.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4).replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_EPE_ELTTR_VT6.replace(PLMConstants.ELTTR_VT6, ELTTR_VT6)
					.replace(PLMConstants.ELTTR_VT4, ELTTR_VT4).replace(PLMConstants.ELTTR_VT3, ELTTR_VT3));
		
			LOG.info("Query for Collect STATS ELTTR_VT6 : " + PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT6.replace(PLMConstants.ELTTR_VT6, ELTTR_VT6));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT6.replace(PLMConstants.ELTTR_VT6, ELTTR_VT6));
		
			
			LOG.info("Query for Creating ELTTR_VT7 : " + PLMOfflineQueries.CREATE_EPE_ELTTR_VT7.replace(PLMConstants.ELTTR_VT7, ELTTR_VT7)
					.replace(PLMConstants.ELTTR_VT6, ELTTR_VT6));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_EPE_ELTTR_VT7.replace(PLMConstants.ELTTR_VT7, ELTTR_VT7)
					.replace(PLMConstants.ELTTR_VT6, ELTTR_VT6));
		
			LOG.info("Query for Collect STATS ELTTR_VT7 : " + PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT7.replace(PLMConstants.ELTTR_VT7, ELTTR_VT7));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT7.replace(PLMConstants.ELTTR_VT7, ELTTR_VT7));
			

			LOG.info("Query for Creating ELTTR_VT8 : " + PLMOfflineQueries.CREATE_EPE_ELTTR_VT8.replace(PLMConstants.ELTTR_VT8, ELTTR_VT8)
					.replace(PLMConstants.ELTTR_VT7, ELTTR_VT7));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_EPE_ELTTR_VT8.replace(PLMConstants.ELTTR_VT8, ELTTR_VT8)
					.replace(PLMConstants.ELTTR_VT7, ELTTR_VT7));
		
			LOG.info("Query for Collect STATS ELTTR_VT8 : " + PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT8.replace(PLMConstants.ELTTR_VT8, ELTTR_VT8));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT8.replace(PLMConstants.ELTTR_VT8, ELTTR_VT8));
		
			
			LOG.info("Query for Creating ELTTR_VT9 : " + PLMOfflineQueries.CREATE_EPE_ELTTR_VT9.replace(PLMConstants.ELTTR_VT9, ELTTR_VT9)
					.replace(PLMConstants.ELTTR_VT8, ELTTR_VT8));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_EPE_ELTTR_VT9.replace(PLMConstants.ELTTR_VT9, ELTTR_VT9)
					.replace(PLMConstants.ELTTR_VT8, ELTTR_VT8));
		
			LOG.info("Query for Collect STATS ELTTR_VT9 : " + PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT9.replace(PLMConstants.ELTTR_VT9, ELTTR_VT9));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_EPE_STATS_ELTTR_VT9.replace(PLMConstants.ELTTR_VT9, ELTTR_VT9));
			
			/*LOG.info("Query for Getting GET_ELTTR_VT9 : " + PLMOfflineQueries.GET_ELTTR_VT9.replace(PLMConstants.ELTTR_VT9, ELTTR_VT9));
			epaBaBomResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_ELTTR_VT9.replace(PLMConstants.ELTTR_VT9, ELTTR_VT9),new epeBaResultMapper());
			LOG.info("Result of ELTTR_VT9 : " + epaBaBomResultList.size());
			*/
			
			LOG.info("Query for Getting GET_ELTTR_PART_DATA : " + PLMOfflineQueries.GET_EPE_ELTTR_PART_DATA.
					replace(PLMConstants.ELTTR_VT1, ELTTR_VT1).replace(PLMConstants.ELTTR_VT2, ELTTR_VT2));
			List<PLMEPEBoMData> partDataList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_EPE_ELTTR_PART_DATA.
					replace(PLMConstants.ELTTR_VT1, ELTTR_VT1).replace(PLMConstants.ELTTR_VT2, ELTTR_VT2),new EpeBaPartMapper());
			
			LOG.info("Query for Getting GET_ELTTR_DOC_DATA : " + PLMOfflineQueries.GET_EPE_ELTTR_DOC_DATA.replace(PLMConstants.ELTTR_VT9, ELTTR_VT9));
			List<PLMEPEBoMData> docDataList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_EPE_ELTTR_DOC_DATA.
					replace(PLMConstants.ELTTR_VT9, ELTTR_VT9),new EpeBaDocMapper());
						
			if (!PLMUtils.isEmptyList(docDataList)) {
				List<PLMEPEBoMData> docChldLst = null;
				for (int i =0;i<docDataList.size();i++) {
					docChldLst = null;
					if (docRecMap.containsKey(docDataList.get(i).getTopDocId())){
						docChldLst = docRecMap.get(docDataList.get(i).getTopDocId());
						docChldLst.add(docDataList.get(i));
					} else {
						docChldLst = new ArrayList<PLMEPEBoMData>();
						docChldLst.add(docDataList.get(i));
					}
					docRecMap.put(docDataList.get(i).getTopDocId(),docChldLst);
				}
			}

			LOG.info("partDataList size "+partDataList.size());
			LOG.info("docDataList size "+docDataList.size());
			LOG.info("docRecMap size "+docRecMap.size());
			Collections.sort(partDataList, new SortEPEBOM());
		
			epaBaBomResultMap.put("partDataList", partDataList);
			epaBaBomResultMap.put("docRecMap", docRecMap);
			
		} catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		} 
		LOG.info("Exiting getEpeBaBoMReport Method");
		return epaBaBomResultMap;
	}
	
	/**
	 * Row mapper for getting EpeBaPartMapper
	 */
	private static final class EpeBaPartMapper implements ParameterizedRowMapper<PLMEPEBoMData>{	
	public PLMEPEBoMData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMEPEBoMData tempData = new PLMEPEBoMData();
		tempData.setDfsOrder(PLMUtils.checkNullVal(rs.getString("DFSORDER")));
		tempData.setMliNew(PLMUtils.checkNullVal(rs.getString("MLI_NEW")));
		tempData.setMli(PLMUtils.checkNullVal(rs.getString("MLI")));
		tempData.setPartId(PLMUtils.checkNullVal(rs.getString("PART_ID")));
		tempData.setPartBomLvl(PLMUtils.checkNullVal(rs.getString("PART_BOM_LVL")));
		tempData.setParentPart(PLMUtils.checkNullVal(rs.getString("PARENT_PART")));
		tempData.setPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
		tempData.setPartRev(PLMUtils.checkNullVal(rs.getString("PART_REV")));
		tempData.setPartDesc(PLMUtils.checkNullVal(rs.getString("PART_DESC")));
		tempData.setPartState(PLMUtils.checkNullVal(rs.getString("PART_STATE")));
		tempData.setFindNum(PLMUtils.checkNullVal(rs.getString("FIND_NUM")));
		tempData.setQuantity(PLMUtils.checkNullVal(rs.getString("QUANTITY")));
		tempData.setUom(PLMUtils.checkNullVal(rs.getString("UOM")));
		tempData.setDocId(PLMUtils.checkNullVal(rs.getString("DOC_ID")));
		tempData.setLogicIndr(PLMUtils.checkNullVal(rs.getString("GE_LOGICAL_INDR")));
		tempData.setReplacePart(PLMUtils.checkNullVal(rs.getString("REPLACEMENT_PART")));
		tempData.setModelValidated(PLMUtils.checkNullVal(rs.getString("MODEL_VALIDATED")));
		return tempData;
		}
	}
	
	/**
	 * Row mapper for getting EpeBaDocMapper
	 */
	private static final class EpeBaDocMapper implements ParameterizedRowMapper<PLMEPEBoMData>{	
	public PLMEPEBoMData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMEPEBoMData tempData = new PLMEPEBoMData();
		tempData.setDocId(PLMUtils.checkNullVal(rs.getString("DOC_ID")));
		tempData.setTopDocId(PLMUtils.checkNullVal(rs.getString("TOP_DOC_ID")));
		tempData.setDocBomLvl(PLMUtils.checkNullVal(rs.getString("DOC_BOM_LVL")));
		tempData.setDocParent(PLMUtils.checkNullVal(rs.getString("DOC_PARENT")));
		tempData.setDocName(PLMUtils.checkNullVal(rs.getString("DOC_NAME")));
		tempData.setLogicIndr(PLMUtils.checkNullVal(rs.getString("LOGICAL_INDR")));
		tempData.setDocRev(PLMUtils.checkNullVal(rs.getString("DOC_REV")));
		tempData.setDocType(PLMUtils.checkNullVal(rs.getString("DOC_TYPE")));
		tempData.setDocState(PLMUtils.checkNullVal(rs.getString("DOC_STATE")));
		tempData.setDocTitle(PLMUtils.checkNullVal(rs.getString("DOC_TITLE")));
		tempData.setDocClass(PLMUtils.checkNullVal(rs.getString("DOC_CLASS")));
		tempData.setDwgCrtlCode(PLMUtils.checkNullVal(rs.getString("DWG_CRITICAL_CODE")));
		tempData.setExportCntrl(PLMUtils.checkNullVal(rs.getString("EXPORT_CONTROL")));
		tempData.setModelValidated(PLMUtils.checkNullVal(rs.getString("MODEL_VALIDATED")));
		tempData.setGeMBPD(PLMUtils.checkNullVal(rs.getString("GE_MBPD")));
		return tempData;
		}
	}
		
	/**
	 * Row mapper for getting epeBaResultMapper
	 */
	/*private static final class epeBaResultMapper implements ParameterizedRowMapper<PLMEPEBoMData>{	
	public PLMEPEBoMData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMEPEBoMData tempData = new PLMEPEBoMData();
		tempData.setDfsOrder(PLMUtils.checkNullVal(rs.getString("DFSORDER")));
		tempData.setMli(PLMUtils.checkNullVal(rs.getString("MLI")));
		tempData.setPartBomLvl(PLMUtils.checkNullVal(rs.getString("PART_BOM_LVL")));
		tempData.setParentPart(PLMUtils.checkNullVal(rs.getString("PARENT_PART")));
		tempData.setPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
		tempData.setPartRev(PLMUtils.checkNullVal(rs.getString("PART_REV")));
		tempData.setPartDesc(PLMUtils.checkNullVal(rs.getString("PART_DESC")));
		tempData.setPartState(PLMUtils.checkNullVal(rs.getString("PART_STATE")));
		tempData.setFindNum(PLMUtils.checkNullVal(rs.getString("FIND_NUM")));
		tempData.setQuantity(PLMUtils.checkNullVal(rs.getString("QUANTITY")));
		tempData.setUom(PLMUtils.checkNullVal(rs.getString("UOM")));
		tempData.setReplacePart(PLMUtils.checkNullVal(rs.getString("REPLACEMENT_PART")));
		tempData.setDocBomLvl(PLMUtils.checkNullVal(rs.getString("DOC_BOM_LVL")));
		tempData.setDocParent(PLMUtils.checkNullVal(rs.getString("DOC_PARENT")));
		tempData.setDocName(PLMUtils.checkNullVal(rs.getString("DOC_NAME")));
		tempData.setLogicIndr(PLMUtils.checkNullVal(rs.getString("LOGICAL_INDR")));
		tempData.setDocRev(PLMUtils.checkNullVal(rs.getString("DOC_REV")));
		tempData.setDocType(PLMUtils.checkNullVal(rs.getString("DOC_TYPE")));
		tempData.setDocState(PLMUtils.checkNullVal(rs.getString("DOC_STATE")));
		tempData.setDocTitle(PLMUtils.checkNullVal(rs.getString("DOC_TITLE")));
		tempData.setDocClass(PLMUtils.checkNullVal(rs.getString("DOC_CLASS")));
		tempData.setDwgCrtlCode(PLMUtils.checkNullVal(rs.getString("DWG_CRITICAL_CODE")));
		tempData.setExportCntrl(PLMUtils.checkNullVal(rs.getString("EXPORT_CONTROL")));
		return tempData;
		}
	}*/
	
	/**
	 * 
	 * class to sort list of object of type PLMEPABoMData
	 * 
	 */
	private static class SortEPEBOM implements Comparator<PLMEPEBoMData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMEPEBoMData aString,
				PLMEPEBoMData bString) {
			
			return aString.getDfsOrder().compareTo(bString.getDfsOrder());
		   		      
		}
	}


}
