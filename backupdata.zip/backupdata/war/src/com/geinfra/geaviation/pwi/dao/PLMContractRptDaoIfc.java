/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMContractRptDaoIfc.java
 * @Creation date: 12-Aug-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import com.geinfra.geaviation.pwi.data.PLMContractRptData;
import com.geinfra.geaviation.pwi.data.PLMContractSystemAsignData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMContractRptDaoIfc {
	/**
	 * This method is used to fetch Contract Info
	 * 
	 * @param cntrtNm
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMContractRptData> fetchCntrInfo(String cntrtNm) throws PLMCommonException;
	
	/**
	 * This method is used to getContractInfoRpt
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<PLMContractRptData>> getContractInfoRpt(String cntrtNm)	throws PLMCommonException;
	/**
	 * This method is used to fetch Project Info
	 * 
	 * @param projectNm
	 * @return List
	 * @throws PLMCommonException
	 */
	//Newly Added for Project Summary Report
	public List<PLMContractRptData> fetchProjectInfo(String projectNm) throws PLMCommonException;
	
	public Map<String, List<PLMContractRptData>> getProjectInfoRpt(String projectNm)throws PLMCommonException;

	public List<PLMContractSystemAsignData> searchSystemNames(String systemWithWildcards)throws PLMCommonException;

	public boolean addSystemNames(String systemName, String hdnSystmId,boolean gasId,boolean genId,boolean steamId);

	public boolean deleteSystemName(String systemWithWildcards);

	public List<PLMContractSystemAsignData> searchAssignSystems(PLMContractSystemAsignData assignData)throws PLMCommonException;
	
	public  List<PLMContractSystemAsignData> getAssignOptionData(String selOption)throws PLMCommonException;

	public String assignSystemMapping(List<PLMContractSystemAsignData> popUpOptionMapList,String assign) throws PLMCommonException;
	
	public List<PLMContractSystemAsignData> fetchAssignSystemDataList(List<String> selShipBomProjectName) throws PLMCommonException;
	
}
