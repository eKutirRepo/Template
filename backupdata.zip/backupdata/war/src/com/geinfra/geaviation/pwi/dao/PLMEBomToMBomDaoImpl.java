/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEBomToMBomDaoImpl.java
 * @Creation date: 06-Sept-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMEBomToMBomData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMEBomToMBomDaoImpl extends SimpleJdbcDaoSupport implements PLMEBomToMBomDaoIfc{
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMEBomToMBomDaoImpl.class);
	

	/**
	 * This method is used to get Parts for valid
	 * 
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<String> getValidPartList(List<String> partList) throws PLMCommonException{
		LOG.info("Entering in to getValidPartList");
		List<String> partListLcl =new ArrayList<String>();
		StringBuffer searchResultsQry = new StringBuffer();
		try {
		  if(!PLMUtils.isEmptyList(partList)){	
		    searchResultsQry.append(PLMOfflineQueries.GET_VALID_PARTS);
		    searchResultsQry.append(" WHERE A.NM IN (" +PLMUtils.setListForQuery(partList)+ ")");
		    LOG.info("Executing Query for Getting valid Parts>>> "+searchResultsQry);
		    partListLcl =getSimpleJdbcTemplate().query(searchResultsQry.toString(), new PartNameMapper());
		  }
		}catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting in to getValidPartList");
		return partListLcl;
	}
	
	
	/**
	 * Row mapper for getting PddrMapper
	 */
	private static final class PartNameMapper implements ParameterizedRowMapper<String>{	
	public String mapRow(ResultSet rs, int rowCount) throws SQLException {
		String partName = "";
		partName = PLMUtils.checkNullVal(rs.getString("NM"));
		return partName;
		}
	}
	
	/**
	 * This method is used to getting EBOM Data
	 * 
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEBomToMBomData> getEBOMDataForPartName(String partNumber) throws PLMCommonException{
		LOG.info("Entering in to getEBOMDataForPartName for part Number>> "+partNumber);
		List<PLMEBomToMBomData> ebomDataList =new ArrayList<PLMEBomToMBomData>();
		try {
		LOG.info("Executing Query for Getting EBOM Data List>> "+PLMOfflineQueries.GET_EBOM_DATA);
		
		ebomDataList =getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_EBOM_DATA, new EbomDataForPartMapper(), partNumber);
		LOG.info("Result of ebomDataList  >>>>>>>>>>>>: " + ebomDataList.size());
		}catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting in to getEBOMDataForPartName");
		return ebomDataList;
	}
	
	/**
	 * Row mapper for getting EbomDataForPartMapper
	 */
	private static final class EbomDataForPartMapper implements ParameterizedRowMapper<PLMEBomToMBomData>{	
	public PLMEBomToMBomData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMEBomToMBomData tempData = new PLMEBomToMBomData();
		tempData.setBomLevel(PLMUtils.checkNullVal(rs.getString("BOM_LEVEL")));
		tempData.setBomPrefix(PLMUtils.checkNullVal(rs.getString("GE_BOM_PREFIX")));
		tempData.setEid(PLMUtils.checkNullVal(rs.getString("EID")));
		tempData.setParentName(PLMUtils.checkNullVal(rs.getString("PARENT_NAME")));
		tempData.setPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
		tempData.setBomRevision(PLMUtils.checkNullVal(rs.getString("PART_REVISION")));
		tempData.setDescription(PLMUtils.checkNullVal(rs.getString("PART_DESCRIPTION")));
		tempData.setState(PLMUtils.checkNullVal(rs.getString("PART_STATE")));
		
		if(!PLMUtils.isEmpty(rs.getString("QTY"))){
		  tempData.setQuantityDb(Double.parseDouble(rs.getString("QTY")));
		}
		
		tempData.setQuantity(PLMUtils.checkNullVal(rs.getString("QTY")));
		tempData.setUnitOfMeasure(PLMUtils.checkNullVal(rs.getString("UOM")));
		tempData.setProdStatus(PLMUtils.checkNullVal(rs.getString("PROD_STATUS")));
		tempData.setPathFlag(false);		
		tempData.setCompared(false);	
		tempData.setConsumFlag(false);
		return tempData;
		}
	}
	
	/**
	 * This method is used to getting PLM MBOM Data
	 * 
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEBomToMBomData> getPlmMBOMDataForPartName(String partNumber) throws PLMCommonException{
		LOG.info("Entering in to getPlmMBOMDataForPartName of partNumber >>"+partNumber);
		List<PLMEBomToMBomData> plantIdList =new ArrayList<PLMEBomToMBomData>();
		List<PLMEBomToMBomData> plmMbomDataList =new ArrayList<PLMEBomToMBomData>();
		String timeStamp = null;
		String VT0 =null;
		String VT1 =null;
		try {
		timeStamp = PLMUtils.volTableFormatDate();
		VT0 = PLMConstants.VT0.concat(timeStamp);
		VT1 = PLMConstants.VT1.concat(timeStamp);
		
		LOG.info("Executing Query for Getting Plant Ids>> "+PLMOfflineQueries.GET_PLANT_IDS);
		plantIdList =getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_PLANT_IDS, new PlantNameMapper(), partNumber,partNumber);
		
		if(!PLMUtils.isEmptyList(plantIdList)){
			String plantId=plantIdList.get(0).getPlantId();
			LOG.info("Plant Id >>>>>>>>>> "+plantId);
			
			LOG.info("Executing DELETE FROM GTT_MBOM_RECUR Query : "+PLMOfflineQueries.DELETE_EMBOM_GTT_RECURSION);
			getJdbcTemplate().execute(PLMOfflineQueries.DELETE_EMBOM_GTT_RECURSION);
			
			LOG.info("Executing INSERT INTO GTT_MBOM_RECUR Query " + PLMOfflineQueries.INSERT_EMBOM_GTT_RECURSION.replace("?", plantId));
			getJdbcTemplate().update(PLMOfflineQueries.INSERT_EMBOM_GTT_RECURSION.replace("?", plantId));
			
			LOG.info("Query for Collect STATS MBOM_GTT_RECURSION 1 " + PLMOfflineQueries.COLLECT_MBOM_GTT_RECURSION1);
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_GTT_RECURSION1);
				
			LOG.info("Query for Collect STATS MBOM_GTT_RECURSION 2 " + PLMOfflineQueries.COLLECT_MBOM_GTT_RECURSION2);
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_GTT_RECURSION2);
				
			LOG.info("Query for Collect STATS MBOM_GTT_RECURSION 3 " + PLMOfflineQueries.COLLECT_MBOM_GTT_RECURSION3);
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_GTT_RECURSION3);
			
			LOG.info("Query for Creating VT0 : " + PLMOfflineQueries.CREATE_PLM_MBOM_VT0.replace(PLMConstants.VT0, VT0));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_PLM_MBOM_VT0.replace(PLMConstants.VT0, VT0));
	
			LOG.info("Query for Inserting  VT0 data from from R_PLBOM_CONSUMED : " + PLMOfflineQueries.INSERT_PLM_MBOM_VT0_ONE.replace(PLMConstants.VT0, VT0));
			getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PLM_MBOM_VT0_ONE.replace(PLMConstants.VT0, VT0));
			
			LOG.info("Query for Collect Stats 1 for VT0 : " + PLMOfflineQueries.COLLECT_STATS_PLM_MBOM_VT0.replace(PLMConstants.VT0, VT0));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_PLM_MBOM_VT0.replace(PLMConstants.VT0, VT0));

			LOG.info("Query for Inserting  VT0 data from from R_PLBOM : " + PLMOfflineQueries.INSERT_PLM_MBOM_VT0_TWO.replace(PLMConstants.VT0, VT0));
			getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PLM_MBOM_VT0_TWO.replace(PLMConstants.VT0, VT0));

			LOG.info("Query for Collect Stats 2 for VT0 : " + PLMOfflineQueries.COLLECT_STATS_PLM_MBOM_VT0.replace(PLMConstants.VT0, VT0));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_PLM_MBOM_VT0.replace(PLMConstants.VT0, VT0));
			
			LOG.info("Query for Creating VT1 : " + PLMOfflineQueries.GET_MBOM_GTT_RECURSION.replace(PLMConstants.VT1, VT1).replace("?","'"+partNumber+"'"));
			getJdbcTemplate().execute(PLMOfflineQueries.GET_MBOM_GTT_RECURSION.replace(PLMConstants.VT1, VT1).replace("?","'"+partNumber+"'"));

			
			LOG.info("Query for Getting MBOM Data : " + PLMOfflineQueries.GET_PLM_MBOM_DATA.replace(PLMConstants.VT0, VT0).replace(PLMConstants.VT1, VT1));
			plmMbomDataList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_PLM_MBOM_DATA.replace(PLMConstants.VT0, VT0).replace(PLMConstants.VT1, VT1)
					,new PlmMbomDataForPartMapper());
			LOG.info("Result of Plm MbomDataList  >>>>>>>>>>>>>: " + plmMbomDataList.size());
		 }
		}catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting in to getPlmMBOMDataForPartName");
		return plmMbomDataList;
	}
	
	/**
	 * Row mapper for getting PddrMapper
	 */
	private static final class PlantNameMapper implements ParameterizedRowMapper<PLMEBomToMBomData>{	
	public PLMEBomToMBomData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMEBomToMBomData tempData = new PLMEBomToMBomData();
		tempData.setPlantId(PLMUtils.checkNullVal(rs.getString("PLANT_ID")));
		return tempData;
		}
	}
	
	/**
	 * Row mapper for getting PlmMbomDataForPartMapper
	 */
	private static final class PlmMbomDataForPartMapper implements ParameterizedRowMapper<PLMEBomToMBomData>{	
	public PLMEBomToMBomData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMEBomToMBomData tempData = new PLMEBomToMBomData();
		tempData.setBomLevel(PLMUtils.checkNullVal(rs.getString("BOM_LEVEL")));
		tempData.setBomPrefix(PLMUtils.checkNullVal(rs.getString("GE_BOM_PREFIX")));
		tempData.setEid(PLMUtils.checkNullVal(rs.getString("EID")));
		tempData.setParentName(PLMUtils.checkNullVal(rs.getString("PARENT_NAME")));
		tempData.setPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
		tempData.setBomRevision(PLMUtils.checkNullVal(rs.getString("PART_REVISION")));
		tempData.setDescription(PLMUtils.checkNullVal(rs.getString("PART_DESCRIPTION")));
		tempData.setState(PLMUtils.checkNullVal(rs.getString("PART_STATE")));
		 if(!PLMUtils.isEmpty(rs.getString("PART_QTY"))){
			  tempData.setQuantityDb(Double.parseDouble(rs.getString("PART_QTY")));
		 }
		tempData.setQuantity(PLMUtils.checkNullVal(rs.getString("PART_QTY")));
		tempData.setUnitOfMeasure(PLMUtils.checkNullVal(rs.getString("UOM")));
		tempData.setProdStatus(PLMUtils.checkNullVal(rs.getString("PROD_STATUS")));
		tempData.setConsumState(PLMUtils.checkNullVal(rs.getString("Consumption_Status")));
		tempData.setPathFlag(false);		
		tempData.setCompared(false);
		tempData.setConsumFlag(true);
		return tempData;
		}
	}
	
	/**
	 * This method is used to get Copics MBOM Data
	 * 
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEBomToMBomData> getCopicsMBOMDataForPartName(String partNumber) throws PLMCommonException{
		LOG.info("Entering in to getCopicsMBOMDataForPartName for part Number>> "+partNumber);
		List<PLMEBomToMBomData> copicsMbomDataList =new ArrayList<PLMEBomToMBomData>();
		try {
		LOG.info("Executing Query for Getting COPIC MBOM Data List>> "+PLMOfflineQueries.GET_COPICS_MBOM_DATA);
		
		copicsMbomDataList =getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_COPICS_MBOM_DATA, new CopicsMbomDataForPartMapper(), partNumber);
		LOG.info("Result of Copics MbomDataList  >>>>>>>>>>>>: " + copicsMbomDataList.size());
		}catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting in to getCopicsMBOMDataForPartName");
		return copicsMbomDataList;
	}
	/**
	 * Row mapper for getting CopicsMbomDataForPartMapper
	 */
	private static final class CopicsMbomDataForPartMapper implements ParameterizedRowMapper<PLMEBomToMBomData>{	
	public PLMEBomToMBomData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMEBomToMBomData tempData = new PLMEBomToMBomData();
		tempData.setBomLevel(PLMUtils.checkNullVal(rs.getString("BOM_LEVEL")));
		tempData.setBomPrefix(PLMUtils.checkNullVal(rs.getString("GE_BOM_PREFIX")));
		tempData.setEid(PLMUtils.checkNullVal(rs.getString("EID")));
		tempData.setParentName(PLMUtils.checkNullVal(rs.getString("PARENT_NAME")));
		tempData.setPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
		tempData.setBomRevision(PLMUtils.checkNullVal(rs.getString("PART_REVISION")));
		tempData.setDescription(PLMUtils.checkNullVal(rs.getString("PART_DESCRIPTION")));
		tempData.setState(PLMUtils.checkNullVal(rs.getString("PART_STATE")));
		 if(!PLMUtils.isEmpty(rs.getString("PART_QTY"))){
			  tempData.setQuantityDb(Double.parseDouble(rs.getString("PART_QTY")));
		 }
		tempData.setQuantity(PLMUtils.checkNullVal(rs.getString("PART_QTY")));
		tempData.setUnitOfMeasure(PLMUtils.checkNullVal(rs.getString("UOM")));
		tempData.setProdStatus(PLMUtils.checkNullVal(rs.getString("PROD_STATUS")));
		tempData.setPathFlag(false);		
		tempData.setCompared(false);		
		tempData.setConsumFlag(false);
		return tempData;
		}
	}
	
	/**
	 * This method is used to get Contract for Part Name
	 * 
	 * @param partList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEBomToMBomData> getContractForPartName(List<String> partList) throws PLMCommonException{
		LOG.info("Entering in to getContractForPartName");
		List<PLMEBomToMBomData> contractNameList =new ArrayList<PLMEBomToMBomData>();
		StringBuffer searchResultsQry = new StringBuffer();
		try {
		  if(!PLMUtils.isEmptyList(partList)){	
		    searchResultsQry.append(PLMOfflineQueries.GET_CONTRACT_DATA_FOR_PARTS);
		    searchResultsQry.append(" WHERE TOP_PART IN (" +PLMUtils.setListForQuery(partList)+ ")");
		    LOG.info("Executing Query for Getting contract details for valid Parts>>> "+searchResultsQry);
		    contractNameList =getSimpleJdbcTemplate().query(searchResultsQry.toString(), new ContractDataForPartsMapper());
		  }
		}catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting in to getContractForPartName");
		return contractNameList;
	}
	
	/**
	 * Row mapper for getting ContractDataForPartsMapper
	 */
	private static final class ContractDataForPartsMapper implements ParameterizedRowMapper<PLMEBomToMBomData>{	
	public PLMEBomToMBomData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMEBomToMBomData tempData = new PLMEBomToMBomData();
		tempData.setContractNm(PLMUtils.checkNullVal(rs.getString("CONTRACT_NAME")));
		tempData.setContractDesc(PLMUtils.checkNullVal(rs.getString("CONTRACT_DESC")));
		tempData.setPartNm(PLMUtils.checkNullVal(rs.getString("TOP_PART")));
		return tempData;
		}
	}
	
}
