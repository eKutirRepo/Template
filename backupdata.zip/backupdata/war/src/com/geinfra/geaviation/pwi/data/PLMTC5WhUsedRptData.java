/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMTC5WhUsedRptData.java
 * @Creation date: 5-June-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;
public class PLMTC5WhUsedRptData {
	/**
	 * Holds the topPartDoc
	 */
	private String topPartDoc;
	/**
	 * Holds the topPartDocRev
	 */
	private String topPartDocRev;
	/**
	 * Holds the descFr
	 */
	private String descFr;
	/**
	 * Holds the descEn
	 */
	private String descEn;
	/**
	 * Holds the prj
	 */
	private String prj;
	/**
	 * Holds the contract
	 */
	private String contract;
	/**
	 * Holds the turbine
	 */
	private String turbine;
	/**
	 * Holds the sn
	 */
	private String sn;
	/**
	 * Holds the topPartDoc
	 */
	private String mli;
	/**
	 * Holds the imdtPrntNm
	 */
	private String imdtPrntNm;
	/**
	 * Holds the imdtPrntRev
	 */
	private String imdtPrntRev;
	/**
	 * Holds the imdtPrntFr
	 */
	private String imdtPrntFr;
	/**
	 * Holds the imdtPrntEn
	 */
	private String imdtPrntEn;
	/**
	 * Holds the childPartDoc
	 */
	private String childPartDoc;
	/**
	 * Holds the level
	 */
	private String level;
	/**
	 * Holds the dfsOrder
	 */
	private String dfsOrder;
	/**
	 * @return the topPartDoc
	 */
	public String getTopPartDoc() {
		return topPartDoc;
	}
	/**
	 * @param topPartDoc the topPartDoc to set
	 */
	public void setTopPartDoc(String topPartDoc) {
		this.topPartDoc = topPartDoc;
	}
	/**
	 * @return the topPartDocRev
	 */
	public String getTopPartDocRev() {
		return topPartDocRev;
	}
	/**
	 * @param topPartDocRev the topPartDocRev to set
	 */
	public void setTopPartDocRev(String topPartDocRev) {
		this.topPartDocRev = topPartDocRev;
	}
	/**
	 * @return the descFr
	 */
	public String getDescFr() {
		return descFr;
	}
	/**
	 * @param descFr the descFr to set
	 */
	public void setDescFr(String descFr) {
		this.descFr = descFr;
	}
	/**
	 * @return the descEn
	 */
	public String getDescEn() {
		return descEn;
	}
	/**
	 * @param descEn the descEn to set
	 */
	public void setDescEn(String descEn) {
		this.descEn = descEn;
	}
	/**
	 * @return the prj
	 */
	public String getPrj() {
		return prj;
	}
	/**
	 * @param prj the prj to set
	 */
	public void setPrj(String prj) {
		this.prj = prj;
	}
	/**
	 * @return the contract
	 */
	public String getContract() {
		return contract;
	}
	/**
	 * @param contract the contract to set
	 */
	public void setContract(String contract) {
		this.contract = contract;
	}
	/**
	 * @return the turbine
	 */
	public String getTurbine() {
		return turbine;
	}
	/**
	 * @param turbine the turbine to set
	 */
	public void setTurbine(String turbine) {
		this.turbine = turbine;
	}
	/**
	 * @return the sn
	 */
	public String getSn() {
		return sn;
	}
	/**
	 * @param sn the sn to set
	 */
	public void setSn(String sn) {
		this.sn = sn;
	}
	/**
	 * @return the mli
	 */
	public String getMli() {
		return mli;
	}
	/**
	 * @param mli the mli to set
	 */
	public void setMli(String mli) {
		this.mli = mli;
	}
	/**
	 * @return the imdtPrntNm
	 */
	public String getImdtPrntNm() {
		return imdtPrntNm;
	}
	/**
	 * @param imdtPrntNm the imdtPrntNm to set
	 */
	public void setImdtPrntNm(String imdtPrntNm) {
		this.imdtPrntNm = imdtPrntNm;
	}
	/**
	 * @return the imdtPrntRev
	 */
	public String getImdtPrntRev() {
		return imdtPrntRev;
	}
	/**
	 * @param imdtPrntRev the imdtPrntRev to set
	 */
	public void setImdtPrntRev(String imdtPrntRev) {
		this.imdtPrntRev = imdtPrntRev;
	}
	/**
	 * @return the imdtPrntFr
	 */
	public String getImdtPrntFr() {
		return imdtPrntFr;
	}
	/**
	 * @param imdtPrntFr the imdtPrntFr to set
	 */
	public void setImdtPrntFr(String imdtPrntFr) {
		this.imdtPrntFr = imdtPrntFr;
	}
	/**
	 * @return the imdtPrntEn
	 */
	public String getImdtPrntEn() {
		return imdtPrntEn;
	}
	/**
	 * @param imdtPrntEn the imdtPrntEn to set
	 */
	public void setImdtPrntEn(String imdtPrntEn) {
		this.imdtPrntEn = imdtPrntEn;
	}
	/**
	 * @return the childPartDoc
	 */
	public String getChildPartDoc() {
		return childPartDoc;
	}
	/**
	 * @param childPartDoc the childPartDoc to set
	 */
	public void setChildPartDoc(String childPartDoc) {
		this.childPartDoc = childPartDoc;
	}
	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}
	/**
	 * @return the dfsOrder
	 */
	public String getDfsOrder() {
		return dfsOrder;
	}
	/**
	 * @param dfsOrder the dfsOrder to set
	 */
	public void setDfsOrder(String dfsOrder) {
		this.dfsOrder = dfsOrder;
	}
	
	
	
}
