/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName RptTypeRelationVo.java
 * @Creation date: 18-Aug-2014
 * @version 1.0
  * @author : Tech Mahindra
 */
package com.geinfra.geaviation.pwi.model;

import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.json.Jsonable;

public class RptTypeRelationVo implements Jsonable {
	
	private int rowId;
	private String selType;
	private String selTypeRelVal = "";
	private String selTypeRelValEedw = "";
	private boolean searchable;
	private List<SelectItem> typeRelList= new ArrayList<SelectItem>();

	private int rownum;
	private boolean toDelete;	
	private String coulmnName;
	private String displayName;
	private String inputType;
	private List<String>searchOptr = new ArrayList<String>();
	//private String searchOptr;
	private boolean fillHardCode;
	private boolean fillSqlDriven;
	private String fillDesc;
	private String substPlaceHldr;
	private List<SelectItem> inputTypeList= new ArrayList<SelectItem>();
	private List<SelectItem> substPlaceHldrList = new ArrayList<SelectItem>();
	private List<SelectItem> srchOpList = new ArrayList<SelectItem>();
	
	private List<SelectItem> srchMandtry = new ArrayList<SelectItem>();
	private String selectedSrchMandtry;
	
	public List<SelectItem> getSrchMandtry() {
		return srchMandtry;
	}
	public void setSrchMandtry(List<SelectItem> srchMandtry) {
		this.srchMandtry = srchMandtry;
	}
	public String getSelectedSrchMandtry() {
		return selectedSrchMandtry;
	}
	public void setSelectedSrchMandtry(String selectedSrchMandtry) {
		this.selectedSrchMandtry = selectedSrchMandtry;
	}
	public RptTypeRelationVo()
	{
		
	}
	public RptTypeRelationVo(int rowId,String selType,String selTypeRelVal,List<SelectItem> typeRelList)
	{
		this.rowId = rowId;
		this.selType = selType;
		this.selTypeRelVal = selTypeRelVal.trim();
		this.typeRelList = typeRelList;
	}
	
	
	public int getRowId() {
		return rowId;
	}


	public void setRowId(int rowId) {
		this.rowId = rowId;
	}




	public String getSelType() {
		return selType;
	}




	public void setSelType(String selType) {
		this.selType = selType;
	}




	public String getSelTypeRelVal() {
		return selTypeRelVal.trim();
	}




	public void setSelTypeRelVal(String selTypeRelVal) {
		this.selTypeRelVal = selTypeRelVal.trim();
	}




	public boolean isSearchable() {
		return searchable;
	}




	public void setSearchable(boolean searchable) {
		this.searchable = searchable;
	}


	public List<SelectItem> getTypeRelList() {
		return typeRelList;
	}
	public void setTypeRelList(List<SelectItem> typeRelList) {
		this.typeRelList = typeRelList;
	}
	
	public String getSelTypeRelValEedw() {
		return selTypeRelValEedw.trim();
	}
	public void setSelTypeRelValEedw(String selTypeRelValEedw) {
		this.selTypeRelValEedw = selTypeRelValEedw.trim();
	}
	
	public int getRownum() {
		return rownum;
	}
	public void setRownum(int rownum) {
		this.rownum = rownum;
	}
	public boolean isToDelete() {
		return toDelete;
	}
	public void setToDelete(boolean toDelete) {
		this.toDelete = toDelete;
	}
	public String getCoulmnName() {
		return coulmnName;
	}
	public void setCoulmnName(String coulmnName) {
		this.coulmnName = coulmnName;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getInputType() {
		return inputType;
	}
	public void setInputType(String inputType) {
		this.inputType = inputType;
	}
	/*
	public String getSearchOptr() {
		return searchOptr;
	}
	public void setSearchOptr(String searchOptr) {
		this.searchOptr = searchOptr;
	}
	*/
	
	/**
	 * @return the searchOptr
	 */
	public List<String> getSearchOptr() {
		return searchOptr;
	}
	/**
	 * @param searchOptr the searchOptr to set
	 */
	public void setSearchOptr(List<String> searchOptr) {
		this.searchOptr = searchOptr;
	}
	public boolean isFillHardCode() {
		return fillHardCode;
	}
	public void setFillHardCode(boolean fillHardCode) {
		this.fillHardCode = fillHardCode;
	}
	public boolean isFillSqlDriven() {
		return fillSqlDriven;
	}
	public void setFillSqlDriven(boolean fillSqlDriven) {
		this.fillSqlDriven = fillSqlDriven;
	}
	public String getFillDesc() {
		return fillDesc;
	}
	public void setFillDesc(String fillDesc) {
		this.fillDesc = fillDesc;
	}
	public String getSubstPlaceHldr() {
		return substPlaceHldr;
	}
	public void setSubstPlaceHldr(String substPlaceHldr) {
		this.substPlaceHldr = substPlaceHldr;
	}
	
	
	public List<SelectItem> getInputTypeList() {
		return inputTypeList;
	}
	public void setInputTypeList(List<SelectItem> inputTypeList) {
		this.inputTypeList = inputTypeList;
	}
	public List<SelectItem> getSubstPlaceHldrList() {
		return substPlaceHldrList;
	}
	public void setSubstPlaceHldrList(List<SelectItem> substPlaceHldrList) {
		this.substPlaceHldrList = substPlaceHldrList;
	}
	
	
	public List<SelectItem> getSrchOpList() {
		return srchOpList;
	}
	public void setSrchOpList(List<SelectItem> srchOpList) {
		this.srchOpList = srchOpList;
	}
	@Override
	public String toJson() {
		// TODO Auto-generated method stub
		return null;
	}



}
