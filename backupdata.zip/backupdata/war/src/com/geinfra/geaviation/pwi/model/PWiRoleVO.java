package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;

import com.geinfra.geaviation.pwi.json.JsonBuilder;
import com.geinfra.geaviation.pwi.json.Jsonable;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : PWiObjectTypeVO - Object Type object.
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiRoleVO extends PWiBaseVO implements Serializable,
		Jsonable {
	private static final long serialVersionUID = 2L;
	private Integer roleSeqId;
	private String roleNm;
	private String roleDesc;
	private String roleType;
	private boolean eligibleFrDlt;

	public PWiRoleVO() {
	}

	public PWiRoleVO(Integer roleSeqId) {
		this.roleSeqId = roleSeqId;
	}

	public PWiRoleVO(Integer roleSeqId, String roleNm, String roleDesc , String roleType) {
		this.roleSeqId = roleSeqId;
		this.roleNm = roleNm;
		this.roleDesc = roleDesc;
		this.roleType = roleType;
	}

	public Integer getRoleSeqId() {
		return roleSeqId;
	}

	public void setRoleSeqId(Integer roleSeqId) {
		this.roleSeqId = roleSeqId;
	}

	public String getRoleNm() {
		return roleNm;
	}

	public void setRoleNm(String roleNm) {
		this.roleNm = roleNm;
	}

	public String getRoleDesc() {
		return roleDesc;
	}

	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}
	
		
	public String getRoleType() {
	
		return roleType;
	}

	
	public void setRoleType(String roleType) {
	
		this.roleType = roleType;
	}
		
	public boolean isEligibleFrDlt() {
	
		return eligibleFrDlt;
	}

	
	public void setEligibleFrDlt(boolean eligibleFrDlt) {
	
		this.eligibleFrDlt = eligibleFrDlt;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (roleSeqId != null ? roleSeqId.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object instanceof PWiRoleVO) {
			PWiRoleVO other = (PWiRoleVO) object;
			if (this.roleSeqId != null && other.roleSeqId != null) {
				return this.roleSeqId.equals(other.roleSeqId);
			}
		}
		return false;
	}

	@Override
	public String toString() {
		return (null != this.getRoleDesc() ? this.getRoleDesc() : "");
	}

	public String toJson() {
		JsonBuilder builder = new JsonBuilder();
		builder.startObject();
		builder.addStringProperty("id", roleSeqId);
		builder.addStringProperty("name", roleNm);
		builder.addStringProperty("description", roleDesc);
		builder.addStringProperty("type", roleType);
		builder.endObject();
		return builder.toString();
	}
}
