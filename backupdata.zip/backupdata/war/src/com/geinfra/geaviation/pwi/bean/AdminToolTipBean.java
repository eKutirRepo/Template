package com.geinfra.geaviation.pwi.bean;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;

import org.apache.commons.lang.StringUtils;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.service.AdminToolTipService;

/**
 * 
 * Project : Product Lifecycle Management
 * Date Written : May 19, 2010
 * Security : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2013 GE All rights reserved
 * 
 * Description : AdminSettingsBean - allows administrators to set
 *                                   application parameters
 * 
 * Revision Log May 19, 2010 | v1.0.
 * --------------------------------------------------------------
 * 2013.01.16   Himanshu    Added new configurable fields
 * 2013.02.08   Hasso       Extended validation to all HTML fields 
 */

public class AdminToolTipBean extends BaseBean {
	private static final String JAVASCRIPT_START_TAG = "<SCRIPT";
	private static final String JAVASCRIPT_CLOSE_TAG = "</SCRIPT>";
	private static final String JAVASCRIPT = "TEXT/JAVASCRIPT";

	private AdminToolTipService adminToolTipService;

	private String homeToolTipText;
	
	public void setAdminToolTipService(
			AdminToolTipService adminToolTipService) {
		this.adminToolTipService = adminToolTipService;
	}

	@PostConstruct
	public void postConstruct() {
		try {
			String postback = FacesContext.getCurrentInstance()
					.getExternalContext().getRequestParameterMap().get(
							"postback");
			// Unless postback, need to loading settings from database
			if (postback == null) {
				homeToolTipText = adminToolTipService.getHomeToolTip();

			}
		} catch (PWiException e) {
			// Throw RuntimeException because PostConstruct annotation doesn't
			// support checked exceptions
			throw new RuntimeException("Error post-constructing", e);
		}

	}

	public String actionSaveSettings() throws PWiException {
		// Make sure there is no JavaScript in any customizeable HTML
		if ( ! (validate(homeToolTipText)) ) {
			return "";
		}

		// Save header text
		adminToolTipService.setHomeToolTip(homeToolTipText);
		
		return "updated";
	}

	private boolean validate(String text) {
		boolean valid = true;

		// Validate text
		if (StringUtils.contains(StringUtils.upperCase(text),
				JAVASCRIPT_START_TAG)
				|| StringUtils.contains(StringUtils.upperCase(text),
						JAVASCRIPT)
				|| StringUtils.contains(StringUtils.upperCase(text),
						JAVASCRIPT_CLOSE_TAG)) {
			handleFacesError("Validation Failed! Please remove JavaScript from all custom text.");
			valid = false;
		}

		return valid;
	}

	/**
	 * @return the settingsText
	 * @throws PWiException
	 */
	
	public String getHomeToolTipText() throws PWiException {
		return homeToolTipText;
	}
	
	public void setHomeToolTipText(String settingsValue) {
		this.homeToolTipText = settingsValue;
	}
	
}
