/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEPEBoMDaoIfc.java
 * @Creation date: 05-Nov-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import com.geinfra.geaviation.pwi.data.PLMEPEBoMData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMEPEBoMDaoIfc {
	/**
	 * This method is used to get List of Top Lvl parts.
	 * 
	 * @param topLvlPart
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEPEBoMData> getTopLvlPartList(String topLvlPart)throws PLMCommonException;	
	/**
	 * This method is used to get EPE BA BOM report
	 * 
	 * @param partId
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, Object> getEpeBaBoMReport(String partId) throws PLMCommonException;
}
