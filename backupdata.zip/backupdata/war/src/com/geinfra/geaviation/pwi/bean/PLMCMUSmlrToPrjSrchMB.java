/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCMUSmlrToPrjSrchMB.java
 * @Creation date: 23-Mar-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Hyperlink;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFHyperlink;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMCMUSmlrToPrjData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMWhereUsedServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMCMUSmlrToPrjSrchMB {

	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMCMUSmlrToPrjSrchMB.class);
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor =null;
	/**
	 * Holds the cmuSmlrToPrjSrchData
	 */
	private PLMCMUSmlrToPrjData cmuSmlrToPrjSrchData = new PLMCMUSmlrToPrjData();
	
	/**
	 * Holds the resourceBundle
	 */
	ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the User info
	 */
	private PLMPwiUserData userDetails = null;
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB=null;
	/**
	 * Holds the plmWhereUsedService
	 */
	private PLMWhereUsedServiceIfc plmWhereUsedService = null;
	
	private List<SelectItem> frameTypeList = new ArrayList<SelectItem>();
	private List<SelectItem> fuelTypeList = new ArrayList<SelectItem>();
	private List<SelectItem> combustorTypeList = new ArrayList<SelectItem>();
	private String alertMessage;
	Map<String,List<PLMCMUSmlrToPrjData>> allReport = new HashMap<String,List<PLMCMUSmlrToPrjData>>();
	private List<PLMCMUSmlrToPrjData> cmuOnscreentListForParts = new ArrayList<PLMCMUSmlrToPrjData>();
	private List<PLMCMUSmlrToPrjData> cmuOnscreentListForDoc = new ArrayList<PLMCMUSmlrToPrjData>();
	//Adding 2 more variables to store data
	private List<PLMCMUSmlrToPrjData> cmuOnscreentListForPartsTemp = new ArrayList<PLMCMUSmlrToPrjData>();
	private List<PLMCMUSmlrToPrjData> cmuOnscreentListForDocTemp = new ArrayList<PLMCMUSmlrToPrjData>();
	
	private boolean cmuSimPrjSrchFlag = false;
	private boolean partsBomFlg;
	private boolean docBomFlg;
	private boolean partsInfoFlag=true;
	private boolean docInfoFlag=true;
	private String noPartsRecFound;
	private String noDocRecFound;
	private Date effectivityDateFrom;
	private Date effectivityDateTo;
	private boolean allOpenFrameTypeList=false;

	private boolean allOpenFrameTypeFreeTxt=false;
	private String mliTextBoxName;
	private String selFrameTypeListName;
	private String selFuelTypeListName;
	private String selCombustorTypeListName;
	private String selFrameTypeTextBoxName;
	private String selFuelTypeTextBoxName;
	private String selCombustorTypeTextBoxName;
	private int partsCounts;
	private int docCounts;
	private int recordPartsCounts = PLMConstants.N_100;
	private int recordDocCounts = PLMConstants.N_100;
	private String totalRecordPartsAptMsg;
	private String totalRecordDocAptMsg;
	
	/**
	 * @param mliTextBoxName the mliTextBoxName to set
	 */
	public void setMliTextBoxName(String mliTextBoxName) {
		this.mliTextBoxName = mliTextBoxName;
	}
	/**
	 * @return the totalRecordDocAptMsg
	 */
	public String getMliTextBoxName() {
		return mliTextBoxName;
	}
	/**
	 * @return the totalRecordPartsAptMsg
	 */
	public String getTotalRecordPartsAptMsg() {
		return totalRecordPartsAptMsg;
	}
	/**
	 * @param totalRecordPartsAptMsg the totalRecordPartsAptMsg to set
	 */
	public void setTotalRecordPartsAptMsg(String totalRecordPartsAptMsg) {
		this.totalRecordPartsAptMsg = totalRecordPartsAptMsg;
	}
	/**
	 * @return the totalRecordDocAptMsg
	 */
	public String getTotalRecordDocAptMsg() {
		return totalRecordDocAptMsg;
	}
	/**
	 * @param totalRecordDocAptMsg the totalRecordDocAptMsg to set
	 */
	public void setTotalRecordDocAptMsg(String totalRecordDocAptMsg) {
		this.totalRecordDocAptMsg = totalRecordDocAptMsg;
	}
	/**
	 * @return the partsCounts
	 */
	public int getPartsCounts() {
		return partsCounts;
	}
	/**
	 * @param partsCounts the partsCounts to set
	 */
	public void setPartsCounts(int partsCounts) {
		this.partsCounts = partsCounts;
	}
	/**
	 * @return the docCounts
	 */
	public int getDocCounts() {
		return docCounts;
	}
	/**
	 * @param docCounts the docCounts to set
	 */
	public void setDocCounts(int docCounts) {
		this.docCounts = docCounts;
	}
	/**
	 * @return the recordPartsCounts
	 */
	public int getRecordPartsCounts() {
		return recordPartsCounts;
	}
	/**
	 * @param recordPartsCounts the recordPartsCounts to set
	 */
	public void setRecordPartsCounts(int recordPartsCounts) {
		this.recordPartsCounts = recordPartsCounts;
	}
	/**
	 * @return the recordDocCounts
	 */
	public int getRecordDocCounts() {
		return recordDocCounts;
	}
	/**
	 * @param recordDocCounts the recordDocCounts to set
	 */
	public void setRecordDocCounts(int recordDocCounts) {
		this.recordDocCounts = recordDocCounts;
	}
	/**
	 * @return the cmuSimPrjSrchFlag
	 */
	public boolean isCmuSimPrjSrchFlag() {
		return cmuSimPrjSrchFlag;
	}
	/**
	 * @param cmuSimPrjSrchFlag the cmuSimPrjSrchFlag to set
	 */
	public void setCmuSimPrjSrchFlag(boolean cmuSimPrjSrchFlag) {
		this.cmuSimPrjSrchFlag = cmuSimPrjSrchFlag;
	}
	/**
	 * @return the cmuOnscreentListForPartsTemp
	 */
	public List<PLMCMUSmlrToPrjData> getCmuOnscreentListForPartsTemp() {
		return cmuOnscreentListForPartsTemp;
	}
	/**
	 * @param cmuOnscreentListForPartsTemp the cmuOnscreentListForPartsTemp to set
	 */
	public void setCmuOnscreentListForPartsTemp(
			List<PLMCMUSmlrToPrjData> cmuOnscreentListForPartsTemp) {
		this.cmuOnscreentListForPartsTemp = cmuOnscreentListForPartsTemp;
	}
	/**
	 * @return the cmuOnscreentListForDocTemp
	 */
	public List<PLMCMUSmlrToPrjData> getCmuOnscreentListForDocTemp() {
		return cmuOnscreentListForDocTemp;
	}
	/**
	 * @param cmuOnscreentListForDocTemp the cmuOnscreentListForDocTemp to set
	 */
	public void setCmuOnscreentListForDocTemp(
			List<PLMCMUSmlrToPrjData> cmuOnscreentListForDocTemp) {
		this.cmuOnscreentListForDocTemp = cmuOnscreentListForDocTemp;
	}
	/**
	 * @return the allOpenFrameTypeList
	 */
	public boolean isAllOpenFrameTypeList() {
		return allOpenFrameTypeList;
	}
	/**
	 * @param allOpenFrameTypeList the allOpenFrameTypeList to set
	 */
	public void setAllOpenFrameTypeList(boolean allOpenFrameTypeList) {
		this.allOpenFrameTypeList = allOpenFrameTypeList;
	}
	
	/**
	 * @return the allOpenFrameTypeFreeTxt
	 */
	public boolean isAllOpenFrameTypeFreeTxt() {
		return allOpenFrameTypeFreeTxt;
	}
	/**
	 * @param allOpenFrameTypeFreeTxt the allOpenFrameTypeFreeTxt to set
	 */
	public void setAllOpenFrameTypeFreeTxt(boolean allOpenFrameTypeFreeTxt) {
		this.allOpenFrameTypeFreeTxt = allOpenFrameTypeFreeTxt;
	}
	
	/**
	 * @return the selFrameTypeListName
	 */
	public String getSelFrameTypeListName() {
		return selFrameTypeListName;
	}
	/**
	 * @param selFrameTypeListName the selFrameTypeListName to set
	 */
	public void setSelFrameTypeListName(String selFrameTypeListName) {
		this.selFrameTypeListName = selFrameTypeListName;
	}
	/**
	 * @return the selFuelTypeListName
	 */
	public String getSelFuelTypeListName() {
		return selFuelTypeListName;
	}
	/**
	 * @param selFuelTypeListName the selFuelTypeListName to set
	 */
	public void setSelFuelTypeListName(String selFuelTypeListName) {
		this.selFuelTypeListName = selFuelTypeListName;
	}
	/**
	 * @return the selCombustorTypeListName
	 */
	public String getSelCombustorTypeListName() {
		return selCombustorTypeListName;
	}
	/**
	 * @param selCombustorTypeListName the selCombustorTypeListName to set
	 */
	public void setSelCombustorTypeListName(String selCombustorTypeListName) {
		this.selCombustorTypeListName = selCombustorTypeListName;
	}
	/**
	 * @return the selFrameTypeTextBoxName
	 */
	public String getSelFrameTypeTextBoxName() {
		return selFrameTypeTextBoxName;
	}
	/**
	 * @param selFrameTypeTextBoxName the selFrameTypeTextBoxName to set
	 */
	public void setSelFrameTypeTextBoxName(String selFrameTypeTextBoxName) {
		this.selFrameTypeTextBoxName = selFrameTypeTextBoxName;
	}
	/**
	 * @return the selFuelTypeTextBoxName
	 */
	public String getSelFuelTypeTextBoxName() {
		return selFuelTypeTextBoxName;
	}
	/**
	 * @param selFuelTypeTextBoxName the selFuelTypeTextBoxName to set
	 */
	public void setSelFuelTypeTextBoxName(String selFuelTypeTextBoxName) {
		this.selFuelTypeTextBoxName = selFuelTypeTextBoxName;
	}
	/**
	 * @return the selCombustorTypeTextBoxName
	 */
	public String getSelCombustorTypeTextBoxName() {
		return selCombustorTypeTextBoxName;
	}
	/**
	 * @param selCombustorTypeTextBoxName the selCombustorTypeTextBoxName to set
	 */
	public void setSelCombustorTypeTextBoxName(String selCombustorTypeTextBoxName) {
		this.selCombustorTypeTextBoxName = selCombustorTypeTextBoxName;
	}
	/**
	 * @return the effectivityDateFrom
	 */
	public Date getEffectivityDateFrom() {
		return effectivityDateFrom;
	}
	/**
	 * @param effectivityDateFrom the effectivityDateFrom to set
	 */
	public void setEffectivityDateFrom(Date effectivityDateFrom) {
		this.effectivityDateFrom = effectivityDateFrom;
	}
	/**
	 * @return the effectivityDateTo
	 */
	public Date getEffectivityDateTo() {
		return effectivityDateTo;
	}
	/**
	 * @param effectivityDateTo the effectivityDateTo to set
	 */
	public void setEffectivityDateTo(Date effectivityDateTo) {
		this.effectivityDateTo = effectivityDateTo;
	}
	
	/**
	 * @return the docBomFlg
	 */
	public boolean isDocBomFlg() {
		return docBomFlg;
	}

	/**
	 * @param docBomFlg the docBomFlg to set
	 */
	public void setDocBomFlg(boolean docBomFlg) {
		this.docBomFlg = docBomFlg;
	}

	/**
	 * @return the noDocRecFound
	 */
	public String getNoDocRecFound() {
		return noDocRecFound;
	}

	/**
	 * @param noDocRecFound the noDocRecFound to set
	 */
	public void setNoDocRecFound(String noDocRecFound) {
		this.noDocRecFound = noDocRecFound;
	}

	/**
	 * @return the noPartsRecFound
	 */
	public String getNoPartsRecFound() {
		return noPartsRecFound;
	}

	/**
	 * @param noPartsRecFound the noPartsRecFound to set
	 */
	public void setNoPartsRecFound(String noPartsRecFound) {
		this.noPartsRecFound = noPartsRecFound;
	}

	/**
	 * @return the partsInfoFlag
	 */
	public boolean isPartsInfoFlag() {
		return partsInfoFlag;
	}

	/**
	 * @param partsInfoFlag the partsInfoFlag to set
	 */
	public void setPartsInfoFlag(boolean partsInfoFlag) {
		this.partsInfoFlag = partsInfoFlag;
	}

	/**
	 * @return the docInfoFlag
	 */
	public boolean isDocInfoFlag() {
		return docInfoFlag;
	}

	/**
	 * @param docInfoFlag the docInfoFlag to set
	 */
	public void setDocInfoFlag(boolean docInfoFlag) {
		this.docInfoFlag = docInfoFlag;
	}

	/**
	 * @return the partsBomFlg
	 */
	public boolean isPartsBomFlg() {
		return partsBomFlg;
	}

	/**
	 * @param partsBomFlg the partsBomFlg to set
	 */
	public void setPartsBomFlg(boolean partsBomFlg) {
		this.partsBomFlg = partsBomFlg;
	}

	/**
	 * @return the cmuOnscreentListForParts
	 */
	public List<PLMCMUSmlrToPrjData> getCmuOnscreentListForParts() {
		return cmuOnscreentListForParts;
	}

	/**
	 * @param cmuOnscreentListForParts the cmuOnscreentListForParts to set
	 */
	public void setCmuOnscreentListForParts(
			List<PLMCMUSmlrToPrjData> cmuOnscreentListForParts) {
		this.cmuOnscreentListForParts = cmuOnscreentListForParts;
	}

	/**
	 * @return the cmuOnscreentListForDoc
	 */
	public List<PLMCMUSmlrToPrjData> getCmuOnscreentListForDoc() {
		return cmuOnscreentListForDoc;
	}

	/**
	 * @param cmuOnscreentListForDoc the cmuOnscreentListForDoc to set
	 */
	public void setCmuOnscreentListForDoc(
			List<PLMCMUSmlrToPrjData> cmuOnscreentListForDoc) {
		this.cmuOnscreentListForDoc = cmuOnscreentListForDoc;
	}

	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the cmuSmlrToPrjSrchData
	 */
	public PLMCMUSmlrToPrjData getCmuSmlrToPrjSrchData() {
		return cmuSmlrToPrjSrchData;
	}

	/**
	 * @param cmuSmlrToPrjSrchData the cmuSmlrToPrjSrchData to set
	 */
	public void setCmuSmlrToPrjSrchData(PLMCMUSmlrToPrjData cmuSmlrToPrjSrchData) {
		this.cmuSmlrToPrjSrchData = cmuSmlrToPrjSrchData;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the plmWhereUsedService
	 */
	public PLMWhereUsedServiceIfc getPlmWhereUsedService() {
		return plmWhereUsedService;
	}

	/**
	 * @param plmWhereUsedService the plmWhereUsedService to set
	 */
	public void setPlmWhereUsedService(PLMWhereUsedServiceIfc plmWhereUsedService) {
		this.plmWhereUsedService = plmWhereUsedService;
	}

	/**
	 * @return the frameTypeList
	 */
	public List<SelectItem> getFrameTypeList() {
		return frameTypeList;
	}

	/**
	 * @param frameTypeList the frameTypeList to set
	 */
	public void setFrameTypeList(List<SelectItem> frameTypeList) {
		this.frameTypeList = frameTypeList;
	}

	/**
	 * @return the fuelTypeList
	 */
	public List<SelectItem> getFuelTypeList() {
		return fuelTypeList;
	}

	/**
	 * @param fuelTypeList the fuelTypeList to set
	 */
	public void setFuelTypeList(List<SelectItem> fuelTypeList) {
		this.fuelTypeList = fuelTypeList;
	}

	/**
	 * @return the combustorTypeList
	 */
	public List<SelectItem> getCombustorTypeList() {
		return combustorTypeList;
	}

	/**
	 * @param combustorTypeList the combustorTypeList to set
	 */
	public void setCombustorTypeList(List<SelectItem> combustorTypeList) {
		this.combustorTypeList = combustorTypeList;
	}

	public String loadFrameFuelCombustorList()
	{
		LOG.info("loadFrameFuelCombustorList() Method");
		String fwdFlag = "";
		alertMessage = "";
		partsBomFlg=false;;
		docBomFlg=false;
		partsInfoFlag=true;
		docInfoFlag=true;
		noPartsRecFound=new String();
		noDocRecFound=new String();
		partsCounts=0;
		docCounts=0;
	
		allOpenFrameTypeFreeTxt=false;
		allOpenFrameTypeList=false;
		mliTextBoxName="";
		selCombustorTypeListName="";
		selCombustorTypeTextBoxName="";
		selFrameTypeListName="";
		selFrameTypeTextBoxName="";
		selFuelTypeListName="";
		selFuelTypeTextBoxName="";
		effectivityDateFrom=null;
		effectivityDateTo=null;
		recordDocCounts=PLMConstants.N_100;
		recordPartsCounts =PLMConstants.N_100;
		try {
			 commonMB.insertCannedRptRecordHitInfo("CMU Similar To Project Search");
			 Map<String, List<SelectItem>> dropdownlist = plmWhereUsedService.loadFrameFuelCombustorList();
			 frameTypeList = (List<SelectItem>) dropdownlist.get("frameTypeList");
			 fuelTypeList = (List<SelectItem>) dropdownlist.get("fuelTypeList");
			 combustorTypeList = (List<SelectItem>) dropdownlist.get("combustorTypeList");
			 LOG.info("Frame type Fuel Type Combustor type List size while loading"+""+frameTypeList.size()+""+fuelTypeList.size()+""+combustorTypeList.size());
			 
			fwdFlag = "cmuSmlrToPrjSrchRptHome";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadFrameFuelCombustorList: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","CMU Similar To Project Search");
		} 
		return fwdFlag;
	}
	public String generateCmuSimilarPrjReport(){
		LOG.info("get data from generateCmuSimilarPrjReport() Method");
				String fwdFlag = "";
				partsBomFlg=false;;
				docBomFlg=false;
				partsInfoFlag=true;
				docInfoFlag=true;
				noPartsRecFound=new String();
				noDocRecFound=new String();
				alertMessage = "";
				cmuSimPrjSrchFlag=false;
				partsCounts=0;
				docCounts=0;
			cmuSmlrToPrjSrchData=new PLMCMUSmlrToPrjData();
			allReport=new HashMap<String,List<PLMCMUSmlrToPrjData>>();
			cmuOnscreentListForPartsTemp=new ArrayList<PLMCMUSmlrToPrjData>();
			cmuOnscreentListForDocTemp=new ArrayList<PLMCMUSmlrToPrjData>();
			cmuOnscreentListForParts=new ArrayList<PLMCMUSmlrToPrjData>();
			cmuOnscreentListForDoc=new ArrayList<PLMCMUSmlrToPrjData>();
		try { 
		alertMessage = validateReportInputs();
			 if (PLMConstants.EMPTY.equals(alertMessage)) {
				 //Option A
				if(allOpenFrameTypeList && !PLMUtils.isEmpty(selFrameTypeListName)){
					LOG.info("allOpenFrameTypeList"+allOpenFrameTypeList +selFrameTypeListName);
					cmuSmlrToPrjSrchData.setSelFrameTypeListName(selFrameTypeListName);
				}else{
					LOG.info("allOpenFrameTypeList else"+allOpenFrameTypeList +selFrameTypeListName);
					cmuSmlrToPrjSrchData.setSelFrameTypeListName("");
				}
				
				if(!PLMUtils.isEmpty(selFuelTypeListName)){
					cmuSmlrToPrjSrchData.setSelFuelTypeListName(selFuelTypeListName);
				}else{
					cmuSmlrToPrjSrchData.setSelFuelTypeListName("");
				}
				if(!PLMUtils.isEmpty(selCombustorTypeListName)){
					cmuSmlrToPrjSrchData.setSelCombustorTypeListName(selCombustorTypeListName);
				}else{
					cmuSmlrToPrjSrchData.setSelCombustorTypeListName("");
				}
				//Option B
				if(allOpenFrameTypeFreeTxt  && !PLMUtils.isEmpty(selFrameTypeTextBoxName)){
					cmuSmlrToPrjSrchData.setSelFrameTypeTextBoxName(selFrameTypeTextBoxName);
				}else{
					cmuSmlrToPrjSrchData.setSelFrameTypeTextBoxName("");
				}
				if(!PLMUtils.isEmpty(selFuelTypeTextBoxName)){
					cmuSmlrToPrjSrchData.setSelFuelTypeTextBoxName(selFuelTypeTextBoxName);
				}else{
					cmuSmlrToPrjSrchData.setSelFuelTypeTextBoxName("");
				}
				
				if(!PLMUtils.isEmpty(mliTextBoxName)){
					cmuSmlrToPrjSrchData.setMliTextBoxName(mliTextBoxName);
				}else{
					cmuSmlrToPrjSrchData.setMliTextBoxName("");
				}
				if(!PLMUtils.isEmpty(selCombustorTypeTextBoxName)){
					cmuSmlrToPrjSrchData.setSelCombustorTypeTextBoxName(selCombustorTypeTextBoxName);
				}else{
					cmuSmlrToPrjSrchData.setSelCombustorTypeTextBoxName("");
				}
				if(!PLMUtils.isEmptyDate(effectivityDateFrom)){
					cmuSmlrToPrjSrchData.setEffectivityDateFrom(effectivityDateFrom);
				}
				if(!PLMUtils.isEmptyDate(effectivityDateTo)){
					cmuSmlrToPrjSrchData.setEffectivityDateTo(effectivityDateTo);
				}
				 allReport = plmWhereUsedService.generateCmuSimilarPrjReport(cmuSmlrToPrjSrchData.getSelFrameTypeListName(),cmuSmlrToPrjSrchData.getSelFrameTypeTextBoxName(),
						 cmuSmlrToPrjSrchData.getSelFuelTypeListName(),cmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName(),
						 cmuSmlrToPrjSrchData.getSelCombustorTypeListName(),cmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName(),cmuSmlrToPrjSrchData.getMliTextBoxName(),
						 cmuSmlrToPrjSrchData.getEffectivityDateFrom(),cmuSmlrToPrjSrchData.getEffectivityDateTo());
				
				 cmuOnscreentListForPartsTemp=allReport.get("partsBomList");
				 cmuOnscreentListForDocTemp=allReport.get("specDocList");
				 if(cmuOnscreentListForPartsTemp.size()>0){
					 recordPartsCounts =PLMConstants.N_100;
					 partsBomFlg=true;
				 }
				 else{
					 partsBomFlg=false;
				 }
				 if(cmuOnscreentListForDocTemp.size()>0){
					 recordDocCounts =PLMConstants.N_100;
					 docBomFlg=true;
				 }
				 else{
					 docBomFlg=false;
				 }
				 if(!PLMUtils.isEmptyList(cmuOnscreentListForPartsTemp)){
					 int partRecordLast=0;
					 PLMCMUSmlrToPrjData sample = new PLMCMUSmlrToPrjData();
					/* for(CMUSmlrToPrjSrchData tempParts:cmuOnscreentListForPartsTemp){
						 CMUSmlrToPrjSrchData sample = new CMUSmlrToPrjSrchData();
						 sample.setFdm(tempParts.getFdm());
						 sample.setMli(tempParts.getMli());
						 sample.setPartNumber(tempParts.getPartNumber());
						 sample.setDescription(tempParts.getDescription());
						 if(tempParts.getFcodeOne().equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelFuelTypeListName())){
							 sample.setFcodeOne(tempParts.getFcodeOne());
						 }else if(tempParts.getFcodeOne().equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelCombustorTypeListName())){
							 sample.setFcodeTwo(tempParts.getFcodeOne());
						 }else if(tempParts.getFcodeOne().equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName())){
							 sample.setFcodeThree(tempParts.getFcodeOne());
						 }else if(tempParts.getFcodeOne().equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName())){
							 sample.setFcodeFour(tempParts.getFcodeOne());
						 }
						 cmuOnscreentListForParts.add(sample); 
					 }*/
					 for(int i=0;i<cmuOnscreentListForPartsTemp.size();i++){
						 
						 if(i==0){
						 sample.setFdmId(cmuOnscreentListForPartsTemp.get(i).getFdmId());
						 sample.setFdm(cmuOnscreentListForPartsTemp.get(i).getFdm());
						 sample.setMli(cmuOnscreentListForPartsTemp.get(i).getMli());
						 sample.setFrameType(cmuOnscreentListForPartsTemp.get(i).getFrameType());
						 sample.setPartNumber(cmuOnscreentListForPartsTemp.get(i).getPartNumber());
						 sample.setPartNumberId(cmuOnscreentListForPartsTemp.get(i).getPartNumberId());
						 sample.setDescription(cmuOnscreentListForPartsTemp.get(i).getDescription());
						 if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTemp.get(i).getFcodeOne()).equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelFuelTypeListName())){
							 sample.setFcodeOne(cmuOnscreentListForPartsTemp.get(i).getFcodeOne());
						 }if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTemp.get(i).getFcodeOne()).equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelCombustorTypeListName())){
							 sample.setFcodeTwo(cmuOnscreentListForPartsTemp.get(i).getFcodeOne());
						 }if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTemp.get(i).getFcodeOne()).equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName())){
							 sample.setFcodeThree(cmuOnscreentListForPartsTemp.get(i).getFcodeOne());
						 }if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTemp.get(i).getFcodeOne()).equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName())){
							 sample.setFcodeFour(cmuOnscreentListForPartsTemp.get(i).getFcodeOne());
						 }
						 cmuOnscreentListForParts.add(sample);
						 partRecordLast=cmuOnscreentListForParts.size()-1;
						 }
						 else{
								 if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTemp.get(i).getFdm()).equalsIgnoreCase(cmuOnscreentListForPartsTemp.get(i-1).getFdm())
										 && PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTemp.get(i).getFrameType()).equalsIgnoreCase(cmuOnscreentListForPartsTemp.get(i-1).getFrameType())
										 && PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTemp.get(i).getMli()).equalsIgnoreCase(cmuOnscreentListForPartsTemp.get(i-1).getMli())
										 && PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTemp.get(i).getPartNumber()).equalsIgnoreCase(cmuOnscreentListForPartsTemp.get(i-1).getPartNumber())
										 && PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTemp.get(i).getDescription()).equalsIgnoreCase(cmuOnscreentListForPartsTemp.get(i-1).getDescription())){
									 if(PLMUtils.isEmptyRtnStr(cmuSmlrToPrjSrchData.getSelFuelTypeListName()).equalsIgnoreCase(cmuOnscreentListForPartsTemp.get(i).getFcodeOne())){
										 cmuOnscreentListForParts.get(partRecordLast).setFcodeOne(cmuOnscreentListForPartsTemp.get(i).getFcodeOne());
									 }if(PLMUtils.isEmptyRtnStr(cmuSmlrToPrjSrchData.getSelCombustorTypeListName()).equalsIgnoreCase(cmuOnscreentListForPartsTemp.get(i).getFcodeOne())){
										 cmuOnscreentListForParts.get(partRecordLast).setFcodeTwo(cmuOnscreentListForPartsTemp.get(i).getFcodeOne());
									 }if(PLMUtils.isEmptyRtnStr(cmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName()).equalsIgnoreCase(cmuOnscreentListForPartsTemp.get(i).getFcodeOne())){
										 cmuOnscreentListForParts.get(partRecordLast).setFcodeThree(cmuOnscreentListForPartsTemp.get(i).getFcodeOne());
									 }if(PLMUtils.isEmptyRtnStr(cmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName()).equalsIgnoreCase(cmuOnscreentListForPartsTemp.get(i).getFcodeOne())){
										 cmuOnscreentListForParts.get(partRecordLast).setFcodeFour(cmuOnscreentListForPartsTemp.get(i).getFcodeOne());
									 }
								 }else{
									 sample = new PLMCMUSmlrToPrjData();
									 sample.setFdmId(cmuOnscreentListForPartsTemp.get(i).getFdmId());
									 sample.setFrameType(cmuOnscreentListForPartsTemp.get(i).getFrameType());
									 sample.setFdm(cmuOnscreentListForPartsTemp.get(i).getFdm());
									 sample.setMli(cmuOnscreentListForPartsTemp.get(i).getMli());
									 sample.setPartNumber(cmuOnscreentListForPartsTemp.get(i).getPartNumber());
									 sample.setPartNumberId(cmuOnscreentListForPartsTemp.get(i).getPartNumberId());
									 sample.setDescription(cmuOnscreentListForPartsTemp.get(i).getDescription());
									 if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTemp.get(i).getFcodeOne()).equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelFuelTypeListName())){
										 sample.setFcodeOne(cmuOnscreentListForPartsTemp.get(i).getFcodeOne());
									 }if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTemp.get(i).getFcodeOne()).equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelCombustorTypeListName())){
										 sample.setFcodeTwo(cmuOnscreentListForPartsTemp.get(i).getFcodeOne());
									 }if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTemp.get(i).getFcodeOne()).equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName())){
										 sample.setFcodeThree(cmuOnscreentListForPartsTemp.get(i).getFcodeOne());
									 }if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTemp.get(i).getFcodeOne()).equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName())){
										 sample.setFcodeFour(cmuOnscreentListForPartsTemp.get(i).getFcodeOne());
									 }
									 cmuOnscreentListForParts.add(sample);
									 partRecordLast=cmuOnscreentListForParts.size()-1;
								 }
							 
						 }
						  
					 }
					 partsCounts=cmuOnscreentListForParts.size();
				 }
				 if(!PLMUtils.isEmptyList(cmuOnscreentListForDocTemp)){
					 int docRecLast=0;
					/* for(CMUSmlrToPrjSrchData tempParts:cmuOnscreentListForDocTemp){
						 CMUSmlrToPrjSrchData sample = new CMUSmlrToPrjSrchData();
						 sample.setFdm(tempParts.getFdm());
						 sample.setMli(tempParts.getMli());
						 sample.setDocNumber(tempParts.getDocNumber());
						 sample.setDescription(tempParts.getDescription());
						 if(tempParts.getFcodeOne().equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelFuelTypeListName())){
							 sample.setFcodeOne(tempParts.getFcodeOne());
						 }else if(tempParts.getFcodeOne().equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelCombustorTypeListName())){
							 sample.setFcodeTwo(tempParts.getFcodeOne());
						 }else if(tempParts.getFcodeOne().equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName())){
							 sample.setFcodeThree(tempParts.getFcodeOne());
						 }else if(tempParts.getFcodeOne().equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName())){
							 sample.setFcodeFour(tempParts.getFcodeOne());
						 }
						 cmuOnscreentListForDoc.add(sample); 
					 }*/
					 PLMCMUSmlrToPrjData sample = new PLMCMUSmlrToPrjData();
					 for(int i=0;i<cmuOnscreentListForDocTemp.size();i++){
						 if(i==0){
							 sample.setFdmId(cmuOnscreentListForDocTemp.get(i).getFdmId());
							 sample.setFrameType(cmuOnscreentListForDocTemp.get(i).getFrameType());
							 sample.setFdm(cmuOnscreentListForDocTemp.get(i).getFdm());
							 sample.setMli(cmuOnscreentListForDocTemp.get(i).getMli());
							 sample.setDocNumber(cmuOnscreentListForDocTemp.get(i).getDocNumber());
							 sample.setDocNumberId(cmuOnscreentListForDocTemp.get(i).getDocNumberId());
							 sample.setDescription(cmuOnscreentListForDocTemp.get(i).getDescription());
							 if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTemp.get(i).getFcodeOne()).equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelFuelTypeListName())){
								 sample.setFcodeOne(cmuOnscreentListForDocTemp.get(i).getFcodeOne());
							 }if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTemp.get(i).getFcodeOne()).equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelCombustorTypeListName())){
								 sample.setFcodeTwo(cmuOnscreentListForDocTemp.get(i).getFcodeOne());
							 }if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTemp.get(i).getFcodeOne()).equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName())){
								 sample.setFcodeThree(cmuOnscreentListForDocTemp.get(i).getFcodeOne());
							 }if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTemp.get(i).getFcodeOne()).equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName())){
								 sample.setFcodeFour(cmuOnscreentListForDocTemp.get(i).getFcodeOne());
							 }
							 cmuOnscreentListForDoc.add(sample);
							 docRecLast=cmuOnscreentListForDoc.size()-1;
						 } else {
								 if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTemp.get(i).getFdm()).equalsIgnoreCase(cmuOnscreentListForDocTemp.get(i-1).getFdm())
										 && PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTemp.get(i).getFrameType()).equalsIgnoreCase(cmuOnscreentListForDocTemp.get(i-1).getFrameType())
										 && PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTemp.get(i).getMli()).equalsIgnoreCase(cmuOnscreentListForDocTemp.get(i-1).getMli())
										 && PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTemp.get(i).getDocNumber()).equalsIgnoreCase(cmuOnscreentListForDocTemp.get(i-1).getDocNumber())
										 && PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTemp.get(i).getDescription()).equalsIgnoreCase(cmuOnscreentListForDocTemp.get(i-1).getDescription())){
									 if(PLMUtils.isEmptyRtnStr(cmuSmlrToPrjSrchData.getSelFuelTypeListName()).equalsIgnoreCase(cmuOnscreentListForDocTemp.get(i).getFcodeOne())){
										 cmuOnscreentListForDoc.get(docRecLast).setFcodeOne(cmuOnscreentListForDocTemp.get(i).getFcodeOne());
									 }if(PLMUtils.isEmptyRtnStr(cmuSmlrToPrjSrchData.getSelCombustorTypeListName()).equalsIgnoreCase(cmuOnscreentListForDocTemp.get(i).getFcodeOne())){
										 cmuOnscreentListForDoc.get(docRecLast).setFcodeTwo(cmuOnscreentListForDocTemp.get(i).getFcodeOne());
									 }if(PLMUtils.isEmptyRtnStr(cmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName()).equalsIgnoreCase(cmuOnscreentListForDocTemp.get(i).getFcodeOne())){
										 cmuOnscreentListForDoc.get(docRecLast).setFcodeThree(cmuOnscreentListForDocTemp.get(i).getFcodeOne());
									 }if(PLMUtils.isEmptyRtnStr(cmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName()).equalsIgnoreCase(cmuOnscreentListForDocTemp.get(i).getFcodeOne())){
										 cmuOnscreentListForDoc.get(docRecLast).setFcodeFour(cmuOnscreentListForDocTemp.get(i).getFcodeOne());
									 }
								 }else{
									 
									 sample = new PLMCMUSmlrToPrjData();
									 sample.setFdmId(cmuOnscreentListForDocTemp.get(i).getFdmId());
									 sample.setFdm(cmuOnscreentListForDocTemp.get(i).getFdm());
									 sample.setFrameType(cmuOnscreentListForDocTemp.get(i).getFrameType());
									 sample.setMli(cmuOnscreentListForDocTemp.get(i).getMli());
									 sample.setDocNumber(cmuOnscreentListForDocTemp.get(i).getDocNumber());
									 sample.setDocNumberId(cmuOnscreentListForDocTemp.get(i).getDocNumberId());
									 sample.setDescription(cmuOnscreentListForDocTemp.get(i).getDescription());
									 if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTemp.get(i).getFcodeOne()).equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelFuelTypeListName())){
										 sample.setFcodeOne(cmuOnscreentListForDocTemp.get(i).getFcodeOne());
									 }if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTemp.get(i).getFcodeOne()).equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelCombustorTypeListName())){
										 sample.setFcodeTwo(cmuOnscreentListForDocTemp.get(i).getFcodeOne());
									 }if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTemp.get(i).getFcodeOne()).equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName())){
										 sample.setFcodeThree(cmuOnscreentListForDocTemp.get(i).getFcodeOne());
									 }if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTemp.get(i).getFcodeOne()).equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName())){
										 sample.setFcodeFour(cmuOnscreentListForDocTemp.get(i).getFcodeOne());
									 }
									 
									 cmuOnscreentListForDoc.add(sample);
									 docRecLast=cmuOnscreentListForDoc.size()-1;
									 
								 }
						 }
						  
					 }
					 docCounts=cmuOnscreentListForDoc.size();
				 }
				 totalRecordPartsAptMsg="Total record For Parts(BOM) Data is : "+cmuOnscreentListForParts.size();
				 totalRecordDocAptMsg="Total record For Specification and Document Data is : "+cmuOnscreentListForDoc.size();
				 if(cmuOnscreentListForParts.size()>0 || cmuOnscreentListForDoc.size()>0){
	     		  fwdFlag = "cmuSmlrToPrjSrchRptHomeDetails";
				 }
				 else{
					 alertMessage = "No Records Found for the Selected combination";
					 fwdFlag = "cmuSmlrToPrjSrchRptHome";
				 }
			 }
			 else{
				 fwdFlag = "cmuSmlrToPrjSrchRptHome";
			 }
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@generateCmuSimilarPrjReport: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","CMU Similar To Project Search");
		} 
		
		return fwdFlag;
	}
	/*public void getpartsBom() throws PLMCommonException {
		allReport = plmWhereUsedService.generateCmuSimilarPrjReport(cmuSmlrToPrjSrchData.getSelFrameTypeListName(),cmuSmlrToPrjSrchData.getSelFrameTypeTextBoxName(),
				 cmuSmlrToPrjSrchData.getSelFuelTypeListName(),cmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName(),
				 cmuSmlrToPrjSrchData.getSelCombustorTypeListName(),cmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName(),
				 cmuSmlrToPrjSrchData.getEffectivityDateFrom(),cmuSmlrToPrjSrchData.getEffectivityDateTo());
		
		cmuOnscreentListForPartsTemp=allReport.get("partsBomList");
		 if(PLMUtils.isEmptyList(cmuOnscreentListForPartsTemp)){
			 partsBomFlg=true;
		 }
		 else{
			 noPartsRecFound="No Parts(BOM) record found for selected input combination";
			 partsBomFlg=false;
		 }
		
	}
	public void getDocBom() throws PLMCommonException {
		allReport = plmWhereUsedService.generateCmuSimilarPrjReport(cmuSmlrToPrjSrchData.getSelFrameTypeListName(),cmuSmlrToPrjSrchData.getSelFrameTypeTextBoxName(),
				 cmuSmlrToPrjSrchData.getSelFuelTypeListName(),cmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName(),
				 cmuSmlrToPrjSrchData.getSelCombustorTypeListName(),cmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName(),
				 cmuSmlrToPrjSrchData.getEffectivityDateFrom(),cmuSmlrToPrjSrchData.getEffectivityDateTo());
		
		cmuOnscreentListForDocTemp=allReport.get("specDocList");
		 if(PLMUtils.isEmptyList(cmuOnscreentListForDocTemp)){
			 docBomFlg=true;
		 }
		 else{
			 noDocRecFound="No Specification and Document record found for selected input combination";
			 docBomFlg=false;
		 }
	}*/
	/**
	 * Generates generateWhereUsedEMBOMMail
	 * 
	 * @return String
	 * @throws PWiException 
	 * @throws PLMCommonException
	 */
	public String generateCmuSimilarPrjEmailReport() throws PWiException{
		String fwdFlag = "cmuSmlrToPrjSrchRptHome";
		cmuSimPrjSrchFlag = true;
		try {
			String alertMsg = validateReportInputs();
			
			// Get user details for sending mail. Need before taskexecuter as context will be null while excuting the thread
			 userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
			
			if (PLMUtils.isEmpty(alertMsg)) {
				alertMessage = alertMessage + PLMConstants.WHERE_USED_CMU_MAIL_MSG;
				taskExecutor.execute(new MailThread());
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@generateCmuSimilarPrjEmailReport: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"cmuSmlrToPrjSrchRptHome","CMU Similar To Project Search");
		} 
		return fwdFlag;
	}
	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendReportThroughMail();
		}
	}
	/**
	 * This method is used for sendReportThroughMail
	 * 
	 */
	public void sendReportThroughMail() {

		String successMsg = "";
		String from = PLMConstants.WHERE_USED_MAIL_FROM;
		PLMCMUSmlrToPrjData setcmuSmlrToPrjSrchData=new PLMCMUSmlrToPrjData();
		Map<String,List<PLMCMUSmlrToPrjData>> allReportLcl=new HashMap<String,List<PLMCMUSmlrToPrjData>>();
		List<PLMCMUSmlrToPrjData> cmuOnscreentListForPartsTmpLcl=new ArrayList<PLMCMUSmlrToPrjData>();
		List<PLMCMUSmlrToPrjData> cmuOnscreentListForDocTmpLcl=new ArrayList<PLMCMUSmlrToPrjData>();
		List<PLMCMUSmlrToPrjData> cmuOnscreentListForPartsLcl=new ArrayList<PLMCMUSmlrToPrjData>();
		List<PLMCMUSmlrToPrjData> cmuOnscreentListForDocLcl=new ArrayList<PLMCMUSmlrToPrjData>();
		String to = userDetails.getUserEmailId();	
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String signature = PLMConstants.WHERE_USED_LOU_MAIL_SIGNATURE;
		String errorSubject = PLMConstants.WHERE_USED_CMU_MAIL_SUBJECT;
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("WHERUSED_CMU_REPORT_NAME")+ "_" + uniqTime +".xlsx";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("WHERUSED_CMU_REPORT_NAME") +  "_" + uniqTime + ".zip";
		try {
			if(allOpenFrameTypeList && !PLMUtils.isEmpty(selFrameTypeListName)){
				LOG.info("allOpenFrameTypeList"+allOpenFrameTypeList +selFrameTypeListName);
				setcmuSmlrToPrjSrchData.setSelFrameTypeListName(selFrameTypeListName);
			}else{
				LOG.info("allOpenFrameTypeList else"+allOpenFrameTypeList +selFrameTypeListName);
				setcmuSmlrToPrjSrchData.setSelFrameTypeListName("");
			}
			
			if(!PLMUtils.isEmpty(selFuelTypeListName)){
				setcmuSmlrToPrjSrchData.setSelFuelTypeListName(selFuelTypeListName);
			}else{
				setcmuSmlrToPrjSrchData.setSelFuelTypeListName("");
			}
			if(!PLMUtils.isEmpty(selCombustorTypeListName)){
				setcmuSmlrToPrjSrchData.setSelCombustorTypeListName(selCombustorTypeListName);
			}else{
				setcmuSmlrToPrjSrchData.setSelCombustorTypeListName("");
			}
			//Option B
			if(allOpenFrameTypeFreeTxt  && !PLMUtils.isEmpty(selFrameTypeTextBoxName)){
				setcmuSmlrToPrjSrchData.setSelFrameTypeTextBoxName(selFrameTypeTextBoxName);
			}else{
				setcmuSmlrToPrjSrchData.setSelFrameTypeTextBoxName("");
			}
			if(!PLMUtils.isEmpty(mliTextBoxName)){
				setcmuSmlrToPrjSrchData.setMliTextBoxName(mliTextBoxName);
			}else{
				setcmuSmlrToPrjSrchData.setMliTextBoxName("");
			}
			if(!PLMUtils.isEmpty(selFuelTypeTextBoxName)){
				setcmuSmlrToPrjSrchData.setSelFuelTypeTextBoxName(selFuelTypeTextBoxName);
			}else{
				setcmuSmlrToPrjSrchData.setSelFuelTypeTextBoxName("");
			}
			if(!PLMUtils.isEmpty(selCombustorTypeTextBoxName)){
				setcmuSmlrToPrjSrchData.setSelCombustorTypeTextBoxName(selCombustorTypeTextBoxName);
			}else{
				setcmuSmlrToPrjSrchData.setSelCombustorTypeTextBoxName("");
			}
			if(!PLMUtils.isEmptyDate(effectivityDateFrom)){
				setcmuSmlrToPrjSrchData.setEffectivityDateFrom(effectivityDateFrom);
			}
			if(!PLMUtils.isEmptyDate(effectivityDateTo)){
				setcmuSmlrToPrjSrchData.setEffectivityDateTo(effectivityDateTo);
			}
			 allReportLcl = plmWhereUsedService.generateCmuSimilarPrjReport(setcmuSmlrToPrjSrchData.getSelFrameTypeListName(),setcmuSmlrToPrjSrchData.getSelFrameTypeTextBoxName(),
					 setcmuSmlrToPrjSrchData.getSelFuelTypeListName(),setcmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName(),
					 setcmuSmlrToPrjSrchData.getSelCombustorTypeListName(),setcmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName(),setcmuSmlrToPrjSrchData.getMliTextBoxName(),
					 setcmuSmlrToPrjSrchData.getEffectivityDateFrom(),setcmuSmlrToPrjSrchData.getEffectivityDateTo());
			
			 cmuOnscreentListForPartsTmpLcl=allReportLcl.get("partsBomList");
			 cmuOnscreentListForDocTmpLcl=allReportLcl.get("specDocList");
			
			 if(!PLMUtils.isEmptyList(cmuOnscreentListForPartsTmpLcl)){
				 int partrecLast=0;
				/* for(CMUSmlrToPrjSrchData tempParts:cmuOnscreentListForPartsTemp){
					 CMUSmlrToPrjSrchData sample = new CMUSmlrToPrjSrchData();
					 sample.setFdm(tempParts.getFdm());
					 sample.setMli(tempParts.getMli());
					 sample.setPartNumber(tempParts.getPartNumber());
					 sample.setDescription(tempParts.getDescription());
					 if(tempParts.getFcodeOne().equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelFuelTypeListName())){
						 sample.setFcodeOne(tempParts.getFcodeOne());
					 }else if(tempParts.getFcodeOne().equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelCombustorTypeListName())){
						 sample.setFcodeTwo(tempParts.getFcodeOne());
					 }else if(tempParts.getFcodeOne().equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName())){
						 sample.setFcodeThree(tempParts.getFcodeOne());
					 }else if(tempParts.getFcodeOne().equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName())){
						 sample.setFcodeFour(tempParts.getFcodeOne());
					 }
					 cmuOnscreentListForParts.add(sample); 
				 }*/
				 for(int i=0;i<cmuOnscreentListForPartsTmpLcl.size();i++){
					 PLMCMUSmlrToPrjData sample = new PLMCMUSmlrToPrjData();
					 if(i==0){
					 sample.setFdmId(cmuOnscreentListForPartsTmpLcl.get(i).getFdmId());
					 sample.setFdm(cmuOnscreentListForPartsTmpLcl.get(i).getFdm());
					 sample.setFrameType(cmuOnscreentListForPartsTmpLcl.get(i).getFrameType());
					 sample.setMli(cmuOnscreentListForPartsTmpLcl.get(i).getMli());
					 sample.setPartNumber(cmuOnscreentListForPartsTmpLcl.get(i).getPartNumber());
					 sample.setPartNumberId(cmuOnscreentListForPartsTmpLcl.get(i).getPartNumberId());
					 sample.setDescription(cmuOnscreentListForPartsTmpLcl.get(i).getDescription());
					 if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne()).equalsIgnoreCase(setcmuSmlrToPrjSrchData.getSelFuelTypeListName())){
						 sample.setFcodeOne(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne());
					 }else if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne()).equalsIgnoreCase(setcmuSmlrToPrjSrchData.getSelCombustorTypeListName())){
						 sample.setFcodeTwo(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne());
					 }else if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne()).equalsIgnoreCase(setcmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName())){
						 sample.setFcodeThree(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne());
					 }else if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne()).equalsIgnoreCase(setcmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName())){
						 sample.setFcodeFour(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne());
					 }
					 cmuOnscreentListForPartsLcl.add(sample);
					 partrecLast=cmuOnscreentListForPartsLcl.size()-1;
					 }
					 else{
							 if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTmpLcl.get(i).getFdm()).equalsIgnoreCase(cmuOnscreentListForPartsTmpLcl.get(i-1).getFdm())
									 && PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTmpLcl.get(i).getMli()).equalsIgnoreCase(cmuOnscreentListForPartsTmpLcl.get(i-1).getMli())
									 && PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTmpLcl.get(i).getPartNumber()).equalsIgnoreCase(cmuOnscreentListForPartsTmpLcl.get(i-1).getPartNumber())
									 && PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTmpLcl.get(i).getDescription()).equalsIgnoreCase(cmuOnscreentListForPartsTmpLcl.get(i-1).getDescription())){
								 if(PLMUtils.isEmptyRtnStr(setcmuSmlrToPrjSrchData.getSelFuelTypeListName()).equalsIgnoreCase(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne())){
									 cmuOnscreentListForPartsLcl.get(partrecLast).setFcodeOne(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne());
								 }if(PLMUtils.isEmptyRtnStr(setcmuSmlrToPrjSrchData.getSelCombustorTypeListName()).equalsIgnoreCase(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne())){
									 cmuOnscreentListForPartsLcl.get(partrecLast).setFcodeTwo(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne());
								 }if(PLMUtils.isEmptyRtnStr(setcmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName()).equalsIgnoreCase(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne())){
									 cmuOnscreentListForPartsLcl.get(partrecLast).setFcodeThree(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne());
								 }if(PLMUtils.isEmptyRtnStr(setcmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName()).equalsIgnoreCase(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne())){
									 cmuOnscreentListForPartsLcl.get(partrecLast).setFcodeFour(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne());
								 }
							 }else{
								 sample.setFdmId(cmuOnscreentListForPartsTmpLcl.get(i).getFdmId());
								 sample.setFdm(cmuOnscreentListForPartsTmpLcl.get(i).getFdm());
								 sample.setFrameType(cmuOnscreentListForPartsTmpLcl.get(i).getFrameType());
								 sample.setMli(cmuOnscreentListForPartsTmpLcl.get(i).getMli());
								 sample.setPartNumber(cmuOnscreentListForPartsTmpLcl.get(i).getPartNumber());
								 sample.setPartNumberId(cmuOnscreentListForPartsTmpLcl.get(i).getPartNumberId());
								 sample.setDescription(cmuOnscreentListForPartsTmpLcl.get(i).getDescription());
								 if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne()).equalsIgnoreCase(setcmuSmlrToPrjSrchData.getSelFuelTypeListName())){
									 sample.setFcodeOne(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne());
								 }else if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne()).equalsIgnoreCase(setcmuSmlrToPrjSrchData.getSelCombustorTypeListName())){
									 sample.setFcodeTwo(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne());
								 }else if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne()).equalsIgnoreCase(setcmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName())){
									 sample.setFcodeThree(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne());
								 }else if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne()).equalsIgnoreCase(setcmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName())){
									 sample.setFcodeFour(cmuOnscreentListForPartsTmpLcl.get(i).getFcodeOne());
								 }
								 cmuOnscreentListForPartsLcl.add(sample);
								 partrecLast=cmuOnscreentListForPartsLcl.size()-1;
							 }
						 
					 }
					  
				 }
			 }
			 if(!PLMUtils.isEmptyList(cmuOnscreentListForDocTmpLcl)){
				 int docRecLast=0;
				 /*for(CMUSmlrToPrjSrchData tempParts:cmuOnscreentListForDocTemp){
					 CMUSmlrToPrjSrchData sample = new CMUSmlrToPrjSrchData();
					 sample.setFdm(tempParts.getFdm());
					 sample.setMli(tempParts.getMli());
					 sample.setDocNumber(tempParts.getDocNumber());
					 sample.setDescription(tempParts.getDescription());
					 if(tempParts.getFcodeOne().equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelFuelTypeListName())){
						 sample.setFcodeOne(tempParts.getFcodeOne());
					 }else if(tempParts.getFcodeOne().equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelCombustorTypeListName())){
						 sample.setFcodeTwo(tempParts.getFcodeOne());
					 }else if(tempParts.getFcodeOne().equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName())){
						 sample.setFcodeThree(tempParts.getFcodeOne());
					 }else if(tempParts.getFcodeOne().equalsIgnoreCase(cmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName())){
						 sample.setFcodeFour(tempParts.getFcodeOne());
					 }
					 cmuOnscreentListForDoc.add(sample); 
				 }*/
				 for(int i=0;i<cmuOnscreentListForDocTmpLcl.size();i++){
					 PLMCMUSmlrToPrjData sample = new PLMCMUSmlrToPrjData();
					 if(i==0){
					 sample.setFdmId(cmuOnscreentListForDocTmpLcl.get(i).getFdmId());
					 sample.setFdm(cmuOnscreentListForDocTmpLcl.get(i).getFdm());
					 sample.setFrameType(cmuOnscreentListForDocTmpLcl.get(i).getFrameType());
					 sample.setMli(cmuOnscreentListForDocTmpLcl.get(i).getMli());
					 sample.setDocNumber(cmuOnscreentListForDocTmpLcl.get(i).getDocNumber());
					 sample.setDocNumberId(cmuOnscreentListForDocTmpLcl.get(i).getDocNumberId());
					 sample.setDescription(cmuOnscreentListForDocTmpLcl.get(i).getDescription());
					 if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne()).equalsIgnoreCase(setcmuSmlrToPrjSrchData.getSelFuelTypeListName())){
						 sample.setFcodeOne(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne());
					 }else if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne()).equalsIgnoreCase(setcmuSmlrToPrjSrchData.getSelCombustorTypeListName())){
						 sample.setFcodeTwo(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne());
					 }else if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne()).equalsIgnoreCase(setcmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName())){
						 sample.setFcodeThree(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne());
					 }else if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne()).equalsIgnoreCase(setcmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName())){
						 sample.setFcodeFour(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne());
					 }
					 cmuOnscreentListForDocLcl.add(sample);
					 docRecLast=cmuOnscreentListForDocLcl.size()-1;
					 }
					 else{
							 if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTmpLcl.get(i).getFdm()).equalsIgnoreCase(cmuOnscreentListForDocTmpLcl.get(i-1).getFdm())
									 && PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTmpLcl.get(i).getMli()).equalsIgnoreCase(cmuOnscreentListForDocTmpLcl.get(i-1).getMli())
									 && PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTmpLcl.get(i).getDocNumber()).equalsIgnoreCase(cmuOnscreentListForDocTmpLcl.get(i-1).getDocNumber())
									 && PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTmpLcl.get(i).getDescription()).equalsIgnoreCase(cmuOnscreentListForDocTmpLcl.get(i-1).getDescription())){
								 if(PLMUtils.isEmptyRtnStr(setcmuSmlrToPrjSrchData.getSelFuelTypeListName()).equalsIgnoreCase(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne())){
									 cmuOnscreentListForDocTmpLcl.get(docRecLast).setFcodeOne(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne());
								 }if(PLMUtils.isEmptyRtnStr(setcmuSmlrToPrjSrchData.getSelCombustorTypeListName()).equalsIgnoreCase(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne())){
									 cmuOnscreentListForDocTmpLcl.get(docRecLast).setFcodeTwo(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne());
								 }if(PLMUtils.isEmptyRtnStr(setcmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName()).equalsIgnoreCase(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne())){
									 cmuOnscreentListForDocTmpLcl.get(docRecLast).setFcodeThree(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne());
								 }if(PLMUtils.isEmptyRtnStr(setcmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName()).equalsIgnoreCase(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne())){
									 cmuOnscreentListForDocTmpLcl.get(docRecLast).setFcodeFour(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne());
								 }
							 }else{
								 sample.setFdmId(cmuOnscreentListForDocTmpLcl.get(i).getFdmId());
								 sample.setFrameType(cmuOnscreentListForDocTmpLcl.get(i).getFrameType());
								 sample.setFdm(cmuOnscreentListForDocTmpLcl.get(i).getFdm());
								 sample.setMli(cmuOnscreentListForDocTmpLcl.get(i).getMli());
								 sample.setDocNumber(cmuOnscreentListForDocTmpLcl.get(i).getDocNumber());
								 sample.setDocNumberId(cmuOnscreentListForDocTmpLcl.get(i).getDocNumberId());
								 sample.setDescription(cmuOnscreentListForDocTmpLcl.get(i).getDescription());
								 if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne()).equalsIgnoreCase(setcmuSmlrToPrjSrchData.getSelFuelTypeListName())){
									 sample.setFcodeOne(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne());
								 }else if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne()).equalsIgnoreCase(setcmuSmlrToPrjSrchData.getSelCombustorTypeListName())){
									 sample.setFcodeTwo(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne());
								 }else if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne()).equalsIgnoreCase(setcmuSmlrToPrjSrchData.getSelFuelTypeTextBoxName())){
									 sample.setFcodeThree(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne());
								 }else if(PLMUtils.isEmptyRtnStr(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne()).equalsIgnoreCase(setcmuSmlrToPrjSrchData.getSelCombustorTypeTextBoxName())){
									 sample.setFcodeFour(cmuOnscreentListForDocTmpLcl.get(i).getFcodeOne());
								 }
								 cmuOnscreentListForDocLcl.add(sample);
								 docRecLast=cmuOnscreentListForDocLcl.size()-1;
							 }
						 
					 }
					  
				 }
			 }
		
			StringBuffer searchCriteriaMsg = saveWhereUsedXLSFile(setcmuSmlrToPrjSrchData,cmuOnscreentListForPartsLcl,cmuOnscreentListForDocLcl,filePathXls);
			String subject = PLMConstants.WHERE_USED_CMU_MAIL_SUBJECT;
			String message = toAddressee + PLMConstants.WHERE_USED_CMU_MAIL_CONTENT + searchCriteriaMsg.toString() + PLMConstants.WHERE_USED_EBOM_MAIL_SIGNATURE;
			PLMUtils.generateZipFile(filePathXls,filePathZip);
			LOG.info(searchCriteriaMsg.toString());
			PLMUtils.sendMailWithAttachment(from, to, subject, message, filePathZip);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,errorSubject,toAddressee,signature);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,errorSubject,toAddressee,signature);
		} finally {
			PLMUtils.deleteFiles(filePathXls,filePathZip);
		}  
		if(PLMUtils.isEmpty(successMsg)){
			LOG.info("Mail sent successfully.");
		}
	}
	/**
	 * This method is used for Bordering Cell in XLSX
	 * 
	 * @return StringBuffer
	 */
	private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
		style.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style.setBorderRight(XSSFCellStyle.BORDER_THIN);
		return style;
	}
	/**
	 * This method is used for saveWhereUsedXLSFile
	 * 
	 * @param plmThreadWhereUsedData,whereUsedEMBOMSearchPList
	 * @return StringBuffer
	 * @throws Exception
	 */
	public StringBuffer saveWhereUsedXLSFile(PLMCMUSmlrToPrjData cmuSrchData,List<PLMCMUSmlrToPrjData> cmuSearchListParts,List<PLMCMUSmlrToPrjData> cmuSearchListDoc,String filePathXls) throws Exception {
		StringBuffer searchCriteriaMsg = new StringBuffer();
		searchCriteriaMsg.append(PLMConstants.WHERE_USED_EBOM_MAIL_SEARCH_CRITERIA);
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXls);
				SXSSFWorkbook workbook = new SXSSFWorkbook();
				//For Parts(BOM)
				// Start : POI Styles
				XSSFCellStyle headerStyle = (XSSFCellStyle) workbook.createCellStyle();
				headerStyle.setFillForegroundColor(HSSFColor.BLACK.index);
				headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
				
				XSSFFont headerFont = (XSSFFont) workbook.createFont(); 
				headerFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				headerFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headerFont.setFontHeightInPoints((short)9);
				headerFont.setFontName("GE Inspira");
				headerFont.setColor(IndexedColors.WHITE.getIndex());
				headerStyle.setFont(headerFont);
				
				XSSFCellStyle searchFieldNameStyle = (XSSFCellStyle) workbook.createCellStyle();
				searchFieldNameStyle = setBorderStyle(searchFieldNameStyle);
				searchFieldNameStyle.setAlignment(CellStyle.ALIGN_RIGHT);
				
				XSSFFont boldFont = (XSSFFont) workbook.createFont();
				boldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				boldFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				boldFont.setFontHeightInPoints((short)9);
				boldFont.setFontName("GE Inspira");
				boldFont.setColor(IndexedColors.BLACK.getIndex());
				searchFieldNameStyle.setFont(boldFont);
				
				XSSFFont cellstyleFont = (XSSFFont)workbook.createFont(); 
				cellstyleFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				
				cellstyleFont.setFontHeightInPoints((short)9);
				cellstyleFont.setFontName("GE Inspira");
				cellstyleFont.setColor(IndexedColors.BLACK.getIndex());
				
				XSSFCellStyle contentStyle = (XSSFCellStyle) workbook.createCellStyle();
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(cellstyleFont);
				
				XSSFCellStyle contentStyleHyperLinkFdm = (XSSFCellStyle) workbook.createCellStyle();
				XSSFFont fontHyperLinkFdm = (XSSFFont) workbook.createFont();
				fontHyperLinkFdm.setFontName(PLMConstants.EXCEL_FONT_NAME);
				fontHyperLinkFdm.setFontHeightInPoints((short)9);
				fontHyperLinkFdm.setUnderline(HSSFFont.U_SINGLE);
				fontHyperLinkFdm.setColor(HSSFColor.BLUE.index);
				contentStyleHyperLinkFdm.setFont(fontHyperLinkFdm);
				contentStyleHyperLinkFdm=setBorderStyle(contentStyleHyperLinkFdm);
				
			    XSSFFont underLinedFont = (XSSFFont) workbook.createFont();
		        underLinedFont.setUnderline(HSSFFont.U_SINGLE);
		        underLinedFont.setColor(IndexedColors.BLUE.getIndex());
				XSSFCellStyle hyperLinkStyle = (XSSFCellStyle) workbook.createCellStyle();				
				hyperLinkStyle = setBorderStyle(hyperLinkStyle);
				hyperLinkStyle.setFont(underLinedFont);
				
				
				XSSFFont font = (XSSFFont) workbook.createFont(); 
				font.setFontName(PLMConstants.EXCEL_FONT_NAME);
				font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				font.setFontHeightInPoints((short)9);
				font.setFontName("GE Inspira");
				
				XSSFCellStyle cellBoldStyle = (XSSFCellStyle) workbook.createCellStyle();
				cellBoldStyle = setBorderStyle(cellBoldStyle);
				cellBoldStyle.setFont(font);
				
				SXSSFRow row = null;
				SXSSFCell cell = null;
				SXSSFSheet sheet =  null;
				
				int rowcount = -1;
						sheet = (SXSSFSheet) workbook.createSheet("PARTS (BOM)");
							//Header mliTextBoxName
						if(!PLMUtils.isEmptyList(cmuSearchListParts)) {

							String[] copicsColNames = {"FDM", "FRAME TYPE", "MLI", "PART NUMBER", "DESCRIPTION", "F Code 1","F Code 2", "F Code 3","F Code 4"};
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell.setCellValue("Frame Type Drop Down: ");
							searchCriteriaMsg.append("Frame Type Drop Down: "+cmuSrchData.getSelFrameTypeListName()+"\n");
							cell.setCellStyle(cellBoldStyle);
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellValue(cmuSrchData.getSelFrameTypeListName());
							cell.setCellStyle(cellBoldStyle);
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell.setCellValue("Frame Type Free Text: ");
							searchCriteriaMsg.append("Frame Type Free Text: "+cmuSrchData.getSelFrameTypeTextBoxName()+"\n");
							cell.setCellStyle(cellBoldStyle);
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellValue(cmuSrchData.getSelFrameTypeTextBoxName());
							cell.setCellStyle(cellBoldStyle);
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell.setCellValue("Fuel Type(F Code 1) :");
							searchCriteriaMsg.append("Fuel Type(F Code 1) :"+cmuSrchData.getSelFuelTypeListName()+"\n");
							cell.setCellStyle(cellBoldStyle);
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellValue(cmuSrchData.getSelFuelTypeListName());
							cell.setCellStyle(cellBoldStyle);
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell.setCellValue("Combustor Type(F Code 2): ");
							searchCriteriaMsg.append("Combustor Type(F Code 2): "+cmuSrchData.getSelCombustorTypeListName()+"\n");
							cell.setCellStyle(cellBoldStyle);
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellValue(cmuSrchData.getSelCombustorTypeListName());
							cell.setCellStyle(cellBoldStyle);
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell.setCellValue("Any Code(F Code 3) :");
							searchCriteriaMsg.append("Any Code(F Code 3) :"+cmuSrchData.getSelFuelTypeTextBoxName()+"\n");
							cell.setCellStyle(cellBoldStyle);
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellValue(cmuSrchData.getSelFuelTypeTextBoxName());
							cell.setCellStyle(cellBoldStyle);
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell.setCellValue("Any Code(F Code 4) :");
							searchCriteriaMsg.append("Any Code(F Code 4) :"+cmuSrchData.getSelCombustorTypeTextBoxName()+"\n");
							cell.setCellStyle(cellBoldStyle);
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellValue(cmuSrchData.getSelCombustorTypeTextBoxName());
							cell.setCellStyle(cellBoldStyle);
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell.setCellValue("MLI Filter :");
							searchCriteriaMsg.append("MLI Filter :"+cmuSrchData.getMliTextBoxName()+"\n");
							cell.setCellStyle(cellBoldStyle);
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellValue(cmuSrchData.getMliTextBoxName());
							cell.setCellStyle(cellBoldStyle);
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell.setCellValue("PLM Project Creation Date From : ");
							cell.setCellStyle(cellBoldStyle);
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
							if(!PLMUtils.isEmptyDate(cmuSrchData.getEffectivityDateFrom())){
							    cell.setCellValue(PLMUtils.getFormatRelDate(cmuSrchData.getEffectivityDateFrom()));
							    searchCriteriaMsg.append("PLM Project Creation Date From : "+cmuSrchData.getEffectivityDateFrom()+"\n");
							}
							else{
								cell.setCellValue("");
								searchCriteriaMsg.append("PLM Project Creation Date From : "+""+"\n");
							}
							cell.setCellStyle(cellBoldStyle);
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell.setCellValue("PLM Project Creation Date To : ");
							cell.setCellStyle(cellBoldStyle);
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
							if(!PLMUtils.isEmptyDate(cmuSrchData.getEffectivityDateTo())){
								cell.setCellValue(PLMUtils.getFormatRelDate(cmuSrchData.getEffectivityDateTo()));
								searchCriteriaMsg.append("PLM Project Creation Date From : "+cmuSrchData.getEffectivityDateTo()+"\n");	
							}
							else{
								cell.setCellValue("");
								searchCriteriaMsg.append("PLM Project Creation Date To : "+""+"\n");
							}
							cell.setCellStyle(cellBoldStyle);
							
						    row = (SXSSFRow) sheet.createRow(++rowcount);
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							for ( int i = 0 ; i < copicsColNames.length; i++ ) {
								cell = (SXSSFCell) row.createCell(i);
								cell.setCellStyle(headerStyle);
								cell. setCellValue(copicsColNames[i]);
							}
							//Header
							for(int i = 0; i < cmuSearchListParts.size(); i++) {
								PLMCMUSmlrToPrjData dataObj = (PLMCMUSmlrToPrjData) cmuSearchListParts.get(i);
								row = (SXSSFRow) sheet.createRow(++rowcount);
								CreationHelper createHelper = workbook.getCreationHelper();
								
								Hyperlink link = createHelper.createHyperlink(Hyperlink.LINK_URL);
								Hyperlink link2 = createHelper.createHyperlink(Hyperlink.LINK_URL);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
								
								cell.setCellStyle(contentStyleHyperLinkFdm);
								cell.setCellValue(dataObj.getFdm());
								link.setAddress(PLMUtils.getMessage(PLMConstants.TASK_SEARCH_REDIRECT_URL_GE)+dataObj.getFdmId()); 
								cell.setHyperlink(link);
							
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getFrameType());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getMli());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
								cell.setCellStyle(contentStyleHyperLinkFdm);
								cell.setCellValue(dataObj.getPartNumber());
								link2.setAddress(PLMUtils.getMessage(PLMConstants.PART_NUMBER_LINK_ID_URL_ONE)+dataObj.getPartNumberId()
										+PLMUtils.getMessage(PLMConstants.PART_NUMBER_LINK_ID_URL_TWO)+dataObj.getPartNumber()+PLMUtils.getMessage(PLMConstants.PART_NUMBER_LINK_ID_URL_THREE));        
								cell.setHyperlink(link2);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getDescription());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getFcodeOne());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getFcodeTwo());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getFcodeThree());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getFcodeFour());
							
								if(null!=link){
									link =null;
								}
								if(null!=link2){
									link2 =null;
								}
								
						}
						  	sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,8000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,5000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,5000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,8000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,5000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,8000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,4000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,6000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,6000);
							sheet.createFreezePane( 0, 10 );

						}else{
							SXSSFRow row1 = (SXSSFRow) sheet.createRow(++rowcount);
							SXSSFCell cell1 = (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell1.setCellValue("No Records Found in PARTS(BOM)");
							cell1.setCellStyle(contentStyle);
							sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
						}
						
						rowcount = -1;
						sheet = (SXSSFSheet) workbook.createSheet("SPECIFICATIONS AND DOCUMENTS");

						if(!PLMUtils.isEmptyList(cmuSearchListDoc)) {
								//Header
								String[] sbomDeviationCols = {"FDM", "FRAME TYPE", "MLI", "DOC NUMBER", "DESCRIPTION", "F Code 1","F Code 2", "F Code 3","F Code 4"};
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
								cell.setCellValue("Frame Type Drop Down: ");
								cell.setCellStyle(cellBoldStyle);
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellValue(cmuSrchData.getSelFrameTypeListName());
								cell.setCellStyle(cellBoldStyle);
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
								cell.setCellValue("Frame Type Free Text: ");
								cell.setCellStyle(cellBoldStyle);
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellValue(cmuSrchData.getSelFrameTypeTextBoxName());
								cell.setCellStyle(cellBoldStyle);
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
								cell.setCellValue("Fuel Type(F Code 1) : ");
								cell.setCellStyle(cellBoldStyle);
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellValue(cmuSrchData.getSelFuelTypeListName());
								cell.setCellStyle(cellBoldStyle);
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
								cell.setCellValue("Combustor Type(F Code 2) :");
								cell.setCellStyle(cellBoldStyle);
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellValue(cmuSrchData.getSelCombustorTypeListName());
								cell.setCellStyle(cellBoldStyle);
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
								cell.setCellValue("Any Code(F Code 3) : ");
								cell.setCellStyle(cellBoldStyle);
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellValue(cmuSrchData.getSelFuelTypeTextBoxName());
								cell.setCellStyle(cellBoldStyle);
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
								cell.setCellValue("Any Code(F Code 4) : ");
								cell.setCellStyle(cellBoldStyle);
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellValue(cmuSrchData.getSelCombustorTypeTextBoxName());
								cell.setCellStyle(cellBoldStyle);
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
								cell.setCellValue("MLI Filter :");
								cell.setCellStyle(cellBoldStyle);
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellValue(cmuSrchData.getMliTextBoxName());
								cell.setCellStyle(cellBoldStyle);
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
								cell.setCellValue("PLM Project Creation Date From : ");
								cell.setCellStyle(cellBoldStyle);
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								if(!PLMUtils.isEmptyDate(cmuSrchData.getEffectivityDateFrom()))
								    cell.setCellValue(PLMUtils.getFormatRelDate(cmuSrchData.getEffectivityDateFrom()));
								else
									cell.setCellValue("");
								cell.setCellStyle(cellBoldStyle);
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
								cell.setCellValue("PLM Project Creation Date To : ");
								cell.setCellStyle(cellBoldStyle);
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								if(!PLMUtils.isEmptyDate(cmuSrchData.getEffectivityDateTo()))
									cell.setCellValue(PLMUtils.getFormatRelDate(cmuSrchData.getEffectivityDateTo()));
								else
									cell.setCellValue("");
								cell.setCellStyle(cellBoldStyle);
								
								row = (SXSSFRow) sheet.createRow(++rowcount);
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								for ( int i = 0 ; i < sbomDeviationCols.length; i++ ) {
									cell = (SXSSFCell) row.createCell(i);
									cell.setCellStyle(headerStyle);
									cell. setCellValue(sbomDeviationCols[i]);
								}
								
								
								//Header
								for(int i = 0; i < cmuSearchListDoc.size(); i++) {
									PLMCMUSmlrToPrjData dataObj = (PLMCMUSmlrToPrjData) cmuSearchListDoc.get(i);
									row = (SXSSFRow) sheet.createRow(++rowcount);
									CreationHelper createHelper = workbook.getCreationHelper();
									Hyperlink link = createHelper.createHyperlink(Hyperlink.LINK_URL);
									Hyperlink link2 = createHelper.createHyperlink(Hyperlink.LINK_URL);
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
									cell.setCellStyle(contentStyleHyperLinkFdm);
									cell.setCellValue(dataObj.getFdm());
									link.setAddress(PLMUtils.getMessage(PLMConstants.TASK_SEARCH_REDIRECT_URL_GE)+dataObj.getFdmId());        
									cell.setHyperlink(link);
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getFrameType());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getMli());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
									cell.setCellStyle(contentStyleHyperLinkFdm);
									cell.setCellValue(dataObj.getDocNumber());
									link2.setAddress(PLMUtils.getMessage(PLMConstants.DOC_NUMBER_LINK_ID_URL_ONE)+dataObj.getDocNumberId()
											+PLMUtils.getMessage(PLMConstants.DOC_NUMBER_LINK_ID_URL_TWO)+dataObj.getDocNumber()+PLMUtils.getMessage(PLMConstants.DOC_NUMBER_LINK_ID_URL_THREE));        
									cell.setHyperlink(link2);
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getDescription());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getFcodeOne());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getFcodeTwo());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getFcodeThree());
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getFcodeFour());
									
							}
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,8000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,5000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,5000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,8000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,5000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,8000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,4000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,6000);
								sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,6000);
								sheet.createFreezePane( 0, 10 );

						}else{
							SXSSFRow row1 = (SXSSFRow) sheet.createRow(++rowcount);
							SXSSFCell cell1 = (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell1.setCellValue("No Records Found in Specification and Document");
							cell1.setCellStyle(contentStyle);
							sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
						}
			
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveWhereUsedXLSFile: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveWhereUsedXLSFile: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveWhereUsedXLSFile: ", e);
				throw e;
			}
		}
		return searchCriteriaMsg;
	}
	
	/**
	 * This method is used for validateWhereUsedEMBOM
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String validateReportInputs() throws PLMCommonException {
		LOG.info("Inside validateReportInputs method");
		Date effectiveDateFrom = effectivityDateFrom;
		Date effectiveDateTo = effectivityDateTo;
		if (PLMUtils.isEmpty(selFrameTypeListName)
				&& PLMUtils.isEmpty(selFrameTypeTextBoxName)
				&& PLMUtils.isEmpty(selFuelTypeListName)
				&& PLMUtils.isEmpty(selFuelTypeTextBoxName)
				&& PLMUtils.isEmpty(selCombustorTypeListName)
				&& PLMUtils.isEmpty(selCombustorTypeTextBoxName)
				&& PLMUtils.isEmptyDate(effectivityDateFrom)
				&& PLMUtils.isEmptyDate(effectivityDateTo)) {
				if(!cmuSimPrjSrchFlag){
				alertMessage = "*Please Provide some values and select the checkbox to that value for Online Report";
				}else{
				alertMessage = "*Please Provide some values and select the checkbox to that value for Email Report";
				}
			}else if ((PLMUtils.isEmpty(selFuelTypeListName)) 
					&& (PLMUtils.isEmpty(selFuelTypeTextBoxName)) && (PLMUtils.isEmpty(selCombustorTypeListName)) 
					&& (PLMUtils.isEmpty(selCombustorTypeTextBoxName))) {
					alertMessage = "*Please Select/Provide atleast one F Code";
			}else if ((!PLMUtils.isEmpty(selFrameTypeListName)) 
					&& (allOpenFrameTypeList == false)) {
					alertMessage = "*Please select Frame Type Checkbox From Dropdown List to Generate report";
			}else if ((!PLMUtils.isEmpty(selFrameTypeTextBoxName)) 
					&& (allOpenFrameTypeFreeTxt == false)) {
					alertMessage = "*Please select corresponding Frame Type Checkbox to Generate report";
			}else if ((PLMUtils.isEmpty(selFrameTypeListName)) 
					&& (allOpenFrameTypeList == true)) {
					alertMessage = "*Please select a Frame Type From Dropdown List to Generate report";
			}else if ((PLMUtils.isEmpty(selFrameTypeTextBoxName)) 
					&& (allOpenFrameTypeFreeTxt == true)) {
					alertMessage = "*Please Provide some Data in Frame Type Free Text Box to Generate report";
			}else {
				if (PLMUtils.checkForNullOfTwoDates(effectiveDateFrom, effectiveDateTo)) {
				alertMessage = alertMessage + PLMConstants.Dates_NullCheck_Msg;
				}else if (PLMUtils.checkForFromAndToDate(effectiveDateFrom, effectiveDateTo)) {
					alertMessage = alertMessage + PLMConstants.Date_ValMsg;
				}			
			}
		
		return alertMessage;
	}
	/**
	 * This method is used for export to Excel of Shipping BOM Report
	 * 
	 */
	public void downloadPartsSrchExcel() throws PLMCommonException {
		
		LOG.info("Entering downloadPartsSrchExcel Method");
		String reportName="Parts(BOM) Report_".concat(new SimpleDateFormat().format(new Date()));
		String fileName="Parts BOM Report";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("fdm", "FDM", FormatType.LINK, null, null, 25,"fdmId"),
                    new PLMXlsxRptColumn("frameType", "FRAME TYPE", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("mli", "MLI", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("partNumber", "PART NUMBER", FormatType.LINK, null, null, 15,"partNumberId"),
                    new PLMXlsxRptColumn("description", "DESCRIPTION", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("fcodeOne", "F CODE 1", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("fcodeTwo", "F CODE 2", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("fcodeThree", "F CODE 3", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("fcodeFour", "F CODE 4", FormatType.TEXT, null, null, 10)

			};
			PLMXlsxRptColumn[] critcolumns =
					new PLMXlsxRptColumn[] {
					new PLMXlsxRptColumn("selFrameTypeListName", "Frame Type Drop Down: ", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("selFrameTypeTextBoxName", "Frame Type Free Text: ", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("selFuelTypeListName", "Fuel Type(F Code 1): ", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("selCombustorTypeListName", "Combustor Type(F Code 2): ", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("selFuelTypeTextBoxName", "Any Code(F Code 3): ", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("selCombustorTypeTextBoxName", "Any Code(F Code 4): ", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("mliTextBoxName", "MLI Filter", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("effectivityDateFrom", "PLM Project Creation Date From: ", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("effectivityDateTo", "PLM Project Creation Date To: ", FormatType.TEXT_NOWRAP)

					};
			 
			excelUtil.export(cmuOnscreentListForParts, reportColumns, reportName, fileName, true, critcolumns, cmuSmlrToPrjSrchData);
		
	}
	/**
	 * This method is used for export to downloadDocSrchExcel
	 * 
	 */
	public void downloadDocSrchExcel() throws PLMCommonException {
		
		LOG.info("Entering downloadDocSrchExcel Method");
		String reportName="Specification and Document Report_".concat(new SimpleDateFormat().format(new Date()));
		String fileName="Spec And Doc Report";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("fdm", "FDM", FormatType.LINK, null, null, 25,"fdmId"),
                    new PLMXlsxRptColumn("frameType", "FRAME TYPE", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("mli", "MLI", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("docNumber", "DOC NUMBER", FormatType.LINK, null, null, 15,"docNumberId"),
                    new PLMXlsxRptColumn("description", "DESCRIPTION", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("fcodeOne", "F CODE 1", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("fcodeTwo", "F CODE 2", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("fcodeThree", "F CODE 3", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("fcodeFour", "F CODE 4", FormatType.TEXT, null, null, 10)

			};
			PLMXlsxRptColumn[] critcolumns =
					new PLMXlsxRptColumn[] {
					new PLMXlsxRptColumn("selFrameTypeListName", "Frame Type Drop Down: ", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("selFrameTypeTextBoxName", "Frame Type Free Text: ", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("selFuelTypeListName", "Fuel Type(F Code 1): ", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("selCombustorTypeListName", "Combustor Type(F Code 2): ", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("selFuelTypeTextBoxName", "Any Code(F Code 3): ", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("selCombustorTypeTextBoxName", "Any Code(F Code 4): ", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("mliTextBoxName", "MLI Filter", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("effectivityDateFrom", "PLM Project Creation Date From: ", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("effectivityDateTo", "PLM Project Creation Date To: ", FormatType.TEXT_NOWRAP)

					};
			 
			excelUtil.export(cmuOnscreentListForDoc, reportColumns, reportName, fileName, true, critcolumns, cmuSmlrToPrjSrchData);
		
	}
	/**
	 * This method is used for changePartListner
	 * 
	 * @param event
	 */
	public void changePartListner(ActionEvent event) {
		LOG.info("Action listner called.....--------------------------->"
				+ recordPartsCounts);
		if (recordPartsCounts == 100) {
			LOG.info("101");
			recordPartsCounts = PLMConstants.N_100;
		} else if (recordPartsCounts == 200) {
			LOG.info("200");
			recordPartsCounts = 200;
		} else if (recordPartsCounts == 500) {
			LOG.info("500");
			recordPartsCounts = 500;
		} else if (recordPartsCounts == 1000) {
			LOG.info("1000");
			recordPartsCounts = 1000;
		} else if (recordPartsCounts == 2000) {
			LOG.info("2000");
			recordPartsCounts = 2000;
		} else if (recordPartsCounts == 5000) {
			LOG.info("5000");
			recordPartsCounts = 5000;
		} 
		LOG.info("final value.....--------------------------->"
				+ recordPartsCounts);
	}

	/**
	 * This method is used for changeDocListner
	 * 
	 * @param event
	 */
	public void changeDocListner(ActionEvent event) {
		LOG.info("Action listner called.....--------------------------->"
				+ recordDocCounts);
		if (recordDocCounts == 100) {
			LOG.info("101");
			recordDocCounts = PLMConstants.N_100;
		} else if (recordDocCounts == 200) {
			LOG.info("200");
			recordDocCounts = 200;
		} else if (recordDocCounts == 500) {
			LOG.info("500");
			recordDocCounts = 500;
		} else if (recordDocCounts == 1000) {
			LOG.info("1000");
			recordDocCounts = 1000;
		} else if (recordDocCounts == 2000) {
			LOG.info("2000");
			recordDocCounts = 2000;
		} else if (recordDocCounts == 5000) {
			LOG.info("5000");
			recordDocCounts = 5000;
		} else if (recordDocCounts == docCounts) {
			LOG.info("All");
			recordDocCounts = docCounts;
		}
		LOG.info("final value.....--------------------------->"
				+ recordDocCounts);
	}
	/**
	 * Resets the CMU Similar Project Search  Data
	 * @return String
	 */
	public String resetData(){
		String fwdFlag = "cmuSmlrToPrjSrchRptHome";
		alertMessage = "";
		partsBomFlg=false;;
		docBomFlg=false;
		partsInfoFlag=true;
		docInfoFlag=true;
		partsCounts=0;
		docCounts=0;
		noPartsRecFound=new String();
		noDocRecFound=new String();
		mliTextBoxName="";
		allOpenFrameTypeFreeTxt=false;
		allOpenFrameTypeList=false;
		
		selCombustorTypeListName="";
		selCombustorTypeTextBoxName="";
		selFrameTypeListName="";
		selFrameTypeTextBoxName="";
		selFuelTypeListName="";
		selFuelTypeTextBoxName="";
		effectivityDateFrom=null;
		effectivityDateTo=null;
		return fwdFlag;
	}	
}
