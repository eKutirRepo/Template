/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCompleteEbomRptMB.java
 * @Creation date: 06-Apr-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.data.PLMCompleteEbomReportData;
import com.geinfra.geaviation.pwi.service.PLMCompleteEbomReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

public class PLMCompleteEbomRptMB {

	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMCompleteEbomRptMB.class);
	private List<SelectItem> projectNameList = new ArrayList<SelectItem>();
	private List<SelectItem> topPartNameList = new ArrayList<SelectItem>();
	private List<PLMCompleteEbomReportData> completeEbomReportList = new ArrayList<PLMCompleteEbomReportData>();
	private int recordCounts = PLMConstants.N_15;
	private PLMCompleteEbomReportData pwiCompleteEbomReportvo = new PLMCompleteEbomReportData();
	private String alertMessage;
	private List<String> selShipBomTopPartName = new ArrayList<String>();
	private String selShipBomProjectName = new String();
	private PLMCompleteEbomReportServiceIfc plmCompleteEbomReportService = null;
	private boolean allOpenTopPartName;
	private PLMCommonMB commonMB;
	private String totalRecordCompleteEbomAptMsg;
	
	
	/**
	 * @return the projectNameList
	 */
	public List<SelectItem> getProjectNameList() {
		return projectNameList;
	}
	/**
	 * @param projectNameList the projectNameList to set
	 */
	public void setProjectNameList(List<SelectItem> projectNameList) {
		this.projectNameList = projectNameList;
	}
	/**
	 * @return the topPartNameList
	 */
	public List<SelectItem> getTopPartNameList() {
		return topPartNameList;
	}
	/**
	 * @param topPartNameList the topPartNameList to set
	 */
	public void setTopPartNameList(List<SelectItem> topPartNameList) {
		this.topPartNameList = topPartNameList;
	}
	/**
	 * @return the completeEbomReportList
	 */
	public List<PLMCompleteEbomReportData> getCompleteEbomReportList() {
		return completeEbomReportList;
	}
	/**
	 * @param completeEbomReportList the completeEbomReportList to set
	 */
	public void setCompleteEbomReportList(
			List<PLMCompleteEbomReportData> completeEbomReportList) {
		this.completeEbomReportList = completeEbomReportList;
	}
	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}
	/**
	 * @param recordCounts the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}
	/**
	 * @return the pwiCompleteEbomReportvo
	 */
	public PLMCompleteEbomReportData getPwiCompleteEbomReportvo() {
		return pwiCompleteEbomReportvo;
	}
	/**
	 * @param pwiCompleteEbomReportvo the pwiCompleteEbomReportvo to set
	 */
	public void setPwiCompleteEbomReportvo(
			PLMCompleteEbomReportData pwiCompleteEbomReportvo) {
		this.pwiCompleteEbomReportvo = pwiCompleteEbomReportvo;
	}
	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}
	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}
	/**
	 * @return the selShipBomTopPartName
	 */
	public List<String> getSelShipBomTopPartName() {
		return selShipBomTopPartName;
	}
	/**
	 * @param selShipBomTopPartName the selShipBomTopPartName to set
	 */
	public void setSelShipBomTopPartName(List<String> selShipBomTopPartName) {
		this.selShipBomTopPartName = selShipBomTopPartName;
	}
	/**
	 * @return the selShipBomProjectName
	 */
	public String getSelShipBomProjectName() {
		return selShipBomProjectName;
	}
	/**
	 * @param selShipBomProjectName the selShipBomProjectName to set
	 */
	public void setSelShipBomProjectName(String selShipBomProjectName) {
		this.selShipBomProjectName = selShipBomProjectName;
	}
	/**
	 * @return the plmCompleteEbomReportService
	 */
	public PLMCompleteEbomReportServiceIfc getPlmCompleteEbomReportService() {
		return plmCompleteEbomReportService;
	}
	/**
	 * @param plmCompleteEbomReportService the plmCompleteEbomReportService to set
	 */
	public void setPlmCompleteEbomReportService(
			PLMCompleteEbomReportServiceIfc plmCompleteEbomReportService) {
		this.plmCompleteEbomReportService = plmCompleteEbomReportService;
	}
	/**
	 * @return the allOpenTopPartName
	 */
	public boolean isAllOpenTopPartName() {
		return allOpenTopPartName;
	}
	/**
	 * @param allOpenTopPartName the allOpenTopPartName to set
	 */
	public void setAllOpenTopPartName(boolean allOpenTopPartName) {
		this.allOpenTopPartName = allOpenTopPartName;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}
	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the totalRecordCompleteEbomAptMsg
	 */
	public String getTotalRecordCompleteEbomAptMsg() {
		return totalRecordCompleteEbomAptMsg;
	}
	/**
	 * @param totalRecordCompleteEbomAptMsg the totalRecordCompleteEbomAptMsg to set
	 */
	public void setTotalRecordCompleteEbomAptMsg(
			String totalRecordCompleteEbomAptMsg) {
		this.totalRecordCompleteEbomAptMsg = totalRecordCompleteEbomAptMsg;
	}
	/**
	 * This method is used for getLoadingData
	 *  for project names
	 * 
	 * @return String
	 */
	public String getLoadingData()
	{
		LOG.info("getLoadingData() Method");
		String fwdFlag = "";
		alertMessage = "";
		allOpenTopPartName=false;
		selShipBomTopPartName=new ArrayList<String>();
		selShipBomProjectName=new String();
		pwiCompleteEbomReportvo.setSelectedProjectName("");
		pwiCompleteEbomReportvo.setSelectedTopPartName("");
		topPartNameList = new ArrayList<SelectItem>();
		try {
			 commonMB.insertCannedRptRecordHitInfo("Complete EBOM Report");
			 Map<String, List<SelectItem>> dropdownlist = plmCompleteEbomReportService.getLoadingData();
			 projectNameList = (List<SelectItem>) dropdownlist.get("projectnamelist");
			fwdFlag = "plmCompleteEbomRptHome";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getLoadingData: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Complete EBOM Report");
		} 
		return fwdFlag;
	}
	
	/**
	 * This method is used for Contract auto complete feature
	 * 
	 * @return String
	 */
	public List<String> projectFamilyAutocomplete(Object projectEbomFamilySuggest) {
		LOG.info("Inside projectFamilyAutocomplete method... PLMCompleteEbomReportMB");
		String pref = (String) projectEbomFamilySuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (projectNameList.size() > 0) {
				for (SelectItem item : projectNameList) {
					if (!item.getLabel().equals("")
							&& item.getLabel().startsWith(
									pref.toUpperCase(Locale.getDefault()))) {
						result.add(item.getLabel());
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@projectFamilyAutocomplete in PLMCompleteEbomReportMB:",
					exception);
		}
		LOG.info("Exit from projectFamilyAutocomplete method... PLMCompleteEbomReportMB");
		return result;
	}

	/**
	 * This method is used for Top Part Name auto complete feature
	 * 
	 * @return String
	 */
	public List<String> topPartFamilyAutocomplete(Object topPartEbomFamilySuggest) {
		LOG.info("Inside projectFamilyAutocomplete method... PLMCompleteEbomReportMB");
		String pref = (String) topPartEbomFamilySuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (topPartNameList.size() > 0) {
				for (SelectItem item : topPartNameList) {
					if (!item.getLabel().equals("")
							&& item.getLabel().startsWith(
									pref.toUpperCase(Locale.getDefault()))) {
						result.add(item.getLabel());
						
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@topPartFamilyAutocomplete in PLMCompleteEbomReportMB:",
					exception);
		}
		LOG.info("Exit from topPartFamilyAutocomplete method... PLMCompleteEbomReportMB");
		return result;
	}
	
	/**
	 * This method is used to get Top Part Name Information for Project
	 * 
	 * @param event
	 */
	public void fetchTopPartList(ActionEvent event){
		LOG.info("Entering fetchTopPartList method PLMCompleteEbomReportMB");
		try{
			 List <PLMCompleteEbomReportData> projectListData = new ArrayList<PLMCompleteEbomReportData>();
			 topPartNameList = new ArrayList<SelectItem>();
			 projectListData = plmCompleteEbomReportService.fetchTopPartList(selShipBomProjectName);
			 LOG.info("Top Part LIST DATA Size"+projectListData.size());
			   for(int i=0;i<projectListData.size();i++){
				   topPartNameList.add(new SelectItem(projectListData.get(i).getTopPartName()));
				}
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting fetchTopPartList method PLMCompleteEbomReportMB");
	}
	/**
	 * This method is used for generating report on UI
	 * 
	 * @return String
	 */
	public String generateCompleteEbomAppReport() {
		LOG.info("get data from generateCompleteEbomAppReport() Method");
				String fwdFlag = "";
				alertMessage = "";
				totalRecordCompleteEbomAptMsg="";
				completeEbomReportList=new ArrayList<PLMCompleteEbomReportData>();
		try { 
			 if (allOpenTopPartName){
				 if(!PLMUtils.isEmptyList(topPartNameList))
				      {
					 selShipBomTopPartName = new ArrayList<String>();
						   for (int i = 0 ; i < topPartNameList.size() ; i++ )
					  	     {
							String requireValue = topPartNameList.get(i).getValue().toString();
							selShipBomTopPartName.add(requireValue);
						    }
				      }
			}
			
			 alertMessage = validateCompleteEbomAptReport();
			 if (PLMConstants.EMPTY.equals(alertMessage)) {
				
				 completeEbomReportList = plmCompleteEbomReportService.generateCompleteEbomAppReport(selShipBomProjectName,selShipBomTopPartName);
				 if(completeEbomReportList.size()>0){
					 totalRecordCompleteEbomAptMsg="Total Records of Complete EBOM Report:: "+completeEbomReportList.size();
					 recordCounts = PLMConstants.N_100;
	     		  fwdFlag = "plmCompleteEbomRptHomeDetails";
				 }
				 else{
					 alertMessage = "No Records Found for the Selected combination";
					 fwdFlag = "plmCompleteEbomRptHome";
				 }
			 }
			 else{
				 fwdFlag = "plmCompleteEbomRptHome";
			 }
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@generateCompleteEbomAppReport: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Complete EBOM Report");
		} 
		
		return fwdFlag;
	}
	/**
	 * This method is used for export to Excel of Back log Report
	 * 
	 */
	public void downloadCompleteEbomSrchExcel() throws PLMCommonException {
		
		LOG.info("Entering downloadCompleteEbomSrchExcel Method");
		//7269088_rev_001__Engineering_Bill_of_Materials1484680264437
		String reportName=selShipBomProjectName.concat("_Engineering_Bill_of_Materials").concat(new SimpleDateFormat().format(new Date()));
		String fileName="Complete EBOM Report";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					new PLMXlsxRptColumn("level", "Level", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("name", "Name", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("type", "Type", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("rev", "Rev", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("policy", "Policy", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("findNum", "F/N", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("refDesignator", "Ref Des", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("componentLocation", "Component Location", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("description", "Description", FormatType.TEXT, null, null, 25),
                    new PLMXlsxRptColumn("state", "State", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("quantity", "Qty", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("unitOfMeasure", "U of M", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("usage", "Usage", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("partFamily", "Part Family", FormatType.TEXT, null, null, 15)
			};
			
			PLMXlsxRptColumn[] critcolumns =
					new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("selectedProjectNameHeader", "Selected Project Name", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("selectedTopPartNameHeader", "Selected Top Part Names", FormatType.TEXT_NOWRAP)
					};
			pwiCompleteEbomReportvo.setSelectedProjectNameHeader(selShipBomProjectName);
			pwiCompleteEbomReportvo.setSelectedTopPartNameHeader(PLMUtils.convertListToString(selShipBomTopPartName));
			excelUtil.export(completeEbomReportList, reportColumns, reportName, fileName, true, critcolumns, pwiCompleteEbomReportvo);
	 }
	/**
	 * This method is used for validateBacklogAptReport
	 * 
	 * @return String
	 */
	public String  validateCompleteEbomAptReport(){
		alertMessage ="";
		if (PLMUtils.isEmpty(selShipBomProjectName)) {
			alertMessage = "*Project Name Input Selection is mandatory";
		}
		
		return alertMessage;
	}
	/**
	 * reset
	 */
	public void resetCompleteEbomReport(){
		alertMessage = "";
		allOpenTopPartName=false;
		topPartNameList=new ArrayList<SelectItem>();
		totalRecordCompleteEbomAptMsg="";
		pwiCompleteEbomReportvo.setSelectedProjectName("");
		pwiCompleteEbomReportvo.setSelectedTopPartName("");
		selShipBomProjectName = new String();
		selShipBomTopPartName = new ArrayList<String>();
	}
	
}
