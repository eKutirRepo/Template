/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMGBomDaoIfc.java
 * @Creation date: 4-April-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMCostCatalogData;
import com.geinfra.geaviation.pwi.data.PLMGBomData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMGBomDaoIfc {
	/**
	 * This method is used to getDropDownData
	 * @return java.util.Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getDropDownData() throws PLMCommonException;
	/**
	 * This method is used to getGBOMData
	 * @return java.util.List
	 * @param varMap, hwPrdMap
	 * @throws PLMCommonException
	 */
	public List<PLMGBomData> getGBOMData(Map<String, Object> varMap,Map<String, Object> hwPrdMap) throws PLMCommonException;
	/**
	 * This method is used to getExcelHeaderList
	 * @return java.util.List
	 * @param headerCFNamesList
	 * @throws PLMCommonException
	 */
	public List<PLMGBomData> getExcelHeaderList(List<String> headerCFNamesList) throws PLMCommonException;
	/**
	 * This method is used to getDispNameForMMName
	 * @return java.util.Map
	 * @param selectedModelMktNamesList
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getDispNameForMMName(List<String> selectedModelMktNamesList) throws PLMCommonException;
	/**
	 * This method is used to getHwPrdNameList
	 * @return java.util.List
	 * @param selectedModelMktNamesList, selectedTfDisplayNamesList
	 * @throws PLMCommonException
	 */
	public List<PLMGBomData> getHwPrdNameList(List<String> selectedModelMktNamesList,List<String> selectedTfDisplayNamesList) throws PLMCommonException;
	//Added for Feature Impact Report
	public List<SelectItem> getFeatImptReptDrpDwnData() throws PLMCommonException;
	public List<SelectItem> getFrameTypeData(String selectedProductLine) throws PLMCommonException;
	public List<PLMGBomData> getFeatureNameList(String selectedProductLine,String selectedFrameType) throws PLMCommonException;
	public Map<String, List<PLMGBomData>> getCFList(List<String> hrdwrPrdctList) throws PLMCommonException;
	public Map<String, List<PLMGBomData>> getFeatImptReptTab1Data(Map<String, Object> varMap,Map<String, Object> hwPrdMap) throws PLMCommonException;
	public List<PLMGBomData> getExcelHeaderListFir(List<String> headerCFNamesList) throws PLMCommonException;
	public Map<String ,List<PLMGBomData>> getFeatImptReptTab2Data(Map<String, Object> tab2InputData) throws PLMCommonException;
	//public String getVTTableName(List<String> hrdwrPrdctList) throws PLMCommonException;
	
	//Newly Added for Part Cost Catalog Report
	/**
	 * This method is used for Generating Part Cost Catalog Report
	 * 
	 * @param selectedHwPrdNameList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMCostCatalogData> getPartCostCatalogData(List<String> selectedHwPrdNameList,String selCostType) throws PLMCommonException;
	/**
	 * This method is used for getting Hardware product and Revision
	 * 
	 * @param selectedHwPrdNameList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMCostCatalogData> getHardwarePrdRevision(List<String> selectedHwPrdNameList) throws PLMCommonException;
	
//Newly Added by srinivas for 3.0.7 Release
	
	/**
	 * This method is used for getting CINomen
	 * 
	 * @param hrdwrPrdctList
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<PLMGBomData>> getCINomenList(List<String> hrdwrPrdctList) throws PLMCommonException;
	
	/**
	 * This method is used for getting Cost type
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getCostTypeList() throws PLMCommonException;
	
	//Newly Added for BOM Report for GBoM Parts for 4.5 Release
	/**
	 * This method is used for inserting GBOM part into GTT Tables
	 * 
	 * @param hrdwrPrdctList,ciNomenNamesList
	 * @return int
	 * @throws PLMCommonException
	 */
	public List<String> gbomPartsBoMReport(List<String> hrdwrPrdctList,List<String> ciNomenNamesList, 
			String fileDir) throws PLMCommonException;

}
