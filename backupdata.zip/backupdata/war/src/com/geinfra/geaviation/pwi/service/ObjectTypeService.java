package com.geinfra.geaviation.pwi.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.context.PWiContext;
import com.geinfra.geaviation.pwi.dao.GroupTypeDAO;
import com.geinfra.geaviation.pwi.dao.ObjectTypeDAO;
import com.geinfra.geaviation.pwi.dao.QueryGroupDAO;
import com.geinfra.geaviation.pwi.dao.QueryObjectDAO;
import com.geinfra.geaviation.pwi.model.PWiObjectTypeVO;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.model.PWiQueryObjectVO;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.util.RoleInfoUtil;

/**
 * Project : Product Lifecycle Management Date Written : Apr 20, 2011 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : ObjectTypeService
 * 
 * Revision Log Apr 20, 2011 | v1.0.
 * --------------------------------------------------------------
 */
public class ObjectTypeService {
	// Injected
	private ObjectTypeDAO objectTypeDAO;
	private QueryGroupDAO queryGroupDAO;
	private QueryObjectDAO queryObjectDAO;
	private GroupTypeDAO groupTypeDAO;
	private TransactionTemplate transactionTemplate;

	// Object Type Name Pattern
	private static final Pattern NAME_PATTERN = Pattern
			.compile("^[_A-Za-z0-9@'\\s-]+$");

	public void setObjectTypeDAO(ObjectTypeDAO objectTypeDAO) {
		this.objectTypeDAO = objectTypeDAO;
	}
	
	public void setQueryGroupDAO(QueryGroupDAO queryGroupDAO) {
		this.queryGroupDAO = queryGroupDAO;
	}

	public void setQueryObjectDAO(QueryObjectDAO queryObjectDAO) {
		this.queryObjectDAO = queryObjectDAO;
	}
	
	public void setGroupTypeDAO(GroupTypeDAO groupTypeDAO) {
		this.groupTypeDAO = groupTypeDAO;
	}
	
	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}

	public List<PWiObjectTypeVO> getAllPWiObjectTypes() {
		return objectTypeDAO.findAllPWiObjectTypes();
	}

	public List<PWiObjectTypeVO> getPWiQiObjectTypes() {
		return objectTypeDAO.findPWiQiObjectTypes();
	}

	public List<PWiObjectTypeVO> getPWiObjectTypesForUser()
			throws PWiException {
		return objectTypeDAO.findPWiObjectTypesForGroups(
				RoleInfoUtil.getInstance().getRolesForUser(
						PWiContext.getCurrentInstance().getUserSso()));
	}

	public PWiObjectTypeVO getObjectTypeByName(String objectTypeName) {
		List<PWiObjectTypeVO> objectTypes = getAllPWiObjectTypes();
		for (PWiObjectTypeVO objectType : objectTypes) {
			if (objectTypeName.equalsIgnoreCase(objectType.getObjTypNm())) {
				return objectType;
			}
		}
		return null;
	}

	public PWiObjectTypeVO getObjectTypeById(Integer objectTypeId) {
		return objectTypeDAO.getObjectTypeById(objectTypeId);
	}

	public List<PWiQueryObjectVO> getSelectedObjectTypes(Integer queryId) {
		return queryObjectDAO.getQueryObjectForQuery(queryId);
	}

	public List<PWiObjectTypeVO> getAllObjectTypesWithGroups() {
		return objectTypeDAO.getAllObjectTypesWithGroups();
	}
	
	public boolean validateName(String objectTypeName) {
		boolean result = true;
		if (StringUtils.isBlank(objectTypeName)) {
			FacesContext.getCurrentInstance().addMessage(
					PWiConstants.ERROR_BLANK_NAME,
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							PWiConstants.ERROR_BLANK_NAME,
							PWiConstants.ERROR_BLANK_NAME));
			result = false;
		} else {
			Matcher matcher = NAME_PATTERN.matcher(objectTypeName);
			if (!matcher.find()) {
				FacesContext.getCurrentInstance().addMessage(
						PWiConstants.ERROR_INVALID_NAME,
						new FacesMessage(FacesMessage.SEVERITY_ERROR,
								PWiConstants.ERROR_INVALID_NAME,
								PWiConstants.ERROR_INVALID_NAME));
				result = false;
			}
		}
		return result;
	}

	public int checkNames(String objTypNm, String objTypDesc) {
		return objectTypeDAO.checkNames(objTypNm, objTypDesc);
	}

	public int checkNamesForEdit(String objTypNm, String objTypDesc,
			Integer objTypSeqId) {
		return objectTypeDAO.checkNamesEdit(objTypNm, objTypDesc, objTypSeqId);
	}
	
	public Integer createNewObjectType(final String objTypName,
			final String objTypDesc, final boolean shwInQi,
			final List<Integer> selectedGroupIds, final String sso) throws PWiException {
		return (Integer) transactionTemplate.execute(new TransactionCallback() {
			public Object doInTransaction(TransactionStatus ts) {
				// create Object Type
				Integer objTypId =  objectTypeDAO.createNewObjectType(
						objTypName, objTypDesc, shwInQi, sso);
				
				// Add group references
				if (!selectedGroupIds.isEmpty()) {
					groupTypeDAO.addGroupsForObjectType(selectedGroupIds,
							objTypId, sso);
				}
				
				return objTypId;
			}
		});
	}

	public void updateObjectType(final PWiObjectTypeVO objectType,
			List<Integer> selectedGroupIds, final String sso)
			throws PWiException {
		final Integer objectTypeId = objectType.getObjTypSeqId();

		// determine groups to add and remove
		List<PWiQueryGroupVO> existingGroups =  queryGroupDAO
				.findSelectedGroupsForObjectType(objectTypeId);
		List<Integer> existingGroupIds = new ArrayList<Integer>(
				existingGroups.size());
		for (PWiQueryGroupVO group : existingGroups) {
			existingGroupIds.add(group.getQueryGroupId());
		}

		// determine groups to add
		@SuppressWarnings("unchecked")
		final List<Integer> groupIdsToAddForObjectType = new ArrayList<Integer>(
				(Collection<Integer>) CollectionUtils.subtract(
						selectedGroupIds, existingGroupIds));
		// determine groups to remove
		@SuppressWarnings("unchecked")
		final List<Integer> groupIdsToRemoveForObjectType = new ArrayList<Integer>(
				(Collection<Integer>) CollectionUtils.subtract(
						existingGroupIds, selectedGroupIds));

		// start transaction to update objectType information
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			protected void doInTransactionWithoutResult(
					TransactionStatus transactionStatus) {

				// update objectType
				objectTypeDAO.updateObjectType(objectType, sso);

				// add groups
				if (!groupIdsToAddForObjectType.isEmpty()) {
					groupTypeDAO.addGroupsForObjectType(groupIdsToAddForObjectType,
							objectTypeId, sso);
				}

				// remove groups
				if (!groupIdsToRemoveForObjectType.isEmpty()) {
					groupTypeDAO.deleteGroupsForObjectType(
							groupIdsToRemoveForObjectType, objectTypeId);
				}
			}
		});
	}
}
