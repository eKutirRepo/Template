/**
 * Copyright (C) 2012 GE Infra. 
 * All rights reserved 
 * @FileName PLMOmmReportDaoIfc.java
 * @Creation date: 14-June-2012
 * @version 2.0.1
 * @author : Tech Mahindra (PLMR Team)
 */


package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import com.geinfra.geaviation.pwi.data.PLMOmmReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMOmmReportDaoIfc {
	/**
	 * This method is used for checkForValidSerialNo
	 * 
	 * @param serialNo
	 * @return int
	 * @throws PLMCommonException
	 */
	public int checkForValidSerialNo(String serialNo) throws PLMCommonException;
	/**
	 * This method is used for getContractNo
	 * 
	 * @param serialNo
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getContractNo(String serialNo) throws PLMCommonException;
	/**
	 * This method is used for getOmmBomExplosionReport
	 * 
	 * @param topPartId
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<PLMOmmReportData>> getOmmBomExplosionReport(String topPartId, String topPartNm) throws PLMCommonException;
	/**
	 * This method is used for getOmmCustomerDocReport
	 * 
	 * @param serialNo
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMOmmReportData> getOmmCustomerDocReport(String serialNo) throws PLMCommonException;
	/**
	 * This method is used for getOmmSbomDeviationReport
	 * 
	 * @param serialNo
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMOmmReportData> getOmmSbomDeviationReport(String serialNo) throws PLMCommonException;
	
	//Newly Added method for Getting list of part Names based on Serial Number
	/**
	 * This method is used to get List of Top parts.
	 * 
	 * @param serialNo
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMOmmReportData> getTopPartsList(String serialNo)throws PLMCommonException;	
}