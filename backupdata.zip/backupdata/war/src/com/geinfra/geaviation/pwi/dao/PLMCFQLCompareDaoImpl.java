/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCFQLCompareDaoImpl.java
 * @Creation date: 06-Sept-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMCFQLCompareData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.sun.jms.util.Log;

public class PLMCFQLCompareDaoImpl extends SimpleJdbcDaoSupport implements PLMCFQLCompareDaoIfc  {
	/**
	 * Holds the Logger.
	 */
	private static final Logger LOG = Logger.getLogger(PLMCFQLCompareDaoImpl.class);

	/**
	 * This method is used to get CF QL Compare Report
	 * 
	 * @param bulkHwPRdList
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public TreeMap <Integer,Object>  getCFQLCompareRpt(List<PLMCFQLCompareData> bulkHwPRdFinalList) throws PLMCommonException{
		LOG.info("Entering in to getCFQLCompareRpt");
		List<PLMCFQLCompareData> cfQlCompareList =new ArrayList<PLMCFQLCompareData>();
		StringBuffer searchQuery = new StringBuffer();
		StringBuffer appendFilter = new StringBuffer();
		boolean whereFlag=false;
		TreeMap <Integer,Object> cfQlCompareTreeMapFinal = new TreeMap<Integer,Object>();
		try {
			for(int i=0;i<bulkHwPRdFinalList.size();i++){
				if(!PLMUtils.isEmpty(bulkHwPRdFinalList.get(i).getHwPrdctNm()) && !PLMUtils.isEmpty(bulkHwPRdFinalList.get(i).getRevNm())){
					if(!whereFlag){
						appendFilter.append(" WHERE( ");
						whereFlag=true;
					}else{
						appendFilter.append(" OR ");
					}
					appendFilter.append("(HW_PRDT.NM ='"+bulkHwPRdFinalList.get(i).getHwPrdctNm()+"'");
					appendFilter.append(" AND HW_PRDT.REVISION ='"+bulkHwPRdFinalList.get(i).getRevNm()+"')");
				}
			}
			appendFilter.append(")");
			
			searchQuery.append(PLMSearchQueries.GET_CF_QL_COMPARE_DATA_ONE);
			searchQuery.append(appendFilter);
			searchQuery.append(PLMSearchQueries.GET_CF_QL_COMPARE_DATA_TWO);
			searchQuery.append(appendFilter);
			searchQuery.append(PLMSearchQueries.GET_CF_QL_COMPARE_DATA_THREE);
			 LOG.info("Executing Query for getCFQLCompareRpt >>> "+searchQuery);
			cfQlCompareList =getSimpleJdbcTemplate().query(searchQuery.toString(), new CfQlCompareMapper());
			 LOG.info("cfQlCompareList size >>> "+cfQlCompareList.size());
			List<String> marketNameList = new ArrayList<String>();
			List<String> marketNameList1 = new ArrayList<String>();
			
			HashMap<String, String> mktMap = new HashMap<String, String>();
			HashMap<String, String> mktMap1 = new HashMap<String, String>();
			 Map<String, List<PLMCFQLCompareData>> confFeautureDispNmMap =new LinkedHashMap<String, List<PLMCFQLCompareData>>();
			 List<PLMCFQLCompareData> displayNmList =new ArrayList<PLMCFQLCompareData>();
			 String prevHpMktNm = "";
			 String prevOption = " ";
			 String prevChapterDispNm = "";
			 int count = 0;
			 // Loop to get unique list of marketing Names & Conf Options (with list of chapters connected to it)
			 for(PLMCFQLCompareData fetchData :cfQlCompareList){
				  mktMap.put(fetchData.getHpMarketingNm(), "");
				  mktMap1.put(fetchData.getHpMarketingNm()  + " " + fetchData.getHwPrdctNm(), fetchData.getHpMarketingNm());
				  if ("".equalsIgnoreCase(prevChapterDispNm)) {
					  prevChapterDispNm = fetchData.getChDisplayNm();
				  }
				  if (prevChapterDispNm.equalsIgnoreCase(fetchData.getChDisplayNm())) {
					  displayNmList.add(fetchData);
				  } else if (!prevChapterDispNm.equalsIgnoreCase(fetchData.getChDisplayNm())) {
					  confFeautureDispNmMap.put(prevChapterDispNm, displayNmList);
					  //LOG.info("Add list of objects to map for chapter >>>> " + prevChapterDispNm + " >>> "+ displayNmList.size());
					  displayNmList =new ArrayList<PLMCFQLCompareData>();
					  displayNmList.add(fetchData);
				  }
				  prevChapterDispNm = fetchData.getChDisplayNm();
			 }
			 
			 if (confFeautureDispNmMap.size() > 0) {
				 confFeautureDispNmMap.put(prevChapterDispNm, displayNmList);
			 }
			 marketNameList.addAll(mktMap.keySet());
			 marketNameList1.addAll(mktMap1.keySet());
			 
			 LOG.info("Unique List of Marketing Names: " + marketNameList);
			 LOG.info("Unique List of Marketing Names1: " + marketNameList1);
			 LOG.info("Unique List of Display Names: " + confFeautureDispNmMap.size());
			
			List<PLMCFQLCompareData> lst = new ArrayList<PLMCFQLCompareData>();
			List<PLMCFQLCompareData> cfQlCompareDtLstFinal = new ArrayList<PLMCFQLCompareData>();

			PLMCFQLCompareData objData =new PLMCFQLCompareData();
			
			Iterator entries = confFeautureDispNmMap.entrySet().iterator();
			while (entries.hasNext()){
				Entry thisEntry = (Entry) entries.next();
				String key = (String) thisEntry.getKey();
				List<PLMCFQLCompareData> dataLst = (ArrayList<PLMCFQLCompareData>)thisEntry.getValue();
				//LOG.info("Inside while loop" + dataLst.size() + "  key name >>>>> " + key);
				count = 0;
				boolean recordAdded = true;
				PLMCFQLCompareData tempData = new PLMCFQLCompareData();
				PLMCFQLCompareData nextTempData = new PLMCFQLCompareData();
				for (int x = 0; x < dataLst.size(); x++) {
					tempData = (PLMCFQLCompareData) dataLst.get(x);
					String nextOption = "";
					if (x < dataLst.size() - 1) {
						nextTempData = (PLMCFQLCompareData) dataLst.get(x+1);
						nextOption = nextTempData.getConfOption();
					} 
					PLMCFQLCompareData objTypeData =new PLMCFQLCompareData();
					
					
						if (recordAdded) {
							//LOG.info("inside recordAdded cond");
							objData =new PLMCFQLCompareData();
							lst = new ArrayList<PLMCFQLCompareData>();
							objData.setLevel(tempData.getLevel());
							objData.setDisplayNm(tempData.getDisplayNm());
							objData.setConfOption(tempData.getConfOption());
							objData.setRev(tempData.getRev());
							objData.setPegasusCode(tempData.getPegasusCode());
							objTypeData.setHpMarketingNm(tempData.getHpMarketingNm());
							objTypeData.setChDisplayNm(tempData.getChDisplayNm());
							objTypeData.setMfChapter(tempData.getMfChapter());
							objTypeData.setRevChapter(tempData.getRevChapter());
							objTypeData.setSubType(tempData.getSubType());
							objTypeData.setDefaultType(tempData.getDefaultType());
							objTypeData.setSequenceNum(tempData.getSequenceNum());
							if (marketNameList.size() == 1) {
								if ("3".equalsIgnoreCase(objData.getLevel())) {
									objTypeData.setChDisplayNm(tempData.getChDisplayNm());
									objTypeData.setRevChapter(tempData.getRevChapter());
									objTypeData.setSubType(tempData.getSubType());
									objTypeData.setDefaultType(tempData.getDefaultType());
								} else if ("2".equalsIgnoreCase(objData.getLevel())) {
									objTypeData.setChDisplayNm("");
									objTypeData.setRevChapter("");
									objTypeData.setSubType("");
									objTypeData.setDefaultType("");
								}
								objTypeData.setAvailable(true);
							}
							lst.add(objTypeData);
							count++;
							recordAdded = false;
						} else if (prevOption.equalsIgnoreCase(tempData.getConfOption())
								&& !prevHpMktNm.equalsIgnoreCase(tempData.getHpMarketingNm())) {
							//LOG.info(" inside else if cond2 ");
							objTypeData.setHpMarketingNm(tempData.getHpMarketingNm());
							objTypeData.setChDisplayNm(tempData.getChDisplayNm());
							objTypeData.setMfChapter(tempData.getMfChapter());
							objTypeData.setRevChapter(tempData.getRevChapter());
							objTypeData.setSubType(tempData.getSubType());
							objTypeData.setDefaultType(tempData.getDefaultType());
							objTypeData.setSequenceNum(tempData.getSequenceNum());
							lst.add(objTypeData);
							count++;
							if (count == marketNameList.size()) {
								count = 0;
								//LOG.info(" inside else cond if count == marketNameList.size() ");
								List<PLMCFQLCompareData> lstNew = new ArrayList<PLMCFQLCompareData>();
								boolean matchFound = false;
								for (int i = 0; i < marketNameList.size(); i++) {
									PLMCFQLCompareData objTypeDataNew =new PLMCFQLCompareData();
									for (int j = 0; j < lst.size(); j++) {
										if (marketNameList.get(i).equalsIgnoreCase(lst.get(j).getHpMarketingNm())) {
											if ("3".equalsIgnoreCase(objData.getLevel())) {
												objTypeDataNew.setChDisplayNm(lst.get(j).getChDisplayNm());
												objTypeDataNew.setRevChapter(lst.get(j).getRevChapter());
												objTypeDataNew.setSubType(lst.get(j).getSubType());
												objTypeDataNew.setDefaultType(lst.get(j).getDefaultType());
											} else if ("2".equalsIgnoreCase(objData.getLevel())) {
												objTypeDataNew.setChDisplayNm("");
												objTypeDataNew.setRevChapter("");
												objTypeDataNew.setSubType("");
												objTypeDataNew.setDefaultType("");
											}
											objTypeDataNew.setMfChapter(lst.get(j).getMfChapter());
											objTypeDataNew.setSequenceNum(lst.get(j).getSequenceNum());
											objTypeDataNew.setHpMarketingNm(lst.get(j).getHpMarketingNm());
											objTypeDataNew.setAvailable(true);
											lstNew.add(objTypeDataNew);
											matchFound = true;
											//LOG.info("lst.get(j).getHpMarketingNm() >>> " + lst.get(j).getHpMarketingNm());
											break;
										} 
									}
									if (!matchFound) {
										//LOG.info("Match Not Found");
										objTypeDataNew.setHpMarketingNm(marketNameList.get(i));
										objTypeDataNew.setChDisplayNm("0");
										objTypeDataNew.setMfChapter("0");
										objTypeDataNew.setRevChapter("0");
										objTypeDataNew.setSubType("0");
										objTypeDataNew.setDefaultType("0");
										objTypeDataNew.setSequenceNum("0");
										objTypeDataNew.setAvailable(false);
										lstNew.add(objTypeDataNew);
										matchFound = false;
									}
								}
								//LOG.info("Chapter Disp Name >>> "+ tempData.getChDisplayNm());
								//LOG.info("Display Name >>> "+ tempData.getDisplayNm());
								//LOG.info("lst New size after setting data >>> " + lstNew.size());
								objData.setMktNm(marketNameList); // Set Marketing Names
								objData.setTypeList(lstNew); // Set Option, Sub Type, Default
								//lst.clear();
								cfQlCompareDtLstFinal.add(objData);
								//LOG.info("New object added here "+cfQlCompareDtLstFinal.size());
								recordAdded = true;
							}
						} 
						
						if (count < marketNameList.size() && (x < dataLst.size() && !tempData.getConfOption().equalsIgnoreCase(nextOption)) && !recordAdded) {		
								count = 0;
								//LOG.info(" inside else cond count < marketNameList.size() ");
								List<PLMCFQLCompareData> lstNew = new ArrayList<PLMCFQLCompareData>();
								for (int i = 0; i < marketNameList.size(); i++) {
									boolean matchFound = false;
									PLMCFQLCompareData objTypeDataNew =new PLMCFQLCompareData();
									for (int j = 0; j < lst.size(); j++) {
										if (marketNameList.get(i).equalsIgnoreCase(lst.get(j).getHpMarketingNm())) {
											if ("3".equalsIgnoreCase(objData.getLevel())) {
												objTypeDataNew.setChDisplayNm(lst.get(j).getChDisplayNm());
												objTypeDataNew.setRevChapter(lst.get(j).getRevChapter());
												objTypeDataNew.setSubType(lst.get(j).getSubType());
												objTypeDataNew.setDefaultType(lst.get(j).getDefaultType());
											} else if ("2".equalsIgnoreCase(objData.getLevel())) {
												objTypeDataNew.setChDisplayNm("");
												objTypeDataNew.setRevChapter("");
												objTypeDataNew.setSubType("");
												objTypeDataNew.setDefaultType("");
											}
											objTypeDataNew.setMfChapter(lst.get(j).getMfChapter());
											objTypeDataNew.setSequenceNum(lst.get(j).getSequenceNum());
											objTypeDataNew.setHpMarketingNm(lst.get(j).getHpMarketingNm());
											objTypeDataNew.setAvailable(true);
											lstNew.add(objTypeDataNew);
											matchFound = true;
											//LOG.info("lst.get(j).getHpMarketingNm() >>> " + lst.get(j).getHpMarketingNm());
											break;
										} 
									}
									if (!matchFound) {
										//LOG.info("Match Not Found");
										objTypeDataNew.setHpMarketingNm(marketNameList.get(i));
										objTypeDataNew.setChDisplayNm("0");
										objTypeDataNew.setMfChapter("0");
										objTypeDataNew.setRevChapter("0");
										objTypeDataNew.setSubType("0");
										objTypeDataNew.setDefaultType("0");
										objTypeDataNew.setSequenceNum("0");
										objTypeDataNew.setAvailable(false);
										lstNew.add(objTypeDataNew);
										matchFound = false;
									}
								}
								//LOG.info("Chapter Disp Name >>> "+ tempData.getChDisplayNm());
								//LOG.info("Display Name >>> "+ tempData.getDisplayNm());
								//LOG.info("lst New size after setting data >>> " + lstNew.size());
								objData.setMktNm(marketNameList); // Set Marketing Names
								objData.setTypeList(lstNew); // Set Option, Sub Type, Default
								//lst.clear();
								cfQlCompareDtLstFinal.add(objData);
								//LOG.info("New object added here "+cfQlCompareDtLstFinal.size());
								recordAdded = true;
						}
						
						if (marketNameList.size() == 1) {
							count = 0;
							//LOG.info(" inside else cond marketNameList.size() == 1 ");
							//LOG.info("Chapter Disp Name >>> "+ tempData.getChDisplayNm());
							//LOG.info("Display Name >>> "+ tempData.getDisplayNm());
							//LOG.info("lst New size after setting data >>> " + lst.size());
							objData.setMktNm(marketNameList); // Set Marketing Names
							objData.setTypeList(lst); // Set Option, Sub Type, Default
							//lst.clear();
							cfQlCompareDtLstFinal.add(objData);
							//LOG.info("New object added here "+cfQlCompareDtLstFinal.size());
							recordAdded = true;
						}
					
					prevOption = tempData.getConfOption();
					prevHpMktNm = tempData.getHpMarketingNm();
				}
				
				if (count > 0 && cfQlCompareDtLstFinal.size() > 0) {
					
					count = 0;
					//LOG.info(" inside else cond count < marketNameList.size() ");
					List<PLMCFQLCompareData> lstNew = new ArrayList<PLMCFQLCompareData>();
					for (int i = 0; i < marketNameList.size(); i++) {
						boolean matchFound = false;
						PLMCFQLCompareData objTypeDataNew =new PLMCFQLCompareData();
						for (int j = 0; j < lst.size(); j++) {
							if (marketNameList.get(i).equalsIgnoreCase(lst.get(j).getHpMarketingNm())) {
								if ("3".equalsIgnoreCase(objData.getLevel())) {
									objTypeDataNew.setChDisplayNm(lst.get(j).getChDisplayNm());
									objTypeDataNew.setRevChapter(lst.get(j).getRevChapter());
									objTypeDataNew.setSubType(lst.get(j).getSubType());
									objTypeDataNew.setDefaultType(lst.get(j).getDefaultType());
								} else if ("2".equalsIgnoreCase(objData.getLevel())) {
									objTypeDataNew.setChDisplayNm("");
									objTypeDataNew.setRevChapter("");
									objTypeDataNew.setSubType("");
									objTypeDataNew.setDefaultType("");
								}
								objTypeDataNew.setMfChapter(lst.get(j).getMfChapter());
								objTypeDataNew.setSequenceNum(lst.get(j).getSequenceNum());
								objTypeDataNew.setHpMarketingNm(lst.get(j).getHpMarketingNm());
								objTypeDataNew.setAvailable(true);
								lstNew.add(objTypeDataNew);
								matchFound = true;
								//LOG.info("lst.get(j).getHpMarketingNm() >>> " + lst.get(j).getHpMarketingNm());
								break;
							} 
						}
						if (!matchFound) {
							//LOG.info("Match Not Found");
							objTypeDataNew.setHpMarketingNm(marketNameList.get(i));
							objTypeDataNew.setChDisplayNm("0");
							objTypeDataNew.setMfChapter("0");
							objTypeDataNew.setRevChapter("0");
							objTypeDataNew.setSubType("0");
							objTypeDataNew.setDefaultType("0");
							objTypeDataNew.setSequenceNum("0");
							objTypeDataNew.setAvailable(false);
							lstNew.add(objTypeDataNew);
							matchFound = false;
						}
					}
					//LOG.info("Chapter Disp Name >>> "+ tempData.getChDisplayNm());
					//LOG.info("Display Name >>> "+ tempData.getDisplayNm());
					//LOG.info("lst New size after setting data >>> " + lstNew.size());
					objData.setMktNm(marketNameList); // Set Marketing Names
					objData.setTypeList(lstNew); // Set Option, Sub Type, Default
					//lst.clear();
					cfQlCompareDtLstFinal.add(objData);
					//LOG.info("New object added here "+cfQlCompareDtLstFinal.size());
					recordAdded = true;
			
				}
			}
			
			cfQlCompareTreeMapFinal.put(0, marketNameList1);
			cfQlCompareTreeMapFinal.put(1, cfQlCompareDtLstFinal);
			//cfQlCompareTreeMapFinal.put(2, cfQlCompareList);
			cfQlCompareTreeMapFinal.put(2, marketNameList);
			cfQlCompareTreeMapFinal.put(3, mktMap1);
			
			//cfQlCompareList.clear();
			confFeautureDispNmMap.clear();
			
			LOG.info("List of getCFQLCompareRpt cfQlCompareDtLstFinal>>>> "+cfQlCompareDtLstFinal.size());
		}catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
			e.printStackTrace();
		}
		LOG.info("Exiting in to getCFQLCompareRpt");
		return cfQlCompareTreeMapFinal;
	}
	
	/**
	 * Row mapper for getting CfQlCompareMapper
	 */
	private static final class CfQlCompareMapper implements ParameterizedRowMapper<PLMCFQLCompareData>{	
	public PLMCFQLCompareData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMCFQLCompareData tempData = new PLMCFQLCompareData();
		
		tempData.setLevel(PLMUtils.checkNullVal(rs.getString("LVL")));
		tempData.setDisplayNm(PLMUtils.checkNullVal(rs.getString("DISPLAY_NAME")));
		tempData.setConfOption(PLMUtils.checkNullVal(rs.getString("CFGN_OPTION")));
		tempData.setRev(PLMUtils.checkNullVal(rs.getString("REVISION")));
		tempData.setPegasusCode(PLMUtils.checkNullVal(rs.getString("PEGASUS_CODE")));
		tempData.setHpMarketingNm(PLMUtils.checkNullVal(rs.getString("HP_MARKETING_NAME")));
		tempData.setChDisplayNm(PLMUtils.checkNullVal(rs.getString("CHAP_DISPLAY_NAME")));
		tempData.setMfChapter(PLMUtils.checkNullVal(rs.getString("MF_CHAPTER")));
		tempData.setRevChapter(PLMUtils.checkNullVal(rs.getString("REV_CHAPTER")));
		tempData.setSubType(PLMUtils.checkNullVal(rs.getString("GE_OPTION_SUB_TYPE")));
		tempData.setDefaultType(PLMUtils.checkNullVal(rs.getString("DEFAULT_SELECTION")));
		tempData.setSequenceNum(PLMUtils.checkNullVal(rs.getString("SEQUENCE_ORDER")));
		tempData.setObjType(PLMUtils.checkNullVal(rs.getString("OBJ_TYPE")));
		tempData.setHwPrdctNm(PLMUtils.checkNullVal(rs.getString("HARDWARE_PRODUCT")));
		tempData.setRevNm(PLMUtils.checkNullVal(rs.getString("HP_REV")));
		tempData.setProductType(PLMUtils.checkNullVal(rs.getString("PRODUCT")));
		tempData.setProductLine(PLMUtils.checkNullVal(rs.getString("PRODUCT_LINE")));
		tempData.setModel(PLMUtils.checkNullVal(rs.getString("MODEL")));
		tempData.setHpState(PLMUtils.checkNullVal(rs.getString("HP_STATE")));
		tempData.setVisitFlag(false);
		return tempData;
		}
	}
	
	/**
	 * This method is used to validate CF QL Compare Report
	 * 
	 * @param bulkHwPRdList
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getValidHardwrPrd(List<PLMCFQLCompareData> bulkHwPRdFinalList) throws PLMCommonException{
		LOG.info("Entering in to getValidHardwrPrd");
		String alertMsg="";
		int hrdWareCount=0;
		int hrdWareRevCount=0;
		try {
			for(int i=0;i<bulkHwPRdFinalList.size();i++){
				if(!PLMUtils.isEmpty(bulkHwPRdFinalList.get(i).getHwPrdctNm()) && !PLMUtils.isEmpty(bulkHwPRdFinalList.get(i).getRevNm())){
					hrdWareCount=0;
					hrdWareRevCount=0;
				    LOG.info("Executing Query for validing Hardware Product Name>>> "+PLMSearchQueries.GET_VALID_HARDWARE_NMS);
				    hrdWareCount = getJdbcTemplate().queryForInt(PLMSearchQueries.GET_VALID_HARDWARE_NMS, 
							new Object[] { bulkHwPRdFinalList.get(i).getHwPrdctNm()});
				    if(hrdWareCount==0){
				    	alertMsg = "HardWare Product Name of "+bulkHwPRdFinalList.get(i).getHwPrdctNm() +" does not exist";
				    	break;
				    }else{
				    LOG.info("Executing Query for Getting valid Parts>>> "+PLMSearchQueries.GET_COMBINATION_HARDWARE_REV);
				    hrdWareRevCount = getJdbcTemplate().queryForInt(PLMSearchQueries.GET_COMBINATION_HARDWARE_REV, 
							new Object[] { bulkHwPRdFinalList.get(i).getHwPrdctNm(),bulkHwPRdFinalList.get(i).getRevNm()});
				       if(hrdWareRevCount==0){
				    	alertMsg = "Combination of "+bulkHwPRdFinalList.get(i).getHwPrdctNm() +","+bulkHwPRdFinalList.get(i).getRevNm() +" does not exist";
				    	break;
				      }
				    }

				}
			}
		}catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting in to getValidHardwrPrd");
		return alertMsg;
	}
	
	/**
	 * This method is used to get CF QL Compare Report
	 * 
	 * @param bulkHwPRdList
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public TreeMap <Integer,Object>  getCFQLNonCompareRpt(List<PLMCFQLCompareData> bulkHwPRdFinalList) throws PLMCommonException{
		LOG.info("Entering in to getCFQLCompareRpt");
		List<PLMCFQLCompareData> cfQlCompareList =new ArrayList<PLMCFQLCompareData>();
		StringBuffer searchQuery = new StringBuffer();
		StringBuffer appendFilter = new StringBuffer();
		boolean whereFlag=false;
		TreeMap <Integer,Object> cfQlCompareTreeMapFinal = new TreeMap<Integer,Object>();
		try {
			for(int i=0;i<bulkHwPRdFinalList.size();i++){
				if(!PLMUtils.isEmpty(bulkHwPRdFinalList.get(i).getHwPrdctNm()) && !PLMUtils.isEmpty(bulkHwPRdFinalList.get(i).getRevNm())){
					if(!whereFlag){
						appendFilter.append(" WHERE( ");
						whereFlag=true;
					}else{
						appendFilter.append(" OR ");
					}
					appendFilter.append("(HW_PRDT.NM ='"+bulkHwPRdFinalList.get(i).getHwPrdctNm()+"'");
					appendFilter.append(" AND HW_PRDT.REVISION ='"+bulkHwPRdFinalList.get(i).getRevNm()+"')");
				}
			}
			appendFilter.append(")");
			
			searchQuery.append(PLMSearchQueries.GET_CF_QL1_COMPARE_DATA_ONE);
			searchQuery.append(appendFilter);
			searchQuery.append(PLMSearchQueries.GET_CF_QL1_COMPARE_DATA_TWO);
			searchQuery.append(appendFilter);
			searchQuery.append(PLMSearchQueries.GET_CF_QL1_COMPARE_DATA_FOUR);
			LOG.info("Executing Query for getCFQLCompareRpt >>> "+searchQuery);
			cfQlCompareList =getSimpleJdbcTemplate().query(searchQuery.toString(), new CfQlCompareMapper());
			LOG.info("cfQlCompareList size >>> "+cfQlCompareList.size());
			
			cfQlCompareTreeMapFinal.put(0, cfQlCompareList);
			
		}catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
			e.printStackTrace();
		}
		LOG.info("Exiting in to getCFQLCompareRpt");
		return cfQlCompareTreeMapFinal;
	}
	
	/**
	 * This method is used to validate Project Scorecard Report
	 * 
	 * @param pcNames
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getValidPCName(List<String> pcNamesList) throws PLMCommonException{
		LOG.info("Entering in to getValidPCName");
		String alertMsg="";
		int pcCount=0;
		try {
			for(int i=0;i<pcNamesList.size();i++){
				if(!PLMUtils.isEmpty(pcNamesList.get(i))){
					pcCount=0;
				    LOG.info("Executing Query for validing PC Name>>> "+PLMSearchQueries.GET_VALID_PC_NMS);
				    pcCount = getJdbcTemplate().queryForInt(PLMSearchQueries.GET_VALID_PC_NMS, 
							new Object[] { pcNamesList.get(i)});
				    if(pcCount==0){
				    	alertMsg = "PC Name of "+pcNamesList.get(i) +" does not exist";
				    	break;
				    }
				}
			}
		}catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting in to getValidPCName");
		return alertMsg;
	}
	
	/**
	 * This method is used to get Project Scorecard Report
	 * 
	 * @param prjSCFinalList
	 * @return List
	 * @throws PLMCommonException
	 */
	public TreeMap <Integer,Object>  getPrjScorecardData(List<String> prjSCFinalList) throws PLMCommonException {
		LOG.info("Entering in to getPrjScorecardData");
		List<PLMCFQLCompareData> prjSCList =new ArrayList<PLMCFQLCompareData>();
		StringBuffer searchQuery = new StringBuffer();
		StringBuffer appendFilter = new StringBuffer();
		StringBuffer appendHpPc=new StringBuffer();
		TreeMap <Integer,Object> cfQlCompareTreeMapFinal = new TreeMap<Integer,Object>();
		String timeStamp = PLMUtils.volTableFormatDate();
		try {
			appendFilter.append("(");
			for(int i=0;i<prjSCFinalList.size();i++){
				if(!PLMUtils.isEmpty(prjSCFinalList.get(i))){
					appendFilter.append("'").append(prjSCFinalList.get(i)).append("',");
				}
			}
			if (appendFilter.length() > 1) {
				appendFilter.delete(appendFilter.length()-1, appendFilter.length());
			}
			appendFilter.append(")");
			
			
			
			String VT_GET_CRS = PLMConstants.VT_GET_CRS.concat(timeStamp);
			String sql = (PLMSearchQueries.CREATE_VT_GET_CRS).replace("#", appendFilter).replace(PLMConstants.VT_GET_CRS, VT_GET_CRS);
			LOG.info("Executing for CREATE_VT_GET_CRS Query : " + sql);
			getJdbcTemplate().execute(sql);
			
			String VT_CR_DATA = PLMConstants.VT_CR_DATA.concat(timeStamp);
			sql = (PLMSearchQueries.CREATE_VT_CR_DATA).replace("#", appendFilter).replace(PLMConstants.VT_GET_CRS, VT_GET_CRS)
					.replace(PLMConstants.VT_CR_DATA, VT_CR_DATA);
			LOG.info("Executing for CREATE_VT_CR_DATA Query : " + sql);
			getJdbcTemplate().execute(sql);
			
			List<PLMCFQLCompareData> hpDataList = new ArrayList<PLMCFQLCompareData>();
		//	String hpName = "";
			//String hpRev = "";
			//List<String>hpNameList=new ArrayList<String>();
			//List<String>hpRevList=new ArrayList<String>();
		/*	if (!PLMUtils.isEmptyList(prjSCFinalList)) {
				sql = (PLMSearchQueries.GET_HP_NAME +"('" + prjSCFinalList.get(0) +"')").replace(PLMConstants.VT_GET_CRS, VT_GET_CRS);
				LOG.info("Executing for GET_HP_NAME Query : " + sql);
				hpDataList = getSimpleJdbcTemplate().query(sql, new HPDataMapper());
				if (!PLMUtils.isEmptyList(hpDataList) && hpDataList.size() > 0) {
					hpName = hpDataList.get(0).getHwPrdctNm();
					hpRev = hpDataList.get(0).getRevNm();
				}
				LOG.info("hpData for first Input PC Name >>>> "+ hpName + " ---- " + hpRev);
			}*/
			
		if (!PLMUtils.isEmptyList(prjSCFinalList)) {
				
				appendHpPc.append("(");
				for(int i=0;i<prjSCFinalList.size();i++){
					if(!PLMUtils.isEmpty(prjSCFinalList.get(i))){
						appendHpPc.append("'").append(prjSCFinalList.get(i)).append("',");
					}
				}
				if (appendHpPc.length() > 1) {
					appendHpPc.delete(appendFilter.length()-1, appendFilter.length());
				}
				appendHpPc.append(")");
				
				sql = (PLMSearchQueries.GET_HP_NAME +appendHpPc).replace(PLMConstants.VT_GET_CRS, VT_GET_CRS);
				LOG.info("Executing for GET_HP_NAME Query : " + sql);
				hpDataList = getSimpleJdbcTemplate().query(sql, new HPDataMapper());
	
		}
			
		searchQuery.append(PLMSearchQueries.GET_PRJSC_DATA1);	
		if (!PLMUtils.isEmptyList(hpDataList)) {
			searchQuery.append(" WHERE (");
			for(int i=0;i<hpDataList.size();i++){
				if(i>0){
					searchQuery.append(" OR ");
				}
				searchQuery.append("( HW_PRDT.NM = '").append(hpDataList.get(i).getHwPrdctNm()).append("' AND HW_PRDT.REVISION = '").append(hpDataList.get(i).getRevNm()).append("' )");
			}
			searchQuery.append(")");
			
		}
			
		LOG.info("Executing for GET_HP_NAME Query : " + searchQuery);
		
		//	searchQuery.append(" WHERE HW_PRDT.NM = '").append(hpName).append("' AND HW_PRDT.REVISION = '").append(hpRev).append("' ");
			//searchQuery.append(" OR HW_PRDT.NM = '").append(hpName).append("' AND HW_PRDT.REVISION = '").append(hpRev).append("' ");
			searchQuery.append(PLMSearchQueries.GET_PRJSC_DATA2);
			searchQuery.append(appendFilter);
			searchQuery.append(PLMSearchQueries.GET_PRJSC_DATA3);
			if (!PLMUtils.isEmptyList(hpDataList)) {
				searchQuery.append(" WHERE (");
				for(int i=0;i<hpDataList.size();i++){
					if(i>0){
						searchQuery.append(" OR ");
					}
					searchQuery.append("( HW_PRDT.NM = '").append(hpDataList.get(i).getHwPrdctNm()).append("' AND HW_PRDT.REVISION = '").append(hpDataList.get(i).getRevNm()).append("' )");
					
				}
				searchQuery.append(")");
				
			}
			
			
			
			
		//	searchQuery.append(" WHERE HW_PRDT.NM = '").append(hpName).append("' AND HW_PRDT.REVISION = '").append(hpRev).append("' ");
			searchQuery.append(PLMSearchQueries.GET_PRJSC_DATA4);
			sql = searchQuery.toString().replace(PLMConstants.VT_CR_DATA, VT_CR_DATA);
			LOG.info("Executing Query for getPrjScorecardData >>> "+searchQuery);
			prjSCList =getSimpleJdbcTemplate().query(sql, new PrjScorecardMapper());
			 LOG.info("prjSCList size >>> "+prjSCList.size());
			List<String> marketNameList = new ArrayList<String>();
			List<String> marketNameList1 = new ArrayList<String>();
			
			HashMap<String, String> mktMap = new HashMap<String, String>();
			HashMap<String, String> mktMap1 = new HashMap<String, String>();
			 Map<String, List<PLMCFQLCompareData>> confFeautureDispNmMap =new LinkedHashMap<String, List<PLMCFQLCompareData>>();
			 List<PLMCFQLCompareData> displayNmList =new ArrayList<PLMCFQLCompareData>();
			 //String prevHpMktNm = "";
			 String prevOption = " ";
			 String prevChapterDispNm = "";
			 // Loop to get unique list of marketing Names & Conf Options (with list of chapters connected to it)
			 for(PLMCFQLCompareData fetchData :prjSCList){
				  mktMap.put(fetchData.getHpMarketingNm(), "");
				  mktMap1.put(fetchData.getHpMarketingNm()  + " " + fetchData.getHwPrdctNm(), "");
				  if ("".equalsIgnoreCase(prevChapterDispNm)) {
					  prevChapterDispNm = fetchData.getChDisplayNm();
				  }
				  if (prevChapterDispNm.equalsIgnoreCase(fetchData.getChDisplayNm())) {
					  displayNmList.add(fetchData);
				  } else if (!prevChapterDispNm.equalsIgnoreCase(fetchData.getChDisplayNm())) {
					  confFeautureDispNmMap.put(prevChapterDispNm, displayNmList);
					  //LOG.info("Add list of objects to map for chapter >>>> " + prevChapterDispNm + " >>> "+ displayNmList.size());
					  displayNmList =new ArrayList<PLMCFQLCompareData>();
					  displayNmList.add(fetchData);
				  }
				  prevChapterDispNm = fetchData.getChDisplayNm();
			 }
			 
			 if (confFeautureDispNmMap.size() > 0) {
				 confFeautureDispNmMap.put(prevChapterDispNm, displayNmList);
			 }
			 marketNameList.addAll(mktMap.keySet());
			 marketNameList1.addAll(mktMap1.keySet());
			 
			 LOG.info("Unique List of Marketing Names: " + marketNameList);
			 LOG.info("Unique List of Marketing Names1: " + marketNameList1);
			 LOG.info("Unique List of Display Names: " + confFeautureDispNmMap.size());
			
			List<PLMCFQLCompareData> cfQlCompareDtLstFinal = new ArrayList<PLMCFQLCompareData>();

			PLMCFQLCompareData objData =new PLMCFQLCompareData();
			String prevLvl="";
			
			//Iterator entries = confFeautureDispNmMap.entrySet().iterator();
			//while (entries.hasNext()){
			//	Entry thisEntry = (Entry) entries.next();
			//	String key = (String) thisEntry.getKey();
			//	List<PLMCFQLCompareData> dataLst = (ArrayList<PLMCFQLCompareData>)thisEntry.getValue();
				//LOG.info("Inside while loop" + dataLst.size() + "  key name >>>>> " + key);
				boolean recordAdded = false;
				String[] pcArray = new String[prjSCFinalList.size()];
				String[] crArray = new String[prjSCFinalList.size()];
				PLMCFQLCompareData tempData = new PLMCFQLCompareData();
				
				for (int x = 0; x < prjSCList.size(); x++) {
					tempData = (PLMCFQLCompareData) prjSCList.get(x);
					
					if ("2".equalsIgnoreCase(tempData.getLevel())) {
						
						if ("3".equalsIgnoreCase(prevLvl)) {
							//LOG.info("Inside IF cond add level 3 obj at level 2 >>>>> "+ tempData.getConfOption());
							//LOG.info("pcArray >>>> "+ pcArray.toString());
							//LOG.info("crArray >>>> "+ crArray.toString());
							objData.setPcChkList(pcArray);
							objData.setCrValList(crArray);
							cfQlCompareDtLstFinal.add(objData);
							recordAdded = true;
						} 
						
						//LOG.info("Inside IF cond level 2 >>>>> "+ tempData.getConfOption());
						objData =new PLMCFQLCompareData();
						pcArray = new String[prjSCFinalList.size()];
						crArray = new String[prjSCFinalList.size()];
						objData.setLevel(tempData.getLevel());
						objData.setDisplayNm(tempData.getDisplayNm());
						objData.setConfOption(tempData.getConfOption());
						objData.setRev(tempData.getRev());
						objData.setPegasusCode(tempData.getPegasusCode());
						objData.setHpMarketingNm(tempData.getHpMarketingNm());
						objData.setChDisplayNm(tempData.getChDisplayNm());
						objData.setMfChapter(tempData.getMfChapter());
						objData.setRevChapter(tempData.getRevChapter());
						objData.setSubType(tempData.getSubType());
						objData.setDefaultType(tempData.getDefaultType());
						objData.setSequenceNum(tempData.getSequenceNum());
						objData.setHwPrdctNm(tempData.getHwPrdctNm());
						
						objData.setChDisplayNm("");
						objData.setRevChapter("");
						objData.setSubType("");
						objData.setDefaultType("");
						
						objData.setPcChkList(pcArray);
						objData.setCrValList(crArray);	
						
						objData.setAvailable(true);
						cfQlCompareDtLstFinal.add(objData);
						recordAdded = true;
						prevLvl = tempData.getLevel();
					} else if ("3".equalsIgnoreCase(tempData.getLevel())) {
						//LOG.info("Inside IF cond level 3 >>>>> "+ tempData.getConfOption() + "  record Added >>>> "+ recordAdded);
							
							if (!prevOption.equalsIgnoreCase(tempData.getConfOption())) {
								
								if (!recordAdded) {
									//LOG.info("Inside IF cond add obj at level 3 >>>>> "+ tempData.getConfOption());
									//LOG.info("pcArray >>>> "+ pcArray.toString());
									//LOG.info("crArray >>>> "+ crArray.toString());
									objData.setPcChkList(pcArray);
									objData.setCrValList(crArray);
									cfQlCompareDtLstFinal.add(objData);
									recordAdded = true;
								} 
									
								objData = new PLMCFQLCompareData();
								pcArray = new String[prjSCFinalList.size()];
								crArray = new String[prjSCFinalList.size()];
								
								objData.setLevel(tempData.getLevel());
								objData.setDisplayNm(tempData.getDisplayNm());
								objData.setConfOption(tempData.getConfOption());
								objData.setRev(tempData.getRev());
								objData.setPegasusCode(tempData.getPegasusCode());
								objData.setHpMarketingNm(tempData.getHpMarketingNm());
								objData.setChDisplayNm(tempData.getChDisplayNm());
								objData.setMfChapter(tempData.getMfChapter());
								objData.setRevChapter(tempData.getRevChapter());
								objData.setSubType(tempData.getSubType());
								objData.setDefaultType(tempData.getDefaultType());
								objData.setSequenceNum(tempData.getSequenceNum());
								objData.setHwPrdctNm(tempData.getHwPrdctNm());
								objData.setChDisplayNm(tempData.getChDisplayNm());
								objData.setRevChapter(tempData.getRevChapter());
								objData.setSubType(tempData.getSubType());
								objData.setDefaultType(tempData.getDefaultType());
								
								objData.setAvailable(true);
								recordAdded = false;
								
						} else {
							recordAdded = false;
						}
						
						for (int i = 0; i < prjSCFinalList.size(); i++) {
							if (prjSCFinalList.get(i).equalsIgnoreCase(tempData.getPcName())) {
								pcArray[i] = "X";
								crArray[i] = tempData.getCrName();
								break;
							}
						}
						prevOption = tempData.getConfOption();
						prevLvl = tempData.getLevel();
					}
					
				}
			
				
			if (!recordAdded && prjSCList.size() > 0) {
				//LOG.info("Inside IF cond add obj at level 3 >>>>> "+ tempData.getConfOption());
				//LOG.info("pcArray >>>> "+ pcArray.toString());
				//LOG.info("crArray >>>> "+ crArray.toString());
				objData.setPcChkList(pcArray);
				objData.setCrValList(crArray);
				cfQlCompareDtLstFinal.add(objData);
				recordAdded = true;
			} 
				
			cfQlCompareTreeMapFinal.put(0, marketNameList1);
			cfQlCompareTreeMapFinal.put(1, cfQlCompareDtLstFinal);
			//cfQlCompareList.clear();
			//confFeautureDispNmMap.clear();
			
			LOG.info("List of getPrjScorecardData cfQlCompareDtLstFinal>>>> "+cfQlCompareDtLstFinal.size());
		}catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
			e.printStackTrace();
		}
		LOG.info("Exiting in to getPrjScorecardData");
		return cfQlCompareTreeMapFinal;
	}
	
	/**
	 * Row mapper for getting HPDataMapper
	 */
	private static final class HPDataMapper implements ParameterizedRowMapper<PLMCFQLCompareData>{	
	public PLMCFQLCompareData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMCFQLCompareData tempData = new PLMCFQLCompareData();
		
		tempData.setHwPrdctNm(PLMUtils.checkNullVal(rs.getString("PLANT_HP")));
		tempData.setRevNm(PLMUtils.checkNullVal(rs.getString("PLANT_HP_REV")));
		return tempData;
		}
	}
	
	/**
	 * Row mapper for getting PrjScorecardMapper
	 */
	private static final class PrjScorecardMapper implements ParameterizedRowMapper<PLMCFQLCompareData>{	
	public PLMCFQLCompareData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMCFQLCompareData tempData = new PLMCFQLCompareData();
		
		tempData.setLevel(PLMUtils.checkNullVal(rs.getString("LVL")));
		tempData.setDisplayNm(PLMUtils.checkNullVal(rs.getString("DISPLAY_NAME")));
		tempData.setConfOption(PLMUtils.checkNullVal(rs.getString("CFGN_OPTION")));
		tempData.setRev(PLMUtils.checkNullVal(rs.getString("REVISION")));
		tempData.setPegasusCode(PLMUtils.checkNullVal(rs.getString("PEGASUS_CODE")));
		tempData.setHpMarketingNm(PLMUtils.checkNullVal(rs.getString("HP_MARKETING_NAME")));
		tempData.setChDisplayNm(PLMUtils.checkNullVal(rs.getString("CHAP_DISPLAY_NAME")));
		tempData.setMfChapter(PLMUtils.checkNullVal(rs.getString("MF_CHAPTER")));
		tempData.setRevChapter(PLMUtils.checkNullVal(rs.getString("REV_CHAPTER")));
		tempData.setSubType(PLMUtils.checkNullVal(rs.getString("GE_OPTION_SUB_TYPE")));
		tempData.setDefaultType(PLMUtils.checkNullVal(rs.getString("DEFAULT_SELECTION")));
		tempData.setSequenceNum(PLMUtils.checkNullVal(rs.getString("SEQUENCE_ORDER")));
		tempData.setObjType(PLMUtils.checkNullVal(rs.getString("OBJ_TYPE")));
		tempData.setHwPrdctNm(PLMUtils.checkNullVal(rs.getString("HARDWARE_PRODUCT")));
		tempData.setPcName(PLMUtils.checkNullVal(rs.getString("PC_NAME")));
		tempData.setCrName(PLMUtils.checkNullVal(rs.getString("CR_NAME")));
		//tempData.setRevNm(PLMUtils.checkNullVal(rs.getString("HP_REV")));
		//tempData.setProductType(PLMUtils.checkNullVal(rs.getString("PRODUCT")));
		//tempData.setProductLine(PLMUtils.checkNullVal(rs.getString("PRODUCT_LINE")));
		//tempData.setModel(PLMUtils.checkNullVal(rs.getString("MODEL")));
		//tempData.setHpState(PLMUtils.checkNullVal(rs.getString("HP_STATE")));
		tempData.setVisitFlag(false);
		return tempData;
		}
	}
}
