/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCRReportData.java
 * @Creation date: 12-Aug-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;
import java.util.List;

public class PLMCRReportData {
	/**
	 * Holds the crId
	 */
	private String crId;

	/**
	 * Holds the crName
	 */
	private String crName;
	/**
	 * Holds the crState
	 */
	private String crState;
	/**
	 * Holds the crOrigDt
	 */
	private String crOrigDt;
	/**
	 * Holds the coName
	 */
	private String coNameCst;
	/**
	 * Holds the pcName
	 */
	private String pcName;
	/**
	 * Holds the costGrp
	 */
	private String costGrp;
	/**
	 * Holds the originSSO
	 */
	private String originSSO;
	/**
	 * Holds the originNM
	 */
	private String originNM;
	/**
	 * Holds the ownerSSO
	 */
	private String ownerSSO;
	
	/**
	 * Holds the ownerNM
	 */
	private String ownerNM;
	
	/**
	 * Holds the crTitle
	 */
	private String crTitleCst;
	/**
	 * Holds the crDesc
	 */
	private String crDesc;
	
	/**
	 * Holds the contract
	 */
	private String contract;

	/**
	 * Holds the affectedMLI
	 */
	private String affectedMLI;

	/**
	 * Holds the enterpriseIdf
	 */
	private String enterpriseIdf;
	/**
	 * Holds the routeId
	 */
	private String routeId;
	
	/**
	 * Holds the routeName
	 */
	private String routeName;
	/**
	 * Holds the routeOwnSSO
	 */
	private String routeOwnSSO;
	/**
	 * Holds the routeDueDt
	 */
	private String routeDueDt;
	/**
	 * Holds the routeOrgDt
	 */
	private String routeOrgDt;

	/**
	 * Holds the routeState
	 */
	private String routeState;
	/**
	 * Holds the taskId
	 */
	private String taskId;
	/**
	 * Holds the taskName
	 */
	private String taskName;
	/**
	 * Holds the taskState
	 */
	private String taskState;
	
	/**
	 * Holds the taskOwnerSSO
	 */
	private String taskOwnerSSO;
	/**
	 * Holds the taskAprovStatus
	 */
	private String taskAprovStatus;
	/**
	 * Holds the taskDueDt
	 */
	private String taskDueDt;

	/**
	 * Holds the taskOrgDt
	 */
	private String taskOrgDt;

	/**
	 * Holds the taskCompleteDt
	 */
	private String taskCompleteDt;
	/**
	 * Holds the dispositionCmts
	 */
	private String dispositionCmts;

	
	/**
	 * Holds the allOpen
	 */
	private boolean allOpen;
	
	/**
	  * Holds the taskStateList
	  */
	private List<String> stateList;
	
	
	/**
	  * Holds the productList
	  */
	private List<String> productList;
	
	/**
	  * Holds the originFromDate
	  */
	private Date originFromDate;
	
	/**
	  * Holds the originToDate
	  */
	private Date originToDate;
	
	/**
	  * Holds the crOriginator
	  */
	private String crOriginator;
	/**
	  * Holds the crOwner
	  */
	private String crOwner;

	/**
	  * Holds the crTitleNm
	  */
	private String crTitleNm;

	/**
	  * Holds the crDescNm
	  */
	private String crDescNm;

	/**
	  * Holds the plmCntrIps
	  */
	private String plmCntrIps;
	/**
	  * Holds the project
	  */
	private String project;
	/**
	  * Holds the satisfyImpact
	  */
	private String satisfyImpact;
	/**
	  * Holds the accesstoAllObj
	  */
	private String accesstoAllObj;

	/**
	  * Holds the routeTaskFlg
	  */
	private boolean routeTaskFlg;
	
	/**
	 * Holds the contractDesc
	 */
	private String contractDesc;
	
	/**
	 * Holds the coState
	 */
	private String coState;
	
	/**
	 * Holds the crNumber
	 */
	private String crNumber;
	
	/**
	 * Holds the lfName
	 */
	private String lfName;
	/**
	 * Holds the lfRev
	 */
	private String lfRev;
	/**
	 * Holds the lfType
	 */
	private String lfType;
	/**
	 * Holds the tfMarketNm
	 */
	private String tfMarketNm;
	/**
	 * Holds the tfDesc
	 */
	private String tfDesc;
	/**
	 * Holds the cycleTimeDwgs
	 */
	private double cycleTimeDwgs;
	/**
	 * Holds the engHours
	 */
	private double engHours;
	/**
	 * Holds the drafHours
	 */
	private double drafHours;
	/**
	 * Holds the materialLeadTm
	 */
	private double materialLeadTm;
	/**
	 * Holds the shipDirectCst
	 */
	private double shipDirectCst;
	/**
	 * Holds the rawInProcessCst
	 */
	private double rawInProcessCst;
	/**
	 * Holds the appliedDirectLbr
	 */
	private double appliedDirectLbr;
	/**
	 * Holds the geShopWrkLab
	 */
	private double geShopWrkLab;
	/**
	 * Holds the partName
	 */
	private String partName;
	/**
	 * Holds the geTransportCst
	 */
	private double geTransportCst;
	/**
	 * Holds the geFieldInstalCst
	 */
	private double geFieldInstalCst;
	/**
	 * Holds the unitMeasure
	 */
	private String unitMeasure;
	/**
	 * Holds the productConf
	 */
	private String productConf;
	/**
	 * Holds the geMfgLbrHours
	 */
	private double geMfgLbrHours;
	/**
	 * Holds the enginerDisposition
	 */
	private String enginerDisposition;
	
	/**
	 * Holds the contractCrId
	 */
	private String contractCrId;
	
	/**
	 * Holds the contractCrId
	 */
	private int crLvl;
	/**
	 * Holds the contractCrId
	 */
	private String crLvlStr;
	
	/**
	 * @return the allOpen
	 */
	public boolean isAllOpen() {
		return allOpen;
	}
	/**
	 * @param allOpen the allOpen to set
	 */
	public void setAllOpen(boolean allOpen) {
		this.allOpen = allOpen;
	}
	/**
	 * @return the stateList
	 */
	public List<String> getStateList() {
		return stateList;
	}
	/**
	 * @param stateList the stateList to set
	 */
	public void setStateList(List<String> stateList) {
		this.stateList = stateList;
	}
	/**
	 * @return the productList
	 */
	public List<String> getProductList() {
		return productList;
	}
	/**
	 * @param productList the productList to set
	 */
	public void setProductList(List<String> productList) {
		this.productList = productList;
	}
	
	/**
	 * @return the crId
	 */
	public String getCrId() {
		return crId;
	}
	/**
	 * @param crId the crId to set
	 */
	public void setCrId(String crId) {
		this.crId = crId;
	}
	/**
	 * @return the crName
	 */
	public String getCrName() {
		return crName;
	}
	/**
	 * @param crName the crName to set
	 */
	public void setCrName(String crName) {
		this.crName = crName;
	}
	/**
	 * @return the crState
	 */
	public String getCrState() {
		return crState;
	}
	/**
	 * @param crState the crState to set
	 */
	public void setCrState(String crState) {
		this.crState = crState;
	}
	/**
	 * @return the crOrigDt
	 */
	public String getCrOrigDt() {
		return crOrigDt;
	}
	/**
	 * @param crOrigDt the crOrigDt to set
	 */
	public void setCrOrigDt(String crOrigDt) {
		this.crOrigDt = crOrigDt;
	}
	/**
	 * @return the coName
	 */
	/*public String getCoName() {
		return coName;
	}*/
	/**
	 * @param coName the coName to set
	 */
	/*public void setCoName(String coName) {
		this.coName = coName;
	}*/
	/**
	 * @return the coNameCst
	 */
	public String getCoNameCst() {
		return coNameCst;
	}
	/**
	 * @param coNameCst the coNameCst to set
	 */
	public void setCoNameCst(String coNameCst) {
		this.coNameCst = coNameCst;
	}
	/**
	 * @return the pcName
	 */
	public String getPcName() {
		return pcName;
	}
	/**
	 * @param pcName the pcName to set
	 */
	public void setPcName(String pcName) {
		this.pcName = pcName;
	}
	/**
	 * @return the costGrp
	 */
	public String getCostGrp() {
		return costGrp;
	}
	/**
	 * @param costGrp the costGrp to set
	 */
	public void setCostGrp(String costGrp) {
		this.costGrp = costGrp;
	}
	/**
	 * @return the originSSO
	 */
	public String getOriginSSO() {
		return originSSO;
	}
	/**
	 * @param originSSO the originSSO to set
	 */
	public void setOriginSSO(String originSSO) {
		this.originSSO = originSSO;
	}
	/**
	 * @return the originNM
	 */
	public String getOriginNM() {
		return originNM;
	}
	/**
	 * @param originNM the originNM to set
	 */
	public void setOriginNM(String originNM) {
		this.originNM = originNM;
	}
	/**
	 * @return the ownerSSO
	 */
	public String getOwnerSSO() {
		return ownerSSO;
	}
	/**
	 * @param ownerSSO the ownerSSO to set
	 */
	public void setOwnerSSO(String ownerSSO) {
		this.ownerSSO = ownerSSO;
	}
	/**
	 * @return the ownerNM
	 */
	public String getOwnerNM() {
		return ownerNM;
	}
	/**
	 * @param ownerNM the ownerNM to set
	 */
	public void setOwnerNM(String ownerNM) {
		this.ownerNM = ownerNM;
	}
	/**
	 * @return the crTitle
	 */
	public String getCrTitleCst() {
		return crTitleCst;
	}
	/**
	 * @param crTitle the crTitle to set
	 */
	public void setCrTitleCst(String crTitleCst) {
		this.crTitleCst = crTitleCst;
	}
	/**
	 * @return the crDesc
	 */
	public String getCrDesc() {
		return crDesc;
	}
	/**
	 * @param crDesc the crDesc to set
	 */
	public void setCrDesc(String crDesc) {
		this.crDesc = crDesc;
	}
	/**
	 * @return the contract
	 */
	public String getContract() {
		return contract;
	}
	/**
	 * @param contract the contract to set
	 */
	public void setContract(String contract) {
		this.contract = contract;
	}
	/**
	 * @return the affectedMLI
	 */
	public String getAffectedMLI() {
		return affectedMLI;
	}
	/**
	 * @param affectedMLI the affectedMLI to set
	 */
	public void setAffectedMLI(String affectedMLI) {
		this.affectedMLI = affectedMLI;
	}
	/**
	 * @return the enterpriseIdf
	 */
	public String getEnterpriseIdf() {
		return enterpriseIdf;
	}
	/**
	 * @param enterpriseIdf the enterpriseIdf to set
	 */
	public void setEnterpriseIdf(String enterpriseIdf) {
		this.enterpriseIdf = enterpriseIdf;
	}
	/**
	 * @return the routeId
	 */
	public String getRouteId() {
		return routeId;
	}
	/**
	 * @param routeId the routeId to set
	 */
	public void setRouteId(String routeId) {
		this.routeId = routeId;
	}
	/**
	 * @return the routeName
	 */
	public String getRouteName() {
		return routeName;
	}
	/**
	 * @param routeName the routeName to set
	 */
	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}
	/**
	 * @return the routeOwnSSO
	 */
	public String getRouteOwnSSO() {
		return routeOwnSSO;
	}
	/**
	 * @param routeOwnSSO the routeOwnSSO to set
	 */
	public void setRouteOwnSSO(String routeOwnSSO) {
		this.routeOwnSSO = routeOwnSSO;
	}
	/**
	 * @return the routeDueDt
	 */
	public String getRouteDueDt() {
		return routeDueDt;
	}
	/**
	 * @param routeDueDt the routeDueDt to set
	 */
	public void setRouteDueDt(String routeDueDt) {
		this.routeDueDt = routeDueDt;
	}
	/**
	 * @return the routeOrgDt
	 */
	public String getRouteOrgDt() {
		return routeOrgDt;
	}
	/**
	 * @param routeOrgDt the routeOrgDt to set
	 */
	public void setRouteOrgDt(String routeOrgDt) {
		this.routeOrgDt = routeOrgDt;
	}
	/**
	 * @return the routeState
	 */
	public String getRouteState() {
		return routeState;
	}
	/**
	 * @param routeState the routeState to set
	 */
	public void setRouteState(String routeState) {
		this.routeState = routeState;
	}
	/**
	 * @return the taskId
	 */
	public String getTaskId() {
		return taskId;
	}
	/**
	 * @param taskId the taskId to set
	 */
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	/**
	 * @return the taskName
	 */
	public String getTaskName() {
		return taskName;
	}
	/**
	 * @param taskName the taskName to set
	 */
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	/**
	 * @return the taskState
	 */
	public String getTaskState() {
		return taskState;
	}
	/**
	 * @param taskState the taskState to set
	 */
	public void setTaskState(String taskState) {
		this.taskState = taskState;
	}
	/**
	 * @return the taskOwnerSSO
	 */
	public String getTaskOwnerSSO() {
		return taskOwnerSSO;
	}
	/**
	 * @param taskOwnerSSO the taskOwnerSSO to set
	 */
	public void setTaskOwnerSSO(String taskOwnerSSO) {
		this.taskOwnerSSO = taskOwnerSSO;
	}
	/**
	 * @return the taskAprovStatus
	 */
	public String getTaskAprovStatus() {
		return taskAprovStatus;
	}
	/**
	 * @param taskAprovStatus the taskAprovStatus to set
	 */
	public void setTaskAprovStatus(String taskAprovStatus) {
		this.taskAprovStatus = taskAprovStatus;
	}
	/**
	 * @return the taskDueDt
	 */
	public String getTaskDueDt() {
		return taskDueDt;
	}
	/**
	 * @param taskDueDt the taskDueDt to set
	 */
	public void setTaskDueDt(String taskDueDt) {
		this.taskDueDt = taskDueDt;
	}
	/**
	 * @return the taskOrgDt
	 */
	public String getTaskOrgDt() {
		return taskOrgDt;
	}
	/**
	 * @param taskOrgDt the taskOrgDt to set
	 */
	public void setTaskOrgDt(String taskOrgDt) {
		this.taskOrgDt = taskOrgDt;
	}
	/**
	 * @return the taskCompleteDt
	 */
	public String getTaskCompleteDt() {
		return taskCompleteDt;
	}
	/**
	 * @param taskCompleteDt the taskCompleteDt to set
	 */
	public void setTaskCompleteDt(String taskCompleteDt) {
		this.taskCompleteDt = taskCompleteDt;
	}
	/**
	 * @return the dispositionCmts
	 */
	public String getDispositionCmts() {
		return dispositionCmts;
	}
	/**
	 * @param dispositionCmts the dispositionCmts to set
	 */
	public void setDispositionCmts(String dispositionCmts) {
		this.dispositionCmts = dispositionCmts;
	}
	/**
	 * @return the originFromDate
	 */
	public Date getOriginFromDate() {
		Date origFrmDt= originFromDate;
		return origFrmDt;
	}
	/**
	 * @param originFromDate the originFromDate to set
	 */
	public void setOriginFromDate(Date originFromDate) {
		Date origFrmDt= originFromDate;
		this.originFromDate = origFrmDt;
	}
	/**
	 * @return the originToDate
	 */
	public Date getOriginToDate() {
		Date origToDt= originToDate;
		return origToDt;
	}
	/**
	 * @param originToDate the originToDate to set
	 */
	public void setOriginToDate(Date originToDate) {
		Date origToDt= originToDate;
		this.originToDate = origToDt;
	}
	/**
	 * @return the crOriginator
	 */
	public String getCrOriginator() {
		return crOriginator;
	}
	/**
	 * @param crOriginator the crOriginator to set
	 */
	public void setCrOriginator(String crOriginator) {
		this.crOriginator = crOriginator;
	}
	/**
	 * @return the crOwner
	 */
	public String getCrOwner() {
		return crOwner;
	}
	/**
	 * @param crOwner the crOwner to set
	 */
	public void setCrOwner(String crOwner) {
		this.crOwner = crOwner;
	}
	/**
	 * @return the crTitleNm
	 */
	public String getCrTitleNm() {
		return crTitleNm;
	}
	/**
	 * @param crTitleNm the crTitleNm to set
	 */
	public void setCrTitleNm(String crTitleNm) {
		this.crTitleNm = crTitleNm;
	}
	/**
	 * @return the crDescNm
	 */
	public String getCrDescNm() {
		return crDescNm;
	}
	/**
	 * @param crDescNm the crDescNm to set
	 */
	public void setCrDescNm(String crDescNm) {
		this.crDescNm = crDescNm;
	}
	/**
	 * @return the plmCntrIps
	 */
	public String getPlmCntrIps() {
		return plmCntrIps;
	}
	/**
	 * @param plmCntrIps the plmCntrIps to set
	 */
	public void setPlmCntrIps(String plmCntrIps) {
		this.plmCntrIps = plmCntrIps;
	}
	/**
	 * @return the project
	 */
	public String getProject() {
		return project;
	}
	/**
	 * @param project the project to set
	 */
	public void setProject(String project) {
		this.project = project;
	}
	/**
	 * @return the satisfyImpact
	 */
	public String getSatisfyImpact() {
		return satisfyImpact;
	}
	/**
	 * @param satisfyImpact the satisfyImpact to set
	 */
	public void setSatisfyImpact(String satisfyImpact) {
		this.satisfyImpact = satisfyImpact;
	}
	/**
	 * @return the accesstoAllObj
	 */
	public String getAccesstoAllObj() {
		return accesstoAllObj;
	}
	/**
	 * @param accesstoAllObj the accesstoAllObj to set
	 */
	public void setAccesstoAllObj(String accesstoAllObj) {
		this.accesstoAllObj = accesstoAllObj;
	}
	/**
	 * @return the routeTaskFlg
	 */
	public boolean isRouteTaskFlg() {
		return routeTaskFlg;
	}
	/**
	 * @param routeTaskFlg the routeTaskFlg to set
	 */
	public void setRouteTaskFlg(boolean routeTaskFlg) {
		this.routeTaskFlg = routeTaskFlg;
	}
	/**
	 * @return the contractDesc
	 */
	public String getContractDesc() {
		return contractDesc;
	}
	/**
	 * @param contractDesc the contractDesc to set
	 */
	public void setContractDesc(String contractDesc) {
		this.contractDesc = contractDesc;
	}
	/**
	 * @return the coState
	 */
	public String getCoState() {
		return coState;
	}
	/**
	 * @param coState the coState to set
	 */
	public void setCoState(String coState) {
		this.coState = coState;
	}
	/**
	 * @return the crNumber
	 */
	public String getCrNumber() {
		return crNumber;
	}
	/**
	 * @param crNumber the crNumber to set
	 */
	public void setCrNumber(String crNumber) {
		this.crNumber = crNumber;
	}
	/**
	 * @return the lfName
	 */
	public String getLfName() {
		return lfName;
	}
	/**
	 * @param lfName the lfName to set
	 */
	public void setLfName(String lfName) {
		this.lfName = lfName;
	}
	/**
	 * @return the lfRev
	 */
	public String getLfRev() {
		return lfRev;
	}
	/**
	 * @param lfRev the lfRev to set
	 */
	public void setLfRev(String lfRev) {
		this.lfRev = lfRev;
	}
	/**
	 * @return the lfType
	 */
	public String getLfType() {
		return lfType;
	}
	/**
	 * @param lfType the lfType to set
	 */
	public void setLfType(String lfType) {
		this.lfType = lfType;
	}
	/**
	 * @return the tfMarketNm
	 */
	public String getTfMarketNm() {
		return tfMarketNm;
	}
	/**
	 * @param tfMarketNm the tfMarketNm to set
	 */
	public void setTfMarketNm(String tfMarketNm) {
		this.tfMarketNm = tfMarketNm;
	}
	/**
	 * @return the tfDesc
	 */
	public String gettfDesc() {
		return tfDesc;
	}
	/**
	 * @param tfDesc the tfDesc to set
	 */
	public void setTfDesc(String tfDesc) {
		this.tfDesc = tfDesc;
	}
	
	/**
	 * @return the tfDesc
	 */
	public String getTfDesc() {
		return tfDesc;
	}
	/**
	 * @return the cycleTimeDwgs
	 */
	public double getCycleTimeDwgs() {
		return cycleTimeDwgs;
	}
	/**
	 * @param cycleTimeDwgs the cycleTimeDwgs to set
	 */
	public void setCycleTimeDwgs(double cycleTimeDwgs) {
		this.cycleTimeDwgs = cycleTimeDwgs;
	}
	/**
	 * @return the engHours
	 */
	public double getEngHours() {
		return engHours;
	}
	/**
	 * @param engHours the engHours to set
	 */
	public void setEngHours(double engHours) {
		this.engHours = engHours;
	}
	/**
	 * @return the drafHours
	 */
	public double getDrafHours() {
		return drafHours;
	}
	/**
	 * @param drafHours the drafHours to set
	 */
	public void setDrafHours(double drafHours) {
		this.drafHours = drafHours;
	}
	/**
	 * @return the materialLeadTm
	 */
	public double getMaterialLeadTm() {
		return materialLeadTm;
	}
	/**
	 * @param materialLeadTm the materialLeadTm to set
	 */
	public void setMaterialLeadTm(double materialLeadTm) {
		this.materialLeadTm = materialLeadTm;
	}
	/**
	 * @return the shipDirectCst
	 */
	public double getShipDirectCst() {
		return shipDirectCst;
	}
	/**
	 * @param shipDirectCst the shipDirectCst to set
	 */
	public void setShipDirectCst(double shipDirectCst) {
		this.shipDirectCst = shipDirectCst;
	}
	/**
	 * @return the rawInProcessCst
	 */
	public double getRawInProcessCst() {
		return rawInProcessCst;
	}
	/**
	 * @param rawInProcessCst the rawInProcessCst to set
	 */
	public void setRawInProcessCst(double rawInProcessCst) {
		this.rawInProcessCst = rawInProcessCst;
	}
	/**
	 * @return the appliedDirectLbr
	 */
	public double getAppliedDirectLbr() {
		return appliedDirectLbr;
	}
	/**
	 * @param appliedDirectLbr the appliedDirectLbr to set
	 */
	public void setAppliedDirectLbr(double appliedDirectLbr) {
		this.appliedDirectLbr = appliedDirectLbr;
	}
	/**
	 * @return the geShopWrkLab
	 */
	public double getGeShopWrkLab() {
		return geShopWrkLab;
	}
	/**
	 * @param geShopWrkLab the geShopWrkLab to set
	 */
	public void setGeShopWrkLab(double geShopWrkLab) {
		this.geShopWrkLab = geShopWrkLab;
	}
	/**
	 * @return the partName
	 */
	public String getPartName() {
		return partName;
	}
	/**
	 * @param partName the partName to set
	 */
	public void setPartName(String partName) {
		this.partName = partName;
	}
	/**
	 * @return the geTransportCst
	 */
	public double getGeTransportCst() {
		return geTransportCst;
	}
	/**
	 * @param geTransportCst the geTransportCst to set
	 */
	public void setGeTransportCst(double geTransportCst) {
		this.geTransportCst = geTransportCst;
	}
	/**
	 * @return the geFieldInstalCst
	 */
	public double getGeFieldInstalCst() {
		return geFieldInstalCst;
	}
	/**
	 * @param geFieldInstalCst the geFieldInstalCst to set
	 */
	public void setGeFieldInstalCst(double geFieldInstalCst) {
		this.geFieldInstalCst = geFieldInstalCst;
	}
	/**
	 * @return the unitMeasure
	 */
	public String getUnitMeasure() {
		return unitMeasure;
	}
	/**
	 * @param unitMeasure the unitMeasure to set
	 */
	public void setUnitMeasure(String unitMeasure) {
		this.unitMeasure = unitMeasure;
	}
	/**
	 * @return the productConf
	 */
	public String getProductConf() {
		return productConf;
	}
	/**
	 * @param productConf the productConf to set
	 */
	public void setProductConf(String productConf) {
		this.productConf = productConf;
	}
	/**
	 * @return the geMfgLbrHours
	 */
	public double getGeMfgLbrHours() {
		return geMfgLbrHours;
	}
	/**
	 * @param geMfgLbrHours the geMfgLbrHours to set
	 */
	public void setGeMfgLbrHours(double geMfgLbrHours) {
		this.geMfgLbrHours = geMfgLbrHours;
	}
	/**
	 * @return the enginerDisposition
	 */
	public String getEnginerDisposition() {
		return enginerDisposition;
	}
	/**
	 * @param enginerDisposition the enginerDisposition to set
	 */
	public void setEnginerDisposition(String enginerDisposition) {
		this.enginerDisposition = enginerDisposition;
	}
	/**
	 * @return the contractCrId
	 */
	public String getContractCrId() {
		return contractCrId;
	}
	/**
	 * @param contractCrId the contractCrId to set
	 */
	public void setContractCrId(String contractCrId) {
		this.contractCrId = contractCrId;
	}
	/**
	 * @return the crLvl
	 */
	public int getCrLvl() {
		return crLvl;
	}
	/**
	 * @param crLvl the crLvl to set
	 */
	public void setCrLvl(int crLvl) {
		this.crLvl = crLvl;
	}
	/**
	 * @return the crLvlStr
	 */
	public String getCrLvlStr() {
		return crLvlStr;
	}
	/**
	 * @param crLvlStr the crLvlStr to set
	 */
	public void setCrLvlStr(String crLvlStr) {
		this.crLvlStr = crLvlStr;
	}
	
}
