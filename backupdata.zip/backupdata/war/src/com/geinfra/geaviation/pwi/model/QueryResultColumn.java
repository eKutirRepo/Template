package com.geinfra.geaviation.pwi.model;

/**
* Project        :   Product Lifecycle Management
* Date Written   :   Jan 25, 2011
* Security       :   GE Confidential
* Restrictions   :   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
* Copyright(C) 2011 GE 
* All rights reserved
*
* Description    :  QueryResultColumn - value object from service tier
*
* Revision Log Jan 25, 2011 | v1.0.
* --------------------------------------------------------------
*/
public class QueryResultColumn {
	private String id;
	private String label;
	private int type;
	
	public QueryResultColumn(String id, String label,int type) {
		this.id = id;
		this.label = label;
		this.type = type;
	}
	
	public String getId() {
		return id;
	}
	
	public String getLabel() {
		return label;
	}
	
	public int getType() {
		return type;
	}
	
}
