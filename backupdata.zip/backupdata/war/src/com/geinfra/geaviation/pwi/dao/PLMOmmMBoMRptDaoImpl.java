/**
 * Copyright (C) 2012 GE Infra. 
 * All rights reserved 
 * @FileName PLMOmmMBoMRptDaoImpl.java
 * @Creation date: 26-April-2016
 * @version 2.0.1
 * @author : Tech Mahindra (PLMR Team) 
 */


package com.geinfra.geaviation.pwi.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMOmmMBoMRptData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMOmmMBoMRptDaoImpl extends SimpleJdbcDaoSupport implements PLMOmmMBoMRptDaoIfc {
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMOmmMBoMRptDaoImpl.class);
	
	/**
	 * This method is used for checkForValidPartNum
	 * 
	 * @param partNo
	 * @return int
	 * @throws PLMCommonException
	 */
	public int checkForValidPartNum(String partNo) throws PLMCommonException {	
		LOG.info("Entering checkForValidSerialNo Method");
		int partNumCount = 0;
		try {
			LOG.info("Query for checking valid Serial # : " + PLMOfflineQueries.GET_MBOM_OMM_VALID_PART_NUM);
			partNumCount = getSimpleJdbcTemplate().queryForInt(PLMOfflineQueries.GET_MBOM_OMM_VALID_PART_NUM, new Object[]{partNo,partNo,partNo,partNo});
			LOG.info("Result of Part Number Count  : " + partNumCount);
		} catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting checkForValidSerialNo Method");
		return partNumCount;
	}

			
	/**
	 * This method is used for getOmmMBomExplosionReport
	 * 
	 * @param topPartId
	 * @return Map
	 * @throws PLMCommonException
	 */
	public List<PLMOmmMBoMRptData> getOmmMBomExplosionReport(String partNo) throws PLMCommonException {
		LOG.info("Entering getOmmMBomExplosionReport Method");
		List<PLMOmmMBoMRptData> ommBomExplosionResultList =  new ArrayList<PLMOmmMBoMRptData>();
		List<PLMOmmMBoMRptData> vt0ResultList =  new ArrayList<PLMOmmMBoMRptData>();
		List<PLMOmmMBoMRptData> vt4ResultList =  new ArrayList<PLMOmmMBoMRptData>();
		List<PLMOmmMBoMRptData> orderedResultList =  new ArrayList<PLMOmmMBoMRptData>();
		String partNoLcl = partNo;
		List<PLMOmmMBoMRptData> vt0ResultListNew = new ArrayList<PLMOmmMBoMRptData>();
		
		String timeStamp = null;
		String OMMR_VT1 =null;
		String OMMR_VT21=null;
		String OMMR_VT22=null;
		String OMMR_VT23=null;
		String OMMR_VT13=null;
		String OMMR_VT31=null;
		String OMMR_VT32=null;
		String OMMR_VT33=null;
		String OMMR_VT14=null;
		try {
			timeStamp = PLMUtils.volTableFormatDate();
			
			LOG.info("The timeStamp for the Report "+timeStamp);
			
			OMMR_VT1 = PLMConstants.OMMR_VT1.concat(timeStamp);
			OMMR_VT21 = PLMConstants.OMMR_VT21.concat(timeStamp);
			OMMR_VT22 = PLMConstants.OMMR_VT22.concat(timeStamp);
			OMMR_VT23 = PLMConstants.OMMR_VT23.concat(timeStamp);
			OMMR_VT13 = PLMConstants.OMMR_VT13.concat(timeStamp);
			OMMR_VT31 = PLMConstants.OMMR_VT31.concat(timeStamp);
			OMMR_VT32 = PLMConstants.OMMR_VT32.concat(timeStamp);
			OMMR_VT33 = PLMConstants.OMMR_VT33.concat(timeStamp);
			OMMR_VT14 = PLMConstants.OMMR_VT14.concat(timeStamp);
			
			   LOG.info("Executing GET OMM MBOM Data List Query : "+PLMOfflineQueries.GET_MBOM_OMM_DATA_LIST);
				
				vt0ResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_MBOM_OMM_DATA_LIST,new OmmVT0ResultMapper(), new Object[]{partNo});
				LOG.info("Result of OMM MBOM Data List : " + vt0ResultList.size());
			
				LOG.info("Query for Creating OMMR_VT1 : " + PLMOfflineQueries.CREATE_MBOM_OMM_VT1.replace(PLMConstants.OMMR_VT1, OMMR_VT1));
				getJdbcTemplate().execute(PLMOfflineQueries.CREATE_MBOM_OMM_VT1.replace(PLMConstants.OMMR_VT1, OMMR_VT1));
				
				// add top level parent to vt0ResultList
				PLMOmmMBoMRptData data = new PLMOmmMBoMRptData();
				data.setRowKey(0);
				data.setBomLevel(0);
				data.setParentId("");
				data.setParentName(partNo);
				data.setChildId("");
				data.setPartNo(partNo);
				data.setPartDesc("");
				data.setMli("");
				data.setPin("");
				data.setSuffix("");
				data.setFindNum("");
				data.setPartEid("");
				//qty empty
				data.setUomDesc("");
				data.setPathFlag("");
				vt0ResultListNew.add(data);
				
				if(!PLMUtils.isEmptyList(vt0ResultList)){
					vt0ResultListNew.addAll(vt0ResultList);
				}
				
				if(!PLMUtils.isEmptyList(vt0ResultListNew)) {
					LOG.info("The Top Level Part Name --> "+partNoLcl);
					if(!PLMUtils.isEmpty(partNoLcl)){
						vt0ResultListNew = formTreeStruct(vt0ResultListNew, partNoLcl);
						LOG.info("Result of VT0 After Ordering : " + vt0ResultListNew.size());
						if(!PLMUtils.isEmptyList(vt0ResultListNew)){
							final List<PLMOmmMBoMRptData> insertResultList = vt0ResultListNew;
							int[] updateCount = null;
							LOG.info("Insert Query :  " + PLMOfflineQueries.INSERT_MBOM_OMM_VT1.replace(PLMConstants.OMMR_VT1, OMMR_VT1));
							updateCount  = getSimpleJdbcTemplate().getJdbcOperations().batchUpdate(PLMOfflineQueries.INSERT_MBOM_OMM_VT1.replace(PLMConstants.OMMR_VT1, OMMR_VT1), new BatchPreparedStatementSetter() 
							{
							public void setValues(PreparedStatement ps,int iCount)throws SQLException {
								ps.setInt(1,iCount);
								ps.setInt(2, insertResultList.get(iCount).getBomLevel());
								ps.setString(3, insertResultList.get(iCount).getParentId());
								ps.setString(4, insertResultList.get(iCount).getParentName());
								ps.setString(5, insertResultList.get(iCount).getChildId());
								ps.setString(6, insertResultList.get(iCount).getPartNo());
								ps.setString(7, insertResultList.get(iCount).getPartDesc());
								ps.setString(8, insertResultList.get(iCount).getMli());
								ps.setString(9, insertResultList.get(iCount).getPin());
								ps.setString(10, insertResultList.get(iCount).getSuffix());
								ps.setString(11, insertResultList.get(iCount).getFindNum());
								ps.setString(12, insertResultList.get(iCount).getPartEid());
								ps.setInt(13, insertResultList.get(iCount).getQty());
								ps.setString(14, insertResultList.get(iCount).getUomDesc());
							}
							public int getBatchSize() {
								return insertResultList.size();
							}
							});
							LOG.info("Total inserted Records : " + updateCount.length);
							
							LOG.info("Query for Collect Stats OMMR_VT1 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT1.replace(PLMConstants.OMMR_VT1, OMMR_VT1));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT1.replace(PLMConstants.OMMR_VT1, OMMR_VT1));
							
							LOG.info("Query for Creating OMMR_VT21 : " + PLMOfflineQueries.CREATE_MBOM_OMM_VT21.replace(PLMConstants.OMMR_VT21, OMMR_VT21)
									.replace(PLMConstants.OMMR_VT1, OMMR_VT1));
							getJdbcTemplate().execute(PLMOfflineQueries.CREATE_MBOM_OMM_VT21.replace(PLMConstants.OMMR_VT21, OMMR_VT21)
									.replace(PLMConstants.OMMR_VT1, OMMR_VT1));
							
							LOG.info("Query for Collect Stats 1 OMMR_VT21 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT21_1.replace(PLMConstants.OMMR_VT21, OMMR_VT21));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT21_1.replace(PLMConstants.OMMR_VT21, OMMR_VT21));
							
							LOG.info("Query for Collect Stats 2 OMMR_VT21 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT21_2.replace(PLMConstants.OMMR_VT21, OMMR_VT21));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT21_2.replace(PLMConstants.OMMR_VT21, OMMR_VT21));
							
							LOG.info("Query for Creating OMMR_VT22 : " + PLMOfflineQueries.CREATE_MBOM_OMM_VT22.replace(PLMConstants.OMMR_VT22, OMMR_VT22)
									.replace(PLMConstants.OMMR_VT21, OMMR_VT21));
							getJdbcTemplate().execute(PLMOfflineQueries.CREATE_MBOM_OMM_VT22.replace(PLMConstants.OMMR_VT22, OMMR_VT22)
									.replace(PLMConstants.OMMR_VT21, OMMR_VT21));
							
							LOG.info("Query for Collect Stats 1 OMMR_VT22 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT22_1.replace(PLMConstants.OMMR_VT22, OMMR_VT22));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT22_1.replace(PLMConstants.OMMR_VT22, OMMR_VT22));
							
							LOG.info("Query for Collect Stats 2 OMMR_VT22 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT22_2.replace(PLMConstants.OMMR_VT21, OMMR_VT22));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT22_2.replace(PLMConstants.OMMR_VT22, OMMR_VT22));

							LOG.info("Query for Creating OMMR_VT23 : " + PLMOfflineQueries.CREATE_MBOM_OMM_VT23.replace(PLMConstants.OMMR_VT23, OMMR_VT23)
									.replace(PLMConstants.OMMR_VT22, OMMR_VT22));
							getJdbcTemplate().execute(PLMOfflineQueries.CREATE_MBOM_OMM_VT23.replace(PLMConstants.OMMR_VT23, OMMR_VT23)
									.replace(PLMConstants.OMMR_VT22, OMMR_VT22));
							
							LOG.info("Query for Collect Stats 1 OMMR_VT23 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT23_1.replace(PLMConstants.OMMR_VT23, OMMR_VT23));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT23_1.replace(PLMConstants.OMMR_VT23, OMMR_VT23));
							
							LOG.info("Query for Collect Stats 2 OMMR_VT23 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT23_2.replace(PLMConstants.OMMR_VT23, OMMR_VT23));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT23_2.replace(PLMConstants.OMMR_VT23, OMMR_VT23));

							LOG.info("Query for Creating OMMR_VT13 : " + PLMOfflineQueries.CREATE_MBOM_OMM_VT13.replace(PLMConstants.OMMR_VT13, OMMR_VT13)
									.replace(PLMConstants.OMMR_VT23, OMMR_VT23));
							getJdbcTemplate().execute(PLMOfflineQueries.CREATE_MBOM_OMM_VT13.replace(PLMConstants.OMMR_VT13, OMMR_VT13)
									.replace(PLMConstants.OMMR_VT23, OMMR_VT23));
							
							LOG.info("Query for Collect Stats 1 OMMR_VT13 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT13_1.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT13_1.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
							
							LOG.info("Query for Collect Stats 2 OMMR_VT13 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT13_2.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT13_2.replace(PLMConstants.OMMR_VT13, OMMR_VT13));

							LOG.info("Query for Collect Stats 3 OMMR_VT13 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT13_3.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT13_3.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
							
							LOG.info("Query for Collect Stats 4 OMMR_VT13 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT13_4.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT13_4.replace(PLMConstants.OMMR_VT13, OMMR_VT13));

							LOG.info("Query for Collect Stats 5 OMMR_VT13 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT13_5.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT13_5.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
							
							LOG.info("Query for Creating OMMR_VT31 : " + PLMOfflineQueries.CREATE_MBOM_OMM_VT31.replace(PLMConstants.OMMR_VT31, OMMR_VT31)
									.replace(PLMConstants.OMMR_VT1, OMMR_VT1));
							getJdbcTemplate().execute(PLMOfflineQueries.CREATE_MBOM_OMM_VT31.replace(PLMConstants.OMMR_VT31, OMMR_VT31)
									.replace(PLMConstants.OMMR_VT1, OMMR_VT1));
							
							LOG.info("Query for Collect Stats 1 OMMR_VT31 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT31_1.replace(PLMConstants.OMMR_VT31, OMMR_VT31));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT31_1.replace(PLMConstants.OMMR_VT31, OMMR_VT31));
							
							LOG.info("Query for Collect Stats 2 OMMR_VT31 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT31_2.replace(PLMConstants.OMMR_VT31, OMMR_VT31));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT31_2.replace(PLMConstants.OMMR_VT31, OMMR_VT31));
							
							LOG.info("Query for Creating OMMR_VT32 : " + PLMOfflineQueries.CREATE_MBOM_OMM_VT32.replace(PLMConstants.OMMR_VT32, OMMR_VT32)
									.replace(PLMConstants.OMMR_VT31, OMMR_VT31));
							getJdbcTemplate().execute(PLMOfflineQueries.CREATE_MBOM_OMM_VT32.replace(PLMConstants.OMMR_VT32, OMMR_VT32)
									.replace(PLMConstants.OMMR_VT31, OMMR_VT31));
							
							LOG.info("Query for Collect Stats 1 OMMR_VT32 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT32_1.replace(PLMConstants.OMMR_VT32, OMMR_VT32));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT32_1.replace(PLMConstants.OMMR_VT32, OMMR_VT32));
							
							LOG.info("Query for Collect Stats 2 OMMR_VT32 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT32_2.replace(PLMConstants.OMMR_VT32, OMMR_VT32));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT32_2.replace(PLMConstants.OMMR_VT32, OMMR_VT32));
							
							LOG.info("Query for Creating OMMR_VT33 : " + PLMOfflineQueries.CREATE_MBOM_OMM_VT33.replace(PLMConstants.OMMR_VT33, OMMR_VT33)
									.replace(PLMConstants.OMMR_VT32, OMMR_VT32));
							getJdbcTemplate().execute(PLMOfflineQueries.CREATE_MBOM_OMM_VT33.replace(PLMConstants.OMMR_VT33, OMMR_VT33)
									.replace(PLMConstants.OMMR_VT32, OMMR_VT32));
							
							LOG.info("Query for Collect Stats OMMR_VT33 : " + PLMOfflineQueries.COLLECT_MBOM_OMM_VT33.replace(PLMConstants.OMMR_VT33, OMMR_VT33));
							getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_MBOM_OMM_VT33.replace(PLMConstants.OMMR_VT33, OMMR_VT33));
						
							LOG.info("Query for Creating OMMR_VT14 : " + PLMOfflineQueries.CREATE_MBOM_OMM_VT14.replace(PLMConstants.OMMR_VT14, OMMR_VT14)
									.replace(PLMConstants.OMMR_VT33, OMMR_VT33));
							getJdbcTemplate().execute(PLMOfflineQueries.CREATE_MBOM_OMM_VT14.replace(PLMConstants.OMMR_VT14, OMMR_VT14)
									.replace(PLMConstants.OMMR_VT33, OMMR_VT33));
							
							
							LOG.info("Executing GET OMM MBOM Data FinalList Query : "+PLMOfflineQueries.GET_MBOM_OMM_DATA_FINAL_LIST
							.replace(PLMConstants.OMMR_VT14, OMMR_VT14).replace(PLMConstants.OMMR_VT13, OMMR_VT13));
							vt4ResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_MBOM_OMM_DATA_FINAL_LIST
									.replace(PLMConstants.OMMR_VT14, OMMR_VT14).replace(PLMConstants.OMMR_VT13, OMMR_VT13),new OmmMBomExplosionResultMapper());
							LOG.info("Result of OMM MBOM Data FinalList : " + vt4ResultList.size());
							
							if(!PLMUtils.isEmptyList(vt4ResultList)){
								ommBomExplosionResultList = separatePartAndDocument(vt4ResultList);
								
								ommBomExplosionResultList = generatePin(ommBomExplosionResultList);
							
								LOG.info("Result of OMMR_VT16 "+ ommBomExplosionResultList.size());
							} else {
								LOG.info("No Results for OMMR_VT16" );
							}
						} else {
							LOG.info("Ordering failed : Returns Empty Result");
						}
					} else {
						LOG.info("Ordering failed : No Top Level Parent found");
					}
				} else {
					LOG.info("OMMR_VT11 Returns Empty Result");
				}
		} catch(DataAccessException e){			
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getOmmMBomExplosionReport Method");
		return ommBomExplosionResultList;
	}
	
	/**
	 * This method is used for generatePin
	 * 
	 * @param lttrTdResultList
	 * @return List
	 */
	public List<PLMOmmMBoMRptData> generatePin(List<PLMOmmMBoMRptData> ommBomExplosionResultLcl) {
		boolean mliFound = false;
		boolean prefix1302Found = false;
		int bomLevel = 0;
		int lastBomLevel = 0;
		String prefix;
		int levelFor1302 = 0;
		int levelForMli = 0;
		String mliArray[] = new String [100];
		String pinArray[] = new String [100];
		int levelArray[] = new int[100];
		String first2Char = "";
		// start : for loop
		for (int i = 0 ; i < ommBomExplosionResultLcl.size(); i++) 
		   {
			bomLevel = ommBomExplosionResultLcl.get(i).getBomLevel();
			//prefix = ommBomExplosionResultLcl.get(i).getPrefix().trim();
			prefix = ommBomExplosionResultLcl.get(i).getMli().trim();
			/*if (!prefix.equals(prefix.trim())) {
				
				LOG.info("Prefix and Trimmed Prefix is not equal->"+prefix+"<-Test");
			}
			if (prefix!=null){
				
				if (prefix.trim().length() <4) {
					
					LOG.info(" Prefix Value -->"+prefix.trim());
					LOG.info(" LEVEL "+lttrTdResultList.get(i).getBomLevel());
					LOG.info(" PARENT "+lttrTdResultList.get(i).getParentPdName());
					LOG.info(" CHILD "+lttrTdResultList.get(i).getPdName());
					
				}
			}*/
			//LOG.info("Prefix value"+prefix);
			ommBomExplosionResultLcl.get(i).setPin("");
			ommBomExplosionResultLcl.get(i).setHpin("");
			if (!prefix.isEmpty() && prefix.length()>1) {
				first2Char = prefix.substring(0, 2);
			} else {
				first2Char = prefix+" ";
			}
			//LOG.info("value of i " + i);
			//LOG.info("bomLevel " + bomLevel);
			//LOG.info("Prefix" + prefix);
			//LOG.info("first2Char" + first2Char);
			// start : If bom level is equal to zero
			if(bomLevel == 0) {
				//LOG.info("bomLevel == 0");
				ommBomExplosionResultLcl.get(i).setMli("");
				ommBomExplosionResultLcl.get(i).setParentMLI("");
				ommBomExplosionResultLcl.get(i).setPin("");
				ommBomExplosionResultLcl.get(i).setHpin("");
			}
			// end : If bom level is equal to zero
			
			// start : If bom level is equal to or greater than one
			if(bomLevel >= 1) {
				//LOG.info("bomLevel >= 1");
				if(mliFound){
					//LOG.info("mliFound for bomLevel >= 1");
					if(prefix1302Found && bomLevel == levelFor1302 + 1) {
						//LOG.info("prefix1302Found && bomLevel == levelFor1302 + 1");
					} else {
						if(bomLevel > levelForMli) {
							//LOG.info("bomLevel > levelForMli");
							ommBomExplosionResultLcl.get(i).setParentMLI(mliArray[levelForMli]);
							ommBomExplosionResultLcl.get(i).setPin(pinArray[levelForMli-1]);
							lastBomLevel = bomLevel;								// setting previous bom level
							ommBomExplosionResultLcl.get(i).setHpin(pinArray[1]);			// setting hpin
							continue;												// skips the current iteration
						} else {													// Reset all the values
							for (int j = bomLevel ; j <= levelArray[lastBomLevel + 1] ; j++){  
								mliArray[j] = "";
								pinArray[j] = "";
								levelArray[j] = 0;
							}
							mliFound = false;
							prefix1302Found = false;
						}
					 }
				}
				levelArray [bomLevel] = bomLevel; // Assigns bom level to level array
				
				if (first2Char.matches("[a-zA-Z]*") && !(prefix.equals("IS06"))) {  // if first two characters of the alphabet and not equals to IS06
					//LOG.info("first2Char.matches([a-zA-Z]*) && !(prefix.equals(IS06)");
					pinArray [bomLevel] = prefix;
				} else  { 															// if first two characters is not alphabet
					if (prefix.equals("1302")){  									// check if prefix equals to 1302
						//LOG.info("prefix.equals(1302)");
						pinArray [bomLevel] = prefix;
						mliArray [bomLevel] = prefix;
						prefix1302Found = true;
						levelFor1302 = bomLevel;
					} else {														// if prefix does not equals to 1302
						mliFound = true;
						levelForMli = bomLevel;
						mliArray [bomLevel] = prefix;
						//LOG.info("bomLevel" + bomLevel);
						//LOG.info("mliArray [bomLevel] = " +  mliArray [bomLevel]);
					}
				}
				
				if (prefix1302Found && bomLevel > levelFor1302){ 					// if prefix1302 found and level greater than level for 1302
					//LOG.info("mliFound && bomLevel > levelFor1302");
					if(prefix.equals("1303") || prefix.equals("1305")) {			// if prefix equals 1303 or 1305
						//LOG.info("prefix.equals(1303) || prefix.equals(1305)");
						mliFound = true;
						levelForMli = bomLevel;
						ommBomExplosionResultLcl.get(i).setParentMLI(mliArray[bomLevel - 1]);		// setting mli
						ommBomExplosionResultLcl.get(i).setPin(pinArray[bomLevel - 2]);		// setting pin
					} else {														// if prefix not equals 1303 or 1305
						//LOG.info("else of prefix.equals(1303) || prefix.equals(1305)");
						mliFound = true;
						levelForMli = bomLevel - 1;
						ommBomExplosionResultLcl.get(i).setParentMLI(mliArray[levelForMli]);		// setting mli
						ommBomExplosionResultLcl.get(i).setPin(pinArray[levelForMli - 1]);	// setting pin
					}
					lastBomLevel = bomLevel;										// setting previous bom level
					ommBomExplosionResultLcl.get(i).setHpin(pinArray[1]);					// setting hpin
					continue;														// skips the current iteration
				}
					
				if (mliFound){														// if mli found
					//LOG.info("mli found for all level");
					if (bomLevel >= 2){
						//LOG.info("bomLevel >= 2");
						ommBomExplosionResultLcl.get(i).setParentMLI(mliArray[levelForMli]);		//setting mli
						ommBomExplosionResultLcl.get(i).setPin(pinArray[levelForMli - 1]);	//setting pin
					}
				} else {
					//LOG.info("mli not found for all level");
					if (prefix1302Found && bomLevel ==  levelFor1302){
						//LOG.info("prefix1302Found && bomLevel ==  levelFor1302");
						ommBomExplosionResultLcl.get(i).setParentMLI(mliArray[levelFor1302]);		//setting mli
					} else {
						//LOG.info("else of prefix1302Found && bomLevel ==  levelFor1302");
						ommBomExplosionResultLcl.get(i).setParentMLI("");							//setting mli
					}
					if(bomLevel > 1){
						//LOG.info("bomLevel > 1");
						ommBomExplosionResultLcl.get(i).setPin(pinArray[bomLevel - 1]);		//setting pin
					}
				}
				lastBomLevel = bomLevel;											// setting previous bom level
				ommBomExplosionResultLcl.get(i).setHpin(pinArray[1]);						// setting hpin
			}
			// end : If bom level is equal to or greater than one	
		 }	
		// end : for loop	
		return ommBomExplosionResultLcl;
	}

	/**
	 * This method is used for formTreeStruct
	 * 
	 * @param vt0ResultList,topLevelParent,partCostGrpMap
	 * @return List
	 */
	
	public List<PLMOmmMBoMRptData> formTreeStruct(List<PLMOmmMBoMRptData> vt0ResultList,String topLevelParent) {
		LOG.info("Entering formTreeStruct Method");
		int bomLevel = 0;
		int index;
		int prevIndex = -1;
		String parentName = topLevelParent;
		List<PLMOmmMBoMRptData> orderedResultList =  new ArrayList<PLMOmmMBoMRptData>();
		while(true){
			index = findChildrens(vt0ResultList,parentName,prevIndex,bomLevel);
			if(index == -1){			
				if(bomLevel == 0){
					break;			
				}
				vt0ResultList.get(prevIndex).setPathFlag("COMPLETED");
				bomLevel = 0;
				parentName = topLevelParent;
			} else {
				if(!vt0ResultList.get(index).getPathFlag().equals("VISITED")){
					vt0ResultList.get(index).setPathFlag("VISITED");
					orderedResultList.add(vt0ResultList.get(index));
				}
				prevIndex = index;	
				bomLevel = bomLevel + 1;
				parentName = vt0ResultList.get(index).getPartNo();
			}
		}
		LOG.info("Exiting formTreeStruct Method");
		return orderedResultList;
	}
	/**
	 * This method is used for findChildrens
	 * 
	 * @param vt0ResultList,parentName,prevIndex,bomLevel
	 * @return int
	 */
	public int findChildrens(List<PLMOmmMBoMRptData> vt0ResultList,String parentName,int prevIndex, int bomLevel) {
		int retIndex = -1;
		for(int i = 0 ; i < vt0ResultList.size();i++) {
			if(vt0ResultList.get(i).getParentName().equals(parentName) && vt0ResultList.get(i).getBomLevel() == bomLevel){
				if(bomLevel == 0) {
					if(!vt0ResultList.get(i).getPathFlag().equals("COMPLETED")){
						retIndex = i;
						break;
					}
				} else {
					if(vt0ResultList.get(i).getParentName().equals(vt0ResultList.get(prevIndex).getPartNo())){
						if(!vt0ResultList.get(i).getPathFlag().equals("COMPLETED")){
							retIndex = i;
							break;
						} 
					}
				}
			}
		}
		return retIndex;
	}
	
	/**
	 * This method is used for separatePartAndDocument
	 * 
	 * @param vt4ResultListevel
	 * @return List
	 */
	public List<PLMOmmMBoMRptData> separatePartAndDocument(List<PLMOmmMBoMRptData> vt4ResultList){
		LOG.info("Entering separatePartAndDocument Method");
		List<PLMOmmMBoMRptData> ommBomExplosionResultList =  new ArrayList<PLMOmmMBoMRptData>();
		int maxRecordId =  vt4ResultList.get(vt4ResultList.size() - 1).getRecordId();
		for(int recordId = 0 ; recordId <= maxRecordId ; recordId++){
			List<PLMOmmMBoMRptData> recordIdList = getRecordIds(vt4ResultList,recordId);
			if(!PLMUtils.isEmptyList(recordIdList)){
				for(int i = 0 ; i < recordIdList.size(); i++){
					if(i == 0) {
						ommBomExplosionResultList.add(setPartAsType(recordIdList.get(i)));
						if(!PLMUtils.isEmpty(recordIdList.get(i).getDocName())){
							ommBomExplosionResultList.add(setDocumentAsType(recordIdList.get(i)));
						}
					} else {
						if(!PLMUtils.isEmpty(recordIdList.get(i).getDocName())){
							ommBomExplosionResultList.add(setDocumentAsType(recordIdList.get(i)));
						}
					}
				}
			}
		}
		LOG.info("Exiting separatePartAndDocument Method");
		return ommBomExplosionResultList;
	}
	
	/**
	 * This method is used for getRecordIds
	 * 
	 * @param vt4ResultList,recordId
	 * @return List
	 */
	public List<PLMOmmMBoMRptData> getRecordIds (List<PLMOmmMBoMRptData> vt4ResultList, int recordId){
		List<PLMOmmMBoMRptData> recordIdList =  new ArrayList<PLMOmmMBoMRptData>();
		for(int i = 0 ; i < vt4ResultList.size() ; i++){
			if(recordId == vt4ResultList.get(i).getRecordId()){
				recordIdList.add(vt4ResultList.get(i));
			}
		}
		return recordIdList;
	}
	
	/**
	 * This method is used for setPartAsType
	 * 
	 * @param ommPartRefData
	 * @return PLMOmmMBoMRptData
	 */
	public PLMOmmMBoMRptData setPartAsType(PLMOmmMBoMRptData ommPartRefData){
		PLMOmmMBoMRptData ommPartData = copyObject(ommPartRefData); 
		ommPartData.setLogicalIndicator("");
		//ommPartData.setType("Part");
		/*if (ommPartData.getPartType()==null)
		LOG.info("ommPartData.getPartType() -->"+ommPartData.getPartType());*/		
		ommPartData.setEid(ommPartData.getPartEid());
		ommPartData.setType(ommPartData.getPartType());
		ommPartData.setDocName("");
		ommPartData.setDocRev("");
		ommPartData.setDocState("");
		ommPartData.setDocDesc("");
		ommPartData.setSecurityClass("");
		ommPartData.setExportClass("");
		ommPartData.setGeDwgCriticalCode("");
		return ommPartData;
	}
	/**
	 * This method is used for setDocumentAsType
	 * 
	 * @param ommPartRefData
	 * @return PLMOmmMBoMRptData
	 */
	public PLMOmmMBoMRptData setDocumentAsType(PLMOmmMBoMRptData ommDocRefData){
		PLMOmmMBoMRptData ommDocData = copyObject(ommDocRefData);
		//ommDocData.setMli("");
		//ommDocData.setPin("");
		ommDocData.setSuffix("");
		ommDocData.setFindNum("");
		ommDocData.setPartEid("");
		//ommDocData.setPartFamily("");
		//ommDocData.setType("Document");
		/*if (ommDocData.getDocType()==null)
		LOG.info("ommPartData.getPartType() -->"+ommDocData.getDocType());*/
		ommDocData.setEid(ommDocData.getLogicalIndicator());
		ommDocData.setType(ommDocData.getDocType());
		ommDocData.setPartNo(ommDocData.getDocName());
		ommDocData.setPartRev(ommDocData.getDocRev());
		ommDocData.setPartState(ommDocData.getDocState());
		ommDocData.setPartDesc(ommDocData.getDocDesc());
		ommDocData.setPartUom("");
		ommDocData.setQty(0);
		ommDocData.setDocName("");
		ommDocData.setDocRev("");
		ommDocData.setDocState("");
		ommDocData.setDocDesc("");
		return ommDocData;
	}
	
	/**
	 * This method is used for copyObject
	 * 
	 * @param refObj
	 * @return PLMOmmMBoMRptData
	 */
	public PLMOmmMBoMRptData copyObject(PLMOmmMBoMRptData refObj){
		PLMOmmMBoMRptData copiedObj = new PLMOmmMBoMRptData();
		copiedObj.setBomLevel(refObj.getBomLevel());
		copiedObj.setLogicalIndicator(refObj.getLogicalIndicator());
		copiedObj.setMli(refObj.getMli());
		copiedObj.setPin(refObj.getPin());
		copiedObj.setSuffix(refObj.getSuffix());
		copiedObj.setFindNum(refObj.getFindNum());
		copiedObj.setPartEid(refObj.getPartEid());
		copiedObj.setType(refObj.getType());
		copiedObj.setEid(refObj.getEid());
		copiedObj.setPartType(refObj.getPartType());
		copiedObj.setDocType(refObj.getDocType());
		copiedObj.setPartNo(refObj.getPartNo());
		copiedObj.setPartRev(refObj.getPartRev());
		copiedObj.setPartState(refObj.getPartState());
		copiedObj.setPartDesc(refObj.getPartDesc());
		copiedObj.setQty(refObj.getQty());
		copiedObj.setPartUom(refObj.getPartUom());
		copiedObj.setDocName(refObj.getDocName());
		copiedObj.setDocRev(refObj.getDocRev());
		copiedObj.setDocState(refObj.getDocState());
		copiedObj.setDocDesc(refObj.getDocDesc());
		copiedObj.setSecurityClass(refObj.getSecurityClass());
		copiedObj.setExportClass(refObj.getExportClass());
		copiedObj.setParentName(refObj.getParentName());
		copiedObj.setGeDwgCriticalCode(refObj.getGeDwgCriticalCode());
		copiedObj.setPartFamily(refObj.getPartFamily());
		copiedObj.setPartFamilyTitle(refObj.getPartFamilyTitle());
		copiedObj.setRecordId(refObj.getRecordId());
		return copiedObj;
	}
	
	/**
	 * This method is used for getOmmSbomDeviationReport
	 * 
	 * @param partNo
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMOmmMBoMRptData> getOmmSbomDeviationReport(String partNo) throws PLMCommonException {
		LOG.info("Entering getOmmSbomDeviationReport Method");
		List<PLMOmmMBoMRptData> ommSbomDeviationResultList =  new ArrayList<PLMOmmMBoMRptData>();
		try{
			LOG.info("Query for Getting SBOM Deviation Results : " + PLMOfflineQueries.GET_MBOM_OMM_BOM_DEVIATION);
			ommSbomDeviationResultList =  getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_MBOM_OMM_BOM_DEVIATION, new OmmSbomDeviationResultMapper(), partNo);
			LOG.info("Result of SBOM Deviation : " + ommSbomDeviationResultList.size());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getOmmSbomDeviationReport Method");
		return ommSbomDeviationResultList;
	}
	/**
	 * Row mapper for getting ommVT0ResultMapper
	 */
	private static final class OmmVT0ResultMapper implements ParameterizedRowMapper<PLMOmmMBoMRptData>{ 	
	public PLMOmmMBoMRptData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMOmmMBoMRptData tempData = new PLMOmmMBoMRptData();
			tempData.setRowKey(rs.getInt(PLMConstants.OMM_BOM_COL_ROW_KEY));
			tempData.setBomLevel(rs.getInt(PLMConstants.OMM_BOM_COL_BOM_LEVEL));
			tempData.setParentId(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PARENT_ID)));
			tempData.setParentName(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PARENT_ITEM)));
			tempData.setChildId(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_CHILD_ID)));
			tempData.setPartNo(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_NO)));
			tempData.setPartDesc(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_DESC)));
			tempData.setMli(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_MLI)));
			tempData.setPin(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PIN)));
			tempData.setSuffix(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_SUFFIX)));
			tempData.setFindNum(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_FINDNUM)));
			tempData.setPartEid(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_EID)));
			tempData.setQty(rs.getInt(PLMConstants.OMM_BOM_COL_QUANTITY));
			tempData.setUomDesc(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_UOMDESC)));
			//tempData.setPartType(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_TYPE)));
			tempData.setPathFlag("");
			return tempData;
		}
	}
	/**
	 * Row mapper for getting ommBomExplosionResultMapper
	 */
	private static final class OmmMBomExplosionResultMapper implements ParameterizedRowMapper<PLMOmmMBoMRptData>{ 	
	public PLMOmmMBoMRptData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMOmmMBoMRptData tempData = new PLMOmmMBoMRptData();
			tempData.setBomLevel(rs.getInt(PLMConstants.OMM_BOM_COL_BOM_LEVEL));
			tempData.setLogicalIndicator(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_LOGICAL_INDICATOR)));
			tempData.setMli(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_MLI)));
			tempData.setPin(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PIN)));
			tempData.setSuffix(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_SUFFIX)));
			tempData.setFindNum(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_FINDNUM)));
			tempData.setPartEid(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_EID)));
			//tempData.setType(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_TYPE)));
			tempData.setType("");
			tempData.setEid("");
			tempData.setPartNo(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_NO)));
			tempData.setPartRev(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_REV)));
			tempData.setPartState(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_STATE)));
			tempData.setPartDesc(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_DESC)));
			tempData.setPartFamily(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_FAMILY)));
			tempData.setPartFamilyTitle(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PF_TITLE)));
			tempData.setQty(rs.getInt(PLMConstants.OMM_BOM_COL_QUANTITY));
			tempData.setPartUom(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_UOM)));
			tempData.setPartType(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_TYPE)));
			tempData.setDocType(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_DOC_TYPE)));
			tempData.setDocName(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_DOC_NAME)));
			tempData.setDocRev(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_DOC_REV)));
			tempData.setDocState(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_DOC_STATE)));
			tempData.setDocDesc(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_DOC_DESCRIPTION)));
			tempData.setSecurityClass(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_SECURITY_CLASS)));
			tempData.setExportClass(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_EXPORT_CLASS)));
			tempData.setParentName(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PARENT_ITEM)));
			/*if(PLMUtils.isEmpty(tempData.getExportClass())){
				tempData.setGeDwgCriticalCode("");
			} else if(tempData.getExportClass().equals("Export Controlled")){
				tempData.setGeDwgCriticalCode("Critical");
			} else {
				tempData.setGeDwgCriticalCode("Non-Critical");
			}*/
			tempData.setGeDwgCriticalCode(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_GE_DWG_CRITICAL_CODE)));
			tempData.setRecordId(rs.getInt(PLMConstants.OMM_BOM_COL_RECORD_ID));
			return tempData;
		}
	}
	
	/**
	 * Row mapper for getting ommSbomDeviationResultMapper
	 */
	private static final class OmmSbomDeviationResultMapper implements ParameterizedRowMapper<PLMOmmMBoMRptData>{	
	public PLMOmmMBoMRptData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMOmmMBoMRptData tempData = new PLMOmmMBoMRptData();
			tempData.setTurbineNo(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_TURBINE_NO)));
			tempData.setPin(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_PIN)));
			tempData.setNewItem(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_NEW_ITEM)));
			tempData.setOldItem(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_OLD_ITEM)));
			tempData.setSection(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_SECTION)));
			tempData.setRevisonNo(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_REVISION_NO)));
			tempData.setAuthorization(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_AUTHORIZATION)));
			tempData.setDescription(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_DESCRIPTION)));
			tempData.setDateApplied(rs.getDate(PLMConstants.OMM_SBOM_COL_DATE_APPLIED));
			tempData.setQty(rs.getInt(PLMConstants.OMM_SBOM_COL_QUANTITY));
			tempData.setAnNum(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_AN_NO)));
			tempData.setAuthor(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_AUTHOR)));
			tempData.setAuthorFn(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_AUTHOR_FIRST_NAME)));
			tempData.setAuthorLn(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_AUTHOR_LAST_NAME)));
			tempData.setCatNo(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_CATEGORY_NO)));
			tempData.setLocation(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_LOCATION)));
			tempData.setParentPin(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_PARENT_PIN)));
			return tempData;
		}
	}
	
	/**
	 * @return the LOG
	 */
	public static Logger getLOG() {
		return LOG;
	}
}