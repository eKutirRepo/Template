package com.geinfra.geaviation.pwi.dao;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Project : Product Lifecycle Management Date Written : May 18, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : PWiDAO - Base DAO Implementation. Contains Getter/Setters for
 * the JDBCTemplate.
 * 
 * Revision Log May 18, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiDAO {
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
}
