/**
 * Copyright (C) 2014 GE Infra. All rights reserved
 * 
 * @FileName PLMBomDfctRptMB.java
 * @Creation date: 15-July-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMBomDfctRptData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMBomDfctRptServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMBomDfctRptMB {
	/**
	 * Holds the Loggger
	 */
	private static final Logger LOG = Logger.getLogger(PLMBomDfctRptMB.class);
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds the plmERPRptService
	 */
	private PLMBomDfctRptServiceIfc plmBomDfctRptService = null;
	/**
	 * Holds the resourceBundle
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	/**
	 * Holds user information
	 */
	private PLMPwiUserData userDetails = null;
	/**
	 * Holds the partNumber
	 */
	private String partNumber;
	/**
	 * Holds the partId
	 */
	private String partId;
	/**
	 * Holds the alertBomDefctMsg
	 */
	private String alertBomDefctMsg;
	
	/**
	 * Holds the bomDftListData
	 */
	private List<PLMBomDfctRptData> bomDftListData = new ArrayList<PLMBomDfctRptData>();
	
	/**
	 * This method is used to load home page of BOM Defect Report 
	 * 
	 * @return String
	 * @throws PLMCommonException 
	 */
	public String loadBomDefectHomePage(){
		LOG.info("Entering loadBomDefectHomePage Method");
		try {
			commonMB.insertCannedRptRecordHitInfo("BOM Defect Report (CMU)");
			alertBomDefctMsg = "";
			partNumber="";
			partId="";
			} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadOmmMBOMRptPage:", exception);
		}
		LOG.info("Exiting loadBomDefectHomePage Method");
		return "bomDefectRpt";
	}

	/**
	 * This method is used for Validating Part Number Input
	 * 
	 * @return String
	 */
	public String validatePartNumber() {
		LOG.info("Entering validatePartNumber Method");
		LOG.info("Part Number Entered "+partNumber);
		String alertMsg = "";
		if(PLMUtils.isEmpty(partNumber)){
			alertMsg = PLMConstants.BOM_DEFECT_SEARCH_CRITERIA;
		} else if(!PLMUtils.checkForSpecialChars(partNumber)){
			alertMsg = PLMConstants.BOM_DEFECT_NO_SPLCHAR_CRITERIA;
		}
		LOG.info("Exiting validatePartNumber Method");
		return alertMsg;
	}

	/**
	 * This method is used for Generating BOM Defect Report
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String generateBomDefectRpt() throws PWiException {
		LOG.info("Entering generateBomDefectRpt Method");
		String fwdflag = "bomDefectRpt";
		alertBomDefctMsg = "";
		alertBomDefctMsg = validatePartNumber();
		partId="";
		List<String> partIdList =new ArrayList<String>();
		userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		if (PLMUtils.isEmpty(alertBomDefctMsg)) {
			try {
				partIdList =  plmBomDfctRptService.checkForValidPartNum(partNumber);
				if(!PLMUtils.isEmptyList(partIdList)) {
					partId = partIdList.get(0);
					LOG.info("Part Id>>>>>>>>>> "+partId);
					alertBomDefctMsg =  PLMConstants.BOM_DEFECT_MAIL_ALERT_MSG;
					taskExecutor.execute(new MailThread());
				} else {
					alertBomDefctMsg =  PLMConstants.BOM_DEFECT_INVALID_SERIAL_NO_ALERT_MSG;
				}
			 } catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@generateBomDefectRpt: ", exception);
				fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"bomDefectRpt","BOM Defect Report (CMU)");
			}
		}
		LOG.info("Exiting generateBomDefectRpt Method");
		return fwdflag;
	}
	
	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendBomDefectRptMail();
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return void
	 */
	public void sendBomDefectRptMail() {
		LOG.info("Entering sendBomDefectRptMail Method");
		String partNumLcl = partNumber;
		String partIdLcl = partId;
		String from = PLMConstants.OMM_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.BOM_DEFECT_SUBJECT + partNumLcl;
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("BOM_DEFECT_CMU_REPORT_NAME") +  partNumLcl + "_" + uniqTime + ".xlsx";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("BOM_DEFECT_CMU_REPORT_NAME") +  partNumLcl + "_" + uniqTime + ".zip";
		try {
			List<PLMBomDfctRptData> bomDftResultList = plmBomDfctRptService.getBomDefectRpt(partIdLcl);
			StringBuffer mailBody = new StringBuffer().append(toAddressee);
			if(PLMUtils.isEmptyList(bomDftResultList)){
				mailBody.append(PLMConstants.BOM_DEFECT_MAIL_CONTENT_NO_RECORD);
				mailBody.append(partNumLcl)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				PLMUtils.sendMail(from, to, subject, mailBody.toString());
			} else {
				mailBody.append(PLMConstants.BOM_DEFECT_MAIL_CONTENT);
				mailBody.append(partNumLcl)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				saveBomDefectXLSFile(partNumLcl,bomDftResultList,fileDir,filePathXls);
				PLMUtils.generateZipFile(filePathXls,filePathZip);
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendBomDefectRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendBomDefectRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} finally {
			PLMUtils.deleteFiles(filePathXls,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendBomDefectRptMail Method");
	}

	
	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return void
	 */
	
	public void saveBomDefectXLSFile(String partNumLcl,
					List<PLMBomDfctRptData> bomDftResultList,String fileDir,String filePathXls) throws IOException {
		LOG.info("Entering saveBomDefectXLSFile Method");
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXls);
				SXSSFWorkbook workbook = new SXSSFWorkbook();
				
				// Start : POI Styles
				XSSFCellStyle headerStyle = (XSSFCellStyle) workbook.createCellStyle();
				headerStyle.setFillForegroundColor(HSSFColor.BLACK.index);
				headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
				
				XSSFFont headerFont = (XSSFFont) workbook.createFont(); 
				headerFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				headerFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headerFont.setFontHeightInPoints((short)9);
				headerFont.setFontName("GE Inspira");
				headerFont.setColor(IndexedColors.WHITE.getIndex());
				headerStyle.setFont(headerFont);
				
				XSSFCellStyle searchFieldNameStyle = (XSSFCellStyle) workbook.createCellStyle();
				searchFieldNameStyle = setBorderStyle(searchFieldNameStyle);
				searchFieldNameStyle.setAlignment(CellStyle.ALIGN_RIGHT);
				
				XSSFFont boldFont = (XSSFFont) workbook.createFont();
				boldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				boldFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				boldFont.setFontHeightInPoints((short)9);
				boldFont.setFontName("GE Inspira");
				boldFont.setColor(IndexedColors.BLACK.getIndex());
				searchFieldNameStyle.setFont(boldFont);
				
				XSSFFont cellstyleFont = (XSSFFont)workbook.createFont(); 
				cellstyleFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				
				cellstyleFont.setFontHeightInPoints((short)9);
				cellstyleFont.setFontName("GE Inspira");
				cellstyleFont.setColor(IndexedColors.BLACK.getIndex());
				
				XSSFCellStyle contentStyle = (XSSFCellStyle) workbook.createCellStyle();
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(cellstyleFont);
				
				XSSFFont cellstyleFontRed = (XSSFFont)workbook.createFont(); 
				cellstyleFontRed.setFontName(PLMConstants.EXCEL_FONT_NAME);
				
				cellstyleFontRed.setFontHeightInPoints((short)9);
				cellstyleFontRed.setFontName("GE Inspira");
				cellstyleFontRed.setColor(IndexedColors.RED.getIndex());
				
				XSSFCellStyle redcontentStyle = (XSSFCellStyle) workbook.createCellStyle();
				redcontentStyle = setBorderStyle(redcontentStyle);
				redcontentStyle.setFont(cellstyleFontRed);
				
				XSSFCellStyle redCellStyle = (XSSFCellStyle)workbook.createCellStyle();
				redCellStyle = setBorderStyle(redCellStyle);
				redCellStyle.setFont(cellstyleFont);
				redCellStyle.setFillForegroundColor(HSSFColor.RED.index);
				redCellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND); 
				
				
				XSSFCellStyle yellowCellStyle = (XSSFCellStyle)workbook.createCellStyle();
				yellowCellStyle = setBorderStyle(yellowCellStyle);
				yellowCellStyle.setFont(cellstyleFont);
				yellowCellStyle.setFillForegroundColor(HSSFColor.YELLOW.index);
				yellowCellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND); 
				// End : POI Styles
				
				SXSSFRow row = null;
				SXSSFCell cell = null;
				SXSSFSheet sheet =  null;
				
				int rowcount = -1;
				if(!PLMUtils.isEmptyList(bomDftResultList)) {
						rowcount = -1;
						sheet = (SXSSFSheet) workbook.createSheet(partNumLcl);
						// To display Search Criteria 
						row = (SXSSFRow) sheet.createRow(++rowcount);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						cell.setCellValue("Part Number");
						cell.setCellStyle(searchFieldNameStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellValue(partNumLcl);
						cell.setCellStyle(contentStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellValue("");
						
						// One Row Space
						row = (SXSSFRow) sheet.createRow(++rowcount);
							//Header
							String[] bomColNames = {"LVL","Name","Rev","EID","F/N","Qty","Production Status","PLM U of M","Description","Application Notes","PLM State",
									"PLM Alternate Part","Preferred Replacement?","ERP Item Status","ERP Superceded To","ERP Cost","ERP Total Cycle","ERP U of M","PLM Chem Code","Error Text"};
							row = (SXSSFRow) sheet.createRow(++rowcount);
							for ( int i = 0 ; i < bomColNames.length; i++ ) {
								cell = (SXSSFCell) row.createCell(i);
								cell.setCellStyle(headerStyle);
								cell. setCellValue(bomColNames[i]);
							}
							//Header
							for(int i = 0; i < bomDftResultList.size(); i++) {
								PLMBomDfctRptData dataObj = (PLMBomDfctRptData) bomDftResultList.get(i);
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getLevel());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartName());
								
								
								//part Revision is highlighted foreground as red based on conditions
								if(!PLMUtils.checkAlphabetic(dataObj.getPartRev()) && !PLMUtils.isEmpty(dataObj.getPartRev())){
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
									cell.setCellStyle(redcontentStyle);
									cell.setCellValue(dataObj.getPartRev());
								}else{
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getPartRev());
								}
								
								
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEid());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getFindNum());
								
					
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getQuantity());
					
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getProdStatus());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPlmUoM());
								
								if(dataObj.getPartDesc().contains("HAZ")){
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
									cell.setCellStyle(redcontentStyle);
									cell.setCellValue(dataObj.getPartDesc());
								}else{
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getPartDesc());	
								}
								
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getGeApplicationNotes());
							
								//PLM State is highlighted as red based on conditions
								 if(dataObj.getPlmState().equalsIgnoreCase("Obsolete")){
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TEN);
									cell.setCellStyle(redCellStyle);
									cell.setCellValue(dataObj.getPlmState());
								}else{
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getPlmState());
								}
								 
								 
								 	cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getAlternatePart());
									
									
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWELVE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getGePreferedReplacement());
									
								
								 //chemical code is EMPTY and ERP status is EMPTY then ERP Item status is highlighted as red
								if((PLMUtils.isEmpty(dataObj.getPlmChmclCode()) && PLMUtils.isEmpty(dataObj.getErpItmStaus()))
									|| (dataObj.getErpItmStaus().equalsIgnoreCase("Obsolete")|| dataObj.getErpItmStaus().equalsIgnoreCase("Superceded")
											||dataObj.getErpItmStaus().equalsIgnoreCase("Superced-W"))){
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
									cell.setCellStyle(redCellStyle);
									cell.setCellValue(dataObj.getErpItmStaus());
									//ERP Item status is highlighted as yellow based on conditions
								}else if(dataObj.getErpItmStaus().equalsIgnoreCase("SI Active") || dataObj.getErpItmStaus().equalsIgnoreCase("Inactive")){
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
									cell.setCellStyle(yellowCellStyle);
									cell.setCellValue(dataObj.getErpItmStaus());
								}else{
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getErpItmStaus());
								}
								
								
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getSupercededTo());
								
							
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getItemCost());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getErpTotalCycle());
								
								if((!PLMUtils.isEmpty(dataObj.getErpUoM()) && !PLMUtils.isEmpty(dataObj.getPlmUoM()))
										&& !dataObj.getPlmUoM().equalsIgnoreCase(dataObj.getErpUoM())){
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
									cell.setCellStyle(redcontentStyle);
									cell.setCellValue(dataObj.getErpUoM());
								}else{
								  cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
								  cell.setCellStyle(contentStyle);
								  cell.setCellValue(dataObj.getErpUoM());
								}
								 //chemical code is either "LIQ" or "GAS" or EMPTY - highlighted as yellow
								if((dataObj.getPlmChmclCode().equalsIgnoreCase("LIQ") || dataObj.getPlmChmclCode().equalsIgnoreCase("GAS"))
										|| (PLMUtils.isEmpty(dataObj.getPlmChmclCode()))){
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHTEEN);
									cell.setCellStyle(yellowCellStyle);
									cell.setCellValue(dataObj.getPlmChmclCode());
								}else{
									cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHTEEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getPlmChmclCode());
								}
								
								
								StringBuffer errorText= new StringBuffer();
								
								//Appending the error Text based on the following conditions
								
								//condition for Any part at any level of the BOM that is "Obsolete" in PLM
								if(dataObj.getPlmState().equalsIgnoreCase("Obsolete")){
								  errorText.append("Part is Obsolete in PLM; revise or clone higher assembly and replace with current alternate part;");
								}
								
								//condition for Any part at any level of the BOM that is in an ERP item status of Obsolete,Superceded,Supersed-W.
								if(dataObj.getErpItmStaus().equalsIgnoreCase("Obsolete") ||dataObj.getErpItmStaus().equalsIgnoreCase("Superced-W")
										|| dataObj.getErpItmStaus().equalsIgnoreCase("Superceded")){
								 errorText.append("Obsolete, Superseded or Superced-W: Part is not orderable in ERP (revise/clone BOM and replace part);");
								}
								
								//condition If ERP Item Status is SI Active.
								if(dataObj.getErpItmStaus().equalsIgnoreCase("SI Active")){
								 errorText.append("SI Active: Part is not orderable at this level (check other levels);");	
								}	

								//condition If ERP Item Status is Inactive.
								if(dataObj.getErpItmStaus().equalsIgnoreCase("Inactive")){
								 errorText.append("Inactive Part: May take additional time to obtain supplier quotes.;");	
								}	
								
								//condition for Parts whose PLM UOM differs from the ERP UOM.
								if((!PLMUtils.isEmpty(dataObj.getErpUoM()) && !PLMUtils.isEmpty(dataObj.getPlmUoM()))
										&& !dataObj.getPlmUoM().equalsIgnoreCase(dataObj.getErpUoM())){
									 errorText.append("PLM-ERP Unit of Measure Mismatch (clone and supersede part);");
								}
								
								//condition for Parts with alphabetical revisions rather than numeric ones.
								if(!PLMUtils.isEmpty(dataObj.getPartRev()) &&!PLMUtils.checkAlphabetic(dataObj.getPartRev())){
									 errorText.append("Revise part to numerical revision level;");
								}
								
								//condition for Parts at any level in the BOM with EMPTY value in Chemical Code and ERP Itm Status field in PLM Part Properties; 
								if(PLMUtils.isEmpty(dataObj.getPlmChmclCode()) && PLMUtils.isEmpty(dataObj.getErpItmStaus())){
									 errorText.append("ERP requires Chemical Code (set for new parts);");
								}
								
								//condition for Parts whose PLM Description contains the string "HAZ"
								if(dataObj.getPartDesc().contains("HAZ")){
									 errorText.append("Avoid \"HAZ\" in part descriptions where possible;");
								}
								
								//condition for Parts whose chemical code is either "LIQ" or "GAS". 
								if(dataObj.getPlmChmclCode().equalsIgnoreCase("LIQ") || dataObj.getPlmChmclCode().equalsIgnoreCase("GAS")){
									 errorText.append("Ensure chemicals are in separate VDIR BOM group;");
								}
							
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINETEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(errorText.toString());
								
								
								
							}//end of for loop bomDftResultList
						}//end of if isEmptyList(bomDftResultList)

					  	sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,3200);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,4000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,1500);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,2000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,3500);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,4500);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,3000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,3000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,8000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE,8000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN,3500);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN, 4500);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWELVE, 4500);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTEEN, 5000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTEEN, 4500);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTEEN, 4500);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIXTEEN, 4500);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVENTEEN, 4500);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHTEEN, 4500);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINETEEN, 18000);
						sheet.createFreezePane( 0, 3 );
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveBomDefectXLSFile: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveBomDefectXLSFile: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveBomDefectXLSFile: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveBomDefectXLSFile Method");
	}
	
	/**
	 * This method is used for Bordering Cell in XLS
	 * 
	 * @return XSSFCellStyle
	 */
	
	private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
		style.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style.setBorderRight(XSSFCellStyle.BORDER_THIN);
		return style;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}
	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	
	/**
	 * @return the plmBomDfctRptService
	 */
	public PLMBomDfctRptServiceIfc getPlmBomDfctRptService() {
		return plmBomDfctRptService;
	}
	/**
	 * @param plmBomDfctRptService the plmBomDfctRptService to set
	 */
	public void setPlmBomDfctRptService(PLMBomDfctRptServiceIfc plmBomDfctRptService) {
		this.plmBomDfctRptService = plmBomDfctRptService;
	}
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}
	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}
	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}
	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}
	
	/**
	 * @return the userDetails
	 */
	public PLMPwiUserData getUserDetails() {
		return userDetails;
	}
	/**
	 * @param userDetails the userDetails to set
	 */
	public void setUserDetails(PLMPwiUserData userDetails) {
		this.userDetails = userDetails;
	}



	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}
	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	/**
	 * @return the alertBomDefctMsg
	 */
	public String getAlertBomDefctMsg() {
		return alertBomDefctMsg;
	}
	/**
	 * @param alertBomDefctMsg the alertBomDefctMsg to set
	 */
	public void setAlertBomDefctMsg(String alertBomDefctMsg) {
		this.alertBomDefctMsg = alertBomDefctMsg;
	}

	/**
	 * @return the bomDftListData
	 */
	public List<PLMBomDfctRptData> getBomDftListData() {
		return bomDftListData;
	}

	/**
	 * @param bomDftListData the bomDftListData to set
	 */
	public void setBomDftListData(List<PLMBomDfctRptData> bomDftListData) {
		this.bomDftListData = bomDftListData;
	}

}
