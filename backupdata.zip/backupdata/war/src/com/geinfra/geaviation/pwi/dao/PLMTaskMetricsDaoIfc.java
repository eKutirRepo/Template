/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMTaskMetricsDaoIfc.java
 * @Creation date: 15-June-2011
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */


package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMProjectTaskData;
import com.geinfra.geaviation.pwi.data.PLMTaskMetricsData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMTaskMetricsDaoIfc {
	/**
	 * This method is used for getStatusDropDownvalues
	 * 
	 * @param searchResultsQry
	 * @return Map
	 * @throws PLMCommonException
	 */
    Map<String, List<SelectItem>> getStatusDropDownvalues()throws PLMCommonException;
    /**
	 * This method is used for getPrjDropDownvalues
	 * 
	 * @param searchResultsQry
	 * @return Map
	 * @throws PLMCommonException
	 */
    Map<String, List<SelectItem>> getPrjDropDownvalues()throws PLMCommonException;
    /**
	 * This method is used for getPrjSearchData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	List<PLMProjectTaskData> getPrjSearchData(StringBuffer searchResultsQry) throws PLMCommonException;
	  /**
	 * This method is used for loadTaskVolumeReport
	 * 
	 * @param taskMetricData,taskVolumeList
	 * @return List
	 * @throws PLMCommonException
	 */
	List<PLMTaskMetricsData> loadTaskVolumeReport(PLMTaskMetricsData taskMetricData,List<PLMTaskMetricsData> taskVolumeList) throws PLMCommonException;
	  /**
	 * This method is used for loadTaskVolumeDetailReport
	 * 
	 * @param taskMetricData
	 * @return List
	 * @throws PLMCommonException
	 */
	List<String> loadTaskVolumeDetailReport(PLMTaskMetricsData taskMetricData) throws PLMCommonException;
	  /**
	 * This method is used for taskVolumeExpandVP
	 * 
	 * @param taskMetricData,taskVolumeList
	 * @return List
	 * @throws PLMCommonException
	 */
	List<PLMTaskMetricsData> taskVolumeExpandVP(PLMTaskMetricsData taskMetricData,List<PLMTaskMetricsData> taskVolumeList) throws PLMCommonException;
	  /**
	 * This method is used for taskVolumeExpandGM
	 * 
	 * @param taskMetricData,taskVolumeList
	 * @return List
	 * @throws PLMCommonException
	 */
	List<PLMTaskMetricsData> taskVolumeExpandGM(PLMTaskMetricsData taskMetricData,List<PLMTaskMetricsData> taskVolumeList) throws PLMCommonException;
	  /**
	 * This method is used for taskVolumeExpandFM
	 * 
	 * @param taskMetricData,taskVolumeList
	 * @return List
	 * @throws PLMCommonException
	 */
	List<PLMTaskMetricsData> taskVolumeExpandFM(PLMTaskMetricsData taskMetricData,List<PLMTaskMetricsData> taskVolumeList) throws PLMCommonException;
	  /**
	 * This method is used for taskVolumeExpandMgr4
	 * 
	 * @param taskMetricData,taskVolumeList
	 * @return List
	 * @throws PLMCommonException
	 */
	List<PLMTaskMetricsData> taskVolumeExpandMgr4(PLMTaskMetricsData taskMetricData,List<PLMTaskMetricsData> taskVolumeList) throws PLMCommonException;
	  /**
	 * This method is used for taskVolumeExpandMgr3
	 * 
	 * @param taskMetricData,taskVolumeList
	 * @return List
	 * @throws PLMCommonException
	 */
	List<PLMTaskMetricsData> taskVolumeExpandMgr3(PLMTaskMetricsData taskMetricData,List<PLMTaskMetricsData> taskVolumeList) throws PLMCommonException;
	  /**
	 * This method is used for taskVolumeExpandMgr2
	 * 
	 * @param taskMetricData,taskVolumeList
	 * @return List
	 * @throws PLMCommonException
	 */
	List<PLMTaskMetricsData> taskVolumeExpandMgr2(PLMTaskMetricsData taskMetricData,List<PLMTaskMetricsData> taskVolumeList) throws PLMCommonException;
	  /**
	 * This method is used for taskVolumeExpandMgr1
	 * 
	 * @param taskMetricData,taskVolumeList
	 * @return List
	 * @throws PLMCommonException
	 */
	List<PLMTaskMetricsData> taskVolumeExpandMgr1(PLMTaskMetricsData taskMetricData,List<PLMTaskMetricsData> taskVolumeList) throws PLMCommonException;
}