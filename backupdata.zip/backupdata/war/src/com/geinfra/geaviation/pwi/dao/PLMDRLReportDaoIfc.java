/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMDRLReportDaoIfc.java
 * @Creation date: 05-Nov-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.data.PLMDRLReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMDRLReportDaoIfc {
	/**
	 * This method is used to get Result List
	 * 
	 * @param plmDRLReportData
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMDRLReportData> getDRLReportResult(PLMDRLReportData plmDRLReportData) throws PLMCommonException;

}
