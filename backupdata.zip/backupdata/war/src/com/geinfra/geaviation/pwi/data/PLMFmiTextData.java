/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMFmiTextData.java
 * @Creation date: 11-June-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.data;

import java.io.File;

public class PLMFmiTextData {
	/**
	  * Holds the templatepath
	  */
	private String templatepath;
	/**
	  * Holds the filename
	  */
	private String filename;
	/**
	  * Holds the srcfile
	  */
	private File srcfile;
	/**
	  * Holds the id
	  */
	private int id;
	/**
	  * Holds the name
	  */
	private String name;
	/**
	  * Holds the marketingname
	  */
	private String marketingname;
	/**
	  * Holds the cinomenclature
	  */
	private String cinomenclature;
	/**
	  * Holds the cinomenclaturdesc
	  */
	private String cinomenclaturdesc;
	/**
	  * Holds the fmitext
	  */
	private String fmitext;
	/**
	  * Holds the fmitext1
	  */
	private String fmitext1;
	/**
	  * Holds the specialnotestext
	  */
	private String specialnotestext;
	/**
	  * Holds the fieldtext
	  */
	private String fieldtext;
	/**
	  * Holds the repairtext
	  */
	private String repairtext;
	/**
	  * Holds the specialtoolstext
	  */
	private String specialtoolstext;
	/**
	  * Holds the refdoctext
	  */
	private String refdoctext;
	/**
	  * Holds the createdBy
	  */
	private String createdBy;
	/**
	  * Holds the creationdate
	  */
	private String creationdate;
	/**
	  * Holds the lastUpdatedBy
	  */
	private String lastUpdatedBy;
	/**
	  * Holds the lastUpdatedDate
	  */
	private String lastUpdatedDate;
	/**
	  * Holds the errormessage
	  */
	private String fmiTxtErrMsg;

	/**
	 * @return the templatepath
	 */
	public String getTemplatepath() {
		return templatepath;
	}

	/**
	 * @param templatepath
	 *            the templatepath to set
	 */
	public void setTemplatepath(String templatepath) {
		this.templatepath = templatepath;
	}

	/**
	 * @return the filename
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * @param filename
	 *            the filename to set
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}

	/**
	 * @return the srcfile
	 */
	public File getSrcfile() {
		return srcfile;
	}

	/**
	 * @param srcfile
	 *            the srcfile to set
	 */
	public void setSrcfile(File srcfile) {
		this.srcfile = srcfile;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the cinomenclature
	 */
	public String getCinomenclature() {
		return cinomenclature;
	}

	/**
	 * @param cinomenclature
	 *            the cinomenclature to set
	 */
	public void setCinomenclature(String cinomenclature) {
		this.cinomenclature = cinomenclature;
	}

	/**
	 * @return the cinomenclaturdesc
	 */
	public String getCinomenclaturdesc() {
		return cinomenclaturdesc;
	}

	/**
	 * @param cinomenclaturdesc
	 *            the cinomenclaturdesc to set
	 */
	public void setCinomenclaturdesc(String cinomenclaturdesc) {
		this.cinomenclaturdesc = cinomenclaturdesc;
	}

	/**
	 * @return the fmitext
	 */
	public String getFmitext() {
		return fmitext;
	}

	/**
	 * @param fmitext
	 *            the fmitext to set
	 */
	public void setFmitext(String fmitext) {
		this.fmitext = fmitext;
	}
	
	/**
	 * @return the fmitext1
	 */
	public String getFmitext1() {
		return fmitext1;
	}
	/**
	 * @param fmitext
	 *            the fmitext to set
	 */
	public void setFmitext1(String fmitext1) {
		this.fmitext1 = fmitext1;
	}


	/**
	 * @return the specialnotestext
	 */
	public String getSpecialnotestext() {
		return specialnotestext;
	}

	/**
	 * @param specialnotestext
	 *            the specialnotestext to set
	 */
	public void setSpecialnotestext(String specialnotestext) {
		this.specialnotestext = specialnotestext;
	}

	/**
	 * @return the fieldtext
	 */
	public String getFieldtext() {
		return fieldtext;
	}

	/**
	 * @param fieldtext
	 *            the fieldtext to set
	 */
	public void setFieldtext(String fieldtext) {
		this.fieldtext = fieldtext;
	}

	/**
	 * @return the repairtext
	 */
	public String getRepairtext() {
		return repairtext;
	}

	/**
	 * @param repairtext
	 *            the repairtext to set
	 */
	public void setRepairtext(String repairtext) {
		this.repairtext = repairtext;
	}

	/**
	 * @return the specialtoolstext
	 */
	public String getSpecialtoolstext() {
		return specialtoolstext;
	}

	/**
	 * @param specialtoolstext
	 *            the specialtoolstext to set
	 */
	public void setSpecialtoolstext(String specialtoolstext) {
		this.specialtoolstext = specialtoolstext;
	}

	/**
	 * @return the refdoctext
	 */
	public String getRefdoctext() {
		return refdoctext;
	}

	/**
	 * @param refdoctext
	 *            the refdoctext to set
	 */
	public void setRefdoctext(String refdoctext) {
		this.refdoctext = refdoctext;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdby
	 *            the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the creationdate
	 */
	public String getCreationdate() {
		return creationdate;
	}

	/**
	 * @param creationdate
	 *            the creationdate to set
	 */
	public void setCreationdate(String creationdate) {
		this.creationdate = creationdate;
	}

	/**
	 * @return the lastUpdatedBy
	 */
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	/**
	 * @param lastUpdatedBy
	 *            the lastUpdatedBy to set
	 */
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	/**
	 * @return the marketingname
	 */
	public String getMarketingname() {
		return marketingname;
	}

	/**
	 * @param marketingname
	 *            the marketingname to set
	 */
	public void setMarketingname(String marketingname) {
		this.marketingname = marketingname;
	}

	/**
	 * @return the fmiTxtErrMsg
	 */
	public String getFmiTxtErrMsg() {
		return fmiTxtErrMsg;
	}

	/**
	 * @param fmiTxtErrMsg the fmiTxtErrMsg to set
	 */
	public void setFmiTxtErrMsg(String fmiTxtErrMsg) {
		this.fmiTxtErrMsg = fmiTxtErrMsg;
	}

	/**
	 * @return the lastUpdatedDate
	 */
	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	/**
	 * @param lastUpdatedDate the lastUpdatedDate to set
	 */
	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}