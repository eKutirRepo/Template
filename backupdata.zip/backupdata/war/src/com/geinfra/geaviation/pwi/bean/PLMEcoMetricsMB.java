/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEcoMetricsMB.java
 * @Creation date: 22-July-2011
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.data.PLMEcoMetricsData;
import com.geinfra.geaviation.pwi.service.PLMEcoMetricsServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

public class PLMEcoMetricsMB{
	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMEcoMetricsMB.class);
	/**
	 * Holds the ecocategorylist
	 */
	private List<PLMEcoMetricsData> ecocategorylist = new ArrayList<PLMEcoMetricsData>();
	/**
	 * Holds the ecovolumelist
	 */
	private List<PLMEcoMetricsData> ecovolumelist = new ArrayList<PLMEcoMetricsData>();
	/**
	 * Holds the ecocategorylistcsv
	 */
	private List<PLMEcoMetricsData> ecocategorylistcsv;
	/**
	 * Holds the ecovolumelistcsv
	 */
	private List<PLMEcoMetricsData> ecovolumelistcsv;
	/**
	 * Holds the econameslist
	 */
	private List<String> econameslist;
	/**
	 * Holds the ecocategorydata
	 */
	private PLMEcoMetricsData ecocategorydata = new PLMEcoMetricsData();
	/**
	 * Holds the ecovolumedata
	 */
	private PLMEcoMetricsData ecovolumedata = new PLMEcoMetricsData();
	/**
	 * Holds the ecoMetricService
	 */
	private PLMEcoMetricsServiceIfc ecoMetricService = null;
	/**
	 * Holds the plmkpiecoSearchMB
	 */
	private PLMEcoSearchMB plmkpiecoSearchMB = new PLMEcoSearchMB();
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB=null;
		
   // Eco Category
	
	/**
	 * This method is used for loadEcoCategoryReport
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String loadEcoCategoryReport() throws PLMCommonException {
		LOG.info("Entering loadEcoCategoryReport of MB");
		String fwdflag = "";
		try {
			ecocategorylist = ecoMetricService.loadEcoCategoryReport(ecocategorydata,ecocategorylist);
			if (!PLMUtils.isEmptyList(ecocategorylist)) {
				fwdflag = "ecocategoryreport";
			}
			else
			{
				fwdflag = "invalidecocategoryreport";
			}
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@loadEcoCategoryReport: ", exception);
				fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","ECO Category - Distribution by Type");
			}
			
		try {
			commonMB.insertCannedRptRecordHitInfo("ECO Category-Distribution By Type");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
			try {
			    commonMB.getPLMDateStamp(PLMConstants.ECO_TABLE);
				}catch (PLMCommonException exception) {
					LOG.log(Level.ERROR, "Exception@getPLMDateStamp: ", exception);
				}
				
		LOG.info("Exiting loadEcoCategoryReport of MB");
		return fwdflag;
	}
	
	/**
	 * This method is used for ecoCatExpandVp
	 * 
	 * 
	 * @throws PLMCommonException
	 */
  	public void ecoCatExpandVp() throws PLMCommonException {
		LOG.info("Entering ecoCatExpandVp of MB");
		try {
			ecocategorylist = ecoMetricService.ecoCatExpandVp(ecocategorydata,ecocategorylist);
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@ecoCatExpandVp: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecocategoryreport","ECO Category - Distribution by Type");
				throw exception;
			}
		LOG.info("Exiting ecoCatExpandVp of MB");
	}	

  	/**
	 * This method is used for ecoCatExpandGm
	 * 
	 * 
	 * @throws PLMCommonException
	 */
	public void ecoCatExpandGm() throws PLMCommonException {
		LOG.info("Entering ecoCatExpandGm of MB");
		try {
			ecocategorylist = ecoMetricService.ecoCatExpandGm(ecocategorydata,ecocategorylist);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@ecoCatExpandGm: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecocategoryreport","ECO Category - Distribution by Type");
				throw exception;
			}
		LOG.info("Exiting ecoCatExpandGm of MB");
	}
	
	/**
	 * This method is used for ecoCatExpandFm
	 * 
	 * 
	 * @throws PLMCommonException
	 */
	public void ecoCatExpandFm() throws PLMCommonException {
		LOG.info("Entering ecoCatExpandFm of MB");
		try {
			ecocategorylist = ecoMetricService.ecoCatExpandFm(ecocategorydata,ecocategorylist);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@ecoCatExpandFm: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecocategoryreport","ECO Category - Distribution by Type");
				throw exception;
			}
		LOG.info("Exiting ecoCatExpandFm of MB");
	}	
	/**
	 * This method is used for ecoCatExpandMgr4
	 * 
	 * 
	 * @throws PLMCommonException
	 */
	public void ecoCatExpandMgr4() throws PLMCommonException {
		LOG.info("Entering ecoCatExpandMgr4 of MB");
		try {
			ecocategorylist = ecoMetricService.ecoCatExpandMgr4(ecocategorydata,ecocategorylist);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@ecoCatExpandMgr4: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecocategoryreport","ECO Category - Distribution by Type");
				throw exception;
			}
		LOG.info("Exiting ecoCatExpandMgr4 of MB");
	}	
	
	/**
	 * This method is used for ecoCatExpandMgr3
	 * 
	 * 
	 * @throws PLMCommonException
	 */
	public void ecoCatExpandMgr3() throws PLMCommonException {
		LOG.info("Entering ecoCatExpandMgr3 of MB");
		try {
			ecocategorylist = ecoMetricService.ecoCatExpandMgr3(ecocategorydata,ecocategorylist);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@ecoCatExpandMgr3: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecocategoryreport","ECO Category - Distribution by Type");
				throw exception;
			}
		LOG.info("Exiting ecoCatExpandMgr3 of MB");	
	}	
	
	/**
	 * This method is used for ecoCatExpandMgr2
	 * 
	 * 
	 * @throws PLMCommonException
	 */
	public void ecoCatExpandMgr2() throws PLMCommonException {
		LOG.info("Entering ecoCatExpandMgr2 of MB");
		try {
			ecocategorylist = ecoMetricService.ecoCatExpandMgr2(ecocategorydata,ecocategorylist);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@ecoCatExpandMgr2: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecocategoryreport","ECO Category - Distribution by Type");
				throw exception;
			}
		LOG.info("Exiting ecoCatExpandMgr2 of MB");
	}
	
	/**
	 * This method is used for ecoCatExpandMgr1
	 * 
	 * 
	 * @throws PLMCommonException
	 */
	public void ecoCatExpandMgr1() throws PLMCommonException {
		LOG.info("Entering ecoCatExpandMgr1 of MB");
		try {
			ecocategorylist = ecoMetricService.ecoCatExpandMgr1(ecocategorydata,ecocategorylist);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@ecoCatExpandMgr1: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecocategoryreport","ECO Category - Distribution by Type");
				throw exception;
			}
		LOG.info("Exiting ecoCatExpandMgr1 of MB");
	}
	/**
	 * This method is used for loadEcoCategoryDetailReport
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String loadEcoCategoryDetailReport() throws PLMCommonException {
		LOG.info("Entering loadEcoCategoryDetailReport of MB");
		String fwdflag ="";
		try {
			econameslist = ecoMetricService.loadEcoCategoryDetailReport(ecocategorydata);
			if(!PLMUtils.isEmptyList(econameslist))
			{
				LOG.info("Size of List : " + econameslist.size());
				fwdflag = plmkpiecoSearchMB.getEcoCategoryDetailReport(econameslist,ecocategorydata);
			}
			else
			{
				fwdflag = "invalidEco";
			}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@loadEcoCategoryDetailReport: ", exception);
				fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecocategoryreport","ECO Category - Distribution by Type");
			}
			plmkpiecoSearchMB.setPage("ecocategory");
			LOG.info("Exiting loadEcoCategoryDetailReport of MB");
			return fwdflag;
		}
	
	/**
	 * This method is used for loadEcoCategoryCsv
	 * 
	 * @return String
	 * 
	 */
	public void loadEcoCategory(){
		LOG.info("Entering loadEcoCategory of MB");
		ecocategorylistcsv = new ArrayList<PLMEcoMetricsData>() ;
		if(!PLMUtils.isEmptyList(ecocategorylist))
		{
			for (int vpindex = 0; vpindex < ecocategorylist.size();vpindex++)
			{
				PLMEcoMetricsData tempdata =  ecocategorylist.get(vpindex);
				ecocategorylistcsv.add(tempdata);
				if(ecocategorylist.get(vpindex).isCollapse())
				{
					List<PLMEcoMetricsData> gmlist = ecocategorylist.get(vpindex).getGmTable();
						if(!PLMUtils.isEmptyList(gmlist))
						{
							for (int gmindex = 0; gmindex < gmlist.size();gmindex++)
							{
								tempdata =  gmlist.get(gmindex);
								ecocategorylistcsv.add(tempdata);
								if(tempdata.isCollapse())
								{
									List<PLMEcoMetricsData> fmlist = gmlist.get(gmindex).getFmTable();
										if(!PLMUtils.isEmptyList(fmlist))
										{
											for (int fmindex = 0; fmindex < fmlist.size();fmindex++)
											{
												tempdata =  fmlist.get(fmindex);
												ecocategorylistcsv.add(tempdata);
													if(tempdata.isCollapse())
													{
														List<PLMEcoMetricsData> mgr4list = fmlist.get(fmindex).getMgr4table();
														if(!PLMUtils.isEmptyList(mgr4list))
														{
															for (int mgr4index = 0; mgr4index < mgr4list.size();mgr4index++)
															{
																tempdata =  mgr4list.get(mgr4index);
																ecocategorylistcsv.add(tempdata);
																  if(tempdata.isCollapse())
																	{
																	  List<PLMEcoMetricsData> mgr3list = mgr4list.get(mgr4index).getMgr3table();
																	if(!PLMUtils.isEmptyList(mgr3list))
																	{
																		for (int mgr3index = 0; mgr3index < mgr3list.size();mgr3index++)
																		{
																			tempdata =  mgr3list.get(mgr3index);
																			 ecocategorylistcsv.add(tempdata);
																				if(tempdata.isCollapse())
																				{
																					List<PLMEcoMetricsData> mgr2list = mgr3list.get(mgr3index).getMgr2table();
																					if(!PLMUtils.isEmptyList(mgr2list))
																					   {
																						for (int mgr2index = 0; mgr2index < mgr2list.size();mgr2index++)
																							{
																								tempdata =  mgr2list.get(mgr2index);
																								ecocategorylistcsv.add(tempdata);
																								if(tempdata.isCollapse())
																								{
																									List<PLMEcoMetricsData> mgr1list = mgr2list.get(mgr2index).getMgr1table();
																								if(!PLMUtils.isEmptyList(mgr1list))
																								   {
																									for (int mgr1index = 0; mgr1index < mgr1list.size();mgr1index++)
																										{
																										tempdata =  mgr1list.get(mgr1index);
																										ecocategorylistcsv.add(tempdata);
																										if(tempdata.isCollapse())
																										   {
																											List<PLMEcoMetricsData> ownerlist = mgr1list.get(mgr1index).getOwnertable();
																											if(!PLMUtils.isEmptyList(ownerlist))
																											   {
																												for (int ownerindex = 0; ownerindex < ownerlist.size();ownerindex++)
																													{
																													tempdata =  ownerlist.get(ownerindex);
																													ecocategorylistcsv.add(tempdata);
																													}
																											   }
																										   }
																										}
																								   }
																								}
																							}
																					   }
																				}
																			}
																		}
																	}
																}
														}
													}
											}
										}
									}
							}
						}
					}
			}
		}
		LOG.info("Exitign loadEcoCategory of MB");
	}
	
	/**
	 * This method is used to download excel for EC
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	
	public void downloadECExcel() throws PLMCommonException {
		
		LOG.info("Entering downloadECExcel Method");
		String reportName="ecocategoryreportDoc";
		String fileName="ecocategoryreport";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("name", "Name", FormatType.TEXT, null, null, 30),
                    new PLMXlsxRptColumn("missingreqerror", "Missing Req Error", FormatType.INTEGER, null, null, 16),
                    new PLMXlsxRptColumn("productimprovement", "Product Improvement", FormatType.INTEGER, null, null, 20),
                    new PLMXlsxRptColumn("unassigned", "Unassigned", FormatType.INTEGER, null, null, 11),
                    new PLMXlsxRptColumn("initialrelease", "Initial Release", FormatType.INTEGER, null, null, 13),
                    new PLMXlsxRptColumn("customerchange", "Customer Change", FormatType.INTEGER, null, null, 16)
			};

		PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] {};

		excelUtil.export(ecocategorylistcsv, reportColumns, fileName, fileName, true, critcolumns, ecocategorydata);
		
	}
	
	/**
	 * This method is used for Generating Report in CSV for EC
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadECCSV() throws PLMCommonException {
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
				new PLMCsvRptColumn("name", "Name", FormatTypeCsv.TEXT, null, null, 30),
                new PLMCsvRptColumn("missingreqerror", "Missing Req Error", FormatTypeCsv.INTEGER, null, null, 16),
                new PLMCsvRptColumn("productimprovement", "Product Improvement", FormatTypeCsv.INTEGER, null, null, 20),
                new PLMCsvRptColumn("unassigned", "Unassigned", FormatTypeCsv.INTEGER, null, null, 11),
                new PLMCsvRptColumn("initialrelease", "Initial Release", FormatTypeCsv.INTEGER, null, null, 13),
                new PLMCsvRptColumn("customerchange", "Customer Change", FormatTypeCsv.INTEGER, null, null, 16)
		};

		csvUtil.exportCsv(ecocategorylistcsv, reportColumns, "ecocategoryreport", dateFormat, false, null, null, ",");
		
	}
	
	/**
	 * This method is used for Downloading EV Report in Excel
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadECExcelInit() throws PLMCommonException {
		
		loadEcoCategory();
		downloadECExcel();
		
	}
	
	/**
	 * This method is used for Downloading EV Report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadECCSVInit() throws PLMCommonException {
		
		loadEcoCategory();
		downloadECCSV();
		
	}
	
	//Eco Volume
	
	/**
	 * This method is used for loadEcoVolumeReport
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String loadEcoVolumeReport() throws PLMCommonException {
		LOG.info("Entering loadEcoVolumeReport of MB");
		String fwdflag = "";
			
		try	{
			
			ecovolumelist = ecoMetricService.loadEcoVolumeReport(ecovolumedata,ecovolumelist);
			if (!PLMUtils.isEmptyList(ecovolumelist)) {
			fwdflag = "ecovolumereport";
			}
			else
			{
			fwdflag = "invalidecovolumereport";
			}
		}catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadEcoVolumeReport: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","ECO Volume");
		}
		
		try {
			commonMB.insertCannedRptRecordHitInfo("ECO Volume");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try	{
			commonMB.getPLMDateStamp(PLMConstants.ECO_TABLE);
			}catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPLMDateStamp: ", exception);
		}
		LOG.info("Exiting loadEcoVolumeReport of MB");
		return fwdflag;
	}
	
	/**
	 * This method is used for ecoVolExpandVp
	 * 
	 * 
	 * @throws PLMCommonException
	 */
   public void ecoVolExpandVp() throws PLMCommonException {
		LOG.info("Entering ecoVolExpandVp of MB");
		try {
			ecovolumelist = ecoMetricService.ecoVolExpandVp(ecovolumedata,ecovolumelist);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@ecoVolExpandVp: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecovolumereport","ECO Volume");
				throw exception;
			}
		LOG.info("Exiting ecoVolExpandVp of MB");	
	}	
	
	/**
	 * This method is used for ecoVolExpandGm
	 * 
	 * 
	 * @throws PLMCommonException
	 */
	public void ecoVolExpandGm() throws PLMCommonException {
		LOG.info("Entering ecoVolExpandGm of MB");
		try {
			ecovolumelist = ecoMetricService.ecoVolExpandGm(ecovolumedata,ecovolumelist);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@ecoVolExpandGm: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecovolumereport","ECO Volume");
				throw exception;
			}
		LOG.info("Exiting ecoVolExpandGm of MB");	
	}
	/**
	 * This method is used for ecoVolExpandFm
	 * 
	 * 
	 * @throws PLMCommonException
	 */
	public void ecoVolExpandFm() throws PLMCommonException {
		LOG.info("Entering ecoVolExpandFm of MB");
		try {
			ecovolumelist = ecoMetricService.ecoVolExpandFm(ecovolumedata,ecovolumelist);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@ecoVolExpandFm: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecovolumereport","ECO Volume");
				throw exception;
			}
		LOG.info("Exiting ecoVolExpandFm of MB");	
	}	
	
	/**
	 * This method is used for ecoVolExpandMgr4
	 * 
	 * 
	 * @throws PLMCommonException
	 */
	public void ecoVolExpandMgr4() throws PLMCommonException {
		LOG.info("Entering ecoVolExpandMgr4 of MB");
		try {
			ecovolumelist = ecoMetricService.ecoVolExpandMgr4(ecovolumedata,ecovolumelist);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@ecoVolExpandMgr4: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecovolumereport","ECO Volume");
				throw exception;
			}
		LOG.info("Exiting ecoVolExpandMgr4 of MB");	
	}	
	/**
	 * This method is used for ecoVolExpandMgr3
	 * 
	 * 
	 * @throws PLMCommonException
	 */
	public void ecoVolExpandMgr3() throws PLMCommonException {
		LOG.info("Entering ecoVolExpandMgr3 of MB");
		try {
			ecovolumelist = ecoMetricService.ecoVolExpandMgr3(ecovolumedata,ecovolumelist);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@ecoVolExpandMgr3: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecovolumereport","ECO Volume");
				throw exception;
			}
		LOG.info("Exiting ecoVolExpandMgr3 of MB");
	}	
	
	/**
	 * This method is used for ecoVolExpandMgr2
	 * 
	 * 
	 * @throws PLMCommonException
	 */
	public void ecoVolExpandMgr2() throws PLMCommonException {
		LOG.info("Entering ecoVolExpandMgr2 of MB");
		try {
			ecovolumelist = ecoMetricService.ecoVolExpandMgr2(ecovolumedata,ecovolumelist);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@ecoVolExpandMgr2: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecovolumereport","ECO Volume");
				throw exception;
			}
		LOG.info("Exiting ecoVolExpandMgr2 of MB");
	}
	
	/**
	 * This method is used for ecoVolExpandMgr1
	 * 
	 * 
	 * @throws PLMCommonException
	 */
	public void ecoVolExpandMgr1() throws PLMCommonException {
		LOG.info("Entering ecoVolExpandMgr1 of MB");
		try {
			ecovolumelist = ecoMetricService.ecoVolExpandMgr1(ecovolumedata,ecovolumelist);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@ecoVolExpandMgr1: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecovolumereport","ECO Volume");
				throw exception;
			}
		LOG.info("Exiting ecoVolExpandMgr1 of MB");
	}

	/**
	 * This method is used for loadEcoVolumeDetailReport
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String loadEcoVolumeDetailReport() throws PLMCommonException {
		LOG.info("Entering loadEcoVolumeDetailReport of MB");
		String fwdflag ="";
		try {
			econameslist = ecoMetricService.loadEcoVolumeDetailReport(ecovolumedata);
			if(!PLMUtils.isEmptyList(econameslist))
			{
				LOG.info("Size of List : " + econameslist.size());
				fwdflag = plmkpiecoSearchMB.getEcoVolumeDetailReport(econameslist,ecovolumedata);
			}
			else
			{
				fwdflag = "invalidEco";
			}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@loadEcoVolumeDetailReport: ", exception);
				fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecovolumereport","ECO Volume");
			}
			plmkpiecoSearchMB.setPage("ecovolume");
			LOG.info("Exiting loadEcoVolumeDetailReport of MB");
			return fwdflag;
		}
	/**
	 * This method is used for loadEcoVolumeCsv
	 * 
	 * @return String
	 * @throws PLMCommonException 
	 * 
	 */
	public void loadEcoVolume() throws PLMCommonException
	{
		LOG.info("Entering loadEcoVolume of MB");
		ecovolumelistcsv= new ArrayList<PLMEcoMetricsData>() ;
			if(!PLMUtils.isEmptyList(ecovolumelist))
			{
				for (int vpindex = 0; vpindex < ecovolumelist.size();vpindex++)
				{
					PLMEcoMetricsData tempdata =  ecovolumelist.get(vpindex);
					ecovolumelistcsv.add(tempdata);
					if(ecovolumelist.get(vpindex).isCollapse())
					{
						List<PLMEcoMetricsData> gmlist = ecovolumelist.get(vpindex).getGmTable();
							if(!PLMUtils.isEmptyList(gmlist))
							{
								for (int gmindex = 0; gmindex < gmlist.size();gmindex++)
								{
									tempdata =  gmlist.get(gmindex);
									ecovolumelistcsv.add(tempdata);
									if(tempdata.isCollapse())
									{
										List<PLMEcoMetricsData> fmlist = gmlist.get(gmindex).getFmTable();
											if(!PLMUtils.isEmptyList(fmlist))
											{
												for (int fmindex = 0; fmindex < fmlist.size();fmindex++)
												{
													tempdata =  fmlist.get(fmindex);
													ecovolumelistcsv.add(tempdata);
														if(tempdata.isCollapse())
														{
															List<PLMEcoMetricsData> mgr4list = fmlist.get(fmindex).getMgr4table();
															if(!PLMUtils.isEmptyList(mgr4list))
															{
																for (int mgr4index = 0; mgr4index < mgr4list.size();mgr4index++)
																{
																	tempdata =  mgr4list.get(mgr4index);
																	ecovolumelistcsv.add(tempdata);
																	  if(tempdata.isCollapse())
																		{
																		  List<PLMEcoMetricsData> mgr3list = mgr4list.get(mgr4index).getMgr3table();
																		if(!PLMUtils.isEmptyList(mgr3list))
																		{
																			for (int mgr3index = 0; mgr3index < mgr3list.size();mgr3index++)
																			{
																				tempdata =  mgr3list.get(mgr3index);
																				ecovolumelistcsv.add(tempdata);
																					if(tempdata.isCollapse())
																					{
																						List<PLMEcoMetricsData> mgr2list = mgr3list.get(mgr3index).getMgr2table();
																						if(!PLMUtils.isEmptyList(mgr2list))
																						   {
																							for (int mgr2index = 0; mgr2index < mgr2list.size();mgr2index++)
																								{
																									tempdata =  mgr2list.get(mgr2index);
																									ecovolumelistcsv.add(tempdata);
																									if(tempdata.isCollapse())
																									{
																										List<PLMEcoMetricsData> mgr1list = mgr2list.get(mgr2index).getMgr1table();
																									if(!PLMUtils.isEmptyList(mgr1list))
																									   {
																										for (int mgr1index = 0; mgr1index < mgr1list.size();mgr1index++)
																											{
																											tempdata =  mgr1list.get(mgr1index);
																											ecovolumelistcsv.add(tempdata);
																											if(tempdata.isCollapse())
																											   {
																												List<PLMEcoMetricsData> ownerlist = mgr1list.get(mgr1index).getOwnertable();
																												if(!PLMUtils.isEmptyList(ownerlist))
																												   {
																													for (int ownerindex = 0; ownerindex < ownerlist.size();ownerindex++)
																														{
																														tempdata =  ownerlist.get(ownerindex);
																														ecovolumelistcsv.add(tempdata);
																														}
																												   }
																											   }
																											}
																									   }
																									}
																								}
																						   }
																					}
																				}
																			}
																		}
																	}
															}
														}
												}
											}
										}
								}
							}
						}
				}
			}
		LOG.info("Exiting loadEcoVolume of MB");
		
	}
	
	/**
	 * This method is used to download excel
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	
	public void downloadEVExcel() throws PLMCommonException {
		
		LOG.info("Entering downloadEVExcel Method");
		String reportName="ecovolumereportDoc";
		String fileName="ecovolumereport";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("name", "Name", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("backlog", "ECO Backlog", FormatType.INTEGER, null, null, 11),
                    new PLMXlsxRptColumn("dueWeek", "ECOs Due Week", FormatType.INTEGER, null, null, 15),
                    new PLMXlsxRptColumn("dueMonth", "ECOs Due Month", FormatType.INTEGER, null, null, 16),
                    new PLMXlsxRptColumn("dueYear", "ECOs Due Year", FormatType.INTEGER, null, null, 14)
			};

		PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] {};

		excelUtil.export(ecovolumelistcsv, reportColumns, fileName, fileName, true, critcolumns, ecovolumedata);
		
	}
	
	/**
	 * This method is used for Generating Report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadEVCSV() throws PLMCommonException {
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
				new PLMCsvRptColumn("name", "Name", FormatTypeCsv.TEXT, null, null, 20),
                new PLMCsvRptColumn("backlog", "ECO Backlog", FormatTypeCsv.INTEGER, null, null, 11),
                new PLMCsvRptColumn("dueWeek", "ECOs Due Week", FormatTypeCsv.INTEGER, null, null, 15),
                new PLMCsvRptColumn("dueMonth", "ECOs Due Month", FormatTypeCsv.INTEGER, null, null, 16),
                new PLMCsvRptColumn("dueYear", "ECOs Due Year", FormatTypeCsv.INTEGER, null, null, 14)
		};

		csvUtil.exportCsv(ecovolumelistcsv, reportColumns, "ecovolumereport", dateFormat, false, null, null, ",");
		
	}
	
	/**
	 * This method is used for Downloading EV Report in Excel
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadEVExcelInit() throws PLMCommonException {
		
		loadEcoVolume();
		downloadEVExcel();
		
	}
	
	/**
	 * This method is used for Downloading EV Report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadEVCSVInit() throws PLMCommonException {
		
		loadEcoVolume();
		downloadEVCSV();
		
	}
	
	/**
	 * @return the ecocategorylist
	 */
	public List<PLMEcoMetricsData> getEcocategorylist() {
		return ecocategorylist;
	}

	/**
	 * @param ecocategorylist the ecocategorylist to set
	 */
	public void setEcocategorylist(List<PLMEcoMetricsData> ecocategorylist) {
		this.ecocategorylist = ecocategorylist;
	}
	/**
	 * @return the ecoMetricService
	 */
	public PLMEcoMetricsServiceIfc getEcoMetricService() {
		return ecoMetricService;
	}
	/**
	 * @param PLMEcoMetricsServiceIfc
	 *            the ecoMetricService to set
	 */
	public void setEcoMetricService(PLMEcoMetricsServiceIfc ecoMetricService) {
		this.ecoMetricService = ecoMetricService;
	}
	/**
	 * @return the plmkpiecoSearchMB
	 */
	public PLMEcoSearchMB getPlmkpiecoSearchMB() {
		return plmkpiecoSearchMB;
	}
	/**
	 * @param PLMEcoSearchMB
	 *            the plmkpiecoSearchMB to set
	 */
	public void setPlmkpiecoSearchMB(PLMEcoSearchMB plmkpiecoSearchMB) {
		this.plmkpiecoSearchMB = plmkpiecoSearchMB;
	}
	
	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}

	/**
	 * @return the econameslist
	 */
	public List<String> getEconameslist() {
		return econameslist;
	}

	/**
	 * @param econameslist the econameslist to set
	 */
	public void setEconameslist(List<String> econameslist) {
		this.econameslist = econameslist;
	}

	/**
	 * @return the ecocategorydata
	 */
	public PLMEcoMetricsData getEcocategorydata() {
		return ecocategorydata;
	}

	/**
	 * @param ecocategorydata the ecocategorydata to set
	 */
	public void setEcocategorydata(PLMEcoMetricsData ecocategorydata) {
		this.ecocategorydata = ecocategorydata;
	}

	/**
	 * @return the ecovolumelist
	 */
	public List<PLMEcoMetricsData> getEcovolumelist() {
		return ecovolumelist;
	}

	/**
	 * @param ecovolumelist the ecovolumelist to set
	 */
	public void setEcovolumelist(List<PLMEcoMetricsData> ecovolumelist) {
		this.ecovolumelist = ecovolumelist;
	}

	/**
	 * @return the ecovolumedata
	 */
	public PLMEcoMetricsData getEcovolumedata() {
		return ecovolumedata;
	}

	/**
	 * @param ecovolumedata the ecovolumedata to set
	 */
	public void setEcovolumedata(PLMEcoMetricsData ecovolumedata) {
		this.ecovolumedata = ecovolumedata;
	}

	/**
	 * @return the ecovolumelistcsv
	 */
	public List<PLMEcoMetricsData> getEcovolumelistcsv() {
		return ecovolumelistcsv;
	}

	/**
	 * @param ecovolumelistcsv the ecovolumelistcsv to set
	 */
	public void setEcovolumelistcsv(List<PLMEcoMetricsData> ecovolumelistcsv) {
		this.ecovolumelistcsv = ecovolumelistcsv;
	}

	/**
	 * @return the ecocategorylistcsv
	 */
	public List<PLMEcoMetricsData> getEcocategorylistcsv() {
		return ecocategorylistcsv;
	}

	/**
	 * @param ecocategorylistcsv the ecocategorylistcsv to set
	 */
	public void setEcocategorylistcsv(List<PLMEcoMetricsData> ecocategorylistcsv) {
		this.ecocategorylistcsv = ecocategorylistcsv;
	}
	
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
}