/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMMBOMPddrDaoImpl.java
 * @Creation date: 14-March-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMMBOMPddrData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMMBOMPddrDaoImpl extends SimpleJdbcDaoSupport implements PLMMBOMPddrDaoIfc {
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMMBOMPddrDaoImpl.class);

	/**
	 * This method is used for getDropDownvalues
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getRevisions(String partName) throws PLMCommonException {
		LOG.info("Entering getRevisions method");
		List<SelectItem> revisionList = new ArrayList<SelectItem>();
		try {
			LOG.info("Executed Query for Revisons list"+PLMOfflineQueries.GET_REVISIONS);
			revisionList =getSimpleJdbcTemplate().query(
					PLMOfflineQueries.GET_REVISIONS, new RevisionsListMapper(), partName);
			Collections.sort(revisionList, new PLMUtils.SortListSelItmLbl());
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getRevisions method");
		return revisionList;
	}
	/**
	 * Row mapper for getting dropMapper
	 */
	
	private static final class RevisionsListMapper implements ParameterizedRowMapper<SelectItem>{ 	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(rs.getString("ID")+"~"+rs.getString("REVISION"),rs.getString("REVISION"));
			return selectItem;
		}
   }
	/**
	 * This method is used for getDropDownvalues
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getPlantNames(String partName,String revision) throws PLMCommonException {
		LOG.info("Entering getPlantNames method");
		List<SelectItem> plantNameList = new ArrayList<SelectItem>();
		try {
			LOG.info("Executed Query for Plant Name list"+PLMOfflineQueries.GET_PLANT_NAMES);
			plantNameList =getSimpleJdbcTemplate().query(
					PLMOfflineQueries.GET_PLANT_NAMES, new PlantNameListMapper(), partName,revision);
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getPlantNames method");
		return plantNameList;
	}
	/**
	 * Row mapper for getting dropMapper
	 */
	
	private static final class PlantNameListMapper implements ParameterizedRowMapper<SelectItem>{ 	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(rs.getString("PLANT_ID"),rs.getString("PLANT_NM"));
			return selectItem;
		}
   }
	
	/**
	 * This method is used to get Plant Name count
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public int getPlantNamesCount(String partName)throws PLMCommonException{
		LOG.info("Entering getPlantNamesCount method");
		int count=0;
		try {
			LOG.info("Executed Query for Plant Name list"+PLMOfflineQueries.GET_PLANT_NAMESLIST);
			count =getJdbcTemplate().queryForInt(PLMOfflineQueries.GET_PLANT_NAMESLIST, new Object[] {partName});
			LOG.info("List of Plant Names" +count);
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getPlantNamesCount method");
		return count;
	}

	
	/**
	 * This method is used to get MBOM Pddr Report
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMMBOMPddrData> getMBOMPddrReport(String partName,String plantId,String revisionName,String revisionId)throws PLMCommonException{
		LOG.info("Entering getMBOMPddrReport method");
		List<PLMMBOMPddrData> mbomPddrList = new ArrayList<PLMMBOMPddrData>();
		List<PLMMBOMPddrData> mbomPddrListnew = new ArrayList<PLMMBOMPddrData>();
		String timeStamp = null;
		String VT_ALL_PARTS = null;
		String VT_MBOM = null;
		String VT_TO_DOC = null;
		String VT_GE_DOC = null;
		String VT_PRT_DOC = null;
		String VT_MTR_DOC = null;
		String VT_ALL_DOC = null;
		String VT_PF_ATTR = null;
		String VT_PF_DATA = null;
		String VT_ALT_PART = null;
		String VT_PDDR =null;
		LOG.info("partName>> "+partName);
		LOG.info("revisionId>> "+revisionId);
		LOG.info("revisionName>> "+revisionName);
		LOG.info("Plant Id>> "+plantId);
		try {
			timeStamp = PLMUtils.volTableFormatDate();
			LOG.info("The timeStamp for the Report "+timeStamp);
			
			VT_ALL_PARTS = PLMConstants.VT_ALL_PARTS.concat(timeStamp);
			VT_MBOM = PLMConstants.VT_MBOM.concat(timeStamp);
			VT_TO_DOC = PLMConstants.VT_TO_DOC.concat(timeStamp);
			VT_GE_DOC = PLMConstants.VT_GE_DOC.concat(timeStamp);
			VT_PRT_DOC = PLMConstants.VT_PRT_DOC.concat(timeStamp);
			VT_MTR_DOC = PLMConstants.VT_MTR_DOC.concat(timeStamp);
			VT_ALL_DOC = PLMConstants.VT_ALL_DOC.concat(timeStamp);
			VT_PF_ATTR = PLMConstants.VT_PF_ATTR.concat(timeStamp);
			VT_PF_DATA = PLMConstants.VT_PF_DATA.concat(timeStamp);
			VT_ALT_PART = PLMConstants.VT_ALT_PART.concat(timeStamp);
			VT_PDDR = PLMConstants.VT_PDDR.concat(timeStamp);
		
			LOG.info("Query for Creating VT_ALL_PARTS : " + PLMOfflineQueries.CREATE_VT_ALL_PARTS.replace(PLMConstants.VT_ALL_PARTS, VT_ALL_PARTS));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VT_ALL_PARTS.replace(PLMConstants.VT_ALL_PARTS, VT_ALL_PARTS));
			
			
			LOG.info("Executing DELETE FROM GTT_MBOM_PDDR_RECUR Query : "+PLMOfflineQueries.DELETE_MBOM_PDDR_GTT_RECURSION);
			getJdbcTemplate().execute(PLMOfflineQueries.DELETE_MBOM_PDDR_GTT_RECURSION);
			
			LOG.info("Executing INSERT INTO GTT_MBOM_PDDR_RECUR Query " + PLMOfflineQueries.INSERT_MBOM_PDDR_GTT_RECURSION.replace("?", plantId));
			getJdbcTemplate().update(PLMOfflineQueries.INSERT_MBOM_PDDR_GTT_RECURSION.replace("?", plantId));
			
			LOG.info("Query for Collect STATS MBOM_PDDR_GTT_RECURSION 1 " + PLMOfflineQueries.COLLECT_STATS_MBOM_PDDR_GTT_RECUR1);
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_MBOM_PDDR_GTT_RECUR1);
				
			LOG.info("Query for Collect STATS MBOM_PDDR_GTT_RECURSION 2 " + PLMOfflineQueries.COLLECT_STATS_MBOM_PDDR_GTT_RECUR2);
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_MBOM_PDDR_GTT_RECUR2);
				
			LOG.info("Query for Collect STATS MBOM_PDDR_GTT_RECURSION 3 " + PLMOfflineQueries.COLLECT_STATS_MBOM_PDDR_GTT_RECUR3);
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_MBOM_PDDR_GTT_RECUR3);
			
			LOG.info("Query for Getting PDDR : " + PLMOfflineQueries.GET_PDDR.replace("*", plantId).replace("?", partName).replace("#", revisionName));
			mbomPddrList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_PDDR.replace("*", plantId).replace("?", partName).replace("#", revisionName)
					,new PddrMapper());
			LOG.info("Result of PDDR : " + mbomPddrList.size());
			
			// Set Top Level Parent Data
			PLMMBOMPddrData pddrData = new PLMMBOMPddrData();
			pddrData.setTopLevelParentId(revisionId); 
			pddrData.setTopLevelParentName(partName);
			pddrData.setTopLevelParentRev(revisionName);
			pddrData.setParentId(revisionId);
			pddrData.setParentName(partName);
			pddrData.setParentRev(revisionName);
			pddrData.setChildId(revisionId); 
			pddrData.setChildName(partName);
			pddrData.setChildRev(revisionName);
			pddrData.setDfsOrder(partName);
			pddrData.setBomLevel(1);
			pddrData.setPathFlag("");
			mbomPddrListnew.add(pddrData);
			
			if(!PLMUtils.isEmptyList(mbomPddrList)){
				mbomPddrListnew.addAll(mbomPddrList);
			}
			
			if(!PLMUtils.isEmptyList(mbomPddrListnew)){
				mbomPddrListnew = formTreeStruct(mbomPddrListnew,partName);
				LOG.info("Result of PDDR After Ordering : " + mbomPddrListnew.size());
				
				LOG.info("Query for Creating VT_MBOM : " + PLMOfflineQueries.CREATE_VT_MBOM.replace(PLMConstants.VT_MBOM, VT_MBOM));
				getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VT_MBOM.replace(PLMConstants.VT_MBOM, VT_MBOM));
	
				final List<PLMMBOMPddrData> pddrInsertList = mbomPddrListnew;
				
				int[] updateCount = null;
				LOG.info("Insert Query :  " + PLMOfflineQueries.SET_VT_MBOM.replace(PLMConstants.VT_MBOM, VT_MBOM));
				updateCount  = getSimpleJdbcTemplate().getJdbcOperations().batchUpdate(PLMOfflineQueries.SET_VT_MBOM.
						replace(PLMConstants.VT_MBOM, VT_MBOM), new BatchPreparedStatementSetter() 
				{
				public void setValues(PreparedStatement ps,int iCount)throws SQLException {
					ps.setInt(1,iCount);
					ps.setString(2, pddrInsertList.get(iCount).getRelationId());
					ps.setString(3, pddrInsertList.get(iCount).getTopLevelParentId());
					ps.setString(4, pddrInsertList.get(iCount).getTopLevelParentName());
					ps.setString(5, pddrInsertList.get(iCount).getTopLevelParentRev());
					ps.setString(6, pddrInsertList.get(iCount).getParentId());
					ps.setString(7, pddrInsertList.get(iCount).getParentName());
					ps.setString(8, pddrInsertList.get(iCount).getParentRev());
					ps.setString(9, pddrInsertList.get(iCount).getChildId());
					ps.setInt(10, pddrInsertList.get(iCount).getBomLevel());
					ps.setString(11, pddrInsertList.get(iCount).getFindNumAd());
					ps.setString(12, pddrInsertList.get(iCount).getGeBomPrfixAd());
					ps.setString(13, pddrInsertList.get(iCount).getChildName());
					ps.setString(14, pddrInsertList.get(iCount).getChildRev());
					ps.setString(15, pddrInsertList.get(iCount).getQtyAdd());
					ps.setString(16, pddrInsertList.get(iCount).getFuncCodeAd());
					ps.setString(17, pddrInsertList.get(iCount).getDfsOrder());
				}
				public int getBatchSize() {
					return pddrInsertList.size();
				}
				});
				LOG.info("Total inserted Records : " + updateCount.length);
				
				 //" PARENT_ID,PARENT_NAME,PARENT_REVISION,CHILD_ID,LVL,FIND_NUM,GE_BOM_PREFIX"+
				 //" CHILD_NAME,CHILD_REVISION,QUANTITY,FNCT_CODE,DFSORDER
				
			/*LOG.info("Query for Inserting VT_MBOM for Parent Insertion : " + PLMOfflineQueries.INSERT_VT_MBOM1.replace(PLMConstants.VT_MBOM, VT_MBOM)
					.replace(PLMConstants.VT_ALL_PARTS, VT_ALL_PARTS).replace("?", partName).replace("#", revision));
			getJdbcTemplate().execute(PLMOfflineQueries.INSERT_VT_MBOM1.replace(PLMConstants.VT_MBOM, VT_MBOM).replace(PLMConstants.VT_ALL_PARTS, VT_ALL_PARTS)
					.replace("?", partName).replace("#", revision));
			
			LOG.info("Query for Inserting VT_MBOM for Child Insertion : " + PLMOfflineQueries.INSERT_VT_MBOM2.replace(PLMConstants.VT_MBOM, VT_MBOM)
					.replace("*", plantId).replace("?", partName).replace("#", revision));
			getJdbcTemplate().execute(PLMOfflineQueries.INSERT_VT_MBOM2.replace(PLMConstants.VT_MBOM, VT_MBOM)
					.replace("*", plantId).replace("?", partName).replace("#", revision));*/

			
			LOG.info("Query for collect Stats VT_MBOM : " + PLMOfflineQueries.COLLECT_STATS_VT_MBOM.replace(PLMConstants.VT_MBOM, VT_MBOM));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_VT_MBOM.replace(PLMConstants.VT_MBOM, VT_MBOM));
			
			LOG.info("Query for Updating VT_MBOM for Childs Data  : " + PLMOfflineQueries.UPDATE_VT_MBOM2.replace(PLMConstants.VT_MBOM, VT_MBOM)
					.replace(PLMConstants.VT_ALL_PARTS, VT_ALL_PARTS));
			getJdbcTemplate().execute(PLMOfflineQueries.UPDATE_VT_MBOM2.replace(PLMConstants.VT_MBOM, VT_MBOM)
					.replace(PLMConstants.VT_ALL_PARTS, VT_ALL_PARTS));

			LOG.info("Query for Creating VT_TO_DOC : " + PLMOfflineQueries.CREATE_VT_TO_DOC.replace(PLMConstants.VT_TO_DOC, VT_TO_DOC)
					.replace(PLMConstants.VT_MBOM, VT_MBOM));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VT_TO_DOC.replace(PLMConstants.VT_TO_DOC, VT_TO_DOC)
					.replace(PLMConstants.VT_MBOM, VT_MBOM));
			
			LOG.info("Query for Creating VT_GE_DOC : " + PLMOfflineQueries.CREATE_VT_GE_DOC.replace(PLMConstants.VT_GE_DOC, VT_GE_DOC)
					.replace(PLMConstants.VT_TO_DOC, VT_TO_DOC));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VT_GE_DOC.replace(PLMConstants.VT_GE_DOC, VT_GE_DOC)
					.replace(PLMConstants.VT_TO_DOC, VT_TO_DOC));
			
			LOG.info("Query for Creating VT_PRT_DOC : " + PLMOfflineQueries.CREATE_VT_PRT_DOC.replace(PLMConstants.VT_PRT_DOC, VT_PRT_DOC)
					.replace(PLMConstants.VT_TO_DOC, VT_TO_DOC).replace(PLMConstants.VT_GE_DOC, VT_GE_DOC));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VT_PRT_DOC.replace(PLMConstants.VT_PRT_DOC, VT_PRT_DOC)
					.replace(PLMConstants.VT_TO_DOC, VT_TO_DOC).replace(PLMConstants.VT_GE_DOC, VT_GE_DOC));

			LOG.info("Query for collect Stats1 VT_PRT_DOC : " + PLMOfflineQueries.COLLECT_STATS_VT_PRT_DOC1.replace(PLMConstants.VT_PRT_DOC, VT_PRT_DOC));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_VT_PRT_DOC1.replace(PLMConstants.VT_PRT_DOC, VT_PRT_DOC));
		
			
			LOG.info("Query for collect Stats2 VT_PRT_DOC : " + PLMOfflineQueries.COLLECT_STATS_VT_PRT_DOC2.replace(PLMConstants.VT_PRT_DOC, VT_PRT_DOC));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_VT_PRT_DOC2.replace(PLMConstants.VT_PRT_DOC, VT_PRT_DOC));
		
			
			LOG.info("Query for collect Stats3 VT_PRT_DOC : " + PLMOfflineQueries.COLLECT_STATS_VT_PRT_DOC3.replace(PLMConstants.VT_PRT_DOC, VT_PRT_DOC));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_VT_PRT_DOC3.replace(PLMConstants.VT_PRT_DOC, VT_PRT_DOC));
		

			LOG.info("Query for Creating VT_MTR_DOC : " + PLMOfflineQueries.CREATE_VT_MTR_DOC.replace(PLMConstants.VT_MTR_DOC, VT_MTR_DOC)
					.replace(PLMConstants.VT_MBOM, VT_MBOM));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VT_MTR_DOC.replace(PLMConstants.VT_MTR_DOC, VT_MTR_DOC)
					.replace(PLMConstants.VT_MBOM, VT_MBOM));

			
			LOG.info("Query for Creating VT_ALL_DOC : " + PLMOfflineQueries.CREATE_VT_ALL_DOC.replace(PLMConstants.VT_ALL_DOC, VT_ALL_DOC)
				.replace(PLMConstants.VT_PRT_DOC, VT_PRT_DOC).replace(PLMConstants.VT_MTR_DOC, VT_MTR_DOC).replace(PLMConstants.VT_MBOM, VT_MBOM));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VT_ALL_DOC.replace(PLMConstants.VT_ALL_DOC, VT_ALL_DOC)
				.replace(PLMConstants.VT_PRT_DOC, VT_PRT_DOC).replace(PLMConstants.VT_MTR_DOC, VT_MTR_DOC).replace(PLMConstants.VT_MBOM, VT_MBOM));

			LOG.info("Query for Creating VT_PF_ATTR : " + PLMOfflineQueries.CREATE_VT_PF_ATTR.replace(PLMConstants.VT_PF_ATTR, VT_PF_ATTR)
					.replace(PLMConstants.VT_MBOM, VT_MBOM));
				getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VT_PF_ATTR.replace(PLMConstants.VT_PF_ATTR, VT_PF_ATTR)
					.replace(PLMConstants.VT_MBOM, VT_MBOM));
				
			LOG.info("Query for collect Stats1 VT_PF_ATTR : " + PLMOfflineQueries.COLLECT_STATS_VT_PF_ATTR1.replace(PLMConstants.VT_PF_ATTR, VT_PF_ATTR));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_VT_PF_ATTR1.replace(PLMConstants.VT_PF_ATTR, VT_PF_ATTR));
		
			
			LOG.info("Query for collect Stats2 VT_PF_ATTR : " + PLMOfflineQueries.COLLECT_STATS_VT_PF_ATTR2.replace(PLMConstants.VT_PF_ATTR, VT_PF_ATTR));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_VT_PF_ATTR2.replace(PLMConstants.VT_PF_ATTR, VT_PF_ATTR));
		
			
			LOG.info("Query for collect Stats3 VT_PF_ATTR : " + PLMOfflineQueries.COLLECT_STATS_VT_PF_ATTR3.replace(PLMConstants.VT_PF_ATTR, VT_PF_ATTR));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_VT_PF_ATTR3.replace(PLMConstants.VT_PF_ATTR, VT_PF_ATTR));
		
			LOG.info("Query for Creating VT_PF_DATA : " + PLMOfflineQueries.CREATE_VT_PF_DATA.replace(PLMConstants.VT_PF_DATA, VT_PF_DATA)
					.replace(PLMConstants.VT_PF_ATTR, VT_PF_ATTR));
				getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VT_PF_DATA.replace(PLMConstants.VT_PF_DATA, VT_PF_DATA)
					.replace(PLMConstants.VT_PF_ATTR, VT_PF_ATTR));

			LOG.info("Query for collect Stats1 VT_PF_DATA : " + PLMOfflineQueries.COLLECT_STATS_VT_PF_DATA1.replace(PLMConstants.VT_PF_DATA, VT_PF_DATA));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_VT_PF_DATA1.replace(PLMConstants.VT_PF_DATA, VT_PF_DATA));
		
			
			LOG.info("Query for collect Stats2 VT_PF_DATA : " + PLMOfflineQueries.COLLECT_STATS_VT_PF_DATA2.replace(PLMConstants.VT_PF_DATA, VT_PF_DATA));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_VT_PF_DATA2.replace(PLMConstants.VT_PF_DATA, VT_PF_DATA));
		
			
			LOG.info("Query for collect Stats3 VT_PF_DATA : " + PLMOfflineQueries.COLLECT_STATS_VT_PF_DATA3.replace(PLMConstants.VT_PF_DATA, VT_PF_DATA));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_VT_PF_DATA3.replace(PLMConstants.VT_PF_DATA, VT_PF_DATA));

			LOG.info("Query for Creating VT_ALT_PART : " + PLMOfflineQueries.CREATE_VT_ALT_PART.replace(PLMConstants.VT_ALT_PART, VT_ALT_PART)
					.replace(PLMConstants.VT_MBOM, VT_MBOM).replace(PLMConstants.VT_ALL_PARTS, VT_ALL_PARTS));
				getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VT_ALT_PART.replace(PLMConstants.VT_ALT_PART, VT_ALT_PART)
					.replace(PLMConstants.VT_MBOM, VT_MBOM).replace(PLMConstants.VT_ALL_PARTS, VT_ALL_PARTS));

			
			LOG.info("Query for Creating VT_PDDR : " + PLMOfflineQueries.INSERT_MBOM_PDDR_DATA.replace(PLMConstants.VT_PDDR, VT_PDDR)
					.replace(PLMConstants.VT_ALL_DOC, VT_MBOM).replace(PLMConstants.VT_PF_DATA, VT_ALL_DOC)
					.replace(PLMConstants.VT_ALT_PART, VT_PF_DATA).replace(PLMConstants.VT_ALT_PART, VT_ALT_PART));
			
			getJdbcTemplate().execute(PLMOfflineQueries.INSERT_MBOM_PDDR_DATA.replace(PLMConstants.VT_PDDR, VT_PDDR)
					.replace(PLMConstants.VT_MBOM, VT_MBOM).replace(PLMConstants.VT_ALL_DOC, VT_ALL_DOC)
					.replace(PLMConstants.VT_PF_DATA, VT_PF_DATA).replace(PLMConstants.VT_ALT_PART, VT_ALT_PART));
			
			
			LOG.info("Final Query for Exectuing : " + PLMOfflineQueries.GET_MBOM_PDDR_DATA.replace(PLMConstants.VT_PDDR, VT_PDDR));
			
			mbomPddrList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_MBOM_PDDR_DATA.replace(PLMConstants.VT_PDDR, VT_PDDR)
					,new MBomPddrMapper());
			
			LOG.info("Result Size : " + mbomPddrList.size());
		  }
			
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getMBOMPddrReport method");
		return mbomPddrList;
	}
	
	/**
	 * Row mapper for getting PddrMapper
	 */
	private static final class PddrMapper implements ParameterizedRowMapper<PLMMBOMPddrData>{	
	public PLMMBOMPddrData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMMBOMPddrData tempData = new PLMMBOMPddrData();
		//tempData.setRelationId(PLMUtils.checkNullVal(rs.getString("RELATION_ID")));
		tempData.setTopLevelParentId(PLMUtils.checkNullVal(rs.getString("TOP_LEVEL_PARENT_ID")));
		tempData.setTopLevelParentName(PLMUtils.checkNullVal(rs.getString("TOP_LEVEL_PARENT_NAME")));
		tempData.setTopLevelParentRev(PLMUtils.checkNullVal(rs.getString("TOP_LEVEL_PART_REVISION")));
		tempData.setParentId(PLMUtils.checkNullVal(rs.getString("PARENT_ID")));
		tempData.setParentName(PLMUtils.checkNullVal(rs.getString("PARENT_NAME")));
		tempData.setParentRev(PLMUtils.checkNullVal(rs.getString("PARENT_REVISION")));
		tempData.setChildId(PLMUtils.checkNullVal(rs.getString("CHILD_ID")));
		tempData.setBomLevel(rs.getInt("LVL"));
		tempData.setFindNumAd(PLMUtils.checkNullVal(rs.getString("FIND_NUM")));
		tempData.setGeBomPrfixAd(PLMUtils.checkNullVal(rs.getString("GE_BOM_PREFIX")));
		tempData.setChildName(PLMUtils.checkNullVal(rs.getString("CHILD_NAME")));
		tempData.setChildRev(PLMUtils.checkNullVal(rs.getString("CHILD_REVISION")));
		tempData.setQtyAdd(PLMUtils.checkNullVal(rs.getString("QUANTITY")));
		tempData.setFuncCodeAd(PLMUtils.checkNullVal(rs.getString("FNCT_CODE")));
		tempData.setDfsOrder(PLMUtils.checkNullVal(rs.getString("DFSORDER")));
		tempData.setPathFlag("");
		return tempData;
		}
	}
	
	/**
	 * This method is used for formTreeStruct
	 * 
	 * @param mbomPddrList,mlno
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMMBOMPddrData> formTreeStruct(List<PLMMBOMPddrData> mbomPddrList,String mlNo) {
		int bomLevel = 1;
		int index;
		int prevIndex = -1;
		String parentPdName = mlNo;
		List<PLMMBOMPddrData> mbomPddrFinalList =  new ArrayList<PLMMBOMPddrData>();
		while(true){
			index = findChildrens(mbomPddrList,parentPdName,prevIndex,bomLevel);
			if(index == -1){			
				if(bomLevel == 1){
					break;			
				}
				mbomPddrList.get(prevIndex).setPathFlag("COMPLETED");
				bomLevel = 1;
				parentPdName = mlNo;
			} else {
				if(!mbomPddrList.get(index).getPathFlag().equals("VISITED")){
					mbomPddrList.get(index).setPathFlag("VISITED");
					mbomPddrFinalList.add(mbomPddrList.get(index));
				}
				prevIndex = index;	
				bomLevel = bomLevel + 1;
				parentPdName = mbomPddrList.get(index).getChildName();
			}
		}
		return mbomPddrFinalList;
	}
	
	/**
	 * This method is used for findChildrens
	 * 
	 * @param lttrTdResultList,parentPdName,prevIndex,bomLevel
	 * @return int
	 */
	public int findChildrens(List<PLMMBOMPddrData> mbomPddrList,String parentPdName,int prevIndex, int bomLevel) {
		int retIndex = -1;
		for(int i = 0 ; i < mbomPddrList.size();i++) {
			if(mbomPddrList.get(i).getParentName().equals(parentPdName) && mbomPddrList.get(i).getBomLevel() == bomLevel){
				if(bomLevel == 1) {
					if(!mbomPddrList.get(i).getPathFlag().equals("COMPLETED")){
						retIndex = i;
						break;
					}
				} else {
					if(mbomPddrList.get(i).getParentName().equals(mbomPddrList.get(prevIndex).getChildName())){
						if(!mbomPddrList.get(i).getPathFlag().equals("COMPLETED")){
							retIndex = i;
							break;
						} 
					}
				}
			}
		}
		return retIndex;
	}
	
	/**
	 * Row mapper for getting MBomPddrMapper
	 */
	private static final class MBomPddrMapper implements ParameterizedRowMapper<PLMMBOMPddrData>{	
	public PLMMBOMPddrData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMMBOMPddrData tempData = new PLMMBOMPddrData();
		tempData.setLevel(PLMUtils.checkNullVal(rs.getString("LVL")));
		tempData.setFn(PLMUtils.checkNullVal(rs.getString("FIND_NUM")));
		tempData.setBomPrefix(PLMUtils.checkNullVal(rs.getString("GE_BOM_PREFIX")));
		tempData.setPartNumber(PLMUtils.checkNullVal(rs.getString("CHILD_NAME")));
		tempData.setPartRev(PLMUtils.checkNullVal(rs.getString("CHILD_REVISION")));
		tempData.setQty(PLMUtils.checkNullVal(rs.getString("QUANTITY")).trim());
		tempData.setUom(PLMUtils.checkNullVal(rs.getString("UOM")));
		tempData.setFunctionCode(PLMUtils.checkNullVal(rs.getString("FNCT_CODE")));
		tempData.setEid(PLMUtils.checkNullVal(rs.getString("EID")));
		tempData.setDocName(PLMUtils.checkNullVal(rs.getString("DOC_NAME")));
		tempData.setDocRev(PLMUtils.checkNullVal(rs.getString("DOC_REV")));
		tempData.setDescription(PLMUtils.checkNullVal(rs.getString("DESCRIPTION")));
		tempData.setType(PLMUtils.checkNullVal(rs.getString("_TYPE")));
		tempData.setState(PLMUtils.checkNullVal(rs.getString("STATE")));
		tempData.setOrgReplcPart(PLMUtils.checkNullVal(rs.getString("ALT_PART_NEW")));
		tempData.setPartAttribute(PLMUtils.checkNullVal(rs.getString("PF_ATTRIBUTE_VAL_NEW")));
		return tempData;
		}
	}

	

}
