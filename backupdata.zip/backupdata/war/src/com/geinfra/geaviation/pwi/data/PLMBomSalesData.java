/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBomSalesData.java
 * @Creation date: 10-Sep-2013
 * @version 2.2
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;

public class PLMBomSalesData {
	/**
	  * Holds the bomLevel
	  */
	private String bomLevel;
	/**
	  * Holds the bomRevision
	  */
	private String bomRevision;
	/**
	  * Holds the salesID
	  */
	private String salesID;
	/**
	  * Holds the unitSerialNumber
	  */
	private String unitSerialNumber;
	/**
	  * Holds the erpLineNumber
	  */
	private String erpLineNumber;
	/**
	  * Holds the requestedShipDate
	  */
	private String requestedShipDate;
	/**
	  * Holds the lineStatus
	  */
	private String lineStatus;
	/**
	  * Holds the internalComments
	  */
	private String internalComments;
	/**
	  * Holds the externalComments
	  */
	private String externalComments;
	/**
	  * Holds the mlno
	  */
	private String mlNum;
	/**
	  * Holds the partName
	  */
	private String partName;
	/**
	 * Holds the partRev
	 */
	private String partRev;
	/**
	 * Holds the partRev
	 */
	private String partVal;
	/**
	  * Holds the unitOfMeasure
	  */
	private String unitOfMeasure;
	/**
	  * Holds the description
	  */
	private String description;
	/**
	  * Holds the state
	  */
	private String state;
	/**
	  * Holds the quantity
	  */
	private String quantity;
	/**
	  * Holds the isCompared
	  */
	private boolean isCompared;
	/**
	  * Holds the contractNo
	  */
	private String contractNo;
	/**
	  * Holds the parentName
	  */
	private String parentName;
	
	//private String lmDate;
	/**
	  * Holds the lmDate
	  */
	private Date lmDate;
	/**
	  * Holds the partModDate
	  */
	private Date partModDate;
	/**
	  * Holds the salesData
	  */
	private PLMBomSalesData salesData;
	/**
	  * Holds the promisedDate
	  */
	private String promisedDate;
	/**
	  * Holds the shipDate
	  */
	private String shipDate;
	/**
	  * Holds the delivery
	  */
	private String delivery;
	/**
	  * Holds the requestedShipDate
	  */
	private String trackingLpn;
	/**
	  * Holds the contractName
	  */
	private String contractName;
	/**
	  * Holds the contractDesc
	  */
	private String contractDesc;
	/**
	  * Holds the partId
	  */
	private String partId;

	/**
	 * @param lmDate The lmDate to set.
	 */
	public void setLmDate(Date lmDate) {
		Date lmDt= lmDate;
		this.lmDate = lmDt;
	}
	/**
	 * @return Returns the lmDate
	 */
	public Date getLmDate() {
		Date lmDt= lmDate;
		return lmDt;
	}
	
	
	
	
	/**
	 * @return Returns the partModDate
	 */
	public Date getPartModDate() {
		Date partModDt=partModDate;
		return partModDt;
	}
	/**
	 * @param partModDate The partModDate to set.
	 */
	public void setPartModDate(Date partModDate) {
		Date partModDt=partModDate;
		this.partModDate = partModDt;
	}
	
	
	
	/**
	 * @return Returns the bomLevel.
	 */
	public String getBomLevel() {
		return bomLevel;
	}
	/**
	 * @param bomLevel The bomLevel to set.
	 */
	public void setBomLevel(String bomLevel) {
		this.bomLevel = bomLevel;
	}
	/**
	 * @return Returns the bomRevision.
	 */
	public String getBomRevision() {
		return bomRevision;
	}
	/**
	 * @param bomRevision The bomRevision to set.
	 */
	public void setBomRevision(String bomRevision) {
		this.bomRevision = bomRevision;
	}
	/**
	 * @return Returns the description.
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description The description to set.
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return Returns the erpLineNumber.
	 */
	public String getErpLineNumber() {
		return erpLineNumber;
	}
	/**
	 * @param erpLineNumber The erpLineNumber to set.
	 */
	public void setErpLineNumber(String erpLineNumber) {
		this.erpLineNumber = erpLineNumber;
	}
	/**
	 * @return Returns the externalComments.
	 */
	public String getExternalComments() {
		return externalComments;
	}
	/**
	 * @param externalComments The externalComments to set.
	 */
	public void setExternalComments(String externalComments) {
		this.externalComments = externalComments;
	}
	/**
	 * @return Returns the internalComments.
	 */
	public String getInternalComments() {
		return internalComments;
	}
	/**
	 * @param internalComments The internalComments to set.
	 */
	public void setInternalComments(String internalComments) {
		this.internalComments = internalComments;
	}
	/**
	 * @return Returns the lineStatus.
	 */
	public String getLineStatus() {
		return lineStatus;
	}
	/**
	 * @param lineStatus The lineStatus to set.
	 */
	public void setLineStatus(String lineStatus) {
		this.lineStatus = lineStatus;
	}
	
	/**
	 * @return the mlNum
	 */
	public String getMlNum() {
		return mlNum;
	}
	/**
	 * @param mlNum the mlNum to set
	 */
	public void setMlNum(String mlNum) {
		this.mlNum = mlNum;
	}
	/**
	 * @return Returns the mlno.
	 */
	/*public String getMlno() {
		return mlno;
	}*/
	/**
	 * @param mlno The mlno to set.
	 */
	/*public void setMlno(String mlno) {
		this.mlno = mlno;
	}*/
	/**
	 * @return Returns the partName.
	 */
	public String getPartName() {
		return partName;
	}
	/**
	 * @param partName The partName to set.
	 */
	public void setPartName(String partName) {
		this.partName = partName;
	}
	/**
	 * @return the partRev
	 */
	public String getPartRev() {
		return partRev;
	}
	/**
	 * @param partRev the partRev to set
	 */
	public void setPartRev(String partRev) {
		this.partRev = partRev;
	}
	/**
	 * @return the partVal
	 */
	public String getPartVal() {
		return partVal;
	}
	/**
	 * @param partVal the partVal to set
	 */
	public void setPartVal(String partVal) {
		this.partVal = partVal;
	}
	/**
	 * @return Returns the quantity.
	 */
	public String getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity The quantity to set.
	 */
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return Returns the requestedShipDate.
	 */
	public String getRequestedShipDate() {
		return requestedShipDate;
	}
	/**
	 * @param requestedShipDate The requestedShipDate to set.
	 */
	public void setRequestedShipDate(String requestedShipDate) {
		this.requestedShipDate = requestedShipDate;
	}
	/**
	 * @return Returns the salesID.
	 */
	public String getSalesID() {
		return salesID;
	}
	/**
	 * @param salesID The salesID to set.
	 */
	public void setSalesID(String salesID) {
		this.salesID = salesID;
	}
	/**
	 * @return Returns the state.
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state The state to set.
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return Returns the unitOfMeasure.
	 */
	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}
	/**
	 * @param unitOfMeasure The unitOfMeasure to set.
	 */
	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}
	/**
	 * @return Returns the unitSerialNumber.
	 */
	public String getUnitSerialNumber() {
		return unitSerialNumber;
	}
	/**
	 * @param unitSerialNumber The unitSerialNumber to set.
	 */
	public void setUnitSerialNumber(String unitSerialNumber) {
		this.unitSerialNumber = unitSerialNumber;
	}
	/**
	 * @return Returns the isCompared.
	 */
	public boolean isCompared() {
		return isCompared;
	}
	/**
	 * @param isCompared The isCompared to set.
	 */
	public void setCompared(boolean isComparedd) {
		this.isCompared = isComparedd;
	}
	/**
	 * @return Returns the salesData.
	 */
	public PLMBomSalesData getSalesData() {
		return salesData;
	}
	/**
	 * @param salesData The salesData to set.
	 */
	public void setSalesData(PLMBomSalesData salesData) {
		this.salesData = salesData;
	}
	
   /**
	 * @return the promisedDate
	 */
	public String getPromisedDate() {
		return promisedDate;
	}
	/**
	 * @param promisedDate the promisedDate to set
	 */
	public void setPromisedDate(String promisedDate) {
		this.promisedDate = promisedDate;
	}
	/**
	 * @return the shipDate
	 */
	public String getShipDate() {
		return shipDate;
	}
	/**
	 * @param shipDate the shipDate to set
	 */
	public void setShipDate(String shipDate) {
		this.shipDate = shipDate;
	}
	/**
	 * @return the delivery
	 */
	public String getDelivery() {
		return delivery;
	}
	/**
	 * @param delivery the delivery to set
	 */
	public void setDelivery(String delivery) {
		this.delivery = delivery;
	}
	/**
	 * @return the trackingLpn
	 */
	public String getTrackingLpn() {
		return trackingLpn;
	}
	/**
	 * @param trackingLpn the trackingLpn to set
	 */
	public void setTrackingLpn(String trackingLpn) {
		this.trackingLpn = trackingLpn;
	}
	//Added for MBOM Vs SO Report	
	/**
	 * @return Returns the contractNo.
	 */
	public String getContractNo() {
		return contractNo;
	}
	/**
	 * @param partName The partName to set.
	 */
	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}
	
	/**
	 * @return Returns the parentName.
	 */
	public String getParentName() {
		return parentName;
	}
	/**
	 * @param parentName The parentName to set.
	 */
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	/**
	 * @return the contractName
	 */
	public String getContractName() {
		return contractName;
	}
	/**
	 * @param contractName the contractName to set
	 */
	public void setContractName(String contractName) {
		this.contractName = contractName;
	}
	/**
	 * @return the contractDesc
	 */
	public String getContractDesc() {
		return contractDesc;
	}
	/**
	 * @param contractDesc the contractDesc to set
	 */
	public void setContractDesc(String contractDesc) {
		this.contractDesc = contractDesc;
	}
	/**
	 * @return the partId
	 */
	public String getPartId() {
		return partId;
	}
	/**
	 * @param partId the partId to set
	 */
	public void setPartId(String partId) {
		this.partId = partId;
	}

//Added for MBOM Vs SO Report
	
}
