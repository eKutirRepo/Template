/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCopicsSearchDaoImpl.java
 * @Creation date: 03-Nov-2011
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMABITData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMCopicsSearchDaoImpl extends SimpleJdbcDaoSupport implements
		PLMCopicsSearchDaoIfc {
	
	/**
	 * Holds the Logger.
	 */
	private static final Logger LOG = Logger
			.getLogger(PLMCopicsSearchDaoImpl.class);

	/**
	 * This method is used to getSearchDetails
	 * @param paramString1, paramString2, paramString3
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMABITData> getSearchDetails(String itemId, String itemCmnt,
			String itemSrc) throws PLMCommonException {
		LOG.info("In getSearchDetails() method.");
		List<PLMABITData> searchResultList = null;
		try{
		StringBuffer searchResultsQry = new StringBuffer();
		searchResultsQry.append(PLMSearchQueries.GET_ABIT_RESULTS_DETAILS);
		if (itemId != null) {
			String itemIdValue = itemId.replace("*", "%");
			if (itemIdValue.indexOf('%') == -1) {
				itemIdValue = itemIdValue.toUpperCase(Locale.getDefault());
				searchResultsQry.append(" AND UPPER(C.ITM_ID_NUM) LIKE '"
						+ itemIdValue + "%'");
			} else {
				itemIdValue = itemIdValue.toUpperCase(Locale.getDefault());
				searchResultsQry.append(" AND UPPER(C.ITM_ID_NUM) LIKE '"
						+ itemIdValue + "'");
			}
		}

		if (itemCmnt != null) {
			String itemCmntValue = itemCmnt.replace("*", "%");
			if (itemCmntValue.indexOf('%') == -1) {
				itemCmntValue = itemCmntValue.toUpperCase(Locale.getDefault());
				searchResultsQry.append(" AND UPPER(B.CMNT_TXT) LIKE '"
						+ itemCmntValue + "%'");
			} else {
				itemCmntValue = itemCmntValue.toUpperCase(Locale.getDefault());
				searchResultsQry.append(" AND UPPER(B.CMNT_TXT) LIKE '"
						+ itemCmntValue + "'");
			}
		}

		if (itemSrc != null) {
			String itemSrcValue = itemSrc.replace("*", "%");
			if (itemSrcValue.indexOf('%') == -1) {
				itemSrcValue = itemSrcValue.toUpperCase(Locale.getDefault());
				searchResultsQry
						.append(" AND UPPER(C.ITM_SRCE_TYPE_CD) LIKE '"
								+ itemSrcValue + "%'");
			} else {
				itemSrcValue = itemSrcValue.toUpperCase(Locale.getDefault());
				searchResultsQry
						.append(" AND UPPER(C.ITM_SRCE_TYPE_CD) LIKE '"
								+ itemSrcValue + "'");
			}
		}
		LOG.info("searchResultsQry finally is ::" + searchResultsQry);
		searchResultList = getSimpleJdbcTemplate()
				.query(searchResultsQry.toString(), new SearchResultsMapper(),
						new Object[0]);
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return searchResultList;
	}
	
	/**
	 * @return PLMABITData objects.
	 */
	private static final class SearchResultsMapper implements ParameterizedRowMapper<PLMABITData> {
//	private static ParameterizedRowMapper<PLMABITData> searchResultsMapper = new ParameterizedRowMapper<PLMABITData>() {
		public PLMABITData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMABITData abitData = new PLMABITData();
			abitData.setItemSource(PLMUtils.checkNullVal(rs
					.getString("ITM_SRCE_TYPE_CD")));
			abitData.setItemID(PLMUtils
					.checkNullVal(rs.getString("ITM_ID_NUM")));
			abitData.setItemComments(PLMUtils.checkNullVal(rs
					.getString("CMNT_TXT")));
			return abitData;
		}
	}
}