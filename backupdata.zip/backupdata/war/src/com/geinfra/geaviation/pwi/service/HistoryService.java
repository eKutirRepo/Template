package com.geinfra.geaviation.pwi.service;

import java.util.Date;
import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.context.PWiContext;
import com.geinfra.geaviation.pwi.dao.EventDAO;
import com.geinfra.geaviation.pwi.model.MinimalQueryExctnEventVO;
import com.geinfra.geaviation.pwi.model.PWiQueryExctnEventVO;

/**
 * Project : Product Lifecycle Management Date Written : Apr 20, 2011 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : HistoryService
 * 
 * Revision Log Apr 20, 2011 | v1.0.
 * --------------------------------------------------------------
 */
public class HistoryService {
	// Injected
	private EventDAO eventDAO;

	public void setEventDAO(EventDAO eventDAO) {
		this.eventDAO = eventDAO;
	}

	public PWiQueryExctnEventVO getExecutionEventById(Integer eventId) {
		return eventDAO.getExecutionEventById(eventId);
	}

	/**
	 * Finds the most recent execution events run by the specified SSO ordered
	 * with the most recent first.
	 * 
	 * @param ssoId
	 * @param limit
	 *            max number of events to return
	 * @return the execution events
	 */
	public List<MinimalQueryExctnEventVO> getExecutionEvents(String ssoId,
			int limit) {
		return eventDAO.getExecutionEvents(ssoId, limit);
	}

	/**
	 * Retrieves all queries run by the user since the specified date order with
	 * the most recent first.
	 * 
	 * @param dateRunSince
	 * @return queries run by user
	 */
	public List<MinimalQueryExctnEventVO> getExecutionEventsSince(
			Date dateRunSince) throws PWiException {
		String userSso = PWiContext.getCurrentInstance().getUserSso();
		return eventDAO.getExecutionEventsRunSince(userSso, dateRunSince);
	}

}
