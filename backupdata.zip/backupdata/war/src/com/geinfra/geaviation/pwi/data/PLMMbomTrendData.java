/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMMbomTrendData.java
 * @Creation date: 20-July-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.data;

public class PLMMbomTrendData {
	/**
	  * Holds the mlno
	  */
	private String mlNumTrnd;
	/**
	  * Holds the mfgrespcode
	  */
	private String mfgrespcode;
	/**
	  * Holds the totalnoparts
	  */
	private int totalnoparts;
	/**
	  * Holds the noofchangerevision
	  */
	private int noofchangerevision;
		
	
	/**
	 * @return the mlno
	 */
	/*public String getMlno() {
		return mlno;
	}*/

	/**
	 * @param mlno the mlno to set
	 */
	/*public void setMlno(String mlno) {
		this.mlno = mlno;
	}*/

	/**
	 * @return the mlNumTrnd
	 */
	public String getMlNumTrnd() {
		return mlNumTrnd;
	}

	/**
	 * @param mlNumTrnd the mlNumTrnd to set
	 */
	public void setMlNumTrnd(String mlNumTrnd) {
		this.mlNumTrnd = mlNumTrnd;
	}

	/**
	 * @return the mfgrespcode
	 */
	public String getMfgrespcode() {
		return mfgrespcode;
	}

	/**
	 * @param mfgrespcode the mfgrespcode to set
	 */
	public void setMfgrespcode(String mfgrespcode) {
		this.mfgrespcode = mfgrespcode;
	}

	/**
	 * @return the totalnoparts
	 */
	public int getTotalnoparts() {
		return totalnoparts;
	}

	/**
	 * @param totalnoparts the totalnoparts to set
	 */
	public void setTotalnoparts(int totalnoparts) {
		this.totalnoparts = totalnoparts;
	}

	/**
	 * @return the noofchangerevision
	 */
	public int getNoofchangerevision() {
		return noofchangerevision;
	}

	/**
	 * @param noofchangerevision the noofchangerevision to set
	 */
	public void setNoofchangerevision(int noofchangerevision) {
		this.noofchangerevision = noofchangerevision;
	}
	
}