 /**
 * Copyright (C) 2015 GE Infra. 
 * All rights reserved 
 * @FileNamePLMABITSearchMB.java
 * @Creation date: 18-Aug-2015
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMConfigFeatOptRptData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMConfigFeatOptRptDaoImpl extends SimpleJdbcDaoSupport implements PLMConfigFeatOptRptDaoIfc{
	private static final Logger LOG = Logger.getLogger(PLMConfigFeatOptRptDaoImpl.class);
	private static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
	/*private JdbcTemplate jdbcTemplate;
	private JdbcTemplate jdbcTemplateTr;*/
	
	
	public List<SelectItem> getStateDDList() throws PLMCommonException{
		List<SelectItem> stateList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_STATE_LIST, new StateListMapper());
		return stateList;
	}
	
	public List<PLMConfigFeatOptRptData> getSearchResult(PLMConfigFeatOptRptData plmConfigFeatOptRptData, String searchResultsCreateQry) throws PLMCommonException{
		LOG.info("Entering getSearchResult of DAOImpl");
		List<PLMConfigFeatOptRptData> searchResultList = null;

		String timeStamp = PLMUtils.volTableFormatDate();
		String VT_CFO = "VT_CFO".concat(timeStamp);
		try{
			LOG.info("Fetching Results for Config Feature Option Report.....");
			LOG.info("Query for Creating VT_CFO==="+searchResultsCreateQry.replace("VT_CFO", VT_CFO));
			getJdbcTemplate().execute(searchResultsCreateQry.replace("VT_CFO", VT_CFO));
			LOG.info("Query for Getting Result Data==="+PLMSearchQueries.GET_CFO_RESULT_DATA.replace("VT_CFO", VT_CFO));
			searchResultList=getSimpleJdbcTemplate().query(PLMSearchQueries.GET_CFO_RESULT_DATA.replace("VT_CFO", VT_CFO), new CFODataMapper());
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Existing getSearchResult of DAOImpl");
		return searchResultList;
	}
	
	private static final class StateListMapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs.getString("STATE"));
			return selectItem;
		}
	}
	
	private static final class CFODataMapper implements ParameterizedRowMapper<PLMConfigFeatOptRptData> {
		public PLMConfigFeatOptRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMConfigFeatOptRptData data = new PLMConfigFeatOptRptData();
			data.setCoId(PLMUtils.checkNullVal(rs.getString("CO_ID")));
			data.setCoName(PLMUtils.checkNullVal(rs.getString("CO_NAME")));
			data.setGeIndr(PLMUtils.checkNullVal(rs.getString("GE_INDR")));
			/*data.setFrsId(PLMUtils.checkNullVal(rs.getString("FRS_ID")));
			data.setFrsName(PLMUtils.checkNullVal(rs.getString("FRS_NAME")));*/
			data.setDisplayText(PLMUtils.checkNullVal(rs.getString("DISPLAY_TEXT")));
			data.setDisplayName(PLMUtils.checkNullVal(rs.getString("DISPLAY_NAME")));
			data.setCoRevision(PLMUtils.checkNullVal(rs.getString("CO_REVISION")));
			data.setCoState(PLMUtils.checkNullVal(rs.getString("CO_STATE")));
			data.setParentCf(PLMUtils.checkNullVal(rs.getString("PARENT_CF")));
			data.setrNum(PLMUtils.checkNullVal(rs.getString("R_NUM")));
			data.setOwnerSso(PLMUtils.checkNullVal(rs.getString("OWNR_SSO")));
			data.setOwnerName(PLMUtils.checkNullVal(rs.getString("OWNR_NAME")));
			//data.setOrigDate(PLMUtils.checkNullVal(rs.getString("ORIGINATED_DATE")));
			Date origDt = rs.getTimestamp("ORIGINATED_DATE");
			if(origDt != null){
				String origDate = SIMPLE_DATE_FORMAT.format(origDt);
				data.setOrigDate(origDate);
			} else {
				data.setOrigDate("");
			}
			data.setCfgnSelType(PLMUtils.checkNullVal(rs.getString("CFGN_SELECTION_TYPE")));
			
			
			return data;
		}
	}
	
	
	
	
	
	
	

}
