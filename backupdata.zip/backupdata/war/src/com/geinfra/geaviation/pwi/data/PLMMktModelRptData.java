/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMMktModelRptData.java
 * @Creation date: 12-June-2017
 * @version 1.0
 * @author : Tech Mahindra (PWi Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMMktModelRptData {
	
	private String model;
	private String coName;
	private String coRev;
	private String coDesc;
	private String coState;
	private String coDisplayName;
	private String coDisplayText;
	private String reqType;
	private String reqName;
	private String reqDesc;
	private String reqRev;
	private String reqGeIndr;
	private int reqEstimatedCost;
	
	private String productLineName;
	private String modelName;
	private String hardwareProductId;
	private String hardwareProductName;
	private String hardwareProductRev;
	private String hardwareProductNmRev;
	
	
	/**
	 * @return
	 */
	public String getModel() {
		return model;
	}
	/**
	 * @param model
	 */
	public void setModel(String model) {
		this.model = model;
	}
	/**
	 * @return
	 */
	public String getCoName() {
		return coName;
	}
	/**
	 * @param coName
	 */
	public void setCoName(String coName) {
		this.coName = coName;
	}
	/**
	 * @return
	 */
	public String getCoRev() {
		return coRev;
	}
	/**
	 * @param coRev
	 */
	public void setCoRev(String coRev) {
		this.coRev = coRev;
	}
	/**
	 * @return
	 */
	public String getCoDesc() {
		return coDesc;
	}
	/**
	 * @param coDesc
	 */
	public void setCoDesc(String coDesc) {
		this.coDesc = coDesc;
	}
	/**
	 * @return
	 */
	public String getCoState() {
		return coState;
	}
	/**
	 * @param coState
	 */
	public void setCoState(String coState) {
		this.coState = coState;
	}
	/**
	 * @return
	 */
	public String getCoDisplayName() {
		return coDisplayName;
	}
	/**
	 * @param coDisplayName
	 */
	public void setCoDisplayName(String coDisplayName) {
		this.coDisplayName = coDisplayName;
	}
	/**
	 * @return
	 */
	public String getCoDisplayText() {
		return coDisplayText;
	}
	/**
	 * @param coDisplayText
	 */
	public void setCoDisplayText(String coDisplayText) {
		this.coDisplayText = coDisplayText;
	}
	/**
	 * @return
	 */
	public String getReqType() {
		return reqType;
	}
	/**
	 * @param reqType
	 */
	public void setReqType(String reqType) {
		this.reqType = reqType;
	}
	/**
	 * @return
	 */
	public String getReqName() {
		return reqName;
	}
	/**
	 * @param reqName
	 */
	public void setReqName(String reqName) {
		this.reqName = reqName;
	}
	/**
	 * @return
	 */
	public String getReqDesc() {
		return reqDesc;
	}
	/**
	 * @param reqDesc
	 */
	public void setReqDesc(String reqDesc) {
		this.reqDesc = reqDesc;
	}
	/**
	 * @return
	 */
	public String getReqRev() {
		return reqRev;
	}
	/**
	 * @param reqRev
	 */
	public void setReqRev(String reqRev) {
		this.reqRev = reqRev;
	}
	/**
	 * @return
	 */
	public String getReqGeIndr() {
		return reqGeIndr;
	}
	/**
	 * @param reqGeIndr
	 */
	public void setReqGeIndr(String reqGeIndr) {
		this.reqGeIndr = reqGeIndr;
	}
	/**
	 * @return
	 */
	public int getReqEstimatedCost() {
		return reqEstimatedCost;
	}
	/**
	 * @param reqEstimatedCost
	 */
	public void setReqEstimatedCost(int reqEstimatedCost) {
		this.reqEstimatedCost = reqEstimatedCost;
	}
	/**
	 * @return
	 */
	public String getProductLineName() {
		return productLineName;
	}
	/**
	 * @param productLineName
	 */
	public void setProductLineName(String productLineName) {
		this.productLineName = productLineName;
	}
	/**
	 * @return
	 */
	/**
	 * @return
	 */
	public String getModelName() {
		return modelName;
	}
	/**
	 * @param modelName
	 */
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	/**
	 * @return
	 */
	public String getHardwareProductId() {
		return hardwareProductId;
	}
	/**
	 * @param hardwareProductId
	 */
	public void setHardwareProductId(String hardwareProductId) {
		this.hardwareProductId = hardwareProductId;
	}
	/**
	 * @return
	 */
	public String getHardwareProductName() {
		return hardwareProductName;
	}
	/**
	 * @param hardwareProductName
	 */
	public void setHardwareProductName(String hardwareProductName) {
		this.hardwareProductName = hardwareProductName;
	}
	/**
	 * @return
	 */
	public String getHardwareProductRev() {
		return hardwareProductRev;
	}
	/**
	 * @param hardwareProductRev
	 */
	public void setHardwareProductRev(String hardwareProductRev) {
		this.hardwareProductRev = hardwareProductRev;
	}
	/**
	 * @return
	 */
	public String getHardwareProductNmRev() {
		return hardwareProductNmRev;
	}
	/**
	 * @param hardwareProductNmRev
	 */
	public void setHardwareProductNmRev(String hardwareProductNmRev) {
		this.hardwareProductNmRev = hardwareProductNmRev;
	}
	
}