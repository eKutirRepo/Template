 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBomCopicsMB.java
 * @Creation date: 26-Dec-2011
 * @version 2.0.1
 * @author : Tech Mahindra (PLMR Team) 
 */

package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.data.PLMBomCopicsData;
import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.service.PLMMetricsServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;

/**
 * PLMBomCopicsMB is the managed bean class .
 */

public class PLMBomCopicsMB {
	/**
	 * Holds the LOG
	 */
	private static Logger LOG = Logger.getLogger(PLMBomCopicsMB.class);
	/**
	 * Holds the bomCopicsData
	 */
	private PLMBomCopicsData bomCopicsData = null;
	/**
	 * Holds the PLMMetricsServiceIfc
	 */
	private PLMMetricsServiceIfc plmMetricsService  = null;
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds the resourceBundle
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the plmInputList
	 */
	private List <String> plmInputList;
	/**
	 * Holds the copicsInputList
	 */
	private List <String> copicsInputList;
	/**
	 * Holds the plmCopicsInputList
	 */
	private List <String> plmCopicsInputList = new ArrayList<String>();
	/**
	 * Holds the plmCopicsOptionList
	 */
	private List <String> plmCopicsOptionList;
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor=null;
	/**
	 * Holds the itemNoOne
	 */
	private String itemNoOne;
	/**
	 * Holds the itemNoOptionOne
	 */
	private String itemNoOptionOne = "";
	/**
	 * Holds the itemNoTwo
	 */
	private String itemNoTwo;
	/**
	 * Holds the itemNoOptionTwo
	 */
	private String itemNoOptionTwo= "";
	/**
	 * Holds the itemNoThree
	 */
	private String itemNoThree;
	/**
	 * Holds the itemNoOptionThree
	 */
	private String itemNoOptionThree= "";
	/**
	 * Holds the itemNoFour
	 */
	private String itemNoFour;
	/**
	 * Holds the itemNoOptionFour
	 */
	private String itemNoOptionFour= "";
	/**
	 * Holds the itemNoFive
	 */
	private String itemNoFive;
	/**
	 * Holds the itemNoOptionFive
	 */
	private String itemNoOptionFive= "";
	/**
	 * Holds the itemNoSix
	 */
	private String itemNoSix;
	/**
	 * Holds the itemNoOptionSix
	 */
	private String itemNoOptionSix= "";
	

	private PLMLoginData userDataObj = (PLMLoginData) PLMUtils
	.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA);
	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendReportThroughMail();
		}
	}
	
	/**
	 * This method is used for Loading Bom Copics Page
	 * 
	 * @return String
	 */
	public String loadBomCopicsPage() {
		LOG.info("Entering loadBomCopicsPage Method ");
		try {	
			bomCopicsData = new PLMBomCopicsData();
			resetData();
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@loadBomCopicsPage:", exception);
		}
		LOG.info("Exiting loadBomCopicsPage Method ");
		return "bomCopicsValidation";
	}

	/**
	 * This method is used for Comparing PLM & Copics
	 * 
	 * @return String
	 */
	public String getBomCopicsComparisonReport() {
		String fwdflag = "bomCopicsValidation";
		String alertMsg = validateBomCopicsInput();
		if (PLMUtils.isEmpty(alertMsg)) {
			alertMessage = alertMessage + PLMConstants.BOMCOPICS_MAIL_ALERT_MSG;
			taskExecutor.execute(new MailThread());
		}
		return fwdflag;
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * 
	 */
	public void sendReportThroughMail() {
		plmCopicsInputList =  new ArrayList <String>();
		plmCopicsOptionList =  new ArrayList <String>();
		plmCopicsInputList.add(itemNoOne);
		plmCopicsInputList.add(itemNoTwo);
		plmCopicsInputList.add(itemNoThree);
		plmCopicsInputList.add(itemNoFour);
		plmCopicsInputList.add(itemNoFive);
		plmCopicsInputList.add(itemNoSix);
		plmCopicsOptionList.add(itemNoOptionOne);
		plmCopicsOptionList.add(itemNoOptionTwo);
		plmCopicsOptionList.add(itemNoOptionThree);
		plmCopicsOptionList.add(itemNoOptionFour);
		plmCopicsOptionList.add(itemNoOptionFive);
		plmCopicsOptionList.add(itemNoOptionSix);
		String successMsg = "";
		String from = PLMConstants.WHERE_USED_MAIL_FROM;

		String to = userDataObj.getUserEmail();
		String toAddressee = userDataObj.getGivenName_LD().replace(",", "");
		String subject = PLMConstants.BOMCOPICS_MAIL_SUBJECT;		
		toAddressee = "Dear " + toAddressee + ", \n\n";
		try {
			List<PLMBomCopicsData> bomCopicsResultList = plmMetricsService.getBomCopicsComparisonReport(copicsInputList,plmInputList);
			StringBuffer searchCriteriaMsg = saveWhereUsedXLSFile(plmCopicsInputList,plmCopicsOptionList,bomCopicsResultList);
			String message = toAddressee + PLMConstants.BOMCOPICS_MAIL_CONTENT + searchCriteriaMsg.toString() + PLMConstants.WHERE_USED_EBOM_MAIL_SIGNATURE;
			String filePathXLS = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("BOMCOPICS_REPORT_NAME") + ".xls";
			LOG.info(searchCriteriaMsg.toString());
			PLMUtils.sendMailWithAttachment(from, to, subject, message, filePathXLS);
		} catch (IOException exception) {
			LOG.log(Level.ERROR, "Exception@sendReportThroughMail: ", exception);
			successMsg = "Error";
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendReportThroughMail: ", exception);
			successMsg = "Error";
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} 
		if(PLMUtils.isEmpty(successMsg)){
			LOG.info("Mail sent successfully.");
		}
	}
	
	/**
	 * This method is used for Bordering Cell in XLS
	 * 
	 * @return HSSFCellStyle
	 */
	
	private HSSFCellStyle setBorderStyle(HSSFCellStyle style) {
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		return style;
	}
	
	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return StringBuffer
	 */
	
	public StringBuffer saveWhereUsedXLSFile(List<String> plmCopicsInputParamList,List<String> plmCopicsOptionParamList,List<PLMBomCopicsData> bomCopicsResultList) throws IOException {
		String filePath = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("BOMCOPICS_REPORT_NAME") + ".xls";
		//String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		StringBuffer searchCriteriaMsg = new StringBuffer();
		searchCriteriaMsg.append(PLMConstants.BOMCOPICS_MAIL_SEARCH_CRITERIA);
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePath);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist = fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePath);
				HSSFWorkbook workbook = new HSSFWorkbook();
				HSSFSheet sheet =  workbook.createSheet("PLM-BOM Copics Validation Report");
				HSSFCellStyle headerStyle = workbook.createCellStyle();
				headerStyle = setBorderStyle(headerStyle);
				headerStyle.setFillForegroundColor(HSSFColor.YELLOW.index);
				headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				
				HSSFFont font = workbook.createFont(); 
				font.setFontName("GE Inspira");
				font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headerStyle.setFont(font);
				
				HSSFCellStyle cellBoldStyle = workbook.createCellStyle();
				cellBoldStyle = setBorderStyle(cellBoldStyle);
				cellBoldStyle.setFont(font);
				
				HSSFFont nonBoldFont = workbook.createFont();
				nonBoldFont.setFontName("GE Inspira");
				HSSFCellStyle contentStyle = workbook.createCellStyle();				
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(nonBoldFont);
										
				HSSFFont noRecordFont = workbook.createFont(); 
				noRecordFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				noRecordFont.setColor(HSSFColor.RED.index);
				noRecordFont.setFontName("GE Inspira");
				
				HSSFCellStyle noRecordCellStyle = workbook.createCellStyle();
				noRecordCellStyle = setBorderStyle(noRecordCellStyle);
				noRecordCellStyle.setFont(noRecordFont);
				
				int rowcount = -1;
				
				searchCriteriaMsg.append("Item / Drawing / Part Number : ");
				if(!PLMUtils.isEmpty(plmCopicsInputParamList.get(0))) {
					searchCriteriaMsg.append(plmCopicsInputParamList.get(0));
					searchCriteriaMsg.append("(");
					searchCriteriaMsg.append(plmCopicsOptionParamList.get(0));
					searchCriteriaMsg.append(")");
				}
				searchCriteriaMsg.append("\n");
				searchCriteriaMsg.append("Item / Drawing / Part Number : ");
				if(!PLMUtils.isEmpty(plmCopicsInputParamList.get(1))) {
					searchCriteriaMsg.append(plmCopicsInputParamList.get(1));
					searchCriteriaMsg.append("(");
					searchCriteriaMsg.append(plmCopicsOptionParamList.get(1));
					searchCriteriaMsg.append(")");
				}
				searchCriteriaMsg.append("\n");
				searchCriteriaMsg.append("Item / Drawing / Part Number : ");
				if(!PLMUtils.isEmpty(plmCopicsInputParamList.get(2))) {
					searchCriteriaMsg.append(plmCopicsInputParamList.get(2));
					searchCriteriaMsg.append("(");
					searchCriteriaMsg.append(plmCopicsOptionParamList.get(2));
					searchCriteriaMsg.append(")");
				}
				searchCriteriaMsg.append("\n");
				searchCriteriaMsg.append("Item / Drawing / Part Number : ");
				if(!PLMUtils.isEmpty(plmCopicsInputParamList.get(3))) {
					searchCriteriaMsg.append(plmCopicsInputParamList.get(3));
					searchCriteriaMsg.append("(");
					searchCriteriaMsg.append(plmCopicsOptionParamList.get(3));
					searchCriteriaMsg.append(")");
				}
				searchCriteriaMsg.append("\n");
				searchCriteriaMsg.append("Item / Drawing / Part Number : ");
				if(!PLMUtils.isEmpty(plmCopicsInputParamList.get(4))) {
					searchCriteriaMsg.append(plmCopicsInputParamList.get(4));
					searchCriteriaMsg.append("(");
					searchCriteriaMsg.append(plmCopicsOptionParamList.get(4));
					searchCriteriaMsg.append(")");
				}
				searchCriteriaMsg.append("\n");
				searchCriteriaMsg.append("Item / Drawing / Part Number : ");
				if(!PLMUtils.isEmpty(plmCopicsInputParamList.get(5))) {
					searchCriteriaMsg.append(plmCopicsInputParamList.get(5));
					searchCriteriaMsg.append("(");
					searchCriteriaMsg.append(plmCopicsOptionParamList.get(5));
					searchCriteriaMsg.append(")");
				}
				searchCriteriaMsg.append("\n");
				
				String[] searchCriterias = {"Item / Drawing / Part Number :","Item / Drawing / Part Number :","Item / Drawing / Part Number :","Item / Drawing / Part Number :","Item / Drawing / Part Number :","Item / Drawing / Part Number :"};
				String[] searchCriteriasValue = {plmCopicsInputParamList.get(0),plmCopicsInputParamList.get(1),plmCopicsInputParamList.get(2),plmCopicsInputParamList.get(3),plmCopicsInputParamList.get(4),plmCopicsInputParamList.get(5)};
				String[] searchCriteriasOption = {plmCopicsOptionParamList.get(0),plmCopicsOptionParamList.get(1),plmCopicsOptionParamList.get(2),plmCopicsOptionParamList.get(3),plmCopicsOptionParamList.get(4),plmCopicsOptionParamList.get(5)};
				
				HSSFRow row;
				HSSFCell cell;
				
				for ( int i = 0 ; i < searchCriterias.length; i++ ) {
					row = sheet.createRow(i);
					++rowcount;
					cell = row.createCell(0);
					cell.setCellValue(searchCriterias[i]);
					cell.setCellStyle(cellBoldStyle);
					cell = row.createCell(1);
					cell.setCellValue(searchCriteriasValue[i]);
					cell.setCellStyle(cellBoldStyle);
					cell = row.createCell(2);
					cell.setCellValue(searchCriteriasOption[i]);
					cell.setCellStyle(cellBoldStyle);
				}
				
				if(!PLMUtils.isEmptyList(bomCopicsResultList)) {
					int colIndex = 0;
					int rowIndex = rowcount;
					for (int listCnt = 0 ; listCnt < bomCopicsResultList.size(); listCnt++ ){
						List<PLMBomCopicsData> tempCopicsResultList = bomCopicsResultList.get(listCnt).getResultList();
						LOG.info(tempCopicsResultList.size());
						LOG.info(colIndex);
						if(!PLMUtils.isEmptyList(tempCopicsResultList)) {
							String[] colNames = {"CHILD PREFIX", "PARENT PREFIX", "PARENT ITEM", "QUANTITY"};
								row = sheet.getRow(++rowIndex);
								if(row == null){
									row = sheet.createRow(rowIndex);
								}
								row = sheet.getRow(++rowIndex);
								if(row == null){
									row = sheet.createRow(rowIndex);
								}
						
							for ( int i = 0 ; i < colNames.length; i++ ) {
								cell = row.createCell(colIndex + i);
								cell.setCellValue(colNames[i]);
								cell.setCellStyle(headerStyle);
							}
							
							LOG.info(colIndex);
							for(int i = 0; i < tempCopicsResultList.size(); i++) {
								PLMBomCopicsData dataObj = (PLMBomCopicsData) tempCopicsResultList.get(i);
									row = sheet.getRow(++rowIndex);
									if(row == null){
										row = sheet.createRow(rowIndex);
									}
									cell = row.createCell(colIndex);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getChildPrefix());
									cell = row.createCell(colIndex + 1);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getParentPrefix());
									cell = row.createCell(colIndex + 2);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getParentItem());
									cell = row.createCell(colIndex + 3);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getQty());
								}
								sheet.autoSizeColumn(colIndex);
								sheet.autoSizeColumn(colIndex + 1);
								sheet.autoSizeColumn(colIndex + 2);
								sheet.autoSizeColumn(colIndex + 3);
								colIndex = colIndex + 5;
								rowIndex = rowcount;
							LOG.info(colIndex);
						}
					}
				} else {
					String noRecordMsg = PLMConstants.BOMCOPICS_NO_RECORD_FOUND ;
					row = sheet.createRow(++rowcount);
					row = sheet.createRow(++rowcount);
					cell = row.createCell(3);
					cell.setCellValue(noRecordMsg);
					cell.setCellStyle(noRecordCellStyle);
					searchCriteriaMsg.append("\n");
					searchCriteriaMsg.append(noRecordMsg);
					sheet.autoSizeColumn(0);
					sheet.autoSizeColumn(1);
					sheet.autoSizeColumn(2);
					sheet.autoSizeColumn(3);
				}
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.error(e.getMessage());
		} catch (IOException e) {
			LOG.error(e.getMessage());
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
			  LOG.error("Exception in closing the Input and Output Streams  : " + e.getMessage());
			}
		}
		return searchCriteriaMsg;
	}

	
	/**
	 * This method is used for Validating BomCopics User Inpt
	 * 
	 * @return String
	 */
	public String validateBomCopicsInput(){
		
		LOG.info("Entering validateBomCopicsInput Method");
		plmInputList = new ArrayList <String>();
		copicsInputList = new ArrayList <String>();
		int inputCount = 0;
		int radioCount = 0;
		int plmCount = 0;
		int copicsCount = 0;
		int splCharCount = 0;
		if(!PLMUtils.isEmpty(itemNoOne)){
			inputCount ++;
			if(!PLMUtils.checkForSpecialChars(itemNoOne)){
				splCharCount ++;
			}
			if(!PLMUtils.isEmpty(itemNoOptionOne)){
				radioCount ++;
				if(itemNoOptionOne.equals("PLM")){
					plmCount++;
					plmInputList.add(itemNoOne);
					plmCopicsInputList.add(itemNoOne);
				}
				if(itemNoOptionOne.equals("COPICS")){
					copicsCount++;
					copicsInputList.add(itemNoOne);
				}
			}
		}
		if(!PLMUtils.isEmpty(itemNoTwo)){
			inputCount ++;
			if(!PLMUtils.checkForSpecialChars(itemNoTwo)){
				splCharCount ++;
			}
			if(!PLMUtils.isEmpty(itemNoOptionTwo)){
				radioCount ++;
				if(itemNoOptionTwo.equals("PLM")){
					plmCount++;
					plmInputList.add(itemNoTwo);
				}
				if(itemNoOptionTwo.equals("COPICS")){
					copicsCount++;
					copicsInputList.add(itemNoTwo);
				}
			}
		}
		if(!PLMUtils.isEmpty(itemNoThree)){
			inputCount ++;
			if(!PLMUtils.checkForSpecialChars(itemNoThree)){
				splCharCount ++;
			}
			if(!PLMUtils.isEmpty(itemNoOptionThree)){
				radioCount ++;
				if(itemNoOptionThree.equals("PLM")){
					plmCount++;
					plmInputList.add(itemNoThree);
				}
				if(itemNoOptionThree.equals("COPICS")){
					copicsCount++;
					copicsInputList.add(itemNoThree);
				}
			}
		}
		if(!PLMUtils.isEmpty(itemNoFour)){
			inputCount ++;
			if(!PLMUtils.checkForSpecialChars(itemNoFour)){
				splCharCount ++;
			}
			if(!PLMUtils.isEmpty(itemNoOptionFour)){
				radioCount ++;
				if(itemNoOptionFour.equals("PLM")){
					plmCount++;
					plmInputList.add(itemNoFour);
				}
				if(itemNoOptionFour.equals("COPICS")){
					copicsCount++;
					copicsInputList.add(itemNoFour);
				}
			}
		}
		if(!PLMUtils.isEmpty(itemNoFive)){
			inputCount ++;
			if(!PLMUtils.checkForSpecialChars(itemNoFive)){
				splCharCount ++;
			}
			if(!PLMUtils.isEmpty(itemNoOptionFive)){
				radioCount ++;
				if(itemNoOptionFive.equals("PLM")){
					plmCount++;
					plmInputList.add(itemNoFive);
				}
				if(itemNoOptionFive.equals("COPICS")){
					copicsCount++;
					copicsInputList.add(itemNoFive);
				}
			}
		}
		if(!PLMUtils.isEmpty(itemNoSix)){
			inputCount ++;
			if(!PLMUtils.checkForSpecialChars(itemNoSix)){
				splCharCount ++;
			}
			if(!PLMUtils.isEmpty(itemNoOptionSix)){
				radioCount ++;
				if(itemNoOptionSix.equals("PLM")){
					plmCount++;
					plmInputList.add(itemNoSix);
				}
				if(itemNoOptionSix.equals("COPICS")){
					copicsCount++;
					copicsInputList.add(itemNoSix);
				}
			}
		}
		LOG.info("No of Text Box Inputs : " + inputCount);
		LOG.info("No of RadioButton Inputs : " + radioCount);
		LOG.info("No of choosen PLM Inputs : " + plmCount);
		LOG.info("No of choosen COPICS Inputs : " + copicsCount);
		LOG.info("No of Special Char Inputs : " + splCharCount);
		LOG.info("Size of PLMInput List : " + plmInputList.size());
		LOG.info("Size of COPICSInput List : " + copicsInputList.size());
		
		if (splCharCount != 0){
			alertMessage = alertMessage + PLMConstants.BOMCOPICS_SPL_CHAR_VAL_MSG;
		} 
		if (inputCount != radioCount) {
			alertMessage = alertMessage + PLMConstants.BOMCOPICS_SELECT_PLM_OR_COPICS;
		}
		if(inputCount < 2){
			alertMessage = alertMessage + PLMConstants.BOMCOPICS_ANY_SRCH_CRIT;
		} else if (plmCount == 0 || copicsCount == 0 ){
			alertMessage = alertMessage + PLMConstants.BOMCOPICS_SELECT_MIN_ONE_PLM_AND_COPICS;
		}
		
		LOG.info("Exiting validateBomCopicsInput Method");
		return alertMessage;
	}

	/**
	 * This method is used for Resetting the User input
	 * 
	 * @return String
	 */
	
	public String resetData() {
		LOG.info("Entering Reset Method");
		String fwdflag = "bomCopicsValidation";
		itemNoOne = "";
		itemNoOptionOne = "";
		itemNoTwo = "";
		itemNoOptionTwo = "";
		itemNoThree = "";
		itemNoOptionThree = "";
		itemNoFour = "";
		itemNoOptionFour = "";
		itemNoFive = "";
		itemNoOptionFive = "";
		itemNoSix = "";
		itemNoOptionSix = "";
		LOG.info("Exiting Reset Method");
		return fwdflag;
	}

	/**
	 * Start of Setters and Getters
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	
	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}

	/**
	 * @param log the lOG to set
	 */
	public static void setLOG(Logger log) {
		LOG = log;
	}

	/**
	 * @return the bomCopicsData
	 */
	public PLMBomCopicsData getBomCopicsData() {
		return bomCopicsData;
	}

	/**
	 * @param bomCopicsData the bomCopicsData to set
	 */
	public void setBomCopicsData(PLMBomCopicsData bomCopicsData) {
		this.bomCopicsData = bomCopicsData;
	}

	/**
	 * @return the itemNoOne
	 */
	public String getItemNoOne() {
		return itemNoOne;
	}

	/**
	 * @param itemNoOne the itemNoOne to set
	 */
	public void setItemNoOne(String itemNoOne) {
		this.itemNoOne = itemNoOne;
	}

	/**
	 * @return the itemNoOptionOne
	 */
	public String getItemNoOptionOne() {
		return itemNoOptionOne;
	}

	/**
	 * @param itemNoOptionOne the itemNoOptionOne to set
	 */
	public void setItemNoOptionOne(String itemNoOptionOne) {
		this.itemNoOptionOne = itemNoOptionOne;
	}

	/**
	 * @return the itemNoTwo
	 */
	public String getItemNoTwo() {
		return itemNoTwo;
	}

	/**
	 * @param itemNoTwo the itemNoTwo to set
	 */
	public void setItemNoTwo(String itemNoTwo) {
		this.itemNoTwo = itemNoTwo;
	}

	/**
	 * @return the itemNoOptionTwo
	 */
	public String getItemNoOptionTwo() {
		return itemNoOptionTwo;
	}

	/**
	 * @param itemNoOptionTwo the itemNoOptionTwo to set
	 */
	public void setItemNoOptionTwo(String itemNoOptionTwo) {
		this.itemNoOptionTwo = itemNoOptionTwo;
	}

	/**
	 * @return the itemNoThree
	 */
	public String getItemNoThree() {
		return itemNoThree;
	}

	/**
	 * @param itemNoThree the itemNoThree to set
	 */
	public void setItemNoThree(String itemNoThree) {
		this.itemNoThree = itemNoThree;
	}

	/**
	 * @return the itemNoOptionThree
	 */
	public String getItemNoOptionThree() {
		return itemNoOptionThree;
	}

	/**
	 * @param itemNoOptionThree the itemNoOptionThree to set
	 */
	public void setItemNoOptionThree(String itemNoOptionThree) {
		this.itemNoOptionThree = itemNoOptionThree;
	}

	/**
	 * @return the itemNoFour
	 */
	public String getItemNoFour() {
		return itemNoFour;
	}

	/**
	 * @param itemNoFour the itemNoFour to set
	 */
	public void setItemNoFour(String itemNoFour) {
		this.itemNoFour = itemNoFour;
	}

	/**
	 * @return the itemNoOptionFour
	 */
	public String getItemNoOptionFour() {
		return itemNoOptionFour;
	}

	/**
	 * @param itemNoOptionFour the itemNoOptionFour to set
	 */
	public void setItemNoOptionFour(String itemNoOptionFour) {
		this.itemNoOptionFour = itemNoOptionFour;
	}

	/**
	 * @return the itemNoFive
	 */
	public String getItemNoFive() {
		return itemNoFive;
	}

	/**
	 * @param itemNoFive the itemNoFive to set
	 */
	public void setItemNoFive(String itemNoFive) {
		this.itemNoFive = itemNoFive;
	}

	/**
	 * @return the itemNoOptionFive
	 */
	public String getItemNoOptionFive() {
		return itemNoOptionFive;
	}

	/**
	 * @param itemNoOptionFive the itemNoOptionFive to set
	 */
	public void setItemNoOptionFive(String itemNoOptionFive) {
		this.itemNoOptionFive = itemNoOptionFive;
	}

	/**
	 * @return the itemNoSix
	 */
	public String getItemNoSix() {
		return itemNoSix;
	}

	/**
	 * @param itemNoSix the itemNoSix to set
	 */
	public void setItemNoSix(String itemNoSix) {
		this.itemNoSix = itemNoSix;
	}

	/**
	 * @return the itemNoOptionSix
	 */
	public String getItemNoOptionSix() {
		return itemNoOptionSix;
	}

	/**
	 * @param itemNoOptionSix the itemNoOptionSix to set
	 */
	public void setItemNoOptionSix(String itemNoOptionSix) {
		this.itemNoOptionSix = itemNoOptionSix;
	}

	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the plmMetricsService
	 */
	public PLMMetricsServiceIfc getPlmMetricsService() {
		return plmMetricsService;
	}

	/**
	 * @param plmMetricsService the plmMetricsService to set
	 */
	public void setPlmMetricsService(PLMMetricsServiceIfc plmMetricsService) {
		this.plmMetricsService = plmMetricsService;
	}

	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return the plmInputList
	 */
	public List<String> getPlmInputList() {
		return plmInputList;
	}

	/**
	 * @param plmInputList the plmInputList to set
	 */
	public void setPlmInputList(List<String> plmInputList) {
		this.plmInputList = plmInputList;
	}

	/**
	 * @return the copicsInputList
	 */
	public List<String> getCopicsInputList() {
		return copicsInputList;
	}

	/**
	 * @param copicsInputList the copicsInputList to set
	 */
	public void setCopicsInputList(List<String> copicsInputList) {
		this.copicsInputList = copicsInputList;
	}

	/**
	 * @return the plmCopicsInputList
	 */
	public List<String> getPlmCopicsInputList() {
		return plmCopicsInputList;
	}

	/**
	 * @param plmCopicsInputList the plmCopicsInputList to set
	 */
	public void setPlmCopicsInputList(List<String> plmCopicsInputList) {
		this.plmCopicsInputList = plmCopicsInputList;
	}

	/**
	 * @return the plmCopicsOptionList
	 */
	public List<String> getPlmCopicsOptionList() {
		return plmCopicsOptionList;
	}

	/**
	 * @param plmCopicsOptionList the plmCopicsOptionList to set
	 */
	public void setPlmCopicsOptionList(List<String> plmCopicsOptionList) {
		this.plmCopicsOptionList = plmCopicsOptionList;
	}
	
	/**
	 * End of Setters and Getters
	 */
}