/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCustBomRptMB.java
 * @Creation date: 6-March-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFStyles;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTHeight;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTJc;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTShd;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTString;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblBorders;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblWidth;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTcPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTrPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTVerticalJc;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STBorder;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STJc;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STShd;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STTblWidth;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STVerticalJc;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMBoilerShipBomReportData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMBoilerShippingBomReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMCustBomRptMB {

	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMCustBomRptMB.class);
	private List<SelectItem> projectList = new ArrayList<SelectItem>();
	private List<SelectItem> contractNameList = new ArrayList<SelectItem>();
	private List<SelectItem> partAssblyNumList = new ArrayList<SelectItem>();
	private List<SelectItem> taskNameList = new ArrayList<SelectItem>();
	private String selTaskName;
	private List<SelectItem> projectListReset = new ArrayList<SelectItem>();
	private List<SelectItem> projPartList = new ArrayList<SelectItem>();
	private List<SelectItem> projPartListNew = new ArrayList<SelectItem>();
	private List<PLMBoilerShipBomReportData> shippingBomBoilerReportList = new ArrayList<PLMBoilerShipBomReportData>();
	private String totalRecordShippingBomAptMsg;
	private String customerNameHeader;
	private String stationNameHeader;
	private String  unitNoHeader;
	private String  stationLocationHeader;
	private String  contractNameHeader;
	private String  productDescHeader;
	private PLMBoilerShipBomReportData pwiReportvo = new PLMBoilerShipBomReportData();
	private String alertMessage;
	private boolean showPartRev;
	private boolean showDocRev;
	/**
	 * Holds the allOpenPrjName
	 */
	private boolean allOpenPrjName;
	/**
	 * Holds the allAssyNo
	 */
	private boolean allAssyNo;
	
	/**
	 * Holds the allOpenContractName
	 */
	private boolean allOpenContractName;
	/**
	 * Holds the selCustBomProjectName
	 */
	private List<String> selCustBomProjectName = new ArrayList<String>();

	private String selCustBomCntractName;
	private List<String> selPartAssmblyNum  = new ArrayList<String>();
	private PLMBoilerShippingBomReportServiceIfc plmBoilerShippingBomReportService = null;
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds user information
	 */
	private PLMPwiUserData userDetails = null;

	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	/**
	 * Holds the resourceBundle
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");


	
	/**
	 * @return the shippingBomBoilerReportList
	 */
	public List<PLMBoilerShipBomReportData> getShippingBomBoilerReportList() {
		return shippingBomBoilerReportList;
	}

	/**
	 * @param shippingBomBoilerReportList the shippingBomBoilerReportList to set
	 */
	public void setShippingBomBoilerReportList(
			List<PLMBoilerShipBomReportData> shippingBomBoilerReportList) {
		this.shippingBomBoilerReportList = shippingBomBoilerReportList;
	}

	/**
	 * @return the plmBoilerShippingBomReportService
	 */
	public PLMBoilerShippingBomReportServiceIfc getPlmBoilerShippingBomReportService() {
		return plmBoilerShippingBomReportService;
	}

	/**
	 * @param plmBoilerShippingBomReportService the plmBoilerShippingBomReportService to set
	 */
	public void setPlmBoilerShippingBomReportService(
			PLMBoilerShippingBomReportServiceIfc plmBoilerShippingBomReportService) {
		this.plmBoilerShippingBomReportService = plmBoilerShippingBomReportService;
	}

	/**
	 * @return the projPartList
	 */
	public List<SelectItem> getProjPartList() {
		return projPartList;
	}

	/**
	 * @param projPartList the projPartList to set
	 */
	public void setProjPartList(List<SelectItem> projPartList) {
		this.projPartList = projPartList;
	}
	
	/**
	 * @return the projPartListNew
	 */
	public List<SelectItem> getProjPartListNew() {
		return projPartListNew;
	}

	/**
	 * @param projPartListNew the projPartListNew to set
	 */
	public void setProjPartListNew(List<SelectItem> projPartListNew) {
		this.projPartListNew = projPartListNew;
	}

	/**
	 * @return the customerNameHeader
	 */
	public String getCustomerNameHeader() {
		return customerNameHeader;
	}

	/**
	 * @param customerNameHeader the customerNameHeader to set
	 */
	public void setCustomerNameHeader(String customerNameHeader) {
		this.customerNameHeader = customerNameHeader;
	}

	/**
	 * @return the stationNameHeader
	 */
	public String getStationNameHeader() {
		return stationNameHeader;
	}

	/**
	 * @param stationNameHeader the stationNameHeader to set
	 */
	public void setStationNameHeader(String stationNameHeader) {
		this.stationNameHeader = stationNameHeader;
	}

	

	/**
	 * @return the unitNoHeader
	 */
	public String getUnitNoHeader() {
		return unitNoHeader;
	}

	/**
	 * @param unitNoHeader the unitNoHeader to set
	 */
	public void setUnitNoHeader(String unitNoHeader) {
		this.unitNoHeader = unitNoHeader;
	}

	/**
	 * @return the stationLocationHeader
	 */
	public String getStationLocationHeader() {
		return stationLocationHeader;
	}

	/**
	 * @param stationLocationHeader the stationLocationHeader to set
	 */
	public void setStationLocationHeader(String stationLocationHeader) {
		this.stationLocationHeader = stationLocationHeader;
	}

	/**
	 * @return the contractNameHeader
	 */
	public String getContractNameHeader() {
		return contractNameHeader;
	}

	/**
	 * @param contractNameHeader the contractNameHeader to set
	 */
	public void setContractNameHeader(String contractNameHeader) {
		this.contractNameHeader = contractNameHeader;
	}

	/**
	 * @return the productDescHeader
	 */
	public String getProductDescHeader() {
		return productDescHeader;
	}

	/**
	 * @param productDescHeader the productDescHeader to set
	 */
	public void setProductDescHeader(String productDescHeader) {
		this.productDescHeader = productDescHeader;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @return the pwiReportvo
	 */
	public PLMBoilerShipBomReportData getPwiReportvo() {
		return pwiReportvo;
	}

	/**
	 * @param pwiReportvo the pwiReportvo to set
	 */
	public void setPwiReportvo(PLMBoilerShipBomReportData pwiReportvo) {
		this.pwiReportvo = pwiReportvo;
	}

	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the allOpenPrjName
	 */
	public boolean isAllOpenPrjName() {
		return allOpenPrjName;
	}

	/**
	 * @param allOpenPrjName the allOpenPrjName to set
	 */
	public void setAllOpenPrjName(boolean allOpenPrjName) {
		this.allOpenPrjName = allOpenPrjName;
	}

	/**
	 * @return the allOpenContractName
	 */
	public boolean isAllOpenContractName() {
		return allOpenContractName;
	}

	/**
	 * @param allOpenContractName the allOpenContractName to set
	 */
	public void setAllOpenContractName(boolean allOpenContractName) {
		this.allOpenContractName = allOpenContractName;
	}

	/**
	 * @return the selCustBomProjectName
	 */
	public List<String> getSelCustBomProjectName() {
		return selCustBomProjectName;
	}

	/**
	 * @param selCustBomProjectName the selCustBomProjectName to set
	 */
	public void setSelCustBomProjectName(List<String> selCustBomProjectName) {
		this.selCustBomProjectName = selCustBomProjectName;
	}

	/**
	 * @return the selCustBomCntractName
	 */
	public String getSelCustBomCntractName() {
		return selCustBomCntractName;
	}

	/**
	 * @param selCustBomCntractName the selCustBomCntractName to set
	 */
	public void setSelCustBomCntractName(String selCustBomCntractName) {
		this.selCustBomCntractName = selCustBomCntractName;
	}

	/**
	 * @return the selPartAssmblyNum
	 */
	public List<String> getSelPartAssmblyNum() {
		return selPartAssmblyNum;
	}

	/**
	 * @param selPartAssmblyNum the selPartAssmblyNum to set
	 */
	public void setSelPartAssmblyNum(List<String> selPartAssmblyNum) {
		this.selPartAssmblyNum = selPartAssmblyNum;
	}

	/**
	 * @return the plmBoilerReportService
	 */
	public PLMBoilerShippingBomReportServiceIfc getPlmBoilerReportService() {
		return plmBoilerShippingBomReportService;
	}

	/**
	 * @param plmBoilerReportService the plmBoilerReportService to set
	 */
	public void setPlmBoilerReportService(
			PLMBoilerShippingBomReportServiceIfc plmBoilerShippingBomReportService) {
		this.plmBoilerShippingBomReportService = plmBoilerShippingBomReportService;
	}

	/**
	 * @return the projectList
	 */
	public List<SelectItem> getProjectList() {
		return projectList;
	}

	/**
	 * @param projectList the projectList to set
	 */
	public void setProjectList(List<SelectItem> projectList) {
		this.projectList = projectList;
	}

	/**
	 * @return the contractNameList
	 */
	public List<SelectItem> getContractNameList() {
		return contractNameList;
	}

	/**
	 * @param contractNameList the contractNameList to set
	 */
	public void setContractNameList(List<SelectItem> contractNameList) {
		this.contractNameList = contractNameList;
	}

	/**
	 * @return the partAssblyNumList
	 */
	public List<SelectItem> getPartAssblyNumList() {
		return partAssblyNumList;
	}

	/**
	 * @param partAssblyNumList the partAssblyNumList to set
	 */
	public void aetPartAssblyNumList(List<SelectItem> partAssblyNumList) {
		this.partAssblyNumList = partAssblyNumList;
	}

	
	/**
	 * @return the taskNameList
	 */
	public List<SelectItem> getTaskNameList() {
		return taskNameList;
	}

	/**
	 * @param taskNameList the taskNameList to set
	 */
	public void setTaskNameList(List<SelectItem> taskNameList) {
		this.taskNameList = taskNameList;
	}

	/**
	 * @return the selTaskName
	 */
	public String getSelTaskName() {
		return selTaskName;
	}

	/**
	 * @param selTaskName the selTaskName to set
	 */
	public void setSelTaskName(String selTaskName) {
		this.selTaskName = selTaskName;
	}

	/**
	 * @return the totalRecordShippingBomAptMsg
	 */
	public String getTotalRecordShippingBomAptMsg() {
		return totalRecordShippingBomAptMsg;
	}

	/**
	 * @param totalRecordShippingBomAptMsg the totalRecordShippingBomAptMsg to set
	 */
	public void setTotalRecordShippingBomAptMsg(String totalRecordShippingBomAptMsg) {
		this.totalRecordShippingBomAptMsg = totalRecordShippingBomAptMsg;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}


	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor
	 *            the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}
	/**
	 * @return the userDetails
	 */
	public PLMPwiUserData getUserDetails() {
		return userDetails;
	}
	/**
	 * @param userDetails the userDetails to set
	 */
	public void setUserDetails(PLMPwiUserData userDetails) {
		this.userDetails = userDetails;
	}
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}
	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * This method is used for getProjectNameAndContractNameList
	 *  for project name and contract name
	 * 
	 * @return String
	 */
	public String getProjectNameAndContractNameList()
	{
		LOG.info("getProjectNameAndContractNameList() Method");
		String fwdFlag = "";
		alertMessage = "";
		customerNameHeader="";
		stationNameHeader="";
		unitNoHeader="";
		stationLocationHeader="";
		contractNameHeader="";
		productDescHeader="";
		allOpenPrjName=false;
		allOpenContractName=false;
		allAssyNo=false;
		selCustBomProjectName=new ArrayList<String>();
		selCustBomCntractName="";
		selTaskName ="";
		selPartAssmblyNum=new ArrayList<String>();
		pwiReportvo.setSelectedPrjName("");
		pwiReportvo.setSelectedCntractName("");
		pwiReportvo.setSelectedPartAssmbly("");
		pwiReportvo.setSelectedTakName("");
		pwiReportvo.setContractSelctd(false);
		pwiReportvo.setProjectSelctd(false);
		pwiReportvo.setTaskSelectd(false);
		showPartRev = true;
		showDocRev = true;
		try {
			 commonMB.insertCannedRptRecordHitInfo("Customer BOM Report");
			// Map<String, List<SelectItem>> dropdownlist = plmBoilerShippingBomReportService.getProjectNameAndContractNameList();
			// projectList = (List<SelectItem>) dropdownlist.get("projectnamelist");
			 contractNameList = new ArrayList<SelectItem>();
			 projectListReset=projectList;
			 projectList=new ArrayList<SelectItem>();
			// topLvlPartList = (List<SelectItem>) dropdownlist.get("topLvlpartlistreset");
			 partAssblyNumList=new ArrayList<SelectItem>();
			 taskNameList = new ArrayList<SelectItem>();
			fwdFlag = "customerBomRpt";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getProjectNameAndContractNameList: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Shipping BOM Report");
		} 
		return fwdFlag;
	}
	/**
	 * This method is used for Contract auto complete feature
	 * 
	 * @return String
	 */
	/*public List<String> contractFamilyAutocomplete(Object contractShipBomFamilySuggest) {
		LOG.info("Inside contractFamilyAutocomplete method... PLMBoilerShippingBomReportMB");
		String pref = (String) contractShipBomFamilySuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (contractNameList.size() > 0) {
				for (SelectItem item : contractNameList) {
					if (!item.getLabel().equals("")
							&& item.getLabel().startsWith(
									pref.toUpperCase(Locale.getDefault()))) {
						result.add(item.getLabel());
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@contractFamilyAutocomplete in PLMBoilerShippingBomReportMB:",
					exception);
		}
		LOG.info("Exit from contractFamilyAutocomplete method... PLMBoilerShippingBomReportMB");
		return result;
	}*/
	public void contractFamilyAutocomplete(){
		LOG.info("Entering contractFamilyAutocomplete method");
		try{
			contractNameList=new ArrayList<SelectItem>();
			if(!PLMUtils.isEmpty(pwiReportvo.getSelectedCntractName())){
				contractNameList = plmBoilerShippingBomReportService.contractFamilyAutocomplete(pwiReportvo.getSelectedCntractName().trim());
			if(PLMUtils.isEmptyList(contractNameList)){
				contractNameList=new ArrayList<SelectItem>();
				 alertMessage = "No Contracts Found for the Search";
			}
			}else{
				 alertMessage = "Please type some text in the box";
			}
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting contractFamilyAutocomplete method");
	}
	/**
	 * This method is used for Project auto complete feature
	 * 
	 * @return String
	 */
	public List<String> projectFamilyAutocomplete(Object projectCustBomSuggest) {
		LOG.info("Inside projectFamilyAutocomplete method... PLMBoilerShippingBomReportMB");
		String pref = (String) projectCustBomSuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (projectList.size() > 0) {
				for (SelectItem item : projectList) {
					if (!item.getLabel().equals("")
							&& item.getLabel().startsWith(
									pref.toUpperCase(Locale.getDefault()))) {
						result.add(item.getLabel());
						
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@projectFamilyAutocomplete in PLMBoilerShippingBomReportMB:",
					exception);
		}
		LOG.info("Exit from projectFamilyAutocomplete method... PLMBoilerShippingBomReportMB");
		return result;
	}
	/**
	 * This method is used for Task Nanme auto complete feature
	 * 
	 * @return String
	 */
	public List<String> taskNameAutocomplete(Object topLvlPartShipBomFamilySuggest) {
		LOG.info("Inside taskNameAutocomplete method... PLMBoilerShippingBomReportMB");
		String pref = (String) topLvlPartShipBomFamilySuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (taskNameList.size() > 0) {
				for (SelectItem item : taskNameList) {
					if (!item.getLabel().equals("")
							&& item.getLabel().startsWith(
									pref.toUpperCase(Locale.getDefault()))) {
						result.add(item.getValue().toString());
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@taskNameAutocomplete in PLMBoilerShippingBomReportMB:",
					exception);
		}
		LOG.info("Exit from taskNameAutocomplete method... PLMBoilerShippingBomReportMB");
		return result;
	}
	
	/**
	 * This method is used for part Assmbly Num auto complete feature
	 * 
	 * @return String
	 */
	public List<String> partAssmblyNumAutocomplete(Object topLvlPartShipBomFamilySuggest) {
		LOG.info("Inside partAssmblyNumAutocomplete method... PLMBoilerShippingBomReportMB");
		String pref = (String) topLvlPartShipBomFamilySuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (partAssblyNumList.size() > 0) {
				for (SelectItem item : partAssblyNumList) {
					if (!item.getLabel().equals("")
							&& item.getLabel().startsWith(
									pref.toUpperCase(Locale.getDefault()))) {
						result.add(item.getValue().toString());
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@topLvlPartFamilyAutocomplete in PLMBoilerShippingBomReportMB:",
					exception);
		}
		LOG.info("Exit from topLvlPartFamilyAutocomplete method... PLMBoilerShippingBomReportMB");
		return result;
	}
	/**
	 * This method is used to get Project Information for Contracts
	 * 
	 * @param event
	 */
	public void fetchProjectList(ActionEvent event){
		LOG.info("Entering fetchProjectList method PLMBoilerShippingBomReportMB");
		try{
			partAssblyNumList=new ArrayList<SelectItem>();
			 List <PLMBoilerShipBomReportData> projectListData = new ArrayList<PLMBoilerShipBomReportData>();
			 projPartList = new ArrayList<SelectItem>();
			 projectListData = plmBoilerShippingBomReportService.fetchProjectList(selCustBomCntractName);
			 LOG.info("project LIST DATA Size"+projectListData.size());
			 if(projectListData.size()>0)
			 {
				 pwiReportvo.setContractSelctd(true);
			   for(int i=0;i<projectListData.size();i++){
				   projPartList.add(new SelectItem(projectListData.get(i).getProjectName()));
				}
			 }
			   projectList=projPartList;
			  
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting fetchProjectList method PLMBoilerShippingBomReportMB");
	}
	/**
	 * This method is used to get Task Names for Projects
	 * 
	 * @param event
	 */
	public void fetchTasktList(ActionEvent event){
		LOG.info("Entering fetchTasktList method PLMBoilerShippingBomReportMB");
		try{
			 List <PLMBoilerShipBomReportData> partListData = new ArrayList<PLMBoilerShipBomReportData>();
			 List <SelectItem> taskListselectItem = new ArrayList<SelectItem>();
			 if (allOpenPrjName){
				 if(!PLMUtils.isEmptyList(projectList))
				      {
					 selCustBomProjectName = new ArrayList<String>();
						   for (int i = 0 ; i < projectList.size() ; i++ )
					  	     {
							String requireValue = projectList.get(i).getValue().toString();
							selCustBomProjectName.add(requireValue);
						    }
				      }else{
				    	  
				    	  alertMessage = "Please select Contract Name";
				    	  
				      }
			}
			 partListData = plmBoilerShippingBomReportService.fetchTasktList(selCustBomProjectName,projectListReset,allOpenPrjName);
			 LOG.info("Task LIST DATA Size"+partListData.size());
			 if(partListData.size()>0){
				 pwiReportvo.setProjectSelctd(true);
			   for(int i=0;i<partListData.size();i++){
				   taskListselectItem.add(new SelectItem(partListData.get(i).getTopLvlPart(),partListData.get(i).getTaskNameDesc()));
				}
			}
			 taskNameList =taskListselectItem;
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting fetchTasktList method PLMBoilerShippingBomReportMB");
	}
	
	
	/**
	 * This method is used to get Top Lvl Part Information for Projects
	 * 
	 * @param event
	 */
	public void fetchPartAssemblyNumList(ActionEvent event){
		LOG.info("Entering fetchPartAssemblyNumList method PLMBoilerShippingBomReportMB");
		try{
			partAssblyNumList=new ArrayList<SelectItem>();
			 List <PLMBoilerShipBomReportData> partAssmblyData = new ArrayList<PLMBoilerShipBomReportData>();
			 List <SelectItem> partAssmblyNum = new ArrayList<SelectItem>();
			 if(!PLMUtils.isEmpty(selTaskName)){
			  partAssmblyData = plmBoilerShippingBomReportService.fetchPartAssemblyNumList(selCustBomCntractName, selCustBomProjectName, allOpenPrjName,
					  selTaskName);
			  LOG.info("Part Assembly DATA Size"+partAssmblyData.size());
			 }
			 if(partAssmblyData.size()>0){
				 pwiReportvo.setTaskSelectd(true);
			   for(int i=0;i<partAssmblyData.size();i++){
				   partAssmblyNum.add(new SelectItem(partAssmblyData.get(i).getPartAssmblyNo(),
						   partAssmblyData.get(i).getPartAssmblyNoDesc()));
				}
			   partAssblyNumList =partAssmblyNum;
			}
			 
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting fetchPartAssemblyNumList method PLMBoilerShippingBomReportMB");
	}
	
	
	/**
	 * reset
	 */
	public void resetShippingBomAppReport(){
		alertMessage = "";
		allOpenPrjName=false;
		allOpenContractName=false;
		allAssyNo=false;
		contractNameList=new ArrayList<SelectItem>();
		projectList=new ArrayList<SelectItem>();
		partAssblyNumList=new ArrayList<SelectItem>();
		taskNameList=new ArrayList<SelectItem>();
		totalRecordShippingBomAptMsg="";
		customerNameHeader="";
		 stationNameHeader="";
		 unitNoHeader="";
		 stationLocationHeader="";
		 contractNameHeader="";
		 productDescHeader="";
		pwiReportvo.setSelectedPrjName("");
		pwiReportvo.setSelectedCntractName("");
		pwiReportvo.setSelectedPartAssmbly("");
		pwiReportvo.setSelectedTakName("");
		selCustBomCntractName = "";
		selCustBomProjectName = new ArrayList<String>();
		selPartAssmblyNum = new ArrayList<String>();
		pwiReportvo.setContractSelctd(false);
		pwiReportvo.setProjectSelctd(false);
		pwiReportvo.setTaskSelectd(false);
		showPartRev = true;
		showDocRev = true;
	}
	
	/**
	 * This method is used for Generating Customer BOM Report
	 * @throws PWiException 
	 * 
	 * 
	 */
	public void generateCustBOMRpt() throws PWiException {
		LOG.info("Etnering into generateCustBOMRpt");
		alertMessage ="";
		 if (allOpenPrjName){
			 if(!PLMUtils.isEmptyList(projectList))
			      {
				 selCustBomProjectName = new ArrayList<String>();
					   for (int i = 0 ; i < projectList.size() ; i++ )
				  	     {
						String requireValue = projectList.get(i).getValue().toString();
						selCustBomProjectName.add(requireValue);
					    }
			      }
		}
		
		 if (allAssyNo){
			 if(!PLMUtils.isEmptyList(partAssblyNumList))
			      {
				 selPartAssmblyNum = new ArrayList<String>();
					   for (int i = 0 ; i < partAssblyNumList.size() ; i++ )
				  	     {
						String requireValue = partAssblyNumList.get(i).getValue().toString();
						selPartAssmblyNum.add(requireValue);
					    }
			      }
		}
		 
		if (PLMUtils.isEmpty(selCustBomCntractName)) {
			alertMessage = "*Contract Name Input Selection is mandatory";
		}else if (PLMUtils.isEmptyList(selCustBomProjectName) && !allOpenPrjName ) {
			alertMessage = "*Please select atleast one Project Name";
		}else if (PLMUtils.isEmpty(selTaskName)) {
			alertMessage = "*Task Name Input Selection is mandatory";
		}else if ((PLMUtils.isEmptyList(selPartAssmblyNum) && !allAssyNo) || (PLMUtils.isEmptyList(selPartAssmblyNum) && allAssyNo) ) {
			alertMessage = "*Parent Assembly No Input Selection is mandatory";
		}else{
			userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
			alertMessage = PLMConstants.CUST_BOM_RPT_MAIL_ALERT_MSG;
			taskExecutor.execute(new DocGenerationThread());
		}
	}
	
	/**
	 * Background Process Thread
	 */
	private class DocGenerationThread implements Runnable {
		public DocGenerationThread() {
		}
		public void run() {
			sendCustomerBomRptMail();
		}
	}
	
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return void
	 * @throws IOException 
	 */
	public void sendCustomerBomRptMail(){
		LOG.info("Entering sendCustomerBomRptMail Method");
		
	    String contractNm =selCustBomCntractName;
	    List<String> selProjectNm =selCustBomProjectName;
	    boolean allOpenProjectNm =allOpenPrjName;
	    boolean allAssyNum=allAssyNo;
	    String selTaskNm =selTaskName;
	    List<String> selPartAssmbly =selPartAssmblyNum;
	    List<SelectItem> partAssblyNumListLcl =partAssblyNumList;
		String from = PLMConstants.OMM_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.CUST_BOM_RPT_SUBJECT;
		String filePathDocx = "";
		String tempPathDocx = "";
		String custBomRptTempPath = "";
		FileOutputStream fos = null;
		boolean showPartRevision = showPartRev;
		boolean showDocRevision = showDocRev;
		try {
			
			List<PLMBoilerShipBomReportData> customerBomDataList = plmBoilerShippingBomReportService.getCustomerBOMRptData(
					contractNm,selProjectNm,allOpenProjectNm,selTaskNm,allAssyNum,selPartAssmbly,showPartRevision,showDocRevision);
			List<PLMBoilerShipBomReportData> headerList = plmBoilerShippingBomReportService.getHeaderData(
					contractNm,selProjectNm,allOpenProjectNm,selTaskNm,allAssyNum,selPartAssmbly);
			if(!PLMUtils.isEmptyList(customerBomDataList)){
				final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
				Date uniqDate = new Date();
				String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
				String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
				filePathDocx = fileDir + resourceBundle.getString("CUSTOMER_BOM_REPORT_NAME") + "_" + uniqTime + ".docx";
				tempPathDocx = fileDir + resourceBundle.getString("CUSTOMER_BOM_REPORT_TEMPLATE_NAME");
				custBomRptTempPath = fileDir + resourceBundle.getString("CUSTOMER_BOM_REPORT_TEMPLATE");

			   StringBuffer mailBody = new StringBuffer().append(toAddressee);
				mailBody.append(PLMConstants.CUST_BOM_RPT_MAIL_CONTENT)
				.append("Contract Name: "+contractNm);
				
				 if(!PLMUtils.isEmptyList(selProjectNm)){
					mailBody.append("\n\nSelected Project Names: "+selProjectNm);
				 }
				if(!PLMUtils.isEmpty(selTaskNm)){
					mailBody.append("\n\nTask Name: "+selTaskNm);
				}
				if(!PLMUtils.isEmptyList(selPartAssmbly)){
					mailBody.append("\n\nParent ASSY No: "+selPartAssmbly);
				}
				mailBody.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				 createInputDocument(filePathDocx, tempPathDocx, custBomRptTempPath, contractNm, selProjectNm,selTaskNm, selPartAssmbly);
				 createContractHdrDoc(filePathDocx, tempPathDocx, headerList,selPartAssmbly,partAssblyNumListLcl);
				 createCustomerBomDoc(filePathDocx, tempPathDocx, customerBomDataList, showPartRevision, showDocRevision);
				 PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathDocx);
				 LOG.info("Report Attachment Mail sent successfully.");
			}else{
				StringBuffer mailNoDataBody = new StringBuffer().append(toAddressee);
				mailNoDataBody.append(PLMConstants.CUST_BOM_RPT_MAIL_CONTENT_NO_RECORD)
				.append("Contract Name: "+contractNm);
				 if(!PLMUtils.isEmptyList(selProjectNm)){
					 mailNoDataBody.append("\n\nSelected Project Names: "+selProjectNm);
					 }
					if(!PLMUtils.isEmpty(selTaskNm)){
						mailNoDataBody.append("\n\nTask Name: "+selTaskNm);
					}
					if(!PLMUtils.isEmptyList(selPartAssmbly)){
						mailNoDataBody.append("\n\nPart Assembly No: "+selPartAssmbly);
					}
				mailNoDataBody.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
				LOG.info("No data Mail sent successfully.");
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendCustomerBomRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendCustomerBomRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} finally {
			try {
				if (fos!=null){
					fos.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			deleteFiles(filePathDocx);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendCustomerBomRptMail Method");
	}
	
	/**
	 * This method is used to createInputDocument
	 * 
	 * @param FileOutputStream
	 * @param filepathDocx
	 * @param templatePath
	 * @param cntrtSmryTempPath
	 */
	public void createInputDocument(String filePathDocx, String templatePath, String custBomRptTempPath, String contractNum
			,List<String> selProjectName,String selTaskNm,List<String> selPartAssmblyNo) throws Exception {
		LOG.info("Creating New document document -------> " + filePathDocx);
		LOG.info("templatePath------------->" + templatePath);
		//String contractNumInSaverpt = contractNum;
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFDocument doc = new XWPFDocument(new FileInputStream(new File(custBomRptTempPath)));
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3

		XWPFParagraph titlePara = doc.createParagraph();
		titlePara.setStyle("Heading1"); // 4
		titlePara.setAlignment(ParagraphAlignment.CENTER);
		XWPFRun title = titlePara.createRun();
		title.setColor("000000");
		title.setText("CUSTOMER BILL OF MATERIAL");
		//title.addBreak();
		
		/*XWPFParagraph titlePara1 = doc.createParagraph();
		titlePara1.setStyle("Normal"); // 4
		titlePara1.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun title1 = titlePara1.createRun();
		title1.setColor("000000");
		title1.addBreak();
		title1.setText("Input Filters");
		title1.setBold(true);
		title1.setUnderline(UnderlinePatterns.SINGLE);
		title1.setFontSize(10);
		title1.addBreak();

		XWPFParagraph tmpParagraph1 = doc.createParagraph();
		tmpParagraph1.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun boldRun = tmpParagraph1.createRun();
		boldRun.setBold(true);
		boldRun.setFontSize(10);
		XWPFRun unboldRun = tmpParagraph1.createRun();
		unboldRun.setFontSize(10);
		
		XWPFParagraph tmpParagraph2 = doc.createParagraph();
		tmpParagraph2.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun boldRun1 = tmpParagraph2.createRun();
		boldRun1.setBold(true);
		boldRun1.setFontSize(10);
		XWPFRun unboldRun1 = tmpParagraph2.createRun();
		unboldRun1.setFontSize(10);
		
		XWPFParagraph tmpParagraph3 = doc.createParagraph();
		tmpParagraph3.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun boldRun2 = tmpParagraph3.createRun();
		boldRun2.setBold(true);
		boldRun2.setFontSize(10);
		XWPFRun unboldRun2 = tmpParagraph3.createRun();
		unboldRun2.setFontSize(10);
		
		XWPFParagraph tmpParagraph4 = doc.createParagraph();
		tmpParagraph4.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun boldRun3 = tmpParagraph4.createRun();
		boldRun3.setBold(true);
		boldRun3.setFontSize(10);
		XWPFRun unboldRun3 = tmpParagraph4.createRun();
		unboldRun3.setFontSize(10);
		

		if(!PLMUtils.isEmpty(contractNumInSaverpt)){
			boldRun.setText("Contract Name: ");
			unboldRun.setText(contractNumInSaverpt);
		}
		
		if (null != selProjectName && selProjectName.size() > 0) {
			boldRun1.setText("Selected Project Names: ");
			StringBuffer projectNms = new StringBuffer();
			for(String prjNm:selProjectName){
				projectNms.append(prjNm);
				projectNms.append(",");
			}
			unboldRun1.setText(projectNms.substring(0, projectNms.length()-1));
		} 
		
		if(!PLMUtils.isEmpty(selTaskNm)){
			boldRun2.setText("Task Name: ");
			unboldRun2.setText(selTaskNm);
		}
		
		if(!PLMUtils.isEmpty(selPartAssmblyNo)){
			 boldRun3.setText("Parent ASSY No: ");
			 unboldRun3.setText(selPartAssmblyNo);
		 }*/
		
		/*fos = new FileOutputStream(new File(filePathDocx));
		doc.write(fos);
		fos.close();*/

		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}

	}
	
	public void createContractHdrDoc(String filePathDocx, String tempPathDocx, List<PLMBoilerShipBomReportData>headerList,
			List<String> parentAsmbyNmLcl,List<SelectItem>  selPartAssmbly) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);

		List<PLMBoilerShipBomReportData> headerListLcl = new ArrayList<PLMBoilerShipBomReportData>();
		for (PLMBoilerShipBomReportData data : headerList) {
			headerListLcl.add(data);
		}

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(tempPathDocx))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3
		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setStyle("Normal"); // 4
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		/*XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.addBreak();
		tmpRun.setColor("000000");
		tmpRun.setText("Header Section");
		tmpRun.setBold(true);
		tmpRun.setUnderline(UnderlinePatterns.SINGLE);
		tmpRun.setFontSize(10);
		tmpRun.addBreak();*/
		
		//create table
	      XWPFTable table = doc.createTable();
	      
	      CTTblWidth width = table.getCTTbl().addNewTblPr().addNewTblW();
	      width.setType(STTblWidth.DXA);
	      width.setW(BigInteger.valueOf(10000));
	      
	      CTTblPr tblpro = table.getCTTbl().getTblPr();
	      CTJc jc = (tblpro.isSetJc() ? tblpro.getJc() : tblpro.addNewJc());
		   jc.setVal(STJc.CENTER);
		    
	      CTTblBorders borders = tblpro.addNewTblBorders();
	      borders.addNewBottom().setVal(STBorder.NONE); 
	      borders.addNewLeft().setVal(STBorder.NONE);
	      borders.addNewRight().setVal(STBorder.NONE);
	      borders.addNewTop().setVal(STBorder.NONE);
	      //also inner borders
	      borders.addNewInsideH().setVal(STBorder.NONE);
	      borders.addNewInsideV().setVal(STBorder.NONE);
	      XWPFTableCell cell = null;
	  
	      //create first row
	      XWPFTableRow tableRowOne = table.getRow(0);
          XWPFParagraph paragraph1 = tableRowOne.getCell(0).addParagraph();
          cell =  tableRowOne.getCell(0);
          XWPFRun boldRun1 = paragraph1.createRun();
          boldRun1.setBold(true);
          setRun(boldRun1 , "Geinspira" , 10, "Customer: ", false);
          XWPFRun unBoldRun1 = paragraph1.createRun();
          setRun(unBoldRun1 , "Geinspira" , 10, headerListLcl.get(0).getCustomer(), false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          XWPFParagraph paragraph11 = tableRowOne.addNewTableCell().addParagraph();
          cell =  tableRowOne.getCell(1);
          XWPFRun boldRun11 = paragraph11.createRun();
          boldRun11.setBold(true);
          setRun(boldRun11 , "Geinspira" , 10, "Contract: ", false);
          XWPFRun unBoldRun11 = paragraph11.createRun();
          setRun(unBoldRun11 , "Geinspira" , 10, headerListLcl.get(0).getCntName(), false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          //create second row
          XWPFTableRow tableRowTwo = table.getRow(0);
          XWPFParagraph paragraph2 = tableRowTwo.getCell(0).addParagraph();
          cell =  tableRowOne.getCell(0);
          XWPFRun boldRun2 = paragraph2.createRun();
          boldRun2.setBold(true);
          setRun(boldRun2 , "Geinspira" , 10, "Station: ", false);
          XWPFRun unBoldRun2 = paragraph2.createRun();
          setRun(unBoldRun2 , "Geinspira" , 10, headerListLcl.get(0).getStation() , false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          XWPFParagraph paragraph22 = tableRowTwo.getCell(1).addParagraph();
          cell =  tableRowOne.getCell(1);
          XWPFRun boldRun22 = paragraph22.createRun();
          boldRun22.setBold(true);
          setRun(boldRun22 , "Geinspira" , 10, "Project: ", false);
          XWPFRun unBoldRun22 = paragraph22.createRun();
          setRun(unBoldRun22 , "Geinspira" , 10, headerListLcl.get(0).getProjectName(), false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          //create third row
          XWPFTableRow tableRowThree = table.getRow(0);
          XWPFParagraph paragraph3 = tableRowThree.getCell(0).addParagraph();
          cell =  tableRowOne.getCell(0);
          XWPFRun boldRun3 = paragraph3.createRun();
          boldRun3.setBold(true);
          setRun(boldRun3 , "Geinspira" , 10, "Unit No: ", false);
          XWPFRun unBoldRun3 = paragraph3.createRun();
          setRun(unBoldRun3 , "Geinspira" , 10, headerListLcl.get(0).getUnitNo() , false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          XWPFParagraph paragraph33 = tableRowThree.getCell(1).addParagraph();
          cell =  tableRowOne.getCell(1);
          XWPFRun boldRun33 = paragraph33.createRun();
          boldRun33.setBold(true);
          setRun(boldRun33 , "Geinspira" , 10, "WBS No: ", false);
          XWPFRun unBoldRun33 = paragraph33.createRun();
          setRun(unBoldRun33 , "Geinspira" , 10, headerListLcl.get(0).getWbsNo(), false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
         
          //create fourth row
          XWPFTableRow tableRowFour = table.getRow(0);
          XWPFParagraph paragraph4 = tableRowFour.getCell(0).addParagraph();
          cell =  tableRowOne.getCell(0);
          XWPFRun boldRun4 = paragraph4.createRun();
          boldRun4.setBold(true);
          setRun(boldRun4 , "Geinspira" , 10, "Station Location: ", false);
          XWPFRun unBoldRun4 = paragraph4.createRun();
          setRun(unBoldRun4 , "Geinspira" , 10, headerListLcl.get(0).getStationLocation(), false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          XWPFParagraph paragraph44 = tableRowFour.getCell(1).addParagraph();
          cell =  tableRowOne.getCell(1);
          XWPFRun boldRun44 = paragraph44.createRun();
          boldRun44.setBold(true);
          setRun(boldRun44 , "Geinspira" , 10,  "WBS (Task) Description: ", false);
          XWPFRun unBoldRun44 = paragraph44.createRun();
          setRun(unBoldRun44 , "Geinspira" , 10, headerListLcl.get(0).getProductDesc(), false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          //create fifth row
          /*XWPFTableRow tableRowFive = table.getRow(0);
          cell =  tableRowOne.getCell(0);
          XWPFParagraph paragraph5 = tableRowFive.getCell(0).addParagraph();
          XWPFRun boldRun5 = paragraph5.createRun();
          boldRun5.setBold(true);          
          setRun(boldRun5 , "Geinspira" , 10, "Station Location: ", false);
          XWPFRun unBoldRun5 = paragraph5.createRun();
          setRun(unBoldRun5 , "Geinspira" , 10, headerListLcl.get(0).getStationLocation() , false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          String parentAsmbyDesc="";
	      for(SelectItem item:selPartAssmbly){
	    	  if(item.getValue().equals(parentAsmbyNmLcl)){
	    		  parentAsmbyDesc =item.getLabel();
	    		  break;
	    	  }
	      }
	      
          XWPFParagraph paragraph55 = tableRowFive.getCell(1).addParagraph();
          cell =  tableRowOne.getCell(1);
          XWPFRun boldRun55 = paragraph55.createRun();
          boldRun55.setBold(true);
          setRun(boldRun55 , "Geinspira" , 10,  "Parent Assy No: ", false);
          XWPFRun unBoldRun55 = paragraph55.createRun();
          setRun(unBoldRun55 , "Geinspira" , 10, parentAsmbyDesc, false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));
          
          XWPFParagraph paragraph55 = tableRowOne.getCell(0).addParagraph();
          cell =  tableRowOne.getCell(0);
          XWPFRun tmpRun55 = paragraph55.createRun();
          setRun(tmpRun55 , "Geinspira" , 10, "" , false);
          cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(5000));*/
          
		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	private static void setRun (XWPFRun run , String fontFamily , int fontSize , String text , boolean addBreak) {
        run.setFontFamily(fontFamily);
        run.setFontSize(fontSize);
        run.setText(text);
        if (addBreak) run.addBreak();
    }
    
	/**
	 * This method is used to createCustomerBomDoc
	 * 
	 * @param FileOutputStream
	 * @param filepathDocx
	 * @param List
	 *            <PLMBoilerShipBomReportData>
	 * @param templatepath
	 */
	public void createCustomerBomDoc(String filePathDocx, String tempPathDocx, List<PLMBoilerShipBomReportData>customerBomDataList
			,boolean showPartRevision, boolean showDocRevision) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);

		List<PLMBoilerShipBomReportData> customerBomDataListLcl = new ArrayList<PLMBoilerShipBomReportData>();
		for (PLMBoilerShipBomReportData data : customerBomDataList) {
			customerBomDataListLcl.add(data);
		}

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(tempPathDocx))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3
		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setStyle("Normal"); // 4
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		/*XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.addBreak();
		tmpRun.setColor("000000");
		tmpRun.setText("Report Output");
		tmpRun.setBold(true);
		tmpRun.setUnderline(UnderlinePatterns.SINGLE);
		tmpRun.setFontSize(10);
		tmpRun.addBreak();*/
		
		int nRows = customerBomDataListLcl.size() + 1;
		int nCols = 9;
		int index = 0;
		
		if (showPartRevision && showDocRevision) {
			nCols = 10;
		} else if (showPartRevision && !showDocRevision) {
			nCols = 9;
		} else if (!showPartRevision && showDocRevision) {
			nCols = 9;
		} else if (!showPartRevision && !showDocRevision) {
			nCols = 8;
		}
		XWPFTable table = doc.createTable(nRows, nCols);
		table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(15000));
		//table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));
		// Set the table style. If the style is not defined, the table style
		// will become "Normal".
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTJc jc = (tblPr.isSetJc() ? tblPr.getJc() : tblPr.addNewJc());
	    jc.setVal(STJc.CENTER);
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("StyledTable");

		// Get a list of the rows in the table
		List<XWPFTableRow> rows = table.getRows();
		int rowCt = 0;
		int colCt = 0;
		for (XWPFTableRow row : rows) {
			// get table row properties (trPr)
			CTTrPr trPr = row.getCtRow().addNewTrPr();
			// set row height; units = twentieth of a point, 360 = 0.25"
			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(13));

			// get the cells in this row
			List<XWPFTableCell> cells = row.getTableCells();
			// add content to each cell
			for (XWPFTableCell cell : cells) {
				// get a table cell properties element (tcPr)
				CTTcPr tcpr = cell.getCTTc().addNewTcPr();
				// set vertical alignment to "center"
				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				// create cell color element
				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {
					// header row
					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {
					// odd row
					ctshd.setFill("EDF2F8");
				}

				// get 1st paragraph in cell's paragraph list
				XWPFParagraph para = cell.getParagraphs().get(0);
				// create a run to contain the content
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");
				// style cell as desired
				/*
				 * if (colCt == nCols - 1) { // last column is 10pt Courier //
				 * rh.setFontSize(10); // rh.setFontFamily("Courier"); }
				 */
				if (rowCt == 0) {
					
					if (showPartRevision && showDocRevision) {
						if (colCt == 0) {
							// header row
							rh.setText("ITEM NO");
						} else if (colCt == 1) {
							rh.setText("PART NO");
						}else if (colCt == 2) {
							rh.setText("REV");
						}else if (colCt == 3) {
							rh.setText("QUANTITY");
						}else if (colCt == 4) {
							rh.setText("U/M");
						}else if (colCt == 5) {
							rh.setText("DESCRIPTION");
						}else if (colCt == 6) {
							rh.setText("DRAWING NO");
						}else if (colCt == 7) {
							rh.setText("DRAWING REV");
						}else if (colCt == 8) {
							rh.setText("WEIGHT");
						}else if (colCt == 9) {
							rh.setText("REMARK");
						}
					} else if (showPartRevision && !showDocRevision) {
						if (colCt == 0) {
							// header row
							rh.setText("ITEM NO");
						} else if (colCt == 1) {
							rh.setText("PART NO");
						}else if (colCt == 2) {
							rh.setText("REV");
						}else if (colCt == 3) {
							rh.setText("QUANTITY");
						}else if (colCt == 4) {
							rh.setText("U/M");
						}else if (colCt == 5) {
							rh.setText("DESCRIPTION");
						}else if (colCt == 6) {
							rh.setText("DRAWING NO");
						}else if (colCt == 7) {
							rh.setText("WEIGHT");
						}else if (colCt == 8) {
							rh.setText("REMARK");
						}
					} else if (!showPartRevision && showDocRevision) {
						if (colCt == 0) {
							// header row
							rh.setText("ITEM NO");
						} else if (colCt == 1) {
							rh.setText("PART NO");
						}else if (colCt == 2) {
							rh.setText("QUANTITY");
						}else if (colCt == 3) {
							rh.setText("U/M");
						}else if (colCt == 4) {
							rh.setText("DESCRIPTION");
						}else if (colCt == 5) {
							rh.setText("DRAWING NO");
						}else if (colCt == 6) {
							rh.setText("DRAWING REV");
						}else if (colCt == 7) {
							rh.setText("WEIGHT");
						}else if (colCt == 8) {
							rh.setText("REMARK");
						}
					} else if (!showPartRevision && !showDocRevision) {
						if (colCt == 0) {
							// header row
							rh.setText("ITEM NO");
						} else if (colCt == 1) {
							rh.setText("PART NO");
						}else if (colCt == 2) {
							rh.setText("QUANTITY");
						}else if (colCt == 3) {
							rh.setText("U/M");
						}else if (colCt == 4) {
							rh.setText("DESCRIPTION");
						}else if (colCt == 5) {
							rh.setText("DRAWING NO");
						}else if (colCt == 6) {
							rh.setText("WEIGHT");
						}else if (colCt == 7) {
							rh.setText("REMARK");
						}
					}
					rh.setBold(true);
					ht.setVal(BigInteger.valueOf(600));
					row.setHeight(600);
					para.setAlignment(ParagraphAlignment.CENTER);
				} else if (rowCt % 2 == 0) {

					index = rowCt;
					index = index - 1;
					
					if (showPartRevision && showDocRevision) {
						if (colCt == 0) {
							if(!PLMUtils.isEmpty(customerBomDataListLcl.get(index).getItemNumber())){
							rh.setText(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",customerBomDataListLcl.get(index).getLevel())+customerBomDataListLcl.get(index).getItemNumber());
							}else{
								rh.setText("");
							}
						}else if (colCt == 1) {
							rh.setText(customerBomDataListLcl.get(index).getPartNumber());
						}else if (colCt == 2) {
							rh.setText(customerBomDataListLcl.get(index).getPartRev());
						}else if (colCt == 3) {
							rh.setText(customerBomDataListLcl.get(index).getQuantity());
						}else if (colCt == 4) {
							rh.setText(customerBomDataListLcl.get(index).getUnitOfMeasure());
						}else if (colCt == 5) {
							rh.setText(customerBomDataListLcl.get(index).getDescription());
						}else if (colCt == 6) {
							rh.setText(customerBomDataListLcl.get(index).getDrawingNumber());
						}else if (colCt == 7) {
							rh.setText(customerBomDataListLcl.get(index).getDrawingRev());
						}else if (colCt == 8) {
							rh.setText(customerBomDataListLcl.get(index).getWeight());
						}else if (colCt == 9) {
							rh.setText(customerBomDataListLcl.get(index).getRemarks());
						}
					} else if (showPartRevision && !showDocRevision) {
						if (colCt == 0) {
							if(!PLMUtils.isEmpty(customerBomDataListLcl.get(index).getItemNumber())){
							rh.setText(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",customerBomDataListLcl.get(index).getLevel())+customerBomDataListLcl.get(index).getItemNumber());
							}else{
								rh.setText("");
							}
						}else if (colCt == 1) {
							rh.setText(customerBomDataListLcl.get(index).getPartNumber());
						}else if (colCt == 2) {
							rh.setText(customerBomDataListLcl.get(index).getPartRev());
						}else if (colCt == 3) {
							rh.setText(customerBomDataListLcl.get(index).getQuantity());
						}else if (colCt == 4) {
							rh.setText(customerBomDataListLcl.get(index).getUnitOfMeasure());
						}else if (colCt == 5) {
							rh.setText(customerBomDataListLcl.get(index).getDescription());
						}else if (colCt == 6) {
							rh.setText(customerBomDataListLcl.get(index).getDrawingNumber());
						}else if (colCt == 7) {
							rh.setText(customerBomDataListLcl.get(index).getWeight());
						}else if (colCt == 8) {
							rh.setText(customerBomDataListLcl.get(index).getRemarks());
						}
					} else if (!showPartRevision && showDocRevision) {
						if (colCt == 0) {
							if(!PLMUtils.isEmpty(customerBomDataListLcl.get(index).getItemNumber())){
							rh.setText(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",customerBomDataListLcl.get(index).getLevel())+customerBomDataListLcl.get(index).getItemNumber());
							}else{
								rh.setText("");
							}
						}else if (colCt == 1) {
							rh.setText(customerBomDataListLcl.get(index).getPartNumber());
						}else if (colCt == 2) {
							rh.setText(customerBomDataListLcl.get(index).getQuantity());
						}else if (colCt == 3) {
							rh.setText(customerBomDataListLcl.get(index).getUnitOfMeasure());
						}else if (colCt == 4) {
							rh.setText(customerBomDataListLcl.get(index).getDescription());
						}else if (colCt == 5) {
							rh.setText(customerBomDataListLcl.get(index).getDrawingNumber());
						}else if (colCt == 6) {
							rh.setText(customerBomDataListLcl.get(index).getDrawingRev());
						}else if (colCt == 7) {
							rh.setText(customerBomDataListLcl.get(index).getWeight());
						}else if (colCt == 8) {
							rh.setText(customerBomDataListLcl.get(index).getRemarks());
						}
					} else if (!showPartRevision && !showDocRevision) {
						if (colCt == 0) {
							if(!PLMUtils.isEmpty(customerBomDataListLcl.get(index).getItemNumber())){
							rh.setText(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",customerBomDataListLcl.get(index).getLevel())+customerBomDataListLcl.get(index).getItemNumber());
							}else{
								rh.setText("");
							}
						}else if (colCt == 1) {
							rh.setText(customerBomDataListLcl.get(index).getPartNumber());
						}else if (colCt == 2) {
							rh.setText(customerBomDataListLcl.get(index).getQuantity());
						}else if (colCt == 3) {
							rh.setText(customerBomDataListLcl.get(index).getUnitOfMeasure());
						}else if (colCt == 4) {
							rh.setText(customerBomDataListLcl.get(index).getDescription());
						}else if (colCt == 5) {
							rh.setText(customerBomDataListLcl.get(index).getDrawingNumber());
						}else if (colCt == 6) {
							rh.setText(customerBomDataListLcl.get(index).getWeight());
						}else if (colCt == 7) {
							rh.setText(customerBomDataListLcl.get(index).getRemarks());
						}
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > customerBomDataListLcl.size()) {
					break;
				} else {

					index = rowCt;
					index = index - 1;
					
					if (showPartRevision && showDocRevision) {
						if (colCt == 0) {
							if(!PLMUtils.isEmpty(customerBomDataListLcl.get(index).getItemNumber())){
							rh.setText(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",customerBomDataListLcl.get(index).getLevel())+customerBomDataListLcl.get(index).getItemNumber());
							}else{
								rh.setText("");
							}
						}else if (colCt == 1) {
							rh.setText(customerBomDataListLcl.get(index).getPartNumber());
						}else if (colCt == 2) {
							rh.setText(customerBomDataListLcl.get(index).getPartRev());
						}else if (colCt == 3) {
							rh.setText(customerBomDataListLcl.get(index).getQuantity());
						}else if (colCt == 4) {
							rh.setText(customerBomDataListLcl.get(index).getUnitOfMeasure());
						}else if (colCt == 5) {
							rh.setText(customerBomDataListLcl.get(index).getDescription());
						}else if (colCt == 6) {
							rh.setText(customerBomDataListLcl.get(index).getDrawingNumber());
						}else if (colCt == 7) {
							rh.setText(customerBomDataListLcl.get(index).getDrawingRev());
						}else if (colCt == 8) {
							rh.setText(customerBomDataListLcl.get(index).getWeight());
						}else if (colCt == 9) {
							rh.setText(customerBomDataListLcl.get(index).getRemarks());
						}
					} else if (showPartRevision && !showDocRevision) {
						if (colCt == 0) {
							if(!PLMUtils.isEmpty(customerBomDataListLcl.get(index).getItemNumber())){
							rh.setText(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",customerBomDataListLcl.get(index).getLevel())+customerBomDataListLcl.get(index).getItemNumber());
							}else{
								rh.setText("");
							}
						}else if (colCt == 1) {
							rh.setText(customerBomDataListLcl.get(index).getPartNumber());
						}else if (colCt == 2) {
							rh.setText(customerBomDataListLcl.get(index).getPartRev());
						}else if (colCt == 3) {
							rh.setText(customerBomDataListLcl.get(index).getQuantity());
						}else if (colCt == 4) {
							rh.setText(customerBomDataListLcl.get(index).getUnitOfMeasure());
						}else if (colCt == 5) {
							rh.setText(customerBomDataListLcl.get(index).getDescription());
						}else if (colCt == 6) {
							rh.setText(customerBomDataListLcl.get(index).getDrawingNumber());
						}else if (colCt == 7) {
							rh.setText(customerBomDataListLcl.get(index).getWeight());
						}else if (colCt == 8) {
							rh.setText(customerBomDataListLcl.get(index).getRemarks());
						}
					} else if (!showPartRevision && showDocRevision) {
						if (colCt == 0) {
							if(!PLMUtils.isEmpty(customerBomDataListLcl.get(index).getItemNumber())){
							rh.setText(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",customerBomDataListLcl.get(index).getLevel())+customerBomDataListLcl.get(index).getItemNumber());
							}else{
								rh.setText("");
							}
						}else if (colCt == 1) {
							rh.setText(customerBomDataListLcl.get(index).getPartNumber());
						}else if (colCt == 2) {
							rh.setText(customerBomDataListLcl.get(index).getQuantity());
						}else if (colCt == 3) {
							rh.setText(customerBomDataListLcl.get(index).getUnitOfMeasure());
						}else if (colCt == 4) {
							rh.setText(customerBomDataListLcl.get(index).getDescription());
						}else if (colCt == 5) {
							rh.setText(customerBomDataListLcl.get(index).getDrawingNumber());
						}else if (colCt == 6) {
							rh.setText(customerBomDataListLcl.get(index).getDrawingRev());
						}else if (colCt == 7) {
							rh.setText(customerBomDataListLcl.get(index).getWeight());
						}else if (colCt == 8) {
							rh.setText(customerBomDataListLcl.get(index).getRemarks());
						}
					} else if (!showPartRevision && !showDocRevision) {
						if (colCt == 0) {
							if(!PLMUtils.isEmpty(customerBomDataListLcl.get(index).getItemNumber())){
							rh.setText(PLMUtils.repeatStr(PLMConstants.LTTR_BOM_INDENTATION,"",customerBomDataListLcl.get(index).getLevel())+customerBomDataListLcl.get(index).getItemNumber());
							}else{
								rh.setText("");
							}
						}else if (colCt == 1) {
							rh.setText(customerBomDataListLcl.get(index).getPartNumber());
						}else if (colCt == 2) {
							rh.setText(customerBomDataListLcl.get(index).getQuantity());
						}else if (colCt == 3) {
							rh.setText(customerBomDataListLcl.get(index).getUnitOfMeasure());
						}else if (colCt == 4) {
							rh.setText(customerBomDataListLcl.get(index).getDescription());
						}else if (colCt == 5) {
							rh.setText(customerBomDataListLcl.get(index).getDrawingNumber());
						}else if (colCt == 6) {
							rh.setText(customerBomDataListLcl.get(index).getWeight());
						}else if (colCt == 7) {
							rh.setText(customerBomDataListLcl.get(index).getRemarks());
						}
					}
					
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell

			colCt = 0;
			rowCt++;
		} // for row

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}
	/**
	 * This method is used for Deleting docx file
	 * 
	 * @param String
	 */
	public void deleteFiles(String docx) {
		LOG.info("Entering deleteFiles method");
		boolean docxFileExist;
		File docxFile = new File(docx);
		docxFileExist = docxFile.exists();
		if (docxFileExist) {
			boolean deleted = docxFile.delete();
			LOG.info("Successfully deleted docx file : " + deleted);
		}
		LOG.info("Exiting deleteFiles Method");
	}

	/**
	 * @return
	 */
	public boolean isAllAssyNo() {
		return allAssyNo;
	}

	/**
	 * @param allAssyNo
	 */
	public void setAllAssyNo(boolean allAssyNo) {
		this.allAssyNo = allAssyNo;
	}

	/**
	 * @return
	 */
	public boolean isShowPartRev() {
		return showPartRev;
	}

	/**
	 * @param showPartRev
	 */
	public void setShowPartRev(boolean showPartRev) {
		this.showPartRev = showPartRev;
	}
	/**
	 * @return
	 */
	public boolean isShowDocRev() {
		return showDocRev;
	}

	/**
	 * @param showDocRev
	 */
	public void setShowDocRev(boolean showDocRev) {
		this.showDocRev = showDocRev;
	}
	
}
