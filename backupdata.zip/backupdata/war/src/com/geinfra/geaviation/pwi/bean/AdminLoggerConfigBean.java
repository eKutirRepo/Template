package com.geinfra.geaviation.pwi.bean;

import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.common.bean.BaseBean;

/**
 * 
 * Project : Product Lifecycle Management Date Written : May 19, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Backing bean for admin page to change logging configuration at
 * runtime.
 * 
 * Revision Log May 19, 2010 | v1.0.
 * --------------------------------------------------------------
 */

public class AdminLoggerConfigBean extends BaseBean {
	private static final Logger LOGGER = Logger
			.getLogger(AdminLoggerConfigBean.class);

	private static final List<SelectItem> LOG_LEVELS = new ArrayList<SelectItem>();
	static {
		SelectItem debugItem = new SelectItem(Level.DEBUG.toString());
		LOG_LEVELS.add(debugItem);

		SelectItem infoItem = new SelectItem(Level.INFO.toString());
		LOG_LEVELS.add(infoItem);

		SelectItem warningItem = new SelectItem(Level.WARN.toString());
		LOG_LEVELS.add(warningItem);

		SelectItem errorItem = new SelectItem(Level.ERROR.toString());
		LOG_LEVELS.add(errorItem);

		SelectItem fatalItem = new SelectItem(Level.FATAL.toString());
		LOG_LEVELS.add(fatalItem);
	}

	private String logLevel = Logger.getRootLogger().getLevel().toString();

	public List<SelectItem> getLogLevels() {
		return LOG_LEVELS;
	}

	public String getLogLevel() {
		return logLevel;
	}

	public void setLogLevel(String logLevel) {
		this.logLevel = logLevel;
	}

	public void actionChangeLogLevel() {
		Logger root = Logger.getRootLogger();
		if (Level.DEBUG.toString().equals(logLevel)) {
			root.setLevel(Level.DEBUG);
			String message = "Log level changed to debug.";
			LOGGER.info(message);
			handleFacesInfo(message);
			LOGGER.debug("See?");
		} else if (Level.INFO.toString().equals(logLevel)) {
			root.setLevel(Level.INFO);
			String message = "Log level changed to info.";
			LOGGER.info(message);
			handleFacesInfo(message);
		} else if (Level.WARN.toString().equals(logLevel)) {
			root.setLevel(Level.WARN);
			String message = "Log level changed to warn.";
			LOGGER.info(message);
			handleFacesInfo(message);
		} else if (Level.ERROR.toString().equals(logLevel)) {
			root.setLevel(Level.ERROR);
			String message = "Log level changed to error.";
			LOGGER.info(message);
			handleFacesInfo(message);
		} else if (Level.FATAL.toString().equals(logLevel)) {
			root.setLevel(Level.FATAL);
			String message = "Log level changed to fatal.";
			LOGGER.info(message);
			handleFacesInfo(message);
		} else {
			String message = "Failed to change log level.  Log level \""
					+ logLevel + "\" not recognized.";
			LOGGER.warn(message);
			handleFacesError(message);
		}
	}
}
