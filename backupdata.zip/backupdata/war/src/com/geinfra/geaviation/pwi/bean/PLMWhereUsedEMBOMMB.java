/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhereUsedEMBOMMB.java
 * @Creation date: 23-July-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.common.usermodel.Hyperlink;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFCreationHelper;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFHyperlink;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.data.PLMWhereUsedData;
import com.geinfra.geaviation.pwi.service.PLMWhereUsedServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMWhereUsedEMBOMMB {
	
	/**
	 * Holds the User info
	 */
	private PLMPwiUserData userDetails = null;
	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMWhereUsedEMBOMMB.class);
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor =null;
	/**
	 * Holds the plmWhereUsedData
	 */
	PLMWhereUsedData plmWhereUsedData = new PLMWhereUsedData();
	/**
	 * Holds the plmWhereUsedService
	 */
	private PLMWhereUsedServiceIfc plmWhereUsedService = null;
	/**
	 * Holds the whereUsedEMBOMSearchList
	 */
	private List<PLMWhereUsedData> whereUsedEMBOMSearchList;
	/**
	 * Holds the whereUsedEMBOMSearchPartDwgList
	 */
	private List<SelectItem> whereUsedEMBOMSearchPartDwgList;
	/**
	 * Holds the whereUsedEMBOMPartList
	 */
	private Map<String, List<SelectItem>> whereUsedEMBOMPartList;
	/**
	 * Holds the whereUsedEMBOMDwgList
	 */
	private Map<String, List<SelectItem>> whereUsedEMBOMDwgList;
	/**
	 * Holds the partListSize
	 */
	private int partListSize;
	/**
	 * Holds the dwgListSize
	 */
	private int dwgListSize;
	/**
	 * Holds the partDwgListSize
	 */
	private int partDwgListSize;
	/**
	 * Holds the partList
	 */
	private List<SelectItem> partList;
	/**
	 * Holds the dwgList
	 */
	private List<SelectItem> dwgList;
	/**
	 * Holds the partDwgList
	 */
	private List<SelectItem> partDwgList = new ArrayList<SelectItem>();
	/**
	 * Holds the recordCount
	 */
	private int recordCount = PLMConstants.N_100;
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the totalRecCountMsg
	 */
	private String totalRecCountMsg;
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the ajaxExceptionMessage
	 */
	private String ajaxExceptionMessage;
	/**
	 * Holds the partValue
	 */
	private String partValue;
	/**
	 * Holds the dwgValue
	 */
	private String dwgValue;
	/**
	 * Holds the embomFlag
	 */
	private boolean embomFlag = false;
	/**
	 * Holds the resourceBundle
	 */
	ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the whereUsedEMBOMPartdwgList
	 */
	
	private List<PLMWhereUsedData> whereUsedEMBOMPartdwgList;
	/**
	 * Holds the noRecordFlag
	 */
	private boolean noRecordFlag;
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB=null;
	
	/*private PLMLoginData userDataObj = (PLMLoginData) PLMUtils
	.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA);*/
	
	
	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendReportThroughMail();
		}
	}
	
	/**
	 * Load The Where Used Search Page
	 * @return String
	 */
	public String loadWhereUsedPage() {
		String fwdFlag = "";
		plmWhereUsedData = new PLMWhereUsedData();
		alertMessage = "";
		// Code for selecting default Radio Button Selection
		plmWhereUsedData.setStatusIndr("Y");
		fwdFlag = "whereUsedEMBOMSearch";
		try {
			commonMB.insertCannedRptRecordHitInfo("Where Used E+MBOM");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
    	try {
			commonMB.getLegacyDateStamp();			
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getLegacyDateStamp: ", exception);
			} 
		return fwdFlag;
	}
	
	/**
	 * This method is used for validateWhereUsedEMBOM
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String validateWhereUsedEMBOM() throws PLMCommonException {
		LOG.info("Inside validateWhereUsedEMBOM method");
		Date effectivityDateFrom = plmWhereUsedData.getEffectivityDateFrom();
		Date effectivityDateTo = plmWhereUsedData.getEffectivityDateTo();
		alertMessage = "";
		//try {
			if (PLMUtils.isEmpty(plmWhereUsedData.getUnitSerialNumber())
					&& PLMUtils.isEmpty(plmWhereUsedData.getMliCode())
					&& PLMUtils.isEmpty(plmWhereUsedData.getPartDwg())
					&& PLMUtils.isEmpty(plmWhereUsedData.getPartDwgDescription())	
					&& (plmWhereUsedData.isPart() == false)
					&& (plmWhereUsedData.isDwg() == false)
					&& PLMUtils.isEmptyDate(plmWhereUsedData.getEffectivityDateFrom())
					&& PLMUtils.isEmptyDate(plmWhereUsedData.getEffectivityDateTo())) {
				if(!embomFlag){
					alertMessage = PLMConstants.EMBOM_ANY_SRCH_CRIT;
				}else{
					alertMessage = PLMConstants.EMBOM_EMAIL_ANY_SRCH_CRIT;
				}
			} else if ((!PLMUtils.isEmpty(plmWhereUsedData.getMliCode())) 
					&& ((PLMUtils.isEmpty(plmWhereUsedData.getPartDwg())) 
					&& (PLMUtils.isEmpty(plmWhereUsedData.getPartDwgDescription())))) {
				
					alertMessage = alertMessage + PLMConstants.Embom_Validation_Msg;
			}
			else if((!PLMUtils.isEmpty(plmWhereUsedData.getMliCode())) 
						&& (!PLMUtils.isEmpty(plmWhereUsedData.getPartDwgDescription()))
						&& (PLMUtils.isEmpty(plmWhereUsedData.getPartDwg()))){
						if( (!(plmWhereUsedData.isPart())) && (!(plmWhereUsedData.isDwg())))
						{ 
						   alertMessage = alertMessage + PLMConstants.Embom_PartDWG_Number_Msg;
						}else if((plmWhereUsedData.isPart()) || (plmWhereUsedData.isDwg())){
							alertMessage = alertMessage + PLMConstants.Embom_PartDWG_Validation_Msg;
						}
			}
			else {
				if (!PLMUtils.checkForSpecialChars(plmWhereUsedData.getUnitSerialNumber())) {
					alertMessage = alertMessage + PLMConstants.Embom_UnitSerialNumber_ValMsg;
				} 
				if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmWhereUsedData.getMliCode())) {
					alertMessage = alertMessage + PLMConstants.Embom_MLI_ValMsg;
				} 				
				if (!PLMUtils.checkForSpecialChars(plmWhereUsedData.getPartDwg())) {
					alertMessage = alertMessage + PLMConstants.Embom_PartDwg_ValMsg;
				} 
				if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmWhereUsedData.getPartDwgDescription())) {
					alertMessage = alertMessage + PLMConstants.Embom_PartDwgDesc_ValMsg;
				} 
				
				if (PLMUtils.checkForNullOfTwoDates(effectivityDateFrom, effectivityDateTo)) {
					alertMessage = alertMessage + PLMConstants.Dates_NullCheck_Msg;
				} else if (PLMUtils.checkForFromAndToDate(effectivityDateFrom, effectivityDateTo)) {
					alertMessage = alertMessage + PLMConstants.Date_ValMsg;
				}			
			}
		/*} catch (Exception e) {
			LOG.info("Error :" + e.getMessage());
		}*/	
		return alertMessage;
	}
	
	/**
	 * Generates the Where Used Search List
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String generateWhereUsedEMBOMDataFile() {
		LOG.info("Inside generateWhereUsedEMBOMDataFile method");
		String fwdFlag = "";
		embomFlag = false;
		try {
			String alertMsg = validateWhereUsedEMBOM();
			if (PLMUtils.isEmpty(alertMsg)) {
				
					whereUsedEMBOMSearchList = plmWhereUsedService.getWhereUsedEMBOMData(plmWhereUsedData);
					if (whereUsedEMBOMSearchList != null) {
						totalRecCount = whereUsedEMBOMSearchList.size();
					} else {
						totalRecCount = 0;
					}
					totalRecCountMsg = "Total Results Count : " + totalRecCount;
					LOG.info("totalRecCount :" + totalRecCount);
					if (totalRecCount == 0) {
						fwdFlag = "invalidembom";
					} else {
						recordCount = PLMConstants.N_100;
						fwdFlag = "whereUsedEMBOMReport";
						LOG.info("fwdFlag :" + fwdFlag);
					}
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@generateWhereUsedEMBOMDataFile: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"whereUsedEMBOMSearch","Where Used E+MBOM");
		} 
		
		return fwdFlag;
	}	

	/**
	 * This method is used to download excel for Where used EMBOM on screen report
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadEMBOMScreenExcel() throws PLMCommonException {
		LOG.info("Entering downloadEMBOMScreenExcel Method");
		String reportName = "whereUsedEMBOMReport";
		String fileName = "whereUsedEMBOMReport";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		//Export to Excel for Where used EMBOMS Report
		
		PLMXlsxRptColumn[] critcolumns  = new PLMXlsxRptColumn[] {
                new PLMXlsxRptColumn("unitSerialNumber", "Unit Serial Number", FormatType.TEXT),
                new PLMXlsxRptColumn("partDwg", "Part/DWG", FormatType.TEXT),
                new PLMXlsxRptColumn("mliCode", "EID", FormatType.TEXT),
                new PLMXlsxRptColumn("partDwgDescription", "Part Description", FormatType.TEXT),
                new PLMXlsxRptColumn("effectivityDateFrom", "Effectivity Date From", FormatType.DATE),
                new PLMXlsxRptColumn("effectivityDateTo", "Effectivity Date To", FormatType.DATE)
                };
		
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					 new PLMXlsxRptColumn("mliCode", "EID", FormatType.TEXT,null,null,21),
					 new PLMXlsxRptColumn("partDwg", "Part /Dwg", FormatType.LINK, null, null, 20, "partId"),
					 new PLMXlsxRptColumn("partDwgDescription", "Part / Dwg Description", FormatType.TEXT,null,null,21),
					 new PLMXlsxRptColumn("qtyLocation", "Qty", FormatType.TEXT),
					 new PLMXlsxRptColumn("uom", "UOM", FormatType.TEXT,null,null,20),
					 new PLMXlsxRptColumn("plmObjectTypevalue", "PLM Object Type", FormatType.TEXT,null,null,17),
					 new PLMXlsxRptColumn("nextUpperLevel", "Next Upper Level", FormatType.TEXT,null,null,17),
					 new PLMXlsxRptColumn("nextUpperLevelDesc", "Next Upper Level Description", FormatType.TEXT,null,null,30),
					 new PLMXlsxRptColumn("plmObjectStatus", "PLM Object Status", FormatType.TEXT,null,null,17),
					 new PLMXlsxRptColumn("originOfRecord", "Origin of Record", FormatType.TEXT),
					 new PLMXlsxRptColumn("loadDate", "Date", FormatType.DATE),
					 new PLMXlsxRptColumn("unitSerialNumber", "Unit Serial Number", FormatType.TEXT,null,null,20)
			};
			excelUtil.export(whereUsedEMBOMSearchList, reportColumns, fileName, fileName, true, critcolumns, plmWhereUsedData);	
			LOG.info("Exiting downloadEMBOMScreenExcel Method");
	}
	
	/**
	 * This method is used for Generating Where used EMBOM on screen report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	
	public void createDownloadEMBOMCSV() throws PLMCommonException {
		LOG.info("Entering createDownloadEMBOMCSV Method");
		String reportName = "whereUsedEMBOMReport";
		String fileName = "whereUsedEMBOMReport";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		//Export to CSV for Where used EMBOMS Report
		
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					 new PLMCsvRptColumn("mliCode", "EID", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("partDwg", "Part /Dwg", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("partDwgDescription", "Part / Dwg Description", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("qtyLocation", "Qty", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("uom", "UOM", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("plmObjectTypevalue", "PLM Object Type", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("nextUpperLevel", "Next Upper Level", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("nextUpperLevelDesc", "Next Upper Level Description", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("plmObjectStatus", "PLM Object Status", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("originOfRecord", "Origin of Record", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("loadDate", "Date", FormatTypeCsv.DATE),
					 new PLMCsvRptColumn("unitSerialNumber", "Unit Serial Number", FormatTypeCsv.TEXT)
					
			};
			csvUtil.exportCsv(whereUsedEMBOMSearchList, reportColumns, fileName, dateFormat, false, null, null, ",");
			
			LOG.info("Exiting createDownloadEMBOMCSV Method");
	}
	
	/**
	 * This method is used to download excel for Where Used BOM Prefix/LI Report
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	
	public void downloadBOMPrefixScreenExcel() throws PLMCommonException {

		LOG.info("Entering downloadBOMPrefixScreenExcel Method");
		String reportName = "whereUsedBMLLEbomReport";
		String fileName = "whereUsedBMLLEbomReport";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		//Export to Excel for Where used EMBOMS BMLL Report
		
		PLMXlsxRptColumn[] critcolumns  = new PLMXlsxRptColumn[] {
                new PLMXlsxRptColumn("unitAssembleNumber", "Unit / Assembly", FormatType.TEXT),
                new PLMXlsxRptColumn("partDwg", "Part/DWG", FormatType.TEXT),
                new PLMXlsxRptColumn("mliCode", "MLI", FormatType.TEXT),
                new PLMXlsxRptColumn("partDwgDescription", "Part Description", FormatType.TEXT),
                new PLMXlsxRptColumn("effectivityDateFrom", "Effectivity Date From", FormatType.DATE),
                new PLMXlsxRptColumn("effectivityDateTo", "Effectivity Date To", FormatType.DATE)
                };
		
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					 new PLMXlsxRptColumn("mliCode", "CPREF", FormatType.TEXT,null,null,21),
					 new PLMXlsxRptColumn("pin", "PPREF", FormatType.TEXT),
					 new PLMXlsxRptColumn("unitAssembleNumber", "Top Level Parent", FormatType.TEXT,null,null,20),
					 new PLMXlsxRptColumn("parentItem", "Parent Item", FormatType.LINK, null, null, 20, "parentItemId"),
					 new PLMXlsxRptColumn("childItem", "Child Item", FormatType.LINK, null, null, 20, "childItemId"),
					 new PLMXlsxRptColumn("description", "Description", FormatType.TEXT,null,null,25),
					//Added by Hemanth K E+MBOM Enhancement
					 new PLMXlsxRptColumn("quantity", "Quantity", FormatType.TEXT),
					 new PLMXlsxRptColumn("uom", "UOM", FormatType.TEXT),
					 //End
					 new PLMXlsxRptColumn("authecn", "Eng. Change Authorization", FormatType.TEXT,null,null,25),
					 new PLMXlsxRptColumn("itemEffectivityStartDate", "Eff.Start Date", FormatType.DATE),
					 new PLMXlsxRptColumn("itemEffectivityEndDate", "Eff.End Date", FormatType.DATE),
					 new PLMXlsxRptColumn("source", "Source", FormatType.TEXT)
					 
			};
			excelUtil.export(whereUsedBMLLEMBOMSearchList, reportColumns, fileName, fileName, true, critcolumns, plmWhereUsedData);	
			LOG.info("Exiting downloadBOMPrefixScreenExcel Method");
	}
	
	/**
	 * This method is used for Generating Where Used BOM Prefix/LI Report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	
	public void createDownloadBOMPrefixCSV() throws PLMCommonException {

		LOG.info("Entering createDownloadBOMPrefixCSV Method");
		String reportName = "whereUsedBMLLEbomReport";
		String fileName = "whereUsedBMLLEbomReport";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		//Export to CSV for Where used EMBOMS BMLL Report
		
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					 new PLMCsvRptColumn("mliCode", "CPREF", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("pin", "PPREF", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("unitAssembleNumber", "Top Level Parent", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("parentItem", "Parent Item", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("childItem", "Child Item", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("description", "Description", FormatTypeCsv.TEXT),
					 //Added by Hemanth K Enhancement
					 new PLMCsvRptColumn("quantity", "Quantity", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("uom", "UOM", FormatTypeCsv.TEXT),
					 //End
					 new PLMCsvRptColumn("authecn", "Eng. Change Authorization", FormatTypeCsv.TEXT),
					 new PLMCsvRptColumn("itemEffectivityStartDate", "Eff.Start Date", FormatTypeCsv.DATE),
					 new PLMCsvRptColumn("itemEffectivityEndDate", "Eff.End Date", FormatTypeCsv.DATE),
					 new PLMCsvRptColumn("source", "Source", FormatTypeCsv.TEXT)
					 
			};
			csvUtil.exportCsv(whereUsedBMLLEMBOMSearchList, reportColumns, fileName, dateFormat, false, null, null, ",");
			
			LOG.info("Exiting createDownloadBOMPrefixCSV Method");
	}
	
	/**
	 * Generates generateWhereUsedEMBOMMail
	 * 
	 * @return String
	 * @throws PWiException 
	 * @throws PLMCommonException
	 */
	public String generateWhereUsedEMBOMMail() throws PWiException{
		String fwdFlag = "whereUsedEMBOMSearch";
		embomFlag = true;
		try {
			String alertMsg = validateWhereUsedEMBOM();
			
			// Get user details for sending mail. Need before taskexecuter as context will be null while excuting the thread
			 userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
			
			if (PLMUtils.isEmpty(alertMsg)) {
				alertMessage = alertMessage + PLMConstants.Embom_Mail_Msg;
				taskExecutor.execute(new MailThread());
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@generateWhereUsedEMBOMDataFile: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"whereUsedEMBOMSearch","Where Used E+MBOM");
		} 
		return fwdFlag;
	}

	/**
	 * This method is used for sendReportThroughMail
	 * 
	 */
	public void sendReportThroughMail() {
		PLMWhereUsedData plmThreadWhereUsedData = new PLMWhereUsedData();
		plmThreadWhereUsedData.setUnitSerialNumber(plmWhereUsedData.getUnitSerialNumber());
		plmThreadWhereUsedData.setMliCode(plmWhereUsedData.getMliCode());
		plmThreadWhereUsedData.setPartDwg(plmWhereUsedData.getPartDwg());
		plmThreadWhereUsedData.setPartDwgDescription(plmWhereUsedData.getPartDwgDescription());
		plmThreadWhereUsedData.setPart(plmWhereUsedData.isPart());
		plmThreadWhereUsedData.setDwg(plmWhereUsedData.isDwg());
		plmThreadWhereUsedData.setEffectivityDateFrom(plmWhereUsedData.getEffectivityDateFrom());
		plmThreadWhereUsedData.setEffectivityDateTo(plmWhereUsedData.getEffectivityDateTo());
		String successMsg = "";
		String from = PLMConstants.WHERE_USED_MAIL_FROM;

		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String signature = PLMConstants.WHERE_USED_LOU_MAIL_SIGNATURE;
		String errorSubject = PLMConstants.WHERE_USED_EBOM_MAIL_SUBJECT;
		try {
			List<PLMWhereUsedData> whereUsedEMBOMSearchMailList = plmWhereUsedService.getWhereUsedEMBOMData(plmWhereUsedData);
			StringBuffer searchCriteriaMsg = saveWhereUsedXLSFile(plmThreadWhereUsedData,whereUsedEMBOMSearchMailList);
			String subject = PLMConstants.WHERE_USED_EBOM_MAIL_SUBJECT;
			String message = toAddressee + PLMConstants.WHERE_USED_EBOM_MAIL_CONTENT + searchCriteriaMsg.toString() + PLMConstants.WHERE_USED_EBOM_MAIL_SIGNATURE;
			String filePathXLS = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("WHERUSED_EMBOM_REPORT_NAME")+".xls";
			LOG.info(searchCriteriaMsg.toString());
			PLMUtils.sendMailWithAttachment(from, to, subject, message, filePathXLS);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendLOUReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,errorSubject,toAddressee,signature);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendLOUReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,errorSubject,toAddressee,signature);
		}   
		if(PLMUtils.isEmpty(successMsg)){
			LOG.info("Mail sent successfully.");
		}
	}
	/**
	 * This method is used for setBorderStyle
	 * 
	 * @param style
	 * @return HSSFCellStyle
	 */
	private HSSFCellStyle setBorderStyle(HSSFCellStyle style) {
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		return style;
	}
	/**
	 * This method is used for saveWhereUsedXLSFile
	 * 
	 * @param plmThreadWhereUsedData,whereUsedEMBOMSearchPList
	 * @return StringBuffer
	 * @throws Exception
	 */
	public StringBuffer saveWhereUsedXLSFile(PLMWhereUsedData plmThreadWhereUsedData,List<PLMWhereUsedData> whereUsedEMBOMSearchPList) throws Exception {
		String filePath = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("WHERUSED_EMBOM_REPORT_NAME")+".xls";
//		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		StringBuffer searchCriteriaMsg = new StringBuffer();
		searchCriteriaMsg.append(PLMConstants.WHERE_USED_EBOM_MAIL_SEARCH_CRITERIA);
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePath);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePath);
				HSSFWorkbook workbook = new HSSFWorkbook();
				HSSFSheet sheet =  workbook.createSheet("Where Used E+MBOM Report");
				HSSFCellStyle headerStyle = workbook.createCellStyle();
				// cell hyper link
				HSSFCreationHelper helper= (HSSFCreationHelper) workbook.getCreationHelper();
				 HSSFFont underLinedFont = (HSSFFont) workbook.createFont();
			        underLinedFont.setUnderline(HSSFFont.U_SINGLE);
			        underLinedFont.setColor(IndexedColors.BLUE.getIndex());
					HSSFCellStyle hyperLinkStyle = (HSSFCellStyle) workbook.createCellStyle();				
					hyperLinkStyle = setBorderStyle(hyperLinkStyle);
					hyperLinkStyle.setFont(underLinedFont);
				
				headerStyle = setBorderStyle(headerStyle);
				headerStyle.setFillForegroundColor(HSSFColor.YELLOW.index);
				headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				
				HSSFFont font = workbook.createFont(); 
				font.setFontName("GE Inspira");
				font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headerStyle.setFont(font);
				
				HSSFCellStyle cellBoldStyle = workbook.createCellStyle();
				cellBoldStyle = setBorderStyle(cellBoldStyle);
				cellBoldStyle.setFont(font);
				
				HSSFFont nonBoldFont = workbook.createFont();
				nonBoldFont.setFontName("GE Inspira");
				HSSFCellStyle contentStyle = workbook.createCellStyle();				
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(nonBoldFont);
										
				HSSFFont noRecordFont = workbook.createFont(); 
				noRecordFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				noRecordFont.setColor(HSSFColor.RED.index);
				noRecordFont.setFontName("GE Inspira");
				
				HSSFCellStyle noRecordCellStyle = workbook.createCellStyle();
				noRecordCellStyle = setBorderStyle(noRecordCellStyle);
				noRecordCellStyle.setFont(noRecordFont);
				
				int rowcount = -1;
								
				String unitSerialNumber = "";
				searchCriteriaMsg.append("Unit Serial Number     :  ");
				if(plmThreadWhereUsedData.getUnitSerialNumber()!= null){
					searchCriteriaMsg.append(plmThreadWhereUsedData.getUnitSerialNumber());
					unitSerialNumber = plmThreadWhereUsedData.getUnitSerialNumber();
				}
				searchCriteriaMsg.append("\n");
				String mli = "";
				searchCriteriaMsg.append("EID                    :  "); 
				if(plmThreadWhereUsedData.getMliCode()!= null){
					searchCriteriaMsg.append(plmThreadWhereUsedData.getMliCode());
					mli = plmThreadWhereUsedData.getMliCode();
				}
				searchCriteriaMsg.append("\n");
				String partDwg = "";
				searchCriteriaMsg.append("Part/DWG               :  "); 
				if(plmThreadWhereUsedData.getPartDwg()!= null){
					searchCriteriaMsg.append(plmThreadWhereUsedData.getPartDwg());
					partDwg = plmThreadWhereUsedData.getPartDwg();
				}
				searchCriteriaMsg.append("\n");
				String partDesc = "";
				searchCriteriaMsg.append("Part Description       :  "); 
				if(plmThreadWhereUsedData.getPartDwgDescription()!= null){
					searchCriteriaMsg.append(plmThreadWhereUsedData.getPartDwgDescription());
					partDesc = plmThreadWhereUsedData.getPartDwgDescription();
				}
				searchCriteriaMsg.append("\n");
				String effectiveDateFrom = "";
				searchCriteriaMsg.append("Effectivity Date From  :  ");
				if(plmThreadWhereUsedData.getEffectivityDateFrom()!= null){
					effectiveDateFrom = PLMUtils.getFormatRelDate(plmThreadWhereUsedData.getEffectivityDateFrom());
					searchCriteriaMsg.append(PLMUtils.getFormatRelDate(plmThreadWhereUsedData.getEffectivityDateFrom()));
				}
				searchCriteriaMsg.append("\n");
				String effectiveDateTo = "";
				searchCriteriaMsg.append("Effectivity Date To    :  ");
				if(plmThreadWhereUsedData.getEffectivityDateTo()!= null){
					effectiveDateTo = PLMUtils.getFormatRelDate(plmThreadWhereUsedData.getEffectivityDateTo());
					searchCriteriaMsg.append(PLMUtils.getFormatRelDate(plmThreadWhereUsedData.getEffectivityDateTo()));
				}
				searchCriteriaMsg.append("\n");
				
				String[] searchCriterias = {"Unit Serial Number : ","EID : ","Part/DWG : ","Part Description : ","Effectivity Date From : ","Effectivity Date To : "};
				String[] searchCriteriasValue = {unitSerialNumber,mli,partDwg,partDesc,effectiveDateFrom,effectiveDateTo};
				
				HSSFRow row;
				HSSFCell cell;
				
				for ( int i = 0 ; i < searchCriterias.length; i++ ) {
					row = sheet.createRow(i);
					++rowcount;
					cell = row.createCell(0);
					cell.setCellValue(searchCriterias[i]);
					cell.setCellStyle(cellBoldStyle);
					cell = row.createCell(1);
					cell.setCellValue(searchCriteriasValue[i]);
					cell.setCellStyle(cellBoldStyle);
				}
					
				if(!PLMUtils.isEmptyList(whereUsedEMBOMSearchPList)) {
					
					String[] colNames = {"EID", "Part Dwg", "Part / Dwg Description", "Qty","UOM", "PLM Object Type","Next Upper Level", "Next Upper Level Description","PLM Object Status","Origin of Record","Date","Unit Serial Number"};
					row = sheet.createRow(++rowcount);
					row = sheet.createRow(++rowcount);
					
					for ( int i = 0 ; i < colNames.length; i++ ) {
						cell = row.createCell(i);
						cell.setCellValue(colNames[i]);
						cell.setCellStyle(headerStyle);
					}

					for(int i = 0; i < whereUsedEMBOMSearchPList.size(); i++) {
						PLMWhereUsedData dataObj = (PLMWhereUsedData) whereUsedEMBOMSearchPList.get(i);
							row = sheet.createRow(++rowcount);
							cell = row.createCell(0);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getMliCode());
							cell = row.createCell(1);
											
							if(!PLMUtils.isEmpty(dataObj.getPartDwg())){
								if(!PLMUtils.isEmpty(dataObj.getPartId()))
								{
								cell.setCellStyle(hyperLinkStyle);
								HSSFHyperlink url_link =   helper.createHyperlink(Hyperlink.LINK_URL);
								url_link.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getPartId());
								cell.setHyperlink(url_link);
								cell.setCellValue(dataObj.getPartDwg());
								}
								else
								{
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getPartDwg());
								}
							}else{
								cell.setCellStyle(contentStyle);
								 cell.setCellValue("");
							}							
							cell = row.createCell(2);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartDwgDescription());
							cell = row.createCell(3);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getQtyLocation());
							cell = row.createCell(4);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getUom());
							cell = row.createCell(5);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPlmObjectTypevalue());
							cell = row.createCell(6);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getNextUpperLevel());
							cell = row.createCell(7);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getNextUpperLevelDesc());
							cell = row.createCell(8);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPlmObjectStatus());
							cell = row.createCell(9);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getOriginOfRecord());
							cell = row.createCell(10);
							cell.setCellStyle(contentStyle);
							if(dataObj.getLoadDate() != null){
								cell.setCellValue(dateFormat.format(dataObj.getLoadDate()));
							}
							cell = row.createCell(11);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getUnitSerialNumber());
					}
						sheet.autoSizeColumn(0);
						sheet.autoSizeColumn(1);
						sheet.autoSizeColumn(2);
						sheet.autoSizeColumn(3);
						sheet.autoSizeColumn(4);
						sheet.autoSizeColumn(5);
						sheet.autoSizeColumn(6);
						sheet.autoSizeColumn(7);
						sheet.autoSizeColumn(8);
						sheet.autoSizeColumn(9);
						sheet.autoSizeColumn(10);
				} else {
					String noRecordMsg = PLMConstants.WHERE_USED_EBOM_NO_RECORD_FOUND ;
					row = sheet.createRow(++rowcount);
					row = sheet.createRow(++rowcount);
					cell = row.createCell(2);
					cell.setCellValue(noRecordMsg);
					cell.setCellStyle(noRecordCellStyle);
					searchCriteriaMsg.append("\n");
					searchCriteriaMsg.append(noRecordMsg);
					sheet.autoSizeColumn(0);
					sheet.autoSizeColumn(1);
					sheet.autoSizeColumn(2);
				}
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveWhereUsedXLSFile: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveWhereUsedXLSFile: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveWhereUsedXLSFile: ", e);
				throw e;
			}
		}
		return searchCriteriaMsg;
	}
	
	/**
	 * This method is used for getPart
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getPart() throws PLMCommonException {
		try {
			whereUsedEMBOMPartList = plmWhereUsedService.getWhereUsedEMBOMPart(plmWhereUsedData);
			partList = (List<SelectItem>) whereUsedEMBOMPartList.get("partNumList");
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPart: ", exception);
			throw exception;
		} 
		return partList;
	}
	/**
	 * This method is used for getDwg
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getDwg() throws PLMCommonException {
		try {
			whereUsedEMBOMDwgList = plmWhereUsedService.getWhereUsedEMBOMDwg(plmWhereUsedData);
			dwgList = (List<SelectItem>) whereUsedEMBOMDwgList.get("dwgNumList");
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getDwg: ", exception);
			throw exception;
		} 
		return dwgList;
	}
	/**
	 * This method is used for getPartDwg
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getPartDwg() throws PLMCommonException {
		try {
			partDwgList = new ArrayList<SelectItem>();
			List<SelectItem> partNoList = getPart();
			if (partNoList != null && partNoList.size()>0) {
				partDwgList.addAll(partNoList);	
			} 
			List<SelectItem> dwgNoList = getDwg();
			if (dwgNoList != null && dwgNoList.size()>0) {
				partDwgList.addAll(dwgNoList);					
			} 			
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPartDwg: ", exception);
			throw exception;
		} 
		return partDwgList;
	}
	/**
	 * This method is used for getPartDwgNumber
	 * 
	 * @throws PLMCommonException
	 */
	public void getPartDwgNumber() throws PLMCommonException {
		ajaxExceptionMessage = "";
		try {
			if((plmWhereUsedData.isPart() == true) && (plmWhereUsedData.isDwg() == false)){
				List<SelectItem> partNoList = getPart();
				partListSize = partNoList.size();
				LOG.info("partListSize = "+partListSize);
			}else if((plmWhereUsedData.isPart() == false) && (plmWhereUsedData.isDwg() == true)){
				List<SelectItem> dwgNoList = getDwg();
				dwgListSize = dwgNoList.size();
				LOG.info("dwgListSize = "+dwgListSize);
			}else if((plmWhereUsedData.isPart() == true) && (plmWhereUsedData.isDwg() == true)){
				List<SelectItem> partDwgNoList = getPartDwg();
				partDwgListSize = partDwgNoList.size();
				LOG.info("partDwgListSize = "+partDwgListSize);
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPartDwgNumber: ", exception);
			PLMUtils.setCommonException(exception.getMessage(), commonMB, "whereUsedEMBOMSearch","Where Used E+MBOM");
			ajaxExceptionMessage = "ERROR";
		}
	}
	/**
	 * This method is used for getPartDwgDescData
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getPartDwgDescData() throws PLMCommonException {
		String fwdFlag ="";
		noRecordFlag = false;
		try {			
			if(!PLMConstants.EMPTY.equals(plmWhereUsedData.getMliCode())  && !PLMConstants.EMPTY.equals(plmWhereUsedData.getDescription())){
			whereUsedEMBOMPartdwgList = plmWhereUsedService.getWhereUsedEMBOMPartDwg(plmWhereUsedData);
			LOG.info("whereUsedEMBOMPartdwgList>>>>>>>>>> "+whereUsedEMBOMPartdwgList.size());
			recordCount = PLMConstants.N_1000;
		     if(whereUsedEMBOMPartdwgList.size()!=0){
		    	 noRecordFlag = false;
		     }else{
		    	 noRecordFlag = true;
		     }
		 }
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPart: ", exception);
			throw exception;
		} 
		return fwdFlag;
	}
	

	/**
	 * Resets the EMBOM Data
	 * @return String
	 */
	public String resetData(){
		String fwdFlag = "whereUsedEMBOMSearch";
		plmWhereUsedData.setUnitAssembleNumber("");
		plmWhereUsedData.setUnitSerialNumber("");
		plmWhereUsedData.setMliCode("");
		plmWhereUsedData.setPartDwg("");
		plmWhereUsedData.setPartDwgDescription("");
		plmWhereUsedData.setPart(false);
		plmWhereUsedData.setDwg(false);
		plmWhereUsedData.setEffectivityDateFrom(null);
		plmWhereUsedData.setEffectivityDateTo(null);
		return fwdFlag;
	}
	
	/**
	 * This method is used for changeRecordsListner
	 * 
	 * @param event
	 */
	public void changeRecordsListner(ActionEvent event){
		   LOG.info("Action listner called.....--------------------------->"+recordCount);
		   if(recordCount == 100){
			   LOG.info("100");
			   recordCount = PLMConstants.N_100;
		   }else if(recordCount == 200){
			   LOG.info("200");
			   recordCount = 200; 
		   }
		   else if(recordCount == 500){
			   LOG.info("500");
			   recordCount = 500; 
		   }
		   else if(recordCount == 1000){
			   LOG.info("1000");
			   recordCount = 1000; 
		   }
		   else if(recordCount == 2000){
			   LOG.info("2000");
			   recordCount = 2000; 
		   }
		   else if(recordCount == 5000){
			   LOG.info("5000");
			   recordCount = 5000; 
		   }
		   else if(recordCount == totalRecCount){
			   LOG.info("All");
			   recordCount = totalRecCount; 
		   }
		   LOG.info("final value.....--------------------------->"+recordCount);
	   }
	   
	
	

	/**
	 * Generates the BMLL Where Used Search List
	 * @throws PLMCommonException
	 */
	public String generateBMLLWhereUsedEMBOMDataFile() {
		LOG.info("Inside generateBMLLWhereUsedEMBOMDataFile method");
		String fwdFlag = "";
		embomFlag = false;
		try {
			String alertMsg = validateWhereUsedBMLLReport();
			if (PLMUtils.isEmpty(alertMsg)) {
					whereUsedBMLLEMBOMSearchList = plmWhereUsedService.getBMLLWhereUsedEMBOMData(plmWhereUsedData);
					if (whereUsedBMLLEMBOMSearchList != null) {
						totalRecCount = whereUsedBMLLEMBOMSearchList.size();
					} else {
						totalRecCount = 0;
					}
					totalRecCountMsg = "Total Results Count : " + totalRecCount;
					LOG.info("totalRecCount :" + totalRecCount);
					if (totalRecCount == 0) {
						fwdFlag = "invalidembom";
					} else {
						recordCount = PLMConstants.N_100;
						fwdFlag = "whereUsedBMMLEmbomReport";
						LOG.info("fwdFlag :" + fwdFlag);
					}
			}				
		} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@generateBMLLWhereUsedEMBOMDataFile: ", exception);
				fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"generateBMLLWhereUsedEMBOMDataFile","Where Used MBOM");
		} 
		
		return fwdFlag;
	}
	/**
	 * validates the given criteria of BMLI report
	 * @throws PLMCommonException
	 */
	public String validateWhereUsedBMLLReport() throws PLMCommonException {
		LOG.info("Inside validateWhereUsedBMLLReport method");
		Date effectivityDateFrom = plmWhereUsedData.getEffectivityDateFrom();
		Date effectivityDateTo = plmWhereUsedData.getEffectivityDateTo();
			//try {
				if (PLMUtils.isEmpty(plmWhereUsedData.getUnitAssembleNumber())
				&& PLMUtils.isEmpty(plmWhereUsedData.getMliCode())
				&& PLMUtils.isEmpty(plmWhereUsedData.getPartDwg())
				&& PLMUtils.isEmpty(plmWhereUsedData.getPartDwgDescription()) 
				&& PLMUtils.isEmptyDate(plmWhereUsedData.getEffectivityDateFrom())
				&& PLMUtils.isEmptyDate(plmWhereUsedData.getEffectivityDateTo())) {
					alertMessage = PLMConstants.EMBOM_ANY_BMLL_SRCH_CRIT; 				
				}else {
					if(!PLMUtils.isEmpty(plmWhereUsedData.getUnitAssembleNumber())
							&& (!PLMUtils.isEmpty(plmWhereUsedData.getMliCode())
							|| !PLMUtils.isEmpty(plmWhereUsedData.getPartDwg())
							|| !PLMUtils.isEmpty(plmWhereUsedData.getPartDwgDescription()) 
							|| !PLMUtils.isEmptyDate(plmWhereUsedData.getEffectivityDateFrom())
							|| !PLMUtils.isEmptyDate(plmWhereUsedData.getEffectivityDateTo()))){
							if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmWhereUsedData.getUnitAssembleNumber())) {
							alertMessage = alertMessage + PLMConstants.Embom_UnitAssembleNumber_ValMsg;
							}
							if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmWhereUsedData.getMliCode())) {
							alertMessage = alertMessage + PLMConstants.Embom_MLI_ValMsg;
							} 
							if (!PLMUtils.checkForSpecialChars(plmWhereUsedData.getPartDwg())) {
							alertMessage = alertMessage + PLMConstants.Embom_PartDwg_ValMsg;
							} 
							if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmWhereUsedData.getPartDwgDescription())) {
							alertMessage = alertMessage + PLMConstants.Embom_PartDwgDesc_ValMsg;
							} 
							if (PLMUtils.checkForNullOfTwoDates(effectivityDateFrom, effectivityDateTo)) {
							alertMessage = alertMessage + PLMConstants.Dates_NullCheck_Msg;
							} else if (PLMUtils.checkForFromAndToDate(effectivityDateFrom, effectivityDateTo)) {
							alertMessage = alertMessage + PLMConstants.Date_ValMsg;
							}
					  }else{
							if(!PLMUtils.isEmpty(plmWhereUsedData.getUnitAssembleNumber())){
							alertMessage = PLMConstants.EMBOM_ANY_WITH_BMLL_ASSMBLY_CRIT;
							}else{
								alertMessage = PLMConstants.EMBOM_ANY_WITH_SERIAL_CRIT;
							}
						}
			
				}
			/*} catch (Exception e) {
				LOG.info("Error :" + e.getMessage());
			} */
		return alertMessage;
		}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}

	/**
	 * @return the plmWhereUsedData
	 */
	public PLMWhereUsedData getPlmWhereUsedData() {
		return plmWhereUsedData;
	}

	/**
	 * @param plmWhereUsedData the plmWhereUsedData to set
	 */
	public void setPlmWhereUsedData(PLMWhereUsedData plmWhereUsedData) {
		this.plmWhereUsedData = plmWhereUsedData;
	}

	public int getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(int recordCount) {
		LOG.info("recordCount = " + recordCount);
		PLMUtils.getServletSession(true).setAttribute("RecDropDown",
				recordCount);
		this.recordCount = recordCount;
	}

	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}



	/**
	 * @return the ajaxExceptionMessage
	 */
	public String getAjaxExceptionMessage() {
		return ajaxExceptionMessage;
	}

	/**
	 * @param ajaxExceptionMessage the ajaxExceptionMessage to set
	 */
	public void setAjaxExceptionMessage(String ajaxExceptionMessage) {
		this.ajaxExceptionMessage = ajaxExceptionMessage;
	}
	
	//added for BMLL report
	
	private List<PLMWhereUsedData> whereUsedBMLLEMBOMSearchList;

	/**
	 * @return the whereUsedBMLLEMBOMSearchList
	 */
	public List<PLMWhereUsedData> getWhereUsedBMLLEMBOMSearchList() {
		return whereUsedBMLLEMBOMSearchList;
	}

	/**
	 * @param whereUsedBMLLEMBOMSearchList the whereUsedBMLLEMBOMSearchList to set
	 */
	public void setWhereUsedBMLLEMBOMSearchList(
			List<PLMWhereUsedData> whereUsedBMLLEMBOMSearchList) {
		this.whereUsedBMLLEMBOMSearchList = whereUsedBMLLEMBOMSearchList;
	}

	
	
	/**
	 * @return the whereUsedEMBOMPartdwgList
	 */
	public List<PLMWhereUsedData> getWhereUsedEMBOMPartdwgList() {
		return whereUsedEMBOMPartdwgList;
	}

	/**
	 * @param whereUsedEMBOMPartdwgList the whereUsedEMBOMPartdwgList to set
	 */
	public void setWhereUsedEMBOMPartdwgList(
			List<PLMWhereUsedData> whereUsedEMBOMPartdwgList) {
		this.whereUsedEMBOMPartdwgList = whereUsedEMBOMPartdwgList;
	}
	
	

	/**
	 * @return the noRecordFlag
	 */
	public boolean isNoRecordFlag() {
		return noRecordFlag;
	}

	/**
	 * @param noRecordFlag the noRecordFlag to set
	 */
	public void setNoRecordFlag(boolean noRecordFlag) {
		this.noRecordFlag = noRecordFlag;
	}

	/**
	 * @return the plmWhereUsedService
	 */
	public PLMWhereUsedServiceIfc getPlmWhereUsedService() {
		return plmWhereUsedService;
	}

	/**
	 * @param plmWhereUsedService the plmWhereUsedService to set
	 */
	public void setPlmWhereUsedService(PLMWhereUsedServiceIfc plmWhereUsedService) {
		this.plmWhereUsedService = plmWhereUsedService;
	}

	/**
	 * @return the whereUsedEMBOMSearchList
	 */
	public List<PLMWhereUsedData> getWhereUsedEMBOMSearchList() {
		return whereUsedEMBOMSearchList;
	}

	/**
	 * @param whereUsedEMBOMSearchList the whereUsedEMBOMSearchList to set
	 */
	public void setWhereUsedEMBOMSearchList(
			List<PLMWhereUsedData> whereUsedEMBOMSearchList) {
		this.whereUsedEMBOMSearchList = whereUsedEMBOMSearchList;
	}

	/**
	 * @return the whereUsedEMBOMSearchPartDwgList
	 */
	public List<SelectItem> getWhereUsedEMBOMSearchPartDwgList() {
		return whereUsedEMBOMSearchPartDwgList;
	}

	/**
	 * @param whereUsedEMBOMSearchPartDwgList the whereUsedEMBOMSearchPartDwgList to set
	 */
	public void setWhereUsedEMBOMSearchPartDwgList(
			List<SelectItem> whereUsedEMBOMSearchPartDwgList) {
		this.whereUsedEMBOMSearchPartDwgList = whereUsedEMBOMSearchPartDwgList;
	}

	/**
	 * @return the whereUsedEMBOMPartList
	 */
	public Map<String, List<SelectItem>> getWhereUsedEMBOMPartList() {
		return whereUsedEMBOMPartList;
	}

	/**
	 * @param whereUsedEMBOMPartList the whereUsedEMBOMPartList to set
	 */
	public void setWhereUsedEMBOMPartList(
			Map<String, List<SelectItem>> whereUsedEMBOMPartList) {
		this.whereUsedEMBOMPartList = whereUsedEMBOMPartList;
	}

	/**
	 * @return the whereUsedEMBOMDwgList
	 */
	public Map<String, List<SelectItem>> getWhereUsedEMBOMDwgList() {
		return whereUsedEMBOMDwgList;
	}

	/**
	 * @param whereUsedEMBOMDwgList the whereUsedEMBOMDwgList to set
	 */
	public void setWhereUsedEMBOMDwgList(
			Map<String, List<SelectItem>> whereUsedEMBOMDwgList) {
		this.whereUsedEMBOMDwgList = whereUsedEMBOMDwgList;
	}

	/**
	 * @return the partListSize
	 */
	public int getPartListSize() {
		return partListSize;
	}

	/**
	 * @param partListSize the partListSize to set
	 */
	public void setPartListSize(int partListSize) {
		this.partListSize = partListSize;
	}

	/**
	 * @return the dwgListSize
	 */
	public int getDwgListSize() {
		return dwgListSize;
	}

	/**
	 * @param dwgListSize the dwgListSize to set
	 */
	public void setDwgListSize(int dwgListSize) {
		this.dwgListSize = dwgListSize;
	}

	/**
	 * @return the partDwgListSize
	 */
	public int getPartDwgListSize() {
		return partDwgListSize;
	}

	/**
	 * @param partDwgListSize the partDwgListSize to set
	 */
	public void setPartDwgListSize(int partDwgListSize) {
		this.partDwgListSize = partDwgListSize;
	}

	/**
	 * @return the partList
	 */
	public List<SelectItem> getPartList() {
		return partList;
	}

	/**
	 * @param partList the partList to set
	 */
	public void setPartList(List<SelectItem> partList) {
		this.partList = partList;
	}

	/**
	 * @return the dwgList
	 */
	public List<SelectItem> getDwgList() {
		return dwgList;
	}

	/**
	 * @param dwgList the dwgList to set
	 */
	public void setDwgList(List<SelectItem> dwgList) {
		this.dwgList = dwgList;
	}

	/**
	 * @return the partDwgList
	 */
	public List<SelectItem> getPartDwgList() {
		return partDwgList;
	}

	/**
	 * @param partDwgList the partDwgList to set
	 */
	public void setPartDwgList(List<SelectItem> partDwgList) {
		this.partDwgList = partDwgList;
	}

	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/**
	 * @return the totalRecCountMsg
	 */
	public String getTotalRecCountMsg() {
		return totalRecCountMsg;
	}

	/**
	 * @param totalRecCountMsg the totalRecCountMsg to set
	 */
	public void setTotalRecCountMsg(String totalRecCountMsg) {
		this.totalRecCountMsg = totalRecCountMsg;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the partValue
	 */
	public String getPartValue() {
		return partValue;
	}

	/**
	 * @param partValue the partValue to set
	 */
	public void setPartValue(String partValue) {
		this.partValue = partValue;
	}

	/**
	 * @return the dwgValue
	 */
	public String getDwgValue() {
		return dwgValue;
	}

	/**
	 * @param dwgValue the dwgValue to set
	 */
	public void setDwgValue(String dwgValue) {
		this.dwgValue = dwgValue;
	}

	/**
	 * @return the embomFlag
	 */
	public boolean isEmbomFlag() {
		return embomFlag;
	}

	/**
	 * @param embomFlag the embomFlag to set
	 */
	public void setEmbomFlag(boolean embomFlag) {
		this.embomFlag = embomFlag;
	}

	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}


/*	*//**
	 * @return the selcriteriatype
	 *//*
	public String getSelcriteriatype() {
		return selcriteriatype;
	}

	*//**
	 * @param selcriteriatype the selcriteriatype to set
	 *//*
	public void setSelcriteriatype(String selcriteriatype) {
		this.selcriteriatype = selcriteriatype;
	}
	
	*/
	
	
}