/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMProjectTaskMB.java
 * @Creation date: 15-June-2011
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;

import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.richfaces.component.UIDataTable;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMIswasParts;
import com.geinfra.geaviation.pwi.data.PLMProductConfData;
import com.geinfra.geaviation.pwi.data.PLMProjChngData;
import com.geinfra.geaviation.pwi.data.PLMProjChngDtlData;
import com.geinfra.geaviation.pwi.data.PLMProjectTaskData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMMetricsServiceIfc;
import com.geinfra.geaviation.pwi.service.PLMTaskMetricsServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

/**
 * This is Managed Bean to Project Task Report Voucher(by Project)
 */
public class PLMProjectTaskMB {
	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMProjectTaskMB.class);
	/**
	 * Holds the PLMTaskMetricsServiceIfc
	 */
	private PLMTaskMetricsServiceIfc taskMetricsService = null;
	/**
	 * Holds the PLMMetricsServiceIfc
	 */
	private PLMMetricsServiceIfc plmMetricsService  = null;
	/**
	 * Holds the PLMProjectTaskData
	 */
	private PLMProjectTaskData projectTaskData = new PLMProjectTaskData();
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB=null;
	/**
	 * Holds the TaskSearch MB
	 */
	private PLMTaskSearchMB plmTaskSearchMB = new PLMTaskSearchMB();
	
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the Status Results
	 */
	private Map<String, List<SelectItem>> dropDownListProject;
	/**
	 * Holds the Project Results
	 */
	private Map<String, List<SelectItem>> dropDownListStatus;
	/**
	 * Holds the Status Items
	 */
	private List<SelectItem> statusList;
	/**
	 * Holds the Project Items
	 */
	private List<SelectItem> projectList;
	/**
	 * Holds the Max Records per page
	 */
	private int recordCounts = PLMConstants.N_100;
	/**
	 * Holds the Total Records Count for header page
	 */
	private int totalRecCount;
	/**
	 * Holds the Total Record Count Message for header page
	 */
	private String totalRecCountMsg;
	/**
	 * Holds the searchResultListProject
	 */
	private List<PLMProjectTaskData> searchResultListProject;
	/**
	 * Holds the selectedProjectValue
	 */
	private String selectedPrjName;
	/**
	 * Holds the selectedProjectValue
	 */
	private String prjTaskType;
	/**
	 * Holds the selected Contract Value
	 */
	private String contractSessValue;

	/**
	 * Holds the Project Change Header Data
	 */
	private List<PLMProjChngData> prjChngHdrList =new ArrayList<PLMProjChngData>();
	/**
	 * Holds the Project Change Details Data
	 */
	private List<PLMProjChngDtlData> prjChngDtlList;
	/**
	 * Holds the totalRecCount
	 */
	private int totalDetailRecCount;
	/**
	 * Holds the totalDetailRecCountMsg
	 */
	private String totalDetailRecCountMsg;
	/**
	 * Holds the recordCounts
	 */
	private int detailRecordCounts = PLMConstants.N_100;
	
	/**
	 * Holds the contractValues
	 */
	private UIDataTable contractValues =null;
	
	
	/**
	 * Holds the Max Records per page
	 */
	private int prjSumaryRecordCounts = PLMConstants.N_100;

	/**
	 * Holds the contractName
	 */
	private String contractName;
	/**
	 * Holds the contract Selected
	 */
	private String contractSel;
	
	/**
	 * Holds the prjHmSrchFlag
	 **/
	private boolean prjHmSrchFlag;
	
	/**
	 * Holds the prjSumyFlag
	 **/
	private boolean prjSumyFlag;
	/**
	 * Holds the contractDtl
	 **/
	private String contractDtl;
	/**
	 * Holds the topParts
	 **/
	private String topParts;
	
	//newly adding Input fields of project change summary
	/**
	 * Holds the dropdownlist
	 **/
	//private Map<String, List<SelectItem>> dropdownlist;
	/**
	 * Holds the rdoList
	 **/
	private List<SelectItem> rdoList;
	/**
	 * Holds the ecrStateList
	 **/
	private List<SelectItem> ecrStateList = new ArrayList<SelectItem>();
	/**
	 * Holds the ecrCtgryList
	 **/
	private List<SelectItem> ecrCtgryList;
	/**
	 * Holds the prjChngDtlData
	 **/
	private PLMProjChngDtlData prjChngDtlData = new PLMProjChngDtlData();
	/**
	 * Holds the ecoStateList
	 **/
	private List<SelectItem> ecoStateList = new ArrayList<SelectItem>();
	
	
	//newly Added for Contract Summary Report 
	/**
	 * Holds the plmProductData
	 **/
	private PLMProductConfData plmProductData = new PLMProductConfData();
	/**
	 * Holds the prdcontractName
	 **/
	private String prdcontractName;
	/**
	 * Holds the getPrdSummaryData
	 **/
	private Map<String, List<PLMProductConfData>> getPrdSummaryData;
	/**
	 * Holds the prdConfList
	 **/
	private List<SelectItem> prdConfList = new ArrayList<SelectItem>();
	/**
	 * Holds the prdCnfFlag
	 **/
	private boolean prdCnfFlag;
	/**
	 * Holds the productConfSmryList
	 **/
	private List<PLMProductConfData> productConfSmryList = new ArrayList<PLMProductConfData>();
	/**
	 * Holds the customerSmryList
	 **/
	private List<PLMProductConfData> customerSmryList = new ArrayList<PLMProductConfData>();
	/**
	 * Holds the totalPrdContRecCountMsg
	 **/	
	private String totalPrdContRecCountMsg;
	/**
	 * Holds the detailPrdContRecordCounts
	 **/
	private int detailPrdContRecordCounts = PLMConstants.N_100;
	/**
	 * Holds the totalPrdContRecCount
	 **/
	private int totalPrdContRecCount;
	/**
	 * Holds the totalCustReqRecCountMsg
	 **/	
	private String totalCustReqRecCountMsg;
	/**
	 * Holds the detailCustReqRecordCounts
	 **/
	private int detailCustReqRecordCounts = PLMConstants.N_100;
	/**
	 * Holds the totalCustReqRecCount
	 **/
	private int totalCustReqRecCount;
	/**
	 * Holds the prdConfDataFlag
	 **/
	private boolean prdConfDataFlag;
	/**
	 * Holds user details
	 */
	private PLMPwiUserData userDetails;
	/**
	 * Holds the custReqDataFlag
	 **/
	private boolean custReqDataFlag;
	

	//newly added for IsWaParts 
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor =null;
	
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the isWasParts
	 **/
	private PLMIswasParts isWasParts =new PLMIswasParts();
	
	/*private PLMLoginData userDataObj = (PLMLoginData) PLMUtils
	.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA);*/

	/**
	 * This method is used for Resetting the Form Data
	 * 
	 * @return String
	 */
	public String resetPtrvPrjData() {
		LOG.info("Entering resetPtrvPrjData method");
		String fwdflag = "ptrvSearchProject";
		if (projectTaskData.getDueDateFromProject() != null) {
			projectTaskData.setDueDateFromProject(null);
		}
		if (projectTaskData.getDueDateToProject() != null) {
			projectTaskData.setDueDateToProject(null);
		}

		if (projectTaskData.getPrjNamesList() != null) {
			projectTaskData.setPrjNamesList(null);
		}
		if (projectTaskData.getPolicyTask() != null) {
			projectTaskData.setPolicyTask(null);
		}
		if (projectTaskData.getStatusProjectList() != null) {
			projectTaskData.setStatusProjectList(null);
		}
		if (projectTaskData.getVoucherFundingSource() != null) {
			projectTaskData.setVoucherFundingSource(null);
		}
		LOG.info("Exiting resetPtrvPrjData method");
		return fwdflag;
	}

	/**
	 * This method is used for Load Project Task routing voucher Page
	 * 
	 * @return String
	 */
	public String loadPtrvPrjPage() {
		LOG.info("Entering loadPtrvPrjPage method");
		String fwdFlag = "";
		try {
			commonMB.insertCannedRptRecordHitInfo("Project/Route Task Report (By Project)");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			projectTaskData = new PLMProjectTaskData();
			LOG.info("Getting the Status Dropdownlist");
			dropDownListStatus = taskMetricsService.getStatusDropDownvalues();
			statusList = (List<SelectItem>)dropDownListStatus.get("ptrvstatus");
			LOG.info("Size of Status Dropdown : " + statusList.size());
			LOG.info("Getting the Project Dropdownlist");
			dropDownListProject = taskMetricsService.getPrjDropDownvalues();
			projectList = (List<SelectItem>) dropDownListProject.get("ptrvproject");
			resetPtrvPrjData();
			fwdFlag = "ptrvSearchProject";
			LOG.info("projectList" + projectList.size());
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadPtrvPrjPage: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Project / Route Task Report (By Project)");
		} 
		LOG.info("Exiting loadPtrvPrjPage method");
		return fwdFlag;
	}

	/**
	 * This method is used to Load Project Task routing voucher Report
	 * 
	 * @return String
	 */
	public String getPtrvPrjSearchData() {
		String fwdFlag = "";
		LOG.info("Entering getPtrvPrjSearchData method");
		try {
			Date dueDateFromProject = projectTaskData.getDueDateFromProject();
			Date dueDateToProject = projectTaskData.getDueDateToProject();
			if (PLMUtils.isEmptyDate(dueDateFromProject) && PLMUtils.isEmptyDate(dueDateToProject)
					&& PLMUtils.isEmptyList(projectTaskData.getPrjNamesList()) && PLMUtils.isEmpty(projectTaskData.getPolicyTask())
					&& PLMUtils.isEmptyList(projectTaskData.getStatusProjectList())	&& PLMUtils.isEmpty(projectTaskData.getVoucherFundingSource())) {
				alertMessage = PLMConstants.ANY_SRCH_CRIT;
				LOG.info("Null Validation : " +  alertMessage);
			} else {
				if (!PLMUtils.checkForSpecialChars(projectTaskData.getPolicyTask())	&& !PLMUtils.isEmpty(projectTaskData.getPolicyTask())) {
					LOG.info("Special Characters Validation");
					alertMessage = alertMessage	+ PLMConstants.POLICY_TASK_MESSAGE;
					fwdFlag = "ptrvSearchProject";
				}
				if (!PLMUtils.checkForSpecialChars(projectTaskData.getVoucherFundingSource())) {
					alertMessage = alertMessage + PLMConstants.VOUCHER_MESSAGE;
					fwdFlag = "ptrvSearchProject";
				}
				if (PLMUtils.checkForNullOfTwoDates(dueDateFromProject, dueDateToProject)) {
					alertMessage = alertMessage + PLMConstants.Dates_NullCheck_Msg;
				} else if (PLMUtils.checkForFromAndToDate(dueDateFromProject, dueDateToProject)) {
					alertMessage = alertMessage + PLMConstants.Date_ValMsg;
					fwdFlag = "ptrvSearchProject";
				}
			}
				LOG.info("Validation Message  : " + alertMessage);
			if (PLMUtils.isEmpty(alertMessage)) {
					searchResultListProject = taskMetricsService.getPrjSearchData(projectTaskData);
			if (!PLMUtils.isEmptyList(searchResultListProject)) {
					totalRecCount = searchResultListProject.size();
					recordCounts = PLMConstants.N_100;
					fwdFlag = "ptrvReportProject";
					totalRecCountMsg = "Total Results Count : "	+ totalRecCount;
					LOG.info("Total Records :"	+ totalRecCount);
					} 
			else if (PLMUtils.isEmptyList(searchResultListProject)) {
					LOG.info("Invalid project task voucher Search");
					fwdFlag = "invalidsearch";
				}
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPtrvPrjSearchData: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"ptrvSearchProject","Project / Route Task Report (By Project)");
		} 
		LOG.info("Exiting getPtrvPrjSearchData method");
		return fwdFlag;
	}

	/**
	 * This method is used to Load Project Task routing voucher Detailed Report
	 * 
	 * @return String
	 */
	public String getPtrvPrjDetailedReport() {
		LOG.info("Entering the getPtrvPrjDetailedReport method");
		String fwdFlag = "";
		try {
			projectTaskData.setSelectedPrjName(selectedPrjName);
			projectTaskData.setPrjTaskType(prjTaskType);
			LOG.info("Selected Project : " + projectTaskData.getSelectedPrjName());
			LOG.info("Selected Task Type : " + projectTaskData.getPrjTaskType());
			StringBuffer searchResultsQuery = taskMetricsService.getProjectTaskDetailQuery(projectTaskData);
			fwdFlag = plmTaskSearchMB.getProjectTaskDetailReport(searchResultsQuery);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPtrvPrjDetailedReport: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"ptrvReportProject","Project / Route Task Report (By Project)");
		} 
		LOG.info("Exiting the getPtrvPrjDetailedReport method");
		plmTaskSearchMB.setPage("ptrvsearch");
		return fwdFlag;
	}
	/**
	 * This method is used for Load Project Task routing voucher Page
	 * 
	 * @return String
	 */
	public String loadPrjChngSmryPg() {
		LOG.info("Entering loadPrjChngSmryPg method");
		String fwdFlag = "";
		try {
			LOG.info("Loading Project Chng Summary Segement 1 Data");
			prjChngHdrList = plmMetricsService.getProjChngHdr();
			if (!PLMUtils.isEmptyList(prjChngHdrList)) {
				totalRecCount = prjChngHdrList.size();
				prjSumaryRecordCounts = PLMConstants.N_100;				
				fwdFlag = "prjchngSmry";
				totalRecCountMsg = "Total Results Count : "	+ totalRecCount;
				LOG.info("Total Records :"	+ totalRecCount);
				} 
			else if (PLMUtils.isEmptyList(prjChngHdrList)) {
				LOG.info("Invalid Search in Proj Chng Summary Hdr");
				fwdFlag = "invalidhdrsearch";
			}
			//fwdFlag = "prjchngSmry";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadPrjChngSmryPg: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Project Change Summary Report");
		} 
		
		try {
			commonMB.getPLMDateStamp(PLMConstants.CONTRACT_TABLE);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPLMDateStamp: ", exception);
		} 
		LOG.info("Exiting loadPrjChngSmryPg method");
		return fwdFlag;
	}
	
	/**
	 * This method is used for getPrjChngDtlReport
	 * 
	 * @return String
	 */
	public String getPrjChngDtlReport() {
		
//		PLMProjChngData dtlData = new PLMProjChngData();
		
		PLMProjChngData dtlData = (PLMProjChngData)contractValues.getRowData();
		// 723427
		String contract = dtlData.getContract();
		LOG.info("Entering getPrjChngDtlReport method"+contract);
		
		//LOG.info("Entering getPrjChngDtlReport method"+PLMUtils.getRequestParameter("contractSessValue"));
		/*if (!PLMUtils.isEmpty(PLMUtils.getRequestParameter("contractSessValue"))) {
			
			contract = PLMUtils.getRequestParameter("contractSessValue");
		}
		LOG.info("Contract Selected --> "+contract);*/
		String fwdFlag = "";
		

		try {
			if (contract!=null) {
				
				if (prjChngDtlData.isAllOpenEcr()){
					if(!PLMUtils.isEmptyList(ecrStateList))
					{
						List <String> allOpenEcrStateList = new ArrayList <String>();
						for (int i = 0 ; i < ecrStateList.size() ; i++ )
						{
							String stateEcrValue = ecrStateList.get(i).getLabel();
							if(!stateEcrValue.equals("Complete") && !stateEcrValue.equals("Cancelled"))
							{
								allOpenEcrStateList.add(stateEcrValue);
							}
						}
						prjChngDtlData.setSelEcrStateList(allOpenEcrStateList);	
					}
				}
				
				if (prjChngDtlData.isAllOpenEco()){
					if(!PLMUtils.isEmptyList(ecoStateList))
					{
						List <String> allOpenEcoStateList = new ArrayList <String>();
						for (int j = 0 ; j < ecoStateList.size() ; j++ )
						{
							String stateEcoValue = ecoStateList.get(j).getLabel();
							if(!stateEcoValue.equals("Implemented") && !stateEcoValue.equals("Release")&& !stateEcoValue.equals("Cancelled"))
							{
								allOpenEcoStateList.add(stateEcoValue);
							}
						}
						prjChngDtlData.setSelEcoStateList(allOpenEcoStateList);	
					}
				}
				prjChngDtlList = plmMetricsService.getProjChngDtls(contract,prjChngDtlData);
				if (prjChngDtlList != null) {
					totalDetailRecCount = prjChngDtlList.size();
				} else {
					totalDetailRecCount = 0;
				}
				
				totalDetailRecCountMsg = "Contract : "+contract+" - Total Results : "
										 + totalDetailRecCount;
				LOG.info("totalDetailRecCount::::::::::::::::::"
						+ totalDetailRecCount);
				if (totalDetailRecCount == 0) {
					fwdFlag = "prjChngInvalidContract";
				} else {
					
					detailRecordCounts = PLMConstants.N_100;
					contractDtl = contract;
					prjChngDtlData.setContractDtl(contractDtl);
					
					topParts = getTopPartsFromDtls(prjChngDtlList);
					prjChngDtlData.setTopParts(topParts);
					fwdFlag = "prjchngSmryDtls";
				}
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getEcrDetailedReport: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecrSearchResult","ECR Search");
		} 
		LOG.info("Exiting getPrjChngDtlReport method");
		return fwdFlag;
		
	}
	
	/**
	 * This method is used for getTopPartsFromDtls
	 * 
	 * @param prjChngDtlListLcl
	 * @return String
	 */
	public String getTopPartsFromDtls(List<PLMProjChngDtlData> prjChngDtlListLcl) {

		Set<String> topPartsSet = new HashSet<String>();
		List<String> topPartList = new ArrayList<String>();
		
		for (int i=0;i<prjChngDtlListLcl.size();i++) {
			topPartsSet.add(prjChngDtlListLcl.get(i).getTopLvlPrntPrjChng());
		}
		
		Iterator<String> itr = topPartsSet.iterator();
		
		while(itr.hasNext()){
			topPartList.add(itr.next());
		}		
		
		StringBuilder result = new StringBuilder();

        result.append("\"");
	    for(String string : topPartList) {
	        result.append(string);
	        result.append(",");
	    }
	    String finalResStr = result.length() > 0 ? result.substring(0, result.length() - 1)+"\"": "";
	    return finalResStr; 
	}
	
	/**
	 * This method is used for get Project Summary Report
	 * 
	 * @return String
	 */
	public String getPrjChngSearchReport() {
		LOG.info("Entering getPrjSmryReport Method ");
		String fwdflag = "";
		totalRecCount =0;
			try {
				
			 prjChngHdrList = plmMetricsService
					.getPrjSumryReport(contractName);
				if (prjChngHdrList != null) {
					totalRecCount = prjChngHdrList.size();
				} else {
					totalRecCount = 0;
				}
				if (totalRecCount == 0)
					fwdflag = "prjChngInvalidContract";
				else{
					fwdflag = "prjchngSmry";
				}
				LOG.info("Total Results Count" + totalRecCount);
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getPrjSmryReport: ", exception);
				fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"getPrjSmryReport","Project Summary");
			} 
		  
		LOG.info("Exiting getPrjSmryReport Method ");
		return fwdflag;
	}
	
	/**
	 * This method is used for getprjChngSumyAction
	 * 
	 * @return String
	 */
	public String getprjChngSumyAction() {
		String fwdflag = "";
		prjSumyFlag=true;
		prjHmSrchFlag=false;
		if (!PLMConstants.EMPTY.equals(contractName)) {
			alertMessage = validateProjSearchData();
				if (PLMConstants.EMPTY.equals(alertMessage)) {
				 getPrjChngSearchReport();
				if (totalRecCount != 0) {
					fwdflag = "prjchngSmry";
				 } else if(totalRecCount == 0){
					 alertMessage = "No records found for the input Search Criteria.";
					fwdflag = "prjchngSearch";
				}
			  }else{
				  fwdflag = "prjchngSearch";
			  }
		}
		else {
			fwdflag = loadPrjChngSmryPg();
		}
		return fwdflag;
	}
	

	/**
	 * This method is used for validateProjSearchData
	 * 
	 * @return String
	 */
	public String  validateProjSearchData(){
		alertMessage ="";
		if (PLMUtils.checkSplCharsProjSumry(contractName)) {
			alertMessage = PLMConstants.PRJ_SMRY_SPL_CRITERIA;
		} 
		return alertMessage;
	}
	
	/**
	 * This method is used for getprjChngHome
	 * 
	 * @return String
	 */
	public String getprjChngHome(){
		contractName = "";
		prjSumyFlag=false;
		prjHmSrchFlag=false;
		alertMessage = "";
		contractSel ="";
		totalRecCount =0;
		totalDetailRecCount=0;
		totalRecCountMsg="";
		if(prjChngHdrList!=null) {
			prjChngHdrList.clear();
		}
		if (prjChngDtlList!=null){
			prjChngDtlList.clear();
		}
		contractDtl = "";
		topParts = "";
		prjChngDtlData= new PLMProjChngDtlData();	
		try {
			commonMB.insertCannedRptRecordHitInfo("Project Change Summary");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try{
		Map<String, List<SelectItem>> dropdownlist = plmMetricsService.getprjChangeList();
		rdoList = ((List<SelectItem>) dropdownlist.get("rdo"));
		ecrStateList = ((List<SelectItem>) dropdownlist.get("ecrState"));
		ecrCtgryList =((List<SelectItem>) dropdownlist.get("ecrCategory"));
		ecoStateList = ((List<SelectItem>) dropdownlist.get("ecoState"));
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getprjChngHome: ", exception);
		} 
		return "prjchngSearch";
	}
	
	
	/**
	 * This method is used for validateEcrECOData
	 * 
	 * @return String
	 */
	public String  validateEcrECOData(){
		alertMessage ="";
		if (PLMUtils.checkSplCharsProjSumry(contractName)) {
			alertMessage = PLMConstants.PRJ_SMRY_SPL_CRITERIA;
		} 
		else if(PLMUtils.checkSplCharsProjSumry(prjChngDtlData.getEcrOrig())){
			alertMessage = PLMConstants.PRJ_CHANG_ECR_ORG;
		}
		else if(PLMUtils.checkSplCharsProjSumry(prjChngDtlData.getEcrRespDesign())){
			alertMessage = PLMConstants.PRJ_CHANG_RESP_DESIGN;
		}
		else if(PLMUtils.checkForFromAndToDate(prjChngDtlData.getEcrStartDate(), prjChngDtlData.getEcrEndDate())){
			alertMessage = PLMConstants.PRJ_CHANG_ECR_DATE_RANGE;
		}
		else if((!PLMUtils.isEmptyDate(prjChngDtlData.getEcrStartDate())
			      && PLMUtils.isEmptyDate(prjChngDtlData.getEcrEndDate()))
			      ||(PLMUtils.isEmptyDate(prjChngDtlData.getEcrStartDate())
					      && !PLMUtils.isEmptyDate(prjChngDtlData.getEcrEndDate())))
			   {
		alertMessage = PLMConstants.PRJ_CHANG_ECR_DATE;
			  }
		
		else if(PLMUtils.checkForFromAndToDate(prjChngDtlData.getEcoStrDate(), prjChngDtlData.getEcoEndDate())){
			alertMessage = PLMConstants.PRJ_CHANG_ECO_DATE_RANGE;
		}
		
		else if((!PLMUtils.isEmptyDate(prjChngDtlData.getEcoStrDate())
			      && PLMUtils.isEmptyDate(prjChngDtlData.getEcoEndDate()))
			      ||(PLMUtils.isEmptyDate(prjChngDtlData.getEcoStrDate())
					      && !PLMUtils.isEmptyDate(prjChngDtlData.getEcoEndDate())))
			   {
		alertMessage = PLMConstants.PRJ_CHANG_ECO_DATE;
			  }
		
				
		return alertMessage;
	}
	
	/**
	 * This method is used for getprjChngDescdata
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getprjChngDescdata() throws PLMCommonException {
		String fwdFlag ="";
		totalRecCount =0;
		prjSumyFlag=false;
		prjHmSrchFlag=true;
		contractSel ="";
		alertMessage = "";
		try {			
			if(!PLMConstants.EMPTY.equals(contractName)){
				alertMessage = validateEcrECOData();
				if (PLMConstants.EMPTY.equals(alertMessage)) {
					prjChngHdrList = plmMetricsService.getprjContractDescdata(contractName);
					LOG.info("getprjChngDetdata>>>>>>>>>> "+prjChngHdrList.size());
					totalRecCount = prjChngHdrList.size();
					prjSumaryRecordCounts = PLMConstants.N_100;		
				
					if(totalRecCount==1){
						contractSel = prjChngHdrList.get(0).getContract();
					}
					else if(totalRecCount==0){
						alertMessage = "No Records found for the provided input criteria.";
						fwdFlag = "prjchngSearch";
					}
  		        }
				else{
					fwdFlag = "prjchngSearch";
				}
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPart: ", exception);
			throw exception;
		} 
		fwdFlag = PLMConstants.EMPTY;
		return fwdFlag;
	}
	
	/**
	 * This method is used for getPrjChngDescDtlReport
	 * 
	 * @return String
	 * 
	 */
   public String getPrjChngDescDtlReport() {
		
		LOG.info("Entering getPrjChngDescDtlReport method");
		String fwdFlag = "";
		try {
			LOG.info("select contractSel "+contractSel);
				if(!PLMConstants.EMPTY.equals(contractSel)){
					
					if (prjChngDtlData.isAllOpenEcr()){
						if(!PLMUtils.isEmptyList(ecrStateList))
						{
							List <String> allOpenEcrStateList = new ArrayList <String>();
							for (int i = 0 ; i < ecrStateList.size() ; i++ )
							{
								String stateEcrValue = ecrStateList.get(i).getLabel();
								if(!stateEcrValue.equals("Complete") && !stateEcrValue.equals("Cancelled"))
								{
									allOpenEcrStateList.add(stateEcrValue);
								}
							}
							prjChngDtlData.setSelEcrStateList(allOpenEcrStateList);	
						}
					}
					
					if (prjChngDtlData.isAllOpenEco()){
						if(!PLMUtils.isEmptyList(ecoStateList))
						{
							List <String> allOpenEcoStateList = new ArrayList <String>();
							for (int j = 0 ; j < ecoStateList.size() ; j++ )
							{
								String stateEcoValue = ecoStateList.get(j).getLabel();
								if(!stateEcoValue.equals("Implemented") && !stateEcoValue.equals("Release")&& !stateEcoValue.equals("Cancelled"))
								{
									allOpenEcoStateList.add(stateEcoValue);
								}
							}
							prjChngDtlData.setSelEcoStateList(allOpenEcoStateList);	
						}
					}
					
					prjChngDtlList = plmMetricsService.getProjChngDtls(contractSel,prjChngDtlData);
					if (prjChngDtlList != null) {
						totalDetailRecCount = prjChngDtlList.size();
					} else {
						totalDetailRecCount = 0;
					}
					
					totalDetailRecCountMsg = "Contract : "+contractSel+" - Total Results : "
											 + totalDetailRecCount;
					LOG.info("totalDetailRecCount::::::::::::::::::"
							+ totalDetailRecCount);
					if (totalDetailRecCount == 0) {
						fwdFlag = "prjChngInvalidContract";
					} else {
						detailRecordCounts = PLMConstants.N_100;
						contractDtl = contractSel;
						prjChngDtlData.setContractDtl(contractDtl);
						topParts = getTopPartsFromDtls(prjChngDtlList);
						prjChngDtlData.setTopParts(topParts);
						fwdFlag = "prjchngSmryDtls";
					}
				}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getEcrDetailedReport: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecrSearchResult","ECR Search");
		} 
		LOG.info("Exiting getPrjChngDtlReport method "+fwdFlag);
		return fwdFlag;
		
	}
   
	/**
	 * This method is used for changeRecordsListner
	 * 
	 * @param event
	 * 
	 */
   public void changeRecordsListner(ActionEvent event){
	   LOG.info("Action listner called.....--------------------------->"+prjSumaryRecordCounts);
	   if(prjSumaryRecordCounts == 100){
		   LOG.info("100");
	   prjSumaryRecordCounts = PLMConstants.N_100;
	   }else if(prjSumaryRecordCounts == 500){
		   LOG.info("500");
		   prjSumaryRecordCounts = 500; 
	   }
	   else if(prjSumaryRecordCounts == 1000){
		   LOG.info("1000");
		   prjSumaryRecordCounts = 1000; 
	   }
	   else if(prjSumaryRecordCounts == 1500){
		   LOG.info("1500");
		   prjSumaryRecordCounts = 1500; 
	   }
	   else if(prjSumaryRecordCounts == 2000){
		   LOG.info("2000");
		   prjSumaryRecordCounts = 2000; 
	   }
	   else if(prjSumaryRecordCounts == 3000){
		   LOG.info("3000");
		   prjSumaryRecordCounts = 3000; 
	   }
	   else if(prjSumaryRecordCounts == 4000){
		   LOG.info("4000");
		   prjSumaryRecordCounts = 4000; 
	   }else if(prjSumaryRecordCounts == 5000){
		   LOG.info("5000");
		   prjSumaryRecordCounts = 5000; 
	   }
	   else if(prjSumaryRecordCounts == totalRecCount){
		   LOG.info("All");
		   prjSumaryRecordCounts = totalRecCount; 
	   }
	   LOG.info("final value.....--------------------------->"+prjSumaryRecordCounts);
   }
   
   /**
	 * This method is used for changeDetailRecordsListner
	 * 
	 * @param event
	 * 
	 */
   public void changeDetailRecordsListner(ActionEvent event){
	   LOG.info("Action listner called.....--------------------------->"+detailRecordCounts);
	   if(detailRecordCounts == 100){
		   LOG.info("100");
		   detailRecordCounts = PLMConstants.N_100;
	   }else if(detailRecordCounts == 500){
		   LOG.info("500");
		   detailRecordCounts = 500; 
	   }
	   else if(detailRecordCounts == 1000){
		   LOG.info("1000");
		   detailRecordCounts = 1000; 
	   }
	   else if(detailRecordCounts == 1500){
		   LOG.info("1500");
		   detailRecordCounts = 1500; 
	   }
	   else if(detailRecordCounts == 2000){
		   LOG.info("2000");
		   detailRecordCounts = 2000; 
	   }
	   else if(detailRecordCounts == 3000){
		   LOG.info("3000");
		   detailRecordCounts = 3000; 
	   }
	   else if(detailRecordCounts == 4000){
		   LOG.info("4000");
		   detailRecordCounts = 4000; 
	   }else if(detailRecordCounts == 5000){
		   LOG.info("5000");
		   detailRecordCounts = 5000; 
	   }
	   else if(detailRecordCounts == totalRecCount){
		   LOG.info("All");
		   detailRecordCounts = totalRecCount; 
	   }
	   LOG.info("final value.....--------------------------->"+detailRecordCounts);
   }
   
   
   //newly Added method for contract Summary Report
	 
	   /**
		 * This method is used for Load Contract Summary Home Page
		 * 
		 * @return String
		 */
		public String loadContractSmrypage() {
			LOG.info("Entering loadContractSmrypage method");
			String fwdFlag = "selOptionsSrch";
			prdcontractName = "";
			alertMessage = "";
			prdCnfFlag =false;
			plmProductData = new PLMProductConfData();
			totalPrdContRecCountMsg ="";
			detailPrdContRecordCounts = PLMConstants.N_100;
			totalPrdContRecCount=0;
			totalCustReqRecCountMsg="";
			detailCustReqRecordCounts = PLMConstants.N_100;
			totalCustReqRecCount =0;
        	prdConfList = new ArrayList<SelectItem>() ;
        	productConfSmryList = new  ArrayList<PLMProductConfData>();
    		customerSmryList = new  ArrayList<PLMProductConfData>();
    		prdConfDataFlag=false;
    		custReqDataFlag=false;    		
			LOG.info("Exiting loadContractSmrypage method");
			return fwdFlag;
		}
		
	   /**
		 * This method is used for validateProdSearchData
		 * 
		 * @return String
		 */
		public String  validateProdSearchData(){
			alertMessage ="";
			if (PLMUtils.checkSplCharsProjSumry(prdcontractName)) {
				alertMessage = PLMConstants.PRJ_SMRY_SPL_CRITERIA;
			} 
			return alertMessage;
		}
		 /**
		 * This method is used for getPrdConfDescData
		 * 
		 * @return String
		 */
		public String getPrdConfDescData() {
			LOG.info("Entering into getPrjConfDescData ..");
			String fwdFlag = "";
			alertMessage = "";
			try {
				if(!PLMConstants.EMPTY.equals(prdcontractName)){
					alertMessage = validateProdSearchData();
					if (PLMConstants.EMPTY.equals(alertMessage)) {
				
				plmProductData = new PLMProductConfData();
				 Map<String, List<SelectItem>> dropdownList = plmMetricsService.getProductCnfgDesc(prdcontractName);
				
				prdConfList = ((List<SelectItem>) dropdownList.get("prdConfDes"));
				
				if(prdConfList.size()>0){
					prdCnfFlag =true;
				}
				else{
					prdCnfFlag =false;
					alertMessage="No Product Configuration data found for Given Criteria";
				}
				
			  }
			}
				fwdFlag = "selOptionsSrch";
				} catch (PLMCommonException exception) {
					LOG.log(Level.ERROR, "Exception@loadWhereUsedPage: ", exception);
					fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","selOptionsSrch");
				} 
			LOG.info("Exiting into getPrjConfDescData...");
			return fwdFlag;
		}
		 /**
		 * This method is used for validateSelectPrdConf
		 * 
		 * @return String
		 */
		public String  validateSelectPrdConf(){
			alertMessage ="";
			if (PLMUtils.isEmptyList(plmProductData.getSelPrdConfList()) && !plmProductData.isAllOpenPrdCnf()) {
				alertMessage = "Please Select Atleast One Product configuration / select All Check box";
			} 
			return alertMessage;
		}
		/**
		 * This method is used for getContractSummarydata
		 * 
		 * @return String
		 */
		public String getContractSummarydata()  {
			LOG.info("Entering into getContractSummarydata ..");
			String fwdFlag = "";
			alertMessage = "";
			try {
			if (plmProductData.isAllOpenPrdCnf()){
				if(!PLMUtils.isEmptyList(prdConfList))
				{
					List <String> allOpenPrdCnfList = new ArrayList <String>();
					for (int i = 0 ; i < prdConfList.size() ; i++ )
					{
						String prjconfValue = prdConfList.get(i).getValue().toString();
						allOpenPrdCnfList.add(prjconfValue);
					}
					plmProductData.setSelPrdConfList(allOpenPrdCnfList);	
				}
			}
			
			alertMessage = validateSelectPrdConf();
			if (PLMConstants.EMPTY.equals(alertMessage)) {
				getPrdSummaryData = plmMetricsService.getProductCnfgSummary(plmProductData);
				
				productConfSmryList = ((List<PLMProductConfData>) getPrdSummaryData.get("prdSummaryList"));
				totalPrdContRecCount =productConfSmryList.size();
				
				if(totalPrdContRecCount!=0){
				  totalPrdContRecCountMsg = "Selected Options - Total Results : " + productConfSmryList.size();
				  LOG.info("totalDetailRecCountMsg>>>>>>>>. "+totalPrdContRecCountMsg);
				   prdConfDataFlag=true;
				}
				else{
					prdConfDataFlag=false;
				}
				
				
				customerSmryList = ((List<PLMProductConfData>) getPrdSummaryData.get("custReqList"));
				totalCustReqRecCount =customerSmryList.size();
				if(totalCustReqRecCount!=0){
				  totalCustReqRecCountMsg = "Customer Requirements - Total Results : " + customerSmryList.size();
				  LOG.info("totalDetailRecCountMsg>>>>>>>>. "+totalCustReqRecCountMsg);
				  custReqDataFlag=true; 
				}
				else{
				  custReqDataFlag=false; 
				}
				
				fwdFlag= "selOptionsRpt";
				
			}
			else{
				fwdFlag= "selOptionsSrch";
				}
		 }
			catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getContractSummarydata: ", exception);
			} 
			return fwdFlag;
			
		}
		
		/**
		 * This method is used for changeprdContRecordsListner
		 * 
		 * @param event
		 */
		 public void changeprdContRecordsListner(ActionEvent event){
			   LOG.info("Action listner called.....--------------------------->"+detailCustReqRecordCounts);
			   if(detailCustReqRecordCounts == 100){
				   LOG.info("100");
				   detailCustReqRecordCounts = PLMConstants.N_100;
			   }else if(detailCustReqRecordCounts == 500){
				   LOG.info("500");
				   detailCustReqRecordCounts = 500; 
			   }
			   else if(detailCustReqRecordCounts == 1000){
				   LOG.info("1000");
				   detailCustReqRecordCounts = 1000; 
			   }
			   else if(detailCustReqRecordCounts == 1500){
				   LOG.info("1500");
				   detailCustReqRecordCounts = 1500; 
			   }
			   else if(detailCustReqRecordCounts == 2000){
				   LOG.info("2000");
				   detailCustReqRecordCounts = 2000; 
			   }
			   else if(detailCustReqRecordCounts == 3000){
				   LOG.info("3000");
				   detailCustReqRecordCounts = 3000; 
			   }
			   else if(detailCustReqRecordCounts == 4000){
				   LOG.info("4000");
				   detailCustReqRecordCounts = 4000; 
			   }else if(detailCustReqRecordCounts == 5000){
				   LOG.info("5000");
				   detailCustReqRecordCounts = 5000; 
			   }
			   else if(detailCustReqRecordCounts == productConfSmryList.size()){
				   LOG.info("All");
				   detailCustReqRecordCounts = productConfSmryList.size(); 
			   }
			   LOG.info("final value.....--------------------------->"+detailCustReqRecordCounts);
		   }
		 
			/**
			 * This method is used for changeCustReqRecordsListner
			 * 
			 * @param event
			 */
		 public void changeCustReqRecordsListner(ActionEvent event){
			   LOG.info("Action listner called.....--------------------------->"+detailPrdContRecordCounts);
			   if(detailPrdContRecordCounts == 100){
				   LOG.info("100");
				   detailPrdContRecordCounts = PLMConstants.N_100;
			   }else if(detailPrdContRecordCounts == 500){
				   LOG.info("500");
				   detailPrdContRecordCounts = 500; 
			   }
			   else if(detailPrdContRecordCounts == 1000){
				   LOG.info("1000");
				   detailPrdContRecordCounts = 1000; 
			   }
			   else if(detailPrdContRecordCounts == 1500){
				   LOG.info("1500");
				   detailPrdContRecordCounts = 1500; 
			   }
			   else if(detailPrdContRecordCounts == 2000){
				   LOG.info("2000");
				   detailPrdContRecordCounts = 2000; 
			   }
			   else if(detailPrdContRecordCounts == 3000){
				   LOG.info("3000");
				   detailPrdContRecordCounts = 3000; 
			   }
			   else if(detailPrdContRecordCounts == 4000){
				   LOG.info("4000");
				   detailPrdContRecordCounts = 4000; 
			   }else if(detailPrdContRecordCounts == 5000){
				   LOG.info("5000");
				   detailPrdContRecordCounts = 5000; 
			   }
			   else if(detailPrdContRecordCounts == customerSmryList.size()){
				   LOG.info("All");
				   detailPrdContRecordCounts = customerSmryList.size(); 
			   }
			   LOG.info("final value.....--------------------------->"+detailRecordCounts);
		   }
		
   
		   /**
			 * This method is used for getIsWasPartsReport
			 * 
			 * @return String
		 * @throws PWiException 
			 */
		 public String getIsWasPartsReport() throws PLMCommonException, PWiException{
				LOG.info("Entering getIsWasPartsReport Method");
				String fwdFlag = "prjchngSearch";
				
				 if(totalRecCount==1){
					LOG.info("if totcostChgCount is single record" );
					contractSel = prjChngHdrList.get(0).getContract();
					LOG.info("contractSel  single record"+contractSel);
				  }
				    
					 if(totalRecCount !=0) {
						 alertMessage =  PLMConstants.ISWASPARTS_MAIL_ALERT_MSG;
						 
						 userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
						 
						 LOG.info("Mail send succesfulyy");
						taskExecutor.execute(new MailThread());
					     } 
			 	
				LOG.info("Exiting getIsWasPartsReport Method");
				return fwdFlag;
			}
		 
		 /**
			 * Background Process Thread
			 */
			private class MailThread implements Runnable {
				public MailThread(){}
				public void run() {
					sendIsWasPartsReportThroughMail();
				}
			}
			
			
			
			/**
			 * This method is used for Generating & Sending the Report to mail
			 * 
			 * @return String
			 */
			public void sendIsWasPartsReportThroughMail() {
				LOG.info("Entering sendIsWasPartsReportThroughMail Method");
				
				LOG.info("contractName>>>>>>>"+contractName);
				if (contractName!=null) {
				String from = PLMConstants.ISWASPARTS_MAIL_FROM;
				
				String to = userDetails.getUserEmailId();		
				String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
				toAddressee = "Dear " + toAddressee + ", \n\n";
				String subject = PLMConstants.ISWASPARTS_MAIL_SUBJECT + contractSel;
				StringBuffer mailBody = new StringBuffer().append(toAddressee)
				.append(PLMConstants.ISWASPARTS_MAIL_CONTENT)
				.append(contractSel)
				.append(".")
				.append(PLMConstants.ISWASPARTS_MAIL_SIGNATURE)
				.append(PLMConstants.ISWASPARTS_MAIL_FOOTER);
				
				StringBuffer mailNoDataBody = new StringBuffer()
				.append(toAddressee)
				.append(PLMConstants.ISWASPARTS_NO_CONTENT_BODY)
				.append(contractSel)
				.append(".")
				.append(PLMConstants.ISWASPARTS_MAIL_SIGNATURE)
				.append(PLMConstants.ISWASPARTS_MAIL_FOOTER);
				
				final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
				Date uniqDate = new Date();
				String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
				String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
				String filePathXlsx = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("IS_WAS_PARTS_REPORT_NAME") +  contractSel + "_" + uniqTime + ".xlsx";
				String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("IS_WAS_PARTS_REPORT_NAME") +  contractSel + "_" + uniqTime + ".zip";
				File file = null;
				try {
					List<PLMIswasParts> isWasPartsRptList = plmMetricsService.getIsWasPartsReport(contractSel);
					
					if (isWasPartsRptList!=null && isWasPartsRptList.size()>0) {
						saveIsWasPartsXLSXFile(contractSel,isWasPartsRptList,fileDir,filePathXlsx);
						PLMUtils.generateZipFile(filePathXlsx,filePathZip);
						file = new File(filePathZip);
						// Get the number of bytes in the file
						float sizeInBytes = file.length();
						//transform in MB
						float sizeInMb = sizeInBytes / (1024 * 1024);
						LOG.info("Zip File Size for Is Was  Parts Report "+sizeInMb+" MB");
						PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
						LOG.info("Report Attachment Mail sent successfully.");
						isWasPartsRptList.clear();
					} else {				
						PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
						LOG.info("No data Mail sent successfully.");
					}
				} catch (PLMCommonException exception) {
					LOG.log(Level.ERROR, "Exception@sendIsWasPartsReportThroughMail: ", exception);
					PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.ISWASPARTS_MAIL_SIGNATURE);
				} catch (Exception exception) {
					LOG.log(Level.ERROR, "Exception@sendIsWasPartsReportThroughMail: ", exception);
					PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.ISWASPARTS_MAIL_SIGNATURE);
				} finally {
					deleteFiles(filePathXlsx,filePathZip);
					/*if (file!=null)
						file.delete();*/
				}
				LOG.info("Exiting sendIsWasPartsReportThroughMail Method");
				} else {
					LOG.info("Not able to generate the report. The Contract Number selected is "+contractSel);
				}
			}
			
			/**
			 * This method is used for Generating Project Change Summary - Related Issue Report in CSV
			 * 
			 * @throws PLMCommonException
			 */
			
			public void createDownloadRICSV() throws PLMCommonException {
				LOG.info("Entering createDownloadRICSV Method");
				String fileName = "PrjChgSummary";
				
				PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
				SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
				
				//Export to  CSV for Project Summary Report
				PLMCsvRptColumn[] reportColumns =
								new PLMCsvRptColumn[] {new PLMCsvRptColumn("contract", "Contract", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("serialNumber", "Serial Number", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("issueName", "Issue Name", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("issueCategory", "Issue Category", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("issueStatus", "Issue Status", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("buildName", "HW Build", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("buildState", "HW Build State", FormatTypeCsv.TEXT)
								};
				
				csvUtil.exportCsv(prjChngHdrList, reportColumns, fileName, dateFormat, false, null, null, ",");
				LOG.info("Exiting createDownloadRICSV Method");
			}
			
			/**
			 * This method is used for Generating Project Change Summary - Associated ECRs/ECOs Report in CSV
			 * 
			 * @throws PLMCommonException
			 */
			
			public void createDownloadAEECSV() throws PLMCommonException {
				LOG.info("Entering createDownloadAEECSV Method");
				String fileName = "PrjChgSmryDtls";
				
				PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
				SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
				
				//Export to  CSV for Project Summary Report
				PLMCsvRptColumn[] reportColumns =
								new PLMCsvRptColumn[] {new PLMCsvRptColumn("topLvlPrntPrjChng", "Top Level Part", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("parentPart", "Parent Part", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("childPart", "Child Part", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("childPartDesc", "Child Part Desc", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("partType", "Part Type", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("partRev", "Part Rev", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("partStatus", "Part Status", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("childPartDate", "Date of Child Part State", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecrName", "ECR", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecrDescPrjChng", "ECR Description", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoCtgChng", "ECO Category Change", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoSev", "ECO Severity", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoName", "ECO", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoSubst", "ECO Substantiation", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoDesc", "ECO Description", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoFastTrack", "ECO Fast Track", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecrStatus", "ECR Status", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoStatus", "ECO Status", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("requestedChange", "Requested Change", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("dispInField", "Disp. IN FEILD", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("dispInProcess", "Disp. IN PROCESS", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("dispInStock", "Disp. IN STOCK", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("dispOnOrder", "Disp. ON ORDER", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoPolicy", "ECO Policy", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("impactStmt", "CLS_I_IMPACT_STMT_TXT", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("bomMarkup", "BOM Markup", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("bomMarkupType", "BOM Markup Type", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("rdo", "RDO of the Part", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecrCategoryChng", "ECR Category Change", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecrOrig", "ECR Orig", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecrOrigName", "ECR Orig Name", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecrRespDesign", "ECR Resp Design", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecrRespDesignName", "ECR Resp Design Name", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecrModifiedDate", "ECR Modifed Date", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoModifiedDate", "ECO Modifed Date", FormatTypeCsv.TEXT),
								};
				PLMCsvRptColumn[] critcolumns = 
						new PLMCsvRptColumn[] {new PLMCsvRptColumn("contractDtl", "Contract Selected", FormatTypeCsv.TEXT),
						                       new PLMCsvRptColumn("topParts", "Top Level Product Parts Associated", FormatTypeCsv.TEXT)
						};
				csvUtil.exportCsv(prjChngDtlList, reportColumns, fileName, dateFormat, true, critcolumns, prjChngDtlData, ",");
				LOG.info("Exiting createDownloadAEECSV Method");
			}
			
			/**
			 * This method is used for Bordering Cell in XLSX
			 * 
			 * @return StringBuffer
			 */
			private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
				style.setBorderTop(XSSFCellStyle.BORDER_THIN);
				style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
				style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
				style.setBorderRight(XSSFCellStyle.BORDER_THIN);
				return style;
			}
			/**
			 * This method is used for Generating Report in XLS
			 * 
			 * @param contractSelLcl,isWasPartsRptList,fileDir,filePathXlsx
			 * @return StringBuffer
			 * @throws IOException
			 */
			
			public void saveIsWasPartsXLSXFile(String contractSelLcl,
					List<PLMIswasParts> isWasPartsRptList,
					String fileDir,String filePathXlsx) throws IOException {
				LOG.info("Entering saveIsWasPartsXLSXFile File Method");
				FileOutputStream fileOut = null;
				boolean createFileExist;
				try {
					/*File file = new File(fileDir);
					boolean dirExists = file.exists();
					if (!dirExists) {	
						file.mkdir();
					}*/
					File fileName = new File(filePathXlsx);
					boolean fileExist = fileName.exists();
					if(!fileExist) {
						createFileExist =fileName.createNewFile();
						LOG.info("createFileExist>>>>.."+createFileExist);
				 	}
					if (fileName.exists()) {
						fileOut = new FileOutputStream(filePathXlsx);
						SXSSFWorkbook workbook = new SXSSFWorkbook();
						SXSSFSheet sheet =  (SXSSFSheet) workbook.createSheet("Is_Was Parts");
						XSSFCellStyle headerStyle = (XSSFCellStyle) workbook.createCellStyle();
						
						headerStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
						headerStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
						headerStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
						headerStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
						headerStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex()); 
						headerStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
						XSSFFont font = (XSSFFont) workbook.createFont(); 
						font.setFontName(PLMConstants.EXCEL_FONT_NAME);
						font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
						font.setFontHeightInPoints((short)10);
						headerStyle.setFont(font);
						headerStyle = setBorderStyle(headerStyle);
						
						XSSFCellStyle cellBoldStyle = (XSSFCellStyle) workbook.createCellStyle();
						cellBoldStyle = setBorderStyle(cellBoldStyle);
						cellBoldStyle.setFont(font);
						
						XSSFFont nonBoldFont = (XSSFFont) workbook.createFont();
						nonBoldFont.setFontHeightInPoints((short)10);
						nonBoldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
						XSSFCellStyle contentStyle = (XSSFCellStyle) workbook.createCellStyle();				
						contentStyle = setBorderStyle(contentStyle);
						contentStyle.setFont(nonBoldFont);
						XSSFCellStyle contentDecimalStyle = (XSSFCellStyle) workbook.createCellStyle();				
						contentDecimalStyle = setBorderStyle(contentDecimalStyle);
						contentDecimalStyle.setFont(nonBoldFont);
						DataFormat format = workbook.createDataFormat();
						contentDecimalStyle.setDataFormat(format.getFormat("0.00000"));
								
						XSSFFont noRecordFont = (XSSFFont) workbook.createFont(); 
						noRecordFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
						noRecordFont.setColor(Font.COLOR_RED);
						noRecordFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
						noRecordFont.setFontHeightInPoints((short)10);
						XSSFCellStyle noRecordCellStyle = (XSSFCellStyle) workbook.createCellStyle();
						noRecordCellStyle = setBorderStyle(noRecordCellStyle);
						noRecordCellStyle.setFont(noRecordFont);

						CreationHelper createHelper = workbook.getCreationHelper();

						XSSFCellStyle dateStyle = (XSSFCellStyle) workbook.createCellStyle();
						
						dateStyle.setDataFormat(
					        createHelper.createDataFormat().getFormat("mm/dd/yyyy"));
						
						dateStyle = setBorderStyle(contentStyle);		
						dateStyle.setFont(nonBoldFont);
						
						XSSFCellStyle currencyStyle = (XSSFCellStyle) workbook.createCellStyle();
					    XSSFDataFormat df = (XSSFDataFormat) workbook.createDataFormat();
					    currencyStyle.setDataFormat(df.getFormat("$#,##0.00"));
					    currencyStyle = setBorderStyle(currencyStyle);		
					    currencyStyle.setFont(nonBoldFont);

					    XSSFCellStyle dateStyle1 = (XSSFCellStyle) workbook.createCellStyle();
						dateStyle1.setDataFormat(createHelper.createDataFormat().getFormat("m/d/yy h:mm"));
						dateStyle1 = setBorderStyle(contentStyle);
						dateStyle1.setFont(nonBoldFont);
						
						int rowcount = -1;
						
						if(!PLMUtils.isEmptyList(isWasPartsRptList)) {
							
							String[] colNames = {
									"Top Level Part","LVL_ONE_PARENT_NAME","LVL_ONE_PARENT_REV","AFFCT_ITEM_NAME","AFFCT_ITEM_REV",
									"AFFCT_ITEM_LVL","PARENT_PART","GE_BOM_PREFIX","WAS_PART_NAME","WAS_PART_REV","WAS_GE_COPICS_PARENT",
									"WAS_BOM_QUANTITY","IS_PART_NAME","IS_PART_REV","IS_PART_STATE","IS_GE_COPICS_PARENT","IS_BOM_QUANTITY",
									"ECR","ECR DESCRIPTION","ECO CATEGORY CHANGE","ECO SEVERITY","ECO","ECO SUBSTANTIATION","ECO DESCRITPION",
									"ECO FAST TRACK","ECR STATUS","ECO STATUS","REQUESTED CHANGE","DISP.IN FEILD","DISP. IN PROCESS",
									"DISP. IN STOCK","DISP. ON ORDER","ECO POLICY","CLS_I_IMPACT_STMT_TXT","BOM MARKUP","BOM MARKUP TYPE",
									"RDO","ECR CAGTEGORY CHANGE","ECR ORIG","ECR ORIG NAME","ECR RESP DESIGN","ECR RESP DESIGN NAME",
									"ECR MODIFIED DATE","ECO MODIFIED DATE"};

							SXSSFRow row = (SXSSFRow)sheet.createRow(++rowcount);
							SXSSFCell cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell.setCellValue(PLMConstants.ISWASPARTS_SEARCH_CRITERIA_MLNO);
							cell.setCellStyle(cellBoldStyle);

							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellValue(contractSelLcl);
							cell.setCellStyle(cellBoldStyle);
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							for ( int i = 0 ; i < colNames.length; i++ ) {
								cell = (SXSSFCell)  row.createCell(i);
								cell. setCellValue(colNames[i]);
								cell.setCellStyle(headerStyle);
							}
							for(int i = 0; i < isWasPartsRptList.size(); i++) {
								PLMIswasParts dataObj = (PLMIswasParts) isWasPartsRptList.get(i);
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ZERO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getTopLevelPrnt());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getLvlOneParentName());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getLvlOneParentRev());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THREE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getAffectItmName());

								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOUR);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getAffectItmRev());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIVE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getAffectItmLvl());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SIX);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getParentPart());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SEVEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getGeBomPrefix());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_EIGHT);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getWasPartName());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_NINE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getWasPartRev());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getWasGeCopicParent());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getWasBomQty());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWELVE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getIsPartName());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getIsPartRev());
								
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
								cell.setCellStyle(dateStyle1);
								
								DateFormat dateFormat1 = new SimpleDateFormat("MM/dd/yyyy HH:mm aa");
								if(dataObj.getIsPartStateDate()!=null){
									cell.setCellValue(dateFormat1.format(dataObj.getIsPartStateDate()));
								}else{
									cell.setCellValue("");
								}
								
		
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getIsGeCopicParent());
								
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getIsBomQty());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
									cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEcr());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_EIGHTEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEcrDescIwp());
								
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_NINETEEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEcoCtgryChange());
									
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTY);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEcoSeverity());
								
							
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYONE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEco());
									
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYTWO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEcoSubst());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYTHREE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEcoDesc());
								
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYFOUR);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEcoFastTrack());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYFIVE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEcrStatus());
								
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYSIX);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEcoStatus());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYSEVEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getRequestChange());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYEIGHT);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getDispInFeild());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYNINE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getDispInProcess());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTY);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getDispInStock());
								
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYONE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getDispOnOrder());
								
							
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYTWO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEcoPolicy());
								
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYTHREE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getClsImpactStmtTxt());
								
							
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYFOUR);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getBomMarkup());
									
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYFIVE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getBomMarkupType());
								
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYSIX);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getRdo());
									
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYSEVEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEcrCtgryChange());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYEIGHT);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEcrOrig());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTYNINE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEcrOrigName());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTY);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEcrRespDesign());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTYONE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getEcrRespDesignName());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTYTWO);
								cell.setCellStyle(dateStyle1);
								
								if(dataObj.getEcrModifedDate()!=null){
									cell.setCellValue(dateFormat1.format(dataObj.getEcrModifedDate()));
								}else{
									cell.setCellValue("");
								}
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTYTHREE);
								cell.setCellStyle(dateStyle1);
								
								if(dataObj.getEcoModifedDate()!=null){
									cell.setCellValue(dateFormat1.format(dataObj.getEcoModifedDate()));
								}else{
									cell.setCellValue("");
								}
									
							}
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							row = (SXSSFRow) sheet.createRow(++rowcount);
						short colWidth = (short)6400;
						short colWidth1 = (short)6700;
						short colWidth2 = (short)7000;
						short colWidth3 = (short)7200;
						short colWidth4 = (short)7900;
						short colWidth5 = (short)8600;
										
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,colWidth4);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,colWidth2);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,colWidth1);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,colWidth2);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,colWidth2);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,colWidth3);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWELVE,colWidth3);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTEEN,colWidth3);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTEEN,colWidth3);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTEEN,colWidth3);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIXTEEN,colWidth5);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVENTEEN,colWidth5);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHTEEN,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINETEEN,colWidth2);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTY,colWidth2);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYONE,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYTWO,colWidth4);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYTHREE,colWidth4);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYFOUR,colWidth5);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYFIVE,colWidth5);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYSIX,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYSEVEN,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYEIGHT,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYNINE,colWidth2);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTY,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYONE,colWidth1);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYTWO,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYTHREE,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYFOUR,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYFIVE,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYSIX,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYSEVEN,colWidth1);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYEIGHT,colWidth4);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYNINE,colWidth2);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTY,colWidth3);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYONE,colWidth);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYTWO,colWidth5);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTYTHREE,colWidth);

							
						} else {
							LOG.info("There is no record found for " + contractSelLcl+" in method saveIsWasPartsXLSXFile File");
							SXSSFRow row = (SXSSFRow) sheet.createRow(++rowcount);
							SXSSFCell cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							String noRecordMsg = PLMConstants.ISWASPARTS_NO_RECORD_FOUND + contractSelLcl;
							cell.setCellValue(noRecordMsg);
							cell.setCellStyle(noRecordCellStyle);
							sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
						}	
						workbook.write(fileOut);
						fileOut.close();
					}
				} catch (FileNotFoundException e) {
					LOG.log(Level.ERROR, "Exception@saveIsWasPartsXLSXFile File: ", e);
					throw e;
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@saveIsWasPartsXLSXFile File: ", e);
					throw e;
				}  finally {
					try {
						if (fileOut != null) {
							fileOut.close();
						}
					} catch (IOException e) {
						LOG.log(Level.ERROR, "Exception@saveIsWasPartsXLSXFile: ", e);
						throw e;
					}
				}
				LOG.info("Exiting saveIsWasPartsXLSXFile File Method");
			}
			/**
			 * This method is used for Deleting zip file and xls file
			 * 
			 *@param filePathXls,filePathZip
			 */
			public void deleteFiles(String filePathXls,String filePathZip){
				LOG.info("Entering deleteFiles method");
				boolean zipFileExist;
				boolean xlsFileExist;
				File zipFile = new File(filePathZip);
				zipFileExist = zipFile.exists();
				File xlsFile = new File(filePathXls);
				xlsFileExist = xlsFile.exists();
				if(zipFileExist){
					boolean deleted = zipFile.delete();
					LOG.info("Successfully deleted zip file : " + deleted);
				}
				if(xlsFileExist){
					boolean deleted = xlsFile.delete();
					LOG.info("Successfully deleted xls file : " + deleted);
				}
				LOG.info("Exiting deleteFiles Method");
			}
			
			
			/**
			 * This method is used for generating zip file
			 * 
			 *@param filePathXls,filePathZip
			 *@throws IOException
			 */
			/*public void generateZipFile(String filePathXls,String filePathZip) throws IOException {
				LOG.info("Entering generateZipFile method");
				FileOutputStream fileOut = null;
				BufferedOutputStream bufferOut = null;
				ZipOutputStream zipOut = null;
				BufferedInputStream bufferIn = null;
				FileInputStream fileIn = null;
				File xlsFile = new File(filePathXls); 
				try {
					fileOut = new FileOutputStream(filePathZip);
					bufferOut = new BufferedOutputStream(fileOut);
					zipOut = new ZipOutputStream(bufferOut);
					fileIn = new FileInputStream(filePathXls);
					bufferIn = new BufferedInputStream(fileIn);
					int count;
					byte[] data = new byte[1000];
					zipOut.putNextEntry(new ZipEntry(xlsFile.getName()));
					while((count = fileIn.read(data,0,1000)) != -1){  
					zipOut.write(data, 0, count);
					}
					bufferIn.close();
					zipOut.flush();
					zipOut.close();
		   		   }catch (FileNotFoundException e) {
					 LOG.log(Level.ERROR, "Exception@generateZipFile: ", e);
					 throw e;
				   }catch (IOException e) {
					 LOG.log(Level.ERROR, "Exception@generateZipFile: ", e);
					 throw e;
				   }finally {
						try {
							if (bufferOut != null) {
								bufferOut.close();
							}
							if (zipOut != null) {
								zipOut.close();
							}
							if (fileOut != null) {
								fileOut.close();
							}
							if (fileIn != null) {
								fileIn.close();
							}
							if (bufferIn != null) {
								bufferIn.close();
							}
						} catch (IOException e) {
							LOG.log(Level.ERROR, "Exception@generateZipFile: ", e);
							throw e;
						}
					}
				LOG.info("Exiting generateZipFile Method");
			}*/
			
			public void downloadExcel() throws PLMCommonException {

				LOG.info("Entering downloadExcel Method");
				String reportName = "ProjectRoutTaskReport";
				String fileName = "ProjectRoutTaskReport";
				LOG.info("reportName>>> " + reportName);
				LOG.info("fileName>>> " + fileName);
				
				PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
				
				//Export to Excel for project Route Task Report
				
				PLMXlsxRptColumn[] critcolumns  = new PLMXlsxRptColumn[] {
		                new PLMXlsxRptColumn("dueDateFromProject", "Due Date From", FormatType.DATE),
		                new PLMXlsxRptColumn("dueDateToProject", "Due Date To", FormatType.DATE),
		                new PLMXlsxRptColumn("prjNamesExcel", "Project", FormatType.TEXT),
		                new PLMXlsxRptColumn("policyTask", "Policy of Task", FormatType.TEXT),
		                new PLMXlsxRptColumn("statusProjectExcel", "Status", FormatType.TEXT),
		                new PLMXlsxRptColumn("voucherFundingSource", "Voucher Funding Source", FormatType.TEXT)
		                };
					
					PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
							  new PLMXlsxRptColumn("prjName", "Project", FormatType.TEXT, null, null, 26),
							  new PLMXlsxRptColumn("prjTaskCount", "Project Task", FormatType.TEXT, null, null, 26),
							  new PLMXlsxRptColumn("routeTaskCount", "Route Task", FormatType.TEXT),
							  new PLMXlsxRptColumn("summaryCount", "Summary", FormatType.TEXT)
					};
					
					excelUtil.export(searchResultListProject, reportColumns, fileName, fileName, true, critcolumns, projectTaskData);	
				
					LOG.info("Exiting downloadExcel Method");
			} 
			
			public void downloadCSV() throws PLMCommonException {

				LOG.info("Entering downloadCSV Method");
				String fileName = "ProjectRoutTaskReport";
				LOG.info("fileName>>> " + fileName);
				
				PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
				SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
				
				//Export to CSV for project Route Task Report
				PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
							  new PLMCsvRptColumn("prjName", "Project", FormatTypeCsv.TEXT),
							  new PLMCsvRptColumn("prjTaskCount", "Project Task", FormatTypeCsv.INTEGER),
							  new PLMCsvRptColumn("routeTaskCount", "Route Task", FormatTypeCsv.INTEGER),
							  new PLMCsvRptColumn("summaryCount", "Summary", FormatTypeCsv.INTEGER)
					};
				
		      csvUtil.exportCsv(searchResultListProject, reportColumns, fileName, dateFormat, false, null, null, ",");
			  LOG.info("Exiting downloadCSV Method");
			}
			
	/**
	 * @return the taskMetricsService
	 */
	public PLMTaskMetricsServiceIfc getTaskMetricsService() {
		return taskMetricsService;
	}

	/**
	 * @param taskMetricsService the taskMetricsService to set
	 */
	public void setTaskMetricsService(PLMTaskMetricsServiceIfc taskMetricsService) {
		this.taskMetricsService = taskMetricsService;
	}

	/**
	 * @return the projectTaskData
	 */
	public PLMProjectTaskData getProjectTaskData() {
		return projectTaskData;
	}

	/**
	 * @param projectTaskData the projectTaskData to set
	 */
	public void setProjectTaskData(PLMProjectTaskData projectTaskData) {
		this.projectTaskData = projectTaskData;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the dropDownListProject
	 */
	public Map<String, List<SelectItem>> getDropDownListProject() {
		return dropDownListProject;
	}

	/**
	 * @param dropDownListProject the dropDownListProject to set
	 */
	public void setDropDownListProject(
			Map<String, List<SelectItem>> dropDownListProject) {
		this.dropDownListProject = dropDownListProject;
	}

	/**
	 * @return the dropDownListStatus
	 */
	public Map<String, List<SelectItem>> getDropDownListStatus() {
		return dropDownListStatus;
	}

	/**
	 * @param dropDownListStatus the dropDownListStatus to set
	 */
	public void setDropDownListStatus(
			Map<String, List<SelectItem>> dropDownListStatus) {
		this.dropDownListStatus = dropDownListStatus;
	}

	/**
	 * @return the statusList
	 */
	public List<SelectItem> getStatusList() {
		return statusList;
	}

	/**
	 * @param statusList the statusList to set
	 */
	public void setStatusList(List<SelectItem> statusList) {
		this.statusList = statusList;
	}

	/**
	 * @return the projectList
	 */
	public List<SelectItem> getProjectList() {
		return projectList;
	}

	/**
	 * @param projectList the projectList to set
	 */
	public void setProjectList(List<SelectItem> projectList) {
		this.projectList = projectList;
	}

	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @param recordCounts the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}

	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/**
	 * @return the totalRecCountMsg
	 */
	public String getTotalRecCountMsg() {
		return totalRecCountMsg;
	}

	/**
	 * @param totalRecCountMsg the totalRecCountMsg to set
	 */
	public void setTotalRecCountMsg(String totalRecCountMsg) {
		this.totalRecCountMsg = totalRecCountMsg;
	}

	/**
	 * @return the searchResultListProject
	 */
	public List<PLMProjectTaskData> getSearchResultListProject() {
		return searchResultListProject;
	}

	/**
	 * @param searchResultListProject the searchResultListProject to set
	 */
	public void setSearchResultListProject(
			List<PLMProjectTaskData> searchResultListProject) {
		this.searchResultListProject = searchResultListProject;
	}

	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}

	/**
	 * @return the plmTaskSearchMB
	 */
	public PLMTaskSearchMB getPlmTaskSearchMB() {
		return plmTaskSearchMB;
	}

	/**
	 * @param plmTaskSearchMB the plmTaskSearchMB to set
	 */
	public void setPlmTaskSearchMB(PLMTaskSearchMB plmTaskSearchMB) {
		this.plmTaskSearchMB = plmTaskSearchMB;
	}

	/**
	 * @return the selectedPrjName
	 */
	public String getSelectedPrjName() {
		return selectedPrjName;
	}

	/**
	 * @param selectedPrjName the selectedPrjName to set
	 */
	public void setSelectedPrjName(String selectedPrjName) {
		this.selectedPrjName = selectedPrjName;
	}

	/**
	 * @return the prjTaskType
	 */
	public String getPrjTaskType() {
		return prjTaskType;
	}

	/**
	 * @param prjTaskType the prjTaskType to set
	 */
	public void setPrjTaskType(String prjTaskType) {
		this.prjTaskType = prjTaskType;
	}

	public PLMMetricsServiceIfc getPlmMetricsService() {
		return plmMetricsService;
	}

	public void setPlmMetricsService(PLMMetricsServiceIfc plmMetricsService) {
		this.plmMetricsService = plmMetricsService;
	}

	/**
	 * @return the prjChngHdrList
	 */
	public List<PLMProjChngData> getPrjChngHdrList() {
		return prjChngHdrList;
	}

	/**
	 * @param prjChngHdrList the prjChngHdrList to set
	 */
	public void setPrjChngHdrList(List<PLMProjChngData> prjChngHdrList) {
		this.prjChngHdrList = prjChngHdrList;
	}
	
	/**
	 * @return the contractSessValue
	 */
	public String getContractSessValue() {
		return contractSessValue;
	}

	/**
	 * @param contractSessValue the contractSessValue to set
	 */
	public void setContractSessValue(String contractSessValue) {
		this.contractSessValue = contractSessValue;
	}

	/**
	 * @return the prjChngDtlList
	 */
	public List<PLMProjChngDtlData> getPrjChngDtlList() {
		return prjChngDtlList;
	}

	/**
	 * @param prjChngDtlList the prjChngDtlList to set
	 */
	public void setPrjChngDtlList(List<PLMProjChngDtlData> prjChngDtlList) {
		this.prjChngDtlList = prjChngDtlList;
	}

	/**
	 * @return the totalDetailRecCount
	 */
	public int getTotalDetailRecCount() {
		return totalDetailRecCount;
	}

	/**
	 * @param totalDetailRecCount the totalDetailRecCount to set
	 */
	public void setTotalDetailRecCount(int totalDetailRecCount) {
		this.totalDetailRecCount = totalDetailRecCount;
	}

	/**
	 * @return the totalDetailRecCountMsg
	 */
	public String getTotalDetailRecCountMsg() {
		return totalDetailRecCountMsg;
	}

	/**
	 * @param totalDetailRecCountMsg the totalDetailRecCountMsg to set
	 */
	public void setTotalDetailRecCountMsg(String totalDetailRecCountMsg) {
		this.totalDetailRecCountMsg = totalDetailRecCountMsg;
	}

	/**
	 * @return the detailRecordCounts
	 */
	public int getDetailRecordCounts() {
		return detailRecordCounts;
	}

	/**
	 * @param detailRecordCounts the detailRecordCounts to set
	 */
	public void setDetailRecordCounts(int detailRecordCounts) {
		this.detailRecordCounts = detailRecordCounts;
	}

	/**
	 * @return the contractValues
	 */
	public UIDataTable getContractValues() {
		return contractValues;
	}

	/**
	 * @param contractValues the contractValues to set
	 */
	public void setContractValues(UIDataTable contractValues) {
		this.contractValues = contractValues;
	}

	

	/**
	 * @return the prjSumaryRecordCounts
	 */
	public int getPrjSumaryRecordCounts() {
		return prjSumaryRecordCounts;
	}

	/**
	 * @return the contractName
	 */
	public String getContractName() {
		return contractName;
	}

	/**
	 * @param contractName the contractName to set
	 */
	public void setContractName(String contractName) {
		this.contractName = contractName;
	}

	/**
	 * @param prjSumaryRecordCounts the prjSumaryRecordCounts to set
	 */
	public void setPrjSumaryRecordCounts(int prjSumaryRecordCounts) {
		this.prjSumaryRecordCounts = prjSumaryRecordCounts;
	}

	/**
	 * @return the contractSel
	 */
	public String getContractSel() {
		return contractSel;
	}

	/**
	 * @param contractSel the contractSel to set
	 */
	public void setContractSel(String contractSel) {
		this.contractSel = contractSel;
	}

	/**
	 * @return the prjHmSrchFlag
	 */
	public boolean isPrjHmSrchFlag() {
		return prjHmSrchFlag;
	}

	/**
	 * @param prjHmSrchFlag the prjHmSrchFlag to set
	 */
	public void setPrjHmSrchFlag(boolean prjHmSrchFlag) {
		this.prjHmSrchFlag = prjHmSrchFlag;
	}

	/**
	 * @return the prjSumyFlag
	 */
	public boolean isPrjSumyFlag() {
		return prjSumyFlag;
	}

	/**
	 * @param prjSumyFlag the prjSumyFlag to set
	 */
	public void setPrjSumyFlag(boolean prjSumyFlag) {
		this.prjSumyFlag = prjSumyFlag;
	}

	/**
	 * @return the contractDtl
	 */
	public String getContractDtl() {
		return contractDtl;
	}

	/**
	 * @param contractDtl the contractDtl to set
	 */
	public void setContractDtl(String contractDtl) {
		this.contractDtl = contractDtl;
	}

	/**
	 * @return the topParts
	 */
	public String getTopParts() {
		return topParts;
	}

	/**
	 * @param topParts the topParts to set
	 */
	public void setTopParts(String topParts) {
		this.topParts = topParts;
	}

	/**
	 * @return the dropdownlist
	 */
	/*public Map<String, List<SelectItem>> getDropdownlist() {
		return dropdownlist;
	}*/

	/**
	 * @param dropdownlist the dropdownlist to set
	 */
	/*public void setDropdownlist(Map<String, List<SelectItem>> dropdownlist) {
		this.dropdownlist = dropdownlist;
	}*/

	/**
	 * @return the rdoList
	 */
	public List<SelectItem> getRdoList() {
		return rdoList;
	}

	/**
	 * @param rdoList the rdoList to set
	 */
	public void setRdoList(List<SelectItem> rdoList) {
		this.rdoList = rdoList;
	}


	/**
	 * @return the prjChngDtlData
	 */
	public PLMProjChngDtlData getPrjChngDtlData() {
		return prjChngDtlData;
	}

	/**
	 * @param prjChngDtlData the prjChngDtlData to set
	 */
	public void setPrjChngDtlData(PLMProjChngDtlData prjChngDtlData) {
		this.prjChngDtlData = prjChngDtlData;
	}

	/**
	 * @return the ecrCtgryList
	 */
	public List<SelectItem> getEcrCtgryList() {
		return ecrCtgryList;
	}

	/**
	 * @param ecrCtgryList the ecrCtgryList to set
	 */
	public void setEcrCtgryList(List<SelectItem> ecrCtgryList) {
		this.ecrCtgryList = ecrCtgryList;
	}

	/**
	 * @return the ecrStateList
	 */
	public List<SelectItem> getEcrStateList() {
		return ecrStateList;
	}

	/**
	 * @param ecrStateList the ecrStateList to set
	 */
	public void setEcrStateList(List<SelectItem> ecrStateList) {
		this.ecrStateList = ecrStateList;
	}

	/**
	 * @return the ecoStateList
	 */
	public List<SelectItem> getEcoStateList() {
		return ecoStateList;
	}

	/**
	 * @param ecoStateList the ecoStateList to set
	 */
	public void setEcoStateList(List<SelectItem> ecoStateList) {
		this.ecoStateList = ecoStateList;
	}

	/**
	 * @return the plmProductData
	 */
	public PLMProductConfData getPlmProductData() {
		return plmProductData;
	}

	/**
	 * @param plmProductData the plmProductData to set
	 */
	public void setPlmProductData(PLMProductConfData plmProductData) {
		this.plmProductData = plmProductData;
	}

	/**
	 * @return the prdcontractName
	 */
	public String getPrdcontractName() {
		return prdcontractName;
	}

	/**
	 * @param prdcontractName the prdcontractName to set
	 */
	public void setPrdcontractName(String prdcontractName) {
		this.prdcontractName = prdcontractName;
	}
	/**
	 * @return the prdConfList
	 */
	public List<SelectItem> getPrdConfList() {
		return prdConfList;
	}

	/**
	 * @param prdConfList the prdConfList to set
	 */
	public void setPrdConfList(List<SelectItem> prdConfList) {
		this.prdConfList = prdConfList;
	}

	/**
	 * @return the prdCnfFlag
	 */
	public boolean isPrdCnfFlag() {
		return prdCnfFlag;
	}

	/**
	 * @param prdCnfFlag the prdCnfFlag to set
	 */
	public void setPrdCnfFlag(boolean prdCnfFlag) {
		this.prdCnfFlag = prdCnfFlag;
	}

	/**
	 * @return the productConfSmryList
	 */
	public List<PLMProductConfData> getProductConfSmryList() {
		return productConfSmryList;
	}

	/**
	 * @param productConfSmryList the productConfSmryList to set
	 */
	public void setProductConfSmryList(List<PLMProductConfData> productConfSmryList) {
		this.productConfSmryList = productConfSmryList;
	}

	/**
	 * @return the totalPrdContRecCountMsg
	 */
	public String getTotalPrdContRecCountMsg() {
		return totalPrdContRecCountMsg;
	}

	/**
	 * @param totalPrdContRecCountMsg the totalPrdContRecCountMsg to set
	 */
	public void setTotalPrdContRecCountMsg(String totalPrdContRecCountMsg) {
		this.totalPrdContRecCountMsg = totalPrdContRecCountMsg;
	}

	/**
	 * @return the detailPrdContRecordCounts
	 */
	public int getDetailPrdContRecordCounts() {
		return detailPrdContRecordCounts;
	}

	/**
	 * @param detailPrdContRecordCounts the detailPrdContRecordCounts to set
	 */
	public void setDetailPrdContRecordCounts(int detailPrdContRecordCounts) {
		this.detailPrdContRecordCounts = detailPrdContRecordCounts;
	}

	/**
	 * @return the totalPrdContRecCount
	 */
	public int getTotalPrdContRecCount() {
		return totalPrdContRecCount;
	}

	/**
	 * @param totalPrdContRecCount the totalPrdContRecCount to set
	 */
	public void setTotalPrdContRecCount(int totalPrdContRecCount) {
		this.totalPrdContRecCount = totalPrdContRecCount;
	}

	/**
	 * @return the getPrdSummaryData
	 */
	public Map<String, List<PLMProductConfData>> getGetPrdSummaryData() {
		return getPrdSummaryData;
	}

	/**
	 * @param getPrdSummaryData the getPrdSummaryData to set
	 */
	public void setGetPrdSummaryData(
			Map<String, List<PLMProductConfData>> getPrdSummaryData) {
		this.getPrdSummaryData = getPrdSummaryData;
	}

	/**
	 * @return the customerSmryList
	 */
	public List<PLMProductConfData> getCustomerSmryList() {
		return customerSmryList;
	}

	/**
	 * @param customerSmryList the customerSmryList to set
	 */
	public void setCustomerSmryList(List<PLMProductConfData> customerSmryList) {
		this.customerSmryList = customerSmryList;
	}

	/**
	 * @return the totalCustReqRecCountMsg
	 */
	public String getTotalCustReqRecCountMsg() {
		return totalCustReqRecCountMsg;
	}

	/**
	 * @param totalCustReqRecCountMsg the totalCustReqRecCountMsg to set
	 */
	public void setTotalCustReqRecCountMsg(String totalCustReqRecCountMsg) {
		this.totalCustReqRecCountMsg = totalCustReqRecCountMsg;
	}

	/**
	 * @return the detailCustReqRecordCounts
	 */
	public int getDetailCustReqRecordCounts() {
		return detailCustReqRecordCounts;
	}

	/**
	 * @param detailCustReqRecordCounts the detailCustReqRecordCounts to set
	 */
	public void setDetailCustReqRecordCounts(int detailCustReqRecordCounts) {
		this.detailCustReqRecordCounts = detailCustReqRecordCounts;
	}

	/**
	 * @return the totalCustReqRecCount
	 */
	public int getTotalCustReqRecCount() {
		return totalCustReqRecCount;
	}

	/**
	 * @param totalCustReqRecCount the totalCustReqRecCount to set
	 */
	public void setTotalCustReqRecCount(int totalCustReqRecCount) {
		this.totalCustReqRecCount = totalCustReqRecCount;
	}

	/**
	 * @return the prdConfDataFlag
	 */
	public boolean isPrdConfDataFlag() {
		return prdConfDataFlag;
	}

	/**
	 * @param prdConfDataFlag the prdConfDataFlag to set
	 */
	public void setPrdConfDataFlag(boolean prdConfDataFlag) {
		this.prdConfDataFlag = prdConfDataFlag;
	}

	/**
	 * @return the custReqDataFlag
	 */
	public boolean isCustReqDataFlag() {
		return custReqDataFlag;
	}

	/**
	 * @param custReqDataFlag the custReqDataFlag to set
	 */
	public void setCustReqDataFlag(boolean custReqDataFlag) {
		this.custReqDataFlag = custReqDataFlag;
	}

	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return the isWasParts
	 */
	public PLMIswasParts getIsWasParts() {
		return isWasParts;
	}

	/**
	 * @param isWasParts the isWasParts to set
	 */
	public void setIsWasParts(PLMIswasParts isWasParts) {
		this.isWasParts = isWasParts;
	}

	

	
	
	
	
}