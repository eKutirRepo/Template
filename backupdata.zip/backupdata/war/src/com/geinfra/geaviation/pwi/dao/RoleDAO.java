package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.PWiRoleVO;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 5, 2010 Security : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Data access object for object types.
 * 
 * Revision Log Aug 5, 2010 | v1.0. --------------------------------------------------------------
 */
public interface RoleDAO {

	// public List<PWiRoleVO> findPWiQiRoles();
	public List<PWiRoleVO> findPWiRolesForGroups(List<String> groups);


	public List<PWiRoleVO> findAllPWiRoles();


	// Shows List of Roles
	public PWiRoleVO getRoleById(Integer roleId); // Edit the Role with Role ID


	public int checkNames(String roleNm, String roleDesc);


	public int checkNamesEdit(String roleNm, String roleDesc, Integer roleSeqId);


	public void updateRole(PWiRoleVO role);


	public int createNewRole(String roleNm, String roleDesc,String roleType, String userID);


	public List<PWiRoleVO> findSelectedRolesForUser(Integer userId) throws PWiException;


	public void addRolesForUser(List<Integer> groupIdsToAddForObjectType, Integer objectTypeId);


	public void deleteRolesForUser(List<Integer> roleIdsToRemoveForUser, Integer userId);


	public void addGroupsForRole(List<Integer> groupIdsToAddForRole, Integer roleId, String sso);


	public void deleteGroupsForRole(List<Integer> groupIdsToRemoveForRole, Integer roleId);


	public void deleteRole(Integer roleSeqId);


	public List<String> getRoleTypelistList();


}



/*
 * public int checkNamesEdit(String objTypNm, String roleDesc, Integer roleSeqId);
 * 
 * public int checkNames(String objTypNm, String objTypDesc);
 * 
 * public Integer createNewRole(final String roleName, final String roleDesc, final boolean shwInQi,
 * final String sso);
 * 
 * public void updateRole(PWiRoleVO objectType, String sso);
 * 
 * public List<PWiRoleVO> findSelectedRolesForUser(Integer userId) throws PWiException;
 * 
 * public void addRolesForUser(List<Integer> groupIdsToAddForObjectType, Integer objectTypeId,
 * String sso);
 * 
 * public void deleteRolesForUser(List<Integer> roleIdsToRemoveForUser, Integer userId);
 */



