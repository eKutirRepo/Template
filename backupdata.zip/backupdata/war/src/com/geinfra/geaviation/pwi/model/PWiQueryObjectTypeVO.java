package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;

import com.geinfra.geaviation.pwi.json.JsonBuilder;
import com.geinfra.geaviation.pwi.json.Jsonable;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : JSONable, minimal version of PWiQueryObjectVO
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiQueryObjectTypeVO extends PWiBaseVO implements Serializable,
		Jsonable {
	private static final long serialVersionUID = 1L;

	private Integer queryId;
	private Integer objectTypeId;

	public Integer getQueryId() {
		return queryId;
	}

	public void setQueryId(Integer queryId) {
		this.queryId = queryId;
	}

	public Integer getObjectTypeId() {
		return objectTypeId;
	}

	public void setObjectTypeId(Integer objectTypeId) {
		this.objectTypeId = objectTypeId;
	}

	public String toJson() {
		JsonBuilder builder = new JsonBuilder();
		builder.startObject();
		builder.addStringProperty("queryId", queryId);
		builder.addStringProperty("objectTypeId", objectTypeId);
		builder.endObject();
		return builder.toString();
	}
}
