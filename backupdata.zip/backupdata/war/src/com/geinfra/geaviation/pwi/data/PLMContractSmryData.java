/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMContractSmryData.java
 * @Creation date: 12-Aug-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;


public class PLMContractSmryData {
	
	/**
	 *  Holds the hwPrdctNm
	 */
	private String hwPrdctNm;
	/**
	 *  Holds the prdtConfigNm
	 */
	private String prdtConfigNm;
	/**
	 *  Holds the prdtConfigDesc
	 */
	private String prdtConfigDesc;
	/**
	 *  Holds the isOption
	 */
	private String isOption;
	/**
	 * Holds subComponent
	 */
	private String subComponent;
	/**
	 * Holds checkBoxSel
	 */
	private boolean checkBoxSel;
	/**
	 * Holds shpOrdrNumOnScrn
	 */
	private String shpOrdrNumOnScrn;
	/**
	 * Holds pcCstGrp
	 */
	private String pcCstGrp;


	
	/**
	 * @return the hwPrdctNm
	 */
	public String getHwPrdctNm() {
		return hwPrdctNm;
	}
	/**
	 * @param hwPrdctNm the hwPrdctNm to set
	 */
	public void setHwPrdctNm(String hwPrdctNm) {
		this.hwPrdctNm = hwPrdctNm;
	}
	/**
	 * @return the prdtConfigNm
	 */
	public String getPrdtConfigNm() {
		return prdtConfigNm;
	}
	/**
	 * @param prdtConfigNm the prdtConfigNm to set
	 */
	public void setPrdtConfigNm(String prdtConfigNm) {
		this.prdtConfigNm = prdtConfigNm;
	}
	/**
	 * @return the prdtConfigDesc
	 */
	public String getPrdtConfigDesc() {
		return prdtConfigDesc;
	}
	/**
	 * @param prdtConfigDesc the prdtConfigDesc to set
	 */
	public void setPrdtConfigDesc(String prdtConfigDesc) {
		this.prdtConfigDesc = prdtConfigDesc;
	}
	
	/**
	 * @return the subComponent
	 */
	public String getSubComponent() {
		return subComponent;
	}
	/**
	 * @param subComponent the subComponent to set
	 */
	public void setSubComponent(String subComponent) {
		this.subComponent = subComponent;
	}
	/**
	 * @return the checkBoxSel
	 */
	public boolean isCheckBoxSel() {
		return checkBoxSel;
	}
	/**
	 * @param checkBoxSel the checkBoxSel to set
	 */
	public void setCheckBoxSel(boolean checkBoxSel) {
		this.checkBoxSel = checkBoxSel;
	}
	/**
	 * @return the shpOrdrNumOnScrn
	 */
	public String getShpOrdrNumOnScrn() {
		return shpOrdrNumOnScrn;
	}
	/**
	 * @param shpOrdrNumOnScrn the shpOrdrNumOnScrn to set
	 */
	public void setShpOrdrNumOnScrn(String shpOrdrNumOnScrn) {
		this.shpOrdrNumOnScrn = shpOrdrNumOnScrn;
	}
	/**
	 * @return
	 */
	public String getIsOption() {
		return isOption;
	}
	/**
	 * @param isOption
	 */
	public void setIsOption(String isOption) {
		this.isOption = isOption;
	}
	
	/**
	 * @return the pcCstGrp
	 */
	public String getPcCstGrp() {
		return pcCstGrp;
	}
	
	/**
	 * @param pcCstGrp the pcCstGrp to set
	 */
	public void setPcCstGrp(String pcCstGrp) {
		this.pcCstGrp = pcCstGrp;
	}
	
}
