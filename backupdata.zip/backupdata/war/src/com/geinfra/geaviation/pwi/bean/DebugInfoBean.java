package com.geinfra.geaviation.pwi.bean;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;

/**
* 
 * Project : Product Lifecycle Management Intelligence
* Date Written : March 29, 2013
* Security : GE Confidential
* Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
* 
 * Copyright(C) 2013 GE All rights reserved
* 
 * Description : DebugInfoBean - bean for displaying various technical
*                                                                            information for debugging purposes.
* 
 * Revision Log March 19, 2013 | v1.0.
* --------------------------------------------------------------
*/

public class DebugInfoBean extends BaseBean {
                public String getHostname() throws PWiException, IOException {
                                /*byte[] bytes = new byte[100];
                                Runtime.getRuntime().exec("hostname").getInputStream().read(bytes);*/
                                //Corrected as per Nimble report error on 31-Oct-2014
                                
                                                Runtime run = null;
                                                Process proc = null;
                                                BufferedReader br = null;
                                                StringBuffer line=new StringBuffer("");
                                try{
                                                run = Runtime.getRuntime();
                                                proc = run.exec("hostname");
                                                br = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                                                String rdLine;
                                                while((rdLine = br.readLine()) != null){ 
                                                	line.append(rdLine);
                                                                
                                                }
                                                
                                }
                                finally
                                {
                                	if (br!=null)
                                		br.close();
                                }
                                
                                return line.toString();
                }
}
