/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMAeroReportMB.java
 * @Creation date: 06-Apr-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMAeroRptData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMCompleteEbomReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMAeroReportMB {
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMAeroReportMB.class);
	/**
	 * Holds the alertLogAeroMessage
	 */
	private String alertLogAeroMessage;

	/**
	 * Holds the logHardWarePrdNmList
	 */
	private List<SelectItem> logHardWarePrdNmList = new ArrayList<SelectItem>();
	/**
	 * Holds the logHardWarePrd
	 */
	private String logHardWarePrd;
	/**
	 * Holds the logRevisionList
	 */
	private List<SelectItem> logRevisionList = new ArrayList<SelectItem>();
	/**
	/**
	 * Holds the logRevision
	 */
	private String logRevision;
	/**
	 * Holds the alertConfAeroMessage
	 */
	private String alertConfAeroMessage;
	/**
	 * Holds the confHardWarePrdNmList
	 */
	private List<SelectItem> confHardWarePrdNmList = new ArrayList<SelectItem>();
	/**
	 * Holds the confHardWarePrd
	 */
	private String confHardWarePrd;
	/**
	 * Holds the confRevisionList
	 */
	private List<SelectItem> confRevisionList = new ArrayList<SelectItem>();
	/**
	/**
	 * Holds the confRevision
	 */
	private String confRevision;
	/**
	 * Holds the commonMB
	 */
	private PLMCommonMB commonMB;

	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	/**
	 * Holds user information
	 */
	private PLMPwiUserData userDetails = null;

	/**
	 * Holds the plmCompleteEbomReportService
	 */
	private PLMCompleteEbomReportServiceIfc plmCompleteEbomReportService = null;
	/**
	 * Holds the resourceBundle
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	
	//Added for Logical Features
	/**
	 * This method is used for Loading Logical Feature Home Page
	 * @return String
	 */
	public String loadLogicalFeaturePage() {
		LOG.info("Entering loadLogicalFeaturePage Method");
		alertLogAeroMessage = "";
		String fwdFlag = "";
		try {
			commonMB.insertCannedRptRecordHitInfo("Logical Features Report");
			logHardWarePrdNmList =plmCompleteEbomReportService.getHardwareProductNames();
			logHardWarePrd ="";
			logRevision = "";
			logRevisionList = new ArrayList<SelectItem>();
			fwdFlag ="areoLogicaReportSrch";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadLogicalFeaturePage: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Logical Features Report");
		} 
		LOG.info("Exiting loadLogicalFeaturePage Method");
		return fwdFlag;
	}

	/**
	 * This method is used for getLogRevisionNames
	 * 
	 */
	public String getLogRevisionNames() {
		LOG.info("Entering getLogRevisionNames() Method");
		logRevisionList = new ArrayList<SelectItem>();
		alertLogAeroMessage = "";
		String fwdflag = "areoLogicaReportSrch";
		try {
			if(!PLMUtils.isEmpty(logHardWarePrd)){
				logRevisionList = plmCompleteEbomReportService.getRevisionNames(logHardWarePrd);
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getLogRevisionNames: ", exception);
		} 
		LOG.info("Exiting getLogRevisionNames() Method");
		return fwdflag;
	}
	/**
	 * This method is used for reset Logical Feature Home Page
	 * @return String
	 */
	public String resetLogicalFeaturePage() {
		LOG.info("Entering resetLogicalFeaturePage Method");
		alertLogAeroMessage = "";
		String fwdFlag = "";
		logHardWarePrd ="";
		logRevision = "";
		logRevisionList = new ArrayList<SelectItem>();
		fwdFlag ="areoLogicaReportSrch";
		LOG.info("Exiting resetLogicalFeaturePage Method");
		return fwdFlag;
	}

	/**
	 * This method is used for Generating Logical Features Report
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String generateLogicalFeatureRpt() throws PWiException {
		LOG.info("Entering generateLogicalFeatureRpt Method");
		String fwdflag = "areoLogicaReportSrch";
		alertLogAeroMessage = "";
		alertLogAeroMessage = validateLogData();
		userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		if (PLMUtils.isEmpty(alertLogAeroMessage)) {
			alertLogAeroMessage =  PLMConstants.LOGICAL_FTR_MAIL_ALERT_MSG;
			 taskExecutor.execute(new MailThread1());
		}
		LOG.info("Exiting generateLogicalFeatureRpt Method");
		return fwdflag;
	}
	
	/**
	 * This method is used for validateLogData
	 * 
	 * @return String
	 */
	public String validateLogData() {
		LOG.info("Entering validateLogData Method");
		String alertMsg = "";
		if(PLMUtils.isEmpty(logHardWarePrd) || PLMUtils.isEmpty(logRevision)){
			alertMsg = PLMConstants.AERO_SEARCH_CRITERIA;
		} 
		LOG.info("Exiting validateLogData Method");
		return alertMsg;
	}

	/**
	 * Background Process Thread
	 */
	private class MailThread1 implements Runnable {
		public MailThread1(){}
		public void run() {
			sendLogicalFeatureRptMail();
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return void
	 */
	public void sendLogicalFeatureRptMail() {
		LOG.info("Entering sendLogicalFeatureRptMail Method");
		String hardWarePrdLcl =logHardWarePrd;
		String revisionLcl =logRevision;
		String from = PLMConstants.OMM_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.LOGICAL_FTR_SUBJECT;
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("LOGICAL_FEATURE_REPORT_NAME") + "_" + uniqTime + ".xlsx";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("LOGICAL_FEATURE_REPORT_NAME") + "_" + uniqTime + ".zip";
		try {
			Map<String,Object> logicaFeatureMap  = plmCompleteEbomReportService.getLogicalFeatureData(hardWarePrdLcl,revisionLcl);
			List<PLMAeroRptData> logicalFeatureList =(List<PLMAeroRptData>) logicaFeatureMap.get("logicalFeaturesList");
			int maxLevelCnt = (Integer) logicaFeatureMap.get("maxLvl");
			StringBuffer mailBody = new StringBuffer().append(toAddressee);
			if(PLMUtils.isEmptyList(logicalFeatureList)){
				mailBody.append(PLMConstants.LOGICAL_FTR_MAIL_CONTENT_NO_RECORD);
				mailBody.append("Hardware Product :" +hardWarePrdLcl+"\n")
				.append("Revision :" +revisionLcl)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				PLMUtils.sendMail(from, to, subject, mailBody.toString());
			} else {
				mailBody.append(PLMConstants.LOGICAL_FTR_MAIL_CONTENT);
				mailBody.append("Hardware Product :" +hardWarePrdLcl+"\n")
				.append("Revision :" +revisionLcl)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				saveLogicalFeatureXLSFile(maxLevelCnt,hardWarePrdLcl,revisionLcl,logicalFeatureList,fileDir,filePathXls);
				PLMUtils.generateZipFile(filePathXls,filePathZip);
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendLogicalFeatureRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendLogicalFeatureRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} finally {
			PLMUtils.deleteFiles(filePathXls,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendLogicalFeatureRptMail Method");
	}

	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return void
	 */
	
	public void saveLogicalFeatureXLSFile(int maxLvlCntLcl,String hardWarePrdLcl,String revisionLcl,
					List<PLMAeroRptData> logicalFeatureLstLcl,String fileDir,String filePathXls) throws IOException {
		LOG.info("Entering saveLogicalFeatureXLSFile Method");
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXls);
				SXSSFWorkbook workbook = new SXSSFWorkbook();
				
				// Start : POI Styles
				XSSFCellStyle headerStyle = (XSSFCellStyle) workbook.createCellStyle();
				headerStyle.setFillForegroundColor(HSSFColor.BLACK.index);
				headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
				
				XSSFFont headerFont = (XSSFFont) workbook.createFont(); 
				headerFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				headerFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headerFont.setFontHeightInPoints((short)9);
				headerFont.setFontName("GE Inspira");
				headerFont.setColor(IndexedColors.WHITE.getIndex());
				headerStyle.setFont(headerFont);
				
				XSSFCellStyle searchFieldNameStyle = (XSSFCellStyle) workbook.createCellStyle();
				searchFieldNameStyle = setBorderStyle(searchFieldNameStyle);
				searchFieldNameStyle.setAlignment(CellStyle.ALIGN_LEFT);
				
				XSSFFont boldFont = (XSSFFont) workbook.createFont();
				boldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				boldFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				boldFont.setFontHeightInPoints((short)9);
				boldFont.setFontName("GE Inspira");
				boldFont.setColor(IndexedColors.BLACK.getIndex());
				searchFieldNameStyle.setFont(boldFont);
				
				XSSFFont cellstyleFont = (XSSFFont)workbook.createFont(); 
				cellstyleFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				
				cellstyleFont.setFontHeightInPoints((short)9);
				cellstyleFont.setFontName("GE Inspira");
				cellstyleFont.setColor(IndexedColors.BLACK.getIndex());
				
				XSSFCellStyle contentStyle = (XSSFCellStyle) workbook.createCellStyle();
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(cellstyleFont);
				
				XSSFFont font = (XSSFFont) workbook.createFont(); 
				font.setFontName(PLMConstants.EXCEL_FONT_NAME);
				font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				font.setFontHeightInPoints((short)9);
				font.setFontName("GE Inspira");
				
				XSSFCellStyle cellBoldStyle = (XSSFCellStyle) workbook.createCellStyle();
				cellBoldStyle = setBorderStyle(cellBoldStyle);
				cellBoldStyle.setFont(font);

				// End : POI Styles
				
				SXSSFRow row = null;
				SXSSFCell cell = null;
				SXSSFSheet sheet =  null;
				
				int rowcount = -1;
				if(!PLMUtils.isEmptyList(logicalFeatureLstLcl)) {
						rowcount = -1;
						sheet = (SXSSFSheet) workbook.createSheet("Logical Features");
						// To display Search Criteria 
						row = (SXSSFRow) sheet.createRow(++rowcount);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						cell.setCellValue("Hardware Product");
						cell.setCellStyle(searchFieldNameStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellValue(hardWarePrdLcl);
						cell.setCellStyle(contentStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellValue("");
						
						row = (SXSSFRow) sheet.createRow(++rowcount);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						cell.setCellValue("Revision");
						cell.setCellStyle(searchFieldNameStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellValue(revisionLcl);
						cell.setCellStyle(contentStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellValue("");
						
						// One Row Space
						row = (SXSSFRow) sheet.createRow(++rowcount);
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellStyle(headerStyle);
						cell. setCellValue("Level");
						
						int colHdrNum=1;
						
						for(int lvl=1;lvl<=maxLvlCntLcl;lvl++){
							cell = (SXSSFCell) row.createCell(colHdrNum++);
							cell.setCellStyle(headerStyle);
							cell. setCellValue(lvl);
						}
							//Header
							String[] colNames = {"Name","Type","Display Text","Owner","Design Responsibility","State","F/N","Quantity",
									"Reference Designator","Component Location","Usage","Rule Type"};
							
							for ( int i = 0 ; i < colNames.length; i++ ) {
								cell = (SXSSFCell) row.createCell(colHdrNum++);
								cell.setCellStyle(headerStyle);
								cell. setCellValue(colNames[i]);
							}
							//Header
							for(int i = 0; i < logicalFeatureLstLcl.size(); i++) {
								PLMAeroRptData dataObj = (PLMAeroRptData) logicalFeatureLstLcl.get(i);
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getLevel());
								
								colHdrNum=1;
								for(int lvl=1;lvl<=maxLvlCntLcl;lvl++){
									cell = (SXSSFCell) row.createCell(colHdrNum++);
									cell.setCellStyle(contentStyle);
									cell. setCellValue("");
								}
								
								int colDataNum=maxLvlCntLcl+1;
								
								cell = (SXSSFCell) row.createCell(dataObj.getLevel());
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getDisplayNm());
								
								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getChildName());
								
								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getType());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getDisplayText());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getOwner());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getDesignResponse());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getState());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getFindNum());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getQuantity());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getReferenceDesign());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getComponentLoc());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getUsage());
								
								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getRuleType());
								
							}//end of for loop logicalFeatureLstLcl
						}//end of if isEmptyList(logicalFeatureLstLcl)

						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,4000);
						int colHdrNum=1;
						for(int lvl=1;lvl<=maxLvlCntLcl;lvl++){
						sheet.setColumnWidth(colHdrNum++,6000);
						}
						int colDataNum=maxLvlCntLcl+1;
						
						sheet.setColumnWidth(colDataNum++,6000);
						sheet.setColumnWidth(colDataNum++,4000);
						sheet.setColumnWidth(colDataNum++,8000);
						sheet.setColumnWidth(colDataNum++,4000);
						sheet.setColumnWidth(colDataNum++,6000);
						sheet.setColumnWidth(colDataNum++,3000);
						sheet.setColumnWidth(colDataNum++,3000);
						sheet.setColumnWidth(colDataNum++,3000);
						sheet.setColumnWidth(colDataNum++,6000);
						sheet.setColumnWidth(colDataNum++,6000);
						sheet.setColumnWidth(colDataNum++,3000);
						sheet.setColumnWidth(colDataNum++,3000);
						sheet.createFreezePane( 0, 4 );
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveLogicalFeatureXLSFile: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveLogicalFeatureXLSFile: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveLogicalFeatureXLSFile: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveLogicalFeatureXLSFile Method");
	}
	
	//Added for Configuration Features
	/**
	 * This method is used for Loading configuration Feature Home Page
	 * @return String
	 */
	public String loadConfigFeaturePage() {
		LOG.info("Entering loadConfigFeaturePage Method");
		alertConfAeroMessage = "";
		String fwdFlag = "";
		try {
			commonMB.insertCannedRptRecordHitInfo("Configuration Features Report");
			confHardWarePrdNmList =plmCompleteEbomReportService.getHardwareProductNames();
			confHardWarePrd ="";
			confRevision = "";
			confRevisionList = new ArrayList<SelectItem>();
			fwdFlag ="areoConfigFeatureSrch";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadConfigFeaturePage: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Configuration Features Report");
		} 
		LOG.info("Exiting loadConfigFeaturePage Method");
		return fwdFlag;
	}

	/**
	 * This method is used for getConfRevisionNames
	 * 
	 */
	public String getConfRevisionNames() {
		LOG.info("Entering getConfRevisionNames() Method");
		confRevisionList = new ArrayList<SelectItem>();
		alertConfAeroMessage = "";
		String fwdflag = "areoConfigFeatureSrch";
		try {
			if(!PLMUtils.isEmpty(confHardWarePrd)){
				confRevisionList = plmCompleteEbomReportService.getRevisionNames(confHardWarePrd);
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getRevisionNames: ", exception);
		} 
		LOG.info("Exiting getConfRevisionNames() Method");
		return fwdflag;
	}
	/**
	 * This method is used for reset configuration Feature Home Page
	 * @return String
	 */
	public String resetConfigFeaturePage() {
		LOG.info("Entering resetConfigFeaturePage Method");
		alertConfAeroMessage = "";
		String fwdFlag = "";
		confHardWarePrd ="";
		confRevision = "";
		confRevisionList = new ArrayList<SelectItem>();
		fwdFlag ="areoConfigFeatureSrch";
		LOG.info("Exiting resetConfigFeaturePage Method");
		return fwdFlag;
	}
	/**
	 * This method is used for Generating Configuration Features Report
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String generateConfigFeatureRpt() throws PWiException {
		LOG.info("Entering generateConfigFeatureRpt Method");
		String fwdflag = "areoConfigFeatureSrch";
		alertConfAeroMessage = "";
		alertConfAeroMessage = validateConfData();
		userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		if (PLMUtils.isEmpty(alertConfAeroMessage)) {
			alertConfAeroMessage =  PLMConstants.CONF_FTR_MAIL_ALERT_MSG;
			 taskExecutor.execute(new MailThread2());
		}
		LOG.info("Exiting generateConfigFeatureRpt Method");
		return fwdflag;
	}
	/**
	 * This method is used for validateLogData
	 * 
	 * @return String
	 */
	public String validateConfData() {
		LOG.info("Entering validateConfData Method");
		String alertMsg = "";
		if(PLMUtils.isEmpty(confHardWarePrd) || PLMUtils.isEmpty(confRevision)){
			alertMsg = PLMConstants.AERO_SEARCH_CRITERIA;
		} 
		LOG.info("Exiting validateConfData Method");
		return alertMsg;
	}

	/**
	 * Background Process Thread
	 */
	private class MailThread2 implements Runnable {
		public MailThread2(){}
		public void run() {
			sendConfFeatureRptMail();
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return void
	 */
	public void sendConfFeatureRptMail() {
		LOG.info("Entering sendConfFeatureRptMail Method");
		String hardWarePrdLcl =confHardWarePrd;
		String revisionLcl =confRevision;
		String from = PLMConstants.OMM_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.CONF_FTR_SUBJECT;
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("CONFIG_FEATURE_REPORT_NAME") + "_" + uniqTime + ".xlsx";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("CONFIG_FEATURE_REPORT_NAME") + "_" + uniqTime + ".zip";
		try {
			List<PLMAeroRptData> confFeatureList =plmCompleteEbomReportService.getConfigFeatureData(hardWarePrdLcl,revisionLcl);
			StringBuffer mailBody = new StringBuffer().append(toAddressee);
			if(PLMUtils.isEmptyList(confFeatureList)){
				mailBody.append(PLMConstants.CONF_FTR_MAIL_CONTENT_NO_RECORD);
				mailBody.append("Hardware Product :" +hardWarePrdLcl+"\n")
				.append("Revision :" +revisionLcl)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				PLMUtils.sendMail(from, to, subject, mailBody.toString());
			} else {
				mailBody.append(PLMConstants.CONF_FTR_MAIL_CONTENT);
				mailBody.append("Hardware Product :" +hardWarePrdLcl+"\n")
				.append("Revision :" +revisionLcl)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				saveConfFeatureXLSFile(hardWarePrdLcl,revisionLcl,confFeatureList,fileDir,filePathXls);
				PLMUtils.generateZipFile(filePathXls,filePathZip);
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendConfFeatureRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendConfFeatureRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} finally {
			PLMUtils.deleteFiles(filePathXls,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendConfFeatureRptMail Method");
	}

	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return void
	 */
	
	public void saveConfFeatureXLSFile(String hardWarePrdLcl,String revisionLcl,
					List<PLMAeroRptData> confFeatureLstLcl,String fileDir,String filePathXls) throws IOException {
		LOG.info("Entering saveConfFeatureXLSFile Method");
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXls);
				SXSSFWorkbook workbook = new SXSSFWorkbook();
				
				// Start : POI Styles
				XSSFCellStyle headerStyle = (XSSFCellStyle) workbook.createCellStyle();
				headerStyle.setFillForegroundColor(HSSFColor.BLACK.index);
				headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
				
				XSSFFont headerFont = (XSSFFont) workbook.createFont(); 
				headerFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				headerFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headerFont.setFontHeightInPoints((short)9);
				headerFont.setFontName("GE Inspira");
				headerFont.setColor(IndexedColors.WHITE.getIndex());
				headerStyle.setFont(headerFont);
				
				XSSFCellStyle searchFieldNameStyle = (XSSFCellStyle) workbook.createCellStyle();
				searchFieldNameStyle = setBorderStyle(searchFieldNameStyle);
				searchFieldNameStyle.setAlignment(CellStyle.ALIGN_LEFT);
				
				XSSFFont boldFont = (XSSFFont) workbook.createFont();
				boldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				boldFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				boldFont.setFontHeightInPoints((short)9);
				boldFont.setFontName("GE Inspira");
				boldFont.setColor(IndexedColors.BLACK.getIndex());
				searchFieldNameStyle.setFont(boldFont);
				
				XSSFFont cellstyleFont = (XSSFFont)workbook.createFont(); 
				cellstyleFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				
				cellstyleFont.setFontHeightInPoints((short)9);
				cellstyleFont.setFontName("GE Inspira");
				cellstyleFont.setColor(IndexedColors.BLACK.getIndex());
				
				XSSFCellStyle contentStyle = (XSSFCellStyle) workbook.createCellStyle();
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(cellstyleFont);
				
				XSSFFont font = (XSSFFont) workbook.createFont(); 
				font.setFontName(PLMConstants.EXCEL_FONT_NAME);
				font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				font.setFontHeightInPoints((short)9);
				font.setFontName("GE Inspira");
				
				XSSFCellStyle cellBoldStyle = (XSSFCellStyle) workbook.createCellStyle();
				cellBoldStyle = setBorderStyle(cellBoldStyle);
				cellBoldStyle.setFont(font);

				// End : POI Styles
				
				SXSSFRow row = null;
				SXSSFCell cell = null;
				SXSSFSheet sheet =  null;
				
				int rowcount = -1;
				if(!PLMUtils.isEmptyList(confFeatureLstLcl)) {
						rowcount = -1;
						sheet = (SXSSFSheet) workbook.createSheet("Configuration Features");
						// To display Search Criteria 
						row = (SXSSFRow) sheet.createRow(++rowcount);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						cell.setCellValue("Hardware Product");
						cell.setCellStyle(searchFieldNameStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellValue(hardWarePrdLcl);
						cell.setCellStyle(contentStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellValue("");
						
						row = (SXSSFRow) sheet.createRow(++rowcount);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						cell.setCellValue("Revision");
						cell.setCellStyle(searchFieldNameStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellValue(revisionLcl);
						cell.setCellStyle(contentStyle);
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellValue("");
						
						// One Row Space
						row = (SXSSFRow) sheet.createRow(++rowcount);
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellStyle(headerStyle);
						cell. setCellValue("Level");
						
						int colHdrNum=1;
						
						for(int lvl=1;lvl<=3;lvl++){
							cell = (SXSSFCell) row.createCell(colHdrNum++);
							cell.setCellStyle(headerStyle);
							cell. setCellValue(lvl);
						}
							//Header
							String[] colNames = {"Name","Type","State","Display Text","Seq No","Default Selection","Single/Multiple","Must/May",
									"Key in Type","Rule Type","List Price","Min Qty","Max Qty","Owner","Design Responsibility"};
							
							for ( int i = 0 ; i < colNames.length; i++ ) {
								cell = (SXSSFCell) row.createCell(colHdrNum++);
								cell.setCellStyle(headerStyle);
								cell. setCellValue(colNames[i]);
							}
							//Header
							for(int i = 0; i < confFeatureLstLcl.size(); i++) {
								PLMAeroRptData dataObj = (PLMAeroRptData) confFeatureLstLcl.get(i);
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getLevel());
								
								colHdrNum=1;
								for(int lvl=1;lvl<=3;lvl++){
									cell = (SXSSFCell) row.createCell(colHdrNum++);
									cell.setCellStyle(contentStyle);
									cell. setCellValue("");
								}
								
								int colDataNum=3+1;
								
								cell = (SXSSFCell) row.createCell(dataObj.getLevel());
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getConfDisplyNmRev());
								
								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getConfName());
								
								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getConfType());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getConfState());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getConfdisplayTxt());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getSeqNo());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getDefaultSel());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getSingleMultiple());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getMustMay());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getKeyinType());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getConfRuleType());

								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getListPrice());
								
								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getMinQty());
								
								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getMaxQty());
								
								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getConfOwner());
								
								cell = (SXSSFCell) row.createCell(colDataNum++);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getConfDesignResp());
								
							}//end of for loop logicalFeatureLstLcl
						}//end of if isEmptyList(logicalFeatureLstLcl)

						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,4000);
						int colHdrNum=1;
						for(int lvl=1;lvl<=3;lvl++){
						sheet.setColumnWidth(colHdrNum++,6000);
						}
						int colDataNum=3+1;
						
						sheet.setColumnWidth(colDataNum++,5000);
						sheet.setColumnWidth(colDataNum++,5000);
						sheet.setColumnWidth(colDataNum++,3000);
						sheet.setColumnWidth(colDataNum++,8000);
						sheet.setColumnWidth(colDataNum++,2000);
						sheet.setColumnWidth(colDataNum++,4000);
						sheet.setColumnWidth(colDataNum++,4000);
						sheet.setColumnWidth(colDataNum++,3000);
						sheet.setColumnWidth(colDataNum++,3000);
						sheet.setColumnWidth(colDataNum++,3000);
						sheet.setColumnWidth(colDataNum++,3000);
						sheet.setColumnWidth(colDataNum++,3000);
						sheet.setColumnWidth(colDataNum++,3000);
						sheet.setColumnWidth(colDataNum++,4000);
						sheet.setColumnWidth(colDataNum++,8000);
						sheet.createFreezePane( 0, 4 );
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveConfFeatureXLSFile: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveConfFeatureXLSFile: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveConfFeatureXLSFile: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveConfFeatureXLSFile Method");
	}

	/**
	 * This method is used for Bordering Cell in XLS
	 * 
	 * @return XSSFCellStyle
	 */
	
	private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
		style.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style.setBorderRight(XSSFCellStyle.BORDER_THIN);
		return style;
	}

	/**
	 * @return the alertLogAeroMessage
	 */
	public String getAlertLogAeroMessage() {
		return alertLogAeroMessage;
	}

	/**
	 * @param alertLogAeroMessage the alertLogAeroMessage to set
	 */
	public void setAlertLogAeroMessage(String alertLogAeroMessage) {
		this.alertLogAeroMessage = alertLogAeroMessage;
	}

	/**
	 * @return the logHardWarePrdNmList
	 */
	public List<SelectItem> getLogHardWarePrdNmList() {
		return logHardWarePrdNmList;
	}

	/**
	 * @param logHardWarePrdNmList the logHardWarePrdNmList to set
	 */
	public void setLogHardWarePrdNmList(List<SelectItem> logHardWarePrdNmList) {
		this.logHardWarePrdNmList = logHardWarePrdNmList;
	}

	/**
	 * @return the logHardWarePrd
	 */
	public String getLogHardWarePrd() {
		return logHardWarePrd;
	}

	/**
	 * @param logHardWarePrd the logHardWarePrd to set
	 */
	public void setLogHardWarePrd(String logHardWarePrd) {
		this.logHardWarePrd = logHardWarePrd;
	}

	/**
	 * @return the logRevisionList
	 */
	public List<SelectItem> getLogRevisionList() {
		return logRevisionList;
	}

	/**
	 * @param logRevisionList the logRevisionList to set
	 */
	public void setLogRevisionList(List<SelectItem> logRevisionList) {
		this.logRevisionList = logRevisionList;
	}

	/**
	 * @return the logRevision
	 */
	public String getLogRevision() {
		return logRevision;
	}

	/**
	 * @param logRevision the logRevision to set
	 */
	public void setLogRevision(String logRevision) {
		this.logRevision = logRevision;
	}

	/**
	 * @return the alertConfAeroMessage
	 */
	public String getAlertConfAeroMessage() {
		return alertConfAeroMessage;
	}

	/**
	 * @param alertConfAeroMessage the alertConfAeroMessage to set
	 */
	public void setAlertConfAeroMessage(String alertConfAeroMessage) {
		this.alertConfAeroMessage = alertConfAeroMessage;
	}

	/**
	 * @return the confHardWarePrdNmList
	 */
	public List<SelectItem> getConfHardWarePrdNmList() {
		return confHardWarePrdNmList;
	}

	/**
	 * @param confHardWarePrdNmList the confHardWarePrdNmList to set
	 */
	public void setConfHardWarePrdNmList(List<SelectItem> confHardWarePrdNmList) {
		this.confHardWarePrdNmList = confHardWarePrdNmList;
	}

	/**
	 * @return the confHardWarePrd
	 */
	public String getConfHardWarePrd() {
		return confHardWarePrd;
	}

	/**
	 * @param confHardWarePrd the confHardWarePrd to set
	 */
	public void setConfHardWarePrd(String confHardWarePrd) {
		this.confHardWarePrd = confHardWarePrd;
	}

	/**
	 * @return the confRevisionList
	 */
	public List<SelectItem> getConfRevisionList() {
		return confRevisionList;
	}

	/**
	 * @param confRevisionList the confRevisionList to set
	 */
	public void setConfRevisionList(List<SelectItem> confRevisionList) {
		this.confRevisionList = confRevisionList;
	}

	/**
	 * @return the confRevision
	 */
	public String getConfRevision() {
		return confRevision;
	}

	/**
	 * @param confRevision the confRevision to set
	 */
	public void setConfRevision(String confRevision) {
		this.confRevision = confRevision;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the userDetails
	 */
	public PLMPwiUserData getUserDetails() {
		return userDetails;
	}

	/**
	 * @param userDetails the userDetails to set
	 */
	public void setUserDetails(PLMPwiUserData userDetails) {
		this.userDetails = userDetails;
	}

	/**
	 * @return the plmCompleteEbomReportService
	 */
	public PLMCompleteEbomReportServiceIfc getPlmCompleteEbomReportService() {
		return plmCompleteEbomReportService;
	}

	/**
	 * @param plmCompleteEbomReportService the plmCompleteEbomReportService to set
	 */
	public void setPlmCompleteEbomReportService(
			PLMCompleteEbomReportServiceIfc plmCompleteEbomReportService) {
		this.plmCompleteEbomReportService = plmCompleteEbomReportService;
	}

	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}



}
