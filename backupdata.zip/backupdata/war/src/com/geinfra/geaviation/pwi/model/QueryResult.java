package com.geinfra.geaviation.pwi.model;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 10, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : QueryResultSetData
 * 
 * Revision Log Aug 10, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class QueryResult {
	private List<QueryResultColumn> columns = new ArrayList<QueryResultColumn>();
	private List<List<String>> data = new ArrayList<List<String>>();
	private long duration;
	private Exception exception;
	private int columnCount;
	private int rowCount;
	private String sql;
	private ResultStatus resultStatus;

	/**
	 * The result status: success, timeout, result size, invalid exec out, misc.
	 */
	public enum ResultStatus {
		ERROR_MISC, ERROR_TIMEOUT, ERROR_RESULT_SIZE, SUCCESS, ERROR_INVALID_EXEC_OUT
	}

	public List<QueryResultColumn> getColumns() {
		return columns;
	}

	public void setColumns(List<QueryResultColumn> columns) {
		this.columns = columns;
	}

	public List<List<String>> getData() {
		return data;
	}

	public void setData(List<List<String>> data) {
		this.data = data;
	}

	public long getDuration() {
		return duration;
	}

	public void setDuration(long duration) {
		this.duration = duration;
	}

	public int getColumnCount() {
		return columnCount;
	}

	public void setColumnCount(int columnCount) {
		this.columnCount = columnCount;
	}

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public String getSql() {
		return sql;
	}

	public void setSql(String sql) {
		this.sql = sql;
	}

	public String getErrorMessage() {
		return exception != null ? exception.getMessage() : null;
	}

	public Exception getException() {
		return exception;
	}

	public void setException(Exception exception) {
		this.exception = exception;
	}

	public ResultStatus getResultStatus() {
		return resultStatus;
	}

	public void setResultStatus(ResultStatus resultStatus) {
		this.resultStatus = resultStatus;
	}
}
