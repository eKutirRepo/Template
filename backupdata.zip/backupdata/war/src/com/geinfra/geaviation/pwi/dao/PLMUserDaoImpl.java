/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMUserDaoImpl.java
 * @Creation date: 01-Nov-2010
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMQueryConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;

/**
 * PLMUserDaoImpl is the DAO implementation class for PLM Login .
 */
public class PLMUserDaoImpl extends SimpleJdbcDaoSupport implements
		PLMUserDaoIfc {
	/**
	 * Holds the Logger
	 */
	private static final Logger LOG = Logger.getLogger(PLMUserDaoImpl.class);
	/**
	 * Holds the userSSO
	 */
	private String userSSO;
	/**
	 * Holds the event
	 */
	private String event;

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
	}
	/**
	 * This method is used for validateUserDetails
	 * 
	 * @param userSSOId
	 * @return PLMLoginData
	 * @throws PLMCommonException
	 */
	public PLMLoginData validateUserDetails(String userSSOId)
			throws PLMCommonException {
		LOG
				.info("loginUserSSO in validUserDetails of ICMAdminDaoImpl >>>>>>>>>>"
						+ userSSOId);
		PLMLoginData userData = null;
		List<PLMLoginData> userDataList = null;
		try {
			userDataList = getSimpleJdbcTemplate().query(
					PLMQueryConstants.VALID_SSODATA, new Mapper(), userSSOId);
			if (userDataList != null && !userDataList.isEmpty()
					&& userDataList.size() > PLMConstants.N_0) {
				userData = userDataList.get(PLMConstants.N_0);
			}
		} catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		finally {
			userDataList = null;
		}
		return userData;
	}
	
	/**
	 * This method is used for getScreenAccess
	 * 
	 * @param userDetails
	 * @return PLMLoginData
	 * @throws SQLException
	 */
	public PLMLoginData getScreenAccess(PLMLoginData userDetails)
			throws SQLException {
		PLMLoginData retData = userDetails;
		List<String> screens = null;
		String str = null;
		// to get user group access

		screens = getSimpleJdbcTemplate().query(
				PLMQueryConstants.GET_SCREEN_ACCESS,new AccessMapper());

		if (screens != null && screens.size() > 0) {
			for (int i = 0; i < screens.size(); i++) {
				str = screens.get(i);
				if (str.equalsIgnoreCase(PLMConstants.DOCUMENT_SEARCH)) {
					retData.setDocSearchAccess(true);
					LOG.info("The value in is  : "
							+ retData.isDocSearchAccess());
				}
				if (str.equalsIgnoreCase(PLMConstants.DRAWING_SEARCH)) {
					retData.setDrwnWorkFlow(true);
					LOG.info("The value in is  : " + retData.isDrwnWorkFlow());
				}
				if (str.equalsIgnoreCase(PLMConstants.ECO_SEARCH)) {
					retData.setEcosearch(true);
					LOG.info("The value in is  : " + retData.isEcosearch());
				}
				if (str.equalsIgnoreCase(PLMConstants.ECR_SEARCH)) {
					retData.setEcrsearch(true);
					LOG.info("The value in is  : " + retData.isEcrsearch());
				}
				if (str.equalsIgnoreCase(PLMConstants.ISSUES_SEARCH)) {
					retData.setIssuessearch(true);
					LOG.info("The value in is  : " + retData.isIssuessearch());
				}

			}
		}

		return retData;
	}
	/**
	 * Mapper for Getting Access Data
	 */
	//private static ParameterizedRowMapper<String> accessMapper = new ParameterizedRowMapper<String>() {
	private static final class AccessMapper implements ParameterizedRowMapper<String>{	
	public String mapRow(ResultSet rs, int rowCount) throws SQLException {

			String scrName = null;
			scrName = rs.getString("SCREEN_NAME");
			LOG.info("The value is : " + scrName);
			return scrName;

		}
	//	};
	}
	/**
	 * This method is used for validateUser
	 * 
	 * @param loginData
	 * @return boolean
	 * @throws SQLException
	 */
	public boolean validateUser(String loginData) throws SQLException {
		String ssoID_LD = loginData;
		int getResult = getSimpleJdbcTemplate().queryForInt(
				PLMQueryConstants.VALID_SSO, ssoID_LD);
		LOG.info("The value of the int getResult:::::" + getResult);
		if (getResult != 0)
			return true;
		else
			return false;
	}

	
	/**
	 * Mapper for Getting mapper Data
	 */
	//private static ParameterizedRowMapper<PLMLoginData> mapper = new ParameterizedRowMapper<PLMLoginData>() {
	private static final class Mapper implements ParameterizedRowMapper<PLMLoginData>{	
	public PLMLoginData mapRow(ResultSet rs, int rowNum) throws SQLException {
			PLMLoginData userData = new PLMLoginData();
			userData.setFName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.FIRST_NAME)));
			userData.setLName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.LAST_NAME)));
			userData.setEmail(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.USER_EMAIL_ADD)));
			userData.setActiveInd(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ACTIVE_IND)));
			return userData;
		}
	//	};
	}
	
		
	/**
	 * This method is used to fetch fetchUserGroups Information
	 * @param String
	 * @return List<SelectItem>
	 * @throws PLMCommonException
	 * 
	 */
	public List<SelectItem> fetchUserGroups(String userSSOId)
			throws PLMCommonException {
		List<SelectItem> userGroups = null;
		try{
		userGroups = getSimpleJdbcTemplate().query(
				PLMQueryConstants.GET_USERGROUPS, new Grpmapper(), userSSOId);
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return userGroups;
	}
	
	/**
	 * Mapper for Getting grpmapper Data
	 */
	//private static ParameterizedRowMapper<SelectItem> grpmapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class Grpmapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowNum) throws SQLException {
			SelectItem userData = new SelectItem();
			userData.setLabel(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GROUP_NAME)));
			userData.setDescription(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GROUP_DESC)));
			userData.setValue(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GROUP_ID)));
			return userData;
		}
	//	};
	}
	
	/**
	 * This Method is used for insert systemLog event
	 * 
	 * @param userSSOId
	 * 
	 * @param eventId
	 * 
	 * @return boolean
	 * 
	 * @throws PLMCommonException
	 */
	@Transactional
	public void addSystemLogEvent(String userSSOId, String eventId)
			throws PLMCommonException {
		
		this.setUserSSO(userSSOId);
		this.setEvent(eventId);
		addtoSystemLog();
		
	}
	/**
	 * This Method is used for addtoSystemLog
	 * 
	 * @throws PLMCommonException
	 */
	private synchronized void addtoSystemLog() throws PLMCommonException {
		
		Thread accessThread = new Thread(new Runnable() {
			public void run() {
				try {
					int count = getSimpleJdbcTemplate().update(
							PLMQueryConstants.SAVE_SYSTEMLOGDATA,
							new Object[] { PLMUtils.checkNullVal(userSSO),
									PLMUtils.checkNullVal(event),
									PLMUtils.checkNullVal(userSSO),
									PLMUtils.checkNullVal(userSSO) });
					LOG.info("The Update query returned '" + count + "' number of records");
				} catch (DataAccessException ice) {
					LOG.error("Error in granting auto-access process." + ice.getMessage());
				}
			}
				
		});
		accessThread.start();
	}
	/**
	 * This Method is used for getPermissionDetails
	 * 
	 * @return List
	 * @param userGrp
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMLoginData> getPermissionDetails(List<SelectItem> userGrp)
			throws PLMCommonException {
		LOG
				.info("Group in getPermissionDetails of ICMAdminServiceImpl >>>>>>>>>>"
						+ userGrp);
		List<PLMLoginData> permissionData = new ArrayList<PLMLoginData>();
		Map<String, Object> params = new HashMap<String, Object>();
		List<String> groupLst = new ArrayList<String>();
		try{
			for (SelectItem checkString : userGrp) {
				groupLst.add(checkString.getValue().toString());
			}	
			params.put("GRPID", groupLst);
			LOG.info("The Permission Query "+PLMQueryConstants.GET_PERMISSIONDATA_NEW);
			if (!PLMUtils.isEmptyList(groupLst)) {
				permissionData = getNamedJdbcTemplate().query(
						PLMQueryConstants.GET_PERMISSIONDATA_NEW,params,new PermData());
			}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return permissionData;
	}

	/**
	 * Mapper for Getting permission Data
	 */
	//private static ParameterizedRowMapper<PLMLoginData> permData = new ParameterizedRowMapper<PLMLoginData>() {
	private static final class PermData implements ParameterizedRowMapper<PLMLoginData>{ 	
	public PLMLoginData mapRow(ResultSet rs, int rowNum) throws SQLException {
			PLMLoginData userData = new PLMLoginData();
			userData.setScreenId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.SCREEN_NAME)));
			userData.setPermissionId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PERM_NAME)));
			return userData;
		}
	//	};
	}
	
	
	


	/**
	 * @return the userSSO
	 */
	public String getUserSSO() {
		return userSSO;
	}


	/**
	 * @param userSSO the userSSO to set
	 */
	public void setUserSSO(String userSSO) {
		this.userSSO = userSSO;
	}


	/**
	 * @return the event
	 */
	public String getEvent() {
		return event;
	}


	/**
	 * @param event the event to set
	 */
	public void setEvent(String event) {
		this.event = event;
	}}
