/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCompatibilityRulesRptMB.java
 * @Creation date: 10-Apr-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import com.geinfra.geaviation.pwi.data.PLMCompatibilityRulesReportData;
import com.geinfra.geaviation.pwi.service.PLMCompleteEbomReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

public class PLMCompatibilityRulesRptMB {

	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMCompatibilityRulesRptMB.class);
	private List<SelectItem> productNameList = new ArrayList<SelectItem>();
	private List<SelectItem> revNameList = new ArrayList<SelectItem>();
	private List<PLMCompatibilityRulesReportData> compatibilityRulesReportList = new ArrayList<PLMCompatibilityRulesReportData>();
	private int recordCounts = PLMConstants.N_15;
	private PLMCompatibilityRulesReportData pwiCompleteEbomReportvo = new PLMCompatibilityRulesReportData();
	private String alertMessage;
	private String selShipBomHardwareProdName = new String();
	private String selShipBomRevName = new String();
	private PLMCompleteEbomReportServiceIfc plmCompleteEbomReportService = null;
	private PLMCommonMB commonMB;
	private String totalRecordCompleteEbomAptMsg;
	
	
	/**
	 * @return the productNameList
	 */
	public List<SelectItem> getProductNameList() {
		return productNameList;
	}
	/**
	 * @param productNameList the productNameList to set
	 */
	public void setProductNameList(List<SelectItem> productNameList) {
		this.productNameList = productNameList;
	}
	/**
	 * @return the revNameList
	 */
	public List<SelectItem> getRevNameList() {
		return revNameList;
	}
	/**
	 * @param revNameList the revNameList to set
	 */
	public void setRevNameList(List<SelectItem> revNameList) {
		this.revNameList = revNameList;
	}
	/**
	 * @return the compatibilityRulesReportList
	 */
	public List<PLMCompatibilityRulesReportData> getCompatibilityRulesReportList() {
		return compatibilityRulesReportList;
	}
	/**
	 * @param compatibilityRulesReportList the compatibilityRulesReportList to set
	 */
	public void setCompatibilityRulesReportList(
			List<PLMCompatibilityRulesReportData> compatibilityRulesReportList) {
		this.compatibilityRulesReportList = compatibilityRulesReportList;
	}
	/**
	 * @return the pwiCompleteEbomReportvo
	 */
	public PLMCompatibilityRulesReportData getPwiCompleteEbomReportvo() {
		return pwiCompleteEbomReportvo;
	}
	/**
	 * @param pwiCompleteEbomReportvo the pwiCompleteEbomReportvo to set
	 */
	public void setPwiCompleteEbomReportvo(
			PLMCompatibilityRulesReportData pwiCompleteEbomReportvo) {
		this.pwiCompleteEbomReportvo = pwiCompleteEbomReportvo;
	}
	/**
	 * @return the selShipBomHardwareProdName
	 */
	public String getSelShipBomHardwareProdName() {
		return selShipBomHardwareProdName;
	}
	/**
	 * @param selShipBomHardwareProdName the selShipBomHardwareProdName to set
	 */
	public void setSelShipBomHardwareProdName(String selShipBomHardwareProdName) {
		this.selShipBomHardwareProdName = selShipBomHardwareProdName;
	}
	/**
	 * @return the selShipBomRevName
	 */
	public String getSelShipBomRevName() {
		return selShipBomRevName;
	}
	/**
	 * @param selShipBomRevName the selShipBomRevName to set
	 */
	public void setSelShipBomRevName(String selShipBomRevName) {
		this.selShipBomRevName = selShipBomRevName;
	}
	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}
	/**
	 * @param recordCounts the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}
	
	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}
	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}
	
	/**
	 * @return the plmCompleteEbomReportService
	 */
	public PLMCompleteEbomReportServiceIfc getPlmCompleteEbomReportService() {
		return plmCompleteEbomReportService;
	}
	/**
	 * @param plmCompleteEbomReportService the plmCompleteEbomReportService to set
	 */
	public void setPlmCompleteEbomReportService(
			PLMCompleteEbomReportServiceIfc plmCompleteEbomReportService) {
		this.plmCompleteEbomReportService = plmCompleteEbomReportService;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}
	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the totalRecordCompleteEbomAptMsg
	 */
	public String getTotalRecordCompleteEbomAptMsg() {
		return totalRecordCompleteEbomAptMsg;
	}
	/**
	 * @param totalRecordCompleteEbomAptMsg the totalRecordCompleteEbomAptMsg to set
	 */
	public void setTotalRecordCompleteEbomAptMsg(
			String totalRecordCompleteEbomAptMsg) {
		this.totalRecordCompleteEbomAptMsg = totalRecordCompleteEbomAptMsg;
	}
	/**
	 * This method is used for getLoadingDataForCompatibilityRules
	 *  for project names
	 * 
	 * @return String
	 */
	public String getLoadingDataForCompatibilityRules()
	{
		LOG.info("getLoadingDataForCompatibilityRules() Method");
		String fwdFlag = "";
		alertMessage = "";
		selShipBomHardwareProdName="";
		selShipBomRevName="";
		try {
			 commonMB.insertCannedRptRecordHitInfo("Compatibility Rules Report");
			 productNameList =  plmCompleteEbomReportService.getHardwareProductNames();
			 revNameList = new ArrayList<SelectItem>();
			fwdFlag = "plmCompatibilityRulesRptHome";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getLoadingDataForCompatibilityRules: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Compatibility Rules Report");
		} 
		return fwdFlag;
	}
	
	/**
	 * This method is used to get Revision Name Information for Hardware Product Name
	 * 
	 * @param event
	 */
	public void fetchRevList(ActionEvent event){
		LOG.info("Entering fetchRevList method PLMCompatibilityRulesRptMB");
		try{
			 revNameList = new ArrayList<SelectItem>();
			 revNameList = plmCompleteEbomReportService.getRevisionNames(selShipBomHardwareProdName);
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting fetchRevList method PLMCompatibilityRulesRptMB");
	}
	/**
	 * This method is used for generating report on UI
	 * 
	 * @return String
	 */
	public String generateCompatibilityRulesAppReport() {
		LOG.info("get data from generateCompatibilityRulesAppReport() Method");
				String fwdFlag = "";
				alertMessage = "";
				totalRecordCompleteEbomAptMsg="";
				compatibilityRulesReportList=new ArrayList<PLMCompatibilityRulesReportData>();
		try { 
			 alertMessage = validateCompatibilityRulesAptReport();
			 if (PLMConstants.EMPTY.equals(alertMessage)) {
				 compatibilityRulesReportList = plmCompleteEbomReportService.generateCompatibilityRulesAppReport(selShipBomHardwareProdName,selShipBomRevName);
				 if(compatibilityRulesReportList.size()>0){
					 totalRecordCompleteEbomAptMsg="Total Records of Compatibility Rules Report:: "+compatibilityRulesReportList.size();
					 recordCounts = PLMConstants.N_100;
	     		  fwdFlag = "plmCompatibilityRulesRptHomeDetails";
				 }
				 else{
					 alertMessage = "No Records Found for the Selected combination";
					 fwdFlag = "plmCompatibilityRulesRptHome";
				 }
			 }
			 else{
				 fwdFlag = "plmCompatibilityRulesRptHome";
			 }
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@generateCompatibilityRulesAppReport: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Compatibility Rules Report");
		} 
		
		return fwdFlag;
	}
	/**
	 * This method is used for export to Excel of Back log Report
	 * 
	 */
	public void downloadCompatibilityRulesSrchExcel() throws PLMCommonException {
		
		LOG.info("Entering downloadCompatibilityRulesSrchExcel Method");
		//7269088_rev_001__Engineering_Bill_of_Materials1484680264437
		String reportName=selShipBomHardwareProdName.concat("_").concat(selShipBomRevName+"_Compatibility_Rules").concat(new SimpleDateFormat().format(new Date()));
		String fileName="Compatibility Rules";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					new PLMXlsxRptColumn("level", "Level", FormatType.INTEGER, null, null, 10),
                    new PLMXlsxRptColumn("name", "Name", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("leftExpression", "Left Expression", FormatType.TEXT, null, null, 25),
                    new PLMXlsxRptColumn("compatibility", "Compatibility", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("rightExpression", "Right Expression", FormatType.TEXT, null, null, 25),
                    new PLMXlsxRptColumn("errorMessage", "Error Message", FormatType.TEXT, null, null, 25),
                    new PLMXlsxRptColumn("mandatory", "Mandatory", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("designResp", "Design Responsibility", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("owner", "Owner", FormatType.TEXT, null, null, 10)
			};
			
			PLMXlsxRptColumn[] critcolumns =
					new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("hardwareProdNameHeader", "Selected Hardware Product Name", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("revProdNameHeader", "Selected Revision Product Name", FormatType.TEXT_NOWRAP)
					};
			pwiCompleteEbomReportvo.setHardwareProdNameHeader(selShipBomHardwareProdName);
			pwiCompleteEbomReportvo.setRevProdNameHeader(selShipBomRevName);
			excelUtil.export(compatibilityRulesReportList, reportColumns, reportName, fileName, true, critcolumns, pwiCompleteEbomReportvo);
	 }
	/**
	 * This method is used for validateCompatibilityRulesAptReport
	 * 
	 * @return String
	 */
	public String  validateCompatibilityRulesAptReport(){
		alertMessage ="";
		if(PLMUtils.isEmpty(selShipBomHardwareProdName) || PLMUtils.isEmpty(selShipBomRevName)){
			alertMessage = PLMConstants.AERO_SEARCH_CRITERIA;
		}
		return alertMessage;
	}
	/**
	 * reset
	 */
	public void resetCompatibilityRulesReport(){
		alertMessage = "";
		revNameList=new ArrayList<SelectItem>();
		totalRecordCompleteEbomAptMsg="";
		selShipBomHardwareProdName = new String();
		selShipBomRevName = new String();
	}
	
}
