package com.geinfra.geaviation.pwi.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.TransactionStatus;

import com.geinfra.geaviation.pwi.dao.ObjectTypeDAOImpl.PWiObjectTypeVORowMapper;
import com.geinfra.geaviation.pwi.dao.QueriesDAOImpl.PWiQueryNoXmlVORowMapper;
import com.geinfra.geaviation.pwi.model.PWiObjectTypeVO;
import com.geinfra.geaviation.pwi.model.PWiQueryNoXmlVO;
import com.geinfra.geaviation.pwi.model.PWiQueryObjectTypeVO;
import com.geinfra.geaviation.pwi.model.PWiQueryObjectVO;
import com.geinfra.geaviation.pwi.util.ColumnConstants;
import com.geinfra.geaviation.pwi.util.DaoUtil;
import com.geinfra.geaviation.pwi.util.MapperConstants;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Jan 20, 2012 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description :
 * 
 * Revision Log Jan 20, 2012 | v1.0.
 * --------------------------------------------------------------
 */
public class QueryObjectDAOImpl extends PWiDAO implements QueryObjectDAO {
	// injected dependencies
	private DefaultQiOptionsDAO defaultQiOptionsDAO;

	public void setDefaultQiOptionsDAO(DefaultQiOptionsDAO defaultQiOptionsDAO) {
		this.defaultQiOptionsDAO = defaultQiOptionsDAO;
	}

	private static class PWiQueryObjectVORowMapper implements
			ParameterizedRowMapper<PWiQueryObjectVO> {
		PWiObjectTypeVORowMapper objectTypeRowMapper = new PWiObjectTypeVORowMapper();
		PWiQueryNoXmlVORowMapper queryRowMapper = new PWiQueryNoXmlVORowMapper();

		public PWiQueryObjectVO mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PWiObjectTypeVO objectType = objectTypeRowMapper
					.mapRow(rs, rowNum);
			PWiQueryNoXmlVO query = queryRowMapper.mapRow(rs, rowNum);

			PWiQueryObjectVO queryObject = new PWiQueryObjectVO();
			queryObject.setObjectType(objectType);
			queryObject.setQuery(query);

			return queryObject;
		}
	}

	public List<PWiQueryObjectVO> getQueryObjectForQuery(Integer queryId) {
		GetObjectTypesForQuerySetter pss = new GetObjectTypesForQuerySetter(
				queryId);

		@SuppressWarnings("unchecked")
		List<PWiQueryObjectVO> result = (List<PWiQueryObjectVO>) getJdbcTemplate()
				.query(pss.getSql(), pss, new PWiQueryObjectVORowMapper());

		return result;
	}

	private static class GetObjectTypesForQuerySetter implements
			PreparedStatementSetter {
		private Integer queryId;

		public GetObjectTypesForQuerySetter(Integer queryId) {
			this.queryId = queryId;
		}

		public String getSql() {
			StringBuilder builder = new StringBuilder();
			builder.append("SELECT * FROM ");
			builder.append(ColumnConstants.TBL_PWi_QUERY_OBJECT);
			builder.append(" qo, ");
			builder.append(ColumnConstants.TBL_PWi_OBJECT_TYPE);
			builder.append(" obj, ");
			builder.append(ColumnConstants.TBL_PWi_QUERY);
			builder.append(" qry WHERE qo.");
			builder.append(ColumnConstants.QRY_SEQ_ID);
			builder.append(" = ? AND qry.");
			builder.append(ColumnConstants.QRY_SEQ_ID);
			builder.append(" = qo.");
			builder.append(ColumnConstants.QRY_SEQ_ID);
			builder.append(" AND obj.");
			builder.append(ColumnConstants.OBJ_TYP_SEQ_ID);
			builder.append(" = qo.");
			builder.append(ColumnConstants.OBJ_TYP_SEQ_ID);

			return builder.toString();
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			int index = 1;
			ps.setInt(index, queryId.intValue());
		}
	}

	public List<PWiQueryObjectTypeVO> getQueryObjectTypes() {
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT ");
		builder.append(ColumnConstants.QRY_SEQ_ID);
		builder.append(", ");
		builder.append(ColumnConstants.OBJ_TYP_SEQ_ID);
		builder.append(" FROM ");
		builder.append(ColumnConstants.TBL_PWi_QUERY_OBJECT);
	
		@SuppressWarnings("unchecked")
		List<PWiQueryObjectTypeVO> queryObjectTypes = (List<PWiQueryObjectTypeVO>) getJdbcTemplate()
				.query(builder.toString(), MapperConstants.QUERY_OBJECT_TYPE_MAPPER);
		
		return queryObjectTypes;
	}

	public void addObjectTypesForQuery(List<Integer> objectTypeIds,
			Integer queryId, String sso) {
		AddObjectTypesForQuerySetter pss = new AddObjectTypesForQuerySetter(
				queryId, objectTypeIds, sso);

		getJdbcTemplate().batchUpdate(pss.getSql(), pss);
	}

	private static class AddObjectTypesForQuerySetter implements
			BatchPreparedStatementSetter {
		private Integer queryId;
		private List<Integer> objectTypeIds;
		private String sso;

		public AddObjectTypesForQuerySetter(Integer queryId,
				List<Integer> objectTypeIds, String sso) {
			this.queryId = queryId;
			this.objectTypeIds = objectTypeIds;
			this.sso = sso;
		}

		public String getSql() {
			StringBuilder builder = new StringBuilder();
			builder.append("INSERT INTO ");
			builder.append(ColumnConstants.TBL_PWi_QUERY_OBJECT);
			builder.append(" (");
			builder.append(ColumnConstants.QRY_SEQ_ID);
			builder.append(", ");
			builder.append(ColumnConstants.OBJ_TYP_SEQ_ID);
			builder.append(", Crtn_Dt, Crtd_by, Lst_Updt_dt, Lst_Updtd_By)");
			builder.append(" VALUES (?,?,SYSDATE,?,SYSDATE,?)");

			return builder.toString();
		}

		public int getBatchSize() {
			return objectTypeIds.size();
		}

		public void setValues(PreparedStatement ps, int objTypIdIndex) throws SQLException {
			ps.setInt(1, queryId.intValue());
			ps.setInt(2, objectTypeIds.get(objTypIdIndex).intValue());
			ps.setString(3, sso);
			ps.setString(4, sso);
		}
	}

	public void deleteObjectTypesForQuery(List<Integer> objectTypeIds,
			Integer queryId, TransactionStatus status) {
		// delete any default QI options
		defaultQiOptionsDAO.deleteOptionsForQueryObject(queryId, objectTypeIds);

		DeleteObjectTypesForQuerySetter pss = new DeleteObjectTypesForQuerySetter(
				queryId, objectTypeIds);

		getJdbcTemplate().update(pss.getSql(), pss);
	}

	private static class DeleteObjectTypesForQuerySetter implements
			PreparedStatementSetter {
		private Integer queryId;
		private List<Integer> objectTypeIds;

		public DeleteObjectTypesForQuerySetter(Integer queryId,
				List<Integer> objectTypeIds) {
			this.queryId = queryId;
			this.objectTypeIds = objectTypeIds;
		}

		public String getSql() {
			StringBuilder builder = new StringBuilder();
			builder.append("DELETE FROM ");
			builder.append(ColumnConstants.TBL_PWi_QUERY_OBJECT);
			builder.append(" WHERE ");
			builder.append(ColumnConstants.QRY_SEQ_ID);
			builder.append("=? AND ");
			builder.append(ColumnConstants.OBJ_TYP_SEQ_ID);
			builder.append(" IN (");
			builder.append(DaoUtil.getInstance().generateInClausePlaceholders(
					objectTypeIds.size()));
			builder.append(")");

			return builder.toString();
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			int index = 1;
			ps.setInt(index, queryId.intValue());
			index++;
			for (Integer objectTypeId : objectTypeIds) {
				ps.setInt(index, objectTypeId.intValue());
				index++;
			}
		}
	}
}
