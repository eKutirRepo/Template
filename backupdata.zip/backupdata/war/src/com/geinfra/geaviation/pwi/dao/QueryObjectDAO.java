package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import org.springframework.transaction.TransactionStatus;

import com.geinfra.geaviation.pwi.model.PWiQueryObjectTypeVO;
import com.geinfra.geaviation.pwi.model.PWiQueryObjectVO;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Jan 20, 2012 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Data access object interface for the query-object relation.
 * 
 * Revision Log Jan 20, 2012, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public interface QueryObjectDAO {
	public List<PWiQueryObjectVO> getQueryObjectForQuery(Integer queryId);

	/**
	 * @return all query-to-objectType relations in a Jsonable format
	 */
	public List<PWiQueryObjectTypeVO> getQueryObjectTypes();

	public void addObjectTypesForQuery(List<Integer> objectTypeIds,
			Integer queryId, String sso);

	/**
	 * Removes all query-to-objectType relations.
	 * 
	 * Handles deleting any rows from dependent tables (those with foreign keys
	 * to this table) as well, and so should be run in a transaction to
	 * guarantee all tables are updated as expected.
	 * 
	 * @param objectTypeIds
	 * @param queryId
	 * @param status
	 */
	public void deleteObjectTypesForQuery(List<Integer> objectTypeIds,
			Integer queryId, TransactionStatus status);
}
