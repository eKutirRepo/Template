/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCostCycleSmryDaoImpl.java
 * @Creation date: 16-Jul-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMCostCycleSmryData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMCostCycleSmryDaoImpl extends SimpleJdbcDaoSupport implements PLMCostCycleSmryDaoIfc{
	
	/**
	 * Holds the LOG
	 */
	private static Logger LOG = Logger.getLogger(PLMCostCycleSmryDaoImpl.class);
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
	} 

	/**
	 * This method is used for getCrCount
	 * 
	 * @return int
	 * @throws PLMCommonException
	 */
	public int getCrCount(String crNum)throws PLMCommonException {
		LOG.info("Inside getCrCount() of DAOImpl ");
		int crCount=0;
		List<Integer> crCountList=null;
		try {
			LOG.info("Executing query for getting crCount==" + PLMSearchQueries.GET_CR_COUNT);
			crCountList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_CR_COUNT,new CrCountMapper(),new Object[]{crNum});
			crCount = crCountList.get(0).intValue();
			
		} catch (Exception e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Existing getCrCount() of DAOImpl ");
		return crCount;
	}
	
	/**
	 * Row mapper for getting CrCountMapper
	 */
	private static final class CrCountMapper implements ParameterizedRowMapper<Integer>{	
	public Integer mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			
			Integer crCountList = rs.getInt(PLMConstants.REQ_NM);

			return crCountList;

		}
	}
	
	/**
	 * This method is used to get Contracts List
	 * 
	 * @return List<PLMCostCycleSmryData>
	 * @throws PLMCommonException
	 */
	public List<PLMCostCycleSmryData> getContractForCR(String crNum)	throws PLMCommonException{
		LOG.info("Inside getContractForCR() of DAOImpl ");
		List<PLMCostCycleSmryData> contractList = null;
		try{
			LOG.info("Query to fetch contract List=="+PLMSearchQueries.GET_CONTRACT_FOR_CR);
			contractList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_CONTRACT_FOR_CR,new ContractForCRMapper(),new Object[]{crNum});
		}catch (Exception e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Existing getContractForCR() in DAOImpl ");
		return contractList;
	}
	
	/**
	 * Row mapper for getting CrCountMapper
	 */
	private static final class ContractForCRMapper implements ParameterizedRowMapper<PLMCostCycleSmryData>{	
	public PLMCostCycleSmryData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			
		PLMCostCycleSmryData contractList = new PLMCostCycleSmryData();
		
		contractList.setContract(PLMUtils.checkNullVal(rs.getString(PLMConstants.CCS_CONTRACT)));
		contractList.setDescription(PLMUtils.checkNullVal(rs.getString(PLMConstants.CCS_DESCRIPTION)));
		contractList.setCrId(PLMUtils.checkNullVal(rs.getString(PLMConstants.CCS_CR_ID)));
		contractList.setCrName(PLMUtils.checkNullVal(rs.getString(PLMConstants.CCS_CR_NAME)));
		contractList.setCrsName(PLMUtils.checkNullVal(rs.getString(PLMConstants.CCS_CRS_NAME)));
		
		contractList.setDdListContract(new SelectItem(PLMUtils.checkNullValCostCycle(rs.getString(PLMConstants.CCS_CONTRACT))));

		return contractList;

		}
	}
	
	
	/**
	 * This method is used to get Cost Cycle Result List
	 * 
	 * @return List<PLMCostCycleSmryData>
	 * @throws PLMCommonException
	 */ 
	@SuppressWarnings("unchecked")
	public Map<String, List<PLMCostCycleSmryData>> getCostCycleResult(String crNum) throws PLMCommonException{
		LOG.info("Inside getCostCycleResult() of DAOImpl ");
		List<PLMCostCycleSmryData> costCycleResultList = null;
		List<PLMCostCycleSmryData> unitMeasureCalList = null;
		List<PLMCostCycleSmryData> finalcostCycleResultList = new ArrayList<PLMCostCycleSmryData>();
		Map<String, List<PLMCostCycleSmryData>> costCycleResultMap = new HashMap<String, List<PLMCostCycleSmryData>>(); 
		StringBuffer prodConfset =new StringBuffer();
		List<String> prodConfList = new ArrayList<String>();
		 HashMap<String, String> unitMeasures= new HashMap<String, String>();
		 List<PLMCostCycleSmryData> gasGrpList = new ArrayList<PLMCostCycleSmryData>();
		 List<PLMCostCycleSmryData> steamGrpList = new ArrayList<PLMCostCycleSmryData>();
		 List<PLMCostCycleSmryData> genGrpList = new ArrayList<PLMCostCycleSmryData>();
		 List<PLMCostCycleSmryData> totalCostList = new ArrayList<PLMCostCycleSmryData>();
		  Map<String, Object> params = new HashMap<String, Object>();
				
			LOG.info("Query to fetch contract List=="+PLMSearchQueries.GET_COST_CYCLE_RESULT);
			costCycleResultList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_COST_CYCLE_RESULT,new CostCycleResultMapper(),new Object[]{crNum});

			if(!PLMUtils.isEmptyList(costCycleResultList)){
			  for(int i=0;i<costCycleResultList.size();i++){
				  if(costCycleResultList.get(i).getResUnitOfMeasure().equals("Per Unit")){
					  if(prodConfset.lastIndexOf(costCycleResultList.get(i).getResProductConfig()) < 0){
						   prodConfList.add(costCycleResultList.get(i).getResProductConfig());
				       	    prodConfset.append(costCycleResultList.get(i).getResProductConfig()+",");
					  }
				  }
			  }
	   
		if(!PLMUtils.isEmptyList(prodConfList)){	
				params.put("PCNM", prodConfList);
				LOG.info("Query to fetch getUnitsQry List=="+PLMSearchQueries.GET_COST_CYCLE_UNITS);
			unitMeasureCalList = getNamedJdbcTemplate().query(PLMSearchQueries.GET_COST_CYCLE_UNITS,params,new UnitMeasureMapper());
			
			 if(!PLMUtils.isEmptyList(unitMeasureCalList)){
				  for(int j=0;j<unitMeasureCalList.size();j++){
					 unitMeasures.put(unitMeasureCalList.get(j).getResProductConfig(), unitMeasureCalList.get(j).getNoOfUnits());
					  }
		 }	
	  }
		 double prodCostSiteCal = 0;
		 double shopWorkLabCal = 0;
		 double resDraftingHoursCal =0;
		 double resEnggHourscal=0;
		 double resEnggTotalCostcal =0;
		 double resTransportCostCal=0;
		 double resFieldInstallCostCal=0;
		 double resMfgExpCal=0; 
		 double resFieldTransInvCostCal=0;
		 double resEngFieldTransCostCal=0;
		 PLMCostCycleSmryData costCycleCalData = new PLMCostCycleSmryData();
		   for(int k=0;k<costCycleResultList.size();k++){
				 costCycleCalData = new PLMCostCycleSmryData();
				costCycleCalData.setResCustReq(costCycleResultList.get(k).getResCustReq());
				costCycleCalData.setResCustReqDesc(costCycleResultList.get(k).getResCustReqDesc());
				costCycleCalData.setResCRState(costCycleResultList.get(k).getResCRState());
				costCycleCalData.setResContract(costCycleResultList.get(k).getResContract());
				costCycleCalData.setResCostGroup(costCycleResultList.get(k).getResCostGroup());
				costCycleCalData.setResCOName(costCycleResultList.get(k).getResCOName());
				costCycleCalData.setResCOState(costCycleResultList.get(k).getResCOState());
				costCycleCalData.setResTFMktName(costCycleResultList.get(k).getResTFMktName());
				costCycleCalData.setResLFDesc(costCycleResultList.get(k).getResLFDesc());
				costCycleCalData.setResUnitOfMeasure(costCycleResultList.get(k).getResUnitOfMeasure());
				costCycleCalData.setResLocationCurrency(costCycleResultList.get(k).getResLocationCurrency());
				costCycleCalData.setResMaterialShipDirectCost(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResMaterialShipDirectCost()));
				costCycleCalData.setResRawInProcessCost(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResRawInProcessCost()));		
				
				costCycleCalData.setResMfgLaborHours(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResMfgLaborHours()));
				costCycleCalData.setResProdCost(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResProdCost()));
				costCycleCalData.setResShopWorkLabCost(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResShopWorkLabCost()));
				costCycleCalData.setResDraftingHours(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResDraftingHours()));
				costCycleCalData.setResEnggHours(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResEnggHours()));
				costCycleCalData.setResEnggTotalCost(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResEnggTotalCost()));
				costCycleCalData.setResTransportCost(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResTransportCost()));
				costCycleCalData.setResFieldInstallCost(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResFieldInstallCost()));		
				costCycleCalData.setResMfgExp(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResMfgExp()));
				costCycleCalData.setResFieldTransInvCost(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResFieldTransInvCost()));
				costCycleCalData.setResEngFieldTransCost(costCycleResultList.get(k).getResEngFieldTransCost());
				costCycleCalData.setResMfgMatLeadTime(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResMfgMatLeadTime()));
				costCycleCalData.setResMfgPlannedLeadTime(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResMfgPlannedLeadTime()));
				costCycleCalData.setResCycleTimeDrawings(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResCycleTimeDrawings()));
				
				costCycleCalData.setResProductConfig(costCycleResultList.get(k).getResProductConfig());
				costCycleCalData.setResModelNum(costCycleResultList.get(k).getResModelNum());
				costCycleCalData.setResEnggDisposition(costCycleResultList.get(k).getResEnggDisposition());
				costCycleCalData.setResPartName(costCycleResultList.get(k).getResPartName());
				
				if(costCycleResultList.get(k).getResUnitOfMeasure().equals("Per Unit")){
					   String pcName = costCycleResultList.get(k).getResProductConfig();
					   String noOfUnits = unitMeasures.get(pcName);
					    	 if(!PLMUtils.isEmpty(pcName) && (!"OTHERS".equals(noOfUnits) && !PLMUtils.isEmpty(noOfUnits))){
						    	  costCycleCalData.setNoOfUnits(noOfUnits);
						    	  costCycleCalData.setProdCostSite(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResProdCost() * Integer.parseInt(noOfUnits)));
					    	  } else {
						    	  costCycleCalData.setNoOfUnits("By Others");
						    	  costCycleCalData.setProdCostSite(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResProdCost()));
					    	  }
				 
			} else if(costCycleResultList.get(k).getResUnitOfMeasure().equals("Per Site")){
					costCycleCalData.setNoOfUnits("NA (Per Site)");
				costCycleCalData.setProdCostSite(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResProdCost()));
			} else {
				costCycleCalData.setNoOfUnits("By Others");
				costCycleCalData.setProdCostSite(PLMUtils.convertCostCycle(costCycleResultList.get(k).getResProdCost()));
			}
				 costCycleCalData.setSumFlag(false);
			finalcostCycleResultList.add(costCycleCalData);
		     }
			Collections.sort(finalcostCycleResultList, new SortCostGroup());
			Collections.sort(finalcostCycleResultList, new SortCOName());
			Collections.sort(finalcostCycleResultList, new SortTFMarketNM());
		
		   for(int i=0;i<finalcostCycleResultList.size();i++){
			   costCycleCalData = new PLMCostCycleSmryData();
			   prodCostSiteCal = prodCostSiteCal + finalcostCycleResultList.get(i).getProdCostSite();
			   shopWorkLabCal = shopWorkLabCal +finalcostCycleResultList.get(i).getResShopWorkLabCost();
			   resDraftingHoursCal =resDraftingHoursCal+finalcostCycleResultList.get(i).getResDraftingHours();
			   resEnggHourscal = resEnggHourscal+finalcostCycleResultList.get(i).getResEnggHours();
			   resEnggTotalCostcal = resEnggTotalCostcal+finalcostCycleResultList.get(i).getResEnggTotalCost();
			   resTransportCostCal =resTransportCostCal +finalcostCycleResultList.get(i).getResTransportCost();
			   resFieldInstallCostCal= resFieldInstallCostCal+finalcostCycleResultList.get(i).getResFieldInstallCost();
			   resMfgExpCal= resMfgExpCal+finalcostCycleResultList.get(i).getResMfgExp();
			   resFieldTransInvCostCal=resFieldTransInvCostCal+finalcostCycleResultList.get(i).getResFieldTransInvCost();
			   resEngFieldTransCostCal= resEngFieldTransCostCal+finalcostCycleResultList.get(i).getResEngFieldTransCost();
			}
		   
		   costCycleCalData.setResCostGroup("Sub Totals");
		   costCycleCalData.setProdCostSite(PLMUtils.convertCostCycle(prodCostSiteCal));
		   costCycleCalData.setResShopWorkLabCost(PLMUtils.convertCostCycle(shopWorkLabCal));
		   costCycleCalData.setResDraftingHours(PLMUtils.convertCostCycle(resDraftingHoursCal));
		   costCycleCalData.setResEnggHours(PLMUtils.convertCostCycle(resEnggHourscal));
		   costCycleCalData.setResEnggTotalCost(PLMUtils.convertCostCycle(resEnggTotalCostcal));
		   costCycleCalData.setResTransportCost(PLMUtils.convertCostCycle(resTransportCostCal));
		   costCycleCalData.setResFieldInstallCost(PLMUtils.convertCostCycle(resFieldInstallCostCal));
		   costCycleCalData.setResMfgExp(PLMUtils.convertCostCycle(resMfgExpCal));
		   costCycleCalData.setResFieldTransInvCost(PLMUtils.convertCostCycle(resFieldTransInvCostCal));
		   costCycleCalData.setResEngFieldTransCost(PLMUtils.convertCostCycle(resEngFieldTransCostCal));
		   costCycleCalData.setSumFlag(true);
		  
		   finalcostCycleResultList.add(costCycleCalData);
		  String marketNM="";
		  double gasval=0;
		  double genval=0;
		  double steamval=0;
		  HashMap<String, Double> gasMarketNmMap= new HashMap<String, Double>();
		  HashMap<String, Double> genMarketNmMap= new HashMap<String, Double>();
		  HashMap<String, Double> steamMarketNmMap= new HashMap<String, Double>();
		 for(int j=0;j<finalcostCycleResultList.size();j++){
			 if(!PLMUtils.isEmpty(finalcostCycleResultList.get(j).getResCostGroup()) && !PLMUtils.isEmpty(finalcostCycleResultList.get(j).getResUnitOfMeasure())){
			  marketNM = finalcostCycleResultList.get(j).getResTFMktName();
			  
			   if(finalcostCycleResultList.get(j).getResCostGroup().equals("Gas")|| finalcostCycleResultList.get(j).getResCostGroup().equals("Gas - Options")){
					   gasval = PLMUtils.convertCostCycle(finalcostCycleResultList.get(j).getProdCostSite()+finalcostCycleResultList.get(j).getResEngFieldTransCost());
					   if (null != gasMarketNmMap.get(marketNM)) {
						   gasval += gasMarketNmMap.get(marketNM);
					   }
					   gasMarketNmMap.put(finalcostCycleResultList.get(j).getResTFMktName(), gasval);
			   }
			   else if(finalcostCycleResultList.get(j).getResCostGroup().equals("Gen")|| finalcostCycleResultList.get(j).getResCostGroup().equals("Gen - Options")){
					   genval = PLMUtils.convertCostCycle(finalcostCycleResultList.get(j).getProdCostSite()+finalcostCycleResultList.get(j).getResEngFieldTransCost());
					   if (null != genMarketNmMap.get(marketNM)) {
						   genval += genMarketNmMap.get(marketNM);
					   }
					   LOG.info("marketNM >> " + marketNM + " genval >> " + genval);
					   genMarketNmMap.put(finalcostCycleResultList.get(j).getResTFMktName(), genval);
			   }
			   
			   else if(finalcostCycleResultList.get(j).getResCostGroup().equals("Steam")|| finalcostCycleResultList.get(j).getResCostGroup().equals("Steam - Options")){
					   steamval = PLMUtils.convertCostCycle(finalcostCycleResultList.get(j).getProdCostSite()+finalcostCycleResultList.get(j).getResEngFieldTransCost());
					   if (null != steamMarketNmMap.get(marketNM)) {
						   steamval += steamMarketNmMap.get(marketNM);
					   }
					   steamMarketNmMap.put(finalcostCycleResultList.get(j).getResTFMktName(), steamval);
			   }
			 }
		   }
		 
		LOG.info(" finalcostCycleResultList>>"+ finalcostCycleResultList.size());
	     double prdSiteFieldCalGas =0;
		 double prdSiteFieldCalGen =0;
		 double prdSiteFieldCalSteam =0;
	 
		 LOG.info("gas map size " + gasMarketNmMap.size());
			 if(gasMarketNmMap.size()>0){ 
				 List<String> gasKey = new ArrayList<String>(gasMarketNmMap.keySet());				
				 for(int gas=0;gas < gasKey.size();gas++){
					 String key = gasKey.get(gas);
					 Double gasVal = gasMarketNmMap.get(key);	
						
					 costCycleCalData = new PLMCostCycleSmryData();
					 costCycleCalData.setTotalCostSmry(key + " Total Cost");
					 costCycleCalData.setPrdSiteFieldTranCost(gasVal);
					 costCycleCalData.setSumFlag(false);
					 gasGrpList.add(costCycleCalData);
					 prdSiteFieldCalGas += gasVal;
				 }
				  Collections.sort(gasGrpList, new SortGasGroup());
				 
				  costCycleCalData = new PLMCostCycleSmryData();
				  costCycleCalData.setTotalCostSmry("SubCost Gas (SubTots (Product Cost (Site) + Field Eng Trans Cost)):");
				  costCycleCalData.setPrdSiteFieldTranCost(PLMUtils.convertCostCycle(prdSiteFieldCalGas));
				  costCycleCalData.setSumFlag(true);
				  gasGrpList.add(costCycleCalData);
				  LOG.info("gasGrpList size " + gasGrpList.size());
				  
			 }
			 
		 LOG.info("gen map size " + genMarketNmMap.size());
			 if(genMarketNmMap.size()>0){ 
				  
				 List<String> genKey = new ArrayList<String>(genMarketNmMap.keySet());				
				 for(int gen=0;gen < genKey.size();gen++){
					 String key = genKey.get(gen);
					 Double genVal = genMarketNmMap.get(key);	
						
					 costCycleCalData = new PLMCostCycleSmryData();
					 costCycleCalData.setTotalCostSmry(key + " Total Cost");
					 costCycleCalData.setPrdSiteFieldTranCost(genVal);
					 costCycleCalData.setSumFlag(false);
					 genGrpList.add(costCycleCalData);
					 prdSiteFieldCalGen += genVal;
				}
	
				  Collections.sort(genGrpList, new SortGenGroup());
				 LOG.info("After for loop gen");
				  costCycleCalData = new PLMCostCycleSmryData();
				  costCycleCalData.setTotalCostSmry("SubCost Gen (SubTots (Product Cost (Site) + Field Eng Trans Cost)):");
				  costCycleCalData.setPrdSiteFieldTranCost(PLMUtils.convertCostCycle(prdSiteFieldCalGen));
				  costCycleCalData.setSumFlag(true);
				  genGrpList.add(costCycleCalData);
				  LOG.info("genGrpList size " + genGrpList.size());
			}
		 
		 LOG.info("steam map size " + steamMarketNmMap.size());
			 if(steamMarketNmMap.size()>0){ 
				 
				 List<String> steamKey = new ArrayList<String>(steamMarketNmMap.keySet());				
				 for(int steam=0;steam < steamKey.size();steam++){
					 String key = steamKey.get(steam);
					 Double steamVal = steamMarketNmMap.get(key);	
						
					 costCycleCalData = new PLMCostCycleSmryData();
					 costCycleCalData.setTotalCostSmry(key + " Total Cost");
					 costCycleCalData.setPrdSiteFieldTranCost(steamVal);
					 costCycleCalData.setSumFlag(false);
					 steamGrpList.add(costCycleCalData);
					 
					 prdSiteFieldCalSteam += steamVal;
				}
	
				  Collections.sort(steamGrpList, new SortStmGroup());
				  costCycleCalData = new PLMCostCycleSmryData();
				  costCycleCalData.setTotalCostSmry("SubCost Steam (SubTots (Product Cost (Site) + Field Eng Trans Cost)):");
				  costCycleCalData.setPrdSiteFieldTranCost(PLMUtils.convertCostCycle(prdSiteFieldCalSteam));
				  costCycleCalData.setSumFlag(true);
				  steamGrpList.add(costCycleCalData);
				  LOG.info("steamGrpList size " + steamGrpList.size());
			}
		  costCycleCalData = new PLMCostCycleSmryData();
		  costCycleCalData.setTotalCostSmry("Total Cost (SubTots (Product Cost (Site) + Field Eng Trans Cost)):");
		  costCycleCalData.setPrdSiteFieldTranCost(PLMUtils.convertCostCycle(prdSiteFieldCalGas+prdSiteFieldCalGen+prdSiteFieldCalSteam));
		  costCycleCalData.setSumFlag(true);
		  totalCostList.add(costCycleCalData);
		  
		   costCycleResultMap.put("CostCycleResults", finalcostCycleResultList);
		   costCycleResultMap.put("gasGrpList", gasGrpList);
		   costCycleResultMap.put("genGrpList", genGrpList);
    	    costCycleResultMap.put("steamGrpList", steamGrpList);
    	    costCycleResultMap.put("totalCostList", totalCostList);
		    }else{
				   costCycleResultMap.put("CostCycleResults", finalcostCycleResultList);
				   costCycleResultMap.put("gasGrpList", gasGrpList);
		    	    costCycleResultMap.put("genGrpList", genGrpList);
		    	    costCycleResultMap.put("steamGrpList", steamGrpList);
		    	    costCycleResultMap.put("totalCostList", totalCostList);
		     }
 		LOG.info("Existing getCostCycleResult() in DAOImpl ");
		return costCycleResultMap;
		
	}
	/**
	 * 
	 * class to sort list of object of type PLMCostCycleSmryData.
	 * 
	 */
	private static class SortCostGroup implements Comparator<PLMCostCycleSmryData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMCostCycleSmryData aString,
				PLMCostCycleSmryData bString) {
			String aStr;
			String bStr;
			int result=0;
			aStr = aString.getResCostGroup();
			bStr = bString.getResCostGroup();
			if(aStr != null && bStr != null){
			result = aStr.compareTo(bStr);
			}
			return result;
			
		}
	}
	/**
	 * 
	 * class to sort list of object of type PLMCostCycleSmryData.
	 * 
	 */
	private static class SortGasGroup implements Comparator<PLMCostCycleSmryData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMCostCycleSmryData aString,
				PLMCostCycleSmryData bString) {
			String aStr;
			String bStr;
			int result=0;
			aStr = aString.getTotalCostSmry();
			bStr = bString.getTotalCostSmry();
			if(aStr != null && bStr != null){
			result = aStr.compareTo(bStr);
			}
			return result;
			
		}
	}
	/**
	 * 
	 * class to sort list of object of type PLMCostCycleSmryData.
	 * 
	 */
	private static class SortGenGroup implements Comparator<PLMCostCycleSmryData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMCostCycleSmryData aString,
				PLMCostCycleSmryData bString) {
			String aStr;
			String bStr;
			int result=0;
			aStr = aString.getTotalCostSmry();
			bStr = bString.getTotalCostSmry();
			if(aStr != null && bStr != null){
			result = aStr.compareTo(bStr);
			}
			return result;
			
		}
	}
	/**
	 * 
	 * class to sort list of object of type PLMCostCycleSmryData.
	 * 
	 */
	private static class SortStmGroup implements Comparator<PLMCostCycleSmryData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMCostCycleSmryData aString,
				PLMCostCycleSmryData bString) {
			String aStr;
			String bStr;
			int result=0;
			aStr = aString.getTotalCostSmry();
			bStr = bString.getTotalCostSmry();
			if(aStr != null && bStr != null){
			result = aStr.compareTo(bStr);
			}
			return result;
			
		}
	}
	
	/**
	 * 
	 * class to sort list of object of type PLMCostCycleSmryData.
	 * 
	 */
	private static class SortCOName implements Comparator<PLMCostCycleSmryData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMCostCycleSmryData aString,
				PLMCostCycleSmryData bString) {
			String aStr;
			String bStr;
			int result=0;
			aStr = aString.getResCOName();
			bStr = bString.getResCOName();
			if(aStr != null && bStr != null){
			result = aStr.compareTo(bStr);
			}
			return result;
			
		}
	}
	
	/**
	 * 
	 * class to sort list of object of type PLMCostCycleSmryData.
	 * 
	 */
	private static class SortTFMarketNM implements Comparator<PLMCostCycleSmryData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMCostCycleSmryData aString,
				PLMCostCycleSmryData bString) {
			String aStr;
			String bStr;
			int result=0;
			aStr = aString.getResTFMktName();
			bStr = bString.getResTFMktName();
			if(aStr != null && bStr != null){
			result = aStr.compareTo(bStr);
			}
			return result;
			
		}
	}
	
	/**
	 * Row mapper for getting CostCycleResultMapper
	 */
	private static final class CostCycleResultMapper implements ParameterizedRowMapper<PLMCostCycleSmryData>{	
	public PLMCostCycleSmryData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			
		PLMCostCycleSmryData costCycleData = new PLMCostCycleSmryData();
		
		//contractList.setContract(PLMUtils.checkNullVal(rs.getString(PLMConstants.CCS_CONTRACT)));
		costCycleData.setResCustReq(PLMUtils.checkNullVal(rs.getString(PLMConstants.RES_CR_NUM)));
		costCycleData.setResCustReqDesc(PLMUtils.checkNullVal(rs.getString(PLMConstants.RES_CR_DESC)));
		costCycleData.setResCRState(PLMUtils.checkNullVal(rs.getString(PLMConstants.RES_CR_STATE)));
		//costCycleData.setResContract(PLMUtils.checkNullVal(rs.getString(PLMConstants.RES_CONTRACT)));
		costCycleData.setResCostGroup(PLMUtils.checkNullVal(rs.getString(PLMConstants.RES_COST_GROUP)));
		costCycleData.setResCOName(PLMUtils.checkNullVal(rs.getString(PLMConstants.RES_CO_NAME)));
		costCycleData.setResCOState(PLMUtils.checkNullVal(rs.getString(PLMConstants.RES_CO_STATE)));
		costCycleData.setResTFMktName(PLMUtils.checkNullVal(rs.getString(PLMConstants.RES_TF_MKT_NAME)));
		costCycleData.setResLFDesc(PLMUtils.checkNullVal(rs.getString(PLMConstants.RES_LF_DESC)));
		costCycleData.setResUnitOfMeasure(PLMUtils.checkNullVal(rs.getString(PLMConstants.RES_UOM)));
		costCycleData.setResLocationCurrency(PLMUtils.checkNullVal(rs.getString(PLMConstants.RES_LOCN_CURR)));
		costCycleData.setResMaterialShipDirectCost(PLMUtils.convertCostCycle(rs.getDouble(PLMConstants.RES_MAT_SHIP_DIR_COST)));
		costCycleData.setResRawInProcessCost(PLMUtils.convertCostCycle(rs.getDouble(PLMConstants.RES_RAW_IN_PROCESS_COST)));		
		costCycleData.setResMfgLaborHours(PLMUtils.convertCostCycle(rs.getDouble(PLMConstants.RES_MFG_LABOR_HOURS)));
		costCycleData.setResProdCost(PLMUtils.convertCostCycle(rs.getDouble(PLMConstants.RES_PROD_COST)));
		costCycleData.setResShopWorkLabCost(PLMUtils.convertCostCycle(rs.getDouble(PLMConstants.RES_SHOP_LAB_COST)));
		costCycleData.setResDraftingHours(PLMUtils.convertCostCycle(rs.getDouble(PLMConstants.RES_DRAFTING_HOURS)));
		costCycleData.setResEnggHours(PLMUtils.convertCostCycle(rs.getDouble(PLMConstants.RES_ENGG_HOURS)));
		costCycleData.setResEnggTotalCost(PLMUtils.convertCostCycle(rs.getDouble(PLMConstants.RES_ENGG_TOTAL_COST)));
		costCycleData.setResTransportCost(PLMUtils.convertCostCycle(rs.getDouble(PLMConstants.RES_TRANSPORT_COST)));
		costCycleData.setResFieldInstallCost(PLMUtils.convertCostCycle(rs.getDouble(PLMConstants.RES_FIELD_INSTALL_COST)));		
		costCycleData.setResMfgExp(PLMUtils.convertCostCycle(rs.getDouble(PLMConstants.RES_MFG_EXP)));
		costCycleData.setResFieldTransInvCost(PLMUtils.convertCostCycle(rs.getDouble(PLMConstants.RES_FIELD_TRANS_COST)));
		costCycleData.setResEngFieldTransCost(PLMUtils.convertCostCycle(rs.getDouble(PLMConstants.RES_ENG_FIELD_TRANS_COST)));
		costCycleData.setResMfgMatLeadTime(PLMUtils.convertCostCycle(rs.getDouble(PLMConstants.RES_MAT_LEAD_TIME)));
		costCycleData.setResMfgPlannedLeadTime(PLMUtils.convertCostCycle(rs.getDouble(PLMConstants.RES_PLANNED_LEAD_TIME)));
		costCycleData.setResCycleTimeDrawings(PLMUtils.convertCostCycle(rs.getDouble(PLMConstants.RES_CYCLE_TIME_DRAWINGS)));
		costCycleData.setResProductConfig(PLMUtils.checkNullVal(rs.getString(PLMConstants.RES_PROD_CONFIG)));
		costCycleData.setResModelNum(PLMUtils.checkNullVal(rs.getString(PLMConstants.RES_MODEL_NUM)));
		costCycleData.setResEnggDisposition(PLMUtils.checkNullVal(rs.getString(PLMConstants.RES_ENGG_DISPOSITION)));
		costCycleData.setResPartName(PLMUtils.checkNullVal(rs.getString(PLMConstants.RES_PART_NAME)));
		
		
		return costCycleData;

		}
	}

	/** 
	 * Row mapper for getting UnitMeasureMapper
	 */
	private static final class UnitMeasureMapper implements ParameterizedRowMapper<PLMCostCycleSmryData>{	
	public PLMCostCycleSmryData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			
		PLMCostCycleSmryData unitMeasureData = new PLMCostCycleSmryData();
		unitMeasureData.setResProductConfig(PLMUtils.checkNullVal(rs.getString(PLMConstants.PC_NAME)));
		unitMeasureData.setNoOfUnits(PLMUtils.checkNullVal(rs.getString(PLMConstants.CO_VALUE)));
			
		return unitMeasureData;
	
		}
	}
	
	
	

}
