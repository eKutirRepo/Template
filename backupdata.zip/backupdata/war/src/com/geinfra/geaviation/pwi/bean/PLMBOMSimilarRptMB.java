/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBOMSimilarRptMB.java
 * @Creation date: 28-Oct-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMBOMSimilarData;
import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMBOMSimilarServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMBOMSimilarRptMB {
	/**
	 *  Holds the lOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMBOMSimilarRptMB.class);
	/**
	 *  Holds the plmBOMSimilarService
	 */
	private PLMBOMSimilarServiceIfc plmBOMSimilarService = null;
	/**
	 *  Holds the loginMB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	/**
	 *  Holds the bomAlertMsg
	 */
	private String bomAlertMsg;		
	
	private String partGrpInterst= "";
	/**
	 *  Holds the bomMatchLvl
	 */
	private String bomMatchLvl="95";
	 /**
	   * Holds the Properties file
	   */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 *  Holds the partIbomSmlrtyRptList
	 */
	private List<PLMBOMSimilarData> partIbomSmlrtyRptList =new ArrayList<PLMBOMSimilarData>();
	/**
	 *  Holds the commonmSmlrtyRptList
	 */
	private List<PLMBOMSimilarData> commonmSmlrtyRptList =new ArrayList<PLMBOMSimilarData>();
	/**
	 *  Holds the itemPartBomRptList
	 */
	private List<PLMBOMSimilarData> itemPartBomRptList =new ArrayList<PLMBOMSimilarData>();
	/**
	 *  Holds the itemSmlrtyRptList
	 */
	private List<PLMBOMSimilarData> itemSmlrtyRptList =new ArrayList<PLMBOMSimilarData>();
	/**
	 *  Holds the bomSimilarData
	 */
	private PLMBOMSimilarData bomSimilarData =new PLMBOMSimilarData();
	/**
	  * Holds the efftStrDate
	  */
	 private Date efftStrDate;
	 
	 /**
	  * Holds the efftEndDate
	  */
	 private Date efftEndDate;
	
	/**
	 * Holds the SIMPLE_DATE_FORMAT
	 */
	 
	 private PLMPwiUserData userDetails = null;
	
	private PLMLoginData userDataObj = (PLMLoginData) PLMUtils
	.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA);
	
	private final static XSSFColor GREEN = new XSSFColor(new java.awt.Color(0, 176, 80));   
	
	private final static XSSFColor GRAY = new XSSFColor(new java.awt.Color(191, 191, 191));   

	private final static XSSFColor GREEN_LIGHT = new XSSFColor(new java.awt.Color(196, 215, 155)); 

	private final static XSSFColor RED_LIGHT = new XSSFColor(new java.awt.Color(230, 184, 183));   

	
	/**
	 * This method is used to load home page of BOM Similarity Home page 
	 * 
	 * @return String
	 * @throws PLMCommonException 
	 */
	public String getBOMSmlrtyHomePage() {
		LOG.info("Entering getBOMSmlrtyHomePage method");
		
		try {
			commonMB.insertCannedRptRecordHitInfo("BOM Similarity Report");
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo:", exception);
		}
		String fwdFlag="bomSimilaritySrchRpt";
		partGrpInterst="";
		bomAlertMsg="";
		bomMatchLvl="95";
		efftStrDate=null;
		efftEndDate=null;
		commonmSmlrtyRptList =new ArrayList<PLMBOMSimilarData>();
		itemPartBomRptList =new ArrayList<PLMBOMSimilarData>();
		itemSmlrtyRptList =new ArrayList<PLMBOMSimilarData>();
		bomSimilarData=new PLMBOMSimilarData();
	    LOG.info("Exiting getBOMSmlrtyHomePage method");
		return fwdFlag;
		
	}
	/**
	 * This method is used for validating part/Group Interest
	 * 
	 *@return String
	 */
	public String validationForBOMSmlrtyRpt(String contractNumLcl){
		bomAlertMsg = "";
		if (PLMUtils.isEmpty(contractNumLcl)) {
			bomAlertMsg =  PLMConstants.BOM_SIMILARITY_RERORT_ALERT;
		} 
		else if (PLMUtils.checkSplCharsProjSumry(contractNumLcl)){
			bomAlertMsg = PLMConstants.WHERE_USED_SPL_CRITERIA;
		}
		else if((!PLMUtils.isEmptyDate(efftStrDate)
			      && PLMUtils.isEmptyDate(efftEndDate))
			      ||(PLMUtils.isEmptyDate(efftStrDate)
					      && !PLMUtils.isEmptyDate(efftEndDate)))
		  {
		  bomAlertMsg = PLMConstants.BOM_SIMILARITY_DATE;
		  }
		else if (PLMUtils.checkForFromAndToDate(efftStrDate, efftEndDate)) {
			bomAlertMsg =  PLMConstants.WHERE_USED_DATE;
		}
		
		return bomAlertMsg;
	}

	 /**
	 * @throws PWiException 
	 * This method is used for generateEnvComplianceRpt
	 * 
	 * @return String
	 * @throws
	 */
     public void generateBomSmlrtyRpt() throws PLMCommonException, PWiException{
		LOG.info("Entering generateBomSmlrtyRpt Method");
		userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		bomAlertMsg = validationForBOMSmlrtyRpt(partGrpInterst);
		  if(PLMUtils.isEmpty(bomAlertMsg)){
			 bomAlertMsg =  PLMConstants.BOM_SIMILARITY_MAIL_RERORT_ALERT;
        	 LOG.info("Mail send succesfully");
			 taskExecutor.execute(new MailThread());
	       }
 		LOG.info("Exiting generateBomSmlrtyRpt Method");
		
	}
     /**
		 * Background Process Thread
		 */
		private class MailThread implements Runnable {
			public MailThread(){}
			public void run() {
				sendBOMSmlrtyReportMail();
			}
		}
		
		
		/**
		 * This method is used for Generating & Sending the Report to mail
		 * 
		 * @return String
		 */
		public void sendBOMSmlrtyReportMail() {
			LOG.info("Entering sendBOMSmlrtyReportMail Method");
			LOG.info("partGrpInterst>>>>>>>"+partGrpInterst);
			if (partGrpInterst!=null) {
				String partGrpInterstLcl = partGrpInterst;
				String bomMatchLvlLcl = bomMatchLvl;
			String from = PLMConstants.BOM_SIMILARITY_MAIL_FROM;
			String to = userDetails.getUserEmailId();		
			String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
			toAddressee = "Dear " + toAddressee + ", \n\n";
			String subject = PLMConstants.BOM_SIMILARITY_MAIL_FROM_MAIL_SUBJECT + partGrpInterst;
			StringBuffer mailBody = new StringBuffer().append(toAddressee)
			.append(PLMConstants.BOM_SIMILARITY_MAIL_FROM_MAIL_CONTENT)
			.append(partGrpInterst)
			.append(".")
			.append(PLMConstants.BOM_SIMILARITY_MAIL_SIGNATURE)
			.append(PLMConstants.BOM_SIMILARITY_MAIL_FOOTER);
			
			StringBuffer mailNoDataBody = new StringBuffer()
			.append(toAddressee)
			.append(PLMConstants.BOM_SIMILARITY_NO_CONTENT_BODY)
			.append(partGrpInterst)
			.append(".")
			.append(PLMConstants.BOM_SIMILARITY_MAIL_SIGNATURE)
			.append(PLMConstants.BOM_SIMILARITY_MAIL_FOOTER);
			
			final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
			Date uniqDate = new Date();
			String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
			String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
			String filePathXlsx = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("BOM_SMLRTY_RPT_NM") +  partGrpInterst + "_" + uniqTime + ".xlsx";
			String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("BOM_SMLRTY_RPT_NM") +  partGrpInterst + "_" + uniqTime + ".zip";
			File file = null;
			try {
				Map<String, List<PLMBOMSimilarData>> bomSmlrtyRptMap = plmBOMSimilarService.getBOMSmrltyRptDetails(partGrpInterstLcl, bomMatchLvlLcl,efftStrDate, efftEndDate);
				partIbomSmlrtyRptList = bomSmlrtyRptMap.get("partIbomSmlrtyRptList");
				commonmSmlrtyRptList = bomSmlrtyRptMap.get("commonmSmlrtyRptList");
				 
				if ((partIbomSmlrtyRptList!=null && partIbomSmlrtyRptList.size()>0)||
					(commonmSmlrtyRptList!=null && commonmSmlrtyRptList.size()>0)) {
					saveBomSmlrtyFile(partGrpInterstLcl,bomMatchLvlLcl,partIbomSmlrtyRptList,commonmSmlrtyRptList,bomSmlrtyRptMap,fileDir,filePathXlsx);
					PLMUtils.generateZipFile(filePathXlsx,filePathZip);
					file = new File(filePathZip);
					// Get the number of bytes in the file
					float sizeInBytes = file.length();
					//transform in MB
					float sizeInMb = sizeInBytes / (1024 * 1024);
					LOG.info("Zip File Size for BOM Similarity Report "+sizeInMb+" MB");
					PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
					LOG.info("BOM Similarity Report Attachment Mail sent successfully.");
				} else {				
					PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
					LOG.info("No data Mail sent");
				}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@sendBOMSmlrtyReportMail: ", exception);
				PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.BOM_SIMILARITY_MAIL_SIGNATURE);
			} catch (Exception exception) {
				LOG.log(Level.ERROR, "Exception@sendBOMSmlrtyReportMail: ", exception);
				PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.BOM_SIMILARITY_MAIL_SIGNATURE);
			} finally {
				deleteFiles(filePathXlsx,filePathZip);
				/*if (file!=null)
					file.delete();*/
			}
			LOG.info("Exiting sendBOMSmlrtyReportMail Method");
			} else {
				LOG.info("Not able to generate the report. The part /Group Interest is "+partGrpInterst);
			}
		}
		

		/**
		 * This method is used for Generating Report in XLS
		 * 
		 * @param partGrpInterst,bomSmlrtyRptListLcl,commonSmlrtyRptListLcl,fileDir,filePathXlsx
		 * @return StringBuffer
		 * @throws IOException
		 */
		
		public void saveBomSmlrtyFile(String partGrpInterstLcl,String bomMatchLvlLcl,List<PLMBOMSimilarData> bomSmlrtyRptListLcl,
				List<PLMBOMSimilarData> commonSmlrtyRptListLcl,Map<String, List<PLMBOMSimilarData>> bomSmlrtyRptMap,String fileDir,String filePathXlsx) throws IOException {
			LOG.info("Entering saveBomSmlrtyFile File Method");
			FileOutputStream fileOut = null;
			boolean createFileExist;
			itemPartBomRptList = new ArrayList<PLMBOMSimilarData>();
			itemSmlrtyRptList = new ArrayList<PLMBOMSimilarData>();

			final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
			"MM/dd/yyyy");
			try {
				/*File file = new File(fileDir);
				boolean dirExists = file.exists();
				if (!dirExists) {	
					file.mkdir();
				}*/
				File fileName = new File(filePathXlsx);
				boolean fileExist = fileName.exists();
				if(!fileExist) {
					createFileExist =fileName.createNewFile();
					LOG.info("createFileExist>>>>.."+createFileExist);
			 	}
				if (fileName.exists()) {
					fileOut = new FileOutputStream(filePathXlsx);
					SXSSFWorkbook workbook = new SXSSFWorkbook();
					SXSSFSheet sheet =  (SXSSFSheet) workbook.createSheet("BOM Similarity");
						
					XSSFFont font = (XSSFFont) workbook.createFont(); 
					font.setFontName(PLMConstants.EXCEL_FONT_NAME);
					font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
					font.setFontHeightInPoints((short)10);
					
					XSSFCellStyle cellBoldStyle = (XSSFCellStyle) workbook.createCellStyle();
					cellBoldStyle = setBorderStyle(cellBoldStyle);
					cellBoldStyle.setFont(font);
					
					
					XSSFCellStyle cellBoldStyle1 = (XSSFCellStyle) workbook.createCellStyle();
					cellBoldStyle1 = setBorderStyle(cellBoldStyle1);
					cellBoldStyle1.setFont(font);
					cellBoldStyle1.setAlignment(CellStyle.ALIGN_CENTER);
					cellBoldStyle1.setVerticalAlignment(VerticalAlignment.TOP);
				
					XSSFCellStyle cellBoldStyleCenter = (XSSFCellStyle) workbook.createCellStyle();
					cellBoldStyleCenter = setBorderStyle(cellBoldStyleCenter);
					cellBoldStyleCenter.setFont(font);
					cellBoldStyleCenter.setAlignment(CellStyle.ALIGN_CENTER);
					cellBoldStyleCenter.setVerticalAlignment(VerticalAlignment.TOP);
				
					XSSFCellStyle commonStyleCenter = (XSSFCellStyle) workbook.createCellStyle();
					commonStyleCenter = setBorderStyle(commonStyleCenter);
					commonStyleCenter.setFont(font);
					commonStyleCenter.setAlignment(CellStyle.ALIGN_CENTER);
					commonStyleCenter.setVerticalAlignment(VerticalAlignment.TOP);
					commonStyleCenter.setFillForegroundColor(GREEN); 
					commonStyleCenter.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
					
					XSSFCellStyle diffStyl1 = (XSSFCellStyle) workbook.createCellStyle();
					diffStyl1 = setBorderStyle(diffStyl1);
					diffStyl1.setFont(font);
					diffStyl1.setAlignment(CellStyle.ALIGN_CENTER);
					diffStyl1.setVerticalAlignment(VerticalAlignment.TOP);
					diffStyl1.setFillForegroundColor(RED_LIGHT); 
					diffStyl1.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			
					
					XSSFCellStyle diffStyl2 = (XSSFCellStyle) workbook.createCellStyle();
					diffStyl2 = setBorderStyle(diffStyl2);
					diffStyl2.setFont(font);
					diffStyl2.setAlignment(CellStyle.ALIGN_CENTER);
					diffStyl2.setVerticalAlignment(VerticalAlignment.TOP);
					diffStyl2.setFillForegroundColor(GREEN_LIGHT); 
					diffStyl2.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			
					XSSFCellStyle coloumnStyleCenter = (XSSFCellStyle) workbook.createCellStyle();
					coloumnStyleCenter = setBorderStyle(coloumnStyleCenter);
					coloumnStyleCenter.setFont(font);
					coloumnStyleCenter.setAlignment(CellStyle.ALIGN_CENTER);
					coloumnStyleCenter.setVerticalAlignment(VerticalAlignment.TOP);
					coloumnStyleCenter.setFillForegroundColor(GRAY); 
					coloumnStyleCenter.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
				
					
					XSSFFont nonBoldFont = (XSSFFont) workbook.createFont();
					nonBoldFont.setFontHeightInPoints((short)10);
					nonBoldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
					XSSFCellStyle contentStyle = (XSSFCellStyle) workbook.createCellStyle();				
					contentStyle = setBorderStyle(contentStyle);
					contentStyle.setFont(nonBoldFont);
					contentStyle.setAlignment(CellStyle.ALIGN_CENTER);
					
				
					int rowcount = -1;
					
						SXSSFRow row = (SXSSFRow)sheet.createRow(++rowcount);
						SXSSFCell cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						cell.setCellValue("Part/Group Interest");
						cell.setCellStyle(cellBoldStyle);

						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellValue(partGrpInterstLcl);
						cell.setCellStyle(contentStyle);
						
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						cell.setCellValue("Match Level Selection");
						cell.setCellStyle(cellBoldStyle);

						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellValue(bomMatchLvlLcl+"%");
						cell.setCellStyle(contentStyle);
						
					if(bomSimilarData.getEfftStrDate()!=null && bomSimilarData.getEfftEndDate()!=null){	
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						cell.setCellValue("Effective Date From");
						cell.setCellStyle(cellBoldStyle);

						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellValue(SIMPLE_DATE_FORMAT.format(bomSimilarData.getEfftStrDate()));
						cell.setCellStyle(contentStyle);
						
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						cell.setCellValue("Effective Date To");
						cell.setCellStyle(cellBoldStyle);

						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellValue(SIMPLE_DATE_FORMAT.format(bomSimilarData.getEfftEndDate()));
						cell.setCellStyle(contentStyle);
					}	
						String[] commColNames = {" ","Item","Description","Qty"};
						String[] diffColNames = {" ","Item","Parent","Description"};
						int count=0;
						for(int i=0;i<bomSmlrtyRptListLcl.size();i++){
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							count = rowcount;
					     if(commonSmlrtyRptListLcl.size()>0){		
							cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell.setCellValue(bomSmlrtyRptListLcl.get(i).getParent());
							cell.setCellStyle(cellBoldStyle1);
							
							cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE); 
							cell.setCellValue("Common Report");
							cell.setCellStyle(commonStyleCenter);
							cell =(SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
							cell.setCellStyle(commonStyleCenter);
							cell =(SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
							cell.setCellStyle(commonStyleCenter);
							sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ONE,PLMConstants.EXCEL_COL_THREE));
							cell.setCellStyle(commonStyleCenter);
						
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							for (int j = 0 ; j < commColNames.length; j++) {
								cell = (SXSSFCell) row.createCell(j);
								cell. setCellValue(commColNames[j]);
								cell.setCellStyle(coloumnStyleCenter);
							}
						     for(int x=0;x<commonSmlrtyRptListLcl.size();x++){	
								PLMBOMSimilarData dataObj1 = (PLMBOMSimilarData) commonSmlrtyRptListLcl.get(x);
								if (dataObj1.getParent().equals(bomSmlrtyRptListLcl.get(i).getParent())) {
									row = (SXSSFRow) sheet.createRow(++rowcount);
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ZERO);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(" ");
									
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getItem());
									
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWO);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getDescription());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THREE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getQuantity());
								}
						     }
						 } 
							
							itemPartBomRptList = bomSmlrtyRptMap.get(bomSmlrtyRptListLcl.get(i).getParent()+"~a");
						
						  if(itemPartBomRptList.size()>0){	
								row = (SXSSFRow) sheet.createRow(++rowcount);
								cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
								cell.setCellValue("");
								cell.setCellStyle(contentStyle);
								
							 	cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE); 
								cell.setCellValue("Different Report (Items Unique to the Search Item)");
							   cell.setCellStyle(diffStyl1);
								cell =(SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
								cell.setCellStyle(diffStyl1);
								cell =(SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
								cell.setCellStyle(diffStyl1);
								sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ONE,PLMConstants.EXCEL_COL_THREE));
								cell.setCellStyle(diffStyl1);
								row = (SXSSFRow) sheet.createRow(++rowcount);
							for ( int j = 0 ; j < diffColNames.length; j++ ) {
								cell = (SXSSFCell) row.createCell(j);
								cell. setCellValue(diffColNames[j]);
								cell.setCellStyle(coloumnStyleCenter);
							}
							 for(int y=0;y<itemPartBomRptList.size();y++){	
								PLMBOMSimilarData dataObj2 = (PLMBOMSimilarData) itemPartBomRptList.get(y);
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ZERO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue("");
							
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj2.getItem());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(partGrpInterstLcl);
								
							
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THREE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj2.getDescription());
							 }
						 }	
						  
						  
						  
						  itemSmlrtyRptList = bomSmlrtyRptMap.get(bomSmlrtyRptListLcl.get(i).getParent()+"~b");
						 
					      if(itemSmlrtyRptList.size()>0){	
					    	row = (SXSSFRow) sheet.createRow(++rowcount);
					    	cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell.setCellValue("");
							cell.setCellStyle(contentStyle);
								
						 	cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE); 
							cell.setCellValue("Different Report (Items Unique to the Search Results)");
							cell.setCellStyle(diffStyl2);
							cell =(SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
							cell.setCellStyle(diffStyl2);
							cell =(SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
							cell.setCellStyle(diffStyl2);
							sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ONE,PLMConstants.EXCEL_COL_THREE));
							cell.setCellStyle(diffStyl2);
							row = (SXSSFRow) sheet.createRow(++rowcount);	 
							for ( int j = 0 ; j < diffColNames.length; j++ ) {
								cell = (SXSSFCell) row.createCell(j);
								cell. setCellValue(diffColNames[j]);
								cell.setCellStyle(coloumnStyleCenter);
							}
							
							 for(int z=0;z<itemSmlrtyRptList.size();z++){	
								PLMBOMSimilarData dataObj3 = (PLMBOMSimilarData) itemSmlrtyRptList.get(z);
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ZERO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue("");
							
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj3.getItem());
								
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(bomSmlrtyRptListLcl.get(i).getParent());
								
							
								cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THREE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj3.getDescription());
							 }
						  }	
						
					      sheet.addMergedRegion(new CellRangeAddress(count, rowcount, PLMConstants.EXCEL_COL_ZERO, PLMConstants.EXCEL_COL_ZERO));
					     
						}
						
						short colWidth2 = (short)7000;
						short colWidth4 = (short)7900;
						short colWidth5 = (short)8600;
						short colWidth6 = (short)9500;
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,colWidth4);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,colWidth2);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,colWidth5);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,colWidth6);
						
					workbook.write(fileOut);
					fileOut.close();
				}
			} catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@saveEnvComplianceFile File: ", e);
				throw e;
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveEnvComplianceFile File: ", e);
				throw e;
			}  finally {
				try {
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@saveEnvComplianceFile: ", e);
					throw e;
				}
			}
			LOG.info("Exiting saveEnvComplianceFile File Method");
		}
		/**
		 * This method is used for Bordering Cell in XLSX
		 * 
		 * @return StringBuffer
		 */
		private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
			style.setBorderTop(XSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			style.setBorderRight(XSSFCellStyle.BORDER_THIN);
			return style;
		}
		
		/**
		 * This method is used for Deleting zip file and xls file
		 * 
		 *@param filePathXls,filePathZip
		 */
		public void deleteFiles(String filePathXls,String filePathZip){
			LOG.info("Entering deleteFiles method");
			boolean zipFileExist;
			boolean xlsFileExist;
			File zipFile = new File(filePathZip);
			zipFileExist = zipFile.exists();
			File xlsFile = new File(filePathXls);
			xlsFileExist = xlsFile.exists();
			if(zipFileExist){
				boolean deleted = zipFile.delete();
				LOG.info("Successfully deleted zip file : " + deleted);
			}
			if(xlsFileExist){
				boolean deleted = xlsFile.delete();
				LOG.info("Successfully deleted xls file : " + deleted);
			}
			LOG.info("Exiting deleteFiles Method");
		}
	/**
	 * @return the plmBOMSimilarService
	 */
	public PLMBOMSimilarServiceIfc getPlmBOMSimilarService() {
		return plmBOMSimilarService;
	}
	/**
	 * @param plmBOMSimilarService the plmBOMSimilarService to set
	 */
	public void setPlmBOMSimilarService(PLMBOMSimilarServiceIfc plmBOMSimilarService) {
		this.plmBOMSimilarService = plmBOMSimilarService;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}
	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the bomAlertMsg
	 */
	public String getBomAlertMsg() {
		return bomAlertMsg;
	}
	/**
	 * @param bomAlertMsg the bomAlertMsg to set
	 */
	public void setBomAlertMsg(String bomAlertMsg) {
		this.bomAlertMsg = bomAlertMsg;
	}
	/**
	 * @return the partGrpInterst
	 */
	public String getPartGrpInterst() {
		return partGrpInterst;
	}
	/**
	 * @param partGrpInterst the partGrpInterst to set
	 */
	public void setPartGrpInterst(String partGrpInterst) {
		this.partGrpInterst = partGrpInterst;
	}
	/**
	 * @return the bomMatchLvl
	 */
	public String getBomMatchLvl() {
		return bomMatchLvl;
	}
	/**
	 * @param bomMatchLvl the bomMatchLvl to set
	 */
	public void setBomMatchLvl(String bomMatchLvl) {
		this.bomMatchLvl = bomMatchLvl;
	}
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}
	
	/**
	 * @return the partIbomSmlrtyRptList
	 */
	public List<PLMBOMSimilarData> getPartIbomSmlrtyRptList() {
		return partIbomSmlrtyRptList;
	}
	/**
	 * @param partIbomSmlrtyRptList the partIbomSmlrtyRptList to set
	 */
	public void setPartIbomSmlrtyRptList(
			List<PLMBOMSimilarData> partIbomSmlrtyRptList) {
		this.partIbomSmlrtyRptList = partIbomSmlrtyRptList;
	}
	/**
	 * @return the commonmSmlrtyRptList
	 */
	public List<PLMBOMSimilarData> getCommonmSmlrtyRptList() {
		return commonmSmlrtyRptList;
	}
	/**
	 * @param commonmSmlrtyRptList the commonmSmlrtyRptList to set
	 */
	public void setCommonmSmlrtyRptList(List<PLMBOMSimilarData> commonmSmlrtyRptList) {
		this.commonmSmlrtyRptList = commonmSmlrtyRptList;
	}
	/**
	 * @return the itemPartBomRptList
	 */
	public List<PLMBOMSimilarData> getItemPartBomRptList() {
		return itemPartBomRptList;
	}
	/**
	 * @param itemPartBomRptList the itemPartBomRptList to set
	 */
	public void setItemPartBomRptList(List<PLMBOMSimilarData> itemPartBomRptList) {
		this.itemPartBomRptList = itemPartBomRptList;
	}
	/**
	 * @return the itemSmlrtyRptList
	 */
	public List<PLMBOMSimilarData> getItemSmlrtyRptList() {
		return itemSmlrtyRptList;
	}
	/**
	 * @param itemSmlrtyRptList the itemSmlrtyRptList to set
	 */
	public void setItemSmlrtyRptList(List<PLMBOMSimilarData> itemSmlrtyRptList) {
		this.itemSmlrtyRptList = itemSmlrtyRptList;
	}
	/**
	 * @return the bomSimilarData
	 */
	public PLMBOMSimilarData getBomSimilarData() {
		return bomSimilarData;
	}
	/**
	 * @param bomSimilarData the bomSimilarData to set
	 */
	public void setBomSimilarData(PLMBOMSimilarData bomSimilarData) {
		this.bomSimilarData = bomSimilarData;
	}
	

	/**
	 * @return the efftStrDate
	 */
	public Date getEfftStrDate() {
		Date efftStrDt=efftStrDate;
		return efftStrDt;
	}
	/**
	 * @param efftStrDate the efftStrDate to set
	 */
	public void setEfftStrDate(Date efftStrDate) {
		Date efftStrDt=efftStrDate;
		this.efftStrDate = efftStrDt;
	}
	
	/**
	 * @return the efftEndDate
	 */
	public Date getEfftEndDate() {
		Date efftEndDt=efftEndDate;
		return efftEndDt;
	}
	/**
	 * @param efftEndDate the efftEndDate to set
	 */
	public void setEfftEndDate(Date efftEndDate) {
		Date efftEndDt=efftEndDate;
		this.efftEndDate = efftEndDt;
	}
	
}
