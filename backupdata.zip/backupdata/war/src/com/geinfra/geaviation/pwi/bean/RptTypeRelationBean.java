/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName RptTypeRelationBean.java
 * @Creation date: 18-June-2014
 * @version 1.0
  * @author : Tech Mahindra
 */

package com.geinfra.geaviation.pwi.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.el.ELContext;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.xml.bind.JAXBElement;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.bean.util.BeanUtil;
import com.geinfra.geaviation.pwi.bean.util.RptTypeRelMetaDataUtil;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.QueriesVO;
import com.geinfra.geaviation.pwi.model.RptTypeRelationVo;
import com.geinfra.geaviation.pwi.service.QueriesService;
import com.geinfra.geaviation.pwi.service.RptTypeRelationService;
import com.geinfra.geaviation.pwi.service.vo.TypeRelationData;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.xml.QueryXmlReader;
import com.geinfra.geaviation.pwi.xml.query.AllowedoperatorsType;
import com.geinfra.geaviation.pwi.xml.query.ColumnType;
import com.geinfra.geaviation.pwi.xml.query.DbobjectType;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.query.SelectionitemType;
import com.geinfra.geaviation.pwi.xml.query.SqlExecutorXml;

public class RptTypeRelationBean extends BaseBean {
	private static final Logger LOG = Logger
			.getLogger(RptTypeRelationBean.class);
	private String rptTemplateName;
	private String rptTemplateDesc;
	private String rptTemplatekeyWord;
	private int rptTempQuryId;
	private List<SelectItem> typeList = new ArrayList<SelectItem>();
	private List<SelectItem> relationList;
	private List<RptTypeRelationVo> rowType = new ArrayList<RptTypeRelationVo>();
	private RptTypeRelationService rptTypeRelationService;
	private Map<String, QueryType> columnConfDetails = new HashMap<String, QueryType>();
	private int rowlistSize = 0;
	private int selectedRowId = 50;
	private String alertMessage = "";
	
	private String selectedTabName = "tab1";
	private String errorMessage = "";
	private String errorMessageRTN = "";
	private boolean nextFlagTab1 = true;
	private QueriesService queriesService;
	private List<TypeRelationData> listTypeRelData;
	private List<String> typeRelList = new ArrayList<String>() ;
	
	private Map<String, Map<String, RptTypeRelationVo>> rowMap = new HashMap<String, Map<String, RptTypeRelationVo>>();
	private boolean genNewRptTemp = true;

	public boolean isGenNewRptTemp() {
		return genNewRptTemp;
	}

	public void setGenNewRptTemp(boolean genNewRptTemp) {
		this.genNewRptTemp = genNewRptTemp;
	}

	public int getRowlistSize() {
		if (rowType != null) {
			rowlistSize = rowType.size();
		}

		return rowlistSize;
	}

	public void setRowlistSize(int rowlistSize) {
		this.rowlistSize = rowlistSize;
	}



	public List<TypeRelationData> getListTypeRelData() throws PWiException {
		if (listTypeRelData == null) {
			listTypeRelData = rptTypeRelationService.getTypeRelData();
		}
		return listTypeRelData;
	}

	public void setListTypeRelData(List<TypeRelationData> listTypeRelData) {
		this.listTypeRelData = listTypeRelData;
	}
	
	

	public List<String> getTypeRelList() {
		return typeRelList;
	}

	public void setTypeRelList(List<String> typeRelList) {
		this.typeRelList = typeRelList;
	}

	public String getRptTemplateName() {
		return rptTemplateName;
	}

	public void setRptTemplateName(String rptTemplateName) {
		this.rptTemplateName = rptTemplateName;
	}
	

	public String getRptTemplateDesc() {
		return rptTemplateDesc;
	}

	public void setRptTemplateDesc(String rptTemplateDesc) {
		this.rptTemplateDesc = rptTemplateDesc;
	}

	public String getRptTemplatekeyWord() {
		return rptTemplatekeyWord;
	}

	public void setRptTemplatekeyWord(String rptTemplatekeyWord) {
		this.rptTemplatekeyWord = rptTemplatekeyWord;
	}

	public int getRptTempQuryId() {
		return rptTempQuryId;
	}

	public void setRptTempQuryId(int rptTempQuryId) {
		this.rptTempQuryId = rptTempQuryId;
	}

	public List<SelectItem> getRelationList() {
		return relationList;
	}

	public void setRelationList(List<SelectItem> relationList) {
		this.relationList = relationList;
	}

	public List<RptTypeRelationVo> getRowType() {
		RptTypeRelMetaDataUtil metaDataUtil = new RptTypeRelMetaDataUtil();
		
			if (rowType == null) {
				rowType = new ArrayList<RptTypeRelationVo>();
				rowType.add(new RptTypeRelationVo(1, "Type", "Select",
						metaDataUtil.getAllFromType()));
			}/*else if (rowType == null)
			{
				rowType = new ArrayList<RptTypeRelationVo>();
				rowType.add(new RptTypeRelationVo(1, "Type", "Select",
						metaDataUtil.getAllFromType()));
			}*/
		

		return rowType;
	}

	public void setRowType(List<RptTypeRelationVo> rowType) {
		this.rowType = rowType;
	}

	public Map<String, QueryType> getColumnConfDetails() {
		return columnConfDetails;
	}

	public void setColumnConfDetails(Map<String, QueryType> columnConfDetails) {
		this.columnConfDetails = columnConfDetails;
	}

	public void setTypeList(List<SelectItem> typeList) {
		this.typeList = typeList;
	}

	public RptTypeRelationService getRptTypeRelationService() {
		return rptTypeRelationService;
	}

	public void setRptTypeRelationService(
			RptTypeRelationService rptTypeRelationService) {
		this.rptTypeRelationService = rptTypeRelationService;
	}

	
	
	/*
	 * public String getColumnFrTypeJson() {
	 * 
	 * if (columnFrTypeJson == null) { loadColumnFrType(); } return
	 * columnFrTypeJson; }
	 */

	public Map<String, Map<String, RptTypeRelationVo>> getRowMap() {
		return rowMap;
	}

	public void setRowMap(Map<String, Map<String, RptTypeRelationVo>> rowMap) {
		this.rowMap = rowMap;
	}

	
	public QueriesService getQueriesService() {
		return queriesService;
	}

	public void setQueriesService(QueriesService queriesService) {
		this.queriesService = queriesService;
	}

	/*public List<SelectItem> getTypeList() {
		if (typeList == null) {
			if (listTypeRelData!=null) {
				for (int i = 0; i < listTypeRelData.size(); i++) {
					typeList.add(new SelectItem(listTypeRelData.get(i)
							.getFromType(), listTypeRelData.get(i).getFromType()));
	
				}
			}
		}
		return typeList;
	}*/

	public String addTypeRelationRow() {

		if (rowType.get(rowType.size() - 1).getSelType().equals("Select")
				|| rowType.get(rowType.size() - 1).getSelTypeRelVal()
						.equals("Select")) {
			LOG.info("Some input value is not selected...");
			// alertMessage="Please select values for all drop down boxes.....";
			errorMessage = "Please select values for all drop down boxes.";
			return "";
		} else {
			errorMessage = "";
			RptTypeRelMetaDataUtil metaDataUtil = new RptTypeRelMetaDataUtil();
			if (rowType.size() % 2 != 0) {
				String selTypeRelVal = rowType.get(rowType.size() - 1)
						.getSelTypeRelVal();
				String fromType = selTypeRelVal.substring(selTypeRelVal
						.indexOf("-") + 1);
				int rowId = rowType.size() + 1;
				// rowType = new ArrayList<RptTypeRelationVo>();
				rowType.add(new RptTypeRelationVo(rowId, "Relation", "Select",
						metaDataUtil.getRelationForFromType(fromType)));
			} else {
				String fromType = rowType.get(rowType.size() - 2)
						.getSelTypeRelVal();

				fromType = fromType.substring(fromType.indexOf("-") + 1);
				String relType = rowType.get(rowType.size() - 1)
						.getSelTypeRelVal();
				relType = relType.substring(relType.indexOf("-") + 1);
				int rowId = rowType.size() + 1;

				rowType.add(new RptTypeRelationVo(rowId, "Type", "Select",
						metaDataUtil.getToForFromRelType(fromType, relType)));
			}
			return null;
		}
	}

	public String deleteTypeRelationRow() {
		Map<String, String> params = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap();
		String key = "";
		int rowId = Integer.parseInt(params.get("rowId"));
		if (rowType != null) {
			int rowNumbCnt = rowType.size();
			for (int rwcnt = rowId; rwcnt <= rowNumbCnt; rwcnt++) {
				RptTypeRelationVo rptRelVo = rowType.get(rowId - 1);
				if(rptRelVo.getSelTypeRelVal().indexOf("-")!=-1)
				{
				key = rptRelVo.getSelTypeRelVal().substring(0, rptRelVo.getSelTypeRelVal().indexOf("-")).trim();
				}
				else
				{
					key = rptRelVo.getSelTypeRelVal();
				}
			if(rowMap!=null && rowMap.containsKey(key))
				{
				rowMap.remove(key);
				}
				rowType.remove(rowId - 1);
			}
			if (rowType.size() == 0) {
				RptTypeRelMetaDataUtil metaDataUtil = new RptTypeRelMetaDataUtil();
				rowType = new ArrayList<RptTypeRelationVo>();
				rowType.add(new RptTypeRelationVo(1, "Select", "Select",
						metaDataUtil.getAllFromType()));
			}
		}
		return "";
	}

	public String saveSelectedTypes() throws PWiException {
		errorMessage = "";
		errorMessageRTN = "";
		boolean valid=true;
		if (rptTemplateName.equals("")) {
			FacesContext.getCurrentInstance().addMessage(
					null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							"Please enter Report Template Name",
							"Please enter Report Template Name"));
			valid = false;
		}
		if (rptTemplateDesc.equals("")) {
			FacesContext.getCurrentInstance().addMessage(
					null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							"Please enter Report Template Description",
							"Please enter Report Template Description"));
			valid = false;
		}
		if(isGenNewRptTemp())
		{
			if (queriesService.checkQueryName(this.rptTemplateName) > 0) {
				handleFacesError(PWiConstants.ERROR_DUPLICATE_NAME);
				valid = false;
			}
		}
		for (int i = 0; i < rowType.size(); i++) {

			if (rowType.get(i).getSelType().equals("Select")
					|| rowType.get(i).getSelType().equals("")
					|| rowType.get(i).getSelTypeRelVal().equals("Select")
					|| rowType.get(i).getSelTypeRelVal().equals("")) {
				
				FacesContext.getCurrentInstance().addMessage(
						null,
						new FacesMessage(FacesMessage.SEVERITY_ERROR,
								"Please select values for all drop down boxes",
								"Please select values for all drop down boxes"));
				valid = false;
				
			}
		}
		if(!valid)
		{
			return "";
		}
		nextFlagTab1=false;
		selectedTabName="tab2";
		ELContext elContext = FacesContext.getCurrentInstance().getELContext();
		RptTypeRelationSettingBean rptTypeRelationSettingBean = (RptTypeRelationSettingBean) elContext
				.getELResolver().getValue(elContext, null, "rptTypeRelSetBean");
		rptTypeRelationSettingBean.configureTypeSettings();
		return null;
	}

	public void changeListernMethod(ValueChangeEvent e) throws PWiException {
		System.out.println("You selected " + e.getNewValue().toString());
		String fromType = e.getNewValue().toString();

	}

	public void valueChangeRelType() {
	
		Map<String, String> params = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap();
		
		int rowId = Integer.parseInt(params.get("selectedRow"));
		if (rowType != null) {
			int rowNumbCnt = rowType.size();
			for (int rwcnt = rowId; rwcnt <= rowNumbCnt; rwcnt++) {
				rowType.remove(rowId - 1);
			}
			if (rowType.size() == 0) {
				RptTypeRelMetaDataUtil metaDataUtil = new RptTypeRelMetaDataUtil();
				rowType = new ArrayList<RptTypeRelationVo>();
				rowType.add(new RptTypeRelationVo(1, "Select", "Select",
						metaDataUtil.getAllFromType()));
			}
		}
	}

	public void valueChangeRelType1(ValueChangeEvent e) {

		
		int rowId = (Integer) e.getComponent().getAttributes()
				.get("selectedRow");
		

		if (!e.getOldValue().equals("Select")) {
		
			int rowNumbCnt = rowType.size();
			for (int rwcnt = rowId; rwcnt < rowNumbCnt; rwcnt++) {
				rowType.remove(rowId);
			}

			
		}
	}

	public String nextTabFromTab1() {
		selectedTabName = "tab2";
		return "";
	}
	public String nextTabFromTab0() {
		selectedTabName = "tab1";
		return "";
	}
		
	public String callDynRptBldrWiz()
	{
		selectedTabName = "tab1";
		rptTemplateName = "";
		rptTemplateDesc = "";
		rowType = null;
		rowMap=null;
		genNewRptTemp = true;
		ELContext elContext = FacesContext.getCurrentInstance().getELContext();
		RptTypeRelationSettingBean rptTypeRelationSettingBean = (RptTypeRelationSettingBean) elContext
				.getELResolver().getValue(elContext, null, "rptTypeRelSetBean");
		rptTypeRelationSettingBean.setTableTypeMap(new HashMap<String, Map<String,RptTypeRelationVo>>());;
		return PWiConstants.NAV_QUERY_DYN_RPT_BLDR;
	}
	
	public String prevTabFromTab1() {
		
		return PWiConstants.NAV_QUERY_LIST_DRAFT_QUERIES;
	}

	public String prevTabFromTab2() {
		selectedTabName = "tab1";
		nextFlagTab1 = true;
		return "";
	}

	public String nextTabFromTab2() {
		selectedTabName = "tab3";
		return "";
	}

	public String prevTabFromTab3() {
		selectedTabName = "tab2";
		return "";
	}


	/**
	 * @return the selectedRowId
	 */
	public int getSelectedRowId() {
		return selectedRowId;
	}

	/**
	 * @param selectedRowId
	 *            the selectedRowId to set
	 */
	public void setSelectedRowId(int selectedRowId) {
		this.selectedRowId = selectedRowId;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage
	 *            the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	public String getSelectedTabName() {
		return selectedTabName;
	}

	public void setSelectedTabName(String selectedTabName) {
		this.selectedTabName = selectedTabName;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorMessageRTN() {
		return errorMessageRTN;
	}

	public void setErrorMessageRTN(String errorMessageRTN) {
		this.errorMessageRTN = errorMessageRTN;
	}

	public boolean isNextFlagTab1() {
		return nextFlagTab1;
	}

	public void setNextFlagTab1(boolean nextFlagTab1) {
		this.nextFlagTab1 = nextFlagTab1;
	}
	
	public String actionEditQuery(Integer theQueryId) throws NumberFormatException, PWiException {
		typeRelList =new ArrayList<String>();
		rowMap = null;
		QueryXmlReader qryXmlRdr = new QueryXmlReader();
		String queryXML = "";
		QueriesVO queriesVO =  BeanUtil.getInstance().getAdminQueryEditorBean().initEditDraft(theQueryId);
		 QueryType  queryTyp = qryXmlRdr.translateXml(queriesVO.getQueryXML());
		 rptTemplateName = queriesVO.getQueryName();
		 rptTemplateDesc = queriesVO.getQueryDesc();
		 rptTemplatekeyWord = queriesVO.getQryKeyWrdTxt();
		 rptTempQuryId = queriesVO.getQueryId();
		 SqlExecutorXml sqlExcXml = (SqlExecutorXml)queryTyp.getQuerydefinition().getExecutor();
			String strSql = sqlExcXml.getSql();
			strSql = strSql.substring(strSql.indexOf("1=1")+3);
			String[] strParam = strSql.split("}");
		List<DbobjectType> dbObjTypList = queryTyp.getQuerydefinition().getDbobjectlist().getDbobject();
		Map<String, Map<String, RptTypeRelationVo>> tableTypeMap = new HashMap<String, Map<String, RptTypeRelationVo>>();
		for(DbobjectType dbobjectType : dbObjTypList)
		{
				int countColFrObj = 0;	
			List<ColumnType> columnTypeLst = queryTyp.getQuerydefinition().getColumnlist().getColumn();
			
			 Map<String, RptTypeRelationVo> columnTypeMap = new HashMap<String, RptTypeRelationVo>();
			 List<RptTypeRelationVo> columnsList = rptTypeRelationService.getColumnsFrType(dbobjectType.getId().toUpperCase(Locale.US));
			for(RptTypeRelationVo rptTypeRelationVo : columnsList)
			{				
				 String fieldName =  rptTypeRelationVo.getCoulmnName();
				
					for(ColumnType columnType : columnTypeLst)
					{
						String columnId = columnType.getId();
						 
						if(dbobjectType.getAlias().equalsIgnoreCase(columnId.substring(0, columnId.indexOf(columnType.getDbfield().getFieldname()))) && columnType.getDbfield().getFieldname().equalsIgnoreCase(fieldName.trim()))
						{
							countColFrObj = countColFrObj+1;
							rptTypeRelationVo.setToDelete(true);
							rptTypeRelationVo.setCoulmnName(fieldName);
							rptTypeRelationVo.setDisplayName(columnType.getDisplayname());
							if(columnType.isSearchcondmandatory())
							{
								rptTypeRelationVo.setSelectedSrchMandtry("yes");
							}
							else
							{
								rptTypeRelationVo.setSelectedSrchMandtry("no");
							}
							
							if(columnType.getInputtype()!=null)
							{
								if(columnType.getInputtype().getCombobox()!=null)
								{
									rptTypeRelationVo.setInputType("combobox");
									
									rptTypeRelationVo.setFillDesc(getListItemFormMultiValue(columnType.getInputtype().getCombobox().getItem()));						
									
								}
								else if(columnType.getInputtype().getMultiselect()!=null)
								{
									rptTypeRelationVo.setInputType("multiselect");
									
									rptTypeRelationVo.setFillDesc(getListItemFormMultiValue(columnType.getInputtype().getMultiselect().getItem()));						
									
								}
								else if(columnType.getInputtype().getLookup()!=null)
								{
									rptTypeRelationVo.setInputType("lookup");
									
									rptTypeRelationVo.setFillDesc(getListItemFormMultiValue(columnType.getInputtype().getLookup().getItem()));						
									
								}
								else if(columnType.getInputtype().getDropdown()!=null)
								{
									rptTypeRelationVo.setInputType("dropdown");
									
									rptTypeRelationVo.setFillDesc(getListItemFormMultiValue(columnType.getInputtype().getDropdown().getItem()));						
									
								}
								else if(columnType.getInputtype().getDatepicker()!=null)
								{
									rptTypeRelationVo.setInputType("datepicker");
									
									rptTypeRelationVo.setFillDesc("");						
									
								}
							}
							else
							{
								rptTypeRelationVo.setInputType("text");
							}
							
							List<AllowedoperatorsType> allowedoperators = columnType.getAllowedoperators();
							
							rptTypeRelationVo.setSearchOptr(getListOfAllwdOprtr(allowedoperators));
							
							 for(String paramVal:strParam)
							 {
								 System.out.println("paramVal= "+paramVal);
								String colVal = paramVal.substring(paramVal.indexOf("{")+1) ;
								 System.out.println("col val= "+colVal);
								
								 if(colVal.equalsIgnoreCase(dbobjectType.getAlias()+columnType.getDbfield().getFieldname()))
								 {
									 if(paramVal.contains("$and$"))
									 {
										 rptTypeRelationVo.setSubstPlaceHldr("and");
									 }
									 else if(paramVal.contains("$or$"))
									 {
										 rptTypeRelationVo.setSubstPlaceHldr("or");
									 }
									 else
									 {
										 rptTypeRelationVo.setSubstPlaceHldr("date");
									 }
								 }
							 }
									
						}

						
				}
					columnTypeMap.put(fieldName, rptTypeRelationVo);	 	
			}
			
		typeRelList.add(dbobjectType.getId().toUpperCase());
				
		tableTypeMap.put(dbobjectType.getId().toUpperCase(), columnTypeMap);
		}
		getRowsForTypes();
		rowMap = tableTypeMap;
		genNewRptTemp = false;
		selectedTabName="tab1";
		return PWiConstants.NAV_QUERY_DYN_RPT_BLDR;
	}
	public void getRowsForTypes()
	{
		RptTypeRelMetaDataUtil metaDataUtil = new RptTypeRelMetaDataUtil();
		if(typeRelList!=null && typeRelList.size()>0)
		{
			int countRow=0;
			String prevFromTyp = "";
			String prevRelTyp = "";
			for(String typeRelVal : typeRelList) {
						   
			   if(countRow==0)
			   {
				   countRow = countRow+1;
				   prevFromTyp = metaDataUtil.getTypRelValFrEEDWFrm(typeRelVal);
				   prevFromTyp = prevFromTyp.substring(prevFromTyp.indexOf("-") + 1);
				   rowType = new ArrayList<RptTypeRelationVo>();
					rowType.add(new RptTypeRelationVo(countRow, "Type", metaDataUtil.getTypRelValFrEEDWFrm(typeRelVal),
							metaDataUtil.getAllFromType())); 
			   }
			   else if(countRow % 2==0 )
			   {
				   countRow = countRow+1;
				   rowType.add(new RptTypeRelationVo(countRow, "Type", metaDataUtil.getTypRelValFrEEDWTo(typeRelVal),
							metaDataUtil.getToForFromRelType(prevFromTyp,prevRelTyp)));
				   prevFromTyp = metaDataUtil.getTypRelValFrEEDWTo(typeRelVal);
				   prevFromTyp = prevFromTyp.substring(prevFromTyp.indexOf("-") + 1);
			   }
			   else
			   {
				   countRow = countRow+1;
				   rowType.add(new RptTypeRelationVo(countRow, "Relation", metaDataUtil.getTypRelValFrEEDWRel(typeRelVal),
							metaDataUtil.getRelationForFromType(prevFromTyp)));
				   prevRelTyp = metaDataUtil.getTypRelValFrEEDWRel(typeRelVal);
				   prevRelTyp = prevRelTyp.substring(prevRelTyp.indexOf("-") + 1);
			   }
			}
		}
	}
	private static String getListItemFormMultiValue(List<SelectionitemType> lstSelItmTyp) {
		StringBuffer multiInputValue = new StringBuffer("");
		if(lstSelItmTyp!=null)
		{
			int count=0;
			for(SelectionitemType selectionitemType : lstSelItmTyp)
			{
				if(count==0)
				{
					multiInputValue.append(selectionitemType.getValue());
				}
				multiInputValue.append(",").append(selectionitemType.getValue());
				count++;
			}
			
		}

		return multiInputValue.toString();
	}
	private static List<String> getListOfAllwdOprtr(List<AllowedoperatorsType> allowedoperators) {
		List<String> lstOpt = new ArrayList<String>(); 
		if(allowedoperators!=null)
		{
			for(AllowedoperatorsType allowedoperatorsType : allowedoperators)
			{
				List<JAXBElement<String>> opEqualOrOpLikeOrOpValue = allowedoperatorsType.getOpEqualOrOpLikeOrOpValue();
				for(JAXBElement<String> opVal : opEqualOrOpLikeOrOpValue )
				lstOpt.add(opVal.getValue());
			}
			
		}

		return lstOpt;
	}
}
