/**
 * Copyright (C) 2014 GE Infra.  
 * All rights reserved 
 * @FileName PLMSearchDaoIfc.java
 * @Creation date: 24-Oct-2010
 * @version 1.0
 * * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.data.PLMBomSalesData;
import com.geinfra.geaviation.pwi.data.PLMDocGenFmiData;
import com.geinfra.geaviation.pwi.data.PLMFmiTemplateData;
import com.geinfra.geaviation.pwi.data.PLMFmiTextData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

/**
 * PLMSearchDaoIfc is the DAO interface used for PLM document search menu
 */

public interface PLMDocGenDaoIfc {

	/**
	 * This method is used to getFmiDetails
	 * @param fmidetails
	 * @return List
	 */
	public List<PLMDocGenFmiData> getFmiDetails(PLMDocGenFmiData fmidetails)
			throws PLMCommonException;

	/**
	 * This method is used to generateFmiDoc
	 * @param fmidetails
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMDocGenFmiData> generateFmiDoc(PLMDocGenFmiData fmidetails)
			throws PLMCommonException;

	/*
	 * This method is used to uploadFmiTemplate
	 * @param templateData
	 * @return String
	 * @throws PLMCommonException
	 */
	public String uploadFmiTemplate(PLMFmiTemplateData templateData)
			throws PLMCommonException;

	/**
	 * This method is used to downloadFmiTemplate
	 * @param templateData
	 * @return String
	 * @throws PLMCommonException
	 */
	public String downloadFmiTemplate(PLMFmiTemplateData templateData)
			throws PLMCommonException;

	/**
	 * This method is used to uploadFmiText
	 * @param textDataList
	 * @return String
	 * @throws PLMCommonException
	 */
	public String uploadFmiText(List<PLMFmiTextData> textDataList)
			throws PLMCommonException;

	/**
	 * This method is used to downloadFmiText
	 * @return List
	 * @throws PLMCommonException
	 * 
	 */
	public List<PLMFmiTextData> downloadFmiText() throws PLMCommonException;
	
	/**
	 * This method is used to getBOMDataForContract
	 * @param contractNumber
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomSalesData> getBOMDataForContract(String contractNumber, String partNumber) throws PLMCommonException;
	
	/**
	 * This method is used to getMBOMDataForContract
	 * @param contractNumber
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomSalesData> getMBOMDataForContract(String contractNumber, String partNumber) throws PLMCommonException;
	
	/**
	 * This method is used to getSalesDataForContract
	 * @param contractNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomSalesData> getSalesDataForContract(String contractNumber) throws PLMCommonException;
	
	/**
	 * This method is used to getMSalesDataForContract
	 * @param contractNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomSalesData> getMSalesDataForContract(String contractNumber) throws PLMCommonException;
	
	/**
	 * This method is used to getPartsForContract
	 * @param contractNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomSalesData> getPartsForContract(String contractNumber) throws PLMCommonException;
	
	/**
	 * This method is used to getPartsForProject
	 * @param projectNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomSalesData> getPartsForProject(String projectNumber) throws PLMCommonException;
	
	/**
	 * This method is used to getPartsForNonMlMpl
	 * @param nonMlMplList
	 * @return List
	 * @throws PLMCommonException
	 */

	public List<PLMBomSalesData> getPartsForNonMlMpl(List<String> nonMlMplList) throws PLMCommonException;
	/**
	 * This method is used to fetchEbomData
	 * @param ebomId, lvl
	 * @return List
	 * @throws PLMCommonException
	 */
	
	//public List<PLMDocGenFmiData> fetchEbomData(String ebomId,String lvl) throws PLMCommonException;

	
	//Newly Added for FMI New Unit Search
	/**
	 * This method is used to get FMI New Unit details
	 * 
	 * @param fmidetails
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMDocGenFmiData> getFmiNewUnitDetails(PLMDocGenFmiData fmidetails)
			throws PLMCommonException;
	
	/**
	 * This method is used to fetch Contract Info
	 * 
	 * @param cntrtNm
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMDocGenFmiData> fetchCntrInfo(String cntrtNm) throws PLMCommonException;
	
	/**
	 * This method is used to get list of contracts
	 * 
	 * @param Unit Serial Num
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomSalesData> getContractNamesList(String unitSerialNm)throws PLMCommonException;
	
}
