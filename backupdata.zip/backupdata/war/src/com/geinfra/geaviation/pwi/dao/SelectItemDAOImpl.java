package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.faces.model.SelectItem;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.util.SqlTemplateUtil;

/**
 * Project      : Product Lifecycle Management 
 * Date Written : Aug 29, 2012
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 * Copyright(C) 2012 GE All rights reserved
 *
 * Description : Data access object for sql-driven input.
 *
 * Revision Log Aug 29, 2012 | v1.0.
 * --------------------------------------------------------------
 */
public class SelectItemDAOImpl implements SelectItemDAO {
	public static final String SELECT_ITEM_VALUE = "value";
	public static final String SELECT_ITEM_LABEL = "label";
	private static final Logger LOGGER = Logger
			.getLogger(SelectItemDAOImpl.class);
	
	/**
	 * {@inheritDoc}
	 */
	public List<SelectItem> getSelectableItems(String dsn, String sql, String sso)
			throws PWiException {
		final ParameterizedRowMapper<SelectItem> mapper = new SelectItemRowMapper();

		// replace substitution variables in the SQL
		String sqlQry = SqlTemplateUtil.getInstance().evaluateTemplate(sql, sso).getSql();
		
		List<SelectItem> result;
		try {
			// connect to the database
			InitialContext initCtx = new InitialContext();
			Context ctx = (Context) initCtx.lookup("java:/");
			DataSource ds = (DataSource) ctx.lookup(dsn);
			// TODO: perhaps keep one jdbcT for each data source? 
			JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);

			if (LOGGER.isDebugEnabled()) {
				StringBuilder builder = new StringBuilder();
				builder.append("Generating SelectItems using dsn: ").append(dsn);
				builder.append("; sql: ").append(sqlQry);
				LOGGER.debug(builder.toString());
			}

			long start = System.currentTimeMillis();
			
			// yes, it seems daft to declare a new list when we're just going to
			// assign it to an existing list; however, we need to declare the
			// list outside the try block, and for some reason @SuppressWarnings
			// prevents the compiler from recognizing that result has already
			// been declared.
			@SuppressWarnings("unchecked")
			List <SelectItem> tempResult = (List<SelectItem>) jdbcTemplate.query(sqlQry, mapper);
			//List <SelectItem> tempResult = null;
			result = tempResult;
			
			long end = System.currentTimeMillis();
			
			if (LOGGER.isDebugEnabled()) {
				StringBuilder builder = new StringBuilder();
				builder.append("Generated ").append(result.size());
				builder.append(" SelectItems in ");
				builder.append((end - start) / PWiConstants.MILLIS_PER_SEC);
				builder.append(" seconds.");
				LOGGER.debug(builder.toString());
				
				// jdbcTemplate has the potential to throw an unchecked
				// java.sql.SQLException, which we want to catch, but cannot
				// catch unless it is declared to be thrown.
				// Pretending to throw here so we can catch and recover when
				// the exception is actually thrown.
				// Using Boolean.FALSE.booleanValue instead of false to avoid
				// dead code warnings.
				if (Boolean.FALSE.booleanValue()) { throw new SQLException(); }
			}

		} catch (SQLException e) {
			throw new PWiException(e, "Error getting selectable items.");
		} catch (NamingException e) {
			throw new PWiException(e, "Error getting selectable items.");
		} catch (DataAccessException e) {
			throw new PWiException(e, "Error getting selectable items.");
		}
		
		return result;
	}

	private static class SelectItemRowMapper implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowNum) throws SQLException {
			SelectItem se = new SelectItem();
			se.setValue(rs.getString(SelectItemDAOImpl.SELECT_ITEM_VALUE));
			se.setLabel(rs.getString(SelectItemDAOImpl.SELECT_ITEM_LABEL));
			return se;
		}
	}
}
