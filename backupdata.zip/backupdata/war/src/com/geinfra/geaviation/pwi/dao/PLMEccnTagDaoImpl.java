/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMEccnTagDaoImpl.java
 * @Creation date: 17-Jul-2009
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMQueryConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;


/**
 * ICMAdminDaoImpl is the DAO implementation class used for ICM Administrator
 * Menu.
 */
public class PLMEccnTagDaoImpl extends SimpleJdbcDaoSupport implements
		PLMEccnTagDaoIfc {
	/**
	 * Holds the Logger.
	 */
	private static final Logger LOG = Logger.getLogger(PLMEccnTagDaoImpl.class);

	/**
	 * This method is used to displayEccnTag
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<String> displayEccnTag() throws PLMCommonException {
		List<String> taskSaveAndSearchResultList = null;
		try{
		LOG.info("ECCN TAG Query is : " + PLMQueryConstants.GET_ECCN_TAG_DATA);
		taskSaveAndSearchResultList = getSimpleJdbcTemplate().query
		(PLMQueryConstants.GET_ECCN_TAG_DATA, new EccnListDetails());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return taskSaveAndSearchResultList;
	}
	
	/**
	 * mailListDetails Mapper
	 */
	private static final class EccnListDetails implements ParameterizedRowMapper<String> {
//	private static ParameterizedRowMapper<String> eccnListDetails = new ParameterizedRowMapper<String>() {
		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			String metaData = (rs.getString(PLMConstants.ECCN_TAG));
			return metaData;
		}
	}
}
