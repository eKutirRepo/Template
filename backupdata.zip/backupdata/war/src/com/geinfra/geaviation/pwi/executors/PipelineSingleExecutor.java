package com.geinfra.geaviation.pwi.executors;

import java.util.ArrayList;
import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.PWiQueryTimeoutException;
import com.geinfra.geaviation.pwi.common.PWiResultSizeLimitExceededException;
import com.geinfra.geaviation.pwi.model.PWiResultSet;
import com.geinfra.geaviation.pwi.util.QueryProcessingUtil;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;

/**
 * 
 * Project      : Product Lifecycle Management Intelligence
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description :
 * 
 * Revision Log
 * --------------------------------------------------------------
 * 2012.12.18 pH  replaced GEAEResultSet with PWiResultSet
 * 2013.02.21 pH  cleaned up methods; pass and use the proper executor
 */
public class PipelineSingleExecutor implements Executor {
	List<Executor> executors;

	public PipelineSingleExecutor(List<Executor> executors) {
		this.executors = executors;
	}

	/*
	 * A pipeline executor should call each of its child executors in order,
	 * passing the columns and rows from a previous child executor to the next
	 * child executor. The first child executor will likely get empty or null
	 * columns and rows passed in.
	 */

	public PWiResultSet execute(QueryType queryType, Search search,
			SelectedColumns selectedColumns, String sso, String[] columns,
			List<Object[]> rows) throws PWiException,
			PWiResultSizeLimitExceededException, PWiQueryTimeoutException {
		PWiResultSet resultSet = null;
		String[] tempColumns = columns;
		List<Object[]> tempRows = rows;
		
		// we execute for each row, but if rows is null (this is the first
		// Executor in the query), it will crash.  If so, create one:
		if (tempRows == null) {
			tempRows = new ArrayList<Object[]>(1);
		}
		
		// if there were no rows in the previous query (perhaps this is the
		// second query in an Append executor), ensure size at least 1.
		if (tempRows.size() == 0 ) {
			tempRows.add(new Object[0]);
		}

		// execute each executor for each row
		for (Executor executor : executors) {
			// If resultSet is not null (this is not the first loop iteration)
			if (resultSet != null) {
				// If there were no results from the previous query, there won't
				// be any next time, either.  If no rows, return an empty RS
				if (resultSet.size() == 0) {
					closeResultSet(resultSet);
					return new PWiResultSet();
				}
				
				// get rows and columns from the previous result set, then close it
				tempColumns = QueryProcessingUtil.getInstance().getColumns(resultSet);
				tempRows = QueryProcessingUtil.getInstance().getRows(resultSet);
				closeResultSet(resultSet);
			}

			// Execute for each row
			resultSet = executeForEachRow(executor, queryType, search,
					selectedColumns, sso, tempColumns, tempRows);
		}

		return resultSet;
	}

	private PWiResultSet executeForEachRow(Executor executor,
			QueryType queryType, Search search,
			SelectedColumns selectedColumns, String sso, String[] columns,
			List<Object[]> rows) throws PWiException,
			PWiResultSizeLimitExceededException, PWiQueryTimeoutException {
		// When single is specified, run a separate query for each input
		// row and then append the results of each query
		PWiResultSet finalResultSet = null;
		for (Object[] row : rows) {
			// Create a list containing just the single row to pass into
			// method to generate SQL
			List<Object[]> singleRows = new ArrayList<Object[]>(1);
			singleRows.add(row);

			// Execute the current row
			PWiResultSet resultSet = executor.execute(queryType, search,
					selectedColumns, sso, columns, singleRows);

			// Append to existing results
			if (finalResultSet == null) {
				finalResultSet = resultSet;
			} else {
				try {
					QueryProcessingUtil.getInstance().appendResultSet(
							finalResultSet, resultSet);
				} finally {
					closeResultSet(resultSet);
				}
			}
		}

		return finalResultSet;
	}

	private void closeResultSet(PWiResultSet resultSet) {
		if (resultSet != null) {
			resultSet.close();
		}
	}

	public String getExecutedQuery() {
		// Pipeline Single queries are probably implemented this way because
		// they are BIG.  So storing and returning SQL would waste memory and
		// return something that's hardly human-readable.
		return "Getting query string not supported for pipeline single queries.";
	}
}
