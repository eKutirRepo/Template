package com.geinfra.geaviation.pwi.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlSelectBooleanCheckbox;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.xml.bind.JAXBException;

import org.ajax4jsf.component.html.HtmlAjaxSupport;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.richfaces.event.DropEvent;

import com.geinfra.geaviation.pwi.bean.helpers.ExecutionOutputViewConfig;
import com.geinfra.geaviation.pwi.bean.util.BeanUtil;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.QueryAccessException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.context.PWiContext;
import com.geinfra.geaviation.pwi.model.PWiQueryVO;
import com.geinfra.geaviation.pwi.model.TemplateVO;
import com.geinfra.geaviation.pwi.service.QueriesService;
import com.geinfra.geaviation.pwi.service.QueryGroupService;
import com.geinfra.geaviation.pwi.service.QuerySubmissionService;
import com.geinfra.geaviation.pwi.service.SelectItemService;
import com.geinfra.geaviation.pwi.service.helpers.ExecutionOutputModelConfig;
import com.geinfra.geaviation.pwi.service.vo.ExecutedFrom;
import com.geinfra.geaviation.pwi.service.vo.ExecutionMode;
import com.geinfra.geaviation.pwi.service.vo.OutputType;
import com.geinfra.geaviation.pwi.service.vo.QuerySubmission;
import com.geinfra.geaviation.pwi.service.vo.QuerySubmissionResult;
import com.geinfra.geaviation.pwi.service.vo.QueryUserOptions;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.util.SqlTemplateUtil;
import com.geinfra.geaviation.pwi.xml.QueryXmlReader;
import com.geinfra.geaviation.pwi.xml.query.AllowedoperatorsType;
import com.geinfra.geaviation.pwi.xml.query.ColumnType;
import com.geinfra.geaviation.pwi.xml.query.QueryProcessorType;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.query.SelectionType;
import com.geinfra.geaviation.pwi.xml.query.SelectionitemType;
import com.geinfra.geaviation.pwi.xml.query.util.QueryJaxbUtil;
import com.geinfra.geaviation.pwi.xml.search.ColumnRef;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.search.Search.Item;
import com.geinfra.geaviation.pwi.xml.search.util.SearchJaxbUtil;
import com.geinfra.geaviation.pwi.xml.search.util.SearchJaxbUtil.KeyValuePair;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns.Columnref;

/**
 * 
 * Project : Product Lifecycle Management Intelligence Date Written : December
 * 9, 2010 Security : GE Confidential Restrictions : GE PROPRIETARY INFORMATION,
 * FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : QueryBuilderBean
 * 
 * Revision Log December 9, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class QueryBuilderBean extends BaseBean {
	private static final Logger LOGGER = Logger
			.getLogger(QueryBuilderBean.class);
	// Since we can't create new AllowedoperatorTypes, jump straight to strings
	private static final String OP_EQUAL = "opEqual";
	private static final String OP_LIST = "opValue";

	private static final String SESSION_ATTRIBUTE_SUBMISSION_CNTR_BEAN = "submissionCntrlBean";

	// Services
	private QueryGroupService queryGroupService;
	private QueriesService queriesService;
	private QuerySubmissionService querySubmissionService;

	// JSF properties
	private String queryName;
	private List<QueryBuilderRow> queryBuilderRows;
	private String executionModeId;
	private String outputOptionId;
	private String queryProcessorId;
	private String queryDesc;
	private String resultMessage;
	private String queryInfo;
	private List<SelectItem> executionModeOptions = new ArrayList<SelectItem>();
	private Map<String, List<SelectItem>> outputOptionsMap = new HashMap<String, List<SelectItem>>();
	private List<SelectItem> queryProcessorOptions = new ArrayList<SelectItem>();
	private boolean allowReordering;

	// Ancillary properties
	private Map<String, String> defaultOutputIdMap;
	private Map<String, OutputType> outputTypeIdMap;
	private Map<String, TemplateVO> templateIdMap;

	// Data model properties
	private PWiQueryVO queryVo;
	private QuerySubmission querySubmission;
	private Integer queryIdNum;
	private String queryXml;
	private boolean executeFlag;
	private List<SelectItem> sftpServerLists = new ArrayList<SelectItem>();
	private String sftpServerId;
	private boolean sftpOpUsed = false;

	private RptTypeRelationSettingBean rptTypeRelSetBean;

	private QueryUserOptions queryOptions = new QueryUserOptions();

	public QueryUserOptions getQueryOptions() {
		return queryOptions;
	}

	public void setQueryOptions(QueryUserOptions queryOptions) {
		this.queryOptions = queryOptions;
	}

	public RptTypeRelationSettingBean getRptTypeRelSetBean() {
		return rptTypeRelSetBean;
	}

	public void setRptTypeRelSetBean(
			RptTypeRelationSettingBean rptTypeRelSetBean) {
		this.rptTypeRelSetBean = rptTypeRelSetBean;
	}

	public void setQueriesService(QueriesService queriesService) {
		this.queriesService = queriesService;
	}

	public void setQuerySubmissionService(
			QuerySubmissionService querySubmissionService) {
		this.querySubmissionService = querySubmissionService;
	}

	public void setQuerySubmission(QuerySubmission querySubmission) {
		this.querySubmission = querySubmission;
	}

	// Newly Added by srinivas
	/**
	 * Action method that responds to requests to save a template created query.
	 * 
	 * @throws PWiException
	 */
	public void actionxmlQuery() throws PWiException, QueryAccessException {
		executeFlag = false;
		init(0, null);
	}

	public void init(Integer queryId, QueryUserOptions queryUserOptions)
			throws PWiException, QueryAccessException {
		QueryType query;
		queryIdNum = queryId;
		if (queryId != 0) {
			// Retrieve query from database
			queryVo = queriesService.getQueryById(queryId);
			// Translate query XML
			query = new QueryXmlReader().translateXml(queryVo.getQryXml());
			// Initialize query name
			queryName = queryVo.getQryNm();
			// Initialize execution mode and output type options
			queryInfo = queryVo.getQryDesc();
			LOGGER.info("if QueryId is not 0 ######");
		} else {
			executionModeOptions = new ArrayList<SelectItem>();
			executionModeOptions.add(new SelectItem("online", "Online"));
			executionModeId = "web";
			getOutputOptions();
			outputOptionId = "online";
			defaultOutputIdMap = new HashMap<String, String>();
			defaultOutputIdMap.put("online", "web");
			outputTypeIdMap = new HashMap<String, OutputType>();
			outputTypeIdMap.put("web", OutputType.WEB);

			queryXml = rptTypeRelSetBean.getGeneratedXml();
			queryXml = queryXml.substring(queryXml.indexOf("?>") + 2);

			queryName = rptTypeRelSetBean.getRpttyperelationbean()
					.getRptTemplateName();
			queryInfo = rptTypeRelSetBean.getRpttyperelationbean()
					.getRptTemplateDesc();

			query = new QueryXmlReader().translateXml(queryXml);
		}
		// Initialize query builder table
		initQueryBuilderTable(queryUserOptions, query);
		// Initialize allow sorting of columns
		allowReordering = query.getQuerydefinition().getQuerycustomization()
				.getSelect().isAllowsorting();
		// Initialize drag and drop indices
		initializeDragAndDropIndices();
		// Initialize query processors
		initQueryProcessors(query);
		// Initialize query description
		queryDesc = queryInfo;
		if (queryId != 0) {
			initOuputOptions(queryId, queryUserOptions);
		}
	} // end init

	private void initQueryBuilderTable(QueryUserOptions queryUserOptions,
			QueryType query) {
		// Initialize query builder table from query definition
		List<ColumnType> queryColumns = query.getQuerydefinition()
				.getColumnlist().getColumn();
		Map<String, QueryBuilderRow> queryBuilderMap = new LinkedHashMap<String, QueryBuilderRow>();
		List<String> dependList = new ArrayList<String>();
		for (ColumnType columnType : queryColumns) {

			if (columnType != null && columnType.getDepend() != null) {
				dependList.add(columnType.getDepend());
			}

		}
		// For each column
		for (ColumnType columnType : queryColumns) {
			QueryBuilderRow queryBldrRow = new QueryBuilderRow();

			// determine whether to display the column on the query builder page
			boolean availableToDisplay = QueryJaxbUtil.getInstance()
					.isColumnAvailable(columnType.getId(), query);
			boolean selectedToDisplayByDefault = QueryJaxbUtil.getInstance()
					.isColumnSelected(columnType.getId(), query);
			boolean mandatoryToDisplay = QueryJaxbUtil.getInstance()
					.isColumnMandatorySelected(columnType.getId(), query);

			boolean selectableToDisplay = availableToDisplay
					&& !mandatoryToDisplay;
			boolean selectedToDisplay = availableToDisplay
					&& (mandatoryToDisplay || selectedToDisplayByDefault);

			queryBldrRow.setHrefToDisplay(false);
			if (columnType.getHref() != null) {

				queryBldrRow.setHref(columnType.getHref());
				queryBldrRow.setHrefToDisplay(true);

			}

			if (!selectableToDisplay && !selectedToDisplay
					&& !columnType.isSearchable().booleanValue()) {
				// Column has no impact on user, so don't display
				// (Column probably exists for behind-the-scenes
				// post-processing functionality)
				continue;
			}
			// Check box (select to display)
			queryBldrRow.setSelected(selectedToDisplay);
			queryBldrRow.setMandatorySelected(mandatoryToDisplay);
			queryBldrRow.setSelectableToDisplay(selectableToDisplay);

			// TODO pH 2013.02: better name than object type
			// column display name (object type)
			queryBldrRow.setObjType(columnType.getDisplayname());
			queryBldrRow.setObjId(columnType.getId());
			queryBldrRow
					.setSearchable(columnType.isSearchable().booleanValue());
			queryBldrRow.setSearchMandatory(columnType.isSearchcondmandatory()
					.booleanValue());

			if (columnType.getDepend() != null) {
				queryBldrRow.setDepend(columnType.getDepend());
			}

			queryBldrRow.setDepended(dependList.contains(queryBldrRow
					.getObjId()));

			// Search field (iff the column is searchable)
			if (columnType.isSearchable().booleanValue()) {
				queryBldrRow.setOperatorList(getOperatorOptions(columnType
						.getAllowedoperators()));
				if (columnType.getInputtype() == null) {
					// input type is null; we have a plain-text field
					queryBldrRow
							.setInputType(QueryBuilderRow.InputType.PLAINTEXT);
				} else if (columnType.getInputtype().getDatepicker() != null) {
					// inputtype is DatePicker
					queryBldrRow.setDateFormat(columnType.getInputtype()
							.getDatepicker().getFormat());
					queryBldrRow
							.setInputType(QueryBuilderRow.InputType.DATEPICKER);
				} else {
					// all other input types are selection types
					SelectionType selTyp;
					if ((selTyp = columnType.getInputtype().getDropdown()) != null) {
						queryBldrRow
								.setInputType(QueryBuilderRow.InputType.DROPDOWN);
						// Override the specified operator list;
						// only EQUALS makes sense with a dropdown
						queryBldrRow.setOperatorList(Arrays
								.asList(new SelectItem(OP_EQUAL, "=")));
					} else if ((selTyp = columnType.getInputtype()
							.getMultiselect()) != null) {
						queryBldrRow
								.setInputType(QueryBuilderRow.InputType.MULTISELECT);
						// Override the specified operator list;
						// only LIST makes sense with a multiselect
						queryBldrRow.setOperatorList(Arrays
								.asList(new SelectItem(OP_LIST, "LIST")));
					} else if ((selTyp = columnType.getInputtype().getLookup()) != null) {
						queryBldrRow
								.setInputType(QueryBuilderRow.InputType.LOOKUP);
					} else if ((selTyp = columnType.getInputtype()
							.getCombobox()) != null) {
						queryBldrRow
								.setInputType(QueryBuilderRow.InputType.COMBOBOX);
					} else {
						// we have reached an unrecognized input type; log an
						// error and use plain text
						LOGGER.error("Illegal input type for column "
								+ columnType.getDisplayname());
						queryBldrRow
								.setInputType(QueryBuilderRow.InputType.PLAINTEXT);
					}

					// Send the SelectionType as-is; we'll get the SelectItems
					// lazily to speed page load
					if (selTyp != null) {
						queryBldrRow.setSelectionType(selTyp);
						queryBldrRow.setShowOnPageLoad(selTyp
								.isShowOnPageLoad());
					}
				} // end if inputtype null

				if (queryBldrRow.getOperatorList().isEmpty()) {
					queryBldrRow.setSearchable(false);
				} else if (queryBldrRow.getOperatorList().size() == 1) {
					// if only one operator is available, the operator dropdown
					// will be disabled and the operator will not get set,
					// so we set it here.
					queryBldrRow.setSearchOption((String) queryBldrRow
							.getOperatorList().get(0).getValue());
				}
			} // end if column is searchable

			queryBuilderMap.put(columnType.getId().toUpperCase(Locale.US),
					queryBldrRow);
		} // end for each column

		initSelectedColumns(queryUserOptions, queryColumns, queryBuilderMap);
	} // end initQueryBuilderTable

	private void initSelectedColumns(QueryUserOptions queryUserOptions,
			List<ColumnType> queryColumns,
			Map<String, QueryBuilderRow> queryBuilderMap) {
		// Add any query customizations from user such as selected columns
		// and search criteria
		List<String> customSelectedColumns = null;
		if (queryUserOptions != null) {
			// Create list of selected columns from the XML
			SelectedColumns selCol = queryUserOptions.getSelectedColumns();
			customSelectedColumns = new ArrayList<String>();
			for (Columnref ref : selCol.getColumnref()) {
				String columnId = ref.getRef().toUpperCase(Locale.US);

				// Add column to selected columns only if it exists in the
				// query definition
				// (Column could have been removed from the query definition
				// since the query was originally run)
				if (queryBuilderMap.containsKey(columnId)) {
					customSelectedColumns.add(columnId);
				} else {
					StringBuilder builder = new StringBuilder();
					builder.append("Init query builder: Found a user selected column");
					builder.append(" that does not exist in the query definition: ");
					builder.append(columnId);
					LOGGER.warn(builder.toString());
				}
			}

			// Set columns as selected or unselected based on list of
			// selected columns
			for (ColumnType columnType : queryColumns) {
				boolean setSelected = false;
				if (customSelectedColumns.contains(columnType.getId()
						.toUpperCase(Locale.US))) {
					setSelected = true;
				} else {
					setSelected = false;
				}

				QueryBuilderRow row = queryBuilderMap.get(columnType.getId()
						.toUpperCase(Locale.US));
				if (row != null) {
					row.setSelected(setSelected);
				}
			}

			// Initialize any existing search criteria
			Search search = queryUserOptions.getSearch();
			for (Item item : search.getItem()) {
				QueryBuilderRow queryBldrRow = queryBuilderMap.get(item
						.getColumnref().getRef().toUpperCase(Locale.US));

				// Set selected operator
				KeyValuePair<String, String> op = SearchJaxbUtil
						.translateOperator(item);
				queryBldrRow.setSearchOption(op.getKey());

				// Set parameter value
				String parameterValue = item.getValue();
				parameterValue = parameterValue.replaceAll(",", "\n");

				queryBldrRow.setParameter(parameterValue);
			}

		}

		// Add to query builder list
		queryBuilderRows = new ArrayList<QueryBuilderRow>();
		if (customSelectedColumns != null) {
			// User-specified ordering of selected columns is defined, so
			// add these columns in correct order to the beginning of query
			// builder list
			for (String selectedColumn : customSelectedColumns) {
				QueryBuilderRow row = queryBuilderMap.remove(selectedColumn);
				queryBuilderRows.add(row);
			}
		}
		for (QueryBuilderRow queryBldrRow : queryBuilderMap.values()) {
			queryBuilderRows.add(queryBldrRow);
		}
	} // end initSelectedColumns

	private void initOuputOptions(Integer queryId,
			QueryUserOptions queryUserOptions) throws PWiException,
			QueryAccessException {
		ExecutionOutputModelConfig modelConfig = querySubmissionService
				.getExecutionOutputModelConfig(queryId, queryUserOptions);

		ExecutionOutputViewConfig viewConfig = new ExecutionOutputViewConfig(
				modelConfig);
		executionModeOptions = viewConfig.getExecutionModes();
		executionModeId = viewConfig.getSelectedExecutionMode();
		outputOptionId = viewConfig.getSelectedOutputType();
		outputOptionsMap = viewConfig.getOutputModePerExecutionMode();
		defaultOutputIdMap = viewConfig.getDefaultOutputModePerExecutionMode();
		outputOptionId = viewConfig.getSelectedOutputType();
		outputTypeIdMap = viewConfig.getOutputTypeDecoder();
		sftpServerId = "select";
		if (queryUserOptions != null) {
			queryProcessorId = queryUserOptions.getQueryProcessorId();
			if (queryUserOptions.getExecutionModeId() != null
					&& queryUserOptions.getExecutionModeId().contains("sftp::")) {
				executionModeId = "sftp";
				outputOptionId = queryUserOptions.getOutputTypeId();
				sftpServerId = queryUserOptions.getExecutionModeId()
						.substring(
								queryUserOptions.getExecutionModeId().indexOf(
										"::") + 2,
								queryUserOptions.getExecutionModeId().length());
			}
		}
		templateIdMap = viewConfig.getTemplateDecoder();
		List<SelectItem> sftpServerList = new ArrayList<SelectItem>();
		sftpServerList.add(new SelectItem("select", "Select"));
		sftpServerList.add(new SelectItem("RPDMSFTP", "RPDM SFTP Server"));
		sftpServerLists = sftpServerList;

	} // end initOutputOptions

	private void initQueryProcessors(QueryType query) {
		queryProcessorOptions = new ArrayList<SelectItem>();
		for (QueryProcessorType processorType : QueryJaxbUtil.getInstance()
				.getQueryProcessorTypes(query)) {
			if (!processorType.isAlwaysrun()) {
				// Determine label for processor
				String label = processorType.getDisplayname();
				if (label == null) {
					label = processorType.getId();
				}

				// Add processor as an option
				queryProcessorOptions.add(new SelectItem(processorType.getId(),
						label));
			}
		}
	} // end initQueryProcessors

	/**
	 * Value object that stores the execution mode and output type options
	 * available for a particular query.
	 * 
	 * The execution modes and output types available for a query may be a
	 * subset of the execution modes and output types available on the system.
	 * Every execution mode might not be allowed with every output type. The
	 * relation between the execution modes and output types is many-to-many
	 * though, so any execution mode could potentially be allowed with any
	 * output type. Also the templates available for the query is included in
	 * the case that the template output type is available for the query.
	 */
	public static class QueryExecutionOutputOptions {
		private List<ExecutionMode> executionModes;
		private Map<String, List<OutputType>> executionModeToOutputTypesMap;
		private List<TemplateVO> templates;
		private ExecutionMode defaultExecutionMode;
		private Map<String, OutputType> defaultOutputTypeMap = new HashMap<String, OutputType>();

		public QueryExecutionOutputOptions(List<ExecutionMode> executionModes,
				Map<String, List<OutputType>> executionModeToOutputTypesMap,
				List<TemplateVO> templates, ExecutionMode defaultExecutionMode,
				Map<String, OutputType> defaultOutputTypeMap) {
			this.executionModes = executionModes;
			this.executionModeToOutputTypesMap = executionModeToOutputTypesMap;
			this.templates = templates;
			this.defaultExecutionMode = defaultExecutionMode;
			this.defaultOutputTypeMap = defaultOutputTypeMap;
		}

		public List<ExecutionMode> getExecutionModes() {
			return executionModes;
		}

		public List<OutputType> getOutputTypesForExecutionMode(
				String executionModeId) {
			return executionModeToOutputTypesMap.get(executionModeId);
		}

		public boolean isValid(String executionMode, String outputType) {
			// Valid if the output type exists for the execution mode
			List<OutputType> outputTypes = executionModeToOutputTypesMap
					.get(executionMode);
			if (outputTypes != null
					&& outputTypes.contains(OutputType.getById(outputType))) {
				return true;
			}
			return false;
		}

		public List<TemplateVO> getTemplates() {
			return templates;
		}

		public ExecutionMode getDefaultExecutionMode() {
			return defaultExecutionMode;
		}

		public Map<String, OutputType> getDefaultOutputTypeMap() {
			return defaultOutputTypeMap;
		}
	}

	/**
	 * Set drag drop indices for query builder rows. Needs to be called whenever
	 * the order of query builder rows change.
	 */
	private void initializeDragAndDropIndices() {
		int rowIndex = 0;
		for (QueryBuilderRow queryBuilderRow : queryBuilderRows) {
			queryBuilderRow.setDragDropIndex(rowIndex);
			rowIndex++;
		}
	}

	/**
	 * Executes a query specified by the user from the query builder.
	 * 
	 * @return Faces navigation outcome
	 * @throws QueryAccessException
	 * @throws JAXBException
	 * @throws PWiException
	 */
	public String actionCustomizeQuery() throws PWiException,
			QueryAccessException {
		if (!validateBuiltQuery()) {
			return PWiConstants.NAV_QUERY_BUILDER;
		}

		// Create selected columns and create search input...
		SelectedColumns selCol = new SelectedColumns();
		List<SelectedColumns.Columnref> colRefs = selCol.getColumnref();
		Search search = new Search();
		List<Search.Item> items = search.getItem();
		for (QueryBuilderRow qbr : queryBuilderRows) {
			// Add selected column potentially
			if (qbr.isSelected()) {
				SelectedColumns.Columnref colRef = new SelectedColumns.Columnref();
				colRef.setRef(qbr.getObjId());
				colRefs.add(colRef);
			}
			// Add search item potentially
			if (StringUtils.isNotBlank(qbr.getParameter())
					&& qbr.isSearchable()) {
				Search.Item p1 = new Search.Item();

				// Add column ref to search item
				ColumnRef col = new ColumnRef();
				col.setRef(qbr.getObjId());
				p1.setColumnref(col);

				// Get the value of the operator
				String op = qbr.getSearchOption();
				SearchJaxbUtil.setSearchOperator(p1, op);
				String paramVal = qbr.getParameter();
				paramVal = paramVal.replaceAll(",", "\n");
				p1.setValue(paramVal);

				items.add(p1);
			}
		}

		// Create query user options for submitting queries
		QueryUserOptions queryOpts = new QueryUserOptions();
		queryOpts.setSearch(search);
		queryOpts.setSelectedColumns(selCol);
		queryOpts.setQueryProcessorId(queryProcessorId);
		queryOpts.setSftpServerId(sftpServerId);
		queryOpts.setExecutionModeId(executionModeId);
		queryOpts.setOutputTypeId(outputTypeIdMap.get(outputOptionId).getId());
		TemplateVO template = templateIdMap.get(outputOptionId);
		if (template != null) {
			queryOpts.setTemplateId(template.getTemplateId().toString());
		}
		String nav = "";
		if (ExecutionMode.ONLINE.getId().equals(executionModeId)) {
			querySubmission
					.init(queryVo, queryOpts, ExecutedFrom.QUERY_BUILDER);
			QuerySubmissionResult result = querySubmissionService
					.submitQueryFromScratch(queryVo.getQrySeqId(), queryOpts,
							getSsoId(), null, ExecutedFrom.QUERY_BUILDER);

			QuerySubmissionControllerBean querySubmissionControllerBean = BeanUtil
					.getInstance().getQuerySubmissionControllerBean();
			querySubmissionControllerBean.setQuery(queryVo);
			querySubmissionControllerBean.setQuerySubmissionResult(result);

			nav = PWiConstants.NAV_QUERY_RESULT;
		} else if (ExecutionMode.BATCH.getId().equals(executionModeId)
				|| ExecutionMode.SFTP.getId().equals(executionModeId)) {

			System.out.println("value of SFTP - "
					+ ExecutionMode.SFTP.getId().equals(executionModeId));
			QuerySubmissionResult result = querySubmissionService
					.submitQueryFromScratch(queryVo.getQrySeqId(), queryOpts,
							getSsoId(), null, ExecutedFrom.QUERY_BUILDER);

			StringBuilder builder = new StringBuilder();

			builder.append("Query successfully queued for batch execution.");
			builder.append("There are ");
			builder.append(result.getNoOfQueryInBatchMode().intValue());
			builder.append(" queries before yours in line.");
			builder.append(" Your query will be executed shortly.");
			builder.append(" When it is finished, you will be notified via");
			builder.append(" email with a link to the results.");
			builder.append(" You can check the status of your query at any time");
			builder.append(" by visiting the Batch page.");

			handleFacesInfo(builder.toString());

			nav = PWiConstants.NAV_QUERY_BUILDER;
		}
		return nav;
	}

	/**
	 * Executes a query specified by the user from the Generate query builder.
	 * 
	 * @return Faces navigation outcome
	 * @throws QueryAccessException
	 * @throws JAXBException
	 * @throws PWiException
	 */
	public String actionCustomizeXmlQuery() throws PWiException,
			QueryAccessException {
		if (!validateBuiltQuery()) {
			executeFlag = false;
			return PWiConstants.NAV_GEN_QUERY_BUILDER;
		} else {
			executeFlag = true;
		}
		PWiQueryVO qryVo = new PWiQueryVO();
		qryVo.setQryXml(queryXml);

		qryVo.setQryNm(queryName);
		qryVo.setQryDesc(queryInfo);
		// Create selected columns and create search input...
		SelectedColumns selCol = new SelectedColumns();
		List<SelectedColumns.Columnref> colRefs = selCol.getColumnref();
		Search search = new Search();
		List<Search.Item> items = search.getItem();
		for (QueryBuilderRow qbr : queryBuilderRows) {
			// Add selected column potentially
			if (qbr.isSelected()) {
				SelectedColumns.Columnref colRef = new SelectedColumns.Columnref();
				colRef.setRef(qbr.getObjId());
				colRefs.add(colRef);
			}
			// Add search item potentially
			if (StringUtils.isNotBlank(qbr.getParameter())
					&& qbr.isSearchable()) {
				Search.Item p1 = new Search.Item();

				// Add column ref to search item
				ColumnRef col = new ColumnRef();
				col.setRef(qbr.getObjId());
				p1.setColumnref(col);

				// Get the value of the operator
				String op = qbr.getSearchOption();
				SearchJaxbUtil.setSearchOperator(p1, op);
				p1.setValue(qbr.getParameter());

				items.add(p1);
			}
		}

		// Create query user options for submitting queries
		QueryUserOptions queryOpts = new QueryUserOptions();
		queryOpts.setSearch(search);
		queryOpts.setSelectedColumns(selCol);
		queryOpts.setExecutionModeId(executionModeId);
		queryOpts.setOutputTypeId(outputOptionId);

		// Stored result state in third-party request-scoped bean for the
		// result bean to retrieve. Can't pass it directly to result bean
		// because the bean doesn't have a way to distinguish an initial
		// request from an invalid request.
		// TODO pH 2013.05: associate a cacheid with the querySubmission
		// in case users execute multiple queries in rapid succession (from fav
		// or hist)

		querySubmission.init(qryVo, queryOpts, ExecutedFrom.QUERY_BUILDER);
		QuerySubmissionResult result = querySubmissionService
				.submitQueryFromXml(qryVo, queryOpts, getSsoId(), null,
						ExecutedFrom.QUERY_BUILDER);

		QuerySubmissionControllerBean querySubmissionControllerBean = BeanUtil
				.getInstance().getQuerySubmissionControllerBean();
		querySubmissionControllerBean.setQuery(qryVo);
		querySubmissionControllerBean.setQuerySubmissionResult(result);
		FacesContext
				.getCurrentInstance()
				.getExternalContext()
				.getSessionMap()
				.put(SESSION_ATTRIBUTE_SUBMISSION_CNTR_BEAN,
						querySubmissionControllerBean);
		return PWiConstants.NAV_QUERY_EXE_RESULT;
	}

	/**
	 * Runs validation on built query and generates messages for any validation
	 * errors.
	 * 
	 * @return true if valid, false if validation failed
	 */
	private boolean validateBuiltQuery() {
		// Validate query builder fields
		boolean valid = true;
		boolean atLeastOneFieldSelected = false;
		boolean atLeastOneSearchParameterSpecified = false;
		for (QueryBuilderRow queryBuilderRow : queryBuilderRows) {
			// Ensure all search mandatory fields have search criteria
			if (queryBuilderRow.isSearchMandatory()
					&& StringUtils.isBlank(queryBuilderRow.getParameter())) {
				handleFacesError("Parameter is required for "
						+ queryBuilderRow.getObjType());
				valid = false;
			}

			// Ensure at least one column is selected for display
			if (queryBuilderRow.isSelected()) {
				atLeastOneFieldSelected = true;
			}
			// Ensure at least one parameter is specified
			if (!StringUtils.isBlank(queryBuilderRow.getParameter())) {
				atLeastOneSearchParameterSpecified = true;
			}
		}
		if (!atLeastOneFieldSelected) {
			handleFacesError("At least one field must be selected for output in order to run query.");
			valid = false;
		}
		if (!atLeastOneSearchParameterSpecified) {
			handleFacesError("A search parameter is required for at least one field in order to run query.");
			valid = false;
		}
		if (executionModeId.contains("sftp") && sftpServerId.equals("select")) {
			handleFacesError("Please select a SFTP Server location to execute the report.");
			valid = false;
		}

		return valid;
	}

	public void actionListenerProcessDrop(DropEvent dropEvent) {
		int dragIndex = ((Integer) dropEvent.getDragValue()).intValue();
		int dropIndex = ((Integer) dropEvent.getDropValue()).intValue();

		// Move row
		QueryBuilderRow rowBeingMoved = queryBuilderRows.remove(dragIndex);
		queryBuilderRows.add(dropIndex, rowBeingMoved);

		// Reset indices
		initializeDragAndDropIndices();
	}

	/**
	 * AJAX action listener for query builder page for when user selects to
	 * display all or none of the fields. Simply selects all the fields or none
	 * of the fields.
	 * 
	 * @param event
	 */
	public void actionListenerSelectAllOrNone(ActionEvent event) {
		Object source = event.getSource();
		if (source instanceof HtmlAjaxSupport) {
			HtmlAjaxSupport has = (HtmlAjaxSupport) source;
			UIComponent parent = has.getParent();
			if (parent instanceof HtmlSelectBooleanCheckbox) {
				HtmlSelectBooleanCheckbox hsbc = (HtmlSelectBooleanCheckbox) parent;
				Object value = hsbc.getValue();
				if (value instanceof Boolean) {
					boolean selectAll = ((Boolean) value).booleanValue();
					if (selectAll) {
						// Select all fields that are selectable
						for (QueryBuilderRow field : queryBuilderRows) {
							if (field.isSelectableToDisplay()) {
								field.setSelected(true);
							}
						}
					} else {
						// Un-select all fields that are selectable
						for (QueryBuilderRow field : queryBuilderRows) {
							if (field.isSelectableToDisplay()) {
								field.setSelected(false);
							}
						}
					}
				}
			}
		}
	}

	public String getQueryName() {
		return queryName;
	}

	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}

	public List<QueryBuilderRow> getQueryBuilderRows() {
		return queryBuilderRows;
	}

	public String getQueryInfo() {
		return queryInfo;
	}

	public void setQueryInfo(String queryInfo) {
		this.queryInfo = queryInfo;
	}

	public void setQueryBuilderRows(List<QueryBuilderRow> queryBuilderRows) {
		this.queryBuilderRows = queryBuilderRows;
	}

	public String getExecutionModeId() {
		return executionModeId;
	}

	public void setExecutionModeId(String executionModeId) {
		this.executionModeId = executionModeId;

		// If execution mode changes, change the output type to the default for
		// the new execution mode
		if (queryIdNum != 0) {
			this.outputOptionId = defaultOutputIdMap.get(executionModeId);
		}
	}

	public String getQueryProcessorId() {
		return queryProcessorId;
	}

	public void setQueryProcessorId(String queryProcessorId) {
		this.queryProcessorId = queryProcessorId;
	}

	public String getQueryDesc() {
		return queryDesc;
	}

	public void setQueryDesc(String queryDescription) {
		this.queryDesc = queryDescription;
	}

	public String getResultMessage() {
		return resultMessage;
	}

	public boolean isAllowReordering() {
		return allowReordering;
	}

	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}

	public List<SelectItem> getExecutionModeOptions() {
		return executionModeOptions;
	}

	public void setExecutionModeOptions(List<SelectItem> executionModeOptions) {
		this.executionModeOptions = executionModeOptions;
	}

	public List<SelectItem> getQueryProcessorOptions() {
		return queryProcessorOptions;
	}

	public void setQueryProcessorOptions(List<SelectItem> queryProcessorOptions) {
		this.queryProcessorOptions = queryProcessorOptions;
	}

	private List<SelectItem> getOperatorOptions(
			List<AllowedoperatorsType> allowOperator) {
		List<SelectItem> allowedOperatorList = new ArrayList<SelectItem>();
		for (AllowedoperatorsType allowedoperatorsType : allowOperator) {
			Map<String, String> opValues = QueryJaxbUtil.getInstance()
					.translateOperator(allowedoperatorsType);
			for (Map.Entry<String, String> entry : opValues.entrySet()) {
				SelectItem allowOpt = new SelectItem();
				allowOpt.setLabel(entry.getValue());
				allowOpt.setValue(entry.getKey());
				allowedOperatorList.add(allowOpt);
			}
		}
		return allowedOperatorList;
	}
	
	public void filltextboxList(){
		Map<String, String> params = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap();
		String paramval = params.get("paramval");
		String parentVal = "";
		for (QueryBuilderRow qbr1 : queryBuilderRows) {
			if(qbr1.getDepend()!=null && qbr1.getDepend().equals(paramval))
			{
				parentVal = qbr1.getObjId();
			}
		}
		Object[] objArr = null;
		String searchOpt ="";
		
		for (QueryBuilderRow qbr : queryBuilderRows) {

			if (qbr.getParameter() != null && paramval.equals(qbr.getObjId())) {
				searchOpt = qbr.getSearchOption();
				objArr = (Object[]) StringUtils.split(qbr.getParameter(),
						System.getProperty("line.separator"));
			}
			if (qbr.getSelectionType() != null) {
				if (qbr.getSelectionType().getSql() != null) {
					String placeholder = SqlTemplateUtil.getInstance()
							.getPlaceHolderVal(qbr.getContentsql());
					if (placeholder != null) {
						String columnId = parseSingleArgument(placeholder);
						
						if (paramval.equals(columnId)) {
							String sql = SqlTemplateUtil.getInstance()
									.parsePlaceholdersAutoFill(qbr.getContentsql(),
											objArr, searchOpt);

							qbr.getSelectionType().getSql().setContent(sql);
							qbr.setSelectionList(null);
							
						}
						else
						{
							if(parentVal.equals(qbr.getDepend()))
							{
								qbr.getSelectionType().getSql().setContent(qbr.getContentsql());
								qbr.setSelectionList(null);
							}
						}
						
						
					}

				}
			}

		}

	}
	
	
	
	
	
	
	public void fillSelectionList() {

		Map<String, String> params = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap();
		String paramval = params.get("paramval");
		String parentVal = "";
		for (QueryBuilderRow qbr1 : queryBuilderRows) {
			if (qbr1.getDepend() != null && qbr1.getDepend().equals(paramval)) {
				parentVal = qbr1.getObjId();
			}
		}
		Object[] objArr = null;
		for (QueryBuilderRow qbr : queryBuilderRows) {

			if (qbr.getParameter() != null && paramval.equals(qbr.getObjId())) {
				objArr = (Object[]) StringUtils.split(qbr.getParameter(),
						System.getProperty("line.separator"));
			}
			if (qbr.getSelectionType() != null) {
				if (qbr.getSelectionType().getSql() != null) {
					String placeholder = SqlTemplateUtil.getInstance()
							.getPlaceHolderVal(qbr.getContentsql());
					if (placeholder != null) {
						String columnId = parseSingleArgument(placeholder);

						if (paramval.equals(columnId)) {
							String sql = SqlTemplateUtil.getInstance()
									.parsePlaceholdersAutoFill(
											qbr.getContentsql(), objArr,
											qbr.getSearchOption());

							qbr.getSelectionType().getSql().setContent(sql);
							qbr.setSelectionList(null);

						} else {
							if (parentVal.equals(qbr.getDepend())) {
								qbr.getSelectionType().getSql()
										.setContent(qbr.getContentsql());
								qbr.setSelectionList(null);
							}
						}

					}

				}
			}

		}

	}

	public void fillSelectionManyList() {

		Map<String, String> params = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap();
		String paramval = params.get("paramval");
		Object[] objArr = null;
		String parentVal = "";
		for (QueryBuilderRow qbr1 : queryBuilderRows) {
			if (qbr1.getDepend() != null && qbr1.getDepend().equals(paramval)) {
				parentVal = qbr1.getObjId();
			}
		}
		for (QueryBuilderRow qbr : queryBuilderRows) {

			if (qbr.getParameter() != null && paramval.equals(qbr.getObjId())) {
				objArr = (Object[]) StringUtils.split(qbr.getParameter(),
						System.getProperty("line.separator"));
			}
			if (qbr.getSelectionType() != null) {
				if (qbr.getSelectionType().getSql() != null) {
					String placeholder = SqlTemplateUtil.getInstance()
							.getPlaceHolderVal(qbr.getContentsql());
					if (placeholder != null) {
						String columnId = parseSingleArgument(placeholder);
						if (paramval.equals(columnId)) {
							String sql = SqlTemplateUtil.getInstance()
									.parsePlaceholdersAutoFill(
											qbr.getContentsql(), objArr,
											qbr.getSearchOption());

							qbr.getSelectionType().getSql().setContent(sql);
							qbr.setSelectionList(null);
						} else {
							if (parentVal.equals(qbr.getDepend())) {
								qbr.getSelectionType().getSql()
										.setContent(qbr.getContentsql());
								qbr.setSelectionList(null);
							}
						}
					}

				}
			}

		}

	}

	String parseSingleArgument(String placeholder) {
		int beginIndex = placeholder.indexOf('{') + 1;
		int endIndex = placeholder.indexOf('}');
		String columnId = placeholder.substring(beginIndex, endIndex);

		return columnId;
	}

	/**
	 * Project : Product Lifecycle Management Date Written : Apr 12, 2011
	 * Security : GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR
	 * GE USE ONLY
	 * 
	 * Copyright(C) 2011 GE All rights reserved
	 * 
	 * Description : Model for a single query builder row
	 * 
	 * Revision Log Apr 12, 2011 | v1.0. Jul 04, 2012 | pH | added support for
	 * advanced input types Sep 05, 2012 | pH | using lazy init for selection
	 * list
	 * -------------------------------------------------------------------------
	 */
	public static class QueryBuilderRow {
		private static final Logger LOGGER = Logger
				.getLogger(QueryBuilderRow.class);

		// informative selection lists for non-show-on-page-load input lists
		// and not-loadable SQL-driven lists.
		private static final List<SelectItem> SELECTION_LIST_TEMP;
		static {
			SelectItem[] items = { new SelectItem("", "Click to populate",
					null, true) };
			SELECTION_LIST_TEMP = Arrays.asList(items);
		}
		private static final List<SelectItem> SELECTION_LIST_ERR = Arrays
				.asList(new SelectItem("", " ", null, true));

		private String objType;
		private String objId;
		private String outputColumn;
		private String searchOption;
		private InputType inputType; // how the user enters the search criterion
		private String parameter; // the user's input for the search criterion
		// format used by datepicker (sample String: dd.MM.yyyy)
		// For both java.util.SimpleDateFormat and rich:calendar,
		// little mm stands for minutes, and capital MM stands for Month.
		// For more information, please see:
		// http://docs.jboss.org/richfaces/latest_3_3_X/en/tlddoc/rich/calendar.html
		// http://docs.oracle.com/javase/6/docs/api/java/text/SimpleDateFormat.html
		private SimpleDateFormat dateFormat = new SimpleDateFormat();
		// options available for selection input types
		private List<SelectItem> selectionList;
		private SelectionType selectionType;
		private boolean showOnPageLoad = true; // used for selection input types
		private boolean searchable;
		private boolean searchMandatory;
		private String allowOperator;
		private String allowOprEqual;
		private String href;
		private boolean hrefToDisplay = false;
		private boolean selected;
		private boolean mandatorySelected;
		private boolean selectableToDisplay;
		private List<SelectItem> operatorList = new ArrayList<SelectItem>();
		private int dragDropIndex;
		private String contentsql;
		private String depend;
		private boolean depended;

		enum InputType {
			PLAINTEXT, DROPDOWN, MULTISELECT, LOOKUP, DATEPICKER, COMBOBOX
		}

		// The following properties determine which input format is used.
		// (plain text, dropdown menu, date picker, usw.)
		public boolean isInputText() {
			return inputType == InputType.PLAINTEXT;
		}

		public boolean isInputDropdown() {
			return inputType == InputType.DROPDOWN;
		}

		public boolean isInputMultiselect() {
			return inputType == InputType.MULTISELECT;
		}

		public boolean isInputLookup() {
			return inputType == InputType.LOOKUP;
		}

		public boolean isInputDate() {
			return inputType == InputType.DATEPICKER;
		}

		public boolean isInputCombobox() {
			return inputType == InputType.COMBOBOX;
		}

		public void setInputType(InputType inputType) {
			this.inputType = inputType;
		}

		public String getHref() {
			return href;
		}

		public void setHref(String href) {
			this.href = href;
		}

		public boolean isHrefToDisplay() {
			return hrefToDisplay;
		}

		public void setHrefToDisplay(boolean hrefToDisplay) {
			this.hrefToDisplay = hrefToDisplay;
		}

		public boolean isShowOnPageLoad() {
			return showOnPageLoad;
		}

		public void setShowOnPageLoad(boolean showOnPageLoad) {
			this.showOnPageLoad = showOnPageLoad;
		}

		public String getDateFormatUppercase() {
			return dateFormat.toPattern().toUpperCase(Locale.US);
		}

		public String getDateFormat() {
			return dateFormat.toPattern();
		}

		public void setDateFormat(String dateFormat) {
			this.dateFormat = new SimpleDateFormat(dateFormat);
		}

		public String getContentsql() {
			return contentsql;
		}

		public void setContentsql(String contentsql) {
			this.contentsql = contentsql;
		}

		public String getDepend() {
			return depend;
		}

		public void setDepend(String depend) {
			this.depend = depend;
		}

		public boolean isDepended() {
			return depended;
		}

		public void setDepended(boolean depended) {
			this.depended = depended;
		}

		public List<SelectItem> getSelectionList() {
			if (!isShowOnPageLoad()) {
				return SELECTION_LIST_TEMP;
			} else if (selectionList == null) {
				// in case, for some reason, we fail to generate the real list,
				// set the list to an error message
				setSelectionList(SELECTION_LIST_ERR);
				if (selectionType != null) {
					if (selectionType.getItem().size() > 0) {
						setSelectionList(getSelectableItems(selectionType
								.getItem()));
						// selectionType = null; // done with this; free memory
					} else if (selectionType.getSql() != null) {
						if (contentsql == null) {
							setContentsql(selectionType.getSql().getContent());
						}
						if (SqlTemplateUtil.getInstance().getPlaceHolderVal(
								selectionType.getSql().getContent()) == null) {
							try {
								setSelectionList(SelectItemService
										.getInstance()
										.getSelectableItems(
												selectionType.getSql().getDsn(),
												selectionType.getSql()
														.getContent(),
												PWiContext.getCurrentInstance()
														.getUserSso()));
							} catch (PWiException e) {
								LOGGER.error(
										"Error generating selection list.", e);
								setSelectionList(SELECTION_LIST_ERR);
							} finally {
								// selectionType = null; // done with this; free
								// memory
							}
						}
					}
				}
			}
			return selectionList;
		}

		public void setSelectionList(List<SelectItem> selectionList) {
			this.selectionList = selectionList;
		}

		public void setSelectionType(SelectionType selectionType) {
			this.selectionType = selectionType;
		}

		public SelectionType getSelectionType() {
			return selectionType;
		}

		/**
		 * List<SelectItem> getSelectableItems Converts the input list of
		 * SelectionitemTypes to a list of SelectItems
		 * 
		 * @param List
		 *            <SelectionitemType> inItems
		 * @return List<SelectItem>
		 */
		private List<SelectItem> getSelectableItems(
				List<SelectionitemType> inItems) {
			List<SelectItem> outItems = new ArrayList<SelectItem>();
			for (SelectionitemType inItem : inItems) {
				SelectItem outItem = new SelectItem();
				outItem.setLabel(inItem.getLabel());
				outItem.setValue(inItem.getValue());
				outItems.add(outItem);
			}
			return outItems;
		}

		//
		// End properties having to do with input types
		//

		/**
		 * @return the selected
		 */
		public boolean isSelected() {
			return selected;
		}

		/**
		 * @param selected
		 *            the selected to set
		 */
		public void setSelected(boolean selected) {
			this.selected = selected;
		}

		/**
		 * @return the searchable
		 */
		public boolean isSearchable() {
			return searchable;
		}

		/**
		 * @param searchable
		 *            the searchable to set
		 */
		public void setSearchable(boolean searchable) {
			this.searchable = searchable;
		}

		public boolean isSearchMandatory() {
			return searchMandatory;
		}

		public void setSearchMandatory(boolean searchMandatory) {
			this.searchMandatory = searchMandatory;
		}

		public boolean isMandatorySelected() {
			return mandatorySelected;
		}

		public void setMandatorySelected(boolean mandatorySelected) {
			this.mandatorySelected = mandatorySelected;
		}

		public String getObjType() {
			return objType;
		}

		public void setObjType(String objType) {
			this.objType = objType;
		}

		public String getObjId() {
			return objId;
		}

		public void setObjId(String objId) {
			this.objId = objId;
		}

		public String getOutputColumn() {
			return outputColumn;
		}

		public void setOutputColumn(String outputColumn) {
			this.outputColumn = outputColumn;
		}

		public String getSearchOption() {
			return searchOption;
		}

		public void setSearchOption(String searchOption) {
			this.searchOption = searchOption;
		}

		public String getParameter() {
			return parameter;
		}

		public void setParameter(String parameter) {
			// if there is a value selected, load any selection list
			if (!showOnPageLoad && parameter != null && !"".equals(parameter)) {
				showOnPageLoad = true;
			}

			// set parameter
			this.parameter = parameter;
		}

		public String[] getArrayParameter() {
			if (parameter == null) {
				parameter = "";
			}
			return parameter.split("\\\n");
		}

		public void setArrayParameter(String[] sArrayParameter) {
			this.parameter = join(Arrays.asList(sArrayParameter), "\n");
		}

		public Date getDateParameter() {
			Date date = null;
			try {
				if ((parameter != null) && !parameter.equals("")) {
					date = dateFormat.parse(parameter);
				}
			} catch (ParseException e) {
				LOGGER.error(
						(new StringBuilder()).append("Problem parsing date [")
								.append(parameter).append("] using format [")
								.append(dateFormat.toPattern()).append("].")
								.toString(), e);
			}
			return date;
		}

		public void setDateParameter(Date dateParameter) {
			if (dateParameter != null) {
				this.parameter = dateFormat.format(dateParameter);
			} else {
				this.parameter = "";
			}
		}

		/**
		 * join converts a List to a single String by converting each element to
		 * a String and concatenating them with the specified record separator
		 * between each element.
		 * 
		 * @param list
		 *            a List to be converted to a String
		 * @param recordsep
		 *            String separating list elements
		 * @return String representing the list
		 */
		private String join(List<String> list, String recordsep) {
			StringBuilder builder = new StringBuilder();
			if (list != null && list.size() > 0) {
				Iterator<String> iter = list.iterator();
				builder.append(iter.next());
				while (iter.hasNext()) {
					builder.append(recordsep).append(iter.next());
				}
			}
			return builder.toString();
		}

		/**
		 * @return the allowOperator
		 */
		public String getAllowOperator() {
			return allowOperator;
		}

		/**
		 * @param allowOperator
		 *            the allowOperator to set
		 */
		public void setAllowOperator(String allowOperator) {
			this.allowOperator = allowOperator;
		}

		/**
		 * @return the allowOprEqual
		 */
		public String getAllowOprEqual() {
			return allowOprEqual;
		}

		/**
		 * @param allowOprEqual
		 *            the allowOprEqual to set
		 */
		public void setAllowOprEqual(String allowOprEqual) {
			this.allowOprEqual = allowOprEqual;
		}

		public List<SelectItem> getOperatorList() {
			return operatorList;
		}

		public void setOperatorList(List<SelectItem> operatorList) {
			this.operatorList = operatorList;
		}

		/**
		 * @return whether exactlyOneOperator is allowed
		 */
		public boolean isExactlyOneOperator() {
			return operatorList.size() == 1;
		}

		// /**
		// * @param exactlyOneOperator
		// * the exactlyOneOperator to set
		// */
		// public void setExactlyOneOperator(boolean exactlyOneOperator) {
		// this.exactlyOneOperator = exactlyOneOperator;
		// }

		public void setSelectableToDisplay(boolean selectableToDisplay) {
			this.selectableToDisplay = selectableToDisplay;
		}

		public boolean isSelectableToDisplay() {
			return selectableToDisplay;
		}

		public int getDragDropIndex() {
			return dragDropIndex;
		}

		public void setDragDropIndex(int dragDropIndex) {
			this.dragDropIndex = dragDropIndex;
		}
	} // end class QueryBuilderRow

	public void setQueryVo(PWiQueryVO queryVo) {
		this.queryVo = queryVo;
	}

	public String getOutputOptionId() {
		return outputOptionId;
	}

	public void setOutputOptionId(String outputOptionId) {
		this.outputOptionId = outputOptionId;
	}

	public List<SelectItem> getOutputOptions() {
		if (queryIdNum != 0) {
			if (executionModeId.contains("::")) {
				sftpServerId = "select";
				return outputOptionsMap.get(executionModeId.substring(0,
						executionModeId.indexOf("::")));
			} else {
				sftpServerId = "select";
				if (executionModeId.equals("sftp")) {
					List<SelectItem> lstItem = new ArrayList<SelectItem>();
					lstItem.add(new SelectItem("csv", "CSV"));
					return lstItem;
				} else {
					return outputOptionsMap.get(executionModeId);
				}

			}

		} else {
			List<SelectItem> outputOptions = new ArrayList<SelectItem>();
			outputOptions.add(new SelectItem("web"));
			return outputOptions;
		}

	}

	/**
	 * @return the queryIdNum
	 */
	public Integer getQueryIdNum() {
		return queryIdNum;
	}

	/**
	 * @param queryIdNum
	 *            the queryIdNum to set
	 */
	public void setQueryIdNum(Integer queryIdNum) {
		this.queryIdNum = queryIdNum;
	}

	/**
	 * @param queryGroupService
	 *            the queryGroupService to set
	 */
	public void setQueryGroupService(QueryGroupService queryGroupService) {
		this.queryGroupService = queryGroupService;
	}

	/**
	 * @return the executeFlag
	 */
	public boolean isExecuteFlag() {
		return executeFlag;
	}

	/**
	 * @param executeFlag
	 *            the executeFlag to set
	 */
	public void setExecuteFlag(boolean executeFlag) {
		this.executeFlag = executeFlag;
	}

	public String getQueryXml() {
		return queryXml;
	}

	public void setQueryXml(String queryXml) {
		this.queryXml = queryXml;
	}

	public PWiQueryVO getQueryVo() {
		return queryVo;
	}

	public List<SelectItem> getSftpServerLists() {
		return sftpServerLists;
	}

	public void setSftpServerLists(List<SelectItem> sftpServerLists) {
		this.sftpServerLists = sftpServerLists;
	}

	public String getSftpServerId() {
		return sftpServerId;
	}

	public void setSftpServerId(String sftpServerId) {
		this.sftpServerId = sftpServerId;
	}

	public boolean isSftpOpUsed() {
		return sftpOpUsed;
	}

	public void setSftpOpUsed(boolean sftpOpUsed) {
		this.sftpOpUsed = sftpOpUsed;
	}

}