package com.geinfra.geaviation.pwi.service;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.context.PWiContext;
import com.geinfra.geaviation.pwi.dao.AdminSettingsDAO;
import com.geinfra.geaviation.pwi.model.AdminSettingsVO;

/**
 * 
 * Project : Product Lifecycle Management Date Written : May 19, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : AdminSettingsService
 * 
 * Revision Log May 19, 2010 | v1.0.
 * --------------------------------------------------------------
 */

public class AdminSettingsService {
	public static final String SETTING_BATCH_DISABLED = "BatchDisabled";
	public static final String SETTING_HEADER_TEXT = "Message";
	public static final String SETTING_QI_HEADER_TEXT = "QiMessage";
	public static final String SETTING_BATCH_HEADER_TEXT = "BatchMessage";
	public static final String SETTING_BATCH_RENEWAL_PERIOD = "QueryExtentionDuration";
	public static final String SETTING_ONLINE_QUERY_TIMEOUT_SECS = "OnlineQueryTimeout";
	public static final String SETTING_ONLINE_RESULT_SIZE_LIMIT = "OnlineResultSizeLimit";
	public static final String SETTING_FOOTER_TEXT = "Footer";
	public static final String SETTING_HELP_TEXT = "HelpMessage";

	// Injected
	private AdminSettingsDAO adminSettingsDAO;

	private AdminSettingsVO getSetting(String settingName) throws PWiException {
		return adminSettingsDAO.getSetting(settingName);
	}

	private void createSetting(String name, String value) throws PWiException {
		adminSettingsDAO.createSetting(name, value,
				PWiContext.getCurrentInstance().getUserSso());
	}

	private void updateSetting(String name, String value) throws PWiException {
		adminSettingsDAO.updateSetting(name, value,
				PWiContext.getCurrentInstance().getUserSso());
	}

	public boolean isBatchDisabled() throws PWiException {
		AdminSettingsVO setting = adminSettingsDAO
				.getSetting(AdminSettingsService.SETTING_BATCH_DISABLED);
		if (setting == null) {
			return false;
		}
		return Boolean.parseBoolean(setting.getAppParVal());
	}

	public int getOnlineQueryTimeoutSecs() throws PWiException {
		AdminSettingsVO setting = getSetting(SETTING_ONLINE_QUERY_TIMEOUT_SECS);
		return setting != null ? Integer.parseInt(setting.getAppParVal()) : 0;
	}

	public void setOnlineQueryTimeoutSecs(int timeoutSecs) throws PWiException {
		String timeoutString = Integer.toString(timeoutSecs);
		if (getSetting(SETTING_ONLINE_QUERY_TIMEOUT_SECS) == null) {
			createSetting(SETTING_ONLINE_QUERY_TIMEOUT_SECS, timeoutString);
		} else {
			updateSetting(SETTING_ONLINE_QUERY_TIMEOUT_SECS, timeoutString);
		}
	}
	
	public String getBatchHeaderText()throws PWiException {
		AdminSettingsVO setting = adminSettingsDAO
				.getSetting(AdminSettingsService.SETTING_BATCH_HEADER_TEXT);
		return setting != null ? setting.getAppParVal() : "";
	}

	public void setBatchHeaderText(String batchHeaderText) throws PWiException {
		if (getSetting(SETTING_BATCH_HEADER_TEXT) == null) {
			createSetting(SETTING_BATCH_HEADER_TEXT, batchHeaderText);
		} else {
			updateSetting(SETTING_BATCH_HEADER_TEXT, batchHeaderText);
		}
	}
	
	public int getBatchRenewalPeriod() throws PWiException {
		AdminSettingsVO setting = getSetting(SETTING_BATCH_RENEWAL_PERIOD);
		return setting != null ? Integer.parseInt(setting.getAppParVal()) : 0;
	}

	public void setBatchRenewalPeriod(int renewalDays) throws PWiException {
		String expireString = Integer.toString(renewalDays);
		if (getSetting(SETTING_BATCH_RENEWAL_PERIOD) == null) {
			createSetting(SETTING_BATCH_RENEWAL_PERIOD, expireString);
		} else {
			updateSetting(SETTING_BATCH_RENEWAL_PERIOD, expireString);
		}
	}

	public int getOnlineResultSizeLimit() throws PWiException {
		AdminSettingsVO setting = getSetting(SETTING_ONLINE_RESULT_SIZE_LIMIT);
		return setting != null ? Integer.parseInt(setting.getAppParVal()) : 0;
	}

	public void setOnlineResultSizeLimit(int sizeLimit) throws PWiException {
		String sizeString = Integer.toString(sizeLimit);
		if (getSetting(SETTING_ONLINE_RESULT_SIZE_LIMIT) == null) {
			createSetting(SETTING_ONLINE_RESULT_SIZE_LIMIT, sizeString);
		} else {
			updateSetting(SETTING_ONLINE_RESULT_SIZE_LIMIT, sizeString);
		}
	}

	public String getHeaderText() throws PWiException {
		AdminSettingsVO setting = adminSettingsDAO
				.getSetting(AdminSettingsService.SETTING_HEADER_TEXT);
		return setting != null ? setting.getAppParVal() : "";
	}

	public void setHeaderText(String headerText) throws PWiException {
		if (getSetting(SETTING_HEADER_TEXT) == null) {
			createSetting(SETTING_HEADER_TEXT, headerText);
		} else {
			updateSetting(SETTING_HEADER_TEXT, headerText);
		}
	}
	
	public String getFooterText() throws PWiException {
		AdminSettingsVO setting = adminSettingsDAO
				.getSetting(AdminSettingsService.SETTING_FOOTER_TEXT);
		return setting != null ? setting.getAppParVal() : "";
	}
	
	public void setFooterText(String footerText) throws PWiException {
		if (getSetting(SETTING_FOOTER_TEXT) == null) {
			createSetting(SETTING_FOOTER_TEXT, footerText);
		} else {
			updateSetting(SETTING_FOOTER_TEXT, footerText);
		}
	}

	public String getHelpMsgText() throws PWiException {
		AdminSettingsVO setting = adminSettingsDAO
				.getSetting(AdminSettingsService.SETTING_HELP_TEXT);
		return setting != null ? setting.getAppParVal() : "";
	}
	
	public void setHelpMsgText(String helpMsgText) throws PWiException {
		if (getSetting(SETTING_HELP_TEXT) == null) {
			createSetting(SETTING_HELP_TEXT, helpMsgText);
		} else {
			updateSetting(SETTING_HELP_TEXT, helpMsgText);
		}
	}


	public String getQuickIntelligenceHeaderText() throws PWiException {
		AdminSettingsVO setting = adminSettingsDAO
				.getSetting(AdminSettingsService.SETTING_QI_HEADER_TEXT);
		return setting != null ? setting.getAppParVal() : "";
	}

	public void setQuickIntelligenceHeaderText(String headerText) throws PWiException {
		if (getSetting(SETTING_QI_HEADER_TEXT) == null) {
			createSetting(SETTING_QI_HEADER_TEXT, headerText);
		} else {
			updateSetting(SETTING_QI_HEADER_TEXT, headerText);
		}
	}

	/**
	 * @param adminSettingsDAO
	 *            the adminSettingsDAO to set
	 */
	public void setAdminSettingsDAO(AdminSettingsDAO adminSettingsDAO) {
		this.adminSettingsDAO = adminSettingsDAO;
	}
}
