package com.geinfra.geaviation.pwi.context;

import javax.servlet.ServletContext;

import com.geinfra.geaviation.pwi.common.PWiException;

/**
 * Project : Product Lifecycle Management Date Written : Apr 13, 2011 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description :
 * 
 * This class abstracts PortletContext and ServletContext.
 * 
 * Revision Log Apr 13, 2011 | v1.0.
 * --------------------------------------------------------------
 */
public abstract class PWiApplication {
	public static PWiApplication getPWiApplication(Object contextObject)
			throws PWiException {
		if (contextObject instanceof ServletContext) {
			return new ServletContextAdapter((ServletContext) contextObject);
		} else {
			throw new PWiException("Unsupported context object type: "
					+ contextObject);
		}
	}

	public abstract Object getAttribute(String attributeName);

	private static class ServletContextAdapter extends PWiApplication {
		ServletContext servletContext;

		public ServletContextAdapter(ServletContext servletContext) {
			this.servletContext = servletContext;
		}

		public Object getAttribute(String attributeName) {
			return servletContext.getAttribute(attributeName);
		}
	}
}