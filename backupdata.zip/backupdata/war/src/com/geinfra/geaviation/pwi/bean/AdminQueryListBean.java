package com.geinfra.geaviation.pwi.bean;

import java.util.List;

import org.richfaces.component.html.HtmlExtendedDataTable;

import com.geinfra.geaviation.pwi.bean.util.BeanUtil;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.QueriesVO;
import com.geinfra.geaviation.pwi.service.QueriesService;

/**
 * 
 * Project : Product Lifecycle Management Intelligence Date Written : May 21,
 * 2010 Security : GE Confidential Restrictions : GE PROPRIETARY INFORMATION,
 * FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Managed backing bean for admin page which lists all queries
 * defined in the system.
 * 
 * Revision Log May 8, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class AdminQueryListBean extends BaseBean {
	// Injected service
	private QueriesService queriesService;

	private HtmlExtendedDataTable queryTable = new HtmlExtendedDataTable();
	private List<QueriesVO> queriesVOList;
	
	public void setQueriesService(QueriesService queriesService) {
		this.queriesService = queriesService;
	}

	/**
	 * Action method that responds to requests to edit a query in admin
	 * 
	 * @return Faces navigation outcome
	 * @throws PWiException
	 * @throws NumberFormatException
	 */
	public String actionEditQuery() throws NumberFormatException, PWiException {
		return BeanUtil.getInstance().getAdminQueryEditorBean().initEdit(
				((QueriesVO) queryTable.getRowData()).getQueryId());
	}

	/**
	 * Action method that responds to requests for creating a query in admin.
	 * 
	 * @return Faces navigation outcome
	 * @throws PWiException
	 */
	public String actionCreateQuery() throws PWiException {
		return BeanUtil.getInstance().getAdminQueryEditorBean().initCreate();
	}

	public List<QueriesVO> getQueriesVOList() throws PWiException {
		BeanUtil.getInstance().getApplicationParametersBean().setLinkSelectedFrAdmin("Queries");
		if (queriesVOList == null && queriesService != null) {
			queriesVOList = queriesService.getAllQueries();
		}
		return queriesVOList;
	}

	public void setQueriesVOList(List<QueriesVO> queriesVOList) {
		this.queriesVOList = queriesVOList;
	}

	public HtmlExtendedDataTable getQueryTable() {
		return queryTable;
	}

	public void setQueryTable(HtmlExtendedDataTable queryTable) {
		this.queryTable = queryTable;
	}
}