package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : SubscriptionDetails - Subscription representation.
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class SubscriptionDetails implements Serializable {
	private static final long serialVersionUID = -5317869821950289290L;
	private String subscriptionStatus;
	private Object lastRanTime;
	private Object nextScheduledRun;
	private String lastRanOutputLocation;

	/**
	 * @return the subscriptionStatus
	 */
	public String getSubscriptionStatus() {
		return subscriptionStatus;
	}

	/**
	 * @param subscriptionStatus
	 *            the subscriptionStatus to set
	 */
	public void setSubscriptionStatus(String subscriptionStatus) {
		this.subscriptionStatus = subscriptionStatus;
	}

	/**
	 * @return the lastRanTime
	 */
	public Object getLastRanTime() {
		return lastRanTime;
	}

	/**
	 * @param lastRanTime
	 *            the lastRanTime to set
	 */
	public void setLastRanTime(Object lastRanTime) {
		this.lastRanTime = lastRanTime;
	}

	/**
	 * @return the nextScheduledRun
	 */
	public Object getNextScheduledRun() {
		return nextScheduledRun;
	}

	/**
	 * @param nextScheduledRun
	 *            the nextScheduledRun to set
	 */
	public void setNextScheduledRun(Object nextScheduledRun) {
		this.nextScheduledRun = nextScheduledRun;
	}

	/**
	 * @return the lastRanOutputLocation
	 */
	public String getLastRanOutputLocation() {
		return lastRanOutputLocation;
	}

	/**
	 * @param lastRanOutputLocation
	 *            the lastRanOutputLocation to set
	 */
	public void setLastRanOutputLocation(String lastRanOutputLocation) {
		this.lastRanOutputLocation = lastRanOutputLocation;
	}

}
