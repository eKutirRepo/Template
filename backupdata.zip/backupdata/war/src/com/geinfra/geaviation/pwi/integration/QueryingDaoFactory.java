package com.geinfra.geaviation.pwi.integration;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.executors.ExecutorQueryingDao;
import com.geinfra.geaviation.pwi.service.ConfigService;
import com.geinfra.geaviation.pwi.xml.query.DbType;
import com.geinfra.geaviation.pwi.xml.query.QueryType;

/**
 * Project : Product Lifecycle Management Date Written : May 18, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Returns the proper DAO object to execute queries for a given
 * QueryType.
 * 
 * Revision Log May 18, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class QueryingDaoFactory {
	private ConfigService configService;

	public void setConfigService(ConfigService configService) {
		this.configService = configService;
	}

	public QueryingDao lookup(QueryType queryType) throws PWiException {
		QueryingDao queryingDao = null;

		// If specified, use new mechanism for specifying query execution
		if (queryType.getQuerydefinition().getExecutor() != null) {
			queryingDao = new ExecutorQueryingDao(configService
					.getQueryTimeoutSecs(), configService.getResultSizeLimit());
		} else {
			// Otherwise use old mechanism for specifying query execution
			DbType dbType = queryType.getQuerydefinition().getDb();
			if (dbType != null) {
				/*if (dbType.getCustomreport() != null
						&& dbType.getCustomreport().trim().equals(
								"HARDWARETAGGING")) {
					// Use hardware tagging DAO with non-vault ODS
					queryingDao = new HardwareTaggingJDBCDAO(configService
							.getQueryTimeoutSecs(), configService
							.getResultSizeLimit(), false);
				} else if (dbType.getCustomreport() != null
						&& dbType.getCustomreport().trim().equals(
								"HARDWARETAGGINGVAULT")) {
					// Use hardware tagging DAO with vault ODS
					queryingDao = new HardwareTaggingJDBCDAO(configService
							.getQueryTimeoutSecs(), configService
							.getResultSizeLimit(), true);
				} else*/ if (dbType.getTemplatedb() != null) {
					// Use general template DAO
					queryingDao = new TemplateJdbcDAO(configService
							.getQueryTimeoutSecs(), configService
							.getResultSizeLimit());
				}
			}
		}

		if (queryingDao == null) {
			throw new PWiException(
					"Failed to create DAO.  DAO type could not be identified from query definition.");
		}

		return queryingDao;
	}
}
