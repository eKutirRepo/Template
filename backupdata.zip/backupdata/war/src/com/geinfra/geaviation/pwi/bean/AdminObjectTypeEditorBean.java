package com.geinfra.geaviation.pwi.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.PWiObjectTypeVO;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.service.ObjectTypeService;
import com.geinfra.geaviation.pwi.service.QueryGroupService;
import com.geinfra.geaviation.pwi.util.PWiConstants;

/**
 * 
 * Project : Product Lifecycle Management Intelligence Date Written : May 21,
 * 2010 Security : GE Confidential Restrictions : GE PROPRIETARY INFORMATION,
 * FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Backing managed bean for the admin page to create/edit queries.
 * 
 * Revision Log May 8, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class AdminObjectTypeEditorBean extends BaseBean {
	// Dependency-injected services
	private ObjectTypeService objectTypeService;
	private QueryGroupService queryGroupService;

	private Integer objTypId;
	private String objectTypeName;
	private String objectTypeDesc;
	private String allQueryGroups;
	private List<PWiQueryGroupVO> selectedQueryGroupsList;
	private List<PWiQueryGroupVO> availableQueryGroupList;
	private List<PWiQueryGroupVO> originalSelectedGroups;
	private boolean isNew;
	private boolean shwInQi;

	public void setQueryGroupService(QueryGroupService queryGroupService) {
		this.queryGroupService = queryGroupService;
	}

	public void setObjectTypeService(ObjectTypeService objectTypeService) {
		this.objectTypeService = objectTypeService;
	}

	/**
	 * Action method that responds to requests to save a newly created objectType.
	 * 
	 * @return Faces navigation outcome
	 * @throws PWiException
	 */
	public String actionSaveNewObjectType() throws PWiException {
		// Check for validation errors
		try{
			boolean valid = objectTypeService.validateName(objectTypeName);
			if (objectTypeService.checkNames(objectTypeName, objectTypeDesc) > 0) {
				handleFacesError(PWiConstants.ERROR_DUPLICATE_NAME);
				valid = false;
			}
	
			if (!valid) {
				// Validation errors exist, return to same page to display
				// validation error messages
				return PWiConstants.NAV_ADMIN_OBJ_TYP_EDITOR;
			}
	
			List<Integer> selectedGroupIds = new ArrayList<Integer>();
			for (PWiQueryGroupVO group : selectedQueryGroupsList) {
				selectedGroupIds.add(group.getQueryGroupId());
			}
	
			// Persist new objectType
			this.objTypId = objectTypeService.createNewObjectType(
					objectTypeName, objectTypeDesc, shwInQi, selectedGroupIds,
					getSsoId());
	
			handleFacesInfo("ObjectType " + this.objectTypeName + " created successfully.");
		}
		catch(Exception ex){
			throw new PWiException("ObjectTypeService/queryGroupService instance was not initiated.." + ex);
		}
		return PWiConstants.NAV_ADMIN_OBJ_TYP_LIST;
	}

	/**
	 * Initializes state necessary to display admin object type editor to create
	 * a new object type.
	 * 
	 * @return JSF navigation string
	 */
	public String initCreate() {
		this.isNew = true;

		// Initialize object type-related state
		this.objTypId = null;
		this.objectTypeName = null;
		this.objectTypeDesc = null;
		this.shwInQi = true;

		// Initialize group-related state
		this.originalSelectedGroups = new ArrayList<PWiQueryGroupVO>();
		this.selectedQueryGroupsList = new ArrayList<PWiQueryGroupVO>();
		this.availableQueryGroupList = (queryGroupService != null) ? (List<PWiQueryGroupVO>) queryGroupService
				.getAllQueryGroups() : null;

		return PWiConstants.NAV_ADMIN_OBJ_TYP_EDITOR;
	}

	/**
	 * Initializes state necessary to display the admin object type editor to
	 * edit the specified object type.
	 * 
	 * @param theObjectTypeSequenceId
	 *            ID of the object type to edit
	 * @return JSF navigation string
	 * @throws PWiException
	 */
	public String initEdit(Integer theObjectTypeSequenceId) throws PWiException {
		this.isNew = false;

		this.objTypId = theObjectTypeSequenceId;

		try{
			// Initialize object type-related state
			PWiObjectTypeVO resultObjectType = objectTypeService.getObjectTypeById(this.objTypId);
			this.objectTypeName = resultObjectType.getObjTypNm();
			this.objectTypeDesc = resultObjectType.getObjTypDesc();
			this.shwInQi = resultObjectType.isShwInQi();
	
				// Initialize group-related state
				this.originalSelectedGroups = queryGroupService
						.findSelectedGroupsForObjectType(this.objTypId);
				this.selectedQueryGroupsList = new ArrayList<PWiQueryGroupVO>();
				this.selectedQueryGroupsList.addAll(this.originalSelectedGroups);
				this.availableQueryGroupList = (List<PWiQueryGroupVO>) queryGroupService
						.getAllQueryGroups();
				this.availableQueryGroupList.removeAll(selectedQueryGroupsList);
		}
		catch(Exception ex){
			throw new PWiException("ObjectTypeService/queryGroupService instance was not initiated.." + ex);
		}		
		return PWiConstants.NAV_ADMIN_OBJ_TYP_EDITOR;
	}

	public void getNonSelectedGroups(List<PWiQueryGroupVO> availList,
			List<PWiQueryGroupVO> selectList) {
		for (PWiQueryGroupVO queryGroupVO : selectList) {
			removeVO(availList, queryGroupVO);
		}
	}

	private void removeVO(List<PWiQueryGroupVO> searchList,
			PWiQueryGroupVO queryGroupVO) {
		ListIterator<PWiQueryGroupVO> itr = searchList.listIterator();
		while (itr.hasNext()) {
			PWiQueryGroupVO QueryGroupVO1 = (PWiQueryGroupVO) itr.next();
			if (QueryGroupVO1.equals(queryGroupVO)) {
				itr.remove();
			}
		}
	}

	/**
	 * Action method that responds to requests to save changes to an edited
	 * query.
	 * 
	 * @return a Faces navigation outcome.
	 * @throws PWiException
	 */
	public String actionUpdateObjectType() throws PWiException {
		
		try{
			// Check for validation errors
			boolean valid = objectTypeService.validateName(this.objectTypeName);
			if (objectTypeService.checkNamesForEdit(
					this.objectTypeName, this.objectTypeDesc, this.objTypId) > 0) {
				handleFacesError(PWiConstants.ERROR_DUPLICATE_NAME);
				valid = false;
			}
	
			if (!valid) {
				// Validation errors exist, return to same page to display
				// validation error messages
				return PWiConstants.NAV_ADMIN_OBJ_TYP_EDITOR;
			}
	
			String userId = getSsoId();
	
			// Initialize query
			PWiObjectTypeVO objectType = new PWiObjectTypeVO();
			objectType.setObjTypSeqId(objTypId);
			objectType.setObjTypNm(objectTypeName);
			objectType.setObjTypDesc(objectTypeDesc);
			objectType.setShwInQi(shwInQi);
	
			List<Integer> selectedGroupIds = new ArrayList<Integer>();
			for (PWiQueryGroupVO group : selectedQueryGroupsList) {
				selectedGroupIds.add(group.getQueryGroupId());
			}
	
			// Persist updated object type
			objectTypeService.updateObjectType(objectType, selectedGroupIds, userId);
	
			handleFacesInfo("ObjectType " + this.objectTypeName + " updated successfully.");
		}
		catch(Exception ex){
			throw new PWiException("ObjectTypeService instance was not initiated.." + ex);
		}
		return PWiConstants.NAV_ADMIN_OBJ_TYP_LIST;
	}
	
	public String actionCancel() {
		return PWiConstants.NAV_ADMIN_OBJ_TYP_LIST;
	}

	public boolean isNew() {
		return isNew;
	}

	public String getObjectTypeName() {
		return objectTypeName;
	}
	public void setObjectTypeName(String objectTypeName) {
		this.objectTypeName = objectTypeName;
	}

	/**
	 * @return the allQueryGroups
	 */
	public String getAllQueryGroups() {
		return allQueryGroups;
	}

	/**
	 * @param allQueryGroups
	 */
	public void setAllQueryGroups(String allQueryGroups) {
		this.allQueryGroups = allQueryGroups;
	}

	/**
	 * @return the selectedQueryGroupsList
	 */
	public List<PWiQueryGroupVO> getSelectedQueryGroupsList() {
		return selectedQueryGroupsList;
	}

	/**
	 * @param selectedQueryGroupsList
	 *            the selectedQueryGroupsList to set
	 */
	public void setSelectedQueryGroupsList(
			List<PWiQueryGroupVO> selectedQueryGroupsList) {
		this.selectedQueryGroupsList = selectedQueryGroupsList;
	}

	/**
	 * @return the availableQueryGroupList
	 */
	public List<PWiQueryGroupVO> getAvailableQueryGroupList() {
		return availableQueryGroupList;
	}

	/**
	 * @param availableQueryGroupList
	 *            the availableQueryGroupList to set
	 */
	public void setAvailableQueryGroupList(
			List<PWiQueryGroupVO> availableQueryGroupList) {
		this.availableQueryGroupList = availableQueryGroupList;
	}

	public Integer getObjectTypeSequenceId() {
		return objTypId;
	}

	public void setObjectTypeSequenceId(Integer objTypId1) {
		this.objTypId = objTypId1;
	}

	public String getObjectTypeDesc() {
		return objectTypeDesc;
	}

	public void setObjectTypeDesc(String objectTypeDescription) {
		this.objectTypeDesc = objectTypeDescription;
	}

	public void setShwInQi(boolean shwInQi) {
		this.shwInQi = shwInQi;
	}

	public boolean isShwInQi() {
		return shwInQi;
	}
}