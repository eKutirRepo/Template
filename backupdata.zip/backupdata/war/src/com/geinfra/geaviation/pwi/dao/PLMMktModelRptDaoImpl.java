/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMMktModelRptDaoImpl.java
 * @Creation date: 12-June-2017
 * @version 1.0
 * @author : Tech Mahindra (PWi Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMCntrtSmryRptData;
import com.geinfra.geaviation.pwi.data.PLMMktModelRptData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;


public class PLMMktModelRptDaoImpl extends SimpleJdbcDaoSupport implements PLMMktModelRptDaoIfc {
	
	/**
	 * Holds the Logger.
	 */
	private static final Logger LOG = Logger.getLogger(PLMMktModelRptDaoImpl.class);
	
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	
	
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}
	/**
	 * @param selProduct
	 * @param prodManagementFlag
	 * @param preliminaryFlag
	 * @return
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getModels(String selProduct, boolean prodManagementFlag, boolean preliminaryFlag) throws PLMCommonException {
		LOG.info("selProduct in DAO-------------> getModels "+selProduct);
		StringBuffer query = new StringBuffer();
		query.append(PLMSearchQueries.GET_MODEL_NAMES);
		
		if ("Gas".equalsIgnoreCase(selProduct)) {
			query.append("AND T_PRDT_CFGN.GE_COST_GRP IN ( 'Gas', 'Gas-Options') ");
		} else if ("Steam".equalsIgnoreCase(selProduct)) {
			query.append("AND T_PRDT_CFGN.GE_COST_GRP IN ( 'Steam', 'Steam-Options') ");
		} else if ("Gen".equalsIgnoreCase(selProduct)) {
			query.append("AND T_PRDT_CFGN.GE_COST_GRP IN ( 'Gen', 'Gen-Options') ");
		} else if ("PLANT".equalsIgnoreCase(selProduct)) {
			query.append("AND T_PRDT_CFGN.GE_COST_GRP IN ( 'PLANT') ");
		} 
		
		if (prodManagementFlag && preliminaryFlag) {
			query.append("AND T_HW_PRDT.STATE  IN ('Product Management', 'Preliminary') ");
		} else if (prodManagementFlag) {
			query.append("AND T_HW_PRDT.STATE  IN ('Product Management') ");
		} else if (preliminaryFlag) {
			query.append("AND T_HW_PRDT.STATE  IN ('Preliminary') ");
		}
		
		query.append(PLMSearchQueries.GET_MODEL_NAMES_GRP_ORDER);
		LOG.info("Query to get Model Values >>>> " + query.toString());
		return getSimpleJdbcTemplate().query(query.toString(), new GetModelsMapper());
	}
	
	/**
	 * @return String objects.
	 */
	private static final class GetModelsMapper implements ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			SelectItem modelName = new SelectItem(rs.getString(PLMUtils.checkNullVal("MODEL")));
			return modelName;
		}
	}
	
	/**
	 * @param selProduct
	 * @param selModel
	 * @param prodManagementFlag
	 * @param preliminaryFlag
	 * @return
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getConfigOptions(String selProduct, String selModel, boolean prodManagementFlag, boolean preliminaryFlag) throws PLMCommonException {
		LOG.info("selModel in DAO-------------> getConfigOptions "+selModel);
		StringBuffer query = new StringBuffer();
		query.append(PLMSearchQueries.GET_CO_NAMES);
		
		if ("Gas".equalsIgnoreCase(selProduct)) {
			query.append("WHERE T_PRDT_CFGN.GE_COST_GRP IN ( 'Gas', 'Gas-Options') ");
		} else if ("Steam".equalsIgnoreCase(selProduct)) {
			query.append("WHERE T_PRDT_CFGN.GE_COST_GRP IN ( 'Steam', 'Steam-Options') ");
		} else if ("Gen".equalsIgnoreCase(selProduct)) {
			query.append("WHERE T_PRDT_CFGN.GE_COST_GRP IN ( 'Gen', 'Gen-Options') ");
		} else if ("PLANT".equalsIgnoreCase(selProduct)) {
			query.append("WHERE T_PRDT_CFGN.GE_COST_GRP IN ( 'PLANT') ");
		} 
		
		if (prodManagementFlag && preliminaryFlag) {
			query.append("AND T_HW_PRDT.STATE  IN ('Product Management', 'Preliminary') ");
		} else if (prodManagementFlag) {
			query.append("AND T_HW_PRDT.STATE  IN ('Product Management') ");
		} else if (preliminaryFlag) {
			query.append("AND T_HW_PRDT.STATE  IN ('Preliminary') ");
		}
		
		if (!PLMUtils.isEmpty(selModel)) {
			query.append("AND MDL.MARKETING_NAME = '").append(selModel).append("'");
		}
		
		query.append(PLMSearchQueries.GET_CO_NAMES_GRP_ORDER);
		LOG.info("Query to get Configuration Options Values >>>> " + query.toString());
		return getSimpleJdbcTemplate().query(query.toString(), new GetConfigOptionsMapper());
	}
	
	/**
	 * @return String objects.
	 */
	private static final class GetConfigOptionsMapper implements ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			SelectItem configOptionsName = new SelectItem(rs.getString(PLMUtils.checkNullVal("CO_NAME")));
			return configOptionsName;
		}
	}
	
	/**
	 * @param selProduct
	 * @param selModel
	 * @param selconfigOptions
	 * @param prodManagementFlag
	 * @param preliminaryFlag
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMMktModelRptData> getRequirementsList(String selProduct, String selModel, List<String> selconfigOptions, 
			boolean prodManagementFlag, boolean preliminaryFlag) throws PLMCommonException {
		LOG.info("selconfigOptions in DAO-------------> getRequirementsList "+ selconfigOptions);
		StringBuffer query = new StringBuffer();
		query.append(PLMSearchQueries.GET_REQUIREMENTS);
		
		if ("Gas".equalsIgnoreCase(selProduct)) {
			query.append("WHERE T_PRDT_CFGN.GE_COST_GRP IN ( 'Gas', 'Gas-Options') ");
		} else if ("Steam".equalsIgnoreCase(selProduct)) {
			query.append("WHERE T_PRDT_CFGN.GE_COST_GRP IN ( 'Steam', 'Steam-Options') ");
		} else if ("Gen".equalsIgnoreCase(selProduct)) {
			query.append("WHERE T_PRDT_CFGN.GE_COST_GRP IN ( 'Gen', 'Gen-Options') ");
		} else if ("PLANT".equalsIgnoreCase(selProduct)) {
			query.append("WHERE T_PRDT_CFGN.GE_COST_GRP IN ( 'PLANT') ");
		} 
		
		if (prodManagementFlag && preliminaryFlag) {
			query.append("AND HW_PRDT.STATE  IN ('Product Management', 'Preliminary') ");
		} else if (prodManagementFlag) {
			query.append("AND HW_PRDT.STATE  IN ('Product Management') ");
		} else if (preliminaryFlag) {
			query.append("AND HW_PRDT.STATE  IN ('Preliminary') ");
		}
		
		if (!PLMUtils.isEmpty(selModel)) {
			query.append("AND MDL.MARKETING_NAME = '").append(selModel).append("'");
		}
		
		if (!PLMUtils.isEmptyList(selconfigOptions)) {
			query.append(" AND ("); 
			query.append(getStrBufferConsolidate(selconfigOptions, "CONFG_OPTN_NM"));//getStrBufferConsolidate(selconfigOptions, "CONFG_OPTN_NM"));
			query.append(") ");
		}
		
		query.append(PLMSearchQueries.GET_REQUIREMENTS_ORDER);
		LOG.info("Query to get Configuration Options Values >>>> " + query.toString());
		return getSimpleJdbcTemplate().query(query.toString(), new GetRequirementsMapper());
	}
	
	/**
	 * @return String objects.
	 */
	private static final class GetRequirementsMapper implements ParameterizedRowMapper<PLMMktModelRptData> {
		public PLMMktModelRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMMktModelRptData data = new PLMMktModelRptData();
			data.setModel(PLMUtils.checkNullVal(rs.getString("MODEL")));
			data.setCoName(PLMUtils.checkNullVal(rs.getString("CONFG_OPTN_NM")));
			data.setCoRev(PLMUtils.checkNullVal(rs.getString("CONFG_OPTN_REV")));
			data.setCoDesc(PLMUtils.checkNullVal(rs.getString("CONFG_OPTN_DESC")));
			data.setCoState(PLMUtils.checkNullVal(rs.getString("CONFG_OPTN_STATE")));
			data.setCoDisplayName(PLMUtils.checkNullVal(rs.getString("CO_DISPLAY_NAME")));
			data.setCoDisplayText(PLMUtils.checkNullVal(rs.getString("CO_DISPLAY_TEXT")));
			data.setReqType(PLMUtils.checkNullVal(rs.getString("REQ_TYPE")));
			data.setReqName(PLMUtils.checkNullVal(rs.getString("REQUIREMENT_NM")));
			data.setReqDesc(PLMUtils.checkNullVal(rs.getString("REQUIREMENT_DESC")));
			data.setReqRev(PLMUtils.checkNullVal(rs.getString("REQUIREMENT_REV")));
			data.setReqGeIndr(PLMUtils.checkNullVal(rs.getString("REQ_INDR")));
			data.setReqEstimatedCost(rs.getInt("REQ_ESTIMATED_COST"));
			return data;
		}
	}
	
	/**
	 * This method is used to getStrBufferConsolidate 
	 * @param list
	 * @param String
	 * @return StringBuffer
	 * @throws PLMCommonException
	 */
	public StringBuffer getStrBufferConsolidate(List<String> colList,String colName) throws PLMCommonException{
		LOG.info("Entering getStrBufferConsolidate() method.");
		StringBuffer sqlQuery =new StringBuffer();
		try{
			if(!PLMUtils.isEmptyList(colList)){
				int vtCntInt =0;
				int vtCntIncr=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				int vtCntLimit=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				int val = 0;
				int loopCount = 0;
				int partListCnt=colList.size();
				boolean vtFlag=false;
				
				if(partListCnt <=vtCntLimit){
					loopCount = 1;
				}else{
					loopCount = partListCnt/vtCntLimit;				
					val = partListCnt - (vtCntLimit * loopCount);
					  if (val > 0) {
						loopCount++;					
					   }
				}
				
				for (int i=0;i<loopCount;i++) {
					if(vtCntIncr > partListCnt){
						vtCntIncr=partListCnt;
					 }
					List <String> partNumListLcl = new ArrayList<String>();
					LOG.info("-------------------Loop Rotating from part list index "+vtCntInt +" and "+vtCntIncr);
					 for(int j=vtCntInt;j<vtCntIncr;j++){
						 partNumListLcl.add(colList.get(j));
					 }
					if(!vtFlag){
						sqlQuery.append(""+colName+" IN ("+PLMUtils.setListForQuery(partNumListLcl)+")");
						vtFlag =true;
					}else{
						sqlQuery.append(" OR "+colName+" IN ("+PLMUtils.setListForQuery(partNumListLcl)+")");
					}
					vtCntInt =vtCntIncr+1;
					if(vtCntIncr > partListCnt){
						vtCntIncr=partListCnt;
					 }else{
					  vtCntIncr =vtCntIncr+Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
					 }
				}
			}
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getStrBufferConsolidate() method.");
		return sqlQuery;
	}
	
	/**
	 * @param selProduct
	 * @param prodManagementFlag
	 * @param preliminaryFlag
	 * @return
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getProductLines(String selProduct, boolean prodManagementFlag, boolean preliminaryFlag) throws PLMCommonException {
		LOG.info("selProduct in DAO-------------> getProductLines "+selProduct);
		StringBuffer query = new StringBuffer();
		query.append(PLMSearchQueries.GET_PL_NAMES);
		
		if ("Gas".equalsIgnoreCase(selProduct)) {
			query.append("AND T_PRDT_CFGN.GE_COST_GRP IN ( 'Gas', 'Gas-Options') ");
		} else if ("Steam".equalsIgnoreCase(selProduct)) {
			query.append("AND T_PRDT_CFGN.GE_COST_GRP IN ( 'Steam', 'Steam-Options') ");
		} else if ("Gen".equalsIgnoreCase(selProduct)) {
			query.append("AND T_PRDT_CFGN.GE_COST_GRP IN ( 'Gen', 'Gen-Options') ");
		} else if ("PLANT".equalsIgnoreCase(selProduct)) {
			query.append("AND T_PRDT_CFGN.GE_COST_GRP IN ( 'PLANT') ");
		} 
		
		if (prodManagementFlag && preliminaryFlag) {
			query.append("AND T_HW_PRDT.STATE  IN ('Product Management', 'Preliminary') ");
		} else if (prodManagementFlag) {
			query.append("AND T_HW_PRDT.STATE  IN ('Product Management') ");
		} else if (preliminaryFlag) {
			query.append("AND T_HW_PRDT.STATE  IN ('Preliminary') ");
		}
		
		query.append(PLMSearchQueries.GET_PL_NAMES_GRP_ORDER);
		LOG.info("Query to get Product Line Values >>>> " + query.toString());
		return getSimpleJdbcTemplate().query(query.toString(), new GetProductLinesMapper());
	}
	
	/**
	 * @return String objects.
	 */
	private static final class GetProductLinesMapper implements ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			SelectItem productLineName = new SelectItem(rs.getString(PLMUtils.checkNullVal("PRODUCT_LINE")));
			return productLineName;
		}
	}
	
	/**
	 * @param selProduct
	 * @param selProductLine
	 * @param prodManagementFlag
	 * @param preliminaryFlag
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMMktModelRptData> getModelsAndHwPrdts(String selProduct, List<String> selProductLines, boolean prodManagementFlag, 
			boolean preliminaryFlag) throws PLMCommonException {
		LOG.info("selProductLines in DAO-------------> getModelsAndHwPrdts "+ selProductLines);
		StringBuffer query = new StringBuffer();
		query.append(PLMSearchQueries.GET_HP_NAMES);
		
		if ("Gas".equalsIgnoreCase(selProduct)) {
			query.append("AND T_PRDT_CFGN.GE_COST_GRP IN ( 'Gas', 'Gas-Options') ");
		} else if ("Steam".equalsIgnoreCase(selProduct)) {
			query.append("AND T_PRDT_CFGN.GE_COST_GRP IN ( 'Steam', 'Steam-Options') ");
		} else if ("Gen".equalsIgnoreCase(selProduct)) {
			query.append("AND T_PRDT_CFGN.GE_COST_GRP IN ( 'Gen', 'Gen-Options') ");
		} else if ("PLANT".equalsIgnoreCase(selProduct)) {
			query.append("AND T_PRDT_CFGN.GE_COST_GRP IN ( 'PLANT') ");
		} 
		
		if (prodManagementFlag && preliminaryFlag) {
			query.append("AND T_HW_PRDT.STATE  IN ('Product Management', 'Preliminary') ");
		} else if (prodManagementFlag) {
			query.append("AND T_HW_PRDT.STATE  IN ('Product Management') ");
		} else if (preliminaryFlag) {
			query.append("AND T_HW_PRDT.STATE  IN ('Preliminary') ");
		}
		
		if (!PLMUtils.isEmptyList(selProductLines)) {
			query.append(" AND ("); 
			query.append(getStrBufferConsolidate(selProductLines, "PRODUCT_LINE"));
			query.append(") ");
		}
		
		query.append(PLMSearchQueries.GET_HP_NAMES_GRP_ORDER);
		LOG.info("Query to get Configuration Options Values >>>> " + query.toString());
		return getSimpleJdbcTemplate().query(query.toString(), new GetModelsAndHwPrdtsMapper());
	}
	
	/**
	 * @return String objects.
	 */
	private static final class GetModelsAndHwPrdtsMapper implements ParameterizedRowMapper<PLMMktModelRptData> {
		public PLMMktModelRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMMktModelRptData data = new PLMMktModelRptData();
			data.setProductLineName(PLMUtils.checkNullVal(rs.getString("PRODUCT_LINE")));
			data.setModelName(PLMUtils.checkNullVal(rs.getString("MODEL")));
			data.setHardwareProductId(PLMUtils.checkNullVal(rs.getString("HP_ID")));
			data.setHardwareProductName(PLMUtils.checkNullVal(rs.getString("HP_NAME")));
			data.setHardwareProductRev(PLMUtils.checkNullVal(rs.getString("HP_REV")));
			data.setHardwareProductNmRev(PLMUtils.checkNullVal(rs.getString("HP_NAME")) + "~" + PLMUtils.checkNullVal(rs.getString("HP_REV")));
			return data;
		}
	}
}