package com.geinfra.geaviation.pwi.model;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : PWiTableauReportsVO - Object Type object.
 * 
 * Revision Log April 26, 2016 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiTableauReportsVO{
	
	private Integer id;
	private Integer vid;
	private String name;
	private String description;
	private String confServer;
	private String confReportName;
	private String params;
	private String site;
	
	public PWiTableauReportsVO(){
		//TO-DO if needed
	}
	
	public PWiTableauReportsVO(Integer id, String name, String description, String confServer, String confReportName, String params, String site, Integer vid){
		this.id = id;
		this.name = name;
		this.description = description;
		this.confServer = confServer;
		this.confReportName = confReportName;
		this.params = params;
		this.site = site;
		this.vid = vid;
	}
	
	public PWiTableauReportsVO(Integer id, String name, String description, String confServer, String confReportName, String params, String site){
		this.id = id;
		this.name = name;
		this.description = description;
		this.confServer = confServer;
		this.confReportName = confReportName;
		this.params = params;
		this.site = site;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getConfServer() {
		return confServer;
	}
	public void setConfServer(String confServer) {
		this.confServer = confServer;
	}
	public String getConfReportName() {
		return confReportName;
	}
	public void setConfReportName(String confReportName) {
		this.confReportName = confReportName;
	}
	public String getParams() {
		return params;
	}
	public void setParams(String params) {
		this.params = params;
	}
	public String getSite() {
		return site;
	}
	public void setSite(String site) {
		this.site = site;
	}
	public Integer getVid() {
		return vid;
	}
	public void setVid(Integer vid) {
		this.vid = vid;
	}
	
}
