package com.geinfra.geaviation.pwi.service.helpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.geinfra.geaviation.pwi.model.TemplateVO;
import com.geinfra.geaviation.pwi.service.vo.ExecutionMode;
import com.geinfra.geaviation.pwi.service.vo.OutputType;
import com.geinfra.geaviation.pwi.xml.query.ExecutionModeType;
import com.geinfra.geaviation.pwi.xml.query.ExecutionOutputOptionsType;
import com.geinfra.geaviation.pwi.xml.query.OutputTypeType;
import com.geinfra.geaviation.pwi.xml.query.QueryType;

/**
*
* Project      : Product Lifecycle Management Intelligence
* Date Written : September 23, 2011
* Security     : GE Confidential
* Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
* Copyright(C) 2013 GE All rights reserved
*
* Description :
*
* Revision Log September 23, 2011 | v1.0.
* --------------------------------------------------------------
*/
public class ExecutionOutputModelUtil {
	private static final ExecutionOutputModelUtil INSTANCE = new ExecutionOutputModelUtil();
	
	private ExecutionOutputModelUtil () {
		// nothing to do
		// private b/c singleton
	}
	
	public static ExecutionOutputModelUtil getInstance() {
		return INSTANCE;
	}
	
	public List<ExecutionOutputTuple> getAvailable(
			ExecutionOutputConfig config) {
		return config.getAvailable();
	}

	public Map<ExecutionMode, ExecutionOutputTuple> getDefaults(
			ExecutionOutputConfig config) {
		return config.getDefaults();
	}

	public ExecutionOutputTuple getInitial(ExecutionOutputConfig config,
			ExecutionOutputTuple eventTuple) {
		ExecutionOutputTuple initial = null;
		if (config.getAvailable().contains(eventTuple)) {
			initial = eventTuple;
		} else {
			initial = config.getInitial();
		}
		return initial;
	}

	public ExecutionOutputConfig getExecutionOutputConfig(
			ExecutionOutputConfig defaultConfig,
			ExecutionOutputConfig queryConfig) {
		ExecutionOutputConfig config = null;
		if (queryConfig != null) {
			config = queryConfig;
		} else {
			config = defaultConfig;
		}
		return config;
	}
	
	private void addAllOutputTypes(List<ExecutionOutputTuple> available,
			ExecutionMode mode, List<TemplateVO>templates, boolean tabbed) {
		if (!tabbed && ExecutionMode.ONLINE.equals(mode)) {
			// WEB is available only ONLINE, and when not tabbed
			available.add(new ExecutionOutputTuple(mode,
					OutputType.WEB, null));
		}
		
		// Only xlsx is available for tabbed queries
		available.add(new ExecutionOutputTuple(mode,
				OutputType.XLSX, null));
		
		if (!tabbed) {
			available.add(new ExecutionOutputTuple(mode,
					OutputType.XLS, null));
			available.add(new ExecutionOutputTuple(mode,
					OutputType.CSV, null));
			available.add(new ExecutionOutputTuple(mode,
					OutputType.PDF, null));
			available.add(new ExecutionOutputTuple(mode,
					OutputType.XML, null));
			// TODO pH 2012.10: when templates become available for XLSX and
			//                  tabbed queries, move templates to above XLSX
			if (templates != null) {
				for (TemplateVO template : templates) {
					available.add(new ExecutionOutputTuple(
							mode, OutputType.TEMPLATE, template));
				}
			}
		}
	}

	public ExecutionOutputConfig getDefaultConfig(
			List<TemplateVO> templates, boolean batchDisabled, boolean tabbed) {
		// Create available, defaults
		List<ExecutionOutputTuple> defaultAvailable =
				new ArrayList<ExecutionOutputTuple>();
		Map<ExecutionMode, ExecutionOutputTuple> defaultDefaults =
				new HashMap<ExecutionMode, ExecutionOutputTuple>();
		
		// add available types and set default for online mode
		addAllOutputTypes(defaultAvailable, ExecutionMode.ONLINE,
				templates, tabbed);
		defaultDefaults.put(ExecutionMode.ONLINE, defaultAvailable.get(0));

		if (!batchDisabled) {
			// add available types and set default for batch mode
			addAllOutputTypes(defaultAvailable, ExecutionMode.BATCH,
					templates, tabbed);
			addAllOutputTypes(defaultAvailable, ExecutionMode.SFTP,
					templates, tabbed);
			defaultDefaults.put(ExecutionMode.BATCH, new ExecutionOutputTuple(
					ExecutionMode.BATCH, OutputType.XLSX, null));
			defaultDefaults.put(ExecutionMode.SFTP, new ExecutionOutputTuple(
					ExecutionMode.SFTP, OutputType.XLSX, null));
		}

		// Create initial
		ExecutionOutputTuple defaultInitial = defaultAvailable.get(0);

		// Create default config
		ExecutionOutputConfig defaultConfig = new ExecutionOutputConfig(
				defaultAvailable, defaultDefaults, defaultInitial);

		return defaultConfig;
	}

	public ExecutionOutputConfig getQueryConfig(QueryType queryType,
			List<TemplateVO> templates) {
		List<ExecutionOutputTuple> available = new ArrayList<ExecutionOutputTuple>();
		Map<ExecutionMode, ExecutionOutputTuple> defaults = new HashMap<ExecutionMode, ExecutionOutputTuple>();

		ExecutionOutputOptionsType executionOutputOptionsType = queryType
				.getQuerydefinition().getExecutionoutputoptions();
		if (executionOutputOptionsType == null) {
			return null;
		}

		// Determine available and defaults
		for (ExecutionModeType executionModeType : executionOutputOptionsType
				.getExecutionmode()) {
			ExecutionMode executionMode = ExecutionMode
					.getById(executionModeType.getId());
			if (executionMode == null) {
				// Ignore invalid execution modes
				continue;
			}
			boolean assignedDefaultOutputType = false;
			for (OutputTypeType outputTypeType : executionModeType
					.getOutputtype()) {
				OutputType outputType = OutputType.getById(outputTypeType
						.getId());
				if (outputType == null) {
					// Ignore invalid output types
					continue;
				}

				if (OutputType.TEMPLATE.equals(outputType)) {
					// Add entry for each template
					if (templates != null) {
						for (TemplateVO template : templates) {
							ExecutionOutputTuple tuple = new ExecutionOutputTuple(
									executionMode, outputType, template);
							available.add(tuple);
							if (!assignedDefaultOutputType) {
								defaults.put(executionMode, tuple);
								assignedDefaultOutputType = true;
							}
						}
					}
				} else {
					// Add entry for output type
					ExecutionOutputTuple tuple = new ExecutionOutputTuple(
							executionMode, outputType, null);
					available.add(tuple);
					if (!assignedDefaultOutputType) {
						defaults.put(executionMode, tuple);
						assignedDefaultOutputType = true;
					}
				}
			}
		}

		// Return null if no available were found
		if (available.size() == 0) {
			return null;
		}

		// Determine initial
		ExecutionMode defaultExecutionMode = available.get(0)
				.getExecutionMode();
		ExecutionOutputTuple initial = defaults.get(defaultExecutionMode);

		return new ExecutionOutputConfig(available, defaults, initial);
	}
}
