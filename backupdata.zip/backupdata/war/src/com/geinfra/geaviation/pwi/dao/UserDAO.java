package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.model.PWiUserVO;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 5, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Data access object for object types.
 * 
 * Revision Log Aug 5, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public interface UserDAO {
	/**
	 * Used in Quick Intelligence and click-through menus
	 * @return all PWi Object Types for
	 */
	

	public List<PWiUserVO> findAllPWiUsers();

	/**
	 * Used to administrate default QI options
	 * 
	 * @return all PWi Object Types visible in Quick Intelligence 
	 */
	public List<PWiUserVO> findPWiQiUsers();

	/**
	 * @param map the current user's groups
	 * @return list of object types relevant in the specified groups
	 */
	

	public PWiUserVO getUserById(Integer userId);
	
	/**
	 * Used to administrate Object Type visibility
	 * 
	 * @return all PLMi object types, including a string list of relevant groups
	 */
	public List<PWiUserVO> findUsersforSelectedGroups(String availableQueryGroupList);
	
	/**
	 * Checks whether name or description is being used by another object type
	 * 
	 * @param objTypNm
	 * @param objTypDesc
	 * @param objTypSeqId
	 * @return the number of object types, besides this one, using the same name
	 * 		or description
	 */
	public int checkNamesEdit(String userNm, String userLastname, String email,Integer userId ,String SSO);

	public int checkNames(String firstName,String userLastname, String email,String SSO);

	public int createNewUser(final String sso,final String firstName,final String lastName,
			final String email,final boolean enabled,final List<String> selectedRoleNms,final String emailNotification); 
			
	
	public void updateUser(PWiUserVO user, String userId);

	public List<PWiUserVO> getUsersFromSelectedGroups(
			List<PWiQueryGroupVO> selectedQueryGroupsList);
	
	public PWiUserVO getUserInfoForSSO(String ssoId) throws PLMCommonException;
	
	//Newly Added for getting Roles
	public List<PWiUserVO> getUsersFromSelectedGroups()throws PLMCommonException;
		
	public List<PWiUserVO> searchUser(String searchSso, String searchFname,
			String searchLname, String roleId, String status)throws PLMCommonException;

}