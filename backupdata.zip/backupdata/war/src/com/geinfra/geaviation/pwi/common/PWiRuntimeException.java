/**
 * Project        :	  PWi Development
 * Date Written   :   May 2010
 * Security       :   GE Confidential
 * Restrictions   :   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 * Copyright(C) 2009 GE 
 * All rights reserved
 *
 * Description    :  This is Exception Class to catch the Exceptions.
 *
 * --------------------------------------------------------------
 */

package com.geinfra.geaviation.pwi.common;

/**
 * Project : Product Lifecycle Management Date Written : May 18, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : PWiException - Handles all Overhaul exceptions.
 * 
 * Revision Log May 18, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiRuntimeException extends RuntimeException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The error message. */
	private String errorMessage = "";

	/**
	 * The Constructor.
	 * 
	 * @param exception
	 *            the exception
	 * @param errorMessage
	 *            the error message
	 */
	public PWiRuntimeException(Exception exception, String errorMessage) {
		super(exception);
		this.errorMessage = errorMessage;
	}

	/**
	 * The Constructor.
	 * 
	 * @param errorMessage
	 *            the error message
	 */
	public PWiRuntimeException(String errorMessage) {
		super(errorMessage);
		this.errorMessage = errorMessage;
	}

	/**
	 * The Constructor.
	 * 
	 * @param exception
	 *            the exception
	 */
	public PWiRuntimeException(Exception exception) {
		super(exception);
	}

	/**
	 * Gets the error message.
	 * 
	 * @return Returns the errorMessage.
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * Sets the error message.
	 * 
	 * @param errorMessage
	 *            The errorMessage to set.
	 */
	public void setErrorMessage(final String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * To string.
	 * 
	 * @return Appends the actual exception message and custom message and
	 *         returns it.
	 */
	public String toString() {
		return "Exception : " + super.toString() + ", ErrorMessage - "
				+ getErrorMessage();
	}

}
