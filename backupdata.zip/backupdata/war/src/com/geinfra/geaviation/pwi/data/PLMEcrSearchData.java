/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEcrSearchData.java
 * @Creation date: 16-Feb-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.data;

import java.util.Date;
import java.util.List;

public class PLMEcrSearchData {
	/**
	  * Holds the ecrName
	  */
	private String ecrName;
	/**
	  * Holds the ecrRevision
	  */
	private String ecrRevision;
	/**
	  * Holds the ecrOwner
	  */
	private String ecrOwner;
	/**
	  * Holds the ecrOwnerName
	  */
	private String ecrOwnerName;
	/**
	  * Holds the ecrOriginator
	  */
	private String ecrOriginator;
	/**
	  * Holds the ecrOriginatorName
	  */
	private String ecrOriginatorName;
	/**
	  * Holds the ecrSev
	  */
	private String ecrSev;
	/**
	  * Holds the ecrSevList
	  */
	private List<String> ecrSevList;
	/**
	  * Holds the ecrSevExcel
	  */
	private String ecrSevExcel;
	/**
	  * Holds the ecrState
	  */
	private String ecrState;
	/**
	  * Holds the allOpen
	  */
	private boolean allOpen;
	/**
	  * Holds the ecrStateList
	  */
	private List<String> ecrStateList;
	/**
	  * Holds the ecrStateExcel
	  */
	private String ecrStateExcel;
	/**
	  * Holds the ecrCategChng
	  */
	private String ecrCategChng;
	/**
	  * Holds the ecrCategChngList
	  */
	private List<String> ecrCategChngList;
	/**
	  * Holds the ecrCategChngExcel
	  */
	private String ecrCategChngExcel;
	/**
	  * Holds the fromecrStrtDate
	  */
	private Date fromecrStrtDate;
	/**
	  * Holds the toecrEndDate
	  */
	private Date toecrEndDate;
	/**
	  * Holds the designEngr
	  */
	private String designEngr;
	/**
	  * Holds the againsttype
	  */
	private String againsttype;
	/**
	  * Holds the ecrdesc
	  */
	private String ecrdesc;
	/**
	  * Holds the ecrevaluator
	  */
	private String ecrevaluator;
	/**
	  * Holds the ecostartdate
	  */
	private String ecostartdate;
	/**
	  * Holds the ecocount
	  */
	private String ecocount;
	/**
	  * Holds the reportedagnt
	  */
	private String reportedagnt;
	/**
	  * Holds the resdesigneng
	  */
	private String resdesigneng;
	/**
	  * Holds the resdesignengName
	  */
	private String resdesignengName;
	/**
	  * Holds the ECRLastUpdate
	  */
	private String ECRLastUpdate;
	/**
	  * Holds the reasonforchange
	  */
	private String reasonforchange;
	/**
	  * Holds the reasonforcancel
	  */
	private String reasonforcancel;
	/**
	  * Holds the generaldescrchange
	  */
	private String generaldescrchange;
	/**
	  * Holds the ageindays
	  */
	private String ageindays;
	/**
	  * Holds the GEChangeDeadline
	  */
	private String GEChangeDeadline;
	/**
	  * Holds the ISDeviation
	  */
	private String ISDeviation;
	/**
	  * Holds the reviewerscomments
	  */
	private String reviewerscomments;
	/**
	  * Holds the ecoName
	  */
	private String ecoName;
	/**
	  * Holds the ECODescription
	  */
	private String ECODescription;
	/**
	  * Holds the ecoOwner
	  */
	private String ecoOwner;
	/**
	  * Holds the ecoOwnerName
	  */
	private String ecoOwnerName;
	/**
	  * Holds the ecoState
	  */
	private String ecoState;
	/**
	  * Holds the ccbchair
	  */
	private String ccbchair;
	/**
	  * Holds the ccbChairmanName
	  */
	private String ccbChairmanName;
	/**
	  * Holds the ecrLastUpdateExl
	  */
	private Date ecrLastUpdateExl;
	
	//Newly Added for Affected Items
	/**
	  * Holds the affctdItmId
	  */
	private String affctdItmId;
	/**
	  * Holds the affctdItmName
	  */
	private String affctdItmName;
	/**
	  * Holds the affctdItmType
	  */
	private String affctdItmType;
	/**
	  * Holds the affctdItmState
	  */
	private String affctdItmState;
	/**
	  * Holds the partItmId
	  */
	private String partItmId;
	/**
	  * Holds the partItmName
	  */
	private String partItmName;
	/**
	  * Holds the partItmType
	  */
	private String partItmType;
	/**
	  * Holds the partItmState
	  */
	private String partItmState;
	
	private String partItmRev;

	/**
	  * Holds the whereUsdItmId
	  */
	private String whereUsdItmId;
	/**
	  * Holds the whereUsdItmName
	  */
	private String whereUsdItmName;
	/**
	  * Holds the whereUsdItmType
	  */
	private String whereUsdItmType;
	/**
	  * Holds the whereUsdItmState
	  */
	private String whereUsdItmState;
	
	private String whereUsdItmRev;
		
	/**
	  * Holds the ecrLevel
	  */
	private String ecrLevel;
	/**
	  * Holds the affectedItemId
	  */
	private String affectedItemId;
	/**
	  * Holds the affectedItemName
	  */
	private String affectedItemName;
	/**
	  * Holds the affectedforceRevId
	  */
	private String affectedforceRevId;

	/**
	  * Holds the affectedforceRev
	  */
	private String affectedforceRev;
	/**
	  * Holds the whereUsedId
	  */
	private String whereUsedId;
	/**
	  * Holds the whereUsedName
	  */
	private String whereUsedName;
	/**
	  * Holds the type
	  */
	private String type;
	/**
	  * Holds the state
	  */
	private String state;
	
	/**
	  * Holds the selEcrName
	  */
	private String selEcrName;

	private String revision;
	
	private boolean partInOtherEcr;
	
	private String partInOtherEcrStr;


	/**
	 * @return the ecrName
	 */
	public String getEcrName() {
		return ecrName;
	}

	/**
	 * @param ecrName
	 *            the ecrName to set
	 */
	public void setEcrName(String ecrName) {
		this.ecrName = ecrName;
	}

	/**
	 * @return the ecrRevision
	 */
	public String getEcrRevision() {
		return ecrRevision;
	}

	/**
	 * @param ecrRevision
	 *            the ecrRevision to set
	 */
	public void setEcrRevision(String ecrRevision) {
		this.ecrRevision = ecrRevision;
	}

	/**
	 * @return the ecrOwner
	 */
	public String getEcrOwner() {
		return ecrOwner;
	}

	/**
	 * @param ecrOwner
	 *            the ecrOwner to set
	 */
	public void setEcrOwner(String ecrOwner) {
		this.ecrOwner = ecrOwner;
	}

	/**
	 * @return the ecrOriginator
	 */
	public String getEcrOriginator() {
		return ecrOriginator;
	}

	/**
	 * @param ecrOriginator
	 *            the ecrOriginator to set
	 */
	public void setEcrOriginator(String ecrOriginator) {
		this.ecrOriginator = ecrOriginator;
	}

	/**
	 * @return the ecrSev
	 */
	public String getEcrSev() {
		return ecrSev;
	}

	/**
	 * @param ecrSev
	 *            the ecrSev to set
	 */
	public void setEcrSev(String ecrSev) {
		this.ecrSev = ecrSev;
	}

	/**
	 * @return the ecrSevList
	 */
	public List<String> getEcrSevList() {
		return ecrSevList;
	}

	/**
	 * @param ecrSevList the ecrSevList to set
	 */
	public void setEcrSevList(List<String> ecrSevList) {
		this.ecrSevList = ecrSevList;
	}

	/**
	 * @return the ecrSevExcel
	 */
	public String getEcrSevExcel() {
		return ecrSevExcel;
	}

	/**
	 * @param ecrSevExcel the ecrSevExcel to set
	 */
	public void setEcrSevExcel(String ecrSevExcel) {
		this.ecrSevExcel = ecrSevExcel;
	}

	/**
	 * @return the ecrState
	 */
	public String getEcrState() {
		return ecrState;
	}

	/**
	 * @param ecrState
	 *            the ecrState to set
	 */
	public void setEcrState(String ecrState) {
		this.ecrState = ecrState;
	}

	/**
	 * @return the ecrCategChngList
	 */
	public List<String> getEcrCategChngList() {
		return ecrCategChngList;
	}

	/**
	 * @param ecrCategChngList the ecrCategChngList to set
	 */
	public void setEcrCategChngList(List<String> ecrCategChngList) {
		this.ecrCategChngList = ecrCategChngList;
	}

	/**
	 * @return the ecrCategChngExcel
	 */
	public String getEcrCategChngExcel() {
		return ecrCategChngExcel;
	}

	/**
	 * @param ecrCategChngExcel the ecrCategChngExcel to set
	 */
	public void setEcrCategChngExcel(String ecrCategChngExcel) {
		this.ecrCategChngExcel = ecrCategChngExcel;
	}

	/**
	 * @return the ecrStateList
	 */
	public List<String> getEcrStateList() {
		return ecrStateList;
	}

	/**
	 * @param ecrStateList the ecrStateList to set
	 */
	public void setEcrStateList(List<String> ecrStateList) {
		this.ecrStateList = ecrStateList;
	}

	/**
	 * @return the ecrStateExcel
	 */
	public String getEcrStateExcel() {
		return ecrStateExcel;
	}

	/**
	 * @param ecrStateExcel the ecrStateExcel to set
	 */
	public void setEcrStateExcel(String ecrStateExcel) {
		this.ecrStateExcel = ecrStateExcel;
	}

	/**
	 * @return the ecrCategChng
	 */
	public String getEcrCategChng() {
		return ecrCategChng;
	}

	/**
	 * @param ecrCategChng
	 *            the ecrCategChng to set
	 */
	public void setEcrCategChng(String ecrCategChng) {
		this.ecrCategChng = ecrCategChng;
	}

	/**
	 * @return the fromecrStrtDate
	 */
	public Date getFromecrStrtDate() {
		Date temp = null;
		temp = fromecrStrtDate;
		return temp;
	}

	/**
	 * @param fromecrStrtDate
	 *            the fromecrStrtDate to set
	 */
	public void setFromecrStrtDate(Date fromecrStrtDate) {
		if(fromecrStrtDate!=null){
		 this.fromecrStrtDate = (Date)fromecrStrtDate.clone();
		}else{
		 this.fromecrStrtDate=null;
		}
	}

	/**
	 * @return the toecrEndDate
	 */
	public Date getToecrEndDate() {
		Date temp = null;
		temp = toecrEndDate;
		return temp;
	}

	/**
	 * @param toecrStrtDate
	 *            the toecrStrtDate to set
	 */
	public void setToecrEndDate(Date toecrEndDate) {
		if(toecrEndDate!=null){
		 this.toecrEndDate = (Date)toecrEndDate.clone();
		}else{
		 this.toecrEndDate =null;
		}
	}

	/**
	 * @return the designEngr
	 */
	public String getDesignEngr() {
		return designEngr;
	}

	/**
	 * @param designEngr
	 *            the designEngr to set
	 */
	public void setDesignEngr(String designEngr) {
		this.designEngr = designEngr;
	}

	/**
	 * @return the againsttype
	 */
	public String getAgainsttype() {
		return againsttype;
	}

	/**
	 * @param againsttype
	 *            the againsttype to set
	 */
	public void setAgainsttype(String againsttype) {
		this.againsttype = againsttype;
	}

	/**
	 * @return the ecrdesc
	 */
	public String getEcrdesc() {
		return ecrdesc;
	}

	/**
	 * @param ecrdesc
	 *            the ecrdesc to set
	 */
	public void setEcrdesc(String ecrdesc) {
		this.ecrdesc = ecrdesc;
	}

	/**
	 * @return the ecrevaluator
	 */
	public String getEcrevaluator() {
		return ecrevaluator;
	}

	/**
	 * @param ecrevaluator
	 *            the ecrevaluator to set
	 */
	public void setEcrevaluator(String ecrevaluator) {
		this.ecrevaluator = ecrevaluator;
	}

	/**
	 * @return the ecostartdate
	 */
	public String getEcostartdate() {
		return ecostartdate;
	}

	/**
	 * @param ecostartdate
	 *            the ecostartdate to set
	 */
	public void setEcostartdate(String ecostartdate) {
		this.ecostartdate = ecostartdate;
	}

	/**
	 * @return the ecocount
	 */
	public String getEcocount() {
		return ecocount;
	}

	/**
	 * @param ecocount
	 *            the ecocount to set
	 */
	public void setEcocount(String ecocount) {
		this.ecocount = ecocount;
	}

	/**
	 * @return the reportedagnt
	 */
	public String getReportedagnt() {
		return reportedagnt;
	}

	/**
	 * @param reportedagnt
	 *            the reportedagnt to set
	 */
	public void setReportedagnt(String reportedagnt) {
		this.reportedagnt = reportedagnt;
	}

	/**
	 * @return the resdesigneng
	 */
	public String getResdesigneng() {
		return resdesigneng;
	}

	/**
	 * @param resdesigneng
	 *            the resdesigneng to set
	 */
	public void setResdesigneng(String resdesigneng) {
		this.resdesigneng = resdesigneng;
	}

	/**
	 * @return the eCRLastUpdate
	 */
	public String getECRLastUpdate() {
		return ECRLastUpdate;
	}

	/**
	 * @param lastUpdate
	 *            the eCRLastUpdate to set
	 */
	public void setECRLastUpdate(String lastUpdate) {
		ECRLastUpdate = lastUpdate;
	}

	

	/**
	 * @return the reasonforchange
	 */
	public String getReasonforchange() {
		return reasonforchange;
	}

	/**
	 * @param reasonforchange the reasonforchange to set
	 */
	public void setReasonforchange(String reasonforchange) {
		this.reasonforchange = reasonforchange;
	}

	/**
	 * @return the reasonforcancel
	 */
	public String getReasonforcancel() {
		return reasonforcancel;
	}

	/**
	 * @param reasonforcancel the reasonforcancel to set
	 */
	public void setReasonforcancel(String reasonforcancel) {
		this.reasonforcancel = reasonforcancel;
	}

	/**
	 * @return the generaldescrchange
	 */
	public String getGeneraldescrchange() {
		return generaldescrchange;
	}

	/**
	 * @param generaldescrchange the generaldescrchange to set
	 */
	public void setGeneraldescrchange(String generaldescrchange) {
		this.generaldescrchange = generaldescrchange;
	}

	/**
	 * @return the ageindays
	 */
	public String getAgeindays() {
		return ageindays;
	}

	/**
	 * @param ageindays the ageindays to set
	 */
	public void setAgeindays(String ageindays) {
		this.ageindays = ageindays;
	}

	/**
	 * @return the gEChangeDeadline
	 */
	public String getGEChangeDeadline() {
		return GEChangeDeadline;
	}

	/**
	 * @param changeDeadline
	 *            the gEChangeDeadline to set
	 */
	public void setGEChangeDeadline(String changeDeadline) {
		GEChangeDeadline = changeDeadline;
	}

	/**
	 * @return the iSDeviation
	 */
	public String getISDeviation() {
		return ISDeviation;
	}

	/**
	 * @param deviation
	 *            the iSDeviation to set
	 */
	public void setISDeviation(String deviation) {
		ISDeviation = deviation;
	}

	

	/**
	 * @return the reviewerscomments
	 */
	public String getReviewerscomments() {
		return reviewerscomments;
	}

	/**
	 * @param reviewerscomments the reviewerscomments to set
	 */
	public void setReviewerscomments(String reviewerscomments) {
		this.reviewerscomments = reviewerscomments;
	}

	/**
	 * @return the ecoName
	 */
	public String getEcoName() {
		return ecoName;
	}

	/**
	 * @param name
	 *            the eCOName to set
	 */
	public void setEcoName(String name) {
		ecoName = name;
	}

	/**
	 * @return the eCODescription
	 */
	public String getECODescription() {
		return ECODescription;
	}

	/**
	 * @param description
	 *            the eCODescription to set
	 */
	public void setECODescription(String description) {
		ECODescription = description;
	}

	/**
	 * @return the ecoOwner
	 */
	public String getEcoOwner() {
		return ecoOwner;
	}

	/**
	 * @param owner
	 *            the eCOOwner to set
	 */
	public void setEcoOwner(String owner) {
		ecoOwner = owner;
	}

	/**
	 * @return the ecoState
	 */
	public String getEcoState() {
		return ecoState;
	}

	/**
	 * @param state
	 *            the eCOState to set
	 */
	public void setEcoState(String state) {
		ecoState = state;
	}

	/**
	 * @return the ccbchair
	 */
	public String getCcbchair() {
		return ccbchair;
	}

	/**
	 * @param ccbchair
	 *            the ccbchair to set
	 */
	public void setCcbchair(String ccbchair) {
		this.ccbchair = ccbchair;
	}

	/**
	 * @return the allOpen
	 */
	public boolean isAllOpen() {
		return allOpen;
	}

	/**
	 * @param allOpen the allOpen to set
	 */
	public void setAllOpen(boolean allOpen) {
		this.allOpen = allOpen;
	}

	/**
	 * @return the ecrOwnerName
	 */
	public String getEcrOwnerName() {
		return ecrOwnerName;
	}

	/**
	 * @param ecrOwnerName the ecrOwnerName to set
	 */
	public void setEcrOwnerName(String ecrOwnerName) {
		this.ecrOwnerName = ecrOwnerName;
	}

	/**
	 * @return the ecrOriginatorName
	 */
	public String getEcrOriginatorName() {
		return ecrOriginatorName;
	}

	/**
	 * @param ecrOriginatorName the ecrOriginatorName to set
	 */
	public void setEcrOriginatorName(String ecrOriginatorName) {
		this.ecrOriginatorName = ecrOriginatorName;
	}

	/**
	 * @return the ecoOwnerName
	 */
	public String getEcoOwnerName() {
		return ecoOwnerName;
	}

	/**
	 * @param ecoOwnerName the ecoOwnerName to set
	 */
	public void setEcoOwnerName(String ecoOwnerName) {
		this.ecoOwnerName = ecoOwnerName;
	}

	/**
	 * @return the ccbChairmanName
	 */
	public String getCcbChairmanName() {
		return ccbChairmanName;
	}

	/**
	 * @param ccbChairmanName the ccbChairmanName to set
	 */
	public void setCcbChairmanName(String ccbChairmanName) {
		this.ccbChairmanName = ccbChairmanName;
	}

	/**
	 * @return the resdesignengName
	 */
	public String getResdesignengName() {
		return resdesignengName;
	}

	/**
	 * @param resdesignengName the resdesignengName to set
	 */
	public void setResdesignengName(String resdesignengName) {
		this.resdesignengName = resdesignengName;
	}

	/**
	 * @return the ecrLastUpdateExl
	 */
	public Date getEcrLastUpdateExl() {
		Date temp = null;
		temp = ecrLastUpdateExl;
		return temp;
	}

	/**
	 * @param ecrLastUpdateExl the ecrLastUpdateExl to set
	 */
	public void setEcrLastUpdateExl(Date ecrLastUpdateExl) {
		Date temp = null;
		temp = ecrLastUpdateExl;
		this.ecrLastUpdateExl = temp;
	}

	/**
	 * @return the affctdItmId
	 */
	public String getAffctdItmId() {
		return affctdItmId;
	}

	/**
	 * @param affctdItmId the affctdItmId to set
	 */
	public void setAffctdItmId(String affctdItmId) {
		this.affctdItmId = affctdItmId;
	}

	/**
	 * @return the affctdItmName
	 */
	public String getAffctdItmName() {
		return affctdItmName;
	}

	/**
	 * @param affctdItmName the affctdItmName to set
	 */
	public void setAffctdItmName(String affctdItmName) {
		this.affctdItmName = affctdItmName;
	}

	/**
	 * @return the affctdItmType
	 */
	public String getAffctdItmType() {
		return affctdItmType;
	}

	/**
	 * @param affctdItmType the affctdItmType to set
	 */
	public void setAffctdItmType(String affctdItmType) {
		this.affctdItmType = affctdItmType;
	}

	/**
	 * @return the affctdItmState
	 */
	public String getAffctdItmState() {
		return affctdItmState;
	}

	/**
	 * @param affctdItmState the affctdItmState to set
	 */
	public void setAffctdItmState(String affctdItmState) {
		this.affctdItmState = affctdItmState;
	}

	/**
	 * @return the partItmId
	 */
	public String getPartItmId() {
		return partItmId;
	}

	/**
	 * @param partItmId the partItmId to set
	 */
	public void setPartItmId(String partItmId) {
		this.partItmId = partItmId;
	}

	/**
	 * @return the partItmName
	 */
	public String getPartItmName() {
		return partItmName;
	}

	/**
	 * @param partItmName the partItmName to set
	 */
	public void setPartItmName(String partItmName) {
		this.partItmName = partItmName;
	}

	/**
	 * @return the partItmType
	 */
	public String getPartItmType() {
		return partItmType;
	}

	/**
	 * @param partItmType the partItmType to set
	 */
	public void setPartItmType(String partItmType) {
		this.partItmType = partItmType;
	}

	/**
	 * @return the partItmState
	 */
	public String getPartItmState() {
		return partItmState;
	}

	/**
	 * @param partItmState the partItmState to set
	 */
	public void setPartItmState(String partItmState) {
		this.partItmState = partItmState;
	}

	/**
	 * @return the whereUsdItmId
	 */
	public String getWhereUsdItmId() {
		return whereUsdItmId;
	}

	/**
	 * @param whereUsdItmId the whereUsdItmId to set
	 */
	public void setWhereUsdItmId(String whereUsdItmId) {
		this.whereUsdItmId = whereUsdItmId;
	}

	/**
	 * @return the whereUsdItmName
	 */
	public String getWhereUsdItmName() {
		return whereUsdItmName;
	}

	/**
	 * @param whereUsdItmName the whereUsdItmName to set
	 */
	public void setWhereUsdItmName(String whereUsdItmName) {
		this.whereUsdItmName = whereUsdItmName;
	}

	/**
	 * @return the whereUsdItmType
	 */
	public String getWhereUsdItmType() {
		return whereUsdItmType;
	}

	/**
	 * @param whereUsdItmType the whereUsdItmType to set
	 */
	public void setWhereUsdItmType(String whereUsdItmType) {
		this.whereUsdItmType = whereUsdItmType;
	}

	/**
	 * @return the whereUsdItmState
	 */
	public String getWhereUsdItmState() {
		return whereUsdItmState;
	}

	/**
	 * @param whereUsdItmState the whereUsdItmState to set
	 */
	public void setWhereUsdItmState(String whereUsdItmState) {
		this.whereUsdItmState = whereUsdItmState;
	}

	/**
	 * @return the ecrLevel
	 */
	public String getEcrLevel() {
		return ecrLevel;
	}

	/**
	 * @param ecrLevel the ecrLevel to set
	 */
	public void setEcrLevel(String ecrLevel) {
		this.ecrLevel = ecrLevel;
	}

	/**
	 * @return the affectedItemId
	 */
	public String getAffectedItemId() {
		return affectedItemId;
	}

	/**
	 * @param affectedItemId the affectedItemId to set
	 */
	public void setAffectedItemId(String affectedItemId) {
		this.affectedItemId = affectedItemId;
	}

	/**
	 * @return the affectedItemName
	 */
	public String getAffectedItemName() {
		return affectedItemName;
	}

	/**
	 * @param affectedItemName the affectedItemName to set
	 */
	public void setAffectedItemName(String affectedItemName) {
		this.affectedItemName = affectedItemName;
	}

	/**
	 * @return the affectedforceRevId
	 */
	public String getAffectedforceRevId() {
		return affectedforceRevId;
	}

	/**
	 * @param affectedforceRevId the affectedforceRevId to set
	 */
	public void setAffectedforceRevId(String affectedforceRevId) {
		this.affectedforceRevId = affectedforceRevId;
	}

	/**
	 * @return the affectedforceRev
	 */
	public String getAffectedforceRev() {
		return affectedforceRev;
	}

	/**
	 * @param affectedforceRev the affectedforceRev to set
	 */
	public void setAffectedforceRev(String affectedforceRev) {
		this.affectedforceRev = affectedforceRev;
	}

	/**
	 * @return the whereUsedId
	 */
	public String getWhereUsedId() {
		return whereUsedId;
	}

	/**
	 * @param whereUsedId the whereUsedId to set
	 */
	public void setWhereUsedId(String whereUsedId) {
		this.whereUsedId = whereUsedId;
	}

	/**
	 * @return the whereUsedName
	 */
	public String getWhereUsedName() {
		return whereUsedName;
	}

	/**
	 * @param whereUsedName the whereUsedName to set
	 */
	public void setWhereUsedName(String whereUsedName) {
		this.whereUsedName = whereUsedName;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the selEcrName
	 */
	public String getSelEcrName() {
		return selEcrName;
	}

	/**
	 * @param selEcrName the selEcrName to set
	 */
	public void setSelEcrName(String selEcrName) {
		this.selEcrName = selEcrName;
	}

	public String getPartItmRev() {
		return partItmRev;
	}

	public void setPartItmRev(String partItmRev) {
		this.partItmRev = partItmRev;
	}

	public String getRevision() {
		return revision;
	}

	public void setRevision(String revision) {
		this.revision = revision;
	}

	public String getWhereUsdItmRev() {
		return whereUsdItmRev;
	}

	public void setWhereUsdItmRev(String whereUsdItmRev) {
		this.whereUsdItmRev = whereUsdItmRev;
	}

	public boolean isPartInOtherEcr() {
		return partInOtherEcr;
	}

	public void setPartInOtherEcr(boolean partInOtherEcr) {
		this.partInOtherEcr = partInOtherEcr;
	}

	public String getPartInOtherEcrStr() {
		return partInOtherEcrStr;
	}

	public void setPartInOtherEcrStr(String partInOtherEcrStr) {
		this.partInOtherEcrStr = partInOtherEcrStr;
	}

	
	
}
