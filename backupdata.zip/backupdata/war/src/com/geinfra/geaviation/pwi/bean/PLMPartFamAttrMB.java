/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMPartFamAttrMB.java
 * @Creation date: 21-Sept-2015
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Scanner;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMInterfaceAttrData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMPartFamAttrServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMPartFamAttrMB {

	/**
	 * Holds the Loggger
	 */
	private static final Logger LOG = Logger
			.getLogger(PLMInterfaceAttrMB.class);
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;

	/**
	 * Holds the plmPartFamAttrService
	 */
	private PLMPartFamAttrServiceIfc plmPartFamAttrService = null;
	
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage = "";
	/**
	 * Holds the partFamilyIntAttrData
	 */
	private PLMInterfaceAttrData partFamilyIntAttrData = null;
	/**
	 * Holds the contractDDList
	 */
	private List<SelectItem> partFamilyDDList = new ArrayList<SelectItem>();
	/**
	 * Holds the contractDDList
	 */
	private List<SelectItem> attributeNameDDList = new ArrayList<SelectItem>();
	/**
	 * Holds the dropDownMapList
	 */
	private Map<String, List<SelectItem>> dropDownMapList = new HashMap<String, List<SelectItem>>();
	/**
	 * Holds the resultList
	 */
	private List<PLMInterfaceAttrData> resultList = null;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = 50;
	/**
	 * Holds the resultListCount
	 */
	private int resultListCount = 0;
	/**
	 * Holds the resultListCountMsg
	 */
	private String resultListCountMsg = "";
	
	private List<String> resultListForAttribute = null;
	
	private PLMPwiUserData userDetails = null;
	
	private ThreadPoolTaskExecutor taskExecutor = null;
	
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the optionType
	 */
	private String optionType;
	/**
	 * Holds the hyperLinkFlag
	 */
	private boolean hyperLinkFlag;
	/**
	 * Holds the partAttribFlag
	 */
	private boolean partAttribFlag;
	/**
	 * Holds the partFamilyAttribFlag
	 */
	private boolean partFamilyAttribFlag;
	
	/**
	 * This method is used for Loading GBOM Page
	 * 
	 * @return String
	 */
	public String loadPartFamilyAttrSearchPage() {
		LOG.info("Entering loadpartFamilyAttrMastrSearchPage Method");
		
		try {
			commonMB.insertCannedRptRecordHitInfo("Part Family Attribute Master");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		partFamilyDDList = new ArrayList<SelectItem>();
		attributeNameDDList = new ArrayList<SelectItem>();
		partFamilyIntAttrData = new PLMInterfaceAttrData();
		alertMessage ="";
		optionType ="All Parts";
		hyperLinkFlag=true;
		partAttribFlag=true;
		partFamilyAttribFlag=true;
		try {
			// resetPartFamilyIntAttrValues();

			SelectItem stdText = new SelectItem("stdTxt",
					"Please select Part Family to see corresponding Attribute Names");
			attributeNameDDList.add(stdText);

			dropDownMapList = plmPartFamAttrService.getPartFamilyDropDownData();
			LOG.info("dropDownMapList fetched to MB with size =="
					+ dropDownMapList.size());

			partFamilyDDList = (List<SelectItem>) dropDownMapList
					.get("partFamilyDDList");
			LOG.info("partFamilyDDList fetched to MB with size =="
					+ partFamilyDDList.size());

			Collections
					.sort(partFamilyDDList, new PLMUtils.SortListSelItmLbl());

		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@loadGBomReportSearchPage:",
					exception);
		}
		LOG.info("Exiting loadpartFamilyAttrMastrSearchPage Method");
		return "partFamilyAttrMastrSearch";
	}

	/**
	 * This method is used for resetGBomValues
	 * 
	 * 
	 */
	public void resetPartFamilyIntAttrValues() {
		LOG.info("Entering resetPartFamilyIntAttrValues Method");
		partFamilyIntAttrData.setSelectedPartFamily("");
		partFamilyIntAttrData.setSelectedAttributeName("");
		partFamilyDDList.clear();
		alertMessage ="";
		LOG.info("Exiting resetPartFamilyIntAttrValues Method");
	}

	/**
	 * This method is used for valueChangeMMName
	 * 
	 * 
	 */
	public void valueChangePartFamily() {

		try {
			LOG.info("Entering valueChangePartFamily Method");
			String selectedPartFamily = partFamilyIntAttrData
					.getSelectedPartFamily();
			LOG.info("Selected Part Family is :" + selectedPartFamily);
			attributeNameDDList = new ArrayList<SelectItem>();
			attributeNameDDList = (List<SelectItem>) plmPartFamAttrService
					.getAttrNameForPartFamily(selectedPartFamily).get(
							"attrNameForPartFamily");
			LOG.info("attributeNameDDList fetched with size :"
					+ attributeNameDDList.size());
			if (attributeNameDDList.size() == 0) {
				alertMessage = PLMConstants.SELECT_ANOTHER_PARTFAMILY;
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@valueChangePartFamily PLMInterfaceAttrMB:",
					exception);
		}
		LOG.info("Exiting valueChangePartFamily Method");

	}
	
	public String generatePartFamilyAttrMastr() throws PWiException, PLMCommonException {
		LOG.info("Entering generatePartFamilyAttrMastr Method");
		String fwdflag = "partFamilyAttrMastrSearch";
		LOG.info("partFamilyIntAttrData.getSelectedPartFamily()=="
				+ partFamilyIntAttrData.getSelectedPartFamily());
		
		userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		alertMessage ="";
		if (PLMUtils.isEmpty(partFamilyIntAttrData.getSelectedPartFamily()) && PLMUtils.isEmpty(partFamilyIntAttrData.getSelectedPartNum()))
				
		 {
			// if(1 == 0){
			LOG.info("No Input criteria Selected.........");
			//alertMessage = PLMConstants.PART_FAMILY_ATTR_MASTER_MANDITORY;
			alertMessage = PLMConstants.PART_FAMILY_ATTR_MASTER_CRITERIA;
			return "partFamilyAttrMastrSearch";
		} else {
			
			if (!PLMUtils.isEmpty(partFamilyIntAttrData.getSelectedPartFamily())){
				LOG.info("Some Input Criteria Selected.........");
				String selectedPartFamily = partFamilyIntAttrData
						.getSelectedPartFamily().trim();
				int pfCount = plmPartFamAttrService.getPartFamilyCount(selectedPartFamily);
				if(pfCount!=0){
					
				if(pfCount > Integer.parseInt(resourceBundle.getString("PART_FMY_VIEW_CNT_LMT")) 
						&& PLMUtils.isEmpty(partFamilyIntAttrData.getSelectedPartNum())){ 
					alertMessage =  PLMConstants.PART_FAMILY_ATTR_MASTER_EXCESS_PARTS;
					return "partFamilyAttrMastrSearch";
				}else if(hyperLinkFlag && pfCount > Integer.parseInt(resourceBundle.getString("PART_FMY_VIEW_CNT_HYPER_LMT"))
						&& PLMUtils.isEmpty(partFamilyIntAttrData.getSelectedPartNum())){ 
					alertMessage =  PLMConstants.PART_FAMILY_ATTR_MASTER_UNCHK_HYPERLINK;
					return "partFamilyAttrMastrSearch";
				 }
				
				}else{
					alertMessage = PLMConstants.PART_FAMILY_ATTR_MASTER_NO_PARTS;
					return "partFamilyAttrMastrSearch";
				}
			 }
			// Added for Part Number validation
			if (!PLMUtils.isEmpty(partFamilyIntAttrData
					.getSelectedPartNum())) {
				LOG.info("part num is not empty...");
				if (!PLMUtils
						.checkForSpecialCharsForTaskSearch(partFamilyIntAttrData
								.getSelectedPartNum())) {
					LOG.info("Special characters exist in part number...");
					alertMessage = PLMConstants.INVALID_PARTNUM;
					return "partFamilyAttrMastrSearch";
				}
				
				LOG.info("Starting part num count check...");
				boolean partNumMore500 = false;
				partNumMore500 = checkPartNumCount500(partFamilyIntAttrData
								.getSelectedPartNum());
				LOG.info("Ended part num count check...");
				if (!partNumMore500) {
					LOG.info("More than 500 part numbers entered...");
					alertMessage = PLMConstants.PARTNUM_MORE_500;
					return "partFamilyAttrMastrSearch";
				} else {
					LOG.info("Less than or equals to 500 part numbers entered...");
				}
			}
			alertMessage = alertMessage + PLMConstants.PART_FAMILY_ATTR_MASTER_ALERT_MSG;
			taskExecutor.execute(new MailThread());
		}
		return fwdflag;
	}
	
	/**
	 * This method is used to validate the part number limit of 500 entering with comma seperated and next line
	 * 
	 * @param partNum
	 * @return boolean
	 * 
	 */
	  public boolean checkPartNumCount500(String partNum){
		    LOG.info("Entering checkPartNumCount500 method");
		    String comma = ",";
		    String splitString =partNum;
		    boolean flag = false;
		    List<String> partNumList = new ArrayList<String>();
		    List<String> partNumComaList = new ArrayList<String>();
		    String [] partNumArr =null;
		    Scanner scanner = new Scanner(splitString);
			while (scanner.hasNextLine()) {
			  String lineReader = scanner.nextLine();
			  if(lineReader.contains(comma)){
				  partNumArr=lineReader.split(comma);
				  partNumComaList =new ArrayList<String>(Arrays.asList(partNumArr));
				  partNumList.addAll(partNumComaList);
		    	}else if(!lineReader.contains(comma)){
		    		partNumList.add(lineReader);
		    	}
			}
			scanner.close();
			 if(partNumList.size()<=PLMConstants.N_500){
				  flag=true;
				  partFamilyIntAttrData.setPartNumlist(partNumList);
			 }else{
				 flag=false;
			 }
			 LOG.info("partNumList.size>>>>>>>>> "+partNumList.size());
			 LOG.info("existing checkPartNumCount500 method");
		    return flag;
		  }

	
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendPartFamilyReportThroughMail();
		}
	}

	/**
	 * This method is used for Generating PartFamily Attribute Master ReportThroughMail
	 * 
	 * @return String
	 */
	public void sendPartFamilyReportThroughMail() {
		LOG.info("Entering onscreenPartFamilyReport Method");
		 Map<String,String> partAttributeMastrMap = new HashMap<String,String>();
			String selectedPartFamily = partFamilyIntAttrData.getSelectedPartFamily();
			String selectedPartNum = partFamilyIntAttrData.getSelectedPartNum();
			PLMInterfaceAttrData partFamilyData =new PLMInterfaceAttrData(); 
			partFamilyData.setSelectedPartFamily(partFamilyIntAttrData.getSelectedPartFamily());
			partFamilyData.setSelectedPartNum(partFamilyIntAttrData.getSelectedPartNum());
			partFamilyData.setPartNumlist(partFamilyIntAttrData.getPartNumlist());
			String optionTypeLcl =optionType;
			boolean hyperLinkFlagLcl =hyperLinkFlag;
			boolean partAttribFlagLcl =partAttribFlag;
			boolean partFamilyAttribFlagLcl =partFamilyAttribFlag;
			String from = PLMConstants.LTTR_MAIL_FROM;

			String to = userDetails.getUserEmailId();		
			String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
			toAddressee = "Dear " + toAddressee + ", \n\n";
			String subject = PLMConstants.PART_FAMILY_ATTR_MASTER_SUBJECT ;
			StringBuffer mailBody = new StringBuffer().append(toAddressee)
			.append(PLMConstants.PART_FAMILY_ATTR_MASTER_CONTENT);
			if(!PLMUtils.isEmpty(selectedPartFamily)){
				mailBody.append(PLMConstants.PART_FAMILY_ATTR_MASTER_CONTENT1)
				.append(selectedPartFamily)
				.append(".");
			}
			if(!PLMUtils.isEmpty(partFamilyData.getSelectedPartNum())){
				mailBody.append(PLMConstants.PART_FAMILY_ATTR_MASTER_CONTENT2);
				mailBody.append(partFamilyData.getPartNumlist());
				mailBody.append(".");
			}
			mailBody.append(PLMConstants.PART_FAMILY_ATTR_MASTER_CONTENT3)
			.append(optionTypeLcl)
			.append(".")
			.append(PLMConstants.PART_FAMILY_ATTR_MASTER_SIGNATURE)
			.append(PLMConstants.PART_FAMILY_ATTR_MASTER_FOOTER);
			
			try {
				partAttributeMastrMap = plmPartFamAttrService.getPartFamilyAttrMasterResultList(partFamilyData,optionTypeLcl,hyperLinkFlagLcl,partAttribFlagLcl,partFamilyAttribFlagLcl);
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), partAttributeMastrMap.get("filePathZip"));
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@sendPartFamilyAttrMastrReportThroughMail: ", exception);
				PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
			} catch (Exception exception) {
				LOG.log(Level.ERROR, "Exception@sendPartFamilyAttrMastrReportThroughMail: ", exception);
				PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
			} finally {
				PLMUtils.deleteFiles(partAttributeMastrMap.get("filePathXls"),partAttributeMastrMap.get("filePathZip"));
			}
			LOG.info("Mail sent successfully.");
	}
	
	/**
	 * This method is used for resetSearchData
	 * 
	 * @return String
	 */
	public String resetSearchData() {
		LOG.info("Entering resetSearchData");
		String fwdFlag = "partFamilyAttrMastrSearch";
		try {
			partFamilyIntAttrData.setSelectedAttributeName("");
			partFamilyIntAttrData.setSelectedPartFamily("");
			partFamilyIntAttrData.setSelectedPartNum("");
			partFamilyIntAttrData.setSelectedCurrPrevRev(false);
			partFamilyIntAttrData.setSelectedInProcessStates(null);
			partFamilyIntAttrData.setSelectedPartType(null);
			attributeNameDDList = new ArrayList<SelectItem>();
			SelectItem stdText = new SelectItem("stdTxt",
					"Please select Part Family to see corresponding Attribute Names");
			attributeNameDDList.add(stdText);
			alertMessage ="";
			optionType ="All Parts";
			hyperLinkFlag =true;
			partAttribFlag =true;
			partFamilyAttribFlag =true;
			LOG.info("executed resetSearchData inside resetSearchData");

		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@resetSearchData PLMInterfaceAttrMB:", exception);
		}
		LOG.info("Existing resetSearchData");
		return fwdFlag;

	}

	/**
	 * This method is used for auto complete feature
	 * 
	 * @return String
	 */
	public List<String> partFamilyAutocomplete(Object partFamilySuggest) {
		LOG.info("Inside partFamilyAutocomplete method...");
		String pref = (String) partFamilySuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (partFamilyDDList.size() > 0) {
				for (SelectItem item : partFamilyDDList) {
					if (!item.getLabel().equals("")
							&& item.getLabel().startsWith(
									pref.toUpperCase(Locale.getDefault()))) {
						// LOG.info("Added=="+item.getLabel());
						result.add(item.getLabel());
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@partFamilyAutocomplete in PLMPartFamilyIntAttrMB:",
					exception);
		}
		LOG.info("Existing partFamilyAutocomplete method...");
		return result;
	}

	/**
	 * This method is used for auto complete feature
	 * 
	 * @return String
	 */
	public void clearPartFamily() {
		LOG.info("Inside clearPartFamily method...");
		try {

		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@partFamilyAutocomplete in PLMPartFamilyIntAttrMB:",
					exception);
		}

	}

	/**
	 * This method is used to download an Excel File
	 * 
	 * 
	 */
	public void downloadExcel() throws PLMCommonException {
		LOG.info("Entering downloadExcel Method");
		String reportName = "PartFamily-InterfaceAttribute";
		try {

			if (resultList != null && resultList.size() > 0) {
				generatePartFamilyExcel(resultList, reportName);
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@downloadExcel: ", exception);
		}
		LOG.info("Exiting downloadExcel Method");

	}
	
	/**
	 * This method is used for download Excel sheet for each report
	 * 
	 * @return String
	 */
	public void downloadCSV() throws PLMCommonException {
		LOG.info("Entering downloadCSV Method");
		String reportName = "InterfaceAttribute";
		String fileName = "Interface Attribute Report";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		// Export to CSV for Interface Attribue Report
			PLMCsvRptColumn[] reportColumns =
					new PLMCsvRptColumn[] {new PLMCsvRptColumn("partName", "Part Name", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("partTitle", "Part Description", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("revision", "Revision", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("interfaceName", "Interface Name", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("attributeGroup", "Attribute Group", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("attributeNm", "Attribute Name", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("attributeValue", "Attribute Value", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("rdo", "RDO", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("partType", "Part Type", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("partState", "Part State", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("partFamilyNm", "Part Family Name", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("partFamilyDescription", "Part Family Description", FormatTypeCsv.TEXT)};

			csvUtil.exportCsv(resultList, reportColumns, fileName, dateFormat, false, null, null, ",");
			
			LOG.info("Exiting downloadCSV Method");
	}

	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return File
	 */
	
	

	public File generatePartFamilyExcel(
			List<PLMInterfaceAttrData> resultListLcl, String reportName)
			throws IOException {
		LOG.info("Entering generatePartFamilyExcel Method");
		File flexcelFile = null;
		FileOutputStream fileOut = null;
		InputStream fstream = null;
		BufferedOutputStream bos = null;
		OutputStream os = null;
		XSSFWorkbook workbook = null;
		XSSFSheet sheet = null;
		XSSFCell cell = null;
		Map<PLMInterfaceAttrData,List<PLMInterfaceAttrData>> newMap = new HashMap<PLMInterfaceAttrData,List<PLMInterfaceAttrData>>();
		try {

			StringBuilder fileNameStr = new StringBuilder()
					.append(PLMUtils.getMessage("OFFLINE_RPT_DIR", "Reports"))
					.append(reportName).append(PLMUtils.getCurrentDateTime())
					.append(".xlsx");

			flexcelFile = new File(fileNameStr.toString());
			workbook = new XSSFWorkbook();

			if (workbook != null) {

				sheet = workbook.createSheet(reportName);
				sheet.createFreezePane(0, 1);
				XSSFFont fontstyle = workbook.createFont();
				fontstyle.setFontName(PLMConstants.EXCEL_FONT_NAME);

				XSSFCellStyle unLockedTextStyle = workbook.createCellStyle();
				unLockedTextStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				unLockedTextStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				unLockedTextStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
				unLockedTextStyle.setBorderTop((HSSFCellStyle.BORDER_THIN));
				unLockedTextStyle.setFont(fontstyle);
				unLockedTextStyle.setWrapText(true);
				unLockedTextStyle.setLocked(false);
				unLockedTextStyle.setAlignment(CellStyle.ALIGN_CENTER);

				/*
				 * HSSFCellStyle lockedTextStyle = workbook.createCellStyle();
				 * lockedTextStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				 * lockedTextStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				 * lockedTextStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
				 * lockedTextStyle.setBorderTop((HSSFCellStyle.BORDER_THIN));
				 * lockedTextStyle.setFont(fontstyle);
				 * lockedTextStyle.setWrapText(true);
				 * lockedTextStyle.setLocked(true);
				 * lockedTextStyle.setAlignment(CellStyle.ALIGN_CENTER);
				 */

				XSSFCellStyle headerStyle = workbook.createCellStyle();

				headerStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
				XSSFFont font = workbook.createFont();
				font.setFontName(PLMConstants.EXCEL_FONT_NAME);
				font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headerStyle.setFont(font);
				headerStyle.setWrapText(true);
				headerStyle.setLocked(true);
				headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
				headerStyle = setBorderStyle(headerStyle);

				int rowcount = -1;

				if (!PLMUtils.isEmptyList(resultListLcl)) {
					String[] colNames = { "Part Number", "Part Revision",
							"Part Description", "Part Family" };
					XSSFRow row = sheet.createRow(++rowcount);

					for (int i = 0; i < colNames.length; i++) {
						cell = row.createCell(i);
						cell.setCellValue(colNames[i]);
						cell.setCellStyle(headerStyle);
						headerStyle = cell.getCellStyle();
						cell.setCellStyle(headerStyle);
					}

					int countFrHead = colNames.length;
					headerStyle = workbook.createCellStyle();				
					
					for (int k = 0; k < resultListForAttribute.size();k++) {
						
						cell = row.createCell(countFrHead);
						cell.setCellValue(resultListForAttribute.get(k));
						headerStyle.setRotation((short)60);
						cell.setCellStyle(headerStyle);
						headerStyle = cell.getCellStyle();
						cell.setCellStyle(headerStyle);
						countFrHead = countFrHead +1;
					}
					
					for (PLMInterfaceAttrData plmInterfaceAttrData:resultListLcl) {
					    
					    
					    row = sheet.createRow(++rowcount);
					    
						cell = row.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(plmInterfaceAttrData.getPartName());

						cell = row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(plmInterfaceAttrData.getRevision());

						cell = row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(plmInterfaceAttrData.getPartFamilyDescription());

						cell = row.createCell(PLMConstants.EXCEL_COL_THREE);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(plmInterfaceAttrData.getPartFamilyNm());
						
						int counter = PLMConstants.EXCEL_COL_FOUR;
						String attributeNames1 =plmInterfaceAttrData.getAttributeNm();
						
						String[] attributeNameArr1 = attributeNames1.split("@");
						for(int countAttrPart=0 ; countAttrPart < attributeNameArr1.length ;countAttrPart++)
						{
							
							for(int countAttrNm=0;countAttrNm < resultListForAttribute.size() ; countAttrNm++)
							{
								if(countAttrPart==countAttrNm)
								{
									if(resultListForAttribute.get(countAttrNm).equals(attributeNameArr1[countAttrPart].substring(0,attributeNameArr1[countAttrPart].lastIndexOf(";"))))
									{
										cell = row.createCell(counter);
										cell.setCellStyle(unLockedTextStyle);
										System.out.println(attributeNameArr1[countAttrPart]+"::"+attributeNameArr1[countAttrPart].lastIndexOf(";"));
										if(attributeNameArr1[countAttrPart].lastIndexOf(";")!= -1)
										{
										cell.setCellValue(attributeNameArr1[countAttrPart].substring(attributeNameArr1[countAttrPart].lastIndexOf(";")+1));
										}
										else
										{
											cell.setCellValue(" ");
										}
										counter++;
									}
									else
									{
										cell = row.createCell(counter);
										cell.setCellStyle(unLockedTextStyle);
										cell.setCellValue(" ");
										counter++;
									}
								}
								
							}
							
						}
						
					}
					
					row = sheet.createRow(++rowcount);
					row = sheet.createRow(++rowcount);
					short colWidth = (short) 6400;
					short colWidth1 = (short) 6700;
					short colWidth2 = (short) 7000;
					short colWidth3 = (short) 7200;
					short colWidth4 = (short) 7900;

					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, colWidth1);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE, colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX, colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,
							colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,
							colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE, colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN, colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN,
							colWidth3);

				}
			
				fileOut = new FileOutputStream(flexcelFile);
				workbook.write(fileOut);
				String fileName = flexcelFile.getName();
				FacesContext context = FacesContext.getCurrentInstance();
				HttpServletResponse response = (HttpServletResponse) context
						.getExternalContext().getResponse();
				response.setContentType("application/vnd.ms-excel");
				response.setHeader("content-disposition",
						"attachment; filename=" + fileName);
				os = response.getOutputStream();
				workbook.write(os);
				fileOut.close();
				os.close();
				context.responseComplete();
				LOG.info("test file name" + fileName);
				LOG.info("test report-------" + flexcelFile);

			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@generateFMIManageTxt: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@generateFMIManageTxt: ", e);
			throw e;
		} finally {
			try {
				if (bos != null) {
					bos.close();
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "The Exception in generateFMIManageTxt "
						+ exception);
			}
			try {
				if (os != null) {
					os.close();
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "The Exception in generateFMIManageTxt "
						+ exception);
			}
			try {
				if (fstream != null) {
					fstream.close();
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "The Exception in generateFMIManageTxt "
						+ exception);
			}
			try {
				if (flexcelFile != null) {
					PLMUtils.deleteDocument(flexcelFile.getAbsolutePath());
				}
			} catch (Exception exception) {
				LOG.log(Level.ERROR, "The Exception in generateFMIManageTxt "
						+ exception);
			}
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "The Exception in generateFMIManageTxt "
						+ exception);
			}

		}
		LOG.info("Exiting generateFMIManageTxt Method");
		return flexcelFile;

	}

	/**
	 * This method is used for Bordering Cell in XLS
	 * 
	 * @return StringBuffer
	 */

	private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		return style;
	}

	/**
	 * This method is used for recordsPerPageListner
	 * 
	 * @param event
	 * 
	 */
	public void recordsPerPageListner(ActionEvent event) {
		LOG.info("Entering recordsPerPageListner method");
		LOG.info("Action listner called.....--------------------------->"
				+ recordCounts);
		if (recordCounts == 15) {
			LOG.info("15");
			recordCounts = 15;
		} else if (recordCounts == 30) {
			LOG.info("30");
			recordCounts = 30;
		} else if (recordCounts == 50) {
			LOG.info("50");
			recordCounts = 50;
		} else if (recordCounts == 100) {
			LOG.info("100");
			recordCounts = 100;
		} else if (recordCounts == 200) {
			LOG.info("200");
			recordCounts = 200;
		}

		else if (recordCounts == resultListCount) {
			LOG.info("All");
			recordCounts = resultListCount;
		}
		LOG.info("final value.....--------------------------->" + recordCounts);
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB
	 *            the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return LOG;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage
	 *            the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the partFamilyDDList
	 */
	public List<SelectItem> getPartFamilyDDList() {
		return partFamilyDDList;
	}

	/**
	 * @param partFamilyDDList
	 *            the partFamilyDDList to set
	 */
	public void setPartFamilyDDList(List<SelectItem> partFamilyDDList) {
		this.partFamilyDDList = partFamilyDDList;
	}

	/**
	 * @return the attributeNameDDList
	 */
	public List<SelectItem> getAttributeNameDDList() {
		return attributeNameDDList;
	}

	/**
	 * @param attributeNameDDList
	 *            the attributeNameDDList to set
	 */
	public void setAttributeNameDDList(List<SelectItem> attributeNameDDList) {
		this.attributeNameDDList = attributeNameDDList;
	}

	/**
	 * @return the dropDownMapList
	 */
	public Map<String, List<SelectItem>> getDropDownMapList() {
		return dropDownMapList;
	}

	/**
	 * @param dropDownMapList
	 *            the dropDownMapList to set
	 */
	public void setDropDownMapList(Map<String, List<SelectItem>> dropDownMapList) {
		this.dropDownMapList = dropDownMapList;
	}

	

	/**
	 * @return the plmPartFamAttrService
	 */
	public PLMPartFamAttrServiceIfc getPlmPartFamAttrService() {
		return plmPartFamAttrService;
	}

	/**
	 * @param plmPartFamAttrService the plmPartFamAttrService to set
	 */
	public void setPlmPartFamAttrService(
			PLMPartFamAttrServiceIfc plmPartFamAttrService) {
		this.plmPartFamAttrService = plmPartFamAttrService;
	}

	/**
	 * @return the partFamilyIntAttrData
	 */
	public PLMInterfaceAttrData getPartFamilyIntAttrData() {
		return partFamilyIntAttrData;
	}

	/**
	 * @param partFamilyIntAttrData
	 *            the partFamilyIntAttrData to set
	 */
	public void setPartFamilyIntAttrData(
			PLMInterfaceAttrData partFamilyIntAttrData) {
		this.partFamilyIntAttrData = partFamilyIntAttrData;
	}

	/**
	 * @return the resultList
	 */
	public List<PLMInterfaceAttrData> getResultList() {
		return resultList;
	}

	/**
	 * @param resultList
	 *            the resultList to set
	 */
	public void setResultList(List<PLMInterfaceAttrData> resultList) {
		this.resultList = resultList;
	}

	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @param recordCounts
	 *            the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}

	/**
	 * @return the resultListCount
	 */
	public int getResultListCount() {
		return resultListCount;
	}

	/**
	 * @param resultListCount
	 *            the resultListCount to set
	 */
	public void setResultListCount(int resultListCount) {
		this.resultListCount = resultListCount;
	}

	/**
	 * @return the resultListCountMsg
	 */
	public String getResultListCountMsg() {
		return resultListCountMsg;
	}

	/**
	 * @param resultListCountMsg
	 *            the resultListCountMsg to set
	 */
	public void setResultListCountMsg(String resultListCountMsg) {
		this.resultListCountMsg = resultListCountMsg;
	}

	public List<String> getResultListForAttribute() {
		return resultListForAttribute;
	}

	public void setResultListForAttribute(
			List<String> resultListForAttribute) {
		this.resultListForAttribute = resultListForAttribute;
	}

	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the optionType
	 */
	public String getOptionType() {
		return optionType;
	}

	/**
	 * @param optionType the optionType to set
	 */
	public void setOptionType(String optionType) {
		this.optionType = optionType;
	}
	/**
	 * @return the hyperLinkFlag
	 */
	public boolean isHyperLinkFlag() {
		return hyperLinkFlag;
	}

	/**
	 * @param hyperLinkFlag the hyperLinkFlag to set
	 */
	public void setHyperLinkFlag(boolean hyperLinkFlag) {
		this.hyperLinkFlag = hyperLinkFlag;
	}

	/**
	 * @return the partAttribFlag
	 */
	public boolean isPartAttribFlag() {
		return partAttribFlag;
	}

	/**
	 * @param partAttribFlag the partAttribFlag to set
	 */
	public void setPartAttribFlag(boolean partAttribFlag) {
		this.partAttribFlag = partAttribFlag;
	}

	/**
	 * @return the partFamilyAttribFlag
	 */
	public boolean isPartFamilyAttribFlag() {
		return partFamilyAttribFlag;
	}

	/**
	 * @param partFamilyAttribFlag the partFamilyAttribFlag to set
	 */
	public void setPartFamilyAttribFlag(boolean partFamilyAttribFlag) {
		this.partFamilyAttribFlag = partFamilyAttribFlag;
	}

	
}
