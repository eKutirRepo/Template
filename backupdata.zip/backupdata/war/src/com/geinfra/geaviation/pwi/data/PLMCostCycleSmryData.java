/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCostCycleSmryData.java
 * @Creation date: 16-Jul-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import javax.faces.model.SelectItem;

public class PLMCostCycleSmryData {
	
	/**
	  * Holds the costReqNum
	  */
	private String costReqNum;
	
	/**
	  * Holds the contract
	  */
	private String contract;
	/**
	  * Holds the description
	  */
	private String description;
	/**
	  * Holds the crId
	  */
	private String crId;
	/**
	  * Holds the crName
	  */
	private String crName;
	/**
	  * Holds the crsName
	  */
	private String crsName;
	/**
	  * Holds the ddListContract
	  */
	private SelectItem ddListContract;
	
	/**
	  * Holds the selectedContract
	  */
	private String selectedContract;
	
	/**
	  * Holds the resCustReq
	  */
	private String resCustReq;
	/**
	  * Holds the resCustReqDesc
	  */
	private String resCustReqDesc;
	/**
	  * Holds the resCustReqSpec
	  */
	private String resCustReqSpec;
	/**
	  * Holds the resCRState
	  */
	private String resCRState;
	/**
	  * Holds the resContract
	  */
	private String resContract;
	/**
	  * Holds the resContractDesc
	  */
	private String resContractDesc;
	/**
	  * Holds the resCostGroup
	  */
	private String resCostGroup;
	/**
	  * Holds the resCOName
	  */
	private String resCOName;
	/**
	  * Holds the resCOState
	  */
	private String resCOState;
	/**
	  * Holds the resTFMktName
	  */
	private String resTFMktName;
	/**
	  * Holds the resLFDesc
	  */
	private String resLFDesc;
	/**
	  * Holds the resUnitOfMeasure
	  */
	private String resUnitOfMeasure;
	/**
	  * Holds the resLocationCurrency
	  */
	private String resLocationCurrency;
	/**
	  * Holds the resMaterialShipDirectCost
	  */
	private double resMaterialShipDirectCost;
	/**
	  * Holds the resRawInProcessCost
	  */
	private double resRawInProcessCost;
	/**
	  * Holds the resMfgLaborHours
	  */
	private double resMfgLaborHours;
	/**
	  * Holds the resProdCost
	  */
	private double resProdCost;
	/**
	  * Holds the resShopWorkLabCost
	  */
	private double resShopWorkLabCost;
	/**
	  * Holds the resDraftingHours
	  */
	private double resDraftingHours;
	/**
	  * Holds the resEnggHours
	  */
	private double resEnggHours;
	/**
	  * Holds the resEnggTotalCost
	  */
	private double resEnggTotalCost;
	/**
	  * Holds the resTransportCost
	  */
	private double resTransportCost;
	/**
	  * Holds the resFieldInstallCost
	  */
	private double resFieldInstallCost;	
	/**
	  * Holds the resMfgExp
	  */
	private double resMfgExp;
	/**
	  * Holds the resFieldTransInvCost
	  */
	private double resFieldTransInvCost;
	/**
	  * Holds the resEngFieldTransCost
	  */
	private double resEngFieldTransCost;
	/**
	  * Holds the resMfgMatLeadTime
	  */
	private double resMfgMatLeadTime;
	/**
	  * Holds the resMfgPlannedLeadTime
	  */
	private double resMfgPlannedLeadTime;
	/**
	  * Holds the resCycleTimeDrawings
	  */
	private double resCycleTimeDrawings;
	/**
	  * Holds the resProductConfig
	  */
	private String resProductConfig;
	/**
	  * Holds the resModelNum
	  */
	private String resModelNum;
	/**
	  * Holds the resEnggDisposition
	  */
	private String resEnggDisposition;
	/**
	  * Holds the resPartName
	  */
	private String resPartName;
	
	/**
	  * Holds the noOfUnits
	  */
	private int resNoOfUnits;
	
	/**
	  * Holds the noOfUnits
	  */
	private String noOfUnits;
	/**
	  * Holds the prodCostSite
	  */
	private double prodCostSite;
	/**
	  * Holds the prdSiteFieldTranCost
	  */
	private String totalCostSmry;
	
	/**
	  * Holds the prdSiteFieldTranCost
	  */
	private double prdSiteFieldTranCost;
	/**
	  * Holds the sumFlag
	  */
	private boolean sumFlag;
	
	/**
	  * Holds the custReqNm
	  */
	private String custReqNm;
	
	
	
	
	

	/**
	 * @return the costReqNum
	 */
	public String getCostReqNum() {
		return costReqNum;
	}

	/**
	 * @param costReqNum the costReqNum to set
	 */
	public void setCostReqNum(String costReqNum) {
		this.costReqNum = costReqNum;
	}

	/**
	 * @return the contract
	 */
	public String getContract() {
		return contract;
	}

	/**
	 * @param contract the contract to set
	 */
	public void setContract(String contract) {
		this.contract = contract;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the crId
	 */
	public String getCrId() {
		return crId;
	}

	/**
	 * @param crId the crId to set
	 */
	public void setCrId(String crId) {
		this.crId = crId;
	}

	/**
	 * @return the crName
	 */
	public String getCrName() {
		return crName;
	}

	/**
	 * @param crName the crName to set
	 */
	public void setCrName(String crName) {
		this.crName = crName;
	}

	/**
	 * @return the crsName
	 */
	public String getCrsName() {
		return crsName;
	}

	/**
	 * @param crsName the crsName to set
	 */
	public void setCrsName(String crsName) {
		this.crsName = crsName;
	}

	/**
	 * @return the selectedContract
	 */
	public String getSelectedContract() {
		return selectedContract;
	}

	/**
	 * @param selectedContract the selectedContract to set
	 */
	public void setSelectedContract(String selectedContract) {
		this.selectedContract = selectedContract;
	}

	/**
	 * @return the ddListContract
	 */
	public SelectItem getDdListContract() {
		return ddListContract;
	}

	/**
	 * @param ddListContract the ddListContract to set
	 */
	public void setDdListContract(SelectItem ddListContract) {
		this.ddListContract = ddListContract;
	}

	/**
	 * @return the resCustReq
	 */
	public String getResCustReq() {
		return resCustReq;
	}

	/**
	 * @param resCustReq the resCustReq to set
	 */
	public void setResCustReq(String resCustReq) {
		this.resCustReq = resCustReq;
	}

	/**
	 * @return the resCustReqDesc
	 */
	public String getResCustReqDesc() {
		return resCustReqDesc;
	}

	/**
	 * @param resCustReqDesc the resCustReqDesc to set
	 */
	public void setResCustReqDesc(String resCustReqDesc) {
		this.resCustReqDesc = resCustReqDesc;
	}

	/**
	 * @return the resCustReqSpec
	 */
	public String getResCustReqSpec() {
		return resCustReqSpec;
	}

	/**
	 * @param resCustReqSpec the resCustReqSpec to set
	 */
	public void setResCustReqSpec(String resCustReqSpec) {
		this.resCustReqSpec = resCustReqSpec;
	}

	/**
	 * @return the resCRState
	 */
	public String getResCRState() {
		return resCRState;
	}

	/**
	 * @param resCRState the resCRState to set
	 */
	public void setResCRState(String resCRState) {
		this.resCRState = resCRState;
	}

	/**
	 * @return the resContract
	 */
	public String getResContract() {
		return resContract;
	}

	/**
	 * @param resContract the resContract to set
	 */
	public void setResContract(String resContract) {
		this.resContract = resContract;
	}

	/**
	 * @return the resContractDesc
	 */
	public String getResContractDesc() {
		return resContractDesc;
	}

	/**
	 * @param resContractDesc the resContractDesc to set
	 */
	public void setResContractDesc(String resContractDesc) {
		this.resContractDesc = resContractDesc;
	}

	/**
	 * @return the resCostGroup
	 */
	public String getResCostGroup() {
		return resCostGroup;
	}

	/**
	 * @param resCostGroup the resCostGroup to set
	 */
	public void setResCostGroup(String resCostGroup) {
		this.resCostGroup = resCostGroup;
	}

	/**
	 * @return the resCOName
	 */
	public String getResCOName() {
		return resCOName;
	}

	/**
	 * @param resCOName the resCOName to set
	 */
	public void setResCOName(String resCOName) {
		this.resCOName = resCOName;
	}

	/**
	 * @return the resCOState
	 */
	public String getResCOState() {
		return resCOState;
	}

	/**
	 * @param resCOState the resCOState to set
	 */
	public void setResCOState(String resCOState) {
		this.resCOState = resCOState;
	}

	/**
	 * @return the resTFMktName
	 */
	public String getResTFMktName() {
		return resTFMktName;
	}

	/**
	 * @param resTFMktName the resTFMktName to set
	 */
	public void setResTFMktName(String resTFMktName) {
		this.resTFMktName = resTFMktName;
	}

	/**
	 * @return the resLFDesc
	 */
	public String getResLFDesc() {
		return resLFDesc;
	}

	/**
	 * @param resLFDesc the resLFDesc to set
	 */
	public void setResLFDesc(String resLFDesc) {
		this.resLFDesc = resLFDesc;
	}

	/**
	 * @return the resUnitOfMeasure
	 */
	public String getResUnitOfMeasure() {
		return resUnitOfMeasure;
	}

	/**
	 * @param resUnitOfMeasure the resUnitOfMeasure to set
	 */
	public void setResUnitOfMeasure(String resUnitOfMeasure) {
		this.resUnitOfMeasure = resUnitOfMeasure;
	}

	/**
	 * @return the resLocationCurrency
	 */
	public String getResLocationCurrency() {
		return resLocationCurrency;
	}

	/**
	 * @param resLocationCurrency the resLocationCurrency to set
	 */
	public void setResLocationCurrency(String resLocationCurrency) {
		this.resLocationCurrency = resLocationCurrency;
	}

	

	/**
	 * @return the resMaterialShipDirectCost
	 */
	public double getResMaterialShipDirectCost() {
		return resMaterialShipDirectCost;
	}

	/**
	 * @param resMaterialShipDirectCost the resMaterialShipDirectCost to set
	 */
	public void setResMaterialShipDirectCost(double resMaterialShipDirectCost) {
		this.resMaterialShipDirectCost = resMaterialShipDirectCost;
	}

	
	
	/**
	 * @return the resRawInProcessCost
	 */
	public double getResRawInProcessCost() {
		return resRawInProcessCost;
	}

	/**
	 * @param resRawInProcessCost the resRawInProcessCost to set
	 */
	public void setResRawInProcessCost(double resRawInProcessCost) {
		this.resRawInProcessCost = resRawInProcessCost;
	}

	/**
	 * @return the resMfgLaborHours
	 */
	public double getResMfgLaborHours() {
		return resMfgLaborHours;
	}

	/**
	 * @param resMfgLaborHours the resMfgLaborHours to set
	 */
	public void setResMfgLaborHours(double resMfgLaborHours) {
		this.resMfgLaborHours = resMfgLaborHours;
	}

	/**
	 * @return the resProdCost
	 */
	public double getResProdCost() {
		return resProdCost;
	}

	/**
	 * @param resProdCost the resProdCost to set
	 */
	public void setResProdCost(double resProdCost) {
		this.resProdCost = resProdCost;
	}

	/**
	 * @return the resShopWorkLabCost
	 */
	public double getResShopWorkLabCost() {
		return resShopWorkLabCost;
	}

	/**
	 * @param resShopWorkLabCost the resShopWorkLabCost to set
	 */
	public void setResShopWorkLabCost(double resShopWorkLabCost) {
		this.resShopWorkLabCost = resShopWorkLabCost;
	}

	/**
	 * @return the resDraftingHours
	 */
	public double getResDraftingHours() {
		return resDraftingHours;
	}

	/**
	 * @param resDraftingHours the resDraftingHours to set
	 */
	public void setResDraftingHours(double resDraftingHours) {
		this.resDraftingHours = resDraftingHours;
	}

	/**
	 * @return the resEnggHours
	 */
	public double getResEnggHours() {
		return resEnggHours;
	}

	/**
	 * @param resEnggHours the resEnggHours to set
	 */
	public void setResEnggHours(double resEnggHours) {
		this.resEnggHours = resEnggHours;
	}

	/**
	 * @return the resEnggTotalCost
	 */
	public double getResEnggTotalCost() {
		return resEnggTotalCost;
	}

	/**
	 * @param resEnggTotalCost the resEnggTotalCost to set
	 */
	public void setResEnggTotalCost(double resEnggTotalCost) {
		this.resEnggTotalCost = resEnggTotalCost;
	}

	/**
	 * @return the resTransportCost
	 */
	public double getResTransportCost() {
		return resTransportCost;
	}

	/**
	 * @param resTransportCost the resTransportCost to set
	 */
	public void setResTransportCost(double resTransportCost) {
		this.resTransportCost = resTransportCost;
	}

	/**
	 * @return the resFieldInstallCost
	 */
	public double getResFieldInstallCost() {
		return resFieldInstallCost;
	}

	/**
	 * @param resFieldInstallCost the resFieldInstallCost to set
	 */
	public void setResFieldInstallCost(double resFieldInstallCost) {
		this.resFieldInstallCost = resFieldInstallCost;
	}

	/**
	 * @return the resMfgExp
	 */
	public double getResMfgExp() {
		return resMfgExp;
	}

	/**
	 * @param resMfgExp the resMfgExp to set
	 */
	public void setResMfgExp(double resMfgExp) {
		this.resMfgExp = resMfgExp;
	}

	/**
	 * @return the resFieldTransInvCost
	 */
	public double getResFieldTransInvCost() {
		return resFieldTransInvCost;
	}

	/**
	 * @param resFieldTransInvCost the resFieldTransInvCost to set
	 */
	public void setResFieldTransInvCost(double resFieldTransInvCost) {
		this.resFieldTransInvCost = resFieldTransInvCost;
	}

	/**
	 * @return the resEngFieldTransCost
	 */
	public double getResEngFieldTransCost() {
		return resEngFieldTransCost;
	}

	/**
	 * @param resEngFieldTransCost the resEngFieldTransCost to set
	 */
	public void setResEngFieldTransCost(double resEngFieldTransCost) {
		this.resEngFieldTransCost = resEngFieldTransCost;
	}

	/**
	 * @return the resMfgMatLeadTime
	 */
	public double getResMfgMatLeadTime() {
		return resMfgMatLeadTime;
	}

	/**
	 * @param resMfgMatLeadTime the resMfgMatLeadTime to set
	 */
	public void setResMfgMatLeadTime(double resMfgMatLeadTime) {
		this.resMfgMatLeadTime = resMfgMatLeadTime;
	}

	/**
	 * @return the resMfgPlannedLeadTime
	 */
	public double getResMfgPlannedLeadTime() {
		return resMfgPlannedLeadTime;
	}

	/**
	 * @param resMfgPlannedLeadTime the resMfgPlannedLeadTime to set
	 */
	public void setResMfgPlannedLeadTime(double resMfgPlannedLeadTime) {
		this.resMfgPlannedLeadTime = resMfgPlannedLeadTime;
	}

	/**
	 * @return the resCycleTimeDrawings
	 */
	public double getResCycleTimeDrawings() {
		return resCycleTimeDrawings;
	}

	/**
	 * @param resCycleTimeDrawings the resCycleTimeDrawings to set
	 */
	public void setResCycleTimeDrawings(double resCycleTimeDrawings) {
		this.resCycleTimeDrawings = resCycleTimeDrawings;
	}

	/**
	 * @return the resProductConfig
	 */
	public String getResProductConfig() {
		return resProductConfig;
	}

	/**
	 * @param resProductConfig the resProductConfig to set
	 */
	public void setResProductConfig(String resProductConfig) {
		this.resProductConfig = resProductConfig;
	}

	/**
	 * @return the resModelNum
	 */
	public String getResModelNum() {
		return resModelNum;
	}

	/**
	 * @param resModelNum the resModelNum to set
	 */
	public void setResModelNum(String resModelNum) {
		this.resModelNum = resModelNum;
	}

	/**
	 * @return the resEnggDisposition
	 */
	public String getResEnggDisposition() {
		return resEnggDisposition;
	}

	/**
	 * @param resEnggDisposition the resEnggDisposition to set
	 */
	public void setResEnggDisposition(String resEnggDisposition) {
		this.resEnggDisposition = resEnggDisposition;
	}

	/**
	 * @return the resPartName
	 */
	public String getResPartName() {
		return resPartName;
	}

	/**
	 * @param resPartName the resPartName to set
	 */
	public void setResPartName(String resPartName) {
		this.resPartName = resPartName;
	}

	/**
	 * @return the noOfUnits
	 */
	public int getResNoOfUnits() {
		return resNoOfUnits;
	}

	/**
	 * @param noOfUnits the noOfUnits to set
	 */
	public void setResNoOfUnits(int resNoOfUnits) {
		this.resNoOfUnits = resNoOfUnits;
	}

	/**
	 * @return the noOfUnits
	 */
	public String getNoOfUnits() {
		return noOfUnits;
	}

	/**
	 * @param noOfUnits the noOfUnits to set
	 */
	public void setNoOfUnits(String noOfUnits) {
		this.noOfUnits = noOfUnits;
	}

	/**
	 * @return the prodCostSite
	 */
	public double getProdCostSite() {
		return prodCostSite;
	}

	/**
	 * @param prodCostSite the prodCostSite to set
	 */
	public void setProdCostSite(double prodCostSite) {
		this.prodCostSite = prodCostSite;
	}

	/**
	 * @return the prdSiteFieldTranCost
	 */
	public double getPrdSiteFieldTranCost() {
		return prdSiteFieldTranCost;
	}

	/**
	 * @param prdSiteFieldTranCost the prdSiteFieldTranCost to set
	 */
	public void setPrdSiteFieldTranCost(double prdSiteFieldTranCost) {
		this.prdSiteFieldTranCost = prdSiteFieldTranCost;
	}

	/**
	 * @return the sumFlag
	 */
	public boolean isSumFlag() {
		return sumFlag;
	}

	/**
	 * @param sumFlag the sumFlag to set
	 */
	public void setSumFlag(boolean sumFlag) {
		this.sumFlag = sumFlag;
	}

	/**
	 * @return the totalCostSmry
	 */
	public String getTotalCostSmry() {
		return totalCostSmry;
	}

	/**
	 * @param totalCostSmry the totalCostSmry to set
	 */
	public void setTotalCostSmry(String totalCostSmry) {
		this.totalCostSmry = totalCostSmry;
	}

	/**
	 * @return the custReqNm
	 */
	public String getCustReqNm() {
		return custReqNm;
	}

	/**
	 * @param custReqNm the custReqNm to set
	 */
	public void setCustReqNm(String custReqNm) {
		this.custReqNm = custReqNm;
	}

	
	
	
	
	

}
