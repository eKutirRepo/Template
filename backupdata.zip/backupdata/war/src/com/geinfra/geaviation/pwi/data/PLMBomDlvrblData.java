/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBomDlvrblData.java
 * @Creation date: 11-Sept-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMBomDlvrblData {

	
	// PROPERTIES *************************************************************
	
	public PLMPRSData chapter;
	public PLMBomSpecPartData bom_part;
	public PLMTaskDlvrblData task_deliverable;
	public String rowColor;

	
	// CONSTRUCTOR ************************************************************

	/**
	 * Creates a new instance of the class BomDeliverable
	 * 
	 */
	public PLMBomDlvrblData (PLMBomSpecPartData bom_part, PLMTaskDlvrblData task_deliverable) {  
		this.bom_part = bom_part;
		this.task_deliverable = task_deliverable;		
	}
	
	// ACCESSOR METHODS *******************************************************

	public PLMPRSData getChapter() {
		return chapter;
	}

	public void setChapter(PLMPRSData chapter) {
		this.chapter = chapter;
	}

	public PLMTaskDlvrblData getTask_deliverable() {
		return task_deliverable;
	}

	public void setTask_deliverable(PLMTaskDlvrblData task_deliverable) {
		this.task_deliverable = task_deliverable;
	}

	public PLMBomSpecPartData getBom_part() {
		return bom_part;
	}

	public void setBom_part(PLMBomSpecPartData bom_part) {
		this.bom_part = bom_part;
	}

	public String getRowColor() {
		return rowColor;
	}

	public void setRowColor(String rowColor) {
		this.rowColor = rowColor;
	}

	// OVERRIDEN METHODS ******************************************************
	/**
	 * Returns the BomDeliverable information as a String
	 * 
	 * @return type (String) 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer strBomDeliverable = new StringBuffer();
		
		strBomDeliverable
			.append(chapter.toString()).append("-")
			.append(task_deliverable.toString()).append("-")
			.append(bom_part.toString());
		
		return strBomDeliverable.toString();
	}
	
}
