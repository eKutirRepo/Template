 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMAdminGroupMB.java
 * @Creation date: 17-Jul-2009
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.bean;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.faces.context.FacesContext;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.bean.util.BeanUtil;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.context.PWiContext;
import com.geinfra.geaviation.pwi.data.PLMAdminData;
import com.geinfra.geaviation.pwi.data.PLMAdminReportsData;
import com.geinfra.geaviation.pwi.data.PLMSecurityMatrixData;
import com.geinfra.geaviation.pwi.service.PLMAdminServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;

/**
 * PLMAdminGroupMB is the managed bean class used for PLM groups.
 */
public class PLMAdminGroupMB{
	/**
	 * Holds the Logger
	 */
	private static final Logger LOG = Logger.getLogger(PLMAdminGroupMB.class);

	/**
	 * List of PLMAdmindata.
	 */
	private List<PLMAdminData> listOfGroup = new ArrayList<PLMAdminData>();
	/**
	 * The String of groupID
	 */
	private String gruopId;
	/**
	 * The String of groupName
	 */
	private String groupName = "";
	/**
	 * The String of groupDesc
	 */
	private String groupDesc = "";
	/**
	 * The String of alertStr
	 */
	private String alertStr;
	/**
	 * The String of alert
	 */
	private String alert;
	/**
	 * Object of PLMAdminData
	 */
	private PLMAdminData groupData;
	/**
	 * used for headers in security matrix
	 */
	private List<String> headers = new ArrayList<String>();

	/**
	 * used for headers in security matrix
	 */
	private List<String> headers1 = new ArrayList<String>();
	
	/**
	 * The List of configStatusPop.
	 */
	private List<PLMAdminReportsData> refreshOriList = new ArrayList<PLMAdminReportsData>();
	/**
	 * The List of eccnTagList.
	 */
	private List<String> eccnTagList;
	/**
	 * The List of selectedEccnTagList.
	 */
	
	private List<String> selectedEccnTagList = new ArrayList<String>();

	/**
	 * The int of headerssize
	 */
	private int headerssize;
	/**
	 * The int of headerssize1
	 */
	private int headerssize1;
	/**
	 * The boolean of read
	 */
	private boolean read;
	/**
	 * The boolean of write
	 */
	private boolean write;
	/**
	 * The boolean of delete
	 */
	private boolean delete;
	/**
	 * The String of loggedUser
	 */
	private String loggedUser;
	/**
	 * list of securitymatrix
	 */
	private List<PLMSecurityMatrixData> mainList = new ArrayList<PLMSecurityMatrixData>();
	/**
	 * The int of numOfCol
	 */
	private int numOfCol;
	/**
	 * The int of numOfElement
	 * 
	 */
	private int numOfElement;
	/**
	 * The String of returnValue
	 */
	private String returnValue;
	/**
	 * The String of radioId
	 */
	private String radioId;
	
	/**
	 * Service Handler for PLMAdminServiceIfc
	 */
	public PLMAdminServiceIfc adminServiceIfc;
	
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;

	/* Added for BI Home Page */
	/**
	 * Holds the sortOrder
	 */
	private String sortOrder = "";
	/**
	 * Holds the reportName
	 */ 
	private String reportName = "";
	/**
	 * Holds the reportURL
	 */
	private String reportURL = "";
	/**
	 * Holds the description
	 */
	 private String description ="";
	 /**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the recordCount
	 */
	private int recordCount = 20;
	/**
	 * Holds the selectedReports
	 */
	private String selectedReports = "";
	/**
	 * Holds the oldReportName
	 */
	private String oldReportName;
	/**
	 * Holds the sso_id
	 */
	private String sso_id;
	/**
	 * Holds the alertAdmGrpmsg
	 */
	private String alertAdmGrpmsg;
	/**
	 * Holds the alertConfmsg
	 */
	private String alertConfmsg;
	/**
	 * Holds the alertReportmsg
	 */
	private String alertReportmsg;
	/**
	 * Holds the alertmsgModify
	 */
	private String alertmsgModify = null;
	/**
	 * Holds the duplicateReportNames
	 */
	private boolean duplicateReportNames = false;
	/**
	 * Holds the modifiedSortOrder
	 */
	private String modifiedSortOrder = "";
	/**
	 * Holds the modifiedReportName
	 */
	private String modifiedReportName = "";
	/**
	 * Holds the modifiedDescription
	 */
	private String modifiedDescription = "";
	/**
	 * Holds the modifiedReportURL
	 */
	private String modifiedReportURL = "";
	/**
	 * Holds the modifyFlag
	 */
	private boolean modifyFlag = true;
	/**
	 * Holds the reportData1
	 */
	private PLMAdminReportsData reportData1 = new PLMAdminReportsData();
	/**
	 * Holds the adminHomeFlag
	 */
   private boolean adminHomeFlag;
   /**
	 * Holds the noRecordFlag
	 */
   private boolean noRecordFlag;
   /**
  	 * Holds the biSeqId
  	 */
   private String biSeqId;
   
   private boolean addRptFlg;
   
   private boolean editRptFlg;
 
	/**
	 * List of PLMAdmindata.
	 */
	private List<PLMAdminData> listOfReports = new ArrayList<PLMAdminData>();
	/**
	 * @return the reportData1
	 */
	public PLMAdminReportsData getReportData1() {
		return reportData1;
	}

	/**
	 * @param reportData1 the reportData1 to set
	 */
	public void setReportData1(PLMAdminReportsData reportData1) {
		this.reportData1 = reportData1;
	}

	/**
	 * @return the modifyFlag
	 */
	public boolean isModifyFlag() {
		return modifyFlag;
	}

	/**
	 * @param modifyFlag
	 *            the modifyFlag to set
	 */
	public void setModifyFlag(boolean modifyFlag) {
		this.modifyFlag = modifyFlag;
	}

	/**
	 * @return the alertmsgModify
	 */
	public String getAlertmsgModify() {
		return alertmsgModify;
	}

	/**
	 * @param alertmsgModify
	 *            the alertmsgModify to set
	 */
	public void setAlertmsgModify(String alertmsgModify) {
		this.alertmsgModify = alertmsgModify;
	}

	/**
	 * @return the modifiedSortOrder
	 */
	public String getModifiedSortOrder() {
		return modifiedSortOrder;
	}

	/**
	 * @param modifiedSortOrder
	 *            the modifiedSortOrder to set
	 */
	public void setModifiedSortOrder(String modifiedSortOrder) {
		this.modifiedSortOrder = modifiedSortOrder;
	}

	/**
	 * @return the modifiedReportName
	 */
	public String getModifiedReportName() {
		return modifiedReportName;
	}

	/**
	 * @param modifiedReportName
	 *            the modifiedReportName to set
	 */
	public void setModifiedReportName(String modifiedReportName) {
		this.modifiedReportName = modifiedReportName;
	}

	
	/**
	 * @return the modifiedDescription
	 */
	public String getModifiedDescription() {
		return modifiedDescription;
	}

	/**
	 * @param modifiedDescription the modifiedDescription to set
	 */
	public void setModifiedDescription(String modifiedDescription) {
		this.modifiedDescription = modifiedDescription;
	}

	/**
	 * @return the modifiedReportURL
	 */
	public String getModifiedReportURL() {
		return modifiedReportURL;
	}

	/**
	 * @param modifiedReportURL
	 *            the modifiedReportURL to set
	 */
	public void setModifiedReportURL(String modifiedReportURL) {
		this.modifiedReportURL = modifiedReportURL;
	}

	/**
	 * @return the duplicateReportNames
	 */
	public boolean isDuplicateReportNames() {
		return duplicateReportNames;
	}

	/**
	 * @param duplicateReportNames
	 *            the duplicateReportNames to set
	 */
	public void setDuplicateReportNames(boolean duplicateReportNames) {
		this.duplicateReportNames = duplicateReportNames;
	}

	/**
	 * @return the oldReportName
	 */
	public String getOldReportName() {
		return oldReportName;
	}

	/**
	 * @param oldReportName
	 *            the oldReportName to set
	 */
	public void setOldReportName(String oldReportName) {
		this.oldReportName = oldReportName;
	}

	/**
	 * @return the sso_id
	 */
	public String getSso_id() {
		return sso_id;
	}

	/**
	 * @param sso_id
	 *            the sso_id to set
	 */
	public void setSso_id(String sso_id) {
		this.sso_id = sso_id;
	}

	/**
	 * @return the selectedReports
	 */
	public String getSelectedReports() {
		return selectedReports;
	}

	/**
	 * @param selectedReports
	 *            the selectedReports to set
	 */
	public void setSelectedReports(String selectedReports) {
		this.selectedReports = selectedReports;
	}

	/**
	 * @return the recordCount
	 */
	public int getRecordCount() {
		return recordCount;
	}

	/**
	 * @param recordCount
	 *            the recordCount to set
	 */
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount
	 *            the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	private List<PLMAdminReportsData> adminReportsDataList = new ArrayList<PLMAdminReportsData>();

	/**
	 * @return the sortOrder
	 */
	public String getSortOrder() {
		return sortOrder;
	}
	
	/**
	 * @return the biSeqId
	 */
	public String getBiSeqId() {
		return biSeqId;
	}
	/**
	 * @param biSeqId the biSeqId to set
	 */
	public void setBiSeqId(String biSeqId) {
		this.biSeqId = biSeqId;
	}
	
	public List<PLMAdminData> getListOfReports()  throws PLMCommonException{
		listOfReports = adminServiceIfc.getListOfReports();
		if (listOfReports != null) {
			totalRecCount = listOfReports.size();
			LOG.info("getListOfReports  " + totalRecCount);
		}
		return listOfReports;
	}

	/**
	 * @return the adminReportsDataList
	 * @throws PLMCommonException 
	 */
	public List<PLMAdminReportsData> getAdminReportsDataList() throws PLMCommonException {

		LOG.info("Entering into getAdminReportsDataList");
		alert = null;
		alertAdmGrpmsg = null;
		if (alertmsgModify != null && alertmsgModify.equals(PLMConstants.BI_SUCCESS_EDITED)) {
			alertAdmGrpmsg = alertmsgModify;
			alertmsgModify = null;
		} else {
			alertmsgModify = null;
		}
		sortOrder = null;
		reportName = null;
		reportURL = null;
		description = null;
		modifyFlag = true;
		adminReportsDataList = new ArrayList<PLMAdminReportsData>();
		adminReportsDataList = adminServiceIfc.getReportNames();
		LOG.info("\n\n alertmsgModify --" + alertmsgModify);

		if (adminReportsDataList != null) {
			totalRecCount = adminReportsDataList.size();
			adminHomeFlag = true;
			noRecordFlag = false;
		} else {
			adminHomeFlag = false;
			noRecordFlag = true;
			totalRecCount = 0;
		}

		return adminReportsDataList;
	}

	/**
	 * @param adminReportsDataList
	 *            the adminReportsDataList to set
	 */
	public void setAdminReportsDataList(
			List<PLMAdminReportsData> adminReportsDataList) {
		this.adminReportsDataList = adminReportsDataList;
	}

	/**
	 * @param sortOrder
	 *            the sortOrder to set
	 */
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 * @return the reportName
	 */
	public String getReportName() {
		return reportName;
	}

	/**
	 * @param reportName
	 *            the reportName to set
	 */
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the reportURL
	 */
	public String getReportURL() {
		return reportURL;
	}

	/**
	 * @param reportURL
	 *            the reportURL to set
	 */
	public void setReportURL(String reportURL) {
		this.reportURL = reportURL;
	}

	/**
	 * @return the getAlertAdmGrpmsg
	 */
	public String getAlertAdmGrpmsg() {
		return alertAdmGrpmsg;
	}

	/**
	 * @param alertAdmGrpmsg
	 *            the alertAdmGrpmsg to set
	 */
	public void setAlertAdmGrpmsg(String alertAdmGrpmsg) {
		this.alertAdmGrpmsg = alertAdmGrpmsg;
	}

	
	/**
	 * @return the adminHomeFlag
	 */
	public boolean isAdminHomeFlag() {
		return adminHomeFlag;
	}

	/**
	 * @param adminHomeFlag the adminHomeFlag to set
	 */
	public void setAdminHomeFlag(boolean adminHomeFlag) {
		this.adminHomeFlag = adminHomeFlag;
	}

	/**
	 * @return the noRecordFlag
	 */
	public boolean isNoRecordFlag() {
		return noRecordFlag;
	}

	/**
	 * @param noRecordFlag the noRecordFlag to set
	 */
	public void setNoRecordFlag(boolean noRecordFlag) {
		this.noRecordFlag = noRecordFlag;
	}

	/**
	 * 
	 * Started for BI Home Page
	 */
	
	/**
	 * for Loading Home Page
	 * 
	 * @return String
	 */
	public String getHomePage() {

		try {
			alert = null;
			alertAdmGrpmsg = null;
			if(alertmsgModify != null && alertmsgModify.equals(PLMConstants.BI_SUCCESS_EDITED))
				{
				alertAdmGrpmsg=alertmsgModify;
				alertmsgModify=null;
				} else {
					alertmsgModify=null;
			}
			sortOrder = null;
			reportName = null;
			reportURL = null;
			description = null;
			modifyFlag = true;
			adminReportsDataList = new ArrayList<PLMAdminReportsData>();
			adminReportsDataList = adminServiceIfc.getReportNames();
			LOG.info("\n\n alertmsgModify --"+alertmsgModify);
		} catch (PLMCommonException exception) {
			
			LOG.log(Level.ERROR, "Exception@getHomePage: ", exception);
		}
		if (adminReportsDataList != null) {
			totalRecCount = adminReportsDataList.size();
	   	adminHomeFlag = true;
	   	noRecordFlag = false;
	 	} else {
			adminHomeFlag = false;
			noRecordFlag = true;
			totalRecCount = 0;
		}
		return "homePage";
	}

	/**
	 * for reset of Report Details
	 * 
	 * 
	 */
	public String addNewRptPage() {

		String fwdFlag = "addEditRptPage";
		alertAdmGrpmsg = null;
		sortOrder = null;
		reportName = null;
		reportURL = null;
		alertReportmsg = null;
		alertConfmsg = "";	
		alertmsgModify = null;
		alert = null;
		sortOrder = null;
		reportName = null;
		reportURL = null;
		description = null;
		addRptFlg = true;
		editRptFlg = false;
		return fwdFlag;
	}
	

	public String editRptPage() {

		String fwdFlag = "addEditRptPage";
		alertAdmGrpmsg = null;
		sortOrder = null;
		reportName = null;
		reportURL = null;
		alertReportmsg = null;
		alertConfmsg = "";	
		alert = null;
		alertmsgModify = null;	
		sortOrder = null;
		reportName = null;
		reportURL = null;
		description = null;
		addRptFlg = false;
		editRptFlg = true;
		
		selectedReports = null;
		alertAdmGrpmsg = null;
		modifiedReportName = (String) FacesContext.getCurrentInstance()
		.getExternalContext().getRequestParameterMap().get(
				"reportName");
		
		oldReportName = (String) FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap().get(
						"reportName");
		
		modifiedSortOrder = (String) FacesContext.getCurrentInstance()
		.getExternalContext().getRequestParameterMap().get(
				"sortOrder");
		
		selectedReports = modifiedReportName;
		LOG.info("selectedReports---------->" + selectedReports);
			
		modifiedReportURL = (String) FacesContext.getCurrentInstance()
		.getExternalContext().getRequestParameterMap().get(
				"reportURL");
		
		modifiedDescription = (String) FacesContext.getCurrentInstance()
		.getExternalContext().getRequestParameterMap().get(
				"description");
		
		biSeqId = (String) FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap().get(
						"biSeqId");
		LOG.info("selected BiSeqId---------->" + biSeqId);
		
		return fwdFlag;
	}
	
	/**
	 * for enableButton
	 * 
	 * 
	 */
	public void enableButton() {
		modifyFlag = false;

	}

	/**
	 * for refresh Alert
	 * 
	 *
	 */
	public void refreshAlert() {
		alertAdmGrpmsg = null;
		alert = null;
		alertmsgModify = null;
		selectedReports = null;
		duplicateReportNames = false;

	}


	/**
	 * for adding report in Home Page
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String addReportName() throws PWiException {

		alertAdmGrpmsg = null;
		duplicateReportNames = false;
		sortOrder = sortOrder.trim();
		reportName = reportName.trim();
		reportURL = reportURL.trim();
		description = description.trim();
		alertConfmsg = "";
		alertReportmsg = "";
		addRptFlg = true;
		editRptFlg = false;
		String fwdFlag = "addEditRptPage";
		sso_id = PWiContext.getCurrentInstance().getUserSso();
		LOG.info("Add Report sso_id>>>>>>>>>>>>>>>> " + sso_id);
		if ((PLMConstants.EMPTY_STRING.equals(sortOrder) || PLMConstants.EMPTY_STRING.equals(reportName) || PLMConstants.EMPTY_STRING
						.equals(reportURL)) || PLMConstants.EMPTY_STRING.equals(description)) {
			alertReportmsg = PLMConstants.BI_MANDATORY_EMPTY;
			LOG.info("alertReportmsg-------->" + alertReportmsg);
			return fwdFlag;

		} else {
			PLMAdminReportsData reportData = new PLMAdminReportsData();
			reportData.setSortOrder(Integer.parseInt(sortOrder));
			reportData.setReportName(reportName);
			reportData.setDescription(description);
			reportData.setReportURL(reportURL);
			Iterator<PLMAdminReportsData> it = adminReportsDataList.iterator();
			while (it.hasNext()) {
				PLMAdminReportsData tempData = it.next();
				if (tempData.getReportName().equals(reportData.getReportName())) {
					duplicateReportNames = true;
					alertReportmsg = PLMConstants.BI_RNAME_EXISTING;
					LOG.info("alertReportmsg Same Report Name-------->" + alertReportmsg);
					alertConfmsg = "";
				}
				if (!(tempData.getReportName().equals(reportData.getReportName())) && tempData.getSortOrder() == reportData.getSortOrder()) {
					alertConfmsg = PLMConstants.BI_SORT_UNIQUE;
					LOG.info("alertConfmsg-------->" + alertConfmsg);
					alertReportmsg = "";
					duplicateReportNames = true;
				}
			}
			if (PLMUtils.isEmpty(alertReportmsg) && PLMUtils.isEmpty(alertConfmsg)) {
				
				fwdFlag = addReportConfirmation();
			}
		}
		return fwdFlag;

	}
		
	/**
	 *   for adding report Confirmation in Home Page
	 *   
	 *   @return String
	 */
	public String addReportConfirmation() throws PWiException{
		alertAdmGrpmsg = null;		
		sortOrder=sortOrder.trim();
		reportName=reportName.trim();
		reportURL=reportURL.trim();
		description=description.trim();
		alertConfmsg = null;
		LOG.info("addReportConfirmation------------>" + alertReportmsg);
		sso_id= PWiContext.getCurrentInstance().getUserSso();
		LOG.info("Add Report sso_id>>>>>>>>>>>>>>>> "+sso_id);
		String fwdFlag = "adminrptlinks";
		try {
			PLMAdminReportsData reportData = new PLMAdminReportsData();
			reportData.setSortOrder(Integer.parseInt(sortOrder));
			reportData.setReportName(reportName);
			reportData.setDescription(description);
			reportData.setReportURL(reportURL);
			adminServiceIfc.addReportData(reportData, sso_id);
			setSortOrder(null);
			setReportName(null);
			setDescription(null);
			setReportURL(null);
			adminReportsDataList = new ArrayList<PLMAdminReportsData>();
			adminReportsDataList = adminServiceIfc.getReportNames();
			totalRecCount = adminReportsDataList.size();
			alertAdmGrpmsg = PLMConstants.BI_SUCCESS_ADDED;
			LOG.info("alertmsg----addReportConfirmation-------->" + alertAdmGrpmsg);
		}catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@addReportConfirmation: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"adminrptlinks","Admin Home Page");
			return fwdFlag;
		}
		
		return fwdFlag;
	}
	
	
	/**
	 * for refresh the report
	 * 
	 * @return String
	 */
	
	public String refreshReport() {
		LOG.info("refreshReport------>");
		adminReportsDataList =	refreshOriList;
		return "";
	}
	
	/**
	 *  for modify report Data in Home page
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String modifyReportData() throws PWiException {
		String fwdFlag = "addEditRptPage";
		duplicateReportNames = false;
		sso_id = PWiContext.getCurrentInstance().getUserSso();
		LOG.info("Update Report sso_id>>>>>>>>>>>>>>>> "+sso_id);
		modifiedReportName=modifiedReportName.trim();
		modifiedReportURL=modifiedReportURL.trim();
		modifiedDescription=modifiedDescription.trim();
		modifiedSortOrder=modifiedSortOrder.trim();
		alertConfmsg = null;
		alertReportmsg = "";
		alertmsgModify = null;
		refreshOriList = new ArrayList<PLMAdminReportsData>(adminReportsDataList);
		alertAdmGrpmsg = null;
		alertmsgModify = null;
		addRptFlg = false;
		editRptFlg = true;
	
		if ((PLMConstants.EMPTY_STRING.equals(modifiedReportName)
				|| PLMConstants.EMPTY_STRING.equals(modifiedReportURL) || PLMConstants.EMPTY_STRING
				.equals(modifiedSortOrder)|| PLMConstants.EMPTY_STRING
				.equals(modifiedDescription))) {
			alertReportmsg = PLMConstants.BI_MANDATORY_EMPTY;
			return fwdFlag;
		} else {
			PLMAdminReportsData modifiedReportData = new PLMAdminReportsData();
			modifiedReportData.setReportName(modifiedReportName);
			modifiedReportData.setReportURL(modifiedReportURL);
			modifiedReportData.setDescription(modifiedDescription);
			modifiedReportData.setSortOrder(Integer.parseInt(modifiedSortOrder));
			
			Iterator<PLMAdminReportsData> it = adminReportsDataList.iterator();
			while (it.hasNext()) {
				PLMAdminReportsData tempData = it.next();
				LOG.info("selectedReports--------->>" +selectedReports);
				if (tempData.getReportName().equals(selectedReports)) {
					reportData1 = tempData;
					break;
				}
			}
			List<PLMAdminReportsData> tempList = adminReportsDataList;
			tempList.remove(reportData1);
			
			Iterator<PLMAdminReportsData> it1 = tempList.iterator();
			while (it1.hasNext()) {
				PLMAdminReportsData tempData = it1.next();
				
				if (tempData.getReportName().equals(modifiedReportData.getReportName())){
					
					alertReportmsg = PLMConstants.BI_RNAME_EXISTING;
					LOG.info("alertReportmsg------->" + alertReportmsg);
					duplicateReportNames = true;
							
				}
				if ((tempData.getSortOrder()==
								modifiedReportData.getSortOrder())) {
					alertConfmsg = PLMConstants.BI_SORT_UNIQUE;
					LOG.info("alertConfmsg------->" + alertConfmsg);
					duplicateReportNames = true;
				}

			}
			if (PLMUtils.isEmpty(alertReportmsg) && PLMUtils.isEmpty(alertConfmsg)) {
				
				fwdFlag = modifyConfReportData();
			}
			
		
		}
		return fwdFlag;
	}
	
	/**
	 * for modifying report Confirmation
	 * 
	 * @return String
	 */

	public String modifyConfReportData() throws PWiException {
		String fwdFlag = "adminrptlinks";
		LOG.info("modifyConfReportData------->>");	
		PLMAdminReportsData modifiedReportData = new PLMAdminReportsData();
		modifiedReportData.setReportName(modifiedReportName);
		modifiedReportData.setReportURL(modifiedReportURL);
		modifiedReportData.setSortOrder(Integer.parseInt(modifiedSortOrder));
		modifiedReportData.setDescription(modifiedDescription);
		LOG.info("oldReportName------->>" + oldReportName);	
		sso_id = PWiContext.getCurrentInstance().getUserSso();
		LOG.info("Update Report sso_id>>>>>>>>>>>>>>>> "+sso_id);
		try {
			adminServiceIfc.modifyReportData(modifiedReportData,
					oldReportName, sso_id);
			alertAdmGrpmsg = PLMConstants.BI_SUCCESS_EDITED;
			adminReportsDataList = new ArrayList<PLMAdminReportsData>();
			adminReportsDataList = adminServiceIfc.getReportNames();
			totalRecCount = adminReportsDataList.size();
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@modifyConfReportData: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"adminrptlinks","Maintain BI Home Page");
			return fwdFlag;
		}
		return fwdFlag;
	}

	/**
	 * for deleting report in Home Page
	 * 
	 * @return String
	 */
	public String deleteReportData() {
		alertAdmGrpmsg = null;
		LOG.info("deleteReportData------->" + selectedReports);
		/*PLMAdminReportsData reportData = new PLMAdminReportsData();
		reportData.setReportName(selectedReports);*/

		try {
			adminServiceIfc.deleteReportData(selectedReports);
			adminReportsDataList = new ArrayList<PLMAdminReportsData>();
			adminReportsDataList = adminServiceIfc.getReportNames();
			totalRecCount = adminReportsDataList.size();
			alertAdmGrpmsg=PLMConstants.BI_SUCCESS_DELETED;
			
		} catch (PLMCommonException exception) {
			
			LOG.log(Level.ERROR, "Exception@deleteReportData: ", exception);
		}
		return "";
	}

	/**
	 * for pre modify report in Home Page
	 * 
	 * @return String
	 */
	public String modifyReport() {
		selectedReports = null;
		alertAdmGrpmsg = null;
		modifiedReportName = (String) FacesContext.getCurrentInstance()
		.getExternalContext().getRequestParameterMap().get(
				"reportName");
		
		oldReportName = (String) FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap().get(
						"reportName");
		
		modifiedSortOrder = (String) FacesContext.getCurrentInstance()
		.getExternalContext().getRequestParameterMap().get(
				"sortOrder");
		
		selectedReports = modifiedReportName;
		LOG.info("selectedReports---------->" + selectedReports);
			
		modifiedReportURL = (String) FacesContext.getCurrentInstance()
		.getExternalContext().getRequestParameterMap().get(
				"reportURL");
		
		modifiedDescription = (String) FacesContext.getCurrentInstance()
		.getExternalContext().getRequestParameterMap().get(
				"description");
		
		biSeqId = (String) FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap().get(
						"biSeqId");
		LOG.info("selected BiSeqId---------->" + biSeqId);
		return "";

	}

	/**
	 * 
	 * Ended for BI Home Page
	 */

	/**
	 * @return java.lang.String For getting the list of groups
	 */
	
	/*public String getListOfGroups() {
		returnValue = PLMConstants.EMPTY_STRING;
		try {
			 LOG.info("came to MB");
			read = false;
			write = false;
			delete = false;
			String screenName = PLMUtils.getRequestParameter("screenName");
			 LOG.info("screenName---" + screenName);
			if (PLMUtils.getServletSession(true).getAttribute("USER_DATA") != null) {
				loggedUser = userDataObj.getUserSsoId();
				Map<String, List<String>> permDetails = userDataObj
						.getSecurityMatrix();
				List<String> permNames = permDetails.get(screenName);
				if (permNames.contains(PLMUtils
						.getMessage(PLMConstants.PEMISSION_READ))) {
					read = true;
				}
				if (permNames.contains(PLMUtils
						.getMessage(PLMConstants.PEMISSION_WRITE))) {
					write = true;
				}
				if (permNames.contains(PLMUtils
						.getMessage(PLMConstants.PEMISSION_DELETE))) {
					delete = true;
				}
			}

			listOfGroup = adminServiceIfc.getListOfGroups();
			returnValue = "showgroups";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getListOfGroups: ", exception);
			returnValue = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Maintain Groups");
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@getListOfGroups: ", exception);
			returnValue = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Maintain Groups");
		}
		return returnValue;
	}*/

	/**
	 * @return java.lang.String For the use of Export to Excel.
	 */
	
	public String getExportListOfGroups() {
		returnValue = PLMConstants.EMPTY_STRING;
		try {
			listOfGroup = adminServiceIfc.getListOfGroups();
			returnValue = "showgroupsExcel";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getExportListOfGroups: ", exception);
			returnValue = PLMUtils.setCommonException(exception.getMessage(),commonMB,"showgroups","Maintain Groups");
		}
		return returnValue;

	}

	/**
	 * @return java.lang.String For getting the security matrix for existing
	 *         group
	 */
	public String getGroupPermissions() throws PLMCommonException {
		returnValue = PLMConstants.EMPTY_STRING;
		try {
			mainList.clear();
			numOfCol = 0;
			numOfElement = 0;
			gruopId = (String) FacesContext.getCurrentInstance()
					.getExternalContext().getRequestParameterMap().get(
							"groupID");
			for (PLMAdminData test : listOfGroup) {
				if (test.getGruopId().equals(gruopId)) {
					groupName = test.getGroupName();
					groupDesc = test.getGroupDescription();
				}
			}

			mainList = adminServiceIfc.getGroupPermissions(gruopId);
		
			numOfElement = mainList.size();
			numOfCol = 0;
			for (PLMSecurityMatrixData data : mainList) {
				if (data.isHeader()) {
					numOfCol++;
				}
			}
			returnValue = PLMConstants.EMPTY_STRING;
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getGroupPermissions: ", exception);
			PLMUtils.setCommonException(exception.getMessage(),commonMB,"showgroups","Maintain Groups");
			throw exception;
		} 
		return returnValue;
	}

	/**
	 * @return java.lang.String For getting the security matrix for a new group
	 */
	public String addGroup() throws PLMCommonException {
		returnValue = PLMConstants.EMPTY_STRING;
		try {
			mainList.clear();
			groupName = PLMConstants.EMPTY_STRING;
			groupDesc = PLMConstants.EMPTY_STRING;
			numOfCol = 0;
			numOfElement = 0;

			mainList = adminServiceIfc.addGroup();

			numOfElement = mainList.size();
			for (PLMSecurityMatrixData data : mainList) {
				if (data.isHeader()) {
					numOfCol++;
				}
			}
			returnValue = PLMConstants.EMPTY_STRING;
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@addGroup: ", exception);
			PLMUtils.setCommonException(exception.getMessage(),commonMB,"showgroups","Maintain Groups");
			throw exception;
		}	
		return returnValue;
	}

	/**
	 * @return java.lang.String For saving the data for a new group
	 */
	public String groupAdd() throws PLMCommonException {
		try {

			if (((groupName.trim()).length() > 0)
					|| ((groupDesc.trim()).length() > 0)) {
				if (((groupName.trim()).length() > 0)) {
					if ((groupDesc.trim()).length() > 0) {
						if ((PLMUtils.isHtmlIndependent(groupName))) {
							LOG.info("GroupNAme and Group Desc" + groupName
									+ "----------------" + groupDesc);
							ArrayList<PLMSecurityMatrixData> securityData = null;
							// int length = mainList.size();
							PLMSecurityMatrixData col = null;
							for (PLMSecurityMatrixData temp : mainList) {

								if (temp.getAccessID() != 0
										&& !temp.isHeader()
										&& !(temp.getOutputValue()
												.equalsIgnoreCase("NA"))) {
									col = new PLMSecurityMatrixData();
									col.setScreenId(temp.getPermissionIdNew());
									col.setPermissionId(temp.getAccessID());
									if (temp.isCheckValue()) {
										col.setAccessInd(PLMConstants.YES);
									} else {
										col.setAccessInd(PLMConstants.NOO);
									}
									if (securityData == null) {
										securityData = new ArrayList<PLMSecurityMatrixData>();
									}
									securityData.add(col);
								}
							}
							boolean result = adminServiceIfc.groupAdd(
									groupName, groupDesc, securityData,
									PLMConstants.YES, loggedUser);
							if (result) {
								alertStr = groupName + " "
										+ PLMConstants.GROUP_ADDED;
								listOfGroup = adminServiceIfc.getListOfGroups();
							} else {
								alert = PLMConstants.GROUP_EXISTS;
								returnValue = PLMConstants.EMPTY_STRING;
							}

							returnValue = PLMConstants.EMPTY_STRING;
						} else {
							alert = "Please enter a valid group name, special characters are not allowed";
							returnValue = PLMConstants.EMPTY_STRING;
						}

					} else {
						alert = PLMConstants.GROUP_DESCRIPTION;
						returnValue = PLMConstants.EMPTY_STRING;
					}
				} else {
					alert = PLMConstants.GROUP_NAME_ALERT;
					returnValue = PLMConstants.EMPTY_STRING;
				}
			} else {

				alert = PLMConstants.GROUP_NAME_DESCRIPTION_ALERT;
				returnValue = PLMConstants.EMPTY_STRING;
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@groupAdd: ", exception);
			PLMUtils.setCommonException(exception.getMessage(),commonMB,"showgroups","Maintain Groups");
			throw exception;
		} 
		return returnValue;
	}

	/**
	 * 
	 * @return java.lang.String For deleting a group.
	 */
	public String deleteGroup() throws PLMCommonException {
		try {
			String groupNm = PLMConstants.EMPTY_STRING;
			LOG.info("-in Groupname is-" + groupNm);
			if (radioId != null && !PLMConstants.EMPTY_STRING.equals(radioId)) {
				gruopId = radioId;
				// PLMAdminData sum=new PLMAdminData();
				for (PLMAdminData sum : listOfGroup) {
					if (sum.getGruopId().equals(gruopId)) {
						groupNm = sum.getGroupName();
					}

				}
				radioId = PLMConstants.EMPTY_STRING;
				boolean result = adminServiceIfc.deleteGroup(gruopId);
				if (result) {
					listOfGroup = adminServiceIfc.getListOfGroups();
					alertStr = groupNm + PLMConstants.DELETE_CONFIRMATION;
				} else {
					alert = PLMConstants.USERS_ASSOCIATED;
					returnValue = PLMConstants.EMPTY_STRING;
				}
			} else {
				alert = PLMConstants.DELETE_REQUEST;
				returnValue = PLMConstants.EMPTY_STRING;
			}

		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@deleteGroup: ", exception);
			PLMUtils.setCommonException(exception.getMessage(),commonMB,"showgroups","Maintain Groups");
			throw exception;
		}  
		return returnValue;
	}

	/**
	 * @return java.lang.String For saving the data for a existing group
	 */
	public String updateGroup() throws PLMCommonException {
		try {
			if (((groupName.trim()).length() > 0)
					|| ((groupDesc.trim()).length() > 0)) {
				if ((groupName.trim()).length() > 0) {
					if ((groupDesc.trim()).length() > 0) {
						// int x = 0;

						ArrayList<PLMSecurityMatrixData> securityData = null;
						// int length = mainList.size();
						PLMSecurityMatrixData col = null;
						for (PLMSecurityMatrixData temp : mainList) {

							if (temp.getAccessID() != 0
									&& !temp.isHeader()
									&& !(temp.getOutputValue()
											.equalsIgnoreCase(PLMConstants.NOT_APPLICABLE))) {
								col = new PLMSecurityMatrixData();
								int groupInt = Integer.parseInt(gruopId);
								col.setGroupId(groupInt);
								col.setScreenId(temp.getPermissionIdNew());
								col.setPermissionId(temp.getAccessID());
								if (temp.isCheckValue()) {
									col.setAccessInd(PLMConstants.YES);
								} else {
									col.setAccessInd(PLMConstants.NOO);
								}

								if (securityData == null) {
									securityData = new ArrayList<PLMSecurityMatrixData>();
								}
								securityData.add(col);
							}

						}
						
						boolean result = adminServiceIfc.updateGroup(groupName,
								groupDesc, securityData, PLMConstants.NOO,
								loggedUser);
						if (result != true) {
							alertStr = PLMConstants.CHANGES_GROUP + groupName
									+ PLMConstants.HAVE_SAVED;
						}
						listOfGroup = adminServiceIfc.getListOfGroups();

						returnValue = PLMConstants.EMPTY_STRING;
					} else {
						alert = PLMConstants.GROUP_DESCRIPTION;
						returnValue = PLMConstants.EMPTY_STRING;
					}
				}

				else {
					alert = PLMConstants.GROUP_NAME_ALERT;
					returnValue = PLMConstants.EMPTY_STRING;
				}
			} else {
				alert = PLMConstants.GROUP_NAME_DESCRIPTION_ALERT;
				returnValue = PLMConstants.EMPTY_STRING;
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@updateGroup: ", exception);
			PLMUtils.setCommonException(exception.getMessage(),commonMB,"showgroups","Maintain Groups");
			throw exception;
		} 
		return returnValue;
	}
	
	
	

	/**
	 * 
	 * @return the listOfGroup
	 */
	public List<PLMAdminData> getListOfGroup() {
		return listOfGroup;
	}

	/**
	 * @param listOfGroup
	 *            the listOfGroup to set
	 */
	public void setListOfGroup(List<PLMAdminData> listOfGroupa) {
		this.listOfGroup = listOfGroupa;
	}

	/**
	 * @return the headers1
	 */
	public List<String> getHeaders1() {
		return headers1;
	}

	/**
	 * @param headers1
	 *            the headers1 to set
	 */
	public void setHeaders1(List<String> headers1a) {
		this.headers1 = headers1a;
	}

	/**
	 * @return the headerssize1
	 */
	public int getHeaderssize1() {
		return headerssize1;
	}

	/**
	 * @param headerssize1
	 *            the headerssize1 to set
	 */
	public void setHeaderssize1(int headerssize1a) {
		this.headerssize1 = headerssize1a;
	}

	/**
	 * @return the headerssize
	 */
	public int getHeaderssize() {
		return headerssize;
	}

	/**
	 * @param headerssize
	 *            the headerssize to set
	 */
	public void setHeaderssize(int headerssizea) {
		this.headerssize = headerssizea;
	}

	/**
	 * @return the headers
	 */
	public List<String> getHeaders() {
		return headers;
	}

	/**
	 * @param headers
	 *            the headers to set
	 */
	public void setHeaders(List<String> headersa) {
		this.headers = headersa;
	}

	/**
	 * @return the groupData
	 */
	public PLMAdminData getGroupData() {
		return groupData;
	}

	/**
	 * @param groupData
	 *            the groupData to set
	 */
	public void setGroupData(PLMAdminData groupDataa) {
		this.groupData = groupDataa;
	}

	/**
	 * @return the gruopId
	 */
	public String getGruopId() {
		return gruopId;
	}

	/**
	 * @param gruopId
	 *            the gruopId to set
	 */
	public void setGruopId(String gruopIda) {
		this.gruopId = gruopIda;
	}

	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * @param groupName
	 *            the groupName to set
	 */
	public void setGroupName(String groupNamea) {
		this.groupName = groupNamea;
	}

	/**
	 * @return the groupDesc
	 */
	public String getGroupDesc() {
		return groupDesc;
	}

	/**
	 * @param groupDesc
	 *            the groupDesc to set
	 */
	public void setGroupDesc(String groupDesca) {
		this.groupDesc = groupDesca;
	}

	/**
	 * @return the alertStr
	 */
	public String getAlertStr() {

		String temp = null;
		temp = alertStr;
		alertStr = PLMConstants.EMPTY_STRING;
		return temp;
	}

	/**
	 * @param alertStr
	 *            the alertStr to set
	 */
	public void setAlertStr(String alertStra) {
		this.alertStr = alertStra;
		LOG.info("alertStr-------" + alertStr);
	}

	/**
	 * @return the read
	 */
	public boolean isRead() {
		return read;
	}

	/**
	 * @param read
	 *            the read to set
	 */
	public void setRead(boolean reada) {
		this.read = reada;
	}

	/**
	 * @return the write
	 */
	public boolean isWrite() {
		return write;
	}

	/**
	 * @param write
	 *            the write to set
	 */
	public void setWrite(boolean writea) {
		this.write = writea;
	}

	/**
	 * @return the delete
	 */
	public boolean isDelete() {
		return delete;
	}

	/**
	 * @param delete
	 *            the delete to set
	 */
	public void setDelete(boolean deletea) {
		this.delete = deletea;
	}

	/**
	 * @return the loggedUser
	 */
	public String getLoggedUser() {
		return loggedUser;
	}

	/**
	 * @param loggedUser
	 *            the loggedUser to set
	 */
	public void setLoggedUser(String loggedUsera) {
		this.loggedUser = loggedUsera;
	}

	/**
	 * @return the alert
	 */
	public String getAlert() {
		String temp = null;
		temp = alert;
		alert = PLMConstants.EMPTY_STRING;
		return temp;

	}

	/**
	 * @param alert
	 *            the alert to set
	 */
	public void setAlert(String alera) {
		this.alert = alera;
	}

	/**
	 * @return the numOfCol
	 */
	public int getNumOfCol() {
		return numOfCol;
	}

	/**
	 * @param numOfCol
	 *            the numOfCol to set
	 */
	public void setNumOfCol(int numOfCola) {
		this.numOfCol = numOfCola;
	}

	/**
	 * @return the numOfElement
	 */
	public int getNumOfElement() {
		return numOfElement;
	}

	/**
	 * @param numOfElement
	 *            the numOfElement to set
	 */
	public void setNumOfElement(int numOfElementa) {
		this.numOfElement = numOfElementa;
	}

	/**
	 * @return the mainList
	 */
	public List<PLMSecurityMatrixData> getMainList() {
		return mainList;
	}

	/**
	 * @param mainList
	 *            the mainList to set
	 */
	public void setMainList(List<PLMSecurityMatrixData> mainLista) {
		this.mainList = mainLista;
	}

	/**
	 * @return the radioId
	 */
	public String getRadioId() {
		String temp = null;
		temp = radioId;
		radioId = PLMConstants.EMPTY_STRING;
		return temp;
	}

	/**
	 * @return
	 */
	public String clearGroupValue() {
		radioId = PLMConstants.EMPTY_STRING;
		return PLMConstants.EMPTY_STRING;
	}

	/**
	 * @param radioId
	 *            the radioId to set
	 */
	public void setRadioId(String radioIda) {
		this.radioId = radioIda;
	}
	
	/**
	 * @return adminServiceIfc
	 */
	public PLMAdminServiceIfc getAdminServiceIfc() {
		return adminServiceIfc;
	}

	/**
	 * @param adminServiceIfc
	 */
	public void setAdminServiceIfc(PLMAdminServiceIfc objAdminServiceIfc) {
		this.adminServiceIfc = objAdminServiceIfc;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	
	public List<String> getEccnTagList() {
		return eccnTagList;
	}

	public void setEccnTagList(List<String> eccnTagList) {
		this.eccnTagList = eccnTagList;
	}
	
	public List<String> getSelectedEccnTagList() {
		return selectedEccnTagList;
	}

	public void setSelectedEccnTagList(List<String> selectedEccnTagList) {
		this.selectedEccnTagList = selectedEccnTagList;
	}

	/**
	 * @return the alertConfmsg
	 */
	public String getAlertConfmsg() {
		return alertConfmsg;
	}

	/**
	 * @param alertConfmsg the alertConfmsg to set
	 */
	public void setAlertConfmsg(String alertConfmsg) {
		this.alertConfmsg = alertConfmsg;
	}

	/**
	 * @return the alertReportmsg
	 */
	public String getAlertReportmsg() {
		return alertReportmsg;
	}

	/**
	 * @param alertReportmsg the alertReportmsg to set
	 */
	public void setAlertReportmsg(String alertReportmsg) {
		this.alertReportmsg = alertReportmsg;
	}

	
	/**
	 * @return the addRptFlg
	 */
	public boolean isAddRptFlg() {
		return addRptFlg;
	}

	
	/**
	 * @param addRptFlg the addRptFlg to set
	 */
	public void setAddRptFlg(boolean addRptFlg) {
		this.addRptFlg = addRptFlg;
	}

	
	/**
	 * @return the editRptFlg
	 */
	public boolean isEditRptFlg() {
		return editRptFlg;
	}

	
	/**
	 * @param editRptFlg the editRptFlg to set
	 */
	public void setEditRptFlg(boolean editRptFlg) {
		this.editRptFlg = editRptFlg;
	}

	
}
