/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMTC5FullBomRptData.java
 * @Creation date: 27-April-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMTC5FullBomRptData {
	/**
	 * Holds the lvlBomDoc
	 */
	private String lvlBomDoc;
	/**
	 * Holds the idRepere
	 */
	private String idRepere;
	/**
	 * Holds the qty
	 */
	private String qty;
	/**
	 * Holds the uomDosType
	 */
	private String uomDosType;
	/**
	 * Holds the objName
	 */
	private String objName;
	/**
	 * Holds the objRev
	 */
	private String objRev;
	/**
	 * Holds the frDescription
	 */
	private String frDescription;
	/**
	 * Holds the enDescription
	 */
	private String enDescription;
	/**
	 * Holds the structure
	 */
	private String structure;
	/**
	 * @return the lvlBomDoc
	 */
	public String getLvlBomDoc() {
		return lvlBomDoc;
	}
	/**
	 * @param lvlBomDoc the lvlBomDoc to set
	 */
	public void setLvlBomDoc(String lvlBomDoc) {
		this.lvlBomDoc = lvlBomDoc;
	}
	/**
	 * @return the idRepere
	 */
	public String getIdRepere() {
		return idRepere;
	}
	/**
	 * @param idRepere the idRepere to set
	 */
	public void setIdRepere(String idRepere) {
		this.idRepere = idRepere;
	}
	/**
	 * @return the qty
	 */
	public String getQty() {
		return qty;
	}
	/**
	 * @param qty the qty to set
	 */
	public void setQty(String qty) {
		this.qty = qty;
	}
	/**
	 * @return the uomDosType
	 */
	public String getUomDosType() {
		return uomDosType;
	}
	/**
	 * @param uomDosType the uomDosType to set
	 */
	public void setUomDosType(String uomDosType) {
		this.uomDosType = uomDosType;
	}
	/**
	 * @return the objName
	 */
	public String getObjName() {
		return objName;
	}
	/**
	 * @param objName the objName to set
	 */
	public void setObjName(String objName) {
		this.objName = objName;
	}
	/**
	 * @return the objRev
	 */
	public String getObjRev() {
		return objRev;
	}
	/**
	 * @param objRev the objRev to set
	 */
	public void setObjRev(String objRev) {
		this.objRev = objRev;
	}
	/**
	 * @return the frDescription
	 */
	public String getFrDescription() {
		return frDescription;
	}
	/**
	 * @param frDescription the frDescription to set
	 */
	public void setFrDescription(String frDescription) {
		this.frDescription = frDescription;
	}
	/**
	 * @return the enDescription
	 */
	public String getEnDescription() {
		return enDescription;
	}
	/**
	 * @param enDescription the enDescription to set
	 */
	public void setEnDescription(String enDescription) {
		this.enDescription = enDescription;
	}
	/**
	 * @return the structure
	 */
	public String getStructure() {
		return structure;
	}
	/**
	 * @param structure the structure to set
	 */
	public void setStructure(String structure) {
		this.structure = structure;
	}

}
