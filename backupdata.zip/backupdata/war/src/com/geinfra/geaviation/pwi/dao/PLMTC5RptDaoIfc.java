/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMTC5RptDaoIfc.java
 * @Creation date: 27-April-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.data.PLMTC5FullBomRptData;
import com.geinfra.geaviation.pwi.data.PLMTC5MliRptData;
import com.geinfra.geaviation.pwi.data.PLMTC5RelationsRptData;
import com.geinfra.geaviation.pwi.data.PLMTC5WhUsedRptData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMTC5RptDaoIfc {
	/**
	 * This method is used to get TC5 Relation Report data
	 * 
	 * @param tc5Code,selRevision
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTC5RelationsRptData> getTC5RelationRpt(String tc5Code,String selRevision)throws PLMCommonException;
	
	/**
	 * This methods is used get TC5 MLI Report data
	 * 
	 * @param searchResultsQry
	 * @return List
	 * throws PLMCommonException
	 */
	public List<PLMTC5MliRptData> getTC5MLIReport(String finalQuery, PLMTC5MliRptData searchData)throws PLMCommonException;
	/**
	 * This method is used to get TC5 Full BOM data
	 * 
	 * @param searchData
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTC5FullBomRptData> getTC5FullBomReport(String tc5CodeFullBom,String bomLevel,boolean allBomLvlFlg,
			String refDocLevel,boolean allRefDocLvlFlg,boolean includeDefFlag)throws PLMCommonException;
	
	/**
	 * This methods is used getTC5WhUsedRpt
	 * 
	 * @param partDocNumLcl
	 * @return List<PLMTC5WhUsedRptData>
	 * throws PLMCommonException
	 */
	public List<PLMTC5WhUsedRptData> getTC5WhUsedRpt(String partDocNumLcl)throws PLMCommonException;
}
