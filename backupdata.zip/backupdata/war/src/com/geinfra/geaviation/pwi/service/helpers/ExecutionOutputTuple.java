/**
 * 
 */
package com.geinfra.geaviation.pwi.service.helpers;

import com.geinfra.geaviation.pwi.model.TemplateVO;
import com.geinfra.geaviation.pwi.service.vo.ExecutionMode;
import com.geinfra.geaviation.pwi.service.vo.OutputType;

/**
*
* Project      : Product Lifecycle Management Intelligence
* Date Written : September 23, 2011
* Security     : GE Confidential
* Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
* Copyright(C) 2013 GE All rights reserved
*
* Description :
*
* Revision Log September 23, 2011 | v1.0.
* --------------------------------------------------------------
*/
public class ExecutionOutputTuple {
	private ExecutionMode executionMode;
	private OutputType outputType;
	private TemplateVO template;

	public ExecutionOutputTuple(ExecutionMode executionMode,
			OutputType outputType, TemplateVO template) {
		this.executionMode = executionMode;
		this.outputType = outputType;
		this.template = template;
	}

	public ExecutionMode getExecutionMode() {
		return executionMode;
	}

	public OutputType getOutputType() {
		return outputType;
	}

	public TemplateVO getTemplate() {
		return template;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("(");
		builder.append(executionMode.toString());
		builder.append(", ");
		builder.append(outputType.toString());
		builder.append(", ");
		builder.append(template);
		builder.append(")");
		return builder.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((executionMode == null) ? 0 : executionMode.hashCode());
		result = prime * result
				+ ((outputType == null) ? 0 : outputType.hashCode());
		result = prime * result
				+ ((template == null) ? 0 : template.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExecutionOutputTuple other = (ExecutionOutputTuple) obj;
		if (executionMode == null) {
			if (other.executionMode != null)
				return false;
		} else if (!executionMode.equals(other.executionMode))
			return false;
		if (outputType == null) {
			if (other.outputType != null)
				return false;
		} else if (!outputType.equals(other.outputType))
			return false;
		if (template == null) {
			if (other.template != null)
				return false;
		} else if (!template.equals(other.template))
			return false;
		return true;
	}
}