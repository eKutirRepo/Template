package com.geinfra.geaviation.pwi.common;

/**
 * 
 * Project        :   Product Lifecycle Management
 * Date Written   :   Aug 5, 2010
 * Security       :   GE Confidential
 * Restrictions   :   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 * Copyright(C) 2010 GE 
 * All rights reserved
 *
 * Description    :  RecordStatus - bean representation for comparison status.
 *
 * Revision Log Aug 5, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public enum RecordStatus {
	Equal("Equal"), Deleted("Deleted"), New("New"), Updated("Updated");

	private String status;

	RecordStatus(String st) {
		this.status = st;
	}

	String getStatus() {
		return this.status;
	}
}
