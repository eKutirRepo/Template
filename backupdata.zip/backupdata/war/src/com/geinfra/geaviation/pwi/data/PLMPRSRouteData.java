/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMPRSRouteData.java
 * @Creation date: 11-Sept-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMPRSRouteData {

	
	// PROPERTIES *************************************************************

	private String id;
	
	private String name;
	
	private String status;

	private String dueDate;
	
	private String description;
	
	private String owner;
	
	private String stateCondition;
	
	private String color;
	
	
	// CONSTRUCTOR ************************************************************
	public PLMPRSRouteData (String id, 
						String name,
						String status, 
						String dueDate, 
						String description,
						String owner,
						String stateCondition,
						String color) {  
		this.id = id;
		this.name = name;
		this.status = status;
		this.dueDate = dueDate;
		this.description = description;
		this.owner = owner;
		this.stateCondition = stateCondition;
		this.color = color;
	}
	
	// ACCESSOR METHODS *******************************************************
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getStateCondition() {
		return stateCondition;
	}

	public void setStateCondition(String stateCondition) {
		this.stateCondition = stateCondition;
	}

	
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	// OVERRIDEN METHODS ******************************************************
	/**
	 * Returns the SalesOrder information as a String
	 * 
	 * @return type (String) 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer strSalesOrder = new StringBuffer();
		
		strSalesOrder
			.append(id).append(" ")
			.append(name).append(" ")
			.append(status).append(" ")
			.append(dueDate).append(" ")
			.append(description).append(" ")
			.append(owner).append(" ")
			.append(stateCondition).append(" ")
			.append(color).append(" ")
			;
		
		return strSalesOrder.toString();
	}
	
}
