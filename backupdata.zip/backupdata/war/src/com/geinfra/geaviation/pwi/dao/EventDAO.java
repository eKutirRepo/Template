package com.geinfra.geaviation.pwi.dao;

import java.util.Date;
import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.MinimalQueryExctnEventVO;
import com.geinfra.geaviation.pwi.model.PWiQueryExctnEventVO;
import com.geinfra.geaviation.pwi.service.QuerySubmissionService.EventStatus;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 5, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Data access object interface for execution events.
 * 
 * Revision Log Aug 5, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public interface EventDAO {

	public PWiQueryExctnEventVO getExecutionEventById(Integer eventId);

	/**
	 * Finds the most recent execution events run by the specified SSO ordered
	 * with the most recent first.
	 * 
	 * @param ssoId
	 * @param limit
	 *            max number of events to return
	 * @return the execution events
	 */
	public List<MinimalQueryExctnEventVO> getExecutionEvents(String ssoId,
			int limit);

	/**
	 * Finds all execution events run by the specified SSO since the specified
	 * date ordered with the most recent events coming first.
	 * 
	 * @param ssoId
	 * @param dateRunSince
	 * @return the execution events
	 */
	public List<MinimalQueryExctnEventVO> getExecutionEventsRunSince(
			String ssoId, Date dateRunSince);

	public Integer insertExecutionEvent(PWiQueryExctnEventVO event)
			throws PWiException;

	public PWiQueryExctnEventVO getNextBatchExecutionQuery();

	public List<MinimalQueryExctnEventVO> getExecutionEventForUserByStatus(
			String sso, EventStatus eventStatus);

	public boolean updateExecutionEventStatus(String status,
			Integer eventSeqId, Integer colCnt, Integer rowCnt, long duration);

	public boolean updateExecutionEventStatus(String status, Integer eventSeqId);

	public boolean renewQry(Integer eventSeqId);
	

	public int getNoOfQueryInPipe();
}
