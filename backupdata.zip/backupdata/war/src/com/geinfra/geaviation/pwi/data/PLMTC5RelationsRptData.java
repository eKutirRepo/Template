/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMTC5RelationsRptData.java
 * @Creation date: 27-April-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;

public class PLMTC5RelationsRptData {
	/**
	 * Hold frmType
	 */
	private String frmType;
	/**
	 * Hold frmVersion
	 */
	private String frmVersion;
	/**
	 * Hold frmIdentifier
	 */
	private String frmIdentifierId;
	/**
	 * Hold frmIdentifier
	 */
	private String frmIdentifier;
	/**
	 * Hold frmState
	 */
	private String frmState;
	/**
	 * Hold frmRelaseDt
	 */
	private String frmRelaseDt;
	/**
	 * Hold frmDesc
	 */
	private String frmDesc;
	/**
	 * Hold frmLibelle
	 */
	private String frmLibelle;
	/**
	 * Hold connRelation
	 */
	private String connRelation;
	/**
	 * Hold type
	 */
	private String type;
	/**
	 * Hold version
	 */
	private String version;
	/**
	 * Hold identifierId
	 */
	private String identifierId;
	/**
	 * Hold identifier
	 */
	private String identifier;
	/**
	 * Hold state
	 */
	private String state;
	/**
	 * Hold release
	 */
	private String release;
	/**
	 * Hold description
	 */
	private String description;
	/**
	 * Hold libelle
	 */
	private String libelle;
	/**
	 * Hold code
	 */
	private String code;
	/**
	 * Hold showMore
	 */
	private String showMore;
	/**
	 * Hold frmClassO
	 */
	private String frmClassO;
	/**
	 * Hold cssClassO
	 */
	private String cssClassO;
	
	/**
	 * Holds the tc5Code
	 */
	private String tc5Code;
	/**
	 * Holds the selRevision
	 */
	private String selRevision;
	
	/**
	 * Hold frmRelaseDtExl
	 */
	private Date frmRelaseDtExl;
	/**
	 * Hold releaseExl
	 */
	private Date releaseExl;

	/**
	 * @return the frmType
	 */
	public String getFrmType() {
		return frmType;
	}
	/**
	 * @param frmType the frmType to set
	 */
	public void setFrmType(String frmType) {
		this.frmType = frmType;
	}
	/**
	 * @return the frmVersion
	 */
	public String getFrmVersion() {
		return frmVersion;
	}
	/**
	 * @param frmVersion the frmVersion to set
	 */
	public void setFrmVersion(String frmVersion) {
		this.frmVersion = frmVersion;
	}
	/**
	 * @return the frmIdentifierId
	 */
	public String getFrmIdentifierId() {
		return frmIdentifierId;
	}
	/**
	 * @param frmIdentifierId the frmIdentifierId to set
	 */
	public void setFrmIdentifierId(String frmIdentifierId) {
		this.frmIdentifierId = frmIdentifierId;
	}
	/**
	 * @return the frmIdentifier
	 */
	public String getFrmIdentifier() {
		return frmIdentifier;
	}
	/**
	 * @param frmIdentifier the frmIdentifier to set
	 */
	public void setFrmIdentifier(String frmIdentifier) {
		this.frmIdentifier = frmIdentifier;
	}
	/**
	 * @return the frmState
	 */
	public String getFrmState() {
		return frmState;
	}
	/**
	 * @param frmState the frmState to set
	 */
	public void setFrmState(String frmState) {
		this.frmState = frmState;
	}
	/**
	 * @return the frmRelaseDt
	 */
	public String getFrmRelaseDt() {
		return frmRelaseDt;
	}
	/**
	 * @param frmRelaseDt the frmRelaseDt to set
	 */
	public void setFrmRelaseDt(String frmRelaseDt) {
		this.frmRelaseDt = frmRelaseDt;
	}
	/**
	 * @return the frmDesc
	 */
	public String getFrmDesc() {
		return frmDesc;
	}
	/**
	 * @param frmDesc the frmDesc to set
	 */
	public void setFrmDesc(String frmDesc) {
		this.frmDesc = frmDesc;
	}
	/**
	 * @return the frmLibelle
	 */
	public String getFrmLibelle() {
		return frmLibelle;
	}
	/**
	 * @param frmLibelle the frmLibelle to set
	 */
	public void setFrmLibelle(String frmLibelle) {
		this.frmLibelle = frmLibelle;
	}
	/**
	 * @return the connRelation
	 */
	public String getConnRelation() {
		return connRelation;
	}
	/**
	 * @param connRelation the connRelation to set
	 */
	public void setConnRelation(String connRelation) {
		this.connRelation = connRelation;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}
	/**
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}
	/**
	 * @return the identifierId
	 */
	public String getIdentifierId() {
		return identifierId;
	}
	/**
	 * @param identifierId the identifierId to set
	 */
	public void setIdentifierId(String identifierId) {
		this.identifierId = identifierId;
	}
	/**
	 * @return the identifier
	 */
	public String getIdentifier() {
		return identifier;
	}
	/**
	 * @param identifier the identifier to set
	 */
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the release
	 */
	public String getRelease() {
		return release;
	}
	/**
	 * @param release the release to set
	 */
	public void setRelease(String release) {
		this.release = release;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the libelle
	 */
	public String getLibelle() {
		return libelle;
	}
	/**
	 * @param libelle the libelle to set
	 */
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * @return the showMore
	 */
	public String getShowMore() {
		return showMore;
	}
	/**
	 * @param showMore the showMore to set
	 */
	public void setShowMore(String showMore) {
		this.showMore = showMore;
	}
	/**
	 * @return the frmClassO
	 */
	public String getFrmClassO() {
		return frmClassO;
	}
	/**
	 * @param frmClassO the frmClassO to set
	 */
	public void setFrmClassO(String frmClassO) {
		this.frmClassO = frmClassO;
	}
	/**
	 * @return the cssClassO
	 */
	public String getCssClassO() {
		return cssClassO;
	}
	/**
	 * @param cssClassO the cssClassO to set
	 */
	public void setCssClassO(String cssClassO) {
		this.cssClassO = cssClassO;
	}
	/**
	 * @return the tc5Code
	 */
	public String getTc5Code() {
		return tc5Code;
	}
	/**
	 * @param tc5Code the tc5Code to set
	 */
	public void setTc5Code(String tc5Code) {
		this.tc5Code = tc5Code;
	}
	/**
	 * @return the selRevision
	 */
	public String getSelRevision() {
		return selRevision;
	}
	/**
	 * @param selRevision the selRevision to set
	 */
	public void setSelRevision(String selRevision) {
		this.selRevision = selRevision;
	}
	/**
	 * @return the frmRelaseDtExl
	 */
	public Date getFrmRelaseDtExl() {
		Date temp = null;
		temp = frmRelaseDtExl;
		return temp;
	}
	/**
	 * @param frmRelaseDtExl the frmRelaseDtExl to set
	 */
	public void setFrmRelaseDtExl(Date frmRelaseDtExl) {
		Date temp = null;
		temp = frmRelaseDtExl;
		this.frmRelaseDtExl = temp;
	}
	/**
	 * @return the releaseExl
	 */
	public Date getReleaseExl() {
		Date temp = null;
		temp = releaseExl;
		return temp;
	}
	/**
	 * @param releaseExl the releaseExl to set
	 */
	public void setReleaseExl(Date releaseExl) {
		Date temp = null;
		temp = releaseExl;
		this.releaseExl = temp;
	}
	
	
}
