/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCRReportDaoIfc.java
 * @Creation date: 12-Aug-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMCRReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMCRReportDaoIfc {

	/**
	 * This method is used to get  List of States
	 * 
	 * @return List<SelectItem>
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getCRStates()throws PLMCommonException;
	
	/**
	 * This method is used to get CR Report List
	 * 
	 * @return List<PLMCRReportData>
	 * @throws PLMCommonException
	 */
	public List<PLMCRReportData> getCRReportData(PLMCRReportData reportData)	throws PLMCommonException;
	
	/**
	 * This method is used to get CR Report Details List
	 * 
	 * @return List<PLMCRReportData>
	 * @throws PLMCommonException
	 */
	public List<PLMCRReportData> getCRReportDetailsData(List<String> crValuesList,PLMCRReportData reportData)	throws PLMCommonException;
	
}
