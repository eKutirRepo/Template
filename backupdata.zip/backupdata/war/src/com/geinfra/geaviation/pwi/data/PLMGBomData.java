/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMGBomData.java
 * @Creation date: 29-April-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.data;

public class PLMGBomData {
	/**
	  * Holds the mktName
	  */
	private String mktName;
	/**
	  * Holds the ciDispName
	  */
	private String ciDispName;
	/**
	  * Holds the gbomPart
	  */
	private String gbomPart;
	/**
	  * Holds the confFeatureName
	  */
	private String confFeatureName;
	/**
	  * Holds the confOptnName
	  */
	private String confOptnName;
	/**
	  * Holds the headerConfFeature
	  */
	private String headerConfFeature;
	/**
	  * Holds the headerConfFeatureDispName
	  */
	private String headerConfFeatureDispName;
	/**
	  * Holds the headerConfOption
	  */
	private String headerConfOption;
	/**
	  * Holds the headerConfOptionDispName
	  */
	private String headerConfOptionDispName;
	/**
	  * Holds the frameType
	  */
	private String frameType;
	/**
	  * Holds the modelName
	  */
	private String modelName;
	/**
	  * Holds the productLine
	  */
	private String productLine;
	/**
	  * Holds the compValue
	  */
	private String[] compValue;
	
	//Added for FeatImptRept
	/**
	  * Holds the featDispName
	  */
	private String featDispName;
	/**
	  * Holds the featName
	  */
	private String featName;
	/**
	  * Holds the featType
	  */
	private String featType;
	/**
	  * Holds the ruleType
	  */
	private String ruleType;
	/**
	  * Holds the gbomPartFir
	  */
	private String gbomPartFir;
	/**
	  * Holds the cfName
	  */
	private String cfName;
	/**
	  * Holds the coName
	  */
	private String coName;
	/**
	  * Holds the dfsOrder
	  */
	private String dfsOrder;
	/**
	  * Holds the dfsOrderType
	  */
	private String dfsOrderType;
	/**
	  * Holds the hwPrdtNm
	  */
	private String hwPrdtNm;
	/**
	  * Holds the vtTableName
	  */
	private String vtTableName;
	/**
	  * Holds the level
	  */
	private String level;
	/**
	  * Holds the parentFeatName
	  */
	private String parentFeatName;
	/**
	  * Holds the childFeatName
	  */
	private String childFeatName;
	/**
	  * Holds the childFeatDispName
	  */
	private String childFeatDispName;
	/**
	  * Holds the strAdd
	  */
	private String strAdd;
	/**
	  * Holds the strDel
	  */
	private String strDel;
	/**
	  * Holds the cfDispName
	  */
	private String cfDispName;
	
	/**
	  * Holds the childFeatId
	  */
	private String childFeatId;
	
	/**
	  * Holds the gbomPartId
	  */
	private String gbomPartId;
	
	/**
	  * Holds the cfId
	  */
	private String cfId;

	/**
	  * Holds the coId
	  */
	private String coId;

	/**
	 * @return the mktName
	 */
	public String getMktName() {
		return mktName;
	}
	/**
	 * @param mktName
	 */
	public void setMktName(String mktName) {
		this.mktName = mktName;
	}
	/**
	 * @return the ciDispName
	 */
	public String getCiDispName() {
		return ciDispName;
	}
	/**
	 * @param ciDispName
	 */
	public void setCiDispName(String ciDispName) {
		this.ciDispName = ciDispName;
	}
	/**
	 * @return the gbomPart
	 */
	public String getGbomPart() {
		return gbomPart;
	}
	/**
	 * @param gbomPart
	 */
	public void setGbomPart(String gbomPart) {
		this.gbomPart = gbomPart;
	}
	/**
	 * @return the confFeatureName
	 */
	public String getConfFeatureName() {
		return confFeatureName;
	}
	/**
	 * @param confFeatureName
	 */
	public void setConfFeatureName(String confFeatureName) {
		this.confFeatureName = confFeatureName;
	}
	/**
	 * @return the confOptnName
	 */
	public String getConfOptnName() {
		return confOptnName;
	}
	/**
	 * @param confOptnName
	 */
	public void setConfOptnName(String confOptnName) {
		this.confOptnName = confOptnName;
	}
	/**
	 * @return the headerConfFeature
	 */
	public String getHeaderConfFeature() {
		return headerConfFeature;
	}
	/**
	 * @param headerConfFeature
	 */
	public void setHeaderConfFeature(String headerConfFeature) {
		this.headerConfFeature = headerConfFeature;
	}
	/**
	 * @return the headerConfOption
	 */
	public String getHeaderConfOption() {
		return headerConfOption;
	}
	/**
	 * @param headerConfOption
	 */
	public void setHeaderConfOption(String headerConfOption) {
		this.headerConfOption = headerConfOption;
	}
	/**
	 * @return the headerConfOptionDispName
	 */
	public String getHeaderConfOptionDispName() {
		return headerConfOptionDispName;
	}
	/**
	 * @param headerConfOptionDispName
	 */
	public void setHeaderConfOptionDispName(String headerConfOptionDispName) {
		this.headerConfOptionDispName = headerConfOptionDispName;
	}
	
	/**
	 * @return the headerConfFeatureDispName
	 */
	public String getHeaderConfFeatureDispName() {
		return headerConfFeatureDispName;
	}
	
	/**
	 * @param headerConfFeatureDispName
	 */
	public void setHeaderConfFeatureDispName(String headerConfFeatureDispName) {
		this.headerConfFeatureDispName = headerConfFeatureDispName;
	}
	
	/**
	 * @return the frameType
	 */
	public String getFrameType() {
		return frameType;
	}
	/**
	 * @param frameType
	 */
	public void setFrameType(String frameType) {
		this.frameType = frameType;
	}
	/**
	 * @return the modelName
	 */
	public String getModelName() {
		return modelName;
	}
	/**
	 * @param modelName
	 */
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	/**
	 * @return the productLine
	 */
	public String getProductLine() {
		return productLine;
	}
	/**
	 * @param productLine
	 */
	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}
	/**
	 * @return the compValue
	 */
	public String[] getCompValue() {
		String[]compVal=compValue;
		return compVal;
	}
	/**
	 * @param compValue
	 */
	public void setCompValue(String[] compValue) {
		String[]compVal=compValue;
		this.compValue = compVal;
	}
	/**
	 * @return the featDispName
	 */
	public String getFeatDispName() {
		return featDispName;
	}
	/**
	 * @param featDispName the featDispName to set
	 */
	public void setFeatDispName(String featDispName) {
		this.featDispName = featDispName;
	}
	/**
	 * @return the featName
	 */
	public String getFeatName() {
		return featName;
	}
	/**
	 * @param featName the featName to set
	 */
	public void setFeatName(String featName) {
		this.featName = featName;
	}
	/**
	 * @return the featType
	 */
	public String getFeatType() {
		return featType;
	}
	/**
	 * @param featType the featType to set
	 */
	public void setFeatType(String featType) {
		this.featType = featType;
	}
	/**
	 * @return the ruleType
	 */
	public String getRuleType() {
		return ruleType;
	}
	/**
	 * @param ruleType the ruleType to set
	 */
	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}
	/**
	 * @return the gbomPartFir
	 */
	public String getGbomPartFir() {
		return gbomPartFir;
	}
	/**
	 * @param gbomPartFir the gbomPartFir to set
	 */
	public void setGbomPartFir(String gbomPartFir) {
		this.gbomPartFir = gbomPartFir;
	}
	/**
	 * @return the cfName
	 */
	public String getCfName() {
		return cfName;
	}
	/**
	 * @param cfName the cfName to set
	 */
	public void setCfName(String cfName) {
		this.cfName = cfName;
	}
	/**
	 * @return the coName
	 */
	public String getCoName() {
		return coName;
	}
	/**
	 * @param coName the coName to set
	 */
	public void setCoName(String coName) {
		this.coName = coName;
	}
	/**
	 * @return the dfsOrder
	 */
	public String getDfsOrder() {
		return dfsOrder;
	}
	/**
	 * @param dfsOrder the dfsOrder to set
	 */
	public void setDfsOrder(String dfsOrder) {
		this.dfsOrder = dfsOrder;
	}
	/**
	 * @return the dfsOrderType
	 */
	public String getDfsOrderType() {
		return dfsOrderType;
	}
	/**
	 * @param dfsOrderType the dfsOrderType to set
	 */
	public void setDfsOrderType(String dfsOrderType) {
		this.dfsOrderType = dfsOrderType;
	}
	/**
	 * @return the hwPrdtNm
	 */
	public String getHwPrdtNm() {
		return hwPrdtNm;
	}
	/**
	 * @param hwPrdtNm the hwPrdtNm to set
	 */
	public void setHwPrdtNm(String hwPrdtNm) {
		this.hwPrdtNm = hwPrdtNm;
	}
	/**
	 * @return the vtTableName
	 */
	public String getVtTableName() {
		return vtTableName;
	}
	/**
	 * @param vtTableName the vtTableName to set
	 */
	public void setVtTableName(String vtTableName) {
		this.vtTableName = vtTableName;
	}
	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}
	/**
	 * @return the parentFeatName
	 */
	public String getParentFeatName() {
		return parentFeatName;
	}
	/**
	 * @param parentFeatName the parentFeatName to set
	 */
	public void setParentFeatName(String parentFeatName) {
		this.parentFeatName = parentFeatName;
	}
	/**
	 * @return the childFeatName
	 */
	public String getChildFeatName() {
		return childFeatName;
	}
	/**
	 * @param childFeatName the childFeatName to set
	 */
	public void setChildFeatName(String childFeatName) {
		this.childFeatName = childFeatName;
	}
	/**
	 * @return the childFeatDispName
	 */
	public String getChildFeatDispName() {
		return childFeatDispName;
	}
	/**
	 * @param childFeatDispName the childFeatDispName to set
	 */
	public void setChildFeatDispName(String childFeatDispName) {
		this.childFeatDispName = childFeatDispName;
	}
	/**
	 * @return the strAdd
	 */
	public String getStrAdd() {
		return strAdd;
	}
	/**
	 * @param strAdd the strAdd to set
	 */
	public void setStrAdd(String strAdd) {
		this.strAdd = strAdd;
	}
	/**
	 * @return the strDel
	 */
	public String getStrDel() {
		return strDel;
	}
	/**
	 * @param strDel the strDel to set
	 */
	public void setStrDel(String strDel) {
		this.strDel = strDel;
	}
	/**
	 * @return the cfDispName
	 */
	public String getCfDispName() {
		return cfDispName;
	}
	/**
	 * @param cfDispName the cfDispName to set
	 */
	public void setCfDispName(String cfDispName) {
		this.cfDispName = cfDispName;
	}
	/**
	 * @return the childFeatId
	 */
	public String getChildFeatId() {
		return childFeatId;
	}
	/**
	 * @param childFeatId the childFeatId to set
	 */
	public void setChildFeatId(String childFeatId) {
		this.childFeatId = childFeatId;
	}
	/**
	 * @return the gbomPartId
	 */
	public String getGbomPartId() {
		return gbomPartId;
	}
	/**
	 * @param gbomPartId the gbomPartId to set
	 */
	public void setGbomPartId(String gbomPartId) {
		this.gbomPartId = gbomPartId;
	}
	/**
	 * @return the cfId
	 */
	public String getCfId() {
		return cfId;
	}
	/**
	 * @param cfId the cfId to set
	 */
	public void setCfId(String cfId) {
		this.cfId = cfId;
	}
	/**
	 * @return the coId
	 */
	public String getCoId() {
		return coId;
	}
	/**
	 * @param coId the coId to set
	 */
	public void setCoId(String coId) {
		this.coId = coId;
	}
	
	
	
}
