/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEBOMPddrMB.java
 * @Creation date: 05-Dec-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMEBOMPddrData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMEBOMPddrServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMEBOMPddrMB {
	/**
	 * Holds the Logger.
	 */
	private static final Logger LOG = Logger.getLogger(PLMEBOMPddrMB.class);
	/**
	 *  Holds the PLMEBOMPddrServiceIfc
	 */
	private PLMEBOMPddrServiceIfc plmEBOMPddrService = null;
	/**
	 *  Holds the alertEMsgPddrRpt
	 */
	private String alertEMsgPddrRpt;
	/**
	 * Holds the PLMEBOMPddrData
	 */
	private PLMEBOMPddrData plmEBOMPddrData = null;
	/**
	 * Holds the ebomPartName
	 */
	private String ebomPartName;
	/**
	 * Holds the showEbomFlag
	 */
	private boolean showEbomFlag;
	/**
	 * Holds the editEbomFlag
	 */
	private boolean editEbomFlag;
	/**
	 * Holds the ebomRevisionList
	 */
	private List<PLMEBOMPddrData> ebomRevisionList = new ArrayList<PLMEBOMPddrData>();
	/**
	 * Holds the commonMB
	 */
	private PLMCommonMB commonMB = null;
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;

	private PLMPwiUserData userDetails = null;
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	
	/**
	 * Holds the revision
	 */
	private String revision;
	/**
	 * Holds the selRevision
	 */
	private String selRevision;

	/**
	 * This method is used for Loading EBOM PDDR Home Page
	 * 
	 * @return String
	 */
	public String loadEBOMPDDRHome() {
		LOG.info("Entering loadEBOMPDDRHome Method");
		try {
			commonMB.insertCannedRptRecordHitInfo("EBOM PDDR Report");
			
			plmEBOMPddrData = new PLMEBOMPddrData();
			ebomPartName="";
			showEbomFlag=false;
			editEbomFlag=false;
			alertEMsgPddrRpt = "";
			revision ="";
			ebomRevisionList = new ArrayList<PLMEBOMPddrData>();
			} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadEBOMPDDRHome:", exception);
		}
		LOG.info("Exiting loadEBOMPDDRHome Method");
		return "ebomPddrSearch";
	}
	
	/**
	 * This method is used for Reset Data
	 * 
	 * @return String
	 */
	public String resetData(){
		ebomPartName="";
		plmEBOMPddrData.setSelectRevision("");
		showEbomFlag=false;
		editEbomFlag=false;
		alertEMsgPddrRpt = "";
		ebomRevisionList = new ArrayList<PLMEBOMPddrData>();
		revision ="";
		return "ebomPddrSearch";
	}
	
	/**
	 * This method is used for getRevisionsDropDown
	 * 
	 * @return String
	 */
	public String getEbomRevisionsDropDown() {
		LOG.info("Entering getEbomRevisionsDropDown() Method");
		ebomRevisionList = new ArrayList<PLMEBOMPddrData>();
		alertEMsgPddrRpt = "";
		String fwdFlag = "ebomPddrSearch";
		try {
			if(!PLMUtils.isEmpty(ebomPartName)){
				
				ebomRevisionList = plmEBOMPddrService.getEbomRevisions(ebomPartName);

				if(ebomRevisionList.size()>0){
				 LOG.info("ebomRevisionList size :"+ebomRevisionList.size());
				 // setSelRevision(ebomRevisionList.get(0).getRevision());
				  //setRevision(ebomRevisionList.get(0).getRevision());
					  showEbomFlag=true;
				      editEbomFlag=true;
				}else{
					 alertEMsgPddrRpt="Part Name does not Exist..please enter valid Part Name";
					showEbomFlag=false;
					editEbomFlag=false;
				}
			}else{
				alertEMsgPddrRpt="Please Enter a Part Name";
				showEbomFlag=false;
				editEbomFlag=false;
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getEbomRevisionsDropDown: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","EBOM PDDR Report");
		} 
		LOG.info("Exiting getEbomRevisionsDropDown() Method");
		return fwdFlag;
	}
	
	public void chngRevisionNmVal(){
		LOG.info("Entering into  chngRevisionNmVal method");
			if(!PLMUtils.isEmpty(selRevision)){
				 setSelRevision(selRevision);
		} LOG.info("setSelRevision >>> "+selRevision);
		LOG.info("Exiting into  chngRevisionNmVal method");
	
	}
	/**
	 * This method is used for Generating MBOM PDDR Report
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String generateEmailReport() throws PWiException {
		LOG.info("Entering generateEmailReport Method");
		String fwdflag = "ebomPddrSearch";
		
		userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		
		if(!PLMUtils.isEmpty(selRevision)){
			alertEMsgPddrRpt = PLMConstants.EBOM_MAIL_ALERT_MSG;
			LOG.info("sendEBOMPDDRReportThroughMail Method>>>>>>>>>>>>>>>>>>"+selRevision);
			taskExecutor.execute(new MailThread());
			}else if(PLMUtils.isEmpty(selRevision)){
				alertEMsgPddrRpt="Please select a Revision";
			  fwdflag = "ebomPddrSearch";
			 }
		
		LOG.info("Exiting generateEmailReport Method");
		return fwdflag;
	}
	
	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendEBOMPDDRReportThroughMail();
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return String
	 */
	public void sendEBOMPDDRReportThroughMail() {
		LOG.info("Entering sendEBOMPDDRReportThroughMail Method");
		String partNameLcl = ebomPartName;
		String revisionName = selRevision;
		Date date = new Date();
		String reportDate = String.format("%tc", date );
		
		String from = PLMConstants.LTTR_MAIL_FROM;

		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.EBOM_MAIL_SUBJECT + partNameLcl;
		
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("EBOM_PDDR_REPORT_NAME") +  partNameLcl + "_" + uniqTime + ".xlsx";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("EBOM_PDDR_REPORT_NAME") +  partNameLcl + "_" + uniqTime + ".zip";
		try {
			List<PLMEBOMPddrData> ebompddrList = plmEBOMPddrService.getEBOMPddrReport(partNameLcl,revisionName);
			StringBuffer mailBody = new StringBuffer().append(toAddressee);
			if(!PLMUtils.isEmptyList(ebompddrList)){
				mailBody.append(PLMConstants.EBOM_MAIL_CONTENT)
				.append(partNameLcl)
				.append(".")
				.append(PLMConstants.LTTR_MAIL_SIGNATURE)
				.append(PLMConstants.LTTR_MAIL_FOOTER);
				saveEBomPddrXls(partNameLcl,revisionName,reportDate,ebompddrList,fileDir,filePathXls);
				PLMUtils.generateZipFile(filePathXls,filePathZip);
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
			}else{
				mailBody.append(PLMConstants.EBOM_MAIL_CONTENT_NO_RECORD);
				mailBody.append(partNameLcl)
				.append(".")
				.append(PLMConstants.LTTR_MAIL_SIGNATURE)
				.append(PLMConstants.LTTR_MAIL_FOOTER);
				PLMUtils.sendMail(from, to, subject, mailBody.toString());
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendEBOMPDDRReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendEBOMPDDRReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
		} finally {
			deleteFiles(filePathXls,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendEBOMPDDRReportThroughMail Method");
	}

	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return StringBuffer
	 */
	
	public void saveEBomPddrXls(String partNmLcl,String revisionLcl,String reportDateLcl,List<PLMEBOMPddrData> ebompddrList,String fileDir,String filePathXls) throws IOException {
		LOG.info("Entering saveEBomPddrXls Method");
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist = fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXls);
				SXSSFWorkbook workbook = new SXSSFWorkbook();
				SXSSFSheet sheet =  (SXSSFSheet) workbook.createSheet(partNmLcl);
				XSSFCellStyle headerStyle = (XSSFCellStyle) workbook.createCellStyle();
				
				headerStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
				headerStyle.setFillForegroundColor(HSSFColor.YELLOW.index);
				headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				XSSFFont font = (XSSFFont) workbook.createFont(); 
				font.setFontName(PLMConstants.EXCEL_FONT_NAME);
				font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				headerStyle.setFont(font);
				headerStyle = setBorderStyle(headerStyle);
				
				XSSFCellStyle cellBoldStyle = (XSSFCellStyle) workbook.createCellStyle();
				cellBoldStyle = setBorderStyle(cellBoldStyle);
				cellBoldStyle.setFont(font);
				
				XSSFFont nonBoldFont = (XSSFFont) workbook.createFont();
				nonBoldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				XSSFCellStyle contentStyle = (XSSFCellStyle) workbook.createCellStyle();				
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(nonBoldFont);
				XSSFCellStyle contentStyle1 = (XSSFCellStyle) workbook.createCellStyle();				
				contentStyle1 = setBorderStyle(contentStyle1);
				contentStyle1.setFont(nonBoldFont);
				contentStyle1.setWrapText(true);
				XSSFCellStyle contentDecimalStyle = (XSSFCellStyle) workbook.createCellStyle();				
				contentDecimalStyle = setBorderStyle(contentDecimalStyle);
				contentDecimalStyle.setFont(nonBoldFont);
				DataFormat format = workbook.createDataFormat();
				contentDecimalStyle.setDataFormat(format.getFormat("0.00000"));
										
				XSSFFont noRecordFont = (XSSFFont) workbook.createFont(); 
				noRecordFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				noRecordFont.setColor(HSSFColor.RED.index);
				noRecordFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				XSSFCellStyle noRecordCellStyle = (XSSFCellStyle) workbook.createCellStyle();
				noRecordCellStyle = setBorderStyle(noRecordCellStyle);
				noRecordCellStyle.setFont(noRecordFont);

				CreationHelper createHelper = workbook.getCreationHelper();

				XSSFCellStyle dateStyle = (XSSFCellStyle) workbook.createCellStyle();
				
				dateStyle.setDataFormat(
			        createHelper.createDataFormat().getFormat("mm/dd/yyyy"));
				
				dateStyle = setBorderStyle(contentStyle);		
				dateStyle.setFont(nonBoldFont);
				
				int rowcount = -1;
				
				if(!PLMUtils.isEmptyList(ebompddrList)) {
					
					String[] colNames = {"Level","F/N","BOM Prefix","Part Number","Part Rev","Qty","UOM","EID","Doc Name","Doc Rev","Description","Type","State","Original / Replacement Part","Model Validated","Part Attributes"};
					
					SXSSFRow row = (SXSSFRow) sheet.createRow(++rowcount);
					SXSSFCell cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					cell.setCellValue("EBOM Part Definition Data Report for - "+partNmLcl + " rev "+revisionLcl);
					cell.setCellStyle(cellBoldStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_FIVE));
					
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT); 
					cell.setCellValue(reportDateLcl);
					cell.setCellStyle(cellBoldStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_EIGHT,PLMConstants.EXCEL_COL_TEN));
					
					row = (SXSSFRow) sheet.createRow(++rowcount);
					row = (SXSSFRow) sheet.createRow(++rowcount);
					
					for ( int i = 0 ; i < colNames.length; i++ ) {
						cell = (SXSSFCell) row.createCell(i);
						cell. setCellValue(colNames[i]);
						cell.setCellStyle(headerStyle);
					}
					
					for(int i = 0; i < ebompddrList.size(); i++) {
						PLMEBOMPddrData dataObj = (PLMEBOMPddrData) ebompddrList.get(i);
							row = (SXSSFRow) sheet.createRow(++rowcount);

							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getLevel());
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getFn());
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getBomPrefix());
				
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartNumber());
				
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartRev());
				
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getQty());
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getUom());

							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getEid());
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getDocName());
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
							cell.setCellStyle(contentDecimalStyle);
							cell.setCellValue(dataObj.getDocRev());
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getDescription());
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getType());
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWELVE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getState());
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getOrgReplcPart());
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getModelValidated());
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
							cell.setCellStyle(contentStyle1);
							cell.setCellValue(dataObj.getPartAttribute());
							
					}
					
					row = (SXSSFRow) sheet.createRow(++rowcount);
					row = (SXSSFRow) sheet.createRow(++rowcount);
					
					short colWidth1 = (short) 5000;
					short colWidth2 = (short) 3200;
					short colWidth3 = (short) 6500;
					short colWidth4 = (short) 2800;
					short colWidth5 = (short) 11500;
					short colWidth6 = (short) 7500;
					short colWidth7 = (short) 13000;
					short colWidth8 = (short) 2000;
		
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,colWidth8);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,colWidth1);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,colWidth1);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,colWidth1);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE,colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN,colWidth5);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN,colWidth3);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWELVE,colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTEEN,colWidth6);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTEEN,colWidth1);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTEEN,colWidth7);
					sheet.createFreezePane(0,3);
					sheet.setZoom(4,5);
				} else {
					LOG.info("There is no record found for " + partNmLcl);
					XSSFRow row = (XSSFRow) sheet.createRow(++rowcount);
					XSSFCell cell = row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					String noRecordMsg = PLMConstants.EBOM_NO_RECORD_FOUND + partNmLcl;
					cell.setCellValue(noRecordMsg);
					cell.setCellStyle(noRecordCellStyle);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
				}	
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveEBomPddrXls: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveEBomPddrXls: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveEBomPddrXls: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveEBomPddrXls Method");
	}

	/**
	 * This method is used for Bordering Cell in XLS
	 * 
	 * @return StringBuffer
	 */
	
	private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
		style.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style.setBorderRight(XSSFCellStyle.BORDER_THIN);
		return style;
	}

	
	/**
	 * This method is used for Deleting zip file and xls file
	 * 
	 * @return void
	 */
	public void deleteFiles(String filePathXls,String filePathZip){
		LOG.info("Entering deleteFiles method");
		boolean zipFileExist;
		boolean xlsFileExist;
		File zipFile = new File(filePathZip);
		zipFileExist = zipFile.exists();
		File xlsFile = new File(filePathXls);
		xlsFileExist = xlsFile.exists();
		if(zipFileExist){
			boolean deleted = zipFile.delete();
			LOG.info("Successfully deleted zip file : " + deleted);
		}
		if(xlsFileExist){
			boolean deleted = xlsFile.delete();
			LOG.info("Successfully deleted xls file : " + deleted);
		}
		LOG.info("Exiting deleteFiles Method");
	}



	/**
	 * @return the plmEBOMPddrService
	 */
	public PLMEBOMPddrServiceIfc getPlmEBOMPddrService() {
		return plmEBOMPddrService;
	}

	/**
	 * @param plmEBOMPddrService the plmEBOMPddrService to set
	 */
	public void setPlmEBOMPddrService(PLMEBOMPddrServiceIfc plmEBOMPddrService) {
		this.plmEBOMPddrService = plmEBOMPddrService;
	}

	/**
	 * @return the alertEMsgPddrRpt
	 */
	public String getAlertEMsgPddrRpt() {
		return alertEMsgPddrRpt;
	}

	/**
	 * @param alertEMsgPddrRpt the alertEMsgPddrRpt to set
	 */
	public void setAlertEMsgPddrRpt(String alertEMsgPddrRpt) {
		this.alertEMsgPddrRpt = alertEMsgPddrRpt;
	}

	/**
	 * @return the plmEBOMPddrData
	 */
	public PLMEBOMPddrData getPlmEBOMPddrData() {
		return plmEBOMPddrData;
	}

	/**
	 * @param plmEBOMPddrData the plmEBOMPddrData to set
	 */
	public void setPlmEBOMPddrData(PLMEBOMPddrData plmEBOMPddrData) {
		this.plmEBOMPddrData = plmEBOMPddrData;
	}

	/**
	 * @return the ebomPartName
	 */
	public String getEbomPartName() {
		return ebomPartName;
	}

	/**
	 * @param ebomPartName the ebomPartName to set
	 */
	public void setEbomPartName(String ebomPartName) {
		this.ebomPartName = ebomPartName;
	}

	/**
	 * @return the showEbomFlag
	 */
	public boolean isShowEbomFlag() {
		return showEbomFlag;
	}

	/**
	 * @param showEbomFlag the showEbomFlag to set
	 */
	public void setShowEbomFlag(boolean showEbomFlag) {
		this.showEbomFlag = showEbomFlag;
	}

	/**
	 * @return the editEbomFlag
	 */
	public boolean isEditEbomFlag() {
		return editEbomFlag;
	}

	/**
	 * @param editEbomFlag the editEbomFlag to set
	 */
	public void setEditEbomFlag(boolean editEbomFlag) {
		this.editEbomFlag = editEbomFlag;
	}

	/**
	 * @return the ebomRevisionList
	 */
	public List<PLMEBOMPddrData> getEbomRevisionList() {
		return ebomRevisionList;
	}

	/**
	 * @param ebomRevisionList the ebomRevisionList to set
	 */
	public void setEbomRevisionList(List<PLMEBOMPddrData> ebomRevisionList) {
		this.ebomRevisionList = ebomRevisionList;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the userDetails
	 */
	public PLMPwiUserData getUserDetails() {
		return userDetails;
	}

	/**
	 * @param userDetails the userDetails to set
	 */
	public void setUserDetails(PLMPwiUserData userDetails) {
		this.userDetails = userDetails;
	}

	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return the revision
	 */
	public String getRevision() {
		return revision;
	}

	/**
	 * @param revision the revision to set
	 */
	public void setRevision(String revision) {
		this.revision = revision;
	}

	/**
	 * @return the selRevision
	 */
	public String getSelRevision() {
		return selRevision;
	}

	/**
	 * @param selRevision the selRevision to set
	 */
	public void setSelRevision(String selRevision) {
		this.selRevision = selRevision;
	}

}
