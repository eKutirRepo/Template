package com.geinfra.geaviation.pwi.queryprocessing;

import java.sql.Types;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.PWiResultSet;
import com.geinfra.geaviation.pwi.model.PWiResultSetColMetaData;
import com.geinfra.geaviation.pwi.xml.query.ColumnType;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.query.util.QueryJaxbUtil;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;

/**
 * Project      : Product Lifecycle Management Intelligence
 * Date Written : Apr 12, 2011
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : AssyQueryProcessor
 * 
 * Revision Log Apr 12, 2011 | v1.0.
 * 2012.12.18 pH  replaced GEAEResultSet with PWiResultSet
 * --------------------------------------------------------------
 */
public class AssyQueryProcessor implements QueryProcessor {
	public static final String TYPE = "assyWt";
	private static final Logger LOGGER = Logger
			.getLogger(AssyQueryProcessor.class);
	private static final String ARR_HEADING[] = { "LVL", "ASSEMBLY", "PPN",
			"ZONE", "SHEET", "PART", "NOMENCLATURE", "QTY", "PART_WT",
			"EXT_WT", "ROLLUP", "PHY_WT", "PHY_EXT_WT", "PHY_TOTAL", "DELTA",
			"REMARKS" };

	public PWiResultSet postProcess(PWiResultSet prsNHA, Search search,
			List<String> selectedColumns, QueryType queryType)
			throws PWiException {
//		try {
			int intArraySize = prsNHA.size();
			LOGGER.debug(" arraysize " + intArraySize);

			if (intArraySize <= 0) {
				return null;
			}

			// Initialize result set meta data
			HashMap<String, Integer> ht1 = new HashMap<String, Integer>();
			HashMap<Integer, PWiResultSetColMetaData> ht2 =
					new HashMap<Integer, PWiResultSetColMetaData>();
			initMetaData(ht1, ht2, prsNHA, queryType);

			/**
			 * Adds the ResultSet contents into a String array
			 */
			String[][] arrResult = extractResults(prsNHA, intArraySize,
					ARR_HEADING.length);
			LOGGER.debug("array leng " + arrResult.length);

			/**
			 * This Loop Calculates the ExtWt = (Qty * PartWt) Updates to the
			 * ArrayList
			 */
			calculateExtWt(intArraySize, arrResult);

			// This Loop will calculate the deepst Level of the given
			// assembly to calculate the Rollup
			int intMaxLvl = calculateDeepestLevel(intArraySize, arrResult);

			// This Block calculates the Rollup from deepst lvl first
			calculateRollup(intArraySize, arrResult, intMaxLvl);

			// this loop is checking for ErrorMsg
			checkForErrorMsg(intArraySize, arrResult);

			/**
			 * This Loop will calculate the Total of SubAssemblies by Levelwise
			 * and check Rollup, accordingly set ErrorMsg
			 */
			calculateTotalOfSubAssemblies(intArraySize, arrResult);

			/**
			 * This Loop populates the ArrayList
			 */
			ArrayList<ArrayList<String>> lstFinalDataBlock = populateArrayList(
					intArraySize, ARR_HEADING.length, arrResult);

			// Initialize PLMi result set
			PWiResultSet PWiRs = new PWiResultSet();
			PWiRs.setData(lstFinalDataBlock, ht1, ht2);
			LOGGER.debug(" size of res in AssyImpl " + PWiRs.size());
			return PWiRs;
//		} catch (SQLException e) {
//			throw new PWiException(e, "Error");
//		}
	}

	private void initMetaData(HashMap<String, Integer> ht1,
			HashMap<Integer, PWiResultSetColMetaData> ht2,
			PWiResultSet prsNHA, QueryType queryType) {
		int inColType = 12;
		for (int i = 1; i <= ARR_HEADING.length; ++i) {
			PWiResultSetColMetaData PWicmd = new PWiResultSetColMetaData();
			PWicmd.colindex = i;
			PWicmd.colname = ARR_HEADING[i - 1];
			ColumnType qryCol = QueryJaxbUtil.getInstance().getColumnForId(queryType,
					PWicmd.colname);
			PWicmd.colheading = qryCol.getDisplayname();
			switch (i) {
			case 16:
				inColType = Types.VARCHAR;
				break;
			case 9:
			case 10:
			case 11:
			case 12:
			case 13:
			case 14:
			case 15:
				inColType = Types.DOUBLE;
				break;
			default:
				inColType = prsNHA.getColumnType(i);
			}

			PWicmd.coltype = inColType;
			ht2.put(Integer.valueOf(i), PWicmd);
			ht1.put(PWicmd.colname, Integer.valueOf(i));
		}
	}

	private void checkForErrorMsg(int intArraySize, String[][] arrResult) {
		for (int l = 1; l < intArraySize - 1; l++) {
			if (arrResult[l][15].trim().length() == 0
					&& arrResult[l][8].trim().equalsIgnoreCase("")) {
				arrResult[l][15] = "Missing Weight";
			}
		}
	}

	private ArrayList<ArrayList<String>> populateArrayList(int intArraySize,
			int iColCount, String[][] arrResult) {
		ArrayList<ArrayList<String>> lstFinalDataBlock = new ArrayList<ArrayList<String>>();
		// for Decimal formatting
		DecimalFormat objDf = new DecimalFormat("########0.000");
		for (int k = 0; k < intArraySize; k++) {
			// Logger.trace("in k loop "+ k);
			String strQtyChk = arrResult[k][7].trim();
			ArrayList<String> alTemp = new ArrayList<String>();

			if (!"DEL".equalsIgnoreCase(strQtyChk)
					&& !"-".equalsIgnoreCase(strQtyChk)) {
				for (int p = 0; p < iColCount; p++) {

					switch (p) {
					case 8:
					case 9:
					case 10:
					case 11:
					case 12:
					case 13:
					case 14:
						String strVal = arrResult[k][p].trim();
						if (strVal.equals("0") || strVal.equals("0.0")
								|| strVal.equals("-1")) {
							strVal = "";
						}
						// TODO pH 2012.12: we probably don't need this trim:
						if (strVal.trim().length() > 0) {
							alTemp.add(convertToDecimalFormat(
									strVal, objDf));
						} else {
							alTemp.add(strVal);
						}
						break;

					default:
						alTemp.add(arrResult[k][p].trim());

					}// end switch

				}// end for
				lstFinalDataBlock.add(alTemp);
			}// end if
		}
		return lstFinalDataBlock;
	}

	private void calculateTotalOfSubAssemblies(int intArraySize,
			String[][] arrResult) {
		if (intArraySize > 1) {
			int intPresLvl = Integer.parseInt(arrResult[1][0].trim());
			int intNextLvl = 0;
			for (int z = 2; z <= intArraySize - 1; z++) {
				intNextLvl = Integer.parseInt(arrResult[z][0].trim());
				if (intNextLvl > intPresLvl) {

					if (arrResult[z - 1][15].trim().length() == 0
							&& !arrResult[z - 1][9].trim().equalsIgnoreCase(
									arrResult[z - 1][10])) {
						arrResult[z - 1][15] = "Mismatch with Rollup";
					}
				}
				// assigning NextLvl to PresLvl so that in the next
				// iteration PresLvl would change to Latest ;
				intPresLvl = intNextLvl;
			}
		}
		LOGGER.debug("Populated the msgs");
	}

	private void calculateRollup(int intArraySize, String[][] arrResult,
			int intMaxLvl) {
		int level = intMaxLvl;
		for (int x = level; x >= 0; x--) {
			double dbSum = 0.0;
			double dbPhySum = 0.0;
			boolean isWeightMissing = false;
			for (int y = intArraySize - 1; y > 0; y--) {

				int Lvl1 = Integer.parseInt(arrResult[y][0].trim());
				int Lvl2 = Integer.parseInt(arrResult[y - 1][0].trim());

				// int iNxtLvl =
				// Integer.parseInt(arrResult[y+1][0].trim() );
				if (level == Lvl1) {
					// if a subassembly has a weight assigned
					// and QTY is numeric use extended wt for
					// calcuating roll up wt
					// else use the corresponding rollup weights to
					// calculate the ext wt
					if (arrResult[y][8].trim().length() > 0
							&& isNumber(arrResult[y][7])
							&& !arrResult[y][8].trim().equals("0")) {
						dbSum = dbSum
								+ Double.parseDouble(arrResult[y][9].trim());
					} else if (!arrResult[y][10].equals("-1")
							&& isNumber(arrResult[y][7])) {
						dbSum = dbSum
								+ Double.parseDouble(arrResult[y][10].trim());
					}

					// calculate physical weights
					if (arrResult[y][11].trim().length() > 0
							&& isNumber(arrResult[y][7])) {
						dbPhySum = dbPhySum
								+ Double.parseDouble(arrResult[y][12].trim());
					} else if (!arrResult[y][13].equals("0")) {
						dbPhySum = dbPhySum
								+ Double.parseDouble(arrResult[y][13].trim());
					}

					// if partweight is missing
					if (!isWeightMissing
							&& arrResult[y][8].trim().length() == 0) {
						isWeightMissing = true;
					}
					// This checking is for assign dbSum to
					// arrResult[][] and refresh dbSum
					if (Lvl2 == level - 1) {

						arrResult[y - 1][10] = Double.toString(dbSum);
						arrResult[y - 1][13] = Double.toString(dbPhySum);

						// if any part contributing to the rollup has
						// weight missing, set the message
						if (isWeightMissing
								&& arrResult[y - 1][8].trim().length() == 0) {
							arrResult[y - 1][15] = "INCOMPLETE WEIGHT";
						}
						isWeightMissing = false;
						dbSum = 0.0;
						dbPhySum = 0.0;
					}
				}

			}
			// increase Level to next Higher Level
			level--;
		}
		LOGGER.debug("got the rollups ");
	}

	private int calculateDeepestLevel(int intArraySize, String[][] arrResult) {
		int intMaxLvl = Integer.parseInt(arrResult[0][0].trim());
		for (int z = 1; z < intArraySize - 1; z++) {
			int intTemp = Integer.parseInt(arrResult[z][0].trim());
			if (intMaxLvl < intTemp)
				intMaxLvl = intTemp;
		}
		LOGGER.debug("max level " + intMaxLvl);
		return intMaxLvl;
	}

	private void calculateExtWt(int intArraySize, String[][] arrResult) {
		for (int j = 1; j < intArraySize; j++) {
			double dblTotal = 0.0; // set to zero to be presereved in the final
			// result
			String strQtyNum = arrResult[j][7].trim();
			String strPartWtNum = arrResult[j][8].trim();
			String strPhyPartWtNum = arrResult[j][11].trim();
			boolean isQtyNum = isNumber(strQtyNum);
			boolean isPartWtNum = isNumber(strPartWtNum);
			boolean isPhyPartWtNum = isNumber(strPhyPartWtNum);

			// This Block Checks for the Qty & UnitWt and caluclates
			// TotalWt
			if (isQtyNum && isPartWtNum) {
				int intQty = Integer.parseInt(strQtyNum);
				double dblUnit = Double.parseDouble(strPartWtNum);
				dblTotal = ((double) (intQty)) * (dblUnit);
			}

			arrResult[j][9] = Double.toString(dblTotal);

			double dbSum = dblTotal;// temporary var for the totalwt
			dblTotal = 0.0;
			// This Block Checks for the Qty & Physical UnitWt and
			// calculates Total PhysicalWt
			if (isQtyNum && isPhyPartWtNum) {
				int intQty = Integer.parseInt(strQtyNum);
				double dblUnit = Double.parseDouble(strPhyPartWtNum);
				dblTotal = ((double) (intQty)) * (dblUnit);
			}
			arrResult[j][12] = Double.toString(dblTotal);

			// total calculated and total physical weight have values
			// calculate the delta=calculated wt - physical weight
			if (dblTotal > 0.0 && dbSum > 0.0) {
				arrResult[j][14] = Double.toString(dblTotal - dbSum);
			}
		}
	}

	private String[][] extractResults(PWiResultSet prsNHA, int intArraySize,
			int iColCount) {
		String[][] arrResult = new String[intArraySize][iColCount];

		LOGGER.debug("gettng into while ");
		int index = 0;

		prsNHA.first();
		do {
			// Logger.trace(" working on row "+i);
			// adding LVL
			arrResult[index][0] = rightJustified(prsNHA.getString(1).trim(), 3);
			// adding NHA
			arrResult[index][1] = getFormattedString(prsNHA.getString(2)
					.trim(), 18);
			// adding PPN
			arrResult[index][2] = getFormattedString(prsNHA.getString(3)
					.trim(), 5);
			// adding ZONE
			arrResult[index][3] = getFormattedString(prsNHA.getString(4)
					.trim(), 4);
			// adding SHEET
			arrResult[index][4] = rightJustified(prsNHA.getString(5).trim(), 5);
			// adding PART
			arrResult[index][5] = getFormattedString(prsNHA.getString(6)
					.trim(), 18);
			// adding Nomenclature
			arrResult[index][6] = getFormattedString(prsNHA.getString(7)
					.trim(), 15);
			// adding QTY
			arrResult[index][7] = rightJustified(prsNHA.getString(8).trim(), 3);
			// adding PARTWT
			arrResult[index][8] = prsNHA.getString(9).trim();
			// adding EXTWT
			arrResult[index][9] = "0";
			// adding ROLLUP
			arrResult[index][10] = "-1";

			// adding PARTWT
			arrResult[index][11] = prsNHA.getString(10).trim();
			// adding EXTWT
			arrResult[index][12] = "0";
			// adding Total
			arrResult[index][13] = "0";
			// adding delta
			arrResult[index][14] = "0"; // prsNHA.getString(11).trim();
			// adding ERRORS
			arrResult[index][15] = " ";
			index++;
		} while (prsNHA.next());

		return arrResult;
	}

	/**
	 * Method Name : rightJustified
	 * 
	 * Description : This Method alligns the Input
	 * Right Justified upto 'n' number spaces
	 * 
	 * @param strInput
	 * @param intSize
	 * @return String
	 */
	private String rightJustified(String strInput, int intSize) {
		StringBuffer strTemp = new StringBuffer();
		if (strInput.length() < intSize) {
			for (int m = strInput.length(); m < intSize; m++) {
				strTemp = strTemp.append(" ");
			}
			strTemp.append(strInput);
		} else
			strTemp.append(strInput);

		return strTemp.toString();
	}

	public void preProcess(SelectedColumns selectedColumns)
			throws PWiException {
		// Nothing to do
	}

	/**
	 * This method checks whether the string that is passed is equal to the size
	 * of string that is expected in the field. If the string is not of the
	 * required length it appends spaces or trims the string as required. If the
	 * string is null returns empty string.
	 * 
	 * @param strInput
	 *            The java.lang.String representing inputString to to be checked
	 *            for its length
	 * @param intSize
	 *            This represents the actual length of the string that is
	 *            expected in the output file.
	 * @return String Returns the formated String
	 */
	private String getFormattedString(String strInput, int intSize) {
		int intCount = 0;
		intCount = strInput.length();
		StringBuilder sbResult = new StringBuilder();
		if (intCount < intSize) {
			sbResult.append(strInput);
			for (int i = intCount; i < intSize; i++) {
				sbResult.append(" ");
			}
		} else if (intCount > intSize) {
			sbResult.append(strInput.substring(0, intSize));
		} else {
			sbResult.append(strInput);
		}
		return sbResult.toString();
	}

	/**
	 * Method Name: isNumber
	 * 
	 * Description: This method returns true if a String
	 * is Number
	 * 
	 * @param strNumber
	 * @return boolean
	 */
	public boolean isNumber(String strNumber) {
		boolean isNumber = false;
		try {
			if (strNumber != null) {
				Double.parseDouble(strNumber);
				isNumber = true;
			}
		} catch (NumberFormatException nfe) {
			isNumber = false;
		}
		return isNumber;
	}

	/**
	 * Method Name : convertToDecimalFormat
	 * 
	 * Description : This Method converts
	 * the string to given decimal format
	 * 
	 * @param strInput
	 * @param objDf
	 *            - Decimal format of the output
	 * @return String
	 */
	public String convertToDecimalFormat(String strInput, DecimalFormat objDf) {
		String result = strInput;
		if (strInput.trim().length() > 0) {
			result = objDf.format(new Double(strInput));
		}
		return result;
	}

}
