package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import com.geinfra.geaviation.pwi.model.PWiGroupQueryVO;
import com.geinfra.geaviation.pwi.model.PWiUserVO;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Jan 20, 2012 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Data access object interface for group query table
 * 
 * Revision Log Jan 20, 2012 | v1.0.
 * --------------------------------------------------------------
 */
public interface GroupQueryDAO {
	public List<PWiGroupQueryVO> getGroupQueriesForQuery(Integer queryId);

	public void addGroupsForQuery(List<Integer> groupIdsToAddForQuery, Integer queryId,
			String sso);

	public void deleteGroupsForQuery(List<Integer> groupIdsToRemoveForQuery, Integer queryId);

	public List<PWiUserVO> getUserGroupQueriesForQuery(Integer queryId);

	public void addDeleteUserGroupsForQuery(Integer queryId, String sso,
			Map<String, List<PWiUserVO>> tempGrpUsrMap);
}
