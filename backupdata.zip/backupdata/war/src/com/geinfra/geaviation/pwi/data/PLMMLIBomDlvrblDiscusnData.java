/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMMLIBomDlvrblDiscusnData.java
 * @Creation date: 11-Sept-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.ArrayList;
import java.util.List;

public class PLMMLIBomDlvrblDiscusnData {

	
	// PROPERTIES *************************************************************
	
	private int index;
	public String mli;
	public List<PLMBomDlvrblDiscsnData> list_bom_deliverables_discussions;
	private boolean displayed;

	
	// CONSTRUCTOR ************************************************************

	/**
	 * Creates a new instance of the class BomDeliverable
	 * 
	 */
	public PLMMLIBomDlvrblDiscusnData (int index, String mli, List<PLMBomDlvrblDiscsnData> list_bom_deliverables_discussions) {  
		this.index = index;
		this.mli = mli;		
		this.list_bom_deliverables_discussions = list_bom_deliverables_discussions;
	}
	
	// ACCESSOR METHODS *******************************************************

	public int getIndex() {
		return index;
	}
		
	public String getMli() {
		return mli;
	}

	public void setMli(String mli) {
		this.mli = mli;
	}
	
	public List<PLMBomDlvrblDiscsnData> getList_bom_deliverables_discussions() {
		return list_bom_deliverables_discussions;
	}

	public void setDeliverable_discussion(ArrayList<PLMBomDlvrblDiscsnData> bom_deliverables_discussionsLst) {
		this.list_bom_deliverables_discussions = bom_deliverables_discussionsLst;
	}
	
	public boolean isDisplayed() {
		return displayed;
	}

	public void setDisplayed(boolean displayed) {
		this.displayed = displayed;
	}

	/**
	 * Returns the banner for list_deliverables_discussions
	 * 
	 * @return bannerDlvrblsDscssns (String)
	 */
	public String getBannerBmDlvrblsDscssns() {
		if (list_bom_deliverables_discussions != null) {
			if (!list_bom_deliverables_discussions.isEmpty()) {
				return list_bom_deliverables_discussions.size() + " Discussions found";
			} else {
				return " Discussions found for the entered search criteria.";
			}
		} else {
			return "";
		}
	}

	/**
	 * Returns the banner list_deliverables_discussions style
	 * 
	 * @return bannerDlvrblsDscssnsStyle (String)
	 */
	public String getBannerBmDlvrblsDscssnsStyle() {
		if (list_bom_deliverables_discussions != null) {
			if (!list_bom_deliverables_discussions.isEmpty()) {
				return "navy";
			} else {
				return "darkRed";
			}
		} else {
			return "";
		}
	}

	// OVERRIDEN METHODS ******************************************************
	/**
	 * Returns the MLIDeliverableDiscussion information as a String
	 * 
	 * @return type (String) 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer strMLIDeliverableDiscussion = new StringBuffer();
		
		strMLIDeliverableDiscussion
			.append(mli).append(" ")
			.append(list_bom_deliverables_discussions.toString());
		
		return strMLIDeliverableDiscussion.toString();
	}
	
}
