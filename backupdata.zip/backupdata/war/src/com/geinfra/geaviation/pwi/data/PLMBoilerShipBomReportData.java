/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBoilerShipBomReportData.java
 * @Creation date: 17-Feb-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;

public class PLMBoilerShipBomReportData {

	private String cntName;
	private String projectName;
	private String topLvlPart;
	private String selectedPrjName;
	private String selectedCntractName;
	private String selectedTopLvlPartName;
	private String station;
	private String stationLocation;
	private String customer;
	private String unitNo;
	private String wbsNo;
	private String productDesc;
	private String drawingNumber;
	private String drawingRev;
	private String itemNumber;
	private String partNumber;
	private String quantity;
	private String unitOfMeasure;
	private String description;
	private String weight;
	private String remarks;
	private String gePower="";
	private String shipBomRpt="";
	private int level;
	private String selectedPartAssmbly;
	private String selectedTakName;
	private String partAssmblyNo;
	private String partAssmblyDesc;
	private String partRev;
	private String partAssmblyNoDesc;
	private String taskNameDesc;
	private boolean contractSelctd;
	private boolean projectSelctd;
	private boolean taskSelectd;
	private String reportDate;
	
	/**
	 * @return the gePower
	 */
	public String getGePower() {
		return gePower;
	}
	/**
	 * @param gePower the gePower to set
	 */
	public void setGePower(String gePower) {
		this.gePower = gePower;
	}
	/**
	 * @return the shipBomRpt
	 */
	public String getShipBomRpt() {
		return shipBomRpt;
	}
	/**
	 * @param shipBomRpt the shipBomRpt to set
	 */
	public void setShipBomRpt(String shipBomRpt) {
		this.shipBomRpt = shipBomRpt;
	}
	/**
	 * @return the station
	 */
	public String getStation() {
		return station;
	}
	/**
	 * @param station the station to set
	 */
	public void setStation(String station) {
		this.station = station;
	}
	/**
	 * @return the stationLocation
	 */
	public String getStationLocation() {
		return stationLocation;
	}
	/**
	 * @param stationLocation the stationLocation to set
	 */
	public void setStationLocation(String stationLocation) {
		this.stationLocation = stationLocation;
	}
	/**
	 * @return the customer
	 */
	public String getCustomer() {
		return customer;
	}
	/**
	 * @param customer the customer to set
	 */
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	/**
	 * @return the unitNo
	 */
	public String getUnitNo() {
		return unitNo;
	}
	/**
	 * @param unitNo the unitNo to set
	 */
	public void setUnitNo(String unitNo) {
		this.unitNo = unitNo;
	}
	/**
	 * @return the wbsNo
	 */
	public String getWbsNo() {
		return wbsNo;
	}
	/**
	 * @param wbsNo the wbsNo to set
	 */
	public void setWbsNo(String wbsNo) {
		this.wbsNo = wbsNo;
	}
	/**
	 * @return the productDesc
	 */
	public String getProductDesc() {
		return productDesc;
	}
	/**
	 * @param productDesc the productDesc to set
	 */
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	/**
	 * @return the drawingNumber
	 */
	public String getDrawingNumber() {
		return drawingNumber;
	}
	/**
	 * @param drawingNumber the drawingNumber to set
	 */
	public void setDrawingNumber(String drawingNumber) {
		this.drawingNumber = drawingNumber;
	}
	/**
	 * @return the drawingRev
	 */
	public String getDrawingRev() {
		return drawingRev;
	}
	/**
	 * @param drawingRev the drawingRev to set
	 */
	public void setDrawingRev(String drawingRev) {
		this.drawingRev = drawingRev;
	}
	/**
	 * @return the itemNumber
	 */
	public String getItemNumber() {
		return itemNumber;
	}
	/**
	 * @param itemNumber the itemNumber to set
	 */
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}
	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	/**
	 * @return the quantity
	 */
	public String getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return the unitOfMeasure
	 */
	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}
	/**
	 * @param unitOfMeasure the unitOfMeasure to set
	 */
	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the weight
	 */
	public String getWeight() {
		return weight;
	}
	/**
	 * @param weight the weight to set
	 */
	public void setWeight(String weight) {
		this.weight = weight;
	}
	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}
	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	/**
	 * @return the selectedPrjName
	 */
	public String getSelectedPrjName() {
		return selectedPrjName;
	}
	/**
	 * @param selectedPrjName the selectedPrjName to set
	 */
	public void setSelectedPrjName(String selectedPrjName) {
		this.selectedPrjName = selectedPrjName;
	}
	/**
	 * @return the selectedCntractName
	 */
	public String getSelectedCntractName() {
		return selectedCntractName;
	}
	/**
	 * @param selectedCntractName the selectedCntractName to set
	 */
	public void setSelectedCntractName(String selectedCntractName) {
		this.selectedCntractName = selectedCntractName;
	}
	/**
	 * @return the selectedTopLvlPartName
	 */
	public String getSelectedTopLvlPartName() {
		return selectedTopLvlPartName;
	}
	/**
	 * @param selectedTopLvlPartName the selectedTopLvlPartName to set
	 */
	public void setSelectedTopLvlPartName(String selectedTopLvlPartName) {
		this.selectedTopLvlPartName = selectedTopLvlPartName;
	}
	/**
	 * @return the topLvlPart
	 */
	public String getTopLvlPart() {
		return topLvlPart;
	}
	/**
	 * @param topLvlPart the topLvlPart to set
	 */
	public void setTopLvlPart(String topLvlPart) {
		this.topLvlPart = topLvlPart;
	}
	/**
	 * @return the cntName
	 */
	public String getCntName() {
		return cntName;
	}
	/**
	 * @param cntName the cntName to set
	 */
	public void setCntName(String cntName) {
		this.cntName = cntName;
	}
	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}
	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	/**
	 * @return the level
	 */
	public int getLevel() {
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(int level) {
		this.level = level;
	}
	
	/**
	 * @return the selectedPartAssmbly
	 */
	public String getSelectedPartAssmbly() {
		return selectedPartAssmbly;
	}
	/**
	 * @param selectedPartAssmbly the selectedPartAssmbly to set
	 */
	public void setSelectedPartAssmbly(String selectedPartAssmbly) {
		this.selectedPartAssmbly = selectedPartAssmbly;
	}
	/**
	 * @return the selectedTakName
	 */
	public String getSelectedTakName() {
		return selectedTakName;
	}
	/**
	 * @param selectedTakName the selectedTakName to set
	 */
	public void setSelectedTakName(String selectedTakName) {
		this.selectedTakName = selectedTakName;
	}
	/**
	 * @return the partAssmblyNo
	 */
	public String getPartAssmblyNo() {
		return partAssmblyNo;
	}
	/**
	 * @param partAssmblyNo the partAssmblyNo to set
	 */
	public void setPartAssmblyNo(String partAssmblyNo) {
		this.partAssmblyNo = partAssmblyNo;
	}
	/**
	 * @return the partAssmblyDesc
	 */
	public String getPartAssmblyDesc() {
		return partAssmblyDesc;
	}
	/**
	 * @param partAssmblyDesc the partAssmblyDesc to set
	 */
	public void setPartAssmblyDesc(String partAssmblyDesc) {
		this.partAssmblyDesc = partAssmblyDesc;
	}
	/**
	 * @return the partRev
	 */
	public String getPartRev() {
		return partRev;
	}
	/**
	 * @param partRev the partRev to set
	 */
	public void setPartRev(String partRev) {
		this.partRev = partRev;
	}
	/**
	 * @return the partAssmblyNoDesc
	 */
	public String getPartAssmblyNoDesc() {
		return partAssmblyNoDesc;
	}
	/**
	 * @param partAssmblyNoDesc the partAssmblyNoDesc to set
	 */
	public void setPartAssmblyNoDesc(String partAssmblyNoDesc) {
		this.partAssmblyNoDesc = partAssmblyNoDesc;
	}
	/**
	 * @return the taskNameDesc
	 */
	public String getTaskNameDesc() {
		return taskNameDesc;
	}
	/**
	 * @param taskNameDesc the taskNameDesc to set
	 */
	public void setTaskNameDesc(String taskNameDesc) {
		this.taskNameDesc = taskNameDesc;
	}
	/**
	 * @return
	 */
	public boolean isContractSelctd() {
		return contractSelctd;
	}
	/**
	 * @param contractSelctd
	 */
	public void setContractSelctd(boolean contractSelctd) {
		this.contractSelctd = contractSelctd;
	}
	/**
	 * @return
	 */
	public boolean isProjectSelctd() {
		return projectSelctd;
	}
	/**
	 * @param projectSelctd
	 */
	public void setProjectSelctd(boolean projectSelctd) {
		this.projectSelctd = projectSelctd;
	}
	/**
	 * @return
	 */
	public boolean isTaskSelectd() {
		return taskSelectd;
	}
	/**
	 * @param taskSelectd
	 */
	public void setTaskSelectd(boolean taskSelectd) {
		this.taskSelectd = taskSelectd;
	}
	/**
	 * @return
	 */
	public String getReportDate() {
		return reportDate;
	}
	/**
	 * @param reportDate
	 */
	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}
	
	
	
	
	
}
