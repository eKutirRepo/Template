package com.geinfra.geaviation.pwi.dao;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.geinfra.geaviation.pwi.model.PWiFrequencyTypeVO;
import com.geinfra.geaviation.pwi.model.PWiUserCustomQueryVO;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 5, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Data access object interface for user custom queries.
 * 
 * Revision Log Aug 5, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public interface CustomQueryDAO {
	public PWiUserCustomQueryVO getUserCustomQueryById(Integer customId);

	public boolean addQueriesAsFavorite(PWiUserCustomQueryVO vo);

	public List<PWiFrequencyTypeVO> getSubscriptionFrquencies();

	public int cancelFavoriteQuerySubscriptionById(String strUserSSOId,
			int prtyCstmQrySeqId);

	public int modifySubscrptnFavoriteQueriesforUser(String strUserSSOId,
			Integer prtyCstmQrySeqId, Integer frqncyTypSeqId,
			Timestamp nextExeDate, String currQryRsltFlPthTxt,
			String prrQryRsltFlPthTxt);

	public int deleteFavoriteQueryById(Integer prtyCstmQrySeqId);

	public int deleteFavoriteQueriesForSearch(String strUserSSOId,
			Integer queryId);

	public List<PWiUserCustomQueryVO> getAllFavoriteQueriesforUser(String sso);

	public int insertCustomQuery(String sso, Integer queryId,
			String customName, String searchXml, String selectedColumnsXml,
			String currentResultPath, String previousResultPath,
			String queryProcessorId);

	public List<PWiUserCustomQueryVO> getSubscribedQueries();

	public boolean updateSubscriptionResult(Integer cstmQrySeqId, Date nxtdt,
			String prevFile, String currFile, String comparisonFile);
}
