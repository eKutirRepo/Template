/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved
 * @FileName PLMReportData.java
 * @Creation date: 17-Jul-2009
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

/**
 * ICMReportData is the Transfer/Value Object class for ICM Reports.
 */
public class PLMReportData {
	/**
	 * The String logDate
	 */
	private String logDate;
	/**
	 * The String logEvent
	 */
	private String logEvent;
	/**
	 * The String userName
	 */
	private String userName;
	/**
	 * The String userSsoId
	 */
	private String userSsoId;

	/**
	 * @return logDate
	 */
	public String getLogDate() {
		return logDate;
	}

	/**
	 * @param strLogDate
	 */
	public void setLogDate(String strLogDate) {
		this.logDate = strLogDate;
	}

	/**
	 * @return logEvent
	 */
	public String getLogEvent() {
		return logEvent;
	}

	/**
	 * @param strLogEvent
	 */
	public void setLogEvent(String strLogEvent) {
		this.logEvent = strLogEvent;
	}

	/**
	 * @return userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param strUserName
	 */
	public void setUserName(String strUserName) {
		this.userName = strUserName;
	}

	/**
	 * @return userSsoId
	 */
	public String getUserSsoId() {
		return userSsoId;
	}

	/**
	 * @param strUserSsoId
	 */
	public void setUserSsoId(String strSsoId) {
		this.userSsoId = strSsoId;
	}

}
