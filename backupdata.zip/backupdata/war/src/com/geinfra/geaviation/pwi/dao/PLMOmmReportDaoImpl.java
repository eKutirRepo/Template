/**
 * Copyright (C) 2012 GE Infra.
 * All rights reserved 
 * @FileName PLMOmmReportDaoImpl.java
 * @Creation date: 14-June-2012
 * @version 2.0.1
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMOmmReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMOmmReportDaoImpl extends SimpleJdbcDaoSupport implements PLMOmmReportDaoIfc {
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMOmmReportDaoImpl.class);
	
	/**
	 * This method is used for checkForValidSerialNo
	 * 
	 * @param serialNo
	 * @return int
	 * @throws PLMCommonException
	 */
	public int checkForValidSerialNo(String serialNo) throws PLMCommonException {	
		LOG.info("Entering checkForValidSerialNo Method");
		int serialCount = 0;
		try {
			LOG.info("Query for checking valid Serial # : " + PLMOfflineQueries.GET_OMM_VALID_SERIAL_NO);
			serialCount = getSimpleJdbcTemplate().queryForInt(PLMOfflineQueries.GET_OMM_VALID_SERIAL_NO, new Object[]{serialNo});
			LOG.info("Result of Serial Number Count  : " + serialCount);
		} catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting checkForValidSerialNo Method");
		return serialCount;
	}


	// Newly Added method for Getting list of part Names based on Serial Number
	/**
	 * This method is used to get List of Top parts.
	 * 
	 * @param serialNo
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMOmmReportData> getTopPartsList(String serialNo) throws PLMCommonException {

		LOG.info("Entering getTopLvlPartList Method");
		List<PLMOmmReportData> topPartList = new ArrayList<PLMOmmReportData>();
		try {
			LOG.info("serialNo  #  : " + serialNo);
			LOG.info("Executing TOP  Part Query  > " + PLMOfflineQueries.GET_TOP_PARTS_SERIAL_NO);
			topPartList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_TOP_PARTS_SERIAL_NO, new TopPartsMapper(), serialNo, serialNo);
			LOG.info("Size of  TOP Level Part  > " + topPartList.size());
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getTopLvlPartList Method");
		return topPartList;
	}


	/**
	 * Row mapper for getting TopPartsMapper
	 */
	private static final class TopPartsMapper implements ParameterizedRowMapper<PLMOmmReportData> {

		public PLMOmmReportData mapRow(ResultSet rs, int rowCount) throws SQLException {

			PLMOmmReportData tempData = new PLMOmmReportData();
			tempData.setGeSerialNum(rs.getString("SRLNUM"));
			tempData.setContract(rs.getString("CONTRACT"));
			tempData.setHardWarePrd(rs.getString("HW_PRDT"));
			tempData.setTopPartId(rs.getString("PART_ID")+"~"+rs.getString("PART_NM")+"~"+rs.getString("CONTRACT"));
			tempData.setTopPart(rs.getString("PART_NM"));
			tempData.setPartRev(rs.getString("PART_REV"));
			tempData.setPartDesc(rs.getString("PART_DESC"));
			tempData.setPartType(rs.getString("PART_TYPE"));
			return tempData;
		}
	}
	/**
	 * This method is used for getContractNo
	 * 
	 * @param serialNo
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getContractNo(String serialNo) throws PLMCommonException {
		LOG.info("Entering getContractNo Method");
//		List <String> contractNoList = new ArrayList<String>();
		String contractNo = "";
		try {
			LOG.info("Query for getting Contract No : " + PLMOfflineQueries.GET_OMM_CONTRACT_NO);
			List <String> contractNoList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_OMM_CONTRACT_NO, new ContractNoMapper(), new Object[]{serialNo});
			if(!PLMUtils.isEmptyList(contractNoList)){
				contractNo = PLMUtils.convertListToString(contractNoList);
				LOG.info("contractNoList>> "+contractNoList.size());
				LOG.info("Result of Contract Name : " + contractNo);
			} else {
				LOG.info("No Contract Name found");
			}
		} catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getContractNo Method");
		return contractNo;
	}
	
	/**
	 * This method is used for getOmmBomExplosionReport
	 * 
	 * @param topPartId
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<PLMOmmReportData>> getOmmBomExplosionReport(String topPartId, String topPartNm) throws PLMCommonException {
		LOG.info("Entering getOmmBomExplosionReport Method");
		List<PLMOmmReportData> ommBomExplosionResultList =  new ArrayList<PLMOmmReportData>();
		List<PLMOmmReportData> vt0ResultList =  new ArrayList<PLMOmmReportData>();
		List<PLMOmmReportData> vt4ResultList =  new ArrayList<PLMOmmReportData>();
		List<PLMOmmReportData> orderedResultList =  new ArrayList<PLMOmmReportData>();
		List<PLMOmmReportData> partCostGrpResultList =  new ArrayList<PLMOmmReportData>();
		Map<String, String> levelOnepartsMap = new HashMap<String, String>();
		Map<String, String> partCostGrpMap = new HashMap<String, String>();
		Map<String, String> costGrpUniqMap = new HashMap<String, String>();
		Map<String, List<PLMOmmReportData>> ommBomExplosionResultMap = new HashMap<String, List<PLMOmmReportData>>();
		String topLevelParent = topPartNm;
		boolean VTSerialNumExecuted = false;
		boolean VT0Executed = false;
		boolean VT1Executed = false;
		
		boolean VT21Executed = false;
		boolean VT22Executed = false;
		boolean VT23Executed = false;

		boolean VT2Executed = false;
		
		boolean VT31Executed = false;
		boolean VT32Executed = false;
		boolean VT33Executed = false;

		boolean VT3Executed = false;
		//boolean VT4Executed = false;
		//boolean VT5Executed = false;
		
		String timeStamp = null;
		String OMMR_VT0 = null;	
		//String OMMR_VTU = null;
		String OMMR_VT11 = null;
		String OMMR_VT12 = null;
		
		String OMMR_VT21 = null;
		String OMMR_VT22 = null;
		String OMMR_VT23 = null;
		

		String OMMR_VT21Query = null;
		String OMMR_VT22Query = null;
		String OMMR_VT23Query = null;
		
		String OMMR_VT13 = null;

		String OMMR_VT31 = null;
		String OMMR_VT32 = null;
		String OMMR_VT33 = null;

		String OMMR_VT31Query = null;
		String OMMR_VT32Query = null;
		String OMMR_VT33Query = null;
		
		String OMMR_VT14 = null;
		//String OMMR_VT15 = null;
		//String OMMR_VT16 = null;
		
		try {
			
			timeStamp = PLMUtils.volTableFormatDate();
			
			LOG.info("The timeStamp for the Report "+timeStamp);
			
			OMMR_VT0 = PLMConstants.OMMR_VT0.concat(timeStamp);
			OMMR_VT11 = PLMConstants.OMMR_VT11.concat(timeStamp);
			OMMR_VT12 = PLMConstants.OMMR_VT12.concat(timeStamp);

			OMMR_VT21 = PLMConstants.OMMR_VT21.concat(timeStamp);
			OMMR_VT22 = PLMConstants.OMMR_VT22.concat(timeStamp);
			OMMR_VT23 = PLMConstants.OMMR_VT23.concat(timeStamp);
			
			OMMR_VT13 = PLMConstants.OMMR_VT13.concat(timeStamp);
			
			OMMR_VT31 = PLMConstants.OMMR_VT31.concat(timeStamp);
			OMMR_VT32 = PLMConstants.OMMR_VT32.concat(timeStamp);
			OMMR_VT33 = PLMConstants.OMMR_VT33.concat(timeStamp);
			
			OMMR_VT14 = PLMConstants.OMMR_VT14.concat(timeStamp);
			//OMMR_VT15 = PLMConstants.OMMR_VT15.concat(timeStamp);
			//OMMR_VT16 = PLMConstants.OMMR_VT16.concat(timeStamp);
			
			
			/*String OMMR_VT0_query = PLMOfflineQueries.CREATE_OMM_VT_SERIAL_NUM_ASSC.replace(PLMConstants.OMMR_VT0, OMMR_VT0);
			
			String vtSerialNumAsscQuery = OMMR_VT0_query.replace("?", serialNo);
			LOG.info("Query for Creating VT_SERIAL_NUM_ASSC : " + vtSerialNumAsscQuery);
			getJdbcTemplate().execute(vtSerialNumAsscQuery);
			
			VTSerialNumExecuted = true;
			if (VTSerialNumExecuted) {
				String OMMR_VT0_COLSTS_query = PLMOfflineQueries.OMM_VT_SRL_NUM_COL_STAT.replace(PLMConstants.OMMR_VT0, OMMR_VT0);
				LOG.info("Query for Collect STATS OMM_VT_SRL_NUM_COL_STAT : " + OMMR_VT0_COLSTS_query);
				getJdbcTemplate().execute(OMMR_VT0_COLSTS_query);
			}
			
			LOG.info("Query for Getting Total No of Records of VT_SERIAL_NUM_ASSC : " + PLMOfflineQueries.GET_OMM_VT_SERIAL_NUM_ASSC_RECORD_COUNT.replace(PLMConstants.OMMR_VT0, OMMR_VT0));
			int vtSerialNumAsscNoOfRecords  = getSimpleJdbcTemplate().queryForInt(PLMOfflineQueries.GET_OMM_VT_SERIAL_NUM_ASSC_RECORD_COUNT.replace(PLMConstants.OMMR_VT0, OMMR_VT0));
			LOG.info("Result of OMMR_VT0 total records : " + vtSerialNumAsscNoOfRecords);
			*/
			//if(vtSerialNumAsscNoOfRecords > 0) {
				LOG.info("Query for Creating VT11 : " + PLMOfflineQueries.CREATE_OMM_VT11.replace(PLMConstants.OMMR_VT11, OMMR_VT11)
						.replace("?", "'"+topPartId+"'"));
				String OMMR_VT11_query = PLMOfflineQueries.CREATE_OMM_VT11.replace(PLMConstants.OMMR_VT11, OMMR_VT11).replace("?", "'"+topPartId+"'");
				getJdbcTemplate().execute(OMMR_VT11_query);
				VT0Executed = true;
				if (VT0Executed) {
					LOG.info("Query for Collect STATS VT0_COL_STATS : " + PLMOfflineQueries.VT0_COL_STATS.replace(PLMConstants.OMMR_VT11, OMMR_VT11));
					getJdbcTemplate().execute(PLMOfflineQueries.VT0_COL_STATS.replace(PLMConstants.OMMR_VT11, OMMR_VT11));
				}
				LOG.info("Query for Getting OMMR_VT11 : " + PLMOfflineQueries.GET_OMM_VT0.replace(PLMConstants.OMMR_VT11, OMMR_VT11));
				vt0ResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_OMM_VT0.replace(PLMConstants.OMMR_VT11, OMMR_VT11),new OmmVT0ResultMapper());
				LOG.info("Result of OMMR_VT11 : " + vt0ResultList.size());
				
				levelOnepartsMap = getLevelOneParts(vt0ResultList);
				
				if(!PLMUtils.isEmptyList(vt0ResultList)) {
					LOG.info("Query for Getting Cost Group : " + PLMOfflineQueries.GET_OMM_COST_GROUP.replace(PLMConstants.OMMR_VT11, OMMR_VT11));
					partCostGrpResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_OMM_COST_GROUP.replace(PLMConstants.OMMR_VT11, OMMR_VT11),new OmmVTGrpResultMapper());
					for (PLMOmmReportData data : partCostGrpResultList) {
						partCostGrpMap.put(data.getPartNo(), data.getCostGroup());
						//costGrpUniqMap.put(data.getCostGroup(),data.getCostGroup());
					}
					
					if(levelOnepartsMap.size() != partCostGrpMap.size()){
						for (Map.Entry<String, String> entry : levelOnepartsMap.entrySet()) {
							if(partCostGrpMap.get(entry.getKey()) == null || partCostGrpMap.get(entry.getKey()).trim().equals("")){
								partCostGrpMap.put(entry.getKey(), "OTHERS");
							}
						}
					}
					
					if(partCostGrpMap.size() > 0){
						for (Map.Entry<String, String> entry : partCostGrpMap.entrySet()) {
							if(entry.getValue() == null || entry.getValue().trim().equals("")){
								costGrpUniqMap.put(entry.getValue(), "OTHERS");
								partCostGrpMap.put(entry.getKey(),"OTHERS");
							}else{
								costGrpUniqMap.put(entry.getValue(), entry.getValue());
							}
						}
					}
					
					
					/*for(int i = 0 ; i < vt0ResultList.size();i++) {
						if (vt0ResultList.get(i).getBomLevel() == 1){
							topLevelParent = vt0ResultList.get(i).getParentName();
							LOG.info("Top Level Parent : " + topLevelParent);
							break;
						}
					}*/
					LOG.info("The Top Level Part Name --> "+topLevelParent);
					if(!PLMUtils.isEmpty(topLevelParent)){
						orderedResultList = formTreeStruct(vt0ResultList, topLevelParent, partCostGrpMap);
						LOG.info("Result of VT0 After Ordering : " + orderedResultList.size());
						if(!PLMUtils.isEmptyList(orderedResultList)){
							LOG.info("Query for Creating OMMR_VT12 : " + PLMOfflineQueries.CREATE_OMM_VT1.replace(PLMConstants.OMMR_VT12, OMMR_VT12));
							getJdbcTemplate().execute(PLMOfflineQueries.CREATE_OMM_VT1.replace(PLMConstants.OMMR_VT12, OMMR_VT12));
							VT1Executed = true;
							LOG.info("VT1Executed "+VT1Executed);
							final List<PLMOmmReportData> insertResultList = orderedResultList;
							int[] updateCount = null;
							LOG.info("Insert Query :  " + PLMOfflineQueries.SET_OMM_VT1.replace(PLMConstants.OMMR_VT12, OMMR_VT12));
							updateCount  = getSimpleJdbcTemplate().getJdbcOperations().batchUpdate(PLMOfflineQueries.SET_OMM_VT1.replace(PLMConstants.OMMR_VT12, OMMR_VT12), new BatchPreparedStatementSetter() 
							{
							public void setValues(PreparedStatement ps,int iCount)throws SQLException {
								ps.setInt(1,iCount);
								ps.setInt(2, insertResultList.get(iCount).getBomLevel());
								ps.setString(3, insertResultList.get(iCount).getParentId());
								ps.setString(4, insertResultList.get(iCount).getParentName());
								ps.setString(5, insertResultList.get(iCount).getChildId());
								ps.setString(6, insertResultList.get(iCount).getPartNo());
								ps.setString(7, insertResultList.get(iCount).getPartType());
								ps.setString(8, insertResultList.get(iCount).getMli());
								ps.setString(9, insertResultList.get(iCount).getPin());
								ps.setString(10, insertResultList.get(iCount).getSuffix());
								ps.setInt(11, insertResultList.get(iCount).getQty());
								ps.setString(12, insertResultList.get(iCount).getCostGroup());

							}
							public int getBatchSize() {
								return insertResultList.size();
							}
							});
							LOG.info("Total inserted Records : " + updateCount.length);
							LOG.info("Query for Collect STATS OMM_VT1_COL_STATS : " + PLMOfflineQueries.OMM_VT1_COL_STATS.replace(PLMConstants.OMMR_VT12, OMMR_VT12));
							getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT1_COL_STATS.replace(PLMConstants.OMMR_VT12, OMMR_VT12));
							
							//Start: Added New Tables
							OMMR_VT21Query = PLMOfflineQueries.CREATE_OMM_VT21.replace(PLMConstants.OMMR_VT12,OMMR_VT12);
							OMMR_VT21Query = OMMR_VT21Query.replace(PLMConstants.OMMR_VT21, OMMR_VT21);
							
							LOG.info("Query for Creating VT21 : " + OMMR_VT21Query);
							getJdbcTemplate().execute(OMMR_VT21Query);
							VT21Executed = true;
							if (VT21Executed) {
								LOG.info("Query for Collect STATS VT21_COL_STATS 1 : " + PLMOfflineQueries.OMM_VT21_COL_STATS1.replace(PLMConstants.OMMR_VT21, OMMR_VT21));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT21_COL_STATS1.replace(PLMConstants.OMMR_VT21, OMMR_VT21));	
								LOG.info("Query for Collect STATS VT21_COL_STATS 2 : " + PLMOfflineQueries.OMM_VT21_COL_STATS2.replace(PLMConstants.OMMR_VT21, OMMR_VT21));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT21_COL_STATS2.replace(PLMConstants.OMMR_VT21, OMMR_VT21));			
							}
							
							OMMR_VT22Query = PLMOfflineQueries.CREATE_OMM_VT22.replace(PLMConstants.OMMR_VT22,OMMR_VT22);
							OMMR_VT22Query = OMMR_VT22Query.replace(PLMConstants.OMMR_VT21, OMMR_VT21);
							
							LOG.info("Query for Creating VT22 : " + OMMR_VT22Query);
							getJdbcTemplate().execute(OMMR_VT22Query);
							VT22Executed = true;
							if (VT22Executed) {
								LOG.info("Query for Collect STATS VT22_COL_STATS 1 : " + PLMOfflineQueries.OMM_VT22_COL_STATS1.replace(PLMConstants.OMMR_VT22, OMMR_VT22));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT22_COL_STATS1.replace(PLMConstants.OMMR_VT22, OMMR_VT22));	
								LOG.info("Query for Collect STATS VT22_COL_STATS 2 : " + PLMOfflineQueries.OMM_VT22_COL_STATS2.replace(PLMConstants.OMMR_VT22, OMMR_VT22));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT22_COL_STATS2.replace(PLMConstants.OMMR_VT22, OMMR_VT22));			
							}
							
							OMMR_VT23Query = PLMOfflineQueries.CREATE_OMM_VT23.replace(PLMConstants.OMMR_VT23,OMMR_VT23);
							OMMR_VT23Query = OMMR_VT23Query.replace(PLMConstants.OMMR_VT22, OMMR_VT22);
							
							
							LOG.info("Query for Creating VT23 : " + OMMR_VT23Query);
							getJdbcTemplate().execute(OMMR_VT23Query);
							VT23Executed = true;
							if (VT23Executed) {
								LOG.info("Query for Collect STATS VT23_COL_STATS 1 : " + PLMOfflineQueries.OMM_VT23_COL_STATS1.replace(PLMConstants.OMMR_VT23, OMMR_VT23));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT23_COL_STATS1.replace(PLMConstants.OMMR_VT23, OMMR_VT23));	
								LOG.info("Query for Collect STATS VT23_COL_STATS 2 : " + PLMOfflineQueries.OMM_VT23_COL_STATS2.replace(PLMConstants.OMMR_VT23, OMMR_VT23));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT23_COL_STATS2.replace(PLMConstants.OMMR_VT23, OMMR_VT23));			
							}
							
							//End: Added New Tables
							
							String OMMR_VT13_query = PLMOfflineQueries.CREATE_OMM_VT2.replace(PLMConstants.OMMR_VT13, OMMR_VT13);
							OMMR_VT13_query = OMMR_VT13_query.replace(PLMConstants.OMMR_VT23, OMMR_VT23);
							
							LOG.info("Query for Creating OMMR_VT13 : " + OMMR_VT13_query);
							getJdbcTemplate().execute(OMMR_VT13_query);
							VT2Executed = true;
							if (VT2Executed) {
								LOG.info("Query for Collect STATS OMM_VT2_COL_STATS1 : " + PLMOfflineQueries.OMM_VT2_COL_STATS1.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT2_COL_STATS1.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
								LOG.info("Query for Collect STATS OMM_VT2_COL_STATS2 : " + PLMOfflineQueries.OMM_VT2_COL_STATS2.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT2_COL_STATS2.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
								LOG.info("Query for Collect STATS OMM_VT2_COL_STATS3 : " + PLMOfflineQueries.OMM_VT2_COL_STATS3.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT2_COL_STATS3.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
								LOG.info("Query for Collect STATS OMM_VT2_COL_STATS4 : " + PLMOfflineQueries.OMM_VT2_COL_STATS4.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT2_COL_STATS4.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
								LOG.info("Query for Collect STATS OMM_VT2_COL_STATS5 : " + PLMOfflineQueries.OMM_VT2_COL_STATS5.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT2_COL_STATS5.replace(PLMConstants.OMMR_VT13, OMMR_VT13));
							}
							int count  = getSimpleJdbcTemplate().queryForInt("SELECT COUNT(*) FROM "+OMMR_VT13);
							LOG.info("Result of OMMR_VT13 : " + count);
							
							//Start: Added New Queries
							
							OMMR_VT31Query = PLMOfflineQueries.CREATE_OMM_VT31.replace(PLMConstants.OMMR_VT31,OMMR_VT31);
							OMMR_VT31Query = OMMR_VT31Query.replace(PLMConstants.OMMR_VT12, OMMR_VT12);
							
							LOG.info("Query for Creating VT31 : " + OMMR_VT31Query);
							getJdbcTemplate().execute(OMMR_VT31Query);
							VT31Executed = true;
							if (VT31Executed) {
								/*LOG.info("Query for Collect STATS VT31_COL_STATS : " + PLMOfflineQueries.OMM_VT31_COL_STATS.replace(PLMConstants.OMMR_VT31,OMMR_VT31));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT31_COL_STATS.replace(PLMConstants.OMMR_VT31,OMMR_VT31));*/	
								LOG.info("Query for Collect STATS VT31_COL_STATS1 : " + PLMOfflineQueries.OMM_VT31_COL_STATS1.replace(PLMConstants.OMMR_VT31,OMMR_VT31));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT31_COL_STATS1.replace(PLMConstants.OMMR_VT31,OMMR_VT31));	
								LOG.info("Query for Collect STATS VT31_COL_STATS2 : " + PLMOfflineQueries.OMM_VT31_COL_STATS2.replace(PLMConstants.OMMR_VT31,OMMR_VT31));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT31_COL_STATS2.replace(PLMConstants.OMMR_VT31,OMMR_VT31));	
							}
							
							OMMR_VT32Query = PLMOfflineQueries.CREATE_OMM_VT32.replace(PLMConstants.OMMR_VT32,OMMR_VT32);
							OMMR_VT32Query = OMMR_VT32Query.replace(PLMConstants.OMMR_VT31,OMMR_VT31);
							
							LOG.info("Query for Creating VT32 : " + OMMR_VT32Query);
							getJdbcTemplate().execute(OMMR_VT32Query);
							VT32Executed = true;
							if (VT32Executed) {
								/*LOG.info("Query for Collect STATS VT32_COL_STATS : " + PLMOfflineQueries.OMM_VT32_COL_STATS.replace(PLMConstants.OMMR_VT32,OMMR_VT32));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT32_COL_STATS.replace(PLMConstants.OMMR_VT32,OMMR_VT32));*/	
								LOG.info("Query for Collect STATS VT32_COL_STATS1 : " + PLMOfflineQueries.OMM_VT32_COL_STATS1.replace(PLMConstants.OMMR_VT32,OMMR_VT32));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT32_COL_STATS1.replace(PLMConstants.OMMR_VT32,OMMR_VT32));	
								LOG.info("Query for Collect STATS VT32_COL_STATS2 : " + PLMOfflineQueries.OMM_VT32_COL_STATS2.replace(PLMConstants.OMMR_VT32,OMMR_VT32));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT32_COL_STATS2.replace(PLMConstants.OMMR_VT32,OMMR_VT32));	
							}

							OMMR_VT33Query = PLMOfflineQueries.CREATE_OMM_VT33.replace(PLMConstants.OMMR_VT33,OMMR_VT33);
							OMMR_VT33Query = OMMR_VT33Query.replace(PLMConstants.OMMR_VT32,OMMR_VT32);
							
							LOG.info("Query for Creating VT33 : " +OMMR_VT33Query);
							getJdbcTemplate().execute(OMMR_VT33Query);
							VT33Executed = true;
							if (VT33Executed) {
								LOG.info("Query for Collect STATS VT33_COL_STATS : " + PLMOfflineQueries.OMM_VT33_COL_STATS.replace(PLMConstants.OMMR_VT33,OMMR_VT33));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT33_COL_STATS.replace(PLMConstants.OMMR_VT33,OMMR_VT33));	
							}
							
							//End: Added New Queries
							
							String OMMR_VT14_query = PLMOfflineQueries.CREATE_OMM_VT3.replace(PLMConstants.OMMR_VT14, OMMR_VT14);
							OMMR_VT14_query = OMMR_VT14_query.replace(PLMConstants.OMMR_VT33,OMMR_VT33);
							
							LOG.info("Query for Creating VT3 : " + OMMR_VT14_query);
							getJdbcTemplate().execute(OMMR_VT14_query);
							VT3Executed = true;
							LOG.info("VT3Executed "+VT3Executed);
							/*if (VT3Executed) {
								LOG.info("Query for Collect STATS VT3_COL_STATS : " + PLMOfflineQueries.OMM_VT3_COL_STATS.replace(PLMConstants.OMMR_VT14, OMMR_VT14));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT3_COL_STATS.replace(PLMConstants.OMMR_VT14, OMMR_VT14));								
							}
							count  = getSimpleJdbcTemplate().queryForInt("SELECT COUNT(*) FROM "+OMMR_VT14);
							LOG.info("Result of OMMR_VT14 : " + count);
							String OMMR_VT15_query = PLMOfflineQueries.CREATE_OMM_VT4.replace(PLMConstants.OMMR_VT15, OMMR_VT15);
							LOG.info("Query for Creating OMMR_VT15 : " + OMMR_VT15_query);
							String OMMR_VT151_query = OMMR_VT15_query.replace(PLMConstants.OMMR_VT13, OMMR_VT13);
							getJdbcTemplate().execute(OMMR_VT151_query.replace(PLMConstants.OMMR_VT14, OMMR_VT14));
							VT4Executed = true;
							if (VT4Executed) {
								LOG.info("Query for Collect STATS VT4_COL_STATS : " + PLMOfflineQueries.OMM_VT4_COL_STATS.replace(PLMConstants.OMMR_VT15, OMMR_VT15));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT4_COL_STATS.replace(PLMConstants.OMMR_VT15, OMMR_VT15));								
							}
							
							String OMMR_VT16_query = PLMOfflineQueries.CREATE_OMM_VT5.replace(PLMConstants.OMMR_VT16, OMMR_VT16);
							LOG.info("Query for Creating OMMR_VT16 : " + OMMR_VT16_query);							
							getJdbcTemplate().execute(OMMR_VT16_query.replace(PLMConstants.OMMR_VT15, OMMR_VT15));
							VT5Executed = true;
							if (VT5Executed) {
								LOG.info("Query for Collect STATS VT4_COL_STATS : " + PLMOfflineQueries.OMM_VT5_COL_STATS.replace(PLMConstants.OMMR_VT16, OMMR_VT16));
								getJdbcTemplate().execute(PLMOfflineQueries.OMM_VT5_COL_STATS.replace(PLMConstants.OMMR_VT16, OMMR_VT16));								
							}	*/						
							
							
							for (Map.Entry<String, String> costGrpMap : costGrpUniqMap.entrySet()) {
								LOG.info("Query for Getting OMMR_VT16 : " + PLMOfflineQueries.GET_OMM_VT4.replace(PLMConstants.OMMR_VT13, OMMR_VT13).replace(PLMConstants.OMMR_VT14, OMMR_VT14));
								vt4ResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_OMM_VT4.replace(PLMConstants.OMMR_VT13, OMMR_VT13).replace(PLMConstants.OMMR_VT14, OMMR_VT14),new OmmBomExplosionResultMapper(), new Object[]{costGrpMap.getKey()});
								LOG.info("Result of OMMR_VT16 For Cost Group : "+costGrpMap.getKey()+" Count = "+ vt4ResultList.size());
								if(!PLMUtils.isEmptyList(vt4ResultList)){
									ommBomExplosionResultList = separatePartAndDocument(vt4ResultList);
									ommBomExplosionResultMap.put(costGrpMap.getKey(), ommBomExplosionResultList);
									LOG.info("Result of Bom Explosion For Cost Group : "+costGrpMap.getKey()+" Count = "+ommBomExplosionResultList.size());
								} else {
									LOG.info("OMMR_VT16 Returns Empty Result For Cost Group : "+costGrpMap.getKey());
								}
							}							
						} else {
							LOG.info("Ordering failed : Returns Empty Result");
						}
					} else {
						LOG.info("Ordering failed : No Top Level Parent found");
					}
				} else {
					LOG.info("OMMR_VT11 Returns Empty Result");
				}
			/*} else {
				LOG.info("OMMR_VT0 Returns Empty Result");
			}*/
		} catch(DataAccessException e){			
			PLMUtils.checkException(e.getMessage());
		} /*finally {
			try {
				dropVolatileTablesForOmmReport(VTSerialNumExecuted,VT0Executed,VT1Executed,
						VT21Executed, VT22Executed, VT23Executed, VT2Executed,
						VT31Executed, VT32Executed, VT33Executed, VT3Executed,
						VT4Executed, timeStamp);
			} catch(DataAccessException e) {
				LOG.info("Exception occurred while dropping the tables in dropVolatileTablesForOmmReport method : " + e.getMessage());
				PLMUtils.checkException(e.getMessage());
			}
		}*/
		LOG.info("Exiting getOmmBomExplosionReport Method");
		return ommBomExplosionResultMap;
	}
	
	
	/**
	 * This method is used for getLevelOneParts
	 * 
	 * @param vt0ResultList
	 * @return Map
	 */
	public Map<String, String> getLevelOneParts(List<PLMOmmReportData> vt0ResultList){		
		Map<String, String> levelOnepartsMap = new HashMap<String, String>();
		for (PLMOmmReportData tempData : vt0ResultList) {
			if(tempData.getBomLevel() == 1){
				levelOnepartsMap.put(tempData.getPartNo(),tempData.getPartNo());
			}
		}
		return levelOnepartsMap;
	}
	
	/**
	 * This method is used for formTreeStruct
	 * 
	 * @param vt0ResultList,topLevelParent,partCostGrpMap
	 * @return List
	 */
	
	public List<PLMOmmReportData> formTreeStruct(List<PLMOmmReportData> vt0ResultList,String topLevelParent, Map<String, String> partCostGrpMap) {
		LOG.info("Entering formTreeStruct Method");
		int bomLevel = 1;
		int index;
		int prevIndex = -1;
		String parentName = topLevelParent;
		String levelOneCostGrp = "";
		List<PLMOmmReportData> orderedResultList =  new ArrayList<PLMOmmReportData>();
		while(true){
			index = findChildrens(vt0ResultList,parentName,prevIndex,bomLevel);
			if(index == -1){			
				if(bomLevel == 1){
					break;			
				}
				vt0ResultList.get(prevIndex).setPathFlag("COMPLETED");
				bomLevel = 1;
				parentName = topLevelParent;
			} else {
				if(!vt0ResultList.get(index).getPathFlag().equals("VISITED")){
					if(bomLevel == 1){
						levelOneCostGrp = partCostGrpMap.get(vt0ResultList.get(index).getPartNo());
					}
					vt0ResultList.get(index).setPathFlag("VISITED");
					vt0ResultList.get(index).setCostGroup(levelOneCostGrp);
					orderedResultList.add(vt0ResultList.get(index));
				}
				prevIndex = index;	
				bomLevel = bomLevel + 1;
				parentName = vt0ResultList.get(index).getPartNo();
			}
		}
		LOG.info("Exiting formTreeStruct Method");
		return orderedResultList;
	}
	/**
	 * This method is used for findChildrens
	 * 
	 * @param vt0ResultList,parentName,prevIndex,bomLevel
	 * @return int
	 */
	public int findChildrens(List<PLMOmmReportData> vt0ResultList,String parentName,int prevIndex, int bomLevel) {
		int retIndex = -1;
		for(int i = 0 ; i < vt0ResultList.size();i++) {
			if(vt0ResultList.get(i).getParentName().equals(parentName) && vt0ResultList.get(i).getBomLevel() == bomLevel){
				if(bomLevel == 1) {
					if(!vt0ResultList.get(i).getPathFlag().equals("COMPLETED")){
						retIndex = i;
						break;
					}
				} else {
					if(vt0ResultList.get(i).getParentName().equals(vt0ResultList.get(prevIndex).getPartNo())){
						if(!vt0ResultList.get(i).getPathFlag().equals("COMPLETED")){
							retIndex = i;
							break;
						} 
					}
				}
			}
		}
		return retIndex;
	}
	
	/**
	 * This method is used for separatePartAndDocument
	 * 
	 * @param vt4ResultListevel
	 * @return List
	 */
	public List<PLMOmmReportData> separatePartAndDocument(List<PLMOmmReportData> vt4ResultList){
		LOG.info("Entering separatePartAndDocument Method");
		List<PLMOmmReportData> ommBomExplosionResultList =  new ArrayList<PLMOmmReportData>();
		int maxRecordId =  vt4ResultList.get(vt4ResultList.size() - 1).getRecordId();
		for(int recordId = 0 ; recordId <= maxRecordId ; recordId++){
			List<PLMOmmReportData> recordIdList = getRecordIds(vt4ResultList,recordId);
			if(!PLMUtils.isEmptyList(recordIdList)){
				for(int i = 0 ; i < recordIdList.size(); i++){
					if(i == 0) {
						ommBomExplosionResultList.add(setPartAsType(recordIdList.get(i)));
						if(!PLMUtils.isEmpty(recordIdList.get(i).getDocName())){
							ommBomExplosionResultList.add(setDocumentAsType(recordIdList.get(i)));
						}
					} else {
						if(!PLMUtils.isEmpty(recordIdList.get(i).getDocName())){
							ommBomExplosionResultList.add(setDocumentAsType(recordIdList.get(i)));
						}
					}
				}
			}
		}
		LOG.info("Exiting separatePartAndDocument Method");
		return ommBomExplosionResultList;
	}
	
	/**
	 * This method is used for getRecordIds
	 * 
	 * @param vt4ResultList,recordId
	 * @return List
	 */
	public List<PLMOmmReportData> getRecordIds (List<PLMOmmReportData> vt4ResultList, int recordId){
		List<PLMOmmReportData> recordIdList =  new ArrayList<PLMOmmReportData>();
		for(int i = 0 ; i < vt4ResultList.size() ; i++){
			if(recordId == vt4ResultList.get(i).getRecordId()){
				recordIdList.add(vt4ResultList.get(i));
			}
		}
		return recordIdList;
	}
	
	/**
	 * This method is used for setPartAsType
	 * 
	 * @param ommPartRefData
	 * @return PLMOmmReportData
	 */
	public PLMOmmReportData setPartAsType(PLMOmmReportData ommPartRefData){
		PLMOmmReportData ommPartData = copyObject(ommPartRefData); 
		ommPartData.setLogicalIndicator("");
		//ommPartData.setType("Part");
		/*if (ommPartData.getPartType()==null)
		LOG.info("ommPartData.getPartType() -->"+ommPartData.getPartType());*/		
		ommPartData.setType(ommPartData.getPartType());
		ommPartData.setDocName("");
		ommPartData.setDocRev("");
		ommPartData.setDocState("");
		ommPartData.setDocDesc("");
		ommPartData.setSecurityClass("");
		ommPartData.setExportClass("");
		ommPartData.setGeDwgCriticalCode("");
		return ommPartData;
	}
	
	/**
	 * This method is used for setDocumentAsType
	 * 
	 * @param ommPartRefData
	 * @return PLMOmmReportData
	 */
	public PLMOmmReportData setDocumentAsType(PLMOmmReportData ommDocRefData){
		PLMOmmReportData ommDocData = copyObject(ommDocRefData);
		ommDocData.setMli("");
		ommDocData.setPin("");
		ommDocData.setSuffix("");
		//ommDocData.setPartFamily("");
		//ommDocData.setType("Document");
		/*if (ommDocData.getDocType()==null)
		LOG.info("ommPartData.getPartType() -->"+ommDocData.getDocType());*/
		ommDocData.setType(ommDocData.getDocType());
		ommDocData.setPartNo(ommDocData.getDocName());
		ommDocData.setPartRev(ommDocData.getDocRev());
		ommDocData.setPartState(ommDocData.getDocState());
		ommDocData.setPartDesc(ommDocData.getDocDesc());
		ommDocData.setPartUom("");
		ommDocData.setQty(0);
		ommDocData.setDocName("");
		ommDocData.setDocRev("");
		ommDocData.setDocState("");
		ommDocData.setDocDesc("");
		return ommDocData;
	}
	/**
	 * This method is used for copyObject
	 * 
	 * @param refObj
	 * @return PLMOmmReportData
	 */
	public PLMOmmReportData copyObject(PLMOmmReportData refObj){
		PLMOmmReportData copiedObj = new PLMOmmReportData();
		copiedObj.setBomLevel(refObj.getBomLevel());
		copiedObj.setLogicalIndicator(refObj.getLogicalIndicator());
		copiedObj.setMli(refObj.getMli());
		copiedObj.setPin(refObj.getPin());
		copiedObj.setSuffix(refObj.getSuffix());
		copiedObj.setType(refObj.getType());
		copiedObj.setPartType(refObj.getPartType());
		copiedObj.setDocType(refObj.getDocType());
		copiedObj.setPartNo(refObj.getPartNo());
		copiedObj.setPartRev(refObj.getPartRev());
		copiedObj.setPartState(refObj.getPartState());
		copiedObj.setPartDesc(refObj.getPartDesc());
		copiedObj.setQty(refObj.getQty());
		copiedObj.setPartUom(refObj.getPartUom());
		copiedObj.setDocName(refObj.getDocName());
		copiedObj.setDocRev(refObj.getDocRev());
		copiedObj.setDocState(refObj.getDocState());
		copiedObj.setDocDesc(refObj.getDocDesc());
		copiedObj.setSecurityClass(refObj.getSecurityClass());
		copiedObj.setExportClass(refObj.getExportClass());
		copiedObj.setParentName(refObj.getParentName());
		copiedObj.setGeDwgCriticalCode(refObj.getGeDwgCriticalCode());
		copiedObj.setPartFamily(refObj.getPartFamily());
		copiedObj.setPartFamilyTitle(refObj.getPartFamilyTitle());
		copiedObj.setCostGroup(refObj.getCostGroup());
		copiedObj.setRecordId(refObj.getRecordId());
		return copiedObj;
	}
	
	
	/*private void dropVolatileTablesForOmmReport(boolean VTSerialNumExecuted,boolean VT0Executed, 
			boolean VT1Executed,
			boolean VT21Executed, boolean VT22Executed, boolean VT23Executed, boolean VT2Executed,
			boolean VT31Executed, boolean VT32Executed, boolean VT33Executed, boolean VT3Executed, 
			boolean VT4Executed, String timeStamp) throws PLMCommonException {
		
		LOG.info("Entering dropVolatileTablesForOmmReport Method");
		
		
		String DROP_OMMR_VT0;
		String DROP_OMMR_VT11;
		String DROP_OMMR_VT12;

		String DROP_OMMR_VT21;
		String DROP_OMMR_VT22;
		String DROP_OMMR_VT23;
		
		String DROP_OMMR_VT13;
		
		String DROP_OMMR_VT31;
		String DROP_OMMR_VT32;
		String DROP_OMMR_VT33;
		
		String DROP_OMMR_VT14;
		String DROP_OMMR_VT15;
		
		DROP_OMMR_VT0 = PLMConstants.OMMR_VT0.concat(timeStamp);
		DROP_OMMR_VT11 = PLMConstants.OMMR_VT11.concat(timeStamp);
		DROP_OMMR_VT12 = PLMConstants.OMMR_VT12.concat(timeStamp);

		DROP_OMMR_VT21 = PLMConstants.OMMR_VT21.concat(timeStamp);
		DROP_OMMR_VT22 = PLMConstants.OMMR_VT22.concat(timeStamp);
		DROP_OMMR_VT23 = PLMConstants.OMMR_VT23.concat(timeStamp);
		
		DROP_OMMR_VT13 = PLMConstants.OMMR_VT13.concat(timeStamp);
		

		DROP_OMMR_VT31 = PLMConstants.OMMR_VT31.concat(timeStamp);
		DROP_OMMR_VT32 = PLMConstants.OMMR_VT32.concat(timeStamp);
		DROP_OMMR_VT33 = PLMConstants.OMMR_VT33.concat(timeStamp);
		
		DROP_OMMR_VT14 = PLMConstants.OMMR_VT14.concat(timeStamp);
		DROP_OMMR_VT15 = PLMConstants.OMMR_VT15.concat(timeStamp);
		
		String OMMR_VT0_dropQuery = PLMOfflineQueries.DROP_OMM_VT_SERIAL_NUM_ASSC.replace(PLMConstants.OMMR_VT0, DROP_OMMR_VT0);
		String OMMR_VT11_dropQuery = PLMOfflineQueries.DROP_OMM_VT0.replace(PLMConstants.OMMR_VT11, DROP_OMMR_VT11);
		String OMMR_VT12_dropQuery = PLMOfflineQueries.DROP_OMM_VT1.replace(PLMConstants.OMMR_VT12, DROP_OMMR_VT12);

		String OMMR_VT21_dropQuery = PLMOfflineQueries.DROP_OMM_VT21.replace(PLMConstants.OMMR_VT21, DROP_OMMR_VT21);
		String OMMR_VT22_dropQuery = PLMOfflineQueries.DROP_OMM_VT22.replace(PLMConstants.OMMR_VT22, DROP_OMMR_VT22);
		String OMMR_VT23_dropQuery = PLMOfflineQueries.DROP_OMM_VT23.replace(PLMConstants.OMMR_VT23, DROP_OMMR_VT23);
		
		String OMMR_VT13_dropQuery = PLMOfflineQueries.DROP_OMM_VT2.replace(PLMConstants.OMMR_VT13, DROP_OMMR_VT13);

		String OMMR_VT31_dropQuery = PLMOfflineQueries.DROP_OMM_VT31.replace(PLMConstants.OMMR_VT31, DROP_OMMR_VT31);
		String OMMR_VT32_dropQuery = PLMOfflineQueries.DROP_OMM_VT32.replace(PLMConstants.OMMR_VT32, DROP_OMMR_VT32);
		String OMMR_VT33_dropQuery = PLMOfflineQueries.DROP_OMM_VT33.replace(PLMConstants.OMMR_VT33, DROP_OMMR_VT33);
		
		String OMMR_VT14_dropQuery = PLMOfflineQueries.DROP_OMM_VT3.replace(PLMConstants.OMMR_VT14, DROP_OMMR_VT14);
		String OMMR_VT15_dropQuery = PLMOfflineQueries.DROP_OMM_VT4.replace(PLMConstants.OMMR_VT15, DROP_OMMR_VT15);
		
		if (VTSerialNumExecuted) {
			LOG.info("Query for Drop OMMR_VT0 : " + OMMR_VT0_dropQuery);
			getJdbcTemplate().execute(OMMR_VT0_dropQuery);
			VTSerialNumExecuted = false;
		}
		if (VT0Executed) {
			LOG.info("Query for Drop OMMR_VT11 : " + OMMR_VT11_dropQuery);
			getJdbcTemplate().execute(OMMR_VT11_dropQuery);
			VT0Executed = false;
		}
		if (VT1Executed) {
			LOG.info("Query for Drop OMMR_VT12 : " + OMMR_VT12_dropQuery);
			getJdbcTemplate().execute(OMMR_VT12_dropQuery);
			VT1Executed = false;
		}
		
		if (VT21Executed) {
			LOG.info("Query for Drop VT21 : " + OMMR_VT21_dropQuery);
			getJdbcTemplate().execute(OMMR_VT21_dropQuery);
			VT21Executed = false;
		}
		if (VT22Executed) {
			LOG.info("Query for Drop VT22 : " + OMMR_VT22_dropQuery);
			getJdbcTemplate().execute(OMMR_VT22_dropQuery);
			VT22Executed = false;
		}
		if (VT23Executed) {
			LOG.info("Query for Drop VT23 : " + OMMR_VT23_dropQuery);
			getJdbcTemplate().execute(OMMR_VT23_dropQuery);
			VT23Executed = false;
		}

		if (VT2Executed) {
			LOG.info("Query for Drop OMMR_VT13 : " + OMMR_VT13_dropQuery);
			getJdbcTemplate().execute(OMMR_VT13_dropQuery);
			VT2Executed = false;
		}
		
		if (VT31Executed) {
			LOG.info("Query for Drop VT31 : " + OMMR_VT31_dropQuery);
			getJdbcTemplate().execute(OMMR_VT31_dropQuery);
			VT31Executed = false;
		}
		if (VT32Executed) {
			LOG.info("Query for Drop VT32 : " + OMMR_VT32_dropQuery);
			getJdbcTemplate().execute(OMMR_VT32_dropQuery);
			VT32Executed = false;
		}
		if (VT33Executed) {
			LOG.info("Query for Drop VT33 : " + OMMR_VT33_dropQuery);
			getJdbcTemplate().execute(OMMR_VT33_dropQuery);
			VT33Executed = false;
		}

		
		if (VT3Executed) {
			LOG.info("Query for Drop OMMR_VT14 : " + OMMR_VT14_dropQuery);
			getJdbcTemplate().execute(OMMR_VT14_dropQuery);
			VT3Executed = false;
		}
		if (VT4Executed) {
			LOG.info("Query for Drop OMMR_VT15 : " + OMMR_VT15_dropQuery);
			getJdbcTemplate().execute(OMMR_VT15_dropQuery);
			VT4Executed = false;
		}
		LOG.info("Exiting dropVolatileTablesForOmmReport Method");
	}*/
	/**
	 * This method is used for getOmmCustomerDocReport
	 * 
	 * @param serialNo
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMOmmReportData> getOmmCustomerDocReport(String serialNo) throws PLMCommonException {
		LOG.info("Entering getOmmCustomerDocReport Method");
		List<PLMOmmReportData> ommCustomerDocResultList =  new ArrayList<PLMOmmReportData>();
		try{
			LOG.info("Query for Getting Customer Doc Results : " + PLMOfflineQueries.GET_OMM_CUSTOMER_DOCUMENTS);
			ommCustomerDocResultList =  getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_OMM_CUSTOMER_DOCUMENTS,new OmmCustomerDocResultMapper(), serialNo);
			LOG.info("Result of Customer Doc : " + ommCustomerDocResultList.size());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getOmmCustomerDocReport Method");
		return ommCustomerDocResultList;
	}
	/**
	 * This method is used for getOmmSbomDeviationReport
	 * 
	 * @param serialNo
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMOmmReportData> getOmmSbomDeviationReport(String serialNo) throws PLMCommonException {
		LOG.info("Entering getOmmSbomDeviationReport Method");
		List<PLMOmmReportData> ommSbomDeviationResultList =  new ArrayList<PLMOmmReportData>();
		try{
			LOG.info("Query for Getting SBOM Deviation Results : " + PLMOfflineQueries.GET_OMM_BOM_DEVIATION);
			ommSbomDeviationResultList =  getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_OMM_BOM_DEVIATION, new OmmSbomDeviationResultMapper(), serialNo);
			LOG.info("Result of SBOM Deviation : " + ommSbomDeviationResultList.size());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getOmmSbomDeviationReport Method");
		return ommSbomDeviationResultList;
	}
	/**
	 * Row mapper for getting contractNoMapper
	 */
	//private static ParameterizedRowMapper <String> contractNoMapper = new ParameterizedRowMapper<String>() {
	private static final class ContractNoMapper implements ParameterizedRowMapper <String>{ 	
	public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			String result;
			result = rs.getString(PLMUtils.checkNullVal(PLMConstants.OMM_COL_CONTRACT_NO));
			return result;
		}          
	//	};
	}
	/**
	 * Row mapper for getting ommVT0ResultMapper
	 */
	//private static ParameterizedRowMapper<PLMOmmReportData> ommVT0ResultMapper = new ParameterizedRowMapper<PLMOmmReportData>() {
	private static final class OmmVT0ResultMapper implements ParameterizedRowMapper<PLMOmmReportData>{ 	
	public PLMOmmReportData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMOmmReportData tempData = new PLMOmmReportData();
			tempData.setBomLevel(rs.getInt(PLMConstants.OMM_BOM_COL_BOM_LEVEL));
			tempData.setMli(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_MLI)));
			tempData.setPin(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PIN)));
			tempData.setSuffix(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_SUFFIX)));
			tempData.setPartNo(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_NO)));
			tempData.setPartType(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_TYPE)));
			tempData.setQty(rs.getInt(PLMConstants.OMM_BOM_COL_QUANTITY));
			tempData.setParentName(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PARENT_ITEM)));
			tempData.setParentId(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PARENT_ID)));
			tempData.setChildId(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_CHILD_ID)));
			tempData.setPathFlag("");
			return tempData;
		}
	//	};
	}
	/**
	 * Row mapper for getting ommVTGrpResultMapper
	 */
	//private static ParameterizedRowMapper<PLMOmmReportData> ommVTGrpResultMapper = new ParameterizedRowMapper<PLMOmmReportData>() {
	private static final class OmmVTGrpResultMapper implements ParameterizedRowMapper<PLMOmmReportData>{	
	public PLMOmmReportData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMOmmReportData tempData = new PLMOmmReportData();			
			tempData.setPartNo(PLMUtils.checkNullVal(rs.getString("TOP_PARENT")));
			tempData.setCostGroup(PLMUtils.checkNullVal(rs.getString("COST_GROUP")));
			LOG.info("TOP_PARENT = "+tempData.getPartNo()
					+"COST_GROUP = "+tempData.getCostGroup());
			return tempData;
		}
	//	};
	}
	/**
	 * Row mapper for getting ommBomExplosionResultMapper
	 */
	//private static ParameterizedRowMapper<PLMOmmReportData> ommBomExplosionResultMapper = new ParameterizedRowMapper<PLMOmmReportData>() {
	private static final class OmmBomExplosionResultMapper implements ParameterizedRowMapper<PLMOmmReportData>{ 	
	public PLMOmmReportData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMOmmReportData tempData = new PLMOmmReportData();
			tempData.setBomLevel(rs.getInt(PLMConstants.OMM_BOM_COL_BOM_LEVEL));
			tempData.setLogicalIndicator(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_LOGICAL_INDICATOR)));
			tempData.setMli(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_MLI)));
			tempData.setPin(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PIN)));
			tempData.setSuffix(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_SUFFIX)));
			//tempData.setType(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_TYPE)));
			tempData.setType("");
			tempData.setPartNo(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_NO)));
			tempData.setPartRev(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_REV)));
			tempData.setPartState(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_STATE)));
			tempData.setPartDesc(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_DESC)));
			tempData.setPartFamily(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_FAMILY)));
			tempData.setPartFamilyTitle(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PF_TITLE)));
			tempData.setQty(rs.getInt(PLMConstants.OMM_BOM_COL_QUANTITY));
			tempData.setPartUom(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_UOM)));
			tempData.setPartType(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PART_TYPE)));
			tempData.setDocType(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_DOC_TYPE)));
			//OMM_BOM_COL_PART_TYPE
			//OMM_BOM_COL_PART_TYPE
			tempData.setDocName(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_DOC_NAME)));
			tempData.setDocRev(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_DOC_REV)));
			tempData.setDocState(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_DOC_STATE)));
			tempData.setDocDesc(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_DOC_DESCRIPTION)));
			tempData.setSecurityClass(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_SECURITY_CLASS)));
			tempData.setExportClass(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_EXPORT_CLASS)));
			tempData.setParentName(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_PARENT_ITEM)));
			/*if(PLMUtils.isEmpty(tempData.getExportClass())){
				tempData.setGeDwgCriticalCode("");
			} else if(tempData.getExportClass().equals("Export Controlled")){
				tempData.setGeDwgCriticalCode("Critical");
			} else {
				tempData.setGeDwgCriticalCode("Non-Critical");
			}*/
			tempData.setGeDwgCriticalCode(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_GE_DWG_CRITICAL_CODE)));
			tempData.setCostGroup(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_BOM_COL_COST_GROUP)));
			tempData.setRecordId(rs.getInt(PLMConstants.OMM_BOM_COL_RECORD_ID));
			return tempData;
		}
	//	};
	}
	
	/**
	 * Row mapper for getting ommCustomerDocResultMapper
	 */
	//private static ParameterizedRowMapper<PLMOmmReportData> ommCustomerDocResultMapper = new ParameterizedRowMapper<PLMOmmReportData>() {
	private static final class OmmCustomerDocResultMapper implements ParameterizedRowMapper<PLMOmmReportData>{	
	public PLMOmmReportData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMOmmReportData tempData = new PLMOmmReportData();
			tempData.setDocName(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_CUSTOMER_DOCUMENTS_COL_DOC_NAME)));
			tempData.setDocRev(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_CUSTOMER_DOCUMENTS_COL_DOC_REVISION)));
			tempData.setDocState(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_CUSTOMER_DOCUMENTS_COL_DOC_STATE)));
			tempData.setDocDesc(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_CUSTOMER_DOCUMENTS_COL_DOC_DESCRIPTION)));
			return tempData;
		}
	//	};
	}
	/**
	 * Row mapper for getting ommSbomDeviationResultMapper
	 */
	//private static ParameterizedRowMapper<PLMOmmReportData> ommSbomDeviationResultMapper = new ParameterizedRowMapper<PLMOmmReportData>() {
	private static final class OmmSbomDeviationResultMapper implements ParameterizedRowMapper<PLMOmmReportData>{	
	public PLMOmmReportData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMOmmReportData tempData = new PLMOmmReportData();
			tempData.setTurbineNo(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_TURBINE_NO)));
			tempData.setPin(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_PIN)));
			tempData.setNewItem(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_NEW_ITEM)));
			tempData.setOldItem(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_OLD_ITEM)));
			tempData.setSection(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_SECTION)));
			tempData.setRevisonNo(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_REVISION_NO)));
			tempData.setAuthorization(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_AUTHORIZATION)));
			tempData.setDescription(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_DESCRIPTION)));
			tempData.setDateApplied(rs.getDate(PLMConstants.OMM_SBOM_COL_DATE_APPLIED));
			tempData.setQty(rs.getInt(PLMConstants.OMM_SBOM_COL_QUANTITY));
			tempData.setAnNum(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_AN_NO)));
			tempData.setAuthor(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_AUTHOR)));
			tempData.setAuthorFn(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_AUTHOR_FIRST_NAME)));
			tempData.setAuthorLn(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_AUTHOR_LAST_NAME)));
			tempData.setCatNo(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_CATEGORY_NO)));
			tempData.setLocation(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_LOCATION)));
			tempData.setParentPin(PLMUtils.checkNullVal(rs.getString(PLMConstants.OMM_SBOM_COL_PARENT_PIN)));
			return tempData;
		}
	//	};
	}
	
	/**
	 * @return the LOG
	 */
	public static Logger getLOG() {
		return LOG;
	}
}