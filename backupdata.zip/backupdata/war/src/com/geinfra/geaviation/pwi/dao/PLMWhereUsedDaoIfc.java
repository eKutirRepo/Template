/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhereUsedDaoIfc.java
 * @Creation date: 23-July-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMCMUSmlrToPrjData;
import com.geinfra.geaviation.pwi.data.PLMImpactAnalysisData;
import com.geinfra.geaviation.pwi.data.PLMWhereUsedData;
import com.geinfra.geaviation.pwi.data.PLMWhereUsedReqData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMWhereUsedDaoIfc {
	/**
	 * This method is used for getWhereUsedData
	 * 
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getWhereUsedData(String partNumber) throws PLMCommonException;
	/**
	 * This method is used for getWhereUsedLOUReport
	 * 
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getWhereUsedLOUReport(String partNumber) throws PLMCommonException;
	/**
	 * This method is used for getWhereUsedLogIndicatorData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getWhereUsedLogIndicatorData(StringBuffer searchResultsQry) throws PLMCommonException;
	/**
	 * This method is used for getWhereUsedEMBOMData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getWhereUsedEMBOMData(StringBuffer searchResultsQry) throws PLMCommonException;
	/**
	 * This method is used for getWhereUsedEMBOMPart
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getWhereUsedEMBOMPart(StringBuffer searchResultsQry) throws PLMCommonException;
	//public List<PLMWhereUsedData> getWhereUsedEMBOMDwg(StringBuffer searchResultsQry) throws PLMCommonException;
	/**
	 * This method is used for getWhereUsedEMBOMDwg
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getWhereUsedEMBOMDwg(StringBuffer searchResultsQry) throws PLMCommonException;
	/**
	 * This method is used for getMFTFDropDownValues
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getMFTFDropDownValues()throws PLMCommonException; 
	/**
	 * This method is used for getMFTFSearchData
	 * 
	 * @return List
	 * @param searchResultsQry
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getMFTFSearchData(StringBuffer searchResultsQry)throws PLMCommonException;
	/**
	 * This method is used for getBMLLWhereUsedEMBOMData
	 * 
	 * @return List
	 * @param searchResultsQry
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getBMLLWhereUsedEMBOMData(StringBuffer searchResultsQry) throws PLMCommonException;
	/**
	 * This method is used for getWhereUsedEMBOMPartDwg
	 * 
	 * @return List
	 * @param searchResultsQry
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getWhereUsedEMBOMPartDwg(StringBuffer searchResultsQry) throws PLMCommonException;
	//Newly added of Where Used Requirement
	/**
	 * This method is used for getWhereUsedReqData
	 * 	 
	 * @return List
	 * @param reportData
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedReqData> getWhereUsedReqData(PLMWhereUsedReqData reportData) throws PLMCommonException;
	/**
	 * This method is used for getFramTypeList
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getFramTypeList() throws PLMCommonException;
	/**
	 * This method is used for fetchWhrUsdTpLvlImplsnData
	 * 
	 * @return List
	 * @param partNm
	 * @throws PLMCommonException
	 */
	public Map<String,List<PLMWhereUsedData>> fetchWhrUsdTpLvlImplsnData(String partNm) throws PLMCommonException;
	/**
	 * This method is used to fetch get Impact Anaysis
	 * 
	 * @param partNm
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<PLMImpactAnalysisData>> getImpactAnalysisForParts(
			List<String> partIdLst) throws PLMCommonException;

	//Newly Added methods for multiple part numbers
	/**
	 * This method is used to getCopicsDataCount 
	 * 
	 * @param partNm
	 * @return int
	 * @throws PLMCommonException
	 */
	public int getCopicsDataCount(List<String> partNmList) throws PLMCommonException;
	/**
	 * This method is used to getSbomDevDataCount 
	 * 
	 * @param partNm
	 * @return int
	 * @throws PLMCommonException
	 */
	public int getSbomDevDataCount(List<String> partNmList) throws PLMCommonException;

	/**
	 * This method is used to getEbomDataCount 
	 * 
	 * @param partNm
	 * @return int
	 * @throws PLMCommonException
	 */
	public int getEbomDataCount(List<String> partNmList) throws PLMCommonException;
	/**
	 * This method is used to getCopicsData
	 * 
	 * @param partNm
	 * @return Map
	 * @throws PLMCommonException
	 */
	
	
	public int getRpdmDataCount(List<String> partNmList)throws PLMCommonException;
	
	public Map<String,Object> getCopicsData(List<String> partNmList) throws PLMCommonException;
	/**
	 * This method is used to get getSBOMDevData 
	 * 
	 * @param partNm
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String,Object> getSBOMDevData(List<String> partNmList) throws PLMCommonException;
	/**
	 * This method is used to getEBOMData 
	 * 
	 * @param partNm
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String,Object> getEBOMData(List<String> partNmList) throws PLMCommonException;
	/**
	 * This method is used to loadFrameFuelCombustorList
	 * @return
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> loadFrameFuelCombustorList() throws PLMCommonException;
	public Map<String,List<PLMCMUSmlrToPrjData>> generateCmuSimilarPrjReport(
			String selFrameTypeListName, String selFrameTypeTextBoxName,
			String selFuelTypeListName, String selFuelTypeTextBoxName,
			String selCombustorTypeListName,
			String selCombustorTypeTextBoxName,String mliTextBoxName, Date effectivityDateFrom,
			Date effectivityDateTo)  throws PLMCommonException;
	
	public Map<String, Object> getRpDmData(List<String> partNmList)throws PLMCommonException;
	
	
}
