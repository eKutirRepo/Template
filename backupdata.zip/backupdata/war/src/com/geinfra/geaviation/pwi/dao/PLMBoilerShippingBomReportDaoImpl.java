
/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBoilerShippingBomReportDaoImpl.java
 * @Creation date: 21-Feb-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMBoilerShipBomReportData;
import com.geinfra.geaviation.pwi.data.PLMBoilerShopBomReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMBoilerShippingBomReportDaoImpl extends SimpleJdbcDaoSupport implements PLMBoilerShippingBomReportDaoIfc{

	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMBoilerShippingBomReportDaoImpl.class);
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	
	
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * This method is used for getProjectNameAndContractNameList
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public Map<String, List<SelectItem>> getProjectNameAndContractNameList()
			throws PLMCommonException {

		LOG.info("Inside getProjectNameAndContractNameList method of PLMBoilerShippingBomReportDaoImpl class");
		Map<String, List<SelectItem>> dropdownlist = new HashMap<String, List<SelectItem>>();		
		List<SelectItem> projectNameList = null;
		List<SelectItem> contractNameList = null;
		List<SelectItem> taskListAll = null;
		try {			
			
			LOG.info("Query for getting distinct Contract Name List : " + PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_CONTRACT);
			contractNameList = getJdbcTemplate().query(PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_CONTRACT, new DstnctCntractMapper());		
			Collections.sort(contractNameList, new PLMUtils.SortListSelItem());
			LOG.info("size of  Contract Name List : " + contractNameList.size());
			
			LOG.info("Query for getting distinct Project Name List : " + PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_PROJECT_FROM_CNTRACT);
			projectNameList = getJdbcTemplate().query(PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_PROJECT_FROM_CNTRACT,new DstnctPrjMapper());	
			Collections.sort(projectNameList, new PLMUtils.SortListSelItem());
			LOG.info("size of  Project Name List : " + projectNameList.size());
			
			LOG.info("Query for getting distinct All Task Name List : " + PLMSearchQueries.GET_ALL_TASK_NAMES_FROM_PROJECT);
			taskListAll = getJdbcTemplate().query(PLMSearchQueries.GET_ALL_TASK_NAMES_FROM_PROJECT,new DstnctTaskMapper());	
			Collections.sort(taskListAll, new PLMUtils.SortListSelItem());
			LOG.info("size of  All Task List : " + taskListAll.size());
			
			dropdownlist.put("projectnamelist", projectNameList);
			dropdownlist.put("contractnamelist", contractNameList);
			dropdownlist.put("topLvlpartlistreset", taskListAll);

		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return dropdownlist;
	}
	/**
	 * Row mapper for getting DISTINCT PROJECTS
	 */
	private static final class DstnctPrjMapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(rs
					.getString("PROJECT").toUpperCase());

			return selectItem;

		}
	}
	private static final class DstnctTaskMapper implements ParameterizedRowMapper<SelectItem>{	
		public SelectItem mapRow(ResultSet rs, int rowCount)
					throws SQLException {

				SelectItem selectItem = new SelectItem(rs
						.getString("WBS_NO").toUpperCase());

				return selectItem;

			}
		}
	/**
	 * Row mapper for getting DISTINCT CONTRACTS
	 */
	private static final class DstnctCntractMapper implements ParameterizedRowMapper<SelectItem>{
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs
					.getString("NAME").toUpperCase());
			return selectItem;
		}
	}
	
	/**
	 * This method is used to fetch project for contracts
	 * 
	 * @param selShipBomCntractName
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMBoilerShipBomReportData> fetchProjectList(String selShipBomCntractName) throws PLMCommonException {
		StringBuffer searchQuery =new StringBuffer();
		searchQuery.append(PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_PROJECT_FROM_CNTRACT);
		if(!PLMUtils.isEmpty(selShipBomCntractName)){
		searchQuery.append(" WHERE T_CONTRACT.NAME ='");
		searchQuery.append(selShipBomCntractName);
		searchQuery.append("'");
		}
		LOG.info("Executing GET_PROJ_INFO_FROM_CNTRACT : " + searchQuery.toString() + "\n");
		return getJdbcTemplate().query(searchQuery.toString(), new ProjInfoMapper());
	}

	/**
	 * This method is used to fetch top lvl parts for projects
	 * 
	 * @param selShipBomProjectName
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMBoilerShipBomReportData> fetchTasktList(List<String> selShipBomProjectName,List<SelectItem> projectList,boolean allOpenPrjName) throws PLMCommonException {
		List<PLMBoilerShipBomReportData> topList = new ArrayList<PLMBoilerShipBomReportData>();
		StringBuffer searchQuery =new StringBuffer();
		if(!PLMUtils.isEmptyList(selShipBomProjectName) && allOpenPrjName != true){
			/*if(selShipBomProjectName.size()==projectList.size()){
				searchQuery.append(PLMSearchQueries.GET_ALL_TASK_NAMES_FROM_PROJECT);
			}else{*/
				searchQuery.append(PLMSearchQueries.GET_TASK_NAMES_FROM_PROJECT);
				searchQuery.append(" WHERE (");
				searchQuery.append(getStrBufferConsolidate(selShipBomProjectName, "T_PRJ.NAME"));
				searchQuery.append(")");
			/*}*/
		
		LOG.info("Executing GET_TASK_NAMES_FROM_PROJECT IF: " + searchQuery.toString() + "\n");
		topList= getJdbcTemplate().query(searchQuery.toString(), new PartInfoMapper());
		}else if(PLMUtils.isEmptyList(selShipBomProjectName) && allOpenPrjName == true)
		{
			if(selShipBomProjectName.size()==projectList.size()){
				searchQuery.append(PLMSearchQueries.GET_ALL_TASK_NAMES_FROM_PROJECT);
			}else{
				searchQuery.append(PLMSearchQueries.GET_TASK_NAMES_FROM_PROJECT);
				searchQuery.append(" WHERE (");
				searchQuery.append(getStrBufferConsolidate(selShipBomProjectName, "T_PRJ.NAME"));
				searchQuery.append(")");
			}
			LOG.info("Executing GET_TASK_NAMES_FROM_PROJECT ELSE IF: " + searchQuery.toString() + "\n");
			topList= getJdbcTemplate().query(searchQuery.toString(), new PartInfoMapper());
		}else if(!PLMUtils.isEmptyList(selShipBomProjectName) && allOpenPrjName == true)
		{
			if(selShipBomProjectName.size()==projectList.size()){
				searchQuery.append(PLMSearchQueries.GET_ALL_TASK_NAMES_FROM_PROJECT);
			}else{
				searchQuery.append(PLMSearchQueries.GET_TASK_NAMES_FROM_PROJECT);
				searchQuery.append(" WHERE (");
				searchQuery.append(getStrBufferConsolidate(selShipBomProjectName, "T_PRJ.NAME"));
				searchQuery.append(")");
			}
			LOG.info("Executing GET_TASK_NAMES_FROM_PROJECT 2nd ELSE IF: " + searchQuery.toString() + "\n");
			topList= getJdbcTemplate().query(searchQuery.toString(), new PartInfoMapper());
		}
		return topList;
	}
	
	/**
	 * @return PLMBoilerShipBomReportData objects.
	 */
	private static final class ProjInfoMapper implements ParameterizedRowMapper<PLMBoilerShipBomReportData> {
		public PLMBoilerShipBomReportData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMBoilerShipBomReportData data = new PLMBoilerShipBomReportData();
			data.setProjectName(PLMUtils.checkNullVal(rs.getString("PROJECT")).toUpperCase());
			return data;
		}
	}
	/**
	 * @return PLMBoilerShipBomReportData objects.
	 */
	private static final class PartInfoMapper implements ParameterizedRowMapper<PLMBoilerShipBomReportData> {
		public PLMBoilerShipBomReportData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMBoilerShipBomReportData data = new PLMBoilerShipBomReportData();
			data.setTopLvlPart(PLMUtils.checkNullVal(rs.getString("WBS_NO")).toUpperCase());
			data.setDescription(PLMUtils.checkNullVal(rs.getString("DESCRIPTION")).toUpperCase());
			data.setTaskNameDesc(PLMUtils.checkNullVal(rs.getString("TASKNM_DESC")));
			return data;
		}
	}
	
	/**
	 * This method is used to getStrBufferConsolidate 
	 * @param list
	 * @param String
	 * @return StringBuffer
	 * @throws PLMCommonException
	 */
	public StringBuffer getStrBufferConsolidate(List<String> colList,String colName) throws PLMCommonException{
		LOG.info("Entering getStrBufferConsolidate() method.");
		StringBuffer sqlQuery =new StringBuffer();
		try{
			if(!PLMUtils.isEmptyList(colList)){
				int vtCntInt =0;
				int vtCntIncr=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				int vtCntLimit=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				int val = 0;
				int loopCount = 0;
				int partListCnt=colList.size();
				boolean vtFlag=false;
				
				if(partListCnt <=vtCntLimit){
					loopCount = 1;
				}else{
					loopCount = partListCnt/vtCntLimit;				
					val = partListCnt - (vtCntLimit * loopCount);
					  if (val > 0) {
						loopCount++;					
					   }
				}
				
				for (int i=0;i<loopCount;i++) {
					if(vtCntIncr > partListCnt){
						vtCntIncr=partListCnt;
					 }
					List <String> partNumListLcl = new ArrayList<String>();
					LOG.info("-------------------Loop Rotating from part list index "+vtCntInt +" and "+vtCntIncr);
					 for(int j=vtCntInt;j<vtCntIncr;j++){
						 partNumListLcl.add(colList.get(j));
					 }
					if(!vtFlag){
						sqlQuery.append(""+colName+" IN ("+PLMUtils.setListForQuery(partNumListLcl)+")");
						vtFlag =true;
					}else{
						sqlQuery.append(" OR "+colName+" IN ("+PLMUtils.setListForQuery(partNumListLcl)+")");
					}
					vtCntInt =vtCntIncr+1;
					if(vtCntIncr > partListCnt){
						vtCntIncr=partListCnt;
					 }else{
					  vtCntIncr =vtCntIncr+Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
					 }
				}
			}
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getStrBufferConsolidate() method.");
		return sqlQuery;
	}
	
	/**
	 * This method is used to Generate Shipping BOM Report
	 * @param selShipBomCntractName
	 * @param allOpenContractName
	 * @param selShipBomProjectName
	 * @param allOpenPrjName
	 * @param selShipBomTopLvlPartName
	 * @param allOpenTopLvlPart
	 * @param showDocRev
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMBoilerShipBomReportData> generateShippingBomAppReport(
			String selShipBomCntractName, boolean allOpenContractName,
			List<String> selShipBomProjectName, boolean allOpenPrjName,
			List<String> selShipBomTopLvlPartName, boolean allOpenTopLvlPart,List<SelectItem>projectList,List<SelectItem>taskList, boolean showDocRev)
			throws PLMCommonException {

		LOG.info("Entering into  generateShippingBomAppReport");
		LOG.info("Entering into  selShipBomCntractName"+selShipBomCntractName);
		List <PLMBoilerShipBomReportData> fmiappReportList= new ArrayList <PLMBoilerShipBomReportData>();
		StringBuffer sqlQuery = new StringBuffer();
		boolean whereFlag=false;
		List<String> partAssmlyList = null;
		List<String> partAssmlyFromList = null;
		List<String> partAssmlyToList = null;
		
		List<String> partAssmlyToShippingBomData = null;
		
		String timeStamp = PLMUtils.volTableFormatDate();
		 try {
			 	String VT_SHIP_BOM_DATA = PLMConstants.VT_SHIP_BOM_DATA.concat(timeStamp);
		 		partAssmlyList = fetchPartAssemblyNameList(selShipBomCntractName, selShipBomProjectName, selShipBomTopLvlPartName);
		 		LOG.info("partAssmlyList Full List >>>  " + partAssmlyList);
		 		
		 		// GET TO LIST FROM EBOM 
			 	if(!PLMUtils.isEmptyList(partAssmlyList)){
			 		 sqlQuery.append(PLMSearchQueries.GET_EBOM_TO_LIST);
			 		 sqlQuery.append(" WHERE ("); 
					 sqlQuery.append(getStrBufferConsolidate(partAssmlyList, "TO_NAME"));
					 sqlQuery.append(")");
					 LOG.info("Query to get TO_NAME EBOM LIST >>>> "+ sqlQuery.toString());
					 partAssmlyToList =  getJdbcTemplate().query(sqlQuery.toString(), new EBOMNameMapper());	
					 LOG.info("TO_NAME EBOM LIST Record Count:: "+partAssmlyToList);
				}
				
				partAssmlyFromList = new ArrayList<String>();
				for (int i = 0; i < partAssmlyList.size(); i++) {
					if (!partAssmlyToList.contains(partAssmlyList.get(i))) {
						partAssmlyFromList.add(partAssmlyList.get(i));
					}
				}
				LOG.info("FROM_NAME EBOM LIST Record Count:: "+ partAssmlyFromList);
				
				// CREATE VOLATILE TO INSERT FROM AND TO LIST DATA 
				sqlQuery.delete(0, sqlQuery.length());
				sqlQuery.append(PLMSearchQueries.CREATE_BOILER_SHIPPINGBOM_REPORT);
				String sql = sqlQuery.toString().replace(PLMConstants.VT_SHIP_BOM_DATA, VT_SHIP_BOM_DATA);
				LOG.info("Executing for CREATE_BOILER_SHIPPINGBOM_REPORT Query : " + sql);
				getJdbcTemplate().execute(sql);
				
				// CREATE SEED QUERY DATA TO GET FROM LIST EBOM RECORDS 
				sqlQuery.delete(0, sqlQuery.length());
				sqlQuery.append(PLMSearchQueries.INSERT_BOILER_SHIPPINGBOM_REPORT1);
				sqlQuery.append(" WHERE ("); 
				if(!PLMUtils.isEmpty(selShipBomCntractName)){
					 if(!whereFlag){
						 sqlQuery.append(" CONTRACT IN ('"); 
						 sqlQuery.append(selShipBomCntractName);
						 sqlQuery.append("')");
					 	whereFlag=true;
					 }
				}
				
				if(!PLMUtils.isEmptyList(selShipBomProjectName)){
					 if(!whereFlag){
						 if(selShipBomProjectName.size()==projectList.size())
						 {
							 sqlQuery.append(" PROJECT IN(");
							 sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_PROJECT_FROM_CNTRACT_WITHOUT_ORDER_BY);
							 sqlQuery.append(")");
						 }else{
						 sqlQuery.append(getStrBufferConsolidate(selShipBomProjectName, "PROJECT"));
						 }
						 if(!PLMUtils.isEmptyList(selShipBomTopLvlPartName))
						 {
							 if(selShipBomTopLvlPartName.size()==taskList.size()){
								 sqlQuery.append(" AND WBS_NO IN(");
								 sqlQuery.append(PLMSearchQueries.GET_ALL_TASK_NAMES_FROM_PROJECT_WITHOUT_ORDER_BY);
								 sqlQuery.append(")");
							 }else{
								 sqlQuery.append(" AND ("); 
								 sqlQuery.append(getStrBufferConsolidate(selShipBomTopLvlPartName, "WBS_NO"));
								 sqlQuery.append(")");
							 }
						 
						 }
						 if (!PLMUtils.isEmptyList(partAssmlyFromList)) {
							 sqlQuery.append(" AND ("); 
						     sqlQuery.append(getStrBufferConsolidate(partAssmlyFromList, "R_DLV.TO_NAME"));
						     sqlQuery.append(")");
						 }
					 }
					 else{
						 if(selShipBomProjectName.size()==projectList.size())
						 {
							 sqlQuery.append(" AND PROJECT IN(");
							 sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_PROJECT_FROM_CNTRACT_WITHOUT_ORDER_BY);
							 sqlQuery.append(")");
						 }else{
							 sqlQuery.append(" AND ("); 
						     sqlQuery.append(getStrBufferConsolidate(selShipBomProjectName, "PROJECT"));
						     sqlQuery.append(")");
						 }
						 if(!PLMUtils.isEmptyList(selShipBomTopLvlPartName))
						 {
						 sqlQuery.append(" AND ("); 
						 if(selShipBomTopLvlPartName.size()==taskList.size()){
							 sqlQuery.append(" WBS_NO IN(");
							 sqlQuery.append(PLMSearchQueries.GET_ALL_TASK_NAMES_FROM_PROJECT_WITHOUT_ORDER_BY);
							 sqlQuery.append(")");
						 }else{
							 sqlQuery.append(getStrBufferConsolidate(selShipBomTopLvlPartName, "WBS_NO"));
						 }
						 sqlQuery.append(")");
						 }
						 
						 if (!PLMUtils.isEmptyList(partAssmlyFromList)) {
							 sqlQuery.append(" AND ("); 
						     sqlQuery.append(getStrBufferConsolidate(partAssmlyFromList, "R_DLV.TO_NAME"));
						     sqlQuery.append(")");
						 }
					 }
					
				 	whereFlag=true;
				}
				sqlQuery.append(")");
				//sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_BOILER_SHIPPINGBOM_REPORT1);
				sql = sqlQuery.toString().replace(PLMConstants.VT_SHIP_BOM_DATA, VT_SHIP_BOM_DATA);
				if (!PLMUtils.isEmptyList(partAssmlyFromList) && partAssmlyFromList.size() > 0) {
					LOG.info("Executing for Insert INSERT_SHIP_BOM_DATA1 Query : " + sql);
					getJdbcTemplate().execute(sql);
				}
				
				// INSERT SEED QUERY DATA TO GET TO LIST EBOM RECORDS 
				sqlQuery.delete(0, sqlQuery.length());
				whereFlag=false;
				sqlQuery.append(PLMSearchQueries.INSERT_BOILER_SHIPPINGBOM_REPORT2);
				sqlQuery.append(" WHERE ("); 
				if(!PLMUtils.isEmpty(selShipBomCntractName)){
					if(!whereFlag){
						sqlQuery.append(" CONTRACT IN ('"); 
						sqlQuery.append(selShipBomCntractName);
						sqlQuery.append("')");
						whereFlag=true;
					}
				}
				
				if(!PLMUtils.isEmptyList(selShipBomProjectName)){
					if(!whereFlag){
						if(selShipBomProjectName.size()==projectList.size())
						{
							sqlQuery.append(" PROJECT IN(");
							sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_PROJECT_FROM_CNTRACT_WITHOUT_ORDER_BY);
							sqlQuery.append(")");
						}else{
							sqlQuery.append(getStrBufferConsolidate(selShipBomProjectName, "PROJECT"));
						}
						if(!PLMUtils.isEmptyList(selShipBomTopLvlPartName))
						{
							if(selShipBomTopLvlPartName.size()==taskList.size()){
								sqlQuery.append(" AND WBS_NO IN(");
								sqlQuery.append(PLMSearchQueries.GET_ALL_TASK_NAMES_FROM_PROJECT_WITHOUT_ORDER_BY);
								sqlQuery.append(")");
							}else{
								sqlQuery.append(" AND ("); 
								sqlQuery.append(getStrBufferConsolidate(selShipBomTopLvlPartName, "WBS_NO"));
								sqlQuery.append(")");
							}
							
						}
						if (!PLMUtils.isEmptyList(partAssmlyToList)) {
							 sqlQuery.append(" AND ("); 
						     sqlQuery.append(getStrBufferConsolidate(partAssmlyToList, "R_DLV.TO_NAME"));
						     sqlQuery.append(")");
						 }
					}
					else{
						if(selShipBomProjectName.size()==projectList.size())
						{
							sqlQuery.append(" AND PROJECT IN(");
							sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_PROJECT_FROM_CNTRACT_WITHOUT_ORDER_BY);
							sqlQuery.append(")");
						}else{
							sqlQuery.append(" AND ("); 
							sqlQuery.append(getStrBufferConsolidate(selShipBomProjectName, "PROJECT"));
							sqlQuery.append(")");
						}
						if(!PLMUtils.isEmptyList(selShipBomTopLvlPartName))
						{
							sqlQuery.append(" AND ("); 
							if(selShipBomTopLvlPartName.size()==taskList.size()){
								sqlQuery.append(" WBS_NO IN(");
								sqlQuery.append(PLMSearchQueries.GET_ALL_TASK_NAMES_FROM_PROJECT_WITHOUT_ORDER_BY);
								sqlQuery.append(")");
							}else{
								sqlQuery.append(getStrBufferConsolidate(selShipBomTopLvlPartName, "WBS_NO"));
							}
							sqlQuery.append(")");
						}
						
						 if (!PLMUtils.isEmptyList(partAssmlyToList)) {
							 sqlQuery.append(" AND ("); 
						     sqlQuery.append(getStrBufferConsolidate(partAssmlyToList, "R_DLV.TO_NAME"));
						     sqlQuery.append(")");
						 }
					}
					
					whereFlag=true;
				}
				sqlQuery.append(")");
				sql = sqlQuery.toString().replace(PLMConstants.VT_SHIP_BOM_DATA, VT_SHIP_BOM_DATA);
				if (!PLMUtils.isEmptyList(partAssmlyToList) && partAssmlyToList.size() > 0) {
					LOG.info("Executing for Insert INSERT_SHIP_BOM_DATA2 Query : " + sql);
					getJdbcTemplate().execute(sql);
					///Added New Logic
					sqlQuery.delete(0, sqlQuery.length());
					sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_VT_SHIPPING_BOM_DATA);
					sql = sqlQuery.toString().replace(PLMConstants.VT_SHIP_BOM_DATA, VT_SHIP_BOM_DATA);
					LOG.info("Executing for retrieve shopbomdata Query : " + sql);
					partAssmlyToShippingBomData=getJdbcTemplate().query(sql, new VTSHIPPINGPBOMMapper());
					
				
				if(!partAssmlyToShippingBomData.isEmpty() ){
						
						partAssmlyFromList = new ArrayList<String>();
						for (int i = 0; i < partAssmlyToShippingBomData.size(); i++) {
							for(int j = 0; j < partAssmlyToList.size(); j++){
								if(!partAssmlyToShippingBomData.get(i).equalsIgnoreCase(partAssmlyToList.get(j))){
									partAssmlyFromList.add(partAssmlyToList.get(j));
									partAssmlyToShippingBomData.add(partAssmlyToList.get(j));
									LOG.info("part added log and  : " + partAssmlyToList.get(j));
									break;
								}
								
							}
							
						
								
						}
						
						
					}else{
						partAssmlyToShippingBomData =new ArrayList<String>();
						partAssmlyToShippingBomData.addAll(partAssmlyToList);
						partAssmlyFromList =new ArrayList<String>();
						partAssmlyFromList.addAll(partAssmlyToList);
					}
							
				LOG.info("Executing for retrieve shopbomdata Query : " + partAssmlyToList);
				LOG.info("Executing for retrieve shopbomdata Query : " + partAssmlyToShippingBomData);
					
					sqlQuery.delete(0, sqlQuery.length());
					sqlQuery.append(PLMSearchQueries.INSERT_BOILER_SHIPPINGBOM_REPORT1);
					sqlQuery.append(" WHERE ("); 
					if(!PLMUtils.isEmpty(selShipBomCntractName)){
						 if(!whereFlag){
							 sqlQuery.append(" CONTRACT IN ('"); 
							 sqlQuery.append(selShipBomCntractName);
							 sqlQuery.append("')");
							/* sqlQuery.append(" AND T_CONTRACT1.NAME IN ('"); 
							 sqlQuery.append(selShipBomCntractName);
							 sqlQuery.append("')");*/
						 }
					}
					if(!PLMUtils.isEmptyList(selShipBomProjectName)){
						 if(!whereFlag){
							 sqlQuery.append(" AND ("); 
						     sqlQuery.append(getStrBufferConsolidate(selShipBomProjectName, "PROJECT"));
						     sqlQuery.append(")");
						   /*  sqlQuery.append(" AND ("); 
						     sqlQuery.append(getStrBufferConsolidate(selShipBomProjectName, "T_PRJ1.NAME"));
						     sqlQuery.append(")");*/
						 }
					}
					if(!PLMUtils.isEmptyList(selShipBomTopLvlPartName)){
						 if(!whereFlag){
							 sqlQuery.append(" AND WBS_NO IN ('"); 
							 sqlQuery.append(selShipBomTopLvlPartName);
							 sqlQuery.append("')");
						 }
					}
					if(!PLMUtils.isEmptyList(partAssmlyFromList)){
						 if(!whereFlag){
							 sqlQuery.append(" AND ("); 
						     sqlQuery.append(getStrBufferConsolidate(partAssmlyFromList, "PARENT_ASSY_NO"));
						     sqlQuery.append(")");
						 }
					}
					sqlQuery.append(")");
					sql = sqlQuery.toString().replace(PLMConstants.VT_SHIP_BOM_DATA, VT_SHIP_BOM_DATA);
					if (!PLMUtils.isEmptyList(partAssmlyFromList) && partAssmlyFromList.size() > 0) {
						LOG.info("Executing for INSERT_SHOP_BOM_DATA1 Query for missing part: " + sql);
						getJdbcTemplate().execute(sql);
					}
				
				}
				
				sqlQuery.delete(0, sqlQuery.length());
				sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_BOILER_SHIPPINGBOM_REPORT2);
				
				if(!PLMUtils.isEmpty(selShipBomCntractName)){
					 sqlQuery.append(" RCP.FROM_NAME IN ('"); 
					 sqlQuery.append(selShipBomCntractName);
					 sqlQuery.append("')");
				}
				if(!PLMUtils.isEmptyList(selShipBomProjectName)){
					 sqlQuery.append(" AND ("); 
				     sqlQuery.append(getStrBufferConsolidate(selShipBomProjectName, "RCP.TO_NAME"));
				     sqlQuery.append(")");
				}
				
				
				sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_BOILER_SHIPPINGBOM_REPORT3);
				
				if (showDocRev) {
					sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_SHIP_BOM_RPT4);
				} 
				sqlQuery.append(" ORDER BY D.DFSORDER");
				StringBuffer sb = new StringBuffer();
				sb.append("CASE WHEN T_ACAD_DWG.NAME IS NOT NULL THEN T_ACAD_DWG.MAX_REV ")
						.append("WHEN T_INV_ASBLY.NAME IS NOT NULL THEN T_INV_ASBLY.MAX_REV ")
						.append("WHEN T_INV_CMPNT.NAME IS NOT NULL THEN T_INV_CMPNT.MAX_REV ")
						.append("WHEN T_INV_DWG.NAME IS NOT NULL THEN T_INV_DWG.MAX_REV ")
						.append("ELSE R_PART_SPECN.TO_REVISION END ");
				sql = sqlQuery.toString();
				if (showDocRev) {
					sql = sql.replace(PLMConstants.VT_SHIP_BOM_DATA, VT_SHIP_BOM_DATA).replace("#", sb.toString());
				} else {
					sql = sql.replace(PLMConstants.VT_SHIP_BOM_DATA, VT_SHIP_BOM_DATA).replace("#", "R_PART_SPECN.TO_REVISION");
				}
				
				LOG.info("Final Query for Shipping BOM report:: "+ sql);
				fmiappReportList =  getJdbcTemplate().query(sql, new ShippingBomMapper());	
				LOG.info("Shipping BOM Record Count:: "+fmiappReportList.size());
				
			} catch (DataAccessException e) {
				PLMUtils.checkException(e.getMessage());
			}catch (Exception e) {
				PLMUtils.checkException(e.getMessage());
			}
			return fmiappReportList;
	
	}
	
	/**
	 * @return PLMBoilerShipBomReportData objects.
	 */
	private static final class ShippingBomMapper implements ParameterizedRowMapper<PLMBoilerShipBomReportData> {
		public PLMBoilerShipBomReportData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMBoilerShipBomReportData tempData =new PLMBoilerShipBomReportData();
			/*tempData.setStationLocation(PLMUtils.checkNullVal(rs.getString("STATION_LOCATION")));
			tempData.setStation(PLMUtils.checkNullVal(rs.getString("STATION")));
			tempData.setCustomer(PLMUtils.checkNullVal(rs.getString("CUSTOMER")));
			tempData.setCntName(PLMUtils.checkNullVal(rs.getString("CONTRACT")));
			tempData.setUnitNo(PLMUtils.checkNullVal(rs.getString("UNIT_NO")));
			tempData.setProjectName(PLMUtils.checkNullVal(rs.getString("PROJECT")));*/
			tempData.setWbsNo(PLMUtils.checkNullVal(rs.getString("WBS_NO")));
			tempData.setProductDesc(PLMUtils.checkNullVal(rs.getString("PRODUCT_DESCRIPTION")));
			tempData.setDrawingNumber(PLMUtils.checkNullVal(rs.getString("DRAWING_NO")));
			tempData.setDrawingRev(PLMUtils.checkNullVal(rs.getString("DRAWING_REV")));
			tempData.setItemNumber(PLMUtils.checkNullVal(rs.getString("ITEM_NO")));
			tempData.setPartNumber(PLMUtils.checkNullVal(rs.getString("PART_NO")));
			tempData.setPartRev(PLMUtils.checkNullVal(rs.getString("PART_REVISION")));
			tempData.setQuantity(PLMUtils.checkNullVal(rs.getString("QTY")));
			tempData.setUnitOfMeasure(PLMUtils.checkNullVal(rs.getString("UNIT_OF_MEASURE")));
			tempData.setDescription(PLMUtils.checkNullVal(rs.getString("DESCRIPTION")));
			tempData.setRemarks(PLMUtils.checkNullVal(rs.getString("REMARKS")));
			tempData.setWeight(PLMUtils.checkNullVal(rs.getString("WEIGHT")));
			
			return tempData;
		}
	}
	/**
	 * @return String objects.
	 */
	private static final class EBOMNameMapper implements ParameterizedRowMapper<String> {
		public String mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			String str = PLMUtils.checkNullVal(rs.getString("PART_NAME"));
			return str;
		}
	}
	
	
	
	
	private static final class VTSHIPPINGPBOMMapper implements ParameterizedRowMapper<String> {
		public String mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			String str = PLMUtils.checkNullVal(rs.getString("PARENT_ASSY_NO"));
			return str;
		}
	}
	
	
	/**
	 * @return String objects.
	 */
	private static final class VTSHOPBOMMapper implements ParameterizedRowMapper<String> {
		public String mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			String str = PLMUtils.checkNullVal(rs.getString("PARENT_ASSY_NO"));
			return str;
		}
	}
	
	
	//Added for Customer BOM Report
	/**
	 * This method is used to generate report
	 * @param selContractNm
	 * @param selProjectList
	 * @param allOpenPrjName
	 * @param selTaskName
	 * @param allAssyNum
	 * @param selPartAssmblyNumList
	 * @param showPartRev
	 * @param showDocRev
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<PLMBoilerShipBomReportData> getCustomerBOMRptData(
			String selContractNm,List<String> selProjectList, 
			boolean allOpenPrjName,String selTaskName, boolean allAssyNum, List<String> selPartAssmblyNumList,
			boolean showPartRev, boolean showDocRev) throws PLMCommonException{
		LOG.info("Entering into  getCustomerBOMRptData");
		List <PLMBoilerShipBomReportData> customerBomRptList= new ArrayList <PLMBoilerShipBomReportData>();
		boolean whereFlag=false;
		String timeStamp = PLMUtils.volTableFormatDate();
		List<String> partAssmlyFromList = null;
		List<String> partAssmlyToList = null;
		StringBuffer sqlQuery = new StringBuffer();
		
		List<String> partAssmlyToCustomBomData = null;
		
		 try {
			    String VT_CUST_BOM_DATA = PLMConstants.VT_CUST_BOM_DATA.concat(timeStamp);
			    String VT_PART_DATA = PLMConstants.VT_PART_DATA.concat(timeStamp);
			    String VT_BOM_DATA = PLMConstants.VT_BOM_DATA.concat(timeStamp);
		 		
		 		// GET TO LIST FROM EBOM 
			 	if(!PLMUtils.isEmptyList(selPartAssmblyNumList)){
			 		sqlQuery.append(PLMSearchQueries.GET_EBOM_TO_LIST);
			 		 sqlQuery.append(" WHERE ("); 
					 sqlQuery.append(getStrBufferConsolidate(selPartAssmblyNumList, "TO_NAME"));
					 sqlQuery.append(")");
					 LOG.info("Query to get TO_NAME EBOM LIST >>>> "+ sqlQuery.toString());
					 partAssmlyToList =  getJdbcTemplate().query(sqlQuery.toString(), new EBOMNameMapper());	
					 LOG.info("TO_NAME EBOM LIST Record Count:: "+partAssmlyToList);
				}
				
				partAssmlyFromList = new ArrayList<String>();
				for (int i = 0; i < selPartAssmblyNumList.size(); i++) {
					if (!partAssmlyToList.contains(selPartAssmblyNumList.get(i))) {
						partAssmlyFromList.add(selPartAssmblyNumList.get(i));
					}
				}
				LOG.info("FROM_NAME EBOM LIST Record Count:: "+ partAssmlyFromList);
				
				// CREATE VOLATILE TO INSERT FROM AND TO LIST DATA 
				sqlQuery.delete(0, sqlQuery.length());
				sqlQuery.append(PLMSearchQueries.CREATE_BOILER_CUSTBOM_REPORT);
				String sql = sqlQuery.toString().replace(PLMConstants.VT_CUST_BOM_DATA, VT_CUST_BOM_DATA);
				LOG.info("Executing for CREATE_CUST_BOM_DATA Query : " + sql);
				getJdbcTemplate().execute(sql);
				
				// CREATE VOLATILE TO INSERT PART MASTER TABLE DATA WITH MAX REVISION 
				sqlQuery.delete(0, sqlQuery.length());
				sqlQuery.append(PLMSearchQueries.CREATE_BOILER_PART_DATA);
				sql = sqlQuery.toString().replace(PLMConstants.VT_PART_DATA, VT_PART_DATA);
				LOG.info("Executing for CREATE_BOILER_PART_DATA Query : " + sql);
				getJdbcTemplate().execute(sql);
				
				// INSERT SEED QUERY DATA TO GET FROM LIST EBOM RECORDS 
				sqlQuery.delete(0, sqlQuery.length());
				sqlQuery.append(PLMSearchQueries.INSERT_BOILER_CUSTBOM_REPORT1);
				if(!PLMUtils.isEmpty(selContractNm)){
					 if(!whereFlag){
						 sqlQuery.append(" WHERE "); 
						 sqlQuery.append(" T_CONTRACT.NAME IN ('"); 
						 sqlQuery.append(selContractNm);
						 sqlQuery.append("')");
					 	 whereFlag=true;
					 }
				}
				
				if(!PLMUtils.isEmptyList(selProjectList) && !allOpenPrjName){
					 if(!whereFlag){
						 sqlQuery.append(" WHERE ("); 
						 sqlQuery.append(getStrBufferConsolidate(selProjectList, "T_PRJ.NAME"));
						 sqlQuery.append(" ) ");
						 whereFlag=true;
					 }else{
						 sqlQuery.append(" AND ( "); 
						 sqlQuery.append(getStrBufferConsolidate(selProjectList, "T_PRJ.NAME"));
						 sqlQuery.append(" ) ");
					 }
				}
				
				if(!PLMUtils.isEmpty(selTaskName)){
					 if(!whereFlag){
						 sqlQuery.append(" WHERE "); 
						 sqlQuery.append(" T_TASK.NAME IN ('"); 
						 sqlQuery.append(selTaskName);
						 sqlQuery.append("')");
						 whereFlag=true;
					 }else{
						 sqlQuery.append(" AND "); 
						 sqlQuery.append(" T_TASK.NAME IN ('"); 
						 sqlQuery.append(selTaskName);
						 sqlQuery.append("')");
					 }
				}
				
				if(!PLMUtils.isEmptyList(partAssmlyFromList) && !allAssyNum){
					 if(!whereFlag){
						 sqlQuery.append(" WHERE ("); 
						 sqlQuery.append(getStrBufferConsolidate(partAssmlyFromList, "R_DLV.TO_NAME")); 
						 sqlQuery.append(" )");
						 whereFlag=true;
					 }else{
						 sqlQuery.append(" AND ( "); 
						 sqlQuery.append(getStrBufferConsolidate(partAssmlyFromList, "R_DLV.TO_NAME")); 
						 sqlQuery.append(" ) ");
					 }
				}
				sql = sqlQuery.toString().replace(PLMConstants.VT_CUST_BOM_DATA, VT_CUST_BOM_DATA);
				if (!PLMUtils.isEmptyList(partAssmlyFromList) && partAssmlyFromList.size() > 0) {
					LOG.info("Executing for INSERT_CUST_BOM_DATA1 Query : " + sql);
					getJdbcTemplate().execute(sql);
				}
				
				// INSERT SEED QUERY DATA TO GET TO LIST EBOM RECORDS  
				whereFlag=false;
				sqlQuery.delete(0, sqlQuery.length());
				sqlQuery.append(PLMSearchQueries.INSERT_BOILER_CUSTBOM_REPORT2);
				sqlQuery.append(" WHERE ("); 
				if(!PLMUtils.isEmpty(selContractNm)){
					 if(!whereFlag){
						 sqlQuery.append(" CONTRACT IN ('"); 
						 sqlQuery.append(selContractNm);
						 sqlQuery.append("')");
						 sqlQuery.append(" AND T_CONTRACT1.NAME IN ('"); 
						 sqlQuery.append(selContractNm);
						 sqlQuery.append("')");
					 	 whereFlag=true;
					 }
				}
				
				if(!PLMUtils.isEmptyList(selProjectList) && !allOpenPrjName){
					 if(!whereFlag){
						 sqlQuery.append(" WHERE ("); 
						 sqlQuery.append(getStrBufferConsolidate(selProjectList, "T_PRJ1.NAME"));
						 sqlQuery.append(" ) ");
						 whereFlag=true;
					 }else{
						 sqlQuery.append(" AND ("); 
					     sqlQuery.append(getStrBufferConsolidate(selProjectList, "PROJECT"));
					     sqlQuery.append(")");
						 sqlQuery.append(" AND ( "); 
						 sqlQuery.append(getStrBufferConsolidate(selProjectList, "T_PRJ1.NAME"));
						 sqlQuery.append(" ) ");
					 }
				}
				
				if(!PLMUtils.isEmpty(selTaskName)){
					 if(!whereFlag){
						 sqlQuery.append(" WHERE "); 
						 sqlQuery.append(" WBS_NO IN ('"); 
						 sqlQuery.append(selTaskName);
						 sqlQuery.append("')");
						 whereFlag=true;
					 }else{
						 sqlQuery.append(" AND "); 
						 sqlQuery.append(" WBS_NO IN ('"); 
						 sqlQuery.append(selTaskName);
						 sqlQuery.append("')");
					 }
				}
				
				if(!PLMUtils.isEmptyList(partAssmlyToList) && !allAssyNum){
					 if(!whereFlag){
						 sqlQuery.append(" WHERE ("); 
						 sqlQuery.append(getStrBufferConsolidate(partAssmlyToList, "PARENT_ASSY_NO")); 
						 sqlQuery.append(" )");
						 whereFlag=true;
					 }else{
						 sqlQuery.append(" AND ( "); 
						 sqlQuery.append(getStrBufferConsolidate(partAssmlyToList, "PARENT_ASSY_NO")); 
						 sqlQuery.append(" ) ");
					 }
				}
				sqlQuery.append(")");
				sql = sqlQuery.toString().replace(PLMConstants.VT_CUST_BOM_DATA, VT_CUST_BOM_DATA);
				if (!PLMUtils.isEmptyList(partAssmlyToList) && partAssmlyToList.size() > 0) {
					LOG.info("Executing for INSERT_CUST_BOM_DATA2 Query : " + sql);
					getJdbcTemplate().execute(sql);
					
					sqlQuery.delete(0, sqlQuery.length());
					sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_VT_CUSTOM_BOM_DATA);
					sql = sqlQuery.toString().replace(PLMConstants.VT_CUST_BOM_DATA, VT_CUST_BOM_DATA);
					LOG.info("Executing for retrieve shopbomdata Query : " + sql);
					partAssmlyToCustomBomData=getJdbcTemplate().query(sql, new VTSHOPBOMMapper());
					
				
				if(!partAssmlyToCustomBomData.isEmpty() ){
						
						partAssmlyFromList = new ArrayList<String>();
						for (int i = 0; i < partAssmlyToCustomBomData.size(); i++) {
							for(int j = 0; j < partAssmlyToList.size(); j++){
								if(!partAssmlyToCustomBomData.get(i).equalsIgnoreCase(partAssmlyToList.get(j))){
									partAssmlyFromList.add(partAssmlyToList.get(j));
									partAssmlyToCustomBomData.add(partAssmlyToList.get(j));
									LOG.info("part added log and  : " + partAssmlyToList.get(j));
									break;
								}
								
							}
							
								
						}
						
						
					}else{
						partAssmlyToCustomBomData =new ArrayList<String>();
						partAssmlyToCustomBomData.addAll(partAssmlyToList);
						partAssmlyFromList =new ArrayList<String>();
						partAssmlyFromList.addAll(partAssmlyToList);
					}
							
				LOG.info("Executing for retrieve SUTOM Query : " + partAssmlyToList);
				LOG.info("Executing for retrieve shopbomdata Query : " + partAssmlyToCustomBomData);
				whereFlag=false;
					sqlQuery.delete(0, sqlQuery.length());
					sqlQuery.append(PLMSearchQueries.INSERT_BOILER_CUSTBOM_REPORT1);
					sqlQuery.append(" WHERE ("); 
					if(!PLMUtils.isEmpty(selContractNm)){
						 if(!whereFlag){
							 sqlQuery.append(" CONTRACT IN ('"); 
							 sqlQuery.append(selContractNm);
							 sqlQuery.append("')");
							/* sqlQuery.append(" AND T_CONTRACT1.NAME IN ('"); 
							 sqlQuery.append(selShipBomCntractName);
							 sqlQuery.append("')");*/
						 }
					}
					if(!PLMUtils.isEmptyList(selProjectList)){
						 if(!whereFlag){
							 sqlQuery.append(" AND ("); 
						     sqlQuery.append(getStrBufferConsolidate(selProjectList, "PROJECT"));
						     sqlQuery.append(")");
						   /*  sqlQuery.append(" AND ("); 
						     sqlQuery.append(getStrBufferConsolidate(selShipBomProjectName, "T_PRJ1.NAME"));
						     sqlQuery.append(")");*/
						 }
					}
					if(!PLMUtils.isEmpty(selTaskName)){
						 if(!whereFlag){
							 sqlQuery.append(" AND WBS_NO IN ('"); 
							 sqlQuery.append(selTaskName);
							 sqlQuery.append("')");
						 }
					}
					if(!PLMUtils.isEmptyList(partAssmlyFromList)){
						 if(!whereFlag){
							 sqlQuery.append(" AND ("); 
						     sqlQuery.append(getStrBufferConsolidate(partAssmlyFromList, "PARENT_ASSY_NO"));
						     sqlQuery.append(")");
						 }
					}
					sqlQuery.append(")");
					sql = sqlQuery.toString().replace(PLMConstants.VT_CUST_BOM_DATA, VT_CUST_BOM_DATA);
					if (!PLMUtils.isEmptyList(partAssmlyFromList) && partAssmlyFromList.size() > 0) {
						LOG.info("Executing for INSERT_CUSTOM_BOM_DATA1 Query for missing part: " + sql);
						getJdbcTemplate().execute(sql);
					}
					
					
				}
				
				
				sqlQuery.delete(0, sqlQuery.length());
				sqlQuery.append(PLMSearchQueries.CREATE_VT_BOM_DATA_1);
				
				if (showPartRev) {
					sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_CUST_BOM_RPT_MAX_PART1);
				} else {
					sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_CUST_BOM_RPT_PART1);
				}
				
				sqlQuery.append(PLMSearchQueries.CREATE_VT_BOM_DATA_11);
				if (showPartRev && showDocRev) {
					sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_CUST_BOM_RPT_MAX_PART)
					.append(PLMSearchQueries.QRY_FOR_GETTING_CUST_BOM_RPT3).append(PLMSearchQueries.QRY_FOR_GETTING_CUST_BOM_RPT_MAX_DOC);
				} else if (!showPartRev && !showDocRev) {
					sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_CUST_BOM_RPT_PART)
					.append(PLMSearchQueries.QRY_FOR_GETTING_CUST_BOM_RPT3).append(PLMSearchQueries.QRY_FOR_GETTING_CUST_BOM_RPT_DOC);
				} else if (showPartRev && !showDocRev) {
					sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_CUST_BOM_RPT_MAX_PART)
					.append(PLMSearchQueries.QRY_FOR_GETTING_CUST_BOM_RPT3).append(PLMSearchQueries.QRY_FOR_GETTING_CUST_BOM_RPT_DOC);
				} else if (!showPartRev && showDocRev) {
					sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_CUST_BOM_RPT_PART)
					.append(PLMSearchQueries.QRY_FOR_GETTING_CUST_BOM_RPT3).append(PLMSearchQueries.QRY_FOR_GETTING_CUST_BOM_RPT_MAX_DOC);
				}
				sql = sqlQuery.toString();
				StringBuffer sb = new StringBuffer();
				sb.append("CASE WHEN T_ACAD_DWG.NAME IS NOT NULL THEN T_ACAD_DWG.MAX_REV ")
						.append("WHEN T_INV_ASBLY.NAME IS NOT NULL THEN T_INV_ASBLY.MAX_REV ")
						.append("WHEN T_INV_CMPNT.NAME IS NOT NULL THEN T_INV_CMPNT.MAX_REV ")
						.append("WHEN T_INV_DWG.NAME IS NOT NULL THEN T_INV_DWG.MAX_REV ")
						.append("ELSE R_PART_SPECN.TO_REVISION END ");
				
				if (showPartRev && showDocRev) {
					sql = sql.replace(PLMConstants.VT_CUST_BOM_DATA, VT_CUST_BOM_DATA).replace(PLMConstants.VT_BOM_DATA, VT_BOM_DATA)
							.replace(PLMConstants.VT_PART_DATA, VT_PART_DATA).replace("?", "T_PART.MAX_REV").replace("#", sb.toString());
				} else if (!showPartRev && !showDocRev) {
					sql = sql.replace(PLMConstants.VT_CUST_BOM_DATA, VT_CUST_BOM_DATA).replace(PLMConstants.VT_BOM_DATA, VT_BOM_DATA)
							.replace(PLMConstants.VT_PART_DATA, VT_PART_DATA)
							.replace("?", "T_PART.REVISION").replace("#", "R_PART_SPECN.TO_REVISION");
				} else if (showPartRev && !showDocRev) {
					sql = sql.replace(PLMConstants.VT_CUST_BOM_DATA, VT_CUST_BOM_DATA).replace(PLMConstants.VT_BOM_DATA, VT_BOM_DATA)
							.replace(PLMConstants.VT_PART_DATA, VT_PART_DATA)
							.replace("?", "T_PART.MAX_REV").replace("#", "R_PART_SPECN.TO_REVISION");
				} else if (!showPartRev && showDocRev) {
					sql = sql.replace(PLMConstants.VT_CUST_BOM_DATA, VT_CUST_BOM_DATA).replace(PLMConstants.VT_BOM_DATA, VT_BOM_DATA)
							.replace(PLMConstants.VT_PART_DATA, VT_PART_DATA).replace("?", "T_PART.REVISION").replace("#", sb.toString());
				}
				
				sqlQuery.delete(0, sqlQuery.length());
				sqlQuery.append(sql).append(PLMSearchQueries.CREATE_VT_BOM_DATA_2);
				
				//sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_SHOP_BOM_RPT71);
				if(!PLMUtils.isEmpty(selContractNm)){
					 sqlQuery.append(" RCP.FROM_NAME IN ('"); 
					 sqlQuery.append(selContractNm);
					 sqlQuery.append("')");
				}
				if(!PLMUtils.isEmptyList(selProjectList)){
					 sqlQuery.append(" AND ("); 
				     sqlQuery.append(getStrBufferConsolidate(selProjectList, "RCP.TO_NAME"));
				     sqlQuery.append(")");
				}
				sqlQuery.append(PLMSearchQueries.CREATE_VT_BOM_DATA_3);
				LOG.info("Executing Query for createVT_BOM_DATA Volatile: "+ sqlQuery.toString());
				getJdbcTemplate().execute(sqlQuery.toString());
				
				LOG.info("Executing final Query for Customer BOM Data: "+PLMSearchQueries.GET_VT_BOM_DATA.replace(PLMConstants.VT_BOM_DATA, VT_BOM_DATA));
				customerBomRptList =  getJdbcTemplate().query(PLMSearchQueries.GET_VT_BOM_DATA.replace(PLMConstants.VT_BOM_DATA, VT_BOM_DATA)
						, new CustomerBomMapper());
				LOG.info("Customer BOM Record Count:: "+customerBomRptList.size());
					
			} catch (DataAccessException e) {
				PLMUtils.checkException(e.getMessage());
			}catch (Exception e) {
				PLMUtils.checkException(e.getMessage());
			}
			return customerBomRptList;
	}
	
	/**
	 * @return PLMBoilerShipBomReportData objects.
	 */
	private static final class CustomerBomMapper implements ParameterizedRowMapper<PLMBoilerShipBomReportData> {
		public PLMBoilerShipBomReportData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMBoilerShipBomReportData tempData =new PLMBoilerShipBomReportData();
			/*tempData.setStationLocation(PLMUtils.checkNullVal(rs.getString("STATION_LOCATION")));
			tempData.setStation(PLMUtils.checkNullVal(rs.getString("STATION")));
			tempData.setCustomer(PLMUtils.checkNullVal(rs.getString("CUSTOMER")));
			tempData.setCntName(PLMUtils.checkNullVal(rs.getString("CONTRACT")));
			tempData.setUnitNo(PLMUtils.checkNullVal(rs.getString("UNIT_NO")));
			tempData.setProjectName(PLMUtils.checkNullVal(rs.getString("PROJECT")));
			tempData.setWbsNo(PLMUtils.checkNullVal(rs.getString("WBS_NO")));
			tempData.setProductDesc(PLMUtils.checkNullVal(rs.getString("PRODUCT_DESCRIPTION")));*/
			tempData.setDrawingNumber(PLMUtils.checkNullVal(rs.getString("PART_DRAWING_NO")));
			tempData.setDrawingRev(PLMUtils.checkNullVal(rs.getString("PART_DRAWING_REV")));
			tempData.setItemNumber(PLMUtils.checkNullVal(rs.getString("ITEM_NO")));
			tempData.setPartNumber(PLMUtils.checkNullVal(rs.getString("PART_NO")));
			tempData.setPartRev(PLMUtils.checkNullVal(rs.getString("PART_REVISION")));
			tempData.setQuantity(PLMUtils.checkNullVal(rs.getString("QTY")));
			tempData.setUnitOfMeasure(PLMUtils.checkNullVal(rs.getString("UNIT_OF_MEASURE")));
			tempData.setDescription(PLMUtils.checkNullVal(rs.getString("DESCRIPTION")));
			tempData.setRemarks(PLMUtils.checkNullVal(rs.getString("REMARKS")));
			tempData.setWeight(PLMUtils.checkNullVal(rs.getString("WEIGHT")));
			tempData.setLevel(rs.getInt("LVL"));
			return tempData;
		}
	}
	
	//Added for Shop BOM
	/**
	 * This method is used to Get Shop BOM Report
	 * @param selShipBomCntractName
	 * @param allOpenContractName
	 * @param selShipBomProjectName
	 * @param allOpenPrjName
	 * @param selShipBomTopLvlPartName
	 * @param allOpenTopLvlPart
	 * @param showPartRev
	 * @param showDocRev
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMBoilerShopBomReportData> getShopBomHeaderSectionDataList(
			String selShipBomCntractName, boolean allOpenContractName,
			List<String> selShipBomProjectName, boolean allOpenPrjName,
			String selShipBomTopLvlPartName, boolean allOpenTopLvlPart,List<String> selShipBomParentAssyNo, boolean allOpenParentAssy,
			boolean showPartRev, boolean showDocRev)
			throws PLMCommonException {
		LOG.info("Entering into  getShopBomHeaderSectionDataList");
		LOG.info("Entering into  selShipBomCntractName"+selShipBomCntractName);
		List <PLMBoilerShopBomReportData> fmiappReportList= new ArrayList <PLMBoilerShopBomReportData>();
		StringBuffer sqlQuery = new StringBuffer();
		boolean whereFlag=false;
		String timeStamp = PLMUtils.volTableFormatDate();
		List<String> partAssmlyFromList = null;
		List<String> partAssmlyToList = null;
		
		List<String> partAssmlyToShopBomData = null;
		 try {
			    String VT_SHOP_BOM_DATA = PLMConstants.VT_SHOP_BOM_DATA.concat(timeStamp);
		 		
		 		// GET TO LIST FROM EBOM 
			 	if(!PLMUtils.isEmptyList(selShipBomParentAssyNo)){
			 		sqlQuery.append(PLMSearchQueries.GET_EBOM_TO_LIST);
			 		 sqlQuery.append(" WHERE ("); 
					 sqlQuery.append(getStrBufferConsolidate(selShipBomParentAssyNo, "TO_NAME"));
					 sqlQuery.append(")");
					 LOG.info("Query to get TO_NAME EBOM LIST >>>> "+ sqlQuery.toString());
					 partAssmlyToList =  getJdbcTemplate().query(sqlQuery.toString(), new EBOMNameMapper());	
					 LOG.info("TO_NAME EBOM LIST Record Count:: "+partAssmlyToList);
				}
				
				partAssmlyFromList = new ArrayList<String>();
				for (int i = 0; i < selShipBomParentAssyNo.size(); i++) {
					if (!partAssmlyToList.contains(selShipBomParentAssyNo.get(i))) {
						partAssmlyFromList.add(selShipBomParentAssyNo.get(i));
					}
				}
				LOG.info("FROM_NAME EBOM LIST Record Count:: "+ partAssmlyFromList);
				
				// CREATE VOLATILE TO INSERT FROM AND TO LIST DATA 
				sqlQuery.delete(0, sqlQuery.length());
				sqlQuery.append(PLMSearchQueries.CREATE_BOILER_SHOPBOM_REPORT);
				String sql = sqlQuery.toString().replace(PLMConstants.VT_SHOP_BOM_DATA, VT_SHOP_BOM_DATA);
				LOG.info("Executing for CREATE_SHOP_BOM_DATA Query : " + sql);
				getJdbcTemplate().execute(sql);
				
				
				// INSERT SEED QUERY DATA TO GET FROM LIST EBOM RECORDS 
				sqlQuery.delete(0, sqlQuery.length());
				sqlQuery.append(PLMSearchQueries.INSERT_BOILER_SHOPBOM_REPORT1);
				sqlQuery.append(" WHERE ("); 
				if(!PLMUtils.isEmpty(selShipBomCntractName)){
					 if(!whereFlag){
						 sqlQuery.append(" CONTRACT IN ('"); 
						 sqlQuery.append(selShipBomCntractName);
						 sqlQuery.append("')");
					 }
				}
				if(!PLMUtils.isEmptyList(selShipBomProjectName)){
					 if(!whereFlag){
						 sqlQuery.append(" AND ("); 
					     sqlQuery.append(getStrBufferConsolidate(selShipBomProjectName, "PROJECT"));
					     sqlQuery.append(")");
					 }
				}
				if(!PLMUtils.isEmpty(selShipBomTopLvlPartName)){
					 if(!whereFlag){
						 sqlQuery.append(" AND WBS_NO IN ('"); 
						 sqlQuery.append(selShipBomTopLvlPartName);
						 sqlQuery.append("')");
					 }
				}
				if(!PLMUtils.isEmptyList(partAssmlyFromList)){
					 if(!whereFlag){
						 sqlQuery.append(" AND ("); 
					     sqlQuery.append(getStrBufferConsolidate(partAssmlyFromList, "PARENT_ASSY_NO"));
					     sqlQuery.append(")");
					 }
				}
				sqlQuery.append(")");
				sql = sqlQuery.toString().replace(PLMConstants.VT_SHOP_BOM_DATA, VT_SHOP_BOM_DATA);
				if (!PLMUtils.isEmptyList(partAssmlyFromList) && partAssmlyFromList.size() > 0) {
					LOG.info("Executing for INSERT_SHOP_BOM_DATA1 Query : " + sql);
					getJdbcTemplate().execute(sql);
				}
				
				
				// INSERT SEED QUERY DATA TO GET TO LIST EBOM RECORDS  
				whereFlag=false;
				sqlQuery.delete(0, sqlQuery.length());
				sqlQuery.append(PLMSearchQueries.INSERT_BOILER_SHOPBOM_REPORT2);
				sqlQuery.append(" WHERE ("); 
				if(!PLMUtils.isEmpty(selShipBomCntractName)){
					 if(!whereFlag){
						 sqlQuery.append(" CONTRACT IN ('"); 
						 sqlQuery.append(selShipBomCntractName);
						 sqlQuery.append("')");
						 sqlQuery.append(" AND T_CONTRACT1.NAME IN ('"); 
						 sqlQuery.append(selShipBomCntractName);
						 sqlQuery.append("')");
					 }
				}
				if(!PLMUtils.isEmptyList(selShipBomProjectName)){
					 if(!whereFlag){
						 sqlQuery.append(" AND ("); 
					     sqlQuery.append(getStrBufferConsolidate(selShipBomProjectName, "PROJECT"));
					     sqlQuery.append(")");
					     sqlQuery.append(" AND ("); 
					     sqlQuery.append(getStrBufferConsolidate(selShipBomProjectName, "T_PRJ1.NAME"));
					     sqlQuery.append(")");
					 }
				}
				if(!PLMUtils.isEmpty(selShipBomTopLvlPartName)){
					 if(!whereFlag){
						 sqlQuery.append(" AND WBS_NO IN ('"); 
						 sqlQuery.append(selShipBomTopLvlPartName);
						 sqlQuery.append("')");
					 }
				}
				if(!PLMUtils.isEmptyList(partAssmlyToList)){
					 if(!whereFlag){
						 sqlQuery.append(" AND ("); 
					     sqlQuery.append(getStrBufferConsolidate(partAssmlyToList, "PARENT_ASSY_NO"));
					     sqlQuery.append(")");
					 }
				}
				sqlQuery.append(")");
				sql = sqlQuery.toString().replace(PLMConstants.VT_SHOP_BOM_DATA, VT_SHOP_BOM_DATA);
				if (!PLMUtils.isEmptyList(partAssmlyToList) && partAssmlyToList.size() > 0) {
					LOG.info("Executing for INSERT_SHOP_BOM_DATA2 Query : " + sql);
					getJdbcTemplate().execute(sql);
					
			
					///Added New Logic
					sqlQuery.delete(0, sqlQuery.length());
					sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_VT_SHOP_BOM_DATA);
					sql = sqlQuery.toString().replace(PLMConstants.VT_SHOP_BOM_DATA, VT_SHOP_BOM_DATA);
					LOG.info("Executing for retrieve shopbomdata Query : " + sql);
					partAssmlyToShopBomData=getJdbcTemplate().query(sql, new VTSHOPBOMMapper());
					
				
				if(!partAssmlyToShopBomData.isEmpty() ){
						
						partAssmlyFromList = new ArrayList<String>();
						for (int i = 0; i < partAssmlyToShopBomData.size(); i++) {
							for(int j = 0; j < partAssmlyToList.size(); j++){
								if(!partAssmlyToShopBomData.get(i).equalsIgnoreCase(partAssmlyToList.get(j))){
									partAssmlyFromList.add(partAssmlyToList.get(j));
									partAssmlyToShopBomData.add(partAssmlyToList.get(j));
									LOG.info("part added log and  : " + partAssmlyToList.get(j));
									break;
								}
								
							}
							
						
								
						}
						
						
					}else{
						partAssmlyToShopBomData =new ArrayList<String>();
						partAssmlyToShopBomData.addAll(partAssmlyToList);
						partAssmlyFromList =new ArrayList<String>();
						partAssmlyFromList.addAll(partAssmlyToList);
					}
							
				LOG.info("Executing for retrieve shopbomdata Query : " + partAssmlyToList);
				LOG.info("Executing for retrieve shopbomdata Query : " + partAssmlyToShopBomData);
					
					sqlQuery.delete(0, sqlQuery.length());
					sqlQuery.append(PLMSearchQueries.INSERT_BOILER_SHOPBOM_REPORT1);
					sqlQuery.append(" WHERE ("); 
					if(!PLMUtils.isEmpty(selShipBomCntractName)){
						 if(!whereFlag){
							 sqlQuery.append(" CONTRACT IN ('"); 
							 sqlQuery.append(selShipBomCntractName);
							 sqlQuery.append("')");
							/* sqlQuery.append(" AND T_CONTRACT1.NAME IN ('"); 
							 sqlQuery.append(selShipBomCntractName);
							 sqlQuery.append("')");*/
						 }
					}
					if(!PLMUtils.isEmptyList(selShipBomProjectName)){
						 if(!whereFlag){
							 sqlQuery.append(" AND ("); 
						     sqlQuery.append(getStrBufferConsolidate(selShipBomProjectName, "PROJECT"));
						     sqlQuery.append(")");
						   /*  sqlQuery.append(" AND ("); 
						     sqlQuery.append(getStrBufferConsolidate(selShipBomProjectName, "T_PRJ1.NAME"));
						     sqlQuery.append(")");*/
						 }
					}
					if(!PLMUtils.isEmpty(selShipBomTopLvlPartName)){
						 if(!whereFlag){
							 sqlQuery.append(" AND WBS_NO IN ('"); 
							 sqlQuery.append(selShipBomTopLvlPartName);
							 sqlQuery.append("')");
						 }
					}
					if(!PLMUtils.isEmptyList(partAssmlyFromList)){
						 if(!whereFlag){
							 sqlQuery.append(" AND ("); 
						     sqlQuery.append(getStrBufferConsolidate(partAssmlyFromList, "PARENT_ASSY_NO"));
						     sqlQuery.append(")");
						 }
					}
					sqlQuery.append(")");
					sql = sqlQuery.toString().replace(PLMConstants.VT_SHOP_BOM_DATA, VT_SHOP_BOM_DATA);
					if (!PLMUtils.isEmptyList(partAssmlyFromList) && partAssmlyFromList.size() > 0) {
						LOG.info("Executing for INSERT_SHOP_BOM_DATA1 Query for missing part: " + sql);
						getJdbcTemplate().execute(sql);
					}
				}
				
				sqlQuery.delete(0, sqlQuery.length());
				sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_SHOP_BOM_RPT2);
				if (showPartRev && showDocRev) {
					sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_SHOP_BOM_RPT_MAX_PART)
					.append(PLMSearchQueries.QRY_FOR_GETTING_SHOP_BOM_RPT8).append(PLMSearchQueries.QRY_FOR_GETTING_SHOP_BOM_RPT_MAX_DOC);
				} else if (!showPartRev && !showDocRev) {
					sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_SHOP_BOM_RPT_PART)
					.append(PLMSearchQueries.QRY_FOR_GETTING_SHOP_BOM_RPT8).append(PLMSearchQueries.QRY_FOR_GETTING_SHOP_BOM_RPT_DOC);
				} else if (showPartRev && !showDocRev) {
					sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_SHOP_BOM_RPT_MAX_PART)
					.append(PLMSearchQueries.QRY_FOR_GETTING_SHOP_BOM_RPT8).append(PLMSearchQueries.QRY_FOR_GETTING_SHOP_BOM_RPT_DOC);
				} else if (!showPartRev && showDocRev) {
					sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_SHOP_BOM_RPT_PART)
					.append(PLMSearchQueries.QRY_FOR_GETTING_SHOP_BOM_RPT8).append(PLMSearchQueries.QRY_FOR_GETTING_SHOP_BOM_RPT_MAX_DOC);
				}
				
				sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_SHOP_BOM_RPT71);
				if(!PLMUtils.isEmpty(selShipBomCntractName)){
					 sqlQuery.append(" RCP.FROM_NAME IN ('"); 
					 sqlQuery.append(selShipBomCntractName);
					 sqlQuery.append("')");
				}
				if(!PLMUtils.isEmptyList(selShipBomProjectName)){
					 sqlQuery.append(" AND ("); 
				     sqlQuery.append(getStrBufferConsolidate(selShipBomProjectName, "RCP.TO_NAME"));
				     sqlQuery.append(")");
				}
				sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_SHOP_BOM_RPT72);
				
				sql = sqlQuery.toString();
				StringBuffer sb = new StringBuffer();
				sb.append("CASE WHEN T_ACAD_DWG.NAME IS NOT NULL THEN T_ACAD_DWG.MAX_REV ")
						.append("WHEN T_INV_ASBLY.NAME IS NOT NULL THEN T_INV_ASBLY.MAX_REV ")
						.append("WHEN T_INV_CMPNT.NAME IS NOT NULL THEN T_INV_CMPNT.MAX_REV ")
						.append("WHEN T_INV_DWG.NAME IS NOT NULL THEN T_INV_DWG.MAX_REV ")
						.append("ELSE R_PART_SPECN.TO_REVISION END ");
				
				if (showPartRev && showDocRev) {
					sql = sql.replace(PLMConstants.VT_SHOP_BOM_DATA, VT_SHOP_BOM_DATA).replace("?", "T_PART.MAX_REV").replace("#", sb.toString());
				} else if (!showPartRev && !showDocRev) {
					sql = sql.replace(PLMConstants.VT_SHOP_BOM_DATA, VT_SHOP_BOM_DATA).replace("?", "T_PART.REVISION").replace("#", "R_PART_SPECN.TO_REVISION");
				} else if (showPartRev && !showDocRev) {
					sql = sql.replace(PLMConstants.VT_SHOP_BOM_DATA, VT_SHOP_BOM_DATA).replace("?", "T_PART.MAX_REV").replace("#", "R_PART_SPECN.TO_REVISION");
				} else if (!showPartRev && showDocRev) {
					sql = sql.replace(PLMConstants.VT_SHOP_BOM_DATA, VT_SHOP_BOM_DATA).replace("?", "T_PART.REVISION").replace("#", sb.toString());
				}
				
				LOG.info("Shop BOM Final Query:: "+sql);
				fmiappReportList =  getJdbcTemplate().query(sql, new ShopBomMapper());	
				LOG.info("Shop BOM Record Count Header:: "+fmiappReportList.size());
					
			} catch (DataAccessException e) {
				PLMUtils.checkException(e.getMessage());
			}catch (Exception e) {
				PLMUtils.checkException(e.getMessage());
			}
			return fmiappReportList;
	
	}
	/**
	 * @return PLMBoilerShopBomReportData objects.
	 */
	private static final class ShopBomMapper implements ParameterizedRowMapper<PLMBoilerShopBomReportData> {
		public PLMBoilerShopBomReportData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMBoilerShopBomReportData tempData =new PLMBoilerShopBomReportData();
			/*tempData.setStationLocation(PLMUtils.checkNullVal(rs.getString("STATION_LOCATION")));
			tempData.setStation(PLMUtils.checkNullVal(rs.getString("STATION")));
			tempData.setCustomer(PLMUtils.checkNullVal(rs.getString("CUSTOMER")));*/
			tempData.setCntName(PLMUtils.checkNullVal(rs.getString("CONTRACT")));
			tempData.setUnitNo(PLMUtils.checkNullVal(rs.getString("UNIT_NO")));
			tempData.setProjectName(PLMUtils.checkNullVal(rs.getString("PROJECT")));
			tempData.setWbsNo(PLMUtils.checkNullVal(rs.getString("WBS_NO")));
			tempData.setWbsName(PLMUtils.checkNullVal(rs.getString("WBS_NAME")));
			tempData.setParentAssyNo(PLMUtils.checkNullVal(rs.getString("PARENT_ASSY_NO")));
			//tempData.setDrawingNumber(PLMUtils.checkNullVal(rs.getString("DRAWING_NO")));
			tempData.setItemNumber(rs.getString("ITEM_NO"));
			tempData.setLevel(rs.getInt("LVL"));
			tempData.setPartNumber(PLMUtils.checkNullVal(rs.getString("PART_NO")));
			tempData.setDrawingRev(PLMUtils.checkNullVal(rs.getString("PART_REVISION")));
			tempData.setQuantity(PLMUtils.checkNullVal(rs.getString("QTY")));
			tempData.setUnitOfMeasure(PLMUtils.checkNullVal(rs.getString("UNIT_OF_MEASURE")));
			tempData.setMatlCode(PLMUtils.checkNullVal(rs.getString("MATL_CODE")));
			tempData.setMatlCodeId(PLMUtils.checkNullVal(rs.getString("MATL_CODE_ID")));
			tempData.setProductDesc(PLMUtils.checkNullVal(rs.getString("DESCRIPTION")));
			tempData.setPartDrawingNumber(PLMUtils.checkNullVal(rs.getString("PART_DRAWING_NO")));
			tempData.setPartDrawingRev(PLMUtils.checkNullVal(rs.getString("PART_DRAWING_REV")));
			tempData.setWeight(PLMUtils.checkNullVal(rs.getString("WEIGHT")));
			tempData.setRemarks(PLMUtils.checkNullVal(rs.getString("REMARKS")));
			
			return tempData;
		}
	}

	/**
	 * This method is used to Get Shop BOM Report Material List Data
	 * @param matlCodeList
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMBoilerShopBomReportData> getShopBomMaterialSectionDataList(
			List<String> matlCodeList) throws PLMCommonException {
		LOG.info("Entering into  getShopBomMaterialSectionDataList");
		LOG.info("Entering into  materialCodeList size"+matlCodeList.size());
		List <PLMBoilerShopBomReportData> fmiappReportList= new ArrayList <PLMBoilerShopBomReportData>();
		StringBuffer sqlQuery = new StringBuffer();
		 try {
				sqlQuery.append(PLMSearchQueries.QRY_FOR_GETTING_MATL_LIST_FOR_SHOP_BOM);
				if(!PLMUtils.isEmptyList(matlCodeList)){
						 sqlQuery.append(" AND ("); 
						 sqlQuery.append(getStrBufferConsolidate(matlCodeList, "MAT.ID"));
						 sqlQuery.append(")");
				}
				
				LOG.info("Final Query for Shop BOM Material Code List report:: "+sqlQuery);
				fmiappReportList =  getJdbcTemplate().query(sqlQuery.toString(), new ShopBoMatlCodemMapper());	
				LOG.info("Shop BOM Material Code Record Count :: "+fmiappReportList.size());
					
			} catch (DataAccessException e) {
				PLMUtils.checkException(e.getMessage());
			}catch (Exception e) {
				PLMUtils.checkException(e.getMessage());
			}
			return fmiappReportList;
	}
	
	/**
	 * @return PLMBoilerShopBomReportData objects.
	 */
	private static final class ShopBoMatlCodemMapper implements ParameterizedRowMapper<PLMBoilerShopBomReportData> {
		public PLMBoilerShopBomReportData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMBoilerShopBomReportData tempData =new PLMBoilerShopBomReportData();
			tempData.setItem(PLMUtils.checkNullVal(rs.getString("ITEM")));
			tempData.setUnsNo(PLMUtils.checkNullVal(rs.getString("UNS_NO")));
			tempData.setComposition(PLMUtils.checkNullVal(rs.getString("COMPOSITION")));
			tempData.setSpec(PLMUtils.checkNullVal(rs.getString("SPEC")));
			tempData.setGrade(PLMUtils.checkNullVal(rs.getString("GRADE")));
			tempData.setPurchInst(PLMUtils.checkNullVal(rs.getString("PURCH_INST")));
			tempData.setMatlNotesSub(PLMUtils.checkNullVal(rs.getString("MATLNOTES_SUB")));
			tempData.setUsageRemarks(PLMUtils.checkNullVal(rs.getString("USAGE_REMARKS")));
			return tempData;
		}
	}
	
	/**
	 * This method is used to fetch Part Assembly Numbers
	 * @param taskName
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerShipBomReportData> fetchPartAssemblyNumList(String selContractNm,List<String> selProjectList, 
			boolean allOpenPrjName, String selTaskName) throws PLMCommonException{
		List<PLMBoilerShipBomReportData> partAssmblyList = new ArrayList<PLMBoilerShipBomReportData>();
		try {
		
		StringBuffer sqlQuery = new StringBuffer();
		sqlQuery.append(PLMSearchQueries.GET_PART_ASSMBLY_NAMES);
		
		sqlQuery.append(" WHERE ("); 
		if(!PLMUtils.isEmpty(selContractNm)){
				 sqlQuery.append(" T_CONTRACT.NAME IN ('"); 
				 sqlQuery.append(selContractNm);
				 sqlQuery.append("')");
		}
		if(!PLMUtils.isEmptyList(selProjectList) && !allOpenPrjName){
			sqlQuery.append(" AND ( "); 
			sqlQuery.append(getStrBufferConsolidate(selProjectList, "T_PRJ.NAME"));
			sqlQuery.append(" ) ");
		}
		if(!PLMUtils.isEmpty(selTaskName)){
				 sqlQuery.append(" AND R_DLV.FROM_NAME IN ('"); 
				 sqlQuery.append(selTaskName);
				 sqlQuery.append("')");
		}
		sqlQuery.append(") ORDER BY PARENT_ASSY_NO");
		
		LOG.info("Executing part Assembly Data Query: " + sqlQuery.toString() + "\n");
		partAssmblyList= getSimpleJdbcTemplate().query(sqlQuery.toString(), new PartAssmblyMapper());
		LOG.info("part Assembly Data List>> "+ partAssmblyList.size());
		}catch (DataAccessException e) {
				PLMUtils.checkException(e.getMessage());
		 }catch (Exception e) {
				PLMUtils.checkException(e.getMessage());
		 } 
		return partAssmblyList;
	}
	
	/**
	 * This method is used to fetch Part Assembly Numbers
	 * @param taskName
	 * @return
	 * @throws PLMCommonException
	 */
	public List<String> fetchPartAssemblyNameList(String selContractNm,List<String> selProjectList, List<String> selTaskNameList) throws PLMCommonException{
		List<String> partAssmblyList = new ArrayList<String>();
		try {
			
			StringBuffer sqlQuery = new StringBuffer();
			sqlQuery.append(PLMSearchQueries.GET_PART_ASSMBLY_NAMES);
			
			sqlQuery.append(" WHERE ("); 
			if(!PLMUtils.isEmpty(selContractNm)){
				sqlQuery.append(" T_CONTRACT.NAME IN ('"); 
				sqlQuery.append(selContractNm);
				sqlQuery.append("')");
			}
			if(!PLMUtils.isEmptyList(selProjectList)){
				sqlQuery.append(" AND ( "); 
				sqlQuery.append(getStrBufferConsolidate(selProjectList, "T_PRJ.NAME"));
				sqlQuery.append(" ) ");
			}
			if(!PLMUtils.isEmptyList(selTaskNameList)){
				sqlQuery.append(" AND ( "); 
				sqlQuery.append(getStrBufferConsolidate(selTaskNameList, "R_DLV.FROM_NAME"));
				sqlQuery.append(" ) ");
			}
			sqlQuery.append(") ORDER BY PARENT_ASSY_NO");
			
			LOG.info("Executing part Assembly Data Query: " + sqlQuery.toString() + "\n");
			partAssmblyList= getSimpleJdbcTemplate().query(sqlQuery.toString(), new PartAssmblyNmMapper());
			LOG.info("part Assembly Data List>> "+ partAssmblyList.size());
		}catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}catch (Exception e) {
			PLMUtils.checkException(e.getMessage());
		} 
		return partAssmblyList;
	}
	
	/**
	 * @return PLMBoilerShopBomReportData objects.
	 */
	private static final class PartAssmblyNmMapper implements ParameterizedRowMapper<String> {
		public String mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			String str = PLMUtils.checkNullVal(rs.getString("PARENT_ASSY_NO"));
			return str;
		}
	}

	/**
	 * @return PLMBoilerShopBomReportData objects.
	 */
	private static final class PartAssmblyMapper implements ParameterizedRowMapper<PLMBoilerShipBomReportData> {
		public PLMBoilerShipBomReportData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMBoilerShipBomReportData tempData =new PLMBoilerShipBomReportData();
			tempData.setPartAssmblyNo(PLMUtils.checkNullVal(rs.getString("PARENT_ASSY_NO")));
			tempData.setPartAssmblyDesc(PLMUtils.checkNullVal(rs.getString("PARENT_ASSY_DESC")));
			tempData.setPartAssmblyNoDesc(PLMUtils.checkNullVal(rs.getString("PARTNM_DESC")));
			return tempData;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SelectItem> contractFamilyAutocomplete(String contract)
			throws PLMCommonException {
		List<SelectItem> contractNameList = new ArrayList<SelectItem>();
		try{
		
		StringBuffer sb = new StringBuffer();
		sb.append(PLMSearchQueries.QRY_FOR_GETTING_DSTNCT_CONTRACT);
		if(!PLMUtils.isEmpty(contract)){
			sb.append(" where name like'");
			sb.append(contract);
			sb.append("%'");
		}
		LOG.info("Query for getting distinct Contract Name List : " + sb.toString());
		contractNameList = getJdbcTemplate().query(sb.toString(),new DstnctCntractMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return contractNameList;
	}
	
	/**
	 * @param selContractNm
	 * @param selProjectList
	 * @param allOpenPrjName
	 * @param selTaskName
	 * @param allAssyNum
	 * @param selPartAssmblyNumList
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerShipBomReportData> getHeaderData(
			String selContractNm,List<String> selProjectList, 
			boolean allOpenPrjName,String selTaskName, boolean allAssyNum, List<String> selPartAssmblyNumList) throws PLMCommonException{
		
		boolean whereFlag=false;
		StringBuffer qry = new StringBuffer();
		LOG.info("Entering into  getHeaderData");
		List <PLMBoilerShipBomReportData> headerList= new ArrayList <PLMBoilerShipBomReportData>();
		
		qry.append(PLMSearchQueries.GET_HEADER_DATA);
		
		try {
		if(!PLMUtils.isEmpty(selContractNm)){
			 if(!whereFlag){
				 qry.append(" WHERE "); 
				 qry.append(" T_CONTRACT.NAME IN ('"); 
				 qry.append(selContractNm);
				 qry.append("')");
			 	 whereFlag=true;
			 }
		}
		
		if(!PLMUtils.isEmptyList(selProjectList) && !allOpenPrjName){
			 if(!whereFlag){
				 qry.append(" WHERE ("); 
				 qry.append(getStrBufferConsolidate(selProjectList, "T_PRJ.NAME"));
				 qry.append(" ) ");
				 whereFlag=true;
			 }else{
				 qry.append(" AND ( "); 
				 qry.append(getStrBufferConsolidate(selProjectList, "T_PRJ.NAME"));
				 qry.append(" ) ");
			 }
		}
		
		if(!PLMUtils.isEmpty(selTaskName)){
			 if(!whereFlag){
				 qry.append(" WHERE "); 
				 qry.append(" T_TASK.NAME IN ('"); 
				 qry.append(selTaskName);
				 qry.append("')");
				 whereFlag=true;
			 }else{
				 qry.append(" AND "); 
				 qry.append(" T_TASK.NAME IN ('"); 
				 qry.append(selTaskName);
				 qry.append("')");
			 }
		}
		
		/*if(!PLMUtils.isEmptyList(selPartAssmblyNumList) && !allAssyNum){
			 if(!whereFlag){
				 qry.append(" WHERE ("); 
				 qry.append(getStrBufferConsolidate(selPartAssmblyNumList, "R_DLV.TO_NAME")); 
				 qry.append(" )");
				 whereFlag=true;
			 }else{
				 qry.append(" AND ( "); 
				 qry.append(getStrBufferConsolidate(selPartAssmblyNumList, "R_DLV.TO_NAME")); 
				 qry.append(" ) ");
			 }
		}*/
		
		LOG.info("Executing final Query for Header Data: "+ qry);
		headerList =  getJdbcTemplate().query(qry.toString(), new GetHeaderMapper());
		LOG.info("headerList Record Count:: " + headerList.size());
			
	} catch (DataAccessException e) {
		PLMUtils.checkException(e.getMessage());
	} catch (Exception e) {
		PLMUtils.checkException(e.getMessage());
	}
	return headerList;
	
		
	}
	
	/**
	 * @return PLMBoilerShipBomReportData objects.
	 */
	private static final class GetHeaderMapper implements ParameterizedRowMapper<PLMBoilerShipBomReportData> {
		public PLMBoilerShipBomReportData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMBoilerShipBomReportData tempData =new PLMBoilerShipBomReportData();
			tempData.setStationLocation(PLMUtils.checkNullVal(rs.getString("STATION_LOCATION")));
			tempData.setStation(PLMUtils.checkNullVal(rs.getString("STATION")));
			tempData.setCustomer(PLMUtils.checkNullVal(rs.getString("CUSTOMER")));
			tempData.setCntName(PLMUtils.checkNullVal(rs.getString("CONTRACT")));
			tempData.setUnitNo(PLMUtils.checkNullVal(rs.getString("UNIT_NO")));
			tempData.setProjectName(PLMUtils.checkNullVal(rs.getString("PROJECT")));
			tempData.setWbsNo(PLMUtils.checkNullVal(rs.getString("WBS_NO")));
			tempData.setProductDesc(PLMUtils.checkNullVal(rs.getString("WBS_NAME")));
			return tempData;
		}
	}
	
	/**
	 * @param selContractNm
	 * @param selProjectList
	 * @param allOpenPrjName
	 * @param selTaskName
	 * @param allOpenTopLvlPart
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMBoilerShipBomReportData> getShippingHeaderData(
			String selContractNm, List<String> selProjectList, 
			boolean allOpenPrjName,List<String> selTaskName, boolean allOpenTopLvlPart) throws PLMCommonException{
		
		boolean whereFlag=false;
		StringBuffer qry = new StringBuffer();
		LOG.info("Entering into  getShippingHeaderData");
		List <PLMBoilerShipBomReportData> headerList= new ArrayList <PLMBoilerShipBomReportData>();
		
		qry.append(PLMSearchQueries.GET_HEADER_DATA);
		
		try {
		if(!PLMUtils.isEmpty(selContractNm) ){
			 if(!whereFlag){
				 qry.append(" WHERE "); 
				 qry.append(" T_CONTRACT.NAME IN ('"); 
				 qry.append(selContractNm);
				 qry.append("')");
			 	 whereFlag=true;
			 }
		}
		
		if(!PLMUtils.isEmptyList(selProjectList) && !allOpenPrjName){
			 if(!whereFlag){
				 qry.append(" WHERE ("); 
				 qry.append(getStrBufferConsolidate(selProjectList, "T_PRJ.NAME"));
				 qry.append(" ) ");
				 whereFlag=true;
			 }else{
				 qry.append(" AND ( "); 
				 qry.append(getStrBufferConsolidate(selProjectList, "T_PRJ.NAME"));
				 qry.append(" ) ");
			 }
		}
		
		if(!PLMUtils.isEmptyList(selTaskName)  && !allOpenTopLvlPart){
			 if(!whereFlag){
				 qry.append(" WHERE ("); 
				 qry.append(getStrBufferConsolidate(selTaskName, "T_TASK.NAME"));
				 qry.append(" ) ");
				 whereFlag=true;
			 }else{
				 qry.append(" AND ( "); 
				 qry.append(getStrBufferConsolidate(selTaskName, "T_TASK.NAME"));
				 qry.append(" ) ");
			 }
		}
		
		LOG.info("Executing final Query for Header Data: "+ qry);
		headerList =  getJdbcTemplate().query(qry.toString(), new GetHeaderMapper());
		LOG.info("headerList Record Count:: " + headerList.size());
			
	} catch (DataAccessException e) {
		PLMUtils.checkException(e.getMessage());
	} catch (Exception e) {
		PLMUtils.checkException(e.getMessage());
	}
	return headerList;
	}
}
