/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMIssuesReportData.java
 * @Creation date: 11-Feb-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;
import java.util.List;

public class PLMIssuesReportData {

	/**
	 * The String name
	 */
	private String name;
	/**
	 * The String description
	 */
	private String desc;
	/**
	 * The String state
	 */
	private String state;
	/**
	  * Holds the stateList
	  */
	private List<String> stateList;
	/**
	  * Holds the stateExcel
	  */
	private String stateExcel;
	/**
	 * The String owner
	 */
	private String owner;
	/**
	 * The String ownerName
	 */
	private String ownerName;
	/**
	 * The String co_owner
	 */
	private String co_owner;
	/**
	 * The String coOwnerName
	 */
	private String coOwnerName;
	/**
	 * The String orig_nator
	 */
	private String orig_nator;
	/**
	 * The String originatorName
	 */
	private String originatorName;
	/**
	 * The String from_orig_date
	 */
	private Date orig_date;
	/**
	  * Holds the orig_date_from
	  */
	private Date orig_date_from;
	/**
	  * Holds the orig_date_from_excel
	  */
	private String orig_date_from_excel;
	/**
	  * Holds the orig_date_to
	  */
	private Date orig_date_to;
	/**
	  * Holds the orig_date_to_excel
	  */
	private String orig_date_to_excel;
	/**
	  * Holds the estim_date
	  */
	
	private Date estim_date;
	/**
	  * Holds the estim_date_to
	  */
	private Date estim_date_to;
	/**
	  * Holds the estim_date_to_excel
	  */
	private String estim_date_to_excel;
	/**
	  * Holds the estim_date_from
	  */
	private Date estim_date_from;
	/**
	  * Holds the estim_date_from_excel
	  */
	private String estim_date_from_excel;
	/**
	  * Holds the act_date
	  */
	
	private Date act_date;
	/**
	  * Holds the act_date_to
	  */
	private Date act_date_to;
	/**
	  * Holds the act_date_to_excel
	  */
	private String act_date_to_excel;
	/**
	  * Holds the act_date_from
	  */
	private Date act_date_from;
	/**
	  * Holds the act_date_from_excel
	  */
	private String act_date_from_excel;
	/**
	 * The String priority
	 */
	private String priority;
	/**
	  * Holds the priorityList
	  */
	private List<String> priorityList;
	private String priorityExcel;
	/**
	 * The String int_priority
	 */
	private String int_priority;
	/**
	  * Holds the int_priorityList
	  */
	private List<String> int_priorityList;
	/**
	  * Holds the int_priorityExcel
	  */
	private String int_priorityExcel;
	/**
	 * The String category
	 */
	private String catg;
	/**
	  * Holds the catgList
	  */
	private List<String> catgList;
	/**
	  * Holds the catgExcel
	  */
	private String catgExcel;
	/**
	 * The String clas_fication
	 */
	private String clas_fication;
	/**
	  * Holds the clas_ficationList
	  */
	private List<String> clas_ficationList;
	/**
	  * Holds the stateExcel
	  */
	private String clas_ficationExcel;
	/**
	 * The String resp_Org
	 */
	private String resp_Org;
	/**
	 * The String rep_agnst
	 */
	private String rep_agnst;
	/**
	 * @return the owner_name
	 */

	private String owner_name;
	/**
	  * Holds the cycle_time
	  */
	private String cycle_time;
	/**
	  * Holds the rdo
	  */
	private String rdo;
	/**
	  * Holds the aff_item
	  */
	private String aff_item;
	/**
	  * Holds the eco
	  */
	private String eco;
	/**
	  * Holds the ecr_name
	  */
	private String ecr_name;
	/**
	  * Holds the res_org
	  */
	private String res_org;
	/**
	  * Holds the source_sys
	  */
	private String source_sys;
	/**
	  * Holds the source_sysList
	  */
	private List<String> source_sysList;
	/**
	  * Holds the source_sysExcel
	  */
	private String source_sysExcel;
	/**
	  * Holds the problem_type
	  */
	private String problem_type;
	/**
	  * Holds the problem_typeList
	  */
	private List<String> problem_typeList;
	/**
	  * Holds the problem_typeExcel
	  */
	private String problem_typeExcel;
	/**
	  * Holds the setissuesdetailedreport
	  */
	private String setissuesdetailedreport;
	/**
	  * Holds the unitSerialNum
	  */
	private String unitSerialNum;
	
	/**
	  * Holds the id
	  */
	private String id;

	/**
	  * Holds the contractName
	  */
	private String contractName;

	/**
	  * Holds the documentName
	  */
	private String documentName;
	/**
	  * Holds the partName
	  */
	private String partName;

	/**
	  * Holds the hardWareBldNm
	  */
	private String hardWareBldNm;
	/**
	  * Holds the projectName
	  */
	private String projectName;
	/**
	  * Holds the resolvedToNm
	  */
	private String resolvedToNm;
	
	private String actionTaken;
	
	private Date lastStateChange;
	/**
	  * Holds the orig_date_from_excel
	  */
	private String lastStateChange_excel;
	
	private String reportdObjNmStr;
	
	private String reportdObjIdStr;
	
	private List<String> reportdObjNmLst;
	
	private List<String> reportdObjIdLst;


	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param desc
	 *            the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state
	 *            the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the stateList
	 */
	public List<String> getStateList() {
		return stateList;
	}

	/**
	 * @param stateList the stateList to set
	 */
	public void setStateList(List<String> stateList) {
		this.stateList = stateList;
	}

	/**
	 * @return the stateExcel
	 */
	public String getStateExcel() {
		return stateExcel;
	}

	/**
	 * @param stateExcel the stateExcel to set
	 */
	public void setStateExcel(String stateExcel) {
		this.stateExcel = stateExcel;
	}

	/**
	 * @return the owner
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * @param owner
	 *            the owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}

	/**
	 * @return the co_owner
	 */
	public String getCo_owner() {
		return co_owner;
	}

	/**
	 * @param co_owner
	 *            the co_owner to set
	 */
	public void setCo_owner(String co_owner) {
		this.co_owner = co_owner;
	}

	/**
	 * @return the orig_nator
	 */
	public String getOrig_nator() {
		return orig_nator;
	}

	/**
	 * @param orig_nator
	 *            the orig_nator to set
	 */
	public void setOrig_nator(String orig_nator) {
		this.orig_nator = orig_nator;
	}

	/**
	 * @return the estim_finish
	 */

	/**
	 * @return the priority
	 */
	public String getPriority() {
		return priority;
	}

	/**
	 * @return the estim_date
	 */
	public Date getEstim_date() {
		Date temp = null;
		temp = estim_date;
		return temp;
	}

	/**
	 * @param estim_date
	 *            the estim_date to set
	 */
	public void setEstim_date(Date estim_date) {
		Date temp = null;
		temp = estim_date;
		this.estim_date = temp;
	}

	/**
	 * @return the estim_date_to
	 */
	public Date getEstim_date_to() {
		Date temp = null;
		temp = estim_date_to;
		return temp;
	}

	/**
	 * @param estim_date_to
	 *            the estim_date_to to set
	 */
	public void setEstim_date_to(Date estim_date_to) {
		Date temp = null;
		temp = estim_date_to;
		this.estim_date_to = temp;
	}

	/**
	 * @return the estim_date_from
	 */
	public Date getEstim_date_from() {
		Date temp = null;
		temp = estim_date_from;
		return temp;
	}

	/**
	 * @param estim_date_from
	 *            the estim_date_from to set
	 */
	public void setEstim_date_from(Date estim_date_from) {
		Date temp = null;
		temp = estim_date_from;
		this.estim_date_from = temp;
	}

	/**
	 * @return the act_date
	 */
	public Date getAct_date() {
		Date temp = null;
		temp = act_date;
		return temp;
	}

	/**
	 * @param act_date
	 *            the act_date to set
	 */
	public void setAct_date(Date act_date) {
		Date temp = null;
		temp = act_date;
		this.act_date = temp;
	}

	/**
	 * @return the act_date_to
	 */
	public Date getAct_date_to() {
		Date temp = null;
		temp = act_date_to;
		return temp;
	}

	/**
	 * @param act_date_to
	 *            the act_date_to to set
	 */
	public void setAct_date_to(Date act_date_to) {
		Date temp = null;
		temp = act_date_to;
		this.act_date_to = temp;
	}

	/**
	 * @return the act_date_from
	 */
	public Date getAct_date_from() {
		Date temp = null;
		temp = act_date_from;
		return temp;
	}

	/**
	 * @param act_date_from
	 *            the act_date_from to set
	 */
	public void setAct_date_from(Date act_date_from) {
		Date temp = null;
		temp = act_date_from;
		this.act_date_from = temp;
	}

	/**
	 * @param priority
	 *            the priority to set
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}

	/**
	 * @return the priorityList
	 */
	public List<String> getPriorityList() {
		return priorityList;
	}

	/**
	 * @param priorityList the priorityList to set
	 */
	public void setPriorityList(List<String> priorityList) {
		this.priorityList = priorityList;
	}

	/**
	 * @return the priorityExcel
	 */
	public String getPriorityExcel() {
		return priorityExcel;
	}

	/**
	 * @param priorityExcel the priorityExcel to set
	 */
	public void setPriorityExcel(String priorityExcel) {
		this.priorityExcel = priorityExcel;
	}

	/**
	 * @return the int_priority
	 */
	public String getInt_priority() {
		return int_priority;
	}

	/**
	 * @param int_priority
	 *            the int_priority to set
	 */
	public void setInt_priority(String int_priority) {
		this.int_priority = int_priority;
	}

	/**
	 * @return the int_priorityList
	 */
	public List<String> getInt_priorityList() {
		return int_priorityList;
	}

	/**
	 * @param int_priorityList the int_priorityList to set
	 */
	public void setInt_priorityList(List<String> int_priorityList) {
		this.int_priorityList = int_priorityList;
	}

	/**
	 * @return the int_priorityExcel
	 */
	public String getInt_priorityExcel() {
		return int_priorityExcel;
	}

	/**
	 * @param int_priorityExcel the int_priorityExcel to set
	 */
	public void setInt_priorityExcel(String int_priorityExcel) {
		this.int_priorityExcel = int_priorityExcel;
	}

	/**
	 * @return the catg
	 */
	public String getCatg() {
		return catg;
	}

	/**
	 * @param catg
	 *            the catg to set
	 */
	public void setCatg(String catg) {
		this.catg = catg;
	}

	/**
	 * @return the catgList
	 */
	public List<String> getCatgList() {
		return catgList;
	}

	/**
	 * @param catgList the catgList to set
	 */
	public void setCatgList(List<String> catgList) {
		this.catgList = catgList;
	}

	/**
	 * @return the catgExcel
	 */
	public String getCatgExcel() {
		return catgExcel;
	}

	/**
	 * @param catgExcel the catgExcel to set
	 */
	public void setCatgExcel(String catgExcel) {
		this.catgExcel = catgExcel;
	}

	/**
	 * @return the clas_fication
	 */
	public String getClas_fication() {
		return clas_fication;
	}

	/**
	 * @param clas_fication
	 *            the clas_fication to set
	 */
	public void setClas_fication(String clas_fication) {
		this.clas_fication = clas_fication;
	}

	/**
	 * @return the clas_ficationList
	 */
	public List<String> getClas_ficationList() {
		return clas_ficationList;
	}

	/**
	 * @param clas_ficationList the clas_ficationList to set
	 */
	public void setClas_ficationList(List<String> clas_ficationList) {
		this.clas_ficationList = clas_ficationList;
	}

	/**
	 * @return the clas_ficationExcel
	 */
	public String getClas_ficationExcel() {
		return clas_ficationExcel;
	}

	/**
	 * @param clas_ficationExcel the clas_ficationExcel to set
	 */
	public void setClas_ficationExcel(String clas_ficationExcel) {
		this.clas_ficationExcel = clas_ficationExcel;
	}

	/**
	 * @return the resp_Org
	 */
	public String getResp_Org() {
		return resp_Org;
	}

	/**
	 * @param resp_Org
	 *            the resp_Org to set
	 */
	public void setResp_Org(String resp_Org) {
		this.resp_Org = resp_Org;
	}

	/**
	 * @return the rep_agnst
	 */
	public String getRep_agnst() {
		return rep_agnst;
	}

	/**
	 * @param rep_agnst
	 *            the rep_agnst to set
	 */
	public void setRep_agnst(String rep_agnst) {
		this.rep_agnst = rep_agnst;
	}

	/**
	 * @return the orig_date_from
	 */
	public Date getOrig_date_from() {
		Date temp = null;
		temp = orig_date_from;
		return temp;
	}

	/**
	 * @param orig_date_from
	 *            the orig_date_from to set
	 */
	public void setOrig_date_from(Date orig_date_from) {
		Date temp = null;
		temp = orig_date_from;
		this.orig_date_from = temp;
	}

	/**
	 * @return the orig_date_to
	 */
	public Date getOrig_date_to() {
		Date temp = null;
		temp = orig_date_to;
		return temp;
	}

	/**
	 * @param orig_date_to
	 *            the orig_date_to to set
	 */
	public void setOrig_date_to(Date orig_date_to) {
		Date temp = null;
		temp = orig_date_to;
		this.orig_date_to = temp;
	}

	/**
	 * @return the orig_date
	 */
	public Date getOrig_date() {
		Date temp = null;
		temp = orig_date;
		return temp;
	}

	/**
	 * @param orig_date
	 *            the orig_date to set
	 */
	public void setOrig_date(Date orig_date) {
		Date temp = null;
		temp = orig_date;
		this.orig_date = temp;
	}

	/**
	 * @return the owner_name
	 */
	public String getOwner_name() {
		return owner_name;
	}

	/**
	 * @param owner_name
	 *            the owner_name to set
	 */
	public void setOwner_name(String owner_name) {
		this.owner_name = owner_name;
	}

	/**
	 * @return the cycle_time
	 */
	public String getCycle_time() {
		return cycle_time;
	}

	/**
	 * @param cycle_time
	 *            the cycle_time to set
	 */
	public void setCycle_time(String cycle_time) {
		this.cycle_time = cycle_time;
	}

	/**
	 * @return the rdo
	 */
	public String getRdo() {
		return rdo;
	}

	/**
	 * @param rdo
	 *            the rdo to set
	 */
	public void setRdo(String rdo) {
		this.rdo = rdo;
	}

	/**
	 * @return the aff_item
	 */
	public String getAff_item() {
		return aff_item;
	}

	/**
	 * @param aff_item
	 *            the aff_item to set
	 */
	public void setAff_item(String aff_item) {
		this.aff_item = aff_item;
	}

	/**
	 * @return the eco
	 */
	public String getEco() {
		return eco;
	}

	/**
	 * @param eco
	 *            the eco to set
	 */
	public void setEco(String eco) {
		this.eco = eco;
	}

	/**
	 * @return the ecr_name
	 */
	public String getEcr_name() {
		return ecr_name;
	}

	/**
	 * @param ecr_name
	 *            the ecr_name to set
	 */
	public void setEcr_name(String ecr_name) {
		this.ecr_name = ecr_name;
	}

	/**
	 * @return the res_org
	 */
	public String getRes_org() {
		return res_org;
	}

	/**
	 * @param res_org
	 *            the res_org to set
	 */
	public void setRes_org(String res_org) {
		this.res_org = res_org;
	}

	/**
	 * @return the source_sys
	 */
	public String getSource_sys() {
		return source_sys;
	}

	/**
	 * @param source_sys
	 *            the source_sys to set
	 */
	public void setSource_sys(String source_sys) {
		this.source_sys = source_sys;
	}
	/**
	 * @return the source_sysList
	 */
	public List<String> getSource_sysList() {
		return source_sysList;
	}

	/**
	 * @param source_sysList the source_sysList to set
	 */
	public void setSource_sysList(List<String> source_sysList) {
		this.source_sysList = source_sysList;
	}

	/**
	 * @return the source_sysExcel
	 */
	public String getSource_sysExcel() {
		return source_sysExcel;
	}

	/**
	 * @param source_sysExcel the source_sysExcel to set
	 */
	public void setSource_sysExcel(String source_sysExcel) {
		this.source_sysExcel = source_sysExcel;
	}

	/**
	 * @return the problem_type
	 */
	public String getProblem_type() {
		return problem_type;
	}

	/**
	 * @param problem_type
	 *            the problem_type to set
	 */
	public void setProblem_type(String problem_type) {
		this.problem_type = problem_type;
	}

	/**
	 * @return the problem_typeList
	 */
	public List<String> getProblem_typeList() {
		return problem_typeList;
	}

	/**
	 * @param problem_typeList the problem_typeList to set
	 */
	public void setProblem_typeList(List<String> problem_typeList) {
		this.problem_typeList = problem_typeList;
	}

	/**
	 * @return the problem_typeExcel
	 */
	public String getProblem_typeExcel() {
		return problem_typeExcel;
	}

	/**
	 * @param problem_typeExcel the problem_typeExcel to set
	 */
	public void setProblem_typeExcel(String problem_typeExcel) {
		this.problem_typeExcel = problem_typeExcel;
	}

	/**
	 * @return the setissuesdetailedreport
	 */
	public String getSetissuesdetailedreport() {
		return setissuesdetailedreport;
	}

	/**
	 * @param setissuesdetailedreport
	 *            the setissuesdetailedreport to set
	 */
	public void setSetissuesdetailedreport(String setissuesdetailedreport) {
		this.setissuesdetailedreport = setissuesdetailedreport;
	}

	/**
	 * @return the ownerName
	 */
	public String getOwnerName() {
		return ownerName;
	}

	/**
	 * @param ownerName the ownerName to set
	 */
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	/**
	 * @return the originatorName
	 */
	public String getOriginatorName() {
		return originatorName;
	}

	/**
	 * @param originatorName the originatorName to set
	 */
	public void setOriginatorName(String originatorName) {
		this.originatorName = originatorName;
	}

	/**
	 * @return the coOwnerName
	 */
	public String getCoOwnerName() {
		return coOwnerName;
	}

	/**
	 * @param coOwnerName the coOwnerName to set
	 */
	public void setCoOwnerName(String coOwnerName) {
		this.coOwnerName = coOwnerName;
	}

	/**
	 * @return the orig_date_from_excel
	 */
	public String getOrig_date_from_excel() {
		return orig_date_from_excel;
	}

	/**
	 * @param orig_date_from_excel the orig_date_from_excel to set
	 */
	public void setOrig_date_from_excel(String orig_date_from_excel) {
		this.orig_date_from_excel = orig_date_from_excel;
	}

	/**
	 * @return the estim_date_to_excel
	 */
	public String getEstim_date_to_excel() {
		return estim_date_to_excel;
	}

	/**
	 * @param estim_date_to_excel the estim_date_to_excel to set
	 */
	public void setEstim_date_to_excel(String estim_date_to_excel) {
		this.estim_date_to_excel = estim_date_to_excel;
	}

	/**
	 * @return the estim_date_from_excel
	 */
	public String getEstim_date_from_excel() {
		return estim_date_from_excel;
	}

	/**
	 * @param estim_date_from_excel the estim_date_from_excel to set
	 */
	public void setEstim_date_from_excel(String estim_date_from_excel) {
		this.estim_date_from_excel = estim_date_from_excel;
	}

	/**
	 * @return the act_date_to_excel
	 */
	public String getAct_date_to_excel() {
		return act_date_to_excel;
	}

	/**
	 * @param act_date_to_excel the act_date_to_excel to set
	 */
	public void setAct_date_to_excel(String act_date_to_excel) {
		this.act_date_to_excel = act_date_to_excel;
	}

	/**
	 * @return the act_date_from_excel
	 */
	public String getAct_date_from_excel() {
		return act_date_from_excel;
	}

	/**
	 * @param act_date_from_excel the act_date_from_excel to set
	 */
	public void setAct_date_from_excel(String act_date_from_excel) {
		this.act_date_from_excel = act_date_from_excel;
	}

	/**
	 * @return the orig_date_to_excel
	 */
	public String getOrig_date_to_excel() {
		return orig_date_to_excel;
	}

	/**
	 * @param orig_date_to_excel the orig_date_to_excel to set
	 */
	public void setOrig_date_to_excel(String orig_date_to_excel) {
		this.orig_date_to_excel = orig_date_to_excel;
	}

	/**
	 * @return the unitSerialNum
	 */
	public String getUnitSerialNum() {
		return unitSerialNum;
	}

	/**
	 * @param unitSerialNum the unitSerialNum to set
	 */
	public void setUnitSerialNum(String unitSerialNum) {
		this.unitSerialNum = unitSerialNum;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the contractName
	 */
	public String getContractName() {
		return contractName;
	}

	/**
	 * @param contractName the contractName to set
	 */
	public void setContractName(String contractName) {
		this.contractName = contractName;
	}

	/**
	 * @return the documentName
	 */
	public String getDocumentName() {
		return documentName;
	}

	/**
	 * @param documentName the documentName to set
	 */
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	/**
	 * @return the partName
	 */
	public String getPartName() {
		return partName;
	}

	/**
	 * @param partName the partName to set
	 */
	public void setPartName(String partName) {
		this.partName = partName;
	}

	/**
	 * @return the hardWareBldNm
	 */
	public String getHardWareBldNm() {
		return hardWareBldNm;
	}

	/**
	 * @param hardWareBldNm the hardWareBldNm to set
	 */
	public void setHardWareBldNm(String hardWareBldNm) {
		this.hardWareBldNm = hardWareBldNm;
	}

	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	/**
	 * @return the resolvedToNm
	 */
	public String getResolvedToNm() {
		return resolvedToNm;
	}

	/**
	 * @param resolvedToNm the resolvedToNm to set
	 */
	public void setResolvedToNm(String resolvedToNm) {
		this.resolvedToNm = resolvedToNm;
	}

	public String getActionTaken() {
		return actionTaken;
	}

	public void setActionTaken(String actionTaken) {
		this.actionTaken = actionTaken;
	}

	public Date getLastStateChange() {
		Date temp = null;
		temp = lastStateChange;
		return temp;
	}

	public void setLastStateChange(Date lastStateChange) {
		Date temp = null;
		temp = lastStateChange;
		this.lastStateChange = temp;
	}

	public String getLastStateChange_excel() {
		return lastStateChange_excel;
	}

	public void setLastStateChange_excel(String lastStateChange_excel) {
		this.lastStateChange_excel = lastStateChange_excel;
	}

	public String getReportdObjNmStr() {
		return reportdObjNmStr;
	}

	public void setReportdObjNmStr(String reportdObjNmStr) {
		this.reportdObjNmStr = reportdObjNmStr;
	}

	public String getReportdObjIdStr() {
		return reportdObjIdStr;
	}

	public void setReportdObjIdStr(String reportdObjIdStr) {
		this.reportdObjIdStr = reportdObjIdStr;
	}

	public List<String> getReportdObjNmLst() {
		return reportdObjNmLst;
	}

	public void setReportdObjNmLst(List<String> reportdObjNmLst) {
		this.reportdObjNmLst = reportdObjNmLst;
	}

	public List<String> getReportdObjIdLst() {
		return reportdObjIdLst;
	}

	public void setReportdObjIdLst(List<String> reportdObjIdLst) {
		this.reportdObjIdLst = reportdObjIdLst;
	}

	
	
}
// Ended By Adesh
