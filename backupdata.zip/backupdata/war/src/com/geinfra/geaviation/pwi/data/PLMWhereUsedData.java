/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhereUsedData.java
 * @Creation date: 23-July-2011
 * @version 1.0
 * @author :Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="PLMWhereUsedData")
public class PLMWhereUsedData {
	/**
	  * Holds the partNumber
	  */
	private String partNumber;
	/**
	  * Holds the unitNumber
	  */
	private String unitNumber;
	/**
	  * Holds the designMemo
	  */
	private String designMemo;
	/**
	  * Holds the shopOrder
	  */
	private String shopOrder;
	/**
	  * Holds the serialNo
	  */
	private String serialNo;
	/**
	  * Holds the status
	  */
	private String status;
	
	/**
	  * Holds the dwgNo
	  */
	private String dwgNo;
	/**
	  * Holds the dwgTitle
	  */
	private String dwgTitle;
	/**
	  * Holds the parentPin
	  */
	private String parentPin;
	/**
	  * Holds the quantity
	  */
	private String quantity;
	/**
	  * Holds the invalidBom
	  */
	private String invalidBom;
	/**
	  * Holds the bomHeader
	  */
	private boolean bomHeader;
	/**
	  * Holds the invalidData
	  */
	private boolean invalidData;
	/**
	  * Holds the blank
	  */
	private boolean blank;
	 
	//Radio button
	/**
	  * Holds the statusIndr
	  */
	private String statusIndr;
	
	//PLMWhereUsedLogicalIndicator
	/**
	  * Holds the document
	  */
	private boolean document;
	/**
	  * Holds the partSpecification
	  */
	private boolean partSpecification;
	/**
	  * Holds the refDocument
	  */
	private boolean refDocument;
	/**
	  * Holds the project
	  */
	private String project;
	/**
	  * Holds the contract
	  */
	private String contract;
	/**
	  * Holds the docName
	  */
	private String docName;
	/**
	  * Holds the partNo
	  */
	private String partNo;
	/**
	  * Holds the docTitle
	  */
	private String docTitle;
	/**
	  * Holds the type
	  */
	private String type;
	/**
	  * Holds the rev
	  */
	private String rev;
	/**
	  * Holds the logicalIndicator
	  */
	private String logicalIndicator;
	/**
	  * Holds the typeOfLogicalIndicator
	  */
	private String typeOfLogicalIndicator;
	//PLMWhereUsedLogicalIndicator

	//PLMWhereUsedEMBOMData
	/**
	  * Holds the unitSerialNumber
	  */
	private String unitSerialNumber;
	/**
	  * Holds the mliCode
	  */
	private String mliCode;
	/**
	  * Holds the partDwg
	  */
	private String partDwg;
	/**
	  * Holds the partDescription
	  */
	private String partDescription;
	/**
	  * Holds the plmObjectTypevalue
	  */
	private String plmObjectTypevalue;
	/**
	  * Holds the effectivityDateFrom
	  */
	private Date effectivityDateFrom;
	/**
	  * Holds the effectivityDateTo
	  */
	private Date effectivityDateTo;
	/**
	  * Holds the qtyLocation
	  */
	private String qtyLocation;
	/**
	  * Holds the plmRelation
	  */
	private String plmRelation;
	/**
	  * Holds the loadDate
	  */
	private Date loadDate;
	/**
	  * Holds the nextUpperLevelDesc
	  */
	private String nextUpperLevelDesc;
	/**
	  * Holds the nextUpperLevel
	  */
	private String nextUpperLevel;
	/**
	  * Holds the plmRelationship
	  */
	private String plmRelationship;
	/**
	  * Holds the designDemo
	  */
	private String designDemo;
	/**
	  * Holds the partDwgDescription
	  */
	private String partDwgDescription;
	/**
	  * Holds the serialNumber
	  */
	private String serialNumber;
	/**
	  * Holds the plmObjectStatus
	  */
	private String plmObjectStatus;
	/**
	  * Holds the eMbomDate
	  */
	private String eMbomDate;
	/**
	  * Holds the originOfRecord
	  */
	private String originOfRecord;
	/**
	  * Holds the unitSerialNum
	  */
	private String unitSerialNum;
	/**
	  * Holds the part
	  */
	private boolean part;
	/**
	  * Holds the dwg
	  */
	private boolean dwg;
	/**
	  * Holds the partValue
	  */
	private String partValue;
	/**
	  * Holds the dwgValue
	  */
	private String dwgValue;
	/**
	  * Holds the partDwgValue
	  */
	private String partDwgValue;
	
	//added by lakshmi for PLM Where Used MF/TF Report
	
	/**
	  * Holds the tchFeatureNm
	  */
	private String tchFeatureNm;
	/**
	  * Holds the mfTfTypeList
	  */
	private List<String> mfTfTypeList;
	/**
	  * Holds the description
	  */
	private String description;
	/**
	  * Holds the mfTfStateList
	  */
	private List<String> mfTfStateList;
	/**
	  * Holds the chkManOpVal
	  */
	private boolean chkManOpVal;
	/**
	  * Holds the mftfTypeString
	  */
	private String mftfTypeString;
	/**
	  * Holds the mftfStateString
	  */
	private String mftfStateString;
	/**
	  * Holds the mkttchFeatureNm
	  */
	private String mkttchFeatureNm = "Marketing";
	/**
	  * Holds the name
	  */
	private String name;
	/**
	  * Holds the contractName
	  */
	private String contractName;
	/**
	  * Holds the cusName
	  */
	private String cusName;
	/**
	  * Holds the model
	  */
	private String model;
	/**
	  * Holds the mktFeatureNm
	  */
	private String mktFeatureNm;
	/**
	  * Holds the state
	  */
	private String state;
	/**
	  * Holds the qty
	  */
	private String qty;
	/**
	  * Holds the ruleType
	  */
	private String ruleType;
	/**
	  * Holds the ruleExp
	  */
	private String ruleExp;
	/**
	  * Holds the partFamily
	  */
	private String partFamily;
	/**
	  * Holds the featureUsg
	  */
	private String featureUsg;
	
	//added for BMLL Report
	/**
	  * Holds the unitAssembleNumber
	  */
	private String unitAssembleNumber;
	/**
	  * Holds the parentItem
	  */
	private String parentItem;
	/**
	  * Holds the childItem
	  */
	private String childItem;
	/**
	  * Holds the authecn
	  */
	private String authecn;
	/**
	  * Holds the itemEffectivityStartDate
	  */
	private Date itemEffectivityStartDate;
	/**
	  * Holds the itemEffectivityEndDate
	  */
	private Date itemEffectivityEndDate;
	/**
	  * Holds the level
	  */
	private int level;
	/**
	  * Holds the pin
	  */
	private String pin;
	/**
	  * Holds the source
	  */
	private String source;
	
	//Newly Added
	/**
	  * Holds the partDwgVal
	  */
	private String partDwgVal;
	/**
	  * Holds the descriptionVal
	  */
	private String descriptionVal;
	
	//Newly Added filter criteria
	/**
	  * Holds the relatedName
	  */
	private String relatedName;
	/**
	  * Holds the relatedItem
	  */
	private String relatedItem;
	/**
	  * Holds the relatedItemType
	  */
	private String relatedItemType;
	
	//Added by Raju
	
	//For copics data
	/**
	  * Holds the parentItem1
	  */
	private String parentItem1;
	/**
	  * Holds the imdtParentItem
	  */
	private String imdtParentItem;
	/**
	  * Holds the srlNum
	  */
	private String srlNum;
	/**
	  * Holds the status1
	  */
	private String status1;
	
	//For Sbom data
	/**
	  * Holds the turbnNUm
	  */
	private String turbnNUm;
	/**
	  * Holds the srlNum1
	  */
	private String srlNum1;
	/**
	  * Holds the newItem
	  */
	private String newItem;
	/**
	  * Holds the oldItem
	  */
	private String oldItem;
	/**
	  * Holds the mli
	  */
	private String mli;
	/**
	  * Holds the descript
	  */
	private String descript;
	/**
	  * Holds the dtent
	  */
	private String dtent;
	/**
	  * Holds the qty1
	  */
	private String qty1;
	/**
	  * Holds the authen
	  */
	private String authen;
	/**
	  * Holds the orign
	  */
	private String orign;
		
	//For ebom data
	/**
	  * Holds the topLvlParentId
	  */
	private String topLvlParentId;
	/**
	  * Holds the topLvlParentNm
	  */
	private String topLvlParentNm;
	/**
	  * Holds the topLvlParentRev
	  */
	private String topLvlParentRev;
	/**
	  * Holds the immediateParentId
	  */
	private String immediateParentId;
	/**
	  * Holds the immediateParent
	  */
	private String immediateParent;
	/**
	  * Holds the immediateParentRev
	  */
	private String immediateParentRev;
	/**
	  * Holds the partId
	  */
	private String partId;
	/**
	  * Holds the partNm
	  */
	private String partNm;
	/**
	  * Holds the partDesc
	  */
	private String partDesc;
	/**
	  * Holds the lvl
	  */
	private String lvl;
	/**
	  * Holds the dfsOrdr
	  */
	private String dfsOrdr;
	/**
	  * Holds the contractId
	  */
	private String contractId;
	/**
	  * Holds the hwPrdId
	  */
	private String hwPrdId;
	/**
	  * Holds the ftrId
	  */
	private String ftrId;
	/**
	  * Holds the selectedTypeExl
	  */
	private String selectedTypeExl;
	
	/**
	  * Holds the dtentExl
	  */
	private Date dtentExl;
	//Newly Added Ids
	/**
	  * Holds the parentItemId
	  */
	private String parentItemId;
	/**
	  * Holds the childItemId
	  */
	private String childItemId;
	//End
	/**
	  * Holds the topLvlParent
	  */
	private String topLvlParent;
	/**
	  * Holds the topLvlParentDesc
	  */
	private String topLvlParentDesc;
	/**
	  * Holds the imdParent
	  */
	private String imdParent;
	/**
	  * Holds the imdParentDesc
	  */
	private String imdParentDesc;
	/**
	  * Holds the partNum
	  */
	private String partNum;
	/**
	  * Holds the childItemId
	  */
	private String partUom;
	/**
	  * Holds the partCount
	  */
	private int partCount;
	/**
	  * Holds the topPartCount
	  */
	private int topPartCount;
	
	
	
	/**
	 * Holds The selection type for optionvalue
	 */
	private String optionval;
	
	
	/**
	 * Holds The quantity value what user can input
	 */
	private String quantityval;
	
	
	
	/**
	 * Holds the UOM ID 
	 */
	private String uom;
	
	/**
	 * Holds the UOM Description
	 */
	private String uomDesc;
	
	/**
	 * Holds the systemId
	 */
	private String systemId;
	
	/**
	 * Holds the systemName
	 */
	private String systemName;
	
	/**
	 * Holds the className
	 */
	private String className;
	
	/**
	 * Holds the relType
	 */
	private String relType;
	
	/**
	 * Holds the parentName
	 */
	private String parentName;
	
	/**
	 * Holds the parentTextName
	 */
	private String parentTextName;
	
	/**
	 * Holds the childName
	 */
	private String childName;
	

	/**
	 * Holds the childRev
	 */
	private String childRev;
	
	/**
	 * Holds the textName
	 */
	private String textName;
	
	/**
	 * Holds the t4refPartNumber
	 */
	private String t4refPartNumber;
	
	/**
	 * Holds the t4refPartRev
	 */
	private String t4refPartRev;
	
	/**
	 * Holds the bomLevel
	 */
	private String bomLevel;
	
	/**
	 * Holds the languageCode
	 */
	private String languageCode;
	
	
	
	

	/**
	 * @return the languageCode
	 */
	public String getLanguageCode() {
		return languageCode;
	}

	/**
	 * @param languageCode the languageCode to set
	 */
	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}

	/**
	 * @return the uom
	 */
	public String getUom() {
		return uom;
	}

	/**
	 * @param uom the uom to set
	 */
	public void setUom(String uom) {
		this.uom = uom;
	}

	/**
	 * @return the uomDesc
	 */
	public String getUomDesc() {
		return uomDesc;
	}

	/**
	 * @param uomDesc the uomDesc to set
	 */
	public void setUomDesc(String uomDesc) {
		this.uomDesc = uomDesc;
	}

	/**
	 * @return the statusIndr
	 */
	public String getStatusIndr() {
		return statusIndr;
	}
	
	/**
	 * @param statusIndr
	 */
	public void setStatusIndr(String statusIndr) {
		this.statusIndr = statusIndr;
	}
	
	
	//PLMWhereUsedEMBOMData
	
	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}
	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	/**
	 * @return the unitNumber
	 */
	public String getUnitNumber() {
		return unitNumber;
	}
	/**
	 * @param unitNumber the unitNumber to set
	 */
	public void setUnitNumber(String unitNumber) {
		this.unitNumber = unitNumber;
	}
	/**
	 * @return the designMemo
	 */
	public String getDesignMemo() {
		return designMemo;
	}
	/**
	 * @param designMemo the designMemo to set
	 */
	public void setDesignMemo(String designMemo) {
		this.designMemo = designMemo;
	}
	/**
	 * @return the shopOrder
	 */
	public String getShopOrder() {
		return shopOrder;
	}
	/**
	 * @param shopOrder the shopOrder to set
	 */
	public void setShopOrder(String shopOrder) {
		this.shopOrder = shopOrder;
	}
	/**
	 * @return the serialNo
	 */
	public String getSerialNo() {
		return serialNo;
	}
	/**
	 * @param serialNo the serialNo to set
	 */
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the loadDate
	 */

	public Date getLoadDate() {
		Date temp = null;
		temp = loadDate;
		return temp;
	}
	/**
	 * @param loadDate the loadDate to set
	 */
	public void setLoadDate(Date loadDate) {
		Date temp = null;
		temp = loadDate;
		this.loadDate = temp;
	}
	/**
	 * @return the project
	 */
	public String getProject() {
		return project;
	}
	/**
	 * @param project the project to set
	 */
	public void setProject(String project) {
		this.project = project;
	}
	/**
	 * @return the contract
	 */
	public String getContract() {
		return contract;
	}
	/**
	 * @param contract the contract to set
	 */
	public void setContract(String contract) {
		this.contract = contract;
	}
	/**
	 * @return the docName
	 */
	public String getDocName() {
		return docName;
	}
	/**
	 * @param docName the docName to set
	 */
	public void setDocName(String docName) {
		this.docName = docName;
	}
	/**
	 * @return the docTitle
	 */
	public String getDocTitle() {
		return docTitle;
	}
	/**
	 * @param docTitle the docTitle to set
	 */
	public void setDocTitle(String docTitle) {
		this.docTitle = docTitle;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the rev
	 */
	public String getRev() {
		return rev;
	}
	/**
	 * @param rev the rev to set
	 */
	public void setRev(String rev) {
		this.rev = rev;
	}
	/**
	 * @return the logicalIndicator
	 */
	public String getLogicalIndicator() {
		return logicalIndicator;
	}
	/**
	 * @param logicalIndicator the logicalIndicator to set
	 */
	public void setLogicalIndicator(String logicalIndicator) {
		this.logicalIndicator = logicalIndicator;
	}
	/**
	 * @return the typeOfLogicalIndicator
	 */
	public String getTypeOfLogicalIndicator() {
		return typeOfLogicalIndicator;
	}
	/**
	 * @param typeOfLogicalIndicator the typeOfLogicalIndicator to set
	 */
	public void setTypeOfLogicalIndicator(String typeOfLogicalIndicator) {
		this.typeOfLogicalIndicator = typeOfLogicalIndicator;
	}
	/**
	 * @return the unitSerialNumber
	 */
	public String getUnitSerialNumber() {
		return unitSerialNumber;
	}
	/**
	 * @param unitSerialNumber the unitSerialNumber to set
	 */
	public void setUnitSerialNumber(String unitSerialNumber) {
		this.unitSerialNumber = unitSerialNumber;
	}
	/**
	 * @return the mliCode
	 */
	public String getMliCode() {
		return mliCode;
	}
	/**
	 * @param mliCode the mliCode to set
	 */
	public void setMliCode(String mliCode) {
		this.mliCode = mliCode;
	}
	/**
	 * @return the partDwg
	 */
	public String getPartDwg() {
		return partDwg;
	}
	/**
	 * @param partDwg the partDwg to set
	 */
	public void setPartDwg(String partDwg) {
		this.partDwg = partDwg;
	}
	/**
	 * @return the partDescription
	 */
	public String getPartDescription() {
		return partDescription;
	}
	/**
	 * @param partDescription the partDescription to set
	 */
	public void setPartDescription(String partDescription) {
		this.partDescription = partDescription;
	}
	
	public String getPlmObjectTypevalue() {
		return plmObjectTypevalue;
	}
	public void setPlmObjectTypevalue(String plmObjectTypevalue) {
		this.plmObjectTypevalue = plmObjectTypevalue;
	}
	
	
	/**
	 * @return the effectivityDateFrom
	 */
	public Date getEffectivityDateFrom() {
		Date temp = null;
		temp = effectivityDateFrom;
		return temp;
	}
	/**
	 * @param effectivityDateFrom the effectivityDateFrom to set
	 */
	public void setEffectivityDateFrom(Date effectivityDateFrom) {
		Date temp = null;
		temp = effectivityDateFrom;
		this.effectivityDateFrom = temp;
	}
	/**
	 * @return the effectivityDateTo
	 */
	public Date getEffectivityDateTo() {
		Date temp = null;
		temp = effectivityDateTo;
		return temp;
	}
	/**
	 * @param effectivityDateTo the effectivityDateTo to set
	 */
	public void setEffectivityDateTo(Date effectivityDateTo) {
		Date temp = null;
		temp = effectivityDateTo;
		this.effectivityDateTo = temp;
	}
	
	/**
	 * @return the qtyLocation
	 */
	public String getQtyLocation() {
		return qtyLocation;
	}

	/**
	 * @param qtyLocation the qtyLocation to set
	 */
	public void setQtyLocation(String qtyLocation) {
		this.qtyLocation = qtyLocation;
	}

	/**
	 * @return the plmRelation
	 */
	public String getPlmRelation() {
		return plmRelation;
	}

	/**
	 * @param plmRelation the plmRelation to set
	 */
	public void setPlmRelation(String plmRelation) {
		this.plmRelation = plmRelation;
	}

	/**
	 * @return the nextUpperLevelDesc
	 */
	public String getNextUpperLevelDesc() {
		return nextUpperLevelDesc;
	}

	/**
	 * @param nextUpperLevelDesc the nextUpperLevelDesc to set
	 */
	public void setNextUpperLevelDesc(String nextUpperLevelDesc) {
		this.nextUpperLevelDesc = nextUpperLevelDesc;
	}

	/**
	 * @return the nextUpperLevel
	 */
	public String getNextUpperLevel() {
		return nextUpperLevel;
	}

	/**
	 * @param nextUpperLevel the nextUpperLevel to set
	 */
	public void setNextUpperLevel(String nextUpperLevel) {
		this.nextUpperLevel = nextUpperLevel;
	}

	/**
	 * @return the plmRelationship
	 */
	public String getPlmRelationship() {
		return plmRelationship;
	}

	/**
	 * @param plmRelationship the plmRelationship to set
	 */
	public void setPlmRelationship(String plmRelationship) {
		this.plmRelationship = plmRelationship;
	}

	/**
	 * @return the designDemo
	 */
	public String getDesignDemo() {
		return designDemo;
	}

	/**
	 * @param designDemo the designDemo to set
	 */
	public void setDesignDemo(String designDemo) {
		this.designDemo = designDemo;
	}

	/**
	 * @return the partDwgDescription
	 */
	public String getPartDwgDescription() {
		return partDwgDescription;
	}

	/**
	 * @param partDwgDescription the partDwgDescription to set
	 */
	public void setPartDwgDescription(String partDwgDescription) {
		this.partDwgDescription = partDwgDescription;
	}

	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}

	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * @return the plmObjectStatus
	 */
	public String getPlmObjectStatus() {
		return plmObjectStatus;
	}

	/**
	 * @param plmObjectStatus the plmObjectStatus to set
	 */
	public void setPlmObjectStatus(String plmObjectStatus) {
		this.plmObjectStatus = plmObjectStatus;
	}

	/**
	 * @return the originOfRecord
	 */
	public String getOriginOfRecord() {
		return originOfRecord;
	}

	/**
	 * @param originOfRecord the originOfRecord to set
	 */
	public void setOriginOfRecord(String originOfRecord) {
		this.originOfRecord = originOfRecord;
	}

	/**
	 * @return the unitSerialNum
	 */
	public String getUnitSerialNum() {
		return unitSerialNum;
	}

	/**
	 * @param unitSerialNum the unitSerialNum to set
	 */
	public void setUnitSerialNum(String unitSerialNum) {
		this.unitSerialNum = unitSerialNum;
	}

	/**
	 * @return the part
	 */
	public boolean isPart() {
		return part;
	}

	/**
	 * @param part the part to set
	 */
	public void setPart(boolean part) {
		this.part = part;
	}

	/**
	 * @return the dwg
	 */
	public boolean isDwg() {
		return dwg;
	}

	/**
	 * @param dwg the dwg to set
	 */
	public void setDwg(boolean dwg) {
		this.dwg = dwg;
	}

	/**
	 * @return the document
	 */
	public boolean isDocument() {
		return document;
	}
	/**
	 * @param document the document to set
	 */
	public void setDocument(boolean document) {
		this.document = document;
	}
	/**
	 * @return the partSpecification
	 */
	public boolean isPartSpecification() {
		return partSpecification;
	}
	/**
	 * @param partSpecification the partSpecification to set
	 */
	public void setPartSpecification(boolean partSpecification) {
		this.partSpecification = partSpecification;
	}
	/**
	 * @return the refDocument
	 */
	public boolean isRefDocument() {
		return refDocument;
	}
	/**
	 * @param refDocument the refDocument to set
	 */
	public void setRefDocument(boolean refDocument) {
		this.refDocument = refDocument;
	}
	/**
	 * @return the dwgNo
	 */
	public String getDwgNo() {
		return dwgNo;
	}
	/**
	 * @param dwgNo the dwgNo to set
	 */
	public void setDwgNo(String dwgNo) {
		this.dwgNo = dwgNo;
	}
	/**
	 * @return the invalidData
	 */
	public boolean isInvalidData() {
		return invalidData;
	}
	/**
	 * @param invalidData the invalidData to set
	 */
	public void setInvalidData(boolean invalidData) {
		this.invalidData = invalidData;
	}
	/**
	 * @return the dwgTitle
	 */
	public String getDwgTitle() {
		return dwgTitle;
	}
	/**
	 * @param dwgTitle the dwgTitle to set
	 */
	public void setDwgTitle(String dwgTitle) {
		this.dwgTitle = dwgTitle;
	}
	/**
	 * @return the parentPin
	 */
	public String getParentPin() {
		return parentPin;
	}
	/**
	 * @param parentPin the parentPin to set
	 */
	public void setParentPin(String parentPin) {
		this.parentPin = parentPin;
	}
	/**
	 * @return the quantity
	 */
	public String getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return the invalidBom
	 */
	public String getInvalidBom() {
		return invalidBom;
	}
	/**
	 * @param invalidBom the invalidBom to set
	 */
	public void setInvalidBom(String invalidBom) {
		this.invalidBom = invalidBom;
	}
	public String getPartValue() {
		return partValue;
	}
	public void setPartValue(String partValue) {
		this.partValue = partValue;
	}
	public String getDwgValue() {
		return dwgValue;
	}
	public void setDwgValue(String dwgValue) {
		this.dwgValue = dwgValue;
	}
	/**
	 * @return the blank
	 */
	public boolean isBlank() {
		return blank;
	}
	/**
	 * @param blank the blank to set
	 */
	public void setBlank(boolean blank) {
		this.blank = blank;
	}
	public String getPartDwgValue() {
		return partDwgValue;
	}
	public void setPartDwgValue(String partDwgValue) {
		this.partDwgValue = partDwgValue;
	}
	/**
	 * @return the bomHeader
	 */
	public boolean isBomHeader() {
		return bomHeader;
	}
	/**
	 * @param bomHeader the bomHeader to set
	 */
	public void setBomHeader(boolean bomHeader) {
		this.bomHeader = bomHeader;
	}
	/**
	 * @return the partNo
	 */
	public String getPartNo() {
		return partNo;
	}
	/**
	 * @param partNo the partNo to set
	 */
	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}
	/**
	 * @return the mktFeatureNm
	 */
	public String getMktFeatureNm() {
		return mktFeatureNm;
	}
	/**
	 * @param mktFeatureNm the mktFeatureNm to set
	 */
	public void setMktFeatureNm(String mktFeatureNm) {
		this.mktFeatureNm = mktFeatureNm;
	}
	/**
	 * @return the tchFeatureNm
	 */
	public String getTchFeatureNm() {
		return tchFeatureNm;
	}
	/**
	 * @param tchFeatureNm the tchFeatureNm to set
	 */
	public void setTchFeatureNm(String tchFeatureNm) {
		this.tchFeatureNm = tchFeatureNm;
	}
	/**
	 * @return the mfTfTypeList
	 */
	public List<String> getMfTfTypeList() {
		return mfTfTypeList;
	}
	/**
	 * @param mfTfTypeList the mfTfTypeList to set
	 */
	public void setMfTfTypeList(List<String> mfTfTypeList) {
		this.mfTfTypeList = mfTfTypeList;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the contractName
	 */
	public String getContractName() {
		return contractName;
	}
	/**
	 * @param contractName the contractName to set
	 */
	public void setContractName(String contractName) {
		this.contractName = contractName;
	}
	/**
	 * @return the mfTfStateList
	 */
	public List<String> getMfTfStateList() {
		return mfTfStateList;
	}
	/**
	 * @param mfTfStateList the mfTfStateList to set
	 */
	public void setMfTfStateList(List<String> mfTfStateList) {
		this.mfTfStateList = mfTfStateList;
	}
	/**
	 * @return the chkManOpVal
	 */
	public boolean isChkManOpVal() {
		return chkManOpVal;
	}
	/**
	 * @param chkManOpVal the chkManOpVal to set
	 */
	public void setChkManOpVal(boolean chkManOpVal) {
		this.chkManOpVal = chkManOpVal;
	}
	/**
	 * @return the mftfTypeString
	 */
	public String getMftfTypeString() {
		return mftfTypeString;
	}
	/**
	 * @param mftfTypeString the mftfTypeString to set
	 */
	public void setMftfTypeString(String mftfTypeString) {
		this.mftfTypeString = mftfTypeString;
	}
	/**
	 * @return the mftfStateString
	 */
	public String getMftfStateString() {
		return mftfStateString;
	}
	/**
	 * @param mftfStateString the mftfStateString to set
	 */
	public void setMftfStateString(String mftfStateString) {
		this.mftfStateString = mftfStateString;
	}
	/**
	 * @return the mkttchFeatureNm
	 */
	public String getMkttchFeatureNm() {
		return mkttchFeatureNm;
	}
	/**
	 * @param mkttchFeatureNm the mkttchFeatureNm to set
	 */
	public void setMkttchFeatureNm(String mkttchFeatureNm) {
		this.mkttchFeatureNm = mkttchFeatureNm;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the cusName
	 */
	public String getCusName() {
		return cusName;
	}
	/**
	 * @param cusName the cusName to set
	 */
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}
	/**
	 * @param model the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the qty
	 */
	public String getQty() {
		return qty;
	}
	/**
	 * @param qty the qty to set
	 */
	public void setQty(String qty) {
		this.qty = qty;
	}
	/**
	 * @return the ruleType
	 */
	public String getRuleType() {
		return ruleType;
	}
	/**
	 * @param ruleType the ruleType to set
	 */
	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}
	/**
	 * @return the ruleExp
	 */
	public String getRuleExp() {
		return ruleExp;
	}
	/**
	 * @param ruleExp the ruleExp to set
	 */
	public void setRuleExp(String ruleExp) {
		this.ruleExp = ruleExp;
	}
	/**
	 * @return the partFamily
	 */
	public String getPartFamily() {
		return partFamily;
	}
	/**
	 * @param partFamily the partFamily to set
	 */
	public void setPartFamily(String partFamily) {
		this.partFamily = partFamily;
	}
	/**
	 * @return the featureUsg
	 */
	public String getFeatureUsg() {
		return featureUsg;
	}
	/**
	 * @param featureUsg the featureUsg to set
	 */
	public void setFeatureUsg(String featureUsg) {
		this.featureUsg = featureUsg;
	}

	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}

	/**
	 * @param source the source to set
	 */
	public void setSource(String source) {
		this.source = source;
	}

	/**
	 * @return the pin
	 */
	public String getPin() {
		return pin;
	}

	/**
	 * @param pin the pin to set
	 */
	public void setPin(String pin) {
		this.pin = pin;
	}

	/**
	 * @return the parentItem
	 */
	public String getParentItem() {
		return parentItem;
	}

	/**
	 * @param parentItem the parentItem to set
	 */
	public void setParentItem(String parentItem) {
		this.parentItem = parentItem;
	}

	/**
	 * @return the childItem
	 */
	public String getChildItem() {
		return childItem;
	}

	/**
	 * @param childItem the childItem to set
	 */
	public void setChildItem(String childItem) {
		this.childItem = childItem;
	}

	/**
	 * @return the authecn
	 */
	public String getAuthecn() {
		return authecn;
	}

	/**
	 * @param authecn the authecn to set
	 */
	public void setAuthecn(String authecn) {
		this.authecn = authecn;
	}

	/**
	 * @return the itemEffectivityStartDate
	 */
	public Date getItemEffectivityStartDate() {
		Date itemEfficientStrDt =itemEffectivityStartDate;
		return itemEfficientStrDt;
	}

	/**
	 * @param itemEffectivityStartDate the itemEffectivityStartDate to set
	 */
	public void setItemEffectivityStartDate(Date itemEffectivityStartDate) {
		Date itemEfficientStrDt =itemEffectivityStartDate;
		this.itemEffectivityStartDate = itemEfficientStrDt;
	}

	/**
	 * @return the level
	 */
	public int getLevel() {
		return level;
	}

	/**
	 * @param level the level to set
	 */
	public void setLevel(int level) {
		this.level = level;
	}
	
	/**
	 * @return the unitAssembleNumber
	 */
	public String getUnitAssembleNumber() {
		return unitAssembleNumber;
	}
	/**
	 * @param unitAssembleNumber the unitAssembleNumber to set
	 */
	public void setUnitAssembleNumber(String unitAssembleNumber) {
		this.unitAssembleNumber = unitAssembleNumber;
	}
	/**
	 * @return the partDwgVal
	 */
	public String getPartDwgVal() {
		return partDwgVal;
	}
	/**
	 * @param partDwgVal the partDwgVal to set
	 */
	public void setPartDwgVal(String partDwgVal) {
		this.partDwgVal = partDwgVal;
	}
	/**
	 * @return the descriptionVal
	 */
	public String getDescriptionVal() {
		return descriptionVal;
	}
	/**
	 * @param descriptionVal the descriptionVal to set
	 */
	public void setDescriptionVal(String descriptionVal) {
		this.descriptionVal = descriptionVal;
	}

	/**
	 * @return the itemEffectivityEndDate
	 */
	public Date getItemEffectivityEndDate() {
		Date itemEfficientEndDt =itemEffectivityEndDate;
		return itemEfficientEndDt;
	}

	/**
	 * @param itemEffectivityEndDate the itemEffectivityEndDate to set
	 */
	public void setItemEffectivityEndDate(Date itemEffectivityEndDate) {
		Date itemEfficientEndDt =itemEffectivityEndDate;
		this.itemEffectivityEndDate = itemEfficientEndDt;
	}

	/**
	 * @return the relatedName
	 */
	public String getRelatedName() {
		return relatedName;
	}

	/**
	 * @param relatedName the relatedName to set
	 */
	public void setRelatedName(String relatedName) {
		this.relatedName = relatedName;
	}

	/**
	 * @return the relatedItem
	 */
	public String getRelatedItem() {
		return relatedItem;
	}

	/**
	 * @param relatedItem the relatedItem to set
	 */
	public void setRelatedItem(String relatedItem) {
		this.relatedItem = relatedItem;
	}

	/**
	 * @return the relatedItemType
	 */
	public String getRelatedItemType() {
		return relatedItemType;
	}

	/**
	 * @param relatedItemType the relatedItemType to set
	 */
	public void setRelatedItemType(String relatedItemType) {
		this.relatedItemType = relatedItemType;
	}

	/**
	 * @return the parentItem1
	 */
	public String getParentItem1() {
		return parentItem1;
	}

	/**
	 * @param parentItem1 the parentItem1 to set
	 */
	public void setParentItem1(String parentItem1) {
		this.parentItem1 = parentItem1;
	}

	/**
	 * @return the imdtParentItem
	 */
	public String getImdtParentItem() {
		return imdtParentItem;
	}

	/**
	 * @param imdtParentItem the imdtParentItem to set
	 */
	public void setImdtParentItem(String imdtParentItem) {
		this.imdtParentItem = imdtParentItem;
	}

	/**
	 * @return the srlNum
	 */
	public String getSrlNum() {
		return srlNum;
	}

	/**
	 * @param srlNum the srlNum to set
	 */
	public void setSrlNum(String srlNum) {
		this.srlNum = srlNum;
	}

	/**
	 * @return the status1
	 */
	public String getStatus1() {
		return status1;
	}

	/**
	 * @param status1 the status1 to set
	 */
	public void setStatus1(String status1) {
		this.status1 = status1;
	}

	/**
	 * @return the eMbomDate
	 */
	public String geteMbomDate() {
		return eMbomDate;
	}

	/**
	 * @param eMbomDate the eMbomDate to set
	 */
	public void seteMbomDate(String eMbomDateLcl) {
		this.eMbomDate = eMbomDateLcl;
	}

	
	/**
	 * @return the turbnNUm
	 */
	public String getTurbnNUm() {
		return turbnNUm;
	}

	/**
	 * @param turbnNUm the turbnNUm to set
	 */
	public void setTurbnNUm(String turbnNUm) {
		this.turbnNUm = turbnNUm;
	}

	
	/**
	 * @return the newItem
	 */
	public String getNewItem() {
		return newItem;
	}

	/**
	 * @param newItem the newItem to set
	 */
	public void setNewItem(String newItem) {
		this.newItem = newItem;
	}

	/**
	 * @return the oldItem
	 */
	public String getOldItem() {
		return oldItem;
	}

	/**
	 * @param oldItem the oldItem to set
	 */
	public void setOldItem(String oldItem) {
		this.oldItem = oldItem;
	}

	



	/**
	 * @return the descript
	 */
	public String getDescript() {
		return descript;
	}

	/**
	 * @param descript the descript to set
	 */
	public void setDescript(String descript) {
		this.descript = descript;
	}

	/**
	 * @return the dtent
	 */
	public String getDtent() {
		return dtent;
	}

	/**
	 * @param dtent the dtent to set
	 */
	public void setDtent(String dtent) {
		this.dtent = dtent;
	}

	/**
	 * @return the qty1
	 */
	public String getQty1() {
		return qty1;
	}

	/**
	 * @param qty1 the qty1 to set
	 */
	public void setQty1(String qty1) {
		this.qty1 = qty1;
	}

	/**
	 * @return the topLvlParentId
	 */
	public String getTopLvlParentId() {
		return topLvlParentId;
	}

	/**
	 * @param topLvlParentId the topLvlParentId to set
	 */
	public void setTopLvlParentId(String topLvlParentId) {
		this.topLvlParentId = topLvlParentId;
	}

	/**
	 * @return the topLvlParentNm
	 */
	public String getTopLvlParentNm() {
		return topLvlParentNm;
	}

	/**
	 * @param topLvlParentNm the topLvlParentNm to set
	 */
	public void setTopLvlParentNm(String topLvlParentNm) {
		this.topLvlParentNm = topLvlParentNm;
	}

	/**
	 * @return the topLvlParentRev
	 */
	public String getTopLvlParentRev() {
		return topLvlParentRev;
	}

	/**
	 * @param topLvlParentRev the topLvlParentRev to set
	 */
	public void setTopLvlParentRev(String topLvlParentRev) {
		this.topLvlParentRev = topLvlParentRev;
	}

	/**
	 * @return the immediateParent
	 */
	public String getImmediateParent() {
		return immediateParent;
	}

	/**
	 * @param immediateParent the immediateParent to set
	 */
	public void setImmediateParent(String immediateParent) {
		this.immediateParent = immediateParent;
	}

	/**
	 * @return the immediateParentRev
	 */
	public String getImmediateParentRev() {
		return immediateParentRev;
	}

	/**
	 * @param immediateParentRev the immediateParentRev to set
	 */
	public void setImmediateParentRev(String immediateParentRev) {
		this.immediateParentRev = immediateParentRev;
	}

	/**
	 * @return the partId
	 */
	public String getPartId() {
		return partId;
	}

	/**
	 * @param partId the partId to set
	 */
	public void setPartId(String partId) {
		this.partId = partId;
	}

	/**
	 * @return the partNm
	 */
	public String getPartNm() {
		return partNm;
	}

	/**
	 * @param partNm the partNm to set
	 */
	public void setPartNm(String partNm) {
		this.partNm = partNm;
	}

	/**
	 * @return the partDesc
	 */
	public String getPartDesc() {
		return partDesc;
	}

	/**
	 * @param partDesc the partDesc to set
	 */
	public void setPartDesc(String partDesc) {
		this.partDesc = partDesc;
	}

	/**
	 * @return the lvl
	 */
	public String getLvl() {
		return lvl;
	}

	/**
	 * @param lvl the lvl to set
	 */
	public void setLvl(String lvl) {
		this.lvl = lvl;
	}

	/**
	 * @return the dfsOrdr
	 */
	public String getDfsOrdr() {
		return dfsOrdr;
	}

	/**
	 * @param dfsOrdr the dfsOrdr to set
	 */
	public void setDfsOrdr(String dfsOrdr) {
		this.dfsOrdr = dfsOrdr;
	}

	/**
	 * @return the srlNum1
	 */
	public String getSrlNum1() {
		return srlNum1;
	}

	/**
	 * @param srlNum1 the srlNum1 to set
	 */
	public void setSrlNum1(String srlNum1) {
		this.srlNum1 = srlNum1;
	}

	/**
	 * @return the mli
	 */
	public String getMli() {
		return mli;
	}

	/**
	 * @param mli the mli to set
	 */
	public void setMli(String mli) {
		this.mli = mli;
	}

	/**
	 * @return the authen
	 */
	public String getAuthen() {
		return authen;
	}

	/**
	 * @param authen the authen to set
	 */
	public void setAuthen(String authen) {
		this.authen = authen;
	}

	/**
	 * @return the orign
	 */
	public String getOrign() {
		return orign;
	}

	/**
	 * @param orign the orign to set
	 */
	public void setOrign(String orign) {
		this.orign = orign;
	}

	/**
	 * @return the immediateParentId
	 */
	public String getImmediateParentId() {
		return immediateParentId;
	}

	/**
	 * @param immediateParentId the immediateParentId to set
	 */
	public void setImmediateParentId(String immediateParentId) {
		this.immediateParentId = immediateParentId;
	}

	/**
	 * @return the contractId
	 */
	public String getContractId() {
		return contractId;
	}
	/**
	 * @param contractId the contractId to set
	 */
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	/**
	 * @return the hwPrdId
	 */
	public String getHwPrdId() {
		return hwPrdId;
	}
	/**
	 * @param hwPrdId the hwPrdId to set
	 */
	public void setHwPrdId(String hwPrdId) {
		this.hwPrdId = hwPrdId;
	}
	/**
	 * @return the ftrId
	 */
	public String getFtrId() {
		return ftrId;
	}
	/**
	 * @param ftrId the ftrId to set
	 */
	public void setFtrId(String ftrId) {
		this.ftrId = ftrId;
	}

	/**
	 * @return the selectedTypeExl
	 */
	public String getSelectedTypeExl() {
		return selectedTypeExl;
	}

	/**
	 * @param selectedTypeExl the selectedTypeExl to set
	 */
	public void setSelectedTypeExl(String selectedTypeExl) {
		this.selectedTypeExl = selectedTypeExl;
	}

	/**
	 * @return the dtentExl
	 */
	public Date getDtentExl() {
		Date temp = null;
		temp = dtentExl;
		return temp;
	}

	/**
	 * @param dtentExl the dtentExl to set
	 */
	public void setDtentExl(Date dtentExl) {
		Date temp = null;
		temp = dtentExl;
		this.dtentExl = temp;
	}

	/**
	 * @return the parentItemId
	 */
	public String getParentItemId() {
		return parentItemId;
	}

	/**
	 * @param parentItemId the parentItemId to set
	 */
	public void setParentItemId(String parentItemId) {
		this.parentItemId = parentItemId;
	}

	/**
	 * @return the childItemId
	 */
	public String getChildItemId() {
		return childItemId;
	}

	/**
	 * @param childItemId the childItemId to set
	 */
	public void setChildItemId(String childItemId) {
		this.childItemId = childItemId;
	}

	/**
	 * @return the topLvlParent
	 */
	public String getTopLvlParent() {
		return topLvlParent;
	}

	/**
	 * @param topLvlParent the topLvlParent to set
	 */
	public void setTopLvlParent(String topLvlParent) {
		this.topLvlParent = topLvlParent;
	}

	/**
	 * @return the topLvlParentDesc
	 */
	public String getTopLvlParentDesc() {
		return topLvlParentDesc;
	}

	/**
	 * @param topLvlParentDesc the topLvlParentDesc to set
	 */
	public void setTopLvlParentDesc(String topLvlParentDesc) {
		this.topLvlParentDesc = topLvlParentDesc;
	}

	/**
	 * @return the imdParent
	 */
	public String getImdParent() {
		return imdParent;
	}

	/**
	 * @param imdParent the imdParent to set
	 */
	public void setImdParent(String imdParent) {
		this.imdParent = imdParent;
	}

	/**
	 * @return the imdParentDesc
	 */
	public String getImdParentDesc() {
		return imdParentDesc;
	}

	/**
	 * @param imdParentDesc the imdParentDesc to set
	 */
	public void setImdParentDesc(String imdParentDesc) {
		this.imdParentDesc = imdParentDesc;
	}

	/**
	 * @return the partNum
	 */
	public String getPartNum() {
		return partNum;
	}

	/**
	 * @param partNum the partNum to set
	 */
	public void setPartNum(String partNum) {
		this.partNum = partNum;
	}

	/**
	 * @return the partUom
	 */
	public String getPartUom() {
		return partUom;
	}

	/**
	 * @param partUom the partUom to set
	 */
	public void setPartUom(String partUom) {
		this.partUom = partUom;
	}
	/**
	 * @return the partCount
	 */
	public int getPartCount() {
		return partCount;
	}

	/**
	 * @param partCount the partCount to set
	 */
	public void setPartCount(int partCount) {
		this.partCount = partCount;
	}

	/**
	 * @return the topPartCount
	 */
	public int getTopPartCount() {
		return topPartCount;
	}

	/**
	 * @param topPartCount the topPartCount to set
	 */
	public void setTopPartCount(int topPartCount) {
		this.topPartCount = topPartCount;
	}

	/**
	 * @return the optionval
	 */
	public String getOptionval() {
		return optionval;
	}

	/**
	 * @param optionval the optionval to set
	 */
	public void setOptionval(String optionval) {
		this.optionval = optionval;
	}

	/**
	 * @return the quantityval
	 */
	public String getQuantityval() {
		return quantityval;
	}

	/**
	 * @param quantityval the quantityval to set
	 */
	public void setQuantityval(String quantityval) {
		this.quantityval = quantityval;
	}

	/**
	 * @return the systemId
	 */
	public String getSystemId() {
		return systemId;
	}

	/**
	 * @param systemId the systemId to set
	 */
	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	/**
	 * @return the systemName
	 */
	public String getSystemName() {
		return systemName;
	}

	/**
	 * @param systemName the systemName to set
	 */
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}

	/**
	 * @return the className
	 */
	public String getClassName() {
		return className;
	}

	/**
	 * @param className the className to set
	 */
	public void setClassName(String className) {
		this.className = className;
	}

	/**
	 * @return the relType
	 */
	public String getRelType() {
		return relType;
	}

	/**
	 * @param relType the relType to set
	 */
	public void setRelType(String relType) {
		this.relType = relType;
	}

	/**
	 * @return the parentName
	 */
	public String getParentName() {
		return parentName;
	}

	/**
	 * @param parentName the parentName to set
	 */
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	/**
	 * @return the parentTextName
	 */
	public String getParentTextName() {
		return parentTextName;
	}

	/**
	 * @param parentTextName the parentTextName to set
	 */
	public void setParentTextName(String parentTextName) {
		this.parentTextName = parentTextName;
	}

	/**
	 * @return the childName
	 */
	public String getChildName() {
		return childName;
	}

	/**
	 * @param childName the childName to set
	 */
	public void setChildName(String childName) {
		this.childName = childName;
	}

	/**
	 * @return the childRev
	 */
	public String getChildRev() {
		return childRev;
	}

	/**
	 * @param childRev the childRev to set
	 */
	public void setChildRev(String childRev) {
		this.childRev = childRev;
	}

	/**
	 * @return the textName
	 */
	public String getTextName() {
		return textName;
	}

	/**
	 * @param textName the textName to set
	 */
	public void setTextName(String textName) {
		this.textName = textName;
	}

	/**
	 * @return the t4refPartNumber
	 */
	public String getT4refPartNumber() {
		return t4refPartNumber;
	}

	/**
	 * @param t4refPartNumber the t4refPartNumber to set
	 */
	public void setT4refPartNumber(String t4refPartNumber) {
		this.t4refPartNumber = t4refPartNumber;
	}

	/**
	 * @return the t4refPartRev
	 */
	public String getT4refPartRev() {
		return t4refPartRev;
	}

	/**
	 * @param t4refPartRev the t4refPartRev to set
	 */
	public void setT4refPartRev(String t4refPartRev) {
		this.t4refPartRev = t4refPartRev;
	}

	/**
	 * @return the bomLevel
	 */
	public String getBomLevel() {
		return bomLevel;
	}

	/**
	 * @param bomLevel the bomLevel to set
	 */
	public void setBomLevel(String bomLevel) {
		this.bomLevel = bomLevel;
	}
	
	
	
}