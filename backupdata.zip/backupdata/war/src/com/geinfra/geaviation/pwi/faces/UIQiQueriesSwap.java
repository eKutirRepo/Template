/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName UIQiQueriesSwap.java
 * @Creation date: 18-Aug-2014
 * @version 1.0
  * @author : Tech Mahindra
 */
package com.geinfra.geaviation.pwi.faces;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.component.UIComponentBase;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.model.SelectItem;

import org.ajax4jsf.renderkit.RendererUtils;

public class UIQiQueriesSwap extends UIComponentBase {

	@SuppressWarnings("unchecked")
	public Map<String, List<SelectItem>> getMapping() {
		ValueExpression ve = getValueExpression("mapping");
		if (ve != null) {
			try {
				return (Map<String, List<SelectItem>>) (ve
						.getValue(getFacesContext().getELContext()));
			} catch (ELException e) {
				throw new FacesException(e);
			}
		} else {
			return (null);
		}
	}

	@Override
	public String getFamily() {
		return "qiQueriesSwap";
	}

	public String getRendererType() {
		return "renderer";
	}

	public void encodeBegin(FacesContext context) throws IOException {
		ResponseWriter writer = context.getResponseWriter();

		writer.startElement("script", this);
		RendererUtils.getInstance().writeAttribute(writer, "type",
				"text/javascript");

		writer.write("\n//<![CDATA[\n");

		// Attach queries-by-object-type map to queries select list
		writer.write("jQuery(document).ready(function() {\n");
		writer.write("\t// Select query select list\n");
		writer
				.write("\tvar querySelectList = getQuerySelectList();\n\n");

		Map<String, List<SelectItem>> mapping = getMapping();
		/*
		 * commented the code for findbugs of nimble report 6-Nov-2014
		 * 
		 * Set<Entry<String, List<SelectItem>>> objTypeSet = mapping.entrySet();
		Iterator<Entry<String, List<SelectItem>>> it = objTypeSet.iterator();*/
		
		/*Using entrySet instead of keySet to improve performance 
		 * as keySet iterates twice on the map for every key 
		 * on 31-Oct-2014 as per Nimble report
		 */
		for(Entry<String, List<SelectItem>> entry : mapping.entrySet()){
			writer.write("\tvar " + entry.getKey() + "Data = [];\n");
			List<SelectItem> queries = mapping.get(entry.getKey());
			for (int index = 0; index < queries.size(); index++) {
				SelectItem item = queries.get(index);
				writer.write("\t" + entry.getKey() + "Data[" + index + "] = {\n");
				writer.write("\t\tvalue: " + item.getValue() + ",\n");
				writer.write("\t\tlabel: '" + item.getLabel() + "'\n");
				writer.write("\t}" + ";\n\n");
			}
			writer.write("\tquerySelectList.data('" + entry.getKey() + "ObjectType"
					+ "', " + entry.getKey() + "Data);\n\n");
		}
		
		/*Commented on 31-Oct-2014 as per Nimble report
		 * for (String objectType : mapping.keySet()) {
			writer.write("\tvar " + objectType + "Data = [];\n");
			List<SelectItem> queries = mapping.get(objectType);
			for (int index = 0; index < queries.size(); index++) {
				SelectItem item = queries.get(index);
				writer.write("\t" + objectType + "Data[" + index + "] = {\n");
				writer.write("\t\tvalue: " + item.getValue() + ",\n");
				writer.write("\t\tlabel: '" + item.getLabel() + "'\n");
				writer.write("\t}" + ";\n\n");
			}
			writer.write("\tquerySelectList.data('" + objectType + "ObjectType"
					+ "', " + objectType + "Data);\n\n");
		}*/
		writer.write("});\n\n");

		// Attach onchange event handler to the object type dropdown
		writer.write("jQuery(document).ready(function() {\n");
		writer.write("\t// Select query select list\n");
		writer
				.write("\tvar select = jQuery('select[id$=\"qiSearchPanelObjectType\"]');\n");
		writer.write("\tselect.change(function(eventObject) {\n");
		writer.write("\t\tloadQueriesForObjectType(select.val());\n");
		writer.write("\t});\n");
		writer.write("});\n\n");

		// Define function to get query select list
		writer.write("function getQuerySelectList() {\n");
		writer
				.write("\treturn jQuery('select[id$=\"qiSearchPanelQueries\"]');\n");
		writer.write("}\n\n");

		// Define function to load queries for specified object type
		writer.write("function loadQueriesForObjectType(objectType) {\n");
		writer.write("\t// Select query select list\n");
		writer.write("\tvar querySelectList = getQuerySelectList();\n\n");

		writer.write("\t// Remove all options from query select list\n");
		writer.write("\tquerySelectList.empty();\n\n");

		writer.write("\t// Select list of queries for object type\n");
		writer.write("\tvar key = objectType+'ObjectType'\n");
		writer
				.write("\tvar queries = querySelectList.data(key);\n\n");

		writer.write("\t// Add each query into the query select list\n");

		writer.write("\tfor (var i = 0; i < queries.length; i++) {\n");
		writer.write("\t\t// Create option for query\n");
		writer
				.write("\t\tvar queryOption = jQuery();\n");
		writer.write("\t\t// Add to query select list box\n");
		writer.write("\t\tgetQuerySelectList().append('<option value=\"' + queries[i].value + '\">' + queries[i].label + '</option>');\n");
		writer.write("\t}\n}\n");
		writer.write("//]]>\n");

		writer.endElement("script");
	}

	public void encodeEnd(FacesContext context) throws IOException {
		return;
	}

	public void decode(FacesContext context) {
		return;
	}
}
