/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMDrawingSearchData.java
 * @Creation date: 14-June-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PLMDrawingSearchData {
	/**
	 * The String task_owner
	 */
	private String task_owner;
	/**
	 * The String task_owner_ln
	 */
	private String task_owner_ln;
	/**
	 * The String task_owner_fn
	 */
	private String task_owner_fn;
	/**
	 * The String mngr_of_task_owner
	 */
	private String mngr_of_task_owner;
	/**
	 * The String rdo_ownership
	 */
	private String rdo_ownership;
	/**
	 * The String task_id_no
	 */
	private String task_id_no;
	/**
	 * The String task_start_date
	 */
	private String task_start_date;
	/**
	 * The String task_due_date
	 */
	private String task_due_date;
	/**
	 * The String dpo_number
	 */
	private String dpo_number;
	/**
	 * The String dpo_revision
	 */
	private String dpo_revision;
	/**
	 * The String dpo_owner
	 */
	private String dpo_owner;
	/**
	 * The String dpo_desc
	 */
	private String dpo_desc;
	/**
	 * The String dpo_lifecycle_state
	 */
	private String dpo_lifecycle_state;
	/**
	 * The String related_eco
	 */
	private String related_eco;
	/**
	 * The String assignee
	 */
	private String assignee;
	/**
	 * The String assigneeManager
	 */
	private String assigneeManager;
	/**
	 * Holds the rdoNamesList
	 */
	private List<String> rdoNamesList= new ArrayList<String>();
		/**
	 * Holds the itemTypeList
	 */
	private List<String> itemTypeList= new ArrayList<String>();
	/**
	 * Holds the approveStList
	 */
	private List<String> approveStList;
	//Newly added feilds for 4.6 Release
	/**
	 * Holds the taskName
	 */
	private String taskName;
	/**
	 * Holds the approvalStatus
	 */
	private String approvalStatus;
	/**
	 * Holds the routeTskCrtDt
	 */
	private String routeTskCrtDt;
	/**
	 * Holds the taskComments
	 */
	private String taskComments;
	/**
	 * Holds the taskOwner
	 */
	private String taskOwner;
	/**
	 * Holds the taskOwnerNm
	 */
	private String taskOwnerNm;
	/**
	 * Holds the taskAssign
	 */
	private String taskAssign;
	/**
	 * Holds the taskAssignNm
	 */
	private String taskAssignNm;
	/**
	 * Holds the taskAssignMngr
	 */
	private String taskAssignMngr;
	/**
	 * Holds the taskName
	 */
	private String taskAssignMngrNm;
	/**
	 * Holds the scheduleDt
	 */
	private String scheduleDt;
	/**
	 * Holds the completeDt
	 */
	private String completeDt;
	/**
	 * Holds the affectedId
	 */
	private String affectedId;
	/**
	 * Holds the affectedNm
	 */
	private String affectedNm;
	/**
	 * Holds the affectedType
	 */
	private String affectedType;
	/**
	 * Holds the affectedRev
	 */
	private String affectedRev;
	/**
	 * Holds the relDwgEco
	 */
	private String relDwgEco;
	/**
	 * Holds the ecoDesc
	 */
	private String ecoDesc;
	/**
	 * Holds the ecoLfCycleSt
	 */
	private String ecoLfCycleSt;
	/**
	 * Holds the rdo
	 */
	private String rdo;
	/**
	 * Holds the routeCrtFrmDt
	 */
	private Date routeCrtFrmDt;
	/**
	 * Holds the routeCrtToDt
	 */
	private Date routeCrtToDt;
	/**
	 * Holds the taskCompltFrmDt
	 */
	private Date taskCompltFrmDt;
	/**
	 * Holds the taskCompltTpDt
	 */
	private Date taskCompltToDt;
	/**
	 * Holds the checkIboxTsk
	 */
	private boolean checkIboxTsk;
	/**
	 * Holds the routeTskCrtDtExl
	 */
	private Date routeTskCrtDtExl;
	/**
	 * Holds the scheduleDtExl
	 */
	private Date scheduleDtExl;
	/**
	 * Holds the completeDtExl
	 */
	private Date completeDtExl;
	/**
	 * Holds the routeOwner
	 */
	private String routeOwner;
	
	/**
	 * Holds the routeOwnerName
	 */
	private String routeOwnerName;
	
	/**
	 * Holds the ecoRelDt
	 */
	private String ecoRelDt;
	
	private String relEcoPolicy;
	
	
	/**
	 * Holds the ecoRelDtExl
	 */
	private Date ecoRelDtExl;
	
	
	/**
	 * @return the task_owner
	 */
	public String getTask_owner() {
		return task_owner;
	}

	/**
	 * @param task_owner
	 *            the task_owner to set
	 */
	public void setTask_owner(String task_owner) {
		this.task_owner = task_owner;
	}

	/**
	 * @return the mngr_of_task_owner
	 */
	public String getMngr_of_task_owner() {
		return mngr_of_task_owner;
	}

	/**
	 * @param mngr_of_task_owner
	 *            the mngr_of_task_owner to set
	 */
	public void setMngr_of_task_owner(String mngr_of_task_owner) {
		this.mngr_of_task_owner = mngr_of_task_owner;
	}

	/**
	 * @return the rdo_ownership
	 */
	public String getRdo_ownership() {
		return rdo_ownership;
	}

	/**
	 * @param rdo_ownership
	 *            the rdo_ownership to set
	 */
	public void setRdo_ownership(String rdo_ownership) {
		this.rdo_ownership = rdo_ownership;
	}

	/**
	 * @return the task_id_no
	 */
	public String getTask_id_no() {
		return task_id_no;
	}

	/**
	 * @param task_id_no
	 *            the task_id_no to set
	 */
	public void setTask_id_no(String task_id_no) {
		this.task_id_no = task_id_no;
	}

	/**
	 * @return the task_start_date
	 */
	public String getTask_start_date() {
		return task_start_date;
	}

	/**
	 * @param task_start_date
	 *            the task_start_date to set
	 */
	public void setTask_start_date(String task_start_date) {
		this.task_start_date = task_start_date;
	}

	/**
	 * @return the task_due_date
	 */
	public String getTask_due_date() {
		return task_due_date;
	}

	/**
	 * @param task_due_date
	 *            the task_due_date to set
	 */
	public void setTask_due_date(String task_due_date) {
		this.task_due_date = task_due_date;
	}

	/**
	 * @return the dpo_number
	 */
	public String getDpo_number() {
		return dpo_number;
	}

	/**
	 * @param dpo_number
	 *            the dpo_number to set
	 */
	public void setDpo_number(String dpo_number) {
		this.dpo_number = dpo_number;
	}

	/**
	 * @return the dpo_revision
	 */
	public String getDpo_revision() {
		return dpo_revision;
	}

	/**
	 * @param dpo_revision
	 *            the dpo_revision to set
	 */
	public void setDpo_revision(String dpo_revision) {
		this.dpo_revision = dpo_revision;
	}

	/**
	 * @return the dpo_owner
	 */
	public String getDpo_owner() {
		return dpo_owner;
	}

	/**
	 * @param dpo_owner
	 *            the dpo_owner to set
	 */
	public void setDpo_owner(String dpo_owner) {
		this.dpo_owner = dpo_owner;
	}

	/**
	 * @return the dpo_desc
	 */
	public String getDpo_desc() {
		return dpo_desc;
	}

	/**
	 * @param dpo_desc
	 *            the dpo_desc to set
	 */
	public void setDpo_desc(String dpo_desc) {
		this.dpo_desc = dpo_desc;
	}

	/**
	 * @return the dpo_lifecycle_state
	 */
	public String getDpo_lifecycle_state() {
		return dpo_lifecycle_state;
	}

	/**
	 * @param dpo_lifecycle_state
	 *            the dpo_lifecycle_state to set
	 */
	public void setDpo_lifecycle_state(String dpo_lifecycle_state) {
		this.dpo_lifecycle_state = dpo_lifecycle_state;
	}

	/**
	 * @return the related_eco
	 */
	public String getRelated_eco() {
		return related_eco;
	}

	/**
	 * @param related_eco
	 *            the related_eco to set
	 */
	public void setRelated_eco(String related_eco) {
		this.related_eco = related_eco;
	}

	/**
	 * @return the task_owner_fn
	 */
	public String getTask_owner_fn() {
		return task_owner_fn;
	}

	/**
	 * @param task_owner_fn
	 *            the task_owner_fn to set
	 */
	public void setTask_owner_fn(String task_owner_fn) {
		this.task_owner_fn = task_owner_fn;
	}

	/**
	 * @return the task_owner_ln
	 */
	public String getTask_owner_ln() {
		return task_owner_ln;
	}

	/**
	 * @param task_owner_ln
	 *            the task_owner_ln to set
	 */
	public void setTask_owner_ln(String task_owner_ln) {
		this.task_owner_ln = task_owner_ln;
	}

	/**
	 * @return the assignee
	 */
	public String getAssignee() {
		return assignee;
	}

	/**
	 * @param assignee the assignee to set
	 */
	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

	/**
	 * @return the assigneeManager
	 */
	public String getAssigneeManager() {
		return assigneeManager;
	}

	/**
	 * @param assigneeManager the assigneeManager to set
	 */
	public void setAssigneeManager(String assigneeManager) {
		this.assigneeManager = assigneeManager;
	}
	/**
	 * @return the rdoNamesList
	 */
	public List<String> getRdoNamesList() {
		return rdoNamesList;
	}

	/**
	 * @param rdoNamesList the rdoNamesList to set
	 */
	public void setRdoNamesList(List<String> rdoNamesList) {
		this.rdoNamesList = rdoNamesList;
	}

	/**
	 * @return the itemTypeList
	 */
	public List<String> getItemTypeList() {
		return itemTypeList;
	}

	/**
	 * @param itemTypeList the itemTypeList to set
	 */
	public void setItemTypeList(List<String> itemTypeList) {
		this.itemTypeList = itemTypeList;
	}

	/**
	 * @return the approveStList
	 */
	public List<String> getApproveStList() {
		return approveStList;
	}

	/**
	 * @param approveStList the approveStList to set
	 */
	public void setApproveStList(List<String> approveStList) {
		this.approveStList = approveStList;
	}

	/**
	 * @return the taskName
	 */
	public String getTaskName() {
		return taskName;
	}

	/**
	 * @param taskName the taskName to set
	 */
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	/**
	 * @return the approvalStatus
	 */
	public String getApprovalStatus() {
		return approvalStatus;
	}

	/**
	 * @param approvalStatus the approvalStatus to set
	 */
	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	/**
	 * @return the routeTskCrtDt
	 */
	public String getRouteTskCrtDt() {
		return routeTskCrtDt;
	}

	/**
	 * @param routeTskCrtDt the routeTskCrtDt to set
	 */
	public void setRouteTskCrtDt(String routeTskCrtDt) {
		this.routeTskCrtDt = routeTskCrtDt;
	}

	/**
	 * @return the taskComments
	 */
	public String getTaskComments() {
		return taskComments;
	}

	/**
	 * @param taskComments the taskComments to set
	 */
	public void setTaskComments(String taskComments) {
		this.taskComments = taskComments;
	}

	/**
	 * @return the taskOwner
	 */
	public String getTaskOwner() {
		return taskOwner;
	}

	/**
	 * @param taskOwner the taskOwner to set
	 */
	public void setTaskOwner(String taskOwner) {
		this.taskOwner = taskOwner;
	}

	/**
	 * @return the taskOwnerNm
	 */
	public String getTaskOwnerNm() {
		return taskOwnerNm;
	}

	/**
	 * @param taskOwnerNm the taskOwnerNm to set
	 */
	public void setTaskOwnerNm(String taskOwnerNm) {
		this.taskOwnerNm = taskOwnerNm;
	}

	/**
	 * @return the taskAssign
	 */
	public String getTaskAssign() {
		return taskAssign;
	}

	/**
	 * @param taskAssign the taskAssign to set
	 */
	public void setTaskAssign(String taskAssign) {
		this.taskAssign = taskAssign;
	}

	/**
	 * @return the taskAssignNm
	 */
	public String getTaskAssignNm() {
		return taskAssignNm;
	}

	/**
	 * @param taskAssignNm the taskAssignNm to set
	 */
	public void setTaskAssignNm(String taskAssignNm) {
		this.taskAssignNm = taskAssignNm;
	}

	/**
	 * @return the taskAssignMngr
	 */
	public String getTaskAssignMngr() {
		return taskAssignMngr;
	}

	/**
	 * @param taskAssignMngr the taskAssignMngr to set
	 */
	public void setTaskAssignMngr(String taskAssignMngr) {
		this.taskAssignMngr = taskAssignMngr;
	}

	/**
	 * @return the taskAssignMngrNm
	 */
	public String getTaskAssignMngrNm() {
		return taskAssignMngrNm;
	}

	/**
	 * @param taskAssignMngrNm the taskAssignMngrNm to set
	 */
	public void setTaskAssignMngrNm(String taskAssignMngrNm) {
		this.taskAssignMngrNm = taskAssignMngrNm;
	}

	/**
	 * @return the scheduleDt
	 */
	public String getScheduleDt() {
		return scheduleDt;
	}

	/**
	 * @param scheduleDt the scheduleDt to set
	 */
	public void setScheduleDt(String scheduleDt) {
		this.scheduleDt = scheduleDt;
	}

	/**
	 * @return the completeDt
	 */
	public String getCompleteDt() {
		return completeDt;
	}

	/**
	 * @param completeDt the completeDt to set
	 */
	public void setCompleteDt(String completeDt) {
		this.completeDt = completeDt;
	}

	/**
	 * @return the affectedId
	 */
	public String getAffectedId() {
		return affectedId;
	}

	/**
	 * @param affectedId the affectedId to set
	 */
	public void setAffectedId(String affectedId) {
		this.affectedId = affectedId;
	}

	/**
	 * @return the affectedNm
	 */
	public String getAffectedNm() {
		return affectedNm;
	}

	/**
	 * @param affectedNm the affectedNm to set
	 */
	public void setAffectedNm(String affectedNm) {
		this.affectedNm = affectedNm;
	}

	/**
	 * @return the affectedType
	 */
	public String getAffectedType() {
		return affectedType;
	}

	/**
	 * @param affectedType the affectedType to set
	 */
	public void setAffectedType(String affectedType) {
		this.affectedType = affectedType;
	}

	/**
	 * @return the affectedRev
	 */
	public String getAffectedRev() {
		return affectedRev;
	}

	/**
	 * @param affectedRev the affectedRev to set
	 */
	public void setAffectedRev(String affectedRev) {
		this.affectedRev = affectedRev;
	}

	/**
	 * @return the relDwgEco
	 */
	public String getRelDwgEco() {
		return relDwgEco;
	}

	/**
	 * @param relDwgEco the relDwgEco to set
	 */
	public void setRelDwgEco(String relDwgEco) {
		this.relDwgEco = relDwgEco;
	}

	/**
	 * @return the ecoDesc
	 */
	public String getEcoDesc() {
		return ecoDesc;
	}

	/**
	 * @param ecoDesc the ecoDesc to set
	 */
	public void setEcoDesc(String ecoDesc) {
		this.ecoDesc = ecoDesc;
	}

	/**
	 * @return the ecoLfCycleSt
	 */
	public String getEcoLfCycleSt() {
		return ecoLfCycleSt;
	}

	/**
	 * @param ecoLfCycleSt the ecoLfCycleSt to set
	 */
	public void setEcoLfCycleSt(String ecoLfCycleSt) {
		this.ecoLfCycleSt = ecoLfCycleSt;
	}

	/**
	 * @return the rdo
	 */
	public String getRdo() {
		return rdo;
	}

	/**
	 * @param rdo the rdo to set
	 */
	public void setRdo(String rdo) {
		this.rdo = rdo;
	}

	/**
	 * @return the routeCrtFrmDt
	 */
	public Date getRouteCrtFrmDt() {
		Date temp = null;
		temp = routeCrtFrmDt;
		return temp;
	}

	/**
	 * @param routeCrtFrmDt the routeCrtFrmDt to set
	 */
	public void setRouteCrtFrmDt(Date routeCrtFrmDt) {
		if(routeCrtFrmDt!=null){
			 this.routeCrtFrmDt = (Date)routeCrtFrmDt.clone();
		}else{
			 this.routeCrtFrmDt =null;
		}
	}

	/**
	 * @return the routeCrtToDt
	 */
	public Date getRouteCrtToDt() {
		Date temp = null;
		temp = routeCrtToDt;
		return temp;
	}

	/**
	 * @param routeCrtToDt the routeCrtToDt to set
	 */
	public void setRouteCrtToDt(Date routeCrtToDt) {
		if(routeCrtToDt!=null){
			 this.routeCrtToDt = (Date)routeCrtToDt.clone();
		}else{
			 this.routeCrtToDt =null;
		}
	}

	/**
	 * @return the taskCompltFrmDt
	 */
	public Date getTaskCompltFrmDt() {
		Date temp = null;
		temp = taskCompltFrmDt;
		return temp;
	}

	/**
	 * @param taskCompltFrmDt the taskCompltFrmDt to set
	 */
	public void setTaskCompltFrmDt(Date taskCompltFrmDt) {
		if(taskCompltFrmDt!=null){
			 this.taskCompltFrmDt = (Date)taskCompltFrmDt.clone();
		}else{
			 this.taskCompltFrmDt =null;
		}
	}

	/**
	 * @return the taskCompltToDt
	 */
	public Date getTaskCompltToDt() {
		Date temp = null;
		temp = taskCompltToDt;
		return temp;
	}

	/**
	 * @param taskCompltToDt the taskCompltToDt to set
	 */
	public void setTaskCompltToDt(Date taskCompltToDt) {
		if(taskCompltToDt!=null){
			 this.taskCompltToDt = (Date)taskCompltToDt.clone();
		}else{
			 this.taskCompltToDt =null;
		}
	}

	/**
	 * @return the checkIboxTsk
	 */
	public boolean isCheckIboxTsk() {
		return checkIboxTsk;
	}

	/**
	 * @param checkIboxTsk the checkIboxTsk to set
	 */
	public void setCheckIboxTsk(boolean checkIboxTsk) {
		this.checkIboxTsk = checkIboxTsk;
	}

	/**
	 * @return the routeTskCrtDtExl
	 */
	public Date getRouteTskCrtDtExl() {
		Date temp = null;
		temp = routeTskCrtDtExl;
		return temp;
	}

	/**
	 * @param routeTskCrtDtExl the routeTskCrtDtExl to set
	 */
	public void setRouteTskCrtDtExl(Date routeTskCrtDtExl) {
		Date temp = null;
		temp = routeTskCrtDtExl;
		this.routeTskCrtDtExl = temp;
	}

	/**
	 * @return the scheduleDtExl
	 */
	public Date getScheduleDtExl() {
		Date temp = null;
		temp = scheduleDtExl;
		return temp;
	}

	/**
	 * @param scheduleDtExl the scheduleDtExl to set
	 */
	public void setScheduleDtExl(Date scheduleDtExl) {
		Date temp = null;
		temp = scheduleDtExl;
		this.scheduleDtExl = temp;
	}

	/**
	 * @return the completeDtExl
	 */
	public Date getCompleteDtExl() {
		Date temp = null;
		temp = completeDtExl;
		return temp;
	}

	/**
	 * @param completeDtExl the completeDtExl to set
	 */
	public void setCompleteDtExl(Date completeDtExl) {
		Date temp = null;
		temp = completeDtExl;
		this.completeDtExl = temp;
	}

	/**
	 * @return the routeOwner
	 */
	public String getRouteOwner() {
		return routeOwner;
	}

	/**
	 * @param routeOwner the routeOwner to set
	 */
	public void setRouteOwner(String routeOwner) {
		this.routeOwner = routeOwner;
	}

	/**
	 * @return the routeOwnerName
	 */
	public String getRouteOwnerName() {
		return routeOwnerName;
	}

	/**
	 * @param routeOwnerName the routeOwnerName to set
	 */
	public void setRouteOwnerName(String routeOwnerName) {
		this.routeOwnerName = routeOwnerName;
	}

	/**
	 * @return the ecoRelDt
	 */
	public String getEcoRelDt() {
		return ecoRelDt;
	}

	/**
	 * @param ecoRelDt the ecoRelDt to set
	 */
	public void setEcoRelDt(String ecoRelDt) {
		this.ecoRelDt = ecoRelDt;
	}

	/**
	 * @return the ecoRelDtExl
	 */
	public Date getEcoRelDtExl() {
		Date temp = null;
		temp = ecoRelDtExl;
		return temp;
	}

	/**
	 * @param ecoRelDtExl the ecoRelDtExl to set
	 */
	public void setEcoRelDtExl(Date ecoRelDtExl) {
		Date temp = null;
		temp = ecoRelDtExl;
		this.ecoRelDtExl = temp;
	}

	
	/**
	 * @return the relEcoPolicy
	 */
	public String getRelEcoPolicy() {
		return relEcoPolicy;
	}

	
	/**
	 * @param relEcoPolicy the relEcoPolicy to set
	 */
	public void setRelEcoPolicy(String relEcoPolicy) {
		this.relEcoPolicy = relEcoPolicy;
	}

	
}