package com.geinfra.geaviation.pwi.cleanupuserfiles;

import java.io.File;
import java.util.Date;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.common.MainExecution;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.PWiQueryExctnEventVO;
import com.geinfra.geaviation.pwi.service.QuerySubmissionService;
import com.geinfra.geaviation.pwi.util.FilePathUtil;
import com.geinfra.geaviation.pwi.util.FileUtil;

/**
 * 
 * Project : Product Lifecycle Management
 * Date Written : 2012 Oct 16
 * Security : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : CleanupJob - Cleans up query result files
 * 
 * Revision Log 2012.10.16 |  pH | v1.0.
 * --------------------------------------------------------------
 */
public class CleanupJob {
	private static final Logger LOGGER = Logger
			.getLogger(CleanupJob.class);
	
	// dates 
	private static final long TWO_DAYS = 86400000L; // two days in milliseconds
	private static final long TODAY_MS = System.currentTimeMillis();
	private static final Date TODAY = new Date();
	
	// messages
	private static final String OLD = " is older than 2 days, removing file...";
	private static final String EXPIRED = " has expired, removing file...";
	private static final String EMPTY = " is empty, removing directory...";

	// Injected
	private QuerySubmissionService querySubmissionService;

	public void setQuerySubmissionService(
			QuerySubmissionService querySubmissionService) {
		this.querySubmissionService = querySubmissionService;
	}

	public void cleanupFiles(MainExecution mainExecution) {
		// Get root directory
		String appDataMountPath = mainExecution.getAppDataPath();

		// Clean up temporary files for online results (older than two days):
		// Get list of files
		File onlineDir = new File(FilePathUtil.getInstance()
				.onlineModePath(appDataMountPath));
		// For each file, if it is older than two days, delete it
		if (onlineDir!=null) {
			File[] fileDir = onlineDir.listFiles();
			if (fileDir!=null) {
				for (File file : fileDir) {
					if ((file.lastModified() + TWO_DAYS) < TODAY_MS) {
						deleteFile(file, OLD);
					}
				}
			}
		}
		//
		// Clean up each user's expired batch and subscription results
		cleanupDir(new File(FilePathUtil.getInstance()
				.usersPath(appDataMountPath)));
	}
	
	/**
	 * Cleans up subdirectories and files in a directory containing batch and
	 * subscription results.  Cleans files based on their expiration dates;
	 * then, if the directory is empty, removes the directory.
	 * 
	 * @param dir the directory to be cleaned
	 */
	private void cleanupDir(File dir) {
		if (dir!=null) {
			LOGGER.debug("Cleaning up directory: " + dir.getPath());
			// clean children (files and directories)
			File[] dirFiles = dir.listFiles();
			if (dirFiles!=null && dirFiles.length !=0)  {
				for (File child : dirFiles) {
					if (child.isDirectory()) {
						cleanupDir(child);
					} else {
						cleanupFile(child);
					}
				} // end for each child
			}
			// if it is now empty, remove it
			String[] dirLst = dir.list();
			
			if (dirLst!=null && dirLst.length <= 0 ) {
				deleteFile(dir, EMPTY);
			}
		}
	} // end cleanupDir
	
	/**
	 * Cleans up a file based on its expiration date.  If there is no expiration
	 * date, creates one.
	 * (filename format <undefined>-<extn-evnt-id>.<extn>
	 * 
	 * @param file the file to be checked for expiration
	 */
	private void cleanupFile(File file) {
		LOGGER.debug("Cleaning up file: " + file.getPath());
		// getVO(eventID)
		PWiQueryExctnEventVO PWivo;
		try {
			PWivo = querySubmissionService.getExecutionEventById(
					FileUtil.getInstance().parseEventIdFromQueryResultFileName(
							file.getName()));
		} catch(NumberFormatException e) {
			// same behavior for an invalid number ("abc") as for an invalid
			// execution event id (no execution event exists with given ID)
			PWivo = null;
		} // end try
		
		if (PWivo != null) {
			if (PWivo.getExpirationDate() != null) {
				if (PWivo.getExpirationDate().before(TODAY)) {
					deleteFile(file, EXPIRED);
				} else if(LOGGER.isDebugEnabled()) {
					LOGGER.debug((new StringBuilder(file.getPath()))
							.append(" expires on ")
							.append(PWivo.getExpirationDate().toString())
							.toString());
				} // end if expired
			} else {
				// if there is no date, create one
				querySubmissionService.renewFile(PWivo.getEventId());
			} // end if
		} else {
			// if there is no VO, delete the file based on its modified date
			if ((file.lastModified() + TWO_DAYS) < TODAY_MS) {
				deleteFile(file, OLD);
			} // end if older than two days
		} // end if
	} // end cleanupFile
	
	/**
	 * Deletes the file specified, logs the deletion, and catches any error
	 * 
	 * @param file the file to be deleted
	 * @param message the message to be logged
	 */
	private void deleteFile(File file, String message) {
		LOGGER.info((new StringBuilder(file.getPath())) 
				.append(message).toString());
		try {
			FileUtil.getInstance().deleteFile(file);
		} catch (PWiException e) {
			LOGGER.error((new StringBuilder("Unable to delete "))
					.append(file.getName()).toString(), e);
		}
	}
}
