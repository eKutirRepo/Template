 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMTaskMetricsMB.java
 * @Creation date: 18-June-2010
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team) 
 */

package com.geinfra.geaviation.pwi.bean;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.data.PLMTaskMetricsData;
import com.geinfra.geaviation.pwi.service.PLMTaskMetricsServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

public class PLMTaskMetricsMB {
	/**
	 * Holds the Logger object to the messages.
	 */
	private static Logger LOG = Logger.getLogger(PLMTaskMetricsMB.class);
	/**
	 * Holds the taskVolumeList
	 */
	private List<PLMTaskMetricsData> taskVolumeList = new ArrayList<PLMTaskMetricsData>();
	/**
	 * Holds the taskVolumeListCsv
	 */
	private List<PLMTaskMetricsData> taskVolumeListCsv;
	/**
	 * Holds the tasknameslist
	 */
	private List<String> tasknameslist;
	/**
	 * Holds the taskMetricData
	 */
	private PLMTaskMetricsData taskMetricData = new PLMTaskMetricsData();
	/**
	 * Holds the taskMetricsService
	 */
	private PLMTaskMetricsServiceIfc taskMetricsService = null;
	/**
	 * Holds the plmTaskSearchMB
	 */
	private PLMTaskSearchMB plmTaskSearchMB = new PLMTaskSearchMB();
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB=null;
	
	/**
	 * This method gets the Task Volume Report.
	 * @return String
	 * @throws PLMCommonException
	 */
	public String loadTaskVolumeReport() {
		LOG.info("Entering loadTaskVolumeReport of MB");
		try {
			commonMB.insertCannedRptRecordHitInfo("Task Volume");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		String fwdflag = "";
		try{
		taskVolumeList = taskMetricsService.loadTaskVolumeReport(taskMetricData,taskVolumeList);
		if (!PLMUtils.isEmptyList(taskVolumeList)) {
			fwdflag = "taskVolumeReport";
		}
		else
		{
			fwdflag = "invalidTaskVolumeReport";
		}
		}catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadTaskVolumeReport: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Task Volume");
		} 
		
		try {
			commonMB.getPLMDateStamp(PLMConstants.TASK_TABLE);
		 } catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPLMDateStamp: ", exception);
		 } 
		LOG.info("Exiting loadTaskVolumeReport of MB");
		return fwdflag;
	}
	
	/**
	 * This method expands VP
	 * 
	 * @throws PLMCommonException
	 */
	public void taskVolumeExpandVP() throws PLMCommonException {
		LOG.info("Entering taskVolumeExpandVP of MB");
		try {
			taskVolumeList = taskMetricsService.taskVolumeExpandVP(taskMetricData,taskVolumeList);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@taskVolumeExpandVP: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"taskVolumeReport","Task Volume");
				throw exception;
			}
		LOG.info("Exiting taskVolumeExpandVP of MB");	
	}	
	/**
	 * This method expands GM
	 * 
	 * @throws PLMCommonException
	 */
	public void taskVolumeExpandGM() throws PLMCommonException {
		LOG.info("Entering taskVolumeExpandGM of MB");
		try {
			taskVolumeList = taskMetricsService.taskVolumeExpandGM(taskMetricData,taskVolumeList);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@taskVolumeExpandGM: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"taskVolumeReport","Task Volume");
				throw exception;
			}
		LOG.info("Exiting taskVolumeExpandGM of MB");	
	}
	/**
	 * This method expands FM
	 * 
	 * @throws PLMCommonException
	 */
	public void taskVolumeExpandFM() throws PLMCommonException {
		LOG.info("Entering taskVolumeExpandFM of MB");
		try {
			taskVolumeList = taskMetricsService.taskVolumeExpandFM(taskMetricData,taskVolumeList);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@taskVolumeExpandFM: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"taskVolumeReport","Task Volume");
				throw exception;
			}
		LOG.info("Exiting taskVolumeExpandFM of MB");
	}
	/**
	 * This method expands Manager4
	 * 
	 * @throws PLMCommonException 
	 */
	public void taskVolumeExpandMgr4() throws PLMCommonException {
		LOG.info("Entering taskVolumeExpandMgr4 of MB");
		try {
			taskVolumeList = taskMetricsService.taskVolumeExpandMgr4(taskMetricData,taskVolumeList);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@taskVolumeExpandMgr4: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"taskVolumeReport","Task Volume");
				throw exception;
			}
		LOG.info("Exiting taskVolumeExpandMgr4 of MB");
	}
	/**
	 * This method expands Manager3
	 * 
	 * @throws PLMCommonException 	 
	 */	
	public void taskVolumeExpandMgr3() throws PLMCommonException {
		LOG.info("Entering taskVolumeExpandMgr3 of MB");
		try {
			taskVolumeList = taskMetricsService.taskVolumeExpandMgr3(taskMetricData,taskVolumeList);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@taskVolumeExpandMgr3: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"taskVolumeReport","Task Volume");
				throw exception;
			}
		LOG.info("Exiting taskVolumeExpandMgr3 of MB");	
	}
	/**
	 * This method expands Manager2
	 * 
	 * @throws PLMCommonException 	
	 */	
	public void taskVolumeExpandMgr2() throws PLMCommonException {
		LOG.info("Entering taskVolumeExpandMgr2 of MB");
		try {
			taskVolumeList = taskMetricsService.taskVolumeExpandMgr2(taskMetricData,taskVolumeList);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@taskVolumeExpandMgr2: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"taskVolumeReport","Task Volume");
				throw exception;
			}
		LOG.info("Exiting taskVolumeExpandMgr2 of MB");	
	}
	/**
	 * This method expands Manager1
	 * 
	 * @throws PLMCommonException 	
	 */
	public void taskVolumeExpandMgr1() throws PLMCommonException {
		LOG.info("Entering taskVolumeExpandMgr1 of MB");
		try {
			taskVolumeList = taskMetricsService.taskVolumeExpandMgr1(taskMetricData,taskVolumeList);
			}catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@taskVolumeExpandMgr1: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"taskVolumeReport","Task Volume");
				throw exception;
			}
		LOG.info("Exiting taskVolumeExpandMgr1 of MB");	
	}
	/**
	 * This method gets Task Volume Detail Report.
	 * @return String
	 * @throws PLMCommonException 	
	 */
	public String loadTaskVolumeDetailReport() throws PLMCommonException {
		LOG.info("Entering loadTaskVolumeDetailReport of MB");
		String fwdflag ="";
		try {
			tasknameslist = taskMetricsService.loadTaskVolumeDetailReport(taskMetricData);
			if(!PLMUtils.isEmptyList(tasknameslist))
			{
				LOG.info("Size of List " + tasknameslist.size());
				fwdflag = plmTaskSearchMB.getTaskVolumeDetailReport(tasknameslist,taskMetricData);
			}
			else
			{
				fwdflag = "taskInvalidSearch";
			}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@loadTaskVolumeDetailReport: ", exception);
				fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"taskVolumeReport","Task Volume");
			}
			plmTaskSearchMB.setPage("taskvolume");
			LOG.info("Exiting loadTaskVolumeDetailReport of MB");
			return fwdflag;
		}
		
	/**
	 * This method exports the Task Volume Report to CSV.
	 * @return String
	 */
	public void loadTaskVolume()
	{
		LOG.info("Entering loadTaskVolume of MB");
		taskVolumeListCsv= new ArrayList<PLMTaskMetricsData>() ;
		
			if(!PLMUtils.isEmptyList(taskVolumeList))
			{
				for (int vpindex = 0; vpindex < taskVolumeList.size();vpindex++)
				{
					PLMTaskMetricsData tempdata =  taskVolumeList.get(vpindex);
					taskVolumeListCsv.add(tempdata);
					if(taskVolumeList.get(vpindex).isCollapse())
					{
						List<PLMTaskMetricsData> gmlist = taskVolumeList.get(vpindex).getGmTable();
							if(!PLMUtils.isEmptyList(gmlist))
							{
								for (int gmindex = 0; gmindex < gmlist.size();gmindex++)
								{
									tempdata =  gmlist.get(gmindex);
									taskVolumeListCsv.add(tempdata);
									if(tempdata.isCollapse())
									{
										List<PLMTaskMetricsData> fmlist = gmlist.get(gmindex).getFmTable();
											if(!PLMUtils.isEmptyList(fmlist))
											{
												for (int fmindex = 0; fmindex < fmlist.size();fmindex++)
												{
													tempdata =  fmlist.get(fmindex);
													taskVolumeListCsv.add(tempdata);
														if(tempdata.isCollapse())
														{
															List<PLMTaskMetricsData> mgr4list = fmlist.get(fmindex).getMgr4table();
															if(!PLMUtils.isEmptyList(mgr4list))
															{
																for (int mgr4index = 0; mgr4index < mgr4list.size();mgr4index++)
																{
																	tempdata =  mgr4list.get(mgr4index);
																	taskVolumeListCsv.add(tempdata);
																	  if(tempdata.isCollapse())
																		{
																		  List<PLMTaskMetricsData> mgr3list = mgr4list.get(mgr4index).getMgr3table();
																		if(!PLMUtils.isEmptyList(mgr3list))
																		{
																			for (int mgr3index = 0; mgr3index < mgr3list.size();mgr3index++)
																			{
																				tempdata =  mgr3list.get(mgr3index);
																				taskVolumeListCsv.add(tempdata);
																					if(tempdata.isCollapse())
																					{
																						List<PLMTaskMetricsData> mgr2list = mgr3list.get(mgr3index).getMgr2table();
																						if(!PLMUtils.isEmptyList(mgr2list))
																						   {
																							for (int mgr2index = 0; mgr2index < mgr2list.size();mgr2index++)
																								{
																									tempdata =  mgr2list.get(mgr2index);
																									taskVolumeListCsv.add(tempdata);
																									if(tempdata.isCollapse())
																									{
																										List<PLMTaskMetricsData> mgr1list = mgr2list.get(mgr2index).getMgr1table();
																									if(!PLMUtils.isEmptyList(mgr1list))
																									   {
																										for (int mgr1index = 0; mgr1index < mgr1list.size();mgr1index++)
																											{
																											tempdata =  mgr1list.get(mgr1index);
																											taskVolumeListCsv.add(tempdata);
																											if(tempdata.isCollapse())
																											   {
																												List<PLMTaskMetricsData> ownerlist = mgr1list.get(mgr1index).getOwnertable();
																												if(!PLMUtils.isEmptyList(ownerlist))
																												   {
																													for (int ownerindex = 0; ownerindex < ownerlist.size();ownerindex++)
																														{
																														tempdata =  ownerlist.get(ownerindex);
																														taskVolumeListCsv.add(tempdata);
																														}
																												   }
																											   }
																											}
																									   }
																									}
																								}
																						   }
																					}
																				}
																			}
																		}
																	}
															}
														}
												}
											}
										}
								}
							}
						}
				}
			}
		LOG.info("Exiting loadTaskVolume of MB");
	}
	
	/**
	 * This method is used to download excel
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	
	public void downloadTVExcel() throws PLMCommonException {
		
		LOG.info("Entering downloadTVExcel Method");
		String reportName="taskvolumereportDoc";
		String fileName="taskvolumereport";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("name", "Name", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("backLogs", "Task Backlog", FormatType.INTEGER, null, null, 11),
                    new PLMXlsxRptColumn("dueWeek", "Task Due Week", FormatType.INTEGER, null, null, 15),
                    new PLMXlsxRptColumn("dueMonth", "Task Due Month", FormatType.INTEGER, null, null, 16),
                    new PLMXlsxRptColumn("dueYear", "Task Due Year", FormatType.INTEGER, null, null, 14)
			};

		PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] {};

		excelUtil.export(taskVolumeListCsv, reportColumns, fileName, fileName, true, critcolumns, taskMetricData);
		
	}
	
	/**
	 * This method is used for Generating Report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadTVCSV() throws PLMCommonException {
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
				new PLMCsvRptColumn("name", "Name", FormatTypeCsv.TEXT, null, null, 20),
                new PLMCsvRptColumn("backLogs", "Task Backlog", FormatTypeCsv.INTEGER, null, null, 11),
                new PLMCsvRptColumn("dueWeek", "Task Due Week", FormatTypeCsv.INTEGER, null, null, 15),
                new PLMCsvRptColumn("dueMonth", "Task Due Month", FormatTypeCsv.INTEGER, null, null, 16),
                new PLMCsvRptColumn("dueYear", "Task Due Year", FormatTypeCsv.INTEGER, null, null, 14)
		};

		csvUtil.exportCsv(taskVolumeListCsv, reportColumns, "taskvolumereport", dateFormat, false, null, null, ",");
		
	}
	
	/**
	 * This method is used for Downloading TV Report in Excel
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadTVExcelInit() throws PLMCommonException {
		
		loadTaskVolume();
		downloadTVExcel();
		
	}
	
	/**
	 * This method is used for Downloading TV Report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadTVCSVInit() throws PLMCommonException {
		
		loadTaskVolume();
		downloadTVCSV();
		
	}
	
	/**
	 * @return the taskMetricsService
	 */
	public PLMTaskMetricsServiceIfc getTaskMetricsService() {
		return taskMetricsService;
	}

	/**
	 * @param taskMetricsService the taskMetricsService to set
	 */
	public void setTaskMetricsService(PLMTaskMetricsServiceIfc taskMetricsService) {
		this.taskMetricsService = taskMetricsService;
	}

	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}

	/**
	 * @param log the lOG to set
	 */
	public static void setLOG(Logger log) {
		LOG = log;
	}

	/**
	 * @return the taskVolumeList
	 */
	public List<PLMTaskMetricsData> getTaskVolumeList() {
		return taskVolumeList;
	}

	/**
	 * @param taskVolumeList the taskVolumeList to set
	 */
	public void setTaskVolumeList(List<PLMTaskMetricsData> taskVolumeList) {
		this.taskVolumeList = taskVolumeList;
	}

	/**
	 * @return the taskMetricData
	 */
	public PLMTaskMetricsData getTaskMetricData() {
		return taskMetricData;
	}

	/**
	 * @param taskMetricData the taskMetricData to set
	 */
	public void setTaskMetricData(PLMTaskMetricsData taskMetricData) {
		this.taskMetricData = taskMetricData;
	}

	/**
	 * @return the taskVolumeListCsv
	 */
	public List<PLMTaskMetricsData> getTaskVolumeListCsv() {
		return taskVolumeListCsv;
	}

	/**
	 * @param taskVolumeListCsv the taskVolumeListCsv to set
	 */
	public void setTaskVolumeListCsv(List<PLMTaskMetricsData> taskVolumeListCsv) {
		this.taskVolumeListCsv = taskVolumeListCsv;
	}

	/**
	 * @return the tasknameslist
	 */
	public List<String> getTasknameslist() {
		return tasknameslist;
	}

	/**
	 * @param tasknameslist the tasknameslist to set
	 */
	public void setTasknameslist(List<String> tasknameslist) {
		this.tasknameslist = tasknameslist;
	}

	/**
	 * @return the plmTaskSearchMB
	 */
	public PLMTaskSearchMB getPlmTaskSearchMB() {
		return plmTaskSearchMB;
	}

	/**
	 * @param plmTaskSearchMB the plmTaskSearchMB to set
	 */
	public void setPlmTaskSearchMB(PLMTaskSearchMB plmTaskSearchMB) {
		this.plmTaskSearchMB = plmTaskSearchMB;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
}