package com.geinfra.geaviation.pwi.bean;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.richfaces.component.html.HtmlDataTable;
import org.richfaces.event.UploadEvent;
import org.richfaces.model.UploadItem;
import org.springframework.util.FileCopyUtils;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.PWiObjectTypeVO;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.model.PWiQueryNoXmlVO;
import com.geinfra.geaviation.pwi.model.PWiQueryObjectVO;
import com.geinfra.geaviation.pwi.model.PWiQueryVO;
import com.geinfra.geaviation.pwi.model.PWiUserVO;
import com.geinfra.geaviation.pwi.model.QueriesVO;
import com.geinfra.geaviation.pwi.model.TemplateVO;
import com.geinfra.geaviation.pwi.service.ObjectTypeService;
import com.geinfra.geaviation.pwi.service.QueriesService;
import com.geinfra.geaviation.pwi.service.QueryGroupService;
import com.geinfra.geaviation.pwi.service.TemplateService;
import com.geinfra.geaviation.pwi.service.UserService;
import com.geinfra.geaviation.pwi.util.PWiConstants;

/**
 * 
 * Project : Product Lifecycle Management Intelligence Date Written : May 21,
 * 2010 Security : GE Confidential Restrictions : GE PROPRIETARY INFORMATION,
 * FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Backing managed bean for the admin page to create/edit queries.
 * 
 * Revision Log May 8, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class AdminQueryEditorBean extends BaseBean {
	// Dependency-injected services
	private QueriesService queriesService;
	private QueryGroupService queryGroupService;
	private TemplateService templateService;
	private ObjectTypeService objectTypeService;

	private Integer queryId;
	private String queryName;
	private String queryXML;
	private String qryKeyWrdTxt;
	private String allQueryGroups;
	private List<PWiQueryGroupVO> selectedQueryGroupsList;
	private List<PWiQueryGroupVO> availableQueryGroupList;
	private List<PWiQueryGroupVO> originalSelectedGroups;
	private List<PWiUserVO> originalUserGroupListFrQuery;
	private String createButtonValue;
	private String editButtonValue;
	private String queryDesc;
	//private List<SelectItem> PWiObjectTypes;
	private List<SelectItem> pwiObjectTypes;
	private List<Integer> slctdObjTyps = new ArrayList<Integer>();
	private List<Integer> originalSelObjs;
	private boolean exportControlled;
	private boolean geOnly;
	private boolean popular;
	private boolean active;
	private boolean userFlag =false;
	private List<PWiUserVO> usersFromSelectedGroup = new ArrayList<PWiUserVO>();
	private UserService userService;
	private String usersfromselectedgroups;
	private String selectedItemsValue;

	private Map<Integer, TemplateBean> templates = new HashMap<Integer, TemplateBean>();

	private int maxFilesQuantity;

	// Editable template properties
	private Integer editedTemplateViewId;
	private String editedTemplateName;
	private boolean editedTemplateEnabled;
	private UploadItem uploadItem;

	private int nextTemplateViewId;
	private HtmlDataTable userListTable = new HtmlDataTable();
	private List<PWiUserVO> userVOList;
	private List<String> selectedUserList;
	private List<String> availableGroups= new ArrayList<String>();
	private List<String> selectedGroups= new ArrayList<String>();
	private List<SelectItem> selectedList = new ArrayList<SelectItem>();
	private List<SelectItem> availableList = new ArrayList<SelectItem>();
	private List<SelectItem> listGroupDtls = new ArrayList<SelectItem>();
	

	private String slectedGroupName ="";
	
	private List<SelectItem> listOfGroups = new ArrayList<SelectItem>();
	
	private Map<String, List<PWiUserVO>> tempGrpUsrMap = new HashMap<String, List<PWiUserVO>>();
	
	private String selectedGroup;
	
	
	
	/**
	 * @return the slectedGroupName
	 */
	public String getSlectedGroupName() {
		return slectedGroupName;
	}

	/**
	 * @param slectedGroupName the slectedGroupName to set
	 */
	public void setSlectedGroupName(String slectedGroupName) {
		this.slectedGroupName = slectedGroupName;
	}

	/**
	 * @return the selectedGroup
	 */
	public String getSelectedGroup() {
		return selectedGroup;
	}

	/**
	 * @param selectedGroup the selectedGroup to set
	 */
	public void setSelectedGroup(String selectedGroup) {
		this.selectedGroup = selectedGroup;
	}

	
	
	/**
	 * @return the userFlag
	 */
	public boolean isUserFlag() {
		return userFlag;
	}

	/**
	 * @param userFlag the userFlag to set
	 */
	public void setUserFlag(boolean userFlag) {
		this.userFlag = userFlag;
	}

	/**
	 * @return the listGroupDtls
	 */
	public List<SelectItem> getListGroupDtls() {
		return listGroupDtls;
	}

	/**
	 * @param listGroupDtls the listGroupDtls to set
	 */
	public void setListGroupDtls(List<SelectItem> listGroupDtls) {
		this.listGroupDtls = listGroupDtls;
	}

	/**
	 * @return the userVOList
	 */
	public List<PWiUserVO> getUserVOList() {
		return userVOList;
	}
	
	/**
	 * @return the listOfGrups
	 */
	public List<SelectItem> getListOfGroups() {
		return listOfGroups;
	}

	/**
	 * @param listOfGrups
	 *            the listOfGrups to set
	 */
	public void setListOfGroups(List<SelectItem> listOfGroupsa) {
		this.listOfGroups = listOfGroupsa;
	}

	/**
	 * @return the availableGroups
	 */
	public List<String> getAvailableGroups() {
		return availableGroups;
	}

	/**
	 * @param availableGroups the availableGroups to set
	 */
	public void setAvailableGroups(List<String> availableGroups) {
		this.availableGroups = availableGroups;
	}

	/**
	 * @return the selectedGroups
	 */
	public List<String> getSelectedGroups() {
		return selectedGroups;
	}

	/**
	 * @param selectedGroups the selectedGroups to set
	 */
	public void setSelectedGroups(List<String> selectedGroups) {
		this.selectedGroups = selectedGroups;
	}

	/**
	 * @return the selectedList
	 */
	public List<SelectItem> getSelectedList() {
		return selectedList;
	}

	/**
	 * @param selectedList the selectedList to set
	 */
	public void setSelectedList(List<SelectItem> selectedLista) {
		this.selectedList = selectedLista;
	}

	/**
	 * @return the availableList
	 */
	public List<SelectItem> getAvailableList() {
		
		return availableList;
	}

	/**
	 * @param availableList the availableList to set
	 */
	public void setAvailableList(List<SelectItem> availableLista) {
		this.availableList = availableLista;
	}

	/**
	 * @param userVOList the userVOList to set
	 */
	public void setUserVOList(List<PWiUserVO> userVOList) {
		this.userVOList = userVOList;
	}

	

	/**
	 * @return the userService
	 */
	public UserService getUserService() {
		return userService;
	}

	/**
	 * @param userService the userService to set
	 */
	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public void setQueriesService(QueriesService queriesService) {
		this.queriesService = queriesService;
	}
	public List<PWiUserVO> getUsersFromSelectedGroup() {
		return usersFromSelectedGroup;
	}

	/**
	 * @param usersFromSelectedGroup the usersFromSelectedGroup to set
	 */
	public void setUsersFromSelectedGroup(List<PWiUserVO> usersFromSelectedGroup) {
		this.usersFromSelectedGroup = usersFromSelectedGroup;
	}

	/**
	 * @return the usersfromselectedgroups
	 */
	public String getUsersfromselectedgroups() {
		return usersfromselectedgroups;
	}

	/**
	 * @param usersfromselectedgroups the usersfromselectedgroups to set
	 */
	public void setUsersfromselectedgroups(String usersfromselectedgroups) {
		this.usersfromselectedgroups = usersfromselectedgroups;
	}

	/**
	 * @return the userListTable
	 */
	public HtmlDataTable getUserListTable() {
		return userListTable;
	}

	/**
	 * @param userListTable the userListTable to set
	 */
	public void setUserListTable(HtmlDataTable userListTable) {
		this.userListTable = userListTable;
	}

	public void setQueryGroupService(QueryGroupService queryGroupService) {
		this.queryGroupService = queryGroupService;
	}

	public void setTemplateService(TemplateService templateService) {
		this.templateService = templateService;
	}

	public void setObjectTypeService(ObjectTypeService objectTypeService) {
		this.objectTypeService = objectTypeService;
	}

	public String getQryKeyWrdTxt() {
		return qryKeyWrdTxt;
	}

	public void setQryKeyWrdTxt(String qryKeyWrdTxt) {
		this.qryKeyWrdTxt = qryKeyWrdTxt;
	}

	public List<PWiQueryNoXmlVO> getSrchQueriesUsersList()
			throws PWiException {
		return queriesService != null ? queriesService.getQueriesForUser() : null;
	}

	/**
	 * Action method that responds to requests to save a newly created query.
	 * 
	 * @return Faces navigation outcome
	 * @throws PWiException
	 */
	public String actionSaveNewQuery() throws PWiException {
		try{
			List<PWiQueryGroupVO> tempSelectedQueryGroupsList = new ArrayList<PWiQueryGroupVO>();
			// Check for validation errors
			boolean valid = queriesService.validateQuery(this.queryName,this.queryDesc, queryXML,
					qryKeyWrdTxt);
			if (queriesService.checkQueryName(this.queryName) > 0) {
				handleFacesError(PWiConstants.ERROR_DUPLICATE_NAME);
				valid = false;
			}
	
			// Check templates for validation errors
			for (TemplateBean template : templates.values()) {
				if (!org.springframework.util.StringUtils.hasText(template
						.getTemplateName())) {
					FacesContext.getCurrentInstance().addMessage(
							null,
							new FacesMessage(FacesMessage.SEVERITY_ERROR,
									"Please enter a template name",
									"Please enter a template name"));
					valid = false;
				}
			}
	
			if (!valid) {
				// Validation errors exist, return to same page to display
				// validation error messages
				return PWiConstants.NAV_ADMIN_QUERY_EDITOR;
			}
	
			for(SelectItem slctItm:getSelectedList())
			{
				PWiQueryGroupVO qrGrpVo = new PWiQueryGroupVO();
				qrGrpVo.setQueryGroupId(Integer.parseInt(slctItm.getValue().toString().substring(0, slctItm.getValue().toString().indexOf(':'))));
				qrGrpVo.setQueryGroupName(slctItm.getLabel());
				tempSelectedQueryGroupsList.add(qrGrpVo);
			}
			// Persist new query
			Integer newQueryId = queriesService.createNewQuery(this.queryName,
					this.queryDesc, this.slctdObjTyps, this.qryKeyWrdTxt,
					getQueryXML(), tempSelectedQueryGroupsList, getSsoId(),
					exportControlled, geOnly, popular, active,tempGrpUsrMap,"N");
	
			// Persist template changes
			for (TemplateBean template : templates.values()) {
				// All templates are new since query is new
	
				// Ignore any marked to delete
				if (template.isMarkedToDelete) {
					continue;
				}
	
				// Create template
				templateService.createTemplate(template.getTemplateName(), template
						.isEnabled(), template.getTemplateBytes(), newQueryId,
						getSsoId());
			}
	
			handleFacesInfo("Query " + this.queryName + " created successfully.");
		}
		catch(PWiException ex){
			
			try {
				throw new PWiException("queriesService/templateService instance was not initiated.." + ex);
			} catch (PWiException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return PWiConstants.NAV_ADMIN_QUERY_LIST;
	}

	/**
	 * Initializes state necessary to display admin query editor to create a new
	 * query.
	 * 
	 * @return JSF navigation string
	 * @throws PWiException
	 */
	public String initCreate() {
		this.createButtonValue = "Create New Query";
		this.editButtonValue = null;

		// Initialize query-related state
		this.queryId = null;
		this.queryName = null;
		this.queryXML = null;
		this.qryKeyWrdTxt = null;
		this.queryDesc = null;
		this.exportControlled = false;
		this.geOnly = false;
		this.popular = false;
		this.active = true;
		this.userFlag=false;

		// Initialize object type related state
		tempGrpUsrMap = new HashMap<String, List<PWiUserVO>>();
		this.usersFromSelectedGroup = new ArrayList<PWiUserVO>();
		this.originalSelObjs = new ArrayList<Integer>();
		this.slctdObjTyps = new ArrayList<Integer>();

		// Initialize group-related state
		this.originalSelectedGroups = new ArrayList<PWiQueryGroupVO>();
		this.selectedQueryGroupsList = new ArrayList<PWiQueryGroupVO>();
		this.availableQueryGroupList = (List<PWiQueryGroupVO>) queryGroupService
				.getAllQueryGroups();
		this.selectedList = new ArrayList<SelectItem>();
		this.availableList = new ArrayList<SelectItem>(); 
		for(PWiQueryGroupVO usrgrpVo : availableQueryGroupList)
		{
			this.availableList.add(new SelectItem(usrgrpVo.getQueryGroupId()+":"+usrgrpVo.getQueryGroupName(), usrgrpVo.getQueryGroupName()));
		}
		

		// Initialize template-related state
		this.templates = new HashMap<Integer, TemplateBean>();
		this.editedTemplateViewId = null;
		this.editedTemplateName = null;
		this.editedTemplateEnabled = true;
		this.uploadItem = null;
		this.maxFilesQuantity = 1;
		this.nextTemplateViewId = 0;

		return PWiConstants.NAV_ADMIN_QUERY_EDITOR;
	}

	/**
	 * Initializes state necessary to display the admin query editor to edit the
	 * specified query.
	 * 
	 * @param theQueryId
	 *            ID of the query to edit
	 * @return JSF navigation string
	 * @throws PWiException
	 */
	public String initEdit(Integer theQueryId) throws PWiException {
		this.editButtonValue = "Update Query";
		this.createButtonValue = null;

		this.queryId = theQueryId;

		try{
			//Initialize query-related state
			QueriesVO resultQuery = queriesService.searchQuery(this.queryId);
			this.queryName = resultQuery.getQueryName();
			this.queryXML = resultQuery.getQueryXML();
			this.qryKeyWrdTxt = resultQuery.getQryKeyWrdTxt();
			this.queryDesc = resultQuery.getQueryDesc();
			this.exportControlled = resultQuery.isExportControlled();
			this.geOnly = resultQuery.isGeOnly();
			this.popular = resultQuery.isPopular();
			this.active = resultQuery.isActive();
			this.userFlag=false;
	
			// Initialize group-related state
			this.usersFromSelectedGroup = new ArrayList<PWiUserVO>();
			this.originalSelectedGroups = queryGroupService
					.findSelectedQueryGroups(this.queryId);
		//	this.originalUserGroupListFrQuery = queryGroupService.findSelectedQueryGroupsUsers(this.queryId);
			List<PWiUserVO> lsUsrVo = new ArrayList<PWiUserVO>();
			int prevGrpId = 0;
			String prevGrpName= "";
			int count = 0;
			/*for(PWiUserVO usrGrpVo : this.originalUserGroupListFrQuery)
			{
				
				
				if(prevGrpId!=usrGrpVo.getSelectedGroupId())
				{
					
					if(prevGrpId!=0)
					{
					tempGrpUsrMap.put(prevGrpId+":"+prevGrpName,lsUsrVo);
					lsUsrVo = new ArrayList<PWiUserVO>();
					}
					prevGrpId = usrGrpVo.getSelectedGroupId();
					prevGrpName=usrGrpVo.getUserForSelectedGroup();
					count = count+1;
				}
				lsUsrVo.add(usrGrpVo);
				
			}
			if(count==1)
			{
				tempGrpUsrMap.put(prevGrpId+":"+prevGrpName,lsUsrVo);
			}*/
			this.selectedQueryGroupsList = new ArrayList<PWiQueryGroupVO>();
			this.selectedQueryGroupsList.addAll(this.originalSelectedGroups);
			this.availableQueryGroupList = (List<PWiQueryGroupVO>) queryGroupService
					.getAllQueryGroups();
			this.availableQueryGroupList.removeAll(selectedQueryGroupsList);
			this.selectedList = new ArrayList<SelectItem>(); 
			for(PWiQueryGroupVO usrgrpVo : selectedQueryGroupsList)
			{
				/*int count1=0;
				if(++count1==1)
				{
					frameTypeListner(usrgrpVo.getQueryGroupId()+":"+usrgrpVo.getQueryGroupName());
				}
				*/
				this.selectedList.add(new SelectItem(usrgrpVo.getQueryGroupId()+":"+usrgrpVo.getQueryGroupName(), usrgrpVo.getQueryGroupName()));
			}
			this.availableList = new ArrayList<SelectItem>(); 
			for(PWiQueryGroupVO usrgrpVo : availableQueryGroupList)
			{
				this.availableList.add(new SelectItem(usrgrpVo.getQueryGroupId()+":"+usrgrpVo.getQueryGroupName(), usrgrpVo.getQueryGroupName()));
			}
			this.availableList.removeAll(selectedList);
			// Initialize object types related state
			this.originalSelObjs = getUserSelectedObjectTypes(theQueryId);
			this.slctdObjTyps = new ArrayList<Integer>();
			this.slctdObjTyps.addAll(originalSelObjs);
	
			// Initialize template-related state
			this.editedTemplateViewId = null;
			this.editedTemplateName = null;
			this.editedTemplateEnabled = true;
			this.uploadItem = null;
			this.maxFilesQuantity = 1;
			this.nextTemplateViewId = 0;
			this.templates = new HashMap<Integer, TemplateBean>();
	
			// Retrieve existing templates
			List<TemplateVO> templateVOs = templateService.getTemplates(theQueryId);
			for (TemplateVO templateVO : templateVOs) {
				TemplateBean template = new TemplateBean(Integer
						.valueOf(nextTemplateViewId++), templateVO);
				templates.put(template.getTemplateViewId(), template);
			}
		}
		catch(Exception ex){
			throw new PWiException("queriesService/templateService instance was not initiated.." + ex);
		}
		return PWiConstants.NAV_ADMIN_QUERY_EDITOR;
	}
	
	public QueriesVO initEditDraft(Integer theQueryId) throws PWiException {
		this.editButtonValue = "Update Query";
		this.createButtonValue = null;

		this.queryId = theQueryId;
		QueriesVO resultQuery=null;

		try{
			// Initialize query-related state
			resultQuery = queriesService.searchQuery(this.queryId);
			this.queryName = resultQuery.getQueryName();
			this.queryXML = resultQuery.getQueryXML();
			this.qryKeyWrdTxt = resultQuery.getQryKeyWrdTxt();
			this.queryDesc = resultQuery.getQueryDesc();
			
		
		}
		catch(Exception ex){
			throw new PWiException("queriesService/templateService instance was not initiated.." + ex);
		}
		return resultQuery;
	}

	public void getNonSelectedGroups(List<PWiQueryGroupVO> availList,
			List<PWiQueryGroupVO> selectList) {
		for (PWiQueryGroupVO queryGroupVO : selectList) {
			removeVO(availList, queryGroupVO);
		}
	}

	private List<Integer> getUserSelectedObjectTypes(Integer theQueryId) {
		List<PWiQueryObjectVO> result = objectTypeService != null ? objectTypeService
				.getSelectedObjectTypes(theQueryId) : null;
		this.slctdObjTyps = new ArrayList<Integer>();
		if (result != null) {
			for (PWiQueryObjectVO vo : result) {
				this.slctdObjTyps.add(vo.getObjectType().getObjTypSeqId());
			}
		}
		return this.slctdObjTyps;
	}

	private void removeVO(List<PWiQueryGroupVO> searchList,
			PWiQueryGroupVO queryGroupVO) {
		ListIterator<PWiQueryGroupVO> itr = searchList.listIterator();
		while (itr.hasNext()) {
			PWiQueryGroupVO QueryGroupVO1 = (PWiQueryGroupVO) itr.next();
			if (QueryGroupVO1.equals(queryGroupVO)) {
				itr.remove();
			}
		}
	}

	/**
	 * Action method that responds to requests to save changes to an edited
	 * query.
	 * 
	 * @return a Faces navigation outcome.
	 * @throws PWiException
	 */
	public String actionUpdateQuery() throws PWiException {
		try{
			List<PWiQueryGroupVO> tempSelectedQueryGroupsList = new ArrayList<PWiQueryGroupVO>();
			// Check for validation errors
			boolean valid = queriesService.validateQuery(this.queryName,this.queryDesc, queryXML,
					qryKeyWrdTxt);
			if (queriesService.checkQueryNameForEdit(this.queryName, this.queryId) > 0) {
				handleFacesError(PWiConstants.ERROR_DUPLICATE_NAME);
				valid = false;
			}
	
			// Check templates for validation errors
			for (TemplateBean template : templates.values()) {
				if (!org.springframework.util.StringUtils.hasText(template
						.getTemplateName())) {
					FacesContext.getCurrentInstance().addMessage(
							null,
							new FacesMessage(FacesMessage.SEVERITY_ERROR,
									"Please enter a template name",
									"Please enter a template name"));
					valid = false;
				}
			}
	
			if (!valid) {
				// Validation errors exist, return to same page to display
				// validation error messages
				return PWiConstants.NAV_ADMIN_QUERY_EDITOR;
			}
	
			String userId = getSsoId();
	
			// Initialize query
			PWiQueryVO query = new PWiQueryVO();
			query.setQrySeqId(queryId);
			query.setQryNm(queryName);
			query.setQryXml(queryXML);
			query.setQryDesc(this.queryDesc);
			query.setQryKywrdTxt(this.qryKeyWrdTxt);
			query.setExportControlled(exportControlled);
			query.setGeOnly(geOnly);
			query.setPopular(popular);
			query.setActive(active);
	
			for(SelectItem slctItm:getSelectedList())
			{
				PWiQueryGroupVO qrGrpVo = new PWiQueryGroupVO();
				qrGrpVo.setQueryGroupId(Integer.parseInt(slctItm.getValue().toString().substring(0, slctItm.getValue().toString().indexOf(':'))));
				qrGrpVo.setQueryGroupName(slctItm.getLabel());
				tempSelectedQueryGroupsList.add(qrGrpVo);
			}
			List<Integer> selectedGroupIds = new ArrayList<Integer>();
			for (PWiQueryGroupVO group : tempSelectedQueryGroupsList) {
				selectedGroupIds.add(group.getQueryGroupId());
			}
	
			// Persist updated query
			//upadated the method 
			this.queriesService.updateQuery(query, selectedGroupIds,this.slctdObjTyps, userId,tempSelectedQueryGroupsList,tempGrpUsrMap);
			//this.queriesService.updateQuery(query, selectedQueryGroupsList,this.slctdObjTyps, userId,tempGrpUsrMap);

	
			// Persist updated template information
			for (TemplateBean template : templates.values()) {
				// Handle templates marked to delete
				if (template.isMarkedToDelete()) {
					if (template.getTemplateId() != null) {
						// Delete an existing template
						templateService.deleteTemplate(template.getTemplateId());
					} // else template was newly added and thus never
					// persisted, so nothing to delete
					continue;
				}
	
				// Handle templates not marked to delete
				if (template.getTemplateId() == null) {
					// Add a new template
					templateService.createTemplate(template.getTemplateName(),
							template.isEnabled(), template.getTemplateBytes(),
							queryId, userId);
				} else {
					// Update an edited template
					templateService.updateTemplate(template.getTemplateVo(),
							template.getTemplateBytes(), userId);
				}
			}
		}
		catch(PWiException ex){
			try {
			throw new PWiException("queriesService/templateService/selectedQueryGroupsList instance was not initiated.." + ex);
			} catch (PWiException e) {
				e.printStackTrace();
			}
		}
		handleFacesInfo("Query " + this.queryName + " updated successfully.");
		return PWiConstants.NAV_ADMIN_QUERY_LIST;
	}

	/**
	 * @return the selectedUserList
	 */
	public List<String> getSelectedUserList() {
		return selectedUserList;
	}

	/**
	 * @param selectedUserList the selectedUserList to set
	 */
	public void setSelectedUserList(List<String> selectedUserList) {
		this.selectedUserList = selectedUserList;
	}

	/**
	 * @return the queryName
	 */
	public String getQueryName() {
		return queryName;
	}

	/**
	 * @param queryName
	 *            the queryName to set
	 */
	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}

	/**
	 * @return the queryXML
	 */
	public String getQueryXML() {
		return queryXML;
	}

	/**
	 * @param queryXML
	 *            the queryXML to set
	 */
	public void setQueryXML(String queryXML) {
		this.queryXML = queryXML;
	}

	/**
	 * @return the allQueryGroups
	 */
	public String getAllQueryGroups() {
		return allQueryGroups;
	}

	/**
	 * @param allQueryGroups
	 */
	public void setAllQueryGroups(String allQueryGroups) {
		this.allQueryGroups = allQueryGroups;
	}

	/**
	 * @return the selectedQueryGroupsList
	 */
	public List<PWiQueryGroupVO> getSelectedQueryGroupsList() {
		return selectedQueryGroupsList;
	}

	/**
	 * @param selectedQueryGroupsList
	 *            the selectedQueryGroupsList to set
	 */
	public void setSelectedQueryGroupsList(
			List<PWiQueryGroupVO> selectedQueryGroupsList) {
		this.selectedQueryGroupsList = selectedQueryGroupsList;
	}

	/**
	 * @return the availableQueryGroupList
	 */
	public List<PWiQueryGroupVO> getAvailableQueryGroupList() {
		return availableQueryGroupList;
	}

	/**
	 * @param availableQueryGroupList
	 *            the availableQueryGroupList to set
	 */
	public void setAvailableQueryGroupList(
			List<PWiQueryGroupVO> availableQueryGroupList) {
		this.availableQueryGroupList = availableQueryGroupList;
	}

	/**
	 * @return the queryId
	 */
	public Integer getQueryId() {
		return queryId;
	}

	/**
	 * @param queryId
	 */
	public void setQueryId(Integer queryId) {
		this.queryId = queryId;
	}

	/**
	 * @return the createButtonValue
	 */
	public String getCreateButtonValue() {
		return createButtonValue;
	}

	/**
	 * @param createButtonValue
	 *            the createButtonValue to set
	 */
	public void setCreateButtonValue(String createButtonValue) {
		this.createButtonValue = createButtonValue;
	}

	/**
	 * @return the editButtonValue
	 */
	public String getEditButtonValue() {
		return editButtonValue;
	}

	/**
	 * @param editButtonValue
	 *            the editButtonValue to set
	 */
	public void setEditButtonValue(String editButtonValue) {
		this.editButtonValue = editButtonValue;
	}
	public List<SelectItem> getPwiObjectTypes() {
		pwiObjectTypes = new ArrayList<SelectItem>();
		if(objectTypeService != null){
			for (PWiObjectTypeVO vo : objectTypeService.getAllPWiObjectTypes()) {
				pwiObjectTypes.add(new SelectItem(vo.getObjTypSeqId(), vo
						.getObjTypNm()));
			}
		}
		return pwiObjectTypes;
	}
/*
	public List<SelectItem> getPwiObjectTypes() {
		PWiObjectTypes = new ArrayList<SelectItem>();
		for (PWiObjectTypeVO vo : objectTypeService.getAllPWiObjectTypes()) {
			pwiObjectTypes.add(new SelectItem(vo.getObjTypSeqId(), vo
					.getObjTypNm()));
		}
		return pwiObjectTypes;
	}
*/
	public String getQueryDesc() {
		return queryDesc;
	}

	public void setQueryDesc(String queryDescription) {
		this.queryDesc = queryDescription;
	}
		
/*
	public void setPwiObjectTypes(List<SelectItem> PWiObjectTypes) {

	public void setPwiObjectTypes(List<SelectItem> PWiObjectTypes) {
		this.PWiObjectTypes = PWiObjectTypes;
	}
*/
	public String actionCancel() {
		return PWiConstants.NAV_ADMIN_QUERY_LIST;
	}
	
	public void setPwiObjectTypes(List<SelectItem> PWiObjectTypes) {
		this.pwiObjectTypes = PWiObjectTypes;
	}

	/**
	 * @return the slctdObjTyps
	 */
	public List<Integer> getSlctdObjTyps() {
		return slctdObjTyps;
	}

	/**
	 * @param slctdObjTyps
	 *            the slctdObjTyps to set
	 */
	public void setSlctdObjTyps(List<String> slctdObjTyps) {
		this.slctdObjTyps = new ArrayList<Integer>();
		for (String objectType : slctdObjTyps) {
			this.slctdObjTyps.add(Integer.valueOf(objectType));
		}
	}

	/**
	 * Helper method to validate the fields submitted for adding a template.
	 * 
	 * @return true if valid, false otherwise
	 */
	private boolean validateEditedTemplate() {
		boolean valid = true;
		if (!org.springframework.util.StringUtils.hasText(editedTemplateName)) {
			FacesContext.getCurrentInstance().addMessage(
					null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							"Please enter a template name",
							"Please enter a template name"));
			valid = false;
		}
		// If template is being added rather than edited, upload item must not
		// be null
		if (editedTemplateViewId == null && uploadItem == null) {
			FacesContext.getCurrentInstance().addMessage(
					null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							"Please upload an Excel (.xls) file",
							"Please upload an Excel (.xls) file"));
			valid = false;
		}

		return valid;
	}

	public void setExportControlled(boolean exportControlled) {
		this.exportControlled = exportControlled;
	}

	public boolean isExportControlled() {
		return exportControlled;
	}

	public void setGeOnly(boolean geOnly) {
		this.geOnly = geOnly;
	}

	public boolean isGeOnly() {
		return geOnly;
	}

	public void setPopular(boolean popular) {
		this.popular = popular;
	}

	public boolean isPopular() {
		return popular;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isActive() {
		return active;
	}
	public void actionListenerFileUpload(UploadEvent event) {
		// Capture uploaded item and update maxFilesQuantity
		uploadItem = event.getUploadItem();
		maxFilesQuantity = 0;
	}

	public String actionClearTemplateFile() {
		// Clear uploadItem and maxFilesQuantity
		uploadItem = null;
		maxFilesQuantity = 1;
		return null;
	}

	public String actionUpdateTemplate() throws PWiException {
		// Perform validation
		if (!validateEditedTemplate()) {
			return null;
		}

		// Get existing/new template bean to update
		TemplateBean templateBean = null;
		if (editedTemplateViewId == null) {
			editedTemplateViewId = Integer.valueOf(nextTemplateViewId++);
			templateBean = new TemplateBean(editedTemplateViewId);
			templates.put(editedTemplateViewId, templateBean);
		} else {
			templateBean = templates.get(editedTemplateViewId);
		}

		// Retrieve bytes for template file if one was uploaded
		if (uploadItem != null) {
			byte[] templateBytes = null;
			if (uploadItem.isTempFile()) {
				// Read in bytes from file
				try {
					templateBytes = FileCopyUtils.copyToByteArray(uploadItem
							.getFile());
				} catch (IOException e) {
					throw new PWiException(e,
							"Failed to retrieve template bytes.");
				}
			} else {
				templateBytes = uploadItem.getData();
			}
			templateBean.setTemplateBytes(templateBytes);
		}

		// Update editable properties
		templateBean.setTemplateName(editedTemplateName);
		templateBean.setEnabled(editedTemplateEnabled);

		// reset state for editing a template
		editedTemplateViewId = null;
		editedTemplateName = null;
		uploadItem = null;
		maxFilesQuantity = 1;

		// return to same page
		return null;
	}

	public String actionEditTemplate() {
		if (editedTemplateViewId != null) {
			// Get values for existing template
			TemplateBean templateBean = templates.get(editedTemplateViewId);
			editedTemplateName = templateBean.getTemplateName();
			editedTemplateEnabled = templateBean.isEnabled();
		} else {
			// Default values for new template
			editedTemplateName = "";
			editedTemplateEnabled = true;
		}

		uploadItem = null;
		maxFilesQuantity = 1;

		return null;
	}

	public List<TemplateBean> getTemplates() {
		return new ArrayList<TemplateBean>(templates.values());
	}

	public Integer getEditedTemplateViewId() {
		return editedTemplateViewId;
	}

	public void setEditedTemplateViewId(Integer editedTemplateViewId) {
		this.editedTemplateViewId = editedTemplateViewId;
	}

	public int getMaxFilesQuantity() {
		return maxFilesQuantity;
	}

	public String getEditedTemplateName() {
		return editedTemplateName;
	}

	public void setEditedTemplateName(String editedTemplateName) {
		this.editedTemplateName = editedTemplateName;
	}

	public boolean isEditedTemplateEnabled() {
		return editedTemplateEnabled;
	}

	public void setEditedTemplateactived(boolean editedTemplateEnabled1) {
		this.editedTemplateEnabled = editedTemplateEnabled1;
	}
	
	public void actionSaveUsersFromSelectedList()
			throws PWiException {}


	public void frameTypeListner(ValueChangeEvent event) {
		
		usersFromSelectedGroup = new ArrayList<PWiUserVO>();
		
	if(event!=null && event.getNewValue()!=null)
	{
		userFlag = false;
		
		selectedGroup = event.getNewValue().toString(); 
		slectedGroupName = selectedGroup.substring(selectedGroup.indexOf(':')+1);
		//selectedGroup = selectedGroup.substring(selectedGroup.indexOf(":")+1);
		if(tempGrpUsrMap.containsKey(selectedGroup))
		{
			usersFromSelectedGroup = tempGrpUsrMap.get(selectedGroup);
		}
		else
		{
			usersFromSelectedGroup = userService.getUsersforSelectedGroups(slectedGroupName);
		}
			
			if(usersFromSelectedGroup!=null && usersFromSelectedGroup.size()>0)
			{
				userFlag = true;
			}

	}
			
	}
	
public void frameTypeListner(String selectedGrp) {
		
		usersFromSelectedGroup = new ArrayList<PWiUserVO>();
		
	if(selectedGrp!=null)
	{
		userFlag = false;
		
		selectedGroup = selectedGrp; 
		slectedGroupName = selectedGroup.substring(selectedGroup.indexOf(':')+1);
		//selectedGroup = selectedGroup.substring(selectedGroup.indexOf(":")+1);
		if(tempGrpUsrMap.containsKey(selectedGroup))
		{
			usersFromSelectedGroup = tempGrpUsrMap.get(selectedGroup);
		}
		else
		{
			usersFromSelectedGroup = userService.getUsersforSelectedGroups(slectedGroupName);
		}
			
			if(usersFromSelectedGroup!=null && usersFromSelectedGroup.size()>0)
			{
				userFlag = true;
			}

	}
			
	}
	public void saveSelectedUsers() {
		
		
		
		if(tempGrpUsrMap.containsKey(selectedGroup))
		{
			tempGrpUsrMap.remove(selectedGroup);
		}
		
		tempGrpUsrMap.put(selectedGroup, usersFromSelectedGroup);
		
	  handleFacesInfo("Users for " + this.slectedGroupName + " saved successfully.");
			
	}

	   private List<PWiUserVO> userDtls = new ArrayList<PWiUserVO>();
		 
		    private List<String> userLst = new ArrayList<String>(); 
		   

			/**
			 * @return the userDtls
			 */
			public List<PWiUserVO> getUserDtls() {
				return userDtls;
			}

			/**
			 * @param userDtls the userDtls to set
			 */
			public void setUserDtls(List<PWiUserVO> userDtls) {
				this.userDtls = userDtls;
			}

			/**
			 * @return the userLst
			 */
			public List<String> getUserLst() {
				return userLst;
			}

			/**
			 * @param userLst the userLst to set
			 */
			public void setUserLst(List<String> userLst) {
				this.userLst = userLst;
			}

			/**
			 * @return the usersSelectedUsers
			 */
/*			public List<SelectItem> getUsersSelectedUsers() {
				int maxOccur=0;
					for(PWiUserVO userVo : usersFromSelectedGroup)
					{							 
						usersSelectedUsers.add(new SelectItem(userVo.getUserId(),userVo.getUserNm()));
						
						System.out.println("checking occurances"+usersSelectedUsers);
					}					
				
				return usersSelectedUsers;
			}*/
			
			
			
			
			
			/*public List<SelectItem> getUsersSelectedUsers() {
				
				List<PWiUserVO> eachMember = usersFromSelectedGroup;
				  Iterator itr = usersFromSelectedGroup.iterator();
				  while(itr.hasNext()) {
				          eachMember = (List<PWiUserVO>) itr.next();
				          System.out.print("each role" +eachMember);
				      }
				 List<PWiUserVO> userList = new ArrayList();
				
				 usersSelectedUsers.add((SelectItem) eachMember);
				System.out.println("selected users for checkbox"+usersSelectedUsers);
				return usersSelectedUsers;
		}*/
			

			
			
			public String moveToSelectedList(ActionEvent event) {
			
				int leftSize = 0;
				List<SelectItem> tobeRemoved = null;
				String selGrpName = null;
				String oldGrpName = null;
				String selGrpVal = null;
				String selGrpVals = null;
				String addGrpName = null;
				
				for(PWiQueryGroupVO grpVo :availableQueryGroupList )
				{
					listOfGroups.add(new SelectItem(grpVo.getQueryGroupId()+":"+grpVo.getQueryGroupName(),grpVo.getQueryGroupName()));
				}
				
				
				if (availableGroups == null) {
					availableGroups = new ArrayList<String>();
				}
				if (selectedGroups == null) {
					selectedGroups = new ArrayList<String>();
				}
				tobeRemoved = new ArrayList<SelectItem>();
				for (Iterator<String> c = availableGroups.iterator(); c.hasNext();) {
					selGrpName = c.next();
					boolean isExists = false;
					for (Iterator<SelectItem> sl = selectedList.iterator(); sl
							.hasNext();) {
						SelectItem ss = sl.next();
						oldGrpName = (String) ss.getValue();
						if (oldGrpName.equals(selGrpName)) {
							isExists = true;
						}
					}
					if (!isExists) {
						for (SelectItem selList : listOfGroups) {
							if (selGrpName.equals(selList.getValue())) {
								addGrpName = (String) selList.getLabel();
							}
						}
						selectedList.add(new SelectItem(selGrpName, addGrpName));
					}
				}
				leftSize = availableGroups.size();
				for (int i = 0; i < availableList.size(); i++) {
					boolean flag = false;
					selGrpVal = (String) ((SelectItem) availableList.get(i)).getLabel();
					selGrpVals = (String) ((SelectItem) availableList.get(i))
							.getValue();
					for (int j = 0; j < leftSize; j++) {
						if (((String) availableGroups.get(j))
								.equalsIgnoreCase(selGrpVals)) {
							flag = true;
						}
					}
					if (!flag) {
						tobeRemoved.add(new SelectItem(selGrpVals, selGrpVal));
					}
				}
				availableGroups = new ArrayList<String>();
				setAvailableList(tobeRemoved);
				// alertMessage = ReviewConstants.EMPTY;
				// message = ReviewConstants.EMPTY;
				return "";
			}
			
			
			public String moveToAvailableList(ActionEvent ae) {
								
				List<SelectItem> tobeRemoved = null;
				String selGrpName = null;
				String oldGrpName = null;
				String grpName = null;
				String selGrpVals = null;
				String addGrpName = null;
				
				for(PWiQueryGroupVO grpVo :selectedQueryGroupsList )
				{
					listOfGroups.add(new SelectItem(grpVo.getQueryGroupId()+":"+grpVo.getQueryGroupName(),grpVo.getQueryGroupName()));
				}
				
				if (availableList == null) {
					availableList = new ArrayList<SelectItem>();
				}
				if (availableGroups == null) {
					availableGroups = new ArrayList<String>();
				}
				if (selectedGroups == null) {
					selectedGroups = new ArrayList<String>();
				}

				//leftSize = selectedGroups.size();
				tobeRemoved = new ArrayList<SelectItem>();
				//for (Iterator<String> c = selectedGroups.iterator(); c.hasNext();) {
					selGrpName = selectedGroup;
					boolean isExists = false;
					for (Iterator<SelectItem> sl = availableList.iterator(); sl
							.hasNext();) {
						SelectItem ss = sl.next();
						oldGrpName = (String) ss.getValue();
						if (oldGrpName.equals(selGrpName)) {
							isExists = true;
						}
					}
					if (!isExists) {
						for (SelectItem selList : listOfGroups) {
							if (selGrpName.equals(selList.getValue())) {
								addGrpName = (String) selList.getLabel();
							}
						}
						availableList.add(new SelectItem(selGrpName, addGrpName));
					}
				//}
				for (int i = 0; i < selectedList.size(); i++) {
					boolean flag = false;
					grpName = (String) ((SelectItem) selectedList.get(i)).getLabel();
					selGrpVals = (String) ((SelectItem) selectedList.get(i)).getValue();
					if (selGrpName.equalsIgnoreCase(selGrpVals)) {
						flag = true;
					}
					/*for (int j = 0; j < leftSize; j++) {
						selVal = (String) selectedGroups.get(j);
						if (selVal.equalsIgnoreCase(selGrpVals)) {
							flag = true;
						}
					}*/
					if (!flag) {
						tobeRemoved.add(new SelectItem(selGrpVals, grpName));

					}
				}

				// alertMessage = ReviewConstants.EMPTY;
				// message = ReviewConstants.EMPTY;
				if(tempGrpUsrMap.containsKey(selGrpName))
				{
					tempGrpUsrMap.remove(selGrpName);
				}
				this.userFlag = false;
				selectedGroups = new ArrayList<String>();
				setSelectedList(tobeRemoved);
				return "";

			}

			
			/**
			 * @return the selectedItemsValue
			 */
			public String getSelectedItemsValue() {
				return selectedItemsValue;
			}

			/**
			 * @param selectedItemsValue the selectedItemsValue to set
			 */
			public void setSelectedItemsValue(String selectedItemsValue) {
				this.selectedItemsValue = selectedItemsValue;
			}
			
}