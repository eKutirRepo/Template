/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCostCycleSmryMB.java
 * @Creation date: 30-June-2014
 * @version 2.0.1
 * @author : Tech Mahindra (PLMR Team) 
 */

package com.geinfra.geaviation.pwi.bean;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;

import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;

import com.geinfra.geaviation.pwi.data.PLMCostCycleSmryData;
import com.geinfra.geaviation.pwi.service.PLMCostCycleSmryServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMCostCycleSmryMB {
	
	/**
	 * Holds the LOG
	 */
	private static Logger LOG = Logger.getLogger(PLMCostCycleSmryMB.class);
	/**
	 * Holds the LOG
	 */
	private PLMCostCycleSmryData costCycleSmryData = null;
	/**
	 * Holds the PLMCostCycleSmryServiceIfc
	 */
	private PLMCostCycleSmryServiceIfc plmCostCycleSmryService  = null;
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the multipleContract
	 */
	private boolean multipleContract;
	/**
	 * Holds the contractList
	 */
	private List<PLMCostCycleSmryData> contractList = null; 
	/**
	 * Holds the contractDDList
	 */
	private List<SelectItem> contractDDList = null;
	/**
	 * Holds the contractDDList
	 */
	private List<SelectItem> contractDDList1 = null;
	/**
	 * Holds the costCycleResultList
	 */
	private List<PLMCostCycleSmryData> costCycleResultList = null;
	
	/**
	 * Holds the custReq
	 */
	private String custReq;
	/**
	 * Holds the custReqDesc
	 */
	private String custReqDesc;
	/**
	 * Holds the custReqSpec
	 */
	private String custReqSpec;
	/**
	 * Holds the crState
	 */
	private String crState;
	/**
	 * Holds the contract
	 */
	private String contract;
	/**
	 * Holds the contractDesc
	 */
	private String contractDesc;
	/**
	 * Holds the recordCount
	 */
	private int recordCount;
	/**
	 * Holds the recordCount
	 */
	private Map<String, List<PLMCostCycleSmryData>> costCycleResultMap;
	/**
	 * Holds the genGrpList
	 */
	private List<PLMCostCycleSmryData> genGrpList;
	/**
	 * Holds the steamGrpList
	 */
	private List<PLMCostCycleSmryData>  steamGrpList;
	/**
	 * Holds the gasGrpList
	 */
	private List<PLMCostCycleSmryData> gasGrpList;
	
	/**
	 * Holds the totalCostList
	 */
	private List<PLMCostCycleSmryData> totalCostList;
	
	/**
	 * Holds the gasFlag
	 */
	private boolean gasFlag;
	/**
	 * Holds the genFlag
	 */

	private boolean genFlag;
	
	/**
	 * Holds the steamFlag
	 */
	private boolean steamFlag;
	
	/**
	 * Holds the totalCostFlag
	 */
	private boolean totalCostFlag;
	/**
	 * Holds the costSmryGen
	 */
    private String costSmryGen;
    /**
	 * Holds the costSmryGas
	 */
    private String costSmryGas;
    /**
	 * Holds the costSmrySteam
	 */
    private String costSmrySteam;
    /**
	 *  Holds the heightPX
	 */
	private String heightPX = "450px";
	/**
	 *  Holds the heightPX1
	 */
	private String heightPX1 = "450px";
	/**
	 * Holds the crsName
	 */
    private String crsName;
    
    
    /**
	 * Holds the noCostGrpFound
	 */
    private String noCostGrpFound;
    
   
	
	/**
	 * This method is used for Loading CostCycle Summary Page
	 * 
	 * @return String
	 */
	public String loadCostCycleSmryPage() {
		LOG.info("Entering loadCostCycleSmryPage Method");
		
		try {
			commonMB.insertCannedRptRecordHitInfo("Cost and Cycle Summary Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {	
			if(contractDDList==null)
			{
				contractDDList = new ArrayList<SelectItem>();
			}
			costCycleSmryData = new PLMCostCycleSmryData();
			if(costCycleSmryData.getCostReqNum() != null){
				costCycleSmryData.setCostReqNum("");
			}
			multipleContract=false;
			
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@loadCostCycleSmryPage:", exception);
		}
		LOG.info("Exiting loadCostCycleSmryPage Method");
		return "costCycleSmry";
	}
	
	/**
	 * This method is used for Resetting the User input
	 * 
	 * @return String
	 */
	
	public String resetData() {
		
		LOG.info("Entering Reset Method");
		String fwdflag = "costCycleSmry";
		if(costCycleSmryData.getCostReqNum() != null){
			costCycleSmryData.setCostReqNum("");
		}
		LOG.info("Exiting Reset Method");
		return fwdflag;
	}
	
	/**
	 * This method is used for Generating CostCycleSmry Report
	 * 
	 * @return String
	 */
	//CR-000699
	public String showCostCycleSmryReport() {
		LOG.info("Entering showCostCycleSmryReport Method");
		multipleContract = false;
		String fwdflag = "costCycleSmry";
		String crNum = costCycleSmryData.getCostReqNum();
		alertMessage = validateCostCycleInput();
		
		
		if (PLMUtils.isEmpty(alertMessage)) {
			LOG.info("The Input CR NUM is in correct format...");
			try {
				int crCount=0;
				crCount=plmCostCycleSmryService.getCrCount(crNum);
				LOG.info("crCount Value fetched==="+crCount);
				if(crCount == 0){
					LOG.info("This is an invalid CR Number...");
					alertMessage = PLMConstants.COST_REQ_NUM_INVALID;
					return "costCycleSmry";
					
				}
				if(crCount >= 1){
					LOG.info("This is a valid CR Number...");
					contractList=new ArrayList<PLMCostCycleSmryData>();
					contractList=plmCostCycleSmryService.getContractForCR(crNum);
					
					
					
					LOG.info("Fetched Contract List with size=="+contractList.size());
					contractDDList=new ArrayList<SelectItem>();
					contractDDList1=new ArrayList<SelectItem>();
					
					//contractDDList1.add(new SelectItem ("Select"));
					
					for(PLMCostCycleSmryData data : contractList){
						contractDDList1.add(data.getDdListContract());
						LOG.info("one item added...");
					}
					LOG.info("Fetched Redundant Drop Down Contract List with size=="+contractDDList1.size());
					
					Set<SelectItem> uniqueContractDDSet = new HashSet<SelectItem>(); 
					for(SelectItem sitem : contractDDList1){					
						if(uniqueContractDDSet.add(sitem)){						
							uniqueContractDDSet.add(sitem);
							//contractDDList.add(sitem);
						}
					}
					StringBuffer contractset =new StringBuffer();
					for(SelectItem setlistItem : uniqueContractDDSet){
						  if(contractset.lastIndexOf(setlistItem.getValue().toString()) < 0){
					       	     contractDDList.add(setlistItem);
							     contractset.append(setlistItem.getValue()+",");
						  }
					}
					Collections.sort(contractDDList, new PLMUtils.SortListSelItmLbl());
					
					LOG.info("Fetched Unique Drop Down Contract List with size=="+contractDDList.size());
					
					if(contractList.size() == 0){
						LOG.info("Contract List Size is =="+contractList.size());
						alertMessage = PLMConstants.NO_DATA_FOUND;
						return "costCycleSmry";
						//costCycleResultList = new ArrayList<PLMCostCycleSmryData>();
						//costCycleResultList = plmCostCycleSmryService.getCostCycleResult(crNum);
					}
					/*if(contractList.size() == 1){
						LOG.info("Contract List Size is =="+contractList.size());
						String contractNum=contractList.get(0).getContract();
						costCycleResultList = new ArrayList<PLMCostCycleSmryData>();
						costCycleResultList = plmCostCycleSmryService.getCostCycleResult(crNum,contractNum);
					}*/
					if(contractList.size() >= 1){
						LOG.info("Contract List Size is =="+contractList.size());
						multipleContract = true;
						//alertMessage=PLMConstants.SELECT_ONE_CONTRACT;
						return "costCycleSmry";
					}
				}
				
			 } catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@showCostCycleSmryReport: ", exception);
				fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"costCycleSmryResult","Cost Cycle Smry Report");
			}
		}else{
			return "costCycleSmry";
		}
		LOG.info("Exiting showCostCycleSmryReport Method");
		return fwdflag;
	}
	
	/**
	 * This method is used for Generating CostCycleSmry Report for Contract
	 * 
	 * @return String
	 */
	public String showCostCycleSmryReportForContract() {
		LOG.info("Entering showCostCycleSmryReportForContract Method");
		String fwdflag = "costCycleSmryResult";
		String crNum = costCycleSmryData.getCostReqNum();
		String selectedContract = costCycleSmryData.getSelectedContract();
		LOG.info("The Contract selected from the drop down list is==============="+selectedContract);
		contract="";
		contractDesc="";
		genGrpList= new ArrayList<PLMCostCycleSmryData>();
		steamGrpList = new ArrayList<PLMCostCycleSmryData>();
		gasGrpList= new ArrayList<PLMCostCycleSmryData>();
		totalCostList =new ArrayList<PLMCostCycleSmryData>();
		genFlag=false;
		gasFlag=false;
		steamFlag=false;
		totalCostFlag=false;
		int genSize=0;
		int gasSize=0;
		int steamSize=0;
		try {
			if(PLMUtils.isEmpty(selectedContract)){
				alertMessage=PLMConstants.SELECT_ONE_CONTRACT;
				return "costCycleSmry";
			}
			
			if (!PLMUtils.isEmpty(selectedContract)) {
				LOG.info("Selected Contract is ==" + selectedContract);
				
				costCycleResultList = new ArrayList<PLMCostCycleSmryData>();
				costCycleResultMap = new HashMap<String, List<PLMCostCycleSmryData>>(); 
				costCycleResultMap = plmCostCycleSmryService
						.getCostCycleResult(crNum, selectedContract);
				costCycleResultList =costCycleResultMap.get("CostCycleResults");
				
				if(costCycleResultList.size() >0){
				heightPX = PLMUtils.getTableHeight(costCycleResultList.size()+1);
				}
				genGrpList= costCycleResultMap.get("genGrpList");
				steamGrpList =costCycleResultMap.get("steamGrpList"); 
				gasGrpList= costCycleResultMap.get("gasGrpList");
				totalCostList= costCycleResultMap.get("totalCostList");
				
				if(genGrpList.size()>0){
					genFlag=true;
					totalCostFlag=true;
					costSmryGen="Cost Summary - "+selectedContract +"- Gen";
					 genSize=genGrpList.size();
					
				}
				if(gasGrpList.size()>0){
					gasFlag=true;
					totalCostFlag=true;
					costSmryGas="Cost Summary - "+selectedContract +"- Gas";
					 gasSize=gasGrpList.size();
					
				}
				if(steamGrpList.size()>0){
					steamFlag=true;
					totalCostFlag=true;
					costSmrySteam="Cost Summary - "+selectedContract +"- Steam";
					 steamSize=steamGrpList.size();
				}
				heightPX1 = PLMUtils.getTableHeight(genSize+gasSize+steamSize+1);
				
				if(totalCostFlag==false){
					noCostGrpFound="There is no Cost Group associated to the data set retrieved";
				}
				
				 
/*		for (PLMCostCycleSmryData data : costCycleResultList){
			for (int i=0;i<costCycleResultList.size();i++){
				data.setResNoOfUnits(i);
			}
		}*/
				
				if (!(costCycleResultList.size() == 0)) {
					LOG.info("Cost Cycle Result fetched with "
							+ costCycleResultList.size() + " Records...");
				
					
					recordCount=costCycleResultList.size();
					custReq = costCycleResultList.get(0).getResCustReq();
					custReqDesc = costCycleResultList.get(0)
							.getResCustReqDesc().replaceAll("\\n", " ");
 					crState = costCycleResultList.get(0).getResCRState();
					for (PLMCostCycleSmryData data : contractList) {
						if (data.getContract().equals(selectedContract)) {
							contract = data.getContract();
							LOG.info("Contract is======" + contract);
							contractDesc = data.getDescription();
							LOG.info("Contract Desc is======" + contractDesc);
							crsName=data.getCrsName();
							LOG.info("Customer requirement Name ==" + crsName);
						}

					}
				}else{
					alertMessage="No results found for the input CR and Contract Number";
					return "invalidCostCycleSmry";
				}
			}
				else{
					LOG.info("No Contract Selected...");
					alertMessage=PLMConstants.SELECT_ONE_CONTRACT;
					return "costCycleSmry";
				}
				
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@showCostCycleSmryReportForContract: ", exception);
				fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"costCycleSmry","Cost and Cycle Smry Report");
			}
		
		
		LOG.info("Exiting showCostCycleSmryReportForContract Method");
		return fwdflag;
	}
	
	/**
	 * This method is used for Validating Cost Cycle Smry User Input
	 * 
	 * @return String
	 */
	public String validateCostCycleInput() {
		
		LOG.info("Entering validateCostCycleInput Method");
		if(PLMUtils.isEmpty(costCycleSmryData.getCostReqNum())){
			alertMessage = PLMConstants.COST_REQ_NUM_EMPTY;
			LOG.info(alertMessage);
		}else if(!(costCycleSmryData.getCostReqNum().startsWith("CR-"))){
			alertMessage = PLMConstants.COST_REQ_NUM_INVALID_FORMAT;
			LOG.info(alertMessage);
		}
		LOG.info("Exiting validateCostCycleInput Method");
		return alertMessage;
	}

	 private XSSFFont headerFont(SXSSFWorkbook wb, int size){
			XSSFFont font = (XSSFFont) wb.createFont();
			font.setFontName(PLMConstants.EXCEL_FONT_NAME);
			font.setFontHeightInPoints((short)size);
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			return font;
		}
		
		private XSSFFont normalFont(SXSSFWorkbook wb, int size){
			XSSFFont font = (XSSFFont) wb.createFont();
			font.setFontName(PLMConstants.EXCEL_FONT_NAME);
			font.setFontHeightInPoints((short)size);
			return font;
		}
		
		private XSSFCellStyle headerCell(SXSSFWorkbook wb, XSSFFont font, short bgcolor, boolean wrap){
			XSSFCellStyle hCell = normalCell(wb, font, XSSFCellStyle.SOLID_FOREGROUND, wrap);
			//FONT
			hCell.setFont(font);
			
			//HORIZONTAL ALIGNMENT
			hCell.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			
			//COLOR
			hCell.setFillForegroundColor(bgcolor);
			return hCell;
		}
		
		private XSSFCellStyle normalCell(SXSSFWorkbook wb, XSSFFont font, short fillPattern, boolean wrap){
			// Cell Style
			XSSFCellStyle cellStyle = (XSSFCellStyle)wb.createCellStyle();
			
			//Set Font
			cellStyle.setFont(font);
			//WRAP TEXT
			cellStyle.setWrapText(wrap);
			
			//VERTICAL ALIGNMENT
			cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			
			//BORDERS
			cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			
			//FILL PATTERN
			cellStyle.setFillPattern(fillPattern);
			return cellStyle;
		}
		/**
		 * This method is used for Bordering Cell in XLS
		 * 
		 * @return StringBuffer
		 */
		private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
			style.setBorderTop(XSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			style.setBorderRight(XSSFCellStyle.BORDER_THIN);
			return style;
		}
		
	public void downloadExcel() throws PLMCommonException {

		LOG.info("Entering downloadExcel Method");
		FacesContext facesContext = FacesContext.getCurrentInstance();
	  	try {
			HttpServletResponse response = 
				(HttpServletResponse)facesContext.getExternalContext().getResponse();
			
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			
			response.setHeader("Content-disposition", 
					"attachment; filename="+"Cost Cycle Summary.xlsx");
			
			OutputStream outputStream = response.getOutputStream();
			
			SXSSFWorkbook workbook = new SXSSFWorkbook();
			
			XSSFFont font = headerFont(workbook, 10);
			
			// Header Style
			XSSFCellStyle headerStyle = headerCell(workbook, font, HSSFColor.PALE_BLUE.index, true);

			XSSFFont cellfont = normalFont(workbook, 10);
			// Cell Style
			XSSFCellStyle cellStyle = normalCell(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
			
			
			XSSFCellStyle sumCalStyle = (XSSFCellStyle) workbook.createCellStyle();
			sumCalStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			sumCalStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			sumCalStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			sumCalStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			sumCalStyle.setFont(font);
			sumCalStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			sumCalStyle.setWrapText(true);
			sumCalStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
		 
			SXSSFSheet sheet = (SXSSFSheet) workbook.createSheet("Cost Cycle Summary");
			
			int rowcount = 0;
			
			SXSSFCell cell=null;
		    
		    SXSSFRow row = (SXSSFRow) sheet.createRow(rowcount);
		    
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
			cell.setCellValue("Customer Requirement");
			cell.setCellStyle(cellStyle);

			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(custReq);
			cell.setCellStyle(cellStyle);
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
			cell.setCellValue("Customer Requirement Description");
			cell.setCellStyle(cellStyle);

			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(custReqDesc);
			cell.setCellStyle(cellStyle);
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
			cell.setCellValue("Customer Requirement Specification");
			cell.setCellStyle(cellStyle);

			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(crsName);
			cell.setCellStyle(cellStyle);
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
			cell.setCellValue("CR State");
			cell.setCellStyle(cellStyle);

			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(crState);
			cell.setCellStyle(cellStyle);
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
			cell.setCellValue("Contract");
			cell.setCellStyle(cellStyle);

			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(costCycleSmryData.getSelectedContract());
			cell.setCellStyle(cellStyle);
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
			cell.setCellValue("Contract Description");
			cell.setCellStyle(cellStyle);

			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(contractDesc);
			cell.setCellStyle(cellStyle);
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			row = (SXSSFRow) sheet.createRow(++rowcount);
		    
            	
             String[] columns = {"Contract","Cost Group","CO Name","CO State","TF Marketing Name","LF Description","Unit of Measure","Location Currency",
            		 "Material Ship Direct Cost","Raw In Process Cost","Manufacturing Labor Hours","Product Cost","# of Units","Product Cost (Site)",
            		 "Shop Work and Lab","Drafting Hours","Engineering Hours","Eng Total Cost",	"Transportation Cost","GE Field InstallationCost",
            		 "Manufacturing Expenses","Sub Total Field Trans InvCost","Sub Total Eng Field Trans Cost",
            		 "Manufacturing/Material Lead Time (Wks)","Manufacturing/Planned Lead Time (Wks)","Cycle Time Drawings(Wks)",
            		 "Product Configuration	Model Number","Engineering Disposition","Part Name"};
        			
            	for ( int i = 0 ; i < columns.length; i++ ) {
    				cell = (SXSSFCell)row.createCell(i);
    				cell. setCellValue(columns[i]);
    				cell.setCellStyle(headerStyle);
    			}
             
				for(int j=0;j<costCycleResultList.size();j++){
				
					PLMCostCycleSmryData dataObj = (PLMCostCycleSmryData) costCycleResultList.get(j);
					
					row = (SXSSFRow) sheet.createRow(++rowcount);
					
				 if(!dataObj.isSumFlag()){
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(costCycleSmryData.getSelectedContract());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResCostGroup());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResCOName());
					
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResCOState());
					
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResTFMktName());
					
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResLFDesc());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_SIX);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResUnitOfMeasure());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_SEVEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResLocationCurrency());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_EIGHT);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResMaterialShipDirectCost());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_NINE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResRawInProcessCost());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResMfgLaborHours());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResProdCost());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWELVE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getNoOfUnits());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getProdCostSite());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResShopWorkLabCost());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResDraftingHours());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResEnggHours());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResEnggTotalCost());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_EIGHTEEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResTransportCost());
					
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_NINETEEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResFieldInstallCost());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTY);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResMfgExp());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYONE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResFieldTransInvCost());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYTWO);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResEngFieldTransCost());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYTHREE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResMfgMatLeadTime());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYFOUR);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResMfgPlannedLeadTime());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYFIVE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResCycleTimeDrawings());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYSIX);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResProductConfig());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYSEVEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResModelNum());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYEIGHT);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResEnggDisposition());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYNINE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getResPartName());
				 }else{

					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellStyle(sumCalStyle);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(sumCalStyle);
					cell.setCellValue(dataObj.getResCostGroup());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellStyle(sumCalStyle);
					
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
					cell.setCellStyle(sumCalStyle);
					
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell.setCellStyle(sumCalStyle);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell.setCellStyle(sumCalStyle);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_SIX);
					cell.setCellStyle(sumCalStyle);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_SEVEN);
					cell.setCellStyle(sumCalStyle);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_EIGHT);
					cell.setCellStyle(sumCalStyle);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_NINE);
					cell.setCellStyle(sumCalStyle);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TEN);
					cell.setCellStyle(sumCalStyle);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
					cell.setCellStyle(sumCalStyle);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWELVE);
					cell.setCellStyle(sumCalStyle);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
					cell.setCellStyle(sumCalStyle);
					cell.setCellValue(dataObj.getProdCostSite());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
					cell.setCellStyle(sumCalStyle);
					cell.setCellValue(dataObj.getResShopWorkLabCost());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
					cell.setCellStyle(sumCalStyle);
					cell.setCellValue(dataObj.getResDraftingHours());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
					cell.setCellStyle(sumCalStyle);
					cell.setCellValue(dataObj.getResEnggHours());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
					cell.setCellStyle(sumCalStyle);
					cell.setCellValue(dataObj.getResEnggTotalCost());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_EIGHTEEN);
					cell.setCellStyle(sumCalStyle);
					cell.setCellValue(dataObj.getResTransportCost());
					
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_NINETEEN);
					cell.setCellStyle(sumCalStyle);
					cell.setCellValue(dataObj.getResFieldInstallCost());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTY);
					cell.setCellStyle(sumCalStyle);
					cell.setCellValue(dataObj.getResMfgExp());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYONE);
					cell.setCellStyle(sumCalStyle);
					cell.setCellValue(dataObj.getResFieldTransInvCost());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYTWO);
					cell.setCellStyle(sumCalStyle);
					cell.setCellValue(dataObj.getResEngFieldTransCost());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYTHREE);
					cell.setCellStyle(sumCalStyle);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYFOUR);
					cell.setCellStyle(sumCalStyle);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYFIVE);
					cell.setCellStyle(sumCalStyle);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYSIX);
					cell.setCellStyle(sumCalStyle);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYSEVEN);
					cell.setCellStyle(sumCalStyle);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYEIGHT);
					cell.setCellStyle(sumCalStyle);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWENTYNINE);
					cell.setCellStyle(sumCalStyle);
					}
		  	   }
			
             	row = (SXSSFRow) sheet.createRow(++rowcount);
             	row = (SXSSFRow) sheet.createRow(++rowcount);
             	
             	if(gasFlag){
             		
         		 cell = (SXSSFCell)row.createCell(0);
	    		 cell. setCellValue(costSmryGas);
	    		 cell.setCellStyle(headerStyle);
	    		 
	    		 cell = (SXSSFCell)row.createCell(1);
	    		 cell. setCellValue("");
	    		 cell.setCellStyle(headerStyle);
	    		 
	    		 for(int gas=0;gas<gasGrpList.size();gas++){
	    		  
	    		  PLMCostCycleSmryData dataObj1 = (PLMCostCycleSmryData) gasGrpList.get(gas);
	    		 
	    		  row = (SXSSFRow) sheet.createRow(++rowcount);
	    		  
	    		    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellStyle(sumCalStyle);
					cell.setCellValue(dataObj1.getTotalCostSmry());
					
					if(dataObj1.isSumFlag()){
					 cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
					 cell.setCellStyle(sumCalStyle);
					 cell.setCellValue(dataObj1.getPrdSiteFieldTranCost());
					}else{
					  cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
					  cell.setCellStyle(cellStyle);
					  cell.setCellValue(dataObj1.getPrdSiteFieldTranCost());
					}
	    		 
	    		  }
             		
             	}
             	
             	if(genFlag){
             		
            	 cell = (SXSSFCell)row.createCell(0);
   	    		 cell. setCellValue(costSmryGen);
   	    		 cell.setCellStyle(headerStyle);
   	    		 
   	    		 cell = (SXSSFCell)row.createCell(1);
   	    		 cell. setCellValue("");
   	    		 cell.setCellStyle(headerStyle);
   	    		 
   	    		 for(int gen=0;gen<genGrpList.size();gen++){
   	    		  
   	    		  PLMCostCycleSmryData dataObj2 = (PLMCostCycleSmryData) genGrpList.get(gen);
   	    		 
   	    		  row = (SXSSFRow) sheet.createRow(++rowcount);
   	    		  
   	    		    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
   					cell.setCellStyle(sumCalStyle);
   					cell.setCellValue(dataObj2.getTotalCostSmry());
   					
   					if(dataObj2.isSumFlag()){
   					 cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
   					 cell.setCellStyle(sumCalStyle);
   					 cell.setCellValue(dataObj2.getPrdSiteFieldTranCost());
   					}else{
   					  cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
   					  cell.setCellStyle(cellStyle);
   					  cell.setCellValue(dataObj2.getPrdSiteFieldTranCost());
   					}
   	    		  }
                }
             	
             	if(steamFlag){
             		
            	 cell = (SXSSFCell)row.createCell(0);
   	    		 cell. setCellValue(costSmrySteam);
   	    		 cell.setCellStyle(headerStyle);
   	    		 
   	    		 cell = (SXSSFCell)row.createCell(1);
   	    		 cell. setCellValue("");
   	    		 cell.setCellStyle(headerStyle);
   	    		 
   	    		 for(int steam=0;steam<steamGrpList.size();steam++){
   	    		  
   	    		  PLMCostCycleSmryData dataObj3 = (PLMCostCycleSmryData) steamGrpList.get(steam);
   	    		 
   	    		  row = (SXSSFRow) sheet.createRow(++rowcount);
   	    		  
   	    		    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
   					cell.setCellStyle(sumCalStyle);
   					cell.setCellValue(dataObj3.getTotalCostSmry());
   					
   					if(dataObj3.isSumFlag()){
   					 cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
   					 cell.setCellStyle(sumCalStyle);
   					 cell.setCellValue(dataObj3.getPrdSiteFieldTranCost());
   					}else{
   					  cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
   					  cell.setCellStyle(cellStyle);
   					  cell.setCellValue(dataObj3.getPrdSiteFieldTranCost());
   					}
   	    		  }
                }
             	
            	if(totalCostFlag){
             		
      	    		 for(int total=0;total<totalCostList.size();total++){
      	    		  
      	    		  PLMCostCycleSmryData dataObj4 = (PLMCostCycleSmryData) totalCostList.get(total);
      	    		 
      	    		  row = (SXSSFRow) sheet.createRow(++rowcount);
      	    		  
      	    		    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
      					cell.setCellStyle(sumCalStyle);
      					cell.setCellValue(dataObj4.getTotalCostSmry());
      					
      					 cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
      					 cell.setCellStyle(sumCalStyle);
      					 cell.setCellValue(dataObj4.getPrdSiteFieldTranCost());
      	    		  }
                  }

            	 row = (SXSSFRow) sheet.createRow(++rowcount);
            	 row = (SXSSFRow) sheet.createRow(++rowcount);
            	 
			    XSSFCellStyle ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
			    ftrStyle.setFont(font);
			    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
			    cell.setCellStyle(ftrStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_TWO));

				sheet.setColumnWidth(0,35*256);
				sheet.setColumnWidth(1,35*256);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWO);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_THREE);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_FOUR);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_FIVE);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_SIX);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_SEVEN);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_EIGHT);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_NINE);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TEN);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ELEVEN);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWELVE);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_THIRTEEN);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_FOURTEEN);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_FIFTEEN);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_SIXTEEN);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_SEVENTEEN);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_EIGHTEEN);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_NINETEEN);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWENTY);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWENTYONE);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWENTYTWO);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWENTYTHREE);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWENTYFOUR);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWENTYFIVE);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWENTYSIX);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWENTYSEVEN);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWENTYEIGHT);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWENTYNINE);
			
				
				sheet.setColumnWidth(2,15*256);
			
            workbook.write(outputStream);
			
			outputStream.flush();
			
			outputStream.close();
			
		} catch (IOException ioex) {
			ioex.printStackTrace();
		} finally {
			facesContext.responseComplete();
	  	}
		LOG.info("Exiting downloadCIRExcel Method");
		
		
		
		/*LOG.info("Entering downloadExcel Method");
		String reportName="costCycleSmryResultExcel";
		String fileName="Cost and Cycle Summary Report";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		try {
			FacesContext facesContext = FacesContext.getCurrentInstance();

			HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();

			response.setHeader("content-disposition","attachment; filename="+fileName+".xls");

			response.setContentType("application/vnd.ms-excel");
			
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@downloadExcel: ", exception);
		} 
		
		LOG.info("Exiting downloadExcel Method");
		return reportName;*/
		
	} 	

	/**
	 * @return the costCycleSmryData
	 */
	public PLMCostCycleSmryData getCostCycleSmryData() {
		return costCycleSmryData;
	}

	/**
	 * @param costCycleSmryData the costCycleSmryData to set
	 */
	public void setCostCycleSmryData(PLMCostCycleSmryData costCycleSmryData) {
		this.costCycleSmryData = costCycleSmryData;
	}	

	/**
	 * @return the plmCostCycleSmryService
	 */
	public PLMCostCycleSmryServiceIfc getPlmCostCycleSmryService() {
		return plmCostCycleSmryService;
	}

	/**
	 * @param plmCostCycleSmryService the plmCostCycleSmryService to set
	 */
	public void setPlmCostCycleSmryService(
			PLMCostCycleSmryServiceIfc plmCostCycleSmryService) {
		this.plmCostCycleSmryService = plmCostCycleSmryService;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the multipleContract
	 */
	public boolean isMultipleContract() {
		return multipleContract;
	}

	/**
	 * @param multipleContract the multipleContract to set
	 */
	public void setMultipleContract(boolean multipleContract) {
		this.multipleContract = multipleContract;
	}

	/**
	 * @return the contractList
	 */
	public List<PLMCostCycleSmryData> getContractList() {
		return contractList;
	}

	/**
	 * @param contractList the contractList to set
	 */
	public void setContractList(List<PLMCostCycleSmryData> contractList) {
		this.contractList = contractList;
	}

	/**
	 * @return the contractDDList
	 */
	public List<SelectItem> getContractDDList() {
		return contractDDList;
	}

	/**
	 * @param contractDDList the contractDDList to set
	 */
	public void setContractDDList(List<SelectItem> contractDDList) {
		this.contractDDList = contractDDList;
	}

	/**
	 * @return the contractDDList1
	 */
	public List<SelectItem> getContractDDList1() {
		return contractDDList1;
	}

	/**
	 * @param contractDDList1 the contractDDList1 to set
	 */
	public void setContractDDList1(List<SelectItem> contractDDList1) {
		this.contractDDList1 = contractDDList1;
	}

	/**
	 * @return the costCycleResultList
	 */
	public List<PLMCostCycleSmryData> getCostCycleResultList() {
		return costCycleResultList;
	}

	/**
	 * @param costCycleResultList the costCycleResultList to set
	 */
	public void setCostCycleResultList(
			List<PLMCostCycleSmryData> costCycleResultList) {
		this.costCycleResultList = costCycleResultList;
	}

	/**
	 * @return the custReq
	 */
	public String getCustReq() {
		return custReq;
	}

	/**
	 * @param custReq the custReq to set
	 */
	public void setCustReq(String custReq) {
		this.custReq = custReq;
	}

	/**
	 * @return the custReqDesc
	 */
	public String getCustReqDesc() {
		return custReqDesc;
	}

	/**
	 * @param custReqDesc the custReqDesc to set
	 */
	public void setCustReqDesc(String custReqDesc) {
		this.custReqDesc = custReqDesc;
	}

	/**
	 * @return the custReqSpec
	 */
	public String getCustReqSpec() {
		return custReqSpec;
	}

	/**
	 * @param custReqSpec the custReqSpec to set
	 */
	public void setCustReqSpec(String custReqSpec) {
		this.custReqSpec = custReqSpec;
	}

	/**
	 * @return the crState
	 */
	public String getCrState() {
		return crState;
	}

	/**
	 * @param crState the crState to set
	 */
	public void setCrState(String crState) {
		this.crState = crState;
	}

	/**
	 * @return the contract
	 */
	public String getContract() {
		return contract;
	}

	/**
	 * @param contract the contract to set
	 */
	public void setContract(String contract) {
		this.contract = contract;
	}

	/**
	 * @return the contractDesc
	 */
	public String getContractDesc() {
		return contractDesc;
	}

	/**
	 * @param contractDesc the contractDesc to set
	 */
	public void setContractDesc(String contractDesc) {
		this.contractDesc = contractDesc;
	}

	/**
	 * @return the recordCount
	 */
	public int getRecordCount() {
		return recordCount;
	}

	/**
	 * @param recordCount the recordCount to set
	 */
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	/**
	 * @return the costCycleResultMap
	 */
	public Map<String, List<PLMCostCycleSmryData>> getCostCycleResultMap() {
		return costCycleResultMap;
	}

	/**
	 * @param costCycleResultMap the costCycleResultMap to set
	 */
	public void setCostCycleResultMap(
			Map<String, List<PLMCostCycleSmryData>> costCycleResultMap) {
		this.costCycleResultMap = costCycleResultMap;
	}

	/**
	 * @return the genGrpList
	 */
	public List<PLMCostCycleSmryData> getGenGrpList() {
		return genGrpList;
	}

	/**
	 * @param genGrpList the genGrpList to set
	 */
	public void setGenGrpList(List<PLMCostCycleSmryData> genGrpList) {
		this.genGrpList = genGrpList;
	}

	/**
	 * @return the steamGrpList
	 */
	public List<PLMCostCycleSmryData> getSteamGrpList() {
		return steamGrpList;
	}

	/**
	 * @param steamGrpList the steamGrpList to set
	 */
	public void setSteamGrpList(List<PLMCostCycleSmryData> steamGrpList) {
		this.steamGrpList = steamGrpList;
	}

	/**
	 * @return the gasGrpList
	 */
	public List<PLMCostCycleSmryData> getGasGrpList() {
		return gasGrpList;
	}

	/**
	 * @param gasGrpList the gasGrpList to set
	 */
	public void setGasGrpList(List<PLMCostCycleSmryData> gasGrpList) {
		this.gasGrpList = gasGrpList;
	}

	/**
	 * @return the gasFlag
	 */
	public boolean isGasFlag() {
		return gasFlag;
	}

	/**
	 * @param gasFlag the gasFlag to set
	 */
	public void setGasFlag(boolean gasFlag) {
		this.gasFlag = gasFlag;
	}

	/**
	 * @return the genFlag
	 */
	public boolean isGenFlag() {
		return genFlag;
	}

	/**
	 * @param genFlag the genFlag to set
	 */
	public void setGenFlag(boolean genFlag) {
		this.genFlag = genFlag;
	}

	/**
	 * @return the steamFlag
	 */
	public boolean isSteamFlag() {
		return steamFlag;
	}

	/**
	 * @param steamFlag the steamFlag to set
	 */
	public void setSteamFlag(boolean steamFlag) {
		this.steamFlag = steamFlag;
	}

	/**
	 * @return the costSmryGen
	 */
	public String getCostSmryGen() {
		return costSmryGen;
	}

	/**
	 * @param costSmryGen the costSmryGen to set
	 */
	public void setCostSmryGen(String costSmryGen) {
		this.costSmryGen = costSmryGen;
	}

	/**
	 * @return the costSmryGas
	 */
	public String getCostSmryGas() {
		return costSmryGas;
	}

	/**
	 * @param costSmryGas the costSmryGas to set
	 */
	public void setCostSmryGas(String costSmryGas) {
		this.costSmryGas = costSmryGas;
	}

	/**
	 * @return the costSmrySteam
	 */
	public String getCostSmrySteam() {
		return costSmrySteam;
	}

	/**
	 * @param costSmrySteam the costSmrySteam to set
	 */
	public void setCostSmrySteam(String costSmrySteam) {
		this.costSmrySteam = costSmrySteam;
	}

	/**
	 * @return the totalCostList
	 */
	public List<PLMCostCycleSmryData> getTotalCostList() {
		return totalCostList;
	}

	/**
	 * @param totalCostList the totalCostList to set
	 */
	public void setTotalCostList(List<PLMCostCycleSmryData> totalCostList) {
		this.totalCostList = totalCostList;
	}

	/**
	 * @return the totalCostFlag
	 */
	public boolean isTotalCostFlag() {
		return totalCostFlag;
	}

	/**
	 * @param totalCostFlag the totalCostFlag to set
	 */
	public void setTotalCostFlag(boolean totalCostFlag) {
		this.totalCostFlag = totalCostFlag;
	}

	/**
	 * @return the heightPX
	 */
	public String getHeightPX() {
		return heightPX;
	}

	/**
	 * @param heightPX the heightPX to set
	 */
	public void setHeightPX(String heightPX) {
		this.heightPX = heightPX;
	}

	/**
	 * @return the heightPX1
	 */
	public String getHeightPX1() {
		return heightPX1;
	}

	/**
	 * @param heightPX1 the heightPX1 to set
	 */
	public void setHeightPX1(String heightPX1) {
		this.heightPX1 = heightPX1;
	}

	/**
	 * @return the crsName
	 */
	public String getCrsName() {
		return crsName;
	}

	/**
	 * @param crsName the crsName to set
	 */
	public void setCrsName(String crsName) {
		this.crsName = crsName;
	}

	/**
	 * @return the noCostGrpFound
	 */
	public String getNoCostGrpFound() {
		return noCostGrpFound;
	}

	/**
	 * @param noCostGrpFound the noCostGrpFound to set
	 */
	public void setNoCostGrpFound(String noCostGrpFound) {
		this.noCostGrpFound = noCostGrpFound;
	}

	
	
	

}
