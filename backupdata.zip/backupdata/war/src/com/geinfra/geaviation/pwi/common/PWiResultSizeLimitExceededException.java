/**
 * Project        :	  PWi Development
 * Date Written   :   May 2010
 * Security       :   GE Confidential
 * Restrictions   :   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 * Copyright(C) 2009 GE 
 * All rights reserved
 *
 * Description    :  This is Exception Class to catch the Exceptions.
 *
 * --------------------------------------------------------------
 */

package com.geinfra.geaviation.pwi.common;

/**
 * Project : Product Lifecycle Management Date Written : May 18, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Exception intended for when a user attempts to access a query
 * they don't have privileges to.
 * 
 * Revision Log May 18, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiResultSizeLimitExceededException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public PWiResultSizeLimitExceededException(String message) {
		super(message);
	}
}
