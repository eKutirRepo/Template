package com.geinfra.geaviation.pwi.model;

import java.io.InputStream;
import java.io.Reader;
import java.io.Serializable;
import java.sql.NClob;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Locale;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.util.QueryProcessingUtil;

/**
 * Project:      Product Lifecycle Management Intelligence
 * Module:       PWiResultSet.java
 * Author:       Sandeep Chaturvedi
 * Project:      Design Center
 * Date-Written: April 2001
 * Security:     GE Confidential
 * Restrictions: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 * Copyright(C) 2012 GE All rights reserved
 *
 * This is PLMi-specific "implementation" of java.sql.ResultSet <i>and</i>
 * java.sql.ResultSetMetaData.
 * This ResultSet has no link back to the original database; all data is stored
 * in an <code>ArrayList&lt;ArrayList&lt;String&gt;&gt;</code>--so
 * <code>getObject</code> will return a String.
 * 
 * <P>
 * A <code>PWiResultSet</code> object is flexible for reading data in any
 * sequence and any particular row can be fetched. Initially the cursor is
 * positioned before the first row. The <code>next</code> method moves the
 * cursor to the next row, and because it returns <code>false</code> when there
 * are no more rows in the <code>PWiResultSet</code> object, it can be used in
 * a <code>while</code> loop to iterate through the result set.
 * <P>
 * <code>PWiResultSet</code> object is not updatable and is scrollable in both
 * forward and backward directions.
 * 
 * <PRE>
 * 
 *       PWiResultSet PWirs = QueryProcessingUtil.getInstance()
 *               .executeQuery(QueryType queryType, String dataSource,
 *                       TemplateEval templateEval,
 *                       int queryTimeoutSecs, int resultSizeLimit);
 *       // rs will be scrollable, will not show changes made in the database
 * 
 * </PRE>
 * 
 * The <code>PWiResultSet</code> interface provides <code>getXXX</code> methods
 * for retrieving column values from the current row. Values can be retrieved
 * using either the index number of the column or the name of the column.
 * Columns can be read in any sequence.
 * 
 * <P>
 * Since data is already cached and metadata for ResultSet is also stored in
 * <code>PWiResultSet</code>, no further calls are made to database.
 * <P>
 * <P>
 * Column names used as input to <code>getXXX</code> methods are case
 * insensitive. The column name option is designed to be used when column names
 * are used in the SQL query that generated the result set. For columns that are
 * NOT explicitly named in the query, it is best to use column numbers. If
 * column names are used, there is no way for the programmer to guarantee that
 * they actually refer to the intended columns.
 * <P>
 * <P>
 * <code>SQLException</code> has, in many cases, been replaced with
 * <code>IndexOutOfBoundsException</code> for attempts to access a nonexistent
 * column, either by index or name, and many of the operations we do not use
 * throw an <code>UnsupportedOperationException</code>.  (As a general rule,
 * methods implemented by <code>PWiAbstractResultSet</code> either throw this
 * exception or do nothing.
 * <P>
 * <P>
 * It is highly recommended to clear <code>PWiResultSet</code> object using
 * close() method once <code>PWiResultSet</code> is not of any further use.
 * 
 * <P>
 * @see QueryProcessingUtil#executeQuery
 * 
 * Revision Log:
 * -----------------------------------------------------------------------------
 *  07/25/2001  Sandeep  Changed findcolumn - removed to UpperCase();
 *                       commented  line in sort to setrowsetStop
 * 	09/06/2001	pjh      made setData() method public
 *  09/23/2004  Parimala Implemented the methods getBinaryStream, getBigDecimal
 *                       getColumnLabel, getCatalogName
 *  10/29/2004  Parimala Added new methods to support
 *                       oracle 9i data types
 *  03/29/2005  Parimala Added methods getDownloadColumnHeading,
 *                       setColumnHeading(int colIndex, GEAETag columnTag)
 *                       and updated getColumnHeading to solve the issue of
 *                       getting html tag for column names in Excel,PDF and
 *                       CSV downloads. Ref. to Case #2456542
 *  12/12/2012  Hasso    Updated package to com.geinfra.geaviation.pwi.model
 *                       (was geae.dao.GEAEResultSet).
 *  12/21/2012  Hasso    Cleared clutter, improved sort algorithm,
 *                       reordered methods to a more-sensible order,
 *                       further exposed data and metadata to improve append and
 *                       conversion performance 
 *  01/22/2012  Hasso    Removed depricated getBigDecimal methods; moved them to
 *                       PWiAbstractResultSet as unimplemented.
 */
public class PWiResultSet extends PWiAbstractResultSet implements
		Serializable {
	private static final long serialVersionUID = 8004977425441045294L;
	private static final Logger LOGGER = Logger
			.getLogger(PWiResultSet.class);
	private ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();
	private HashMap<String, Integer> htColIdxByName =
		new HashMap<String, Integer>();
	private HashMap<Integer, PWiResultSetColMetaData> htColMdByIdx =
		new HashMap<Integer, PWiResultSetColMetaData>();
	private int rowcounter; // automatically initialized to 0
	private ArrayList<String> row;

	/**
	 * Retrieves the current row number. The first row is number 1, the second
	 * number 2, and so on.
	 * 
	 * @return the current row number; <code>0</code> if there is no current row
	 */
	public int getRow() {
		return rowcounter;
	}

	/**
	 * Moves the cursor down one row from its current position. A
	 * <code>PWiResultSet</code> cursor is initially positioned before the
	 * first row; the first call to the method <code>next</code> makes the first
	 * row the current row; the second call makes the second row the current
	 * row, and so on.
	 * 
	 * @return <code>true</code> if the new current row is valid;
	 *         <code>false</code> if there are no more rows
	 */
	public boolean next() {
		boolean nextBool;

		if (this.rowcounter >= this.size()) {
			nextBool = false;
		} else {
			nextBool = true;
			row = data.get(rowcounter);
			rowcounter++;
		}
		return nextBool;
	}

	/**
	 * Moves the cursor to the first row in this <code>PWiResultSet</code>
	 * object.
	 * 
	 * @return <code>true</code> if the cursor is on a valid row;
	 *         <code>false</code> if there are no rows in the result set
	 */
	public boolean first() {
		rowcounter = 0;
		return this.next();
	}

	/**
	 * Moves the cursor to the last row in this <code>PWiResultSet</code>
	 * object.
	 * 
	 * @return <code>true</code> if the cursor is on a valid row;
	 *         <code>false</code> if there are no rows in the result set
	 */
	public boolean last() {
		if (this.size() == 0) return false;
		rowcounter = this.size() - 1;
		return this.next();
	}

	/**
	 * Moves the cursor to the previous row in this <code>PWiResultSet</code>
	 * object.
	 * 
	 * @return <code>true</code> if the cursor is on a valid row;
	 *         <code>false</code> if it is off the result set
	 */
	public boolean previous() {
		if (rowcounter <= 1) {
			// we are on or before the first row, so no previous rows
			return false;
		}
		// -2+1=-1 (step back once)
		rowcounter -= 2;
		return next();
	}

	/**
	 * Sorts the result set by all columns, left to right
	 */
	public void sort() {
		this.rowcounter = 0;
		this.row = null;
		final int numCols = this.getColumnCount();
	
		Comparator<ArrayList<String>> eachColCaseInsensitiveOrder =
			new Comparator<ArrayList<String>>() {
			public int compare(ArrayList<String> one, ArrayList<String> two) {
				for (int col = 0; col < numCols; col++) {
					int comp = String.CASE_INSENSITIVE_ORDER.compare(
							one.get(col), two.get(col));
					if (comp != 0) {
						return comp;
					}
				} // end for
				return 0; // all columns are equal
			}
	
			//public boolean equals(Object object) { return false; }
			public int hashCode() { return numCols; }
		};
	
		Collections.sort(data, eachColCaseInsensitiveOrder);
	}

	// ======================================================================
	// Methods for accessing results by column index and name
	// ======================================================================
	/**
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param colName
	 *            the SQL name of the column
	 * @return the column value; if the value is SQL <code>NULL</code>, the
	 *         value returned is <code>""</code> (the empty string)
	 * @SQLException is not thrown, because no database access error occurs
	 * @UnsupportedOperationException by <code>PWiAbstractResultSet</code> for
	 *            methods not implemented by <code>PWiResultSet</code>
	 */
	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>String</code> in the Java
	 * programming language.
	 * 
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getString(int columnIndex) {
		return row.get(columnIndex - 1);
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>String</code> in the Java
	 * programming language.
	 * 
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getString(String colName) {
		return getString(findColumn(colName));
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>long</code> in the Java
	 * programming language.
	 * 
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public long getLong(int columnIndex) {
		return Long.parseLong(getString(columnIndex));
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>long</code> in the Java
	 * programming language.
	 * 
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public long getLong(String colName) {
		return getLong(findColumn(colName));
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>float</code> in the Java
	 * programming language.
	 * 
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public float getFloat(int columnIndex) {
		return Float.parseFloat(getString(columnIndex));
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>float</code> in the Java
	 * programming language.
	 * 
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public float getFloat(String colName) {
		return getFloat(findColumn(colName));
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>boolean</code> in the Java
	 * programming language.
	 * 
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public boolean getBoolean(int columnIndex) {
		return Boolean.parseBoolean(getString(columnIndex));
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>boolean</code> in the Java
	 * programming language.
	 * 
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public boolean getBoolean(String colName) {
		return getBoolean(findColumn(colName));
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>int</code> in the Java
	 * programming language.
	 * 
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public int getInt(int columnIndex) {
		return Integer.parseInt(getString(columnIndex));
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>int</code> in the Java
	 * programming language.
	 * 
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public int getInt(String colName) {
		return getInt(findColumn(colName));
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>double</code> in the Java
	 * programming language.
	 * 
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public double getDouble(int columnIndex) {
		return Double.parseDouble(getString(columnIndex));
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>double</code> in the Java
	 * programming language.
	 * 
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public double getDouble(String colName) {
		return getDouble(findColumn(colName));
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>short</code> in the Java
	 * programming language.
	 * 
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public short getShort(int columnIndex) {
		return Short.parseShort(getString(columnIndex));
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>short</code> in the Java
	 * programming language.
	 * 
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public short getShort(String colName) {
		return getShort(findColumn(colName));
	}

	public byte[] getBytes(int columnIndex) {
		return getString(columnIndex).getBytes();
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>java.sql.Time</code> in the
	 * Java programming language.
	 * 
	 */
	public java.sql.Time getTime(int columnIndex) throws SQLException {
		return new java.sql.Time(getLong(columnIndex));
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as a <code>java.sql.Time</code> in the
	 * Java programming language.
	 * 
	 */
	public java.sql.Time getTime(String colName) throws SQLException {
		return getTime(findColumn(colName));
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as an <code>Object</code> in the Java
	 * programming language.  This "<code>Object</code>" just so happens to be a
	 * <code>String</code>, because that's how we store everything.
	 */
	public Object getObject(int columnIndex) {
		return getString(columnIndex);
	}

	/**
	 * Gets the value of the designated column in the current row of this
	 * <code>PWiResultSet</code> object as an <code>Object</code> in the Java
	 * programming language.  This "<code>Object</code>" just so happens to be a
	 * <code>String</code>, because that's how we store everything.
	 */
	public Object getObject(String colName) {
		return getObject(findColumn(colName));
	}

	/**
	 * Update a column with a String value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 */
	public void updateString(int columnIndex, String val) {
		row.set(columnIndex - 1, val == null ? "" : val);
	}
	
	public void updateString(String columnName, String val) {
		updateString(findColumn(columnName), val);
	}

	public void updateObject(int columnIndex, Object val)
			throws SQLException {
		row.set(columnIndex - 1, val == null ? "" : val.toString());
	}

	public void updateObject(String columnName, Object val)
			throws SQLException {
		updateObject(findColumn(columnName), val);
	}

	public ArrayList<String> getRowData() {
		return row;
	}
	
	// TODO pH 2013.01: needed? test custom executors
	// pH 2013.01: per code review, this should be safe to omit; however,
	// we may still wish to test
	private static void checkNulls(ArrayList<String> row) {
		for(int i = 0; i < row.size(); i++) {
			if (row.get(i) == null) {
				row.set(i, "");
				LOGGER.error("column " + i, new NullPointerException());
			}
		}
	}

	/**
	 * Overrides all data and metadata
	 * 
	 * @param data is an ArrayList of complete rows of data. It is the
	 *              responsibility of the client to ensure that each row in
	 *              <code>data</code> is complete and contains no null values.
	 * @param htColIdxByName allows column indices to be found by column name.
	 * @param htColMdByIdx contains metadata for each column
	 */
	public void setData(ArrayList<ArrayList<String>> dataIn,
				HashMap<String, Integer> htColIdxByNameIn,
				HashMap<Integer, PWiResultSetColMetaData> htColMdByIdxIn) {
		for (ArrayList<String> rowIn : dataIn) {
			checkNulls(rowIn);
		}
		this.data = dataIn;
		this.htColMdByIdx = htColMdByIdxIn;
		this.htColIdxByName = htColIdxByNameIn;
	}

	/**
	 * adds one row of data
	 * 
	 * @param row
	 *            is the complete row of data in the form of a ArrayList.
	 *            It is the responsibility of the client to ensure that row
	 *            is complete and there are no null values in row.
	 */
	public void addRow(ArrayList<String> rowIn) {
		checkNulls(rowIn);
		data.add(rowIn);
	}

	/**
	 * Clears the <code>PWiResultSet</code> instance.
	 */
	public void close() {
		this.data = null;
		this.row = null;
		this.htColMdByIdx = null;
		this.htColIdxByName = null;
	}

	public boolean wasNull() {
		return false;
	}

	/**
	 * returns the number of rows fetched from database and stored in this
	 * <code>PWiResultSet</code>
	 */
	public int size() {
		return data.size();
	}

	/**
	 * Maps the given <code>PWiResultSet</code> column name to its
	 * <code>PWiResultSet</code> column index.
	 * 
	 * @param colName String - the name of the column to find
	 * @return int - the index of the column with the specified name, or
	 * <code>PWiConstants.UNDEFINED_INDEX</code> if the name is not found
	 */
	public int findColumn(String colName) {
		Integer colIdx =  htColIdxByName.get(colName.toUpperCase(Locale.US));
		if (colIdx == null){
			if (LOGGER.isDebugEnabled()){
				LOGGER.debug(new IndexOutOfBoundsException(new StringBuffer()
					.append("Invalid column name '").append(colName)
					.append('\'').toString()));
			}
			return PWiConstants.UNDEFINED_INDEX;
		}
		return colIdx.intValue();
	}

	public ResultSetMetaData getMetaData() {
		return this;
	}

	//==========================================================================
	// The methods below implement java.sql.ResultSetMetaData.
	//==========================================================================
	
	/**
	 * Returns the number of columns in this <code>PWiResultSet</code> object.
	 * 
	 * @return the number of columns
	 */
	public int getColumnCount() {
		return htColMdByIdx.size();
	}

	/**
	 * <p>
	 * Returns the fully-qualified name of the Java class whose instances are
	 * manufactured if the method <code>PWiResultSet.getObject</code> is called
	 * to retrieve a value from the column. <code>PWiResultSet.getObject</code>
	 * may return a subclass of the class returned by this method.
	 * 
	 * @return the fully-qualified name of the class in the Java programming
	 *         language that would be used by the method
	 *         <code>PWiResultSet.getObject</code> to retrieve the value in the
	 *         specified column. This is the class name used for custom mapping.
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getColumnClassName(int colindex) {
		return getColumnMetaData(colindex).colclassname;
	}

	/**
	 * Get the designated column's number of decimal digits.
	 * 
	 * @return precision
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public int getPrecision(int colindex) {
		return getColumnMetaData(colindex).precision;
	}

	/**
	 * Gets the designated column's number of digits to right of the decimal
	 * point.
	 * 
	 * @return scale
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public int getScale(int colindex) {
		return getColumnMetaData(colindex).scale;
	}

	/**
	 * Get the designated column's table's schema.
	 * 
	 * @return schema name or "" if not applicable
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getSchemaName(int colindex) {
		return getColumnMetaData(colindex).schema;
	}

	/**
	 * Gets the designated column's table name.
	 * 
	 * @return table name or "" if not applicable
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getTableName(int colindex) {
		return getColumnMetaData(colindex).table;
	}

	/**
	 * Indicates whether the designated column is a cash value.
	 * 
	 * @return <code>true</code> if so; <code>false</code> otherwise
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public boolean isCurrency(int colindex) {
		return getColumnMetaData(colindex).iscurrency;
	}

	/**
	 * Retrieves the designated column's SQL type.
	 * 
	 * @return SQL type from java.sql.Types
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 * @see java.sql.Types
	 */
	public int getColumnType(int colindex) {
		return getColumnMetaData(colindex).coltype;
	}

	/**
	 * Retrieves the designated column's database-specific type name.
	 * 
	 * @return type name used by the database. If the column type is a
	 *         user-defined type, then a fully-qualified type name is returned.
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getColumnTypeName(int colindex) {
		return getColumnMetaData(colindex).coltypename;
	}

	/**
	 * Get the designated column's name.
	 * 
	 * @param column
	 *            the first column is 1, the second is 2, ...
	 * @return column name
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getColumnName(int colindex) {
		return getColumnMetaData(colindex).colname;
	}
	
	/**
	 * Get the designated column's Label.
	 * 
	 * @param column
	 *            the first column is 1, the second is 2, ...
	 * @return column Label
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getColumnLabel(int colindex) {
		return getColumnMetaData(colindex).collabel;
	}

	/**
	 * Get the designated column's Catalog Name.
	 * 
	 * @param column
	 *            the first column is 1, the second is 2, ...
	 * @return column the name of the catalog for the table in which the given
	 *         column appears or "" if not applicable
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getCatalogName(int colindex) {
		return getColumnMetaData(colindex).catalogname;
	}

	/**
	 * gets the Row Cache column name for the given index
	 * 
	 * @param colIndex
	 *            is the index of the column
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public String getColumnHeading(int colindex) {
		return getColumnMetaData(colindex).colheading;
	}
	
	/**
	 * @param colindex - index of the column
	 * @return metadata about the column
	 * @throws IndexOutOfBoundsException when called on an invalid column
	 */
	public PWiResultSetColMetaData getColumnMetaData(int colindex) {
		PWiResultSetColMetaData prscmd = htColMdByIdx.get(Integer.valueOf(colindex));
		if (prscmd == null) {
			throw new IndexOutOfBoundsException(new StringBuffer()
					.append("Invalid column index ")
					.append(colindex).toString());
		}
		return prscmd;
	}

	/**
	 * sets the Column Headings
	 * 
	 * @param colindex
	 *            is the index of the column
	 * @param colHeading
	 *            is the heading to display within the table
	 */
	public void setColumnHeading(int colindex, String colHeading) {
		if (getColumnMetaData(colindex) != null)
			getColumnMetaData(colindex).colheading = colHeading;
		else {
			PWiResultSetColMetaData PWirscmd_tmp = new PWiResultSetColMetaData();
			PWirscmd_tmp.colheading = colHeading;
			htColMdByIdx.put(Integer.valueOf(colindex), PWirscmd_tmp);
		}
	}

	public void setColumnNames(ArrayList<String> selectColumns)
			throws SQLException {
		if (htColIdxByName.size() > 0) {
			throw new SQLException("ResultSetMetaData cannot be overridden.");
		}

		for (int i = 1; i <= selectColumns.size(); i++) {
			PWiResultSetColMetaData PWirscmd = new PWiResultSetColMetaData();
			PWirscmd.colname = selectColumns.get(i - 1).toUpperCase(Locale.US);
			htColIdxByName.put(PWirscmd.colname, Integer.valueOf(i));
			htColMdByIdx.put(Integer.valueOf(i), PWirscmd);
		}
	}

	public int isNullable(int column) {
		return ResultSetMetaData.columnNoNulls;
	}

	public boolean isSigned(int column) {
		return false;
	}

	public boolean isReadOnly(int column) {
		return false;
	}

	public boolean isWritable(int column) {
		return false;
	}

	public boolean isDefinitelyWritable(int column) {
		return false;
	}

	public boolean isAutoIncrement(int column) {
		return false;
	}

	public boolean isCaseSensitive(int column) {
		return false;
	}

	public boolean isSearchable(int column) {
		return false;
	}

	public int getColumnDisplaySize(int column) {
		return 10; // the display size of all columns in GEAEResultSet is 10.
	}

	@Override
	public int getHoldability() throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Reader getNCharacterStream(int columnIndex) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Reader getNCharacterStream(String columnLabel) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NClob getNClob(int columnIndex) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NClob getNClob(String columnLabel) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getNString(int columnIndex) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getNString(String columnLabel) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RowId getRowId(int columnIndex) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RowId getRowId(String columnLabel) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SQLXML getSQLXML(int columnIndex) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SQLXML getSQLXML(String columnLabel) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isClosed() throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void updateAsciiStream(int columnIndex, InputStream inputStrm)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateAsciiStream(String columnLabel, InputStream inputStrm)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateAsciiStream(int columnIndex, InputStream inputStrm, long length)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateAsciiStream(String columnLabel, InputStream inputStrm, long length)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBinaryStream(int columnIndex, InputStream inputStrm)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBinaryStream(String columnLabel, InputStream inputStrm)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBinaryStream(int columnIndex, InputStream inputStrm, long length)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBinaryStream(String columnLabel, InputStream inputStrm,
			long length) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBlob(int columnIndex, InputStream inputStream)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBlob(String columnLabel, InputStream inputStream)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBlob(int columnIndex, InputStream inputStream, long length)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBlob(String columnLabel, InputStream inputStream,
			long length) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateCharacterStream(int columnIndex, Reader reader)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateCharacterStream(String columnLabel, Reader reader)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateCharacterStream(int columnIndex, Reader reader, long length)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateCharacterStream(String columnLabel, Reader reader,
			long length) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateClob(int columnIndex, Reader reader) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateClob(String columnLabel, Reader reader)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateClob(int columnIndex, Reader reader, long length)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateClob(String columnLabel, Reader reader, long length)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateNCharacterStream(int columnIndex, Reader reader)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateNCharacterStream(String columnLabel, Reader reader)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateNCharacterStream(int columnIndex, Reader reader, long length)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateNCharacterStream(String columnLabel, Reader reader,
			long length) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateNClob(int columnIndex, NClob nClob) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateNClob(String columnLabel, NClob nClob)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateNClob(int columnIndex, Reader reader) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateNClob(String columnLabel, Reader reader)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateNClob(int columnIndex, Reader reader, long length)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateNClob(String columnLabel, Reader reader, long length)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateNString(int columnIndex, String nString)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateNString(String columnLabel, String nString)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateRowId(int columnIndex, RowId rwId) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateRowId(String columnLabel, RowId rwId) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateSQLXML(int columnIndex, SQLXML xmlObject)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateSQLXML(String columnLabel, SQLXML xmlObject)
			throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public <T> T unwrap(Class<T> iface) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}


	public <T> T getObject(int arg0, Class<T> arg1) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	
	public <T> T getObject(String arg0, Class<T> arg1) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	

}
