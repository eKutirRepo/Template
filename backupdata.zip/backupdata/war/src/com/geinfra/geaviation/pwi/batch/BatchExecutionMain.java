package com.geinfra.geaviation.pwi.batch;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.common.MainExecution;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 5, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : BatchExecutionMain - Main class for Batch Execution
 * 
 * Revision Log Aug 5, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class BatchExecutionMain {
	private static final Logger LOGGER = Logger
			.getLogger(BatchExecutionMain.class);
	private static final String BATCH_CONTEXT = "batchExecution";

	public static void main(String[] args) {
		try {
			
			/*
			 * args for running batch
			 * 
			 * "dev" "localhost" "D:\GEGDC\SD336397\PWi\pwiOnlineModeResult" "PLMR" "W4z_Xvo3oFNG" "GEEDW_D_PLMRPTG_WEB" 

			"gueiuserP7o9" "" "" "" "30" "WARN" "p:pwi=jdbc:oracle:thin:@pwdbos0407dp04.pw.ge.com:1521:eueoltda" 
											
			"s:plmrterads=jdbc:teradata://GEEDW_DEV_PLP.PW.GE.COM@userid:" "s:renew=jdbc:teradata://GEEDW_DEV_PLP.PW.GE.COM"
			
			*/
			// Initialize execution environment
			
			//c,E,N,Y
			
			MainExecution batchMain = new MainExecution(BATCH_CONTEXT, args);

			// Run job using execution environment
			BatchExecutionJob job = (BatchExecutionJob) batchMain
					.getBeanFromContext("batchExecutionJobBean");
			job.executeBatch(batchMain);
		} catch (Exception e) {
			LOGGER.fatal("Fatal Exception: ", e);
			System.exit(MainExecution.FAILED_EXIT_STATUS);
		}
		System.exit(MainExecution.SUCCEEDED_EXIT_STATUS);
	}
}
