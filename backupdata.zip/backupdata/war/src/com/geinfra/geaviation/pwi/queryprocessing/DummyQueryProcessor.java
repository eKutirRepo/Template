package com.geinfra.geaviation.pwi.queryprocessing;

import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.PWiResultSet;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;

/**
 * Project      : Product Lifecycle Management
 * Date Written : Apr 13, 2011 
 * Security     : GE Confidential 
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : DummyQueryProcessor
 * 
 * Revision Log Apr 13, 2011 | v1.0.
 * 2012.12.18 pH  replaced GEAEResultSet with PWiResultSet
 * --------------------------------------------------------------
 */
public class DummyQueryProcessor implements QueryProcessor {
	public static final String TYPE = "none";
	
	public PWiResultSet postProcess(PWiResultSet rs,
			Search search, List<String> selectedColumns, QueryType queryType) throws PWiException {
		// Do nothing, pass result set through
		return rs;
	}

	public void preProcess(SelectedColumns selectedColumns)
			throws PWiException {
		// Do nothing
	}

}
