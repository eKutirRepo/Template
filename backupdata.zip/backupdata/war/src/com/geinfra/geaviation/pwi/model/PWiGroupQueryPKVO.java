/*
//  @ Project : PWi
//  @ File Name : PWiUserCustomQueryVO.java
//  @ Date : 5/14/2010
//  @ Author : nisverma
 */
package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : PWiGroupQueryPKVO - Primary Key object for query group.
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiGroupQueryPKVO implements Serializable {
	private static final long serialVersionUID = 1L;
	private int qrySeqId;
	private int qryGrpSeqId;

	public PWiGroupQueryPKVO() {
	}

	public PWiGroupQueryPKVO(int qrySeqId, int qryGrpSeqId) {
		this.qrySeqId = qrySeqId;
		this.qryGrpSeqId = qryGrpSeqId;
	}

	public int getQrySeqId() {
		return qrySeqId;
	}

	public void setQrySeqId(int qrySeqId) {
		this.qrySeqId = qrySeqId;
	}

	public int getQryGrpSeqId() {
		return qryGrpSeqId;
	}

	public void setQryGrpSeqId(int qryGrpSeqId) {
		this.qryGrpSeqId = qryGrpSeqId;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (int) qrySeqId;
		hash += (int) qryGrpSeqId;
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object instanceof PWiGroupQueryPKVO) {
			PWiGroupQueryPKVO other = (PWiGroupQueryPKVO) object;
			return this.qrySeqId == other.qrySeqId
					&& this.qryGrpSeqId == other.qryGrpSeqId;
		}
		return false;
	}

	@Override
	public String toString() {
		return "com.geinfra.geaviation.pwi.model.PWiGroupQueryPK[qrySeqId="
				+ qrySeqId + ", qryGrpSeqId=" + qryGrpSeqId + "]";
	}

}
