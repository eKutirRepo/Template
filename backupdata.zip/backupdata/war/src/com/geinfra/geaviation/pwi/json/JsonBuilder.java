package com.geinfra.geaviation.pwi.json;

import java.util.Stack;

/**
 * 
 * Project      : Product Lifecycle Management Intelligence
 * Date Written : Jan 6, 2012
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : helps build and escape JSON (JavaScript Object Notation -
 *               strings representing objects to communicate between Java and
 *               JavaScript)
 * 
 * Revision Log Jan 6, 2012 | v1.0.
 * --------------------------------------------------------------
 */
public class JsonBuilder {
	private enum StackItem {
		OBJECT, ARRAY;
	}

	private Stack<StackItem> stack = new Stack<StackItem>();
	private boolean firstItem; // automatically initialized to false
	private StringBuilder builder = new StringBuilder();

	/**
	 * Get JSON string.
	 * 
	 * Will throw error if objects or arrays aren't ended.
	 */
	public String toString() {
		if (!stack.isEmpty()) {
			throw new IllegalStateException(
					"Failed to output JSON string. There exist objects or arrays that haven't been ended.  stack: "
							+ stack);
		}
		return builder.toString();
	}

	/**
	 * Start JSON object
	 */
	public void startObject() {
		if (!stack.isEmpty() && stack.peek() == StackItem.ARRAY) {
			if (!firstItem) {
				builder.append(",");
			}
		}

		builder.append("{");
		stack.push(StackItem.OBJECT);
		firstItem = true;
	}

	/**
	 * End JSON object.
	 */
	public void endObject() {
		if (stack.isEmpty() || stack.peek() != StackItem.OBJECT) {
			throw new IllegalStateException(
					"Failed to end object. The current state of the builder is not processing an object.  stack: "
							+ stack);
		}

		builder.append("}");
		stack.pop();
		firstItem = false;
	}

	/**
	 * Start a JSON array.
	 */
	public void startArray() {
		if (!stack.isEmpty() && stack.peek() == StackItem.ARRAY) {
			if (!firstItem) {
				builder.append(",");
			}
		}
		builder.append("[");
		stack.push(StackItem.ARRAY);
		firstItem = true;
	}

	/**
	 * End a JSON array.
	 */
	public void endArray() {
		if (stack.isEmpty() || stack.peek() != StackItem.ARRAY) {
			throw new IllegalStateException(
					"Failed to end array. The current state of the builder is not processing an array.  stack: "
							+ stack);
		}

		builder.append("]");
		stack.pop();
		firstItem = false;
	}

	/**
	 * Add a property to a JSON object by representing the specified name/value
	 * objects as JSON strings.
	 * 
	 * @param propertyName
	 * @param propertyValue
	 */
	public void addStringProperty(Object propertyName, Object propertyValue) {
		if (stack.isEmpty() || stack.peek() != StackItem.OBJECT) {
			throw new IllegalStateException(
					"Failed to add string property. The current state of the builder is not processing an object.  stack: "
							+ stack);
		}

		if (firstItem) {
			firstItem = false;
		} else {
			builder.append(",");
		}
		addEscapedString(propertyName);
		builder.append(":");
		addEscapedString(propertyValue);
	}

	/**
	 * Add a property to a JSON object by representing the specified name/value
	 * objects as JSON boolean.
	 * 
	 * @param propertyName
	 * @param propertyValue
	 */
	public void addBooleanProperty(Object propertyName, boolean propertyValue) {
		if (stack.isEmpty() || stack.peek() != StackItem.OBJECT) {
			throw new IllegalStateException(
					"Failed to add boolean property. The current state of the builder is not processing an object.  stack: "
							+ stack);
		}

		if (firstItem) {
			firstItem = false;
		} else {
			builder.append(",");
		}
		addEscapedString(propertyName);
		builder.append(":");
		if (propertyValue) {
			builder.append("true");
		} else {
			builder.append("false");
		}
	}

	/**
	 * Add a property to a JSON object by representing the specified name/value
	 * objects as JSON number.
	 * 
	 * @param propertyName
	 * @param propertyValue
	 */
	public void addNumberProperty(Object propertyName, int propertyValue) {
		if (stack.isEmpty() || stack.peek() != StackItem.OBJECT) {
			throw new IllegalStateException(
					"Failed to add boolean property. The current state of the builder is not processing an object.  stack: "
							+ stack);
		}

		if (firstItem) {
			firstItem = false;
		} else {
			builder.append(",");
		}
		addEscapedString(propertyName);
		builder.append(":");
		builder.append(propertyValue);
	}

	/**
	 * Start a JSON property for a JSON object where the value will be a JSON
	 * array.
	 * 
	 * Add JSON array elements after calling this method and then end the JSON
	 * array using the end array method.
	 * 
	 * @param propertyName
	 */
	public void startArrayProperty(Object propertyName) {
		if (stack.isEmpty() || stack.peek() != StackItem.OBJECT) {
			throw new IllegalStateException(
					"Failed to start array property. The current state of the builder is not processing an object.  stack: "
							+ stack);
		}

		if (firstItem) {
			firstItem = false;
		} else {
			builder.append(",");
		}
		addEscapedString(propertyName);
		builder.append(":");
		startArray();
	}

	/**
	 * Start a JSON property for a JSON object where the value will be another
	 * JSON object.
	 * 
	 * Add JSON object properties after calling this method and then end the
	 * JSON object using the end object method.
	 * 
	 * @param propertyName
	 */
	public void startObjectProperty(Object propertyName) {
		if (stack.isEmpty() || stack.peek() != StackItem.OBJECT) {
			throw new IllegalStateException(
					"Failed to start object property. The current state of the builder is not processing an object.  stack: "
							+ stack);
		}

		if (firstItem) {
			firstItem = false;
		} else {
			builder.append(",");
		}
		addEscapedString(propertyName);
		builder.append(":");
		startObject();
	}

	/**
	 * Add a Java object to a JSON array as a JSON string.
	 * 
	 * @param value
	 */
	public void addStringElement(Object value) {
		if (stack.isEmpty() || stack.peek() != StackItem.ARRAY) {
			throw new IllegalStateException(
					"Failed to add string.  The current state of the builder is not processing an array.  stack: "
							+ stack);
		}

		if (firstItem) {
			firstItem = false;
		} else {
			builder.append(",");
		}
		addEscapedString(value);
	}

	public void addRawJsonElement(String json) {
		if (stack.isEmpty() || stack.peek() != StackItem.ARRAY) {
			throw new IllegalStateException(
					"Failed to add string.  The current state of the builder is not processing an array.  stack: "
							+ stack);
		}

		if (firstItem) {
			firstItem = false;
		} else {
			builder.append(",");
		}
		builder.append(json);
	}
	
	private void addEscapedString(Object object) {
		if (object == null) {
			builder.append("null");
			return;
		}

		String string = object.toString();

		// reverse solidus (must go first as not to escape backslashes added as
		// part of escape sequences)
		string = string.replace("\\", "\\\\");
		// double quotes
		string = string.replace("\"", "\\\"");
		// solidus
		string = string.replace("/", "\\/");
		// backspace
		string = string.replace("\b", "\\b");
		// formfeed
		string = string.replace("\f", "\\f");
		// newline
		string = string.replace("\n", "\\n");
		// carriage return
		string = string.replace("\r", "\\r");
		// horzontal tab
		string = string.replace("\t", "\\t");
		// TODO unicode characters?

		builder.append("\"");
		builder.append(string);
		builder.append("\"");
	}
}
