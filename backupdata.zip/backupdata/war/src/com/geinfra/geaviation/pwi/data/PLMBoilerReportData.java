/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBoilerReportData.java
 * @Creation date: 17-Feb-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;


public class PLMBoilerReportData {

	private String projectName;
	private String taskName;
	private String taskState;			
	private String taskDescription;
	private String taskDuration;
	private String prjOwner;
	private String prjState;
	private String cntName;
	private String cstmrName;
	private String selectedPrjName;
	private String selectedTaskName;
	private String selectedTaskState;
	private String taskCrtnDate;
	private String taskEstdFinishDate;
	private Date taskCrtnDateNew;
	private Date taskEstdFinishDateNew;
	private String ownerName;
	
	/**
	 * @return the taskCrtnDate
	 */
	public String getTaskCrtnDate() {
		return taskCrtnDate;
	}
	/**
	 * @param taskCrtnDate the taskCrtnDate to set
	 */
	public void setTaskCrtnDate(String taskCrtnDate) {
		this.taskCrtnDate = taskCrtnDate;
	}
	/**
	 * @return the taskEstdFinishDate
	 */
	public String getTaskEstdFinishDate() {
		return taskEstdFinishDate;
	}
	/**
	 * @param taskEstdFinishDate the taskEstdFinishDate to set
	 */
	public void setTaskEstdFinishDate(String taskEstdFinishDate) {
		this.taskEstdFinishDate = taskEstdFinishDate;
	}
	/**
	 * @return the taskCrtnDateNew
	 */
	public Date getTaskCrtnDateNew() {
		return taskCrtnDateNew;
	}
	/**
	 * @param taskCrtnDateNew the taskCrtnDateNew to set
	 */
	public void setTaskCrtnDateNew(Date taskCrtnDateNew) {
		this.taskCrtnDateNew = taskCrtnDateNew;
	}
	/**
	 * @return the taskEstdFinishDateNew
	 */
	public Date getTaskEstdFinishDateNew() {
		return taskEstdFinishDateNew;
	}
	/**
	 * @param taskEstdFinishDateNew the taskEstdFinishDateNew to set
	 */
	public void setTaskEstdFinishDateNew(Date taskEstdFinishDateNew) {
		this.taskEstdFinishDateNew = taskEstdFinishDateNew;
	}
	/**
	 * @return the selectedTaskState
	 */
	public String getSelectedTaskState() {
		return selectedTaskState;
	}
	/**
	 * @param selectedTaskState the selectedTaskState to set
	 */
	public void setSelectedTaskState(String selectedTaskState) {
		this.selectedTaskState = selectedTaskState;
	}
	/**
	 * @return the selectedTaskName
	 */
	public String getSelectedTaskName() {
		return selectedTaskName;
	}
	/**
	 * @param selectedTaskName the selectedTaskName to set
	 */
	public void setSelectedTaskName(String selectedTaskName) {
		this.selectedTaskName = selectedTaskName;
	}
	/**
	 * @return the selectedPrjName
	 */
	public String getSelectedPrjName() {
		return selectedPrjName;
	}
	/**
	 * @param selectedPrjName the selectedPrjName to set
	 */
	public void setSelectedPrjName(String selectedPrjName) {
		this.selectedPrjName = selectedPrjName;
	}
	/**
	 * @return the taskState
	 */
	public String getTaskState() {
		return taskState;
	}
	/**
	 * @param taskStatus the taskState to set
	 */
	public void setTaskState(String taskState) {
		this.taskState = taskState;
	}
	/**
	 * @return the taskDescription
	 */
	public String getTaskDescription() {
		return taskDescription;
	}
	/**
	 * @param taskDescription the taskDescription to set
	 */
	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}
	/**
	 * @return the taskDuration
	 */
	public String getTaskDuration() {
		return taskDuration;
	}
	/**
	 * @param taskDuration the taskDuration to set
	 */
	public void setTaskDuration(String taskDuration) {
		this.taskDuration = taskDuration;
	}
	/**
	 * @return the prjOwner
	 */
	public String getPrjOwner() {
		return prjOwner;
	}
	/**
	 * @param prjOwner the prjOwner to set
	 */
	public void setPrjOwner(String prjOwner) {
		this.prjOwner = prjOwner;
	}
	/**
	 * @return the prjState
	 */
	public String getPrjState() {
		return prjState;
	}
	/**
	 * @param prjState the prjState to set
	 */
	public void setPrjState(String prjState) {
		this.prjState = prjState;
	}
	/**
	 * @return the cntName
	 */
	public String getCntName() {
		return cntName;
	}
	/**
	 * @param cntName the cntName to set
	 */
	public void setCntName(String cntName) {
		this.cntName = cntName;
	}
	/**
	 * @return the cstmrName
	 */
	public String getCstmrName() {
		return cstmrName;
	}
	/**
	 * @param cstmrName the cstmrName to set
	 */
	public void setCstmrName(String cstmrName) {
		this.cstmrName = cstmrName;
	}
	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}
	/**
	 * @param projectNameList the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	/**
	 * @return the taskName
	 */
	public String getTaskName() {
		return taskName;
	}
	/**
	 * @param taskName the taskName to set
	 */
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	/**
	 * @return the ownerName
	 */
	public String getOwnerName() {
		return ownerName;
	}
	/**
	 * @param ownerName the ownerName to set
	 */
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	
	
	
}
