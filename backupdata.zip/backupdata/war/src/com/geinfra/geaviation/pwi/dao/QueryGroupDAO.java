package com.geinfra.geaviation.pwi.dao;

import java.sql.SQLException;
import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.model.PWiUserVO;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : Data access object interface for query groups
 * 
 * Revision Log Aug 6, 2010 | v1.0. --------------------------------------------------------------
 */
public interface QueryGroupDAO {

	public List<String> getUnmappedRolesList() throws PWiException;


	public void createQueryGroup(PWiQueryGroupVO creategroup) throws SQLException;


	public List<PWiQueryGroupVO> getAllQueryGroups();


	public void updateQueryGroup(PWiQueryGroupVO creategroup);


	public List<PWiQueryGroupVO> findSelectedQueryGroups(Integer querySeqId) throws PWiException;


	public List<PWiQueryGroupVO> findSelectedGroupsForObjectType(Integer objTypSeqId) throws PWiException;


	public List<PWiQueryGroupVO> getUserQueryGroups(String ssoId);


	public List<PWiUserVO> findSelectedQueryGroupsUsers(Integer querySeqId) throws PWiException;


	public List<PWiQueryGroupVO> findSelectedGroupsForRole(Integer roleId) throws PWiException;
}
