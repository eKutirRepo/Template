 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMAdminUserMB.java
 * @Creation date: 17-Jul-2009
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.bean;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.service.PLMAdminServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;

/**
 * ICMAdminUserMB is the managed bean class used for ICM User Menu.
 */
public class PLMAdminUserMB  {
	/**
	 * Holds the Logger
	 */
	private static final Logger LOG = Logger.getLogger(PLMAdminUserMB.class);

	/**
	 * list of groups.
	 */
	private List<SelectItem> listOfGroups = new ArrayList<SelectItem>();
	/**
	 * The String groupID
	 */
	private String groupId;
	/**
	 * The String groupID
	 */
	private String ssoId = "";
	/**
	 * details object
	 */
	private PLMLoginData details = new PLMLoginData();
	/**
	 * data List
	 * 
	 */
	private List<PLMLoginData> data = new ArrayList<PLMLoginData>();
	/**
	 * The String status
	 */
	private String status;
	/**
	 * The String status
	 */
	private String statusInd;
	/**
	 * The String email
	 */
	private String email;
	/**
	 * The String admin
	 */
	private String admin;
	/**
	 * The String alert
	 */
	private String alert;
	/**
	 * The String comments
	 */
	private String comments;
	/**
	 * The boolean exportExcel
	 */
	private boolean exportExcel;
	/**
	 * The boolean read
	 */
	private boolean read;
	/**
	 * The boolean write
	 */
	private boolean write;
	/**
	 * The boolean delete
	 */
	private boolean delete;
	/**
	 * The boolean disable
	 */
	private boolean disable;
	/**
	 * The String loggedUser
	 */
	private String loggedUser;
	/**
	 * The String alertStrng
	 */
	private String alertStrng;
	/**
	 * The String oldGroupId
	 */
	private String oldGroupId;
	/**
	 * The String returnValue
	 */
	private String returnValue;
	/**
	 * The List check
	 */
	private List<String> check = new ArrayList<String>();
	/**
	 * The String groupName
	 */
	private String groupName;

	/**
	 * Holds the Current Scrollbar Page
	 */
	private int scrollerPage;
	/**
	 * The String searchSso
	 */
	private String searchSso;
	/**
	 * The String searchFname
	 */
	private String searchFname;
	/**
	 * The String searchLname
	 */
	private String searchLname;
	/**
	 * The List pickList
	 */
	private List<String> pickList = new ArrayList<String>();
	/**
	 * The List availableList
	 */
	private List<SelectItem> availableList = new ArrayList<SelectItem>();
	/**
	 * The List availableGroups
	 */
	private List<String> availableGroups = new ArrayList<String>();
	/**
	 * The List selectedGroups
	 */
	private List<String> selectedGroups = new ArrayList<String>();
	/**
	 * The List selectedList
	 */
	private List<SelectItem> selectedList = new ArrayList<SelectItem>();
	/**
	 * No. of records to be displayed
	 */
	private int recordCounts = PLMConstants.N_100;
	/**
	 * Total No. of records available
	 */
	private int totalRecCount;
	/**
	 * Show Data Table
	 */
	private boolean showDataTable;
	
	/**
	 * Service Handler for ICMAdminServiceIfc
	 */
	public PLMAdminServiceIfc adminServiceIfc;
	
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;

	/**
	 * For getting the list of groups
	 * 
	 * @return java.lang.String
	 */
	public String getListOfUserGroups() {
		String toRet = "";
		try {
			groupId = PLMConstants.EMPTY_STRING;
			data.clear();
			read = false;
			write = false;
			delete = false;
			showDataTable = false;
			exportExcel = true;
			disable = true;
			searchFname = PLMConstants.EMPTY_STRING;
			searchSso = PLMConstants.EMPTY_STRING;
			searchLname = PLMConstants.EMPTY_STRING;
			statusInd = PLMConstants.EMPTY_STRING;
			String screenName = PLMUtils.getRequestParameter("screenName");
			LOG.info("screenName---" + screenName);
			if (PLMUtils.getServletSession(true).getAttribute("USER_DATA") != null) {
				PLMLoginData DataObj = (PLMLoginData) PLMUtils.getServletSession(true).getAttribute("USER_DATA");
				loggedUser = DataObj.getUserSsoId();
				LOG.info("admuin Email" + DataObj.getUserEmail());
				Map<String, List<String>> permDetails = DataObj.getSecurityMatrix();
				List<String> permNames = permDetails.get(screenName);
				if (permNames.contains(PLMUtils.getMessage(PLMConstants.PEMISSION_READ))) {
					read = true;
				}
				if (permNames.contains(PLMUtils.getMessage(PLMConstants.PEMISSION_WRITE))) {
					write = true;
				}
				if (permNames.contains(PLMUtils.getMessage(PLMConstants.PEMISSION_DELETE))) {
					delete = true;
				}
			}
			LOG.info("isRead---isWrite---isDelete--" + read + "---" + write
					+ "---" + delete);
			LOG.info("Logged in  sso" + loggedUser);
			// LOG.info("In Managed Bean");
			listOfGroups = adminServiceIfc.getListOfUserGroups();
			toRet = "showusers";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getListOfUserGroups: ", exception);
			toRet = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Maintain Users");
		}  catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@getListOfUserGroups: ", exception);
			toRet = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Maintain Users");
		}
		return toRet;

	}

	/**
	 * For getting the list of slist for the particular group.
	 * 
	 * @return java.lang.String
	 */
	public String getUserList() {
		try {
			groupName = "";
			alert = "";
			returnValue = PLMConstants.EMPTY_STRING;
			exportExcel = true;
			data.clear();
			if (groupId == null
					|| groupId.equalsIgnoreCase(PLMConstants.PLEASE_SELECT)) {
				alert = PLMConstants.GROUP_SELECT;
				returnValue = PLMConstants.EMPTY_STRING;
			} else {

				// LOG.info("GroupIDDDDDDDDDDDDDDDDDDDDDDDDDD" + groupId);
				data = adminServiceIfc.getUserList(groupId);
				// LOG.info("size of list......" + Data.size());
				for (SelectItem dataSelectItem : listOfGroups) {
					if (dataSelectItem.getValue().equals(groupId)) {
						groupName = dataSelectItem.getLabel();
					}
				}
				if (data.size() > 0) {
					exportExcel = false;
					showDataTable = true;
					scrollerPage = PLMConstants.N_1;
				} else {

					alertStrng = groupName
							+ " group does not have any s associated";
					// alert = PLMConstants.NOUSERS_ALERT;
					returnValue = PLMConstants.EMPTY_STRING;
				}
			}
		} catch (PLMCommonException exp) {
			LOG.log(Level.ERROR, "Exception in getUserList " + exp);
			returnValue = PLMConstants.ERROR;
		} catch (Exception ex) {
			LOG.log(Level.ERROR, "Exception in  getUserList", ex);
			returnValue = PLMConstants.ERROR;
		}
		return returnValue;

	}

	/**
	 * 
	 * @return String For getting the excel of 's in the group.
	 */
	public String getUserExport() {
		String toRet = "";
		try {
			if ((searchSso != null && !(PLMConstants.EMPTY_STRING)
					.equals(searchSso.trim()))
					|| (searchFname != null && !(PLMConstants.EMPTY_STRING)
							.equals(searchFname.trim()))
					|| (searchLname != null && !(PLMConstants.EMPTY_STRING)
							.equals(searchLname.trim()))
					|| (groupId != null && !groupId
							.equalsIgnoreCase(PLMConstants.PLEASE_SELECT))
					|| (statusInd != null && !statusInd
							.equalsIgnoreCase(PLMConstants.PLEASE_SELECT))) {
				LOG.info("UserListSize" + data.size());

				toRet = "showusersExcel";
			} else {
				alert = PLMConstants.GROUP_SELECT;
				toRet = PLMConstants.EMPTY_STRING;
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@getUserExport: ", exception);
			toRet = PLMUtils.setCommonException(exception.getMessage(),commonMB,"showusers","Maintain Users");
		}
		return toRet;
	}

	/**
	 * For getting the Data after click on the ssoId link.
	 * 
	 * @return java.lang.String
	 */
	public String modifyUser() throws PLMCommonException {
		String toRet = "";
		try {
			ssoId = (String) FacesContext.getCurrentInstance()
					.getExternalContext().getRequestParameterMap().get(
							"userSSO");
			availableList.clear();
			selectedList.clear();
			pickList.clear();
			status = PLMConstants.EMPTY_STRING;

			// LOG.info("SSOIDDDDDDDDDDDDDDDDDDDDDDDDDD" + ssoId);
			oldGroupId = "";

			details = adminServiceIfc.modifyUser(ssoId);
			// LOG.info("emailnotification......"+
			// Details.getEmailNotification());

			// availableList.addAll(listOfGroups);
			selectedList.addAll(details.getListSelectedGrps());

			for (SelectItem dat : listOfGroups) {
				int count = 0;
				for (SelectItem des : selectedList) {
					if (((String) des.getValue()).equals((String) dat
							.getValue())) {
						LOG.info("equal" + dat.getValue());
						count = 1;
						break;
					}
				}
				if (count != 1) {
					LOG.info("not equal" + dat.getValue());
					availableList.add(dat);
				}
			}
			if (details.getStatus().equalsIgnoreCase(PLMConstants.NOO)) {
				status = PLMConstants.INACTIVE;

			} else {
				status = PLMConstants.ACTIVE;
			}
			// availableList.clear();
			// availableList.addAll(newAvailList);
			// availableList.removeAll(Details.getListSelectedGrps());
			LOG.info("availableList " + availableList);
			LOG.info("Details.getListSelectedGrps() "
					+ details.getListSelectedGrps());
			for (SelectItem dataModifyUser : selectedList) {
				pickList.add((String) dataModifyUser.getValue());
			}

			oldGroupId = groupId;
			LOG.info(">>>>>>>>>>>oldGroupId :" + oldGroupId);
			// LOG.info("status......" + Details.getStatus());

			details.setGropid(groupId);
			toRet = "";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@modifyUser: ", exception);
			PLMUtils.setCommonException(exception.getMessage(),commonMB,"showusers","Maintain Users");
			throw exception;
		} 
		return toRet;

	}

	/**
	 * For updating the details of the .
	 * 
	 * @return java.lang.String
	 */
	public String updateUser() throws PLMCommonException{
		LOG.info("Update USer");
		boolean flag = false;
		if (((details.getSsoId() != null && details.getSsoId().length() == PLMConstants.N_9))) {
			try {
				email = details.getEmailNotification();

				/*
				 * LOG.info("Email......" + email); LOG.info("Status........" +
				 * status); LOG.info("Admin........" + admin);
				 * LOG.info("Group......" + groupId); LOG.info("Comments......" +
				 * comments); LOG.info("SSOID......" + Details.getSsoId());
				 * LOG.info("FirstNAme........" + Details.getFirstName());
				 * LOG.info("LastName........" + Details.getLastName());
				 * LOG.info("Phone......" + Details.getPhone());
				 * LOG.info("Faxno......" + Details.getFax());
				 * LOG.info("Department......" + Details.getDepartment());
				 */
				// Details.setGropid(groupID);
				selectedGroups.clear();
				List<String> selData = new ArrayList<String>();
				for (SelectItem dataUpdateUser : selectedList) {
					selData.add((String) dataUpdateUser.getValue());
				}

				if (pickList.size() == selData.size()
						&& pickList.containsAll(selData)) {
					flag = true;
				}

				details.setStatus(status);
				LOG.info("AvailableList" + availableList);
				LOG.info("Selected" + selectedGroups + flag);
				LOG.info("Selected" + selectedList);
				boolean result = adminServiceIfc.updateUser(details,
						selData, loggedUser, flag);
				// LOG.info("result" + result);
				if (result) {
					// groupId = Details.getGropid();

					// alertStrng = PLMConstants.USERS_MODIFICATION;
					if (details.getFirstName() != null
							&& details.getLastName() != null) {

						searchUser();
						alertStrng = PLMConstants.CHANGES_USER
								+ details.getFirstName() + ", "
								+ details.getLastName()
								+ PLMConstants.HAVE_SAVED;

					} else {

						searchUser();
						alertStrng = PLMConstants.CHANGES_USER
								+ PLMConstants.HAVE_SAVED;
					}

				}

			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@updateUser: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"showusers","Maintain Users");
				throw exception;
			}
		} else {

			alert = PLMConstants.SELECT_STATUS;
			return PLMConstants.EMPTY_STRING;
		}
		return PLMConstants.EMPTY_STRING;
	}

	/**
	 * For updating the details of the .
	 * 
	 * @return java.lang.String
	 */
	public String userAdd() throws PLMCommonException {

		returnValue = PLMConstants.EMPTY_STRING;
		// String grpNm = "";
		if (((details.getSsoId() != null
				&& details.getSsoId().length() == PLMConstants.N_9 && !""
				.equals(details.getSsoId())))
				&& ((details.getGroupInd() != null) && !(details
						.getGroupInd().isEmpty()))) {

			if (details.getEmailNotification() != null
					&& !"".equalsIgnoreCase(details.getEmailNotification())) {
				try {
					email = details.getEmailNotification();

					LOG.info("no of grps seelcted......"
							+ details.getGroupInd().size());
					/*
					 * LOG.info("Email......" + email);
					 * LOG.info("Status........" + status);
					 * LOG.info("Admin........" + admin); LOG.info("Group......" +
					 * groupId); LOG.info("Comments......" + comments);
					 * LOG.info("SSOID......" + Details.getSsoId());
					 * LOG.info("FirstNAme........" +
					 * Details.getFirstName()); LOG.info("LastName........" +
					 * Details.getLastName()); LOG.info("Phone......" +
					 * Details.getPhone()); LOG.info("Faxno......" +
					 * Details.getFax()); LOG.info("Department......" +
					 * Details.getDepartment());
					 */
					// Details.setGropid(groupID);
					details.setStatus(PLMConstants.YES);

					boolean result = adminServiceIfc.userAdd(details,loggedUser);

					if (result) {
						if ((searchSso != null && !"".equals(searchSso.trim()))
								|| (searchFname != null && !""
										.equals(searchFname.trim()))
								|| (searchLname != null && !""
										.equals(searchLname.trim()))
								|| (groupId != null && !groupId
										.equalsIgnoreCase(PLMConstants.PLEASE_SELECT))) {
							LOG.info("cAME INSIDE");
							alertStrng = PLMConstants.USER_ADDED;

						} else {
							alertStrng = PLMConstants.USER_ADDED;
						}

					} else {

						alert = PLMConstants.ALREADY_GRPMEM_ALERT;
						returnValue = PLMConstants.EMPTY_STRING;
					}

				} catch (PLMCommonException exception) {
					LOG.log(Level.ERROR, "Exception@userAdd: ", exception);
					PLMUtils.setCommonException(exception.getMessage(),commonMB,"showusers","Maintain Users");
					throw exception;
				}
			} else {
				alert = PLMConstants.SELECT_EMAILNOTIFICATION;
				returnValue = PLMConstants.EMPTY_STRING;
			}
		}

		else {
			alert = PLMConstants.SELECT_SECURITYGROUP;
			returnValue = PLMConstants.EMPTY_STRING;
		}

		return returnValue;
	}

	/**
	 * For getting the popup data
	 * 
	 * @return java.lang.String
	 */
	public String addUser() throws PLMCommonException {
		String toRet = "";
		try {
			ssoId = PLMConstants.EMPTY_STRING;
			disable = true;
			email = details.getEmailNotification();
			status = PLMConstants.PLEASE_SELECT;
			details = adminServiceIfc.addUser();
			details.setEmailNotification(PLMConstants.NOO);
			/*
			 * LOG.info(Details.getSsoId());
			 * LOG.info(Details.getFirstName());
			 * LOG.info(Details.getLastName());
			 * LOG.info(Details.getListOfGroups());
			 * LOG.info(Details.getPhone());
			 * LOG.info(Details.getDepartment());
			 */
			toRet = "";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@updateUser: ", exception);
			PLMUtils.setCommonException(exception.getMessage(),commonMB,"showusers","Maintain Users");
			throw exception;
		} 
		return toRet;
	}

	/**
	 * For Validating the entered SSOID
	 * 
	 * @return java.lang.String
	 */
	public String validateUser() throws PLMCommonException {
		returnValue = PLMConstants.EMPTY_STRING;
		details = new PLMLoginData();
		if (!"".equals(ssoId) && (ssoId.trim()).length() == PLMConstants.N_9) {
			try {
				details = adminServiceIfc.validateUser(ssoId);
				if ("".equals(details.getSsoId())) {
					alert = PLMConstants.USER_SSO_VALIDATE;
					return PLMConstants.EMPTY_STRING;

				}
				details.setEmailNotification(PLMConstants.NOO);
				disable = false;
				LOG.info("ssoid..........ValidateUSER" + ssoId);
				/*
				 * //Map<String, String> DetailsMap = ICMLdapUtils
				 * .fetchDetails(ssoId);
				 */
				// LOG.info("Details coming from MAp" + DetailsMap);
				/*
				 * if (DetailsMap != null && null !=
				 * DetailsMap.get("uid")) { // LOG.info("Entered in to the
				 * looppppppp");
				 * Details.setSsoId(DetailsMap.get("uid"));
				 * Details.setFirstName(DetailsMap.get("givenName"));
				 * Details.setLastName(DetailsMap.get("sn"));
				 * //Details.setEmail(DetailsMap.get("mail"));
				 * Details.setEmail("RAVINDRA_VADREVU@SATYAM.COM");
				 * Details.setPhone(DetailsMap.get("telephoneNumber"));
				 * Details.setDepartment(DetailsMap
				 * .get("geSSOBusinessUnit"));
				 * Details.setAddress(DetailsMap.get("street"));
				 * Details.setCity(DetailsMap.get("l"));
				 * Details.setState(DetailsMap.get("st"));
				 * Details.setCountry(DetailsMap.get("c"));
				 * Details.setZipCode(DetailsMap.get("postalCode"));
				 * disable = false; } else { alert =
				 * PLMConstants.USER_SSO_VALIDATE; disable = true; returnValue =
				 * PLMConstants.EMPTY_STRING; }
				 */
				// LOG.info("sssssooooooo" + Details.getSsoId());
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@validateUser: ", exception);
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"showusers","Maintain Users");
				throw exception;
			}
		} else {
			// LOG.info("exception....");
			alert = PLMConstants.USER_SSO_VALIDATE;
			returnValue = PLMConstants.EMPTY_STRING;
		}
		return returnValue;
	}

	/**
	 * For deleting the Details
	 * 
	 * @return java.lang.String
	 */
	public String deleteUser() throws PLMCommonException {
		returnValue = PLMConstants.EMPTY_STRING;
		try {

			LOG.info("ssoid..........deleteUSER" + ssoId);
			LOG.info("groupid..........deleteUSER" + details.getGropid());
			boolean result = adminServiceIfc.deleteUser(check, groupId);
			// LOG.info("result" + result);
			if (result) {
				data.clear();

				// groupId = Details.getGropid();
				searchUser();
				alertStrng = PLMConstants.USER_DELETED;
			} else {
				// LOG.info("came to else");
				alert = PLMConstants.NOT_MEMBER;
				returnValue = PLMConstants.EMPTY_STRING;
			}

		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@deleteUser: ", exception);
			PLMUtils.setCommonException(exception.getMessage(),commonMB,"showusers","Maintain Users");
			throw exception;
		}
		return returnValue;
	}

	/**
	 * For validation of  check
	 * 
	 * @return java.lang.String
	 */
	public String validateDeleteUser() {
		try {
			check.clear();
			for (PLMLoginData checkBoolean : data) {
				if (checkBoolean.isCheck()) {
					check.add(checkBoolean.getSsoId());
				}
			}
			if (check.size() > 0) {
				alert = PLMConstants.YES;

			} else {
				alert = PLMConstants.DELETE_USER_REQUEST;
				returnValue = PLMConstants.EMPTY_STRING;
			}

		} catch (Exception exp) {
			LOG.log(Level.ERROR, "Exception in validateDeleteUser " + exp);
			returnValue = PLMConstants.ERROR;
		}
		return "";
	}

	/**
	 * For validation of  check
	 * 
	 * @return java.lang.String
	 */
	public String searchUser() throws PLMCommonException {

		try {
			alert = PLMConstants.EMPTY;
			alertStrng = PLMConstants.EMPTY;
			exportExcel = true;
			if ((searchSso != null && !(PLMConstants.EMPTY_STRING)
					.equals(searchSso.trim()))
					|| (searchFname != null && !(PLMConstants.EMPTY_STRING)
							.equals(searchFname.trim()))
					|| (searchLname != null && !(PLMConstants.EMPTY_STRING)
							.equals(searchLname.trim()))
					|| (groupId != null && !groupId
							.equalsIgnoreCase(PLMConstants.PLEASE_SELECT))
					|| (statusInd != null && !statusInd
							.equalsIgnoreCase(PLMConstants.PLEASE_SELECT))) {

				data = adminServiceIfc.searchUser(PLMUtils.escapeChar(searchSso), PLMUtils.escapeChar(searchFname),
						PLMUtils.escapeChar(searchLname), groupId, statusInd);
				LOG.info("ssoID" + searchSso);
				LOG.info("firstname" + searchFname);
				LOG.info("lastname" + searchLname);
				if (data.size() > 0) {
					totalRecCount = data.size();
					showDataTable = true;
					exportExcel = false;
					scrollerPage = PLMConstants.N_1;
					if (PLMUtils.getServletSession(true).getAttribute(
					"UsrDropDown") != null
					&& !"".equals((PLMUtils.getServletSession(true)
							.getAttribute("UsrDropDown"))
							.toString().trim())) {
						if (!PLMUtils.setNewDropDownValue(Integer
								.parseInt(PLMUtils.getServletSession(true)
										.getAttribute("UsrDropDown")
										.toString()))) {
							recordCounts = Integer.parseInt(PLMUtils
									.getServletSession(true).getAttribute(
											"UsrDropDown").toString());
						} else {
							recordCounts = totalRecCount;
						}
					} 
				} else {
					recordCounts = PLMConstants.N_100;
					showDataTable = false;
					alertStrng = PLMConstants.N0_RECORDS;
					// alert = PLMConstants.NOUSERS_ALERT;
					returnValue = PLMConstants.EMPTY_STRING;
				}
			} else {
				LOG.info("came to else loop");
				alert = PLMConstants.SEARCH_CRITERIA;
				returnValue = PLMConstants.EMPTY_STRING;
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@searchUser: ", exception);
			PLMUtils.setCommonException(exception.getMessage(),commonMB,"showusers","Maintain Users");
			throw exception;
		}  
		return returnValue;
	}

	/**
	 * @param event
	 * @return
	 */
	public String moveToSelectedList(ActionEvent event) {
		LOG.info("moveToSelectedList");
		int leftSize = 0;
		List<SelectItem> tobeRemoved = null;
		String selGrpName = null;
		String oldGrpName = null;
		String selGrpVal = null;
		String selGrpVals = null;
		String addGrpName = null;
		if (availableGroups == null) {
			availableGroups = new ArrayList<String>();
		}
		if (selectedGroups == null) {
			selectedGroups = new ArrayList<String>();
		}
		tobeRemoved = new ArrayList<SelectItem>();
		for (Iterator<String> c = availableGroups.iterator(); c.hasNext();) {
			selGrpName = c.next();
			boolean isExists = false;
			for (Iterator<SelectItem> sl = selectedList.iterator(); sl
					.hasNext();) {
				SelectItem ss = sl.next();
				oldGrpName = (String) ss.getValue();
				if (oldGrpName.equals(selGrpName)) {
					isExists = true;
				}
			}
			if (!isExists) {
				for (SelectItem selList : listOfGroups) {
					if (selGrpName.equals(selList.getValue())) {
						addGrpName = (String) selList.getLabel();
					}
				}
				selectedList.add(new SelectItem(selGrpName, addGrpName));
			}
		}
		leftSize = availableGroups.size();
		for (int i = 0; i < availableList.size(); i++) {
			boolean flag = false;
			selGrpVal = (String) ((SelectItem) availableList.get(i)).getLabel();
			selGrpVals = (String) ((SelectItem) availableList.get(i))
					.getValue();
			for (int j = 0; j < leftSize; j++) {
				if (((String) availableGroups.get(j))
						.equalsIgnoreCase(selGrpVals)) {
					flag = true;
				}
			}
			if (!flag) {
				tobeRemoved.add(new SelectItem(selGrpVals, selGrpVal));
			}
		}
		availableGroups = new ArrayList<String>();
		setAvailableList(tobeRemoved);
		// alertMessage = ReviewConstants.EMPTY;
		// message = ReviewConstants.EMPTY;
		return "";
	}

	/**
	 * @param ae
	 * @return
	 */
	public String moveToAvailableList(ActionEvent ae) {
		LOG.info("moveToAvailableList");
		int leftSize = 0;
		List<SelectItem> tobeRemoved = null;
		String selGrpName = null;
		String oldGrpName = null;
		String grpName = null;
		String selVal = null;
		String selGrpVals = null;
		String addGrpName = null;
		if (availableList == null) {
			availableList = new ArrayList<SelectItem>();
		}
		if (availableGroups == null) {
			availableGroups = new ArrayList<String>();
		}
		if (selectedGroups == null) {
			selectedGroups = new ArrayList<String>();
		}

		leftSize = selectedGroups.size();
		tobeRemoved = new ArrayList<SelectItem>();
		for (Iterator<String> c = selectedGroups.iterator(); c.hasNext();) {
			selGrpName = c.next();
			boolean isExists = false;
			for (Iterator<SelectItem> sl = availableList.iterator(); sl
					.hasNext();) {
				SelectItem ss = sl.next();
				oldGrpName = (String) ss.getValue();
				if (oldGrpName.equals(selGrpName)) {
					isExists = true;
				}
			}
			if (!isExists) {
				for (SelectItem selList : listOfGroups) {
					if (selGrpName.equals(selList.getValue())) {
						addGrpName = (String) selList.getLabel();
					}
				}
				availableList.add(new SelectItem(selGrpName, addGrpName));
			}
		}
		for (int i = 0; i < selectedList.size(); i++) {
			boolean flag = false;
			grpName = (String) ((SelectItem) selectedList.get(i)).getLabel();
			selGrpVals = (String) ((SelectItem) selectedList.get(i)).getValue();
			for (int j = 0; j < leftSize; j++) {
				selVal = (String) selectedGroups.get(j);
				if (selVal.equalsIgnoreCase(selGrpVals)) {
					flag = true;
				}
			}
			if (!flag) {
				tobeRemoved.add(new SelectItem(selGrpVals, grpName));

			}
		}

		// alertMessage = ReviewConstants.EMPTY;
		// message = ReviewConstants.EMPTY;
		selectedGroups = new ArrayList<String>();
		setSelectedList(tobeRemoved);
		return "";

	}

	/**
	 * @return the alertStrng
	 */
	public String getAlertStrng() {
		String temp = null;
		temp = alertStrng;
		alertStrng = PLMConstants.EMPTY_STRING;
		return temp;

	}

	/**
	 * @param alertStrng
	 *            the alertStrng to set
	 */
	public void setAlertStrng(String alertStrnga) {
		this.alertStrng = alertStrnga;
	}

	/**
	 * @return the read
	 */
	public boolean isRead() {
		return read;
	}

	/**
	 * @param read
	 *            the read to set
	 */
	public void setRead(boolean reada) {
		this.read = reada;
	}

	/**
	 * @return the write
	 */
	public boolean isWrite() {
		return write;
	}

	/**
	 * @param write
	 *            the write to set
	 */
	public void setWrite(boolean writea) {
		this.write = writea;
	}

	/**
	 * @return the showDataTable
	 */
	public boolean isShowDataTable() {
		return showDataTable;
	}

	/**
	 * @param showDataTable
	 *            the showDataTable to set
	 */
	public void setShowDataTable(boolean showDataTablea) {
		this.showDataTable = showDataTablea;
	}

	/**
	 * @return the loggedUser
	 */
	public String getLoggedUser() {
		return loggedUser;
	}

	/**
	 * @param loggedUser
	 *            the loggedUser to set
	 */
	public void setLoggedUser(String loggedUsera) {
		this.loggedUser = loggedUsera;
	}

	/**
	 * @return the listOfGrups
	 */
	public List<SelectItem> getListOfGroups() {
		return listOfGroups;
	}

	/**
	 * @param listOfGrups
	 *            the listOfGrups to set
	 */
	public void setListOfGroups(List<SelectItem> listOfGroupsa) {
		this.listOfGroups = listOfGroupsa;
	}

	/**
	 * @return the Data
	 */
	public List<PLMLoginData> getUserData() {
		return data;
	}

	/**
	 * @param Data
	 *            the Data to set
	 */
	public void setUserData(List<PLMLoginData> dataList) {
		this.data = dataList;
	}

	/**
	 * @return the groupID
	 */
	public String getGroupId() {
		return groupId;
	}

	/**
	 * @param groupId
	 *            the groupID to set
	 */
	public void setGroupId(String groupIDa) {
		this.groupId = groupIDa;
	}

	/**
	 * @return the ssoId
	 */
	public String getSsoId() {
		return ssoId;
	}

	/**
	 * @param ssoId
	 *            the ssoId to set
	 */
	public void setSsoId(String ssoIDa) {
		this.ssoId = ssoIDa;
	}

	/**
	 * @return the Details
	 */
	public PLMLoginData getUserDetails() {
		return details;
	}

	/**
	 * @param Details
	 *            the Details to set
	 */
	public void setUserDetails(PLMLoginData loginData) {
		this.details = loginData;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String statusa) {
		this.status = statusa;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String emaila) {
		this.email = emaila;
	}

	/**
	 * @return the admin
	 */
	public String getAdmin() {
		return admin;
	}

	/**
	 * @param admin
	 *            the admin to set
	 */
	public void setAdmin(String admina) {
		this.admin = admina;
	}

	/**
	 * @return the alert
	 */
	public String getAlert() {
		String temp = null;
		temp = alert;
		alert = PLMConstants.EMPTY_STRING;
		return temp;
	}

	/**
	 * @param alert
	 *            the alert to set
	 */
	public void setAlert(String alerta) {

		this.alert = alerta;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments
	 *            the comments to set
	 */
	public void setComments(String commentsa) {
		this.comments = commentsa;
	}

	/**
	 * @return the exportExcel
	 */
	public boolean isExportExcel() {
		return exportExcel;
	}

	/**
	 * @param exportExcel
	 *            the exportExcel to set
	 */
	public void setExportExcel(boolean exportExcela) {
		this.exportExcel = exportExcela;
	}

	/**
	 * @return the disable
	 */
	public boolean isDisable() {
		return disable;
	}

	/**
	 * @param disable
	 *            the disable to set
	 */
	public void setDisable(boolean disablea) {
		this.disable = disablea;
	}

	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * @param groupName
	 *            the groupName to set
	 */
	public void setGroupName(String groupNamea) {
		this.groupName = groupNamea;
	}

	/**
	 * @return the scrollerPage
	 */
	public int getScrollerPage() {
		return scrollerPage;
	}

	/**
	 * @param scrollerPage
	 *            the scrollerPage to set
	 */
	public void setScrollerPage(int scrollerPagea) {
		this.scrollerPage = scrollerPagea;
	}

	/**
	 * @return the searchSso
	 */
	public String getSearchSso() {

		return searchSso;

	}

	/**
	 * @param searchSso
	 *            the searchSso to set
	 */
	public void setSearchSso(String searchSsoa) {
		this.searchSso = searchSsoa;
	}

	/**
	 * @return the searchFname
	 */
	public String getSearchFname() {

		return searchFname;

	}

	/**
	 * @param searchFname
	 *            the searchFname to set
	 */
	public void setSearchFname(String searchFnamea) {
		this.searchFname = searchFnamea;
	}

	/**
	 * @return the searchLname
	 */
	public String getSearchLname() {

		return searchLname;

	}

	/**
	 * @param searchLname
	 *            the searchLname to set
	 */
	public void setSearchLname(String searchLnamea) {
		this.searchLname = searchLnamea;
	}

	/**
	 * @return the pickList
	 */
	public List<String> getPickList() {
		return pickList;
	}

	/**
	 * @param pickList
	 *            the pickList to set
	 */
	public void setPickList(List<String> pickLista) {
		this.pickList = pickLista;
	}

	/**
	 * @return the availablePersons
	 */
	public List<String> getAvailableGroups() {
		return availableGroups;
	}

	/**
	 * @param availablePersons
	 *            the availablePersons to set
	 */
	public void setAvailableGroups(List<String> availableGroupsa) {
		this.availableGroups = availableGroupsa;
	}

	/**
	 * @return the selectedPersons
	 */
	public List<String> getSelectedGroups() {
		return selectedGroups;
	}

	/**
	 * @param selectedPersons
	 *            the selectedPersons to set
	 */
	public void setSelectedGroups(List<String> selectedGroupsa) {
		this.selectedGroups = selectedGroupsa;
	}

	/**
	 * @return the availableList
	 */
	public List<SelectItem> getAvailableList() {
		return availableList;
	}

	/**
	 * @param availableList
	 *            the availableList to set
	 */
	public void setAvailableList(List<SelectItem> availableLista) {
		this.availableList = availableLista;
	}

	/**
	 * @return the selectedList
	 */
	public List<SelectItem> getSelectedList() {
		return selectedList;
	}

	/**
	 * @param selectedList
	 *            the selectedList to set
	 */
	public void setSelectedList(List<SelectItem> selectedLista) {
		this.selectedList = selectedLista;
	}

	/**
	 * @return the statusInd
	 */
	public String getStatusInd() {
		return statusInd;
	}

	/**
	 * @param statusInd
	 *            the statusInd to set
	 */
	public void setStatusInd(String statusInda) {
		this.statusInd = statusInda;
	}
	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @param recordCounts
	 *            the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		LOG.info("::::::::::::::::::" + recordCounts);
		PLMUtils.getServletSession(true).setAttribute("UsrDropDown",
				recordCounts);
		this.recordCounts = recordCounts;
	}
	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount
	 *            the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}
	/**
	 * @return the delete
	 */
	public boolean isDelete() {
		return delete;
	}

	/**
	 * @param delete
	 *            the delete to set
	 */
	public void setDelete(boolean deletea) {
		this.delete = deletea;
	}
	
	/**
	 * @return adminServiceIfc
	 */
	public PLMAdminServiceIfc getAdminServiceIfc() {
		return adminServiceIfc;
	}

	/**
	 * @param adminServiceIfc
	 */
	public void setAdminServiceIfc(PLMAdminServiceIfc objAdminServiceIfc) {
		this.adminServiceIfc = objAdminServiceIfc;
	}


	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
}
