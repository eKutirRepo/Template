package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.PWiQueryVO;
import com.geinfra.geaviation.pwi.model.TemplateVO;
import com.geinfra.geaviation.pwi.service.vo.OutputType;
import com.geinfra.geaviation.pwi.service.vo.QuerySubmissionResult;
import com.geinfra.geaviation.pwi.xml.query.ColumnType;

/**
 * 
 * Project : Product Lifecycle Management Inteligence Date Written : May 21,
 * 2010 Security : GE Confidential Restrictions : GE PROPRIETARY INFORMATION,
 * FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Maintains the state of the query result page that needs to be
 * persisted between consecutive requests.
 * 
 * Revision Log May 8, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class QueryResultViewBean extends BaseBean {
	private String outputOptionId;
	private List<List<Data>> tabRowList;
	private List<String> objectTypeNames;
	private List<List<Data>> filteredResults;
	private String filterString;
	private QuerySubmissionResult querySubmissionResult;
	private String showParameters;
	private boolean displayingWeb;
	private boolean displayingDownload;
	private boolean autoDownload;
	private String numRowsToDisplay;
	private List<SelectItem> outputTypeOptions;
	private String resultMessage;
	private String favoriteName;
	private String executeLink;
	private String modifyLink;
	private Map<String, OutputType> outputTypeIdMap;
	private Map<String, TemplateVO> templateIdMap;
	private String displayingOutputType;
	private String displayingTemplateId;
	private PWiQueryVO query;
	private Integer eventId;
	private Integer cacheId;
	private File queryResultsFile;
	private Map<String, ColumnType> linkColumns;

	public QueryResultViewBean() {

	}

	/**
	 * Copy constructor provided for copying a cache page state from a previous
	 * request so it may be used in respond to a new request.
	 * 
	 * @param bean
	 */
	public QueryResultViewBean(QueryResultViewBean bean) {
		// Properties that should never change
		// So no need to incur overhead of copying those that are non-primitive
		// or not immutable (such as the table of data)
		displayingWeb = bean.isDisplayingWeb();
		querySubmissionResult = bean.getQuerySubmissionResult();
		objectTypeNames = bean.getObjectTypeNames();
		if(displayingWeb)
		{
			tabRowList = bean.getTabRowList();
		}
		else
		{
			
			tabRowList = new ArrayList<List<Data>>();
		        //int rowItr = 0;
		        for (List<String> row : querySubmissionResult.getQueryResult()
		                .getData()) {
		            List<Data> newRow = new ArrayList<Data>();
		            for (int index = 0; index < row.size(); index++) {
		            	
		            	String cellData = new String();
		            	
			          
		            		cellData = row.get(index);
		            	
		            	
		                newRow.add(new Data(cellData, null,
		                        querySubmissionResult.getQueryResult().getColumns()
		                                .get(index).getLabel()));
		            }
		            
		            tabRowList.add(newRow);
		            //rowItr = rowItr + 1;
		        }
			
		}
		filteredResults = bean.getFilteredResults();
		filterString = bean.getFilterString();
		querySubmissionResult = bean.getQuerySubmissionResult();
		showParameters = bean.getShowParameters();
		resultMessage = bean.getResultMessage();
		outputTypeOptions = bean.getOutputTypeOptions();
		outputTypeIdMap = bean.getOutputTypeIdMap();
		templateIdMap = bean.getTemplateIdMap();
		query = bean.getQuery();
		// Properties that could change
		// Need to take care to copy any which are non-primitive or not
		// immutable
		outputOptionId = bean.getOutputOptionId();
		displayingWeb = bean.isDisplayingWeb();
		displayingDownload = bean.isDisplayingDownload();
		autoDownload = bean.isAutoDownload();
		numRowsToDisplay = bean.getNumRowsToDisplay();
		favoriteName = bean.getFavoriteName();
		executeLink = bean.getExecuteLink();
		modifyLink = bean.getModifyLink();
		displayingOutputType = bean.getDisplayingOutputType();
		displayingTemplateId = bean.getDisplayingTemplateId();
		eventId = bean.getEventId();
		if (bean.queryResultsFile != null) {
			queryResultsFile = new File(bean.queryResultsFile.getPath());
		}
		linkColumns = bean.getLinkColumns();
	}

	/**
	 * Project : Product Lifecycle Management Date Written : Apr 12, 2011
	 * Security : GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR
	 * GE USE ONLY
	 * 
	 * Copyright(C) 2011 GE All rights reserved
	 * 
	 * Description : Model for a cell of result data
	 * 
	 * Revision Log Apr 12, 2011 | v1.0.
	 * --------------------------------------------------------------
	 */
	public static class Data {
		private String data;
		private String menuId;
		private String columnLabel;

		public Data(String data, String menuId, String columnLabel) {
			this.data = data;
			this.menuId = menuId;
			this.columnLabel = columnLabel;
		}

		public String getData() {
			return data;
		}
		
		public void setData(String data) {
			this.data = data;
		}

		public String getMenuId() {
			return menuId;
		}

		public String getColumnLabel() {
			return columnLabel;
		}
	}

	public Map<String, ColumnType> getLinkColumns() {
		return linkColumns;
	}

	public void setLinkColumns(Map<String, ColumnType> linkColumns) {
		this.linkColumns = linkColumns;
	}

	public String getOutputOptionId() {
		return outputOptionId;
	}

	public void setOutputOptionId(String outputOptionId) {
		this.outputOptionId = outputOptionId;
	}

	public List<List<Data>> getTabRowList() {
		return tabRowList;
	}

	public void setTabRowList(List<List<Data>> tabRowList) {
		this.tabRowList = tabRowList;
	}

	public QuerySubmissionResult getQuerySubmissionResult() {
		return querySubmissionResult;
	}

	public void setQuerySubmissionResult(
			QuerySubmissionResult querySubmissionResult) {
		this.querySubmissionResult = querySubmissionResult;
	}

	public String getShowParameters() {
		return showParameters;
	}

	public void setShowParameters(String showParameters) {
		this.showParameters = showParameters;
	}

	public boolean isDisplayingWeb() {
		return displayingWeb;
	}

	public void setDisplayingWeb(boolean displayingWeb) {
		this.displayingWeb = displayingWeb;
	}

	public boolean isDisplayingDownload() {
		return displayingDownload;
	}

	public void setDisplayingDownload(boolean displayingDownload) {
		this.displayingDownload = displayingDownload;
	}

	public boolean isAutoDownload() {
		return autoDownload;
	}

	public void setAutoDownload(boolean autoDownload) {
		this.autoDownload = autoDownload;
	}

	public String getNumRowsToDisplay() {
		return numRowsToDisplay;
	}

	public void setNumRowsToDisplay(String numRowsToDisplay) {
		this.numRowsToDisplay = numRowsToDisplay;
	}

	public List<SelectItem> getOutputTypeOptions() {
		return outputTypeOptions;
	}

	public void setOutputTypeOptions(List<SelectItem> outputTypeOptions) {
		this.outputTypeOptions = outputTypeOptions;
	}

	public String getResultMessage() {
		return resultMessage;
	}

	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}

	public String getFavoriteName() {
		return favoriteName;
	}

	public void setFavoriteName(String favoriteName) {
		this.favoriteName = favoriteName;
	}

	public String getExecuteLink() {
		return executeLink;
	}

	public void setExecuteLink(String executeLink) {
		this.executeLink = executeLink;
	}

	public String getModifyLink() {
		return modifyLink;
	}

	public void setModifyLink(String modifyLink) {
		this.modifyLink = modifyLink;
	}

	public Map<String, OutputType> getOutputTypeIdMap() {
		return outputTypeIdMap;
	}

	public void setOutputTypeIdMap(Map<String, OutputType> outputTypeIdMap) {
		this.outputTypeIdMap = outputTypeIdMap;
	}

	public Map<String, TemplateVO> getTemplateIdMap() {
		return templateIdMap;
	}

	public void setTemplateIdMap(Map<String, TemplateVO> templateIdMap) {
		this.templateIdMap = templateIdMap;
	}

	public String getDisplayingOutputType() {
		return displayingOutputType;
	}

	public void setDisplayingOutputType(String displayingOutputType) {
		this.displayingOutputType = displayingOutputType;
	}

	public String getDisplayingTemplateId() {
		return displayingTemplateId;
	}

	public void setDisplayingTemplateId(String displayingTemplateId) {
		this.displayingTemplateId = displayingTemplateId;
	}

	public PWiQueryVO getQuery() {
		return query;
	}

	public void setQuery(PWiQueryVO query) {
		this.query = query;
	}

	public Integer getEventId() {
		return eventId;
	}

	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	public File getQueryResultsFile() {
		return queryResultsFile;
	}

	public void setQueryResultsFile(File queryResultsFile) {
		this.queryResultsFile = queryResultsFile;
	}

	public List<List<Data>> getFilteredResults() {
		return filteredResults;
	}

	public void setFilteredResults(List<List<Data>> filteredResults) {
		this.filteredResults = filteredResults;
	}

	public String getFilterString() {
		return filterString;
	}

	public void setFilterString(String filterString) {
		this.filterString = filterString;
	}

	public Integer getCacheId() {
		return cacheId;
	}

	public void setCacheId(Integer cacheId) {
		this.cacheId = cacheId;
	}
	public List<List<String>> getResults() {
		return querySubmissionResult.getQueryResult().getData();
	}
	
	public List<String> getObjectTypeNames() {
		return objectTypeNames;
	}
	
	public void setObjectTypeNames(List<String> objectTypeNames) {
		this.objectTypeNames = objectTypeNames;
	}

}