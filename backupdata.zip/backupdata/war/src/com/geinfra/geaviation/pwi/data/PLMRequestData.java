/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMRequestData.java
 * @Creation date: 17-Jul-2009
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.List;

import javax.faces.model.SelectItem;

/**
 * ICMRequestData is the Transfer/Value Object class for Welcome & Maintain
 * Screen and Request Account.
 */
public class PLMRequestData {

	/**
	 * The String screenId
	 */
	private String screenId;
	/**
	 * The String localUserfname.
	 */
	private String localUserfname;
	/**
	 * The String localUserlname.
	 */
	private String localUserlname;
	/**
	 * The String screenParentId
	 */
	private String screenParentId;
	/**
	 * The String fieldName
	 */
	private String fieldName;
	/**
	 * Used to designate whether user requested _Search and Read Only or not
	 */
	private boolean isReadOnlyAccsGrp;
	/**
	 * The int countId
	 */
	private int countId;
	/**
	 * The List screenId
	 */
	private List groupSeqId;
	/**
	 * The List groupNameList
	 */
	private List groupNameList;
	/**
	 * The String fieldVal
	 */
	private String fieldVal;
	/**
	 * The String stateId
	 */
	private String stateId;
	/**
	 * The String activeIndSent.
	 */
	private String activeIndSent;
	/**
	 * The String lastUpdatedBy
	 */
	private String lastUpdatedBy;
	/**
	 * The String lastUpdatedDate
	 */
	private String lastUpdatedDate;

	/**
	 * The String typeCd
	 */
	private String typeCd;
	/**
	 * The String fieldType
	 */
	private String fieldType;
	/**
	 * The String createdBy
	 */
	private String createdBy;
	/**
	 * The String createDate
	 */
	private String createDate;
	/**
	 * The String updatedBy
	 */
	private String updatedBy;
	/**
	 * The String updateDate
	 */
	private String updateDate;
	/**
	 * The String modDesc
	 */
	private String modDesc;
	/**
	 * The String modLink
	 */
	private String modLink;
	/**
	 * The ArrayList moduleValList
	 */
	private List moduleValList;
	/**
	 * The ArrayList homePageList
	 */
	private List homePageList;
	/**
	 * The ArrayList groupList
	 */
	private List<SelectItem> groupList;
	/**
	 * The ArrayList changedList
	 */
	private List changedList;
	/**
	 * The String ssoId
	 */
	private String ssoId;
	/**
	 * The String emailId
	 */
	private String emailId;
	/**
	 * The String groupId
	 */
	private String groupId;
	/**
	 * The String nationalityUsr
	 */
	private String nationalityUsr;
	/**
	 * The String contactDetails
	 */
	private String contactDetails;
	/**
	 * The String comments
	 */
	private String comments;
	// Start: Maintain WS
	/**
	 * The String announcements
	 */
	private String maitnAnnouncements;
	/**
	 * The String selectedModName
	 */
	private String selectedMaintainName;
	/**
	 * The String modDesc
	 */
	private String maitnModDesc;
	/**
	 * The String modLink
	 */
	private String maitnModLink;
	/**
	 * The String modPresentation
	 */
	private String maitnModPresentation;
	/**
	 * The String modTraining
	 */
	private String maitnModTraining;
	// End: ICM Application Section

	// Start: Latest Release Section
	/**
	 * The String modTraining
	 */
	private String maitnVersionNo;
	/**
	 * The String modTraining
	 */
	private String maitnReleaseDate;
	/**
	 * The String modTraining
	 */
	private String maitnRelDescription;
	/**
	 * The String modTraining
	 */
	private String maitnRelDetails;
	/**
	 * The ArrayList moduleValList
	 */
	private List maitnModuleValList;
	/**
	 * The String screenId
	 */
	private String maitnScreenId;
	/**
	 * The String screenParentId
	 */
	private String maitnScreenParentId;
	/**
	 * The String fieldName
	 */
	private String maitnFieldName;
	/**
	 * The String fieldVal
	 */
	private String maitnFieldType;
	/**
	 * The String fieldVal
	 */
	private String icmFieldType;
	/**
	 * The String fieldVal
	 */
	private String ancFieldType;
	/**
	 * The String fieldVal
	 */
	private String latFieldType;

	// End: Maintain WS

	/**
	 * @return the screenId
	 */
	public String getScreenId() {
		return screenId;
	}

	/**
	 * @param screenId
	 *            the screenId to set
	 */
	public void setScreenId(String screenId1) {
		this.screenId = screenId1;
	}

	/**
	 * @return the screenParentId
	 */
	public String getScreenParentId() {
		return screenParentId;
	}

	/**
	 * @param screenParentId
	 *            the screenParentId to set
	 */
	public void setScreenParentId(String screenParentId1) {
		this.screenParentId = screenParentId1;
	}

	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * @param fieldName
	 *            the fieldName to set
	 */
	public void setFieldName(String fieldName1) {
		this.fieldName = fieldName1;
	}

	/**
	 * @return the fieldVal
	 */
	public String getFieldVal() {
		return fieldVal;
	}

	/**
	 * @param fieldVal
	 *            the fieldVal to set
	 */
	public void setFieldVal(String fieldVal1) {
		this.fieldVal = fieldVal1;
	}

	/**
	 * @return the typeCd
	 */
	public String getTypeCd() {
		return typeCd;
	}

	/**
	 * @param typeCd
	 *            the typeCd to set
	 */
	public void setTypeCd(String typeCd1) {
		this.typeCd = typeCd1;
	}

	/**
	 * @return the fieldType
	 */
	public String getFieldType() {
		return fieldType;
	}

	/**
	 * @param fieldType
	 *            the fieldType to set
	 */
	public void setFieldType(String fieldType1) {
		this.fieldType = fieldType1;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy
	 *            the createdBy to set
	 */
	public void setCreatedBy(String createdBy1) {
		this.createdBy = createdBy1;
	}

	/**
	 * @return the createDate
	 */
	public String getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate
	 *            the createDate to set
	 */
	public void setCreateDate(String createDate1) {
		this.createDate = createDate1;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy
	 *            the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy1) {
		this.updatedBy = updatedBy1;
	}

	/**
	 * @return the updateDate
	 */
	public String getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate
	 *            the updateDate to set
	 */
	public void setUpdateDate(String updateDate1) {
		this.updateDate = updateDate1;
	}

	/**
	 * @return the modDesc
	 */
	public String getModDesc() {
		return modDesc;
	}

	/**
	 * @param modDesc
	 *            the modDesc to set
	 */
	public void setModDesc(String modDesc1) {
		this.modDesc = modDesc1;
	}

	/**
	 * @return the modLink
	 */
	public String getModLink() {
		return modLink;
	}

	/**
	 * @param modLink
	 *            the modLink to set
	 */
	public void setModLink(String modLink1) {
		this.modLink = modLink1;
	}

	/**
	 * @return the moduleValList
	 */
	public List getModuleValList() {
		return moduleValList;
	}

	/**
	 * @param moduleValList
	 *            the moduleValList to set
	 */
	public void setModuleValList(List moduleValList1) {
		this.moduleValList = moduleValList1;
	}

	/**
	 * @return the homePageList
	 */
	public List getHomePageList() {
		return homePageList;
	}

	/**
	 * @param homePageList
	 *            the homePageList to set
	 */
	public void setHomePageList(List homePageList1) {
		this.homePageList = homePageList1;
	}

	/**
	 * @return the changedList
	 */
	public List getChangedList() {
		return changedList;
	}

	/**
	 * @param changedList
	 *            the changedList to set
	 */
	public void setChangedList(List changedList1) {
		this.changedList = changedList1;
	}

	/**
	 * @return the maitnAnnouncements
	 */
	public String getMaitnAnnouncements() {
		return maitnAnnouncements;
	}

	/**
	 * @param maitnAnnouncements
	 *            the maitnAnnouncements to set
	 */
	public void setMaitnAnnouncements(String maitnAnnouncements1) {
		this.maitnAnnouncements = maitnAnnouncements1;
	}

	/**
	 * @return the selectedMaintainName
	 */
	public String getSelectedMaintainName() {
		return selectedMaintainName;
	}

	/**
	 * @param selectedMaintainName
	 *            the selectedMaintainName to set
	 */
	public void setSelectedMaintainName(String selectedMaintainName1) {
		this.selectedMaintainName = selectedMaintainName1;
	}

	/**
	 * @return the maitnModDesc
	 */
	public String getMaitnModDesc() {
		return maitnModDesc;
	}

	/**
	 * @param maitnModDesc
	 *            the maitnModDesc to set
	 */
	public void setMaitnModDesc(String maitnModDesc1) {
		this.maitnModDesc = maitnModDesc1;
	}

	/**
	 * @return the maitnModLink
	 */
	public String getMaitnModLink() {
		return maitnModLink;
	}

	/**
	 * @param maitnModLink
	 *            the maitnModLink to set
	 */
	public void setMaitnModLink(String maitnModLink1) {
		this.maitnModLink = maitnModLink1;
	}

	/**
	 * @return the maitnModPresentation
	 */
	public String getMaitnModPresentation() {
		return maitnModPresentation;
	}

	/**
	 * @param maitnModPresentation
	 *            the maitnModPresentation to set
	 */
	public void setMaitnModPresentation(String maitnModPresentation1) {
		this.maitnModPresentation = maitnModPresentation1;
	}

	/**
	 * @return the maitnModTraining
	 */
	public String getMaitnModTraining() {
		return maitnModTraining;
	}

	/**
	 * @param maitnModTraining
	 *            the maitnModTraining to set
	 */
	public void setMaitnModTraining(String maitnModTraining1) {
		this.maitnModTraining = maitnModTraining1;
	}

	/**
	 * @return the maitnVersionNo
	 */
	public String getMaitnVersionNo() {
		return maitnVersionNo;
	}

	/**
	 * @param maitnVersionNo
	 *            the maitnVersionNo to set
	 */
	public void setMaitnVersionNo(String maitnVersionNo1) {
		this.maitnVersionNo = maitnVersionNo1;
	}

	/**
	 * @return the maitnReleaseDate
	 */
	public String getMaitnReleaseDate() {
		return maitnReleaseDate;
	}

	/**
	 * @param maitnReleaseDate
	 *            the maitnReleaseDate to set
	 */
	public void setMaitnReleaseDate(String maitnReleaseDate1) {
		this.maitnReleaseDate = maitnReleaseDate1;
	}

	/**
	 * @return the maitnRelDescription
	 */
	public String getMaitnRelDescription() {
		return maitnRelDescription;
	}

	/**
	 * @param maitnRelDescription
	 *            the maitnRelDescription to set
	 */
	public void setMaitnRelDescription(String maitnRelDescription1) {
		this.maitnRelDescription = maitnRelDescription1;
	}

	/**
	 * @return the maitnRelDetails
	 */
	public String getMaitnRelDetails() {
		return maitnRelDetails;
	}

	/**
	 * @param maitnRelDetails
	 *            the maitnRelDetails to set
	 */
	public void setMaitnRelDetails(String maitnRelDetails1) {
		this.maitnRelDetails = maitnRelDetails1;
	}

	/**
	 * @return the maitnModuleValList
	 */
	public List getMaitnModuleValList() {
		return maitnModuleValList;
	}

	/**
	 * @param maitnModuleValList
	 *            the maitnModuleValList to set
	 */
	public void setMaitnModuleValList(List maitnModuleValList1) {
		this.maitnModuleValList = maitnModuleValList1;
	}

	/**
	 * @return the maitnScreenId
	 */
	public String getMaitnScreenId() {
		return maitnScreenId;
	}

	/**
	 * @param maitnScreenId
	 *            the maitnScreenId to set
	 */
	public void setMaitnScreenId(String maitnScreenId1) {
		this.maitnScreenId = maitnScreenId1;
	}

	/**
	 * @return the maitnScreenParentId
	 */
	public String getMaitnScreenParentId() {
		return maitnScreenParentId;
	}

	/**
	 * @param maitnScreenParentId
	 *            the maitnScreenParentId to set
	 */
	public void setMaitnScreenParentId(String maitnScreenParentId1) {
		this.maitnScreenParentId = maitnScreenParentId1;
	}

	/**
	 * @return the maitnFieldName
	 */
	public String getMaitnFieldName() {
		return maitnFieldName;
	}

	/**
	 * @param maitnFieldName
	 *            the maitnFieldName to set
	 */
	public void setMaitnFieldName(String maitnFieldName1) {
		this.maitnFieldName = maitnFieldName1;
	}

	/**
	 * @return the maitnFieldType
	 */
	public String getMaitnFieldType() {
		return maitnFieldType;
	}

	/**
	 * @param maitnFieldType
	 *            the maitnFieldType to set
	 */
	public void setMaitnFieldType(String maitnFieldType1) {
		this.maitnFieldType = maitnFieldType1;
	}

	/**
	 * @return the icmFieldType
	 */
	public String getIcmFieldType() {
		return icmFieldType;
	}

	/**
	 * @param icmFieldType
	 *            the icmFieldType to set
	 */
	public void setIcmFieldType(String icmFieldType1) {
		this.icmFieldType = icmFieldType1;
	}

	/**
	 * @return the ancFieldType
	 */
	public String getAncFieldType() {
		return ancFieldType;
	}

	/**
	 * @param ancFieldType
	 *            the ancFieldType to set
	 */
	public void setAncFieldType(String ancFieldType1) {
		this.ancFieldType = ancFieldType1;
	}

	/**
	 * @return the latFieldType
	 */
	public String getLatFieldType() {
		return latFieldType;
	}

	/**
	 * @param latFieldType
	 *            the latFieldType to set
	 */
	public void setLatFieldType(String latFieldType1) {
		this.latFieldType = latFieldType1;
	}

	/**
	 * @return the groupList
	 */
	public List<SelectItem> getGroupList() {
		return groupList;
	}

	/**
	 * @param groupList
	 *            the groupList to set
	 */
	public void setGroupList(List<SelectItem> groupList1) {
		this.groupList = groupList1;
	}

	/**
	 * @return the ssoId
	 */
	public String getSsoId() {
		return ssoId;
	}

	/**
	 * @param ssoId
	 *            the ssoId to set
	 */
	public void setSsoId(String ssoId1) {
		this.ssoId = ssoId1;
	}

	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * @param emailId
	 *            the emailId to set
	 */
	public void setEmailId(String emailId1) {
		this.emailId = emailId1;
	}

	/**
	 * @return the groupId
	 */
	public String getGroupId() {
		return groupId;
	}

	/**
	 * @param groupId
	 *            the groupId to set
	 */
	public void setGroupId(String groupId1) {
		this.groupId = groupId1;
	}

	/**
	 * @return the nationalityUsr
	 */
	public String getNationalityUsr() {
		return nationalityUsr;
	}

	/**
	 * @param nationalityUsr
	 *            the nationalityUsr to set
	 */
	public void setNationalityUsr(String nationalityUsr1) {
		this.nationalityUsr = nationalityUsr1;
	}

	/**
	 * @return the contactDetails
	 */
	public String getContactDetails() {
		return contactDetails;
	}

	/**
	 * @param contactDetails
	 *            the contactDetails to set
	 */
	public void setContactDetails(String contactDetails1) {
		this.contactDetails = contactDetails1;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments
	 *            the comments to set
	 */
	public void setComments(String comments1) {
		this.comments = comments1;
	}

	/**
	 * @return the stateId
	 */
	public String getStateId() {
		return stateId;
	}

	/**
	 * @param stateId
	 *            the stateId to set
	 */
	public void setStateId(String stateId1) {
		this.stateId = stateId1;
	}

	/**
	 * @return the lastUpdatedBy
	 */
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	/**
	 * @param lastUpdatedBy
	 *            the lastUpdatedBy to set
	 */
	public void setLastUpdatedBy(String lastUpdatedBy1) {
		this.lastUpdatedBy = lastUpdatedBy1;
	}

	/**
	 * @return the lastUpdatedDate
	 */
	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	/**
	 * @param lastUpdatedDate
	 *            the lastUpdatedDate to set
	 */
	public void setLastUpdatedDate(String lastUpdatedDate1) {
		this.lastUpdatedDate = lastUpdatedDate1;
	}

	/**
	 * @return the countId
	 */
	public int getCountId() {
		return countId;
	}

	/**
	 * @param countId
	 *            the countId to set
	 */
	public void setCountId(int countId1) {
		this.countId = countId1;
	}

	/**
	 * @return the activeIndSent
	 */
	public String getActiveIndSent() {
		return activeIndSent;
	}

	/**
	 * @param activeIndSent
	 *            the activeIndSent to set
	 */
	public void setActiveIndSent(String activeIndSent1) {
		this.activeIndSent = activeIndSent1;
	}

	/**
	 * @return the groupSeqId
	 */
	public List getGroupSeqId() {
		return groupSeqId;
	}

	/**
	 * @param groupSeqId
	 *            the groupSeqId to set
	 */
	public void setGroupSeqId(List groupSeqId1) {
		this.groupSeqId = groupSeqId1;
	}

	/**
	 * @return the groupNameList
	 */
	public List getGroupNameList() {
		return groupNameList;
	}

	/**
	 * @param groupNameList
	 *            the groupNameList to set
	 */
	public void setGroupNameList(List groupNameLst1) {
		this.groupNameList = groupNameLst1;
	}

	/**
	 * @return the localUserfname
	 */
	public String getLocalUserfname() {
		return localUserfname;
	}

	/**
	 * @param localUserfname
	 *            the localUserfname to set
	 */
	public void setLocalUserfname(String localUserfname1) {
		this.localUserfname = localUserfname1;
	}

	/**
	 * @return the localUserlname
	 */
	public String getLocalUserlname() {
		return localUserlname;
	}

	/**
	 * @param localUserlname
	 *            the localUserlname to set
	 */
	public void setLocalUserlname(String localUserlname1) {
		this.localUserlname = localUserlname1;
	}

	/**
	 * @return the isReadOnlyAccsGrp
	 */
	public boolean getReadOnlyAccsGrp() {
		return isReadOnlyAccsGrp;
	}

	/**
	 * @param isReadOnlyAccsGrp
	 *            the isReadOnlyAccsGrp to set
	 */
	public void setReadOnlyAccsGrp(boolean isReadOnlyAccsGrp1) {
		this.isReadOnlyAccsGrp = isReadOnlyAccsGrp1;
	}

}
