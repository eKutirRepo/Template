package com.geinfra.geaviation.pwi.bean;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;

import org.apache.commons.lang.StringUtils;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.service.AdminSettingsService;

/**
 * 
 * Project : Product Lifecycle Management
 * Date Written : May 19, 2010
 * Security : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2013 GE All rights reserved
 * 
 * Description : AdminSettingsBean - allows administrators to set
 *                                   application parameters
 * 
 * Revision Log May 19, 2010 | v1.0.
 * --------------------------------------------------------------
 * 2013.01.16   Himanshu    Added new configurable fields
 * 2013.02.08   Hasso       Extended validation to all HTML fields 
 */

public class AdminSettingsBean extends BaseBean {
	private static final String JAVASCRIPT_START_TAG = "<SCRIPT";
	private static final String JAVASCRIPT_CLOSE_TAG = "</SCRIPT>";
	private static final String JAVASCRIPT = "TEXT/JAVASCRIPT";
	private static final String JAVASCRIPT_GT = "<";
	private static final String JAVASCRIPT_LT = ">";

	private static final Pattern NAME_PATTERN = Pattern.compile("^[_A-Za-z0-9@',.=+$#()/\\\\s-]+$");
	private AdminSettingsService adminSettingsService;

	private String headerText;
	private String footerText;
	private String helpMsgText;
	private String quickIntelligenceHeaderText;
	private Integer onlineQueryTimeoutSecs;
	private Integer onlineResultSizeLimit;
	private String batchHeaderText;
	private Integer batchRenewalPeriod;

	public void setAdminSettingsService(
			AdminSettingsService adminSettingsService) {
		this.adminSettingsService = adminSettingsService;
	}

	@PostConstruct
	public void postConstruct() {
		try {
			String postback = FacesContext.getCurrentInstance()
					.getExternalContext().getRequestParameterMap().get(
							"postback");

			// Unless postback, need to loading settings from database
			if (postback == null) {
				headerText = adminSettingsService.getHeaderText();
				
				footerText = adminSettingsService.getFooterText();
				
				helpMsgText = adminSettingsService.getHelpMsgText();
				
				batchHeaderText = adminSettingsService.getBatchHeaderText();

				quickIntelligenceHeaderText = adminSettingsService
						.getQuickIntelligenceHeaderText();

				// TODO pH 2013.02: don't convert between int and Integer
				onlineQueryTimeoutSecs = Integer.valueOf(adminSettingsService
						.getOnlineQueryTimeoutSecs());

				onlineResultSizeLimit = Integer.valueOf(adminSettingsService
						.getOnlineResultSizeLimit());
				
				batchRenewalPeriod = Integer.valueOf(adminSettingsService
						.getBatchRenewalPeriod());
			}
		} catch (PWiException e) {
			// Throw RuntimeException because PostConstruct annotation doesn't
			// support checked exceptions
			throw new RuntimeException("Error post-constructing", e);
		}

	}

	public String actionSaveSettings() throws PWiException {
		// Make sure there is no JavaScript in any customizeable HTML
		if ( ! (validate(headerText) && validate(footerText)
				&& validate(helpMsgText) && validate(batchHeaderText)
				&& validate(quickIntelligenceHeaderText)) ) {
			return "";
		}

		// Save header text
		adminSettingsService.setHeaderText(headerText);
		
		//Save footer text
		adminSettingsService.setFooterText(footerText);
		
		//Save help messag text
		adminSettingsService.setHelpMsgText(helpMsgText);
		
		// Save batch header text
		adminSettingsService.setBatchHeaderText(batchHeaderText);

		// Save quick intelligence header text
		adminSettingsService
				.setQuickIntelligenceHeaderText(quickIntelligenceHeaderText);

		// TODO pH 2013.02: don't convert between int and Integer
		// Save query timeout
		adminSettingsService.setOnlineQueryTimeoutSecs(onlineQueryTimeoutSecs
				.intValue());

		// Save result size limit
		adminSettingsService.setOnlineResultSizeLimit(onlineResultSizeLimit
				.intValue());
		
		// Save batch renewal days
		adminSettingsService.setBatchRenewalPeriod(batchRenewalPeriod
				.intValue());

		handleFacesInfo("Settings saved successfully.");
		return "updated";
	}

	private boolean validate(String text) {
		boolean valid = true;
//add validation using pattern
		// Validate text
		if (!StringUtils.isBlank(text))
		{
			if (StringUtils.contains(StringUtils.upperCase(text),
					JAVASCRIPT_START_TAG)
					|| StringUtils.contains(StringUtils.upperCase(text),
							JAVASCRIPT)
					|| StringUtils.contains(StringUtils.upperCase(text),
							JAVASCRIPT_CLOSE_TAG)||StringUtils.contains(StringUtils.upperCase(text),
									JAVASCRIPT_GT)||StringUtils.contains(StringUtils.upperCase(text),
											JAVASCRIPT_LT)) {
				handleFacesError("Validation Failed! Please remove JavaScript from all custom text.");
				valid = false;
			}
			if(valid)
			{
				Matcher matcher = NAME_PATTERN.matcher(text);
				if (!matcher.find()) {
					handleFacesError("Validation Failed! Please remove JavaScript from all custom text.");
					valid = false;
				}
			}
		}

		return valid;
	}

	/**
	 * @return the settingsText
	 * @throws PWiException
	 */
	public String getHeaderText() throws PWiException {
		return headerText;
	}

	public void setHeaderText(String settingsValue) {
		this.headerText = settingsValue;
	}
	
	public String getFooterText() throws PWiException {
		return footerText;
	}

	public void setFooterText(String settingsValue) {
		this.footerText = settingsValue;
	}

	public String getHelpMsgText() throws PWiException {
		return helpMsgText;
	}

	public void setHelpMsgText(String settingsValue) {
		this.helpMsgText = settingsValue;
	}

	
	public String getQuickIntelligenceHeaderText() throws PWiException {
		return quickIntelligenceHeaderText;
	}

	public void setQuickIntelligenceHeaderText(
			String quickIntelligenceHeaderText) {
		this.quickIntelligenceHeaderText = quickIntelligenceHeaderText;
	}

	public Integer getOnlineQueryTimeoutSecs() throws PWiException {
		return onlineQueryTimeoutSecs;
	}

	public void setOnlineQueryTimeoutSecs(Integer onlineQueryTimeoutSecs) {
		this.onlineQueryTimeoutSecs = onlineQueryTimeoutSecs;
	}

	public Integer getOnlineResultSizeLimit() throws PWiException {
		return onlineResultSizeLimit;
	}

	public void setOnlineResultSizeLimit(Integer onlineResultSizeLimit) {
		this.onlineResultSizeLimit = onlineResultSizeLimit;
	}
	
	public String getBatchHeaderText() {
		return batchHeaderText;
	}

	public void setBatchHeaderText(String batchHeaderText) {
		this.batchHeaderText = batchHeaderText;
	}

	public Integer getBatchRenewalPeriod() {
		return batchRenewalPeriod;
	}

	public void setBatchRenewalPeriod(Integer batchRenewalPeriod) {
		this.batchRenewalPeriod = batchRenewalPeriod;
	}
}
