/**
 * Copyright (C) 2014 GE Infra.  
 * All rights reserved 
 * @FileName PLMCntrtSmryRptDaoIfc.java
 * @Creation date: 17-Jul-2009
 * @version 1.0
 * * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.data.PLMCntrtSmryRptData;
import com.geinfra.geaviation.pwi.data.PLMContractSmryData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMCntrtSmryRptDaoIfc {
	
	/**
	 * This method is used to get Hardware Product Configuration List
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> getHardwarePrdctCnfgList1(String contractNm) throws PLMCommonException;
	
	/**
	 * This method is used to get Hardware Product Configuration List
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> getHardwarePrdctCnfgList2(String contractNm) throws PLMCommonException;
	
	/**
	 * This method is used to fetch Project Name List
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchProjectNameList(String contractNm) throws PLMCommonException;
	
	/**
	 * This method is used to fetch employee names and roles
	 * @param contractNm, prjName
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchEmpNamesNRoles(String contractNm,String prjName) throws PLMCommonException;
	
	/**
	 * This method is used to fetch clin info
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchClinInfo(String contractNm, List<String> prdtTypeListClHb,boolean partTypeAllOpen) throws PLMCommonException;
	
	/**
	 * This method is used to fetch product requirement specific info
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchPrdtRqmntSpecInfo(String contractNm) throws PLMCommonException;
	
	/**
	 * This method is used to fetch crs info
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchCRSInfo(String contractNm) throws PLMCommonException;
	
	/**
	 * This method is used to fetch hardware build info
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchHardwareBuildInfo(String contractNm, List<String> prdtTypeListClHb,boolean partTypeAllOpen) throws PLMCommonException;
	
	/**
	 * This method is used to fetchPLPList
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchPLPList(String contractNm) throws PLMCommonException;
	
	/**
	 * This method is used to fetchPRSRecursiveData
	 * @param prsNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchPRSRecursiveData(String prsNm) throws PLMCommonException;
	
	/**
	 * This method is used to fetchCRSRecursiveData
	 * @param crsNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	
	public List<PLMCntrtSmryRptData> fetchCRSRecursiveData
	(String cntrtNm, String crsNm, String level, List<String> prdtTypeListCrs,boolean partTypeAllOpen) throws PLMCommonException;
	
	/**
	 * This method is used to fetchProductConfigData
	 * @param hrdwrPrdctNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchProductConfigData(String hrdwrPrdctNm) throws PLMCommonException;
	
	/**
	 * This method is used to fetcLogicalFeauturesData
	 * @param hrdwrPrdctNm, contractNum
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetcLogicalFeauturesData(String hrdwrPrdctNm, String contractNum,List<String> crsNmList) throws PLMCommonException;
	
	/**
	 * This method is used to fetcConfigEndItemsData
	 * @param hrdwrPrdctNm, contractNum
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetcConfigEndItemsData(String hrdwrPrdctNm, String contractNum,List<String> crsNmList) throws PLMCommonException;
	
	/**
	 * This method is used to fetchCustReqData
	 * @param hrdwrPrdctNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchCustReqData(String hrdwrPrdctNm) throws PLMCommonException;
	
	/**
	 * This method is used to fetCostObjectsData
	 * @param contractNum,hrdwrPrdctNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetCostObjectsData(String level, List<String> prdtTypeListCrs,boolean partTypeAllOpen,String contractNum,String hrdwrPrdctNm) throws PLMCommonException;
	
	/**
	 * This method is used to fetchTpLvlBomPrtData
	 * @param hrdwrPrdctNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchTpLvlBomPrtData(String hrdwrPrdctNm) throws PLMCommonException;
	
	/**
	 * This method is used to fetchCntrInfo
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchCntrInfo(String cntrtNm) throws PLMCommonException;
	/**
	 * This method is used to fetchCstGrpData
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<String> fetchCstGrpData() throws PLMCommonException;
	
	/**
	 * This method is used to fetchPCInfo
	 * @param contractNm, cstGrpList
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchPCInfo(String cntrtNm) throws PLMCommonException;
//	Newly Added by srinivas for contract summary on screen Report	
	/**
	 * This method is used for get Product Configuration
	 * 
	 * @return List
	 * @param cntrtNm,costGroup
	 * @throws PLMCommonException
	 */
	public List<PLMContractSmryData> fetchProductConf(String cntrtNm) throws PLMCommonException;
	
		
	/**
	 * This method is used for get  ConfigFeatures
	 * 
	 * @return List
	 * @param PCName,notRequireFlg
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchConfFeaturesPCNmData(String contractNum,String PCName,boolean notRequireFlg,boolean noSubTypeFlg,boolean categoryFlag) throws PLMCommonException;
	
	/**
	 * This method is used to fetch cost Group PC Name
	 * 
	 * @param PCName
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchConfFeaturesCostGrpData(String contractNum,List<String> PCNameList,boolean notRequireFlg,boolean noSubTypeFlg,boolean categoryFlag) throws PLMCommonException;

	
		
}
