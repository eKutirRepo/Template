 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMDashBoardMB.java
 * @Creation date: 9-April-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

import com.geinfra.geaviation.pwi.data.PLMDwgDashboardData;
import com.geinfra.geaviation.pwi.data.PLMkpiCostEngData;
import com.geinfra.geaviation.pwi.service.PLMDashboardServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

public class PLMDashBoardMB {
	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMDashBoardMB.class);
	/**
	 * Holds the loginMB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds the dashboardList
	 */
	private List<PLMDwgDashboardData> dashboardList = new ArrayList<PLMDwgDashboardData>();
	/**
	 * Holds the dashboardList_clin
	 */
	private List<PLMDwgDashboardData> dashboardList_clin = new ArrayList<PLMDwgDashboardData>();
	/**
	 * Holds the finalDashboardList
	 */
	private List<PLMDwgDashboardData> finalDashboardList = new ArrayList<PLMDwgDashboardData>();
	/**
	 * Holds the dashboardDetailList
	 */
	private List<PLMDwgDashboardData> dashboardDetailList = new ArrayList<PLMDwgDashboardData>();
	/**
	 * Holds the dashboardData
	 */
	private PLMDwgDashboardData dashboardData = new PLMDwgDashboardData();
	/**
	 * Holds the plmDashboardService
	 */
	private PLMDashboardServiceIfc plmDashboardService = null;
	/**
	 * Holds the dropDownMapList
	 */
	private Map<String, List<SelectItem>> dropDownMapList;
	/**
	 * Holds the contractNamesList
	 */
	private List<SelectItem> contractNamesList= new ArrayList<SelectItem>();
	/**
	 * Holds the selectedContractNamesList
	 */
	private List<String> selectedContractNamesList;
	/**
	 * Holds the percentlistRowCount
	 */
	public int percentlistRowCount = 0;
	/**
	 * Holds the rowIndexForSeparator
	 */
	public int rowIndexForSeparator = 0;
	/**
	 * Holds the typ1RowCount
	 */
	public int typ1RowCount = 0;
	/**
	 * Holds the typ2RowCount
	 */
	public int typ2RowCount = 0;
	/**
	 * Holds the detaillistRowCount
	 */

	public int detaillistRowCount = 0;
	/**
	 * Holds the detaillistRowCountMsg
	 */
	public String detaillistRowCountMsg = "";
	/**
	 * Holds the page
	 */
	private String page = "";
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = 100;
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the gtFlag
	 */

	private String gtFlag = "";
	/**
	 * Holds the gtGenFlag
	 */
	private String gtGenFlag = "";
	/**
	 * Holds the stFlag
	 */
	private String stFlag = "";
	/**
	 * Holds the stGenFlag
	 */
	private String stGenFlag = "";
	/**
	 * Holds the tskTypFullCu
	 */
	
	private String tskTypFullCu="";
	/**
	 * Holds the tskTypDescCu1
	 */
	private String tskTypDescCu1="";
	/**
	 * Holds the tskTypDescCu2
	 */
	private String tskTypDescCu2="";
	/**
	 * Holds the tskTypFullHw
	 */

	private String tskTypFullHw="";
	/**
	 * Holds the tskTypDescHw1
	 */
	private String tskTypDescHw1="";
	/**
	 * Holds the tskTypDescHw2
	 */
	private String tskTypDescHw2="";
	/**
	 * Holds the activeTask
	 */
	private boolean activeTask=false;
	/**
	 * Holds the dataTable
	 */
	private HtmlDataTable dataTable = new HtmlDataTable();

	//Start Newly Added variable for kpiCostEng  for 3.0.10 Release
	/**
	 * Holds the dataTable
	 */
	private String kpiCstAltMessage;
	/**
	 * Holds the ecoEcrName
	 */
	private String ecoEcrName;
	/**
	 * Holds the kpiCstRecordContMsg
	 */
	private String kpiCstRecordContMsg;
	/**
	 * Holds the dashboardDetailList
	 */
	private List<PLMkpiCostEngData> kpiCstEngList = new ArrayList<PLMkpiCostEngData>();
	/**
	 * Holds the kpiCstEngCount
	 */
	private int kpiCstEngCount;

	
	//End Newly Added variable for kpiCostEng  for 3.0.10 Release

	/**
	 *loadDashboardContractSelectionPage
	 * 
	 *@return String
	 */
	
	public String loadDashboardContractSelectionPage()
			throws PLMCommonException {
		LOG.info("Entering loadDashboardContractSelectionPage Method");
		selectedContractNamesList = new ArrayList<String>();

		try {
			commonMB.insertCannedRptRecordHitInfo("Project Lifecycle Drawings");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}

		try {
			
			resetValues();

			dropDownMapList = plmDashboardService.getDropDownData();
			LOG.info("dropDownMapList fetched to MB with size =="
					+ dropDownMapList.size());

			contractNamesList = (List<SelectItem>) dropDownMapList
					.get("contractNamesList");
			LOG.info("contractNameList fetched to MB with size =="
					+ contractNamesList.size());

		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@loadOmmReportPage:", exception);
		}
		LOG.info("Exiting loadDashboardContractSelectionPage Method");
		return "dashboardContract";
	}


	/**
	 *resetValues
	 * 
	 *
	 */
	public void resetValues() {
		contractNamesList = null;
		activeTask=false;

	}

	/**
	 *resetSearchData
	 * 
	 *@return String
	 */
	public String resetSearchData() {
		LOG.info("Entering resetSearchData");
		String fwdFlag = "dashboardContract";

		setSelectedContractNamesList(null);
		activeTask=false;
		
		 try{ fwdFlag= loadDashboardContractSelectionPage();
		 LOG.info(
		  "executed loadDashboardContractSelectionPage inside resetSearchData"
		  );
		  LOG.info("SECOND TIME contractNameList fetched to MB with size =="+
		  contractNamesList.size()); 
		  }catch (Exception exception) {
		  LOG.log(Level.ERROR, "Exception@loadOmmReportPage:", exception); }
		 
		return fwdFlag;

	}
	/**
	 *loadDwgDashboardReport
	 * 
	 *@return String
	 */
	public String loadDwgDashboardReport() throws PLMCommonException {
		LOG.info("Entering loadDwgDashboardReport of MB");
		String fwdflag = "";
		String prevTaskType = "";
		boolean status = false;
		boolean status1 = false;
		String curTaskType = "";
		gtFlag = "";
		gtGenFlag = "";
		stFlag = "";
		stGenFlag = "";
		finalDashboardList = new ArrayList<PLMDwgDashboardData>();
		
		if (PLMUtils.isEmptyList(selectedContractNamesList)){
				 
			LOG.info("No Contract number selected...");
			//fieldName = PLMConstants.UI_DRAWING_SEARCH;
			alertMessage = PLMConstants.DASHBOARD_CONTRACT_ALERT;
		}
		if (PLMUtils.isEmpty(alertMessage)) {
		try	{
			
			tskTypFullCu="CLIN DELVS.";
			 tskTypDescCu1="(Customer";
			 tskTypDescCu2="Drawings)";

			tskTypFullHw="ALL BOM DELVS.";
			 tskTypDescHw1="(Hardware";
			 tskTypDescHw2="Drawings)";
			//loginMB.getPLMDateStamp(PLMConstants.ECO_TABLE);
			dashboardList = plmDashboardService.loadDwgDashboardReport(dashboardData,dashboardList,selectedContractNamesList,activeTask);
			percentlistRowCount=dashboardList.size();
			
		for(int i=0;i<dashboardList.size();i++){
			if(i>0){
				prevTaskType= dashboardList.get(i-1).getTskTypFull();
				curTaskType = dashboardList.get(i).getTskTypFull();
				 if((!curTaskType.equals(prevTaskType)&& !prevTaskType.equals("")))
				{
					status = true;
					status1 =false;
				}
			}
			
				if(i<=7 && (!status || status1))
				{
					
					if (dashboardList.get(i).getGroup().equals("GT")){
						finalDashboardList.add(dashboardList.get(i));
						gtFlag="AV";
					}
					else if (dashboardList.get(i).getGroup().equals("GT GEN")){
						finalDashboardList.add(dashboardList.get(i));
						gtGenFlag="AV";
					}
					else if (dashboardList.get(i).getGroup().equals("ST")){
						finalDashboardList.add(dashboardList.get(i));
						stFlag="AV";
					}
					else if (dashboardList.get(i).getGroup().equals("ST GEN")){
						finalDashboardList.add(dashboardList.get(i));
						stGenFlag="AV";
					}
					if(i==(dashboardList.size()-1)){
						if(!gtFlag.equals("AV")){
							PLMDwgDashboardData dwgDashboardData = new PLMDwgDashboardData();
							dwgDashboardData.setGroup("GT");
							dwgDashboardData.setPercTskCmpl(0.0);
							dwgDashboardData.setPercTskOtd(0.0);
							dwgDashboardData.setNumTskLate("0");
							dwgDashboardData.setNumTskToGo("0");
							dwgDashboardData.setNumTsk30DyAhead("0");				
							dwgDashboardData.setClosedLate("0");
							dwgDashboardData.setClosedOnTime("0");
							dwgDashboardData.setSumOfDelvs("0");
							finalDashboardList.add(dwgDashboardData);
							gtFlag="AV";
						}
						if(!stFlag.equals("AV")){
							PLMDwgDashboardData dwgDashboardData = new PLMDwgDashboardData();
							dwgDashboardData.setGroup("ST");
							dwgDashboardData.setPercTskCmpl(0.0);
							dwgDashboardData.setPercTskOtd(0.0);
							dwgDashboardData.setNumTskLate("0");
							dwgDashboardData.setNumTskToGo("0");
							dwgDashboardData.setNumTsk30DyAhead("0");				
							dwgDashboardData.setClosedLate("0");
							dwgDashboardData.setClosedOnTime("0");
							dwgDashboardData.setSumOfDelvs("0");
							finalDashboardList.add(dwgDashboardData);
							stFlag="AV";
						}
						if(!gtGenFlag.equals("AV")){
							PLMDwgDashboardData dwgDashboardData = new PLMDwgDashboardData();
							dwgDashboardData.setGroup("GT GEN");
							dwgDashboardData.setPercTskCmpl(0.0);
							dwgDashboardData.setPercTskOtd(0.0);
							dwgDashboardData.setNumTskLate("0");
							dwgDashboardData.setNumTskToGo("0");
							dwgDashboardData.setNumTsk30DyAhead("0");				
							dwgDashboardData.setClosedLate("0");
							dwgDashboardData.setClosedOnTime("0");
							dwgDashboardData.setSumOfDelvs("0");
							finalDashboardList.add(dwgDashboardData);
							gtGenFlag="AV";
						}
						if(!stGenFlag.equals("AV")){
							PLMDwgDashboardData dwgDashboardData = new PLMDwgDashboardData();
							dwgDashboardData.setGroup("ST GEN");
							dwgDashboardData.setPercTskCmpl(0.0);
							dwgDashboardData.setPercTskOtd(0.0);
							dwgDashboardData.setNumTskLate("0");
							dwgDashboardData.setNumTskToGo("0");
							dwgDashboardData.setNumTsk30DyAhead("0");				
							dwgDashboardData.setClosedLate("0");
							dwgDashboardData.setClosedOnTime("0");
							dwgDashboardData.setSumOfDelvs("0");
							finalDashboardList.add(dwgDashboardData);
							stGenFlag="AV";
						}
						gtFlag ="";
						gtGenFlag="";
						stFlag ="";
						stGenFlag="";
					}
				}
				else
				{
							if(!gtFlag.equals("AV")){
								PLMDwgDashboardData dwgDashboardData = new PLMDwgDashboardData();
								dwgDashboardData.setGroup("GT");
								dwgDashboardData.setPercTskCmpl(0.0);
								dwgDashboardData.setPercTskOtd(0.0);
								dwgDashboardData.setNumTskLate("0");
								dwgDashboardData.setNumTskToGo("0");
								dwgDashboardData.setNumTsk30DyAhead("0");				
								dwgDashboardData.setClosedLate("0");
								dwgDashboardData.setClosedOnTime("0");
								dwgDashboardData.setSumOfDelvs("0");
								finalDashboardList.add(dwgDashboardData);
								gtFlag="AV";
							}
							if(!stFlag.equals("AV")){
								PLMDwgDashboardData dwgDashboardData = new PLMDwgDashboardData();
								dwgDashboardData.setGroup("ST");
								dwgDashboardData.setPercTskCmpl(0.0);
								dwgDashboardData.setPercTskOtd(0.0);
								dwgDashboardData.setNumTskLate("0");
								dwgDashboardData.setNumTskToGo("0");
								dwgDashboardData.setNumTsk30DyAhead("0");				
								dwgDashboardData.setClosedLate("0");
								dwgDashboardData.setClosedOnTime("0");
								dwgDashboardData.setSumOfDelvs("0");
								finalDashboardList.add(dwgDashboardData);
								stFlag="AV";
							}
							if(!gtGenFlag.equals("AV")){
								PLMDwgDashboardData dwgDashboardData = new PLMDwgDashboardData();
								dwgDashboardData.setGroup("GT GEN");
								dwgDashboardData.setPercTskCmpl(0.0);
								dwgDashboardData.setPercTskOtd(0.0);
								dwgDashboardData.setNumTskLate("0");
								dwgDashboardData.setNumTskToGo("0");
								dwgDashboardData.setNumTsk30DyAhead("0");				
								dwgDashboardData.setClosedLate("0");
								dwgDashboardData.setClosedOnTime("0");
								dwgDashboardData.setSumOfDelvs("0");
								finalDashboardList.add(dwgDashboardData);
								gtGenFlag="AV";
							}
							
							if(!stGenFlag.equals("AV")){
								PLMDwgDashboardData dwgDashboardData = new PLMDwgDashboardData();
								dwgDashboardData.setGroup("ST GEN");
								dwgDashboardData.setPercTskCmpl(0.0);
								dwgDashboardData.setPercTskOtd(0.0);
								dwgDashboardData.setNumTskLate("0");
								dwgDashboardData.setNumTskToGo("0");
								dwgDashboardData.setNumTsk30DyAhead("0");				
								dwgDashboardData.setClosedLate("0");
								dwgDashboardData.setClosedOnTime("0");
								dwgDashboardData.setSumOfDelvs("0");
								finalDashboardList.add(dwgDashboardData);
								stGenFlag="AV";
							}
						gtFlag ="";
						gtGenFlag="";
						stFlag ="";
						stGenFlag="";
						if (dashboardList.get(i).getGroup().equals("GT")){
							finalDashboardList.add(dashboardList.get(i));
							gtFlag="AV";
						}
						else if (dashboardList.get(i).getGroup().equals("GT GEN")){
							finalDashboardList.add(dashboardList.get(i));
							gtGenFlag="AV";
						}
						else if (dashboardList.get(i).getGroup().equals("ST")){
							finalDashboardList.add(dashboardList.get(i));
							stFlag="AV";
						}
						else if (dashboardList.get(i).getGroup().equals("ST GEN")){
							finalDashboardList.add(dashboardList.get(i));
							stGenFlag="AV";
						}
						if(dashboardList.size()==2){
							if(!gtFlag.equals("AV")){
								PLMDwgDashboardData dwgDashboardData = new PLMDwgDashboardData();
								dwgDashboardData.setGroup("GT");
								dwgDashboardData.setPercTskCmpl(0.0);
								dwgDashboardData.setPercTskOtd(0.0);
								dwgDashboardData.setNumTskLate("0");
								dwgDashboardData.setNumTskToGo("0");
								dwgDashboardData.setNumTsk30DyAhead("0");				
								dwgDashboardData.setClosedLate("0");
								dwgDashboardData.setClosedOnTime("0");
								dwgDashboardData.setSumOfDelvs("0");
								finalDashboardList.add(dwgDashboardData);
								gtFlag="AV";
							}
							if(!stFlag.equals("AV")){
								PLMDwgDashboardData dwgDashboardData = new PLMDwgDashboardData();
								dwgDashboardData.setGroup("ST");
								dwgDashboardData.setPercTskCmpl(0.0);
								dwgDashboardData.setPercTskOtd(0.0);
								dwgDashboardData.setNumTskLate("0");
								dwgDashboardData.setNumTskToGo("0");
								dwgDashboardData.setNumTsk30DyAhead("0");				
								dwgDashboardData.setClosedLate("0");
								dwgDashboardData.setClosedOnTime("0");
								dwgDashboardData.setSumOfDelvs("0");
								finalDashboardList.add(dwgDashboardData);
								stFlag="AV";
								
							}
							if(!gtGenFlag.equals("AV")){
								PLMDwgDashboardData dwgDashboardData = new PLMDwgDashboardData();
								dwgDashboardData.setGroup("GT GEN");
								dwgDashboardData.setPercTskCmpl(0.0);
								dwgDashboardData.setPercTskOtd(0.0);
								dwgDashboardData.setNumTskLate("0");
								dwgDashboardData.setNumTskToGo("0");
								dwgDashboardData.setNumTsk30DyAhead("0");				
								dwgDashboardData.setClosedLate("0");
								dwgDashboardData.setClosedOnTime("0");
								dwgDashboardData.setSumOfDelvs("0");
								finalDashboardList.add(dwgDashboardData);
								gtGenFlag="AV";
							}
							
							if(!stGenFlag.equals("AV")){
								PLMDwgDashboardData dwgDashboardData = new PLMDwgDashboardData();
								dwgDashboardData.setGroup("ST GEN");
								dwgDashboardData.setPercTskCmpl(0.0);
								dwgDashboardData.setPercTskOtd(0.0);
								dwgDashboardData.setNumTskLate("0");
								dwgDashboardData.setNumTskToGo("0");
								dwgDashboardData.setNumTsk30DyAhead("0");				
								dwgDashboardData.setClosedLate("0");
								dwgDashboardData.setClosedOnTime("0");
								dwgDashboardData.setSumOfDelvs("0");
								finalDashboardList.add(dwgDashboardData);
								stGenFlag="AV";
							}
						}
						status1=true;
				}
				
			}	
			LOG.info("dashboard Percent List fetched.......Size="+percentlistRowCount);
			//dashboardList_clin = plmDwgDashboardService.loadCLINDwgDashboardReport(dashboardData,dashboardList_clin);
			//LOG.info("dashboardList_clin fetched.......");
			if (!PLMUtils.isEmptyList(finalDashboardList)) {
			fwdflag = "dashboardreport";
			}
			else
			{
			fwdflag = "invalidDashboard";
			}
		}catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadEcoVolumeReport: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","DwgDashboard Report");
		}
		}
		LOG.info("Alert Message is:"+alertMessage);
		LOG.info("Exiting loadDwgDashboardReport of MB");
		return fwdflag;
	}
	
	


	/**
	 *loadDwgDashboardDetailReport
	 * 
	 *@return String
	 *@throws PLMCommonException
	 */
	public String loadDwgDashboardDetailReport() throws PLMCommonException {
		LOG.info("Entering loadDwgDashboardDetailReport of MB");
		String fwdflag = "";
		try {
			dashboardDetailList = plmDashboardService
					.loadDwgDashboardDetailReport(dashboardData,
							dashboardDetailList, selectedContractNamesList,activeTask);

			if (!PLMUtils.isEmptyList(dashboardDetailList)) {
				LOG
						.info("Size of Details List : "
								+ dashboardDetailList.size());
				// fwdflag =
				// plmkpiecoSearchMB.getEcoVolumeDetailReport(econameslist,ecovolumedata);
				detaillistRowCount = dashboardDetailList.size();
				detaillistRowCountMsg = "Total Records Count:"
						+ dashboardDetailList.size();
				page = "dashboardDetailReport";
				fwdflag = "dashboardDetailReport";
			} else {
				fwdflag = "invalidEco";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadEcoVolumeDetailReport: ",
					exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "ecovolumereport", "DwgDashboard Report");
		}
		// plmkpiecoSearchMB.setPage("ecovolume");
		LOG.info("Exiting loadDwgDashboardDetailReport of MB");
		return fwdflag;
	}
	/**
	 *recordsPerPageListner
	 * 
	 *@param event
	 *
	 */
	public void recordsPerPageListner(ActionEvent event) {
		LOG.info("Entering recordsPerPageListner method");
		LOG.info("Action listner called.....--------------------------->"
				+ recordCounts);
		if (recordCounts == 15) {
			LOG.info("15");
			recordCounts = 15;
		} else if (recordCounts == 30) {
			LOG.info("30");
			recordCounts = 30;
		} else if (recordCounts == 50) {
			LOG.info("50");
			recordCounts = 50;
		} else if (recordCounts == 100) {
			LOG.info("100");
			recordCounts = 100;
		} else if (recordCounts == 200) {
			LOG.info("200");
			recordCounts = 200;
		}

		else if (recordCounts == detaillistRowCount) {
			LOG.info("All");
			recordCounts = detaillistRowCount;
		}
		LOG.info("final value.....--------------------------->" + recordCounts);
	}
	
	//Start Newly Added method of 1269 Req for 3.0.10 release
	/**
	 *loadKPICostEngHome
	 * 
	 *@return String
	 */
	
	public String loadKPICostEngHome()
			throws PLMCommonException {
		LOG.info("Entering loadKPICostEngHome Method");
		try {			
			commonMB.insertCannedRptRecordHitInfo("KPI-Cost of Eng. Change Process");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		kpiCstAltMessage="";
		ecoEcrName="";
		kpiCstRecordContMsg="";
		kpiCstEngList = new ArrayList<PLMkpiCostEngData>();
		kpiCstEngCount=0;
		LOG.info("Exiting loadKPICostEngHome Method");
		return "kpiCostEngSearch";
	}
	/**
	 * This method is used for Validating ECO ECR Input
	 * 
	 * @return String
	 */
	public String validateEcoEcrInput() {		
		LOG.info("Entering validateEcoEcrInput Method");
		kpiCstAltMessage="";
		if(PLMUtils.isEmpty(ecoEcrName)){
			kpiCstAltMessage = PLMConstants.ECO_ECR_VALIDINPUT;
		}else if(!PLMUtils.checkForSpecialChars(ecoEcrName)){
			kpiCstAltMessage = PLMConstants.ECO_ECR_SPLCHRS;
		}
		LOG.info("Exiting validateEcoEcrInput Method");
		return kpiCstAltMessage;
	}
	/**
	 *loadDwgDashboardDetailReport
	 * 
	 *@return String
	 *@throws PLMCommonException
	 */
	public String getKPICostEngReport() throws PLMCommonException {
		LOG.info("Entering getKPICostEngReport");
		String fwdflag = "";
		kpiCstAltMessage="";
		try {
			kpiCstAltMessage = validateEcoEcrInput();	
		      if(PLMUtils.isEmpty(kpiCstAltMessage)) {
				LOG.info("ECO / ECR Name>>>>"+ecoEcrName);
				kpiCstEngList = plmDashboardService.getKPICostEngReport(ecoEcrName);
		         if (!PLMUtils.isEmptyList(kpiCstEngList)){
		        	kpiCstEngCount = kpiCstEngList.size()-1;
		        	kpiCstRecordContMsg = "ECO / ECR Name: "+ecoEcrName+" Records Count: "+kpiCstEngCount;
		        	LOG.info(kpiCstRecordContMsg);
		        	fwdflag = "kpiCostEngReport";
		         }else{
		        	fwdflag = "invalidkpiCostEngRpt";
		         }
		      }else{
				fwdflag = "kpiCostEngSearch";
		      }
		 }catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getKPICostEngReport: ",
					exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "kpiCostEngSearch", "KPI-Cost of Eng. Change Process");
		}
		LOG.info("Exiting getKPICostEngReport ");
		return fwdflag;
	}
	
	/**
	 * This method is used to download excel for KPI report
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	
	public void downloadKPIExcel() throws PLMCommonException {
		
		LOG.info("Entering downloadKPIExcel Method");
		String reportName="kpiCostEngineDoc";
		String fileName="kpiCostEngine";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMkpiCostEngData forEcoEcr = new PLMkpiCostEngData();
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
			
		PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("parentPart", "Parent Part", FormatType.TEXT, null, null, 16),
                    new PLMXlsxRptColumn("partLvl", "Part Lvl", FormatType.TEXT, null, null, 13),
                    new PLMXlsxRptColumn("wasPart", "Was Part", FormatType.TEXT, null, null, 14),
                    new PLMXlsxRptColumn("wasPartRev", "Was Part Rev", FormatType.TEXT, null, null, 12),
                    new PLMXlsxRptColumn("wasPartDesc", "Was Part Desc", FormatType.TEXT, null, null, 28),
                    new PLMXlsxRptColumn("wasTargetCst", "Was Target Cost", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("isPart", "Is Part", FormatType.TEXT, null, null, 14),
                    new PLMXlsxRptColumn("isPartRev", "Is Part Rev", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("isPartDesc", "Is Part Desc", FormatType.TEXT, null, null, 28),
                    new PLMXlsxRptColumn("isTargetCst", "Is Target Cost", FormatType.TEXT, null, null, 12)
                    
		};

		PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] {
					new PLMXlsxRptColumn("ecoEcrName", "ECO/ECR Name:", FormatType.TEXT, null, null, 19)
		};
		
		forEcoEcr.setEcoEcrName(ecoEcrName);

		excelUtil.export(kpiCstEngList, reportColumns, fileName, fileName, true, critcolumns, forEcoEcr);
		
	}
	
	/**
	 * This method is used to download excel
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	
	public void downloadPLDExcel() throws PLMCommonException {
		
		LOG.info("Entering downloadPLDExcel Method");
		String reportName="ProjectLifeCycleReportExcelDoc";
		String fileName="ProjectLifeCycleReport";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("taskType", "Task Type", FormatType.TEXT, null, null, 19),
                    new PLMXlsxRptColumn("bussGroup", "Buss. Group", FormatType.TEXT, null, null, 11),
                    new PLMXlsxRptColumn("taskStatus", "Task Status", FormatType.TEXT, null, null, 17),
                    new PLMXlsxRptColumn("contractName", "Contract", FormatType.TEXT, null, null, 8),
                    new PLMXlsxRptColumn("projectName", "Project", FormatType.TEXT, null, null, 8),
                    new PLMXlsxRptColumn("projectDescription", "Project Description", FormatType.TEXT, null, null, 36),
                    new PLMXlsxRptColumn("geActivityCode", "Task", FormatType.TEXT, null, null, 6),
                    new PLMXlsxRptColumn("state", "Task State", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("estimatedFinishDte", "Estimated Finish Dte", FormatType.TEXT, null, null, 16),
                    new PLMXlsxRptColumn("cstmrNeedDte", "Customer Need Dte", FormatType.TEXT, null, null, 16),
                    new PLMXlsxRptColumn("clinInitialDeliveryDte", "CLIN Delivery Dte", FormatType.TEXT, null, null, 16),
                    new PLMXlsxRptColumn("actualFinishDte", "Actual Finish Dte", FormatType.TEXT, null, null, 16),
                    new PLMXlsxRptColumn("ownerName", "Task Owner's Name", FormatType.TEXT, null, null, 19),
                    new PLMXlsxRptColumn("taskOwnr", "Task Owner's SSO", FormatType.TEXT, null, null, 16),
                    new PLMXlsxRptColumn("geMfggDeliverableIndr", "Deliverable Ind.", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("geTaskResponsibleUnit", "Responsible Unit", FormatType.TEXT, null, null, 16),
                    new PLMXlsxRptColumn("geVoucherFundingSource", "Funding Source", FormatType.TEXT, null, null, 22)
                    
						};

		PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] {};

		excelUtil.export(dashboardDetailList, reportColumns, fileName, fileName, true, critcolumns, dashboardData);
		
	}
	
	/**
	 * This method is used for Generating Report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadPLDCSV() throws PLMCommonException {
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
				new PLMCsvRptColumn("taskType", "Task Type", FormatTypeCsv.TEXT, null, null, 19),
                new PLMCsvRptColumn("bussGroup", "Buss. Group", FormatTypeCsv.TEXT, null, null, 11),
                new PLMCsvRptColumn("taskStatus", "Task Status", FormatTypeCsv.TEXT, null, null, 17),
                new PLMCsvRptColumn("contractName", "Contract", FormatTypeCsv.TEXT, null, null, 8),
                new PLMCsvRptColumn("projectName", "Project", FormatTypeCsv.TEXT, null, null, 8),
                new PLMCsvRptColumn("projectDescription", "Project Description", FormatTypeCsv.	TEXT, null, null, 36),
                new PLMCsvRptColumn("geActivityCode", "Task", FormatTypeCsv.TEXT, null, null, 6),
                new PLMCsvRptColumn("state", "Task State", FormatTypeCsv.TEXT, null, null, 10),
                new PLMCsvRptColumn("estimatedFinishDte", "Estimated Finish Dte", FormatTypeCsv.TEXT, null, null, 16),
                new PLMCsvRptColumn("cstmrNeedDte", "Customer Need Dte", FormatTypeCsv.TEXT, null, null, 16),
                new PLMCsvRptColumn("clinInitialDeliveryDte", "CLIN Delivery Dte", FormatTypeCsv.TEXT, null, null, 16),
                new PLMCsvRptColumn("actualFinishDte", "Actual Finish Dte", FormatTypeCsv.TEXT, null, null, 16),
                new PLMCsvRptColumn("ownerName", "Task Owner's Name", FormatTypeCsv.TEXT, null, null, 19),
                new PLMCsvRptColumn("taskOwnr", "Task Owner's SSO", FormatTypeCsv.TEXT, null, null, 16),
                new PLMCsvRptColumn("geMfggDeliverableIndr", "Deliverable Ind.", FormatTypeCsv.TEXT, null, null, 15),
                new PLMCsvRptColumn("geTaskResponsibleUnit", "Responsible Unit", FormatTypeCsv.TEXT, null, null, 16),
                new PLMCsvRptColumn("geVoucherFundingSource", "Funding Source", FormatTypeCsv.TEXT, null, null, 22)
				
		};

		csvUtil.exportCsv(dashboardDetailList, reportColumns, "ProjectLifeCycleReport", dateFormat, false, null, null, ",");
		
	}
	
	//End Newly Added method of 1269 Req for 3.0.10 release
	/**
	 * @return the plmDashboardService
	 */
	public PLMDashboardServiceIfc getPlmDashboardService() {
		return plmDashboardService;
	}

	/**
	 * @param plmDashboardService
	 *            the plmDashboardService to set
	 */
	public void setPlmDashboardService(
			PLMDashboardServiceIfc plmDashboardService) {
		this.plmDashboardService = plmDashboardService;
	}

	public static Logger getLog() {
		return LOG;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the percentlistRowCount
	 */
	public int getPercentlistRowCount() {
		return percentlistRowCount;
	}


	/**
	 * @param percentlistRowCount the percentlistRowCount to set
	 */
	public void setPercentlistRowCount(int percentlistRowCount) {
		this.percentlistRowCount = percentlistRowCount;
	}
	


	/**
	 * @return the dashboardList
	 */
	public List<PLMDwgDashboardData> getDashboardList() {
		return dashboardList;
	}


	/**
	 * @param dashboardList the dashboardList to set
	 */
	public void setDashboardList(List<PLMDwgDashboardData> dashboardList) {
		this.dashboardList = dashboardList;
	}


	/**
	 * @return the dashboardList_clin
	 */
	public List<PLMDwgDashboardData> getDashboardList_clin() {
		return dashboardList_clin;
	}


	/**
	 * @param dashboardListClin the dashboardList_clin to set
	 */
	public void setDashboardList_clin(List<PLMDwgDashboardData> dashboardListClin) {
		dashboardList_clin = dashboardListClin;
	}


	/**
	 * @return the dashboardDetailList
	 */
	public List<PLMDwgDashboardData> getDashboardDetailList() {
		return dashboardDetailList;
	}


	/**
	 * @param dashboardDetailList the dashboardDetailList to set
	 */
	public void setDashboardDetailList(List<PLMDwgDashboardData> dashboardDetailList) {
		this.dashboardDetailList = dashboardDetailList;
	}


	/**
	 * @return the dashboardData
	 */
	public PLMDwgDashboardData getDashboardData() {
		return dashboardData;
	}


	/**
	 * @param dashboardData the dashboardData to set
	 */
	public void setDashboardData(PLMDwgDashboardData dashboardData) {
		this.dashboardData = dashboardData;
	}


	/**
	 * @return the dropDownMapList
	 */
	public Map<String, List<SelectItem>> getDropDownMapList() {
		return dropDownMapList;
	}


	/**
	 * @param dropDownMapList the dropDownMapList to set
	 */
	public void setDropDownMapList(Map<String, List<SelectItem>> dropDownMapList) {
		this.dropDownMapList = dropDownMapList;
	}


	/**
	 * @return the contractNamesList
	 */
	public List<SelectItem> getContractNamesList() {
		return contractNamesList;
	}


	/**
	 * @param contractNamesList the contractNamesList to set
	 */
	public void setContractNamesList(List<SelectItem> contractNamesList) {
		this.contractNamesList = contractNamesList;
	}


	/**
	 * @return the selectedContractNamesList
	 */
	public List<String> getSelectedContractNamesList() {
		return selectedContractNamesList;
	}


	/**
	 * @param selectedContractNamesList the selectedContractNamesList to set
	 */
	public void setSelectedContractNamesList(List<String> selectedContractNamesList) {
		this.selectedContractNamesList = selectedContractNamesList;
	}


	/**
	 * @return the rowIndexForSeparator
	 */
	public int getRowIndexForSeparator() {
		return rowIndexForSeparator;
	}


	/**
	 * @param rowIndexForSeparator the rowIndexForSeparator to set
	 */
	public void setRowIndexForSeparator(int rowIndexForSeparator) {
		this.rowIndexForSeparator = rowIndexForSeparator;
	}


	/**
	 * @return the typ1RowCount
	 */
	public int getTyp1RowCount() {
		return typ1RowCount;
	}


	/**
	 * @param typ1RowCount the typ1RowCount to set
	 */
	public void setTyp1RowCount(int typ1RowCount) {
		this.typ1RowCount = typ1RowCount;
	}


	/**
	 * @return the typ2RowCount
	 */
	public int getTyp2RowCount() {
		return typ2RowCount;
	}


	/**
	 * @param typ2RowCount the typ2RowCount to set
	 */
	public void setTyp2RowCount(int typ2RowCount) {
		this.typ2RowCount = typ2RowCount;
	}


	/**
	 * @return the detaillistRowCount
	 */
	public int getDetaillistRowCount() {
		return detaillistRowCount;
	}


	/**
	 * @param detaillistRowCount the detaillistRowCount to set
	 */
	public void setDetaillistRowCount(int detaillistRowCount) {
		this.detaillistRowCount = detaillistRowCount;
	}


	/**
	 * @return the detaillistRowCountMsg
	 */
	public String getDetaillistRowCountMsg() {
		return detaillistRowCountMsg;
	}


	/**
	 * @param detaillistRowCountMsg the detaillistRowCountMsg to set
	 */
	public void setDetaillistRowCountMsg(String detaillistRowCountMsg) {
		this.detaillistRowCountMsg = detaillistRowCountMsg;
	}


	/**
	 * @return the page
	 */
	public String getPage() {
		return page;
	}


	/**
	 * @param page the page to set
	 */
	public void setPage(String page) {
		this.page = page;
	}


	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}


	/**
	 * @param recordCounts the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}


	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}


	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}


	/**
	 * @return the gtFlag
	 */
	public String getGtFlag() {
		return gtFlag;
	}


	/**
	 * @param gtFlag the gtFlag to set
	 */
	public void setGtFlag(String gtFlag) {
		this.gtFlag = gtFlag;
	}


	/**
	 * @return the gtGenFlag
	 */
	public String getGtGenFlag() {
		return gtGenFlag;
	}


	/**
	 * @param gtGenFlag the gtGenFlag to set
	 */
	public void setGtGenFlag(String gtGenFlag) {
		this.gtGenFlag = gtGenFlag;
	}


	/**
	 * @return the stFlag
	 */
	public String getStFlag() {
		return stFlag;
	}


	/**
	 * @param stFlag the stFlag to set
	 */
	public void setStFlag(String stFlag) {
		this.stFlag = stFlag;
	}


	/**
	 * @return the stGenFlag
	 */
	public String getStGenFlag() {
		return stGenFlag;
	}


	/**
	 * @param stGenFlag the stGenFlag to set
	 */
	public void setStGenFlag(String stGenFlag) {
		this.stGenFlag = stGenFlag;
	}


	/**
	 * @return the tskTypFullCu
	 */
	public String getTskTypFullCu() {
		return tskTypFullCu;
	}


	/**
	 * @param tskTypFullCu the tskTypFullCu to set
	 */
	public void setTskTypFullCu(String tskTypFullCu) {
		this.tskTypFullCu = tskTypFullCu;
	}


	/**
	 * @return the tskTypDescCu1
	 */
	public String getTskTypDescCu1() {
		return tskTypDescCu1;
	}


	/**
	 * @param tskTypDescCu1 the tskTypDescCu1 to set
	 */
	public void setTskTypDescCu1(String tskTypDescCu1) {
		this.tskTypDescCu1 = tskTypDescCu1;
	}


	/**
	 * @return the tskTypDescCu2
	 */
	public String getTskTypDescCu2() {
		return tskTypDescCu2;
	}


	/**
	 * @param tskTypDescCu2 the tskTypDescCu2 to set
	 */
	public void setTskTypDescCu2(String tskTypDescCu2) {
		this.tskTypDescCu2 = tskTypDescCu2;
	}


	/**
	 * @return the tskTypFullHw
	 */
	public String getTskTypFullHw() {
		return tskTypFullHw;
	}


	/**
	 * @param tskTypFullHw the tskTypFullHw to set
	 */
	public void setTskTypFullHw(String tskTypFullHw) {
		this.tskTypFullHw = tskTypFullHw;
	}


	/**
	 * @return the tskTypDescHw1
	 */
	public String getTskTypDescHw1() {
		return tskTypDescHw1;
	}


	/**
	 * @param tskTypDescHw1 the tskTypDescHw1 to set
	 */
	public void setTskTypDescHw1(String tskTypDescHw1) {
		this.tskTypDescHw1 = tskTypDescHw1;
	}


	/**
	 * @return the tskTypDescHw2
	 */
	public String getTskTypDescHw2() {
		return tskTypDescHw2;
	}


	/**
	 * @param tskTypDescHw2 the tskTypDescHw2 to set
	 */
	public void setTskTypDescHw2(String tskTypDescHw2) {
		this.tskTypDescHw2 = tskTypDescHw2;
	}


	/**
	 * @return the activeTask
	 */
	public boolean isActiveTask() {
		return activeTask;
	}


	/**
	 * @param activeTask the activeTask to set
	 */
	public void setActiveTask(boolean activeTask) {
		this.activeTask = activeTask;
	}


	/**
	 * @return the dataTable
	 */
	public HtmlDataTable getDataTable() {
		return dataTable;
	}


	/**
	 * @param dataTable the dataTable to set
	 */
	public void setDataTable(HtmlDataTable dataTable) {
		this.dataTable = dataTable;
	}
	
	
	// Added by Sekhar
	/**
	 * @return the finalDashboardList
	 */
	public List<PLMDwgDashboardData> getFinalDashboardList() {
		return finalDashboardList;
	}
	/**
	 * @param finalDashboardList the finalDashboardList to set
	 */
	public void setFinalDashboardList(
			List<PLMDwgDashboardData> finalDashboardList) {
		this.finalDashboardList = finalDashboardList;
	}


	/**
	 * @return the kpiCstAltMessage
	 */
	public String getKpiCstAltMessage() {
		return kpiCstAltMessage;
	}
	/**
	 * @param kpiCstAltMessage the kpiCstAltMessage to set
	 */
	public void setKpiCstAltMessage(String kpiCstAltMessage) {
		this.kpiCstAltMessage = kpiCstAltMessage;
	}
	/**
	 * @return the ecoEcrName
	 */
	public String getEcoEcrName() {
		return ecoEcrName;
	}

	/**
	 * @param ecoEcrName the ecoEcrName to set
	 */
	public void setEcoEcrName(String ecoEcrName) {
		this.ecoEcrName = ecoEcrName;
	}
	/**
	 * @return the kpiCstRecordContMsg
	 */
	public String getKpiCstRecordContMsg() {
		return kpiCstRecordContMsg;
	}
	/**
	 * @param kpiCstRecordContMsg the kpiCstRecordContMsg to set
	 */
	public void setKpiCstRecordContMsg(String kpiCstRecordContMsg) {
		this.kpiCstRecordContMsg = kpiCstRecordContMsg;
	}
	/**
	 * @return the kpiCstEngList
	 */
	public List<PLMkpiCostEngData> getKpiCstEngList() {
		return kpiCstEngList;
	}
	/**
	 * @param kpiCstEngList the kpiCstEngList to set
	 */
	public void setKpiCstEngList(List<PLMkpiCostEngData> kpiCstEngList) {
		this.kpiCstEngList = kpiCstEngList;
	}
	/**
	 * @return the kpiCstEngCount
	 */
	public int getKpiCstEngCount() {
		return kpiCstEngCount;
	}
	/**
	 * @param kpiCstEngCount the kpiCstEngCount to set
	 */
	public void setKpiCstEngCount(int kpiCstEngCount) {
		this.kpiCstEngCount = kpiCstEngCount;
	}


}
