/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName UIJavascriptInclude.java
 * @Creation date: 18-Aug-2014
 * @version 1.0
  * @author : Tech Mahindra
 */
package com.geinfra.geaviation.pwi.faces;

import java.io.IOException;

import javax.el.ValueExpression;
import javax.faces.component.UIComponentBase;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.context.PWiApplication;
import com.geinfra.geaviation.pwi.context.PWiApplicationContext;
import com.geinfra.geaviation.pwi.context.PWiContext;
import com.geinfra.geaviation.pwi.context.PWiRequest;
import com.geinfra.geaviation.pwi.context.PWiSession;

public class UIJavascriptInclude extends UIComponentBase {
	private String javascriptPath;
	private String timestamp;
	
	public UIJavascriptInclude() throws PWiException {
		PWiRequest request = PWiContext.getCurrentInstance().getRequest();

		// stylesheet path
		String contextPath = request.getContextPath();
		this.javascriptPath = contextPath + "/js/";

		// timestamp
		PWiSession session = request.getSession();
		PWiApplication PWiApplication = (PWiApplication) session
				.getApplication();
		PWiApplicationContext pwiApplicationContext = (PWiApplicationContext) PWiApplication
				.getAttribute(PWiApplicationContext.ATTRIBUTE_NAME);
		this.timestamp = pwiApplicationContext
				.getApplicationContextTimestamp();
	}
	
	@Override
	public String getFamily() {
		return "javascriptInclude";
	}

	public String getRendererType() {
		return "renderer";
	}

	public void encodeBegin(FacesContext context) throws IOException {
		String name = getString("name");
		String src = javascriptPath + name + ".js?" + timestamp;
		
		ResponseWriter writer = context.getResponseWriter();
		writer.startElement("script", this);
		writer.writeAttribute("type", "text/javascript", null);
		writer.writeAttribute("src", src, null);
		writer.endElement("script");
	}

	public void encodeEnd(FacesContext context) throws IOException {
		return;
	}

	public void decode(FacesContext context) {
		return;
	}

	private String getString(String name) {
		String value = null;
		ValueExpression ve = getValueExpression(name);
		if (ve != null) {
			value = (String) ve.getValue(getFacesContext().getELContext());
		} else {
			value = (String) getAttributes().get(name);
		}
		return value;
	}
}
