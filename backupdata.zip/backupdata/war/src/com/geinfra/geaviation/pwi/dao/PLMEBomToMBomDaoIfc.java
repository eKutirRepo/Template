/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEBomToMBomDaoIfc.java
 * @Creation date: 06-Sept-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.data.PLMEBomToMBomData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMEBomToMBomDaoIfc {
	
	/**
	 * This method is used to get Parts for valid
	 * 
	 * @param partList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<String> getValidPartList(List<String> partList) throws PLMCommonException;
	
	/**
	 * This method is used to get EBOM Data
	 * 
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEBomToMBomData> getEBOMDataForPartName(String partNumber) throws PLMCommonException;

	
	/**
	 * This method is used to get PLM MBOM Data
	 * 
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEBomToMBomData> getPlmMBOMDataForPartName(String partNumber) throws PLMCommonException;
	/**
	 * This method is used to get Copics MBOM Data
	 * 
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEBomToMBomData> getCopicsMBOMDataForPartName(String partNumber) throws PLMCommonException;
	/**
	 * This method is used to get Contract for Part Name
	 * 
	 * @param partList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEBomToMBomData> getContractForPartName(List<String> partList) throws PLMCommonException;


}
