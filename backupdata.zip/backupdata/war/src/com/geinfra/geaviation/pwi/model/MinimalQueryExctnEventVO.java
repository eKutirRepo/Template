/*
 //  @ Project : PWi
 //  @ File Name : PWiUserCustomQueryVO.java
 //  @ Date : 5/14/2010
 //  @ Author : nisverma
 */

package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : MinimalQueryExctnEventVO - Object representation of the query
 * execution event table.
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class MinimalQueryExctnEventVO implements Serializable {
	public static final String QRY_EXCTN_EVNT_SEQ_ID = "QRY_EXCTN_EVNT_SEQ_ID";
	public static final String QRY_SEQ_ID = "QRY_SEQ_ID";
	public static final String PRTY_CSTM_QRY_SEQ_ID = "PRTY_CSTM_QRY_SEQ_ID";
	public static final String EXCTD_BY_EMPLY_SSO_ID = "EXCTD_BY_EMPLY_SSO_ID";
	public static final String QRY_EXCTN_DTTM = "QRY_EXCTN_DTTM";
	public static final String QRY_EXCTN_SCNDS_DRTN = "QRY_EXCTN_SCNDS_DRTN";
	public static final String QRY_OTPT_COL_CNT = "QRY_OTPT_COL_CNT";
	public static final String QRY_OTPT_ROWS_CNT = "QRY_OTPT_ROWS_CNT";
	public static final String QRY_EXCTN_SCCS_IND = "QRY_EXCTN_SCCS_IND";
	public static final String QRY_ERR_MSG_TXT = "QRY_ERR_MSG_TXT";
	public static final String QRY_SLCTD_COL_NM = "QRY_SLCTD_COL_NM";
	public static final String QRY_SRCH_CRTR_TXT = "QRY_SRCH_CRTR_TXT";
	public static final String CRTN_DT = "CRTN_DT";
	public static final String CRTD_BY = "CRTD_BY";
	public static final String LST_UPDT_DT = "LST_UPDT_DT";
	public static final String LST_UPDTD_BY = "LST_UPDTD_BY";
	public static final String QRY_PROCESSOR_NM = "QRY_PROCESSOR_NM";
	public static final String QRY_EXCTN_MODE = "QRY_EXCTN_MODE";
	public static final String QRY_OUTPUT_TYPE = "QRY_OUTPUT_TYPE";
	public static final String QRY_TEMPLATE_ID = "QRY_TEMPLATE_ID";
	public static final String QRY_EXECUTED_FROM = "QRY_EXECUTED_FROM";
	public static final String QRY_RERUNNABLE = "QRY_RERUNNABLE";

	private static final long serialVersionUID = 1L;

	private Integer eventId;
	private Date dateExecuted;
	private int rowCount;
	private String searchCriteriaXml;
	private String executionMode;
	private String outputType;
	private boolean rerunnable;
	private String queryName;

	public MinimalQueryExctnEventVO() {
	}

	public MinimalQueryExctnEventVO(MinimalQueryExctnEventVO event) {
		eventId = event.eventId;
		dateExecuted = event.dateExecuted;
		rowCount = event.rowCount;
		searchCriteriaXml = event.searchCriteriaXml;
		executionMode = event.executionMode;
		outputType = event.outputType;
		rerunnable = event.rerunnable;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (eventId != null ? eventId.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object instanceof MinimalQueryExctnEventVO) {
			MinimalQueryExctnEventVO other = (MinimalQueryExctnEventVO) object;
			if (this.eventId != null && other.eventId != null) {
				return this.eventId.equals(other.eventId);
			}
		}
		return false;
	}

	@Override
	public String toString() {
		return "com.geinfra.geaviation.pwi.model.PWiQueryExctnEvent[qryExctnEvntSeqId="
				+ eventId + "]";
	}

	public Integer getEventId() {
		return eventId;
	}

	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	public Date getDateExecuted() {
		return dateExecuted != null ? new Date(dateExecuted.getTime()) : null;
	}

	public void setDateExecuted(Date dateExecuted) {
		this.dateExecuted = dateExecuted != null ? new Date(dateExecuted
				.getTime()) : null;
	}

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public String getSearchCriteriaXml() {
		return searchCriteriaXml;
	}

	public void setSearchCriteriaXml(String searchCriteriaXml) {
		this.searchCriteriaXml = searchCriteriaXml;
	}

	public String getExecutionMode() {
		return executionMode;
	}

	public void setExecutionMode(String executionMode) {
		this.executionMode = executionMode;
	}

	public String getOutputType() {
		return outputType;
	}

	public void setOutputType(String outputType) {
		this.outputType = outputType;
	}

	public boolean isRerunnable() {
		return rerunnable;
	}

	public void setRerunnable(boolean rerunnable) {
		this.rerunnable = rerunnable;
	}

	public String getQueryName() {
		return queryName;
	}

	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}
}
