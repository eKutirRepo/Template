/**
 * Copyright (C) 2012 GE Infra. 
 * All rights reserved 
 * @FileName PLMPddrDaoIfc.java
 * @author : Tech Mahindra (PLMR Team)
 */


package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.data.PLMPddrData;
import com.geinfra.geaviation.pwi.data.PLMPddrSearchData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

/**
 * PLMPddrDaoIfc is the DAO interface used for SBoM Add/Update usecase.
 */
public interface PLMPddrDaoIfc {


	/**
	 * This methods is used for getChildForParent
	 * 
	 * @param mplNumber
	 * @param level
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMPddrData> getChildForParent(List<String> mplNumber,
			String level) throws PLMCommonException;
	
	
	/**
	 * This methods is used for getChildForParentList
	 * 
	 * @param topmplNumber
	 * @param navigList
	 * @param level
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMPddrData> getChildForParentList(String topmplNumber,
			List<PLMPddrData> navigList, int level) throws PLMCommonException;


	/**
	 * This methods is used for searchItemExplorer
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMPddrSearchData> searchItemExplorer() throws PLMCommonException;
	
	/**
	 * This methods is used for getPFDetails
	 * 
	 * @param nodeTitleP
	 * @return PLMPddrData
	 * @throws PLMCommonException
	 */
	public PLMPddrData getPFDetails(String nodeTitleP) throws PLMCommonException;
	
	/**
	 * This methods is used for getTdPddrResult
	 * 
	 * @param pfName
	 * @param sso
	 * @return PLMPddrData
	 * @throws PLMCommonException
	 */
	public PLMPddrData getTdPddrResult(String pfName, String sso) throws PLMCommonException;
			
}
