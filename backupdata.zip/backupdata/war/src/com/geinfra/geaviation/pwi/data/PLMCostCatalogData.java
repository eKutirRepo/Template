/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCostCatalogData.java
 * @Creation date: 12-Aug-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMCostCatalogData {
	 /**
	 *  Holds the partId
	 */	
	private String partId;
	
	 /**
	 *  Holds the partName
	 */	
	private String partName;

	 /**
	 *  Holds the partRevision
	 */
	private String partRevision;
	 /**
	 *  Holds the lfName
	 */
	private String lfName;
	 /**
	 *  Holds the lfDesc
	 */
	private String lfDesc;
	 /**
	 *  Holds the mli
	 */
	private String mli;
	 /**
	 *  Holds the pin
	 */
	private String pin;
	 /**
	 *  Holds the quantity
	 */
	private int quantity;
	 /**
	 *  Holds the totalMaterialCost
	 */
	private int totalMaterialCost;
	 /**
	 *  Holds the totalLabourCost
	 */
	private int totalLabourCost;
	 /**
	 *  Holds the totalCost
	 */
	private int totalCost;
	 /**
	 *  Holds the totalLabourHours
	 */
	private int totalLabourHours;
	
	 /**
	 *  Holds the costItemType
	 */
	private String costItemType;

	 /**
	 *  Holds the msdfLogicCal
	 */
	private String msdfLogicCal;
	 /**
	 *  Holds the systemName
	 */
	private String systemName;
	
	 /**
	 *  Holds the hardwarePrd
	 */
	private String hardwarePrd;
	
	
	 /**
	 *  Holds the hardwarePrdRev
	 */
	private String hardwarePrdRev;
	
	
	 /**
	 *  Holds the quantityExl
	 */
	private double quantityExl;
	 /**
	 *  Holds the totalMaterialCostExl
	 */
	private double totalMaterialCostExl;
	 /**
	 *  Holds the totalLabourCostExl
	 */
	private double totalLabourCostExl;
	 /**
	 *  Holds the totalCostExl
	 */
	private double totalCostExl;
	 /**
	 *  Holds the totalLabourHoursExl
	 */
	private double totalLabourHoursExl;
	
	/**
	 * @return the partName
	 */
	public String getPartName() {
		return partName;
	}
	/**
	 * @param partName the partName to set
	 */
	public void setPartName(String partName) {
		this.partName = partName;
	}
	/**
	 * @return the partRevision
	 */
	public String getPartRevision() {
		return partRevision;
	}
	/**
	 * @param partRevision the partRevision to set
	 */
	public void setPartRevision(String partRevision) {
		this.partRevision = partRevision;
	}
	/**
	 * @return the lfName
	 */
	public String getLfName() {
		return lfName;
	}
	/**
	 * @param lfName the lfName to set
	 */
	public void setLfName(String lfName) {
		this.lfName = lfName;
	}
	/**
	 * @return the lfDesc
	 */
	public String getLfDesc() {
		return lfDesc;
	}
	/**
	 * @param lfDesc the lfDesc to set
	 */
	public void setLfDesc(String lfDesc) {
		this.lfDesc = lfDesc;
	}
	/**
	 * @return the mli
	 */
	public String getMli() {
		return mli;
	}
	/**
	 * @param mli the mli to set
	 */
	public void setMli(String mli) {
		this.mli = mli;
	}
	
	
	/**
	 * @return the costItemType
	 */
	public String getCostItemType() {
		return costItemType;
	}
	/**
	 * @param costItemType the costItemType to set
	 */
	public void setCostItemType(String costItemType) {
		this.costItemType = costItemType;
	}
	/**
	 * @return the partId
	 */
	public String getPartId() {
		return partId;
	}
	/**
	 * @param partId the partId to set
	 */
	public void setPartId(String partId) {
		this.partId = partId;
	}
	/**
	 * @return the msdfLogicCal
	 */
	public String getMsdfLogicCal() {
		return msdfLogicCal;
	}
	/**
	 * @param msdfLogicCal the msdfLogicCal to set
	 */
	public void setMsdfLogicCal(String msdfLogicCal) {
		this.msdfLogicCal = msdfLogicCal;
	}
	/**
	 * @return the pin
	 */
	public String getPin() {
		return pin;
	}
	/**
	 * @param pin the pin to set
	 */
	public void setPin(String pin) {
		this.pin = pin;
	}
	/**
	 * @return the systemName
	 */
	public String getSystemName() {
		return systemName;
	}
	/**
	 * @param systemName the systemName to set
	 */
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	/**
	 * @return the hardwarePrd
	 */
	public String getHardwarePrd() {
		return hardwarePrd;
	}
	/**
	 * @param hardwarePrd the hardwarePrd to set
	 */
	public void setHardwarePrd(String hardwarePrd) {
		this.hardwarePrd = hardwarePrd;
	}
	/**
	 * @return the hardwarePrdRev
	 */
	public String getHardwarePrdRev() {
		return hardwarePrdRev;
	}
	/**
	 * @param hardwarePrdRev the hardwarePrdRev to set
	 */
	public void setHardwarePrdRev(String hardwarePrdRev) {
		this.hardwarePrdRev = hardwarePrdRev;
	}
	/**
	 * @return the totalMaterialCost
	 */
	public int getTotalMaterialCost() {
		return totalMaterialCost;
	}
	/**
	 * @param totalMaterialCost the totalMaterialCost to set
	 */
	public void setTotalMaterialCost(int totalMaterialCost) {
		this.totalMaterialCost = totalMaterialCost;
	}
	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return the totalLabourCost
	 */
	public int getTotalLabourCost() {
		return totalLabourCost;
	}
	/**
	 * @param totalLabourCost the totalLabourCost to set
	 */
	public void setTotalLabourCost(int totalLabourCost) {
		this.totalLabourCost = totalLabourCost;
	}
	/**
	 * @return the totalCost
	 */
	public int getTotalCost() {
		return totalCost;
	}
	/**
	 * @param totalCost the totalCost to set
	 */
	public void setTotalCost(int totalCost) {
		this.totalCost = totalCost;
	}
	/**
	 * @return the totalLabourHours
	 */
	public int getTotalLabourHours() {
		return totalLabourHours;
	}
	/**
	 * @param totalLabourHours the totalLabourHours to set
	 */
	public void setTotalLabourHours(int totalLabourHours) {
		this.totalLabourHours = totalLabourHours;
	}
	/**
	 * @return the quantityExl
	 */
	public double getQuantityExl() {
		return quantityExl;
	}
	/**
	 * @param quantityExl the quantityExl to set
	 */
	public void setQuantityExl(double quantityExl) {
		this.quantityExl = quantityExl;
	}
	/**
	 * @return the totalMaterialCostExl
	 */
	public double getTotalMaterialCostExl() {
		return totalMaterialCostExl;
	}
	/**
	 * @param totalMaterialCostExl the totalMaterialCostExl to set
	 */
	public void setTotalMaterialCostExl(double totalMaterialCostExl) {
		this.totalMaterialCostExl = totalMaterialCostExl;
	}
	/**
	 * @return the totalLabourCostExl
	 */
	public double getTotalLabourCostExl() {
		return totalLabourCostExl;
	}
	/**
	 * @param totalLabourCostExl the totalLabourCostExl to set
	 */
	public void setTotalLabourCostExl(double totalLabourCostExl) {
		this.totalLabourCostExl = totalLabourCostExl;
	}
	/**
	 * @return the totalCostExl
	 */
	public double getTotalCostExl() {
		return totalCostExl;
	}
	/**
	 * @param totalCostExl the totalCostExl to set
	 */
	public void setTotalCostExl(double totalCostExl) {
		this.totalCostExl = totalCostExl;
	}
	/**
	 * @return the totalLabourHoursExl
	 */
	public double getTotalLabourHoursExl() {
		return totalLabourHoursExl;
	}
	/**
	 * @param totalLabourHoursExl the totalLabourHoursExl to set
	 */
	public void setTotalLabourHoursExl(double totalLabourHoursExl) {
		this.totalLabourHoursExl = totalLabourHoursExl;
	}
	
	
	
	
	
	
	
}
