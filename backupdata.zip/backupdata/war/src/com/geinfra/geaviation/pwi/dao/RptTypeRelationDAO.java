/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName RptTypeRelationDAO.java
 * @Creation date: 18-June-2014
 * @version 1.0
  * @author : Tech Mahindra
 */

package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.RptTypeRelationVo;
import com.geinfra.geaviation.pwi.service.vo.TypeRelationData;

public interface RptTypeRelationDAO {
	
	
	public List<RptTypeRelationVo> getColumnsFrType(String selectedType)throws PWiException;
	public List<TypeRelationData> getTypeRelData() throws  PWiException;

}
