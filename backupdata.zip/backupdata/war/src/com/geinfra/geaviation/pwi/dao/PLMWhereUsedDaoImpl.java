/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhereUsedDaoImpl.java
 * @Creation date: 23-July-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMCMUSmlrToPrjData;
import com.geinfra.geaviation.pwi.data.PLMImpactAnalysisData;
import com.geinfra.geaviation.pwi.data.PLMWhereUsedData;
import com.geinfra.geaviation.pwi.data.PLMWhereUsedReqData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMQueryConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMWhereusedQueries;

public class PLMWhereUsedDaoImpl extends SimpleJdbcDaoSupport implements
		PLMWhereUsedDaoIfc {
	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger
			.getLogger(PLMWhereUsedDaoImpl.class);
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");

	/**
	 * This method is used for getWhereUsedData
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getWhereUsedData(
			String partNumber) throws PLMCommonException {
		
		LOG.info("Inside WhereUsed DAO Impl");
		List<PLMWhereUsedData> plmWhereUsedResultList = null;
		try{

		if (partNumber != null) {
			String whereUsedQry = PLMQueryConstants.GET_WHEREUSED1.replace("?", partNumber);
			LOG.info("Part Number : " + partNumber);
			LOG.info("Query 1 : " + whereUsedQry);
			getJdbcTemplate().execute(whereUsedQry);
			
			LOG.info("Query 2 : " + PLMQueryConstants.GET_WHEREUSED2);
			getJdbcTemplate().execute(PLMQueryConstants.GET_WHEREUSED2);
			
			LOG.info("Query 3 : " + PLMQueryConstants.GET_WHEREUSED3);
			getJdbcTemplate().execute(PLMQueryConstants.GET_WHEREUSED3);
			
			LOG.info("Query 4 : " + PLMQueryConstants.GET_WHEREUSED4);
			getJdbcTemplate().execute(PLMQueryConstants.GET_WHEREUSED4);
			
			LOG.info("Query 5 : " + PLMQueryConstants.GET_WHEREUSED5);
			getJdbcTemplate().execute(PLMQueryConstants.GET_WHEREUSED5);
			
			LOG.info("Query 6 : " + PLMQueryConstants.GET_WHEREUSED6);
			getJdbcTemplate().execute(PLMQueryConstants.GET_WHEREUSED6);
			
			LOG.info("Query 7 : " + PLMQueryConstants.GET_WHEREUSED7);
			plmWhereUsedResultList = getSimpleJdbcTemplate().query(PLMQueryConstants.GET_WHEREUSED7, new WhereUsedSearchResultsMapper());			
			LOG.info("Where Used Result List size : " + plmWhereUsedResultList.size());
			
			LOG.info("Dropping Table 1 : " + PLMQueryConstants.DROP_TABLE1);
			getJdbcTemplate().execute(PLMQueryConstants.DROP_TABLE1);
			
			LOG.info("Dropping Table 2 : " + PLMQueryConstants.DROP_TABLE2);
			getJdbcTemplate().execute(PLMQueryConstants.DROP_TABLE2);
			
			LOG.info("Dropping Table 3 : " + PLMQueryConstants.DROP_TABLE3);
			getJdbcTemplate().execute(PLMQueryConstants.DROP_TABLE3);
			
			LOG.info("Dropping Table 4 : " + PLMQueryConstants.DROP_TABLE4);
			getJdbcTemplate().execute(PLMQueryConstants.DROP_TABLE4);
			
			LOG.info("Dropping Table 5 : " + PLMQueryConstants.DROP_TABLE5);
			getJdbcTemplate().execute(PLMQueryConstants.DROP_TABLE5);
			
			LOG.info("Dropping Table 6 : " + PLMQueryConstants.DROP_TABLE6);
			getJdbcTemplate().execute(PLMQueryConstants.DROP_TABLE6);
		}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return plmWhereUsedResultList;
	}
	
	/**
	 * Mapper for Getting Where Used Search results.
	 */
	//private static ParameterizedRowMapper<PLMWhereUsedData> whereUsedSearchResultsMapper = new ParameterizedRowMapper<PLMWhereUsedData>() {
	private static final class WhereUsedSearchResultsMapper implements ParameterizedRowMapper<PLMWhereUsedData>{	
	public PLMWhereUsedData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMWhereUsedData plmWhereUsedData = new PLMWhereUsedData();
			plmWhereUsedData.setPartNumber(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_PART_NUMBER)));
			plmWhereUsedData.setUnitNumber(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_UNIT_NUMBER)));
			plmWhereUsedData.setDesignMemo(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_DESIGN_DEMO)));
			plmWhereUsedData.setShopOrder(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_SHOP_ORDER)));
			plmWhereUsedData.setSerialNo(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_SERIAL_NUMBER)));
			plmWhereUsedData.setStatus(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_STATUS)));
			return plmWhereUsedData;
		}
	//	};
	}
	
	/**
	 * This method is used for getWhereUsedLOUBOMQuery
	 * 
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getWhereUsedLOUBOMQuery(String partNumber) throws PLMCommonException {
		LOG.info("Where Used LOU BOMs List (Query-1) : " + PLMQueryConstants.GET_WHEREUSED_BMTI_LOU1 + "\n");
		return getSimpleJdbcTemplate().query(PLMQueryConstants.GET_WHEREUSED_BMTI_LOU1, new WhereUsedLOUResultsMapper(), new Object[] {partNumber});			   
	}
	
	/**
	 * This method is used for getWhereUsedLOUBOMQuery
	 * 
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getWhereUsedLOUParentQuery(String bomItem, String partNumber) throws PLMCommonException {
		LOG.info("Where Used LOU Parents List (Query-2) : " + PLMQueryConstants.GET_WHEREUSED_BMTI_LOU2  + "\n");
		return getSimpleJdbcTemplate().query(PLMQueryConstants.GET_WHEREUSED_BMTI_LOU2, new WhereUsedLOUResultsMapper(), new Object[] {bomItem, partNumber});
	}
	
	/**
	 * This method is used for getWhereUsedLOUDetailQuery
	 * 
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getWhereUsedLOUDetailQuery(String partNumber) throws PLMCommonException {
		LOG.info("Where Used LOU Detail Result (Query-3) : " + PLMQueryConstants.GET_WHEREUSED_BMTI_LOU3  + "\n");
		return getSimpleJdbcTemplate().query(PLMQueryConstants.GET_WHEREUSED_BMTI_LOU3, new WhereUsedLOUDetailResultsMapper(), new Object[] {partNumber});			   
	}
	
	/**
	 * This method is used for findInfiniteLoop
	 * 
	 * @param whereUsedLOUIntermediatoryList,immediateParent
	 * @return boolean
	 */
	public boolean findInfiniteLoop(List<PLMWhereUsedData> whereUsedLOUIntermediatoryList,String immediateParent){
		boolean returnFlag = false;
		if (!PLMUtils.isEmptyList(whereUsedLOUIntermediatoryList)) {
			for (int  i = 0; i < whereUsedLOUIntermediatoryList.size(); i++) {
				String prevImmediateParent = whereUsedLOUIntermediatoryList.get(i).getDwgNo();
				if(immediateParent.equals(prevImmediateParent)){
					returnFlag = true;
					break;
				}
			}
		}
		return returnFlag;
	}
	/**
	 * This method is used for getWhereUsedLOUReport
	 * 
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getWhereUsedLOUReport(String partNumber) throws PLMCommonException {
		LOG.info("Entering getWhereUsedLOUReport method");
		List<PLMWhereUsedData> whereUsedLOUFinalList = new ArrayList<PLMWhereUsedData>();
		List<PLMWhereUsedData> whereUsedLOUFinalDetailList = new ArrayList<PLMWhereUsedData>();
		List<PLMWhereUsedData> tempWhereUsedLOUBOMList = new ArrayList<PLMWhereUsedData>();
		PLMWhereUsedData invalidBomObj;
		String bomItem = "";
		String parentPartNumber ="";
		try{	
		// "Query-1" 
		LOG.info("Input Part Number by user : " + partNumber + "\n");
		List<PLMWhereUsedData> whereUsedLOUBOMList = getWhereUsedLOUBOMQuery(partNumber);
		
		if (!PLMUtils.isEmptyList(whereUsedLOUBOMList)) {
			//Displaying BOMs One by One 
			for (int  i= 0; i < whereUsedLOUBOMList.size(); i++) {
				LOG.info("List of BOMs " + (i + 1) + " : " + whereUsedLOUBOMList.get(i).getDwgNo());
			}
			LOG.info("\n");
			//Iterating BOMs One by One 
			for (int i = 0; i < whereUsedLOUBOMList.size(); i++) {
				List<PLMWhereUsedData> whereUsedLOUIntermediatoryList = new ArrayList<PLMWhereUsedData>();
				PLMWhereUsedData partNumberObjData = new PLMWhereUsedData();
				partNumberObjData.setDwgNo(partNumber);
				whereUsedLOUIntermediatoryList.add(partNumberObjData);
				bomItem = whereUsedLOUBOMList.get(i).getDwgNo();
				LOG.info("BOM Item " + (i + 1) + " : " + bomItem + "\n");
				parentPartNumber = partNumber;
				int level = 0;
				while (true) {
					// "Query-2"
					List<PLMWhereUsedData> immediateParentList = getWhereUsedLOUParentQuery(bomItem, parentPartNumber);
					invalidBomObj = new PLMWhereUsedData();
					PLMWhereUsedData immediateParentObj = new PLMWhereUsedData();
					LOG.info(immediateParentObj);
					String immediateParent = "";
					LOG.info(immediateParent);
					if(!PLMUtils.isEmptyList(immediateParentList)) {
						immediateParentObj = immediateParentList.get(0);
						immediateParent = immediateParentObj.getDwgNo();
						LOG.info("Found Immediate Parent : " + immediateParent);
						if(bomItem.equals(immediateParent)){
							whereUsedLOUIntermediatoryList.add(immediateParentObj);
							LOG.info("Found Unique - Top level Bom and Immediate Parents are Same");
							LOG.info("Breaking Current Iteration\n");
							break;
						}
					} else {
						whereUsedLOUIntermediatoryList.clear();
						invalidBomObj.setInvalidBom(bomItem);
						invalidBomObj.setInvalidData(true);
						whereUsedLOUIntermediatoryList.add(invalidBomObj);
						LOG.info("No Immediate Parent Found");
						LOG.info("Invalid BOM Item : " + bomItem);
						LOG.info("Breaking Current Iteration\n");
						break;
					}
					if(!PLMUtils.isEmpty(immediateParent) && findInfiniteLoop(whereUsedLOUIntermediatoryList,immediateParent)){
						whereUsedLOUIntermediatoryList.clear();
						invalidBomObj.setInvalidBom(bomItem);
						invalidBomObj.setInvalidData(true);
						whereUsedLOUIntermediatoryList.add(invalidBomObj);
						LOG.info("Infinite Loop Occured where Child and Parent are same for the Immmediate Parent" + immediateParent);
						LOG.info("Invalid BOM Item : " + bomItem);
						LOG.info("Breaking Current Iteration\n");
						break;
					} else if (!PLMUtils.isEmpty(immediateParent)) {
						whereUsedLOUIntermediatoryList.add(immediateParentObj);
						LOG.info("Immediate Parent Added\n");
						// 	"Query-1"
						tempWhereUsedLOUBOMList = getWhereUsedLOUBOMQuery(immediateParent);
					} 
					if(tempWhereUsedLOUBOMList.size() > 1) {
						parentPartNumber = immediateParent;
						LOG.info("Level - " + ++level);
						LOG.info("List Size > 1 - Not Unique");
						LOG.info("Breaking Current Iteration\n");
					 } else if (tempWhereUsedLOUBOMList.size() == 1) {
						whereUsedLOUIntermediatoryList.add(tempWhereUsedLOUBOMList.get(0));
						LOG.info("Level - " + ++level);
						LOG.info("List Size : 1 - Found Unique");
						LOG.info("Valid BOM Item : " + bomItem);
						LOG.info("Breaking Current Iteration\n");
						break;
					} else {
						LOG.info("Level - " + ++level);
						LOG.info("List Size : 0 - Found Unique");
						LOG.info("Valid BOM Item : " + bomItem);
						LOG.info("Breaking Current Iteration\n");
						break;
					}
				}
				if(!invalidBomObj.isInvalidData()) {
					PLMWhereUsedData bomItemObjData = new PLMWhereUsedData();
					bomItemObjData.setDwgNo(bomItem);
					bomItemObjData.setBomHeader(true);
					whereUsedLOUIntermediatoryList.add(bomItemObjData);
				}
				Collections.reverse(whereUsedLOUIntermediatoryList);
				whereUsedLOUFinalList.addAll(whereUsedLOUIntermediatoryList);
				
				// Displaying Bom Results one by one
				if (!PLMUtils.isEmptyList(whereUsedLOUFinalList)) {
					for (int k = 0; k < whereUsedLOUFinalList.size(); k++) {
						LOG.info("LOU List : " + whereUsedLOUFinalList.get(k).getDwgNo());
					}
					LOG.info("\n");
				}
			}
		}
		
		// Query-3
		if (!PLMUtils.isEmptyList(whereUsedLOUFinalList)) {
			// Getting Input List	
			List<PLMWhereUsedData> partDetailList = getWhereUsedLOUDetailQuery(partNumber);
			if(!PLMUtils.isEmptyList(partDetailList) && partDetailList.size() > 1) {
				for ( int i = 1 ; i < partDetailList.size(); i++){
					partDetailList.get(i).setDwgNo(null);
				}
			}
				
			for (int k = 0; k < whereUsedLOUFinalList.size(); k++) {
				String dwgNo = whereUsedLOUFinalList.get(k).getDwgNo();
				if(!whereUsedLOUFinalList.get(k).isInvalidData() &&  !whereUsedLOUFinalList.get(k).isBomHeader()) {
					LOG.info("Getting Detail Result For No. " + (k + 1) + " : " + dwgNo);
					if(dwgNo.equals(partNumber)){
						if(!PLMUtils.isEmptyList(partDetailList)) {
							whereUsedLOUFinalDetailList.addAll(partDetailList);
						} else {
							whereUsedLOUFinalDetailList.add(whereUsedLOUFinalList.get(k));
						}
					} else {
						List<PLMWhereUsedData> dwgDetailList = getWhereUsedLOUDetailQuery(dwgNo);
						if(!PLMUtils.isEmptyList(dwgDetailList)) {
							if(dwgDetailList.size() > 1) {
								for ( int i = 1 ; i < dwgDetailList.size(); i++) {
									dwgDetailList.get(i).setDwgNo(null);
								}
							}
							whereUsedLOUFinalDetailList.addAll(dwgDetailList);
						} else {
							whereUsedLOUFinalDetailList.add(whereUsedLOUFinalList.get(k));
						}
					}
				} else {
					whereUsedLOUFinalDetailList.add(whereUsedLOUFinalList.get(k));
				}
			}
		}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return whereUsedLOUFinalDetailList;
	}
	/**
	 * Mapper for Getting Where Used BMTI LOU results.
	 */
	//private static ParameterizedRowMapper<PLMWhereUsedData> whereUsedLOUResultsMapper = new ParameterizedRowMapper<PLMWhereUsedData>() {
	private static final class WhereUsedLOUResultsMapper implements ParameterizedRowMapper<PLMWhereUsedData>{	
	public PLMWhereUsedData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMWhereUsedData plmWhereUsedData = new PLMWhereUsedData();
			plmWhereUsedData.setDwgNo(PLMUtils.checkNullVal(rs.getString(PLMConstants.WHERE_USED_LOU_PARENT_ITEM)));
			return plmWhereUsedData;
		}
	//	};
	}
	
	/**
	 * Mapper for Getting Where Used BMTI LOU Detail results.
	 */
	//private static ParameterizedRowMapper<PLMWhereUsedData> whereUsedLOUDetailResultsMapper = new ParameterizedRowMapper<PLMWhereUsedData>() {
	private static final class WhereUsedLOUDetailResultsMapper implements ParameterizedRowMapper<PLMWhereUsedData>{	
	public PLMWhereUsedData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMWhereUsedData plmWhereUsedData = new PLMWhereUsedData();
			plmWhereUsedData.setDwgNo(PLMUtils.checkNullVal(rs.getString(PLMConstants.WHERE_USED_LOU_DWG)));
			plmWhereUsedData.setDwgTitle(PLMUtils.checkNullVal(rs.getString(PLMConstants.WHERE_USED_LOU_DWG_TITLE)));
			plmWhereUsedData.setMliCode(PLMUtils.checkNullVal(rs.getString(PLMConstants.WHERE_USED_LOU_MLI)));
			plmWhereUsedData.setParentPin(PLMUtils.checkNullVal(rs.getString(PLMConstants.WHERE_USED_LOU_PARENT_PIN)));
			plmWhereUsedData.setQuantity(PLMUtils.checkNullVal(rs.getString(PLMConstants.WHERE_USED_LOU_QUANTITY)));
			return plmWhereUsedData;
		}
	//	};
	}
	
	/**
	 * This method is used for getWhereUsedEMBOMData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getWhereUsedEMBOMData(StringBuffer searchResultsQry) throws PLMCommonException {
		LOG.info("Entering getWhereUsedEMBOMData method");
		List<PLMWhereUsedData> plmWhereUsedResultList = null;
		try{
		LOG.info("Where Used EMBOM Query : " + searchResultsQry.toString());			
		plmWhereUsedResultList = getSimpleJdbcTemplate().query(searchResultsQry.toString(), new WhereUsedEMBOMSearchResultsMapper());			
		LOG.info("Where Used Result List size : " + plmWhereUsedResultList.size());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return plmWhereUsedResultList;
	}
	/**
	 * Mapper for Getting Where Used EMBOM Search Results
	 */
	//private static ParameterizedRowMapper<PLMWhereUsedData> whereUsedEMBOMSearchResultsMapper = new ParameterizedRowMapper<PLMWhereUsedData>() {
	private static final class WhereUsedEMBOMSearchResultsMapper implements ParameterizedRowMapper<PLMWhereUsedData>{
	public PLMWhereUsedData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMWhereUsedData plmWhereUsedData = new PLMWhereUsedData();
			plmWhereUsedData.setMliCode(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_MLICOSTCODE)));
			plmWhereUsedData.setPartDwg(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_PART)));
			plmWhereUsedData.setPartId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_PART_ID)));
			plmWhereUsedData.setPartDwgDescription(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_PARTDESC)));
			plmWhereUsedData.setQtyLocation(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_QTY)));
			plmWhereUsedData.setPlmObjectTypevalue(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_PLMOBJECTTYPE)));	
			plmWhereUsedData.setNextUpperLevel(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_NEXTUPPERLEVEL)));
			plmWhereUsedData.setNextUpperLevelDesc(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_NEXTUPPERLEVELDESC)));
			plmWhereUsedData.setPlmObjectStatus(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_PLMOBJECTSTATUS)));
			plmWhereUsedData.setOriginOfRecord(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_ORIGINOFRECORD)));
			/*plmWhereUsedData.setPlmRelationship(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_ODSCHILD)));*/
			plmWhereUsedData.setLoadDate(rs
					.getDate(PLMConstants.WHERE_USED_EBOM_EFFECTIVITYDATE));
			plmWhereUsedData.setUnitSerialNumber(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_SERIALNUM)));
			
			
			plmWhereUsedData.setUom(PLMUtils.checkNullVal(rs.getString(PLMConstants.UOM)));
			
			plmWhereUsedData.setUomDesc(PLMUtils.checkNullVal(rs.getString(PLMConstants.UOM_DESC)));
			
			
			
			return plmWhereUsedData;
		}
	//	};
	}
	/**
	 * This method is used for getWhereUsedEMBOMPart
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getWhereUsedEMBOMPart(StringBuffer searchResultsQry) throws PLMCommonException {
		LOG.info("searchResultsQry for getWhereUsedEMBOMPart = "+searchResultsQry);
		Map<String, List<SelectItem>> plmWhereUsedResultMap = new HashMap<String, List<SelectItem>>();
		try{
		List<SelectItem> partList = null;
		partList = getSimpleJdbcTemplate().query(searchResultsQry.toString(), new GetWhereUsedEMBOMPartResultsMapper());
		plmWhereUsedResultMap.put("partNumList", partList);
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return plmWhereUsedResultMap;
	}
	/**
	 * Mapper for Getting Where Used EMBOM Part Results
	 */
	//private static ParameterizedRowMapper<SelectItem> getWhereUsedEMBOMPartResultsMapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class GetWhereUsedEMBOMPartResultsMapper implements ParameterizedRowMapper<SelectItem>{ 	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs
					.getString(PLMConstants.WHERE_USED_EBOM_ITEMIDNUM));			
			return selectItem;
		}
	//	};
	}
	
	/**
	 * This method is used for getWhereUsedEMBOMDwg
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getWhereUsedEMBOMDwg(StringBuffer searchResultsQry) throws PLMCommonException {
		LOG.info("searchResultsQry for getWhereUsedEMBOMDwg = "+searchResultsQry);
		Map<String, List<SelectItem>> plmWhereUsedResultMap = new HashMap<String, List<SelectItem>>();
		List<SelectItem> dwgList = null;
		try{
		dwgList = getSimpleJdbcTemplate().query(searchResultsQry.toString(), new GetWhereUsedEMBOMDwgResultsMapper());
		plmWhereUsedResultMap.put("dwgNumList", dwgList);
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return plmWhereUsedResultMap;
	}
	/**
	 * Mapper for Getting Where Used EMBOM Drawing Results
	 */
	//private static ParameterizedRowMapper<SelectItem> getWhereUsedEMBOMDwgResultsMapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class GetWhereUsedEMBOMDwgResultsMapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			//PLMWhereUsedData plmWhereUsedData = new PLMWhereUsedData();
			SelectItem selectItem = new SelectItem(rs
					.getString("nm"));			
			return selectItem;
		}
	//	};
	}
	
	/**
	 * This method is used for getWhereUsedLogIndicatorData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getWhereUsedLogIndicatorData(
			StringBuffer searchResultsQry) throws PLMCommonException {
		LOG.info("Entering into the  getWhereUsedLogIndicatorData()");
		List<PLMWhereUsedData> plmWhereUsedResultList = null;
		try{
			LOG.info("Where Used Logical Indicator Query : " + searchResultsQry.toString());
			plmWhereUsedResultList = getSimpleJdbcTemplate().query(searchResultsQry.toString(), new WhereUsedLogicalIndicatorSearchResultsMapper());			
			LOG.info("Exiting from the  getWhereUsedLogIndicatorData()");
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return plmWhereUsedResultList;
	}
	/**
	 * Mapper for Getting Where Used logic indicator
	 */
	//private static ParameterizedRowMapper<PLMWhereUsedData> whereUsedLogicalIndicatorSearchResultsMapper = new ParameterizedRowMapper<PLMWhereUsedData>() {
	private static final class WhereUsedLogicalIndicatorSearchResultsMapper implements ParameterizedRowMapper<PLMWhereUsedData>{	
	public PLMWhereUsedData mapRow(ResultSet rs, int rowCount)
		throws SQLException {
			PLMWhereUsedData plmWhereUsedData = new PLMWhereUsedData();
			plmWhereUsedData.setContract(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_LOGICAL_INDICATOR_CONTRACT)));
			plmWhereUsedData.setProject(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_LOGICAL_INDICATOR_PROJECT)));
			plmWhereUsedData.setRelatedItem(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_LOGICAL_INDICATOR_RELATED_ITEM)));
			plmWhereUsedData.setRelatedItemType(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_LOGICAL_INDICATOR_RELATED_ITEMTYPE)));
			plmWhereUsedData.setDocName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_LOGICAL_INDICATOR_DOCNAME)));
			plmWhereUsedData.setType(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_LOGICAL_INDICATOR_DOCTYPE)));
			plmWhereUsedData.setRev(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_LOGICAL_INDICATOR_DOCREV)));
			plmWhereUsedData.setDocTitle(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_LOGICAL_INDICATOR_DOCTITLE)));
			plmWhereUsedData.setLogicalIndicator(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_LOGICAL_INDICATOR_LOGIC)));
			plmWhereUsedData.setTypeOfLogicalIndicator(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_LOGICAL_INDICATOR_LOGICTYPE)));
			return plmWhereUsedData;
		}
	//	};
	}
	
	@SuppressWarnings("unchecked")
	// Retrieving values in Task Data as State List
	/**
	 * This method is used for getMFTFDropDownValues
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getMFTFDropDownValues()
			throws PLMCommonException {

		Map<String, List<SelectItem>> dropdownlist = new HashMap<String, List<SelectItem>>();
		List<SelectItem> mftfstate = null;
		List<SelectItem> mftfType = null;
		try {
			mftfstate = getJdbcTemplate().query(
					PLMWhereusedQueries.GET_MFTF_TYPE_LIST, new MftfStateListMapper());
			LOG.info("Final Query State is : " + mftfstate);
			mftfType = getJdbcTemplate().query(
					PLMWhereusedQueries.GET_MFTF_TYPE_LIST, new MftfTypeListMapper());
			LOG.info("Final Query Associated Type is : " + mftfType);

			dropdownlist.put("mftfstate", mftfstate);
			dropdownlist.put("mftfType", mftfType);

		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return dropdownlist;
	}
	/**
	 * Mapper for Getting mftf state list
	 */
	//private static ParameterizedRowMapper<SelectItem> mftfStateListMapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class MftfStateListMapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			LOG.info("The taskstate row count is : " + rowCount);
			SelectItem selectItem = new SelectItem(rs.getString("to_type"));
			return selectItem;
		}
	//	};
	}
	/**
	 * Mapper for Getting mftf Type list
	 */
	//private static ParameterizedRowMapper<SelectItem> mftfTypeListMapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class MftfTypeListMapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs.getString("to_type"));

			return selectItem;
		}
	//	};
	}
	/**
	 * This method is used for getMFTFSearchData
	 * 
	 * @return searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getMFTFSearchData(StringBuffer searchResultsQry)throws PLMCommonException{
		LOG.info("Entering getMFTFSearchData method");
		List<PLMWhereUsedData> mftfSearchResultList = null;
		
		try{	
			// INSERT QUERIES FOR REC_DATA STARTS HERE
			LOG.info("MF/TF Search Report INSERT_MFTF_REC_DATA1 Query is : " + PLMWhereusedQueries.INSERT_MFTF_REC_DATA1); 
			getJdbcTemplate().execute(PLMWhereusedQueries.INSERT_MFTF_REC_DATA1);
			
			LOG.info("MF/TF Search Report INSERT_MFTF_REC_DATA2 Query is : " + PLMWhereusedQueries.INSERT_MFTF_REC_DATA2);
			getJdbcTemplate().execute(PLMWhereusedQueries.INSERT_MFTF_REC_DATA2);
			
			LOG.info("MF/TF Search Report INSERT_MFTF_REC_DATA3 Query is : " + PLMWhereusedQueries.INSERT_MFTF_REC_DATA3);
			getJdbcTemplate().execute(PLMWhereusedQueries.INSERT_MFTF_REC_DATA3);
			
			//Newly Query for Adding CDR_ODS_R_MANDATORY_CFGN_F table
			LOG.info("MF/TF Search Report INSERT_MFTF_REC_DATA4 Query is : " + PLMWhereusedQueries.INSERT_MFTF_REC_DATA4);
			getJdbcTemplate().execute(PLMWhereusedQueries.INSERT_MFTF_REC_DATA4);
			
			//Newly Query for Adding CDR_ODS_R_VARIES_BY  table
			LOG.info("MF/TF Search Report INSERT_MFTF_REC_DATA5 Query is : " + PLMWhereusedQueries.INSERT_MFTF_REC_DATA5);
			getJdbcTemplate().execute(PLMWhereusedQueries.INSERT_MFTF_REC_DATA5);
		
			LOG.info("Query for Collect STATS MFTF_REC_DATA_COL_STATS1 : " + PLMWhereusedQueries.MFTF_REC_DATA_COL_STATS1);
			getJdbcTemplate().execute(PLMWhereusedQueries.MFTF_REC_DATA_COL_STATS1);
			
			LOG.info("Query for Collect STATS MFTF_REC_DATA_COL_STATS2 : " + PLMWhereusedQueries.MFTF_REC_DATA_COL_STATS2);
			getJdbcTemplate().execute(PLMWhereusedQueries.MFTF_REC_DATA_COL_STATS2);
			// INSERT QUERIES FOR REC_DATA ENDS HERE
			
			// INSERT QUERIES FOR FTR_LIST STARTS HERE
			LOG.info("MF/TF Search Report INSERT_MFTF_FTR_LIST is : " + PLMWhereusedQueries.INSERT_MFTF_FTR_LIST);
			getJdbcTemplate().execute(PLMWhereusedQueries.INSERT_MFTF_FTR_LIST);
			
			LOG.info("Query for Collect STATS MFTF_FTR_LIST_COL_STATS1 : " + PLMWhereusedQueries.MFTF_FTR_LIST_COL_STATS1);
			getJdbcTemplate().execute(PLMWhereusedQueries.MFTF_FTR_LIST_COL_STATS1);
			
			LOG.info("Query for Collect STATS MFTF_FTR_LIST_COL_STATS2 : " + PLMWhereusedQueries.MFTF_FTR_LIST_COL_STATS2);
			getJdbcTemplate().execute(PLMWhereusedQueries.MFTF_FTR_LIST_COL_STATS2);
			// INSERT QUERIES FOR FTR_LIST ENDS HERE
			
			// INSERT QUERIES FOR FTR_DATA STARTS HERE
			LOG.info("MF/TF Search Report INSERT_MFTF_FTR_DATA1 is : " + PLMWhereusedQueries.INSERT_MFTF_FTR_DATA1);
			getJdbcTemplate().execute(PLMWhereusedQueries.INSERT_MFTF_FTR_DATA1);
			
			LOG.info("MF/TF Search Report INSERT_MFTF_FTR_DATA2 is : " + PLMWhereusedQueries.INSERT_MFTF_FTR_DATA2);
			getJdbcTemplate().execute(PLMWhereusedQueries.INSERT_MFTF_FTR_DATA2);
			
			LOG.info("MF/TF Search Report INSERT_MFTF_FTR_DATA3 is : " + PLMWhereusedQueries.INSERT_MFTF_FTR_DATA3);
			getJdbcTemplate().execute(PLMWhereusedQueries.INSERT_MFTF_FTR_DATA3);
			
			LOG.info("MF/TF Search Report INSERT_MFTF_FTR_DATA4 is : " + PLMWhereusedQueries.INSERT_MFTF_FTR_DATA4);
			getJdbcTemplate().execute(PLMWhereusedQueries.INSERT_MFTF_FTR_DATA4);
			
			LOG.info("MF/TF Search Report INSERT_MFTF_FTR_DATA5 is : " + PLMWhereusedQueries.INSERT_MFTF_FTR_DATA5);
			getJdbcTemplate().execute(PLMWhereusedQueries.INSERT_MFTF_FTR_DATA5);
			
			LOG.info("MF/TF Search Report INSERT_MFTF_FTR_DATA6 is : " + PLMWhereusedQueries.INSERT_MFTF_FTR_DATA6);
			getJdbcTemplate().execute(PLMWhereusedQueries.INSERT_MFTF_FTR_DATA6);
			
			LOG.info("MF/TF Search Report INSERT_MFTF_FTR_DATA7 is : " + PLMWhereusedQueries.INSERT_MFTF_FTR_DATA7);
			getJdbcTemplate().execute(PLMWhereusedQueries.INSERT_MFTF_FTR_DATA7);
			
			LOG.info("Query for Collect STATS MFTF_FTR_DATA_COL_STATS1 : " + PLMWhereusedQueries.MFTF_FTR_DATA_COL_STATS1);
			getJdbcTemplate().execute(PLMWhereusedQueries.MFTF_FTR_DATA_COL_STATS1);
			
			LOG.info("Query for Collect STATS MFTF_FTR_DATA_COL_STATS2 : " + PLMWhereusedQueries.MFTF_FTR_DATA_COL_STATS2);
			getJdbcTemplate().execute(PLMWhereusedQueries.MFTF_FTR_DATA_COL_STATS2);
			// INSERT QUERIES FOR FTR_DATA ENDS HERE
			
			// FINAL QUERY STARTS HERE
			LOG.info("MF/TF Search Report Query3 is : " + searchResultsQry.toString());
			mftfSearchResultList = getSimpleJdbcTemplate().query(searchResultsQry.toString(),new MftfReportMapper());
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}finally {
			LOG.info("Inside finally block");
		}
		LOG.info("Exiting getMFTFSearchData method");
		return mftfSearchResultList;
	}
	
	/**
	 * Mapper for Getting mftf Report
	 */
	//private static ParameterizedRowMapper<PLMWhereUsedData> mftfReportMapper = new ParameterizedRowMapper<PLMWhereUsedData>() {
	private static final class MftfReportMapper implements ParameterizedRowMapper<PLMWhereUsedData>{	
	public PLMWhereUsedData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMWhereUsedData mfTfData = new PLMWhereUsedData();
			mfTfData.setContractName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CONTRACT_NAME)));
			mfTfData.setCusName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CUST_NM)));
			mfTfData.setModel(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.HW_PRODUCT_NAME)));
			mfTfData.setName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.MFTF_NAME)));
			mfTfData.setMktFeatureNm(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.MARKETING_NAME)));
			mfTfData.setType(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.FEATURE_TYPE)));
			mfTfData.setRev(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.REV)));
			mfTfData.setDescription(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.MFTF_DESCRIPTION)));
			mfTfData.setState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.MFTF_STATE)));
			/*mfTfData.setFeatureUsg(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.FEATURE_USAGE)));*/
			mfTfData.setQty(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.MFTF_QTY)));
			mfTfData.setRuleType(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.RULE_TYPE)));
			//mfTfData.setRuleExp(PLMUtils.checkNullVal(rs
				//	.getString(PLMConstants.RULE_EXPRESSION)));
			mfTfData.setRuleExp("");
			mfTfData.setPartFamily(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PART_FAMILY)));
			
			mfTfData.setContractId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CONTRACT_ID)));
			mfTfData.setHwPrdId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.HW_PRDT_ID)));
			mfTfData.setFtrId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.FTR_ID)));
					
			return mfTfData;
			
		}
	//	};
	}
	//added for BMLL report
	/**
	 * This methods is used for getBMLLWhereUsedEMBOMData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getBMLLWhereUsedEMBOMData(StringBuffer searchResultsQry) throws PLMCommonException {
		LOG.info("Entering getBMLLWhereUsedEMBOMData method");
		List<PLMWhereUsedData> plmWhereUsedResultList = null;
		String VT_PART = null;
		String timeStamp = null;
		try{
			timeStamp = PLMUtils.volTableFormatDate();
			VT_PART = PLMConstants.VT_PART.concat(timeStamp);
			
			LOG.info("Query for Createing VT_PART volatile : " + PLMWhereusedQueries.CREATE_VT_PART_VOATILE.replace(PLMConstants.VT_PART, VT_PART));
			getJdbcTemplate().execute(PLMWhereusedQueries.CREATE_VT_PART_VOATILE.replace(PLMConstants.VT_PART, VT_PART));
			
			LOG.info("BMLL Where Used EMBOM Query : " + searchResultsQry.toString().replace(PLMConstants.VT_PART, VT_PART));			
			plmWhereUsedResultList = getSimpleJdbcTemplate().query(searchResultsQry.toString().replace(PLMConstants.VT_PART, VT_PART), new WhereUsedBMLLEMBOMSearchResultsMapper());			
		/*	List<PLMWhereUsedData> whrUsedMLNonAplhaList = new ArrayList<PLMWhereUsedData>();
			LOG.info("BMLL Where Used Result List size before removing Non Alpha : " + plmWhereUsedResultList.size());
			if (plmWhereUsedResultList!=null && plmWhereUsedResultList.size() > 0) {
				
				for (int i=0; i< plmWhereUsedResultList.size(); i++)
		        {
					if(plmWhereUsedResultList.get(i).getUnitAssembleNumber().contains("ML-") 
							&& !PLMUtils.isAlphaNumericPin(plmWhereUsedResultList.get(i).getPin()))
					{	
						whrUsedMLNonAplhaList.add(plmWhereUsedResultList.get(i));
					}
		        }
				plmWhereUsedResultList.removeAll(whrUsedMLNonAplhaList);
				whrUsedMLNonAplhaList.clear();
			}
			LOG.info("BMLL Where Used Result List size after removing Non Alpha : " + plmWhereUsedResultList.size());*/
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return plmWhereUsedResultList;
	}
	/**
	 * Mapper for Getting where used BMLL Search Results
	 */
	//private static ParameterizedRowMapper<PLMWhereUsedData> whereUsedBMLLEMBOMSearchResultsMapper = new ParameterizedRowMapper<PLMWhereUsedData>() {
	private static final class WhereUsedBMLLEMBOMSearchResultsMapper implements ParameterizedRowMapper<PLMWhereUsedData>{	
	public PLMWhereUsedData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMWhereUsedData plmWhereUsedData = new PLMWhereUsedData();
			plmWhereUsedData.setUnitAssembleNumber(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_ASSEMBLENUM)));
			plmWhereUsedData.setMliCode(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_MLICOSTCODE)));
			plmWhereUsedData.setPin(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_PIN)));
			plmWhereUsedData.setParentItemId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_PARENT_ID)));
			plmWhereUsedData.setParentItem(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_PARENT)));
			plmWhereUsedData.setChildItemId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_CHILD_ID)));
			plmWhereUsedData.setChildItem(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_CHILD)));
			plmWhereUsedData.setDescription(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_DESCRIPTION)));
			plmWhereUsedData.setAuthecn(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_AUTHECN)));	
			plmWhereUsedData.setItemEffectivityStartDate(rs
					.getDate(PLMConstants.WHERE_USED_EBOM_EFFECTIVITYSTARTDATE));
			plmWhereUsedData.setItemEffectivityEndDate(rs
					.getDate(PLMConstants.WHERE_USED_EBOM_EFFECTIVITYENDDATE));
			plmWhereUsedData.setSource(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_SOURCE)));
			//Added by Hemanth K E+MBOM Enhancement
			plmWhereUsedData.setQuantity(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_QUANTITY)));
			plmWhereUsedData.setUom(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_UOM)));
			/*plmWhereUsedData.setLevel(rs
					.getInt(PLMConstants.WHERE_USED_EBOM_LEVEL));*/
			return plmWhereUsedData;
		}
	//	};
	}

	/**
	 * This methods is used for getWhereUsedEMBOMPartDwg
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMWhereUsedData> getWhereUsedEMBOMPartDwg(StringBuffer searchResultsQry)throws PLMCommonException{
		LOG.info("searchResultsQry for getWhereUsedEMBOMPartDwg = "+searchResultsQry);
		List<PLMWhereUsedData> partDwgSearchResultList = null;
		try{
			LOG.info("searchResultsQry Query : " + searchResultsQry.toString());
			partDwgSearchResultList = getSimpleJdbcTemplate().query(searchResultsQry.toString(), new EMBOMPartDwgResultsMapper());
			LOG.info("searchResultsQry Result List size : " + partDwgSearchResultList.size());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return partDwgSearchResultList;
	}
	
	/**
	 * Mapper for Getting EBOM Part Drawing
	 */
	//private static ParameterizedRowMapper<PLMWhereUsedData> EMBOMPartDwgResultsMapper = new ParameterizedRowMapper<PLMWhereUsedData>() {
	private static final class EMBOMPartDwgResultsMapper implements ParameterizedRowMapper<PLMWhereUsedData>{	
	public PLMWhereUsedData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMWhereUsedData partDwgData = new PLMWhereUsedData();
			partDwgData.setPartDwgVal(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_ITEMIDNUM)));
			partDwgData.setDescriptionVal(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.WHERE_USED_EBOM_ITEMDESC)));
			return partDwgData;
		}
	//	};
	}
	
	
	//Newly added of Where Used Requirement
	/**
	 * This methods is used for getWhereUsedReqData 
	 * 
	 * @param reportData
	 * @return ICMSearchData
	 * @throws ICMCommonException
	 */
	public List<PLMWhereUsedReqData> getWhereUsedReqData(PLMWhereUsedReqData reportData)throws PLMCommonException{
		
		LOG.info("Entering getWhereUsedReqData() method.");
		
		List<PLMWhereUsedReqData> searchResultList = null;
		
		final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy");
		
		String timeStamp = PLMUtils.volTableFormatDate();
		String VT_PRJ_SALES = PLMConstants.VT_PRJ_SALES.concat(timeStamp);
		String VT_SALES_DATA = PLMConstants.VT_SALES_DATA.concat(timeStamp);
		
		String createVTQry = PLMWhereusedQueries.WHERE_USED_CREATE_VT_PRJ_SALES.replace(PLMConstants.VT_PRJ_SALES, VT_PRJ_SALES);
		LOG.info("Creating VT_PRJ_SALES VT Query : " + createVTQry + "\n");
		getJdbcTemplate().execute(createVTQry);
		
		String createVTQry1 = PLMWhereusedQueries.WHERE_USED_CREATE_VT_SALES_DATA.replace(PLMConstants.VT_PRJ_SALES, VT_PRJ_SALES)
				.replace(PLMConstants.VT_SALES_DATA, VT_SALES_DATA);
		LOG.info("Creating VT_SALES_DATA VT Query : " + createVTQry1 + "\n");
		getJdbcTemplate().execute(createVTQry1);
		
		try{
		StringBuffer searchResultsQry = new StringBuffer();
		searchResultsQry.append(PLMWhereusedQueries.WHERE_USED_REQUIRMENT_DETAILS1.replace(PLMConstants.VT_SALES_DATA, VT_SALES_DATA));
		
		if (reportData.getRequirementName() != null && reportData.getRequirementName().length() > 0) {
			LOG.info("Wild card of Requirement Name : " + reportData.getRequirementName());
			searchResultsQry.append(" AND ");
			searchResultsQry.append(PLMUtils.generatePrjQuryForMultipleNames("REQUIREMENT_NAME" ,reportData.getRequirementName()));
			}
		
		if (reportData.getUserSerialNumber() != null && reportData.getUserSerialNumber().length() > 0) {
			LOG.info("Wild card of Unit Serial Number : " + reportData.getUserSerialNumber());
   	 	    searchResultsQry.append(" AND ");
			searchResultsQry.append(PLMUtils.generatePrjQuryForMultipleNames("UNIT_SERIAL_NUM" ,reportData.getUserSerialNumber()));
		}
		
		if (reportData.getFrameTypeList().size() > 0) {
			LOG.info("List of Frames : " + PLMUtils.setListForQuery(reportData.getFrameTypeList()));
			
			searchResultsQry.append(" AND ");
			searchResultsQry.append("FRAME_TYPE IN (" +PLMUtils.setListForQuery(reportData.getFrameTypeList())+ ")");
		}
		
		if (reportData.getContractStartDate() != null && reportData.getContractEndDate() != null) {
			LOG.info("Contract Start  From Date: " + SIMPLE_DATE_FORMAT.format(reportData.getContractStartDate()) +" To Date"+SIMPLE_DATE_FORMAT.format(reportData.getContractEndDate()));
			
			searchResultsQry.append(" AND ");
			searchResultsQry.append("(CONTRACT_START_DATE IS NOT NULL AND CONTRACT_START_DATE BETWEEN CAST('");
			searchResultsQry.append(SIMPLE_DATE_FORMAT.format(reportData.getContractStartDate())+ "' AS DATE FORMAT 'MM/DD/YYYY') AND ");
			searchResultsQry.append(" CAST('");
			searchResultsQry.append(SIMPLE_DATE_FORMAT.format(reportData.getContractEndDate())+ "' AS DATE FORMAT 'MM/DD/YYYY'))");
		}
		
		if (reportData.getFmissueStrDate() != null && reportData.getFmissueEndDate()!=null) {
			LOG.info("FMI Issue  From Datae: " + SIMPLE_DATE_FORMAT.format(reportData.getFmissueStrDate()) +" To Date"+SIMPLE_DATE_FORMAT.format(reportData.getFmissueEndDate()));
			searchResultsQry.append(" AND ");
			searchResultsQry.append("(FMI_ISSUED_DATE IS NOT NULL AND FMI_ISSUED_DATE BETWEEN CAST('");
			searchResultsQry.append(SIMPLE_DATE_FORMAT.format(reportData.getFmissueStrDate())+ "' AS DATE FORMAT 'MM/DD/YYYY') AND ");
			searchResultsQry.append(" CAST('");
			searchResultsQry.append(SIMPLE_DATE_FORMAT.format(reportData.getFmissueEndDate())+ "' AS DATE FORMAT 'MM/DD/YYYY'))");
		}
		
		searchResultsQry.append(PLMWhereusedQueries.WHERE_USED_REQUIRMENT_DETAILS2);
		
		LOG.info("getWhereUsedReportData Search Query is : " + searchResultsQry);
		searchResultList = getSimpleJdbcTemplate().query(searchResultsQry.toString(),new WhereUsedDataMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return searchResultList;

	}
	/**
	 * Mapper for Getting Where used Data
	 */
	//private static ParameterizedRowMapper<PLMWhereUsedReqData> whereUsedDataMapper = new ParameterizedRowMapper<PLMWhereUsedReqData>() {
	private static final class WhereUsedDataMapper implements 	ParameterizedRowMapper<PLMWhereUsedReqData>{
	public PLMWhereUsedReqData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
		
			final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
			"MM/dd/yyyy");
			PLMWhereUsedReqData reportData = new PLMWhereUsedReqData();
			reportData.setProgram(PLMUtils.checkNullVal(rs
					.getString("PROGRAM_NAME")));
			reportData.setContract(PLMUtils.checkNullVal(rs
					.getString("CONTRACT")));
			reportData.setContractDesc(PLMUtils.checkNullVal(rs
					.getString("CONTRACT_DESC")));
			
			Date contratStrDt = rs.getDate("CONTRACT_START_DATE");
			if (contratStrDt != null) {
				String strContractDt = SIMPLE_DATE_FORMAT.format(contratStrDt);
				reportData.setContractStrDt(strContractDt);
			} 	
			
			reportData.setClin(PLMUtils.checkNullVal(rs
					.getString("CLIN")));
			reportData.setCiDesc(PLMUtils.checkNullVal(rs
					.getString("CI_DESCRIPTION")));
			reportData.setFrameType(PLMUtils.checkNullVal(rs
					.getString("FRAME_TYPE")));
			
			
			Date fmiIssueDt = rs.getDate("FMI_ISSUED_DATE");
			if (fmiIssueDt != null) {
				String strIssueDt = SIMPLE_DATE_FORMAT.format(fmiIssueDt);
				reportData.setFmiIssuDt(strIssueDt);
			} 	
			
			reportData.setBuild(PLMUtils.checkNullVal(rs
					.getString("BUILD")));
			reportData.setUnitSerialNum(PLMUtils.checkNullVal(rs
					.getString("UNIT_SERIAL_NUM")));
			reportData.setProjectName(PLMUtils.checkNullVal(rs
					.getString("PROJECT_NAME")));
			reportData.setProjectState(PLMUtils.checkNullVal(rs
					.getString("PROJECT_STATE")));
			reportData.setProjectDesc(PLMUtils.checkNullVal(rs
					.getString("PROJECT_DESCRIPTION")));
			reportData.setPrsName(PLMUtils.checkNullVal(rs
					.getString("PRS_NAME")));
			reportData.setPrsRev(PLMUtils.checkNullVal(rs
					.getString("PRS_REV")));
			reportData.setRequireName(PLMUtils.checkNullVal(rs
					.getString("REQUIREMENT_NAME")));
			reportData.setRequireRev(PLMUtils.checkNullVal(rs
					.getString("REQUIREMENT_REV")));
			reportData.setReqDesc(PLMUtils.checkNullVal(rs
					.getString("REQ_DESC")));
			reportData.setSalesOrder(PLMUtils.checkNullVal(rs
					.getString("SALES_ORDER")));
			return reportData;
		}
	//	};
	}
	
	/**
	 * This methods is used for getFramTypeList
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getFramTypeList()	throws PLMCommonException {
		LOG.info("Entering getFramTypeList() method.");
				Map<String, List<SelectItem>> frameList = new HashMap<String, List<SelectItem>>();
				List<SelectItem> frame = null;
		try {
			frame = getJdbcTemplate().query(PLMWhereusedQueries.WHERE_USED_FRAME_TYPE,new FrameTypeMapper());
			LOG.info("Final Query frame is : " + PLMWhereusedQueries.WHERE_USED_FRAME_TYPE);
			frameList.put("frame", frame);
			
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return frameList;
		}
	
	/**
	 * Mapper for Getting Frame type Data
	 */
	//private static ParameterizedRowMapper<SelectItem> frameTypeMapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class FrameTypeMapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs.getString("FRAME_TYPE"));
			return selectItem;
		}
	//	};
	}
	
	
	//Added By Raju
	/**
	 * This methods is used for fetchWhrUsdTpLvlImplsnData
	 * 
	 * @param partNm
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String,List<PLMWhereUsedData>> fetchWhrUsdTpLvlImplsnData(String partNm) throws PLMCommonException{
		
		Map<String,List<PLMWhereUsedData>> tempMap = new HashMap<String, List<PLMWhereUsedData>>();
		
		String timeStamp = PLMUtils.volTableFormatDate();
		String VT0_TEMP_DT = PLMConstants.VT0.concat(timeStamp);
		String str = PLMWhereusedQueries.WHERE_USED_COPICS_VT0.replace("?", partNm).replace(PLMConstants.VT0, VT0_TEMP_DT);
		LOG.info("Executing WHERE_USED_COPICS_VT0 Query : " + str + "\n");
		LOG.info("partNm in DAO------------->"+partNm);
		getJdbcTemplate().execute(str);
		
		String str2 = PLMWhereusedQueries.GET_WHERE_USED_COPICS_DATA.replace(PLMConstants.VT0, VT0_TEMP_DT);
		LOG.info("Executing GET_WHERE_USED_COPICS_DATA Query : " + str2 + "\n");
		List<PLMWhereUsedData> copicsList = getSimpleJdbcTemplate().query(str2, new CopicsDataMapper());
		tempMap.put("CopicsData", copicsList);
		
		LOG.info("Executing GET_WHERE_USED_SBOM_DEVI_DATA Query : " + PLMWhereusedQueries.GET_WHERE_USED_SBOM_DEVI_DATA + "\n");
		List<PLMWhereUsedData> sbomList = getSimpleJdbcTemplate().query(PLMWhereusedQueries.GET_WHERE_USED_SBOM_DEVI_DATA, new SBomDataMapper(), new Object[]{partNm});
		tempMap.put("SbomData", sbomList);
		
		String VT0_TEMP_DT1 = PLMConstants.VT_TEMP.concat(timeStamp);
		String str4 = PLMWhereusedQueries.WHERE_USED_COPICS_VT1.replace("?", partNm).replace(PLMConstants.VT_TEMP, VT0_TEMP_DT1);
		LOG.info("Executing WHERE_USED_COPICS_VT1 Query : " + str4 + "\n");
		getJdbcTemplate().execute(str4);
		
		String str5 = PLMWhereusedQueries.GET_WHERE_USED_EBOM__DATA.replace(PLMConstants.VT_TEMP, VT0_TEMP_DT1);
		LOG.info("Executing GET_WHERE_USED_EBOM__DATA Query : " + str5 + "\n");
		List<PLMWhereUsedData> ebomList = getSimpleJdbcTemplate().query(str5, new EBomDataMapper());
		tempMap.put("ebomData", ebomList);
		
		
		
		LOG.info("Executing GET_WHERE_USED_RPDM_DATA Query : " + PLMWhereusedQueries.GET_WHERE_USED_RPDM_DATA + "\n");
		List<PLMWhereUsedData> rpdmList = getSimpleJdbcTemplate().query(PLMWhereusedQueries.GET_WHERE_USED_RPDM_DATA, new RpdmDataMapper(), new Object[]{partNm,partNm});
		tempMap.put("rpdmData", rpdmList);
	
		
		return tempMap;
	}
	/**
	 * Mapper for Getting COPICS Data
	 */
	//private static ParameterizedRowMapper<PLMWhereUsedData> copicsDataMapper  = new ParameterizedRowMapper<PLMWhereUsedData>() {
	private static final class CopicsDataMapper implements ParameterizedRowMapper<PLMWhereUsedData>{	
	public PLMWhereUsedData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMWhereUsedData data = new PLMWhereUsedData();
			data.setParentItem1(rs.getString("PARENT_ITEM"));
			data.setImdtParentItem(rs.getString("IMDT_PARENT_ITEM"));
			data.setSrlNum(rs.getString("SRLNUM"));
			data.setStatus1(rs.getString("STATUS"));
			return data;
		}
	//	};
	}
	/**
	 * Mapper for Getting SBOM Data
	 */
	//private static ParameterizedRowMapper<PLMWhereUsedData> sBomDataMapper  = new ParameterizedRowMapper<PLMWhereUsedData>() {
	private static final class SBomDataMapper implements ParameterizedRowMapper<PLMWhereUsedData>{	
	public PLMWhereUsedData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMWhereUsedData data = new PLMWhereUsedData();
			data.setTurbnNUm(rs.getString("TURBNUM"));
			data.setSrlNum1(rs.getString("SRLNUM"));
			data.setMli(rs.getString("MLI"));
			data.setNewItem(rs.getString("NEWITEM"));
			data.setOldItem(rs.getString("OLDITEM"));
			data.setDescript(rs.getString("DESCRIPT"));
			data.setDtent(rs.getString("DTENT"));
			data.setAuthen(rs.getString("AUTHECN"));
			data.setQty1(rs.getString("QTY"));
			data.setOrign(rs.getString("ORIGIN"));
			return data;
		}
	//	};
	}
	
	/**
	 * Mapper for Getting RPDM Data
	 */
	private static final class RpdmDataMapper implements ParameterizedRowMapper<PLMWhereUsedData>{	
	public PLMWhereUsedData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMWhereUsedData data = new PLMWhereUsedData();
			data.setSystemId(PLMUtils.checkNullVal(rs.getString("SYSTEM_ID")));
			data.setSystemName(PLMUtils.checkNullVal(rs.getString("SYSTEM_NM")));
			data.setClassName(PLMUtils.checkNullVal(rs.getString("CLASS_NM")));
			data.setRelType(PLMUtils.checkNullVal(rs.getString("REL_TYPE")));
			data.setParentName(PLMUtils.checkNullVal(rs.getString("PARENT_NM")));
			data.setParentTextName(PLMUtils.checkNullVal(rs.getString("PARENT_TEXTM")));
			data.setChildName(PLMUtils.checkNullVal(rs.getString("CHILD_NAME")));
			data.setChildRev(PLMUtils.checkNullVal(rs.getString("CHILD_REV")));
			data.setTextName(PLMUtils.checkNullVal(rs.getString("TEXTM")));
			data.setLanguageCode(PLMUtils.checkNullVal(rs.getString("LANGUAGE_CODE")));
			data.setT4refPartNumber(PLMUtils.checkNullVal(rs.getString("T4REFPARTNUMBER")));
			data.setT4refPartRev(PLMUtils.checkNullVal(rs.getString("T4REFPARTREVISION")));
			data.setBomLevel(PLMUtils.checkNullVal(rs.getString("BOM_LVL")));
			return data;
		
		}
	//	};
	}
	
	
	
	
	
	/**
	 * Mapper for Getting EBOM Data
	 */
	//private static ParameterizedRowMapper<PLMWhereUsedData> eBomDataMapper  = new ParameterizedRowMapper<PLMWhereUsedData>() {
	private static final class EBomDataMapper implements ParameterizedRowMapper<PLMWhereUsedData>{	
	public PLMWhereUsedData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMWhereUsedData data = new PLMWhereUsedData();
			data.setTopLvlParentId(rs.getString("TOP_LEVEL_PARENT_ID"));
			data.setTopLvlParentNm(rs.getString("TOP_LEVEL_PARENT_NAME"));
			data.setTopLvlParentRev(rs.getString("TOP_LEVEL_PARENT_REVISION"));
			data.setImmediateParentId(rs.getString("IMDT_PARNT_ID"));
			data.setImmediateParent(rs.getString("IMMEDIATE_PARENT"));
			data.setImmediateParentRev(rs.getString("IMMEDIATE_PARENT_REV"));
			data.setPartId(rs.getString("PART_ID"));
			data.setPartNm(rs.getString("PART_NM"));
			data.setPartDesc(rs.getString("PART_DESCRIPTION"));
			data.setLvl(rs.getString("LEVEL"));
			data.setDfsOrdr(rs.getString("DFSORDER"));
			return data;
		}
	//	};
	}
	
  //End Raju
		
	/**
	 * This method is used to fetch where used top lvl implsn data
	 * 
	 * @param partNm
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<PLMImpactAnalysisData>> getImpactAnalysisForParts(
			List<String> partIdLst) throws PLMCommonException{
		
		Map<String, List<PLMImpactAnalysisData>> impactAnlysMap = new HashMap<String, List<PLMImpactAnalysisData>>();
			
			String timeStamp = PLMUtils.volTableFormatDate();
			String IMPAL_EVT1 = PLMConstants.IMPAL_EVT1.concat(timeStamp);
			String IMPAL_MVT_MBOM = PLMConstants.IMPAL_MVT_MBOM.concat(timeStamp);
			String IMPAL_MVT_MBOMP = PLMConstants.IMPAL_MVT_MBOMP.concat(timeStamp);
			String IMPAL_MVT1 = PLMConstants.IMPAL_MVT1.concat(timeStamp);
			String IMPAL_MVT2 = PLMConstants.IMPAL_MVT2.concat(timeStamp);
			String IMPAL_MVT3 = PLMConstants.IMPAL_MVT3.concat(timeStamp);
			String IMPAL_MVT4 = PLMConstants.IMPAL_MVT4.concat(timeStamp);
			String strpartId =PLMUtils.setListForQuery(partIdLst);
			LOG.info("part Id in DAO------------->"+strpartId);
			
			String createEVT1Qry = PLMQueryConstants.IMPANL_EVT1.replace("?", strpartId).replace(PLMConstants.IMPAL_EVT1, IMPAL_EVT1);
			LOG.info("Createing IMPAL_EVT1 VT Query : " + createEVT1Qry + "\n");
			getJdbcTemplate().execute(createEVT1Qry);
			
			String getEVT1Qry = PLMQueryConstants.GET_EIMPANL_SEL.replace(PLMConstants.IMPAL_EVT1, IMPAL_EVT1);
			LOG.info("Executing GET IMPAL_EVT1 Query : " + getEVT1Qry + "\n");
			List<PLMImpactAnalysisData> eBomimpctAnlysisList = getSimpleJdbcTemplate().query(getEVT1Qry, new EBOMImpactDataMapper());
			LOG.info("List of EBoM Results >>> "+eBomimpctAnlysisList.size());
		
			String createMVT_MBOMQry = PLMQueryConstants.CREATE_IMPANL_MVT_MBOM.replace("?", strpartId).replace(PLMConstants.IMPAL_MVT_MBOM, IMPAL_MVT_MBOM);
			LOG.info("Createing IMPAL_MVT_MBOM VT Query : " + createMVT_MBOMQry + "\n");
			getJdbcTemplate().execute(createMVT_MBOMQry);
			
			String createMVT_MBOMPQry = PLMQueryConstants.CREATE_IMPANL_MVT_MBOMP.replace("?", strpartId).replace(PLMConstants.IMPAL_MVT_MBOMP, IMPAL_MVT_MBOMP);
			LOG.info("Creating IMPAL_MVT_MBOMP VT Query : " + createMVT_MBOMPQry + "\n");
			getJdbcTemplate().execute(createMVT_MBOMPQry);
			
			StringBuffer createMVT1Qry = new StringBuffer();
			createMVT1Qry.append(PLMQueryConstants.CREATE_IMPANL_MVT1_ONE.replace(PLMConstants.IMPAL_MVT1, IMPAL_MVT1).replace(PLMConstants.IMPAL_MVT_MBOM, IMPAL_MVT_MBOM));
			createMVT1Qry.append(PLMQueryConstants.CREATE_IMPANL_MVT1_TWO.replace(PLMConstants.IMPAL_MVT_MBOMP, IMPAL_MVT_MBOMP));
			LOG.info("Createing IMPAL_MVT1 VT Query : " + createMVT1Qry + "\n");
			getJdbcTemplate().execute(createMVT1Qry.toString());
			
			String createMVT2Qry = PLMQueryConstants.CREATE_IMPANL_MVT2.replace(PLMConstants.IMPAL_MVT2, IMPAL_MVT2).replace(PLMConstants.IMPAL_MVT1, IMPAL_MVT1);
			LOG.info("Creating IMPAL_MVT2 VT Query : " + createMVT2Qry + "\n");
			getJdbcTemplate().execute(createMVT2Qry);
			
			String createMVT3Qry = PLMQueryConstants.CREATE_IMPANL_MVT3.replace(PLMConstants.IMPAL_MVT3, IMPAL_MVT3).replace(PLMConstants.IMPAL_MVT2, IMPAL_MVT2);
			LOG.info("Createing IMPAL_MVT3 VT Query : " + createMVT3Qry + "\n");
			getJdbcTemplate().execute(createMVT3Qry);
			
			String createMVT4Qry = PLMQueryConstants.CREATE_IMPANL_MVT4.replace(PLMConstants.IMPAL_MVT4, IMPAL_MVT4).replace(PLMConstants.IMPAL_MVT2, IMPAL_MVT2);
			LOG.info("Createing IMPAL_MVT4 VT Query : " + createMVT4Qry + "\n");
			getJdbcTemplate().execute(createMVT4Qry);
			
			String getMVT1Qry = PLMQueryConstants.GET_MIMPANL_FINAL_SEL.replace(PLMConstants.IMPAL_MVT2, IMPAL_MVT2)
					.replace(PLMConstants.IMPAL_MVT3, IMPAL_MVT3).replace(PLMConstants.IMPAL_MVT4, IMPAL_MVT4);
			LOG.info("Executing GET_MIMPANL_FINAL_SEL Query : " + getMVT1Qry + "\n");
			List<PLMImpactAnalysisData> mBomimpctAnlysisList = getSimpleJdbcTemplate().query(getMVT1Qry, new MBOMImpactDataMapper());
			LOG.info("List of MBoM Results >>> "+mBomimpctAnlysisList.size());
			
				for(int i=0;i<partIdLst.size();i++){
					List<PLMImpactAnalysisData> finalEBomimpctAnlysisList = new ArrayList<PLMImpactAnalysisData>();
					List<PLMImpactAnalysisData> finalMBomimpctAnlysisList = new ArrayList<PLMImpactAnalysisData>();
					
				  for(int e=0;e<eBomimpctAnlysisList.size();e++){
					if(eBomimpctAnlysisList.get(e).getPartId().equals(partIdLst.get(i))){ 
					PLMImpactAnalysisData eBomdata = new PLMImpactAnalysisData();
					eBomdata.setImmediateParentId(eBomimpctAnlysisList.get(e).getImmediateParent());
					eBomdata.setImmediateParent(eBomimpctAnlysisList.get(e).getImmediateParent());
					eBomdata.setImmediateParentRev(eBomimpctAnlysisList.get(e).getImmediateParentRev());
					eBomdata.setTopLvlParentNm(eBomimpctAnlysisList.get(e).getTopLvlParentNm());
					eBomdata.setLgclFtrNm(eBomimpctAnlysisList.get(e).getLgclFtrNm());
					eBomdata.setLgclFtrType(eBomimpctAnlysisList.get(e).getLgclFtrType());
					eBomdata.setPrdtCnfgNm(eBomimpctAnlysisList.get(e).getPrdtCnfgNm());
					eBomdata.setHwBldNm(eBomimpctAnlysisList.get(e).getHwBldNm());
					eBomdata.setHwBldState(eBomimpctAnlysisList.get(e).getHwBldState());
					eBomdata.setPlantNm(eBomimpctAnlysisList.get(e).getPlantNm());
					eBomdata.setPartId(eBomimpctAnlysisList.get(e).getPartId());
					eBomdata.setPartNm(eBomimpctAnlysisList.get(e).getPartNm());
					eBomdata.setLvl(eBomimpctAnlysisList.get(e).getLvl());
					eBomdata.setDfsOrdr(eBomimpctAnlysisList.get(e).getDfsOrdr());
					finalEBomimpctAnlysisList.add(eBomdata);
				   }	
				 }	
				 impactAnlysMap.put(partIdLst.get(i)+"~E", finalEBomimpctAnlysisList);
				  
				  for(int m=0;m<mBomimpctAnlysisList.size();m++){
					if(mBomimpctAnlysisList.get(m).getPartId().equals(partIdLst.get(i))){ 
					PLMImpactAnalysisData  mBomdata = new PLMImpactAnalysisData();
					mBomdata.setImmediateParentId(mBomimpctAnlysisList.get(m).getImmediateParent());
					mBomdata.setImmediateParent(mBomimpctAnlysisList.get(m).getImmediateParent());
					mBomdata.setImmediateParentRev(mBomimpctAnlysisList.get(m).getImmediateParentRev());
					mBomdata.setTopLvlParentNm(mBomimpctAnlysisList.get(m).getTopLvlParentNm());
					mBomdata.setLgclFtrNm(mBomimpctAnlysisList.get(m).getLgclFtrNm());
					mBomdata.setLgclFtrType(mBomimpctAnlysisList.get(m).getLgclFtrType());
					mBomdata.setPrdtCnfgNm(mBomimpctAnlysisList.get(m).getPrdtCnfgNm());
					mBomdata.setHwBldNm(mBomimpctAnlysisList.get(m).getHwBldNm());
					mBomdata.setHwBldState(mBomimpctAnlysisList.get(m).getHwBldState());
					mBomdata.setPlantNm(mBomimpctAnlysisList.get(m).getPlantNm());
					mBomdata.setPartId(mBomimpctAnlysisList.get(m).getPartId());
					mBomdata.setPartNm(mBomimpctAnlysisList.get(m).getPartNm());
					mBomdata.setLvl(mBomimpctAnlysisList.get(m).getLvl());
					mBomdata.setDfsOrdr(mBomimpctAnlysisList.get(m).getDfsOrdr());
					finalMBomimpctAnlysisList.add(mBomdata);
				   }	
				 }	
				 impactAnlysMap.put(partIdLst.get(i)+"~M", finalMBomimpctAnlysisList);  
			   }
			
		return impactAnlysMap;
		
	}
	
	/**
	 * Mapper for Getting Impact Analysis Data
	 */
	private static final class EBOMImpactDataMapper implements ParameterizedRowMapper<PLMImpactAnalysisData>{	
	public PLMImpactAnalysisData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
		
			PLMImpactAnalysisData data = new PLMImpactAnalysisData();
			SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
					"MM/dd/yyyy");
			data.setImmediateParentId(PLMUtils.checkNullVal(rs.getString("IMDT_PARNT_ID")));
			data.setImmediateParent(PLMUtils.checkNullVal(rs.getString("IMMEDIATE_PARENT")));
			data.setImmediateParentRev(PLMUtils.checkNullVal(rs.getString("IMMEDIATE_PARENT_REV")));
			data.setTopLvlParentNm(PLMUtils.checkNullVal(rs.getString("TOP_LEVEL_PARENT_NAME")));
			
			data.setLgclFtrNm(PLMUtils.checkNullVal(rs.getString("LGCL_FTR")));
			data.setLgclFtrType(PLMUtils.checkNullVal(rs.getString("LGCL_FTR_TYPE")));
			data.setPrdtCnfgNm(PLMUtils.checkNullVal(rs.getString("PC_NAME")));
			data.setHwBldNm(PLMUtils.checkNullVal(rs.getString("HW_BLD_NAME")));
			data.setHwBldState(PLMUtils.checkNullVal(rs.getString("HW_BLD_STATE")));
			
			Date bldRelDate = rs.getDate("BLD_REL_DATE");
			if (bldRelDate != null) {
				String strIssueDt = SIMPLE_DATE_FORMAT.format(bldRelDate);
				data.setBldRelDate(strIssueDt);
			} 	
			data.setPlantNm(PLMUtils.checkNullVal(rs.getString("PLANT_NM")));
			
			data.setPartId(PLMUtils.checkNullVal(rs.getString("PART_ID")));
			data.setPartNm(PLMUtils.checkNullVal(rs.getString("PART_NM")));
			data.setLvl(PLMUtils.checkNullVal(rs.getString("LEVEL")));
			data.setDfsOrdr(PLMUtils.checkNullVal(rs.getString("DFSORDER")));
			return data;
		}
	}
	
	/**
	 * Mapper for Getting Impact Analysis Data
	 */
	private static final class MBOMImpactDataMapper implements ParameterizedRowMapper<PLMImpactAnalysisData>{	
	public PLMImpactAnalysisData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
		
			PLMImpactAnalysisData data = new PLMImpactAnalysisData();
			SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
					"MM/dd/yyyy");
			data.setImmediateParentId(PLMUtils.checkNullVal(rs.getString("IMDT_PARNT_ID")));
			data.setImmediateParent(PLMUtils.checkNullVal(rs.getString("IMMEDIATE_PARENT")));
			data.setImmediateParentRev(PLMUtils.checkNullVal(rs.getString("IMMEDIATE_PARENT_REV")));
			data.setTopLvlParentNm(PLMUtils.checkNullVal(rs.getString("TOP_LEVEL_PARENT_NAME")));
			
			data.setLgclFtrNm(PLMUtils.checkNullVal(rs.getString("LGCL_FTR")));
			data.setLgclFtrType(PLMUtils.checkNullVal(rs.getString("LGCL_FTR_TYPE")));
			data.setPrdtCnfgNm(PLMUtils.checkNullVal(rs.getString("PC_NAME")));
			data.setHwBldNm(PLMUtils.checkNullVal(rs.getString("HW_BLD_NAME")));
			data.setHwBldState(PLMUtils.checkNullVal(rs.getString("HW_BLD_STATE")));
			
			Date bldRelDate = rs.getDate("BLD_REL_DATE");
			if (bldRelDate != null) {
				String strIssueDt = SIMPLE_DATE_FORMAT.format(bldRelDate);
				data.setBldRelDate(strIssueDt);
			} 	
			data.setPlantNm(PLMUtils.checkNullVal(rs.getString("PLANT_NM")));
			
			data.setPartId(PLMUtils.checkNullVal(rs.getString("PART_ID")));
			data.setPartNm(PLMUtils.checkNullVal(rs.getString("PART_NM")));
			//data.setLvl(PLMUtils.checkNullVal(rs.getString("LEVEL")));
			//data.setDfsOrdr(PLMUtils.checkNullVal(rs.getString("DFSORDER")));
			return data;
		}
	}
	//Newly Added methods for multiple part numbers
	/**
	 * This method is used to getCopicsDataCount 
	 * 
	 * @param partNm
	 * @return Map
	 * @throws PLMCommonException
	 */
	public int getCopicsDataCount(List<String> partNmList) throws PLMCommonException{
		LOG.info("Entering getCopicsDataCount() method.");
		int count=0;
		StringBuffer sqlQuery =new StringBuffer();
		try{
			if(!PLMUtils.isEmptyList(partNmList)){
				int vtCntInt =0;
				int vtCntIncr=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				int vtCntLimit=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				int val = 0;
				int loopCount = 0;
				int partListCnt=partNmList.size();
				boolean vtFlag=false;
				
				if(partListCnt <=vtCntLimit){
					loopCount = 1;
				}else{
					loopCount = partListCnt/vtCntLimit;				
					val = partListCnt - (vtCntLimit * loopCount);
					  if (val > 0) {
						loopCount++;					
					   }
				}
				
				sqlQuery.append(PLMWhereusedQueries.GET_COPICS_DATA_PARTS_COUNT_VAL);
				for (int i=0;i<loopCount;i++) {
					if(vtCntIncr > partListCnt){
						vtCntIncr=partListCnt;
					 }
					List <String> partNumListLcl = new ArrayList<String>();
					LOG.info("-------------------Loop Rotating from part list index "+vtCntInt +" and "+vtCntIncr);
					 for(int j=vtCntInt;j<vtCntIncr;j++){
						 partNumListLcl.add(partNmList.get(j));
					 }
					if(!vtFlag){
						sqlQuery.append("B.ITM_ID_NUM IN ("+PLMUtils.setListForPartNames(partNumListLcl)+")");
						vtFlag =true;
					}else{
						sqlQuery.append(" OR B.ITM_ID_NUM IN ("+PLMUtils.setListForPartNames(partNumListLcl)+")");
					}
					vtCntInt =vtCntIncr+1;
					if(vtCntIncr > partListCnt){
						vtCntIncr=partListCnt;
					 }else{
					  vtCntIncr =vtCntIncr+Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
					 }
				}
				sqlQuery.append(")");
				
				 LOG.info("Executing Query for Count of COPICS part numbers"+sqlQuery);
				 count = getJdbcTemplate().queryForInt(sqlQuery.toString());
			}
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getCopicsDataCount() method.");
		return count;
	}
	
	/**
	 * This method is used to getSbomDevDataCount 
	 * 
	 * @param partNm
	 * @return Map
	 * @throws PLMCommonException
	 */
	public int getSbomDevDataCount(List<String> partNmList) throws PLMCommonException{
		LOG.info("Entering getSbomDevDataCount() method.");
		int count=0;
		StringBuffer sqlQuery =new StringBuffer();
		StringBuffer oldItmQuery =new StringBuffer();
		StringBuffer newItmQuery =new StringBuffer();
		try{
			if(!PLMUtils.isEmptyList(partNmList)){
				int vtCntInt =0;
				int vtCntIncr=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				int vtCntLimit=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				int val = 0;
				int loopCount = 0;
				int partListCnt=partNmList.size();
				boolean vtFlag=false;
				
				if(partListCnt <=vtCntLimit){
					loopCount = 1;
				}else{
					loopCount = partListCnt/vtCntLimit;				
					val = partListCnt - (vtCntLimit * loopCount);
					  if (val > 0) {
						loopCount++;					
					   }
				}
				sqlQuery.append(PLMWhereusedQueries.GET_SBOM_DATA_PARTS_COUNT_VAL_1);
				for (int i=0;i<loopCount;i++) {
					if(vtCntIncr > partListCnt){
						vtCntIncr=partListCnt;
					 }
					List <String> partNumListLcl = new ArrayList<String>();
					LOG.info("-------------------Loop Rotating from part list index "+vtCntInt +" and "+vtCntIncr);
					 for(int j=vtCntInt;j<vtCntIncr;j++){
						 partNumListLcl.add(partNmList.get(j));
					 }
					if(!vtFlag){
						newItmQuery.append("A.NEWITEM IN ("+PLMUtils.setListForPartNames(partNumListLcl)+")");
						oldItmQuery.append("A.OLDITEM IN ("+PLMUtils.setListForPartNames(partNumListLcl)+")");
						vtFlag =true;
					}else{
						newItmQuery.append(" OR A.NEWITEM IN ("+PLMUtils.setListForPartNames(partNumListLcl)+")");
						oldItmQuery.append(" OR A.OLDITEM IN ("+PLMUtils.setListForPartNames(partNumListLcl)+")");
					}
					vtCntInt =vtCntIncr+1;
					if(vtCntIncr > partListCnt){
						vtCntIncr=partListCnt;
					 }else{
					  vtCntIncr =vtCntIncr+Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
					 }
				}
				sqlQuery.append(newItmQuery);
				sqlQuery.append(")");
				sqlQuery.append(PLMWhereusedQueries.GET_SBOM_DATA_PARTS_COUNT_VAL_2);
				sqlQuery.append(oldItmQuery);
				sqlQuery.append("))A");
				
				 LOG.info("Executing Query for Count of SBOM part numbers"+sqlQuery);
				 count = getJdbcTemplate().queryForInt(sqlQuery.toString());
			}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getSbomDevDataCount() method.");
		return count;
	}

	/**
	 * This method is used to getEbomDataCount 
	 * 
	 * @param partNm
	 * @return Map
	 * @throws PLMCommonException
	 */
	public int getEbomDataCount(List<String> partNmList) throws PLMCommonException{
		LOG.info("Entering getEbomDataCount() method.");
		int count=0;
		StringBuffer sqlQuery =new StringBuffer();
		try{
			if(!PLMUtils.isEmptyList(partNmList)){
				int vtCntInt =0;
				int vtCntIncr=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				int vtCntLimit=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				int val = 0;
				int loopCount = 0;
				int partListCnt=partNmList.size();
				boolean vtFlag=false;
				
				if(partListCnt <=vtCntLimit){
					loopCount = 1;
				}else{
					loopCount = partListCnt/vtCntLimit;				
					val = partListCnt - (vtCntLimit * loopCount);
					  if (val > 0) {
						loopCount++;					
					   }
				}
				
				sqlQuery.append(PLMWhereusedQueries.GET_EBOM_DATA_PARTS_COUNT_VAL);
				for (int i=0;i<loopCount;i++) {
					if(vtCntIncr > partListCnt){
						vtCntIncr=partListCnt;
					 }
					List <String> partNumListLcl = new ArrayList<String>();
					LOG.info("-------------------Loop Rotating from part list index "+vtCntInt +" and "+vtCntIncr);
					 for(int j=vtCntInt;j<vtCntIncr;j++){
						 partNumListLcl.add(partNmList.get(j));
					 }
					if(!vtFlag){
						sqlQuery.append(" TO_NAME IN ("+PLMUtils.setListForPartNames(partNumListLcl)+")");
						vtFlag =true;
					}else{
						sqlQuery.append(" OR TO_NAME IN ("+PLMUtils.setListForPartNames(partNumListLcl)+")");
					}
					vtCntInt =vtCntIncr+1;
					if(vtCntIncr > partListCnt){
						vtCntIncr=partListCnt;
					 }else{
					  vtCntIncr =vtCntIncr+Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
					 }
				}
				sqlQuery.append(")");
				
				 LOG.info("Executing Query for Count of EBOM part numbers"+sqlQuery);
				 count = getJdbcTemplate().queryForInt(sqlQuery.toString());
			}
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getEbomDataCount() method.");
		return count;
	}
	
	
	
	/**
	 * This method is used to getSbomDevDataCount 
	 * 
	 * @param partNm
	 * @return Map
	 * @throws PLMCommonException
	 */
	public int getRpdmDataCount(List<String> partNmList) throws PLMCommonException{
		LOG.info("Entering getRpdmCount() method.");
		int count=0;
		StringBuffer sqlQuery =new StringBuffer();
		try{
			if(!PLMUtils.isEmptyList(partNmList)){
				int vtCntInt =0;
				int vtCntIncr=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				int vtCntLimit=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				int val = 0;
				int loopCount = 0;
				int partListCnt=partNmList.size();
				boolean vtFlag=false;
				
				if(partListCnt <=vtCntLimit){
					loopCount = 1;
				}else{
					loopCount = partListCnt/vtCntLimit;				
					val = partListCnt - (vtCntLimit * loopCount);
					  if (val > 0) {
						loopCount++;					
					   }
				}
				
				sqlQuery.append(PLMWhereusedQueries.GET_RPDM_DATA_PARTS_COUNT_VAL);
				for (int i=0;i<loopCount;i++) {
					if(vtCntIncr > partListCnt){
						vtCntIncr=partListCnt;
					 }
					List <String> partNumListLcl = new ArrayList<String>();
					LOG.info("-------------------Loop Rotating from part list index "+vtCntInt +" and "+vtCntIncr);
					 for(int j=vtCntInt;j<vtCntIncr;j++){
						 partNumListLcl.add(partNmList.get(j));
					 }
					if(!vtFlag){
						sqlQuery.append(" CHILD_NAME IN ("+PLMUtils.setListForPartNames(partNumListLcl)+")");
						sqlQuery.append(" OR T4REFPARTNUMBER IN ("+PLMUtils.setListForPartNames(partNumListLcl)+")");
						vtFlag =true;
					}else{
						sqlQuery.append(" OR CHILD_NAME IN ("+PLMUtils.setListForPartNames(partNumListLcl)+")");
						sqlQuery.append(" OR T4REFPARTNUMBER IN ("+PLMUtils.setListForPartNames(partNumListLcl)+")");
					}
					vtCntInt =vtCntIncr+1;
					if(vtCntIncr > partListCnt){
						vtCntIncr=partListCnt;
					 }else{
					  vtCntIncr =vtCntIncr+Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
					 }
				}
				sqlQuery.append(")");
				
				 LOG.info("Executing Query for Count of rpdm part numbers"+sqlQuery);
				 count = getJdbcTemplate().queryForInt(sqlQuery.toString());
			}
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getEbomDataCount() method.");
		return count;
	}
	

	/**
	 * This method is used to getCopicsData
	 * 
	 * @param partNm
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String,Object> getCopicsData(List<String> partNmList) throws PLMCommonException{
		LOG.info("Entering getCopicsData() method.");
		Map<String,Object>  copicsDataMap = new HashMap<String, Object>();
		List<PLMWhereUsedData> copicsDataCountList = new ArrayList<PLMWhereUsedData>();
		List<PLMWhereUsedData> copicsDataList = new ArrayList<PLMWhereUsedData>();
		int partCount =0;
		int topPartCount =0;
		String VT0 =null;
		String VT_ALL_PARTS =null;
		String timeStamp = null;
		timeStamp = PLMUtils.volTableFormatDate();
		try{
			VT0 = PLMConstants.VT0.concat(timeStamp);
			VT_ALL_PARTS = PLMConstants.VT_ALL_PARTS.concat(timeStamp);
			int partListCnt =partNmList.size();
			int vtCntInt =0;
			int vtCntIncr=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
			int vtCntLimit=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
			int val = 0;
			int loopCount = 0;
			boolean vtFlag=false;
			
			if(partListCnt <=vtCntLimit){
				loopCount = 1;
			}else{
				loopCount = partListCnt/vtCntLimit;				
				val = partListCnt - (vtCntLimit * loopCount);
				  if (val > 0) {
					loopCount++;					
				   }
			}
			
			for (int i=0;i<loopCount;i++) {
				if(vtCntIncr > partListCnt){
					vtCntIncr=partListCnt;
				 }
				List <String> partNumListLcl = new ArrayList<String>();
				LOG.info("-------------------Loop Rotating from part list index "+vtCntInt +" and "+vtCntIncr);
				 for(int j=vtCntInt;j<vtCntIncr;j++){
					 partNumListLcl.add(partNmList.get(j));
				 }
				if(!vtFlag){
					LOG.info("Executing create VT0 Query : "+PLMWhereusedQueries.CREATE_COPICS_VTO.replace(PLMConstants.VT0, VT0)
							.replace("?", PLMUtils.setListForPartNames(partNumListLcl))+ "\n");
					getJdbcTemplate().execute(PLMWhereusedQueries.CREATE_COPICS_VTO.replace(PLMConstants.VT0, VT0)
							.replace("?", PLMUtils.setListForPartNames(partNumListLcl)));
					vtFlag =true;
				}else{
					LOG.info("Executing Insert VT0 Query : "+PLMWhereusedQueries.INSERT_COPICS_VTO.replace(PLMConstants.VT0, VT0)
							.replace("?", PLMUtils.setListForPartNames(partNumListLcl))+ "\n");
					getJdbcTemplate().execute(PLMWhereusedQueries.INSERT_COPICS_VTO.replace(PLMConstants.VT0, VT0)
							.replace("?", PLMUtils.setListForPartNames(partNumListLcl)));
				}
				
				vtCntInt =vtCntIncr+1;
				if(vtCntIncr > partListCnt){
					vtCntIncr=partListCnt;
				 }else{
				  vtCntIncr =vtCntIncr+Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				 }
			}
			
			LOG.info("Executing create VT_ALL_PARTS Query : "+PLMWhereusedQueries.CREATE_COPICS_VT_ALL_PARTS.replace(PLMConstants.VT_ALL_PARTS, VT_ALL_PARTS)+"\n");
			getJdbcTemplate().execute(PLMWhereusedQueries.CREATE_COPICS_VT_ALL_PARTS.replace(PLMConstants.VT_ALL_PARTS, VT_ALL_PARTS));

			LOG.info("Executing Final Query for COPICS DATA : "+PLMWhereusedQueries.GET_COPICS_FINAL_DATA.replace(PLMConstants.VT0, VT0)
					.replace(PLMConstants.VT_ALL_PARTS, VT_ALL_PARTS)+"\n");
			copicsDataList =getSimpleJdbcTemplate().query(PLMWhereusedQueries.GET_COPICS_FINAL_DATA.replace(PLMConstants.VT0, VT0)
					.replace(PLMConstants.VT_ALL_PARTS, VT_ALL_PARTS),new CopicsDetailMapper());
			
			
			 LOG.info("Executing Final Query for COPICS DATA Count : "+PLMWhereusedQueries.GET_COUNT_COPICS_FINAL_DATA.replace(PLMConstants.VT0, VT0)
						.replace(PLMConstants.VT_ALL_PARTS, VT_ALL_PARTS));
			copicsDataCountList =getSimpleJdbcTemplate().query(PLMWhereusedQueries.GET_COUNT_COPICS_FINAL_DATA.replace(PLMConstants.VT0, VT0)
					.replace(PLMConstants.VT_ALL_PARTS, VT_ALL_PARTS),new WhereUsedTopLvlCountMapper());
			
			if(!PLMUtils.isEmptyList(copicsDataCountList)){
				partCount =copicsDataCountList.get(0).getPartCount();
				topPartCount =copicsDataCountList.get(0).getTopPartCount();
			}
			
			copicsDataMap.put("CopicsData", copicsDataList);
			copicsDataMap.put("partCount", partCount);
			copicsDataMap.put("topPartCount", topPartCount);
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return copicsDataMap;

	}

	/**
	 * Mapper for Getting COPICS Data
	 */
	private static final class CopicsDetailMapper implements ParameterizedRowMapper<PLMWhereUsedData>{	
	public PLMWhereUsedData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMWhereUsedData data = new PLMWhereUsedData();
			data.setTopLvlParent(PLMUtils.checkNullVal(rs.getString("PARENT_ITEM")));
			data.setTopLvlParentDesc(PLMUtils.checkNullVal(rs.getString("PARENT_DESC")));
			data.setImdParent(PLMUtils.checkNullVal(rs.getString("IMDT_PARENT_ITEM")));
			data.setImdParentDesc(PLMUtils.checkNullVal(rs.getString("IMDT_PARENT_DESC")));
			data.setPartId(PLMUtils.checkNullVal(rs.getString("ID")));
			data.setPartNum(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
			data.setPartDesc(PLMUtils.checkNullVal(rs.getString("PART_DESCRIPTION")));
			data.setQty(PLMUtils.checkNullVal(rs.getString("QTY")));
			data.setPartUom(PLMUtils.checkNullVal(rs.getString("UOM_DESC")));
			data.setSerialNumber(PLMUtils.checkNullVal(rs.getString("SRLNUM")));
			data.setStatus(PLMUtils.checkNullVal(rs.getString("STATUS")));
			return data;
		}
	}
	
	/**
	 * Mapper for Getting WhereUsedTopLvlCountMapper Count Data
	 */
	private static final class WhereUsedTopLvlCountMapper implements ParameterizedRowMapper<PLMWhereUsedData>{	
	public PLMWhereUsedData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMWhereUsedData data = new PLMWhereUsedData();
			data.setPartCount(rs.getInt("PART_CNT"));
			data.setTopPartCount(rs.getInt("TOP_PART_CNT"));
			return data;
		}
	}
	
	
	private static final class WhereUsedTopLvlRpdmData implements ParameterizedRowMapper<PLMWhereUsedData>{	
		public PLMWhereUsedData mapRow(ResultSet rs, int rowcount)
					throws SQLException {
				PLMWhereUsedData data = new PLMWhereUsedData();
				data.setPartCount(rs.getInt("PART_CNT"));
				data.setTopPartCount(rs.getInt("TOP_PART_CNT"));
				return data;
			}
		}
	
	/**
	 * This method is used to getSBOMDevData
	 * 
	 * @param partNm
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String,Object> getSBOMDevData(List<String> partNmList) throws PLMCommonException{
		LOG.info("Entering getSBOMDevData() method.");
		Map<String,Object>  sbomDataMap = new HashMap<String, Object>();
		List<PLMWhereUsedData> sbomDevDatatmpList = new ArrayList<PLMWhereUsedData>();
		List<PLMWhereUsedData> sbomDevDataFinalList = new ArrayList<PLMWhereUsedData>();
		List<PLMWhereUsedData> sbomDataCountList = new ArrayList<PLMWhereUsedData>();
		int partCount =0;
		int topPartCount =0;
		StringBuffer sbomDevCountQry =new StringBuffer();
		StringBuffer oldItmQuery =new StringBuffer();
		StringBuffer newItmQuery =new StringBuffer();
		boolean vtFlag=false;
		try{
			int partListCnt =partNmList.size();
			int vtCntInt =0;
			int vtCntIncr=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
			int vtCntLimit=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
			int val = 0;
			int loopCount = 0;
			
			if(partListCnt <=vtCntLimit){
				loopCount = 1;
			}else{
				loopCount = partListCnt/vtCntLimit;				
				val = partListCnt - (vtCntLimit * loopCount);
				  if (val > 0) {
					loopCount++;					
				   }
			}
			
			for (int i=0;i<loopCount;i++) {
				if(vtCntIncr > partListCnt){
					vtCntIncr=partListCnt;
				 }
				List <String> partNumListLcl = new ArrayList<String>();
				LOG.info("-------------------Loop Rotating from part list index "+vtCntInt +" and "+vtCntIncr);
				 for(int j=vtCntInt;j<vtCntIncr;j++){
					 partNumListLcl.add(partNmList.get(j));
				 }
				 sbomDevDatatmpList = new ArrayList<PLMWhereUsedData>();
				 LOG.info("Executing Final Query for BOM Deviation DATA : "+PLMWhereusedQueries.GET_SBOM_DEV_FINAL_DATA.replace("##1", PLMUtils.setListForPartNames(partNumListLcl))
							.replace("##2", PLMUtils.setListForPartNames(partNumListLcl))+"\n");
				 
				 sbomDevDatatmpList =getSimpleJdbcTemplate().query(PLMWhereusedQueries.GET_SBOM_DEV_FINAL_DATA.replace("##1", PLMUtils.setListForPartNames(partNumListLcl))
							.replace("##2", PLMUtils.setListForPartNames(partNumListLcl)),new SBomDeviationMapper());
				 
				 sbomDevDataFinalList.addAll(sbomDevDatatmpList);
				 
				 if(!vtFlag){
						newItmQuery.append("A.NEWITEM IN ("+PLMUtils.setListForPartNames(partNumListLcl)+")");
						oldItmQuery.append("A.OLDITEM IN ("+PLMUtils.setListForPartNames(partNumListLcl)+")");
						vtFlag =true;
					}else{
						newItmQuery.append(" OR A.NEWITEM IN ("+PLMUtils.setListForPartNames(partNumListLcl)+")");
						oldItmQuery.append(" OR A.OLDITEM IN ("+PLMUtils.setListForPartNames(partNumListLcl)+")");
					}
				 
				vtCntInt =vtCntIncr+1;
				 if(vtCntIncr > partListCnt){
					vtCntIncr=partListCnt;
				 }else{
				  vtCntIncr =vtCntIncr+Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				 }
			}
			LOG.info("Result Set for SBOM Deviation Data"+sbomDevDataFinalList.size());

			sbomDevCountQry.append(PLMWhereusedQueries.GET_COUNT_SBOM_DEV_FINAL_DATA_1);
			sbomDevCountQry.append(newItmQuery);
			sbomDevCountQry.append(")");
			sbomDevCountQry.append(PLMWhereusedQueries.GET_COUNT_SBOM_DEV_FINAL_DATA_2);
			sbomDevCountQry.append(oldItmQuery);
			sbomDevCountQry.append("))A");
			
			 LOG.info("Executing Final Query for BOM Deviation DATA Count : "+sbomDevCountQry);
			sbomDataCountList =getSimpleJdbcTemplate().query(sbomDevCountQry.toString(),new WhereUsedTopLvlCountMapper());
			
			if(!PLMUtils.isEmptyList(sbomDataCountList)){
				partCount =sbomDataCountList.get(0).getPartCount();
				topPartCount =sbomDataCountList.get(0).getTopPartCount();
			}

			sbomDataMap.put("SBoMData", sbomDevDataFinalList);
			sbomDataMap.put("partCount", partCount);
			sbomDataMap.put("topPartCount", topPartCount);
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return sbomDataMap;

	}

	/**
	 * Mapper for Getting SBomDeviationMapper
	 */
	private static final class SBomDeviationMapper implements ParameterizedRowMapper<PLMWhereUsedData>{	
	public PLMWhereUsedData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMWhereUsedData data = new PLMWhereUsedData();
			data.setTurbnNUm(PLMUtils.checkNullVal(rs.getString("TURBNUM")));
			data.setSrlNum1(PLMUtils.checkNullVal(rs.getString("SRLNUM")));
			data.setMli(PLMUtils.checkNullVal(rs.getString("MLI")));
			data.setNewItem(PLMUtils.checkNullVal(rs.getString("NEWITEM")));
			data.setOldItem(PLMUtils.checkNullVal(rs.getString("OLDITEM")));
			data.setDescript(PLMUtils.checkNullVal(rs.getString("DESCRIPT")));
			data.setDtent(PLMUtils.checkNullVal(rs.getString("DTENT")));
			data.setAuthen(PLMUtils.checkNullVal(rs.getString("AUTHECN")));
			data.setQty1(PLMUtils.checkNullVal(rs.getString("QTY")));
			data.setOrign(PLMUtils.checkNullVal(rs.getString("ORIGIN")));
					
			Date dateEnter = rs.getDate("DTENT");
			 if (dateEnter != null) {
			  data.setDtentExl(dateEnter);
			 } 
			return data;
		}
	}
	
	
	
	
	/**
	 * This method is used to getSBOMDevData
	 * 
	 * @param partNm
	 * @return Map
	 * @throws PLMCommonException
	 */
	
	
	public Map<String,Object> getRpDmData(List<String> partNmList) throws PLMCommonException{
		LOG.info("Entering getSBOMDevData() method.");
		Map<String,Object>  rpdmDataMap = new HashMap<String, Object>();
		List<PLMWhereUsedData> rpdmDataList = new ArrayList<PLMWhereUsedData>();
		List<PLMWhereUsedData> sbomDevDataFinalList = new ArrayList<PLMWhereUsedData>();
		List<PLMWhereUsedData> rpdmDataCountList = new ArrayList<PLMWhereUsedData>();
		int partCount =0;
		int topPartCount =0;
		StringBuffer sbomDevCountQry =new StringBuffer();
		StringBuffer oldItmQuery =new StringBuffer();
		StringBuffer newItmQuery =new StringBuffer();
		boolean vtFlag=false;
		try{
			int partListCnt =partNmList.size();
			int vtCntInt =0;
			int vtCntIncr=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
			int vtCntLimit=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
			int val = 0;
			int loopCount = 0;
			
			if(partListCnt <=vtCntLimit){
				loopCount = 1;
			}else{
				loopCount = partListCnt/vtCntLimit;				
				val = partListCnt - (vtCntLimit * loopCount);
				  if (val > 0) {
					loopCount++;					
				   }
			}
			
			for (int i=0;i<loopCount;i++) {
				if(vtCntIncr > partListCnt){
					vtCntIncr=partListCnt;
				 }
				List <String> partNumListLcl = new ArrayList<String>();
				LOG.info("-------------------Loop Rotating from part list index "+vtCntInt +" and "+vtCntIncr);
				 for(int j=vtCntInt;j<vtCntIncr;j++){
					 partNumListLcl.add(partNmList.get(j));
				 }
				 rpdmDataList = new ArrayList<PLMWhereUsedData>();
				 LOG.info("Executing Final Query for BOM Deviation DATA : "+PLMWhereusedQueries.GET_RPDM_FINAL_DATA.replace("##1", PLMUtils.setListForPartNames(partNumListLcl))
							.replace("##2", PLMUtils.setListForPartNames(partNumListLcl))+"\n");
				 
				 rpdmDataList =getSimpleJdbcTemplate().query(PLMWhereusedQueries.GET_RPDM_FINAL_DATA.replace("##1", PLMUtils.setListForPartNames(partNumListLcl))
							.replace("##2", PLMUtils.setListForPartNames(partNumListLcl)),new RPdmDeviationMapper());
				 
				// sbomDevDataFinalList.addAll(sbomDevDatatmpList);
				 
				 LOG.info("Executing Final Query for BOM Deviation DATA : "+PLMWhereusedQueries.GET_RPDM_TOP_PART_COUNT.replace("##1", PLMUtils.setListForPartNames(partNumListLcl))
							.replace("##2", PLMUtils.setListForPartNames(partNumListLcl))+"\n");
				 
				 rpdmDataCountList=getSimpleJdbcTemplate().query(PLMWhereusedQueries.GET_RPDM_TOP_PART_COUNT.replace("##1", PLMUtils.setListForPartNames(partNumListLcl))
							.replace("##2", PLMUtils.setListForPartNames(partNumListLcl)),new WhereUsedTopLvlRpdmData());
				 
				 
				 
			
				
					
					if(!PLMUtils.isEmptyList(rpdmDataCountList)){
						partCount =rpdmDataCountList.get(0).getPartCount();
						topPartCount =rpdmDataCountList.get(0).getTopPartCount();
					}
				 
		

				 rpdmDataMap.put("rpdmData", rpdmDataList);
				 rpdmDataMap.put("partCount", partCount);
				 rpdmDataMap.put("topPartCount", topPartCount);
			
		}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return rpdmDataMap;

	}
	
	
	
	
	
	
	
	private static final class RPdmDeviationMapper implements ParameterizedRowMapper<PLMWhereUsedData>{	
	public PLMWhereUsedData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMWhereUsedData data = new PLMWhereUsedData();
			
			data.setSystemId(PLMUtils.checkNullVal(rs.getString("SYSTEM_ID")));
			data.setSystemName(PLMUtils.checkNullVal(rs.getString("SYSTEM_NM")));
			data.setClassName(PLMUtils.checkNullVal(rs.getString("CLASS_NM")));
			data.setRelType(PLMUtils.checkNullVal(rs.getString("REL_TYPE")));
			data.setParentName(PLMUtils.checkNullVal(rs.getString("PARENT_NM")));
			data.setParentTextName(PLMUtils.checkNullVal(rs.getString("PARENT_TEXTM")));
			data.setChildName(PLMUtils.checkNullVal(rs.getString("CHILD_NAME")));
			data.setChildRev(PLMUtils.checkNullVal(rs.getString("CHILD_REV")));
			data.setTextName(PLMUtils.checkNullVal(rs.getString("TEXTM")));
			data.setT4refPartNumber(PLMUtils.checkNullVal(rs.getString("T4REFPARTNUMBER")));
			data.setT4refPartRev(PLMUtils.checkNullVal(rs.getString("T4REFPARTREVISION")));
			data.setBomLevel(PLMUtils.checkNullVal(rs.getString("BOM_LVL")));
		
			return data;
		}
	}
	
	
	
	
	
	
	
	/**
	 * This method is used to getEBOMData
	 * 
	 * @param partNm
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String,Object> getEBOMData(List<String> partNmList) throws PLMCommonException{
		LOG.info("Entering getEBOMData() method.");
		Map<String,Object>  ebomDataMap = new HashMap<String, Object>();
		List<PLMWhereUsedData> ebomDataList = new ArrayList<PLMWhereUsedData>();
		List<PLMWhereUsedData> ebomDataCountList = new ArrayList<PLMWhereUsedData>();
		int partCount =0;
		int topPartCount =0;
		String VT_TEMP =null;
		String timeStamp = null;
		timeStamp = PLMUtils.volTableFormatDate();
		try{
			VT_TEMP = PLMConstants.VT_TEMP.concat(timeStamp);
			int partListCnt =partNmList.size();
			int vtCntInt =0;
			int vtCntIncr=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
			int vtCntLimit=Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
			int val = 0;
			int loopCount = 0;
			boolean vtFlag=false;
			
			if(partListCnt <=vtCntLimit){
				loopCount = 1;
			}else{
				loopCount = partListCnt/vtCntLimit;				
				val = partListCnt - (vtCntLimit * loopCount);
				  if (val > 0) {
					loopCount++;					
				   }
			}
			
			for (int i=0;i<loopCount;i++) {
				if(vtCntIncr > partListCnt){
					vtCntIncr=partListCnt;
				 }
				List <String> partNumListLcl = new ArrayList<String>();
				LOG.info("-------------------Loop Rotating from part list index "+vtCntInt +" and "+vtCntIncr);
				 for(int j=vtCntInt;j<vtCntIncr;j++){
					 partNumListLcl.add(partNmList.get(j));
				 }
				if(!vtFlag){
					LOG.info("Executing create VT_TEMP Query : "+PLMWhereusedQueries.CREATE_EBOM_VT_TEMP.replace(PLMConstants.VT_TEMP, VT_TEMP)
							.replace("?", PLMUtils.setListForPartNames(partNumListLcl))+ "\n");
					getJdbcTemplate().execute(PLMWhereusedQueries.CREATE_EBOM_VT_TEMP.replace(PLMConstants.VT_TEMP, VT_TEMP)
							.replace("?", PLMUtils.setListForPartNames(partNumListLcl)));
					vtFlag =true;
				}else{
					LOG.info("Executing Insert VT0 Query : "+PLMWhereusedQueries.INSERT_EBOM_VT_TEMP.replace(PLMConstants.VT_TEMP, VT_TEMP)
							.replace("?", PLMUtils.setListForPartNames(partNumListLcl))+ "\n");
					getJdbcTemplate().execute(PLMWhereusedQueries.INSERT_EBOM_VT_TEMP.replace(PLMConstants.VT_TEMP, VT_TEMP)
							.replace("?", PLMUtils.setListForPartNames(partNumListLcl)));
				}
				
				vtCntInt =vtCntIncr+1;
				if(vtCntIncr > partListCnt){
					vtCntIncr=partListCnt;
				 }else{
				  vtCntIncr =vtCntIncr+Integer.parseInt(resourceBundle.getString("PART_NUMBERS_LOOP_CNT"));
				 }
			}
			
			LOG.info("Executing Final Query for EBOM DATA : "+PLMWhereusedQueries.GET_EBOM_FINAL_DATA.replace(PLMConstants.VT_TEMP, VT_TEMP)+"\n");
			ebomDataList =getSimpleJdbcTemplate().query(PLMWhereusedQueries.GET_EBOM_FINAL_DATA.replace(PLMConstants.VT_TEMP, VT_TEMP),new EBomDetailMapper());
			LOG.info("Result Set for EBOM Data"+ebomDataList.size());
			
			LOG.info("Executing Final Query for EBOM DATA Count: "+PLMWhereusedQueries.GET_COUNT_EBOM_FINAL_DATA.replace(PLMConstants.VT_TEMP, VT_TEMP)+"\n");
			ebomDataCountList =getSimpleJdbcTemplate().query(PLMWhereusedQueries.GET_COUNT_EBOM_FINAL_DATA.replace(PLMConstants.VT_TEMP, VT_TEMP)
					,new WhereUsedTopLvlCountMapper());
			
			if(!PLMUtils.isEmptyList(ebomDataCountList)){
				partCount =ebomDataCountList.get(0).getPartCount();
				topPartCount =ebomDataCountList.get(0).getTopPartCount();
			}
			
			ebomDataMap.put("EBoMData", ebomDataList);
			ebomDataMap.put("partCount", partCount);
			ebomDataMap.put("topPartCount", topPartCount);
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return ebomDataMap;

	}

	/**
	 * Mapper for Getting EBomDetailMapper
	 */
	private static final class EBomDetailMapper implements ParameterizedRowMapper<PLMWhereUsedData>{	
	public PLMWhereUsedData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMWhereUsedData data = new PLMWhereUsedData();
			data.setTopLvlParentId(PLMUtils.checkNullVal(rs.getString("TOP_LEVEL_PARENT_ID")));
			data.setTopLvlParentNm(PLMUtils.checkNullVal(rs.getString("TOP_LEVEL_PARENT_NAME")));
			data.setTopLvlParentRev(PLMUtils.checkNullVal(rs.getString("TOP_LEVEL_PARENT_REVISION")));
			data.setTopLvlParentDesc(PLMUtils.checkNullVal(rs.getString("TOP_LEVEL_PARENT_DESC")));
			data.setImmediateParentId(PLMUtils.checkNullVal(rs.getString("IMDT_PARNT_ID")));
			data.setImmediateParent(PLMUtils.checkNullVal(rs.getString("IMMEDIATE_PARENT")));
			data.setImmediateParentRev(PLMUtils.checkNullVal(rs.getString("IMMEDIATE_PARENT_REV")));
			data.setImdParentDesc(PLMUtils.checkNullVal(rs.getString("IMDT_PRNT_DESC")));
			data.setPartId(PLMUtils.checkNullVal(rs.getString("PART_ID")));
			data.setPartNm(PLMUtils.checkNullVal(rs.getString("PART_NM")));
			data.setPartDesc(PLMUtils.checkNullVal(rs.getString("PART_DESCRIPTION")));
			data.setQty(PLMUtils.checkNullVal(rs.getString("QTY")));
			data.setPartUom(PLMUtils.checkNullVal(rs.getString("UOM")));
			data.setLvl(PLMUtils.checkNullVal(rs.getString("LEVEL")));
			data.setDfsOrdr(PLMUtils.checkNullVal(rs.getString("DFSORDER")));
			return data;
		}
	}
	/**
	 * This method is used to loadFrameFuelCombustorList
	 * 
	 * @param 
	 * @return Map
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public Map<String, List<SelectItem>> loadFrameFuelCombustorList() throws PLMCommonException {


		LOG.info("Inside loadFrameFuelCombustorList method of plmwhereuseddaoimpl class");
		Map<String, List<SelectItem>> dropdownlist = new HashMap<String, List<SelectItem>>();		
		List<SelectItem> frameTypeList = null;
		List<SelectItem> fuelTypeList = null;
		List<SelectItem> combustorTypeList = null;
		try {			
			
			LOG.info("Query for getting distinct Frame Type List : " + PLMWhereusedQueries.QRY_FOR_GETTING_DSTNCT_FRAME_TYPE);
			frameTypeList = getJdbcTemplate().query(PLMWhereusedQueries.QRY_FOR_GETTING_DSTNCT_FRAME_TYPE, new DstnctFrameTypeMapper());	
			//frameTypeList=commonMethodHardCoded(1);
			Collections.sort(frameTypeList, new PLMUtils.SortListSelItem());
			LOG.info("size of  Frame Type List : " + frameTypeList.size());
			
			LOG.info("Query for getting distinct Fuel Type List : " + PLMWhereusedQueries.QRY_FOR_GETTING_DSTNCT_FUEL_TYPE);
			fuelTypeList = getJdbcTemplate().query(PLMWhereusedQueries.QRY_FOR_GETTING_DSTNCT_FUEL_TYPE,new DstnctFuelTypeMapper());
			//fuelTypeList=commonMethodHardCoded(2);
			Collections.sort(fuelTypeList, new PLMUtils.SortListSelItem());
			LOG.info("size of  Fuel Type List : " + fuelTypeList.size());
			
			LOG.info("Query for getting distinct Combustor Type List : " + PLMWhereusedQueries.QRY_FOR_GETTING_DSTNCT_COMBUSTOR_TYPE);
			combustorTypeList = getJdbcTemplate().query(PLMWhereusedQueries.QRY_FOR_GETTING_DSTNCT_COMBUSTOR_TYPE,new DstnctCombustorTypeMapper());
			//combustorTypeList=commonMethodHardCoded(3);
			Collections.sort(combustorTypeList, new PLMUtils.SortListSelItem());
			LOG.info("size of  Combustor Type List : " + combustorTypeList.size());
			
			dropdownlist.put("frameTypeList", frameTypeList);
			dropdownlist.put("fuelTypeList", fuelTypeList);
			dropdownlist.put("combustorTypeList", combustorTypeList);

		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return dropdownlist;
	}
	
	/**
	 * Row mapper for getting DstnctFrameTypeMapper
	 */
	private static final class DstnctFrameTypeMapper implements ParameterizedRowMapper<SelectItem>{
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs.getString("NAME").toUpperCase());
			return selectItem;
		}
	}
	/**
	 * Row mapper for getting DstnctFuelTypeMapper
	 */
	private static final class DstnctFuelTypeMapper implements ParameterizedRowMapper<SelectItem>{
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem data = new SelectItem(PLMUtils.checkNullVal(rs.getString("NAME")).toUpperCase(),
					PLMUtils.checkNullVal(rs.getString("DESCRIPTION")).toUpperCase());
			
			return data;
		}
	}
	/**
	 * Row mapper for getting DstnctCombustorTypeMapper
	 */
	private static final class DstnctCombustorTypeMapper implements ParameterizedRowMapper<SelectItem>{
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem data = new SelectItem(PLMUtils.checkNullVal(rs.getString("NAME")).toUpperCase(),
					PLMUtils.checkNullVal(rs.getString("DESCRIPTION")).toUpperCase());
			return data;
		}
	}

	@SuppressWarnings("unchecked")
	/**
	 * generateCmuSimilarPrjReport method for getting both doc list and part list
	 * 
	 */
	public Map<String,List<PLMCMUSmlrToPrjData>> generateCmuSimilarPrjReport(
			String selFrameTypeListName, String selFrameTypeTextBoxName,
			String selFuelTypeListName, String selFuelTypeTextBoxName,
			String selCombustorTypeListName,String selCombustorTypeTextBoxName,String mliTextBoxName,
			Date effectivityDateFrom,Date effectivityDateTo) throws PLMCommonException {

		LOG.info("Entering into  generateCmuSimilarPrjReport");
		LOG.info("Entering into  selFrameTypeListName"+selFrameTypeListName);
		LOG.info("Entering into  selFrameTypeTextBoxName"+selFrameTypeTextBoxName);
		LOG.info("Entering into  selFuelTypeListName"+selFuelTypeListName);
		LOG.info("Entering into  selFuelTypeTextBoxName"+selFuelTypeTextBoxName);
		LOG.info("Entering into  selCombustorTypeListName"+selCombustorTypeListName);
		LOG.info("Entering into  selCombustorTypeTextBoxName"+selCombustorTypeTextBoxName);
		LOG.info("Entering into  mliTextBoxName"+mliTextBoxName);
		LOG.info("Entering into  effectivityDateFrom"+effectivityDateFrom);
		LOG.info("Entering into  effectivityDateTo"+effectivityDateTo);
		Map<String,List<PLMCMUSmlrToPrjData>> cmuDataList= new HashMap<String,List<PLMCMUSmlrToPrjData>>();
		List<PLMCMUSmlrToPrjData> partsBomList =  new ArrayList<PLMCMUSmlrToPrjData>();
		List<PLMCMUSmlrToPrjData> specDocList =  new ArrayList<PLMCMUSmlrToPrjData>();
		StringBuffer sqlQuery = new StringBuffer();
		String VT_QRY1 = null;
		String VT_TOP_PART = null;
		String timeStamp = null;
		 try {
			 timeStamp = PLMUtils.volTableFormatDate();
			 VT_QRY1 = "VT_QRY1".concat(timeStamp);
			 VT_TOP_PART = "VT_TOP_PART".concat(timeStamp);
			 sqlQuery.append(PLMWhereusedQueries.QRY_FOR_CREATING_VOLATILE_ONE.replace("VT_QRY1",VT_QRY1));
				if(!PLMUtils.isEmpty(selFrameTypeListName)){
					sqlQuery.append(" AND GIB_EQUIP.EQUIP_CODE = '"+selFrameTypeListName+"'");
				}else if(!PLMUtils.isEmpty(selFrameTypeTextBoxName)){
					sqlQuery.append(" AND GIB_EQUIP.EQUIP_CODE = '"+selFrameTypeTextBoxName+"'");
				}
				if(!PLMUtils.isEmpty(selFuelTypeListName) || !PLMUtils.isEmpty(selFuelTypeTextBoxName) || !PLMUtils.isEmpty(selCombustorTypeListName) || !PLMUtils.isEmpty(selCombustorTypeTextBoxName)){
					sqlQuery.append(" AND REQUIREMENT_NAME IN (");
					
					List<String> reqList = new ArrayList<String>();
					if(!PLMUtils.isEmpty(selFuelTypeListName)){reqList.add(selFuelTypeListName);}
					if(!PLMUtils.isEmpty(selFuelTypeTextBoxName)){reqList.add(selFuelTypeTextBoxName);}
					if(!PLMUtils.isEmpty(selCombustorTypeListName)){reqList.add(selCombustorTypeListName);}
					if(!PLMUtils.isEmpty(selCombustorTypeTextBoxName)){reqList.add(selCombustorTypeTextBoxName);}
					
					sqlQuery.append(PLMUtils.convertListToStringWithQuotes(reqList)+")");
				
				}
				if(!PLMUtils.isEmpty(mliTextBoxName)){
					int i=mliTextBoxName.lastIndexOf(',');
					if(i==mliTextBoxName.length()-1){
						mliTextBoxName=mliTextBoxName.substring(0,mliTextBoxName.length()-1);
					}
					String sample="'".concat(mliTextBoxName.replaceAll("\\*","\\%").replaceAll("\\,","\\','")).concat("'");
					mliTextBoxName=" WHERE MLI LIKE ANY("+sample+")  ORDER BY MLI, FRAME_TYPE, FDM, ITEM_NUMBER, REQUIREMENT_NAME ";
				}else{
					mliTextBoxName=" ORDER BY MLI, FRAME_TYPE, FDM, ITEM_NUMBER, REQUIREMENT_NAME ";
				}
				
				if(!PLMUtils.isEmptyDate(effectivityDateFrom) && !PLMUtils.isEmptyDate(effectivityDateTo)){
					sqlQuery.append(" AND CAST(CNTRCT_PRJ.creation_date AS DATE)  BETWEEN CAST('");
					sqlQuery.append(new SimpleDateFormat("MM/dd/yyyy").format(effectivityDateFrom)+"'");
					sqlQuery.append(" AS DATE FORMAT 'MM/DD/YYYY') AND CAST('");
					sqlQuery.append(new SimpleDateFormat("MM/dd/yyyy").format(effectivityDateTo)+"'");
					sqlQuery.append(" AS DATE FORMAT 'MM/DD/YYYY')");
				}
				sqlQuery.append("GROUP BY 1,2,3,4,5,6,7) WITH DATA PRIMARY INDEX(PROJECT_NAME) ON COMMIT PRESERVE ROWS");
				
				LOG.info("Final Query for CMU Similar to project search query Volatile1:: "+sqlQuery);
				getJdbcTemplate().execute(sqlQuery.toString());
				
				//Query to execute 2nd Volatile table
				sqlQuery = new StringBuffer();
				sqlQuery.append(PLMWhereusedQueries.QRY_FOR_CREATING_VOLATILE_TWO.replace("VT_TOP_PART", VT_TOP_PART).replace("VT_QRY1", VT_QRY1));
				LOG.info("Final Query for CMU Similar to project search query Volatile2:: "+sqlQuery);
				getJdbcTemplate().execute(sqlQuery.toString());
				
				//Executing for Parts Bom Data
				sqlQuery = new StringBuffer();
				sqlQuery.append(PLMWhereusedQueries.QRY_FOR_GETTING_PARTS_BOM.replace("VT_TOP_PART", VT_TOP_PART));
				sqlQuery.append(mliTextBoxName);
				LOG.info("Final Query for CMU Similar to project search query Parts BOM:: "+sqlQuery);
				partsBomList =  getJdbcTemplate().query(sqlQuery.toString(), new PartsBomMapper());	
				
				//Executing for Specification and Doc Data
				sqlQuery = new StringBuffer();
				sqlQuery.append(PLMWhereusedQueries.QRY_FOR_GETTING_SPEC_DOC.replace("VT_TOP_PART", VT_TOP_PART));
				sqlQuery.append(mliTextBoxName);
				LOG.info("Final Query for CMU Similar to project search query Specification and Document:: "+sqlQuery);
				specDocList =  getJdbcTemplate().query(sqlQuery.toString(), new SpecDocMapper());	
				
				cmuDataList.put("partsBomList", partsBomList);
				cmuDataList.put("specDocList", specDocList);
			} catch (DataAccessException e) {
				PLMUtils.checkException(e.getMessage());
			}catch (Exception e) {
				PLMUtils.checkException(e.getMessage());
			}
			return cmuDataList;
	
	}
	
	/**
	 * Row mapper for getting PartsBomMapper
	 */
	private static final class PartsBomMapper implements ParameterizedRowMapper<PLMCMUSmlrToPrjData>{
		public PLMCMUSmlrToPrjData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMCMUSmlrToPrjData data = new PLMCMUSmlrToPrjData();
			data.setFdmId(PLMUtils.checkNullVal(rs.getString("FDM_ID")).toUpperCase());
			data.setFdm(PLMUtils.checkNullVal(rs.getString("FDM")).toUpperCase());
			data.setMli(PLMUtils.checkNullVal(rs.getString("MLI")).toUpperCase());
			data.setFrameType(PLMUtils.checkNullVal(rs.getString("FRAME_TYPE")).toUpperCase());
			data.setPartNumber(PLMUtils.checkNullVal(rs.getString("ITEM_NUMBER")).toUpperCase());
			data.setPartNumberId(PLMUtils.checkNullVal(rs.getString("PART_NUMBER_ID")).toUpperCase());
			data.setDescription(PLMUtils.checkNullVal(rs.getString("DESCRIPTION")).toUpperCase());
			data.setFcodeOne(PLMUtils.checkNullVal(rs.getString("REQUIREMENT_NAME")).toUpperCase());
			return data;
		}
	}
	/**
	 * Row mapper for getting PartsBomMapper
	 */
	private static final class SpecDocMapper implements ParameterizedRowMapper<PLMCMUSmlrToPrjData>{
		public PLMCMUSmlrToPrjData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMCMUSmlrToPrjData data = new PLMCMUSmlrToPrjData();
			data.setFdmId(PLMUtils.checkNullVal(rs.getString("FDM_ID")).toUpperCase());
			data.setFdm(PLMUtils.checkNullVal(rs.getString("FDM")).toUpperCase());
			data.setMli(PLMUtils.checkNullVal(rs.getString("MLI")).toUpperCase());
			data.setFrameType(PLMUtils.checkNullVal(rs.getString("FRAME_TYPE")).toUpperCase());
			data.setDocNumber(PLMUtils.checkNullVal(rs.getString("ITEM_NUMBER")).toUpperCase());
			data.setDocNumberId(PLMUtils.checkNullVal(rs.getString("DOC_NUMBER_ID")).toUpperCase());
			data.setDescription(PLMUtils.checkNullVal(rs.getString("DESCRIPTION")).toUpperCase());
			data.setFcodeOne(PLMUtils.checkNullVal(rs.getString("REQUIREMENT_NAME")).toUpperCase());
			return data;
		}
	}
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}
	
}