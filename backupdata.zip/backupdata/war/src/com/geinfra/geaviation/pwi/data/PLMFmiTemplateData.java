/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMFmiTemplateData.java
 * @Creation date: 11-June-2011
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.data;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

/**
 * @author bv85490
 *
 */

/**
 * @author bv85490
 * 
 */
public class PLMFmiTemplateData {
	/**
	  * Holds the templatepath
	  */
	private String templatepath;
	/**
	  * Holds the filename
	  */
	private String filename;
	/**
	  * Holds the srcfile
	  */
	private File srcfile;
	/**
	  * Holds the errormessage
	  */
	private String tmpltErrorMsg;

	//newly Added for FMI Manage Text
	private String ceiId;
	private String reqId;
	private String reqName;
	private String reqDesc;
	private String ceiName;
	private String ceiDesc;
	private String mliName;
	private String mliDesc;
	private String mliNotes;
	private String status;
	
	
	private String reqNameTxt;
	private String reqDescTxt;
	
	private String ceiNameTxt;
	private String ceiDescTxt;
	
	private String mliNameTxt;
	private String mliDescTxt;
	private String mliNotesTxt;
	
	private String applicableSymbol;
	private String modidicationDesc;
	private String specialNotes;
	private String repairTextVal;
	private String textFeild;
	private String specialTools;
	private String serviceDoc;
	private String fmiTextVal;
	private String mliId;
	private String stdTaskDuration;
	private int intstdTskDur;
	private String smlrToPartQTC;
	private String fillMntLeadTime;
	private int intfillMntLdTime;
	private String prsText;
	private String hoursEffort;
	private int inthoursEffort;
	
	private String rowcellVal;
	private String fieldName;
	private String errorDesc;
	
	private String reqCeiId;
	
	//Newly Added for setting Bulk CEI Data fields
	private List<SelectItem> selRequirment = new ArrayList<SelectItem>();
	private String selCeiName;
	private List<SelectItem> selCeiNameList= new ArrayList<SelectItem>();
	private String selReqName;
	private boolean displayFlag;
	private List<SelectItem> selMliNameList= new ArrayList<SelectItem>();
	private String selMliName;
	private boolean displayMliFlg;
	private String fmiBenefits;
	/**
	 * @return the selReqName
	 */
	public String getSelReqName() {
		return selReqName;
	}

	/**
	 * @param selReqName the selReqName to set
	 */
	public void setSelReqName(String selReqName) {
		this.selReqName = selReqName;
	}

	/**
	 * @return the templatepath
	 */
	public String getTemplatepath() {
		return templatepath;
	}

	/**
	 * @param templatepath
	 *            the templatepath to set
	 */
	public void setTemplatepath(String templatepath) {
		this.templatepath = templatepath;
	}

	/**
	 * @return the filename
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * @param filename
	 *            the filename to set
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}

	/**
	 * @return the srcfile
	 */
	public File getSrcfile() {
		return srcfile;
	}

	/**
	 * @param srcfile
	 *            the srcfile to set
	 */
	public void setSrcfile(File srcfile) {
		this.srcfile = srcfile;
	}



	/**
	 * @return the tmpltErrorMsg
	 */
	public String getTmpltErrorMsg() {
		return tmpltErrorMsg;
	}

	/**
	 * @param tmpltErrorMsg the tmpltErrorMsg to set
	 */
	public void setTmpltErrorMsg(String tmpltErrorMsg) {
		this.tmpltErrorMsg = tmpltErrorMsg;
	}

	/**
	 * @return the ceiId
	 */
	public String getCeiId() {
		return ceiId;
	}

	/**
	 * @param ceiId the ceiId to set
	 */
	public void setCeiId(String ceiId) {
		this.ceiId = ceiId;
	}

	/**
	 * @return the reqId
	 */
	public String getReqId() {
		return reqId;
	}

	/**
	 * @param reqId the reqId to set
	 */
	public void setReqId(String reqId) {
		this.reqId = reqId;
	}

	/**
	 * @return the reqName
	 */
	public String getReqName() {
		return reqName;
	}

	/**
	 * @param reqName the reqName to set
	 */
	public void setReqName(String reqName) {
		this.reqName = reqName;
	}

	/**
	 * @return the reqDesc
	 */
	public String getReqDesc() {
		return reqDesc;
	}

	/**
	 * @param reqDesc the reqDesc to set
	 */
	public void setReqDesc(String reqDesc) {
		this.reqDesc = reqDesc;
	}

	/**
	 * @return the ceiName
	 */
	public String getCeiName() {
		return ceiName;
	}

	/**
	 * @param ceiName the ceiName to set
	 */
	public void setCeiName(String ceiName) {
		this.ceiName = ceiName;
	}

	/**
	 * @return the ceiDesc
	 */
	public String getCeiDesc() {
		return ceiDesc;
	}

	/**
	 * @param ceiDesc the ceiDesc to set
	 */
	public void setCeiDesc(String ceiDesc) {
		this.ceiDesc = ceiDesc;
	}

	/**
	 * @return the mliName
	 */
	public String getMliName() {
		return mliName;
	}

	/**
	 * @param mliName the mliName to set
	 */
	public void setMliName(String mliName) {
		this.mliName = mliName;
	}

	/**
	 * @return the mliDesc
	 */
	public String getMliDesc() {
		return mliDesc;
	}

	/**
	 * @param mliDesc the mliDesc to set
	 */
	public void setMliDesc(String mliDesc) {
		this.mliDesc = mliDesc;
	}

	/**
	 * @return the reqNameTxt
	 */
	public String getReqNameTxt() {
		return reqNameTxt;
	}

	/**
	 * @param reqNameTxt the reqNameTxt to set
	 */
	public void setReqNameTxt(String reqNameTxt) {
		this.reqNameTxt = reqNameTxt;
	}

	/**
	 * @return the reqDescTxt
	 */
	public String getReqDescTxt() {
		return reqDescTxt;
	}

	/**
	 * @param reqDescTxt the reqDescTxt to set
	 */
	public void setReqDescTxt(String reqDescTxt) {
		this.reqDescTxt = reqDescTxt;
	}

	/**
	 * @return the ceiNameTxt
	 */
	public String getCeiNameTxt() {
		return ceiNameTxt;
	}

	/**
	 * @param ceiNameTxt the ceiNameTxt to set
	 */
	public void setCeiNameTxt(String ceiNameTxt) {
		this.ceiNameTxt = ceiNameTxt;
	}

	/**
	 * @return the ceiDescTxt
	 */
	public String getCeiDescTxt() {
		return ceiDescTxt;
	}

	/**
	 * @param ceiDescTxt the ceiDescTxt to set
	 */
	public void setCeiDescTxt(String ceiDescTxt) {
		this.ceiDescTxt = ceiDescTxt;
	}

	/**
	 * @return the mliNameTxt
	 */
	public String getMliNameTxt() {
		return mliNameTxt;
	}

	/**
	 * @param mliNameTxt the mliNameTxt to set
	 */
	public void setMliNameTxt(String mliNameTxt) {
		this.mliNameTxt = mliNameTxt;
	}

	/**
	 * @return the mliDescTxt
	 */
	public String getMliDescTxt() {
		return mliDescTxt;
	}

	/**
	 * @param mliDescTxt the mliDescTxt to set
	 */
	public void setMliDescTxt(String mliDescTxt) {
		this.mliDescTxt = mliDescTxt;
	}

	/**
	 * @return the mliNotesTxt
	 */
	public String getMliNotesTxt() {
		return mliNotesTxt;
	}

	/**
	 * @param mliNotesTxt the mliNotesTxt to set
	 */
	public void setMliNotesTxt(String mliNotesTxt) {
		this.mliNotesTxt = mliNotesTxt;
	}

	/**
	 * @return the mliNotes
	 */
	public String getMliNotes() {
		return mliNotes;
	}

	/**
	 * @param mliNotes the mliNotes to set
	 */
	public void setMliNotes(String mliNotes) {
		this.mliNotes = mliNotes;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the applicableSymbol
	 */
	public String getApplicableSymbol() {
		return applicableSymbol;
	}

	/**
	 * @param applicableSymbol the applicableSymbol to set
	 */
	public void setApplicableSymbol(String applicableSymbol) {
		this.applicableSymbol = applicableSymbol;
	}

	/**
	 * @return the modidicationDesc
	 */
	public String getModidicationDesc() {
		return modidicationDesc;
	}

	/**
	 * @param modidicationDesc the modidicationDesc to set
	 */
	public void setModidicationDesc(String modidicationDesc) {
		this.modidicationDesc = modidicationDesc;
	}

	/**
	 * @return the specialNotes
	 */
	public String getSpecialNotes() {
		return specialNotes;
	}

	/**
	 * @param specialNotes the specialNotes to set
	 */
	public void setSpecialNotes(String specialNotes) {
		this.specialNotes = specialNotes;
	}

	/**
	 * @return the repairText
	 */
	public String getRepairTextVal() {
		return repairTextVal;
	}

	/**
	 * @param repairText the repairText to set
	 */
	public void setRepairTextVal(String repairTextVal) {
		this.repairTextVal = repairTextVal;
	}

	/**
	 * @return the textFeild
	 */
	public String getTextFeild() {
		return textFeild;
	}

	/**
	 * @param textFeild the textFeild to set
	 */
	public void setTextFeild(String textFeild) {
		this.textFeild = textFeild;
	}

	/**
	 * @return the specialTools
	 */
	public String getSpecialTools() {
		return specialTools;
	}

	/**
	 * @param specialTools the specialTools to set
	 */
	public void setSpecialTools(String specialTools) {
		this.specialTools = specialTools;
	}

	/**
	 * @return the serviceDoc
	 */
	public String getServiceDoc() {
		return serviceDoc;
	}

	/**
	 * @param serviceDoc the serviceDoc to set
	 */
	public void setServiceDoc(String serviceDoc) {
		this.serviceDoc = serviceDoc;
	}

	/**
	 * @return the fmiText
	 */
	public String getFmiTextVal() {
		return fmiTextVal;
	}

	/**
	 * @param fmiText the fmiText to set
	 */
	public void setFmiTextVal(String fmiTextVal) {
		this.fmiTextVal = fmiTextVal;
	}

	/**
	 * @return the mliId
	 */
	public String getMliId() {
		return mliId;
	}
	
	/**
	 * @param mliId the mliId to set
	 */
	public void setMliId(String mliId) {
		this.mliId = mliId;
	}


	
	/**
	 * @return the stdTaskDuration
	 */
	public String getStdTaskDuration() {
		return stdTaskDuration;
	}

	/**
	 * @param stdTaskDuration the stdTaskDuration to set
	 */
	public void setStdTaskDuration(String stdTaskDuration) {
		this.stdTaskDuration = stdTaskDuration;
	}

	/**
	 * @return the intstdTskDur
	 */
	public int getIntstdTskDur() {
		return intstdTskDur;
	}

	/**
	 * @param intstdTskDur the intstdTskDur to set
	 */
	public void setIntstdTskDur(int intstdTskDur) {
		this.intstdTskDur = intstdTskDur;
	}

	/**
	 * @return the smlrToPartQTC
	 */
	public String getSmlrToPartQTC() {
		return smlrToPartQTC;
	}

	/**
	 * @param smlrToPartQTC the smlrToPartQTC to set
	 */
	public void setSmlrToPartQTC(String smlrToPartQTC) {
		this.smlrToPartQTC = smlrToPartQTC;
	}

	/**
	 * @return the fillMntLeadTime
	 */
	public String getFillMntLeadTime() {
		return fillMntLeadTime;
	}

	/**
	 * @param fillMntLeadTime the fillMntLeadTime to set
	 */
	public void setFillMntLeadTime(String fillMntLeadTime) {
		this.fillMntLeadTime = fillMntLeadTime;
	}

	/**
	 * @return the intfillMntLdTime
	 */
	public int getIntfillMntLdTime() {
		return intfillMntLdTime;
	}

	/**
	 * @param intfillMntLdTime the intfillMntLdTime to set
	 */
	public void setIntfillMntLdTime(int intfillMntLdTime) {
		this.intfillMntLdTime = intfillMntLdTime;
	}

	/**
	 * @return the prsText
	 */
	public String getPrsText() {
		return prsText;
	}

	/**
	 * @param prsText the prsText to set
	 */
	public void setPrsText(String prsText) {
		this.prsText = prsText;
	}

	/**
	 * @return the hoursEffort
	 */
	public String getHoursEffort() {
		return hoursEffort;
	}

	/**
	 * @param hoursEffort the hoursEffort to set
	 */
	public void setHoursEffort(String hoursEffort) {
		this.hoursEffort = hoursEffort;
	}

	/**
	 * @return the inthoursEffort
	 */
	public int getInthoursEffort() {
		return inthoursEffort;
	}

	/**
	 * @param inthoursEffort the inthoursEffort to set
	 */
	public void setInthoursEffort(int inthoursEffort) {
		this.inthoursEffort = inthoursEffort;
	}

	/**
	 * @return the rowcellVal
	 */
	public String getRowcellVal() {
		return rowcellVal;
	}

	/**
	 * @param rowcellVal the rowcellVal to set
	 */
	public void setRowcellVal(String rowcellVal) {
		this.rowcellVal = rowcellVal;
	}

	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * @param fieldName the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * @return the errorDesc
	 */
	public String getErrorDesc() {
		return errorDesc;
	}

	/**
	 * @param errorDesc the errorDesc to set
	 */
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	/**
	 * @return the reqCeiId
	 */
	public String getReqCeiId() {
		return reqCeiId;
	}

	/**
	 * @param reqCeiId the reqCeiId to set
	 */
	public void setReqCeiId(String reqCeiId) {
		this.reqCeiId = reqCeiId;
	}

	/**
	 * @return the selRequirment
	 */
	public List<SelectItem> getSelRequirment() {
		return selRequirment;
	}

	/**
	 * @param selRequirment the selRequirment to set
	 */
	public void setSelRequirment(List<SelectItem> selRequirment) {
		this.selRequirment = selRequirment;
	}

	/**
	 * @return the selCeiName
	 */
	public String getSelCeiName() {
		return selCeiName;
	}

	/**
	 * @param selCeiName the selCeiName to set
	 */
	public void setSelCeiName(String selCeiName) {
		this.selCeiName = selCeiName;
	}

	/**
	 * @return the selCeiNameList
	 */
	public List<SelectItem> getSelCeiNameList() {
		return selCeiNameList;
	}

	/**
	 * @param selCeiNameList the selCeiNameList to set
	 */
	public void setSelCeiNameList(List<SelectItem> selCeiNameList) {
		this.selCeiNameList = selCeiNameList;
	}

	/**
	 * @return the displayFlag
	 */
	public boolean isDisplayFlag() {
		return displayFlag;
	}

	/**
	 * @param displayFlag the displayFlag to set
	 */
	public void setDisplayFlag(boolean displayFlag) {
		this.displayFlag = displayFlag;
	}

	/**
	 * @return the selMliNameList
	 */
	public List<SelectItem> getSelMliNameList() {
		return selMliNameList;
	}

	/**
	 * @param selMliNameList the selMliNameList to set
	 */
	public void setSelMliNameList(List<SelectItem> selMliNameList) {
		this.selMliNameList = selMliNameList;
	}

	/**
	 * @return the selMliName
	 */
	public String getSelMliName() {
		return selMliName;
	}

	/**
	 * @param selMliName the selMliName to set
	 */
	public void setSelMliName(String selMliName) {
		this.selMliName = selMliName;
	}

	/**
	 * @return the displayMliFlg
	 */
	public boolean isDisplayMliFlg() {
		return displayMliFlg;
	}

	/**
	 * @param displayMliFlg the displayMliFlg to set
	 */
	public void setDisplayMliFlg(boolean displayMliFlg) {
		this.displayMliFlg = displayMliFlg;
	}

	/**
	 * @return the fmiBenefits
	 */
	public String getFmiBenefits() {
		return fmiBenefits;
	}

	/**
	 * @param fmiBenefits the fmiBenefits to set
	 */
	public void setFmiBenefits(String fmiBenefits) {
		this.fmiBenefits = fmiBenefits;
	}



	
}