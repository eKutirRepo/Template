/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMMktModelRptDaoIfc.java
 * @Creation date: 12-June-2017
 * @version 1.0
 * @author : Tech Mahindra (PWi Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMMktModelRptData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMMktModelRptDaoIfc {
	
	/**
	 * @param selProduct
	 * @param prodManagementFlag
	 * @param preliminaryFlag
	 * @return
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getModels(String selProduct, boolean prodManagementFlag, boolean preliminaryFlag) throws PLMCommonException;
	
	/**
	 * @param selProduct
	 * @param selModel
	 * @param prodManagementFlag
	 * @param preliminaryFlag
	 * @return
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getConfigOptions(String selProduct, String selModel, boolean prodManagementFlag, boolean preliminaryFlag) throws PLMCommonException;
	
	/**
	 * @param selProduct
	 * @param selModel
	 * @param selconfigOptions
	 * @param prodManagementFlag
	 * @param preliminaryFlag
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMMktModelRptData> getRequirementsList(String selProduct, String selModel, List<String> selconfigOptions, 
			boolean prodManagementFlag, boolean preliminaryFlag) throws PLMCommonException;
	
	/**
	 * @param selProduct
	 * @param prodManagementFlag
	 * @param preliminaryFlag
	 * @return
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getProductLines(String selProduct, boolean prodManagementFlag, boolean preliminaryFlag) throws PLMCommonException;
	
	/**
	 * @param selProduct
	 * @param selProductLine
	 * @param prodManagementFlag
	 * @param preliminaryFlag
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMMktModelRptData> getModelsAndHwPrdts(String selProduct, List<String> selProductLines, boolean prodManagementFlag, 
			boolean preliminaryFlag) throws PLMCommonException;
}