package com.geinfra.geaviation.pwi.bean;

import java.util.List;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.bean.util.BeanUtil;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.service.AdminSettingsService;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

/**
 * 
 * Project : Product Lifecycle Management Date Written : May 19, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : ApplicationParametersBean - Application-scoped bean that
 * provides JSF pages with read access to the application parameters stored in
 * the database.
 * 
 * Revision Log May 19, 2010 | v1.0.
 * --------------------------------------------------------------
 */

public class ApplicationParametersBean extends BaseBean {
	// Dependency-injected service
	private AdminSettingsService adminSettingsService;

	private String linkSelectedFrAdmin = "";

	private String selectedTab;

	public void setAdminSettingsService(
			AdminSettingsService adminSettingsService) {
		this.adminSettingsService = adminSettingsService;
	}

	public boolean isBatchDisabled() throws PWiException {
		return adminSettingsService.isBatchDisabled();
	}

	public String getHeaderText() throws PWiException {
		return adminSettingsService.getHeaderText();
	}

	public String getFooterText() throws PWiException {
		return adminSettingsService.getFooterText();
	}

	public String getHelpMsgText() throws PWiException {
		return adminSettingsService.getHelpMsgText();
	}

	public String getBatchHeaderText() throws PWiException {
		return adminSettingsService.getBatchHeaderText();
	}

	public String getQuickIntelligenceHeaderText() throws PWiException {
		return adminSettingsService.getQuickIntelligenceHeaderText();
	}

	public boolean isAdmin() throws PWiException {
		return UserInfoPortalUtil.getInstance().isAdmin();
	}

	public boolean isPwiUser() throws PWiException {
		return UserInfoPortalUtil.getInstance().isPwiUser();
	}

	public boolean isPgPLMUser() throws PWiException {
		return UserInfoPortalUtil.getInstance().isPgPLMUser();
	}

	public String getUserName() throws PWiException {
		return UserInfoPortalUtil.getInstance().getUserName();
	}

	public String getUserSSO() throws PWiException {
		return UserInfoPortalUtil.getInstance().getUserSSO();
	}

	public String getUserFirstName() throws PWiException {
		return UserInfoPortalUtil.getInstance().getUserFirstName();
	}

	public String getUserLastName() throws PWiException {
		return UserInfoPortalUtil.getInstance().getUserLastName();
	}

	public String getUserEmail() throws PWiException {
		return UserInfoPortalUtil.getInstance().getUserEmail();
	}

	public List<SelectItem> getRoleList() throws PWiException {
		return UserInfoPortalUtil.getInstance().getRoleList();
	}

	public boolean isPowerUser() throws PWiException {
		return UserInfoPortalUtil.getInstance().isPowerUser();
	}

	public boolean isPgPLMAdminUser() throws PWiException {
		return UserInfoPortalUtil.getInstance().isPGPLMAdminUser();

	}

	public boolean isDgtFMIUser() throws PWiException {
		return UserInfoPortalUtil.getInstance().isDGTFMIUser();
	}

	public boolean isDgtAdminUser() throws PWiException {
		return UserInfoPortalUtil.getInstance().isDGTAdminUser();
	}

	public boolean isPartCostUser() throws PWiException {
		return UserInfoPortalUtil.getInstance().isPartCostUser();
	}

	public String getLinkSelectedFrAdmin() {
		if (linkSelectedFrAdmin.equals("")) {
			return "Queries";
		} else {
			return linkSelectedFrAdmin;
		}

	}

	public void setLinkSelectedFrAdmin(String linkSelectedFrAdmin) {
		this.linkSelectedFrAdmin = linkSelectedFrAdmin;
	}

	public String loadAdminTab() throws PLMCommonException {

		String selectedTab1 = this.selectedTab;
		this.linkSelectedFrAdmin = selectedTab1;
		if (selectedTab1.equals("Queries")) {
			return PWiConstants.NAV_ADMIN_QUERY_LIST;
		} else if (selectedTab1.equals("Groups")) {
			return PWiConstants.NAV_ADMIN_GROUP_LIST;
		} else if (selectedTab1.equals("Object Types")) {
			return PWiConstants.NAV_ADMIN_OBJ_TYP_LIST;
		} else if (selectedTab1.equals("QI Settings")) {
			return PWiConstants.NAV_ADMIN_QI_SETTINGS;
		} else if (selectedTab1.equals("Settings")) {
			return PWiConstants.NAV_ADMIN_SETTINGS;
		} else if (selectedTab1.equals("Logging")) {
			return PWiConstants.NAV_ADMIN_LOG_CONFIG;
		} else if (selectedTab1.equals("Roles")) {
			return PWiConstants.NAV_ADMIN_ROLE_LIST;
		} else if (selectedTab1.equals("Users")) {
			BeanUtil.getInstance().getAdminUserListBean().setRoleList();
			return PWiConstants.NAV_ADMIN_USER_LIST;
		} else if (selectedTab1.equals("Canned Reports-Home Links")) {
			return PWiConstants.NAV_ADMIN_CAN_RPT_LINKS;
		} else {
			BeanUtil.getInstance().getSysLogMB().loadSysLogPage();
			return PWiConstants.NAV_ADMIN_SYS_LOG;
		}
	}

	public String getSelectedTab() {
		return selectedTab;
	}

	public void setSelectedTab(String selectedTab1) {
		this.selectedTab = selectedTab1;
	}
	
	public boolean isPWiDQBUser() throws PWiException {
		return UserInfoPortalUtil.getInstance().isPWiDQBUser();
	}
	
	public boolean isSysteOptionMap() throws PWiException {
		return UserInfoPortalUtil.getInstance().isSysteOptionMap();
	}
}
