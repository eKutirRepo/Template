/*
//  @ Project : PWi
//  @ File Name : PWiUserCustomQueryVO.java
//  @ Date : 5/14/2010
//  @ Author : nisverma
 */

package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.geinfra.geaviation.pwi.json.JsonBuilder;
import com.geinfra.geaviation.pwi.json.Jsonable;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Represents a query record from the database, but *without* XML
 * fields
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiQueryNoXmlVO implements Serializable, Jsonable {
	private static final long serialVersionUID = 4964743784318826215L;

	private Integer qrySeqId;
	private String qryNm;
	private String qryDesc;
	private String qryKywrdTxt;
	private boolean exportControlled;
	private boolean geOnly;
	private boolean popular;
	private boolean active;
	private List<PWiQueryGroupJoinVO> groups = new ArrayList<PWiQueryGroupJoinVO>();
	private List<PWiObjectTypeVO> objectTypes = new ArrayList<PWiObjectTypeVO>();

	public PWiQueryNoXmlVO() {
	}

	public Integer getQrySeqId() {
		return qrySeqId;
	}

	public void setQrySeqId(Integer qrySeqId) {
		this.qrySeqId = qrySeqId;
	}

	public String getQryNm() {
		return qryNm;
	}

	public void setQryNm(String qryNm) {
		this.qryNm = qryNm;
	}

	public String getQryDesc() {
		return qryDesc;
	}

	public void setQryDesc(String qryDesc) {
		this.qryDesc = qryDesc;
	}

	public String getQryKywrdTxt() {
		return qryKywrdTxt;
	}

	public void setQryKywrdTxt(String qryKywrdTxt) {
		this.qryKywrdTxt = qryKywrdTxt;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (qrySeqId != null ? qrySeqId.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object instanceof PWiQueryNoXmlVO) {
			PWiQueryNoXmlVO other = (PWiQueryNoXmlVO) object;
			if (this.qrySeqId != null && other.qrySeqId != null) {
				return this.qrySeqId.equals(other.qrySeqId);
			}
		}
		return false;
	}

	@Override
	public String toString() {
		return (null != this.getQryNm() ? this.getQryNm() : "");
	}

	public boolean isExportControlled() {
		return exportControlled;
	}

	public void setExportControlled(boolean exportControlled) {
		this.exportControlled = exportControlled;
	}

	public boolean isGeOnly() {
		return geOnly;
	}

	public void setGeOnly(boolean geOnly) {
		this.geOnly = geOnly;
	}

	public void setPopular(boolean popular) {
		this.popular = popular;
	}

	public boolean isPopular() {
		return popular;
	}
	
	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isActive() {
		return active;
	}

	public List<PWiQueryGroupJoinVO> getGroups() {
		return groups;
	}

	public List<PWiObjectTypeVO> getObjectTypes() {
		return objectTypes;
	}

	public String toJson() {
		JsonBuilder builder = new JsonBuilder();
		builder.startObject();
		builder.addStringProperty("id", qrySeqId);
		builder.addStringProperty("name", qryNm);
		builder.addStringProperty("desc", qryDesc);
		builder.addBooleanProperty("exportControlled", exportControlled);
		builder.addBooleanProperty("geOnly", geOnly);
		builder.addBooleanProperty("popular", popular);
		builder.addBooleanProperty("active", active);
		if (groups != null) {
			builder.startArrayProperty("groupIds");
			for (PWiQueryGroupJoinVO group : groups) {
				builder.addStringElement(group.getGroupId());
			}
			builder.endArray();
		}
		builder.endObject();
		return builder.toString();
	}
}
