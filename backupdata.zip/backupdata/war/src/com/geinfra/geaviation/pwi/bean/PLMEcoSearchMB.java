/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEcoSearchMB.java
 * @Creation date: 18-June-2010
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.bean;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.data.PLMEcoMetricsData;
import com.geinfra.geaviation.pwi.data.PLMEcoSearchData;
import com.geinfra.geaviation.pwi.service.PLMkpiReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

/**
 * PLMIssuesReportMB is the managed bean class .
 */
public class PLMEcoSearchMB {

	private static final Logger LOG = Logger.getLogger(PLMEcoSearchMB.class);
	/**
	 * Holds the PLMIssuesReportService
	 */
	private PLMkpiReportServiceIfc plmKpiReportService = null;

	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB=null;

	/**
	 * Holds the searchResultList
	 */
	private List<PLMEcoSearchData> searchResultList;
	/**
	 * Holds the searchResultList
	 */
	private List<PLMEcoSearchData> searchDetailsResultList;
	/**
	 * Holds the searchDetails
	 */
	private String page;
	/**
	 * Holds the searchDetails
	 */
	private PLMEcoSearchData searchDetails = new PLMEcoSearchData();
	/**
	 * Holds the count
	 */
	private int count;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;
	/**
	 * Holds the recordCounts
	 */
	private int detailRecordCounts = PLMConstants.N_100;
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the totalRecCount
	 */
	private int totalDetailRecCount;
	/**
	 * Holds the totalRecCountMsg
	 */
	private String totalRecCountMsg;
	/**
	 * Holds the totalDetailRecCountMsg
	 */
	private String totalDetailRecCountMsg;
	/**
	 * Holds the fieldName
	 */
	private String fieldName;
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the Logger object to the messages.
	 */
	private String fwdFlag;
	/**
	 * Holds the catListData
	 */
	private List<SelectItem> catListData;
	/**
	 * Holds the sevListData
	 */
	private List<SelectItem> sevListData;
	/**
	 * Holds the stateListData
	 */
	private List<SelectItem> stateListData;
	/**
	 * Holds the ecosessionvalue
	 */
	private String ecosessionvalue;
	/**
	 * Holds the selectedecos
	 */
	private String selectedecos = "";
	
	private String reportName;
	
	/**
	 * Holds the allFlag
	 */
	private boolean allFlag;
	/**
	 * Holds the devFlag
	 */
	private boolean devFlag;
	/**
	 * Holds the prodFlag
	 */
	private boolean prodFlag;
	
	private List<SelectItem> rdoListData;

	/**
	 * This method is used for Get Search Eco Data
	 * 
	 * @return String
	 */
	public String getEcoSearchData() {
		fwdFlag = "";
		alertMessage ="";
		totalRecCount = 0;
		allFlag=false;
		devFlag=false;			
		prodFlag=false;
		Date frmEco_orig_date = searchDetails.getFrmEco_orig_date();
		Date toEco_orig_date = searchDetails.getToEco_orig_date();
		
		Date frmEcoReleaseDT = searchDetails.getFrmEcoReleaseDT();
		Date toEcoReleaseDT = searchDetails.getToEcoReleaseDT();

		if (PLMUtils.isEmpty(searchDetails.getEcoName())
				&& PLMUtils.isEmpty(searchDetails.getEcoOwner())
				&& PLMUtils.isEmpty(searchDetails.getEcoOriginator())
				&& PLMUtils.isEmptyList(searchDetails.getEcoCategList())
				&& PLMUtils.isEmptyList(searchDetails.getEcoSevList())
				&& PLMUtils.isEmptyList(searchDetails.getEcoStateList())
				&& PLMUtils.isEmptyList(searchDetails.getEcoRdoList())
				&& PLMUtils.isEmpty(searchDetails.getEcoCycle())
				&& PLMUtils.isEmptyDate(frmEco_orig_date)
				&& PLMUtils.isEmptyDate(toEco_orig_date)
				&& PLMUtils.isEmptyDate(frmEcoReleaseDT)
				&& PLMUtils.isEmptyDate(toEcoReleaseDT)) {
			fieldName = PLMConstants.UI_ISSUES_SEARCH;
			alertMessage = PLMConstants.ANY_SRCH_CRIT;
		} else {
			String ownerWithOutAsterisk = null;
			String originatorWithOutAsterisk = null;
			if (!PLMUtils.isEmpty(searchDetails.getEcoOwner())) {
				ownerWithOutAsterisk = PLMUtils.removeAsteriskAndSpaceFromSSOFields(searchDetails.getEcoOwner());
			}
			if (!PLMUtils.isEmpty(searchDetails.getEcoOriginator())) {
				originatorWithOutAsterisk = PLMUtils.removeAsteriskAndSpaceFromSSOFields(searchDetails.getEcoOriginator());
			}
			if (!PLMUtils.checkForSpecialChars(searchDetails.getEcoName())) {
				alertMessage = alertMessage + PLMConstants.EcoName_ValMsg;
				fwdFlag = "eco";
			}
			if (!PLMUtils.checkForSpecialChars(searchDetails.getEcoOwner())) {
				alertMessage = alertMessage + PLMConstants.EcoOwner_ValMsg;
				fwdFlag = "eco";
			} else if (PLMUtils.isInteger(ownerWithOutAsterisk)) {
				if (ownerWithOutAsterisk.length() != 9)
					alertMessage = alertMessage
							+ PLMConstants.EcoOwnerdigt_ValMsg;
				fwdFlag = "eco";
			}
			if (!PLMUtils
					.checkForSpecialChars(searchDetails.getEcoOriginator())) {
				alertMessage = alertMessage + PLMConstants.EcoOriginator_ValMsg;
				fwdFlag = "eco";
			} else if (PLMUtils.isInteger(originatorWithOutAsterisk)) {
				if (originatorWithOutAsterisk.length() != 9)
					alertMessage = alertMessage
							+ PLMConstants.EcoOrigindigt_ValMsg;
				fwdFlag = "eco";
			}
			if (!PLMUtils.checkForSpecialCharsForInteger(searchDetails
					.getEcoCycle())
					&& !PLMUtils.isEmpty(searchDetails.getEcoCycle())) {
				alertMessage = alertMessage + PLMConstants.EcoCycle_ValMsg;
				fwdFlag = "eco";
			}
			if (!PLMUtils.checkForSpecialChars(searchDetails.getRdo())) {
				alertMessage = alertMessage + PLMConstants.EcoRdo_ValMsg;
				fwdFlag = "eco";
			}
			if (PLMUtils.checkForNullOfTwoDates(frmEco_orig_date, toEco_orig_date)) {
				alertMessage = alertMessage + PLMConstants.Dates_NullCheck_Msg;
			} else if (PLMUtils.checkForFromAndToDate(frmEco_orig_date, toEco_orig_date)) {
				alertMessage = alertMessage + PLMConstants.Date_ValMsg;
				fwdFlag = "eco";
			}
			
			if (PLMUtils.checkForNullOfTwoDates(frmEcoReleaseDT, toEcoReleaseDT)) {
				alertMessage = alertMessage + PLMConstants.Dates_NullCheck_Msg;
			} else if (PLMUtils.checkForFromAndToDate(frmEcoReleaseDT, toEcoReleaseDT)) {
				alertMessage = alertMessage + PLMConstants.Date_ValMsg;
				fwdFlag = "eco";
			}
		}
		if (PLMUtils.isEmpty(alertMessage)) {
			try {
				searchResultList = plmKpiReportService
						.getEcoSearchData(searchDetails);
				if (searchResultList != null) {
					if (searchDetails.getRdecoProdStatus() != null
							&& !(searchDetails.getRdecoProdStatus().equals(""))
							&& searchDetails.getRdecoProdStatus().equalsIgnoreCase("All")) 
					{
						allFlag=true;
					}else if (searchDetails.getRdecoProdStatus() != null
							&& !(searchDetails.getRdecoProdStatus().equals(""))
							&& searchDetails.getRdecoProdStatus().equalsIgnoreCase("Development"))
					{
						devFlag=true;
						
					}else if (searchDetails.getRdecoProdStatus() != null
							&& !(searchDetails.getRdecoProdStatus().equals(""))
							&& searchDetails.getRdecoProdStatus().equalsIgnoreCase("Production")) 
					{
						prodFlag=true;
					}
					totalRecCount = searchResultList.size();
					reportName = "ecoHdrReport";
				} else {
					totalRecCount = 0;
				}
				totalRecCountMsg = "Total Results Count : " + totalRecCount;
				LOG.info("totalRecCount::::::::::::::::::" + totalRecCount);
				if (totalRecCount == 0) {
					fwdFlag = "invalidEco";
				} else {
					recordCounts = PLMConstants.N_100;
					fwdFlag = "ecoresult";
				}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getEcoSearchData: ", exception);
				fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"eco","ECO Search");
			} 
		}
		page = "ecosearch";
		return fwdFlag;
	}
	/**
	 * This method is used for geteconames
	 * 
	 * @return String
	 */
	public String geteconames() {
		try {
			searchDetailsResultList = plmKpiReportService
					.getecoNameBySelection(ecosessionvalue);
			if (searchDetailsResultList != null) {
				totalDetailRecCount = searchDetailsResultList.size();
				reportName = "ecoDetailReport";
			} else {
				totalDetailRecCount = 0;
			}
			totalDetailRecCountMsg = "Total Results Count : "
					+ totalDetailRecCount;
			LOG.info("totalRecCount::::::::::::::::::" + totalDetailRecCount);
			if (totalRecCount == 0) {
				fwdFlag = "invalidEco";
			} else {
				detailRecordCounts = PLMConstants.N_100;
				fwdFlag = "ecodetails";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@geteconames: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecoresult","ECO Search");
		} 
		page = "ecosearch";
		return fwdFlag;
	}
	/**
	 * This method is used for getEcoCategoryDetailReport
	 * 
	 * @param econameslist,ecocategorydata
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getEcoCategoryDetailReport(List<String> econameslist,PLMEcoMetricsData ecocategorydata) throws PLMCommonException {
		try {
			searchDetailsResultList = plmKpiReportService
					.getEcoCategoryDetailReport(econameslist,ecocategorydata);
			if (searchDetailsResultList != null) {
				totalDetailRecCount = searchDetailsResultList.size();
				reportName = "ecoDetailReport";
			} else {
				totalDetailRecCount = 0;
			}
			totalDetailRecCountMsg = "Total Results Count : "
					+ totalDetailRecCount;
			LOG.info("totalRecCount::::::::::::::::::" + totalDetailRecCount);
			if (totalDetailRecCount == 0) {
				fwdFlag = "invalidEco";
			} else {
				detailRecordCounts = PLMConstants.N_100;
				fwdFlag = "ecodetails";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getEcoDetailReport: ", exception);
			throw exception;
		} 
		return fwdFlag;
	}
	/**
	 * This method is used for getEcoVolumeDetailReport
	 * 
	 * @param econameslist,ecovolumedata
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getEcoVolumeDetailReport(List<String> econameslist,PLMEcoMetricsData ecovolumedata) throws PLMCommonException {
		try {
			searchDetailsResultList = plmKpiReportService
					.getEcoVolumeDetailReport(econameslist,ecovolumedata);
			if (searchDetailsResultList != null) {
				totalDetailRecCount = searchDetailsResultList.size();
				reportName = "ecoDetailReport";
			} else {
				totalDetailRecCount = 0;
			}
			totalDetailRecCountMsg = "Total Results Count : "
					+ totalDetailRecCount;
			LOG.info("totalRecCount::::::::::::::::::" + totalDetailRecCount);
			if (totalDetailRecCount == 0) {
				fwdFlag = "invalidEco";
			} else {
				detailRecordCounts = PLMConstants.N_100;
				fwdFlag = "ecodetails";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getEcoDetailReport: ", exception);
			throw exception;
		} 
		return fwdFlag;
	}

	/**
	 * This method is used for getecoNameBySelection
	 * 
	 * @return String
	 */
	public String getecoNameBySelection() {
		if (selectedecos.equalsIgnoreCase("null")) {
			fwdFlag = "";
		} else {
			try {
				searchDetailsResultList = plmKpiReportService
						.getecoNameBySelection(selectedecos);
				if (searchDetailsResultList != null) {
					totalDetailRecCount = searchDetailsResultList.size();
					reportName = "ecoDetailReport";
				} else {
					totalDetailRecCount = 0;
				}
				totalDetailRecCountMsg = "Total Results Detail Count : "
						+ totalDetailRecCount;
				LOG.info("totalDetailRecCount::::::::::::::::::"
						+ totalDetailRecCount);
				if (totalDetailRecCount == 0) {
					fwdFlag = "invalidEco";
				} else {
					detailRecordCounts = PLMConstants.N_100;
					fwdFlag = "ecodetails";
				}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getecoNameBySelection: ", exception);
				fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"ecoresult","ECO Search");
			} 
		}
		page = "ecosearch";
		return fwdFlag;
	}
	/**
	 * This method is used for getDropDownvalues
	 * 
	 * @return String
	 */
	public String getDropDownvalues() {
		LOG.info("getDropDownvalues() Method");
		fwdFlag = "";
		alertMessage = "";
		try {
			commonMB.insertCannedRptRecordHitInfo("ECO Search");
			Map<String, List<SelectItem>> dropdownLstMap = plmKpiReportService.getDropDownvalues();
			catListData = (List<SelectItem>) dropdownLstMap.get("category");
			sevListData = (List<SelectItem>) dropdownLstMap.get("severity");
			stateListData = (List<SelectItem>) dropdownLstMap.get("state");
			rdoListData = (List<SelectItem>) dropdownLstMap.get("rdo");
			resetEcoSearchData();
			searchDetails.setFastTrackEco("All");//Added for Radio Button
			searchDetails.setRdecoProdStatus("All");//Set Default Vale All for the Prod Status radio btn
			allFlag=false;
			devFlag=false;			
			prodFlag=false;
			fwdFlag = "eco";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getDropDownvalues: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","ECO Search");
		} 
		
		/*try {
			commonMB.getPLMDateStamp(PLMConstants.ECO_TABLE);
		 } catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPLMDateStamp: ", exception);
		}*/ 
		
		return fwdFlag;
	}
	/**
	 * This method is used for resetEcoSearchData
	 * 
	 * @return String
	 */
	public String resetEcoSearchData() {
		fwdFlag = "eco";
		searchDetails.setEcoName("");
		searchDetails.setEcoOwner("");
		searchDetails.setEcoOriginator("");
		searchDetails.setEcoSevList(null);
		searchDetails.setEcoCategList(null);
		searchDetails.setEcoStateList(null);
		searchDetails.setEcoRdoList(null);
		searchDetails.setRdo("");
		searchDetails.setEcoCycle("");
		searchDetails.setFrmEco_orig_date(null);
		searchDetails.setToEco_orig_date(null);
		searchDetails.setFrmEcoReleaseDT(null);
		searchDetails.setToEcoReleaseDT(null);
		searchDetails.setFastTrackEco("All");//Added for Radio Button
		searchDetails.setRdecoProdStatus("All");//Set Default Vale All for the Prod Status radio btn
		allFlag=false;
		devFlag=false;			
		prodFlag=false;
		return fwdFlag;
	}

	/**
	 * @param value
	 *            .
	 * @return String
	 */
	public String getTrimValue(String value) {
		String retStr = null;
		if (!PLMUtils.isEmpty(value)) {
			retStr = value.trim();
		}
		return retStr;
	}
	/**
	 * @param recordCounts
	 *            the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		// LOG.info("::::::::::::::::::" + recordCounts);
		PLMUtils.getServletSession(true).setAttribute("RecDropDown",
				recordCounts);
		this.recordCounts = recordCounts;
	}
	
	/**
	 * This method is used for Generating ECO Report in Excel
	 * 
	 * @throws PLMCommonException
	 */
	public void downloadEcoExcel() throws PLMCommonException {
		
		String reportNm = reportName;
		String fileName;
		LOG.info("Inside downloadEcoExcel reportName>>> " + reportNm);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		if (reportNm.equals("ecoHdrReport")) {
			fileName = "ECO Report";
			PLMXlsxRptColumn[] critcolumns =
					new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("ecoName", "ECO Name", FormatType.TEXT),
							new PLMXlsxRptColumn("ecoOwner", "ECO Owner", FormatType.TEXT),
							new PLMXlsxRptColumn("ecoOriginator", "ECO Originator", FormatType.TEXT),
							new PLMXlsxRptColumn("ecoSevExcel", "ECO Severity", FormatType.TEXT),
							new PLMXlsxRptColumn("ecoStateExcel", "ECO State", FormatType.TEXT),
							new PLMXlsxRptColumn("ecoCategExcel", "ECO Category", FormatType.TEXT),
							new PLMXlsxRptColumn("ecoCycle", "ECO Cycle", FormatType.TEXT), new PLMXlsxRptColumn("rdo", "RDO", FormatType.TEXT),
							new PLMXlsxRptColumn("fastTrackEco", "ECO Fast Track", FormatType.TEXT),
							new PLMXlsxRptColumn("frmEco_orig_date_excel", "ECO Origination Start Date From", FormatType.DATEFR),
							new PLMXlsxRptColumn("toEco_orig_date_excel", "ECO Origination Start Date To", FormatType.DATEFR),
							new PLMXlsxRptColumn("frmEcoReleaseDTExcel", "ECO Release Start Date From", FormatType.DATEFR),
							new PLMXlsxRptColumn("toEcoReleaseDTExcel", "ECO Release Start Date To", FormatType.DATEFR),
							new PLMXlsxRptColumn("rdecoProdStatus", "ECO Production Status", FormatType.TEXT)							
			};
			 if(isAllFlag() && !isDevFlag() && !isProdFlag()){
			PLMXlsxRptColumn[] reportColumns =
							new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("ecoName", "ECO Name", FormatType.TEXT),
									new PLMXlsxRptColumn("ecoRev", "ECO REV", FormatType.TEXT),
									new PLMXlsxRptColumn("ecoOwner", "ECO Owner SSO", FormatType.TEXT),
									new PLMXlsxRptColumn("ecoOwnerName", "ECO Owner Name", FormatType.TEXT, null, null, 25),
									new PLMXlsxRptColumn("ecoOriginator", "ECO Orig. SSO", FormatType.TEXT),
									new PLMXlsxRptColumn("ecoOriginatorName", "ECO Orig. Name", FormatType.TEXT, null, null, 25),
									new PLMXlsxRptColumn("ecoDesc", "ECO Description", FormatType.TEXT, null, null, 35),
									new PLMXlsxRptColumn("rdo", "RDO", FormatType.TEXT, null, null, 20),
									new PLMXlsxRptColumn("ecoState", "State", FormatType.TEXT, null, null, 20),
									new PLMXlsxRptColumn("fastTrackEco", "ECO Fast Track", FormatType.TEXT, null, null, 9),
									new PLMXlsxRptColumn("ecoSev", "Severity", FormatType.TEXT, null, null, 9),
									new PLMXlsxRptColumn("ecoDesginEngr", "Design Engr. SSO", FormatType.TEXT),
									new PLMXlsxRptColumn("ecoDesignEngrName", "Design Engr. Name", FormatType.TEXT, null, null, 25),
									new PLMXlsxRptColumn("ecoMfgEngr", "MFG Engr. SSO", FormatType.TEXT),
									new PLMXlsxRptColumn("ecoMfgEngrName", "MFG Engr. Name", FormatType.TEXT, null, null, 25),
									new PLMXlsxRptColumn("eco_orig_date", "ECO Orig Date", FormatType.DATEFR, null, null, 10),
									new PLMXlsxRptColumn("task_count", "Task Count", FormatType.TEXT, null, null, 8),
									new PLMXlsxRptColumn("route_count", "Route Count", FormatType.TEXT, null, null, 8),
									//new PLMXlsxRptColumn("dwg_count", "Drawing Count", FormatType.TEXT, null, null, 9),
									
									new PLMXlsxRptColumn("xlecoCategChng", "ECO Category Change", FormatType.TEXT),
									new PLMXlsxRptColumn("xlecoRlseDt", "ECO Release Date", FormatType.DATEFR, null, null, 10),
									new PLMXlsxRptColumn("xldpoCount", "DPO Count", FormatType.INTEGER, null, null, 8),
									new PLMXlsxRptColumn("xlugModelCount", "UG Model Count", FormatType.INTEGER, null, null, 8),
									new PLMXlsxRptColumn("xlprodParts", "Production Parts", FormatType.INTEGER, null, null, 13),
									new PLMXlsxRptColumn("xldevParts", "Development Parts", FormatType.INTEGER, null, null, 13),
									new PLMXlsxRptColumn("mbpdModelCnt", "MBPD Models", FormatType.INTEGER, null, null, 13),
									new PLMXlsxRptColumn("mbpdPartCnt", "MBPD Parts", FormatType.INTEGER, null, null, 13)
			         };		
			 excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, searchDetails);
							
			 }else if(!isAllFlag() && isDevFlag() && !isProdFlag()){
				PLMXlsxRptColumn[] reportColumns =
						new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("ecoName", "ECO Name", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoRev", "ECO REV", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoOwner", "ECO Owner SSO", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoOwnerName", "ECO Owner Name", FormatType.TEXT, null, null, 25),
								new PLMXlsxRptColumn("ecoOriginator", "ECO Orig. SSO", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoOriginatorName", "ECO Orig. Name", FormatType.TEXT, null, null, 25),
								new PLMXlsxRptColumn("ecoDesc", "ECO Description", FormatType.TEXT, null, null, 35),
								new PLMXlsxRptColumn("rdo", "RDO", FormatType.TEXT, null, null, 20),
								new PLMXlsxRptColumn("ecoState", "State", FormatType.TEXT, null, null, 20),
								new PLMXlsxRptColumn("fastTrackEco", "ECO Fast Track", FormatType.TEXT, null, null, 9),
								new PLMXlsxRptColumn("ecoSev", "Severity", FormatType.TEXT, null, null, 9),
								new PLMXlsxRptColumn("ecoDesginEngr", "Design Engr. SSO", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoDesignEngrName", "Design Engr. Name", FormatType.TEXT, null, null, 25),
								new PLMXlsxRptColumn("ecoMfgEngr", "MFG Engr. SSO", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoMfgEngrName", "MFG Engr. Name", FormatType.TEXT, null, null, 25),
								new PLMXlsxRptColumn("eco_orig_date", "ECO Orig Date", FormatType.DATEFR, null, null, 10),
								new PLMXlsxRptColumn("task_count", "Task Count", FormatType.TEXT, null, null, 8),
								new PLMXlsxRptColumn("route_count", "Route Count", FormatType.TEXT, null, null, 8),
								//new PLMXlsxRptColumn("dwg_count", "Drawing Count", FormatType.TEXT, null, null, 9),
								
								new PLMXlsxRptColumn("xlecoCategChng", "ECO Category Change", FormatType.TEXT),
								new PLMXlsxRptColumn("xlecoRlseDt", "ECO Release Date", FormatType.DATEFR, null, null, 10),
								new PLMXlsxRptColumn("xldpoCount", "DPO Count", FormatType.INTEGER, null, null, 8),
								new PLMXlsxRptColumn("xlugModelCount", "UG Model Count", FormatType.INTEGER, null, null, 8),
								new PLMXlsxRptColumn("xldevParts", "Development Parts", FormatType.INTEGER, null, null, 13),
								new PLMXlsxRptColumn("mbpdModelCnt", "MBPD Models", FormatType.INTEGER, null, null, 13),
								new PLMXlsxRptColumn("mbpdPartCnt", "MBPD Parts", FormatType.INTEGER, null, null, 13)
								
				};
				excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, searchDetails);
				
			}else if(!isAllFlag() && !isDevFlag() && isProdFlag()){
				PLMXlsxRptColumn[] reportColumns =
						new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("ecoName", "ECO Name", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoRev", "ECO REV", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoOwner", "ECO Owner SSO", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoOwnerName", "ECO Owner Name", FormatType.TEXT, null, null, 25),
								new PLMXlsxRptColumn("ecoOriginator", "ECO Orig. SSO", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoOriginatorName", "ECO Orig. Name", FormatType.TEXT, null, null, 25),
								new PLMXlsxRptColumn("ecoDesc", "ECO Description", FormatType.TEXT, null, null, 35),
								new PLMXlsxRptColumn("rdo", "RDO", FormatType.TEXT, null, null, 20),
								new PLMXlsxRptColumn("ecoState", "State", FormatType.TEXT, null, null, 20),
								new PLMXlsxRptColumn("fastTrackEco", "ECO Fast Track", FormatType.TEXT, null, null, 9),
								new PLMXlsxRptColumn("ecoSev", "Severity", FormatType.TEXT, null, null, 9),
								new PLMXlsxRptColumn("ecoDesginEngr", "Design Engr. SSO", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoDesignEngrName", "Design Engr. Name", FormatType.TEXT, null, null, 25),
								new PLMXlsxRptColumn("ecoMfgEngr", "MFG Engr. SSO", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoMfgEngrName", "MFG Engr. Name", FormatType.TEXT, null, null, 25),
								new PLMXlsxRptColumn("eco_orig_date", "ECO Orig Date", FormatType.DATEFR, null, null, 10),
								new PLMXlsxRptColumn("task_count", "Task Count", FormatType.TEXT, null, null, 8),
								new PLMXlsxRptColumn("route_count", "Route Count", FormatType.TEXT, null, null, 8),
								//new PLMXlsxRptColumn("dwg_count", "Drawing Count", FormatType.TEXT, null, null, 9),
								
								new PLMXlsxRptColumn("xlecoCategChng", "ECO Category Change", FormatType.TEXT),
								new PLMXlsxRptColumn("xlecoRlseDt", "ECO Release Date", FormatType.DATEFR, null, null, 10),
								new PLMXlsxRptColumn("xldpoCount", "DPO Count", FormatType.INTEGER, null, null, 8),
								new PLMXlsxRptColumn("xlugModelCount", "UG Model Count", FormatType.INTEGER, null, null, 8),
								new PLMXlsxRptColumn("xlprodParts", "Production Parts", FormatType.INTEGER, null, null, 13),
								new PLMXlsxRptColumn("mbpdModelCnt", "MBPD Models", FormatType.INTEGER, null, null, 13),
								new PLMXlsxRptColumn("mbpdPartCnt", "MBPD Parts", FormatType.INTEGER, null, null, 13)
					};
			
			excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, searchDetails);
			}
		
		} else {
			fileName = "ECO Details";
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
							new PLMXlsxRptColumn("ecoName", "ECO Name", FormatType.TEXT),
		                    new PLMXlsxRptColumn("ecoRev", "ECO REV", FormatType.TEXT),
		                    new PLMXlsxRptColumn("ecoOriginator", "ECO Orig. SSO", FormatType.TEXT),
		                    new PLMXlsxRptColumn("ecoOriginatorName", "ECO Orig. Name", FormatType.TEXT, null, null, 20),
		                    new PLMXlsxRptColumn("ecoOwner", "ECO Owner SSO", FormatType.TEXT),
		                    new PLMXlsxRptColumn("ecoOwnerName", "ECO Owner Name", FormatType.TEXT, null, null, 20),
		                    new PLMXlsxRptColumn("ecoDesc", "ECO Description", FormatType.TEXT, null, null, 35),
		                    new PLMXlsxRptColumn("rdo", "RDO", FormatType.TEXT, null, null, 20),
		                    new PLMXlsxRptColumn("ecoState", "State", FormatType.TEXT),
		                    new PLMXlsxRptColumn("fastTrackEco", "ECO Fast Track", FormatType.TEXT, null, null, 10),
		                    new PLMXlsxRptColumn("ecoCateg", "Category", FormatType.TEXT, null, null, 20),
		                    new PLMXlsxRptColumn("ecoSev", "Severity", FormatType.TEXT, null, null, 10),
		                    new PLMXlsxRptColumn("ecoDesginEngr", "Design Engr. SSO", FormatType.TEXT),
		                    new PLMXlsxRptColumn("ecoDesignEngrName", "Design Engr. Name", FormatType.TEXT, null, null, 20),
		                    new PLMXlsxRptColumn("ecoMfgEngr", "MFG Engr. SSO", FormatType.TEXT),
		                    new PLMXlsxRptColumn("ecoMfgEngrName", "MFG Engr. Name", FormatType.TEXT, null, null, 20),
		                    new PLMXlsxRptColumn("ecoReldateExl", "ECO Rel Date", FormatType.DATEFR, null, null, 20),
		                    new PLMXlsxRptColumn("eco_orig_date", "ECO Orig Date", FormatType.DATEFR, null, null, 15),
		                    new PLMXlsxRptColumn("eco_age_in_days", "ECO Age(In Days)", FormatType.TEXT, null, null, 10),
		                    new PLMXlsxRptColumn("routeName", "Route Name", FormatType.TEXT, null, null, 20),
		                    new PLMXlsxRptColumn("routeType", "Type", FormatType.TEXT),
		                    new PLMXlsxRptColumn("routeOwner", "Route Owner", FormatType.TEXT),
		                    new PLMXlsxRptColumn("routeLastUp", "Route Last Up", FormatType.DATEFR, null, null, 15),
		                    new PLMXlsxRptColumn("routeState", "Route State", FormatType.TEXT, null, null, 12),
		                    new PLMXlsxRptColumn("routeStatus", "Route Status", FormatType.TEXT, null, null, 12),
		                    new PLMXlsxRptColumn("taskName", "Task Name", FormatType.TEXT),
		                    new PLMXlsxRptColumn("taskCreation", "Task Creation", FormatType.DATEFR, null, null, 15),
		                    new PLMXlsxRptColumn("taskOwner", "Task Owner", FormatType.TEXT),
		                    new PLMXlsxRptColumn("taskOwnerFN", "Task Owner FN", FormatType.TEXT),
		                    new PLMXlsxRptColumn("taskOwnerLN", "Task Owner LN", FormatType.TEXT),
		                    new PLMXlsxRptColumn("taskState", "Task State", FormatType.TEXT, null, null, 10),
		                    new PLMXlsxRptColumn("approvalStat", "Approval State", FormatType.TEXT, null, null, 10),
		                    new PLMXlsxRptColumn("scheCompDate", "Scheduled Date", FormatType.DATEFR, null, null, 15),
		                    new PLMXlsxRptColumn("actCompDate", "Completion Date", FormatType.DATEFR, null, null, 15),
		                    new PLMXlsxRptColumn("dwgName", "DWG Name", FormatType.TEXT),
		                    new PLMXlsxRptColumn("dwgRev", "DWG REV", FormatType.TEXT),
		                    new PLMXlsxRptColumn("dwgOriginator", "DWG Orig. SSO", FormatType.TEXT),
		                    new PLMXlsxRptColumn("dwgOriginatorName", "DWG Orig. Name", FormatType.TEXT, null, null, 20),
		                    new PLMXlsxRptColumn("dwgCreateDate", "DWG Creation Date", FormatType.DATEFR, null, null, 15),
		                    new PLMXlsxRptColumn("dwgRelDate", "DWG Release Date", FormatType.DATEFR, null, null, 15),
		                    new PLMXlsxRptColumn("dwgCycletime", "DWG Cycle Time(In Days)", FormatType.TEXT)
		                    
								};


				PLMXlsxRptColumn[] critcolumns =
								new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("ecoName", "ECO Name", FormatType.TEXT),
										new PLMXlsxRptColumn("ecoOwner", "ECO Owner", FormatType.TEXT),
										new PLMXlsxRptColumn("ecoOriginator", "ECO Originator", FormatType.TEXT),
										new PLMXlsxRptColumn("ecoSevExcel", "ECO Severity", FormatType.TEXT),
										new PLMXlsxRptColumn("ecoStateExcel", "ECO State", FormatType.TEXT),
										new PLMXlsxRptColumn("ecoCategExcel", "ECO Category", FormatType.TEXT),
										new PLMXlsxRptColumn("ecoCycle", "ECO Cycle", FormatType.TEXT), new PLMXlsxRptColumn("rdo", "RDO", FormatType.TEXT),
										new PLMXlsxRptColumn("fastTrackEco", "ECO Fast Track", FormatType.TEXT),
										new PLMXlsxRptColumn("frmEco_orig_date_excel", "ECO Origination Start Date From", FormatType.DATEFR),
										new PLMXlsxRptColumn("toEco_orig_date_excel", "ECO Origination Start Date To", FormatType.DATEFR),
										new PLMXlsxRptColumn("frmEcoReleaseDTExcel", "ECO Release Start Date From", FormatType.DATEFR),
										new PLMXlsxRptColumn("toEcoReleaseDTExcel", "ECO Release Start Date To", FormatType.DATEFR),
										new PLMXlsxRptColumn("rdecoProdStatus", "ECO Production Status", FormatType.TEXT)	

								};

				excelUtil.export(searchDetailsResultList, reportColumns, fileName, fileName, true, critcolumns, searchDetails);
			
		}
		
	}
	
	/**
	 * This method is used for Generating ECO Report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	public void downloadEcoCsv() throws PLMCommonException {

		String reportNm = reportName;
		String fileName;
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		LOG.info("Inside downloadEcoExcel reportName>>> " + reportNm);

		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();

		if (reportNm.equals("ecoHdrReport")) {
			fileName = "ECO Report";
			//Added Prod Status Flag				
			if(isAllFlag() && !isDevFlag() && !isProdFlag()){
			PLMCsvRptColumn[] reportColumns =
							new PLMCsvRptColumn[] {new PLMCsvRptColumn("ecoName", "ECO Name", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("ecoRev", "ECO REV", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("ecoOwner", "ECO Owner SSO", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("ecoOwnerName", "ECO Owner Name", FormatTypeCsv.TEXT, null, null, 25),
									new PLMCsvRptColumn("ecoOriginator", "ECO Orig. SSO", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("ecoOriginatorName", "ECO Orig. Name", FormatTypeCsv.TEXT, null, null, 25),
									new PLMCsvRptColumn("ecoDesc", "ECO Description", FormatTypeCsv.TEXT, null, null, 35),
									new PLMCsvRptColumn("rdo", "RDO", FormatTypeCsv.TEXT, null, null, 20),
									new PLMCsvRptColumn("ecoState", "State", FormatTypeCsv.TEXT, null, null, 20),
									new PLMCsvRptColumn("fastTrackEco", "ECO Fast Track", FormatTypeCsv.TEXT, null, null, 9),
									new PLMCsvRptColumn("ecoSev", "Severity", FormatTypeCsv.TEXT, null, null, 9),
									new PLMCsvRptColumn("ecoDesginEngr", "Design Engr. SSO", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("ecoDesignEngrName", "Design Engr. Name", FormatTypeCsv.TEXT, null, null, 25),
									new PLMCsvRptColumn("ecoMfgEngr", "MFG Engr. SSO", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("ecoMfgEngrName", "MFG Engr. Name", FormatTypeCsv.TEXT, null, null, 25),
									new PLMCsvRptColumn("eco_orig_date", "ECO Orig Date", FormatTypeCsv.DATEFR, null, null, 10),
									new PLMCsvRptColumn("task_count", "Task Count", FormatTypeCsv.TEXT, null, null, 8),
									new PLMCsvRptColumn("route_count", "Route Count", FormatTypeCsv.TEXT, null, null, 8),
									//new PLMCsvRptColumn("dwg_count", "Drawing Count", FormatTypeCsv.TEXT, null, null, 8),
									new PLMCsvRptColumn("xlecoCategChng", "ECO Category Change", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("xlecoRlseDt", "ECO Release Date", FormatTypeCsv.DATEFR, null, null, 10),
									new PLMCsvRptColumn("xldpoCount", "DPO Count", FormatTypeCsv.INTEGER, null, null, 8),
									new PLMCsvRptColumn("xlugModelCount", "UG Model Count", FormatTypeCsv.INTEGER, null, null, 8),
									new PLMCsvRptColumn("xlprodParts", "Production Parts", FormatTypeCsv.INTEGER, null, null, 8),
									new PLMCsvRptColumn("xldevParts", "Development Parts", FormatTypeCsv.INTEGER, null, null, 8),
									new PLMCsvRptColumn("mbpdModelCnt", "MBPD Models", FormatTypeCsv.INTEGER, null, null, 13),
									new PLMCsvRptColumn("mbpdPartCnt", "MBPD Parts", FormatTypeCsv.INTEGER, null, null, 13)
			        };
			csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, null, ",");
			}else if(!isAllFlag() && isDevFlag() && !isProdFlag()){
				PLMCsvRptColumn[] reportColumns =
								new PLMCsvRptColumn[] {new PLMCsvRptColumn("ecoName", "ECO Name", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoRev", "ECO REV", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoOwner", "ECO Owner SSO", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoOwnerName", "ECO Owner Name", FormatTypeCsv.TEXT, null, null, 25),
										new PLMCsvRptColumn("ecoOriginator", "ECO Orig. SSO", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoOriginatorName", "ECO Orig. Name", FormatTypeCsv.TEXT, null, null, 25),
										new PLMCsvRptColumn("ecoDesc", "ECO Description", FormatTypeCsv.TEXT, null, null, 35),
										new PLMCsvRptColumn("rdo", "RDO", FormatTypeCsv.TEXT, null, null, 20),
										new PLMCsvRptColumn("ecoState", "State", FormatTypeCsv.TEXT, null, null, 20),
										new PLMCsvRptColumn("fastTrackEco", "ECO Fast Track", FormatTypeCsv.TEXT, null, null, 9),
										new PLMCsvRptColumn("ecoSev", "Severity", FormatTypeCsv.TEXT, null, null, 9),
										new PLMCsvRptColumn("ecoDesginEngr", "Design Engr. SSO", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoDesignEngrName", "Design Engr. Name", FormatTypeCsv.TEXT, null, null, 25),
										new PLMCsvRptColumn("ecoMfgEngr", "MFG Engr. SSO", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoMfgEngrName", "MFG Engr. Name", FormatTypeCsv.TEXT, null, null, 25),
										new PLMCsvRptColumn("eco_orig_date", "ECO Orig Date", FormatTypeCsv.DATEFR, null, null, 10),
										new PLMCsvRptColumn("task_count", "Task Count", FormatTypeCsv.TEXT, null, null, 8),
										new PLMCsvRptColumn("route_count", "Route Count", FormatTypeCsv.TEXT, null, null, 8),
										//new PLMCsvRptColumn("dwg_count", "Drawing Count", FormatTypeCsv.TEXT, null, null, 8),
										new PLMCsvRptColumn("xlecoCategChng", "ECO Category Change", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("xlecoRlseDt", "ECO Release Date", FormatTypeCsv.DATEFR, null, null, 10),
										new PLMCsvRptColumn("xldpoCount", "DPO Count", FormatTypeCsv.INTEGER, null, null, 8),
										new PLMCsvRptColumn("xlugModelCount", "UG Model Count", FormatTypeCsv.INTEGER, null, null, 8),
										new PLMCsvRptColumn("xldevParts", "Development Parts", FormatTypeCsv.INTEGER, null, null, 8),
										new PLMCsvRptColumn("mbpdModelCnt", "MBPD Models", FormatTypeCsv.INTEGER, null, null, 13),
										new PLMCsvRptColumn("mbpdPartCnt", "MBPD Parts", FormatTypeCsv.INTEGER, null, null, 13)
							
				      };
				csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, null, ",");
		     }else if(!isAllFlag() && !isDevFlag() && isProdFlag()){
				PLMCsvRptColumn[] reportColumns =
								new PLMCsvRptColumn[] {new PLMCsvRptColumn("ecoName", "ECO Name", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoRev", "ECO REV", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoOwner", "ECO Owner SSO", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoOwnerName", "ECO Owner Name", FormatTypeCsv.TEXT, null, null, 25),
										new PLMCsvRptColumn("ecoOriginator", "ECO Orig. SSO", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoOriginatorName", "ECO Orig. Name", FormatTypeCsv.TEXT, null, null, 25),
										new PLMCsvRptColumn("ecoDesc", "ECO Description", FormatTypeCsv.TEXT, null, null, 35),
										new PLMCsvRptColumn("rdo", "RDO", FormatTypeCsv.TEXT, null, null, 20),
										new PLMCsvRptColumn("ecoState", "State", FormatTypeCsv.TEXT, null, null, 20),
										new PLMCsvRptColumn("fastTrackEco", "ECO Fast Track", FormatTypeCsv.TEXT, null, null, 9),
										new PLMCsvRptColumn("ecoSev", "Severity", FormatTypeCsv.TEXT, null, null, 9),
										new PLMCsvRptColumn("ecoDesginEngr", "Design Engr. SSO", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoDesignEngrName", "Design Engr. Name", FormatTypeCsv.TEXT, null, null, 25),
										new PLMCsvRptColumn("ecoMfgEngr", "MFG Engr. SSO", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("ecoMfgEngrName", "MFG Engr. Name", FormatTypeCsv.TEXT, null, null, 25),
										new PLMCsvRptColumn("eco_orig_date", "ECO Orig Date", FormatTypeCsv.DATEFR, null, null, 10),
										new PLMCsvRptColumn("task_count", "Task Count", FormatTypeCsv.TEXT, null, null, 8),
										new PLMCsvRptColumn("route_count", "Route Count", FormatTypeCsv.TEXT, null, null, 8),
										//new PLMCsvRptColumn("dwg_count", "Drawing Count", FormatTypeCsv.TEXT, null, null, 8),
										new PLMCsvRptColumn("xlecoCategChng", "ECO Category Change", FormatTypeCsv.TEXT),
										new PLMCsvRptColumn("xlecoRlseDt", "ECO Release Date", FormatTypeCsv.DATEFR, null, null, 10),
										new PLMCsvRptColumn("xldpoCount", "DPO Count", FormatTypeCsv.INTEGER, null, null, 8),
										new PLMCsvRptColumn("xlugModelCount", "UG Model Count", FormatTypeCsv.INTEGER, null, null, 8),
										new PLMCsvRptColumn("xlprodParts", "Production Parts", FormatTypeCsv.INTEGER, null, null, 8),
										new PLMCsvRptColumn("mbpdModelCnt", "MBPD Models", FormatTypeCsv.INTEGER, null, null, 13),
										new PLMCsvRptColumn("mbpdPartCnt", "MBPD Parts", FormatTypeCsv.INTEGER, null, null, 13)
				    };
				csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, null, ",");
			  }

		} else {
			fileName = "ECO Details";
			PLMCsvRptColumn[] reportColumns =
							new PLMCsvRptColumn[] {new PLMCsvRptColumn("ecoName", "ECO Name", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("ecoRev", "ECO REV", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("ecoOriginator", "ECO Orig. SSO", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("ecoOriginatorName", "ECO Orig. Name", FormatTypeCsv.TEXT, null, null, 20),
									new PLMCsvRptColumn("ecoOwner", "ECO Owner SSO", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("ecoOwnerName", "ECO Owner Name", FormatTypeCsv.TEXT, null, null, 20),
									new PLMCsvRptColumn("ecoDesc", "ECO Description", FormatTypeCsv.TEXT, null, null, 35),
									new PLMCsvRptColumn("rdo", "RDO", FormatTypeCsv.TEXT, null, null, 20),
									new PLMCsvRptColumn("ecoState", "State", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("fastTrackEco", "ECO Fast Track", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("ecoCateg", "Category", FormatTypeCsv.TEXT, null, null, 20),
									new PLMCsvRptColumn("ecoSev", "Severity", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("ecoDesginEngr", "Design Engr. SSO", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("ecoDesignEngrName", "Design Engr. Name", FormatTypeCsv.TEXT, null, null, 20),
									new PLMCsvRptColumn("ecoMfgEngr", "MFG Engr. SSO", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("ecoMfgEngrName", "MFG Engr. Name", FormatTypeCsv.TEXT, null, null, 20),
									new PLMCsvRptColumn("ecoReldateExl", "ECO Rel Date", FormatTypeCsv.DATEFR, null, null, 10),
									new PLMCsvRptColumn("eco_orig_date", "ECO Orig Date", FormatTypeCsv.DATEFR, null, null, 10),
									new PLMCsvRptColumn("eco_age_in_days", "ECO Age(In Days)", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("routeName", "Route Name", FormatTypeCsv.TEXT, null, null, 20),
									new PLMCsvRptColumn("routeType", "Type", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("routeOwner", "Route Owner", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("routeLastUp", "Route Last Up", FormatTypeCsv.DATEFR, null, null, 10),
									new PLMCsvRptColumn("routeState", "Route State", FormatTypeCsv.TEXT, null, null, 12),
									new PLMCsvRptColumn("routeStatus", "Route Status", FormatTypeCsv.TEXT, null, null, 12),
									new PLMCsvRptColumn("taskName", "Task Name", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("taskCreation", "Task Creation", FormatTypeCsv.DATEFR, null, null, 10),
									new PLMCsvRptColumn("taskOwner", "Task Owner", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("taskOwnerFN", "Task Owner FN", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("taskOwnerLN", "Task Owner LN", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("taskState", "Task State", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("approvalStat", "Approval State", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("scheCompDate", "Scheduled Date", FormatTypeCsv.DATEFR, null, null, 10),
									new PLMCsvRptColumn("actCompDate", "Completion Date", FormatTypeCsv.DATEFR, null, null, 10),
									new PLMCsvRptColumn("dwgName", "DWG Name", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("dwgRev", "DWG REV", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("dwgOriginator", "DWG Orig. SSO", FormatTypeCsv.TEXT),
									new PLMCsvRptColumn("dwgOriginatorName", "DWG Orig. Name", FormatTypeCsv.TEXT, null, null, 20),
									new PLMCsvRptColumn("dwgCreateDate", "DWG Creation Date", FormatTypeCsv.DATEFR, null, null, 10),
									new PLMCsvRptColumn("dwgRelDate", "DWG Release Date", FormatTypeCsv.DATEFR, null, null, 10),
									new PLMCsvRptColumn("dwgCycletime", "DWG Cycle Time(In Days)", FormatTypeCsv.TEXT)

							};

			csvUtil.exportCsv(searchDetailsResultList, reportColumns, fileName, dateFormat, false, null, null, ",");

		}

	}

	
	public String backToEcoReport(){
		LOG.info("-----back To EcoReport---");
		reportName="ecoHdrReport";
	 return "backtoEcoSinglesearch";
	}

	/*public void downloadEcoSingleSearchExcel() throws PLMCommonException {

		LOG.info("Entering downloadEcoSingleSearchExcel Method");

		String reportName = "ecosinglesearchexcel";
		String fileName = "ECOReport";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();

		PLMXlsxRptColumn[] reportColumns =
						new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("ecoName", "ECO Name", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoRev", "ECO REV", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoOwner", "ECO Owner SSO", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoOwnerName", "ECO Owner Name", FormatType.TEXT, null, null, 25),
								new PLMXlsxRptColumn("ecoOriginator", "ECO Orig. SSO", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoOriginatorName", "ECO Orig. Name", FormatType.TEXT, null, null, 25),
								new PLMXlsxRptColumn("ecoDesc", "ECO Description", FormatType.TEXT, null, null, 35),
								new PLMXlsxRptColumn("ecoState", "State", FormatType.TEXT, null, null, 20),
								new PLMXlsxRptColumn("fastTrackEco", "ECO Fast Track", FormatType.TEXT, null, null, 9),
								new PLMXlsxRptColumn("ecoSev", "Severity", FormatType.TEXT, null, null, 9),
								new PLMXlsxRptColumn("ecoDesginEngr", "Design Engr. SSO", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoDesignEngrName", "Design Engr. Name", FormatType.TEXT, null, null, 25),
								new PLMXlsxRptColumn("ecoMfgEngr", "MFG Engr. SSO", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoMfgEngrName", "MFG Engr. Name", FormatType.TEXT, null, null, 25),
								new PLMXlsxRptColumn("eco_orig_date", "ECO Orig Date", FormatType.DATE, null, null, 10),
								new PLMXlsxRptColumn("task_count", "Task Count", FormatType.TEXT, null, null, 8),
								new PLMXlsxRptColumn("route_count", "Route Count", FormatType.TEXT, null, null, 8),
								new PLMXlsxRptColumn("dwg_count", "Drawing Count", FormatType.TEXT, null, null, 8)
						};


		PLMXlsxRptColumn[] critcolumns =
						new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("ecoName", "ECO Name", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoOwner", "ECO Owner", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoOriginator", "ECO Originator", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoSevExcel", "ECO Severity", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoStateExcel", "ECO State", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoCategExcel", "ECO Category", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoCycle", "ECO Cycle", FormatType.TEXT), new PLMXlsxRptColumn("rdo", "RDO", FormatType.TEXT),
								new PLMXlsxRptColumn("fastTrackEco", "ECO Fast Track", FormatType.TEXT),
								new PLMXlsxRptColumn("frmEco_orig_date_excel", "ECO Origination Start Date From", FormatType.TEXT),
								new PLMXlsxRptColumn("toEco_orig_date_excel", "ECO Origination Start Date To", FormatType.TEXT)
						};

		excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, searchDetails);

		

	} 	
	
	public void downloadEcoResultExcel() throws PLMCommonException {
		LOG.info("Entering downloadEcoResultExcel Method");
		
		String reportName="ecoresultexcel";
		String fileName="ECODetailReport";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					new PLMXlsxRptColumn("ecoName", "ECO Name", FormatType.TEXT),
                    new PLMXlsxRptColumn("ecoRev", "ECO REV", FormatType.TEXT),
                    new PLMXlsxRptColumn("ecoOriginator", "ECO Orig. SSO", FormatType.TEXT),
                    new PLMXlsxRptColumn("ecoOriginatorName", "ECO Orig. Name", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("ecoOwner", "ECO Owner SSO", FormatType.TEXT),
                    new PLMXlsxRptColumn("ecoOwnerName", "ECO Owner Name", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("ecoDesc", "ECO Description", FormatType.TEXT, null, null, 35),
                    new PLMXlsxRptColumn("rdo", "RDO", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("ecoState", "State", FormatType.TEXT),
                    new PLMXlsxRptColumn("fastTrackEco", "ECO Fast Track", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("ecoCateg", "Category", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("ecoSev", "Severity", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("ecoDesginEngr", "Design Engr. SSO", FormatType.TEXT),
                    new PLMXlsxRptColumn("ecoDesignEngrName", "Design Engr. Name", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("ecoMfgEngr", "MFG Engr. SSO", FormatType.TEXT),
                    new PLMXlsxRptColumn("ecoMfgEngrName", "MFG Engr. Name", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("eco_rel_date", "ECO Rel Date", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("eco_orig_date", "ECO Orig Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("eco_age_in_days", "ECO Age(In Days)", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("routeName", "Route Name", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("routeType", "Type", FormatType.TEXT),
                    new PLMXlsxRptColumn("routeOwner", "Route Owner", FormatType.TEXT),
                    new PLMXlsxRptColumn("routeLastUp", "Route Last Up", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("routeState", "Route State", FormatType.TEXT, null, null, 12),
                    new PLMXlsxRptColumn("routeStatus", "Route Status", FormatType.TEXT, null, null, 12),
                    new PLMXlsxRptColumn("taskName", "Task Name", FormatType.TEXT),
                    new PLMXlsxRptColumn("taskCreation", "Task Creation", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("taskOwner", "Task Owner", FormatType.TEXT),
                    new PLMXlsxRptColumn("taskOwnerFN", "Task Owner FN", FormatType.TEXT),
                    new PLMXlsxRptColumn("taskOwnerLN", "Task Owner LN", FormatType.TEXT),
                    new PLMXlsxRptColumn("taskState", "Task State", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("approvalStat", "Approval State", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("scheCompDate", "Scheduled Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("actCompDate", "Completion Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("dwgName", "DWG Name", FormatType.TEXT),
                    new PLMXlsxRptColumn("dwgRev", "DWG REV", FormatType.TEXT),
                    new PLMXlsxRptColumn("dwgOriginator", "DWG Orig. SSO", FormatType.TEXT),
                    new PLMXlsxRptColumn("dwgOriginatorName", "DWG Orig. Name", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("dwgCreateDate", "DWG Creation Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("dwgRelDate", "DWG Release Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("dwgCycletime", "DWG Cycle Time(In Days)", FormatType.TEXT)
                    
						};


		PLMXlsxRptColumn[] critcolumns =
						new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("ecoName", "ECO Name", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoOwner", "ECO Owner", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoOriginator", "ECO Originator", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoSevExcel", "ECO Severity", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoStateExcel", "ECO State", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoCategExcel", "ECO Category", FormatType.TEXT),
								new PLMXlsxRptColumn("ecoCycle", "ECO Cycle", FormatType.TEXT), new PLMXlsxRptColumn("rdo", "RDO", FormatType.TEXT),
								new PLMXlsxRptColumn("fastTrackEco", "ECO Fast Track", FormatType.TEXT),
								new PLMXlsxRptColumn("frmEco_orig_date_excel", "ECO Origination Start Date From", FormatType.TEXT),
								new PLMXlsxRptColumn("toEco_orig_date_excel", "ECO Origination Start Date To", FormatType.TEXT)

						};

		excelUtil.export(searchDetailsResultList, reportColumns, fileName, fileName, true, critcolumns, searchDetails);


	}
	
	public void downloadEcoSingleSearchCSV() throws PLMCommonException {
		
		PrintWriter pwriter = null;
		OutputStream os = null;

		try {
			
			FacesContext facesContext = FacesContext.getCurrentInstance();

			HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
			HttpServletRequest resquest = (HttpServletRequest) facesContext.getExternalContext().getRequest();
			
			HttpSession session = resquest.getSession();
			
			response.setHeader("content-disposition","attachment; filename=ECOReport.csv");
			response.setContentType("application/CSV");
			
			pwriter = response.getWriter();
			   
			   PLMEcoSearchMB searchMB = (PLMEcoSearchMB)session.getAttribute("plmkpiecoSearchMB");
			   
			   pwriter.write("ECO Name");
	 			pwriter.write(",");
	  			pwriter.write("ECO REV");
	 			pwriter.write(",");
	 			pwriter.write("ECO Owner SSO");
	 			pwriter.write(",");
	 			pwriter.write("ECO Owner Name");
	 			pwriter.write(",");
	 			pwriter.write("ECO Orig. SSO");
	 			pwriter.write(",");
	 			pwriter.write("ECO Orig. Name");
	 			pwriter.write(",");
	 			pwriter.write("Eco Description");
	 			pwriter.write(",");
	 			pwriter.write("State");
	 			pwriter.write(",");
	 			//Added for Radio Button
	 			pwriter.write("ECO Fast Track");
	 			pwriter.write(",");
	 			//Added for Radio Button
	 			pwriter.write("Severity");
	  			pwriter.write(",");
	 			pwriter.write("Design Engr. SSO");
	 			pwriter.write(",");
	 			pwriter.write("Design Engr. Name");
	 			pwriter.write(",");
	 			pwriter.write("MFG Engr. SSO ");
	 			pwriter.write(",");
	 			pwriter.write("MFG Engr. Name");
	 			pwriter.write(",");
	 			pwriter.write("ECO Orig Date");
	 			pwriter.write(",");
	 			pwriter.write("Task Count");
	 			pwriter.write(",");
	 			pwriter.write("Route Count");
	 			pwriter.write(",");
	 			pwriter.write("Drawing Count");
	  			pwriter.write("\n");
	 			
	 			
	  			
	  			
	 			SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
	   		//	String route_last_upd = null;
	   		//	String task_creation = null;
	   		//	String sch_date = null;
	   		//	String act_date = null;
	   		//	String dwg_crt = null;
	   		//	String dwg_rel = null;   
	   			String eco_orig_date=null;
			   if(searchMB != null && searchMB.getSearchResultList() != null &&  searchMB.getSearchResultList().size() > 0) {
				 		     		
			   		for(int i=0; i<searchMB.getSearchResultList().size(); i++) {
			   			PLMEcoSearchData dataObj = (PLMEcoSearchData)searchMB.getSearchResultList().get(i);
			   			if(dataObj.getEcoName()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoName()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getEcoRev()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoRev()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getEcoOwner()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoOwner()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getEcoOwnerName()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoOwnerName()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getEcoOriginator()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoOriginator()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getEcoOriginatorName()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoOriginatorName()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getEcoDesc()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoDesc()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getEcoState()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoState()));
			   			}
			   			pwriter.write(",");
	//Added for Radio Button
			   			if(dataObj.getFastTrackEco()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFastTrackEco()));
				   		}
				   		pwriter.write(",");
	//Added for Radio Button			   		
			   			if(dataObj.getEcoSev()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoSev()));
			   			}
			   			pwriter.write(",");
			   			if(dataObj.getEcoDesginEngr()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoDesginEngr()));
			   			}
			   			pwriter.write(",");
			   			if(dataObj.getEcoDesignEngrName()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoDesignEngrName()));
				   		}
				   		pwriter.write(",");
			   			if(dataObj.getEcoMfgEngr()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoMfgEngr()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getEcoMfgEngrName()!= null){
					   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoMfgEngrName()));
					   	}
				   		pwriter.write(",");
			   			if(dataObj.getEco_orig_date()!= null){
					    	eco_orig_date=dateFormat.format(dataObj.getEco_orig_date());
							pwriter.write(eco_orig_date);
						}
			   			pwriter.write(",");
						if(dataObj.getTask_count()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTask_count()));
				   			}
						pwriter.write(",");
						if(dataObj.getRoute_count()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRoute_count()));
							
						}
						pwriter.write(",");
						if(dataObj.getDwg_count()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDwg_count()));
							
						}			
			   			pwriter.write("\n");
			   			
			   		}
			   		
			   }
			   pwriter.flush(); 
			  } catch (FileNotFoundException e) {
			   System.out.println("the exception is---" + e);
			  } catch (Exception e1) {
				  System.out.println("IOException " + e1.getMessage());
			  } finally {
			   try {
			    if (pwriter != null) {
			    	pwriter.close();
			    }
			   } catch (Exception exc) {
			    exc.printStackTrace();
			   }
			   try {
			    if (os != null) {
			     os.close();
			    }
			   } catch (Exception exc) {
			    exc.printStackTrace();
			   }
			  }
	}
	
	public void downloadEcoResultCSV() throws PLMCommonException {
		
		PrintWriter pwriter = null;
		OutputStream os = null;

		try {
			
			FacesContext facesContext = FacesContext.getCurrentInstance();

			HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
			HttpServletRequest resquest = (HttpServletRequest) facesContext.getExternalContext().getRequest();
			
			HttpSession session = resquest.getSession();
			
			response.setHeader("content-disposition","attachment; filename=ECRDetailReport.csv");
			response.setContentType("application/CSV");
			
			pwriter = response.getWriter();
			   
			   PLMEcoSearchMB searchMB = (PLMEcoSearchMB)session.getAttribute("plmkpiecoSearchMB");
			   
			   	pwriter.write("ECO Name"); 			
	  			pwriter.write(",");
	  			pwriter.write("ECO REV");
	  			pwriter.write(",");
	  			pwriter.write("ECO Orig. SSO");
	 			pwriter.write(",");
	 			pwriter.write("ECO Orig. Name");
	 			pwriter.write(",");
	 			pwriter.write("ECO Owner SSO");
	 			pwriter.write(",");
	 			pwriter.write("ECO Owner Name");
	 			pwriter.write(",");
	 			pwriter.write("ECO Description");
	 			pwriter.write(",");
	 			pwriter.write("RDO");
	 			pwriter.write(",");
	 			pwriter.write("State");
	 			pwriter.write(",");
	 			pwriter.write("ECO Fast Track");
	 			pwriter.write(",");
	 			pwriter.write("Category");
	  			pwriter.write(",");
	 			pwriter.write("Severity");
	 			pwriter.write(",");
	 			pwriter.write("Design Engr. SSO");
	 			pwriter.write(",");
	 			pwriter.write("Design Engr. Name");
	 			pwriter.write(",");
	 			pwriter.write("MFG Engr. SSO");
	 			pwriter.write(",");
	 			pwriter.write("MFG Engr. Name");
	 			pwriter.write(",");
	 			pwriter.write("ECO Rel date");
	 			pwriter.write(",");
	 			pwriter.write("ECO Orig Date");
	 			pwriter.write(",");
	 			pwriter.write("ECO Age(In Days)");
	 			pwriter.write(",");
	 			pwriter.write("Route Name");
	 			pwriter.write(",");
	 			pwriter.write("Type");
	 			pwriter.write(",");
	 			pwriter.write("Route Owner");
	 			pwriter.write(",");
	 			pwriter.write("Route Last Up");
	 			pwriter.write(",");
	 			pwriter.write("Route State");
	 			pwriter.write(",");
	 			pwriter.write("Route Status");
	 			pwriter.write(",");
	 			pwriter.write("Task Name");
	 			pwriter.write(",");
	 			pwriter.write("Task Creation");
	 			pwriter.write(",");
	 			pwriter.write("Task Owner");
	 			pwriter.write(",");
	 			pwriter.write("Task Owner FN");
	 			pwriter.write(",");
	 			pwriter.write("Task Owner LN");
	 			pwriter.write(",");
	 			pwriter.write("Task State");
	 			pwriter.write(",");
	 			pwriter.write("Approval State");
	 			pwriter.write(",");
	 			pwriter.write("Scheduled Date");
	 			pwriter.write(",");
	 			pwriter.write("Completion Date");
	 			pwriter.write(",");
	 			pwriter.write("DWG Name");
	 			pwriter.write(",");
	 			pwriter.write("DWG REV");
	 			pwriter.write(",");
	 			pwriter.write("DWG Orig. SSO");
	 			pwriter.write(",");
	 			pwriter.write("DWG Orig. Name");
	 			pwriter.write(",");
	 			pwriter.write("DWG Creation Date");
	 			pwriter.write(",");
	 			pwriter.write("DWG Release Date");
	 			pwriter.write(",");
	 			pwriter.write("DWG Cycle Time(In Days)");
	 			pwriter.write("\n");
	 			
	 			
	  			
	  			
	 			SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
	   			String route_last_upd = null;
	   			String task_creation = null;
	   			String sch_date = null;
	   			String act_date = null;
	   			String dwg_crt = null;
	   			String dwg_rel = null;
	   			String eco_orig_date=null;
			   if(searchMB != null && searchMB.getSearchDetailsResultList() != null &&  searchMB.getSearchDetailsResultList().size() > 0) {
				 		     		
			   		for(int i=0; i<searchMB.getSearchDetailsResultList().size(); i++) {
			   			PLMEcoSearchData dataObj = (PLMEcoSearchData)searchMB.getSearchDetailsResultList().get(i);
			   			if(dataObj.getEcoName()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoName()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getEcoRev()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoRev()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getEcoOriginator()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoOriginator()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getEcoOriginatorName()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoOriginatorName()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getEcoOwner()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoOwner()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getEcoOwnerName()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoOwnerName()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getEcoDesc()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoDesc()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getRdo()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRdo()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getEcoState()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoState()));
			   			}
			   			pwriter.write(",");
			   			if(dataObj.getFastTrackEco()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFastTrackEco()));
				   		}
				   		pwriter.write(",");
			   			if(dataObj.getEcoCateg()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoCateg()));
			   			}
			   			pwriter.write(",");
			   			if(dataObj.getEcoSev()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoSev()));
			   			}
			   			pwriter.write(",");
			   			if(dataObj.getEcoDesginEngr()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoDesginEngr()));
			   			}
			   			pwriter.write(",");
			   			if(dataObj.getEcoDesignEngrName()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoDesignEngrName()));
			   			}
			   			pwriter.write(",");
			   			if(dataObj.getEcoMfgEngr()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoMfgEngr()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getEcoMfgEngrName()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoMfgEngrName()));
				   		}
			   			pwriter.write(",");
						if(dataObj.getEco_rel_date()!= null){
						pwriter.write(dataObj.getEco_rel_date());
						}
						pwriter.write(",");
						if(dataObj.getEco_orig_date()!= null){
					    	eco_orig_date=dateFormat.format(dataObj.getEco_orig_date());
							pwriter.write(eco_orig_date);
						}
						pwriter.write(",");
						if(dataObj.getEco_age_in_days()!= null){
					   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEco_age_in_days()));
						}
						pwriter.write(",");
			   			if(dataObj.getRouteName()!= null){
			   				pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRouteName()));
			   			}
			   			pwriter.write(",");
			   			if(dataObj.getRouteType()!= null){
			   				pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRouteType()));
			   			}
			   			pwriter.write(",");
			   			if(dataObj.getRouteOwner()!= null){
			   				pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRouteOwner()));
			   			}
			   			pwriter.write(",");
			   			if(dataObj.getRouteLastUp()!= null){
			   				route_last_upd=dateFormat.format(dataObj.getRouteLastUp());
				   			pwriter.write(route_last_upd);
				   		}
			   			pwriter.write(",");
				   		if(dataObj.getRouteState()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRouteState()));
				   		}
				   		pwriter.write(",");
				   		if(dataObj.getRouteStatus()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRouteStatus()));
				   		}
				   		pwriter.write(",");
				   		if(dataObj.getTaskName()!= null){
					   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTaskName()));
					    }
				   		pwriter.write(",");
					   	if(dataObj.getTaskCreation()!= null){
					   		task_creation=dateFormat.format(dataObj.getTaskCreation());
				   			pwriter.write(task_creation);
				   			}
					   	pwriter.write(",");
					  	if(dataObj.getTaskOwner()!= null){
						   	pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTaskOwner()));
					  	}
					  	pwriter.write(",");
						if(dataObj.getTaskOwnerFN()!= null){
					   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTaskOwnerFN()));
				   		}
						pwriter.write(",");
				   		if(dataObj.getTaskOwnerLN()!= null){
					   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTaskOwnerLN()));
					   	}
				   		pwriter.write(",");
					   	if(dataObj.getTaskState()!= null){
						   	pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTaskState()));
					   	}
					   	pwriter.write(",");
					   	if(dataObj.getApprovalStat()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getApprovalStat()));
						}
					   	pwriter.write(",");
						if(dataObj.getScheCompDate()!= null){
							sch_date=dateFormat.format(dataObj.getScheCompDate());
				   			pwriter.write(sch_date);
				   			}
						pwriter.write(",");
						if(dataObj.getActCompDate()!= null){
							act_date=dateFormat.format(dataObj.getActCompDate());
				   			pwriter.write(act_date);
				   			}
						pwriter.write(",");
						if(dataObj.getDwgName()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDwgName()));
						}
						pwriter.write(",");
						if(dataObj.getDwgRev()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDwgRev()));
						}
						pwriter.write(",");
						if(dataObj.getDwgOriginator()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDwgOriginator()));
						}
						pwriter.write(",");
						if(dataObj.getDwgOriginatorName()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDwgOriginatorName()));
						}
						pwriter.write(",");
						if(dataObj.getDwgCreateDate()!= null){
							dwg_crt=dateFormat.format(dataObj.getDwgCreateDate());
				   			pwriter.write(dwg_crt);
				   		}
						pwriter.write(",");
						if(dataObj.getDwgRelDate()!= null){
							dwg_rel=dateFormat.format(dataObj.getDwgRelDate());
				   			pwriter.write(dwg_rel);
				   		}
						pwriter.write(",");
						if(dataObj.getDwgCycletime()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDwgCycletime()));
							
						}				
						pwriter.write("\n");
			   			
			   		}
			   		
			   }
			   pwriter.flush(); 
			  } catch (FileNotFoundException e) {
			   System.out.println("the exception is---" + e);
			  } catch (Exception e1) {
				  System.out.println("IOException " + e1.getMessage());
			  } finally {
			   try {
			    if (pwriter != null) {
			    	pwriter.close();
			    }
			   } catch (Exception exc) {
			    exc.printStackTrace();
			   }
			   try {
			    if (os != null) {
			     os.close();
			    }
			   } catch (Exception exc) {
			    exc.printStackTrace();
			   }
			  }
	}*/

	/**
	 * @return the plmEcoSearchService
	 */

	/**
	 * @return the searchResultList
	 */
	public List<PLMEcoSearchData> getSearchResultList() {
		return searchResultList;
	}

	/**
	 * @return the plmKpiReportService
	 */
	public PLMkpiReportServiceIfc getPlmKpiReportService() {
		return plmKpiReportService;
	}

	/**
	 * @param plmKpiReportService
	 *            the plmKpiReportService to set
	 */
	public void setPlmKpiReportService(
			PLMkpiReportServiceIfc plmKpiReportService) {
		this.plmKpiReportService = plmKpiReportService;
	}

	/**
	 * @param searchResultList
	 *            the searchResultList to set
	 */
	public void setSearchResultList(List<PLMEcoSearchData> searchResultList) {
		this.searchResultList = searchResultList;
	}

	/**
	 * @return the searchDetails
	 */
	public PLMEcoSearchData getSearchDetails() {
		return searchDetails;
	}

	/**
	 * @param searchDetails
	 *            the searchDetails to set
	 */
	public void setSearchDetails(PLMEcoSearchData searchDetails) {
		this.searchDetails = searchDetails;
	}

	/**
	 * @return the count
	 */
	public int getCount() {
		return count;
	}

	/**
	 * @param count
	 *            the count to set
	 */
	public void setCount(int count) {
		this.count = count;
	}

	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount
	 *            the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/**
	 * @return the totalRecCountMsg
	 */
	public String getTotalRecCountMsg() {
		return totalRecCountMsg;
	}

	/**
	 * @param totalRecCountMsg
	 *            the totalRecCountMsg to set
	 */
	public void setTotalRecCountMsg(String totalRecCountMsg) {
		this.totalRecCountMsg = totalRecCountMsg;
	}

	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * @param fieldName
	 *            the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage
	 *            the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}

	/**
	 * @param plmIssuesService
	 *            the plmIssuesService to set
	 */
	public void setPlmIssuesService(PLMkpiReportServiceIfc plmIssuesService) {
		this.plmKpiReportService = plmIssuesService;
	}

	/**
	 * @return the catListData
	 */
	public List<SelectItem> getCatListData() {
		return catListData;
	}

	/**
	 * @param catListData
	 *            the catListData to set
	 */
	public void setCatListData(List<SelectItem> catListData) {
		this.catListData = catListData;
	}

	/**
	 * @return the sevListData
	 */
	public List<SelectItem> getSevListData() {
		return sevListData;
	}

	/**
	 * @param sevListData
	 *            the sevListData to set
	 */
	public void setSevListData(List<SelectItem> sevListData) {
		this.sevListData = sevListData;
	}

	
	/**
	 * @return the stateListData
	 */
	public List<SelectItem> getStateListData() {
		return stateListData;
	}

	/**
	 * @param stateListData
	 *            the stateListData to set
	 */
	public void setStateListData(List<SelectItem> stateListData) {
		this.stateListData = stateListData;
	}

	/**
	 * @return the fwdFlag
	 */
	public String getFwdFlag() {
		return fwdFlag;
	}

	/**
	 * @param fwdFlag
	 *            the fwdFlag to set
	 */
	public void setFwdFlag(String fwdFlag) {
		this.fwdFlag = fwdFlag;
	}

	/**
	 * @return the ecosessionvalue
	 */
	public String getEcosessionvalue() {
		return ecosessionvalue;
	}

	/**
	 * @param ecosessionvalue
	 *            the ecosessionvalue to set
	 */
	public void setEcosessionvalue(String ecosessionvalue) {
		this.ecosessionvalue = ecosessionvalue;
	}

	/**
	 * @return the searchDetailsResultList
	 */
	public List<PLMEcoSearchData> getSearchDetailsResultList() {
		return searchDetailsResultList;
	}

	/**
	 * @param searchDetailsResultList
	 *            the searchDetailsResultList to set
	 */
	public void setSearchDetailsResultList(
			List<PLMEcoSearchData> searchDetailsResultList) {
		this.searchDetailsResultList = searchDetailsResultList;
	}

	/**
	 * @return the totalDetailRecCount
	 */
	public int getTotalDetailRecCount() {
		return totalDetailRecCount;
	}

	/**
	 * @param totalDetailRecCount
	 *            the totalDetailRecCount to set
	 */
	public void setTotalDetailRecCount(int totalDetailRecCount) {
		this.totalDetailRecCount = totalDetailRecCount;
	}

	/**
	 * @return the selectedecos
	 */
	public String getSelectedecos() {
		return selectedecos;
	}

	/**
	 * @param selectedecos
	 *            the selectedecos to set
	 */
	public void setSelectedecos(String selectedecos) {
		this.selectedecos = selectedecos;
	}

	/**
	 * @return the detailRecordCounts
	 */
	public int getDetailRecordCounts() {
		return detailRecordCounts;
	}

	/**
	 * @param detailRecordCounts
	 *            the detailRecordCounts to set
	 */
	public void setDetailRecordCounts(int detailRecordCounts) {
		this.detailRecordCounts = detailRecordCounts;
	}

	/**
	 * @return the totalDetailRecCountMsg
	 */
	public String getTotalDetailRecCountMsg() {
		return totalDetailRecCountMsg;
	}

	/**
	 * @param totalDetailRecCountMsg
	 *            the totalDetailRecCountMsg to set
	 */
	public void setTotalDetailRecCountMsg(String totalDetailRecCountMsg) {
		this.totalDetailRecCountMsg = totalDetailRecCountMsg;
	}

	/**
	 * @return the page
	 */
	public String getPage() {
		return page;
	}

	/**
	 * @param page
	 *            the page to set
	 */
	public void setPage(String page) {
		this.page = page;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	
	/**
	 * @return the reportName
	 */
	public String getReportName() {
		return reportName;
	}
	
	/**
	 * @param reportName the reportName to set
	 */
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	/**
	 * @return the allFlag
	 */
	public boolean isAllFlag() {
		return allFlag;
	}
	/**
	 * @param allFlag the allFlag to set
	 */
	public void setAllFlag(boolean allFlag) {
		this.allFlag = allFlag;
	}
	/**
	 * @return the devFlag
	 */
	public boolean isDevFlag() {
		return devFlag;
	}
	/**
	 * @param devFlag the devFlag to set
	 */
	public void setDevFlag(boolean devFlag) {
		this.devFlag = devFlag;
	}
	/**
	 * @return the prodFlag
	 */
	public boolean isProdFlag() {
		return prodFlag;
	}
	/**
	 * @param prodFlag the prodFlag to set
	 */
	public void setProdFlag(boolean prodFlag) {
		this.prodFlag = prodFlag;
	}
	
	public List<SelectItem> getRdoListData() {
		return rdoListData;
	}
	
	public void setRdoListData(List<SelectItem> rdoListData) {
		this.rdoListData = rdoListData;
	}
	
	
	
}