/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMPartTrendsData.java
 * @Creation date: 30-June-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;
import java.util.List;

public class PLMPartTrendsData {
	/**
	  * Holds the rdoName
	  */
	private String rdoName;
	/**
	  * Holds the reportCriteria
	  */
	private String reportCriteria;
	/**
	  * Holds the partChangeInitiation
	  */
	private int partChangeInitiation;
	/**
	  * Holds the partChangeRevision
	  */
	private int partChangeRevision;
	/**
	  * Holds the newPart
	  */
	private int newPart;
	/**
	  * Holds the rdoNamesList
	  */
	private List<String> rdoNamesList;
	/**
	  * Holds the rdonames
	  */
	private String rdonames;
	/**
	  * Holds the issueAgainstPart
	  */
	private int issueAgainstPart;
//	private String startDate;
	
	/**
	  * Holds the startDateC
	  */
	private Date startDateC;
	/**
	  * Holds the endDatec
	  */
	private Date endDatec;

	public Date getStartDateC() {
		Date temp = null;
		temp = startDateC;
		return temp;
	}

	public void setStartDateC(Date startDateC) {
		Date temp = null;
		temp = startDateC;
		this.startDateC = temp;
	}

	public Date getEndDatec() {
		Date temp = null;
		temp = endDatec;
		return temp;
	}

	public void setEndDatec(Date endDatec) {
		Date temp = null;
		temp = endDatec;
		this.endDatec = temp;
	}
	/**
	  * Holds the startDate
	  */
	private String startDate;
	/**
	  * Holds the endDate
	  */
	private String endDate;

	
	/**
	 * @return the rdoName
	 */
	public String getRdoName() {
		return rdoName;
	}

	/**
	 * @param rdoName the rdoName to set
	 */
	public void setRdoName(String rdoName) {
		this.rdoName = rdoName;
	}

	/**
	 * @return the reportCriteria
	 */
	public String getReportCriteria() {
		return reportCriteria;
	}

	/**
	 * @param reportCriteria the reportCriteria to set
	 */
	public void setReportCriteria(String reportCriteria) {
		this.reportCriteria = reportCriteria;
	}

	/**
	 * @return the rdoNamesList
	 */
	public List<String> getRdoNamesList() {
		return rdoNamesList;
	}

	/**
	 * @param rdoNamesList the rdoNamesList to set
	 */
	public void setRdoNamesList(List<String> rdoNamesList) {
		this.rdoNamesList = rdoNamesList;
	}

	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the partChangeInitiation
	 */
	public int getPartChangeInitiation() {
		return partChangeInitiation;
	}

	/**
	 * @param partChangeInitiation the partChangeInitiation to set
	 */
	public void setPartChangeInitiation(int partChangeInitiation) {
		this.partChangeInitiation = partChangeInitiation;
	}

	/**
	 * @return the partChangeRevision
	 */
	public int getPartChangeRevision() {
		return partChangeRevision;
	}

	/**
	 * @param partChangeRevision the partChangeRevision to set
	 */
	public void setPartChangeRevision(int partChangeRevision) {
		this.partChangeRevision = partChangeRevision;
	}

	/**
	 * @return the newPart
	 */
	public int getNewPart() {
		return newPart;
	}

	/**
	 * @param newPart the newPart to set
	 */
	public void setNewPart(int newPart) {
		this.newPart = newPart;
	}
	
	/**
	 * @return the issueAgainstPart
	 */
	public int getIssueAgainstPart() {
		return issueAgainstPart;
	}

	/**
	 * @param issueAgainstPart the issueAgainstPart to set
	 */
	public void setIssueAgainstPart(int issueAgainstPart) {
		this.issueAgainstPart = issueAgainstPart;
	}

	/**
	 * @return the rdonames
	 */
	public String getRdonames() {
		return rdonames;
	}

	/**
	 * @param rdonames the rdonames to set
	 */
	public void setRdonames(String rdonames) {
		this.rdonames = rdonames;
	}
}