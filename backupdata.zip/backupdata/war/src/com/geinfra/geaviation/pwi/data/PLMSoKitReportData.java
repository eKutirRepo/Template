/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMSoKitReportData.java
 * @Creation date: 01-Jan-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMSoKitReportData {

	/**
	  * Holds the erpNo
	  */
	private String erpNo="";
	/**
	  * Holds the inputRadio
	  */
	private String inputRadio;
	/**
	  * Holds the tab1OrderNum
	  */
	private String tab1OrderNum;
	/**
	  * Holds the tab1ErpLineNum
	  */
	private String tab1ErpLineNum;
	/**
	  * Holds the tab1PartName
	  */
	private String tab1PartName;
	/**
	 * Holds the tab1PartRev
	 */
	private String tab1PartRev;
	/**
	  * Holds the tab1PartDesc
	  */
	private String tab1PartDesc;
	/**
	  * Holds the tab1Mli
	  */
	private String tab1Mli;
	/**
	  * Holds the tab1LineStatus
	  */
	private String tab1LineStatus;
	/**
	  * Holds the tab1CustLineNum
	  */
	private String tab1CustLineNum;
	/**
	  * Holds the tab1Qty
	  */
	private String tab1Qty;
	/**
	  * Holds the tab1Uom
	  */
	private String tab1Uom;
	/**
	  * Holds the tab1ShipDate
	  */
	private String tab1ShipDate;
	/**
	  * Holds the tab1RequestDate
	  */
	private String tab1RequestDate;
	
	
	/**
	  * Holds the tab2DfsOrder
	  */
	private String tab2DfsOrder;
	/**
	  * Holds the tab2BomLevel
	  */
	private String tab2BomLevel;
	/**
	  * Holds the tab2TopLevelPart
	  */
	private String tab2TopLevelPart;
	/**
	  * Holds the tab2PartId
	  */
	private String tab2PartId;
	/**
	  * Holds the tab2PartName
	  */
	private String tab2PartName;
	/**
	  * Holds the tab2PartType
	  */
	private String tab2PartType;
	/**
	  * Holds the tab2PartRev
	  */
	private String tab2PartRev;
	/**
	  * Holds the tab2PartPolicy
	  */
	private String tab2PartPolicy;
	/**
	  * Holds the tab2DfsOrder
	  */
	private String tab2FindNum;
	/**
	  * Holds the tab2DfsOrder
	  */
	private String tab2RefDesignator;
	/**
	  * Holds the tab2DfsOrder
	  */
	private String tab2CompLocation;
	/**
	  * Holds the tab2DfsOrder
	  */
	private String tab2PartDesc;
	/**
	  * Holds the tab2DfsOrder
	  */
	private String tab2PartState;
	/**
	  * Holds the tab2PartQty
	  */
	private String tab2PartQty;
	/**
	  * Holds the tab2Uom
	  */
	private String tab2Uom;
	/**
	  * Holds the tab2Usage
	  */
	private String tab2Usage;
	/**
	  * Holds the tab2PartFamily
	  */
	private String tab2PartFamily;
	/**
	  * Holds the tab2GeTechFeature
	  */
	private String tab2GeTechFeature;
	/**
	  * Holds the tab2BomPrefix
	  */
	private String tab2BomPrefix;
	/**
	  * Holds the tab2CopicsParent
	  */
	private String tab2CopicsParent;
	/**
	  * Holds the tab2CopicsSuffix
	  */
	private String tab2CopicsSuffix;
	/**
	  * Holds the tab2StEffDt
	  */
	private String tab2StEffDt;
	/**
	  * Holds the tab2EndEffDt
	  */
	private String tab2EndEffDt;
	/**
	  * Holds the tab2MaterialSpec
	  */
	private String tab2MaterialSpec;
	/**
	  * Holds the tab2GeLdpa
	  */
	private String tab2GeLdpa;
	
	
	
	
	
	
	
	/**
	 * @return the erpNo
	 */
	public String getErpNo() {
		return erpNo;
	}
	/**
	 * @param erpNo the erpNo to set
	 */
	public void setErpNo(String erpNo) {
		this.erpNo = erpNo;
	}
	/**
	 * @return the inputRadio
	 */
	public String getInputRadio() {
		return inputRadio;
	}
	/**
	 * @param inputRadio the inputRadio to set
	 */
	public void setInputRadio(String inputRadio) {
		this.inputRadio = inputRadio;
	}
	/**
	 * @return the tab1OrderNum
	 */
	public String getTab1OrderNum() {
		return tab1OrderNum;
	}
	/**
	 * @param tab1OrderNum the tab1OrderNum to set
	 */
	public void setTab1OrderNum(String tab1OrderNum) {
		this.tab1OrderNum = tab1OrderNum;
	}
	/**
	 * @return the tab1ErpLineNum
	 */
	public String getTab1ErpLineNum() {
		return tab1ErpLineNum;
	}
	/**
	 * @param tab1ErpLineNum the tab1ErpLineNum to set
	 */
	public void setTab1ErpLineNum(String tab1ErpLineNum) {
		this.tab1ErpLineNum = tab1ErpLineNum;
	}
	/**
	 * @return the tab1PartName
	 */
	public String getTab1PartName() {
		return tab1PartName;
	}
	/**
	 * @param tab1PartName the tab1PartName to set
	 */
	public void setTab1PartName(String tab1PartName) {
		this.tab1PartName = tab1PartName;
	}
	/**
	 * @return the tab1PartRev
	 */
	public String getTab1PartRev() {
		return tab1PartRev;
	}
	/**
	 * @param tab1PartRev the tab1PartRev to set
	 */
	public void setTab1PartRev(String tab1PartRev) {
		this.tab1PartRev = tab1PartRev;
	}
	/**
	 * @return the tab1PartDesc
	 */
	public String getTab1PartDesc() {
		return tab1PartDesc;
	}
	/**
	 * @param tab1PartDesc the tab1PartDesc to set
	 */
	public void setTab1PartDesc(String tab1PartDesc) {
		this.tab1PartDesc = tab1PartDesc;
	}
	/**
	 * @return the tab1Mli
	 */
	public String getTab1Mli() {
		return tab1Mli;
	}
	/**
	 * @param tab1Mli the tab1Mli to set
	 */
	public void setTab1Mli(String tab1Mli) {
		this.tab1Mli = tab1Mli;
	}
	/**
	 * @return the tab1LineStatus
	 */
	public String getTab1LineStatus() {
		return tab1LineStatus;
	}
	/**
	 * @param tab1LineStatus the tab1LineStatus to set
	 */
	public void setTab1LineStatus(String tab1LineStatus) {
		this.tab1LineStatus = tab1LineStatus;
	}
	/**
	 * @return the tab1CustLineNum
	 */
	public String getTab1CustLineNum() {
		return tab1CustLineNum;
	}
	/**
	 * @param tab1CustLineNum the tab1CustLineNum to set
	 */
	public void setTab1CustLineNum(String tab1CustLineNum) {
		this.tab1CustLineNum = tab1CustLineNum;
	}
	/**
	 * @return the tab1Qty
	 */
	public String getTab1Qty() {
		return tab1Qty;
	}
	/**
	 * @param tab1Qty the tab1Qty to set
	 */
	public void setTab1Qty(String tab1Qty) {
		this.tab1Qty = tab1Qty;
	}
	/**
	 * @return the tab1Uom
	 */
	public String getTab1Uom() {
		return tab1Uom;
	}
	/**
	 * @param tab1Uom the tab1Uom to set
	 */
	public void setTab1Uom(String tab1Uom) {
		this.tab1Uom = tab1Uom;
	}
	/**
	 * @return the tab1ShipDate
	 */
	public String getTab1ShipDate() {
		return tab1ShipDate;
	}
	/**
	 * @param tab1ShipDate the tab1ShipDate to set
	 */
	public void setTab1ShipDate(String tab1ShipDate) {
		this.tab1ShipDate = tab1ShipDate;
	}
	/**
	 * @return the tab1RequestDate
	 */
	public String getTab1RequestDate() {
		return tab1RequestDate;
	}
	/**
	 * @param tab1RequestDate the tab1RequestDate to set
	 */
	public void setTab1RequestDate(String tab1RequestDate) {
		this.tab1RequestDate = tab1RequestDate;
	}
	/**
	 * @return the tab2DfsOrder
	 */
	public String getTab2DfsOrder() {
		return tab2DfsOrder;
	}
	/**
	 * @param tab2DfsOrder the tab2DfsOrder to set
	 */
	public void setTab2DfsOrder(String tab2DfsOrder) {
		this.tab2DfsOrder = tab2DfsOrder;
	}
	/**
	 * @return the tab2BomLevel
	 */
	public String getTab2BomLevel() {
		return tab2BomLevel;
	}
	/**
	 * @param tab2BomLevel the tab2BomLevel to set
	 */
	public void setTab2BomLevel(String tab2BomLevel) {
		this.tab2BomLevel = tab2BomLevel;
	}
	/**
	 * @return the tab2TopLevelPart
	 */
	public String getTab2TopLevelPart() {
		return tab2TopLevelPart;
	}
	/**
	 * @param tab2TopLevelPart the tab2TopLevelPart to set
	 */
	public void setTab2TopLevelPart(String tab2TopLevelPart) {
		this.tab2TopLevelPart = tab2TopLevelPart;
	}
	/**
	 * @return the tab2PartId
	 */
	public String getTab2PartId() {
		return tab2PartId;
	}
	/**
	 * @param tab2PartId the tab2PartId to set
	 */
	public void setTab2PartId(String tab2PartId) {
		this.tab2PartId = tab2PartId;
	}
	/**
	 * @return the tab2PartName
	 */
	public String getTab2PartName() {
		return tab2PartName;
	}
	/**
	 * @param tab2PartName the tab2PartName to set
	 */
	public void setTab2PartName(String tab2PartName) {
		this.tab2PartName = tab2PartName;
	}
	/**
	 * @return the tab2PartType
	 */
	public String getTab2PartType() {
		return tab2PartType;
	}
	/**
	 * @param tab2PartType the tab2PartType to set
	 */
	public void setTab2PartType(String tab2PartType) {
		this.tab2PartType = tab2PartType;
	}

	/**
	 * @return the tab2PartRev
	 */
	public String getTab2PartRev() {
		return tab2PartRev;
	}
	/**
	 * @param tab2PartRev the tab2PartRev to set
	 */
	public void setTab2PartRev(String tab2PartRev) {
		this.tab2PartRev = tab2PartRev;
	}

	/**
	 * @return the tab2PartPolicy
	 */
	public String getTab2PartPolicy() {
		return tab2PartPolicy;
	}
	/**
	 * @param tab2PartPolicy the tab2PartPolicy to set
	 */
	public void setTab2PartPolicy(String tab2PartPolicy) {
		this.tab2PartPolicy = tab2PartPolicy;
	}
	/**
	 * @return the tab2FindNum
	 */
	public String getTab2FindNum() {
		return tab2FindNum;
	}
	/**
	 * @param tab2FindNum the tab2FindNum to set
	 */
	public void setTab2FindNum(String tab2FindNum) {
		this.tab2FindNum = tab2FindNum;
	}
	/**
	 * @return the tab2RefDesignator
	 */
	public String getTab2RefDesignator() {
		return tab2RefDesignator;
	}
	/**
	 * @param tab2RefDesignator the tab2RefDesignator to set
	 */
	public void setTab2RefDesignator(String tab2RefDesignator) {
		this.tab2RefDesignator = tab2RefDesignator;
	}
	/**
	 * @return the tab2CompLocation
	 */
	public String getTab2CompLocation() {
		return tab2CompLocation;
	}
	/**
	 * @param tab2CompLocation the tab2CompLocation to set
	 */
	public void setTab2CompLocation(String tab2CompLocation) {
		this.tab2CompLocation = tab2CompLocation;
	}
	/**
	 * @return the tab2PartDesc
	 */
	public String getTab2PartDesc() {
		return tab2PartDesc;
	}
	/**
	 * @param tab2PartDesc the tab2PartDesc to set
	 */
	public void setTab2PartDesc(String tab2PartDesc) {
		this.tab2PartDesc = tab2PartDesc;
	}
	/**
	 * @return the tab2PartState
	 */
	public String getTab2PartState() {
		return tab2PartState;
	}
	/**
	 * @param tab2PartState the tab2PartState to set
	 */
	public void setTab2PartState(String tab2PartState) {
		this.tab2PartState = tab2PartState;
	}
	/**
	 * @return the tab2PartQty
	 */
	public String getTab2PartQty() {
		return tab2PartQty;
	}
	/**
	 * @param tab2PartQty the tab2PartQty to set
	 */
	public void setTab2PartQty(String tab2PartQty) {
		this.tab2PartQty = tab2PartQty;
	}
	/**
	 * @return the tab2Uom
	 */
	public String getTab2Uom() {
		return tab2Uom;
	}
	/**
	 * @param tab2Uom the tab2Uom to set
	 */
	public void setTab2Uom(String tab2Uom) {
		this.tab2Uom = tab2Uom;
	}
	/**
	 * @return the tab2Usage
	 */
	public String getTab2Usage() {
		return tab2Usage;
	}
	/**
	 * @param tab2Usage the tab2Usage to set
	 */
	public void setTab2Usage(String tab2Usage) {
		this.tab2Usage = tab2Usage;
	}
	/**
	 * @return the tab2PartFamily
	 */
	public String getTab2PartFamily() {
		return tab2PartFamily;
	}
	/**
	 * @param tab2PartFamily the tab2PartFamily to set
	 */
	public void setTab2PartFamily(String tab2PartFamily) {
		this.tab2PartFamily = tab2PartFamily;
	}
	/**
	 * @return the tab2GeTechFeature
	 */
	public String getTab2GeTechFeature() {
		return tab2GeTechFeature;
	}
	/**
	 * @param tab2GeTechFeature the tab2GeTechFeature to set
	 */
	public void setTab2GeTechFeature(String tab2GeTechFeature) {
		this.tab2GeTechFeature = tab2GeTechFeature;
	}
	/**
	 * @return the tab2BomPrefix
	 */
	public String getTab2BomPrefix() {
		return tab2BomPrefix;
	}
	/**
	 * @param tab2BomPrefix the tab2BomPrefix to set
	 */
	public void setTab2BomPrefix(String tab2BomPrefix) {
		this.tab2BomPrefix = tab2BomPrefix;
	}
	/**
	 * @return the tab2CopicsParent
	 */
	public String getTab2CopicsParent() {
		return tab2CopicsParent;
	}
	/**
	 * @param tab2CopicsParent the tab2CopicsParent to set
	 */
	public void setTab2CopicsParent(String tab2CopicsParent) {
		this.tab2CopicsParent = tab2CopicsParent;
	}
	/**
	 * @return the tab2CopicsSuffix
	 */
	public String getTab2CopicsSuffix() {
		return tab2CopicsSuffix;
	}
	/**
	 * @param tab2CopicsSuffix the tab2CopicsSuffix to set
	 */
	public void setTab2CopicsSuffix(String tab2CopicsSuffix) {
		this.tab2CopicsSuffix = tab2CopicsSuffix;
	}
	/**
	 * @return the tab2StEffDt
	 */
	public String getTab2StEffDt() {
		return tab2StEffDt;
	}
	/**
	 * @param tab2StEffDt the tab2StEffDt to set
	 */
	public void setTab2StEffDt(String tab2StEffDt) {
		this.tab2StEffDt = tab2StEffDt;
	}
	/**
	 * @return the tab2EndEffDt
	 */
	public String getTab2EndEffDt() {
		return tab2EndEffDt;
	}
	/**
	 * @param tab2EndEffDt the tab2EndEffDt to set
	 */
	public void setTab2EndEffDt(String tab2EndEffDt) {
		this.tab2EndEffDt = tab2EndEffDt;
	}
	/**
	 * @return the tab2MaterialSpec
	 */
	public String getTab2MaterialSpec() {
		return tab2MaterialSpec;
	}
	/**
	 * @param tab2MaterialSpec the tab2MaterialSpec to set
	 */
	public void setTab2MaterialSpec(String tab2MaterialSpec) {
		this.tab2MaterialSpec = tab2MaterialSpec;
	}
	/**
	 * @return the tab2GeLdpa
	 */
	public String getTab2GeLdpa() {
		return tab2GeLdpa;
	}
	/**
	 * @param tab2GeLdpa the tab2GeLdpa to set
	 */
	public void setTab2GeLdpa(String tab2GeLdpa) {
		this.tab2GeLdpa = tab2GeLdpa;
	}
	
	
}
