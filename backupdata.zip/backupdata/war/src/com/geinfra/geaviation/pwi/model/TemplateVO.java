package com.geinfra.geaviation.pwi.model;


/**
 * 
 * Project : Product Lifecycle Management Date Written : Sep 27, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : TemplateVO - Data transfer object representing a Template record
 * from the database
 * 
 * Revision Log Sep 27, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class TemplateVO extends PWiBaseVO {
	// constant ints to avoid code review "magic number" violation.
	// these are used to generate more-unique hash codes.
	private static final int BIG1231 = 1231;
	private static final int BIG1237 = 1237;
	
	private Integer templateId;
	private String templateName;
	private boolean enabled;
	private String excelFileName;
	private Integer queryId;
	
	public TemplateVO() {
	}

	public Integer getTemplateId() {
		return templateId;
	}

	public void setTemplateId(Integer templateId) {
		this.templateId = templateId;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public String getExcelFileName() {
		return excelFileName;
	}

	public void setExcelFileName(String excelFileName) {
		this.excelFileName = excelFileName;
	}

	public Integer getQueryId() {
		return queryId;
	}

	public void setQueryId(Integer queryId) {
		this.queryId = queryId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (enabled ? BIG1231 : BIG1237);
		result = prime * result
				+ ((excelFileName == null) ? 0 : excelFileName.hashCode());
		result = prime * result + ((queryId == null) ? 0 : queryId.hashCode());
		result = prime * result
				+ ((templateId == null) ? 0 : templateId.hashCode());
		result = prime * result
				+ ((templateName == null) ? 0 : templateName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TemplateVO other = (TemplateVO) obj;
		if (enabled != other.enabled)
			return false;
		if (excelFileName == null) {
			if (other.excelFileName != null)
				return false;
		} else if (!excelFileName.equals(other.excelFileName))
			return false;
		if (queryId == null) {
			if (other.queryId != null)
				return false;
		} else if (!queryId.equals(other.queryId))
			return false;
		if (templateId == null) {
			if (other.templateId != null)
				return false;
		} else if (!templateId.equals(other.templateId))
			return false;
		if (templateName == null) {
			if (other.templateName != null)
				return false;
		} else if (!templateName.equals(other.templateName))
			return false;
		return true;
	}
}
