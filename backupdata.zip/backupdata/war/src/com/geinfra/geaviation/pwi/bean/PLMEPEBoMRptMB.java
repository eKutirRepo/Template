/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEPEBoMRptMB.java
 * @Creation date: 05-Nov-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMEPEBoMData;
import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMEPEBoMServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMEPEBoMRptMB {
	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMEPEBoMRptMB.class);

	/**
	 * Holds the plmEPABoMService
	 */
	private PLMEPEBoMServiceIfc plmEPEBoMService =null;
	
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the commonMB
	 */
	private PLMCommonMB commonMB;
	/**
	 *  Holds the epaBomAlertMsg
	 */
	private String epaBomAlertMsg;		
	/**
	 *  Holds the projectName
	 */
	private String topLvlPartName;
	/**
	 *  Holds the partId
	 */
	private String partId;

	/**
	 *  Holds the topLvlPartList
	 */
	private List<PLMEPEBoMData> topLvlPartList=new ArrayList<PLMEPEBoMData>(); 
	
	/**
	 *  Holds the topLvlPartListCount
	 */
	private int topLvlPartListCount; 
	
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;
	
	/**
	 *  Holds the selPartId
	 */
	private String selPartId="";

	/**
	 *  Holds the selPartNm
	 */
	private String selPartNm;

	/**
	 * Holds user information
	 */
	private PLMPwiUserData userDetails = null;
	
	
	private PLMLoginData userDataObj = (PLMLoginData) PLMUtils
	.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA);

	
	/**
	 * This method is used to load home page of EPE BA BoM  Home page 
	 * 
	 * @return String
	 * @throws PLMCommonException 
	 */
	public String loadEpeBABomHome() {
		LOG.info("Entering loadEpeBABomHome method");
		
		try {
			commonMB.insertCannedRptRecordHitInfo("EPE BA BOM Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		String fwdFlag="epeBABomReport";
		epaBomAlertMsg="";
		topLvlPartName="";
		partId="";
		selPartNm="";
		topLvlPartList =new ArrayList<PLMEPEBoMData>();
	    LOG.info("Exiting loadEpeBABomHome method");
		return fwdFlag;
		
	}
	/**
	 * This method is used for Validating EPE BA BoM User Input
	 * 
	 * @return String
	 */
	public String validateEpeBABoMInput() {		
		LOG.info("Entering validateEpeBABoMInput Method");
		if(PLMUtils.isEmpty(topLvlPartName)){
			epaBomAlertMsg = PLMConstants.EPE_BA_BOM_CRITERIA;
		}else if(PLMUtils.checkSplCharsProjSumry(topLvlPartName)){
			epaBomAlertMsg = PLMConstants.EPE_BA_BOM_SPLCHAR_CRITERIA;
		}
		LOG.info("Exiting validateEpeBABoMInput Method");
		return epaBomAlertMsg;
	}
	
	/**
	 * This method is used for getProjectListDetails
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getProjectListDetails() {
		String fwdFlag = "";
		epaBomAlertMsg = "";
		topLvlPartListCount =0;
		partId="";
		selPartNm="";
		try {
			epaBomAlertMsg = validateEpeBABoMInput();	
	 		if (PLMUtils.isEmpty(epaBomAlertMsg)) {
	 		topLvlPartList =  plmEPEBoMService.getTopLvlPartList(topLvlPartName);
	 		topLvlPartListCount = topLvlPartList.size();
			LOG.info("The number of results from Top Lvl Part List >> "+topLvlPartListCount);
			recordCounts = PLMConstants.N_100;
			  if(topLvlPartListCount==0){
				epaBomAlertMsg =  PLMConstants.EPE_BA_BOM_INVALID_NO_ALERT_MSG;
			  }
		 	}else{
				fwdFlag = "epeBABomReport";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPart: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"epeBABomReport","EPE BA BOM Report");
		} 
		fwdFlag = PLMConstants.EMPTY;
		return fwdFlag;
	}
	
    /**
 	 * This method is used for generateEpeBABomReport
 	 * 
 	 * @return String
 	 * @throws PLMCommonException
     * @throws PWiException 
 	 */
 	public String generateEpeBABomReport() throws PLMCommonException, PWiException{
 		LOG.info("Entering generateEpeBABomReport Method");
 		String fwdFlag = "epeBABomReport";
 		
 		 if(topLvlPartListCount==1){
 			LOG.info("if topLvlPartListCount is single record" );
 			String[] partIdName = topLvlPartList.get(0).getPartId().split("~");
 			partId = partIdName[0];
			LOG.info("partId>>> "+partId);
			selPartNm =partIdName[1];
			LOG.info("selPartNm>>> "+selPartNm);
		  }
 		    
 		 else if(topLvlPartListCount > 1) {
 			String[] partIdName = selPartId.split("~");
 			partId = partIdName[0];
			LOG.info("partId>>> "+partId);
			selPartNm =partIdName[1];
			LOG.info("selPartNm>>> "+selPartNm);
 		   } 
 		 
 		 	userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
 		 
 		    epaBomAlertMsg = epaBomAlertMsg + PLMConstants.EPE_BA_BOM_MAIL_RERORT_ALERT;
			taskExecutor.execute(new MailThread());
 	 	
 		LOG.info("Exiting generateEpeBABomReport Method");
 		return fwdFlag;
 	}
     
        /**
		 * Background Process Thread
		 */
		private class MailThread implements Runnable {
			public MailThread(){}
			public void run() {
				sendEpeBABoMReportMail();
			}
		}
		
		/**
		 * This method is used for Generating & Sending the Report to mail
		 * 
		 * @return String
		 */
		public void sendEpeBABoMReportMail() {
			LOG.info("Entering sendEpeBABoMReportMail Method");
			String selPartNmLcl =selPartNm;
			String from = PLMConstants.LTTR_MAIL_FROM;
			String to = userDetails.getUserEmailId();		
			String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
			toAddressee = "Dear " + toAddressee + ", \n\n";
			String subject = PLMConstants.EPE_BA_BOM_MAIL_SUBJECT + selPartNmLcl;
			StringBuffer mailBody = new StringBuffer().append(toAddressee)
			.append(PLMConstants.EPE_BA_BOM_MAIL_CONTENT)
			.append(selPartNmLcl)
			.append(".")
			.append(PLMConstants.LTTR_MAIL_SIGNATURE)
			.append(PLMConstants.LTTR_MAIL_FOOTER);
			
			StringBuffer mailNoDataBody = new StringBuffer()
			.append(toAddressee)
			.append(PLMConstants.EPE_BA_BOM_NO_CONTENT_BODY)
			.append(selPartNmLcl)
			.append(".")
			.append(PLMConstants.LTTR_MAIL_SIGNATURE)
			.append(PLMConstants.LTTR_MAIL_FOOTER);
			
			final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
			Date uniqDate = new Date();
			String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
			String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
			//String filePathXlsx = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("EPE_BA_BOM_RPT_NM") +  selPartNm + "_" + uniqTime + ".xlsx";
			String filePathCSV = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("EPE_BA_BOM_RPT_NM") +  selPartNmLcl + "_" + uniqTime + ".csv";
			String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("EPE_BA_BOM_RPT_NM") +  selPartNmLcl + "_" + uniqTime + ".zip";
			try {
			   if(!PLMUtils.isEmpty(partId)){
					 Map<String,Object> epeBaBomMap = plmEPEBoMService.getEpeBaBoMReport(partId);
					 List<PLMEPEBoMData> partDataList = (List<PLMEPEBoMData>)epeBaBomMap.get("partDataList");
					 Map<String,List<PLMEPEBoMData>> docRecMap =(Map<String, List<PLMEPEBoMData>>)epeBaBomMap.get("docRecMap");
					
					   if(!PLMUtils.isEmptyList(partDataList)){
						 //saveEpeBaBoMFile(selPartNm,epeBaBomList,fileDir,filePathXlsx);
						 saveEpeBaBoMCSVFile(selPartNmLcl,partDataList,docRecMap,fileDir,filePathCSV);
						 PLMUtils.generateZipFile(filePathCSV,filePathZip);
						 PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
						 
						 docRecMap.clear();
						 partDataList.clear();
						 epeBaBomMap.clear();
					   }else{				
							PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
							LOG.info("No data Mail sent");
						}
				}else{				
					PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
					LOG.info("No data Mail sent");
				}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@sendEpeBABoMReportMail: ", exception);
				PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
			} catch (Exception exception) {
				LOG.log(Level.ERROR, "Exception@sendEpeBABoMReportMail: ", exception);
				PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
			} finally {
				deleteFiles(filePathCSV,filePathZip);
			}
			LOG.info("Mail sent successfully.");
			LOG.info("Exiting sendEpeBABoMReportMail Method");
		}
		
		
		/**
		 * This method is used for saveEpeBaBoMCSVFile
		 * 
		 * @param  partNameLcl, epeBaBomRptList,fileDir,filePathCSV
		 * @throws Exception
		 */
		public void saveEpeBaBoMCSVFile(String partNameLcl,List<PLMEPEBoMData> partDataList,
				Map<String,List<PLMEPEBoMData>> docRecMap,
				String fileDir,String filePathCSV) throws Exception {
			LOG.info("Entering saveEpeBaBoMCSVFile Method");
			FileOutputStream fileOut = null;
			PrintWriter pwriter =null;
			boolean createFileExist;
			try {
				/*File file = new File(fileDir);
				boolean dirExists = file.exists();
				if (!dirExists) {	
					file.mkdir();
				}*/
				File fileName = new File(filePathCSV);
				boolean fileExist = fileName.exists();
				if(!fileExist) {
					createFileExist =fileName.createNewFile();
					LOG.info("createFileExist>>>>.."+createFileExist);
			 	}
				if (fileName.exists()) {
						fileOut = new FileOutputStream(filePathCSV);
						pwriter =  new PrintWriter( new FileWriter(filePathCSV));
						
						
							pwriter.write("Top Level Part");
							pwriter.write(",");
							pwriter.write(partNameLcl);
							pwriter.write("\n");
						
						    pwriter.write("\n");
			 		
						  	pwriter.write("MLI");
				 			pwriter.write(",");
						  	pwriter.write("BOM_PREFIX");
				 			pwriter.write(",");
				 			pwriter.write("PART_BOM_LVL");
				 			pwriter.write(",");
				 			pwriter.write("PARENT_PART");
				 			pwriter.write(",");
				 			pwriter.write("PART_NAME");
				 			pwriter.write(",");
				 			pwriter.write("PART_REV");
				 			pwriter.write(",");
				  			pwriter.write("PART_DESC");
				 			pwriter.write(",");
				 			pwriter.write("PART_STATE");
				 			pwriter.write(",");
				 			pwriter.write("FIND_NUM");
				 			pwriter.write(",");
				 			pwriter.write("QUANTITY");
				 			pwriter.write(",");
				 			pwriter.write("UOM");
				 			pwriter.write(",");
				 			pwriter.write("REPLACEMENT_PART");
				 			pwriter.write(",");
				 			pwriter.write("DOC_BOM_LVL");
				 			pwriter.write(",");
				 			pwriter.write("DOC_PARENT");
				 			pwriter.write(",");
				 			pwriter.write("DOC_NAME");
				 			pwriter.write(",");
				 			pwriter.write("LOGICAL_INDR");
				 			pwriter.write(",");
				 			pwriter.write("DOC_REV");
				 			pwriter.write(",");
				 			pwriter.write("DOC_TYPE");
				 			pwriter.write(",");
				 			pwriter.write("DOC_STATE");
				 			pwriter.write(",");
				 			pwriter.write("DOC_TITLE");
				 			pwriter.write(",");
				 			pwriter.write("DOC_CLASS");
				 			pwriter.write(",");
				 			pwriter.write("DWG_CRITICAL_CODE");
				 			pwriter.write(",");
				 			pwriter.write("EXPORT_CONTROL");
				 			pwriter.write(",");
				 			pwriter.write("MODEL_VALIDATED");
				 			pwriter.write(",");
				 			pwriter.write("MBPD");
				 			
				 			pwriter.write("\n");
				 			if(!PLMUtils.isEmptyList(partDataList)) {
			 		     		
						   		for(int i=0; i<partDataList.size(); i++) {
						   			PLMEPEBoMData dataObj = (PLMEPEBoMData)partDataList.get(i);
						   			
									if(!PLMUtils.isEmpty(dataObj.getDocId())){	
										List<PLMEPEBoMData> docDataList = docRecMap.get(dataObj.getDocId());
										if (!PLMUtils.isEmptyList(docDataList)) {
											Collections.sort(docDataList, new SortEPEDocs());
											
											for (int j=0;j<docDataList.size();j++) {
												
												PLMEPEBoMData docDataObj = docDataList.get(j);
												
												if(dataObj.getMliNew()!= null){
										   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getMliNew()+"\""));
										   		}
									   			pwriter.write(",");
												if(dataObj.getMli()!= null){
										   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getMli()+"\""));
										   		}
									   			pwriter.write(",");
									   			if(dataObj.getPartBomLvl()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(dataObj.getPartBomLvl()));
												}
												pwriter.write(",");
												if(dataObj.getParentPart()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(dataObj.getParentPart()));
												}
												pwriter.write(",");
												if(dataObj.getPartName()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(dataObj.getPartName()));
												}
												pwriter.write(",");
									   			if(dataObj.getPartRev()!= null){
										   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getPartRev()+"\""));
										   		}
									   			pwriter.write(",");
									   			if(dataObj.getPartDesc()!= null){
										   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getPartDesc()));
										   		}
									   			pwriter.write(",");
									   			
									   			if(dataObj.getPartState()!= null){
									   	   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getPartState()));
											   	}
									   			pwriter.write(",");
									   			if(dataObj.getFindNum()!= null){
										   			   pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getFindNum()+"\""));
												 }
												 pwriter.write(",");
												if(dataObj.getQuantity()!= null){
												 pwriter.write(PLMUtils.convertToCsvValue(dataObj.getQuantity()));
												}
												pwriter.write(",");
												if(dataObj.getUom()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(dataObj.getUom()));
												}
												pwriter.write(",");
												if(dataObj.getReplacePart()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(dataObj.getReplacePart()));
												}
												pwriter.write(",");

												//APPENDING DOC ATTRIBUTES
												if(docDataObj.getDocBomLvl()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(docDataObj.getDocBomLvl()));
												}
												pwriter.write(",");
												if(docDataObj.getDocParent()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(docDataObj.getDocParent()));
												}
												pwriter.write(",");
												if(docDataObj.getDocName()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(docDataObj.getDocName()));
												}
												pwriter.write(",");
												if (docDataObj.getDocBomLvl()!=null) {
													if (Integer.parseInt(docDataObj.getDocBomLvl())==1) {
														if (dataObj.getLogicIndr()!=null) {
															pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getLogicIndr()+"\""));
														}
														pwriter.write(",");
													} else {
														if(docDataObj.getLogicIndr()!= null){
															pwriter.write(PLMUtils.convertToCsvValue("=\""+docDataObj.getLogicIndr()+"\""));
														}
														pwriter.write(",");
													}
														
												} 
												
												if(docDataObj.getDocRev()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(docDataObj.getDocRev()));
												}
												pwriter.write(",");
												if(docDataObj.getDocType()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(docDataObj.getDocType()));
												}
												pwriter.write(",");
												if(docDataObj.getDocState()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(docDataObj.getDocState()));
												}
												pwriter.write(",");
												if(docDataObj.getDocTitle()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(docDataObj.getDocTitle()));
												}
												pwriter.write(",");
												if(docDataObj.getDocClass()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(docDataObj.getDocClass()));
												}
												pwriter.write(",");
												if(docDataObj.getDwgCrtlCode()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(docDataObj.getDwgCrtlCode()));
												}
												pwriter.write(",");
												if(docDataObj.getExportCntrl()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(docDataObj.getExportCntrl()));
												}
												pwriter.write(",");
												if(docDataObj.getModelValidated()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(docDataObj.getModelValidated()));
												}
												pwriter.write(",");
												if(docDataObj.getGeMBPD()!= null){
													pwriter.write(PLMUtils.convertToCsvValue(docDataObj.getGeMBPD()));
												}
												pwriter.write("\n");
												
											} // END OF FOR CONDITION FOR ADDING DOCS FOR A PART
											
										} // END OF IF CONDITION FOR DOCS LIST PRESENT FOR A PART
									} else {
										
										if(dataObj.getMliNew()!= null){
								   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getMliNew()+"\""));
								   		}
							   			pwriter.write(",");
										if(dataObj.getMli()!= null){
								   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getMli()+"\""));
								   		}
							   			pwriter.write(",");
							   			if(dataObj.getPartBomLvl()!= null){
											pwriter.write(PLMUtils.convertToCsvValue(dataObj.getPartBomLvl()));
										}
										pwriter.write(",");
										if(dataObj.getParentPart()!= null){
											pwriter.write(PLMUtils.convertToCsvValue(dataObj.getParentPart()));
										}
										pwriter.write(",");
										if(dataObj.getPartName()!= null){
											pwriter.write(PLMUtils.convertToCsvValue(dataObj.getPartName()));
										}
										pwriter.write(",");
							   			if(dataObj.getPartRev()!= null){
								   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getPartRev()+"\""));
								   		}
							   			pwriter.write(",");
							   			if(dataObj.getPartDesc()!= null){
								   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getPartDesc()));
								   		}
							   			pwriter.write(",");
							   			
							   			if(dataObj.getPartState()!= null){
							   	   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getPartState()));
									   	}
							   			pwriter.write(",");
							   			if(dataObj.getFindNum()!= null){
								   			   pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getFindNum()+"\""));
										 }
										 pwriter.write(",");
										if(dataObj.getQuantity()!= null){
										 pwriter.write(PLMUtils.convertToCsvValue(dataObj.getQuantity()));
										}
										pwriter.write(",");
										if(dataObj.getUom()!= null){
											pwriter.write(PLMUtils.convertToCsvValue(dataObj.getUom()));
										}
										pwriter.write(",");
										if(dataObj.getReplacePart()!= null){
											pwriter.write(PLMUtils.convertToCsvValue(dataObj.getReplacePart()));
										}
										pwriter.write(",");
										
										//DOC BOM LEVEL
										pwriter.write("");
										pwriter.write(",");
										
										//DOC PARENT
										pwriter.write("");
										pwriter.write(",");
										
										//DOC NAME
										pwriter.write("");
										pwriter.write(",");
										
										//LOGICAL INDICATOR
										pwriter.write("");
										pwriter.write(",");
										
										//DOC REV
										pwriter.write("");
										pwriter.write(",");
										
										//DOC TYPE
										pwriter.write("");
										pwriter.write(",");
										
										//DOC STATE
										pwriter.write("");
										pwriter.write(",");
										
										//DOC TITLE
										pwriter.write("");
										pwriter.write(",");
										
										//DOC CLASS
										pwriter.write("");
										pwriter.write(",");
										
										//DWG CRITICAL CODE
										pwriter.write("");
										pwriter.write(",");
										
										//EXPORT CONTROL
										pwriter.write("");
										pwriter.write(",");
										
										//MODEL VALIDATED
										pwriter.write("");
							   			pwriter.write(",");
							   			
							   			//MBPD 
										pwriter.write("");
							   			pwriter.write("\n");

							   			
									} // END OF ELSE CONDITION FOR DOC ID NOT AVAILABLE FOR A PART
						   			
						   		}//END OF FOR LOOP FOR PART RECORDS
						   		
				 			} // END OF IF CONDITION FOR PART LIST EMPTY	
						  
					}//END OF IF FOR FILE NAME EXIST
					
				} catch (FileNotFoundException e) {
					LOG.log(Level.ERROR, "Exception@saveEpeBaBoMCSVFile: ", e);
					throw e;
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@saveEpeBaBoMCSVFile: ", e);
					throw e;
				}  finally {
					try {
						if (pwriter !=null) {
							pwriter.close();
						}
						if (fileOut != null) {
							fileOut.close();
						}
					} catch (IOException e) {
						LOG.log(Level.ERROR, "Exception@saveEpeBaBoMCSVFile: ", e);
						throw e;
					}
				}
				LOG.info("Exiting saveEpeBaBoMCSVFile Method");
			}
			
		/**
		 * 
		 * class to sort list of object of type PLMEPABoMData
		 * 
		 */
		private static class SortEPEDocs implements Comparator<PLMEPEBoMData>,
				Serializable {
			/**
			 * long serialVersionUID
			 */
			private static final long serialVersionUID = 1L;

			/**
			 * used for comparision..
			 */
			public int compare(PLMEPEBoMData aString,
					PLMEPEBoMData bString) {
				
				return aString.getDocBomLvl().compareTo(bString.getDocBomLvl());
			   
			}
		}
		
		/**
		 * This method is used for Deleting zip file and xls file
		 * 
		 * @return void
		 */
		public void deleteFiles(String filePathXls,String filePathZip){
			LOG.info("Entering deleteFiles method");
			boolean zipFileExist;
			boolean xlsFileExist;
			File zipFile = new File(filePathZip);
			zipFileExist = zipFile.exists();
			File xlsFile = new File(filePathXls);
			xlsFileExist = xlsFile.exists();
			if(zipFileExist){
				boolean deleted = zipFile.delete();
				LOG.info("Successfully deleted zip file : " + deleted);
			}
			if(xlsFileExist){
				boolean deleted = xlsFile.delete();
				LOG.info("Successfully deleted xls file : " + deleted);
			}
			LOG.info("Exiting deleteFiles Method");
		}
		/**
		 * This method is used for Bordering Cell in XLSX
		 * 
		 * @return StringBuffer
		 */
		private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
			style.setBorderTop(XSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			style.setBorderRight(XSSFCellStyle.BORDER_THIN);
			return style;
		}
		/**
		 * This method is used for Generating Report in XLS
		 * 
		 * @return StringBuffer
		 */
		
		public void saveEpeBaBoMFile(String partNameLcl,List<PLMEPEBoMData> epeBaBomRptList,String fileDir,String filePathXlsx) throws IOException {
			LOG.info("Entering saveEpeBaBoMFile Method");
			FileOutputStream fileOut = null;
			boolean createFileExist;
			try {
				/*File file = new File(fileDir);
				boolean dirExists = file.exists();
				if (!dirExists) {	
					file.mkdir();
				}*/
				File fileName = new File(filePathXlsx);
				boolean fileExist = fileName.exists();
				if(!fileExist) {
					createFileExist =fileName.createNewFile();
					LOG.info("createFileExist>>>>.."+createFileExist);
			 	}
				if (fileName.exists()) {
					fileOut = new FileOutputStream(filePathXlsx);
					SXSSFWorkbook workbook = new SXSSFWorkbook();
					SXSSFSheet sheet =  (SXSSFSheet) workbook.createSheet("EPE BA BOM Report");
					XSSFCellStyle headerStyle = (XSSFCellStyle) workbook.createCellStyle();
					
					headerStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
					headerStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
					headerStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
					headerStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
					headerStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex()); 
					headerStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
					XSSFFont font = (XSSFFont) workbook.createFont(); 
					font.setFontName(PLMConstants.EXCEL_FONT_NAME);
					font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
					font.setFontHeightInPoints((short)10);
					headerStyle.setFont(font);
					headerStyle = setBorderStyle(headerStyle);
					
					XSSFCellStyle cellBoldStyle = (XSSFCellStyle) workbook.createCellStyle();
					cellBoldStyle = setBorderStyle(cellBoldStyle);
					cellBoldStyle.setFont(font);
					
					XSSFCellStyle cellBoldStyleCenter = (XSSFCellStyle) workbook.createCellStyle();
					cellBoldStyleCenter = setBorderStyle(cellBoldStyle);
					cellBoldStyleCenter.setFont(font);
					cellBoldStyleCenter.setAlignment(CellStyle.ALIGN_LEFT);
				
					
					XSSFFont nonBoldFont = (XSSFFont) workbook.createFont();
					nonBoldFont.setFontHeightInPoints((short)10);
					nonBoldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
					XSSFCellStyle contentStyle = (XSSFCellStyle) workbook.createCellStyle();				
					contentStyle = setBorderStyle(contentStyle);
					contentStyle.setFont(nonBoldFont);
					contentStyle.setAlignment(CellStyle.ALIGN_LEFT);
					int rowcount = -1;
						SXSSFRow row = (SXSSFRow)sheet.createRow(++rowcount);
						SXSSFCell cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						cell.setCellValue("Top Level Part");
						cell.setCellStyle(cellBoldStyle);

						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellValue(selPartNm);
						cell.setCellStyle(contentStyle);
						String[] columnNames = {"MLI","PART_BOM_LVL","PARENT_PART","PART_NAME","PART_REV","PART_DESC","PART_STATE","FIND_NUM",
								"QUANTITY","UOM","REPLACEMENT_PART","DOC_BOM_LVL","DOC_PARENT","DOC_NAME","LOGICAL_INDR","DOC_REV",
								"DOC_TYPE","DOC_STATE","DOC_TITLE","DOC_CLASS","DWG_CRITICAL_CODE","EXPORT_CONTROL"};
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
						for (int i = 0 ; i < columnNames.length; i++) {
								cell = (SXSSFCell) row.createCell(i);
								cell. setCellValue(columnNames[i]);
								cell.setCellStyle(cellBoldStyleCenter);
							}
						     for(int j=0;j<epeBaBomRptList.size();j++){	
						    	 PLMEPEBoMData dataObj1 = (PLMEPEBoMData) epeBaBomRptList.get(j);
									row = (SXSSFRow) sheet.createRow(++rowcount);
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ZERO);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getMli());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getPartBomLvl());
								
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWO);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getParentPart());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THREE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getPartName());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOUR);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getPartRev());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIVE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getPartDesc());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SIX);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getPartState());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SEVEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getFindNum());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_EIGHT);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getQuantity());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_NINE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getUom());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getReplacePart());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getDocBomLvl());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWELVE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getDocParent());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getDocName());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getLogicIndr());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getDocRev());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getDocType());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getDocState());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_EIGHTEEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getDocTitle());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_NINETEEN);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getDocClass());
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTY);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getDwgCrtlCode());
									
									
									cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYONE);
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj1.getExportCntrl());
								}
						     
						short colWidth2 = (short)4000;
						short colWidth4 = (short)4900;
						short colWidth5 = (short)5600;
						short colWidth6 = (short)6900;
						short colWidth7 = (short)9500;
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,colWidth4);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,colWidth2);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,colWidth5);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,colWidth6);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,colWidth6);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,colWidth7);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,colWidth6);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,colWidth6);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,colWidth6);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE,colWidth6);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN,colWidth6);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN,colWidth2);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWELVE,colWidth4);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTEEN,colWidth6);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTEEN,colWidth6);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTEEN,colWidth6);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIXTEEN,colWidth7);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVENTEEN,colWidth2);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHTEEN,colWidth7);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINETEEN,colWidth6);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTY,colWidth6);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYONE,colWidth6);
						
						
					workbook.write(fileOut);
					fileOut.close();
				}
			} catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@saveEpeBaBoMFile: ", e);
				throw e;
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveEpeBaBoMFile: ", e);
				throw e;
			}  finally {
				try {
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@saveEpeBaBoMFile: ", e);
					throw e;
				}
			}
			LOG.info("Exiting saveEpeBaBoMFile Method");
		}

	
	/**
		 * @return the plmEPEBoMService
		 */
		public PLMEPEBoMServiceIfc getPlmEPEBoMService() {
			return plmEPEBoMService;
		}
		/**
		 * @param plmEPEBoMService the plmEPEBoMService to set
		 */
		public void setPlmEPEBoMService(PLMEPEBoMServiceIfc plmEPEBoMService) {
			this.plmEPEBoMService = plmEPEBoMService;
		}
	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}
	
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the epaBomAlertMsg
	 */
	public String getEpaBomAlertMsg() {
		return epaBomAlertMsg;
	}
	/**
	 * @param epaBomAlertMsg the epaBomAlertMsg to set
	 */
	public void setEpaBomAlertMsg(String epaBomAlertMsg) {
		this.epaBomAlertMsg = epaBomAlertMsg;
	}
	
	
	/**
	 * @return the partId
	 */
	public String getPartId() {
		return partId;
	}
	/**
	 * @param partId the partId to set
	 */
	public void setPartId(String partId) {
		this.partId = partId;
	}
	
	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}
	
	public void setRecordCounts(int recordCounts) {
		LOG.info("::::::::::::::::::" + recordCounts);
		PLMUtils.getServletSession(true).setAttribute("RecDropDown",
				recordCounts);
		this.recordCounts = recordCounts;
	}
	/**
	 * @return the selPartId
	 */
	public String getSelPartId() {
		return selPartId;
	}
	/**
	 * @param selPartId the selPartId to set
	 */
	public void setSelPartId(String selPartId) {
		this.selPartId = selPartId;
	}
	/**
	 * @return the selPartNm
	 */
	public String getSelPartNm() {
		return selPartNm;
	}
	/**
	 * @param selPartNm the selPartNm to set
	 */
	public void setSelPartNm(String selPartNm) {
		this.selPartNm = selPartNm;
	}
	/**
	 * @return the topLvlPartName
	 */
	public String getTopLvlPartName() {
		return topLvlPartName;
	}
	/**
	 * @param topLvlPartName the topLvlPartName to set
	 */
	public void setTopLvlPartName(String topLvlPartName) {
		this.topLvlPartName = topLvlPartName;
	}
	/**
	 * @return the topLvlPartList
	 */
	public List<PLMEPEBoMData> getTopLvlPartList() {
		return topLvlPartList;
	}
	/**
	 * @param topLvlPartList the topLvlPartList to set
	 */
	public void setTopLvlPartList(List<PLMEPEBoMData> topLvlPartList) {
		this.topLvlPartList = topLvlPartList;
	}
	/**
	 * @return the topLvlPartListCount
	 */
	public int getTopLvlPartListCount() {
		return topLvlPartListCount;
	}
	/**
	 * @param topLvlPartListCount the topLvlPartListCount to set
	 */
	public void setTopLvlPartListCount(int topLvlPartListCount) {
		this.topLvlPartListCount = topLvlPartListCount;
	}
	
	
	
}
