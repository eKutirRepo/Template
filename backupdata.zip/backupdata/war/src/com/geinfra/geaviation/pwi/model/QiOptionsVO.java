package com.geinfra.geaviation.pwi.model;

import com.geinfra.geaviation.pwi.json.JsonBuilder;
import com.geinfra.geaviation.pwi.json.Jsonable;
import com.geinfra.geaviation.pwi.util.collections.Predicate;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Sep 27, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : TemplateVO - Data transfer object representing a Template
 * record from the database
 * 
 * Revision Log Sep 27, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class QiOptionsVO extends PWiBaseVO implements Jsonable {
	public static final String TABLE = "PLMR.PWi_DEFAULT_QI_OPTIONS";
	public static final String COLUMN_DFLT_QI_OPTN_SEQ_ID = "DFLT_QI_OPTN_SEQ_ID";
	public static final String COLUMN_SSO_ID = "SSO_ID";
	public static final String COLUMN_OBJ_TYP_SEQ_ID = "OBJ_TYP_SEQ_ID";
	public static final String COLUMN_QRY_SEQ_ID = "QRY_SEQ_ID";
	public static final String COLUMN_ORDER_INDEX = "ORDER_INDEX";
	public static final String COLUMN_QRY_SELECTED = "QRY_SELECTED";
	public static final String COLUMN_COLLAPSE_RESULT = "COLLAPSE_RESULT";

	/**
	 * predicate to determine if a QiOptionsVO has the given objectTypeId
	 */
	public static class HasObjectType implements Predicate<QiOptionsVO> {
		private Integer objectTypeId;

		public HasObjectType(Integer objectTypeId) {
			this.objectTypeId = objectTypeId;
		}

		public boolean apply(QiOptionsVO option) {
			if (objectTypeId.equals(option.getObjectTypeId())) {
				return true;
			}
			return false;
		}
	}

	/**
	 * Predicate to determine if a QiOptionsVO has the given objectTypeId and the
	 * given queryId
	 */
	public static class HasObjectTypeAndQuery implements Predicate<QiOptionsVO> {
		private Integer objectTypeId;
		private Integer queryId;

		public HasObjectTypeAndQuery(Integer objectTypeId, Integer queryId) {
			this.objectTypeId = objectTypeId;
			this.queryId = queryId;
		}

		public boolean apply(QiOptionsVO option) {
			if (objectTypeId.equals(option.getObjectTypeId())
					&& queryId.equals(option.getQueryId())) {
				return true;
			}
			return false;
		}
	}

	private Integer defaultQiOptionsId;
	private Integer objectTypeId;
	private Integer queryId;
	private boolean querySelected;
	private boolean collapseResult;
	private Integer orderIndex;

	public QiOptionsVO() {
	}

	public QiOptionsVO(QiOptionsVO qiOption) {
		this.defaultQiOptionsId = qiOption.getDefaultQiOptionsId();
		this.objectTypeId = qiOption.getObjectTypeId();
		this.queryId = qiOption.getQueryId();
		this.querySelected = qiOption.isQuerySelected();
		this.collapseResult = qiOption.isCollapseResult();
		this.orderIndex = qiOption.getOrderIndex();
	}

	public QiOptionsVO(Integer defaultQiOptionsId, Integer objectTypeId,
			Integer queryId, boolean querySelected, boolean collapseResult,
			Integer orderIndex) {
		this.defaultQiOptionsId = defaultQiOptionsId;
		this.objectTypeId = objectTypeId;
		this.queryId = queryId;
		this.querySelected = querySelected;
		this.collapseResult = collapseResult;
		this.orderIndex = orderIndex;
	}

	public Integer getDefaultQiOptionsId() {
		return defaultQiOptionsId;
	}

	public Integer getObjectTypeId() {
		return objectTypeId;
	}

	public Integer getQueryId() {
		return queryId;
	}

	public boolean isQuerySelected() {
		return querySelected;
	}

	public boolean isCollapseResult() {
		return collapseResult;
	}

	public Integer getOrderIndex() {
		return orderIndex;
	}

	public void setDefaultQiOptionsId(Integer defaultQiOptionsId) {
		this.defaultQiOptionsId = defaultQiOptionsId;
	}

	public void setObjectTypeId(Integer objectTypeId) {
		this.objectTypeId = objectTypeId;
	}

	public void setQueryId(Integer queryId) {
		this.queryId = queryId;
	}

	public void setQuerySelected(boolean querySelected) {
		this.querySelected = querySelected;
	}

	public void setCollapseResult(boolean collapseResult) {
		this.collapseResult = collapseResult;
	}

	public void setOrderIndex(Integer orderIndex) {
		this.orderIndex = orderIndex;
	}

	public String toJson() {
		JsonBuilder builder = new JsonBuilder();
		builder.startObject();
		builder.addStringProperty("id", defaultQiOptionsId);
		builder.addStringProperty("objectTypeId", objectTypeId);
		builder.addStringProperty("queryId", queryId);
		builder.addBooleanProperty("selected", querySelected);
		builder.addBooleanProperty("collapseResult", collapseResult);
		if (orderIndex != null) {
			builder.addNumberProperty("orderIndex", orderIndex.intValue());
		}
		builder.endObject();
		return builder.toString();
	}
}
