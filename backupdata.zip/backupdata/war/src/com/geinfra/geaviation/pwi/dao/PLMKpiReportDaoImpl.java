/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMIssuesReportDaoImpl.java
 * @Creation date: 26-Oct-2010
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Serializable;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import com.geinfra.geaviation.pwi.data.PLMEcoSearchData;
import com.geinfra.geaviation.pwi.data.PLMEcrSearchData;
import com.geinfra.geaviation.pwi.data.PLMIssuesReportData;
import com.geinfra.geaviation.pwi.data.PLMTaskSearchData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMQueryConstants;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

/**
 * PLMIssuesReportDaoImpl is the DAO implementation class.
 */
public class PLMKpiReportDaoImpl extends SimpleJdbcDaoSupport implements
		PLMKpiReportDaoIfc {

	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger
			.getLogger(PLMKpiReportDaoImpl.class);
	/**
	 * Holds the datefrmt
	 */
	private static DateFormat datefrmt = new SimpleDateFormat("yyyy-MM-dd");

	/**
	 * Holds the DATE FORMAT
	 */

	private static final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat(
			"MM/dd/yyyy h:mm:ss a");
	/**
	 * Holds the oldTaskName
	 */
	private String oldTaskName = null;
	/**
	 * Holds the oldIndicator
	 */
	private String oldIndicator = null;
	/**
	 * Holds the str
	 */
	/* public static String str = ""; */
	/**
	 * Holds the oldPredIndicator
	 */
	// public static String oldPredIndicator = null;
	/**
	 * Holds the rowVar
	 */
	// private static int rowVar = 0;
	private static final AtomicInteger rowVar = new AtomicInteger();
	/**
	 * Holds the listCount
	 */
	/* private static int listCount = 0; */
	private static final AtomicInteger listCount = new AtomicInteger();
	/**
	 * Holds the availableId
	 */

	/* public static List<String> availableId = null; */
	/**
	 * Holds the visited
	 */
	// public static boolean visited = false;

	/**
	 * Holds the taskDataMap
	 */
	private Map<String, PLMTaskSearchData> taskDataMap = new HashMap<String, PLMTaskSearchData>();
	/**
	 * Holds the selectedIdList
	 */
	private Map<String, String> selectedIdList = new HashMap<String, String>();
	/**
	 * Holds the plmArLst
	 */
	private List<PLMTaskSearchData> plmArLst = new ArrayList<PLMTaskSearchData>();

	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle
			.getBundle("com.geinfra.geaviation.pwi.resources.Reports");

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public NamedParameterJdbcTemplate getNamedJdbcTemplate() {
		if (namedParameterJdbcTemplate == null) {
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		} else {
			return namedParameterJdbcTemplate;
		}

	}

	/**
	 * This method is used for getIssuesData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMIssuesReportData> getIssuesData(StringBuffer searchResultsQry, StringBuffer appendWhereClause)
			throws PLMCommonException {

		List<PLMIssuesReportData> searchResultList = null;
		String timeStamp = PLMUtils.volTableFormatTime();
		String VT_ISSUE_NEW_REQ = PLMConstants.VT_ISSUE_NEW_REQ.concat(timeStamp);
		String VT_ISSUE_REQ_DTL = PLMConstants.VT_ISSUE_REQ_DTL.concat(timeStamp);
		try {
			
			String createVtIssueNewReq = (PLMSearchQueries.CREATE_VT_ISSUE_NEW_REQ1 + appendWhereClause + PLMSearchQueries.CREATE_VT_ISSUE_NEW_REQ2)
					.replace(PLMConstants.VT_ISSUE_NEW_REQ, VT_ISSUE_NEW_REQ);
			LOG.info("Executing createVtIssueNewReq Query : "
					+ createVtIssueNewReq + "\n");
			getJdbcTemplate().execute(createVtIssueNewReq);
			
			String createVtIssueNewReqDtl = PLMSearchQueries.CREATE_VT_ISSUE_NEW_REQ_DTL
					.replace(PLMConstants.VT_ISSUE_NEW_REQ, VT_ISSUE_NEW_REQ)
					.replace(PLMConstants.VT_ISSUE_REQ_DTL, VT_ISSUE_REQ_DTL);
			LOG.info("Executing createVtIssueNewReqDtl Query : "
					+ createVtIssueNewReqDtl + "\n");
			getJdbcTemplate().execute(createVtIssueNewReqDtl);
			
			LOG.info("Issue Search Query : " + searchResultsQry);
			searchResultList = getSimpleJdbcTemplate().query(
					searchResultsQry.toString().replace(PLMConstants.VT_ISSUE_REQ_DTL, VT_ISSUE_REQ_DTL), new IssuesMapper());
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return searchResultList;
	}

	/**
	 * Row mapper for getting issuesMapper
	 */

	// private static ParameterizedRowMapper<PLMIssuesReportData> issuesMapper =
	// new ParameterizedRowMapper<PLMIssuesReportData>() {
	private static final class IssuesMapper implements
			ParameterizedRowMapper<PLMIssuesReportData> {
		public PLMIssuesReportData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMIssuesReportData searchData = new PLMIssuesReportData();
			searchData.setId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ID)));
			searchData.setName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.NAME)));
			searchData.setDesc(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DESC)));
			searchData.setState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.STATE)));
			searchData.setOwner(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.OWNER)));
			searchData.setOwnerName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.OWNERNAME)));
			searchData.setOrig_nator(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ORIG_NATOR)));
			searchData.setOriginatorName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ORIGINATORNAME)));

			searchData.setOrig_date_from(rs.getDate(PLMConstants.ORIG));
			if (PLMUtils.isEmptyDate(rs.getTimestamp(PLMConstants.ORIG))) {
				searchData.setOrig_date_from_excel("");
			} else {
				searchData.setOrig_date_from_excel(DATE_FORMAT_PROC.format(rs
						.getTimestamp(PLMConstants.ORIG)));
			}

			searchData.setEstim_date_from(rs.getDate(PLMConstants.ESTIM));
			if (PLMUtils.isEmptyDate(rs.getTimestamp(PLMConstants.ESTIM))) {
				searchData.setEstim_date_from_excel("");
			} else {
				searchData.setEstim_date_from_excel(DATE_FORMAT_PROC.format(rs
						.getTimestamp(PLMConstants.ESTIM)));
			}

			searchData.setAct_date_from(rs.getDate(PLMConstants.ACT_FINISH));
			if (PLMUtils.isEmptyDate(rs.getTimestamp(PLMConstants.ACT_FINISH))) {
				searchData.setAct_date_from_excel("");
			} else {
				searchData.setAct_date_from_excel(DATE_FORMAT_PROC.format(rs
						.getTimestamp(PLMConstants.ACT_FINISH)));
			}

			searchData.setPriority(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PRIO)));
			searchData.setInt_priority(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.INT_PRI)));
			searchData.setCatg(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CATG)));
			searchData.setClas_fication(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CLAS_FICATION)));
			searchData.setProblem_type(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PROBLEM_TYPE)));
			searchData.setResp_Org(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.RESP_ORG)));
			searchData.setSource_sys(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.SOURCE_SYS)));
			searchData.setActionTaken(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ACTION_TAKEN)));
			searchData.setLastStateChange(rs.getDate(PLMConstants.LAST_STATE_CHANGE));
			if (PLMUtils.isEmptyDate(rs.getTimestamp(PLMConstants.LAST_STATE_CHANGE))) {
				searchData.setLastStateChange_excel("");
			} else {
				searchData.setLastStateChange_excel(DATE_FORMAT_PROC.format(rs
						.getTimestamp(PLMConstants.LAST_STATE_CHANGE)));
			}
			searchData.setReportdObjNmStr(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.REPORTED_OBJ_NM_LST)));
			if(searchData.getReportdObjNmStr().length()>0)
			{
				searchData.setReportdObjNmLst(PLMUtils.convertStringToList(searchData.getReportdObjNmStr()));
			}
			searchData.setReportdObjIdStr(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.REPORTED_OBJ_ID_LST)));
			if(searchData.getReportdObjNmStr().length()>0)
			{
				searchData.setReportdObjIdLst(PLMUtils.convertStringToList(searchData.getReportdObjIdStr()));
			}
			return searchData;

		}
		// };
	}

	@SuppressWarnings("unchecked")
	/**
	 * This method is used for getDropDownvalues
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getDropDownvalues()
			throws PLMCommonException {
		Map<String, List<SelectItem>> dropdownlist = new HashMap<String, List<SelectItem>>();
		List<SelectItem> category = null;
		List<SelectItem> severity = null;
		List<SelectItem> state = null;
		List<SelectItem> rdo = null;

		try {
			category = getJdbcTemplate().query(
					PLMSearchQueries.GET_DROP_VALUE_CC, new DropMapper());
			severity = getJdbcTemplate().query(
					PLMSearchQueries.GET_DROP_VALUE_SV,
					new DropMapperseverity());
			state = getJdbcTemplate().query(PLMSearchQueries.GET_DROP_VALUE_ST,
					new DropMapperstate());
			rdo = getJdbcTemplate().query(PLMSearchQueries.GET_DROP_VALUE_RDO,
					new DropMapperrdo());


			dropdownlist.put("category", category);
			dropdownlist.put("severity", severity);
			dropdownlist.put("state", state);
			dropdownlist.put("rdo", rdo);
			
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return dropdownlist;
	}

	/**
	 * Row mapper for getting dropMapper
	 */
	// private static ParameterizedRowMapper<SelectItem> dropMapper = new
	// ParameterizedRowMapper<SelectItem>() {
	private static final class DropMapper implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(
					rs.getString(PLMConstants.ECOCATEG));

			return selectItem;

		}
		// };
	}

	/**
	 * Row mapper for getting dropMapperseverity
	 */
	// private static ParameterizedRowMapper<SelectItem> dropMapperseverity =
	// new ParameterizedRowMapper<SelectItem>() {
	private static final class DropMapperseverity implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(
					rs.getString(PLMConstants.SEV_RITY));

			return selectItem;

		}
		// };
	}

	/**
	 * Row mapper for getting dropMapperstate
	 */
	// private static ParameterizedRowMapper<SelectItem> dropMapperstate = new
	// ParameterizedRowMapper<SelectItem>() {
	private static final class DropMapperstate implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(
					rs.getString(PLMConstants.EC_STATE));

			return selectItem;

		}
		// };
	}
	
	/**
	 * Row mapper for getting dropMapperstate
	 */
	// private static ParameterizedRowMapper<SelectItem> dropMapperstate = new
	// ParameterizedRowMapper<SelectItem>() {
	private static final class DropMapperrdo implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(
					rs.getString(PLMConstants.RDO));

			return selectItem;

		}
		// };
	}

	/**
	 * This method is used for getEcoSearchData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoSearchData> getEcoSearchData(StringBuffer searchResultsQry)
			throws PLMCommonException {

		List<PLMEcoSearchData> SearchResultList = null;
		try {
			SearchResultList = getSimpleJdbcTemplate().query(
					searchResultsQry.toString(), new EcoSearchMapper());
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return SearchResultList;
	}

	/**
	 * Row mapper for getting ecoSearchMapper
	 */

	// private static ParameterizedRowMapper<PLMEcoSearchData> ecoSearchMapper =
	// new ParameterizedRowMapper<PLMEcoSearchData>() {
	private static final class EcoSearchMapper implements
			ParameterizedRowMapper<PLMEcoSearchData> {
		public PLMEcoSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			PLMEcoSearchData searchData = new PLMEcoSearchData();
			searchData.setEcoName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECONAME)));
			searchData.setEcoRev(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECOREV)));
			searchData.setEcoOwner(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECOOWNER)));
			searchData.setEcoOwnerName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECOOWNERNAME)));
			searchData.setEcoOriginator(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECO_ORIGIN)));
			searchData.setEcoOriginatorName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECO_ORIGIN_NAME)));
			searchData.setEcoDesc(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECODESC)));
			searchData.setRdo(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.RDO_ISSUES)));
			searchData.setEcoState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECOSTATE)));
			searchData.setEcoSev(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECOSEV)));
			searchData.setEcoDesginEngr(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECODESGINENGR)));
			searchData.setEcoDesignEngrName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECODESGINENGRNAME)));
			searchData.setEcoMfgEngr(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECOMFGENGR)));
			searchData.setEcoMfgEngrName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECOMFGENGRNAME)));
			searchData.setTask_count(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_COUNT)));
			searchData.setRoute_count(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ROUTE_COUNT)));
			// searchData.setDwg_count(PLMUtils.checkNullVal(rs.getString(PLMConstants.DRG_COUNT)));
			searchData.setEco_orig_date(rs.getDate(PLMConstants.ECO_ORIG_DATE));
			searchData.setFastTrackEco(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECO_FAST_TRACK)));
			searchData.setXlecoCategChng(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECOCATEG)));
			searchData.setXlecoRlseDt(rs.getDate(PLMConstants.ECO_REL_DATE));
			searchData.setXldpoCount(rs.getInt(PLMConstants.DPO_COUNT));
			searchData
					.setXlugModelCount(rs.getInt(PLMConstants.UG_MODEL_COUNT));
			searchData.setXlprodParts(rs.getInt(PLMConstants.PROD_PARTS));
			searchData.setXldevParts(rs.getInt(PLMConstants.DEV_PARTS));
			searchData.setMbpdPartCount(rs.getString(PLMConstants.MBPD_PART_CNT));
			searchData.setMbpdModelCount(rs.getString(PLMConstants.MBPD_MODEL_CNT));
			searchData.setMbpdPartCnt(Integer.parseInt(searchData.getMbpdPartCount()));
			searchData.setMbpdModelCnt(Integer.parseInt(searchData.getMbpdModelCount()));
			return searchData;
		}
		// };
	}

	/**
	 * This method is used for getEcrSearchData
	 * 
	 * @param searchResultsQry
	 * @return ICMSearchData
	 * @throws PLMCommonException
	 */
	public List<PLMEcrSearchData> getEcrSearchData(StringBuffer searchResultsQry)
			throws PLMCommonException {

		List<PLMEcrSearchData> ecrSearchResultList = null;
		try {
			ecrSearchResultList = getSimpleJdbcTemplate().query(
					searchResultsQry.toString(), new EcrSearchMapper());
			LOG.info("ECR Search Results List size : "
					+ ecrSearchResultList.size());
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return ecrSearchResultList;
	}

	/**
	 * Row mapper for getting ecrSearchMapper
	 */

	// private static ParameterizedRowMapper<PLMEcrSearchData> ecrSearchMapper =
	// new ParameterizedRowMapper<PLMEcrSearchData>() {
	private static final class EcrSearchMapper implements
			ParameterizedRowMapper<PLMEcrSearchData> {
		public PLMEcrSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			PLMEcrSearchData ecrSearchData = new PLMEcrSearchData();
			ecrSearchData.setEcrName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_NAME)));
			ecrSearchData.setEcrRevision(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_REVISION)));
			ecrSearchData.setEcrOwner(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_OWNER)));
			ecrSearchData.setEcrOwnerName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_OWNER_NAME)));
			ecrSearchData.setEcrOriginator(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_ORIGINATOR)));
			ecrSearchData.setEcrOriginatorName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_ORIGINATOR_NAME)));
			ecrSearchData.setEcrdesc(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_DESCRIPTION)));
			ecrSearchData.setEcrState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_STATE)));
			ecrSearchData.setEcrSev(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_SEVIRITY)));
			ecrSearchData.setEcrCategChng(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_CATEGORY_CHANGE)));
			ecrSearchData.setEcrevaluator(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_EVALUATOR)));
			ecrSearchData.setEcocount(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECO_COUNT)));
			ecrSearchData.setResdesigneng(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DESIGN_ENGR)));
			ecrSearchData.setResdesignengName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DESIGN_ENGR_NAME)));
			ecrSearchData.setCcbchair(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CCB_CHAIRMAN)));
			ecrSearchData.setCcbChairmanName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CCB_CHAIRMAN_NAME)));
			return ecrSearchData;

		}
		// };
	}

	@SuppressWarnings("unchecked")
	/**
	 * This method is used for getDropDownvaluesecr
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getDropDownvaluesecr()
			throws PLMCommonException {
		Map<String, List<SelectItem>> dropdownlist = new HashMap<String, List<SelectItem>>();
		List<SelectItem> ecrstateLst = null;
		List<SelectItem> ecrcategoryLst = null;
		List<SelectItem> ecrsevList = null;

		try {
			ecrstateLst = getJdbcTemplate().query(
					PLMSearchQueries.GET_ECR_STATE, new EcrstateMapper());
			Collections.sort(ecrstateLst, new PLMUtils.SortListSelItmLbl());
			ecrcategoryLst = getJdbcTemplate().query(
					PLMSearchQueries.GET_ECR_CATEGORY, new EcrcategoryMapper());
			Collections.sort(ecrcategoryLst, new PLMUtils.SortListSelItmLbl());

			ecrsevList = getJdbcTemplate().query(PLMSearchQueries.GET_ECR_SEV,
					new Ecrservmapper());
			Collections.sort(ecrsevList, new PLMUtils.SortListSelItmLbl());

			dropdownlist.put("ecrstate", ecrstateLst);
			dropdownlist.put("ecrcategory", ecrcategoryLst);
			dropdownlist.put("ecrsev", ecrsevList);

		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return dropdownlist;
	}

	/**
	 * Row mapper for getting ecrstateMapper
	 */
	// private static ParameterizedRowMapper<SelectItem> ecrstateMapper = new
	// ParameterizedRowMapper<SelectItem>() {
	private static final class EcrstateMapper implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(
					rs.getString(PLMConstants.ECRSTATE));

			return selectItem;

		}
		// };
	}

	/**
	 * Row mapper for getting ecrcategoryMapper
	 */
	// private static ParameterizedRowMapper<SelectItem> ecrcategoryMapper = new
	// ParameterizedRowMapper<SelectItem>() {
	private static final class EcrcategoryMapper implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(
					rs.getString(PLMConstants.ECR_CAT));

			return selectItem;

		}
		// };
	}

	/**
	 * Row mapper for getting ecrservmapper
	 */
	// private static ParameterizedRowMapper<SelectItem> ecrservmapper = new
	// ParameterizedRowMapper<SelectItem>() {
	private static final class Ecrservmapper implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(
					rs.getString(PLMConstants.ECR_SEV));

			return selectItem;

		}
		// };
	}

	@SuppressWarnings("unchecked")
	/**
	 * This method is used for getDropDownvalueissues
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getDropDownvalueissues()
			throws PLMCommonException {
		Map<String, List<SelectItem>> dropdownlist = new HashMap<String, List<SelectItem>>();
		List<SelectItem> issuesstate = null;
		List<SelectItem> issuespri = null;
		List<SelectItem> issuesintpri = null;
		List<SelectItem> issuesproblemtype = null;
		List<SelectItem> issuescategory = null;
		List<SelectItem> issuesclassification = null;
		List<SelectItem> issuesSourceSystem = null;

		try {
			issuesstate = getJdbcTemplate().query(
					PLMSearchQueries.GET_ISSUES_STATE, new IssuesstateMapper());

			issuespri = getJdbcTemplate().query(
					PLMSearchQueries.GET_ISSUES_PRIORITY,
					new IssuespriorMapper());

			issuesintpri = getJdbcTemplate().query(
					PLMSearchQueries.GET_ISSUES_INT_PRIORITY,
					new IssuesintpriorMapper());
			issuesproblemtype = getJdbcTemplate().query(
					PLMSearchQueries.GET_ISSUES_PROBLEM_TYPE,
					new IssuesprobletypeMapper());

			issuescategory = getJdbcTemplate().query(
					PLMSearchQueries.GET_ISSUES_CATEGORY,
					new IssuescategoryMapper());

			issuesclassification = getJdbcTemplate().query(
					PLMSearchQueries.GET_ISSUES_CLASSIFICATION,
					new IssuesclassificationMapper());
			issuesSourceSystem = getJdbcTemplate().query(
					PLMSearchQueries.GET_ISSUES_SOURCE_SYSTEM,
					new IssuesSourceSystemMapper());

			dropdownlist.put("issuesstate", issuesstate);
			dropdownlist.put("issuespri", issuespri);
			dropdownlist.put("issuesintpri", issuesintpri);
			dropdownlist.put("issuesproblemtype", issuesproblemtype);
			dropdownlist.put("issuescategory", issuescategory);
			dropdownlist.put("issuesclassification", issuesclassification);
			dropdownlist.put("issuesSourceSystem", issuesSourceSystem);

		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return dropdownlist;
	}

	/**
	 * Row mapper for getting issuesstateMapper
	 */
	// private static ParameterizedRowMapper<SelectItem> issuesstateMapper = new
	// ParameterizedRowMapper<SelectItem>() {
	private static final class IssuesstateMapper implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(
					rs.getString(PLMConstants.ISSUES_STATE));

			return selectItem;

		}
		// };
	}

	/**
	 * Row mapper for getting issuesprobletypeMapper
	 */
	// private static ParameterizedRowMapper<SelectItem> issuesprobletypeMapper
	// = new ParameterizedRowMapper<SelectItem>() {
	private static final class IssuesprobletypeMapper implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(
					rs.getString(PLMConstants.PROBLEM_TYPE));

			return selectItem;

		}
		// };
	}

	/**
	 * Row mapper for getting issuescategoryMapper
	 */
	// private static ParameterizedRowMapper<SelectItem> issuescategoryMapper =
	// new ParameterizedRowMapper<SelectItem>() {
	private static final class IssuescategoryMapper implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(
					rs.getString(PLMConstants.CATG));

			return selectItem;

		}
		// };
	}

	/**
	 * Row mapper for getting issuesclassificationMapper
	 */
	// private static ParameterizedRowMapper<SelectItem>
	// issuesclassificationMapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class IssuesclassificationMapper implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(
					rs.getString(PLMConstants.CLAS_FICATION));

			return selectItem;

		}
		// };
	}

	/**
	 * Row mapper for getting issuespriorMapper
	 */
	// private static ParameterizedRowMapper<SelectItem> issuespriorMapper = new
	// ParameterizedRowMapper<SelectItem>() {
	private static final class IssuespriorMapper implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(
					rs.getString(PLMConstants.ISSUES_PRIORITY));

			return selectItem;

		}
		// };
	}

	/**
	 * Row mapper for getting issuesintpriorMapper
	 */
	// private static ParameterizedRowMapper<SelectItem> issuesintpriorMapper =
	// new ParameterizedRowMapper<SelectItem>() {
	private static final class IssuesintpriorMapper implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(
					rs.getString(PLMConstants.ISSUES_INT_PRIORITY));

			return selectItem;

		}
		// };
	}

	/**
	 * Row mapper for getting issuesSourceSystemMapper
	 */
	// private static ParameterizedRowMapper<SelectItem>
	// issuesSourceSystemMapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class IssuesSourceSystemMapper implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(
					rs.getString(PLMConstants.ISSUE_DROPDOWN_SOURCE_SYS));

			return selectItem;

		}
		// };
	}

	/**
	 * Row mapper for getting ecrdetailsMapper
	 */
	// private static ParameterizedRowMapper<PLMEcrSearchData> ecrdetailsMapper
	// = new ParameterizedRowMapper<PLMEcrSearchData>() {
	private static final class EcrdetailsMapper implements
			ParameterizedRowMapper<PLMEcrSearchData> {
		public PLMEcrSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMEcrSearchData ecrsearchData = new PLMEcrSearchData();
			ecrsearchData.setEcrName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_NAME)));
			ecrsearchData.setEcrRevision(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_REVISION)));
			ecrsearchData.setEcrOwner(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_OWNER)));
			ecrsearchData.setEcrOwnerName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_OWNER_NAME)));
			ecrsearchData.setEcrdesc(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_DESCRIPTION)));
			ecrsearchData.setEcrState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_STATE)));
			ecrsearchData.setECRLastUpdate(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_LAST_UPD)));
			ecrsearchData.setReasonforchange(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.REASON_FOR_CHANGE)));
			ecrsearchData.setEcrOriginator(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_ORIGINATOR)));
			ecrsearchData.setEcrOriginatorName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_ORIGINATOR_NAME)));
			ecrsearchData.setEcrCategChng(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_CATEGORY_CHANGE)));
			ecrsearchData.setEcrSev(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_SEVIRITY)));
			ecrsearchData.setReasonforcancel(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.REASON_FOR_CANCEL)));
			ecrsearchData.setGeneraldescrchange(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GENERAL_DESR_CHANGE)));
			ecrsearchData.setResdesigneng(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DESIGN_ENGR)));
			ecrsearchData.setResdesignengName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DESIGN_ENGR_NAME)));
			ecrsearchData.setEcrevaluator(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_EVALUATOR)));
			ecrsearchData.setFromecrStrtDate(rs
					.getDate(PLMConstants.ECR_START_DATE));
			ecrsearchData
					.setToecrEndDate(rs.getDate(PLMConstants.ECR_END_DATE));
			ecrsearchData.setAgeindays(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_AGE)));
			ecrsearchData.setISDeviation(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.IS_DEVIATION)));
			ecrsearchData.setReviewerscomments(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.REVIEWERS_COMMENTS)));
			ecrsearchData.setEcoName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECO_NAME)));
			ecrsearchData.setECODescription(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECO_DESC)));
			ecrsearchData.setEcoOwner(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECO_OWNER)));
			ecrsearchData.setEcoOwnerName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECO_OWNER_NAME)));
			ecrsearchData.setEcoState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECO_STATE)));
			ecrsearchData.setCcbchair(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CCB_CHAIRMAN)));
			ecrsearchData.setCcbChairmanName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CCB_CHAIRMAN_NAME)));

			if (rs.getDate(PLMConstants.ECR_LAST_UPD) != null) {
				ecrsearchData.setEcrLastUpdateExl(rs
						.getTimestamp(PLMConstants.ECR_LAST_UPD));
			}

			return ecrsearchData;
		}
		// };
	}

	/*
	 * Added new ECR Affected Item List
	 */

	/**
	 * This methods is used for getEcrAffectedItems
	 * 
	 * @param ecrsessionvalue
	 * @return List throws PLMCommonException
	 */
	public List<PLMEcrSearchData> getEcrAffectedItems(String ecrsessionvalue)
			throws PLMCommonException {
		LOG.info("Entering in to getEcrAffectedItems");
		List<PLMEcrSearchData> ecrAffectedPartList = new ArrayList<PLMEcrSearchData>();
		List<PLMEcrSearchData> ecrPartWhereusedList = new ArrayList<PLMEcrSearchData>();
		// List<PLMEcrSearchData> ecrAffectedList = new
		// ArrayList<PLMEcrSearchData>();
		List<PLMEcrSearchData> ecrAffectedFinalList = new ArrayList<PLMEcrSearchData>();

		try {
			LOG.info("ECR Name>>>>" + ecrsessionvalue);
			LOG.info("Execting query for getting AffectedItem with Part Details"
					+ PLMSearchQueries.GET_AFFCTITMS_ADD_DUE);
			ecrAffectedPartList = getSimpleJdbcTemplate().query(
					PLMSearchQueries.GET_AFFCTITMS_ADD_DUE,
					new EcrAffectedPartMapper(),
					new Object[] { ecrsessionvalue });

			LOG.info("Execting query for getting PartItems with Where used Details"
					+ PLMSearchQueries.GET_AFFCTITMS_WHEREUSED);
			ecrPartWhereusedList = getSimpleJdbcTemplate().query(
					PLMSearchQueries.GET_AFFCTITMS_WHEREUSED,
					new EcrPartWhereUsdMapper(),
					new Object[] { ecrsessionvalue });

			if (!PLMUtils.isEmptyList(ecrAffectedPartList)) {
				PLMEcrSearchData tempData = new PLMEcrSearchData();
				String affectedId = "";
				// List<String> partIdList=new ArrayList<String>();
				// String partItemId="";
				for (int i = 0; i < ecrAffectedPartList.size(); i++) {

					if (!affectedId.equals(ecrAffectedPartList.get(i)
							.getAffctdItmId())) {
						tempData = new PLMEcrSearchData();
						tempData.setEcrLevel("1");
						tempData.setAffectedItemId(ecrAffectedPartList.get(i)
								.getAffctdItmId());
						tempData.setAffectedItemName(ecrAffectedPartList.get(i)
								.getAffctdItmName());
						tempData.setType(ecrAffectedPartList.get(i)
								.getAffctdItmType());
						tempData.setState(ecrAffectedPartList.get(i)
								.getAffctdItmState());
						ecrAffectedFinalList.add(tempData);
					}
					if(ecrAffectedPartList.get(i)
							.getPartItmId()!=null && !ecrAffectedPartList.get(i)
							.getPartItmId().equals("") && ecrAffectedPartList.get(i)
							.getPartItmName()!=null && !ecrAffectedPartList.get(i)
									.getPartItmName().equals("") )
					{
					tempData = new PLMEcrSearchData();
					tempData.setEcrLevel("2");
					tempData.setAffectedforceRevId(ecrAffectedPartList.get(i)
							.getPartItmId());
					tempData.setAffectedforceRev(ecrAffectedPartList.get(i)
							.getPartItmName());
					tempData.setType(ecrAffectedPartList.get(i)
							.getPartItmType());
					tempData.setState(ecrAffectedPartList.get(i)
							.getPartItmState());
					tempData.setRevision(ecrAffectedPartList.get(i)
							.getPartItmRev());
					tempData.setPartInOtherEcr(ecrAffectedPartList.get(i).isPartInOtherEcr());
					ecrAffectedFinalList.add(tempData);
					}
					affectedId = ecrAffectedPartList.get(i).getAffctdItmId();
					// ecrAffectedList.add(tempData);

					// Newly Added for Where used type under part types
					for (int k = 0; k < ecrPartWhereusedList.size(); k++) {

						if (ecrPartWhereusedList
								.get(k)
								.getPartItmId()
								.equals(ecrAffectedPartList.get(i)
										.getPartItmId())) {

							tempData = new PLMEcrSearchData();
							tempData.setEcrLevel("3");
							tempData.setWhereUsedId(ecrPartWhereusedList.get(k)
									.getWhereUsdItmId());
							tempData.setWhereUsedName(ecrPartWhereusedList.get(
									k).getWhereUsdItmName());
							tempData.setType(ecrPartWhereusedList.get(k)
									.getWhereUsdItmType());
							tempData.setState(ecrPartWhereusedList.get(k)
									.getWhereUsdItmState());
							tempData.setRevision(ecrPartWhereusedList.get(k)
									.getWhereUsdItmRev());
							ecrAffectedFinalList.add(tempData);

						}
					}

				}

				/*
				 * if(!PLMUtils.isEmptyList(ecrPartWhereusedList)){
				 * 
				 * for(int j=0;j<ecrAffectedList.size();j++){
				 * 
				 * if(!partIdList.contains(ecrAffectedList.get(j).
				 * getAffectedforceRevId())){ for(int
				 * k=0;k<ecrPartWhereusedList.size();k++){
				 * 
				 * if(ecrPartWhereusedList.get(k).getPartItmId().equals(
				 * ecrAffectedList.get(j).getAffectedforceRevId())){
				 * 
				 * if(!partItemId.equals(ecrPartWhereusedList.get(k).getPartItmId
				 * ())){ tempData=new PLMEcrSearchData();
				 * tempData.setEcrLevel("1");
				 * tempData.setAffectedItemId(ecrPartWhereusedList
				 * .get(k).getPartItmId());
				 * tempData.setAffectedItemName(ecrPartWhereusedList
				 * .get(k).getPartItmName());
				 * tempData.setType(ecrAffectedList.get(j).getType());
				 * tempData.setState(ecrAffectedList.get(j).getState());
				 * ecrAffectedFinalList.add(tempData); }
				 * 
				 * tempData=new PLMEcrSearchData(); tempData.setEcrLevel("2");
				 * tempData
				 * .setWhereUsedId(ecrPartWhereusedList.get(k).getWhereUsdItmId
				 * ()); tempData.setWhereUsedName(ecrPartWhereusedList.get(k).
				 * getWhereUsdItmName());
				 * tempData.setType(ecrPartWhereusedList.get
				 * (k).getWhereUsdItmType());
				 * tempData.setState(ecrPartWhereusedList
				 * .get(k).getWhereUsdItmState());
				 * partItemId=ecrPartWhereusedList.get(k).getPartItmId();
				 * ecrAffectedFinalList.add(tempData); } }
				 * partIdList.add(ecrAffectedList
				 * .get(j).getAffectedforceRevId()); } } }
				 */
			}

		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting in to getEcrAffectedItems");
		return ecrAffectedFinalList;
	}

	/**
	 * Row mapper for getting EcrAffectedPartMapper
	 */
	private static final class EcrAffectedPartMapper implements
			ParameterizedRowMapper<PLMEcrSearchData> {
		public PLMEcrSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMEcrSearchData ecrAffctedSrchData = new PLMEcrSearchData();
			ecrAffctedSrchData.setAffctdItmId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_AFFECTED_ITEM_ID)));
			ecrAffctedSrchData.setAffctdItmName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_AFFECTED_ITEM)));
			ecrAffctedSrchData.setAffctdItmType(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_AFFECTED_ITEM_TYPE)));
			ecrAffctedSrchData.setAffctdItmState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_AFFCTED_STATE)));
			ecrAffctedSrchData.setPartItmId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_PART_ID)));
			ecrAffctedSrchData.setPartItmName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_PART_NAME)));
			ecrAffctedSrchData.setPartItmType(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_PART_TYPE)));
			ecrAffctedSrchData.setPartItmState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_PART_STATE)));
			ecrAffctedSrchData.setPartItmRev(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_PART_REV)));			
			if (Integer.parseInt(PLMUtils.checkNullVal(rs
					.getString("OTHER_ECR_CNT"))) > 0) {
				ecrAffctedSrchData.setPartInOtherEcr(true);
			} else {
				ecrAffctedSrchData.setPartInOtherEcr(false);
			}
			return ecrAffctedSrchData;
		}
	}

	/**
	 * Row mapper for getting EcrPartWhereUsdMapper
	 */
	private static final class EcrPartWhereUsdMapper implements
			ParameterizedRowMapper<PLMEcrSearchData> {
		public PLMEcrSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMEcrSearchData ecrAffctedSrchData = new PLMEcrSearchData();
			ecrAffctedSrchData.setPartItmId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.EC_PART_ID)));
			ecrAffctedSrchData.setPartItmName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.EC_PART_NAME)));
			ecrAffctedSrchData.setWhereUsdItmId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_WHEREUSED_ID)));
			ecrAffctedSrchData.setWhereUsdItmName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_WHEREUSED_NAME)));
			ecrAffctedSrchData.setWhereUsdItmType(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_WHEREUSED_TYPE)));
			ecrAffctedSrchData.setWhereUsdItmState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_WHEREUSED_STATE)));
			ecrAffctedSrchData.setWhereUsdItmRev(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_WHEREUSED_REV)));
			return ecrAffctedSrchData;
		}
	}

	@SuppressWarnings("unchecked")
	public List<PLMEcoSearchData> geteconamesbyselection(
			StringBuffer searchResultsQry, Map<String, Object> params)
			throws PLMCommonException {
		List<PLMEcoSearchData> SearchResultList = null;
		try {
			SearchResultList = getNamedJdbcTemplate()
					.query(searchResultsQry.toString(), params,
							new EcodetailsMapper());
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return SearchResultList;
	}

	/**
	 * This method is used for getecrNameBySelection
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMEcrSearchData> getecrNameBySelection(
			StringBuffer searchResultsQry, Map<String, Object> params)
			throws PLMCommonException {
		List<PLMEcrSearchData> SearchResultList = null;
		try {
			LOG.info("FINAL QUERY IS getecrNameBySelection : "
					+ searchResultsQry);
			SearchResultList = getNamedJdbcTemplate()
					.query(searchResultsQry.toString(), params,
							new EcrdetailsMapper());
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return SearchResultList;
	}

	/**
	 * Row mapper for getting ecodetailsMapper
	 */
	// private static ParameterizedRowMapper<PLMEcoSearchData> ecodetailsMapper
	// = new ParameterizedRowMapper<PLMEcoSearchData>() {
	private static final class EcodetailsMapper implements
			ParameterizedRowMapper<PLMEcoSearchData> {
		public PLMEcoSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			PLMEcoSearchData searchData = new PLMEcoSearchData();

			searchData.setEcoName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECONAME)));
			searchData.setEcoRev(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECOREV)));
			searchData.setEcoOwner(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECOOWNER)));
			searchData.setEcoOwnerName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECOOWNERNAME)));
			searchData.setEcoOriginator(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECO_ORIGIN)));
			searchData.setEcoOriginatorName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECO_ORIGIN_NAME)));
			searchData.setEcoDesc(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECODESC)));
			searchData.setEcoState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECOSTATE)));
			searchData.setEcoCateg(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECOCATEG)));
			searchData.setEcoSev(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECOSEV)));
			searchData.setEcoDesginEngr(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECODESGINENGR)));
			searchData.setEcoDesignEngrName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECODESGINENGRNAME)));
			searchData.setEcoMfgEngr(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECOMFGENGR)));
			searchData.setEcoMfgEngrName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECOMFGENGRNAME)));
			searchData.setRdo(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.RDO_ISSUES)));
			searchData.setRouteName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ROUTENAME)));
			searchData.setRouteType(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ROUTETYPE)));
			searchData.setRouteOwner(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ROUTEOWNER)));
			searchData.setRouteLastUp(rs.getDate(PLMConstants.ROUTELASTUP));
			searchData.setRouteState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ROUTESTATE)));
			searchData.setRouteStatus(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ROUTESTATUS)));
			searchData.setTaskName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASKNAME)));
			searchData.setTaskCreation(rs.getDate(PLMConstants.TASKCREATION));
			searchData.setTaskOwner(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASKOWNER)));
			searchData.setTaskOwnerFN(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASKOWNERFN)));
			searchData.setTaskOwnerLN(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASKOWNERLN)));
			searchData.setTaskState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASKSTATE)));
			searchData.setApprovalStat(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.APPROVALSTAT)));
			searchData.setScheCompDate(rs.getDate(PLMConstants.SCHECOMPDATE));
			searchData.setActCompDate(rs.getDate(PLMConstants.ACTCOMPDATE));
			searchData.setDwgName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DWGNAME)));
			searchData.setDwgRev(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DWGREV)));
			searchData.setDwgOriginator(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DWGORIGINATOR)));
			searchData.setDwgOriginatorName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DWGORIGINATORNAME)));
			searchData.setDwgCreateDate(rs.getDate(PLMConstants.DWGCREATEDATE));
			searchData.setDwgRelDate(rs.getDate(PLMConstants.DWGRELDATE));
			searchData.setDwgCycletime(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DWGCYCLETIME)));
			searchData.setEco_rel_date(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECO_REL_DATE)));
			searchData.setEco_orig_date(rs.getDate(PLMConstants.ECO_ORIG_DATE));
			searchData.setEco_age_in_days(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECO_AGE_IN_DAYS)));

			searchData.setFastTrackEco(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECO_FAST_TRACK)));

			if (rs.getDate(PLMConstants.ECO_REL_DATE) != null) {
				searchData.setEcoReldateExl(rs
						.getTimestamp(PLMConstants.ECO_REL_DATE));
			}

			return searchData;

		}
		// };
	}

	/**
	 * This method is used for getIssuesDetailedReport
	 * 
	 * @param issuesValuesList
	 * @return List,searchDetails
	 * @throws PLMCommonException
	 */
	public List<PLMIssuesReportData> getIssuesDetailedReport(
			List<String> issuesValuesList, PLMIssuesReportData searchDetails)
			throws PLMCommonException {
		LOG.info("Entering into getIssuesDetailedReport()");
		List<PLMIssuesReportData> SearchResultList = null;
		String timeStamp = PLMUtils.volTableFormatTime();
		String VT_ISSUE = PLMConstants.VT_ISSUE.concat(timeStamp);
		String VT_CONTRACT = PLMConstants.VT_CONTRACT.concat(timeStamp);
		String VT_CONTRACT_NAME = PLMConstants.VT_CONTRACT_NAME
				.concat(timeStamp);
		String VT_DOCUMENT = PLMConstants.VT_DOCUMENT.concat(timeStamp);
		String VT_DOC_NAME = PLMConstants.VT_DOC_NAME.concat(timeStamp);
		String VT_PART = PLMConstants.VT_PART.concat(timeStamp);
		String VT_PART_NAME = PLMConstants.VT_PART_NAME.concat(timeStamp);
		String VT_HW_BLD = PLMConstants.VT_HW_BLD.concat(timeStamp);
		String VT_HW_BLD_NAME = PLMConstants.VT_HW_BLD_NAME.concat(timeStamp);
		String VT_PROJECT = PLMConstants.VT_PROJECT.concat(timeStamp);
		String VT_PROJECT_NAME = PLMConstants.VT_PROJECT_NAME.concat(timeStamp);
		String VT_RESOLVED_TO = PLMConstants.VT_RESOLVED_TO.concat(timeStamp);
		String VT_RSLVD_TO_NAME = PLMConstants.VT_RSLVD_TO_NAME.concat(timeStamp);
		String VT_ISSUE_NEW_REQ = PLMConstants.VT_ISSUE_NEW_REQ.concat(timeStamp);
		String VT_ISSUE_REQ_DTL = PLMConstants.VT_ISSUE_REQ_DTL.concat(timeStamp);
		;
		StringBuffer issueDetailQuery = new StringBuffer();
		StringBuffer createVTHardWare = new StringBuffer();
		try {
			String createVTIssue = PLMSearchQueries.CREATE_VT_ISSUE.replace(
					PLMConstants.VT_ISSUE, VT_ISSUE);
			LOG.info("Executing createVTIssue Query : " + createVTIssue + "\n");
			getJdbcTemplate().execute(createVTIssue);

			final List<String> finalIssuesValList = issuesValuesList;

			if (!PLMUtils.isEmptyList(finalIssuesValList)) {
				int[] updateCount = null;
				String insertVTIssue = PLMSearchQueries.INSERT_VT_ISSUE
						.replace(PLMConstants.VT_ISSUE, VT_ISSUE);
				LOG.info("Inserting Query of insertVTIssue Value List :  "
						+ insertVTIssue);
				updateCount = getJdbcTemplate().batchUpdate(insertVTIssue,
						new BatchPreparedStatementSetter() {
							public void setValues(PreparedStatement ps,
									int iCount) throws SQLException {
								ps.setString(1, finalIssuesValList.get(iCount));
							}

							public int getBatchSize() {
								return finalIssuesValList.size();
							}
						});
				if (finalIssuesValList.size() == updateCount.length) {
					LOG.info("Inserted Successfully");
				} else {
					LOG.info("Failed to Insert");
				}
			}

			String createVTContract = PLMSearchQueries.CREATE_VT_CONTRACT
					.replace(PLMConstants.VT_CONTRACT, VT_CONTRACT).replace(
							PLMConstants.VT_ISSUE, VT_ISSUE);
			LOG.info("Executing createVTContract Query : " + createVTContract
					+ "\n");
			getJdbcTemplate().execute(createVTContract);

			String createVtContractName = PLMSearchQueries.CREATE_VT_CONTRACT_NAME
					.replace(PLMConstants.VT_CONTRACT_NAME, VT_CONTRACT_NAME)
					.replace(PLMConstants.VT_CONTRACT, VT_CONTRACT);
			LOG.info("Executing createVtContractName Query : "
					+ createVtContractName + "\n");
			getJdbcTemplate().execute(createVtContractName);

			String createVtDocument = PLMSearchQueries.CREATE_VT_DOCUMENT
					.replace(PLMConstants.VT_DOCUMENT, VT_DOCUMENT).replace(
							PLMConstants.VT_ISSUE, VT_ISSUE);
			LOG.info("Executing createVtDocument Query : " + createVtDocument
					+ "\n");
			getJdbcTemplate().execute(createVtDocument);

			String createVtDocName = PLMSearchQueries.CREATE_VT_DOC_NAME
					.replace(PLMConstants.VT_DOC_NAME, VT_DOC_NAME).replace(
							PLMConstants.VT_DOCUMENT, VT_DOCUMENT);
			LOG.info("Executing createVtDocName Query : " + createVtDocName
					+ "\n");
			getJdbcTemplate().execute(createVtDocName);

			String createVtPart = PLMSearchQueries.CREATE_VT_PART.replace(
					PLMConstants.VT_PART, VT_PART).replace(
					PLMConstants.VT_ISSUE, VT_ISSUE);
			LOG.info("Executing createVtPart Query : " + createVtPart + "\n");
			getJdbcTemplate().execute(createVtPart);

			String createVtPartName = PLMSearchQueries.CREATE_VT_PART_NAME
					.replace(PLMConstants.VT_PART_NAME, VT_PART_NAME).replace(
							PLMConstants.VT_PART, VT_PART);
			LOG.info("Executing createVtPartName Query : " + createVtPartName
					+ "\n");
			getJdbcTemplate().execute(createVtPartName);

			createVTHardWare.append(PLMSearchQueries.CREATE_VT_HW_BLD1.replace(
					PLMConstants.VT_HW_BLD, VT_HW_BLD).replace(
					PLMConstants.VT_ISSUE, VT_ISSUE));

			if (searchDetails.getUnitSerialNum() != null) {
				createVTHardWare.append(" AND "
						+ PLMUtils.generateQueryWhereClauseForTaskSearch(
								"HW_BLD." + PLMConstants.UNIT_SERIAL,
								searchDetails.getUnitSerialNum()));
			}
			createVTHardWare.append(PLMSearchQueries.CREATE_VT_HW_BLD2);

			LOG.info("Executing createVTHardWare Query : " + createVTHardWare
					+ "\n");
			getJdbcTemplate().execute(createVTHardWare.toString());

			String createVTHardWareName = PLMSearchQueries.CREATE_VT_HW_BLD_NAME
					.replace(PLMConstants.VT_HW_BLD_NAME, VT_HW_BLD_NAME)
					.replace(PLMConstants.VT_HW_BLD, VT_HW_BLD);
			LOG.info("Executing createVTHardWareName Query : "
					+ createVTHardWareName + "\n");
			getJdbcTemplate().execute(createVTHardWareName);

			String createVtProject = PLMSearchQueries.CREATE_VT_PROJECT
					.replace(PLMConstants.VT_PROJECT, VT_PROJECT).replace(
							PLMConstants.VT_ISSUE, VT_ISSUE);
			LOG.info("Executing createVtProject Query : " + createVtProject
					+ "\n");
			getJdbcTemplate().execute(createVtProject);

			String createVtProjectName = PLMSearchQueries.CREATE_VT_PROJECT_NAME
					.replace(PLMConstants.VT_PROJECT_NAME, VT_PROJECT_NAME)
					.replace(PLMConstants.VT_PROJECT, VT_PROJECT);
			LOG.info("Executing createVtProjectName Query : "
					+ createVtProjectName + "\n");
			getJdbcTemplate().execute(createVtProjectName);

			String createVtResolvedTo = PLMSearchQueries.CREATE_VT_RESOLVED_TO
					.replace(PLMConstants.VT_RESOLVED_TO, VT_RESOLVED_TO)
					.replace(PLMConstants.VT_ISSUE, VT_ISSUE);
			LOG.info("Executing createVtResolvedTo Query : "
					+ createVtResolvedTo + "\n");
			getJdbcTemplate().execute(createVtResolvedTo);

			String createVtResolvedToName = PLMSearchQueries.CREATE_VT_RSLVD_TO_NAME
					.replace(PLMConstants.VT_RSLVD_TO_NAME, VT_RSLVD_TO_NAME)
					.replace(PLMConstants.VT_RESOLVED_TO, VT_RESOLVED_TO);
			LOG.info("Executing createVtResolvedToName Query : "
					+ createVtResolvedToName + "\n");
			getJdbcTemplate().execute(createVtResolvedToName);
			
			String getIssuedDetails = PLMSearchQueries.GET_ISSUES_DETAILS
					.replace(PLMConstants.VT_CONTRACT_NAME, VT_CONTRACT_NAME)
					.replace(PLMConstants.VT_DOC_NAME, VT_DOC_NAME)
					.replace(PLMConstants.VT_PART_NAME, VT_PART_NAME)
					.replace(PLMConstants.VT_HW_BLD_NAME, VT_HW_BLD_NAME)
					.replace(PLMConstants.VT_PROJECT_NAME, VT_PROJECT_NAME)
					.replace(PLMConstants.VT_RSLVD_TO_NAME, VT_RSLVD_TO_NAME);
			issueDetailQuery.append(getIssuedDetails);
			issueDetailQuery.append(PLMUtils.setListForQuery(issuesValuesList)
					+ ")");

			LOG.info("Executing getIssuedDetails Query : " + issueDetailQuery
					+ "\n");

			SearchResultList = getSimpleJdbcTemplate().query(
					issueDetailQuery.toString(), new IssuesdetailsMapper());

		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting into getIssuesDetailedReport()");
		return SearchResultList;
	}

	/**
	 * Row mapper for getting issuesdetailsMapper
	 */
	// private static ParameterizedRowMapper<PLMIssuesReportData>
	// issuesdetailsMapper = new ParameterizedRowMapper<PLMIssuesReportData>() {
	private static final class IssuesdetailsMapper implements
			ParameterizedRowMapper<PLMIssuesReportData> {
		public PLMIssuesReportData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMIssuesReportData searchData = new PLMIssuesReportData();
			searchData.setId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ID)));
			searchData.setName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.NAME)));
			searchData.setDesc(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DESCRIPTION)));
			searchData.setContractName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CONTRACT_NAME)));
			searchData.setDocumentName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOCUMENT_NAME)));
			searchData.setPartName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PART_NAME)));
			searchData.setHardWareBldNm(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.HW_BUILD_NAME)));
			searchData.setUnitSerialNum(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.UNIT_SERIAL_NUM)));
			searchData.setProjectName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PROJECT_NAME)));
			searchData.setResolvedToNm(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.RESOLVED_TO_NAME)));
			searchData.setState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.STATE)));
			searchData.setOwner(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.OWNER)));
			searchData.setOwnerName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.OWNERNAME)));
			searchData.setCo_owner(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CO_OWNER)));
			searchData.setCoOwnerName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CO_OWNER_NAME)));
			searchData.setOrig_nator(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ORIG_NATOR)));
			searchData.setOriginatorName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ORIGINATORNAME)));
			searchData.setOrig_date_from(rs.getDate(PLMConstants.ORIG));
			if (PLMUtils.isEmptyDate(rs.getTimestamp(PLMConstants.ORIG))) {
				searchData.setOrig_date_from_excel("");
			} else {
				searchData.setOrig_date_from_excel(DATE_FORMAT_PROC.format(rs
						.getTimestamp(PLMConstants.ORIG)));
			}
			searchData.setEstim_date_from(rs.getDate(PLMConstants.ESTIM));
			if (PLMUtils.isEmptyDate(rs.getTimestamp(PLMConstants.ESTIM))) {
				searchData.setEstim_date_from_excel("");
			} else {
				searchData.setEstim_date_from_excel(DATE_FORMAT_PROC.format(rs
						.getTimestamp(PLMConstants.ESTIM)));
			}
			searchData.setAct_date_from(rs.getDate(PLMConstants.ACT_FINISH));
			if (PLMUtils.isEmptyDate(rs.getTimestamp(PLMConstants.ACT_FINISH))) {
				searchData.setAct_date_from_excel("");
			} else {
				searchData.setAct_date_from_excel(DATE_FORMAT_PROC.format(rs
						.getTimestamp(PLMConstants.ACT_FINISH)));
			}
			searchData.setCycle_time(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CYCLE_TIME)));
			searchData.setPriority(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PRIO)));
			searchData.setInt_priority(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.INT_PRI)));
			searchData.setCatg(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CATG)));
			searchData.setClas_fication(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CLAS_FICATION)));
			searchData.setProblem_type(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PROBLEM_TYPE)));
			searchData.setSource_sys(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.SOURCE_SYS)));
			searchData.setResp_Org(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.RESP_ORG)));
	
			return searchData;
		}
	}

	@SuppressWarnings("unchecked")
	// Retrieving values in Task Data as State List
	/**
	 * This method is used for getTaskDropDownValues
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getTaskDropDownValues()
			throws PLMCommonException {

		Map<String, List<SelectItem>> dropdownlist = new HashMap<String, List<SelectItem>>();
		List<SelectItem> taskstate = null;
		List<SelectItem> taskAssociatedType = null;
		try {
			taskstate = getJdbcTemplate().query(
					PLMSearchQueries.GET_TASK_STATE_LIST,
					new TaskStateListMapper());
			// LOG.info("Final Query State is : " + taskstate);
			taskAssociatedType = getJdbcTemplate().query(
					PLMSearchQueries.GET_TASK_ASTDTYPE_LIST,
					new TaskAstdTypeListMapper());
			// LOG.info("Final Query Associated Type is : " +
			// taskAssociatedType);

			dropdownlist.put("taskstate", taskstate);
			dropdownlist.put("taskAssociatedType", taskAssociatedType);

		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return dropdownlist;
	}

	/**
	 * Row mapper for getting taskStateListMapper
	 */
	// private static ParameterizedRowMapper<SelectItem> taskStateListMapper =
	// new ParameterizedRowMapper<SelectItem>() {
	private static final class TaskStateListMapper implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs.getString("STATE"));
			return selectItem;
		}
		// };
	}

	/**
	 * Row mapper for getting taskAstdTypeListMapper
	 */
	// private static ParameterizedRowMapper<SelectItem> taskAstdTypeListMapper
	// = new ParameterizedRowMapper<SelectItem>() {
	private static final class TaskAstdTypeListMapper implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(
					rs.getString("DELIVERABLES_TYPE"));

			return selectItem;
		}
		// };
	}

	/**
	 * This method is used for getTaskSearchData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public Map<String,List<PLMTaskSearchData>> getTaskSearchData(
			StringBuffer whereClauseQry, PLMTaskSearchData tasksearchDetails) throws PLMCommonException {
		LOG.info("Entering getTaskSearchData method");
		Map<String,List<PLMTaskSearchData>> listMap = new HashMap<String, List<PLMTaskSearchData>>();
		List<PLMTaskSearchData> taskSearchResultList = null;
		String VTTASK =null;
		String VTCON =null;
		String timeStamp=null;
		StringBuffer createVTTask = new StringBuffer();
		timeStamp = PLMUtils.volTableFormatDate();
		try {
			VTTASK = PLMConstants.VTTASK.concat(timeStamp);
			VTCON = PLMConstants.VTCON.concat(timeStamp);
			createVTTask.append(PLMSearchQueries.CREATE_VTTASK_ONE.replaceAll(PLMConstants.VTTASK, VTTASK))
			 .append(whereClauseQry)
			 .append(PLMSearchQueries.CREATE_VTTASK_TWO);
			LOG.info("Execting  VTTASK Volatile Query is : " + createVTTask);
			getJdbcTemplate().execute(createVTTask.toString());
			
			LOG.info("Execting  VTCON Volatile Query is : " + PLMSearchQueries.CREATE_VTCON.replace(PLMConstants.VTCON, VTCON).replace(PLMConstants.VTTASK, VTTASK));
			getJdbcTemplate().execute(PLMSearchQueries.CREATE_VTCON.replaceAll(PLMConstants.VTCON, VTCON).replace(PLMConstants.VTTASK, VTTASK));
			
			LOG.info("Execting  Final Data for Task Search Query : " + PLMSearchQueries.GET_TASKSEARCH_FINAL_DATA.replace(PLMConstants.VTCON, VTCON).replace(PLMConstants.VTTASK, VTTASK));
			taskSearchResultList = getSimpleJdbcTemplate().query(
					PLMSearchQueries.GET_TASKSEARCH_FINAL_DATA.replaceAll(PLMConstants.VTCON, VTCON).replace(PLMConstants.VTTASK, VTTASK), new TaskReportMapper());
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getTaskSearchData method");
		listMap.put(whereClauseQry.toString(), taskSearchResultList);
		return listMap;
	}

	/**
	 * Row mapper for getting taskReportMapper
	 */

	// private static ParameterizedRowMapper<PLMTaskSearchData> taskReportMapper
	// = new ParameterizedRowMapper<PLMTaskSearchData>() {
	//commented/removed column by subrajit for req - 13948 
	private static final class TaskReportMapper implements
			ParameterizedRowMapper<PLMTaskSearchData> {
		public PLMTaskSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMTaskSearchData taskData = new PLMTaskSearchData();
			taskData.setName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_NAME)));
			taskData.setTaskName(taskData.getName());
			/*taskData.setTitle(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ACTIVITY_CODE_TITLE)));*/
			taskData.setTitle(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_TITLE)));
			taskData.setState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_STATE_NAME)));
			taskData.setOwner(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_OWNER_SSO)));
			taskData.setOwnerName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_OWNER_NAME)));
			/*taskData.setPercentageComplete(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PCT_COMPLETE)));
			taskData.setOrginator(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ORIGINATOR)));
			taskData.setOrginatorName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ORIGINATOR_NAME)));*/
			taskData.setEstimatedFinish(rs
					.getDate(PLMConstants.ESTIMATED_FINISH));
			taskData.setActualFinish(rs.getDate(PLMConstants.ACTUAL_FINISH));
			/*taskData.setStatus(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.STATUS)));
			taskData.setTaskApproval(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_APPROVAL)));*/
			taskData.setDuration(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_ACTUAL_DURATION)));
			/*taskData.setNote(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.NOTES)));
			taskData.setTaskReq(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_REQUIREMENT)));
			taskData.setSynopsis(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.SYNOPSIS)));
			taskData.setProjectrole(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PROJECT_ROLE)));*/
			taskData.setTaskId(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_ID)));
			taskData.setProjectName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PROJECT_NAME)));
			String taskName = taskData.getName().replace("'", "''");
			if (PLMUtils.isEmpty(taskData.getProjectName())) {
				taskData.setVtTaskAndProject("( VT.NAME = '" + taskName + "')");
				taskData.setTaskAndProject("(" + PLMConstants.TASK_NAME
						+ " = '" + taskName + "')");
				taskData.setTaskAndProjectPred("(" + PLMConstants.TASK_NAME
						+ " = '" + taskName + "' / " + PLMConstants.TASK_ID
						+ " = '" + taskData.getTaskId() + "')");
			} else {
				String prjName = taskData.getProjectName().replace("'", "''");
				taskData.setVtTaskAndProject("( VT.NAME = '" + taskName + "' AND "
						+ "VT.PROJECT_NAME = '" + prjName + "')");
				taskData.setTaskAndProject("(" + PLMConstants.TASK_NAME
						+ " = '" + taskName + "' AND "
						+ PLMConstants.PROJECT_NAME + " = '" + prjName + "')");
				taskData.setTaskAndProjectPred("(" + PLMConstants.TASK_NAME
						+ " = '" + taskName + "' / " + PLMConstants.TASK_ID
						+ " = '" + taskData.getTaskId() + "' / "
						+ PLMConstants.PROJECT_NAME + " = '" + prjName + "')");
			}
			taskData.setProjectDesc(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PROJECT_DESCRIPTION)));
			taskData.setContractName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CONTRACT_NAME)));
			taskData.setTaskResponsiblity(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_RESPONSIBLITY)));
			taskData.setTaskResponsiblityName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_RESPONSIBLITY_NAME)));
			/*taskData.setGeActivityCode(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GE_ACTIVITY_CODE)));*/
			taskData.setAssignee(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ASSIGNEES)));
			taskData.setAssigneeName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ASSIGNEES_NAME)));
			taskData.setRequiredHours(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.REQUIRED_HOURS)));
			taskData.setEstimatedStart(null);
			if (rs.getDate(PLMConstants.ESTIMATED_START) != null) {
				taskData.setEstimatedStart(rs
						.getDate(PLMConstants.ESTIMATED_START));
			}
			taskData.setActualHours(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ACTUAL_HOURS)));
			taskData.setActualStart(null);
			if (rs.getDate(PLMConstants.ACTUAL_START) != null) {
				taskData.setActualStart(rs.getDate(PLMConstants.ACTUAL_START));
			}
			taskData.setEstimatedDuration(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ESTIMATED_DURATION)));
			taskData.setMfgIndicator(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GE_MFGG_DELIVERABLE_INDR)));
			taskData.setDeliverable(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DELIVERABLES)));
			taskData.setTaskResponsiblityUnit(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GE_TASK_RESPONSIBLE_UNIT)));
			taskData.setMfgFinish(rs.getDate(PLMConstants.GE_MFGG_NEED_DATE));
			taskData.setCustomerFinish(rs
					.getDate(PLMConstants.GE_CSTMR_NEED_DATE));
			taskData.setAssociateitem(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ASSOCIATED_ITEM)));
			taskData.setType(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DELIVERABLES_TYPE)));
			taskData.setGeTotalFloat(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GE_TOTAL_FLOAT)));
			taskData.setGeLateFinishDate(rs
					.getDate(PLMConstants.GE_LATE_FINISH_DATE));
			taskData.setGeEarlyFinishDate(rs
					.getDate(PLMConstants.GE_EARLY_FINISH_DATE));
			taskData.setCreationDate(rs.getDate(PLMConstants.CREATION_DATE));
			taskData.setActionTaken(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ACTION_TAKEN)));
			taskData.setPendingEffort(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PENDING_EFFORT)));
			taskData.setTotalEffort(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TOTAL_EFFORT)));
			taskData.setGeRemainingHr(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GE_REMAINING_HOURS)));
			taskData.setGePalnnedEffort(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GE_PLANNED_EFFORT)));
			taskData.setExpctdFinishDt(rs.getDate(PLMConstants.GE_EXPECTED_FINISH_DATE));
			taskData.setLateStrtDt(rs.getDate(PLMConstants.GE_LATE_START_DATE));
			return taskData;
		}
		// };
	}

	/**
	 * This method is used for insertTaskSaveAndSearchData
	 * 
	 * @param taskSaveSearchFieldNameList
	 * @param taskSaveSearchFieldValueList
	 * @param tasksearchDetails
	 * @return int
	 * @throws PLMCommonException
	 */
	public int insertTaskSaveAndSearchData(
			List<String> taskSaveSearchFieldNameList,
			List<String> taskSaveSearchFieldValueList,
			PLMTaskSearchData tasksearchDetails) throws PLMCommonException {
		int count = 0;
		Long taskSearchQrySeqId;
		try {
			LOG.info("Query for Insert into PLMR_TASK_SRCH_QRYS is : "
					+ PLMQueryConstants.INSERT_TASK_SAVE_AND_SEARCH_QRYS);
			count = getSimpleJdbcTemplate().update(
					PLMQueryConstants.INSERT_TASK_SAVE_AND_SEARCH_QRYS,
					new Object[] { tasksearchDetails.getSsoId(),
							tasksearchDetails.getQueryName(),
							tasksearchDetails.getSsoId(),
							tasksearchDetails.getSsoId() });
			LOG.info("Total inserted Records in PLMR_TASK_SRCH_QRYS : " + count);
			if (count == 1) {
				LOG.info("Query for Getting Sequential id from PLMR_TASK_SRCH_QRYS is : "
						+ PLMQueryConstants.GET_TASK_SRCH_QRY_SEQ_ID);
				taskSearchQrySeqId = getJdbcTemplate().queryForLong(
						PLMQueryConstants.GET_TASK_SRCH_QRY_SEQ_ID,
						new Object[] { tasksearchDetails.getSsoId(),
								tasksearchDetails.getQueryName() });
				LOG.info("Sequential id : " + taskSearchQrySeqId);
				if (taskSearchQrySeqId != null) {
					final String ssoId = tasksearchDetails.getSsoId();
					final Long finalTaskSearchQrySeqId = taskSearchQrySeqId;
					final List<String> finalTaskSaveSearchFieldNameList = taskSaveSearchFieldNameList;
					final List<String> finalTaskSaveSearchFieldValueList = taskSaveSearchFieldValueList;
					int[] updateCount = null;
					LOG.info("Query for Insert into PLMR_TASK_SRCH_QRYS_DTLS :  "
							+ PLMQueryConstants.INSERT_TASK_SAVE_AND_SEARCH_QRY_DTLS);
					updateCount = getSimpleJdbcTemplate()
							.getJdbcOperations()
							.batchUpdate(
									PLMQueryConstants.INSERT_TASK_SAVE_AND_SEARCH_QRY_DTLS,
									new BatchPreparedStatementSetter() {
										public void setValues(
												PreparedStatement ps, int iCount)
												throws SQLException {
											ps.setLong(1,
													finalTaskSearchQrySeqId);
											ps.setString(2,
													finalTaskSaveSearchFieldNameList
															.get(iCount));
											ps.setString(3,
													finalTaskSaveSearchFieldValueList
															.get(iCount));
											ps.setString(4, ssoId);
											ps.setString(5, ssoId);
										}

										public int getBatchSize() {
											return finalTaskSaveSearchFieldNameList
													.size();
										}
									});
					LOG.info("Total inserted Records in PLMR_TASK_SRCH_QRYS_DTLS : "
							+ updateCount.length);
				}
			}
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return count;
	}

	// raju save & search
	@Transactional
	/**
	 * This method is used for updateTaskSaveAndSearchData
	 * 
	 * @param taskSaveSearchFieldNameList
	 * @param taskSaveSearchFieldValueList
	 * @param tasksearchDetails
	 * @return int
	 * @throws PLMCommonException
	 */
	public int updateTaskSaveAndSearchData(
			List<String> taskSaveSearchFieldNameList,
			List<String> taskSaveSearchFieldValueList,
			PLMTaskSearchData tasksearchDetails) throws PLMCommonException {
		int count = 0;
		Long taskSearchQrySeqId;
		try {
			LOG.info("Query to delete  PLMR_TASK_SRCH_QRY_DTLS is : "
					+ PLMQueryConstants.DELETE_TASK_SAVE_AND_SEARCH_QRY_DTLS);
			count = getSimpleJdbcTemplate().update(
					PLMQueryConstants.DELETE_TASK_SAVE_AND_SEARCH_QRY_DTLS,
					new Object[] { tasksearchDetails.getSeqID() });
			LOG.info("Total deleted Records in PLMR_TASK_SRCH_QRY_DTLS : "
					+ count);
			if (count > 1) {
				LOG.info("before assigning and parsing taskSearchQrySeqId value....."
						+ tasksearchDetails.getSeqID());
				taskSearchQrySeqId = Long.parseLong(tasksearchDetails
						.getSeqID());
				LOG.info("Sequential id : " + taskSearchQrySeqId);
				if (taskSearchQrySeqId != null) {
					final String ssoId = tasksearchDetails.getSsoId();
					final Long finalTaskSearchQrySeqId = taskSearchQrySeqId;
					final List<String> finalTaskSaveSearchFieldNameList = taskSaveSearchFieldNameList;
					final List<String> finalTaskSaveSearchFieldValueList = taskSaveSearchFieldValueList;
					int[] updateCount = null;
					LOG.info("Query for Insert into PLMR_TASK_SRCH_QRYS_DTLS :  "
							+ PLMQueryConstants.INSERT_TASK_SAVE_AND_SEARCH_QRY_DTLS);
					updateCount = getSimpleJdbcTemplate()
							.getJdbcOperations()
							.batchUpdate(
									PLMQueryConstants.INSERT_TASK_SAVE_AND_SEARCH_QRY_DTLS,
									new BatchPreparedStatementSetter() {
										public void setValues(
												PreparedStatement ps, int iCount)
												throws SQLException {
											ps.setLong(1,
													finalTaskSearchQrySeqId);
											ps.setString(2,
													finalTaskSaveSearchFieldNameList
															.get(iCount));
											ps.setString(3,
													finalTaskSaveSearchFieldValueList
															.get(iCount));
											ps.setString(4, ssoId);
											ps.setString(5, ssoId);
										}

										public int getBatchSize() {
											return finalTaskSaveSearchFieldNameList
													.size();
										}
									});
					LOG.info("Total inserted Records in PLMR_TASK_SRCH_QRYS_DTLS : "
							+ updateCount.length);
				}
			}
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return count;
	}

	/**
	 * This method is used for displaySaveAndSearchQuries
	 * 
	 * @param ssoId
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> displaySaveAndSearchQuries(String ssoId)
			throws PLMCommonException {
		List<PLMTaskSearchData> taskSaveAndSearchResultList = null;
		try {
			LOG.info("Task Save And Search Report Query is : "
					+ PLMQueryConstants.GET_TASK_SAVE_SEARCH_DATA);
			LOG.info("My Task Queries ssoId value passed : " + ssoId);
			taskSaveAndSearchResultList = getSimpleJdbcTemplate().query(
					PLMQueryConstants.GET_TASK_SAVE_SEARCH_DATA,
					new TaskSaveSearchReportMapper(), ssoId);
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return taskSaveAndSearchResultList;
	}

	/**
	 * This method is used for deleteQryNameByCheckboxSelection
	 * 
	 * @param selectedQueryName
	 *            ,ssoId
	 * @return int
	 * @throws PLMCommonException
	 */
	public int deleteQryNameByCheckboxSelection(String selectedQueryName,
			String ssoId) throws PLMCommonException {
		int count = 0;
		String taskSearchQrySeqId = null;
		StringTokenizer token = new StringTokenizer(selectedQueryName, ",");
		try {
			while (token.hasMoreElements()) {
				taskSearchQrySeqId = token.nextToken();
				// if(taskSearchQrySeqId != null){
				LOG.info("Delete Query For PLMR_TASK_SRCH_QRY_DTLS :"
						+ PLMQueryConstants.QRY_NAME_DELETE_FROM_SRCH_QRY_DTLS);
				count = getSimpleJdbcTemplate().update(
						PLMQueryConstants.QRY_NAME_DELETE_FROM_SRCH_QRY_DTLS,
						taskSearchQrySeqId);
				LOG.info("Succesfully Data deleted from PLMR_TASK_SRCH_QRY_DTLS :"
						+ count);

				LOG.info("Delete Query for PLMR_TASK_SRCH_QRYS :"
						+ PLMQueryConstants.QRY_NAME_DELETE_FROM_SRCH_QRYS);
				count = getSimpleJdbcTemplate().update(
						PLMQueryConstants.QRY_NAME_DELETE_FROM_SRCH_QRYS,
						taskSearchQrySeqId);
				LOG.info("Succesfully Data deleted from PLMR_TASK_SRCH_QRYS :"
						+ count);
				// }
			}
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return count;
	}

	/**
	 * This method is used for queryNameCheck
	 * 
	 * @param queryName
	 *            ,ssoId
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public boolean queryNameCheck(String ssoId, String queryName)
			throws PLMCommonException {
		boolean isQueryNameExist = false;
		try {
			LOG.info("Query for Checking Query Name Exist already : "
					+ PLMQueryConstants.GET_TASK_SAVE_SEARCH_QUERY_NAME);
			int count = getSimpleJdbcTemplate().queryForInt(
					PLMQueryConstants.GET_TASK_SAVE_SEARCH_QUERY_NAME,
					new Object[] { ssoId, queryName });
			if (count > 0) {
				isQueryNameExist = true;
			} else {
				isQueryNameExist = false;
			}
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return isQueryNameExist;
	}

	/**
	 * This method is used for getTaskSearchSavedFields
	 * 
	 * @param selectedQueryName
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> getTaskSearchSavedFields(
			String selectedQueryName) throws PLMCommonException {
		List<PLMTaskSearchData> taskSearchSavedFields = new ArrayList<PLMTaskSearchData>();
		try {
			LOG.info("Query for Getting Task Search Saved Field Values : "
					+ PLMQueryConstants.GET_TASK_SRCH_SAVED_FIELDS);
			taskSearchSavedFields = getSimpleJdbcTemplate().query(
					PLMQueryConstants.GET_TASK_SRCH_SAVED_FIELDS,
					new TaskSearchSavedFieldsMapper(), selectedQueryName);
			LOG.info("Result of Task Saved Search Values : "
					+ taskSearchSavedFields.size());
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return taskSearchSavedFields;
	}

	/**
	 * Row mapper for getting taskSearchSavedFieldsMapper
	 */
	// private static ParameterizedRowMapper<PLMTaskSearchData>
	// taskSearchSavedFieldsMapper = new
	// ParameterizedRowMapper<PLMTaskSearchData>() {
	private static final class TaskSearchSavedFieldsMapper implements
			ParameterizedRowMapper<PLMTaskSearchData> {
		public PLMTaskSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMTaskSearchData tempData = new PLMTaskSearchData();
			tempData.setFieldNm(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_SRCH_FIELD_NM)));
			tempData.setFieldVal(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_SRCH_FIELD_VAL)));
			return tempData;
		}
		// };
	}

	/**
	 * This method is used for getTypeValue
	 * 
	 * @param aClob
	 * @param colIndex
	 * @param sqlType
	 * @param typeName
	 * @return StringBuffer
	 * @throws SQLException
	 */
	public static StringBuffer getTypeValue(Clob aClob, int colIndex,
			int sqlType, String typeName) throws SQLException {
		try {
			final StringBuffer outputBuffer = new StringBuffer();
			if (aClob != null) {
				final Reader clobReader = aClob.getCharacterStream();
				int length = 0;// (int) aClob.length();
				char[] inputBuffer = new char[PLMConstants.N_1024];
				while ((length = clobReader.read(inputBuffer)) != PLMConstants.N_NEG_1) {
					outputBuffer.append(inputBuffer, 0, length);
				}
			}
			return outputBuffer;
		} catch (IOException e) {
			throw new SQLException(e.toString());
		}
	}

	/**
	 * Row mapper for getting taskSaveSearchReportMapper
	 */
	// private static ParameterizedRowMapper<PLMTaskSearchData>
	// taskSaveSearchReportMapper = new
	// ParameterizedRowMapper<PLMTaskSearchData>() {
	private static final class TaskSaveSearchReportMapper implements
			ParameterizedRowMapper<PLMTaskSearchData> {
		public PLMTaskSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMTaskSearchData taskSaveSearchData = new PLMTaskSearchData();
			int rowCounting = rowCount;
			taskSaveSearchData.setSeqID(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_SRCH_QRY_SEQ_ID)));
			taskSaveSearchData.setQueryName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_SRCH_QRY_NM)));
			taskSaveSearchData.setSerialNo(++rowCounting);
			return taskSaveSearchData;
		}
		// };
	}

	/**
	 * This method is used for getTaskDetailedReport
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> getTaskDetailedReport(
			StringBuffer searchResultsQuery) throws PLMCommonException {
		List<PLMTaskSearchData> SearchResultList = null;
		try {
			SearchResultList = getSimpleJdbcTemplate()
					.query(searchResultsQuery.toString(),
							new TaskDetailReportMapper());
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return SearchResultList;
	}

	/**
	 * This method is used for getPartDropDownvalues
	 * 
	 * @param searchResultsQry
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getRdoValues()
			throws PLMCommonException {
		LOG.info("Entering getPartDropDownvalues Method");
		Map<String, List<SelectItem>> dropdownlist = new HashMap<String, List<SelectItem>>();
		List<SelectItem> rdolist = null;
		try {
			LOG.info("Query for RDO MultiSelect Dropdown List : "
					+ PLMOfflineQueries.RDO_DROPDOWN_LIST);
			rdolist = getSimpleJdbcTemplate().query(
					PLMOfflineQueries.RDO_DROPDOWN_LIST, new DropMapper1());
			Collections.sort(rdolist, new PLMUtils.SortListSelItmLbl());
			dropdownlist.put("rdolist", rdolist);
			LOG.info("Exiting getPartDropDownvalues Method");
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return dropdownlist;
	}

	/**
	 * Row mapper for getting dropMapper1
	 */
	// private static ParameterizedRowMapper<SelectItem> dropMapper1 = new
	// ParameterizedRowMapper<SelectItem>() {
	private static final class DropMapper1 implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(
					rs.getString(PLMConstants.RDO_NAME));
			return selectItem;
		}
		// };
	}

	/**
	 * This method is used for displaySelectedEccnTag
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> displaySelectedEccnTag()
			throws PLMCommonException {
		Map<String, List<SelectItem>> eCCNTagMaplist = new HashMap<String, List<SelectItem>>();
		List<SelectItem> eccnTaglist = null;
		try {
			LOG.info("Query to get ECCN_TAG dropdown list : "
					+ PLMOfflineQueries.ECCN_TAG_DROPDOWN_LIST);
			eccnTaglist = getSimpleJdbcTemplate().query(
					PLMOfflineQueries.ECCN_TAG_DROPDOWN_LIST,
					new EccnSelectListDetails());
			Collections.sort(eccnTaglist, new PLMUtils.SortListSelItmLbl());
			LOG.info("ECCN List fetched...");
			eCCNTagMaplist.put("eccnTaglist", eccnTaglist);
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return eCCNTagMaplist;
	}

	/**
	 * Row mapper for getting eccnSelectListDetails
	 */
	private static final class EccnSelectListDetails implements
			ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(
					rs.getString(PLMConstants.ECCN_TAG_LIST));
			return selectItem;
		}
	};

	/**
	 * Row mapper for getting taskDetailReportMapper
	 */
	// private static ParameterizedRowMapper<PLMTaskSearchData>
	// taskDetailReportMapper = new ParameterizedRowMapper<PLMTaskSearchData>()
	// {
	private static final class TaskDetailReportMapper implements
			ParameterizedRowMapper<PLMTaskSearchData> {
		public PLMTaskSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMTaskSearchData taskData = new PLMTaskSearchData();
			taskData.setName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_NAME)));
			taskData.setTitle(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_TITLE)));
			taskData.setDesc(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_DESCRIPTION)));
			taskData.setState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_STATE_NAME)));
			taskData.setOwner(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_OWNER_SSO)));
			taskData.setOwnerName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_OWNER_NAME)));
			taskData.setTaskName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_NAME)));
			/*taskData.setPercentageComplete(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PCT_COMPLETE)));
			taskData.setOrginator(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ORIGINATOR)));
			taskData.setOrginatorName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ORIGINATOR_NAME)));*/
			taskData.setEstimatedFinish(rs
					.getDate(PLMConstants.ESTIMATED_FINISH));
			taskData.setActualFinish(rs.getDate(PLMConstants.ACTUAL_FINISH));
			/*taskData.setStatus(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.STATUS)));
			taskData.setTaskApproval(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_APPROVAL)));*/
			taskData.setDuration(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_ACTUAL_DURATION)));
			taskData.setAssociateitem(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ASSOCIATED_ITEM)));
		/*	taskData.setNote(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.NOTES)));
			taskData.setTaskReq(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_REQUIREMENT)));
			taskData.setSynopsis(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.SYNOPSIS)));
			taskData.setProjectrole(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PROJECT_ROLE)));
			taskData.setPolicy(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.POLICY)));*/
			taskData.setTaskResponsiblity(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_RESPONSIBLITY)));
			taskData.setTaskResponsiblityName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_RESPONSIBLITY_NAME)));
			taskData.setFindSource(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.VOUCHER_FUNDING_SOURCE)));
			
			/*taskData.setTitle(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ACTIVITY_CODE_TITLE)));*/
			taskData.setType(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DELIVERABLES_TYPE)));
			taskData.setAction(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ACTION)));
			taskData.setApproveStatus(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.APPROVAL_STATUS)));
			taskData.setAssignee(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ASSIGNEES)));
			taskData.setAssigneeName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ASSIGNEES_NAME)));
			taskData.setDeliverable(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DELIVERABLES)));
			taskData.setProjectName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PROJECT_NAME)));
			taskData.setProjectDesc(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PROJECT_DESCRIPTION)));
			/*taskData.setGeActivityCode(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GE_ACTIVITY_CODE)));*/
			taskData.setContractName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CONTRACT_NAME)));
			taskData.setRequiredHours(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.REQUIRED_HOURS)));
			taskData.setEstimatedStart(null);
			if (rs.getDate(PLMConstants.ESTIMATED_START) != null) {
				taskData.setEstimatedStart(rs
						.getDate(PLMConstants.ESTIMATED_START));
			}
			taskData.setActualHours(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ACTUAL_HOURS)));
			taskData.setActualStart(null);
			if (rs.getDate(PLMConstants.ACTUAL_START) != null) {
				taskData.setActualStart(rs.getDate(PLMConstants.ACTUAL_START));
			}
			taskData.setEstimatedDuration(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ESTIMATED_DURATION)));
			taskData.setMfgIndicator(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GE_MFGG_DELIVERABLE_INDR)));
			taskData.setDeliverable(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DELIVERABLES)));
			taskData.setTaskResponsiblityUnit(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GE_TASK_RESPONSIBLE_UNIT)));
			taskData.setMfgFinish(rs.getDate(PLMConstants.GE_MFGG_NEED_DATE));
			taskData.setCustomerFinish(rs
					.getDate(PLMConstants.GE_CSTMR_NEED_DATE));
			taskData.setAssociatedName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ASSOCIATED_ITEM)));
			taskData.setGeTotalFloat(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GE_TOTAL_FLOAT)));
			taskData.setGeLateFinishDate(rs
					.getDate(PLMConstants.GE_LATE_FINISH_DATE));
			taskData.setGeEarlyFinishDate(rs
					.getDate(PLMConstants.GE_EARLY_FINISH_DATE));
			taskData.setCreationDate(rs.getDate(PLMConstants.CREATION_DATE));
			taskData.setActionTaken(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ACTION_TAKEN)));
			taskData.setPendingEffort(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PENDING_EFFORT)));
			taskData.setTotalEffort(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TOTAL_EFFORT)));
			taskData.setGeRemainingHr(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GE_REMAINING_HOURS)));
			taskData.setGePalnnedEffort(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GE_PLANNED_EFFORT)));
			return taskData;
		}
		// };
	}

	// ADDED BY SUDHAKAR FOR PREDESSOR SUCCESSOR PAGE
	/**
	 * This method is used for getSucesPredessorData
	 * 
	 * @param searchResultsQry
	 * @param selectedTaskDetails
	 * @param selectedId
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> getSucesPredessorData(
			StringBuffer searchResultsQry, String selectedTaskDetails,
			Map<String, String> selectedId) throws PLMCommonException {
		List<String> availableId = null;
		List<PLMTaskSearchData> searchResultList = null;
		List<PLMTaskSearchData> searchResultList1 = null;
		List<PLMTaskSearchData> searchResultFirstList = new ArrayList<PLMTaskSearchData>();
		String addedProjectName = "";
		listCount.set(0);
		listCount.set(0);
		List<String> projectNameList = null;
		List<PLMTaskSearchData> plmArLst1 = new ArrayList<PLMTaskSearchData>();
		List<PLMTaskSearchData> plmArLstMegedList = new ArrayList<PLMTaskSearchData>();
		projectNameList = new ArrayList<String>();
		taskDataMap = new HashMap<String, PLMTaskSearchData>();
		plmArLst = new ArrayList<PLMTaskSearchData>();
		availableId = new ArrayList<String>();
		selectedIdList = selectedId;
		boolean succ = false;
		String timeStamp = null;
		String VT_PRED =null;
		String VTCONCT =null;

		try {
			timeStamp = PLMUtils.volTableFormatDate();
			VT_PRED = PLMConstants.VT_PRED.concat(timeStamp);
			VTCONCT = PLMConstants.VTCONCT.concat(timeStamp);

			searchResultsQry.append(PLMSearchQueries.PRED_SUCC_QUERY4);
			searchResultList = getSimpleJdbcTemplate().query(
					searchResultsQry.toString(), new ScsrPredMapper());
			StringBuffer createVolatilePredSucc = new StringBuffer();
			createVolatilePredSucc.append(PLMSearchQueries.CREATE_PRED_SUCC_VT_ONE_1.replace(PLMConstants.VT_PRED, VT_PRED));

			if (searchResultList != null && searchResultList.size() > 0) {
				LOG.info("searchResultList------->" + searchResultList.size());

				for (PLMTaskSearchData prefixSuffix : searchResultList) {
					availableId.add(prefixSuffix.getTaskId());
					if (!addedProjectName.contains(prefixSuffix
							.getOrTaskPreTask())) {
						addedProjectName = addedProjectName + ","
								+ prefixSuffix.getOrTaskPreTask();
						projectNameList.add(prefixSuffix.getOrTaskPreTask());
						PLMTaskSearchData taskData2 = new PLMTaskSearchData();
						if (prefixSuffix.isTaskNameActive()) {
							taskData2.setTaskNameActive(true);
						} else {
							taskData2.setTaskNameActive(false);
						}
						taskData2.setPredSuccName("");
						taskData2.setOrTaskPreTask(prefixSuffix
								.getOrTaskPreTask());
						taskData2.setProjectName(prefixSuffix.getProjectName());
						taskData2.setTaskId(prefixSuffix.getOrTaskPreTask());
						taskData2.setTaskTitle(prefixSuffix.getTaskTitle());

						availableId.add(prefixSuffix.getOrTaskPreTask());
						String exist = prefixSuffix.getProjectName() + ","
								+ taskData2.getOrTaskPreTask();
						taskDataMap.put(exist, taskData2);
						searchResultFirstList.add(taskData2);
					}
				}

				if (searchResultFirstList.size() > 0) {
					for (PLMTaskSearchData firstList : searchResultFirstList) {
						searchResultList.add(firstList);
					}
				}
			}

			if (taskDataMap.size() != 0) {

				createVolatilePredSucc.append(" WHERE TASK_ID IN (");
				if (availableId.size() > 0) {

					for (int i = 0; i < availableId.size(); i++) {
						if (i == availableId.size() - 1) {
							createVolatilePredSucc.append("'");
							createVolatilePredSucc.append(availableId.get(i));
							createVolatilePredSucc.append("')");
						} else {
							createVolatilePredSucc.append("'");
							createVolatilePredSucc.append(availableId.get(i));
							createVolatilePredSucc.append("',");
						}
					}
				}
				createVolatilePredSucc.append(PLMSearchQueries.CREATE_PRED_SUCC_VT_ONE_2);
				
				LOG.info("Query for Creating VT_PRED : " + createVolatilePredSucc);
				getJdbcTemplate().execute(createVolatilePredSucc.toString());

				StringBuffer createVolatileConcat = new StringBuffer();
				createVolatileConcat.append(PLMSearchQueries.CREATE_PRED_SUCC_VT_TWO.replace(PLMConstants.VTCONCT, VTCONCT).replace(PLMConstants.VT_PRED, VT_PRED));
			
				LOG.info("Query for Creating VTCONCT : " + createVolatileConcat);
				getJdbcTemplate().execute(createVolatileConcat.toString());
				
				StringBuffer finalQueryDt = new StringBuffer();
				finalQueryDt.append(PLMSearchQueries.PRED_SUCC_VT_FINAL2.replace(PLMConstants.VTCONCT, VTCONCT).replace(PLMConstants.VT_PRED, VT_PRED));
				
				LOG.info("Query for Exectuing Final Data 2 : " + finalQueryDt);
				searchResultList1 = getSimpleJdbcTemplate().query(
						finalQueryDt.toString(), new PredSuccDetailsMpr());

				// for getting the results from both the lists

				if (searchResultList != null && searchResultList.size() > 0
						&& searchResultList1 != null
						&& searchResultList1.size() > 0) {
					for (PLMTaskSearchData firstList : searchResultList) {
						for (PLMTaskSearchData secondList : searchResultList1) {
							if (firstList.getTaskId().equalsIgnoreCase(
									secondList.getTaskId())) {
								PLMTaskSearchData taskDataNew = new PLMTaskSearchData();
								taskDataNew.setProjectName(firstList
										.getProjectName());
								taskDataNew.setPredSuccName(firstList
										.getPredSuccName());
								taskDataNew.setGeActivityCode(firstList
										.getGeActivityCode());
								taskDataNew.setTaskId(firstList.getTaskId());
								taskDataNew.setAvailableName(firstList
										.getAvailableName());
								taskDataNew
										.setTaskName(firstList.getTaskName());
								// taskDataNew.setTaskTitle(firstList.getTaskTitle());
								taskDataNew.setDelay(firstList.getDelay());
								taskDataNew.setDependencyType(firstList
										.getDependencyType());
								taskDataNew.setOrTaskPreTask(firstList
										.getOrTaskPreTask());
								taskDataNew.setTaskTitle(secondList
										.getTaskTitle());
								taskDataNew.setState(secondList.getState());
								taskDataNew.setPolicy(secondList.getPolicy());
								taskDataNew.setDeliverable(secondList
										.getDeliverable());
								taskDataNew.setAssociateitem(secondList
										.getAssociateitem());
								taskDataNew.setEstimatedStart(secondList
										.getEstimatedStart());
								taskDataNew.setEstimatedFinish(secondList
										.getEstimatedFinish());
								taskDataNew.setRequiredHours(secondList
										.getRequiredHours());
								taskDataNew.setEstimatedDuration(secondList
										.getEstimatedDuration());
								taskDataNew.setActualStart(secondList
										.getActualStart());
								taskDataNew.setActualFinish(secondList
										.getActualFinish());
								taskDataNew.setActualHours(secondList
										.getActualHours());
								taskDataNew.setPercentageComplete(secondList
										.getPercentageComplete());
								taskDataNew.setRespPrsnNM(secondList
										.getRespPrsnNM());
								taskDataNew.setVoucherfind(secondList
										.getVoucherfind());
								taskDataNew.setOwner(secondList.getOwner());
								taskDataNew.setOwnerName(secondList
										.getOwnerName());
								taskDataNew.setTaskApproval(secondList
										.getTaskApproval());
								taskDataNew.setNote(secondList.getNote());
								taskDataNew.setTaskReq(secondList.getTaskReq());
								taskDataNew.setSynopsis(secondList
										.getSynopsis());
								taskDataNew.setProjectrole(secondList
										.getProjectrole());
								taskDataNew.setAction(secondList.getAction());
								taskDataNew.setApproveStatus(secondList
										.getApproveStatus());
								taskDataNew.setTaskName(secondList
										.getTaskName());

								// Newly setting fields
								taskDataNew.setRespSso(secondList.getRespSso());
								taskDataNew.setOrignator(secondList
										.getOrignator());
								taskDataNew.setOrginatorName(secondList
										.getOrginatorName());
								taskDataNew.setGeMfggDeliverableIndr(secondList
										.getGeMfggDeliverableIndr());
								taskDataNew.setGeMfggNeedDate(secondList
										.getGeMfggNeedDate());
								taskDataNew.setGeCstmrNeedDate(secondList
										.getGeCstmrNeedDate());
								taskDataNew.setGeTaskResponsibleUnit(secondList
										.getGeTaskResponsibleUnit());
								
								taskDataNew.setCreationDate(secondList.getCreationDate());
								taskDataNew.setActionTaken(secondList.getActionTaken());
								taskDataNew.setPendingEffort(secondList.getPendingEffort());
								taskDataNew.setTotalEffort(secondList.getTotalEffort());
								taskDataNew.setGeRemainingHr(secondList.getGeRemainingHr());
								taskDataNew.setGePalnnedEffort(secondList.getGePalnnedEffort());
								taskDataNew.setExpctdFinishDt(secondList.getExpctdFinishDt());
								taskDataNew.setLateStrtDt(secondList.getLateStrtDt());
								
								plmArLstMegedList.add(taskDataNew);
							}
						}
					}
				}

				// end of logic from both the lists

				// New Added Code for gettign Prec , Original task,Succ
				if (plmArLstMegedList.size() > 0) {
					LOG.info("plmArLstMegedList.size()>>>>>>"
							+ plmArLstMegedList.size());
					LOG.info("succ>> " + succ);
					for (int j = 0; j < projectNameList.size(); j++) {
						succ = false;
						for (int i = 0; i < plmArLstMegedList.size(); i++) {
							PLMTaskSearchData taskDataNew = new PLMTaskSearchData();
							PLMTaskSearchData prefixSuffix = plmArLstMegedList
									.get(i);
							if (projectNameList.get(j).equalsIgnoreCase(
									prefixSuffix.getOrTaskPreTask())) {
								if (prefixSuffix.getPredSuccName()
										.equalsIgnoreCase("P")) {
									taskDataNew.setProjectName(prefixSuffix
											.getProjectName());
									taskDataNew.setPredSuccName(prefixSuffix
											.getPredSuccName());
									taskDataNew.setGeActivityCode(prefixSuffix
											.getGeActivityCode());
									taskDataNew.setTaskId(prefixSuffix
											.getTaskId());
									taskDataNew.setAvailableName(prefixSuffix
											.getAvailableName());
									taskDataNew.setTaskName(prefixSuffix
											.getTaskName());
									taskDataNew.setTaskTitle(prefixSuffix
											.getTaskTitle());
									taskDataNew.setDelay(prefixSuffix
											.getDelay());
									taskDataNew.setDependencyType(prefixSuffix
											.getDependencyType());
									taskDataNew.setState(prefixSuffix
											.getState());
									taskDataNew.setPolicy(prefixSuffix
											.getPolicy());
									taskDataNew.setDeliverable(prefixSuffix
											.getDeliverable());
									taskDataNew.setAssociateitem(prefixSuffix
											.getAssociateitem());
									taskDataNew.setEstimatedStart(prefixSuffix
											.getEstimatedStart());
									taskDataNew.setEstimatedFinish(prefixSuffix
											.getEstimatedFinish());
									taskDataNew.setRequiredHours(prefixSuffix
											.getRequiredHours());
									taskDataNew
											.setEstimatedDuration(prefixSuffix
													.getEstimatedDuration());
									taskDataNew.setActualStart(prefixSuffix
											.getActualStart());
									taskDataNew.setActualFinish(prefixSuffix
											.getActualFinish());
									taskDataNew.setActualHours(prefixSuffix
											.getActualHours());
									taskDataNew.setStatus(prefixSuffix
											.getStatus());
									taskDataNew
											.setPercentageComplete(prefixSuffix
													.getPercentageComplete());
									taskDataNew.setRespPrsnNM(prefixSuffix
											.getRespPrsnNM());
									taskDataNew.setVoucherfind(prefixSuffix
											.getVoucherfind());
									taskDataNew.setOwner(prefixSuffix
											.getOwner());
									taskDataNew.setOwnerName(prefixSuffix
											.getOwnerName());
									taskDataNew.setTaskApproval(prefixSuffix
											.getTaskApproval());
									taskDataNew.setNote(prefixSuffix.getNote());
									taskDataNew.setTaskReq(prefixSuffix
											.getTaskReq());
									taskDataNew.setSynopsis(prefixSuffix
											.getSynopsis());
									taskDataNew.setProjectrole(prefixSuffix
											.getProjectrole());
									taskDataNew.setAction(prefixSuffix
											.getAction());
									taskDataNew.setApproveStatus(prefixSuffix
											.getApproveStatus());
									taskDataNew.setTaskName(prefixSuffix
											.getTaskName());

									// Newly setting fields
									taskDataNew.setRespSso(prefixSuffix
											.getRespSso());
									taskDataNew.setOrignator(prefixSuffix
											.getOrignator());
									taskDataNew.setOrginatorName(prefixSuffix
											.getOrginatorName());
									taskDataNew
											.setGeMfggDeliverableIndr(prefixSuffix
													.getGeMfggDeliverableIndr());
									taskDataNew.setGeMfggNeedDate(prefixSuffix
											.getGeMfggNeedDate());
									taskDataNew.setGeCstmrNeedDate(prefixSuffix
											.getGeCstmrNeedDate());
									taskDataNew
											.setGeTaskResponsibleUnit(prefixSuffix
													.getGeTaskResponsibleUnit());
									taskDataNew.setCreationDate(prefixSuffix.getCreationDate());
									taskDataNew.setActionTaken(prefixSuffix.getActionTaken());
									taskDataNew.setPendingEffort(prefixSuffix.getPendingEffort());
									taskDataNew.setTotalEffort(prefixSuffix.getTotalEffort());
									taskDataNew.setGeRemainingHr(prefixSuffix.getGeRemainingHr());
									taskDataNew.setGePalnnedEffort(prefixSuffix.getGePalnnedEffort());
									taskDataNew.setExpctdFinishDt(prefixSuffix.getExpctdFinishDt());
									taskDataNew.setLateStrtDt(prefixSuffix.getLateStrtDt());

									taskDataNew.setLineBrkr(false);
									plmArLst1.add(taskDataNew);
								}
							}
						}
						for (int i = 0; i < plmArLstMegedList.size(); i++) {
							PLMTaskSearchData taskDataNew = new PLMTaskSearchData();
							PLMTaskSearchData prefixSuffix = plmArLstMegedList
									.get(i);
							if (projectNameList.get(j).equalsIgnoreCase(
									prefixSuffix.getOrTaskPreTask())) {
								if (!prefixSuffix.getPredSuccName()
										.equalsIgnoreCase("S")
										&& !prefixSuffix.getPredSuccName()
												.equalsIgnoreCase("P")) {

									taskDataNew.setProjectName(prefixSuffix
											.getProjectName());
									taskDataNew.setPredSuccName(prefixSuffix
											.getPredSuccName());
									taskDataNew.setGeActivityCode(prefixSuffix
											.getGeActivityCode());
									taskDataNew.setTaskId(prefixSuffix
											.getTaskId());
									taskDataNew.setAvailableName(prefixSuffix
											.getAvailableName());
									taskDataNew.setTaskName(prefixSuffix
											.getTaskName());
									taskDataNew.setTaskTitle(prefixSuffix
											.getTaskTitle());
									taskDataNew.setDelay(prefixSuffix
											.getDelay());
									taskDataNew.setDependencyType(prefixSuffix
											.getDependencyType());
									taskDataNew.setState(prefixSuffix
											.getState());
									taskDataNew.setPolicy(prefixSuffix
											.getPolicy());
									taskDataNew.setDeliverable(prefixSuffix
											.getDeliverable());
									taskDataNew.setAssociateitem(prefixSuffix
											.getAssociateitem());
									taskDataNew.setEstimatedStart(prefixSuffix
											.getEstimatedStart());
									taskDataNew.setEstimatedFinish(prefixSuffix
											.getEstimatedFinish());
									taskDataNew.setRequiredHours(prefixSuffix
											.getRequiredHours());
									taskDataNew
											.setEstimatedDuration(prefixSuffix
													.getEstimatedDuration());
									taskDataNew.setActualStart(prefixSuffix
											.getActualStart());
									taskDataNew.setActualFinish(prefixSuffix
											.getActualFinish());
									taskDataNew.setActualHours(prefixSuffix
											.getActualHours());
									// taskDataNew.setActualHours(PLMUtils.checkNullVal(rs.getString("ACTUAL_DURATION")));
									taskDataNew.setStatus(prefixSuffix
											.getStatus());
									taskDataNew
											.setPercentageComplete(prefixSuffix
													.getPercentageComplete());
									taskDataNew.setRespPrsnNM(prefixSuffix
											.getRespPrsnNM());
									// taskDataNew.setAssignee(PLMUtils.checkNullVal(rs.getString("ASSIGNEES")));
									// taskDataNew.setAssigneeName(PLMUtils.checkNullVal(rs.getString("ASSIGNEES_NAME")));
									taskDataNew.setVoucherfind(prefixSuffix
											.getVoucherfind());
									taskDataNew.setOwner(prefixSuffix
											.getOwner());
									taskDataNew.setOwnerName(prefixSuffix
											.getOwnerName());
									taskDataNew.setTaskApproval(prefixSuffix
											.getTaskApproval());
									taskDataNew.setNote(prefixSuffix.getNote());
									taskDataNew.setTaskReq(prefixSuffix
											.getTaskReq());
									taskDataNew.setSynopsis(prefixSuffix
											.getSynopsis());
									taskDataNew.setProjectrole(prefixSuffix
											.getProjectrole());
									// taskDataNew.setAssociateitem(PLMUtils.checkNullVal(rs.getString("ASSOCIATED_TYPE")));
									taskDataNew.setAction(prefixSuffix
											.getAction());
									taskDataNew.setApproveStatus(prefixSuffix
											.getApproveStatus());
									taskDataNew.setTaskName(prefixSuffix
											.getTaskName());

									// Newly setting fields
									taskDataNew.setRespSso(prefixSuffix
											.getRespSso());
									taskDataNew.setOrignator(prefixSuffix
											.getOrignator());
									taskDataNew.setOrginatorName(prefixSuffix
											.getOrginatorName());
									taskDataNew
											.setGeMfggDeliverableIndr(prefixSuffix
													.getGeMfggDeliverableIndr());
									taskDataNew.setGeMfggNeedDate(prefixSuffix
											.getGeMfggNeedDate());
									taskDataNew.setGeCstmrNeedDate(prefixSuffix
											.getGeCstmrNeedDate());
									taskDataNew
											.setGeTaskResponsibleUnit(prefixSuffix
													.getGeTaskResponsibleUnit());
									taskDataNew.setCreationDate(prefixSuffix.getCreationDate());
									taskDataNew.setActionTaken(prefixSuffix.getActionTaken());
									taskDataNew.setPendingEffort(prefixSuffix.getPendingEffort());
									taskDataNew.setTotalEffort(prefixSuffix.getTotalEffort());
									taskDataNew.setGeRemainingHr(prefixSuffix.getGeRemainingHr());
									taskDataNew.setGePalnnedEffort(prefixSuffix.getGePalnnedEffort());
									taskDataNew.setExpctdFinishDt(prefixSuffix.getExpctdFinishDt());
									taskDataNew.setLateStrtDt(prefixSuffix.getLateStrtDt());


									taskDataNew.setLineBrkr(false);
									plmArLst1.add(taskDataNew);
								}
							}
						}

						for (int i = 0; i < plmArLstMegedList.size(); i++) {
							PLMTaskSearchData taskDataNew = new PLMTaskSearchData();
							PLMTaskSearchData prefixSuffix = plmArLstMegedList
									.get(i);

							if (projectNameList.get(j).equalsIgnoreCase(
									prefixSuffix.getOrTaskPreTask())) {
								if (prefixSuffix.getPredSuccName()
										.equalsIgnoreCase("S")) {
									taskDataNew.setProjectName(prefixSuffix
											.getProjectName());
									taskDataNew.setPredSuccName(prefixSuffix
											.getPredSuccName());
									taskDataNew.setGeActivityCode(prefixSuffix
											.getGeActivityCode());
									taskDataNew.setTaskId(prefixSuffix
											.getTaskId());
									taskDataNew.setAvailableName(prefixSuffix
											.getAvailableName());
									taskDataNew.setTaskName(prefixSuffix
											.getTaskName());
									taskDataNew.setTaskTitle(prefixSuffix
											.getTaskTitle());
									taskDataNew.setDelay(prefixSuffix
											.getDelay());
									taskDataNew.setDependencyType(prefixSuffix
											.getDependencyType());
									taskDataNew.setState(prefixSuffix
											.getState());
									taskDataNew.setPolicy(prefixSuffix
											.getPolicy());
									taskDataNew.setDeliverable(prefixSuffix
											.getDeliverable());
									taskDataNew.setAssociateitem(prefixSuffix
											.getAssociateitem());
									taskDataNew.setEstimatedStart(prefixSuffix
											.getEstimatedStart());
									taskDataNew.setEstimatedFinish(prefixSuffix
											.getEstimatedFinish());
									taskDataNew.setRequiredHours(prefixSuffix
											.getRequiredHours());
									taskDataNew
											.setEstimatedDuration(prefixSuffix
													.getEstimatedDuration());
									taskDataNew.setActualStart(prefixSuffix
											.getActualStart());
									taskDataNew.setActualFinish(prefixSuffix
											.getActualFinish());
									taskDataNew.setActualHours(prefixSuffix
											.getActualHours());
									// taskDataNew.setActualHours(PLMUtils.checkNullVal(rs.getString("ACTUAL_DURATION")));
									taskDataNew.setStatus(prefixSuffix
											.getStatus());
									taskDataNew
											.setPercentageComplete(prefixSuffix
													.getPercentageComplete());
									taskDataNew.setRespPrsnNM(prefixSuffix
											.getRespPrsnNM());
									// taskDataNew.setAssignee(PLMUtils.checkNullVal(rs.getString("ASSIGNEES")));
									// taskDataNew.setAssigneeName(PLMUtils.checkNullVal(rs.getString("ASSIGNEES_NAME")));
									taskDataNew.setVoucherfind(prefixSuffix
											.getVoucherfind());
									taskDataNew.setOwner(prefixSuffix
											.getOwner());
									taskDataNew.setOwnerName(prefixSuffix
											.getOwnerName());
									taskDataNew.setTaskApproval(prefixSuffix
											.getTaskApproval());
									taskDataNew.setNote(prefixSuffix.getNote());
									taskDataNew.setTaskReq(prefixSuffix
											.getTaskReq());
									taskDataNew.setSynopsis(prefixSuffix
											.getSynopsis());
									taskDataNew.setProjectrole(prefixSuffix
											.getProjectrole());
									// taskDataNew.setAssociateitem(PLMUtils.checkNullVal(rs.getString("ASSOCIATED_TYPE")));
									taskDataNew.setAction(prefixSuffix
											.getAction());
									taskDataNew.setApproveStatus(prefixSuffix
											.getApproveStatus());
									taskDataNew.setTaskName(prefixSuffix
											.getTaskName());

									// Newly setting fields
									taskDataNew.setRespSso(prefixSuffix
											.getRespSso());
									taskDataNew.setOrignator(prefixSuffix
											.getOrignator());
									taskDataNew.setOrginatorName(prefixSuffix
											.getOrginatorName());
									taskDataNew
											.setGeMfggDeliverableIndr(prefixSuffix
													.getGeMfggDeliverableIndr());
									taskDataNew.setGeMfggNeedDate(prefixSuffix
											.getGeMfggNeedDate());
									taskDataNew.setGeCstmrNeedDate(prefixSuffix
											.getGeCstmrNeedDate());
									taskDataNew
											.setGeTaskResponsibleUnit(prefixSuffix
													.getGeTaskResponsibleUnit());
									taskDataNew.setCreationDate(prefixSuffix.getCreationDate());
									taskDataNew.setActionTaken(prefixSuffix.getActionTaken());
									taskDataNew.setPendingEffort(prefixSuffix.getPendingEffort());
									taskDataNew.setTotalEffort(prefixSuffix.getTotalEffort());
									taskDataNew.setGeRemainingHr(prefixSuffix.getGeRemainingHr());
									taskDataNew.setGePalnnedEffort(prefixSuffix.getGePalnnedEffort());
									taskDataNew.setExpctdFinishDt(prefixSuffix.getExpctdFinishDt());
									taskDataNew.setLateStrtDt(prefixSuffix.getLateStrtDt());


									taskDataNew.setLineBrkr(false);
									plmArLst1.add(taskDataNew);
								}
							}
						}

						int key = j;
						key = key + 1;
						if (projectNameList.size() > 1
								&& projectNameList.size() > key) {
							PLMTaskSearchData taskDataNew = new PLMTaskSearchData();
							taskDataNew.setLineBrkr(true);
							plmArLst1.add(taskDataNew);
						}

					}

				}

				LOG.info("plmArLst1.size()------->" + plmArLst1.size());

			}

		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return plmArLst1;
	}

	// ADDED BY SUDHAKAR FOR PREDESSOR SUCCESSOR PAGE
	/**
	 * Row mapper for getting sucessPredmapper
	 */
	// private static ParameterizedRowMapper<PLMTaskSearchData> sucessPredmapper
	// = new ParameterizedRowMapper<PLMTaskSearchData>() {
	private class ScsrPredMapper implements
			ParameterizedRowMapper<PLMTaskSearchData> {

		public PLMTaskSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMTaskSearchData taskData = new PLMTaskSearchData();
			String selectedId = "";
			taskData.setLineBrkr(false);
			taskData.setProjectName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PROJECT_NAME)));
			taskData.setPredSuccName(PLMUtils.checkNullVal(rs
					.getString("PRED_SUCC")));
			taskData.setGeActivityCode(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GE_ACTIVITY_CODE)));
			taskData.setTaskId(PLMUtils.checkNullVal(rs.getString("TASK_ID")));
			taskData.setAvailableName(PLMUtils.checkNullVal(rs
					.getString("NAME")));
			taskData.setTaskName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASKNAME)));
			taskData.setTaskTitle(PLMUtils.checkNullVal(rs
					.getString("TASK_TITLE")));
			taskData.setDelay(PLMUtils.checkNullVal(rs.getString("DELAY")));
			taskData.setDependencyType(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DEPENDENCY_TYPE)));
			String mapValue = taskData.getProjectName() + ","
					+ taskData.getAvailableName();
			String originalTaskId = selectedIdList.get(mapValue);
			taskData.setOrTaskPreTask(originalTaskId);
			if (oldTaskName == null && oldIndicator == null) {
				taskData.setLineBrkr(false);
			}
			if (oldTaskName != null
					&& !oldTaskName.equalsIgnoreCase(rs.getString("NAME"))) {
				rowVar.set(rowCount);
			}
			if (oldTaskName != null && rowVar.get() == rowCount) {
				taskData.setLineBrkr(true);
				listCount.getAndIncrement();
			}
			if (oldIndicator != null
					&& !oldIndicator
							.equalsIgnoreCase(rs.getString("PRED_SUCC"))
					&& oldTaskName.equalsIgnoreCase(rs.getString("NAME"))) {
				taskData.setTaskNameActive(true);
				taskData.setTaskNamePredessorActive(false);
				listCount.getAndIncrement();
			} else {
				taskData.setTaskNameActive(false);
			}
			if (oldIndicator != null && (oldIndicator.equalsIgnoreCase("P"))
					&& !oldTaskName.equalsIgnoreCase(rs.getString("NAME"))) {
				taskData.setTaskNameSuccessorActive(true);
				taskData.setTaskNamePredessorActive(false);
				listCount.getAndIncrement();
			}
			if (oldIndicator != null
					&& (rs.getString("PRED_SUCC").equalsIgnoreCase("S"))
					&& !oldTaskName.equalsIgnoreCase(rs.getString("NAME"))) {
				taskData.setTaskNamePredessorActive(true);
				taskData.setTaskNameSuccessorActive(false);
				listCount.getAndIncrement();
			}
			if (listCount.get() == rowCount
					&& rs.getString("PRED_SUCC").equalsIgnoreCase("P")
					&& oldTaskName != null) {
				taskData.setTaskNameSuccessorActive(true);
				taskData.setTaskNamePredessorActive(false);
			}
			taskData.setOrgTaskName(oldTaskName);
			oldIndicator = rs.getString("PRED_SUCC");
			oldTaskName = rs.getString("NAME");
			selectedId = originalTaskId + "," + taskData.getTaskId();
			taskDataMap.put(selectedId, taskData);
			return taskData;
		}
	}

	// };
	/**
	 * Row mapper for getting sucessPredmapper1
	 */
	// private static ParameterizedRowMapper<PLMTaskSearchData>
	// sucessPredmapper1 = new ParameterizedRowMapper<PLMTaskSearchData>() {

	private final class PredSuccDetailsMpr implements
			ParameterizedRowMapper<PLMTaskSearchData> {

		public PLMTaskSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMTaskSearchData taskData = new PLMTaskSearchData();
			taskData.setTaskTitle(PLMUtils.checkNullVal(rs
					.getString("TASK_TITLE")));
			taskData.setTaskId(PLMUtils.checkNullVal(rs.getString("TASK_ID")));
			taskData.setState(PLMUtils.checkNullVal(rs.getString("STATE")));
			taskData.setPolicy(PLMUtils.checkNullVal(rs.getString("POLICY")));
			taskData.setDeliverable(PLMUtils.checkNullVal(rs
					.getString("DELIVERABLES")));
			taskData.setAssociateitem(PLMUtils.checkNullVal(rs
					.getString("ASSOCIATED_ITEM")));
			taskData.setEstimatedStart(null);
			if (rs.getDate(PLMConstants.ESTIMATED_START) != null) {
				taskData.setEstimatedStart(rs
						.getDate(PLMConstants.ESTIMATED_START));
			}
			if (rs.getDate("ESTIMATED_FINISH") != null) {
				taskData.setEstimatedFinish((rs.getDate("ESTIMATED_FINISH")));
			}
			taskData.setRequiredHours(PLMUtils.checkNullVal(rs
					.getString("REQUIRED_HOURS")));
			taskData.setEstimatedDuration(PLMUtils.checkNullVal(rs
					.getString("ESTIMATED_DURATION")));
			taskData.setActualStart(null);
			if (rs.getDate(PLMConstants.ACTUAL_START) != null) {
				taskData.setActualStart(rs.getDate(PLMConstants.ACTUAL_START));
			}
			taskData.setActualFinish((rs.getDate("ACTUAL_FINISH")));
			taskData.setActualHours(PLMUtils.checkNullVal(rs
					.getString("ACTUAL_HOURS")));
		/*	taskData.setStatus(PLMUtils.checkNullVal(rs.getString("STATUS")));
			taskData.setPercentageComplete(PLMUtils.checkNullVal(rs
					.getString("PCT_COMPLETE")));*/
			taskData.setRespPrsnNM(PLMUtils.checkNullVal(rs
					.getString("TASK_RESPONSIBILITY_NAME")));
			taskData.setVoucherfind(PLMUtils.checkNullVal(rs
					.getString("VOUCHER_FUNDING_SOURCE")));
			taskData.setOwner(PLMUtils.checkNullVal(rs.getString("TASK_OWNR")));
			taskData.setOwnerName(PLMUtils.checkNullVal(rs
					.getString("OWNER_NAME")));
			/*taskData.setTaskApproval(PLMUtils.checkNullVal(rs
					.getString("TASK_APPROVAL")));
			taskData.setNote(PLMUtils.checkNullVal(rs.getString("NOTES")));
			taskData.setTaskReq(PLMUtils.checkNullVal(rs
					.getString("TASK_REQUIREMENT")));
			taskData.setSynopsis(PLMUtils.checkNullVal(rs.getString("SYNOPSIS")));
			taskData.setProjectrole(PLMUtils.checkNullVal(rs
					.getString("PROJECT_ROLE")));*/
			taskData.setAction(PLMUtils.checkNullVal(rs.getString("ACTION")));
			taskData.setApproveStatus(PLMUtils.checkNullVal(rs
					.getString("APPROVAL_STATUS")));
			taskData.setTaskName(PLMUtils.checkNullVal(rs.getString("NAME")));
			taskData.setRespSso(PLMUtils.checkNullVal(rs
					.getString("TASK_RESPONSIBILITY")));
			/*taskData.setOrignator(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ORIG_NATOR)));
			taskData.setOrginatorName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ORIGINATORNAME)));*/
			taskData.setGeMfggDeliverableIndr(PLMUtils.checkNullVal(rs
					.getString("GE_MFGG_DELIVERABLE_INDR")));
			taskData.setGeMfggNeedDate(null);
			if (rs.getDate("GE_MFGG_NEED_DATE") != null) {
				String geMnfDate = datefrmt.format(rs
						.getDate("GE_MFGG_NEED_DATE"));
				taskData.setGeMfggNeedDate(geMnfDate);
				taskData.setGeMfggNeedDateExl(rs.getDate("GE_MFGG_NEED_DATE"));
			}
			taskData.setGeCstmrNeedDate(null);
			if (rs.getDate("GE_CSTMR_NEED_DATE") != null) {
				String geCstmDate = datefrmt.format(rs
						.getDate("GE_CSTMR_NEED_DATE"));
				taskData.setGeCstmrNeedDate(geCstmDate);
				taskData.setGeCstmrNeedDateExl(rs.getDate("GE_CSTMR_NEED_DATE"));
			}
			taskData.setGeTaskResponsibleUnit(PLMUtils.checkNullVal(rs
					.getString("GE_TASK_RESPONSIBLE_UNIT")));
			taskData.setCreationDate(rs.getDate(PLMConstants.CREATION_DATE));
			taskData.setActionTaken(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ACTION_TAKEN)));
			taskData.setPendingEffort(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PENDING_EFFORT)));
			taskData.setTotalEffort(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TOTAL_EFFORT)));
			taskData.setGeRemainingHr(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GE_REMAINING_HOURS)));
			taskData.setGePalnnedEffort(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GE_PLANNED_EFFORT)));
			taskData.setExpctdFinishDt(rs.getDate(PLMConstants.GE_EXPECTED_FINISH_DATE));
			taskData.setLateStrtDt(rs.getDate(PLMConstants.GE_LATE_START_DATE));
			/*
			 * if(taskData!= null) {
			 */
			plmArLst.add(taskData);
			// }
			return taskData;
		}
	}

	// };
	// ENDED BY SUDHAKAR FOR PREDESSOR SUCCESSOR PAGE

	/**
	 * This method is used for getTaskDetailDiscussionRpt
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> getTaskDetailDiscussionRpt(
			StringBuffer searchResultsQuery) throws PLMCommonException {
		List<PLMTaskSearchData> SearchResultList = null;
		try {
			SearchResultList = getSimpleJdbcTemplate().query(
					searchResultsQuery.toString(),
					new TaskViewDiscussionReportMapper());
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return SearchResultList;
	}

	/**
	 * Row mapper for getting taskViewDiscussionReportMapper
	 */
	// private static ParameterizedRowMapper<PLMTaskSearchData>
	// taskViewDiscussionReportMapper = new
	// ParameterizedRowMapper<PLMTaskSearchData>() {
	private static final class TaskViewDiscussionReportMapper implements
			ParameterizedRowMapper<PLMTaskSearchData> {
		public PLMTaskSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMTaskSearchData taskData = new PLMTaskSearchData();
			taskData.setProjectName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PROJECT_NAME)));
			taskData.setName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_NAME)));
			taskData.setDescription(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_DESC)));
			// taskData.setUnitSerialNo(PLMUtils.checkNullVal(rs.getString(PLMConstants.UNIT_SERIAL_NO)));
			taskData.setGeActivityCode(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.GE_ACTIVITY_CODE)));
			taskData.setRespPrsnNM(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.RESP_PRSN_NM)));
			// taskData.setAssigneeName(PLMUtils.checkNullVal(rs.getString(PLMConstants.ASSIGNEES_NAME)));
			taskData.setRespUnitCode(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.RESP_UNIT_CODE)));
			taskData.setLateFinish(rs.getDate(PLMConstants.LATE_FINISH));
			taskData.setDiscussion(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DISCUSSION)));
			taskData.setDateEntered(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DATE_ENTERED)));
			taskData.setEnteredByUsrNM(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ENTERED_BY_USR_NM)));
			taskData.setCustNM(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.CUST_NM)));
			taskData.setCustNeedDate(rs.getDate(PLMConstants.CUST_NEED_DATE));
			taskData.setActualFinish(rs.getDate(PLMConstants.ACTUAL_FINISH));
			taskData.setEcrNo(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECR_NO)));
			taskData.setEcoNo(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECO_NO)));
			taskData.setModel(PLMUtils.checkNullVal(" "));

			if (rs.getDate(PLMConstants.DATE_ENTERED) != null) {
				taskData.setDateEnteredExl(rs
						.getTimestamp(PLMConstants.DATE_ENTERED));
			}

			return taskData;
		}
		// };
	}

	/**
	 * This method is used for getecoDetailsVolume
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMEcoSearchData> getecoDetailsVolume(
			StringBuffer searchResultsQry) throws PLMCommonException {
		List<PLMEcoSearchData> SearchResultList = null;

		LOG.info("FINAL QUERY IS getecoDetailsVolume : " + searchResultsQry);
		SearchResultList = getSimpleJdbcTemplate().query(
				searchResultsQry.toString(), new EcodetailsMapper());

		return SearchResultList;
	}

	/**
	 * This method is used for getAssigneeList
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> getAssigneeList(StringBuffer searchResultsQry)
			throws PLMCommonException {
		List<PLMTaskSearchData> SearchResultList = null;

		LOG.info("FINAL QUERY IS getAssigneeList : " + searchResultsQry);
		SearchResultList = getSimpleJdbcTemplate().query(
				searchResultsQry.toString(), new AssMapper());
		LOG.info("getEcoOwner SearchResultList size is : "
				+ SearchResultList.size());
		return SearchResultList;
	}

	/**
	 * Row mapper for getting assMapper
	 */
	// private static ParameterizedRowMapper<PLMTaskSearchData> assMapper = new
	// ParameterizedRowMapper<PLMTaskSearchData>() {
	private static final class AssMapper implements
			ParameterizedRowMapper<PLMTaskSearchData> {
		public PLMTaskSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			PLMTaskSearchData searchData = new PLMTaskSearchData();
			searchData.setAssignee(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ASSIGNEES)));

			return searchData;
		}
		// };
	}

	// Added by Raju to fetch taskSearchData
	/**
	 * This method is used for fetchTaskSearchDetails
	 * 
	 * @param seqId
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> fetchTaskSearchDetails(String seqId)
			throws PLMCommonException {
		List<PLMTaskSearchData> taskSearchSavedFields = new ArrayList<PLMTaskSearchData>();
		try {
			LOG.info("Query for Getting Task Search Saved Field Values : "
					+ PLMQueryConstants.GET_TASK_SRCH_SAVED_FIELDS_QUERY_TEXT);
			taskSearchSavedFields = getSimpleJdbcTemplate().query(
					PLMQueryConstants.GET_TASK_SRCH_SAVED_FIELDS_QUERY_TEXT,
					new TaskSearchDetailsMapper(), seqId);
			LOG.info("Result of Task Saved Search Values : "
					+ taskSearchSavedFields.size());
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return taskSearchSavedFields;
	}

	/**
	 * Row mapper for getting taskSearchDetailsMapper
	 */
	// private static ParameterizedRowMapper<PLMTaskSearchData>
	// taskSearchDetailsMapper = new ParameterizedRowMapper<PLMTaskSearchData>()
	// {
	private static final class TaskSearchDetailsMapper implements
			ParameterizedRowMapper<PLMTaskSearchData> {
		public PLMTaskSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMTaskSearchData tempData = new PLMTaskSearchData();
			// QRY_NM,FIELD_NM,FIELD_VAL
			tempData.setQueryName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.QUERY_NM)));
			tempData.setFieldNm(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_SRCH_FIELD_NM)));
			tempData.setFieldVal(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_SRCH_FIELD_VAL)));
			return tempData;
		}
		// };
	}

	// End Raju

	/**
	 * This method is used for getEccnDailyValues
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> getEccnOnScreenReport(
			List<String> rdoNamesList, List<String> eccnTagList)
			throws PLMCommonException {
		LOG.info("Entering getEccnOnScreenReport method in DAOIMPL--------");
		List<PLMTaskSearchData> eccnOnScreenDataList = null;
		try {
			StringBuffer searchResultsQry = new StringBuffer();
			searchResultsQry.append(PLMOfflineQueries.ECCN_OUTPUT_QUERY1);

			searchResultsQry.append(PLMOfflineQueries.ECCN_OUTPUT_QUERY2);
			searchResultsQry.append("(");
			searchResultsQry.append(PLMUtils.setListForQuery(rdoNamesList)
					+ ")");

			searchResultsQry.append(PLMOfflineQueries.ECCN_OUTPUT_QUERY3);
			searchResultsQry.append("(");
			searchResultsQry.append(PLMUtils.setListForEccnQuery(eccnTagList)
					+ ")");

			searchResultsQry.append(PLMOfflineQueries.ECCN_OUTPUT_QUERY4);

			searchResultsQry.append(PLMOfflineQueries.ECCN_OUTPUT_QUERY2);
			searchResultsQry.append("(");
			searchResultsQry.append(PLMUtils.setListForQuery(rdoNamesList)
					+ ")");

			searchResultsQry.append(PLMOfflineQueries.ECCN_OUTPUT_QUERY3);
			searchResultsQry.append("(");
			searchResultsQry.append(PLMUtils.setListForEccnQuery(eccnTagList)
					+ ")");

			searchResultsQry.append(PLMOfflineQueries.ECCN_OUTPUT_QUERY5);

			LOG.info("Eccn On Screen Report Query is ::::: "
					+ searchResultsQry.toString());
			eccnOnScreenDataList = getSimpleJdbcTemplate().query(
					searchResultsQry.toString(), eccnOnScreenDataListMapper);
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getEccnOnScreenReport method in DAOIMPL--------");
		return eccnOnScreenDataList;
	}

	/**
	 * Row mapper for getting taskEccnDailyMapper
	 */
	private static ParameterizedRowMapper<PLMTaskSearchData> eccnOnScreenDataListMapper = new ParameterizedRowMapper<PLMTaskSearchData>() {
		public PLMTaskSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMTaskSearchData taskData = new PLMTaskSearchData();
			taskData.setEccnRdo(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOC_RDO)));
			taskData.setEccnName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_NAME)));
			taskData.setEccnRevision(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.DOC_REV)));
			taskData.setEccnState(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TASK_STATE_NAME)));
			taskData.setEccnType1(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TYPE_ONE)));
			taskData.setEccnOriginationDate(rs
					.getDate(PLMConstants.ORIGINATION_DATE));
			taskData.setEccnReleaseDate(rs.getDate(PLMConstants.RELEASE_DATE));
			taskData.setEccnOriginatorSSO(rs
					.getString(PLMConstants.ORIGINATOR_SSO));
			taskData.setEccnEcn(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.ECCN_TAG)));

			/*
			 * taskData.setEccnPolicy(PLMUtils.checkNullVal(rs.getString(
			 * PLMConstants.POLICY)));
			 * taskData.setEccnDescription(PLMUtils.checkNullVal
			 * (rs.getString(PLMConstants.DOC_DESC)));
			 */

			return taskData;
		}
	};

	/**
	 * This method is used for getEccnOnScreenValues
	 * 
	 * @param searchResultsQry
	 * @param rdoNamesList
	 * @param eccnTagList
	 * @param filePath
	 * @param destination
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, Object> createEccnCSVFile(StringBuffer searchResultsQry,
			List<String> rdoNamesList, List<String> eccnTagList,
			String filePath, String destination) throws PLMCommonException {
		LOG.info("Entering getEccnOnScreenReport method in DAOIMPL--------");
		// List<PLMTaskSearchData> eccnOnScreenDataList = null;

		StringBuffer searchCriteriaMsg = null;
		List<Integer> intList = new ArrayList<Integer>();
		intList.add(0);
		// List<String> filNameList = new ArrayList<String>();
		Map<String, Object> mailContents = new HashMap<String, Object>();
		Boolean isEmtyRsltSet = false;
		final String eccnQry = searchResultsQry.toString();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet res = null;
		try {
			con = this.getJdbcTemplate().getDataSource().getConnection();
			// LOG.info("Connection Object"+con);
			LOG.info("Eccn Email Report Query is ::::: " + eccnQry);
			pstmt = con.prepareStatement(eccnQry,
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			// LOG.info("PreparedStatement Object"+pstmt);
			res = pstmt.executeQuery();
			// LOG.info("ResultSet Object"+res);
			int count = 0;
			if (!res.next()) {
				isEmtyRsltSet = true;
				LOG.info("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< RESULT SET IS EMPTY >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
			}
			if (res.next()) {
				res.last();
				count = res.getRow();
				res.first();
			}
			LOG.info("Result Set Position Set To Befrore FirstRow"
					+ res.getRow());
			int eccnRecLmt = Integer.parseInt(PLMUtils
					.getMessage(PLMConstants.ECCN_REC_COUNTER));
			for (int j = 0; j < count; j++) {
				if (0 == (j % eccnRecLmt) && j > 2) {
					intList.add(j);
				}
			}

			/*
			 * for (int j = 0; j < intList.size(); j++) {
			 * filNameList.add(filePath + (j + 1) + PLMConstants.CSV_TYPE); }
			 */
			LOG.info("TOTAL NUMBER OF RECORDS------------->" + count);
			LOG.info("No Of Files to be generated " + intList.size());
			searchCriteriaMsg = saveEccnCSVFileNew(res, filePath, rdoNamesList,
					eccnTagList, intList, count);
			Set<String> zippedFiles = generateZipFilesList(destination);
			List<String> zippedFilesList = new ArrayList<String>(zippedFiles);
			Collections.sort(zippedFilesList, new SortFileName());
			mailContents.put("ZippedFiles", zippedFilesList);
			mailContents.put("searchCriteriaMsg", searchCriteriaMsg);
			mailContents.put("isEmtyRsltSet", isEmtyRsltSet);

		} catch (Exception e) {
			e.printStackTrace();
			PLMUtils.checkException(e.getMessage());
		} finally {
			// if (res != null) {
			try {
				if (res != null) {
					res.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				PLMUtils.checkException(e.getMessage());
			} finally {
				// if (pstmt != null) {
				try {
					if (pstmt != null) {
						pstmt.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					PLMUtils.checkException(e.getMessage());
				} finally {
					// if (con != null) {
					try {
						if (con != null) {
							con.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
						PLMUtils.checkException(e.getMessage());
					}
					// }
				}
				// }

			}
			// }
			// if (pstmt != null) {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				PLMUtils.checkException(e.getMessage());
			} finally {
				// if (con != null) {
				try {
					if (con != null) {
						con.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					PLMUtils.checkException(e.getMessage());
				}
				// }
			}
			// }
			// if (con != null) {
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				PLMUtils.checkException(e.getMessage());
			}
			// }

		}
		LOG.info("Exiting getEccnOnScreenReport method in DAOIMPL--------");
		return mailContents;
	}

	/**
	 * This method is used for saveEccnCSVFile
	 * 
	 * @param res
	 * @param filePath
	 * @param rdoNamesList
	 * @param eccnTagList
	 * @param intList
	 * @param resCount
	 * @return StringBuffer
	 * @throws Exception
	 */

	public StringBuffer saveEccnCSVFileNew(ResultSet res, String filePath,
			List<String> rdoNamesList, List<String> eccnTagList,
			List<Integer> intList, int resCount) throws Exception {
		LOG.info("Inside saveEccnCSVFileNew");
		StringBuffer searchCriteriaMsg = new StringBuffer();
		// String filePath = filePathCVS;
		searchCriteriaMsg.append(PLMConstants.ECCN_MAIL_SEARCH_CRITERIA);
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy",
				Locale.ENGLISH);
		FileOutputStream fileOut = null;

		PrintWriter pwriter = null;

		try {
			for (int j = 0; j < intList.size(); j++) {
				try {
					String modifiedFilePath = filePath + (j + 1)
							+ PLMConstants.CSV_TYPE;
					pwriter = new PrintWriter(modifiedFilePath);
					boolean createFileExist;
					File fileName = new File(modifiedFilePath);
					boolean fileExist = fileName.exists();
					if (!fileExist) {
						createFileExist = fileName.createNewFile();
						LOG.info("createFileExist>>>>.." + createFileExist);
					}

					if (fileName.exists()) {

						String originationDate = null;
						String releasedDate = null;

						fileOut = new FileOutputStream(modifiedFilePath);
						// pwriter = new PrintWriter( new
						// FileWriter(filePath));

						// To set first 3 header & it' values
						if (j == 0) {
							setValueForSearchCriteriaNew(searchCriteriaMsg,
									rdoNamesList, eccnTagList);
						}
						String[] searchCriterias = { "RDO: ", "ECCN : " };
						String[] searchCriteriasValue = {
								PLMUtils.convertListToString(rdoNamesList),
								PLMUtils.convertListToString(eccnTagList) };
						pwriter.write("\n");

						for (int i = 0; i < searchCriterias.length; i++) {
							pwriter.write(searchCriterias[i]);
							pwriter.write(",");
							pwriter.write(searchCriteriasValue[i]);
							pwriter.write("\n");
						}

						pwriter.write("\n");
						/* End */

						pwriter.write("RDO");
						pwriter.write(",");
						pwriter.write("Name");
						pwriter.write(",");
						pwriter.write("Revision");
						pwriter.write(",");
						pwriter.write("State");
						pwriter.write(",");
						pwriter.write("Type");
						pwriter.write(",");
						pwriter.write("Origination Date");
						pwriter.write(",");
						pwriter.write("Release Date");
						pwriter.write(",");
						pwriter.write("Originator SSO");
						pwriter.write(",");
						pwriter.write("ECCN");

						pwriter.write("\n");

						if (res != null) {
							int loopCounter = 0;
							LOG.info("Result Set Posion set to"
									+ intList.get(j));
							res.absolute(intList.get(j));
							if ((j + 1) < intList.size()) {
								loopCounter = intList.get(j + 1);
							} else {
								loopCounter = resCount;
							}
							LOG.info("Loop COunter Value" + loopCounter);
							while (res.next() && (res.getRow() < loopCounter)) {
								res.setFetchSize(1000);
								if (res.getString(PLMConstants.DOC_RDO) != null) {
									pwriter.write(PLMUtils.convertToCsvValue(PLMUtils.checkNullVal(res
											.getString(PLMConstants.DOC_RDO))));
								}
								pwriter.write(",");
								if (res.getString(PLMConstants.TASK_NAME) != null) {
									pwriter.write(PLMUtils.convertToCsvValue(PLMUtils.checkNullVal(res
											.getString(PLMConstants.TASK_NAME))));
								}
								pwriter.write(",");
								if (res.getString(PLMConstants.DOC_REV) != null) {
									pwriter.write(PLMUtils.convertToCsvValue(PLMUtils.checkNullVal(res
											.getString(PLMConstants.DOC_REV))));
								}
								pwriter.write(",");
								if (res.getString(PLMConstants.TASK_STATE_NAME) != null) {
									pwriter.write(PLMUtils.convertToCsvValue(PLMUtils.checkNullVal(res
											.getString(PLMConstants.TASK_STATE_NAME))));
								}
								pwriter.write(",");
								if (res.getString(PLMConstants.TYPE_ONE) != null) {
									pwriter.write(PLMUtils.convertToCsvValue(res
											.getString(PLMConstants.TYPE_ONE)));
								}
								pwriter.write(",");
								if (res.getDate(PLMConstants.ORIGINATION_DATE) != null) {
									originationDate = dateFormat
											.format(res
													.getDate(PLMConstants.ORIGINATION_DATE));
									pwriter.write(originationDate);
								}
								pwriter.write(",");
								if (res.getDate(PLMConstants.RELEASE_DATE) != null) {
									releasedDate = dateFormat
											.format(res
													.getDate(PLMConstants.RELEASE_DATE));
									pwriter.write(releasedDate);
								}
								pwriter.write(",");
								if (res.getString(PLMConstants.ORIGINATOR_SSO) != null) {
									pwriter.write(PLMUtils.convertToCsvValue(res
											.getString(PLMConstants.ORIGINATOR_SSO)));
								}
								pwriter.write(",");
								if (res.getString(PLMConstants.ECCN_TAG) != null) {
									pwriter.write(PLMUtils.convertToCsvValue(PLMUtils.checkNullVal(res
											.getString(PLMConstants.ECCN_TAG))));
								}

								pwriter.write("\n");

							}
						}
					}
				} finally {
					try {
						if (fileOut != null) {
							fileOut.close();
						}
						if (pwriter != null) {
							pwriter.flush();
							pwriter.close();
						}
					} catch (IOException e) {
						LOG.log(Level.ERROR,
								"Exception@saveWhereUsedCSVFile: ", e);
						throw e;
					} finally {
						if (pwriter != null) {
							pwriter.flush();
							pwriter.close();
						}
					}

				}
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveWhereUsedCSVFile: ", e);
			PLMUtils.checkException(e.getMessage());
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveWhereUsedCSVFile: ", e);
			PLMUtils.checkException(e.getMessage());
		} finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}

				if (pwriter != null) {
					pwriter.flush();
					pwriter.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveWhereUsedCSVFile: ", e);
				PLMUtils.checkException(e.getMessage());
			}
		}
		return searchCriteriaMsg;
	}

	/**
	 * This method is used for generating zip file
	 * 
	 * @param filePathXls
	 *            ,filePathZip
	 * @throws IOException
	 */

	/**
	 * This method is used for setValueForSearchCriteria
	 * 
	 * @param searchCriteriaMsg
	 * @param rdoNamesList
	 * @param eccnTagList
	 * @return StringBuffer
	 */
	public StringBuffer setValueForSearchCriteriaNew(
			StringBuffer searchCriteriaMsg, List<String> rdoNamesList,
			List<String> eccnTagList) {
		LOG.info("Inside setValueForSearchCriteriaNew");
		searchCriteriaMsg.append("RDO     :  ");
		if (rdoNamesList != null && rdoNamesList.size() > 0) {
			searchCriteriaMsg
					.append(PLMUtils.convertListToString(rdoNamesList));

		}
		searchCriteriaMsg.append("\n");

		searchCriteriaMsg.append("ECCN Tag                    :  ");
		if (eccnTagList != null && eccnTagList.size() > 0) {
			searchCriteriaMsg.append(PLMUtils.convertListToString(eccnTagList));

		}
		searchCriteriaMsg.append("\n");

		return searchCriteriaMsg;
	}

	// Addeed by Raju -- Code to generate Zip files based on size

	/**
	 * This method is used to generate Zipfiles list
	 * 
	 * @param sourceFolder
	 * @return Set
	 */
	public Set<String> generateZipFilesList(String sourceFolder) {
		List<String> fileList = new ArrayList<String>();
		generateFileList(new File(sourceFolder), sourceFolder, fileList);
		Set<String> filesSet = zipIt(
				resourceBundle.getString("OFFLINE_RPT_DIR"), sourceFolder,
				fileList);
		LOG.info(filesSet);
		return filesSet;

	}

	/**
	 * This method is used to generate Zipfiles
	 * 
	 * @param zipFile
	 * @param SOURCE_FOLDER
	 * @param fileList
	 * @return Set
	 */
	public Set<String> zipIt(String zipFile, String SOURCE_FOLDER,
			List<String> fileList) {
		int fileCount = 1;
		String fileName = resourceBundle.getString("OFFLINE_RPT_DIR")
				+ "ECCN Report" + fileCount + ".zip";
		byte[] buffer = new byte[1024];
		String source = "";
		FileOutputStream fos = null;
		ZipOutputStream zos = null;
		FileInputStream in = null;
		Set<String> filesSet = new HashSet<String>();
		int zipSizeLimit = Integer.parseInt(PLMUtils
				.getMessage(PLMConstants.ECCN_ZIP_FILE_SIZE_LIMIT));
		try {
			try {
				source = SOURCE_FOLDER.substring(
						SOURCE_FOLDER.lastIndexOf('\\') + 1,
						SOURCE_FOLDER.length());
			} catch (Exception e) {
				source = SOURCE_FOLDER;
			}
			double eccnZipFileSize = 0;
			LOG.info(eccnZipFileSize);

			fos = new FileOutputStream(fileName);
			zos = new ZipOutputStream(fos);

			for (String file : fileList) {
				if (eccnZipFileSize > zipSizeLimit) {
					// if (zos != null) {
					zos.close();
					// }
					// if (fos != null) {
					fos.close();
					// }
					fileCount = fileCount + 1;
					fileName = resourceBundle.getString("OFFLINE_RPT_DIR")
							+ "ECCN Report" + fileCount + ".zip";
					fos = new FileOutputStream(fileName);
					zos = new ZipOutputStream(fos);
					// filesSet.add(fileName);
				}
				// ZipEntry ze = new ZipEntry(source + File.separator + file);
				ZipEntry ze = new ZipEntry(new File(source + File.separator
						+ file).getName());
				zos.putNextEntry(ze);
				try {
					in = new FileInputStream(SOURCE_FOLDER + File.separator
							+ file);
					int len;
					while ((len = in.read(buffer)) > 0) {
						zos.write(buffer, 0, len);
					}
				} finally {
					in.close();
				}
				eccnZipFileSize = PLMUtils.getZipFileSize(fileName);
				filesSet.add(fileName);
				LOG.info("File Added to Set :" + fileName);
			}
			zos.closeEntry();
			LOG.info("Folder successfully compressed");

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (zos != null)
					zos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return filesSet;
	}

	/**
	 * This method is used to generateFileList
	 * 
	 * @param node
	 * @param SOURCE_FOLDER
	 * @param fileList
	 */
	public void generateFileList(File node, String SOURCE_FOLDER,
			List<String> fileList) {
		// add file only
		if (node.isFile()) {
			fileList.add(generateZipEntry(node.toString(), SOURCE_FOLDER));
		}
		if (node.isDirectory()) {
			String[] subNote = node.list();
			if (subNote != null) {
				for (String filename : subNote) {
					generateFileList(new File(node, filename), SOURCE_FOLDER,
							fileList);
				}
			}
		}
	}

	/**
	 * This method is used to generateZipEntry
	 * 
	 * @param file
	 * @param SOURCE_FOLDER
	 * @return String
	 */
	private String generateZipEntry(String file, String SOURCE_FOLDER) {
		return file.substring(SOURCE_FOLDER.length() + 1, file.length());
	}

	// End Raju

	/**
	 * 
	 * class to sort list of object of type String.
	 * 
	 */
	private static class SortFileName implements Comparator<String>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(String aString, String bString) {
			return PLMUtils.chkNull(aString).compareTo(
					PLMUtils.chkNull(bString));
		}
	}

	/**
	 * @return the oldTaskName
	 */
	public String getOldTaskName() {
		return oldTaskName;
	}

	// Newly added by srinivas for 3.0.7
	/**
	 * This method is used to get Task Detailed Report task detail page filter
	 * for deliverable type
	 * 
	 * @param selectedTaskDetails
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> getTaskDetailedRptDeliverable(
			StringBuffer whereClauseQry,PLMTaskSearchData plmSearchDataLcl,String selectedTaskDetails) throws PLMCommonException {
		List<PLMTaskSearchData> SearchResultList = null;
		String taskName = null;
		taskName = selectedTaskDetails;
		
		String timeStamp = null;
		String VTCON =null;
		String VTTASK =null;
		try {
			timeStamp = PLMUtils.volTableFormatDate();
			VTCON = PLMConstants.VTCON.concat(timeStamp);
			VTTASK =PLMConstants.VTTASK.concat(timeStamp);
			
			StringBuffer createVTTask = new StringBuffer();
				createVTTask.append(PLMSearchQueries.CREATE_VTTASK_ONE.replaceAll(PLMConstants.VTTASK, VTTASK))
				 .append(whereClauseQry)
				 .append(PLMSearchQueries.CREATE_VTTASK_TWO);

				LOG.info("Execting  VTTASK Volatile Query is : " + createVTTask);
				getJdbcTemplate().execute(createVTTask.toString());
				
				LOG.info("Execting  VTCON Volatile Query is : " + PLMSearchQueries.CREATE_VTCON.replace(PLMConstants.VTCON, VTCON).replace(PLMConstants.VTTASK, VTTASK));
				getJdbcTemplate().execute(PLMSearchQueries.CREATE_VTCON.replaceAll(PLMConstants.VTCON, VTCON).replace(PLMConstants.VTTASK, VTTASK));
			
			StringBuffer finalResultsQry = new StringBuffer();
			finalResultsQry.append(PLMSearchQueries.GET_TASKSEARCH_DETAILS_ONE.replace(PLMConstants.VTCON, VTCON).replace(PLMConstants.VTTASK, VTTASK));
			if (taskName != null) {
				StringTokenizer strTokTask = new StringTokenizer(taskName, ",");
				boolean whereFlagLcl = false;
				while (strTokTask.hasMoreTokens()) {
					if(whereFlagLcl == false) {
						finalResultsQry.append(" WHERE (");
						whereFlagLcl = true;
					} else {
						finalResultsQry.append(" OR ");
					}
					finalResultsQry.append(strTokTask.nextToken());
				}
				finalResultsQry.append(")");
				if(plmSearchDataLcl.getTaskAstdTypeList()!=null && plmSearchDataLcl.getTaskAstdTypeList().size() >0){
					finalResultsQry.append(" AND ");
					finalResultsQry.append(PLMConstants.DELIVERABLES_TYPE);
					finalResultsQry.append(" IN ");
					finalResultsQry.append("(");
					finalResultsQry.append(PLMUtils.setListForQuery(plmSearchDataLcl.getTaskAstdTypeList()) + ")");
				}
				finalResultsQry.append(PLMSearchQueries.GET_TASKSEARCH_DETAILS_TWO);
				
				LOG.info("Task search Details Query :" + finalResultsQry);
			}
			
			SearchResultList = getSimpleJdbcTemplate().query(
					finalResultsQry.toString(), new TaskDetailReportMapper());
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return SearchResultList;
	}

	@Override
	public List<String> getUniquePartNamesForECR(String ecrsessionvalue) {
		// TODO Auto-generated method stub

		List<String> uniquePartNamesForECR = null;
		LOG.info("Executing query..." + PLMSearchQueries.GET_AFFCTITMS_FOR_ECR);
		uniquePartNamesForECR = getSimpleJdbcTemplate().query(
				PLMSearchQueries.GET_AFFCTITMS_FOR_ECR,
				new UniquePartNamesECRMapper(),
				new Object[] { ecrsessionvalue });

		return uniquePartNamesForECR;

	}

	private static final class UniquePartNamesECRMapper implements
			ParameterizedRowMapper<String> {
		public String mapRow(ResultSet rs, int rowCount) throws SQLException {
			String partNames = PLMUtils.checkNullVal(rs
					.getString(PLMConstants.TO_NAME));
			return partNames;
		}
	}

	@Override
	public List<PLMEcrSearchData> getPartsNotHavingRevOthrECR(String ecrsessionvalue) {
		// TODO Auto-generated method stub
		List<PLMEcrSearchData> uniquePartNamesForOthrECR = null;
				
		LOG.info("Executing query..."+PLMSearchQueries.GET_PARTS_ON_OTHER_ECR);
		uniquePartNamesForOthrECR = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_PARTS_ON_OTHER_ECR, new PartsNotHavingRevOthrECRMapper(),new Object[] { ecrsessionvalue });
		
		return uniquePartNamesForOthrECR;
	}

	private static final class PartsNotHavingRevOthrECRMapper implements
			ParameterizedRowMapper<PLMEcrSearchData> {
		public PLMEcrSearchData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMEcrSearchData ecrPartSearchData = new PLMEcrSearchData();
			ecrPartSearchData.setPartItmName(PLMUtils.checkNullVal(rs
					.getString(PLMConstants.PART_NAME)));
			ecrPartSearchData.setPartItmState(PLMUtils.checkNullVal(rs
					.getString("PART_STATE")));
			ecrPartSearchData.setPartItmRev(PLMUtils.checkNullVal(rs
					.getString("PART_REVISION")));
			if (Integer.parseInt(PLMUtils.checkNullVal(rs
					.getString("OTHER_ECR_CNT"))) > 0) {
				ecrPartSearchData.setPartInOtherEcr(true);
			} else {
				ecrPartSearchData.setPartInOtherEcr(false);
			}
			return ecrPartSearchData;
		}
	}

}