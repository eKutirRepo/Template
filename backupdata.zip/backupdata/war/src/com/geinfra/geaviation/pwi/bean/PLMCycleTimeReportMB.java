/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCycleTimeReportMB.java
 * @Creation date: 05-Dec-2014
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.bean;


import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;

import com.geinfra.geaviation.pwi.data.PLMCycleTimeReportData;
import com.geinfra.geaviation.pwi.service.PLMCycleTimeReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

/**
 * PLMIssuesReportMB is the managed bean class .
 */
public class PLMCycleTimeReportMB {

	private static final Logger LOG = Logger.getLogger(PLMCycleTimeReportMB.class);
	/**
	 * Holds the PLMIssuesReportService
	 */
	private PLMCycleTimeReportServiceIfc plmCycleTimeReportService = null;
	/**
	 * Holds the plmCycleTimeReportData
	 */
	private PLMCycleTimeReportData plmCycleTimeReportData = new PLMCycleTimeReportData();

	/**
	 * Holds the commonMB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds the searchResultList
	 */
	private List<PLMCycleTimeReportData> searchResultList;

	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the partFamily
	 */
	private List<SelectItem> partFamily = new ArrayList<SelectItem>();
	/**
	 * Holds the partFamilyNew
	 */
	private List<SelectItem> partFamilyNew=new ArrayList<SelectItem>();
	/**
	 * Holds the rdo
	 */
	private List<SelectItem> rdo = new ArrayList<SelectItem>();
	/**
	 * Holds the rdoNew
	 */
	private List<SelectItem> rdoNew = new ArrayList<SelectItem>();
	/**
	 * Holds the resultList
	 */
	private List<PLMCycleTimeReportData> resultList;
	/**
	 * Holds the resultData
	 */
	private PLMCycleTimeReportData resultData;
	
	/**
	 * Holds the dataTable
	 */
	//private HtmlDataTable dataTable = new HtmlDataTable();
	/**
	 * Holds the dataTable
	 */
	
	private String reviewCount;
	/**
	 * Holds the filterMsgList
	 */
	private List<String> filterMsgList;
	
	//Newly Added for Cycle Time  Parts By Product Line Report
	/**
	 * Holds the productLineLst
	 */
	private List<SelectItem> productLineLst;
	/**
	 * Holds the selProductLn
	 */
	private String selProductLn= "";

	/**
	 * Holds the frameTypeLst
	 */
	private List<SelectItem> frameTypeLst;

	/**
	 * Holds the selFrameType
	 */
	private List<String> selFrameType =new ArrayList<String>();

	/**
	 * Holds the hardWareLst
	 */
	private List<PLMCycleTimeReportData> hardWareObjLst =new ArrayList<PLMCycleTimeReportData>();

	/**
	 * Holds the hardWareLst
	 */
	private List<String> hardWareLst =new ArrayList<String>();
	
	/**
	  * Holds the releaseFromDate
	  */
	private Date releaseFromDate;
	/**
	  * Holds the releaseToDate
	  */
	private Date releaseToDate;
	/**
	 * Holds the cycleTimeByPrdList
	 */
	private List<PLMCycleTimeReportData> cycleTimeByPrdList;
	/**
	  * Holds the releaseFrmDtExl
	  */
	private String releaseFrmDtExl;
	/**
	  * Holds the releaseToDtExl
	  */
	private String releaseToDtExl;
	
	/**
	  * Holds the cycleTimePrdList
	  */
	private List<PLMCycleTimeReportData>  cycleTimePrdList;
	/**
	  * Holds the recordCounts
	  */
	private int recordCounts =100;
	
	/**
	  * Holds the cycleTimePrdCnt
	  */
	private int cycleTimePrdCnt;
	/**
	  * Holds the strCycleTimePrdMsg
	  */
	private String strCycleTimePrdMsg;
	/**
	  * Holds the productLineMsg
	  */
	private String productLineMsg;
	
	/**
	  * Holds the assignFrame
	  */
	private String assignFrame="";
	/**
	  * Holds the assignState
	  */
	private String assignState="";

	/**
	 * This method is used for getDropDownvalues
	 * 
	 * @return String
	 */
	public String getDropDownvalues() {
		LOG.info("getDropDownvalues() Method");
		String fwdFlag = PLMConstants.EMPTY;
		alertMessage = "";

		try {
			commonMB.insertCannedRptRecordHitInfo("Cycle Time-Parts");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}

		try {
			Map<String, List<SelectItem>> dropdownMap = plmCycleTimeReportService.getDropDownvalues();
			LOG.info("fetched dropdown list of size"+dropdownMap.size());
			
			if(!PLMUtils.isEmptyList(partFamilyNew)){
				partFamilyNew.clear();
			}
			
			if(!PLMUtils.isEmptyList(rdoNew)){
				rdoNew.clear();
			}
			
			if(!PLMUtils.isEmptyList(partFamily)){
				partFamily.clear();
			}
			
			if(!PLMUtils.isEmptyList(rdo)){
				rdo.clear();
			}
			
			partFamily = (List<SelectItem>) dropdownMap.get("partFamily");
			Collections.sort(partFamily, new PLMUtils.SortListSelItmLbl());
			LOG.info("partFamily DD List size==="+partFamily.size());
			partFamilyNew.add(new SelectItem("", "Select"));
			partFamilyNew.addAll(partFamily);
			
			rdo = (List<SelectItem>) dropdownMap.get("rdo");
			Collections.sort(rdo, new PLMUtils.SortListSelItmLbl());
			LOG.info("RDO DD List size==="+rdo.size());
			rdoNew.add(new SelectItem("", "Select"));
			rdoNew.addAll(rdo);
			
			resetSearchData();
			
			plmCycleTimeReportData = new PLMCycleTimeReportData();
			fwdFlag = "cycleTimeReportSearch";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getDropDownvalues: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Cycle Time Report");
		} 
		
	
		
		return fwdFlag;
	}
	/**
	 * This method is used for resetEcoSearchData
	 * 
	 * @return String
	 */
	public String resetSearchData() {
		String fwdFlag = "cycleTimeReportSearch";
		filterMsgList= new ArrayList<String>();
		
		plmCycleTimeReportData.setEnteredPartName("");
		plmCycleTimeReportData.setEnteredOwner("");
		plmCycleTimeReportData.setEnteredPartFamily("");
		plmCycleTimeReportData.setEnteredRdo("");
		plmCycleTimeReportData.setEnteredPartType("");
		resultData=new PLMCycleTimeReportData();
		alertMessage="";

		return fwdFlag;
	}

	/**
	 * @param value
	 *            .
	 * @return String
	 */
	public String getTrimValue(String value) {
		String retStr = null;
		if (!PLMUtils.isEmpty(value)) {
			retStr = value.trim();
		}
		return retStr;
	}
	
	/**
	 * This method is used for validateCycleTimeRpt
	 * 
	 * @return String
	 */
	public String validateCycleTimeRpt() throws PLMCommonException {
		alertMessage="";
		if (PLMUtils.isEmpty(plmCycleTimeReportData.getEnteredPartName()) && 
				PLMUtils.isEmpty(plmCycleTimeReportData.getEnteredOwner()) &&
				PLMUtils.isEmpty(plmCycleTimeReportData.getEnteredPartFamily()) &&
						PLMUtils.isEmpty(plmCycleTimeReportData.getEnteredRdo()) &&
								PLMUtils.isEmpty(plmCycleTimeReportData.getEnteredPartType())){
				alertMessage=PLMConstants.ENTER_CYCLETIME_INPUT;
		}
		else if(PLMUtils.checkSplCharsProjSumry(plmCycleTimeReportData.getEnteredPartName())){
			 	alertMessage = PLMConstants.CYCLETIME_PART_SPECIAL_CHAR;
		}
		else if (PLMUtils.checkSplCharsProjSumry(plmCycleTimeReportData.getEnteredOwner())) {
				alertMessage =  PLMConstants.CYCLETIME_OWNER_SPECIAL_CHAR;
		}
		return alertMessage;
	}
	
	/**
	 * This method is used for generate cycle time parts Report
	 * 
	 * @return String
	 */
	public String getCycleTimeReportResult(){
		alertMessage = "";
		filterMsgList= new ArrayList<String>();
		resultData=new PLMCycleTimeReportData();
		LOG.info("Entering getCycleTimeReportResult");
		String fwdFlag = PLMConstants.EMPTY;
 	 try{
 		alertMessage = validateCycleTimeRpt();
 		if(PLMUtils.isEmpty(alertMessage)){
	 		LOG.info("Selected Part Name:"+plmCycleTimeReportData.getEnteredPartName());
	 		LOG.info("Selected Owner:"+plmCycleTimeReportData.getEnteredOwner());
	 		LOG.info("Selected Part Family:"+plmCycleTimeReportData.getEnteredPartFamily());
	 		LOG.info("Selected RDO:"+plmCycleTimeReportData.getEnteredRdo());
	 		LOG.info("Selected Part Type:"+plmCycleTimeReportData.getEnteredPartType());
			
			
			resultData=plmCycleTimeReportService.getCycleTimeReportResult(plmCycleTimeReportData);
			
			LOG.info("Review Count is"+resultData.getReviewCount());
			LOG.info("Review Sum is"+resultData.getReviewSum());
			LOG.info("Approved Count is"+resultData.getApprovedCount());
			LOG.info("Approved Sum is"+resultData.getApprovedSum());
			LOG.info("Release Count is"+resultData.getReleaseCount());
			LOG.info("Release Sum is"+resultData.getReleaseSum());
			
			if(resultData.getReviewCount() != 0){
				LOG.info("Value is not zero proceeding for division");
				double reviewVal = resultData.getReviewSum()/resultData.getReviewCount();
			resultData.setReviewCycleTime(PLMUtils.convertCyclePart(reviewVal));
			}
			
			if(resultData.getApprovedCount() != 0){
				LOG.info("Value is not zero proceeding for division");
				double approveVal = resultData.getApprovedSum()/resultData.getApprovedCount();
			resultData.setApprovedCycleTime(PLMUtils.convertCyclePart(approveVal));
			}
			
			if(resultData.getReleaseCount() != 0){
				LOG.info("Value is not zero proceeding for division");
				double releaseVal = resultData.getReleaseSum()/resultData.getReleaseCount();
			resultData.setReleaseCycleTime(PLMUtils.convertCyclePart(releaseVal));
			}
			
			if (!PLMUtils.isEmpty(plmCycleTimeReportData.getEnteredPartName())){
				String partNameFilterMsg="Part Name: "+plmCycleTimeReportData.getEnteredPartName();
				filterMsgList.add(partNameFilterMsg);
			}
			
			if (!PLMUtils.isEmpty(plmCycleTimeReportData.getEnteredOwner())){
				String ownerFilterMsg="Owner: "+plmCycleTimeReportData.getEnteredOwner();
				filterMsgList.add(ownerFilterMsg);
			}
			
			if (!PLMUtils.isEmpty(plmCycleTimeReportData.getEnteredPartFamily())){
				String partFamilyFilterMsg="Part Family: "+plmCycleTimeReportData.getEnteredPartFamily();
				filterMsgList.add(partFamilyFilterMsg);
			}
			
			if (!PLMUtils.isEmpty(plmCycleTimeReportData.getEnteredRdo())){
				String rdoFilterMsg="RDO: "+plmCycleTimeReportData.getEnteredRdo();
				filterMsgList.add(rdoFilterMsg);
			}
			
			if (!PLMUtils.isEmpty(plmCycleTimeReportData.getEnteredPartType())){
				String partTypeFilterMsg="Part Type: "+plmCycleTimeReportData.getEnteredPartType();
				filterMsgList.add(partTypeFilterMsg);
			}
			
			if(resultData.getReviewCount() == 0 && resultData.getApprovedCount() == 0 && resultData.getReleaseCount() == 0){
				LOG.info("Value is zero proceeding for division");
				fwdFlag ="invalidcycleTime";
			}else{
				fwdFlag ="cycleTimeReportResult";
			}
		}else{
			fwdFlag ="cycleTimeReportSearch";
		}
		 
	  }catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getCycleTimeReportResult: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "cycleTimeReportSearch", "Cycle Time - Parts");
	 }
	  return fwdFlag;
		
	}
	
	private XSSFFont headerFont(SXSSFWorkbook wb, int size){
		XSSFFont font = (XSSFFont) wb.createFont();
		font.setFontName(PLMConstants.EXCEL_FONT_NAME);
		font.setFontHeightInPoints((short)size);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		return font;
	}
	
	private XSSFFont normalFont(SXSSFWorkbook wb, int size){
		XSSFFont font = (XSSFFont) wb.createFont();
		font.setFontName(PLMConstants.EXCEL_FONT_NAME);
		font.setFontHeightInPoints((short)size);
		return font;
	}
	
	private XSSFCellStyle headerCell(SXSSFWorkbook wb, XSSFFont font, short bgcolor, boolean wrap){
		XSSFCellStyle hCell = normalCell(wb, font, XSSFCellStyle.SOLID_FOREGROUND, wrap);
		//FONT
		hCell.setFont(font);
		
		//HORIZONTAL ALIGNMENT
		hCell.setAlignment(XSSFCellStyle.ALIGN_CENTER);
		
		//COLOR
		hCell.setFillForegroundColor(bgcolor);
		return hCell;
	}
	
	private XSSFCellStyle normalCell(SXSSFWorkbook wb, XSSFFont font, short fillPattern, boolean wrap){
		// Cell Style
		XSSFCellStyle cellStyle = (XSSFCellStyle)wb.createCellStyle();
		
		//Set Font
		cellStyle.setFont(font);
		//WRAP TEXT
		cellStyle.setWrapText(wrap);
		
		//VERTICAL ALIGNMENT
		cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
		
		//BORDERS
		cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		
		//FILL PATTERN
		cellStyle.setFillPattern(fillPattern);
		return cellStyle;
	}
	
	private XSSFCellStyle mergeCellText(SXSSFWorkbook wb, XSSFFont font, short fillPattern, boolean wrap){
		// Cell Style
		XSSFCellStyle cellStyle = (XSSFCellStyle)wb.createCellStyle();
		
		//Set Font
		cellStyle.setFont(font);
		//WRAP TEXT
		cellStyle.setWrapText(wrap);
		
		//VERTICAL ALIGNMENT
		cellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
		
		//BORDERS
		cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		
		//FILL PATTERN
		cellStyle.setFillPattern(fillPattern);
		return cellStyle;
	}
	
	/**
	 * Download Excel for Cycle Time-Parts report
	 * */
	
	public void downloadExcel() throws PLMCommonException {
		LOG.info("Entering downloadExcel Method");
		FacesContext facesContext = FacesContext.getCurrentInstance();
	  	try {
			HttpServletResponse response = 
				(HttpServletResponse)facesContext.getExternalContext().getResponse();
			
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			
			response.setHeader("Content-disposition", 
					"attachment; filename="+"cycleTimeParts.xlsx");
			
			OutputStream outputStream = response.getOutputStream();
			
			SXSSFWorkbook workbook = new SXSSFWorkbook();
			
			XSSFFont font = headerFont(workbook, 10);
			
			// Header Style
			XSSFCellStyle headerStyle = headerCell(workbook, font, HSSFColor.PALE_BLUE.index, true);

			XSSFFont cellfont = normalFont(workbook, 10);
			// Cell Style
			XSSFCellStyle cellStyle = normalCell(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
			
			XSSFCellStyle mergeStyle = mergeCellText(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
			
			
			SXSSFSheet sheet =  (SXSSFSheet) workbook.createSheet("cycleTimeParts");
			
			String[] colNames = {"From State","To State","Quantity","Cycle Time Days(Avg for all the parts)"};
			 
			int rowcount = 0;
			
			SXSSFCell cell=null;
		    
		    SXSSFRow row = (SXSSFRow) sheet.createRow(rowcount);
		    
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
			cell.setCellValue("Part Name");
			cell.setCellStyle(cellStyle);

			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(plmCycleTimeReportData.getEnteredPartName());
			cell.setCellStyle(cellStyle);
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			cell.setCellValue("Owner");
			cell.setCellStyle(cellStyle);
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(plmCycleTimeReportData.getEnteredOwner());
			cell.setCellStyle(cellStyle);
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			cell.setCellValue("Part Family");
			cell.setCellStyle(cellStyle);
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(plmCycleTimeReportData.getEnteredPartFamily());
			cell.setCellStyle(cellStyle);
		
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			cell.setCellValue("RDO");
			cell.setCellStyle(cellStyle);
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(plmCycleTimeReportData.getEnteredRdo());
			cell.setCellStyle(cellStyle);
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			cell.setCellValue("Part Type");
			cell.setCellStyle(cellStyle);
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(plmCycleTimeReportData.getEnteredPartType());
			cell.setCellStyle(cellStyle);
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
			for ( int i = 0 ; i < colNames.length; i++ ) {
				cell = (SXSSFCell)row.createCell(i);
				cell. setCellValue(colNames[i]);
				cell.setCellStyle(headerStyle);
			}
		
			row = (SXSSFRow) sheet.createRow(++rowcount);
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			XSSFCellStyle mergeStyle1 = (XSSFCellStyle) workbook.createCellStyle();
			mergeStyle1.setFont(cellfont);
			mergeStyle1.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			mergeStyle1.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			cell.setCellStyle(mergeStyle1);
			cell.setCellValue("Preliminary");
				
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellStyle(cellStyle);
			cell.setCellValue("Review");
			
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
			cell.setCellStyle(cellStyle);
			cell.setCellValue(resultData.getReviewCount());

			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
			cell.setCellStyle(cellStyle);
			cell.setCellValue(resultData.getReviewCycleTime());
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
			cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ZERO);
			cell.setCellStyle(mergeStyle);
			//cell.setCellValue(" ");
			
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellStyle(cellStyle);
			cell.setCellValue("Approved");
			
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
			cell.setCellStyle(cellStyle);
			cell.setCellValue(resultData.getApprovedCount());

			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
			cell.setCellStyle(cellStyle);
			cell.setCellValue(resultData.getApprovedCycleTime());
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
			cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ZERO);
			cell.setCellStyle(mergeStyle);
			//cell.setCellValue(" ");
			
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellStyle(cellStyle);
			cell.setCellValue("Released");
			
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
			cell.setCellStyle(cellStyle);
			cell.setCellValue(resultData.getReleaseCount());

			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
			cell.setCellStyle(cellStyle);
			cell.setCellValue(resultData.getReleaseCycleTime());
			
			sheet.addMergedRegion(new CellRangeAddress(7, rowcount, PLMConstants.EXCEL_COL_ZERO, PLMConstants.EXCEL_COL_ZERO));
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			row = (SXSSFRow) sheet.createRow(++rowcount);
			    XSSFCellStyle ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
			    ftrStyle.setFont(font);
			    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
			    cell.setCellStyle(ftrStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_THREE));

				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ONE);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_TWO);
				sheet.autoSizeColumn(PLMConstants.EXCEL_COL_THREE);
				
				workbook.write(outputStream);
			
			outputStream.flush();
			
			outputStream.close();
			
		} catch (IOException ioex) {
			ioex.printStackTrace();
		} finally {
			facesContext.responseComplete();
	  	}
		LOG.info("Exiting downloadExcel Method");

	}
	
	/**
	 * This method is used to download excel for CTP Product line report details
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadCTPProductLineDetailsExcel() throws PLMCommonException {
		LOG.info("Entering downloadCTPProductLineDetailsExcel Method");
		String reportName = "cycleTimeProductDt";
		String fileName = "cycleTimeProductDt";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		//Export to Excel for Cycle Time product Details
					PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
							  new PLMXlsxRptColumn("partName", "Part Name", FormatType.TEXT, null, null, 18),
							  new PLMXlsxRptColumn("partRev", "Part Revision", FormatType.TEXT),
							  new PLMXlsxRptColumn("partType", "Part Type", FormatType.TEXT, null, null, 22),
							  new PLMXlsxRptColumn("partState", "Part State", FormatType.TEXT),
							  new PLMXlsxRptColumn("releaseDt", "Release Date",FormatType.TEXT)
					};
					
			excelUtil.export(cycleTimePrdList, reportColumns, fileName, fileName, false, null, null);
			
			LOG.info("Exiting downloadCTPProductLineDetailsExcel Method");
		
	}
	
	/**
	 * This method is used to download excel for CTP Product line report
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	
	public void downloadCTPProductLineExcel() throws PLMCommonException {
		LOG.info("Entering downloadCTPProductLineExcel Method");
		FacesContext facesContext = FacesContext.getCurrentInstance();
	  	try {
			HttpServletResponse response = 
				(HttpServletResponse)facesContext.getExternalContext().getResponse();
			
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			
			response.setHeader("Content-disposition", 
					"attachment; filename="+"Cycle Time PartsPrd.xlsx");
			
			OutputStream outputStream = response.getOutputStream();
			
			SXSSFWorkbook workbook = new SXSSFWorkbook();
			
			XSSFFont font = headerFont(workbook, 10);
			
			// Header Style
			XSSFCellStyle headerStyle = headerCell(workbook, font, HSSFColor.PALE_BLUE.index, true);

			XSSFFont cellfont = normalFont(workbook, 10);
			// Cell Style
			XSSFCellStyle cellStyle = normalCell(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
			
			SXSSFSheet sheet =  (SXSSFSheet) workbook.createSheet("CycleTimeParts");
			
			XSSFCellStyle mergeStyle = (XSSFCellStyle) workbook.createCellStyle();
			mergeStyle.setFont(cellfont);
			mergeStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			mergeStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			
			int rowcount = 0;
			
			SXSSFCell cell=null;
		    
		    SXSSFRow row = (SXSSFRow) sheet.createRow(rowcount);
		    
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
			cell.setCellValue("Product Line");
			cell.setCellStyle(cellStyle);

			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(selProductLn);
			cell.setCellStyle(cellStyle);
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			cell.setCellValue("Frame Type");
			cell.setCellStyle(cellStyle);
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(selFrameType.toString());
			cell.setCellStyle(cellStyle);
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			cell.setCellValue("Release Date From");
			cell.setCellStyle(cellStyle);
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(releaseFrmDtExl);
			cell.setCellStyle(cellStyle);
		
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			cell.setCellValue("Release Date To");
			cell.setCellStyle(cellStyle);
			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(releaseToDtExl);
			cell.setCellStyle(cellStyle);
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
		    
            if(!PLMUtils.isEmptyList(cycleTimeByPrdList)) {
            	
             String[] colNames = {"Frame Type","From State","To State","Quantity","Cycle Time Days(Avg for all the parts by Product)"};
        			
            	for ( int i = 0 ; i < colNames.length; i++ ) {
    				cell = (SXSSFCell)row.createCell(i);
    				cell. setCellValue(colNames[i]);
    				cell.setCellStyle(headerStyle);
    			}
    		
				int mergedRowNum=0;
             
				for(int j=0;j<cycleTimeByPrdList.size();j++){
				
				PLMCycleTimeReportData dataObj = (PLMCycleTimeReportData) cycleTimeByPrdList.get(j);
				
				row = (SXSSFRow) sheet.createRow(++rowcount);
				
				mergedRowNum=rowcount;
				
				cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellStyle(mergeStyle);
				cell.setCellValue(dataObj.getFrameType());
				
				cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellStyle(mergeStyle);
				cell.setCellValue("Preliminary");
				
				cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
				cell.setCellStyle(cellStyle);
				cell.setCellValue("Review");
				
				cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getReviewCount());
	
				cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FOUR);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getReviewCycleTime());
				
				row = (SXSSFRow) sheet.createRow(++rowcount);
				cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellStyle(cellStyle);
				
				cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellStyle(cellStyle);
				
				cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
				cell.setCellStyle(cellStyle);
				cell.setCellValue("Approved");
				
				cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getApprovedCount());
	
				cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FOUR);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getApprovedCycleTime());
				
				row = (SXSSFRow) sheet.createRow(++rowcount);
				cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellStyle(cellStyle);
				
				cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellStyle(cellStyle);
				
				cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
				cell.setCellStyle(cellStyle);
				cell.setCellValue("Release");
				
				cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getReleaseCount());
	
				cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FOUR);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getReleaseCycleTime());
				
				sheet.addMergedRegion(new CellRangeAddress(mergedRowNum, mergedRowNum+2, PLMConstants.EXCEL_COL_ZERO, PLMConstants.EXCEL_COL_ZERO));
				sheet.addMergedRegion(new CellRangeAddress(mergedRowNum, mergedRowNum+2, PLMConstants.EXCEL_COL_ONE, PLMConstants.EXCEL_COL_ONE));
			
		  	 }
			
             	row = (SXSSFRow) sheet.createRow(++rowcount);
             	row = (SXSSFRow) sheet.createRow(++rowcount);
             	
			    XSSFCellStyle ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
			    ftrStyle.setFont(font);
			    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
			    cell.setCellStyle(ftrStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_FOUR));

				sheet.setColumnWidth(0,15*256);
				sheet.setColumnWidth(1,15*256);
				sheet.setColumnWidth(2,12*256);
				sheet.setColumnWidth(3,10*256);
				sheet.setColumnWidth(4,20*256);
				
            }	
			
            workbook.write(outputStream);
			
			outputStream.flush();
			
			outputStream.close();
			
		} catch (IOException ioex) {
			ioex.printStackTrace();
		} finally {
			facesContext.responseComplete();
	  	}
		LOG.info("Exiting downloadCTPProductLineExcel Method");
	}
	
	//Newly Added methods for Cycle Time  Parts By Product Line Report
	/**
	 * This method is used for reset of  Cycle Time  Parts By Product Line
	 * 
	 * @return String
	 */
	public void resetCycleTimePrd(){
		alertMessage="";
		frameTypeLst= new ArrayList<SelectItem>();
		selFrameType = new ArrayList<String>();
		hardWareObjLst = new ArrayList<PLMCycleTimeReportData>();
		hardWareLst = new ArrayList<String>();
		releaseFromDate =null;
		releaseToDate = null;
		selProductLn= "";
		assignFrame="";
		assignState="";
		cycleTimeByPrdList =new ArrayList<PLMCycleTimeReportData>();
		cycleTimePrdList = new ArrayList<PLMCycleTimeReportData>();
		cycleTimePrdCnt=0;
		recordCounts=100;
		strCycleTimePrdMsg="";
	}
	/**
	 * This method is used for Loading Cycle Time  Parts By Product Line home page
	 * 
	 * @return String
	 */
	public String loadProductLines() {
		LOG.info("Entering loadProductLines Method");
		resetCycleTimePrd();

		try {
			commonMB.insertCannedRptRecordHitInfo("Cycle Time-Parts By Product Line");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}

		try {
		 productLineLst = plmCycleTimeReportService.getProductLines();
		 LOG.info("productLineLst fetched to MB with size =="+productLineLst.size());
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@loadProductLines:", exception);
		}
		LOG.info("Exiting loadProductLines Method");
		return "cycleTimePartsPrdSearch";
	}
	
	/**
	 * This method is used for frameTypeListner
	 * 
	 *@param ActionEvent
	 */
	public void frameTypeListner(ActionEvent ae) throws PLMCommonException{
		alertMessage="";
		try {
			LOG.info("Entering frameTypeListner Method");
			 if(!PLMUtils.isEmpty(selProductLn)){
			    frameTypeLst = plmCycleTimeReportService.getFrameTypeLst(selProductLn);
				 LOG.info("frameTypeLst fetched to MB with size =="+frameTypeLst.size());
					
			 }else{
				 frameTypeLst=new ArrayList<SelectItem>();
				 hardWareObjLst=new ArrayList<PLMCycleTimeReportData>();
				 hardWareLst=new ArrayList<String>();
			 }
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@frameTypeListner :", exception);
		}
		LOG.info("Exiting frameTypeListner Method");
	}
	
	
	/**
	 * This method is used for hardWareListner
	 * 
	 *@param ActionEvent
	 */
	public void hardWareListner(ActionEvent ae) throws PLMCommonException{
		alertMessage="";
		try {
			LOG.info("Entering hardWareSListner Method");
			 if(!PLMUtils.isEmpty(selProductLn)&& !PLMUtils.isEmptyList(selFrameType)){
				 hardWareObjLst = plmCycleTimeReportService.getHardWareLst(selProductLn,selFrameType);
				 for (int i = 0; i < hardWareObjLst.size(); i++) {
					 hardWareLst.add(hardWareObjLst.get(i).getHwPrdtNm());
				 }
				 LOG.info("hardWareLst fetched to MB with size =="+hardWareLst.size());
			 }else{
				 hardWareObjLst=new ArrayList<PLMCycleTimeReportData>();
				 hardWareLst=new ArrayList<String>();
			 }
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@hardWareSListner :", exception);
		}
		LOG.info("Exiting hardWareListner Method");
	}
	
	/**
	 * This method is used for validateCycleTime Product By Line
	 * 
	 * @return String
	 */
	public String validateCycleTimePrdLn() throws PLMCommonException {
		alertMessage="";
		final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
				"MM/dd/yyyy");
		if (PLMUtils.isEmpty(selProductLn)&& PLMUtils.isEmptyList(selFrameType)){
				alertMessage=PLMConstants.SELECT_RRODlN_FRAMETYPE;
		}
		else if(PLMUtils.isEmptyList(selFrameType)){
			 	alertMessage = PLMConstants.SELECT_FRAMETYPE;
		}
		else if((!PLMUtils.isEmptyDate(releaseFromDate)
			      && PLMUtils.isEmptyDate(releaseToDate))
			      ||(PLMUtils.isEmptyDate(releaseFromDate)
					      && !PLMUtils.isEmptyDate(releaseToDate))){
				alertMessage = PLMConstants.RELEASE_DATE_COMPARISION;
			  }
		else if (PLMUtils.checkForFromAndToDate(releaseFromDate,releaseToDate)) {
			alertMessage =  PLMConstants.RELEASE_DATE_ALERT;
		}
		else if(!PLMUtils.isEmptyDate(releaseFromDate)
			      && !PLMUtils.isEmptyDate(releaseToDate)){
			releaseFrmDtExl =SIMPLE_DATE_FORMAT.format(releaseFromDate);
			releaseToDtExl =SIMPLE_DATE_FORMAT.format(releaseToDate);
		}
		return alertMessage;
	}
	/**
	 * This method is used for generate cycle time parts by product
	 * 
	 * @return String
	 */
	public String getCycleTimePartsProduct(){
		LOG.info("Entering getCycleTimePartsProduct");
		String fwdFlag = PLMConstants.EMPTY;
		alertMessage="";
	 	 try{
	  		alertMessage = validateCycleTimePrdLn();
	  		if(PLMUtils.isEmpty(alertMessage)){
	  			cycleTimeByPrdList=plmCycleTimeReportService.getCycleTimePartProduct(selFrameType,hardWareObjLst,releaseFromDate,releaseToDate);
	  			productLineMsg ="Product Line: "+selProductLn;
	  			if(cycleTimeByPrdList.size()>0){
	 			  fwdFlag ="cycleTimePartsPrdReport";
	  			}else{
	  				fwdFlag ="invalidcycleTimePrd";
	  			}
	 		}else{
	 			fwdFlag ="cycleTimePartsPrdSearch";
	 		}
	 	  }catch (PLMCommonException exception) {
	 			LOG.log(Level.ERROR, "Exception@getCycleTimePartsProduct: ", exception);
	 			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
	 					commonMB, "cycleTimePartsPrdSearch", "Cycle Time - Parts by Prodcut Line");
	 	 }
		return fwdFlag;
	}
	
	/**
	 * This method is used for generate cycle time part by product Details
	 * 
	 * @return String
	 */
	public String getCycleTimePrdDetails(){
		LOG.info("Entering getCycleTimePrdDetails");
		String fwdFlag = PLMConstants.EMPTY;
		alertMessage="";
		List <String> selhardWareLst =new ArrayList<String>();
	 	 try{	
	 		 LOG.info("Assinged Frame "+assignFrame);
	 		for (int i = 0; i < hardWareObjLst.size(); i++) {
	 			 if(assignFrame.equals(hardWareObjLst.get(i).getFrameType())){
	 				selhardWareLst.add(hardWareObjLst.get(i).getHwPrdtNm());
	 			 }	
			 }
	 		cycleTimePrdList=plmCycleTimeReportService.getCycleTimeProductDetials(selhardWareLst,assignState,releaseFromDate,releaseToDate); 	 
	 	    if(!PLMUtils.isEmptyList(cycleTimePrdList)){
	 	    	LOG.info("getCycleTimePrdDetails List details Size"+cycleTimePrdList.size());
	 	    	cycleTimePrdCnt =cycleTimePrdList.size();
	 	    	recordCounts =100;
	 	    	strCycleTimePrdMsg ="Total Results of Cycle Time Parts By Product Line: "+cycleTimePrdCnt;
	 	    	fwdFlag = "cycleTimePartsPrdDetail";
	 	    }else{
	 	    	fwdFlag = "invalidcycleTimePrdDet";
	 	    }
	 	 }catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getCycleTimePrdDetails: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "cycleTimePartsPrdReport", "Cycle Time - Parts by Prodcut Line Details");
	 }
	 	LOG.info("Exiting getCycleTimePrdDetails");
	return fwdFlag;
	}

	 /**
	 * This method is used for recordsPerPageListner
	 * 
	 * @param event
	 * 
	 */
	public void recordsPerPageListner(ActionEvent event) {
		LOG.info("Entering recordsPerPageListner method");
		LOG.info("Action listner called.....--------------------------->"
				+ recordCounts);
		if (recordCounts == 15) {
			LOG.info("15");
			recordCounts = 15;
		} else if (recordCounts == 30) {
			LOG.info("30");
			recordCounts = 30;
		} else if (recordCounts == 50) {
			LOG.info("50");
			recordCounts = 50;
		} else if (recordCounts == 100) {
			LOG.info("100");
			recordCounts = 100;
		} else if (recordCounts == 200) {
			LOG.info("200");
			recordCounts = 200;
		}
		else if (recordCounts == cycleTimePrdCnt) {
			LOG.info("All");
			recordCounts = cycleTimePrdCnt;
		}
		LOG.info("final value.....--------------------------->" + recordCounts);
	}
	

	/**
	 * @return the plmCycleTimeReportService
	 */
	public PLMCycleTimeReportServiceIfc getPlmCycleTimeReportService() {
		return plmCycleTimeReportService;
	}
	/**
	 * @param plmCycleTimeReportService the plmCycleTimeReportService to set
	 */
	public void setPlmCycleTimeReportService(
			PLMCycleTimeReportServiceIfc plmCycleTimeReportService) {
		this.plmCycleTimeReportService = plmCycleTimeReportService;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}
	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the searchResultList
	 */
	public List<PLMCycleTimeReportData> getSearchResultList() {
		return searchResultList;
	}
	/**
	 * @param searchResultList the searchResultList to set
	 */
	public void setSearchResultList(List<PLMCycleTimeReportData> searchResultList) {
		this.searchResultList = searchResultList;
	}
	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}
	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}
	/**
	 * @return the partFamily
	 */
	public List<SelectItem> getPartFamily() {
		return partFamily;
	}
	/**
	 * @param partFamily the partFamily to set
	 */
	public void setPartFamily(List<SelectItem> partFamily) {
		this.partFamily = partFamily;
	}
	/**
	 * @return the rdo
	 */
	public List<SelectItem> getRdo() {
		return rdo;
	}
	/**
	 * @param rdo the rdo to set
	 */
	public void setRdo(List<SelectItem> rdo) {
		this.rdo = rdo;
	}
	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return LOG;
	}
	/**
	 * @return the plmCycleTimeReportData
	 */
	public PLMCycleTimeReportData getPlmCycleTimeReportData() {
		return plmCycleTimeReportData;
	}
	/**
	 * @param plmCycleTimeReportData the plmCycleTimeReportData to set
	 */
	public void setPlmCycleTimeReportData(
			PLMCycleTimeReportData plmCycleTimeReportData) {
		this.plmCycleTimeReportData = plmCycleTimeReportData;
	}
	/**
	 * @return the resultList
	 */
	public List<PLMCycleTimeReportData> getResultList() {
		return resultList;
	}
	/**
	 * @param resultList the resultList to set
	 */
	public void setResultList(List<PLMCycleTimeReportData> resultList) {
		this.resultList = resultList;
	}
	/**
	 * @return the dataTable
	 */
	/*public HtmlDataTable getDataTable() {
		return dataTable;
	}*/
	/**
	 * @param dataTable the dataTable to set
	 */
	/*public void setDataTable(HtmlDataTable dataTable) {
		this.dataTable = dataTable;
	}*/
	/**
	 * @return the resultData
	 */
	public PLMCycleTimeReportData getResultData() {
		return resultData;
	}
	/**
	 * @param resultData the resultData to set
	 */
	public void setResultData(PLMCycleTimeReportData resultData) {
		this.resultData = resultData;
	}
	/**
	 * @return the reviewCount
	 */
	public String getReviewCount() {
		return reviewCount;
	}
	/**
	 * @param reviewCount the reviewCount to set
	 */
	public void setReviewCount(String reviewCount) {
		this.reviewCount = reviewCount;
	}
	/**
	 * @return the partFamilyNew
	 */
	public List<SelectItem> getPartFamilyNew() {
		return partFamilyNew;
	}
	/**
	 * @param partFamilyNew the partFamilyNew to set
	 */
	public void setPartFamilyNew(List<SelectItem> partFamilyNew) {
		this.partFamilyNew = partFamilyNew;
	}
	/**
	 * @return the rdoNew
	 */
	public List<SelectItem> getRdoNew() {
		return rdoNew;
	}
	/**
	 * @param rdoNew the rdoNew to set
	 */
	public void setRdoNew(List<SelectItem> rdoNew) {
		this.rdoNew = rdoNew;
	}
	/**
	 * @return the filterMsgList
	 */
	public List<String> getFilterMsgList() {
		return filterMsgList;
	}
	/**
	 * @param filterMsgList the filterMsgList to set
	 */
	public void setFilterMsgList(List<String> filterMsgList) {
		this.filterMsgList = filterMsgList;
	}
	/**
	 * @return the productLineLst
	 */
	public List<SelectItem> getProductLineLst() {
		return productLineLst;
	}
	/**
	 * @param productLineLst the productLineLst to set
	 */
	public void setProductLineLst(List<SelectItem> productLineLst) {
		this.productLineLst = productLineLst;
	}
	
	/**
	 * @return the selProductLn
	 */
	public String getSelProductLn() {
		return selProductLn;
	}
	/**
	 * @param selProductLn the selProductLn to set
	 */
	public void setSelProductLn(String selProductLn) {
		this.selProductLn = selProductLn;
	}
	/**
	 * @return the frameTypeLst
	 */
	public List<SelectItem> getFrameTypeLst() {
		return frameTypeLst;
	}
	/**
	 * @param frameTypeLst the frameTypeLst to set
	 */
	public void setFrameTypeLst(List<SelectItem> frameTypeLst) {
		this.frameTypeLst = frameTypeLst;
	}
	/**
	 * @return the selFrameType
	 */
	public List<String> getSelFrameType() {
		return selFrameType;
	}
	/**
	 * @param selFrameType the selFrameType to set
	 */
	public void setSelFrameType(List<String> selFrameType) {
		this.selFrameType = selFrameType;
	}
	/**
	 * @return the releaseFromDate
	 */
	public Date getReleaseFromDate() {
		Date temp = null;
		temp = releaseFromDate;
		return temp;
	}
	/**
	 * @param releaseFromDate the releaseFromDate to set
	 */
	public void setReleaseFromDate(Date releaseFromDate) {
		Date temp = null;
		temp = releaseFromDate;
		this.releaseFromDate = temp;
	}
	/**
	 * @return the releaseToDate
	 */
	public Date getReleaseToDate() {
		Date temp = null;
		temp = releaseToDate;
		return temp;
	}
	/**
	 * @param releaseToDate the releaseToDate to set
	 */
	public void setReleaseToDate(Date releaseToDate) {
		Date temp = null;
		temp = releaseToDate;
		this.releaseToDate = temp;
	}
	
	/**
	 * @return the cycleTimeByPrdList
	 */
	public List<PLMCycleTimeReportData> getCycleTimeByPrdList() {
		return cycleTimeByPrdList;
	}
	/**
	 * @param cycleTimeByPrdList the cycleTimeByPrdList to set
	 */
	public void setCycleTimeByPrdList(
			List<PLMCycleTimeReportData> cycleTimeByPrdList) {
		this.cycleTimeByPrdList = cycleTimeByPrdList;
	}
	/**
	 * @return the releaseFrmDtExl
	 */
	public String getReleaseFrmDtExl() {
		return releaseFrmDtExl;
	}
	/**
	 * @param releaseFrmDtExl the releaseFrmDtExl to set
	 */
	public void setReleaseFrmDtExl(String releaseFrmDtExl) {
		this.releaseFrmDtExl = releaseFrmDtExl;
	}
	/**
	 * @return the releaseToDtExl
	 */
	public String getReleaseToDtExl() {
		return releaseToDtExl;
	}
	/**
	 * @param releaseToDtExl the releaseToDtExl to set
	 */
	public void setReleaseToDtExl(String releaseToDtExl) {
		this.releaseToDtExl = releaseToDtExl;
	}
	/**
	 * @return the cycleTimePrdList
	 */
	public List<PLMCycleTimeReportData> getCycleTimePrdList() {
		return cycleTimePrdList;
	}
	/**
	 * @param cycleTimePrdList the cycleTimePrdList to set
	 */
	public void setCycleTimePrdList(List<PLMCycleTimeReportData> cycleTimePrdList) {
		this.cycleTimePrdList = cycleTimePrdList;
	}
	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}
	/**
	 * @param recordCounts the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}
	/**
	 * @return the cycleTimePrdCnt
	 */
	public int getCycleTimePrdCnt() {
		return cycleTimePrdCnt;
	}
	/**
	 * @param cycleTimePrdCnt the cycleTimePrdCnt to set
	 */
	public void setCycleTimePrdCnt(int cycleTimePrdCnt) {
		this.cycleTimePrdCnt = cycleTimePrdCnt;
	}
	/**
	 * @return the strCycleTimePrdMsg
	 */
	public String getStrCycleTimePrdMsg() {
		return strCycleTimePrdMsg;
	}
	/**
	 * @param strCycleTimePrdMsg the strCycleTimePrdMsg to set
	 */
	public void setStrCycleTimePrdMsg(String strCycleTimePrdMsg) {
		this.strCycleTimePrdMsg = strCycleTimePrdMsg;
	}
	/**
	 * @return the productLineMsg
	 */
	public String getProductLineMsg() {
		return productLineMsg;
	}
	/**
	 * @param productLineMsg the productLineMsg to set
	 */
	public void setProductLineMsg(String productLineMsg) {
		this.productLineMsg = productLineMsg;
	}
	/**
	 * @return the assignFrame
	 */
	public String getAssignFrame() {
		return assignFrame;
	}
	/**
	 * @param assignFrame the assignFrame to set
	 */
	public void setAssignFrame(String assignFrame) {
		this.assignFrame = assignFrame;
	}
	/**
	 * @return the assignState
	 */
	public String getAssignState() {
		return assignState;
	}
	/**
	 * @param assignState the assignState to set
	 */
	public void setAssignState(String assignState) {
		this.assignState = assignState;
	}



	
}