/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhrUsdSubstncMB.java
 * @Creation date: 01-Jan-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.data.PLMWhrUsdSubstncData;
import com.geinfra.geaviation.pwi.service.PLMWhrUsdSubstncServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMWhrUsdSubstncMB {
	/**
	 * Holds the Loggger
	 */
	private static final Logger LOG = Logger.getLogger(PLMWhrUsdSubstncMB.class);
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;

	/**
	 * Holds the plmGenSOKitReportService
	 */
	private PLMWhrUsdSubstncServiceIfc whrUsdSubstncService = null;
	/**
	 * Holds the plmGenSOKitReportData
	 */
	private PLMWhrUsdSubstncData whrUsdSubstncData = null;
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor=null;
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage="";
	/**
	 * Holds the DATE_FORMAT_PROC
	 */
	private final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
	/**
	 * Holds the DATE_FORMAT_PROC
	 */
	private final SimpleDateFormat REPORT_DATE_FORMAT = new SimpleDateFormat("dd-MMM-yy");
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the showMaterial
	 */
	private boolean showMaterial=false;
	/**
	 * Holds the materialList
	 */
	private List<SelectItem> materialList = new ArrayList<SelectItem>();
	/**
	 * Holds the materialListNew
	 */
	private List<SelectItem> materialListNew = new ArrayList<SelectItem>();
	/**
	 * Holds the userDataObj
	 */
	 private PLMPwiUserData userDetails = null;
	 
	/*private PLMLoginData userDataObj = (PLMLoginData) PLMUtils
	.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA);*/
	
	private List<PLMWhrUsdSubstncData> whUsedCASSubDataList = new ArrayList<PLMWhrUsdSubstncData>();
	
	/**
	 * This method is used for Loading GeneratorSOKitReportPage
	 * 
	 * @return String
	 */
	public String loadWhUsedCASSubstancePage() {
		LOG.info("Entering loadWhUsedCASSubstancePage Method");
		try {
				//plmGenSOKitReportService = new PLMGenSOKitReportServiceImpl();
				commonMB.insertCannedRptRecordHitInfo("Where Used-CAS Substance");
				whrUsdSubstncData = new PLMWhrUsdSubstncData();
				showMaterial=false;
				alertMessage = "";
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@loadWhUsedCASSubstancePage:", exception);
			}
		LOG.info("Exiting loadWhUsedCASSubstancePage Method");
		return "whUsedCASSubstanceSearch";
	}
	public String resetData(){
		whrUsdSubstncData.setEnteredSubstance("");
		whrUsdSubstncData.setCasSubstanceNum("");
		whrUsdSubstncData.setSelectedMaterial("");
		showMaterial=false;
		alertMessage = "";
		return "whUsedCASSubstanceSearch";
	}
	/**
	 * This method is used for getDropDownvalues
	 * 
	 * @return String
	 */
	public String getMaterialList() {
		LOG.info("getMaterialList() Method");
		materialList = new ArrayList<SelectItem>();
		materialListNew = new ArrayList<SelectItem>();
		alertMessage = "";
		String fwdFlag = "";
		try {
			if(!PLMUtils.isEmpty(whrUsdSubstncData.getEnteredSubstance())|| !PLMUtils.isEmpty(whrUsdSubstncData.getCasSubstanceNum())){
				String substance = whrUsdSubstncData.getEnteredSubstance();
				String caSubstanceNum = whrUsdSubstncData.getCasSubstanceNum();
				
				LOG.info("entered substance is "+substance);
				LOG.info("entered caSubstanceNum is "+caSubstanceNum);
				
				materialList = whrUsdSubstncService.getDropDownvalues(substance,caSubstanceNum);
				LOG.info("fetched materialList of size"+materialList.size());
				
				if(materialList.size()>0){
				Collections.sort(materialList, new PLMUtils.SortListSelItmLbl());
				LOG.info("partFamily DD List size==="+materialList.size());
				materialListNew.add(new SelectItem("", "Select"));
				materialListNew.addAll(materialList);
				LOG.info("Prepared New Material List of Size :"+materialListNew.size());
				
				fwdFlag = "whUsedCASSubstanceSearch";
				showMaterial=true;
				}else{
					alertMessage=PLMConstants.ENTER_ANOTHER_SUBSTANCE;
					fwdFlag = "whUsedCASSubstanceSearch";
					showMaterial=false;
				}
			}else{
				alertMessage=PLMConstants.ENTER_SUBSTANCE;
				fwdFlag = "whUsedCASSubstanceSearch";
				showMaterial=false;
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getMaterialList: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Where Used - CAS Substance Report");
		} 
		return fwdFlag;
	}
	
	 /**
	 * This method is used for sendEmail
	 * @throws PWiException 
	 * 
	 */
	public void sendEmail() throws PWiException{
		if((!PLMUtils.isEmpty(whrUsdSubstncData.getEnteredSubstance())||
				!PLMUtils.isEmpty(whrUsdSubstncData.getCasSubstanceNum())) && !PLMUtils.isEmpty(whrUsdSubstncData.getSelectedMaterial()))
		{
			userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		alertMessage = PLMConstants.WHUSEDCAS_MAIL_ALERT_MSG;
		taskExecutor.execute(new WhUsedCASSubstanceEmailThread());
		}else{
		alertMessage = PLMConstants.ENTER_SUBSTANCE_MATERIAL;
		}
		}
	/**
	 * Background Process Thread
	 */
	private class WhUsedCASSubstanceEmailThread implements Runnable {
		public WhUsedCASSubstanceEmailThread(){}
		public void run() {
			try{
			generateWhUsedCASSubstanceEmailReport();
			}catch (Exception exception) {	
				LOG.log(Level.ERROR, "Exception@run() of WhUsedCASSubstanceEmailThread: ", exception);
			}
		}
	}
	 /**
	 * This method is used for generateWhUsedCASSubstanceEmailReport
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String generateWhUsedCASSubstanceEmailReport() {
		LOG.info("Entering generateWhUsedCASSubstanceEmailReport Method");		
		Map<String, Object> varMap = new HashMap<String, Object>();
			
		String toEmailId = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		
		toAddressee = "Dear " + toAddressee + ", \n\n";
		try {
			//Start
			if((!PLMUtils.isEmpty(whrUsdSubstncData.getEnteredSubstance())||
					!PLMUtils.isEmpty(whrUsdSubstncData.getCasSubstanceNum())) && !PLMUtils.isEmpty(whrUsdSubstncData.getSelectedMaterial()))
			{	
			String substance = whrUsdSubstncData.getEnteredSubstance();
			String casubstanceNum = whrUsdSubstncData.getCasSubstanceNum();
			String material = whrUsdSubstncData.getSelectedMaterial();
			LOG.info("Substance entered..inside if...=="+substance);
			LOG.info("casubstanceNum entered..inside if...=="+casubstanceNum);
			LOG.info("Material entered..inside if...=="+material);
			varMap.put("enteredSubstance", substance);
			varMap.put("casubstanceNum", casubstanceNum);
			varMap.put("selectedMaterial", material);
			LOG.info("before fetching the list");
			whUsedCASSubDataList = whrUsdSubstncService.getWhUsedCASSubData(substance,casubstanceNum,material);
			
			if(!PLMUtils.isEmptyList(whUsedCASSubDataList)){
				varMap.put("whUsedCASSubDataList", whUsedCASSubDataList);
				LOG.info("Inside fetched whUsedCASSubDataList with size"+whUsedCASSubDataList.size());
			
				prepareExcelWorkBook(varMap);
				if(whUsedCASSubDataList.size() != 0){
				writeWhUsedCASSubData(varMap);
				}
				writeDataToExcelFile(varMap);
				PLMUtils.generateZipFile((List<String>)varMap.get("filePathXlsLst"), (String)varMap.get("filePathZip"), false);
				sendWhUsedCASSubRptMail(varMap);	
				LOG.info("*****Report Generated and attachment sent Successfully*****");
			}else{
				StringBuffer noDataMailBody = new StringBuffer().append(toAddressee);
				noDataMailBody.append(PLMConstants.WHUSEDCASSUB_NO_CONTENT_BODY+"\n");
				noDataMailBody.append("Search Criteria"+"\n");
				noDataMailBody.append("---------------"+"\n");
				if(!PLMUtils.isEmpty(substance)){
				noDataMailBody.append("Substance: "+substance+"\n");
				}
				if(!PLMUtils.isEmpty(casubstanceNum)){
				noDataMailBody.append("CAS Number: "+casubstanceNum+"\n");
				}
				noDataMailBody.append("Material: "+material+"\n");
				
				StringBuffer subject = new StringBuffer().append(PLMConstants.WHUSEDCASSUB_MAIL_SUBJECT);
				
				noDataMailBody.append(PLMConstants.GBOM_MAIL_SIGNATURE)
				.append(PLMConstants.GBOM_MAIL_FOOTER);
				PLMUtils.sendMail(PLMConstants.BVS_MAIL_FROM, toEmailId, subject.toString(), noDataMailBody.toString());
				LOG.info("No data mail has been sent");
			}
		}
		//End
		} catch (IOException ioexception) {	
			LOG.log(Level.ERROR, "Exception@generateWhUsedCASSubstanceEmailReport: ", ioexception);
			PLMUtils.checkExceptionAndMail(ioexception.getMessage(),PLMConstants.BVS_MAIL_FROM,toEmailId,PLMConstants.WHUSEDCASSUB_MAIL_SUBJECT,toAddressee,PLMConstants.COST_CHG_MAIL_SIGNATURE);
		} catch (PLMCommonException exception) {
			String fwdflag="";
			LOG.log(Level.ERROR, "Exception@generateWhUsedCASSubstanceEmailReport: ",
					exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "whUsedCASSubstanceSearch", "Where Used - CAS Substance Report");
			LOG.info("exception.getMessage()---------------->"+exception.getMessage());
			PLMUtils.checkExceptionAndMail(exception.getMessage(),PLMConstants.BVS_MAIL_FROM,toEmailId,PLMConstants.WHUSEDCASSUB_MAIL_SUBJECT,toAddressee,PLMConstants.COST_CHG_MAIL_SIGNATURE);
			return fwdflag;
		}
		finally {
			if(varMap.get("filePathXlsx")!= null || varMap.get("filePathZip")!= null){
			PLMUtils.deleteFiles((String)varMap.get("filePathXlsx"),(String)varMap.get("filePathZip"));
			}
		}
		LOG.info("Exiting generateWhUsedCASSubstanceEmailReport Method");
		return"whUsedCASSubstanceSearch";
	}
	/**
	 * This method is used for creating Excel which will have BOM Vs Sales Data
	 * 
	 * @return void
	 * @throws PLMCommonException 
	 */
	private void prepareExcelWorkBook(Map<String, Object> varMap) throws PLMCommonException{
		LOG.info("Inside prepareExcelWorkBook");
		
		SXSSFWorkbook workbook = null;
		SXSSFSheet sheet1 = null;
		SXSSFSheet sheet2 = null;
		FileInputStream file = null;
		try{
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String folderPath = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXlsx = folderPath + resourceBundle.getString("WHUSEDCASSUB_REPORT_NAME") +  uniqTime + ".xlsx";
		String filePathZip = folderPath + resourceBundle.getString("WHUSEDCASSUB_REPORT_NAME") +  uniqTime + ".zip";
		List<String> filePathXlsLst = new ArrayList<String>();
		filePathXlsLst.add(filePathXlsx);
		
		LOG.info("After Template line");
		file = new FileInputStream(new File(folderPath + resourceBundle.getString("WHUSEDCASSUB_REPORT_TEMPLATE_NAME")));
		workbook = new SXSSFWorkbook();
		sheet1 = (SXSSFSheet) workbook.createSheet("Report");
		sheet2 =(SXSSFSheet) workbook.createSheet("List of Materials");
		LOG.info("sheet created====");
		LOG.info("cellstyle done");
		varMap.put("workbook", workbook);
		varMap.put("sheet1", sheet1);	
		varMap.put("sheet2", sheet2);	
		varMap.put("folderPath", folderPath);
		varMap.put("filePathXlsx", filePathXlsx);
		varMap.put("filePathZip", filePathZip);
		varMap.put("filePathXlsLst", filePathXlsLst);
		}catch(IOException io){
			LOG.log(Level.ERROR, "IOException@prepareExcelWorkBook: ", io);
		}finally {
			try {
				if (file != null) {
					file.close();
				}
			} catch (IOException exception) {
				LOG.log(Level.ERROR, "Exception@prepareExcelWorkBook: ", exception);
				PLMUtils.checkException(exception.getMessage());
			}
		}
		LOG.info("Last line of prepareExcelWorkBook");
	}
	/**
	 * This method is used for Comparing BOM Vs Sales Data
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void writeWhUsedCASSubData(Map<String, Object> varMap) throws PLMCommonException{
		
			List<PLMWhrUsdSubstncData> whUsedCASSubLclList = (List<PLMWhrUsdSubstncData>) varMap.get("whUsedCASSubDataList");
			LOG.info("Trying to write whUsedCASSubLclList of size"+whUsedCASSubLclList.size());
			
			int rowCount1 = 4;
			int rowCount2 = 0;
			SXSSFRow row1 = null;
			SXSSFRow row2 = null;
			SXSSFSheet sheet1 = null;
			SXSSFSheet sheet2 = null;
			SXSSFCell cell1 = null;
			SXSSFCell cell2 = null;
			SXSSFWorkbook workbook = null;
			
			sheet1 = (SXSSFSheet) varMap.get("sheet1");
			sheet1.setColumnWidth(0, 3200);
			sheet1.setColumnWidth(1, 4000);
			sheet1.setColumnWidth(2, 4000);
			sheet1.setColumnWidth(3, 5000);
			sheet1.setColumnWidth(4, 3000);
			sheet1.setColumnWidth(5, 6500);
			sheet1.setColumnWidth(6, 8000);
			sheet1.setColumnWidth(7, 5000);
			sheet1.setColumnWidth(8, 5000);
			sheet1.setColumnWidth(9, 6500);
			sheet1.setColumnWidth(10, 6500);
			sheet1.setColumnWidth(11, 6500);
			sheet1.setColumnWidth(12, 5000);
			sheet1.setColumnWidth(13, 4000);
			sheet1.setColumnWidth(14, 4500);
			sheet1.setColumnWidth(15, 4500);
			sheet1.setColumnWidth(16, 3500);
			sheet1.setColumnWidth(17, 4500);
			sheet1.setColumnWidth(18, 5500);
			sheet1.setColumnWidth(19, 4000);
			sheet1.setColumnWidth(20, 4000);
			sheet1.setColumnWidth(21, 5000);
					
			workbook = (SXSSFWorkbook) varMap.get("workbook");
			
			Font fntStyle = workbook.createFont();
	        fntStyle.setBoldweight(Font.BOLDWEIGHT_BOLD);
			
			XSSFCellStyle headerCellStyle=(XSSFCellStyle) workbook.createCellStyle();
			headerCellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			headerCellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			headerCellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			headerCellStyle.setBorderTop((HSSFCellStyle.BORDER_THIN));
			headerCellStyle.setFont(fntStyle);
			headerCellStyle.setAlignment(CellStyle.ALIGN_CENTER);
			//headerCellStyle.setFillBackgroundColor(HSSFColor.BLUE.index);
			headerCellStyle.setFillBackgroundColor(IndexedColors.YELLOW.getIndex());
			
			XSSFCellStyle textcellstyle = (XSSFCellStyle) workbook.createCellStyle(); 
			textcellstyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			textcellstyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			textcellstyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			textcellstyle.setBorderTop((HSSFCellStyle.BORDER_THIN));
			//textcellstyle.setFont(fontstyle);
			textcellstyle.setWrapText(true);
			textcellstyle.setLocked(false); 
			textcellstyle.setAlignment(CellStyle.ALIGN_CENTER);
			
			row1=(SXSSFRow) sheet1.createRow(0);
			cell1=(SXSSFCell) row1.createCell(0);
			cell1.setCellValue("Report Date:");
			cell1.setCellStyle(headerCellStyle);
			cell1=(SXSSFCell) row1.createCell(1);
			Date uniqDate = new Date();
			String reportDate = REPORT_DATE_FORMAT.format(uniqDate);
			cell1.setCellValue(reportDate);
			cell1.setCellStyle(textcellstyle);
			
			
			row1=(SXSSFRow) sheet1.createRow(1);
			cell1=(SXSSFCell) row1.createCell(0);
			cell1.setCellValue("Substance :");
			cell1.setCellStyle(headerCellStyle);
			cell1=(SXSSFCell) row1.createCell(1);
			cell1.setCellValue(PLMUtils.checkNullVal(varMap.get("enteredSubstance").toString()));
			cell1.setCellStyle(textcellstyle);
		
			row1=(SXSSFRow) sheet1.createRow(2);
			cell1=(SXSSFCell) row1.createCell(0);
			cell1.setCellValue("CAS Number :");
			cell1.setCellStyle(headerCellStyle);
			cell1=(SXSSFCell) row1.createCell(1);
			cell1.setCellValue(PLMUtils.checkNullVal(varMap.get("casubstanceNum").toString()));
			cell1.setCellStyle(textcellstyle);
	
			
			row1=(SXSSFRow) sheet1.createRow(3);
			cell1=(SXSSFCell) row1.createCell(0);
			cell1.setCellValue("Material :");
			cell1.setCellStyle(headerCellStyle);
			cell1=(SXSSFCell) row1.createCell(1);
			cell1.setCellValue(varMap.get("selectedMaterial").toString());
			cell1.setCellStyle(textcellstyle);
			
		/*	String[] colNames = {"Contract","Project",
					"WBSE Name","WBSE Part Name","MLI New","PO Number",
					"Purchase Folder Office DTTM","Supplier Name","Supplier Person","Supplier Email","Purchase Folder Name"
					,"Supplier BAAN Code","MLI Reference","Part Level","Part Number","Part Revision","Part Type"
					,"Part Attribute","Part Title","Material","Material Type","Substance CAS Num"
					,"Substance","Regulation","RDO"};*/	
			
			String[] colNames = {"Contract","Project",
					"WBSE Name","MLI New","PO Number",
					"Purchase Folder Office DTTM","Supplier Name","Supplier Person","Supplier Email","Purchase Folder Name"
					,"Supplier BAAN Code","MLI Reference","Part Level","Part Number","Part Revision","Part Type"
					,"Part Attribute","Part Title","Substance CAS Num","Regulation","RDO"};
		
			row1 = (SXSSFRow) sheet1.createRow(++rowCount1);
			for ( int i = 0 ; i < colNames.length; i++ ) {
				cell1 = (SXSSFCell) row1.createCell(i);
				cell1. setCellValue(colNames[i]);
				cell1.setCellStyle(headerCellStyle);
			}
			
			for(int i = 0; i < whUsedCASSubLclList.size(); i++) {
				PLMWhrUsdSubstncData	 dataObj = (PLMWhrUsdSubstncData)whUsedCASSubLclList.get(i);
				row1 =  (SXSSFRow) sheet1.createRow(++rowCount1);
				
				cell1 =   (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getContract());
				
				cell1 =   (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_ONE);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getProject());
				
				cell1 =   (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_TWO);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getWbseName());
			
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_THREE);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getMliNew());
					
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_FOUR);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getPoNumber());
				
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_FIVE);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getPurFoldOffDTTM());
				
				
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_SIX);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getSuppName());
				
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_SEVEN);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getSuppPerson());
				
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_EIGHT);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getSuppEmail());
				
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_NINE);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getPurFoldName());
				
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_TEN);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getSuppBAANCode());
				
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_ELEVEN);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getMliRef());
				
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_TWELVE);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getPartLevel());
				
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getPartNumber());
				
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getPartRevision());
				
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getPartType());
				
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getPartAttribute());
				
				cell1 = (SXSSFCell)  row1.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getPartTitle());
				
				
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_EIGHTEEN);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getSubCASNum());
				
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_NINETEEN);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getRegulation());
				
				cell1 =  (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_TWENTY);
				cell1.setCellStyle(textcellstyle);
				cell1.setCellValue(dataObj.getRdo());
			}
			
			sheet2 = (SXSSFSheet) varMap.get("sheet2");
			sheet2.setColumnWidth(0, 8000);
			
			row2=(SXSSFRow) sheet2.createRow(0);
			cell2=(SXSSFCell) row2.createCell(0);
			cell2.setCellValue("Material");
			cell2.setCellStyle(headerCellStyle);
			for(int i=0;i<materialList.size();i++){
				row2 =  (SXSSFRow) sheet2.createRow(++rowCount2);
			    String material = materialList.get(i).getValue().toString();
				cell2 =   (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell2.setCellStyle(textcellstyle);
				cell2.setCellValue(material);
			}
	}
	/**
	 * This method is used for Writing data in to Excel File
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void writeDataToExcelFile(Map<String, Object> varMap) throws IOException, PLMCommonException{
		SXSSFWorkbook workbook = (SXSSFWorkbook)varMap.get("workbook");
		FileOutputStream outFile = null;		
		String folderPath = (String) varMap.get("folderPath");
		String filePathXlsx = (String) varMap.get("filePathXlsx");		
		LOG.info("folderPath>> "+folderPath);
		try {
		outFile = new FileOutputStream(new File(filePathXlsx));
		workbook.write(outFile);
		
		} catch (IOException ioexception) {	
			PLMUtils.checkException(ioexception.getMessage());
			LOG.log(Level.ERROR, "Exception@writeDataToExcelFile: ", ioexception);
		}
		  finally{
			   if(outFile != null ){
				   try {
					   outFile.close();
				} catch (IOException e) {
					PLMUtils.checkException(e.getMessage());
				}
			   }
		}
	}
	/**
	 * This method is used for sendGBOMMail
	 * 
	 * @param varMap
	 * @throws PLMCommonException
	 */
	private void sendWhUsedCASSubRptMail(Map<String, Object> varMap) throws PLMCommonException{
		LOG.info("Entering sendWhUsedCASSubRptMail Method");
		String from = PLMConstants.BVS_MAIL_FROM;
		String toEmailId = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		StringBuffer subject = new StringBuffer().append(PLMConstants.WHUSEDCASSUB_MAIL_SUBJECT);
		StringBuffer mailBody = new StringBuffer().append(toAddressee);
		
		mailBody.append(PLMConstants.WHUSEDCASSUB_MAIL_CONTENT+"\n");
		mailBody.append("Search Criteria"+"\n");
		mailBody.append("---------------"+"\n");
		if(!PLMUtils.isEmpty(varMap.get("enteredSubstance").toString())){
		mailBody.append("Substance: "+PLMUtils.checkNullVal(varMap.get("enteredSubstance").toString())+"\n");
		}
		if(!PLMUtils.isEmpty(varMap.get("casubstanceNum").toString())){
		mailBody.append("CAS SubStance: "+PLMUtils.checkNullVal(varMap.get("casubstanceNum").toString())+"\n");
		}
		mailBody.append("Material: "+varMap.get("selectedMaterial")+"\n");
		
		mailBody.append(PLMConstants.GBOM_MAIL_SIGNATURE)
		.append(PLMConstants.GBOM_MAIL_FOOTER);
		PLMUtils.sendMailWithAttachment(from, toEmailId, subject.toString(), mailBody.toString(), (String)varMap.get("filePathZip"));
		LOG.info("Exiting sendWhUsedCASSubRptMail Method");
		
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the showMaterial
	 */
	public boolean isShowMaterial() {
		return showMaterial;
	}

	/**
	 * @param showMaterial the showMaterial to set
	 */
	public void setShowMaterial(boolean showMaterial) {
		this.showMaterial = showMaterial;
	}

	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return LOG;
	}
	/**
	 * @return the materialListNew
	 */
	public List<SelectItem> getMaterialListNew() {
		return materialListNew;
	}
	/**
	 * @param materialListNew the materialListNew to set
	 */
	public void setMaterialListNew(List<SelectItem> materialListNew) {
		this.materialListNew = materialListNew;
	}
	
	/**
	 * @param materialList the materialList to set
	 */
	public void setMaterialList(List<SelectItem> materialList) {
		this.materialList = materialList;
	}
	/**
	 * @return the whrUsdSubstncService
	 */
	public PLMWhrUsdSubstncServiceIfc getWhrUsdSubstncService() {
		return whrUsdSubstncService;
	}
	/**
	 * @param whrUsdSubstncService the whrUsdSubstncService to set
	 */
	public void setWhrUsdSubstncService(
			PLMWhrUsdSubstncServiceIfc whrUsdSubstncService) {
		this.whrUsdSubstncService = whrUsdSubstncService;
	}
	/**
	 * @return the whrUsdSubstncData
	 */
	public PLMWhrUsdSubstncData getWhrUsdSubstncData() {
		return whrUsdSubstncData;
	}
	/**
	 * @param whrUsdSubstncData the whrUsdSubstncData to set
	 */
	public void setWhrUsdSubstncData(PLMWhrUsdSubstncData whrUsdSubstncData) {
		this.whrUsdSubstncData = whrUsdSubstncData;
	}

}
