/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMTaskSearchMB.java
 * @Creation date: 18-June-2010
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

import javax.faces.component.html.HtmlCommandButton;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.richfaces.component.UIDataTable;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.context.PWiContext;
import com.geinfra.geaviation.pwi.data.PLMTaskMetricsData;
import com.geinfra.geaviation.pwi.data.PLMTaskSearchData;
import com.geinfra.geaviation.pwi.service.PLMkpiReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;
import com.geinfra.geaviation.pwi.util.UserInfoDbUtil;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMTaskSearchMB {
	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMTaskSearchMB.class);
	/**
	 * Holds the plmIssuesService
	 */
	private PLMkpiReportServiceIfc plmIssuesService = null;
	/**
	 * Holds the searchResultList
	 */
	private List<PLMTaskSearchData> searchResultList = new ArrayList<PLMTaskSearchData>();
	/**
	 * Holds the saveSearchResultList
	 */
	private List<PLMTaskSearchData> saveSearchResultList;
	/**
	 * Holds the discussionRptList
	 */
	private List<PLMTaskSearchData> discussionRptList;
	/**
	 * Holds the searchQuery
	 */
	private String searchQuery;
	/**
	 * Holds the selectedId
	 */
	private String selectedId;
	/**
	 * Holds the selectedIdList
	 */
	private Map<String, String> selectedIdList = new HashMap<String, String>();
	/**
	 * Holds the searchReportList
	 */
	private List<PLMTaskSearchData> searchReportList;
	/**
	 * Holds the loginMB
	 */
	private PLMCommonMB commonMB = null;
	/**
	 * Holds the assignTaskId
	 */
	private String assignTaskId = null;
	/**
	 * Holds the stateList
	 */
	private List<SelectItem> stateList = new ArrayList<SelectItem>();
	/**
	 * Holds the associatedTypeList
	 */
	private List<SelectItem> associatedTypeList;
	/**
	 * Holds the taskValuesList
	 */
	private List<SelectItem> taskValuesList;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_50;
	/**
	 * Holds the plmSearchData
	 */
	private PLMTaskSearchData plmSearchData = new PLMTaskSearchData();
	/**
	 * Holds the selectedTask
	 */
	private String selectedTask;
	/**
	 * Holds the selectedTaskPred
	 */
	private String selectedTaskPred;
	/**
	 * Holds the selectedTaskDt
	 */
	private String selectedTaskDt;
	/**
	 * Holds the selectedQueryName
	 */
	private String selectedQueryName;
	/**
	 * Holds the eCCNTagMaplist
	 */
	private Map<String, List<SelectItem>> eCCNTagMaplist;
	/**
	 * Holds the eccnTagList
	 */
	private List<String> eccnTagList = new ArrayList<String>();
	/**
	 * Holds the alertMsg
	 */
	private String alertMsgTsk;
	/**
	 * Holds the state
	 */
	private String state;
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the totalRecCountMsg
	 */
	private String totalRecCountMsg;
	/**
	 * Holds the totalRecCountForSaveSearchReport
	 */
	private int totalRecCountForSaveSearchReport;
	/**
	 * Holds the totalRecCountMsgForSaveSearchReport
	 */
	private String totalRecCountMsgForSaveSearchReport;
	/**
	 * Holds the recordCountsForSaveSearchReport
	 */
	private int recordCountsForSaveSearchReport = PLMConstants.N_10;
	/**
	 * Holds the ntotalRecCountMsg
	 */
	private String ntotalRecCountMsg;
	/**
	 * Holds the nrecordCounts
	 */
	private int nrecordCounts = PLMConstants.N_50;
	/**
	 * Holds the ntotalRecCount
	 */
	private int ntotalRecCount;
	/**
	 * Holds the page
	 */
	private String page;
	/**
	 * Holds the searchFlag
	 */
	private String searchFlag = "";
	/**
	 * Holds the exceptionOccurred
	 */
	private String exceptionOccurred;
	/**
	 * Holds the totalRecCountForDiscussioRpt
	 */
	private int totalRecCountForDiscussioRpt;
	/**
	 * Holds the totalRecCountMsgForDiscussioRpt
	 */
	private String totalRecCountMsgForDiscussioRpt;
	/**
	 * Holds the recordCountsForDiscussioRpt
	 */
	private int recordCountsForDiscussioRpt = PLMConstants.N_50;
	/**
	 * Holds the precedorList
	 */
	private List<PLMTaskSearchData> precedorList = new ArrayList<PLMTaskSearchData>();
	/**
	 * Holds the successorList
	 */
	private List<PLMTaskSearchData> successorList = new ArrayList<PLMTaskSearchData>();
	/**
	 * Holds the taskSearchDetailsList
	 */
	private List<PLMTaskSearchData> taskSearchDetailsList = new ArrayList<PLMTaskSearchData>();
	/**
	 * Holds the selectedQueryText
	 */
	private String selectedQueryText;
	/**
	 * Holds the projNameLink
	 */
	private UIDataTable projNameLink;
	/**
	 * Holds the assignProjName
	 */
	private String assignProjName;
	/**
	 * Holds the assignTaskName
	 */
	private String assignTaskName;
	/**
	 * Holds the ntotalPreRecCount
	 */
	private int ntotalPreRecCount;
	/**
	 * Holds the ntotalSuccRecCount
	 */
	private int ntotalSuccRecCount;
	/**
	 * Holds the ntotalPreRecCountMsg
	 */
	private String ntotalPreRecCountMsg;
	/**
	 * Holds the ntotalSuccRecCountMsg
	 */
	private String ntotalSuccRecCountMsg;
	/**
	 * Holds the rdoNamesList
	 */
	// private List<String> rdoNamesList= new ArrayList<String>();
	/**
	 * Holds the rdoListData
	 */
	// private List<SelectItem> rdoListData;
	/**
	 * Holds the eccnListData
	 */
	// private List<SelectItem> eccnListData;
	/**
	 * Holds the reportType
	 */
	// private String reportType="";
	/**
	 * Holds the eccnResultList
	 */
	// private List<PLMTaskSearchData> eccnResultList;
	/**
	 * Holds the eccnDailyResultList
	 */
	// private List<PLMTaskSearchData> eccnDailyResultList;
	/**
	 * Holds the eccnWeeklyResultList
	 */
	// private List<PLMTaskSearchData> eccnWeeklyResultList;
	/**
	 * Holds the eccnMonthlyResultList
	 */
	// private List<PLMTaskSearchData> eccnMonthlyResultList;
	/**
	 * Holds the ntotalEccnCount
	 */
	// private int ntotalEccnCount;
	/**
	 * Holds the ntotalEccnCountMsg
	 */
	// private String ntotalEccnCountMsg;

	/**
	 * Object of taskSrchData
	 */
	private PLMTaskSearchData taskSrchData;

	/**
	 * The String alertStr
	 */
	private String alertStr;
	/**
	 * Holds the projectNameLink
	 */
	private HtmlCommandButton projectNameLink;

	/**
	 * Holds the taskNameLink
	 */
	private HtmlCommandButton taskNameLink;
	/**
	 * Holds the recordPreRecCount
	 */
	private int recordPreRecCount = PLMConstants.N_50;
	/**
	 * Holds the recordSuccRecCount
	 */
	private int recordSuccRecCount = PLMConstants.N_100;
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the taskExecutor
	 */
	// private ThreadPoolTaskExecutor taskExecutor =null;
	/**
	 * Holds the taskData
	 */
	public List<PLMTaskSearchData> taskData = new ArrayList<PLMTaskSearchData>();
	/**
	 * Holds the rdoNames
	 */
	// private String rdoNames ;
	/**
	 * Holds the eccnNames
	 */
	// private String eccnNames;
	/**
	 * Holds the totalRecordCountEccn
	 */
	// private int totalRecordCountEccn;
	/**
	 * Holds the pageNo
	 */
	private int pageNo = 1;
	/**
	 * Holds the modifyQueryFlag
	 */
	private boolean modifyQueryFlag;
	/**
	 * Holds the eccnOnScreenDataList
	 */
	// private List<PLMTaskSearchData> eccnOnScreenDataList;
	/**
	 * Holds the eccnEmailDataList
	 */
	// private List<PLMTaskSearchData> eccnEmailDataList;
	 /**
	  * Holds the reportNameXls
	  */
	 private String reportNameXls;
	 /**
	  * Holds the fileNameXls
	  */
	 private String fileNameXls;

	// Newly added for contract info Report
	 
	 private String whereClauseQry;
	 
	 private String userName;
	 
	 private String userEmail;

	/**
	 * This method for loadTaskWithContractNm
	 * 
	 * @return String
	 */
	 
		/**
		 * Holds the taskExecutor
		 */
		private ThreadPoolTaskExecutor taskExecutor = null;
		
		/**
		 * @return the taskExecutor
		 */
		public ThreadPoolTaskExecutor getTaskExecutor() {

			return taskExecutor;
		}


		/**
		 * @param taskExecutor the taskExecutor to set
		 */
		public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {

			this.taskExecutor = taskExecutor;
		}
	 
	public String loadTaskWithContractNm() {
		LOG.info("Entering loadTaskWithContractNm method");
		alertMsgTsk = "";
		plmSearchData = new PLMTaskSearchData();
		String fwdflag = PLMConstants.EMPTY;
		modifyQueryFlag = false;
		try {
			Map<String, List<SelectItem>> dropdownTaskCntrMap = plmIssuesService
					.getTaskDropDownValues();
			stateList = ((List<SelectItem>) dropdownTaskCntrMap
					.get("taskstate"));
			associatedTypeList = ((List<SelectItem>) dropdownTaskCntrMap
					.get("taskAssociatedType"));

			HttpServletRequest httpRequest = (HttpServletRequest) FacesContext
					.getCurrentInstance().getExternalContext().getRequest();

			PLMContractRptMB contractData = (PLMContractRptMB) httpRequest
					.getSession().getAttribute("plmContractRptMB");
			String[] projectidNmArr = contractData.getProjectIdName()
					.split("~");
			String projectNm = projectidNmArr[2];

			LOG.info("contractData.getContractNum()>>>>>>>>."
					+ contractData.getContractNum());
			LOG.info("projectNm >>>>>>>>." + projectNm);
			plmSearchData.setProjectName(projectNm);
			plmSearchData.setContractName(contractData.getContractNum());
			fwdflag = "taskSearchHome";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadTaskPage: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "home", "Task Search");
		}

		try {
			commonMB.getPLMDateStamp(PLMConstants.TASK_TABLE);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPLMDateStamp: ", exception);
		}
		LOG.info("Exiting loadTaskWithContractNm method");
		return fwdflag;
	}
	
	//Newly Added for Project Information Report 
	public String loadTaskWithPrjContractNm() {
		LOG.info("Entering loadTaskWithPrjContractNm method");
		alertMsgTsk = "";
		plmSearchData = new PLMTaskSearchData();
		String fwdflag = PLMConstants.EMPTY;
		modifyQueryFlag = false;
		try {
			Map<String, List<SelectItem>> dropdownTaskCntrMap = plmIssuesService
					.getTaskDropDownValues();
			stateList = ((List<SelectItem>) dropdownTaskCntrMap
					.get("taskstate"));
			associatedTypeList = ((List<SelectItem>) dropdownTaskCntrMap
					.get("taskAssociatedType"));

			HttpServletRequest httpRequest = (HttpServletRequest) FacesContext
					.getCurrentInstance().getExternalContext().getRequest();

			PLMContractRptMB contractData = (PLMContractRptMB) httpRequest
					.getSession().getAttribute("plmContractRptMB");

			LOG.info("projectNm >>>>>>>>." + contractData.getPrjprojectName());
			plmSearchData.setProjectName(contractData.getPrjprojectName());
			fwdflag = "taskSearchHome";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadTaskPage: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "home", "Task Search");
		}

		try {
			commonMB.getPLMDateStamp(PLMConstants.TASK_TABLE);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPLMDateStamp: ", exception);
		}
		LOG.info("Exiting loadTaskWithPrjContractNm method");
		return fwdflag;
	}

	/**
	 * Background Process Thread
	 */
	/*
	 * private class MailThread implements Runnable { public MailThread(){}
	 * public void run() { sendEccnReportThroughMail(); } }
	 */

	// load the task search
	/**
	 * This method for loadTaskPage
	 * 
	 * @return String
	 */
	public String loadTaskPage() {
		LOG.info("Entering loadTaskPage method");
		alertMsgTsk = "";
		plmSearchData = new PLMTaskSearchData();
		String fwdflag = PLMConstants.EMPTY;
		modifyQueryFlag = false;
		try {
			commonMB.insertCannedRptRecordHitInfo("Task Search");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			Map<String, List<SelectItem>> dropdownTaskMap = plmIssuesService
					.getTaskDropDownValues();
			stateList = ((List<SelectItem>) dropdownTaskMap.get("taskstate"));
			associatedTypeList = ((List<SelectItem>) dropdownTaskMap
					.get("taskAssociatedType"));
			reset();
			fwdflag = "taskSearchHome";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadTaskPage: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "home", "Task Search");
		}

		/*try {
			commonMB.getPLMDateStamp(PLMConstants.TASK_TABLE);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPLMDateStamp: ", exception);
		}*/
		LOG.info("Exiting loadTaskPage method");
		return fwdflag;
	}

	/**
	 * This method for assignValues
	 * 
	 */
	public void assignValues() {
		LOG.info("Entering assignValues method");
		LOG.info("ASSIGN PROJ NAME>>>>>>>>>" + assignProjName);
		LOG.info("ASSIGN TASK NAME>>>>>>>>>" + assignTaskName);
		LOG.info("ASSIGN TASK ID>>>>>>>>>" + assignTaskId);
		selectedId = assignProjName + "," + assignTaskId;
		// selectedIdList.put(assignProjName, assignTaskId);
	}

	/**
	 * This method for assignValues
	 * 
	 * @param event
	 */
	public void recordsPerPageListner(ActionEvent event) {
		LOG.info("Entering recordsPerPageListner method");
		LOG.info("Action listner called.....--------------------------->"
				+ recordCounts);
		if (recordCounts == PLMConstants.N_50) {
			LOG.info("50");
			recordCounts = PLMConstants.N_50;
		} else if (recordCounts == PLMConstants.N_100) {
			LOG.info("100");
			recordCounts = PLMConstants.N_100;
		} else if (recordCounts == PLMConstants.N_200) {
			LOG.info("200");
			recordCounts = PLMConstants.N_200;
			;
		}

		LOG.info("final value.....--------------------------->" + recordCounts);
	}

	/**
	 * This method for recordsPerPageListner1
	 * 
	 * @param event
	 */
	public void recordsPerPageListner1(ActionEvent event) {
		LOG.info("Entering recordsPerPageListner method");
		LOG.info("Action listner called.....--------------------------->"
				+ recordPreRecCount);
		if (recordPreRecCount == PLMConstants.N_50) {
			LOG.info("50");
			recordPreRecCount = PLMConstants.N_50;
		} else if (recordPreRecCount == PLMConstants.N_100) {
			LOG.info("100");
			recordPreRecCount = PLMConstants.N_100;
		} else if (recordPreRecCount == PLMConstants.N_200) {
			LOG.info("200");
			recordPreRecCount = PLMConstants.N_200;
		}
		LOG.info("final value.....--------------------------->"
				+ recordPreRecCount);
	}

	/**
	 * This method for recordsPerPageListner2
	 * 
	 * @param event
	 */
	public void recordsPerPageListner2(ActionEvent event) {
		LOG.info("Entering recordsPerPageListner method");
		LOG.info("Action listner called.....--------------------------->"
				+ recordCountsForDiscussioRpt);
		if (recordCountsForDiscussioRpt == PLMConstants.N_50) {
			LOG.info("50");
			recordCountsForDiscussioRpt = PLMConstants.N_50;
		} else if (recordCountsForDiscussioRpt == PLMConstants.N_100) {
			LOG.info("100");
			recordCountsForDiscussioRpt = PLMConstants.N_100;
		} else if (recordCountsForDiscussioRpt == PLMConstants.N_200) {
			LOG.info("200");
			recordCountsForDiscussioRpt = PLMConstants.N_200;
		}

		LOG.info("final value.....--------------------------->"
				+ recordCountsForDiscussioRpt);
	}

	/**
	 * This method for recordsPerPageListner3
	 * 
	 * @param event
	 */
	public void recordsPerPageListner3(ActionEvent event) {
		LOG.info("Entering recordsPerPageListner method");
		LOG.info("Action listner called.....--------------------------->"
				+ nrecordCounts);
		if (nrecordCounts == PLMConstants.N_50) {
			LOG.info("50");
			nrecordCounts = PLMConstants.N_50;
		} else if (nrecordCounts == PLMConstants.N_100) {
			LOG.info("100");
			nrecordCounts = PLMConstants.N_100;
		} else if (nrecordCounts == PLMConstants.N_200) {
			LOG.info("200");
			nrecordCounts = PLMConstants.N_200;
		}
		LOG.info("final value.....--------------------------->" + nrecordCounts);
	}

	/**
	 * This method for validateTaskSearchData
	 * 
	 * @return String
	 */
	public String validateTaskSearchData() {
		// try {
		Date estimatedFinishFromDate = plmSearchData
				.getEstimatedFinishFromDate();
		Date estimatedFinishToDate = plmSearchData.getEstimatedFinishToDate();
		Date actualFinishFromDate = plmSearchData.getActualFinishFromDate();
		Date actualFinishToDate = plmSearchData.getActualFinishToDate();

		Date mfgFromDateM = plmSearchData.getMfgFromDate();
		Date mfgToDateM = plmSearchData.getMfgToDate();
		Date cusFromDate = plmSearchData.getCustomerFromDate();
		Date cusToDate = plmSearchData.getCustomerToDate();

		Date earlyFromDate = plmSearchData.getEarlyFinishFromDate();
		Date earlyToDate = plmSearchData.getEarlyFinishToDate();
		Date lateFromDate = plmSearchData.getLateFinishFromDate();
		Date lateToDate = plmSearchData.getLateFinishToDate();

		Date creationFromDate = plmSearchData.getCreationFromDate();
		Date creationToDate = plmSearchData.getCreationToDate();
		Date expFnshFromDate = plmSearchData.getExpctdFinishFromDt();
		Date expFnshToDate = plmSearchData.getExpctdFinishToDt();

		
		if (plmSearchData.isAllOpen()) {
			if (!PLMUtils.isEmptyList(stateList)) {
				List<String> allOpenStateList = new ArrayList<String>();
				for (int i = 0; i < stateList.size(); i++) {
					String stateValue = stateList.get(i).getLabel();
					if (!stateValue.equals("Complete")) {
						allOpenStateList.add(stateValue);
					}
				}
				plmSearchData.setTaskStateList(allOpenStateList);
			}
		}

		if (PLMUtils.isEmpty(plmSearchData.getName())
				&& PLMUtils.isEmptyList(plmSearchData.getTaskStateList())
				&& PLMUtils.isEmpty(plmSearchData.getOwner())
				&& PLMUtils.isEmpty(plmSearchData.getOrginator())
				&& PLMUtils.isEmpty(plmSearchData.getTaskResponsiblity())
				&& PLMUtils.isEmpty(plmSearchData.getPercentageComplete())
				&& PLMUtils.isEmpty(plmSearchData.getStatus())
				&& PLMUtils.isEmptyDate(estimatedFinishFromDate)
				&& PLMUtils.isEmptyDate(estimatedFinishToDate)
				&& PLMUtils.isEmpty(plmSearchData.getTaskApproval())
				&& PLMUtils.isEmptyDate(actualFinishFromDate)
				&& PLMUtils.isEmptyDate(actualFinishToDate)
				&& PLMUtils.isEmpty(plmSearchData.getType())
				&& PLMUtils.isEmpty(plmSearchData.getVoucherfind())
				&& PLMUtils.isEmpty(plmSearchData.getPolicy())
				&& PLMUtils.isEmpty(plmSearchData.getProjectName())
				&& PLMUtils.isEmpty(plmSearchData.getProjectDesc())
				&& PLMUtils.isEmpty(plmSearchData.getContractName())
				&& PLMUtils.isEmpty(plmSearchData.getTaskName())
				&& PLMUtils.isEmpty(plmSearchData.getAssignee())

				&& PLMUtils.isEmpty(plmSearchData.getMfgIndicator())
				&& PLMUtils.isEmpty(plmSearchData.getTaskResponsiblityUnit())
				&& PLMUtils.isEmpty(plmSearchData.getDeliverable())
				&& PLMUtils.isEmptyDate(mfgFromDateM)
				&& PLMUtils.isEmptyDate(mfgToDateM)
				&& PLMUtils.isEmptyDate(cusFromDate)
				&& PLMUtils.isEmptyDate(cusToDate)
				&& PLMUtils.isEmptyList(plmSearchData.getTaskAstdTypeList())
				&& PLMUtils.isEmpty(plmSearchData.getAssociatedName())
				&& PLMUtils.isEmptyDate(earlyFromDate)
				&& PLMUtils.isEmptyDate(earlyToDate)
				&& PLMUtils.isEmptyDate(lateFromDate)
				&& PLMUtils.isEmptyDate(lateToDate)
				&& PLMUtils.isEmptyDate(creationFromDate)
				&& PLMUtils.isEmptyDate(creationToDate)
				&& PLMUtils.isEmptyDate(expFnshFromDate)
				&& PLMUtils.isEmptyDate(expFnshToDate)

		) {
			alertMsgTsk = PLMConstants.SEARCH_CRITERIA;
			LOG.info("Please enter any criteria and click on search");
		} else {
			String ownerWithOutAsterisk = null;
			String originatorWithOutAsterisk = null;

			if (!PLMUtils.isEmpty(plmSearchData.getOwner())) {
				ownerWithOutAsterisk = PLMUtils
						.removeAsteriskAndSpaceFromSSOFields(plmSearchData
								.getOwner());
			}
			if (!PLMUtils.isEmpty(plmSearchData.getOrginator())) {
				originatorWithOutAsterisk = PLMUtils
						.removeAsteriskAndSpaceFromSSOFields(plmSearchData
								.getOrginator());
			}
			if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmSearchData
					.getName())) {
				alertMsgTsk = alertMsgTsk + PLMConstants.NAME_MESSAGE;
			}
			if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmSearchData
					.getOwner())) {
				alertMsgTsk = alertMsgTsk + PLMConstants.OWNER_MESSAGE;
			} else if (PLMUtils.isInteger(ownerWithOutAsterisk)) {
				if (ownerWithOutAsterisk.length() != 9)
					alertMsgTsk = alertMsgTsk
							+ PLMConstants.TASK_OWNER_DIGT_MESSAGE;
			}
			if (!PLMUtils.isEmpty(plmSearchData.getOrginator())) {
				if (!PLMUtils

						.checkForSpecialCharsForTaskSearch(plmSearchData
								.getOrginator())) {
					alertMsgTsk = alertMsgTsk + PLMConstants.ORIGINATOR_MESSAGE;
				}
			} else if (PLMUtils.isInteger(originatorWithOutAsterisk)) {
				if (originatorWithOutAsterisk.length() != 9)
					alertMsgTsk = alertMsgTsk
							+ PLMConstants.ORIGINATOR_DIGT_MESSAGE;
			}
			if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmSearchData
					.getTaskResponsiblity())) {
				alertMsgTsk = alertMsgTsk + PLMConstants.TASK_RESPONSE;
			}
			if (PLMUtils.isEmptyForMultipleValues(plmSearchData
					.getTaskResponsiblity())
					&& !PLMUtils.isEmpty(plmSearchData.getTaskResponsiblity())) {
				alertMsgTsk = alertMsgTsk
						+ PLMConstants.TASK_RESPONSE_INVALID_MESSAGE;
			}

			String taskResponsiblityAllValue = plmSearchData
					.getTaskResponsiblity();
			if (!PLMUtils.isEmpty(taskResponsiblityAllValue)) {
				StringTokenizer tokens = new StringTokenizer(
						taskResponsiblityAllValue, ",");
				boolean validTaskResponsiblityValue = true;

				while (tokens.hasMoreTokens()) {
					String taskResponsiblityValue = tokens.nextToken();
					String taskResponsiblityWithOutAsterisk = PLMUtils
							.removeAsteriskAndSpaceFromSSOFields(taskResponsiblityValue);
					if (PLMUtils.isInteger(taskResponsiblityWithOutAsterisk)) {
						if (taskResponsiblityWithOutAsterisk.length() != 9) {
							validTaskResponsiblityValue = false;
						}
					}
				}
				if (!validTaskResponsiblityValue) {
					alertMsgTsk = alertMsgTsk
							+ PLMConstants.TASK_RESPONSE_VALIDATE;
				}
			}

			if (!PLMUtils.isEmpty(plmSearchData.getPercentageComplete())) {
				if (!PLMUtils.checkForSpecialCharsForInteger(plmSearchData
						.getPercentageComplete())) {
					alertMsgTsk = alertMsgTsk + PLMConstants.PERCENT_MESSAGE;
				}
			}

			if (!PLMUtils.isEmpty(plmSearchData.getStatus())) {
				if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmSearchData
						.getStatus())) {
					alertMsgTsk = alertMsgTsk + PLMConstants.STATUS_MESSAGE;
				}
			}
			if (!PLMUtils.isEmpty(plmSearchData.getTaskApproval())) {
				if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmSearchData
						.getTaskApproval())) {
					alertMsgTsk = alertMsgTsk + PLMConstants.TASKAPPRV_MESSAGE;
				}
			}
			if (!PLMUtils.isEmpty(plmSearchData.getType())) {
				if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmSearchData
						.getType())) {
					alertMsgTsk = alertMsgTsk
							+ PLMConstants.ASSOCIATETYPE_MESSAGE;
				}
			}
			if (!PLMUtils.isEmpty(plmSearchData.getVoucherfind())) {
				if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmSearchData
						.getVoucherfind())) {
					alertMsgTsk = alertMsgTsk + PLMConstants.VOCHERFIND_MESSAGE;
				}
			}
			if (!PLMUtils.isEmpty(plmSearchData.getPolicy())) {
				if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmSearchData
						.getPolicy())) {
					alertMsgTsk = alertMsgTsk + PLMConstants.POLICY_MESSAGE;
				}
			}
			if (!PLMUtils.isEmpty(plmSearchData.getProjectName())) {
				if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmSearchData
						.getProjectName())) {
					alertMsgTsk = alertMsgTsk + PLMConstants.PROJNAME_MESSAGE;
				}
			}
			if (!PLMUtils.isEmpty(plmSearchData.getTaskResponsiblityUnit())) {
				if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmSearchData
						.getTaskResponsiblityUnit())) {
					alertMsgTsk = alertMsgTsk
							+ PLMConstants.TASKRESPONIBLEUNIT_MESSAGE;
				}
			}
			if (!PLMUtils.isEmpty(plmSearchData.getMfgIndicator())) {
				if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmSearchData
						.getMfgIndicator())) {
					alertMsgTsk = alertMsgTsk
							+ PLMConstants.MFGINDICATOR_MESSAGE;
				}
			}
			if (!PLMUtils.isEmpty(plmSearchData.getDeliverable())) {
				if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmSearchData
						.getDeliverable())) {
					alertMsgTsk = alertMsgTsk
							+ PLMConstants.DELIVERABLE_MESSAGE;
				}
			}
			if (PLMUtils.isEmptyForMultipleValues(plmSearchData
					.getProjectName())
					&& !PLMUtils.isEmpty(plmSearchData.getProjectName())) {
				alertMsgTsk = alertMsgTsk
						+ PLMConstants.PROJNAME_INVALID_MESSAGE;
			}

			if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmSearchData
					.getProjectDesc())
					&& !PLMUtils.isEmpty(plmSearchData.getProjectDesc())) {
				alertMsgTsk = alertMsgTsk + PLMConstants.PROJDESC_MESSAGE;
			}

			if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmSearchData
					.getContractName())
					&& !PLMUtils.isEmpty(plmSearchData.getContractName())) {
				alertMsgTsk = alertMsgTsk + PLMConstants.CONTRTNAME_MESSAGE;
			}
			if (!PLMUtils.isEmpty(plmSearchData.getTaskName())) {
				if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmSearchData
						.getTaskName())) {
					alertMsgTsk = alertMsgTsk + PLMConstants.GE_ACTIVITYCODE;
				}
			}
			if (PLMUtils.isEmptyForMultipleValues(plmSearchData
					.getTaskName())
					&& !PLMUtils.isEmpty(plmSearchData.getTaskName())) {
				alertMsgTsk = alertMsgTsk
						+ PLMConstants.GE_INVALID_ACTIVITYCODE;
			}
			if (!PLMUtils.isEmpty(plmSearchData.getAssignee())) {
				if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmSearchData
						.getAssignee())) {
					alertMsgTsk = alertMsgTsk + PLMConstants.ASSIGNEES_SPL;
				}
			}

			if (PLMUtils.isEmptyForMultipleValues(plmSearchData.getAssignee())
					&& !PLMUtils.isEmpty(plmSearchData.getAssignee())) {
				alertMsgTsk = alertMsgTsk
						+ PLMConstants.ASSIGNEES_INVALID_MESSAGE;
			}
			String assigneeAllValue = plmSearchData.getAssignee();
			if (!PLMUtils.isEmpty(assigneeAllValue)) {
				StringTokenizer tokens = new StringTokenizer(assigneeAllValue,
						",");
				boolean validAssigneeValue = true;

				while (tokens.hasMoreTokens()) {
					String assigneeValue = tokens.nextToken();
					String assigneeWithOutAsterisk = PLMUtils
							.removeAsteriskAndSpaceFromSSOFields(assigneeValue);
					if (PLMUtils.isInteger(assigneeWithOutAsterisk)) {
						if (assigneeWithOutAsterisk.length() != 9) {
							validAssigneeValue = false;
						}
					}
				}
				if (!validAssigneeValue) {
					alertMsgTsk = alertMsgTsk + PLMConstants.ASSIGNEE_VALIDATE;
				}
			}

			if (PLMUtils.checkForNullOfTwoDates(estimatedFinishFromDate,
					estimatedFinishToDate)) {
				alertMsgTsk = alertMsgTsk + PLMConstants.Dates_NullCheck_Msg;
			} else if (PLMUtils.checkForFromAndToDate(estimatedFinishFromDate,
					estimatedFinishToDate)) {
				alertMsgTsk = alertMsgTsk + PLMConstants.Date_ValMsg;
			}

			if (PLMUtils.checkForNullOfTwoDates(actualFinishFromDate,
					actualFinishToDate)) {
				alertMsgTsk = alertMsgTsk + PLMConstants.Dates_NullCheck_Msg;
			} else if (PLMUtils.checkForFromAndToDate(actualFinishFromDate,
					actualFinishToDate)) {
				alertMsgTsk = alertMsgTsk + PLMConstants.Date_ValMsg;
			}

			if (PLMUtils.checkForNullOfTwoDates(mfgFromDateM, mfgToDateM)) {
				alertMsgTsk = alertMsgTsk + PLMConstants.Dates_NullCheck_Msg;
			} else if (PLMUtils.checkForFromAndToDate(mfgFromDateM, mfgToDateM)) {
				alertMsgTsk = alertMsgTsk + PLMConstants.Date_ValMsg;
			}

			if (PLMUtils.checkForNullOfTwoDates(cusFromDate, cusToDate)) {
				alertMsgTsk = alertMsgTsk + PLMConstants.Dates_NullCheck_Msg;
			} else if (PLMUtils.checkForFromAndToDate(cusFromDate, cusToDate)) {
				alertMsgTsk = alertMsgTsk + PLMConstants.Date_ValMsg;
			}

			if (PLMUtils.checkForNullOfTwoDates(earlyFromDate, earlyToDate)) {
				alertMsgTsk = alertMsgTsk + PLMConstants.Dates_NullCheck_Msg;
			} else if (PLMUtils.checkForFromAndToDate(earlyFromDate,
					earlyToDate)) {
				alertMsgTsk = alertMsgTsk + PLMConstants.Date_ValMsg;
			}

			if (PLMUtils.checkForNullOfTwoDates(lateFromDate, lateToDate)) {
				alertMsgTsk = alertMsgTsk + PLMConstants.Dates_NullCheck_Msg;
			} else if (PLMUtils.checkForFromAndToDate(lateFromDate, lateToDate)) {
				alertMsgTsk = alertMsgTsk + PLMConstants.Date_ValMsg;
			}
		}
		/*
		 * }catch (Exception exception) { LOG.log(Level.ERROR,
		 * "Exception@validateTaskSearchData: ", exception); LOG.info("Error :"
		 * + exception.getMessage()); }
		 */
		return alertMsgTsk;
	}

	/**
	 * This method for getTaskSearchData
	 * 
	 * @return String
	 */
	public String getTaskSearchData() {
		String fwdFlag = "";
		LOG.info("Entering getTaskSearchData() method");
		 reportNameXls= "taskSearchReportExcel";
		 fileNameXls="Task Report";
		 alertMsgTsk="";
		 Map<String,List<PLMTaskSearchData>> searchRsltMap = new HashMap<String, List<PLMTaskSearchData>>();
		 
		try {
			alertMsgTsk = validateTaskSearchData();
			if (PLMUtils.isEmpty(alertMsgTsk)) {
				
				searchRsltMap = plmIssuesService.getTaskSearchData(
						plmSearchData, "SEARCH");
				
				for (Map.Entry<String,List<PLMTaskSearchData>> searchEntry : searchRsltMap.entrySet()) {
					
					whereClauseQry = searchEntry.getKey();
					searchResultList = searchEntry.getValue();
				}
				 
				/*
				 * if(searchFlag.equals("SEARCH_AND_EXPORT_EXCEL")){ if
				 * (!PLMUtils.isEmptyList(searchResultList)) {
				 * getTaskSearchDataIntoExcel(); fwdFlag = ""; } else { fwdFlag
				 * = "taskInvalidSearch"; } } else
				 */if (searchFlag.equals("SEARCH")) {
					if (!PLMUtils.isEmptyList(searchResultList)) {
						LOG.info("valid task Search");
						totalRecCount = searchResultList.size();
						recordCounts = PLMConstants.N_50;
						fwdFlag = "taskSearchReport";
						totalRecCountMsg = "Total Results Count : "
								+ totalRecCount;
						LOG.info("Total Results Count : " + totalRecCount);
					} else {
						LOG.info("No records");
						fwdFlag = "taskInvalidSearch";
					}
				}
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getTaskSearchData: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "taskSearchHome", "Task Search");
		}
		page = "tasksearch";
		return fwdFlag;
	}

	/**
	 * This method for getTaskSaveAndSearchData
	 * 
	 * @return String
	 */
	public String getTaskSaveAndSearchData() {
		LOG.info("Entering getTaskSaveAndSearchData() Method");
		String fwdFlag = "";
		 reportNameXls= "taskSearchReportExcel";
		 fileNameXls="Task Report";
		 Map<String,List<PLMTaskSearchData>> searchRsltMap = new HashMap<String, List<PLMTaskSearchData>>();
		try {

			// plmSearchData.setSsoId(userDataObj.getUserSsoId());
			try {
				plmSearchData.setSsoId(PWiContext.getCurrentInstance()
						.getUserSso());
			} catch (PWiException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (!PLMUtils.isEmptyList(searchResultList)) {
				searchResultList.clear();
			}	
			searchRsltMap = plmIssuesService.getTaskSearchData(
					plmSearchData, "SAVE_AND_SEARCH");
			
			for (Map.Entry<String,List<PLMTaskSearchData>> searchEntry : searchRsltMap.entrySet()) {
				
				whereClauseQry = searchEntry.getKey();
				searchResultList = searchEntry.getValue();
			}
		
			if (!PLMUtils.isEmptyList(searchResultList)) {
				totalRecCount = searchResultList.size();
				recordCounts = PLMConstants.N_50;
				fwdFlag = "taskSearchReport";
				totalRecCountMsg = "Total Results Count : " + totalRecCount;
				LOG.info("Total Results Count : " + totalRecCount);
			} else {
				fwdFlag = "taskInvalidSearch";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getTaskSaveAndSearchData: ",
					exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "taskSearchHome", "Task Search");
		}
		LOG.info("Exiting getTaskSaveAndSearchData() Method");
		page = "tasksearch";
		return fwdFlag;
	}

	/**
	 * This method for validateTaskQueryName
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String validateTaskQueryName() throws PLMCommonException {
		LOG.info("Entering validateTaskQueryName() Method");
		String fwdFlag = "";
		boolean isQueryNameExist = false;
		// String isQueryNameModify;
		String queryName = plmSearchData.getQueryName();
		String singleSpaceQryName = queryName.replaceAll("( )+", " ");
		LOG.info("Removing more then one space from query name : "
				+ singleSpaceQryName);
		try {
			if (PLMUtils.isEmpty(singleSpaceQryName)) {
				alertMsgTsk = PLMConstants.QUERYNAME_INVALID_MESSAGE;
			} else if (!PLMUtils
					.checkForSpecialCharsForTaskSearch(singleSpaceQryName)) {
				alertMsgTsk = PLMConstants.QUERYNAME_SPLCHAR_MESSAGE;
			} else if (PLMUtils.isEmpty(plmSearchData.getSeqID())) {
				// isQueryNameExist =
				// plmIssuesService.queryNameCheck(userDataObj.getUserSsoId(),singleSpaceQryName);
				try {
					isQueryNameExist = plmIssuesService.queryNameCheck(
							PWiContext.getCurrentInstance().getUserSso(),
							singleSpaceQryName);
				} catch (PWiException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				exceptionOccurred = "NO";
				if (isQueryNameExist) {
					alertMsgTsk = PLMConstants.QUERYNAME_DUPTEVAL_MESSAGE;
				}
			} else if (!PLMUtils.isEmpty(plmSearchData.getSeqID())) {
				/*
				 * isQueryNameModify =
				 * plmIssuesService.queryNameModify(plmSearchData.getSeqID());
				 * if(isQueryNameModify.equals(plmSearchData.getQueryName())){
				 * alertMsg = PLMConstants.QUERYNAME_DUPTEVAL_MESSAGE; }
				 */
				exceptionOccurred = "NO";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@validateTaskQueryName: ", exception);
			PLMUtils.setCommonException(exception.getMessage(), commonMB,
					"taskSearchHome", "Task Search");
			throw exception;
		}
		LOG.info("Exiting validateTaskQueryName() Method");
		return fwdFlag;
	}

	/**
	 * This method for getTaskProjectMapDetails
	 * 
	 */
	public void getTaskProjectMapDetails() {
		List<String> taskDetails = new ArrayList<String>();
		int count = 0;

		StringTokenizer token = new StringTokenizer(selectedTaskPred, ",");
		while (token.hasMoreElements()) {
			taskDetails.add(token.nextToken());
		}

		selectedTaskPred = "";
		if (taskDetails != null && taskDetails.size() > 0) {
			Pattern pat = Pattern.compile(PLMConstants.PATTERN_AND_STRING);
			count = 0;
			LOG.info("taskDetails.size(------->" + taskDetails.size());
			for (String preTask : taskDetails) {
				if (preTask != null) {
					String array[] = pat.split(preTask);
					if (array != null && array.length > 0) {
						String name = array[0];
						String taskId = array[1];

						boolean projFlg = false;

						if (preTask.contains("PROJECT_NAME")) {
							projFlg = true;
						}

						String projectName = null;

						if (projFlg) {
							projectName = array[2];
						}
						count = count + 1;
						if (taskDetails.size() > 1
								&& taskDetails.size() > count) {
							if (projFlg) {
								selectedTaskPred = selectedTaskPred + name
										+ " AND " + projectName + ",";
							} else {
								selectedTaskPred = selectedTaskPred + name
										+ "),";
							}
						} else if (taskDetails.size() == count) {
							if (projFlg) {
								selectedTaskPred = selectedTaskPred + name
										+ " AND " + projectName;
							} else {
								selectedTaskPred = selectedTaskPred + name
										+ ")";
							}
						}
						String projectValue = null;
						String newTaskId = null;
						if (projFlg) {
							Pattern pat1 = Pattern
									.compile(PLMConstants.PATTERN_SPA_STRING);
							String array1[] = pat1.split(projectName);
							String projectNewName = array1[0];

							// to get the Project Value
							Pattern pat2 = Pattern
									.compile(PLMConstants.PATTERN_EQL_STRING);
							String arrayProjectValue[] = pat2
									.split(projectNewName);
							projectValue = arrayProjectValue[1];
						}

						Pattern patTaskId = Pattern
								.compile(PLMConstants.PATTERN_EQL_STRING);
						String arrayTaskId[] = patTaskId.split(taskId);
						newTaskId = arrayTaskId[1];

						// to get the Task Value
						Pattern patTask = Pattern
								.compile(PLMConstants.PATTERN_EQL_STRING);
						String arrayTaskValue[] = patTask.split(name);
						String taskValue = arrayTaskValue[1];

						// to remove the ' values for the project Name and Task
						// name
						String projectCommaValue = null;
						String taskIdCommaValue = null;
						if (projFlg) {
							Pattern projcommaValue = Pattern
									.compile(PLMConstants.PATTERN_COMMA_STRING);
							String arrayProjectCommaVal[] = projcommaValue
									.split(projectValue);
							projectCommaValue = arrayProjectCommaVal[1];

						}

						Pattern taskidcommaValue = Pattern
								.compile(PLMConstants.PATTERN_COMMA_STRING);
						String arrayTaskIdCommaVal[] = taskidcommaValue
								.split(newTaskId);
						taskIdCommaValue = arrayTaskIdCommaVal[1];

						Pattern taskcommaValue = Pattern
								.compile(PLMConstants.PATTERN_COMMA_STRING);
						String arrayTaskCommaVal[] = taskcommaValue
								.split(taskValue);
						String taskCommaValue = arrayTaskCommaVal[1];

						String mapValue = null;

						if (projFlg) {
							mapValue = projectCommaValue + "," + taskCommaValue;
						} else {
							mapValue = taskCommaValue;
						}
						selectedIdList.put(mapValue, taskIdCommaValue);

					}
				}
			}
		}
	}

	/**
	 * This method for getTaskSearchPrecedorSuccessor
	 * 
	 * @return String
	 */
	public String getTaskSearchPrecedorSuccessor() {
		String fwdFlag = PLMConstants.EMPTY;
		getTaskProjectMapDetails();
		try {
			if (!PLMUtils.isEmptyList(precedorList)) {
				precedorList.clear();
			}
			precedorList = plmIssuesService.getSucesPredessorData(
					selectedTaskPred, selectedIdList);
			// List<PLMTaskSearchData> tempTaskList = new
			// ArrayList<PLMTaskSearchData>();
			// tempTaskList = precedorList;

			if (precedorList.size() != 0) {
				ntotalPreRecCount = precedorList.size();
				recordPreRecCount = PLMConstants.N_50;
				 reportNameXls= "taskSearchPredSucc";
				 fileNameXls="PredecesorSuccesor Report";
				fwdFlag = "taskPrecedorSuccessor";
			} else {
				fwdFlag = "taskInvalidSelect";

			}
			LOG.info("FINAL LIST SIZE------->" + precedorList.size());
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@getTaskSearchPrecedorSuccessor: ",
					exception);
		}
		return fwdFlag;
	}

	/**
	 * This method for validateTaskSaveAndSearch
	 * 
	 * @return String
	 */
	public String validateTaskSaveAndSearch() {
		LOG.info("Entering validateTaskSaveAndSearch() Method");
		String fwdFlag = "";
		alertMsgTsk = validateTaskSearchData();
		alertMsgTsk = replaceBreak(alertMsgTsk);
		if (plmSearchData.getSeqID() == null) {
			plmSearchData.setQueryName("");
		}
		LOG.info("Exiting validateTaskSaveAndSearch() Method");
		return fwdFlag;
	}

	/**
	 * This method for replaceBreak
	 * 
	 * @param temp
	 * @return String
	 */
	public String replaceBreak(String temp) {
		String template = temp;
		int position = template.indexOf('\n');
		if (position == -1) {
			return template;
		} else {
			String firstHalf = template.substring(0, position);
			String secondHalf = template.substring(position + 1,
					template.length());
			template = firstHalf + "<br>" + secondHalf;
			if (template.indexOf('\n') != -1)
				template = replaceBreak(template);
		}
		return template;
	}

	/**
	 * This method for loadSaveAndSearchQueries
	 * 
	 * @return String
	 * @throws PWiException 
	 */

	public String loadSaveAndSearchQueries() throws PWiException{

		String fwdFlag = "";
		alertMsgTsk = "";
		try {
			commonMB.insertCannedRptRecordHitInfo("My Task Queries");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		fwdFlag = displaySaveAndSearchQuries();
		return fwdFlag;
	}

	/**
	 * This method for displaySaveAndSearchQuries
	 * 
	 * @return String
	 * @throws PWiException 
	 */

	public String displaySaveAndSearchQuries() throws PWiException{

		LOG.info("Entering displaySaveAndSearchQuries() Method");
		String fwdFlag = "";
		try {

			// saveSearchResultList =
			// plmIssuesService.displaySaveAndSearchQuries(userDataObj.getUserSsoId());
			try {
				if (!PLMUtils.isEmptyList(saveSearchResultList)) {
					saveSearchResultList.clear();
				}
				saveSearchResultList = plmIssuesService
						.displaySaveAndSearchQuries(PWiContext
								.getCurrentInstance().getUserSso());
			} catch (PWiException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (!PLMUtils.isEmptyList(saveSearchResultList)) {
				totalRecCountForSaveSearchReport = saveSearchResultList.size();
				recordCountsForSaveSearchReport = PLMConstants.N_10;
				fwdFlag = "taskMySavedSearchQueryReport";
				totalRecCountMsgForSaveSearchReport = "Total Results Count : "
						+ totalRecCountForSaveSearchReport;
				LOG.info("Total Results Count : "
						+ totalRecCountForSaveSearchReport);
			} else {
				LOG.info("No records");
				fwdFlag = "invalidTaskSaveSearch";
			}
			/*saveSearchResultList = plmIssuesService.displaySaveAndSearchQuries(PWiContext.getCurrentInstance().getUserSso());
					if (!PLMUtils.isEmptyList(saveSearchResultList)) {
						totalRecCountForSaveSearchReport = saveSearchResultList.size();
						recordCountsForSaveSearchReport = PLMConstants.N_10;
						fwdFlag = "taskMySavedSearchQueryReport";
						totalRecCountMsgForSaveSearchReport = "Total Results Count : " + totalRecCountForSaveSearchReport;
						LOG.info("Total Results Count : " + totalRecCountForSaveSearchReport);
					} else {
						LOG.info("No records");
						fwdFlag = "invalidTaskSaveSearch";
					}*/

		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@displaySaveAndSearchQuries: ",
					exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "home", "My Task Queries");
		}
		LOG.info("Exiting displaySaveAndSearchQuries() Method");
		return fwdFlag;
	}

	/**
	 * This method for deleteQryNameByCheckboxSelection
	 * 
	 * @return String
	 * @throws PWiException 
	 */

	public String deleteQryNameByCheckboxSelection() throws PWiException{
		LOG.info("Entering deleteQryNameByCheckboxSelection() Method");
		String fwdFlag = "";
		try {
			// int deletedCount =
			// plmIssuesService.deleteQryNameByCheckboxSelection(selectedQueryName,userDataObj.getUserSsoId());
			int deletedCount = 0;
			try {
				deletedCount = plmIssuesService
						.deleteQryNameByCheckboxSelection(selectedQueryName,
								PWiContext.getCurrentInstance().getUserSso());
			} catch (PWiException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			LOG.info("Deleetd : " + deletedCount);
			alertMsgTsk = "Selected Querie(s) have been deleted successfully";
			fwdFlag = displaySaveAndSearchQuries();
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR,
					"Exception@deleteQryNameByCheckboxSelection: ", exception);
			fwdFlag = PLMUtils
					.setCommonException(exception.getMessage(), commonMB,
							"taskMySavedSearchQueryReport", "My Task Queries");
		}
		LOG.info("Exiting deleteQryNameByCheckboxSelection() Method");
		return fwdFlag;
	}

	/**
	 * This method for getTaskReportByQueryName
	 * 
	 * @return String
	 */
	public String getTaskReportByQueryName() {
		LOG.info("Entering getTaskReportByQueryName() Method");
		String fwdFlag = "";
		 reportNameXls= "taskSearchReportExcel";
		 fileNameXls="Task Report";
		 final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
					"MM/dd/yyyy", Locale.ENGLISH);
		 Map<String,List<PLMTaskSearchData>> searchRsltMap = new HashMap<String, List<PLMTaskSearchData>>();
		try {
			List<PLMTaskSearchData> taskSearchSavedFields = plmIssuesService
					.getTaskSearchSavedFields(selectedQueryName);
			PLMTaskSearchData taskSearchSavedFieldValues = new PLMTaskSearchData();
			if (!PLMUtils.isEmptyList(taskSearchSavedFields)) {
				for (int i = 0; i < taskSearchSavedFields.size(); i++) {
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.TASK_NAME)) {
						taskSearchSavedFieldValues
								.setName(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.TASK_STATE_NAME)) {
						taskSearchSavedFieldValues.setTaskStateList(PLMUtils
								.convertStringToList(taskSearchSavedFields.get(
										i).getFieldVal()));
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.TASK_OWNER_SSO)) {
						taskSearchSavedFieldValues
								.setOwner(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.ORIGINATOR)) {
						taskSearchSavedFieldValues
								.setOrginator(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.TASK_RESPONSIBLITY)) {
						taskSearchSavedFieldValues
								.setTaskResponsiblity(taskSearchSavedFields
										.get(i).getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.PCT_COMPLETE)) {
						taskSearchSavedFieldValues
								.setPercentageComplete(taskSearchSavedFields
										.get(i).getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.STATUS)) {
						taskSearchSavedFieldValues
								.setStatus(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("ESTIMATED_FINISH_FROM_DATE")) {
						Date estimatedFinishFromDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setEstimatedFinishFromDate(estimatedFinishFromDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("ESTIMATED_FINISH_TO_DATE")) {
						Date estimatedFinishToDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setEstimatedFinishToDate(estimatedFinishToDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("ACTUAL_FINISH_FROM_DATE")) {
						Date actualFinishFromDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setActualFinishFromDate(actualFinishFromDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("ACTUAL_FINISH_TO_DATE")) {
						Date actualFinishToDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setActualFinishToDate(actualFinishToDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.TASK_APPROVAL)) {
						taskSearchSavedFieldValues
								.setTaskApproval(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					/*
					 * if(taskSearchSavedFields.get(i).getFieldNm().equals(
					 * PLMConstants.ASSOCIATED_TYPE)){
					 * taskSearchSavedFieldValues
					 * .setType(taskSearchSavedFields.get(i).getFieldVal()); }
					 */
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.VOUCHER_FUNDING_SOURCE)) {
						taskSearchSavedFieldValues
								.setVoucherfind(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.POLICY)) {
						taskSearchSavedFieldValues
								.setPolicy(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.PROJECT_NAME)) {
						taskSearchSavedFieldValues
								.setProjectName(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.PROJECT_DESCRIPTION)) {
						taskSearchSavedFieldValues
								.setProjectDesc(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.CONTRACT_NAME)) {
						taskSearchSavedFieldValues
								.setContractName(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.GE_ACTIVITY_CODE)) {
						taskSearchSavedFieldValues
								.setGeActivityCode(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.ASSIGNEES)) {
						taskSearchSavedFieldValues
								.setAssignee(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					// added by lakshmi
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.DELIVERABLES)) {
						taskSearchSavedFieldValues
								.setDeliverable(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.GE_TASK_RESPONSIBLE_UNIT)) {
						taskSearchSavedFieldValues
								.setTaskResponsiblityUnit(taskSearchSavedFields
										.get(i).getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.GE_MFGG_DELIVERABLE_INDR)) {
						taskSearchSavedFieldValues
								.setMfgIndicator(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("GE_CSTMR_NEED_FROM_DATE")) {
						Date customerFromDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setCustomerFromDate(customerFromDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("GE_CSTMR_NEED_TO_DATE")) {
						Date customerToDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setCustomerToDate(customerToDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("GE_MFGG_NEED_FROM_DATE")) {
						Date mfgFromDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues.setMfgFromDate(mfgFromDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("GE_MFGG_NEED_TO_DATE")) {
						Date mfgToDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues.setMfgToDate(mfgToDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.ASSOCIATED_NAME)) {
						taskSearchSavedFieldValues
								.setAssociatedName(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.DELIVERABLES_TYPE)) {
						taskSearchSavedFieldValues.setTaskAstdTypeList(PLMUtils
								.convertStringToList(taskSearchSavedFields.get(
										i).getFieldVal()));
					}

					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("EARLY_FINISH_FROM_DATE")) {
						Date earlyFnshFrmDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setEarlyFinishFromDate(earlyFnshFrmDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("EARLY_FINISH_TO_DATE")) {
						Date earlyFnshtoDt = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setEarlyFinishToDate(earlyFnshtoDt);
					}

					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("LATE_FINISH_FROM_DATE")) {
						Date lateFnshFrmDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setLateFinishFromDate(lateFnshFrmDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("LATE_FINISH_TO_DATE")) {
						Date lateFnshtoDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setLateFinishToDate(lateFnshtoDate);
					}

				}

			}
			if (!PLMUtils.isEmptyList(searchResultList)) {
				searchResultList.clear();
			}
			searchRsltMap = plmIssuesService.getTaskSearchData(
					taskSearchSavedFieldValues, "SEARCH");
			
			for (Map.Entry<String,List<PLMTaskSearchData>> searchEntry : searchRsltMap.entrySet()) {
				
				whereClauseQry = searchEntry.getKey();
				searchResultList = searchEntry.getValue();
			}
			
			if (!PLMUtils.isEmptyList(searchResultList)) {
				totalRecCount = searchResultList.size();
				recordCounts = PLMConstants.N_50;
				Map<String, List<SelectItem>> dropdownStateTypeMap = plmIssuesService
						.getTaskDropDownValues();
				stateList = ((List<SelectItem>) dropdownStateTypeMap
						.get("taskstate"));
				associatedTypeList = ((List<SelectItem>) dropdownStateTypeMap
						.get("taskAssociatedType"));
				setPlmSearchData(taskSearchSavedFieldValues);
				plmSearchData.setSeqID(selectedQueryName);
				plmSearchData.setQueryName(selectedQueryText);
				modifyQueryFlag = true;
				fwdFlag = "taskSearchReport";
				totalRecCountMsg = "Total Results Count : " + totalRecCount;
				LOG.info("Total Results Count : " + totalRecCount);
			} else {
				LOG.info("No records");
				fwdFlag = "noRecordByQryName";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getTaskReportByQueryName",
					exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "home", "My Task Queries");
		} catch (ParseException e) {
			LOG.log(Level.ERROR, "Exception@getTaskReportByQueryName", e);
			fwdFlag = PLMUtils.setCommonException(e.getMessage(), commonMB,
					"home", "My Task Queries");
		}
		LOG.info("Exiting getTaskReportByQueryName() Method");
		page = "taskmysavesearch";
		return fwdFlag;
	}

	/**
	 * This method is for reset()
	 * 
	 * @return String
	 */
	public String reset() {

		plmSearchData.setName(PLMConstants.EMPTY);
		plmSearchData.setOwner(PLMConstants.EMPTY);
		plmSearchData.setTaskStateList(null);
		plmSearchData.setAssignee(PLMConstants.EMPTY);
		plmSearchData.setPercentageComplete(PLMConstants.EMPTY);
		plmSearchData.setOrginator(PLMConstants.EMPTY);
		plmSearchData.setEstimatedFinishFromDate(null);
		plmSearchData.setEstimatedFinishToDate(null);
		plmSearchData.setActualFinishFromDate(null);
		plmSearchData.setActualFinishToDate(null);
		plmSearchData.setStatus(PLMConstants.EMPTY);
		plmSearchData.setTaskApproval(PLMConstants.EMPTY);
		plmSearchData.setTaskResponsiblity(PLMConstants.EMPTY);
		plmSearchData.setType(PLMConstants.EMPTY);
		plmSearchData.setVoucherfind(PLMConstants.EMPTY);
		plmSearchData.setPolicy(PLMConstants.EMPTY);
		plmSearchData.setProjectName(PLMConstants.EMPTY);
		plmSearchData.setProjectDesc(PLMConstants.EMPTY);
		plmSearchData.setContractName(PLMConstants.EMPTY);
		plmSearchData.setGeActivityCode(PLMConstants.EMPTY);
		plmSearchData.setAllOpen(false);
		plmSearchData.setMfgIndicator(PLMConstants.EMPTY);
		plmSearchData.setDeliverable(PLMConstants.EMPTY);
		plmSearchData.setTaskResponsiblityUnit(PLMConstants.EMPTY);
		plmSearchData.setMfgFromDate(null);
		plmSearchData.setMfgToDate(null);
		plmSearchData.setCustomerFromDate(null);
		plmSearchData.setCustomerToDate(null);
		plmSearchData.setTaskAstdTypeList(null);
		plmSearchData.setAssociatedName(PLMConstants.EMPTY);
		plmSearchData.setEarlyFinishFromDate(null);
		plmSearchData.setEarlyFinishToDate(null);
		plmSearchData.setLateFinishFromDate(null);
		plmSearchData.setLateFinishToDate(null);

		return "taskSearchHome";
	}

	// Retrieving Task Data based on Selecting Task Names

	/**
	 * This method is used for getTaskDetailedReport
	 * 
	 * @return String
	 */
	public String getTaskDetailedReport() {
		LOG.info("Getting in to Report page>>");
		String fwdFlag = PLMConstants.EMPTY;
		try {
			if (!PLMUtils.isEmptyList(searchReportList)) {
				searchReportList.clear();
			}
			searchReportList = plmIssuesService.getTaskDetailedRptDeliverable(
					plmSearchData, selectedTaskDt);
			if (searchReportList != null) {
				ntotalRecCount = searchReportList.size();
			} else {
				ntotalRecCount = 0;
			}
			ntotalRecCountMsg = "Total Results Count : " + ntotalRecCount;
			LOG.info("ntotalRecCount::::::::::::::::::" + ntotalRecCount);
			if (ntotalRecCount == 0) {

				fwdFlag = "taskSearchReport";
			} else {
				 reportNameXls= "taskDetailReport";
				 fileNameXls="Task Detail Report";
				nrecordCounts = PLMConstants.N_50;
				fwdFlag = "taskSearchDetails";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getTaskDetailedReport: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "taskSearchReport", "Task Search");
		}
		return fwdFlag;
	}

	/**
	 * This method is used for getTaskDetailDiscussionRpt
	 * 
	 * @return String
	 */
	public String getTaskDetailDiscussionRpt() {
		LOG.info("Entering getTaskDetailDiscussionRpt method");
		String fwdFlag = PLMConstants.EMPTY;
		try {
			if (!PLMUtils.isEmptyList(discussionRptList)) {
				discussionRptList.clear();
			}
			discussionRptList = plmIssuesService
					.getTaskDetailDiscussionRpt(selectedTask);
			if (discussionRptList != null) {
				totalRecCountForDiscussioRpt = discussionRptList.size();
			} else {
				totalRecCountForDiscussioRpt = 0;
			}
			totalRecCountMsgForDiscussioRpt = "Total Results Count : "
					+ totalRecCountForDiscussioRpt;
			LOG.info("totalRecCountForDiscussioRpt::::::::::::::::::"
					+ totalRecCountForDiscussioRpt);
			if (totalRecCountForDiscussioRpt == 0) {
				fwdFlag = "taskDiscussionError";
			} else {
				recordCountsForDiscussioRpt = PLMConstants.N_50;
				 reportNameXls= "taskDiscussionRptExl";
				 fileNameXls="Task Discussion Report";
				 fwdFlag = "taskDiscussionRpt";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getTaskDetailDiscussionRpt: ",
					exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "taskSearchReport", "Task Search");
		}
		LOG.info("Exiting getTaskDetailDiscussionRpt method");
		return fwdFlag;
	}
	
	public void getAllTaskDetailDiscussionRpt() throws PWiException {

			alertMessage = PLMConstants.TASK_DISCUS_MAIL_ALERT_MSG;
			userName = UserInfoPortalUtil.getInstance().getUserName();
			userEmail = UserInfoPortalUtil.getInstance().getUserEmail();
			taskExecutor.execute(new AllTaskDetailDiscussionEmailThread());
			//return  "taskSearchReport";

	}
	/**
	 * Background Process Thread
	 */
	private class AllTaskDetailDiscussionEmailThread implements Runnable {

		public AllTaskDetailDiscussionEmailThread() {

		}

		public void run() {

			try {
				getAllTaskDetailDiscussionMailRpt();
			} catch (Exception exception) {
				LOG.log(Level.ERROR, "Exception@run() of AllTaskDetailDiscussionEmailThread: ", exception);
			}
		}
	}
	
	
	
	/**
	 * This method is used for get all TaskDetailDiscussionRpt
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public void getAllTaskDetailDiscussionMailRpt() throws PWiException {
		LOG.info("Entering getTaskDetailDiscussionRpt method");
		String from = PLMConstants.LTTR_MAIL_FROM;
		String to = userEmail;//userDetails.getUserEmailId();		
		String toAddressee = userName;
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.TASK_DISCUS_MAIL_SUBJECT ;//+ mlNo;
		StringBuffer mailBody = new StringBuffer().append(toAddressee)
		.append(PLMConstants.TASK_DISCUS_MAIL_CONTENT)
		.append(PLMConstants.TASK_DISCUS_MAIL_SIGNATURE)
		.append(PLMConstants.TASK_DISCUS_MAIL_FOOTER);
		
		//String mailContent = toAddressee + PLMConstants.LTTR_MAIL_CONTENT + mlNo + "." + PLMConstants.LTTR_MAIL_SIGNATURE;
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + "Task Discussion Report" + "_" + uniqTime + ".xlsx";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + "Task Discussion Report"  + "_" + uniqTime + ".zip";
		
		try {
			if (!PLMUtils.isEmptyList(discussionRptList)) {
				discussionRptList.clear();
			}
			discussionRptList = plmIssuesService
					.getTaskDetailAllDiscussionRpt(whereClauseQry);
			saveTaskAllDiscussionXLSXFile(discussionRptList,fileDir,filePathXls);
			PLMUtils.generateZipFile(filePathXls,filePathZip);
			PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getAllTaskDetailDiscussionRpt: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.TASK_DISCUS_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@getAllTaskDetailDiscussionRpt: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.TASK_DISCUS_MAIL_SIGNATURE);
		} finally {
			deleteFiles(filePathXls,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendLttrReportThroughMail Method");
		
	}
	public void deleteFiles(String filePathXls,String filePathZip){
		LOG.info("Entering deleteFiles method");
		boolean zipFileExist;
		boolean xlsFileExist;
		File zipFile = new File(filePathZip);
		zipFileExist = zipFile.exists();
		File xlsFile = new File(filePathXls);
		xlsFileExist = xlsFile.exists();
		if(zipFileExist){
			boolean deleted = zipFile.delete();
			LOG.info("Successfully deleted zip file : " + deleted);
		}
		if(xlsFileExist){
			boolean deleted = xlsFile.delete();
			LOG.info("Successfully deleted xls file : " + deleted);
		}
		LOG.info("Exiting deleteFiles Method");
	}
		
		public void saveTaskAllDiscussionXLSXFile(List<PLMTaskSearchData>	discussionRptListExcl,
				String fileDir,String filePathXlsx) throws IOException {
			LOG.info("Entering saveTaskAllDiscussionXLSXFile File Method");
			FileOutputStream fileOut = null;
			boolean createFileExist;
			
			LOG.info("Entering downloadExcel Method");
			
			String reportName="taskDiscussionRptExl";
			String fileName="Task Discussion Report";
			LOG.info("reportName>>> " +reportName);
			LOG.info("fileName>>> " +fileName);
			
			PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
			try {
				

				
				PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
	                    new PLMXlsxRptColumn("projectName", "Project Name", FormatType.TEXT, null, null, 27),
	                    new PLMXlsxRptColumn("geActivityCode", "GE Activity NM", FormatType.TEXT, null, null, 15),
	                    new PLMXlsxRptColumn("respPrsnNM", "Resp Prsn NM", FormatType.TEXT, null, null, 15),
	                    new PLMXlsxRptColumn("respUnitCode", "Resp Unit Code", FormatType.TEXT, null, null, 10),
	                    new PLMXlsxRptColumn("lateFinish", "Late Finish", FormatType.DATEFORMT, null, null, 15),
	                    new PLMXlsxRptColumn("name", "Task Name", FormatType.TEXT, null, null, 10),
	                    new PLMXlsxRptColumn("description", "Description", FormatType.TEXT, null, null, 30),
	                    new PLMXlsxRptColumn("discussion", "Discussions", FormatType.TEXT, null, null, 50),
	                    new PLMXlsxRptColumn("dateEnteredExl", "Date Entered", FormatType.DATEFRMTTM, null, null, 20),
	                    new PLMXlsxRptColumn("enteredByUsrNM", "Entered by User NM", FormatType.TEXT, null, null, 15),
	                    new PLMXlsxRptColumn("custNM", "Customer Name", FormatType.TEXT, null, null, 25),
	                    new PLMXlsxRptColumn("custNeedDate", "Customer Need Date", FormatType.DATEFORMT, null, null, 15),
	                    new PLMXlsxRptColumn("actualFinish", "Actual Finish Date", FormatType.DATEFORMT, null, null, 15),
	                    new PLMXlsxRptColumn("ecrNo", "ECR #", FormatType.TEXT, null, null, 15),
	                    new PLMXlsxRptColumn("ecoNo", "ECO #", FormatType.TEXT, null, null, 15),
	                    new PLMXlsxRptColumn("model", "Model", FormatType.TEXT, null, null, 15)
				};
				
				
				PLMXlsxRptColumn[] critcolumns  = new PLMXlsxRptColumn[] {
		                new PLMXlsxRptColumn("name", "Task Name", FormatType.TEXT),
		                new PLMXlsxRptColumn("state", "State", FormatType.TEXT),
		                new PLMXlsxRptColumn("owner", "Owner", FormatType.TEXT),
		                new PLMXlsxRptColumn("orginator", "Originator", FormatType.TEXT),
		                new PLMXlsxRptColumn("taskResponsiblity", "Task Responsibility", FormatType.TEXT),
		                new PLMXlsxRptColumn("percentageComplete", "Percentate Complete", FormatType.TEXT),
		                new PLMXlsxRptColumn("status", "Status", FormatType.TEXT),
		                new PLMXlsxRptColumn("estimateFnshFromDtExl", "Estimated Finish(From Date)", FormatType.TEXT),
		                new PLMXlsxRptColumn("estimateFnshToDtExl", "Estimated Finish(To Date)", FormatType.TEXT),
		                new PLMXlsxRptColumn("taskApproval", "Task Approval", FormatType.TEXT),
		                new PLMXlsxRptColumn("actualFnshFromDtExl", "Actual Finish(From Date)", FormatType.TEXT),
		                new PLMXlsxRptColumn("actualFnshToDtExl", "Actual Finish(To Date)", FormatType.TEXT),
		                new PLMXlsxRptColumn("associatedExcel", "Deliverable Type", FormatType.TEXT),
		                new PLMXlsxRptColumn("voucherfind", "Vocher Funding Source", FormatType.TEXT),
		                new PLMXlsxRptColumn("policy", "Policy", FormatType.TEXT),
		                new PLMXlsxRptColumn("projectName", "Project Name", FormatType.TEXT),
		                new PLMXlsxRptColumn("projectDesc", "Project Description", FormatType.TEXT),
		                new PLMXlsxRptColumn("contractName", "Contract Name", FormatType.TEXT),
		                new PLMXlsxRptColumn("taskName", "Activity Name", FormatType.TEXT),
		                new PLMXlsxRptColumn("assignee", "Assignee", FormatType.TEXT),
		                new PLMXlsxRptColumn("mfgNeedFromDtExl", "Mfg. Need(From Date)", FormatType.TEXT),
		                new PLMXlsxRptColumn("mfgNeedTotExl", "Mfg. Need(To Date)", FormatType.TEXT),
		                new PLMXlsxRptColumn("custNeedFromDtExl", "Customer Need(From Date)", FormatType.TEXT),
		                new PLMXlsxRptColumn("custNeedToDtExl", "Customer Need(To Date)", FormatType.TEXT),
		                new PLMXlsxRptColumn("mfgIndicator", "Mfg.Indicator", FormatType.TEXT),
		                new PLMXlsxRptColumn("taskResponsiblityUnit", "Resp.Unit", FormatType.TEXT),
		                new PLMXlsxRptColumn("deliverable", "Deliverable", FormatType.TEXT),
		                new PLMXlsxRptColumn("earlyFnshFromDtExl", "Early Finish(From Date)", FormatType.TEXT),
		                new PLMXlsxRptColumn("earlyFnshToDtExl", "Early Finish(To Date)", FormatType.TEXT),
		                new PLMXlsxRptColumn("lateFnshFromDtExl", "Late Finish(From Date)", FormatType.TEXT),
		                new PLMXlsxRptColumn("lateFnshToDtExl", "Late Finish(To Date)", FormatType.TEXT)
		
				};
				
				excelUtil.generateXlSX(discussionRptList, reportColumns, fileName, fileName, true, critcolumns, plmSearchData,fileDir,filePathXlsx);
				
			
				
			} catch (Exception e) {
				LOG.log(Level.ERROR, "Exception@saveTaskAllDiscussionXLSXFile File: ", e);
			}  finally {
				try {
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@saveTaskAllDiscussionXLSXFile: ", e);
					throw e;
				}
			}
			LOG.info("Exiting saveTaskAllDiscussionXLSXFile File Method");
		}
		
	/**
	 * This method is used for getTaskVolumeDetailReport
	 * 
	 * @param tasknameslist
	 *            ,taskMetricData
	 * @return String
	 */
	public String getTaskVolumeDetailReport(List<String> tasknameslist,
			PLMTaskMetricsData taskMetricData) {
		String fwdFlag = PLMConstants.EMPTY;
		try {
			if (!PLMUtils.isEmptyList(searchReportList)) {
				searchReportList.clear();
			}
			searchReportList = plmIssuesService.getTaskVolumeDetailReport(
					tasknameslist, taskMetricData);
			if (searchReportList != null) {
				ntotalRecCount = searchReportList.size();
			} else {
				ntotalRecCount = 0;
			}
			ntotalRecCountMsg = "Total Results Count : " + ntotalRecCount;
			LOG.info("ntotalRecCount::::::::::::::::::" + ntotalRecCount);
			if (ntotalRecCount == 0) {
				fwdFlag = "taskInvalidSearch";
			} else {
				nrecordCounts = PLMConstants.N_50;
				fwdFlag = "taskSearchDetails";
				reportNameXls= "taskVolumeReport";
				fileNameXls="Task Detail Report";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getTaskVolumeDetailReport: ",
					exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "taskVolumeReport", "Task Volume");
		}
		return fwdFlag;
	}

	/**
	 * This method is used for getProjectTaskDetailReport
	 * 
	 * @param searchResultsQuery
	 * @return String
	 */
	public String getProjectTaskDetailReport(StringBuffer searchResultsQuery)
			throws PLMCommonException {
		String fwdFlag = PLMConstants.EMPTY;
		try {
			if (!PLMUtils.isEmptyList(searchReportList)) {
				searchReportList.clear();
			}
			searchReportList = plmIssuesService
					.getProjectTaskDetailReport(searchResultsQuery);
			if (searchReportList != null) {
				ntotalRecCount = searchReportList.size();
			} else {
				ntotalRecCount = 0;
			}
			ntotalRecCountMsg = "Total Results Count : " + ntotalRecCount;
			LOG.info("ntotalRecCount::::::::::::::::::" + ntotalRecCount);
			if (ntotalRecCount == 0) {
				fwdFlag = "taskInvalidSearch";
			} else {
				 reportNameXls= "taskVolumeReport";
				 fileNameXls="Task Detail Report";
				nrecordCounts = PLMConstants.N_50;
				fwdFlag = "taskSearchDetails";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getProjectTaskDetailReport: ",
					exception);
			throw exception;
		}
		return fwdFlag;
	}

	/**
	 * This method is used for fetchTaskSearchDetails
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String fetchTaskSearchDetails() throws PLMCommonException {
		LOG.info("Entering fetchTaskSearchDetails method");
		String fwdFlag = "taskSearchHome";
		Map<String, List<SelectItem>> dropdownTasklistMap = plmIssuesService
				.getTaskDropDownValues();
		stateList = ((List<SelectItem>) dropdownTasklistMap.get("taskstate"));
		associatedTypeList = ((List<SelectItem>) dropdownTasklistMap
				.get("taskAssociatedType"));
		modifyQueryFlag = false;
		final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
					"MM/dd/yyyy", Locale.ENGLISH);
		try {
			List<PLMTaskSearchData> taskSearchSavedFields = plmIssuesService
					.fetchTaskSearchDetails(selectedQueryName);
			PLMTaskSearchData taskSearchSavedFieldValues = new PLMTaskSearchData();
			if (!PLMUtils.isEmptyList(taskSearchSavedFields)) {
				for (int i = 0; i < taskSearchSavedFields.size(); i++) {
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.TASK_NAME)) {
						taskSearchSavedFieldValues
								.setName(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.TASK_STATE_NAME)) {
						taskSearchSavedFieldValues.setTaskStateList(PLMUtils
								.convertStringToList(taskSearchSavedFields.get(
										i).getFieldVal()));
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.TASK_OWNER_SSO)) {
						taskSearchSavedFieldValues
								.setOwner(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.ORIGINATOR)) {
						taskSearchSavedFieldValues
								.setOrginator(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.TASK_RESPONSIBLITY)) {
						taskSearchSavedFieldValues
								.setTaskResponsiblity(taskSearchSavedFields
										.get(i).getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.PCT_COMPLETE)) {
						taskSearchSavedFieldValues
								.setPercentageComplete(taskSearchSavedFields
										.get(i).getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.STATUS)) {
						taskSearchSavedFieldValues
								.setStatus(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("ESTIMATED_FINISH_FROM_DATE")) {
						Date estimatedFinishFromDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setEstimatedFinishFromDate(estimatedFinishFromDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("ESTIMATED_FINISH_TO_DATE")) {
						Date estimatedFinishToDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setEstimatedFinishToDate(estimatedFinishToDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("ACTUAL_FINISH_FROM_DATE")) {
						Date actualFinishFromDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setActualFinishFromDate(actualFinishFromDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("ACTUAL_FINISH_TO_DATE")) {
						Date actualFinishToDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setActualFinishToDate(actualFinishToDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.TASK_APPROVAL)) {
						taskSearchSavedFieldValues
								.setTaskApproval(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.VOUCHER_FUNDING_SOURCE)) {
						taskSearchSavedFieldValues
								.setVoucherfind(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.POLICY)) {
						taskSearchSavedFieldValues
								.setPolicy(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.PROJECT_NAME)) {
						taskSearchSavedFieldValues
								.setProjectName(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.PROJECT_DESCRIPTION)) {
						taskSearchSavedFieldValues
								.setProjectDesc(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.CONTRACT_NAME)) {
						taskSearchSavedFieldValues
								.setContractName(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.GE_ACTIVITY_CODE)) {
						taskSearchSavedFieldValues
								.setGeActivityCode(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.ASSIGNEES)) {
						taskSearchSavedFieldValues
								.setAssignee(taskSearchSavedFields.get(i)
										.getFieldVal());
					}

					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.DELIVERABLES)) {
						taskSearchSavedFieldValues
								.setDeliverable(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.GE_TASK_RESPONSIBLE_UNIT)) {
						taskSearchSavedFieldValues
								.setTaskResponsiblityUnit(taskSearchSavedFields
										.get(i).getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.GE_MFGG_DELIVERABLE_INDR)) {
						taskSearchSavedFieldValues
								.setMfgIndicator(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("GE_CSTMR_NEED_FROM_DATE")) {
						Date customerFromDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setCustomerFromDate(customerFromDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("GE_CSTMR_NEED_TO_DATE")) {
						Date customerToDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setCustomerToDate(customerToDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("GE_MFGG_NEED_FROM_DATE")) {
						Date mfgFromDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues.setMfgFromDate(mfgFromDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("GE_MFGG_NEED_TO_DATE")) {
						Date mfgToDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues.setMfgToDate(mfgToDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.ASSOCIATED_NAME)) {
						taskSearchSavedFieldValues
								.setAssociatedName(taskSearchSavedFields.get(i)
										.getFieldVal());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals(PLMConstants.DELIVERABLES_TYPE)) {
						taskSearchSavedFieldValues.setTaskAstdTypeList(PLMUtils
								.convertStringToList(taskSearchSavedFields.get(
										i).getFieldVal()));
					}
					if (taskSearchSavedFields.get(i).getQueryName() != null) {
						taskSearchSavedFieldValues
								.setQueryName(taskSearchSavedFields.get(i)
										.getQueryName());
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("EARLY_FINISH_FROM_DATE")) {
						Date earlyFinishFromDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setEarlyFinishFromDate(earlyFinishFromDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("EARLY_FINISH_TO_DATE")) {
						Date earlyFinishToDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setEarlyFinishToDate(earlyFinishToDate);
					}

					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("LATE_FINISH_FROM_DATE")) {
						Date lateFinishFromDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setLateFinishFromDate(lateFinishFromDate);
					}
					if (taskSearchSavedFields.get(i).getFieldNm()
							.equals("LATE_FINISH_TO_DATE")) {
						Date lateFinishToDate = (Date) SIMPLE_DATE_FORMAT
								.parse(taskSearchSavedFields.get(i)
										.getFieldVal());
						taskSearchSavedFieldValues
								.setLateFinishToDate(lateFinishToDate);
					}

				}
				taskSearchSavedFieldValues.setSeqID(selectedQueryName); // SeqID
				setPlmSearchData(taskSearchSavedFieldValues); // data in page
				/*
				 * LOG.info("getPlmSearchData().setSeqID(selectedQueryName);"+
				 * getPlmSearchData().getSeqID());
				 * LOG.info("plmSearchData.getSeqID()"
				 * +plmSearchData.getSeqID());
				 * LOG.info("plmSearchData.getQueryName();"
				 * +plmSearchData.getQueryName());
				 */

				modifyQueryFlag = true; // added to disable query name change

			}

		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@fetchTaskSearchDetails", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "home", "My Task Queries");
		} catch (ParseException e) {
			LOG.log(Level.ERROR, "Exception@fetchTaskSearchDetails", e);
			fwdFlag = PLMUtils.setCommonException(e.getMessage(), commonMB,
					"home", "My Task Queries");
		}
		LOG.info("Exiting fetchTaskSearchDetails() Method");

		return fwdFlag;
	}

	//Newly Added for downlaod Excel sheet for each report
	/**
	 * This method is used for download Excel sheet for each report
	 * 
	 * @return String
	 */
	public void downloadExcel() throws PLMCommonException {

		LOG.info("Entering downloadExcel Method");
		String reportName=reportNameXls;
		String fileName=fileNameXls;
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		//Export to Excel for Task Search Report Header Page
		if(reportNameXls.equals("taskSearchReportExcel")){
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("name", "Task Name", FormatType.TEXT, null, null, 27),
                    new PLMXlsxRptColumn("projectName", "Project Name", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("projectDesc", "Project Description", FormatType.TEXT, null, null, 40),
                    new PLMXlsxRptColumn("contractName", "Contract Name", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("taskName", "Activity Name", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("title", "Task Title", FormatType.TEXT, null, null, 35),
                    new PLMXlsxRptColumn("state", "State", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("estimatedStart", "Est. Start", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("estimatedFinish", "Est. Finish", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("geEarlyFinishDate", "Early Finish Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("geLateFinishDate", "Late Finish Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("geTotalFloat", "Float", FormatType.TEXT, null, null, 8),
                    new PLMXlsxRptColumn("requiredHours", "Required Hours", FormatType.TEXT, null, null, 9),
                    new PLMXlsxRptColumn("estimatedDuration", "Est. Dur.", FormatType.TEXT, null, null, 8),
                    new PLMXlsxRptColumn("actualStart", "Act. Start", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("actualFinish", "Act. Finish", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("actualHours", "Act. Hours", FormatType.TEXT, null, null, 8),
                    new PLMXlsxRptColumn("duration", "Act. Dur.", FormatType.TEXT, null, null, 8),
                    //new PLMXlsxRptColumn("status", "Status", FormatType.TEXT, null, null, 10),
                   // new PLMXlsxRptColumn("percentageComplete", "% Cmpl.", FormatType.TEXT, null, null, 8),
                    new PLMXlsxRptColumn("taskResponsiblity", "Resp. SSO", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("taskResponsiblityName", "Resp. Name", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("assignee", "Assgn. SSO", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("assigneeName", "Assgn. Name", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("owner", "Owner SSO", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("ownerName", "Owner Name", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("orginator", "Orig. SSO", FormatType.TEXT, null, null, 10),
                  //  new PLMXlsxRptColumn("orginatorName", "Orig. Name", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("taskApproval", "Task Approval", FormatType.TEXT, null, null, 10),
                   // new PLMXlsxRptColumn("note", "Notes", FormatType.TEXT, null, null, 20),
                    //new PLMXlsxRptColumn("taskReq", "Task Requirements", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("synopsis", "Synopsis", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("projectrole", "Project Role", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("taskResponsiblityUnit", "Responsible Unit", FormatType.TEXT, null, null, 12),
                    new PLMXlsxRptColumn("deliverable", "Deliverable", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("type", "Deliverable Type", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("mfgIndicator", "Mfg. Indicator", FormatType.TEXT, null, null, 9),
                    new PLMXlsxRptColumn("mfgFinish", "Mfg. Need Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("customerFinish", "Customer Need Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("creationDate", "Creation Date", FormatType.DATE, null, null, 12),
                    new PLMXlsxRptColumn("actionTaken", "Action Taken", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("expctdFinishDt", "Expected Finish Date", FormatType.DATE, null, null, 20),
                    new PLMXlsxRptColumn("lateStrtDt", "Late start Date", FormatType.DATE, null, null, 9),
                    new PLMXlsxRptColumn("pendingEffort", "Pending Effort", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("totalEffort", "Total Effort", FormatType.TEXT, null, null, 10),  
                    new PLMXlsxRptColumn("gePalnnedEffort", "GE Planned Effort", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("geRemainingHr", "GE Remaining Hour", FormatType.TEXT, null, null, 10)
			};
			
			
			PLMXlsxRptColumn[] critcolumns  = new PLMXlsxRptColumn[] {
	                new PLMXlsxRptColumn("name", "Task Name", FormatType.TEXT),
	                new PLMXlsxRptColumn("stateExcel", "State", FormatType.TEXT),
	                new PLMXlsxRptColumn("owner", "Owner", FormatType.TEXT),
	              //  new PLMXlsxRptColumn("orginator", "Originator", FormatType.TEXT),
	                new PLMXlsxRptColumn("taskResponsiblity", "Task Responsibility", FormatType.TEXT),
	                //new PLMXlsxRptColumn("percentageComplete", "Percentate Complete", FormatType.TEXT),
	               // new PLMXlsxRptColumn("status", "Status", FormatType.TEXT),
	                new PLMXlsxRptColumn("estimateFnshFromDtExl", "Estimated Finish(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("estimateFnshToDtExl", "Estimated Finish(To Date)", FormatType.TEXT),
	                //new PLMXlsxRptColumn("taskApproval", "Task Approval", FormatType.TEXT),
	                new PLMXlsxRptColumn("actualFnshFromDtExl", "Actual Finish(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("actualFnshToDtExl", "Actual Finish(To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("voucherfind", "Voucher Funding Source", FormatType.TEXT),
	                new PLMXlsxRptColumn("policy", "Policy", FormatType.TEXT),
	                new PLMXlsxRptColumn("projectName", "Project Name", FormatType.TEXT),
	                new PLMXlsxRptColumn("projectDesc", "Project Description", FormatType.TEXT),
	                new PLMXlsxRptColumn("contractName", "Contract Name", FormatType.TEXT),
	                new PLMXlsxRptColumn("taskName", "Activity Name", FormatType.TEXT),
	                new PLMXlsxRptColumn("assignee", "Assignee", FormatType.TEXT),
	                new PLMXlsxRptColumn("mfgNeedFromDtExl", "Mfg. Need(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("mfgNeedTotExl", "Mfg. Need(To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("custNeedFromDtExl", "Customer Need(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("custNeedToDtExl", "Customer Need(To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("mfgIndicator", "Mfg.Indicator", FormatType.TEXT),
	                new PLMXlsxRptColumn("taskResponsiblityUnit", "Resp.Unit", FormatType.TEXT),
	                new PLMXlsxRptColumn("deliverable", "Deliverable", FormatType.TEXT),
	                new PLMXlsxRptColumn("earlyFnshFromDtExl", "Early Finish(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("earlyFnshToDtExl", "Early Finish(To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("lateFnshFromDtExl", "Late Finish(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("lateFnshToDtExl", "Late Finish(To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("creationFromDateXl", "Creation (From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("creationToDateXl", "Creation (To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("expctdFinishFromDtXl", "Expected Finish(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("expctdFinishToDtXl", "Expected Finish(To Date)", FormatType.TEXT)
			                
			};
			
			excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, plmSearchData);	
		}
		
		//Export to Excel for Task Search Report Predecessor Successor Report
		if(reportNameXls.equals("taskSearchPredSucc")){
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("projectName", "Project Name", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("taskName", "Task Name", FormatType.TEXT, null, null, 11),
                    new PLMXlsxRptColumn("predSuccName", "Pred / Succ", FormatType.TEXT, null, null, 7),
                    new PLMXlsxRptColumn("dependencyType", "Con Type", FormatType.TEXT, null, null, 7),
                    new PLMXlsxRptColumn("delay", "Delay", FormatType.TEXT, null, null, 6),
                    new PLMXlsxRptColumn("taskTitle", "Task Title", FormatType.TEXT, null, null, 35),
                    new PLMXlsxRptColumn("taskName", "Activity Name", FormatType.TEXT, null, null, 11),
                    new PLMXlsxRptColumn("policy", "Policy", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("deliverable", "Deliverables", FormatType.TEXT, null, null, 18),
                    new PLMXlsxRptColumn("state", "State", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("estimatedStart", "Est. Start", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("estimatedFinish", "Est. Finish", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("requiredHours", "Required Hours", FormatType.TEXT, null, null, 9),
                    new PLMXlsxRptColumn("estimatedDuration", "Est. Dur.", FormatType.TEXT, null, null, 8),
                    new PLMXlsxRptColumn("actualStart", "Act. Start", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("actualFinish", "Act. Finish", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("actualHours", "Act. Hours", FormatType.TEXT, null, null, 8),
                   // new PLMXlsxRptColumn("status", "Status", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("percentageComplete", "% Cmpl.", FormatType.TEXT, null, null, 8),
                    new PLMXlsxRptColumn("respSso", "Resp. SSO", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("respPrsnNM", "Resp. Name", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("voucherfind", "Voucher Funding Source", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("owner", "Owner SSO", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("ownerName", "Owner Name", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("orignator", "Orig.SSO", FormatType.TEXT, null, null, 10),
                   // new PLMXlsxRptColumn("orignatorName", "Orig.Name", FormatType.TEXT, null, null, 15),
                  //  new PLMXlsxRptColumn("taskApproval", "Task Approval", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("note", "Notes", FormatType.TEXT, null, null, 25),
                    new PLMXlsxRptColumn("taskReq", "Task Requirements", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("synopsis", "Synopsis", FormatType.TEXT, null, null, 25),
                   // new PLMXlsxRptColumn("projectrole", "Project Role", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("action", "Action", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("approveStatus", "Approve Status", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("geTaskResponsibleUnit", "Resp. Unit", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("geMfggDeliverableIndr", "Mfg. Indicator", FormatType.TEXT, null, null, 9),
                    new PLMXlsxRptColumn("geMfggNeedDate", "Mfg. Need Date", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("geCstmrNeedDate", "Customer Need Date", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("creationDate", "Creation Date", FormatType.DATE, null, null, 12),
                    new PLMXlsxRptColumn("actionTaken", "Action Taken", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("expctdFinishDt", "Expected Finish Date", FormatType.DATE, null, null, 20),
                    new PLMXlsxRptColumn("lateStrtDt", "Late start Date", FormatType.DATE, null, null, 9),
                    new PLMXlsxRptColumn("pendingEffort", "Pending Effort", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("totalEffort", "Total Effort", FormatType.TEXT, null, null, 10),  
                    new PLMXlsxRptColumn("gePalnnedEffort", "GE Planned Effort", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("geRemainingHr", "GE Remaining Hour", FormatType.TEXT, null, null, 10)
                     		
			};
			
			excelUtil.export(precedorList, reportColumns, fileName, fileName, false, null, null);
		}

		//Export to Excel for Task Search Report Details Page
		if(reportNameXls.equals("taskDetailReport")){
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("projectName", "Project Name", FormatType.TEXT, null, null, 27),
                    new PLMXlsxRptColumn("projectDesc", "Project Description", FormatType.TEXT, null, null, 35),
                    new PLMXlsxRptColumn("contractName", "Contract Name", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("taskName", "Activity Name", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("title", "Task Title", FormatType.TEXT, null, null, 30),
                    new PLMXlsxRptColumn("desc", "Task Description", FormatType.TEXT, null, null, 35),
                    new PLMXlsxRptColumn("name", "Route/Task Name", FormatType.TEXT, null, null, 12),
                    new PLMXlsxRptColumn("policy", "Policy", FormatType.TEXT, null, null, 12),
                    new PLMXlsxRptColumn("deliverable", "Deliverables", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("state", "State", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("estimatedStart", "Est. Start", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("estimatedFinish", "Est. Finish", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("geEarlyFinishDate", "Early Finish Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("geLateFinishDate", "Late Finish Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("geTotalFloat", "Float", FormatType.TEXT, null, null, 6),
                    new PLMXlsxRptColumn("requiredHours", "Required Hours", FormatType.TEXT, null, null, 9),
                    new PLMXlsxRptColumn("estimatedDuration", "Est. Dur.", FormatType.TEXT, null, null, 8),
                    new PLMXlsxRptColumn("actualStart", "Act. Start", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("actualFinish", "Act. Finish", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("actualHours", "Act. Hours", FormatType.TEXT, null, null, 8),
                    new PLMXlsxRptColumn("duration", "Act. Dur.", FormatType.TEXT, null, null, 8),
                   // new PLMXlsxRptColumn("status", "Status", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("percentageComplete", "% Cmpl.", FormatType.TEXT, null, null, 8),
                    new PLMXlsxRptColumn("taskResponsiblity", "Resp. SSO", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("taskResponsiblityName", "Resp. Name", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("assignee", "Assgn. SSO", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("assigneeName", "Assgn. Name", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("findSource", "Voucher Funding Source", FormatType.TEXT, null, null, 25),
                    new PLMXlsxRptColumn("owner", "Owner SSO", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("ownerName", "Owner Name", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("orginator", "Orig. SSO", FormatType.TEXT, null, null, 10),
                   // new PLMXlsxRptColumn("orginatorName", "Orig. Name", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("taskApproval", "Task Approval", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("note", "Notes", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("taskReq", "Task Requirements", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("synopsis", "Synopsis", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("projectrole", "Project Role", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("action", "Action", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("approveStatus", "Approve Status", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("taskResponsiblityUnit", "Responsible Unit", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("mfgIndicator", "Mfg. Indicator", FormatType.TEXT, null, null, 9),
                    new PLMXlsxRptColumn("mfgFinish", "Mfg. Need Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("customerFinish", "Customer Need Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("creationDate", "Creation Date", FormatType.DATE, null, null, 12),
                    new PLMXlsxRptColumn("actionTaken", "Action Taken", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("expctdFinishDt", "Expected Finish Date", FormatType.DATE, null, null, 20),
                    new PLMXlsxRptColumn("lateStrtDt", "Late start Date", FormatType.DATE, null, null, 9),
                    new PLMXlsxRptColumn("pendingEffort", "Pending Effort", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("totalEffort", "Total Effort", FormatType.TEXT, null, null, 10),  
                    new PLMXlsxRptColumn("gePalnnedEffort", "GE Planned Effort", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("geRemainingHr", "GE Remaining Hour", FormatType.TEXT, null, null, 10)
			};
			
			
			PLMXlsxRptColumn[] critcolumns  = new PLMXlsxRptColumn[] {
	                new PLMXlsxRptColumn("name", "Name", FormatType.TEXT),
	                new PLMXlsxRptColumn("stateExcel", "State", FormatType.TEXT),
	                new PLMXlsxRptColumn("owner", "Owner", FormatType.TEXT),
	                new PLMXlsxRptColumn("orginator", "Originator", FormatType.TEXT),
	                new PLMXlsxRptColumn("taskResponsiblity", "Task Responsibility", FormatType.TEXT),
	                new PLMXlsxRptColumn("percentageComplete", "Percentate Complete", FormatType.TEXT),
	               // new PLMXlsxRptColumn("status", "Status", FormatType.TEXT),
	                new PLMXlsxRptColumn("estimateFnshFromDtExl", "Estimated Finish(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("estimateFnshToDtExl", "Estimated Finish(To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("taskApproval", "Task Approval", FormatType.TEXT),
	                new PLMXlsxRptColumn("actualFnshFromDtExl", "Actual Finish(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("actualFnshToDtExl", "Actual Finish(To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("associatedExcel", "Deliverable Type", FormatType.TEXT),
	                new PLMXlsxRptColumn("voucherfind", "Vocher Funding Source", FormatType.TEXT),
	                new PLMXlsxRptColumn("policy", "Policy", FormatType.TEXT),
	                new PLMXlsxRptColumn("projectName", "Project Name", FormatType.TEXT),
	                new PLMXlsxRptColumn("projectDesc", "Project Description", FormatType.TEXT),
	                new PLMXlsxRptColumn("contractName", "Contract Name", FormatType.TEXT),
	                new PLMXlsxRptColumn("taskName", "Activity Name", FormatType.TEXT),
	                new PLMXlsxRptColumn("assignee", "Assignee", FormatType.TEXT),
	                new PLMXlsxRptColumn("mfgNeedFromDtExl", "Mfg. Need(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("mfgNeedTotExl", "Mfg. Need(To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("custNeedFromDtExl", "Customer Need(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("custNeedToDtExl", "Customer Need(To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("mfgIndicator", "Mfg.Indicator", FormatType.TEXT),
	                new PLMXlsxRptColumn("taskResponsiblityUnit", "Resp.Unit", FormatType.TEXT),
	                new PLMXlsxRptColumn("deliverable", "Deliverables", FormatType.TEXT),
	                new PLMXlsxRptColumn("earlyFnshFromDtExl", "Early Finish(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("earlyFnshToDtExl", "Early Finish(To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("lateFnshFromDtExl", "Late Finish(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("lateFnshToDtExl", "Late Finish(To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("creationFromDateXl", "Creation (From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("creationToDateXl", "Creation (To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("expctdFinishFromDtXl", "Expected Finish(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("expctdFinishToDtXl", "Expected Finish(To Date)", FormatType.TEXT)
			};
			
			excelUtil.export(searchReportList, reportColumns, fileName, fileName, true, critcolumns, plmSearchData);
			
		}
		
		if(reportNameXls.equals("taskVolumeReport")){
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("projectName", "Project Name", FormatType.TEXT, null, null, 27),
                    new PLMXlsxRptColumn("projectDesc", "Project Description", FormatType.TEXT, null, null, 35),
                    new PLMXlsxRptColumn("contractName", "Contract Name", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("taskName", "Activity Name", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("title", "Task Title", FormatType.TEXT, null, null, 30),
                    new PLMXlsxRptColumn("desc", "Task Description", FormatType.TEXT, null, null, 35),
                    new PLMXlsxRptColumn("name", "Route/Task Name", FormatType.TEXT, null, null, 12),
                    new PLMXlsxRptColumn("policy", "Policy", FormatType.TEXT, null, null, 12),
                    new PLMXlsxRptColumn("deliverable", "Deliverables", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("state", "State", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("estimatedStart", "Est. Start", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("estimatedFinish", "Est. Finish", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("geEarlyFinishDate", "Early Finish Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("geLateFinishDate", "Late Finish Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("geTotalFloat", "Float", FormatType.TEXT, null, null, 6),
                    new PLMXlsxRptColumn("requiredHours", "Required Hours", FormatType.TEXT, null, null, 9),
                    new PLMXlsxRptColumn("estimatedDuration", "Est. Dur.", FormatType.TEXT, null, null, 8),
                    new PLMXlsxRptColumn("actualStart", "Act. Start", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("actualFinish", "Act. Finish", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("actualHours", "Act. Hours", FormatType.TEXT, null, null, 8),
                    new PLMXlsxRptColumn("duration", "Act. Dur.", FormatType.TEXT, null, null, 8),
                   // new PLMXlsxRptColumn("status", "Status", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("percentageComplete", "% Cmpl.", FormatType.TEXT, null, null, 8),
                    new PLMXlsxRptColumn("taskResponsiblity", "Resp. SSO", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("taskResponsiblityName", "Resp. Name", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("assignee", "Assgn. SSO", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("assigneeName", "Assgn. Name", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("findSource", "Voucher Funding Source", FormatType.TEXT, null, null, 25),
                    new PLMXlsxRptColumn("owner", "Owner SSO", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("ownerName", "Owner Name", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("orginator", "Orig. SSO", FormatType.TEXT, null, null, 10),
                   // new PLMXlsxRptColumn("orginatorName", "Orig. Name", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("taskApproval", "Task Approval", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("note", "Notes", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("taskReq", "Task Requirements", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("synopsis", "Synopsis", FormatType.TEXT, null, null, 15),
                   // new PLMXlsxRptColumn("projectrole", "Project Role", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("action", "Action", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("approveStatus", "Approve Status", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("taskResponsiblityUnit", "Responsible Unit", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("mfgIndicator", "Mfg. Indicator", FormatType.TEXT, null, null, 9),
                    new PLMXlsxRptColumn("mfgFinish", "Mfg. Need Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("customerFinish", "Customer Need Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("creationDate", "Creation Date", FormatType.DATE, null, null, 12),
                    new PLMXlsxRptColumn("actionTaken", "Action Taken", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("expctdFinishDt", "Expected Finish Date", FormatType.DATE, null, null, 20),
                    new PLMXlsxRptColumn("lateStrtDt", "Late start Date", FormatType.DATE, null, null, 9),
                    new PLMXlsxRptColumn("pendingEffort", "Pending Effort", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("totalEffort", "Total Effort", FormatType.TEXT, null, null, 10),  
                    new PLMXlsxRptColumn("gePalnnedEffort", "GE Planned Effort", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("geRemainingHr", "GE Remaining Hour", FormatType.TEXT, null, null, 10)
			};
			
			excelUtil.export(searchReportList, reportColumns, fileName, fileName, false, null, null);
			
		}
		
		//Export to Excel for Task Search Report Discussions Page
		if(reportNameXls.equals("taskDiscussionRptExl")){
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("projectName", "Project Name", FormatType.TEXT, null, null, 27),
                    new PLMXlsxRptColumn("geActivityCode", "GE Activity NM", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("respPrsnNM", "Resp Prsn NM", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("respUnitCode", "Resp Unit Code", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("lateFinish", "Late Finish", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("name", "Task Name", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("description", "Description", FormatType.TEXT, null, null, 30),
                    new PLMXlsxRptColumn("discussion", "Discussions", FormatType.TEXT, null, null, 50),
                    new PLMXlsxRptColumn("dateEntered", "Date Entered", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("enteredByUsrNM", "Entered by User NM", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("custNM", "Customer Name", FormatType.TEXT, null, null, 25),
                    new PLMXlsxRptColumn("custNeedDate", "Customer Need Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("actualFinish", "Actual Finish Date", FormatType.DATE, null, null, 10),
                    new PLMXlsxRptColumn("ecrNo", "ECR #", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("ecoNo", "ECO #", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("model", "Model", FormatType.TEXT, null, null, 15)
			};
			
			
			PLMXlsxRptColumn[] critcolumns  = new PLMXlsxRptColumn[] {
	                new PLMXlsxRptColumn("name", "Task Name", FormatType.TEXT),
	                new PLMXlsxRptColumn("state", "State", FormatType.TEXT),
	                new PLMXlsxRptColumn("owner", "Owner", FormatType.TEXT),
	                new PLMXlsxRptColumn("orginator", "Originator", FormatType.TEXT),
	                new PLMXlsxRptColumn("taskResponsiblity", "Task Responsibility", FormatType.TEXT),
	                new PLMXlsxRptColumn("percentageComplete", "Percentate Complete", FormatType.TEXT),
	                new PLMXlsxRptColumn("status", "Status", FormatType.TEXT),
	                new PLMXlsxRptColumn("estimateFnshFromDtExl", "Estimated Finish(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("estimateFnshToDtExl", "Estimated Finish(To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("taskApproval", "Task Approval", FormatType.TEXT),
	                new PLMXlsxRptColumn("actualFnshFromDtExl", "Actual Finish(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("actualFnshToDtExl", "Actual Finish(To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("associatedExcel", "Deliverable Type", FormatType.TEXT),
	                new PLMXlsxRptColumn("voucherfind", "Vocher Funding Source", FormatType.TEXT),
	                new PLMXlsxRptColumn("policy", "Policy", FormatType.TEXT),
	                new PLMXlsxRptColumn("projectName", "Project Name", FormatType.TEXT),
	                new PLMXlsxRptColumn("projectDesc", "Project Description", FormatType.TEXT),
	                new PLMXlsxRptColumn("contractName", "Contract Name", FormatType.TEXT),
	                new PLMXlsxRptColumn("taskName", "Activity Name", FormatType.TEXT),
	                new PLMXlsxRptColumn("assignee", "Assignee", FormatType.TEXT),
	                new PLMXlsxRptColumn("mfgNeedFromDtExl", "Mfg. Need(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("mfgNeedTotExl", "Mfg. Need(To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("custNeedFromDtExl", "Customer Need(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("custNeedToDtExl", "Customer Need(To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("mfgIndicator", "Mfg.Indicator", FormatType.TEXT),
	                new PLMXlsxRptColumn("taskResponsiblityUnit", "Resp.Unit", FormatType.TEXT),
	                new PLMXlsxRptColumn("deliverable", "Deliverable", FormatType.TEXT),
	                new PLMXlsxRptColumn("earlyFnshFromDtExl", "Early Finish(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("earlyFnshToDtExl", "Early Finish(To Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("lateFnshFromDtExl", "Late Finish(From Date)", FormatType.TEXT),
	                new PLMXlsxRptColumn("lateFnshToDtExl", "Late Finish(To Date)", FormatType.TEXT)
	
			};
			
			excelUtil.export(discussionRptList, reportColumns, fileName, fileName, true, critcolumns, plmSearchData);
			
		}
				
	} 	
	
	/**
	 * This method is used for download Excel sheet for each report
	 * 
	 * @return String
	 */
	public void downloadCSV() throws PLMCommonException {

		LOG.info("Entering downloadExcel Method");
		String reportName = reportNameXls;

		LOG.info("reportName>>> " + reportName);

		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		// Export to CSV for Task Search Report Header Page
		if (reportNameXls.equals("taskSearchReportExcel")) {
			String fileName = "Task Report";
			LOG.info("fileName>>> " + fileName);
			PLMCsvRptColumn[] reportColumns =
							new PLMCsvRptColumn[] {new PLMCsvRptColumn("name", "Task Name", FormatTypeCsv.TEXT, null, null, 27),
									new PLMCsvRptColumn("projectName", "Project Name", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("projectDesc", "Project Description", FormatTypeCsv.TEXT, null, null, 40),
									new PLMCsvRptColumn("contractName", "Contract Name", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("taskName", "Activity Name", FormatTypeCsv.TEXT, null, null, 20),
									new PLMCsvRptColumn("title", "Task Title", FormatTypeCsv.TEXT, null, null, 35),
									new PLMCsvRptColumn("state", "State", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("estimatedStart", "Est. Start", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("estimatedFinish", "Est. Finish", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("geEarlyFinishDate", "Early Finish Date", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("geLateFinishDate", "Late Finish Date", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("geTotalFloat", "Float", FormatTypeCsv.TEXT, null, null, 8),
									new PLMCsvRptColumn("requiredHours", "Required Hours", FormatTypeCsv.TEXT, null, null, 9),
									new PLMCsvRptColumn("estimatedDuration", "Est. Dur.", FormatTypeCsv.TEXT, null, null, 8),
									new PLMCsvRptColumn("actualStart", "Act. Start", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("actualFinish", "Act. Finish", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("actualHours", "Act. Hours", FormatTypeCsv.TEXT, null, null, 8),
									new PLMCsvRptColumn("duration", "Act. Dur.", FormatTypeCsv.TEXT, null, null, 8),
									//new PLMCsvRptColumn("status", "Status", FormatTypeCsv.TEXT, null, null, 10),
									//new PLMCsvRptColumn("percentageComplete", "% Cmpl.", FormatTypeCsv.TEXT, null, null, 8),
									new PLMCsvRptColumn("taskResponsiblity", "Resp. SSO", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("taskResponsiblityName", "Resp. Name", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("assignee", "Assgn. SSO", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("assigneeName", "Assgn. Name", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("owner", "Owner SSO", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("ownerName", "Owner Name", FormatTypeCsv.TEXT, null, null, 15),
									/*new PLMCsvRptColumn("orginator", "Orig. SSO", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("orginatorName", "Orig. Name", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("taskApproval", "Task Approval", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("note", "Notes", FormatTypeCsv.TEXT, null, null, 20),
									new PLMCsvRptColumn("taskReq", "Task Requirements", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("synopsis", "Synopsis", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("projectrole", "Project Role", FormatTypeCsv.TEXT, null, null, 15),*/
									new PLMCsvRptColumn("taskResponsiblityUnit", "Responsible Unit", FormatTypeCsv.TEXT, null, null, 12),
									new PLMCsvRptColumn("deliverable", "Deliverable", FormatTypeCsv.TEXT, null, null, 20),
									new PLMCsvRptColumn("type", "Deliverable Type", FormatTypeCsv.TEXT, null, null, 20),
									new PLMCsvRptColumn("mfgIndicator", "Mfg. Indicator", FormatTypeCsv.TEXT, null, null, 9),
									new PLMCsvRptColumn("mfgFinish", "Mfg. Need Date", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("customerFinish", "Customer Need Date", FormatTypeCsv.DATE, null, null, 10),
									 new PLMCsvRptColumn("creationDate", "Creation Date", FormatTypeCsv.DATE, null, null, 12),
						             new PLMCsvRptColumn("actionTaken", "Action Taken", FormatTypeCsv.TEXT, null, null, 20),
						             new PLMCsvRptColumn("expctdFinishDt", "Expected Finish Date", FormatTypeCsv.DATE, null, null, 20),
						             new PLMCsvRptColumn("lateStrtDt", "Late start Date", FormatTypeCsv.DATE, null, null, 9),
						             new PLMCsvRptColumn("pendingEffort", "Pending Effort", FormatTypeCsv.TEXT, null, null, 10),
						             new PLMCsvRptColumn("totalEffort", "Total Effort", FormatTypeCsv.TEXT, null, null, 10),  
						             new PLMCsvRptColumn("gePalnnedEffort", "GE Planned Effort", FormatTypeCsv.TEXT, null, null, 10),
						             new PLMCsvRptColumn("geRemainingHr", "GE Remaining Hour", FormatTypeCsv.TEXT, null, null, 10)};

			csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, null, ",");
		}

		// Export to CSV for Task Search Report Predecessor Successor Report
		if (reportNameXls.equals("taskSearchPredSucc")) {
			String fileName = "PredecesorSuccesor Report";
			LOG.info("fileName>>> " + fileName);

			PLMCsvRptColumn[] reportColumns =
							new PLMCsvRptColumn[] {new PLMCsvRptColumn("projectName", "Project Name", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("taskName", "Task Name", FormatTypeCsv.TEXT, null, null, 11),
									new PLMCsvRptColumn("predSuccName", "Pred / Succ", FormatTypeCsv.TEXT, null, null, 7),
									new PLMCsvRptColumn("dependencyType", "Con Type", FormatTypeCsv.TEXT, null, null, 7),
									new PLMCsvRptColumn("delay", "Delay", FormatTypeCsv.TEXT, null, null, 6),
									new PLMCsvRptColumn("taskTitle", "Task Title", FormatTypeCsv.TEXT, null, null, 35),
									new PLMCsvRptColumn("taskName", "Activity Name", FormatTypeCsv.TEXT, null, null, 11),
									new PLMCsvRptColumn("policy", "Policy", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("deliverable", "Deliverables", FormatTypeCsv.TEXT, null, null, 18),
									new PLMCsvRptColumn("state", "State", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("estimatedStart", "Est. Start", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("estimatedFinish", "Est. Finish", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("requiredHours", "Required Hours", FormatTypeCsv.TEXT, null, null, 9),
									new PLMCsvRptColumn("estimatedDuration", "Est. Dur.", FormatTypeCsv.TEXT, null, null, 8),
									new PLMCsvRptColumn("actualStart", "Act. Start", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("actualFinish", "Act. Finish", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("actualHours", "Act. Hours", FormatTypeCsv.TEXT, null, null, 8),
									new PLMCsvRptColumn("status", "Status", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("percentageComplete", "% Cmpl.", FormatTypeCsv.TEXT, null, null, 8),
									new PLMCsvRptColumn("respSso", "Resp. SSO", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("respPrsnNM", "Resp. Name", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("voucherfind", "Voucher Funding Source", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("owner", "Owner SSO", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("ownerName", "Owner Name", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("orignator", "Orig.SSO", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("orignatorName", "Orig.Name", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("taskApproval", "Task Approval", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("note", "Notes", FormatTypeCsv.TEXT, null, null, 25),
									new PLMCsvRptColumn("taskReq", "Task Requirements", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("synopsis", "Synopsis", FormatTypeCsv.TEXT, null, null, 25),
									new PLMCsvRptColumn("projectrole", "Project Role", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("action", "Action", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("approveStatus", "Approve Status", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("geTaskResponsibleUnit", "Resp. Unit", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("geMfggDeliverableIndr", "Mfg. Indicator", FormatTypeCsv.TEXT, null, null, 9),
									new PLMCsvRptColumn("geMfggNeedDate", "Mfg. Need Date", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("geCstmrNeedDate", "Customer Need Date", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("creationDate", "Creation Date", FormatTypeCsv.DATE, null, null, 12),
						             new PLMCsvRptColumn("actionTaken", "Action Taken", FormatTypeCsv.TEXT, null, null, 20),
						             new PLMCsvRptColumn("expctdFinishDt", "Expected Finish Date", FormatTypeCsv.DATE, null, null, 20),
						             new PLMCsvRptColumn("lateStrtDt", "Late start Date", FormatTypeCsv.DATE, null, null, 9),
						             new PLMCsvRptColumn("pendingEffort", "Pending Effort", FormatTypeCsv.TEXT, null, null, 10),
						             new PLMCsvRptColumn("totalEffort", "Total Effort", FormatTypeCsv.TEXT, null, null, 10),  
						             new PLMCsvRptColumn("gePalnnedEffort", "GE Planned Effort", FormatTypeCsv.TEXT, null, null, 10),
						             new PLMCsvRptColumn("geRemainingHr", "GE Remaining Hour", FormatTypeCsv.TEXT, null, null, 10)

							};

			csvUtil.exportCsv(precedorList, reportColumns, fileName, dateFormat, false, null, null, ",");
		}

		// Export to CSV for Task Search Report Details Page
		if (reportNameXls.equals("taskDetailReport") || reportNameXls.equals("taskVolumeReport")) {

			String fileName = "Task Detail Report";
			LOG.info("fileName>>> " + fileName);
			PLMCsvRptColumn[] reportColumns =
							new PLMCsvRptColumn[] {new PLMCsvRptColumn("projectName", "Project Name", FormatTypeCsv.TEXT, null, null, 27),
									new PLMCsvRptColumn("projectDesc", "Project Description", FormatTypeCsv.TEXT, null, null, 35),
									new PLMCsvRptColumn("contractName", "Contract Name", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("taskName", "Activity Name", FormatTypeCsv.TEXT, null, null, 20),
									new PLMCsvRptColumn("title", "Task Title", FormatTypeCsv.TEXT, null, null, 30),
									new PLMCsvRptColumn("desc", "Task Description", FormatTypeCsv.TEXT, null, null, 35),
									new PLMCsvRptColumn("name", "Route/Task Name", FormatTypeCsv.TEXT, null, null, 12),
									new PLMCsvRptColumn("policy", "Policy", FormatTypeCsv.TEXT, null, null, 12),
									new PLMCsvRptColumn("deliverable", "Deliverables", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("state", "State", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("estimatedStart", "Est. Start", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("estimatedFinish", "Est. Finish", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("geEarlyFinishDate", "Early Finish Date", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("geLateFinishDate", "Late Finish Date", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("geTotalFloat", "Float", FormatTypeCsv.TEXT, null, null, 6),
									new PLMCsvRptColumn("requiredHours", "Required Hours", FormatTypeCsv.TEXT, null, null, 9),
									new PLMCsvRptColumn("estimatedDuration", "Est. Dur.", FormatTypeCsv.TEXT, null, null, 8),
									new PLMCsvRptColumn("actualStart", "Act. Start", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("actualFinish", "Act. Finish", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("actualHours", "Act. Hours", FormatTypeCsv.TEXT, null, null, 8),
									new PLMCsvRptColumn("duration", "Act. Dur.", FormatTypeCsv.TEXT, null, null, 8),
									new PLMCsvRptColumn("status", "Status", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("percentageComplete", "% Cmpl.", FormatTypeCsv.TEXT, null, null, 8),
									new PLMCsvRptColumn("taskResponsiblity", "Resp. SSO", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("taskResponsiblityName", "Resp. Name", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("assignee", "Assgn. SSO", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("assigneeName", "Assgn. Name", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("findSource", "Voucher Funding Source", FormatTypeCsv.TEXT, null, null, 25),
									new PLMCsvRptColumn("owner", "Owner SSO", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("ownerName", "Owner Name", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("orginator", "Orig. SSO", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("orginatorName", "Orig. Name", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("taskApproval", "Task Approval", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("note", "Notes", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("taskReq", "Task Requirements", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("synopsis", "Synopsis", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("projectrole", "Project Role", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("action", "Action", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("approveStatus", "Approve Status", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("taskResponsiblityUnit", "Responsible Unit", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("mfgIndicator", "Mfg. Indicator", FormatTypeCsv.TEXT, null, null, 9),
									new PLMCsvRptColumn("mfgFinish", "Mfg. Need Date", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("customerFinish", "Customer Need Date", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("creationDate", "Creation Date", FormatTypeCsv.DATE, null, null, 12),
						             new PLMCsvRptColumn("actionTaken", "Action Taken", FormatTypeCsv.TEXT, null, null, 20),
						             new PLMCsvRptColumn("expctdFinishDt", "Expected Finish Date", FormatTypeCsv.DATE, null, null, 20),
						             new PLMCsvRptColumn("lateStrtDt", "Late start Date", FormatTypeCsv.DATE, null, null, 9),
						             new PLMCsvRptColumn("pendingEffort", "Pending Effort", FormatTypeCsv.TEXT, null, null, 10),
						             new PLMCsvRptColumn("totalEffort", "Total Effort", FormatTypeCsv.TEXT, null, null, 10),  
						             new PLMCsvRptColumn("gePalnnedEffort", "GE Planned Effort", FormatTypeCsv.TEXT, null, null, 10),
						             new PLMCsvRptColumn("geRemainingHr", "GE Remaining Hour", FormatTypeCsv.TEXT, null, null, 10)};

			csvUtil.exportCsv(searchReportList, reportColumns, fileName, dateFormat, false, null, null, ",");

		}

		// Export to CSV for Task Search Report Discussions Page
		if (reportNameXls.equals("taskDiscussionRptExl")) {

			String fileName = "Task Discussion Report";
			LOG.info("fileName>>> " + fileName);
			PLMCsvRptColumn[] reportColumns =
							new PLMCsvRptColumn[] {new PLMCsvRptColumn("projectName", "Project Name", FormatTypeCsv.TEXT, null, null, 27),
									new PLMCsvRptColumn("geActivityCode", "GE Activity NM", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("respPrsnNM", "Resp Prsn NM", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("respUnitCode", "Resp Unit Code", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("lateFinish", "Late Finish", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("name", "Task Name", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("description", "Description", FormatTypeCsv.TEXT, null, null, 30),
									new PLMCsvRptColumn("discussion", "Discussions", FormatTypeCsv.TEXT, null, null, 50),
									new PLMCsvRptColumn("dateEntered", "Date Entered", FormatTypeCsv.TEXT, null, null, 10),
									new PLMCsvRptColumn("enteredByUsrNM", "Entered by User NM", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("custNM", "Customer Name", FormatTypeCsv.TEXT, null, null, 25),
									new PLMCsvRptColumn("custNeedDate", "Customer Need Date", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("actualFinish", "Actual Finish Date", FormatTypeCsv.DATE, null, null, 10),
									new PLMCsvRptColumn("ecrNo", "ECR #", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("ecoNo", "ECO #", FormatTypeCsv.TEXT, null, null, 15),
									new PLMCsvRptColumn("model", "Model", FormatTypeCsv.TEXT, null, null, 15)};

			csvUtil.exportCsv(discussionRptList, reportColumns, fileName, dateFormat, false, null, null, ",");

		}
		
	}

	/**
	 * This method is used for backToTaskReport
	 * 
	 * @return String
	 */
	public String backToTaskReport(){
		String fwdFlag = "";
		LOG.info("Entering getTaskSearchData() method");
		 reportNameXls= "taskSearchReportExcel";
		 fileNameXls="Task Report";
		 alertMsgTsk="";
		 fwdFlag = "taskSearchReport";
		 return fwdFlag;
	}
	
	/**
	 * @return the alertStr
	 */
	public String getAlertStr() {

		String temp = null;
		temp = alertStr;
		alertStr = PLMConstants.EMPTY_STRING;
		return temp;
	}

	/**
	 * @param alertStr
	 *            the alertStr to set
	 */
	public void setAlertStr(String alertStra) {
		this.alertStr = alertStra;
		LOG.info("alertStr-------" + alertStr);
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage
	 *            the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle
	 *            the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return the taskData
	 */
	public List<PLMTaskSearchData> getTaskData() {
		return taskData;
	}

	/**
	 * @param taskData
	 *            the taskData to set
	 */
	public void setTaskData(List<PLMTaskSearchData> taskData) {
		this.taskData = taskData;
	}

	/**
	 * @return the assignTaskId
	 */
	public String getAssignTaskId() {
		return assignTaskId;
	}

	/**
	 * @param assignTaskId
	 *            the assignTaskId to set
	 */
	public void setAssignTaskId(String assignTaskId) {
		this.assignTaskId = assignTaskId;
	}

	/**
	 * @return the selectedId
	 */
	public String getSelectedId() {
		return selectedId;
	}

	/**
	 * @param selectedId
	 *            the selectedId to set
	 */
	public void setSelectedId(String selectedId) {
		this.selectedId = selectedId;
	}

	/**
	 * @return the selectedIdList
	 */
	public Map<String, String> getSelectedIdList() {
		return selectedIdList;
	}

	/**
	 * @param selectedIdList
	 *            the selectedIdList to set
	 */
	public void setSelectedIdList(Map<String, String> selectedIdList) {
		this.selectedIdList = selectedIdList;
	}

	/**
	 * @return the selectedTaskPred
	 */
	public String getSelectedTaskPred() {
		return selectedTaskPred;
	}

	/**
	 * @param selectedTaskPred
	 *            the selectedTaskPred to set
	 */
	public void setSelectedTaskPred(String selectedTaskPred) {
		this.selectedTaskPred = selectedTaskPred;
	}

	/**
	 * @return the selectedTaskDt
	 */
	public String getSelectedTaskDt() {
		return selectedTaskDt;
	}

	/**
	 * @param selectedTaskDt the selectedTaskDt to set
	 */
	public void setSelectedTaskDt(String selectedTaskDt) {
		this.selectedTaskDt = selectedTaskDt;
	}

	/**
	 * @return
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * @param pageNo
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * @return the taskSearchDetailsList
	 */
	public List<PLMTaskSearchData> getTaskSearchDetailsList() {
		return taskSearchDetailsList;
	}

	/**
	 * @param taskSearchDetailsList
	 *            the taskSearchDetailsList to set
	 */
	public void setTaskSearchDetailsList(
			List<PLMTaskSearchData> taskSearchDetailsList) {
		this.taskSearchDetailsList = taskSearchDetailsList;
	}

	/**
	 * @return the modifyQueryFlag
	 */
	public boolean isModifyQueryFlag() {
		return modifyQueryFlag;
	}

	/**
	 * @param modifyQueryFlag
	 *            the modifyQueryFlag to set
	 */
	public void setModifyQueryFlag(boolean modifyQueryFlag) {
		this.modifyQueryFlag = modifyQueryFlag;
	}

	/**
	 * @return the selectedQueryText
	 */
	public String getSelectedQueryText() {
		return selectedQueryText;
	}

	/**
	 * @param selectedQueryText
	 *            the selectedQueryText to set
	 */
	public void setSelectedQueryText(String selectedQueryText) {
		this.selectedQueryText = selectedQueryText;
	}

	/**
	 * @return the plmIssuesService
	 */
	public PLMkpiReportServiceIfc getPlmIssuesService() {
		return plmIssuesService;
	}

	/**
	 * @param plmIssuesService
	 *            the plmIssuesService to set
	 */
	public void setPlmIssuesService(PLMkpiReportServiceIfc plmIssuesService) {
		this.plmIssuesService = plmIssuesService;
	}

	/**
	 * @return the searchResultList
	 */
	public List<PLMTaskSearchData> getSearchResultList() {
		return searchResultList;
	}

	/**
	 * @param searchResultList
	 *            the searchResultList to set
	 */
	public void setSearchResultList(List<PLMTaskSearchData> searchResultList) {
		this.searchResultList = searchResultList;
	}

	/**
	 * @return the saveSearchResultList
	 */
	public List<PLMTaskSearchData> getSaveSearchResultList() {
		return saveSearchResultList;
	}

	/**
	 * @param saveSearchResultList
	 *            the saveSearchResultList to set
	 */
	public void setSaveSearchResultList(
			List<PLMTaskSearchData> saveSearchResultList) {
		this.saveSearchResultList = saveSearchResultList;
	}

	/**
	 * @return the discussionRptList
	 */
	public List<PLMTaskSearchData> getDiscussionRptList() {
		return discussionRptList;
	}

	/**
	 * @param discussionRptList
	 *            the discussionRptList to set
	 */
	public void setDiscussionRptList(List<PLMTaskSearchData> discussionRptList) {
		this.discussionRptList = discussionRptList;
	}

	/**
	 * @return the searchQuery
	 */
	public String getSearchQuery() {
		return searchQuery;
	}

	/**
	 * @param searchQuery
	 *            the searchQuery to set
	 */
	public void setSearchQuery(String searchQuery) {
		this.searchQuery = searchQuery;
	}

	/**
	 * @return the searchReportList
	 */
	public List<PLMTaskSearchData> getSearchReportList() {
		return searchReportList;
	}

	/**
	 * @param searchReportList
	 *            the searchReportList to set
	 */
	public void setSearchReportList(List<PLMTaskSearchData> searchReportList) {
		this.searchReportList = searchReportList;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB
	 *            the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the stateList
	 */
	public List<SelectItem> getStateList() {
		return stateList;
	}

	/**
	 * @param stateList
	 *            the stateList to set
	 */
	public void setStateList(List<SelectItem> stateList) {
		this.stateList = stateList;
	}

	/**
	 * @return the associatedTypeList
	 */
	public List<SelectItem> getAssociatedTypeList() {
		return associatedTypeList;
	}

	/**
	 * @param associatedTypeList
	 *            the associatedTypeList to set
	 */
	public void setAssociatedTypeList(List<SelectItem> associatedTypeList) {
		this.associatedTypeList = associatedTypeList;
	}

	/**
	 * @return the taskValuesList
	 */
	public List<SelectItem> getTaskValuesList() {
		return taskValuesList;
	}

	/**
	 * @param taskValuesList
	 *            the taskValuesList to set
	 */
	public void setTaskValuesList(List<SelectItem> taskValuesList) {
		this.taskValuesList = taskValuesList;
	}

	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @param recordCounts
	 *            the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}

	/**
	 * @return the plmSearchData
	 */
	public PLMTaskSearchData getPlmSearchData() {
		return plmSearchData;
	}

	/**
	 * @param plmSearchData
	 *            the plmSearchData to set
	 */
	public void setPlmSearchData(PLMTaskSearchData plmSearchData) {
		this.plmSearchData = plmSearchData;
	}

	/**
	 * @return the selectedTask
	 */
	public String getSelectedTask() {
		return selectedTask;
	}

	/**
	 * @param selectedTask
	 *            the selectedTask to set
	 */
	public void setSelectedTask(String selectedTask) {
		this.selectedTask = selectedTask;
	}

	/**
	 * @return the selectedQueryName
	 */
	public String getSelectedQueryName() {
		return selectedQueryName;
	}

	/**
	 * @param selectedQueryName
	 *            the selectedQueryName to set
	 */
	public void setSelectedQueryName(String selectedQueryName) {
		this.selectedQueryName = selectedQueryName;
	}

	/**
	 * @return the eCCNTagMaplist
	 */
	public Map<String, List<SelectItem>> geteCCNTagMaplist() {
		return eCCNTagMaplist;
	}

	/**
	 * @param eCCNTagMaplist
	 *            the eCCNTagMaplist to set
	 */
	public void seteCCNTagMaplist(
			Map<String, List<SelectItem>> eCCNTagMaplistLcl) {
		this.eCCNTagMaplist = eCCNTagMaplistLcl;
	}

	/**
	 * @return the eccnTagList
	 */
	public List<String> getEccnTagList() {
		return eccnTagList;
	}

	/**
	 * @param eccnTagList
	 *            the eccnTagList to set
	 */
	public void setEccnTagList(List<String> eccnTagList) {
		this.eccnTagList = eccnTagList;
	}

	/**
	 * @return the alertMsgTsk
	 */
	public String getAlertMsgTsk() {
		return alertMsgTsk;
	}

	/**
	 * @param alertMsgTsk
	 *            the alertMsgTsk to set
	 */
	public void setAlertMsgTsk(String alertMsgTsk) {
		this.alertMsgTsk = alertMsgTsk;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state
	 *            the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount
	 *            the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/**
	 * @return the totalRecCountMsg
	 */
	public String getTotalRecCountMsg() {
		return totalRecCountMsg;
	}

	/**
	 * @param totalRecCountMsg
	 *            the totalRecCountMsg to set
	 */
	public void setTotalRecCountMsg(String totalRecCountMsg) {
		this.totalRecCountMsg = totalRecCountMsg;
	}

	/**
	 * @return the totalRecCountForSaveSearchReport
	 */
	public int getTotalRecCountForSaveSearchReport() {
		return totalRecCountForSaveSearchReport;
	}

	/**
	 * @param totalRecCountForSaveSearchReport
	 *            the totalRecCountForSaveSearchReport to set
	 */
	public void setTotalRecCountForSaveSearchReport(
			int totalRecCountForSaveSearchReport) {
		this.totalRecCountForSaveSearchReport = totalRecCountForSaveSearchReport;
	}

	/**
	 * @return the totalRecCountMsgForSaveSearchReport
	 */
	public String getTotalRecCountMsgForSaveSearchReport() {
		return totalRecCountMsgForSaveSearchReport;
	}

	/**
	 * @param totalRecCountMsgForSaveSearchReport
	 *            the totalRecCountMsgForSaveSearchReport to set
	 */
	public void setTotalRecCountMsgForSaveSearchReport(
			String totalRecCountMsgForSaveSearchReport) {
		this.totalRecCountMsgForSaveSearchReport = totalRecCountMsgForSaveSearchReport;
	}

	/**
	 * @return the recordCountsForSaveSearchReport
	 */
	public int getRecordCountsForSaveSearchReport() {
		return recordCountsForSaveSearchReport;
	}

	/**
	 * @param recordCountsForSaveSearchReport
	 *            the recordCountsForSaveSearchReport to set
	 */
	public void setRecordCountsForSaveSearchReport(
			int recordCountsForSaveSearchReport) {
		this.recordCountsForSaveSearchReport = recordCountsForSaveSearchReport;
	}

	/**
	 * @return the ntotalRecCountMsg
	 */
	public String getNtotalRecCountMsg() {
		return ntotalRecCountMsg;
	}

	/**
	 * @param ntotalRecCountMsg
	 *            the ntotalRecCountMsg to set
	 */
	public void setNtotalRecCountMsg(String ntotalRecCountMsg) {
		this.ntotalRecCountMsg = ntotalRecCountMsg;
	}

	/**
	 * @return the nrecordCounts
	 */
	public int getNrecordCounts() {
		return nrecordCounts;
	}

	/**
	 * @param nrecordCounts
	 *            the nrecordCounts to set
	 */
	public void setNrecordCounts(int nrecordCounts) {
		this.nrecordCounts = nrecordCounts;
	}

	/**
	 * @return the ntotalRecCount
	 */
	public int getNtotalRecCount() {
		return ntotalRecCount;
	}

	/**
	 * @param ntotalRecCount
	 *            the ntotalRecCount to set
	 */
	public void setNtotalRecCount(int ntotalRecCount) {
		this.ntotalRecCount = ntotalRecCount;
	}

	/**
	 * @return the page
	 */
	public String getPage() {
		return page;
	}

	/**
	 * @param page
	 *            the page to set
	 */
	public void setPage(String page) {
		this.page = page;
	}

	/**
	 * @return the searchFlag
	 */
	public String getSearchFlag() {
		return searchFlag;
	}

	/**
	 * @param searchFlag
	 *            the searchFlag to set
	 */
	public void setSearchFlag(String searchFlag) {
		this.searchFlag = searchFlag;
	}

	/**
	 * @return the exceptionOccurred
	 */
	public String getExceptionOccurred() {
		return exceptionOccurred;
	}

	/**
	 * @param exceptionOccurred
	 *            the exceptionOccurred to set
	 */
	public void setExceptionOccurred(String exceptionOccurred) {
		this.exceptionOccurred = exceptionOccurred;
	}

	/**
	 * @return the totalRecCountForDiscussioRpt
	 */
	public int getTotalRecCountForDiscussioRpt() {
		return totalRecCountForDiscussioRpt;
	}

	/**
	 * @param totalRecCountForDiscussioRpt
	 *            the totalRecCountForDiscussioRpt to set
	 */
	public void setTotalRecCountForDiscussioRpt(int totalRecCountForDiscussioRpt) {
		this.totalRecCountForDiscussioRpt = totalRecCountForDiscussioRpt;
	}

	/**
	 * @return the totalRecCountMsgForDiscussioRpt
	 */
	public String getTotalRecCountMsgForDiscussioRpt() {
		return totalRecCountMsgForDiscussioRpt;
	}

	/**
	 * @param totalRecCountMsgForDiscussioRpt
	 *            the totalRecCountMsgForDiscussioRpt to set
	 */
	public void setTotalRecCountMsgForDiscussioRpt(
			String totalRecCountMsgForDiscussioRpt) {
		this.totalRecCountMsgForDiscussioRpt = totalRecCountMsgForDiscussioRpt;
	}

	/**
	 * @return the recordCountsForDiscussioRpt
	 */
	public int getRecordCountsForDiscussioRpt() {
		return recordCountsForDiscussioRpt;
	}

	/**
	 * @param recordCountsForDiscussioRpt
	 *            the recordCountsForDiscussioRpt to set
	 */
	public void setRecordCountsForDiscussioRpt(int recordCountsForDiscussioRpt) {
		this.recordCountsForDiscussioRpt = recordCountsForDiscussioRpt;
	}

	/**
	 * @return the precedorList
	 */
	public List<PLMTaskSearchData> getPrecedorList() {
		return precedorList;
	}

	/**
	 * @param precedorList
	 *            the precedorList to set
	 */
	public void setPrecedorList(List<PLMTaskSearchData> precedorList) {
		this.precedorList = precedorList;
	}

	/**
	 * @return the successorList
	 */
	public List<PLMTaskSearchData> getSuccessorList() {
		return successorList;
	}

	/**
	 * @param successorList
	 *            the successorList to set
	 */
	public void setSuccessorList(List<PLMTaskSearchData> successorList) {
		this.successorList = successorList;
	}

	/**
	 * @return the projNameLink
	 */
	public UIDataTable getProjNameLink() {
		return projNameLink;
	}

	/**
	 * @param projNameLink
	 *            the projNameLink to set
	 */
	public void setProjNameLink(UIDataTable projNameLink) {
		this.projNameLink = projNameLink;
	}

	/**
	 * @return the assignProjName
	 */
	public String getAssignProjName() {
		return assignProjName;
	}

	/**
	 * @param assignProjName
	 *            the assignProjName to set
	 */
	public void setAssignProjName(String assignProjName) {
		this.assignProjName = assignProjName;
	}

	/**
	 * @return the assignTaskName
	 */
	public String getAssignTaskName() {
		return assignTaskName;
	}

	/**
	 * @param assignTaskName
	 *            the assignTaskName to set
	 */
	public void setAssignTaskName(String assignTaskName) {
		this.assignTaskName = assignTaskName;
	}

	/**
	 * @return the ntotalPreRecCount
	 */
	public int getNtotalPreRecCount() {
		return ntotalPreRecCount;
	}

	/**
	 * @param ntotalPreRecCount
	 *            the ntotalPreRecCount to set
	 */
	public void setNtotalPreRecCount(int ntotalPreRecCount) {
		this.ntotalPreRecCount = ntotalPreRecCount;
	}

	/**
	 * @return the ntotalSuccRecCount
	 */
	public int getNtotalSuccRecCount() {
		return ntotalSuccRecCount;
	}

	/**
	 * @param ntotalSuccRecCount
	 *            the ntotalSuccRecCount to set
	 */
	public void setNtotalSuccRecCount(int ntotalSuccRecCount) {
		this.ntotalSuccRecCount = ntotalSuccRecCount;
	}

	/**
	 * @return the ntotalPreRecCountMsg
	 */
	public String getNtotalPreRecCountMsg() {
		return ntotalPreRecCountMsg;
	}

	/**
	 * @param ntotalPreRecCountMsg
	 *            the ntotalPreRecCountMsg to set
	 */
	public void setNtotalPreRecCountMsg(String ntotalPreRecCountMsg) {
		this.ntotalPreRecCountMsg = ntotalPreRecCountMsg;
	}

	/**
	 * @return the ntotalSuccRecCountMsg
	 */
	public String getNtotalSuccRecCountMsg() {
		return ntotalSuccRecCountMsg;
	}

	/**
	 * @param ntotalSuccRecCountMsg
	 *            the ntotalSuccRecCountMsg to set
	 */
	public void setNtotalSuccRecCountMsg(String ntotalSuccRecCountMsg) {
		this.ntotalSuccRecCountMsg = ntotalSuccRecCountMsg;
	}

	/**
	 * @return the taskSrchData
	 */
	public PLMTaskSearchData getTaskSrchData() {
		return taskSrchData;
	}

	/**
	 * @param taskSrchData
	 *            the taskSrchData to set
	 */
	public void setTaskSrchData(PLMTaskSearchData taskSrchData) {
		this.taskSrchData = taskSrchData;
	}

	/**
	 * @return the projectNameLink
	 */
	public HtmlCommandButton getProjectNameLink() {
		return projectNameLink;
	}

	/**
	 * @param projectNameLink
	 *            the projectNameLink to set
	 */
	public void setProjectNameLink(HtmlCommandButton projectNameLink) {
		this.projectNameLink = projectNameLink;
	}

	/**
	 * @return the taskNameLink
	 */
	public HtmlCommandButton getTaskNameLink() {
		return taskNameLink;
	}

	/**
	 * @param taskNameLink
	 *            the taskNameLink to set
	 */
	public void setTaskNameLink(HtmlCommandButton taskNameLink) {
		this.taskNameLink = taskNameLink;
	}

	/**
	 * @return the recordPreRecCount
	 */
	public int getRecordPreRecCount() {
		return recordPreRecCount;
	}

	/**
	 * @param recordPreRecCount
	 *            the recordPreRecCount to set
	 */
	public void setRecordPreRecCount(int recordPreRecCount) {
		this.recordPreRecCount = recordPreRecCount;
	}

	/**
	 * @return the recordSuccRecCount
	 */
	public int getRecordSuccRecCount() {
		return recordSuccRecCount;
	}

	/**
	 * @param recordSuccRecCount
	 *            the recordSuccRecCount to set
	 */
	public void setRecordSuccRecCount(int recordSuccRecCount) {
		this.recordSuccRecCount = recordSuccRecCount;
	}

	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return LOG;
	}

	public String getWhereClauseQry() {
		return whereClauseQry;
	}

	public void setWhereClauseQry(String whereClauseQry) {
		this.whereClauseQry = whereClauseQry;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	
	

}