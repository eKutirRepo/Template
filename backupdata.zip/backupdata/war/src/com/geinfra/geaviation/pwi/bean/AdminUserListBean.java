package com.geinfra.geaviation.pwi.bean;


import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.richfaces.component.UIDataTable;
import org.richfaces.component.html.HtmlExtendedDataTable;

import com.geinfra.geaviation.pwi.bean.util.BeanUtil;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.model.PWiUserVO;
import com.geinfra.geaviation.pwi.service.UserService;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;


	/**
	 * 
	 * Project : Product Lifecycle Management Date Written : May 19, 2010 Security :
	 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
	 * 
	 * Copyright(C) 2010 GE All rights reserved
	 * 
	 * Description : QueryGroupBean
	 * This bean backs both the admin-group and admin-createupdategroup jsf pages.
	 * 
	 * Revision Log May 19, 2010 | v1.0.
	 * --------------------------------------------------------------
	 */
	public class AdminUserListBean  extends BaseBean {
		/**
		 * Holds the Logger.
		 */
		private static final Logger LOG = Logger.getLogger(AdminUserListBean.class);
		// Injected services
		private UserService userService;
		
		private HtmlExtendedDataTable userTable = new HtmlExtendedDataTable();
		private List<PWiUserVO> userVOList;
		
		private List<SelectItem> selRoleList;
		
		private String roleId;
		
		private String searchSso;
		private String searchFname;
		private String searchLname;
		private String statusInd;
		private String alrtUserSrchMsg;
		private int recordCount=PLMConstants.N_100;
		private boolean showDataTable;
		private PLMCommonMB commonMB = null;
		private UIDataTable userSssoVal = null;
		private boolean createUsrFlg;
		
		public void setUserService(UserService userService) {
			this.userService = userService;
		}
		
		public String actionEditUser() throws NumberFormatException, PWiException {
			createUsrFlg=false;
			PWiUserVO tempData = (PWiUserVO)userSssoVal.getRowData();
			return BeanUtil.getInstance().getAdminUserEditorBean().initEdit(tempData.getUserId());
		}
		
		
		public String actionCreateUser() throws PWiException {
			createUsrFlg=true;
			return BeanUtil.getInstance().getAdminUserEditorBean().initCreate();
		}
		
		public List<PWiUserVO> getUserVOList() {
			/*if (userVOList == null) {
				userVOList = userService.getAllPWiUsers(); 
			}*/
			return userVOList;
		}
		
		public void setUserVOList(List<PWiUserVO> userVOList) {
			this.userVOList = userVOList;
		}

		public HtmlExtendedDataTable getUserTable() {
			return userTable;
		}

		public void setUserTable(HtmlExtendedDataTable userTable) {
			this.userTable = userTable;
		}
		
		public List<PWiUserVO> getUsersFromSelectedGroups()
		{
			List<PWiQueryGroupVO> selectedQueryGroupsList = null;
			List<PWiUserVO> userDtls= userService.getUsersFromSelectedGroups(selectedQueryGroupsList);
			return userDtls;
			
		}

		
		public void searchUser() throws PLMCommonException {
			try {
				alrtUserSrchMsg = PLMConstants.EMPTY;
				
				if ((searchSso != null && !(PLMConstants.EMPTY_STRING)
						.equals(searchSso.trim()))
						|| (searchFname != null && !(PLMConstants.EMPTY_STRING)
								.equals(searchFname.trim()))
						|| (searchLname != null && !(PLMConstants.EMPTY_STRING)
								.equals(searchLname.trim()))
						|| (roleId != null && !(PLMConstants.EMPTY_STRING)
								.equals(roleId))
						|| (statusInd != null && !(PLMConstants.EMPTY_STRING)
								.equals(statusInd))){
					
					userVOList = userService.searchUser(PLMUtils.escapeChar(searchSso), PLMUtils.escapeChar(searchFname),
							PLMUtils.escapeChar(searchLname), roleId, statusInd);
					if (userVOList.size() > 0) {
						LOG.info("userVOList.size() >>>>>>>>>>>>>>>>>>> "+userVOList.size());
						recordCount=PLMConstants.N_100;
						showDataTable = true;
					} else {
						showDataTable = false;
						alrtUserSrchMsg = PLMConstants.N0_RECORDS;
					}
				} else {
					alrtUserSrchMsg = PLMConstants.SEARCH_CRITERIA;
				}
			} catch (PLMCommonException exception) {
				PLMUtils.setCommonException(exception.getMessage(),commonMB,"adminListUsers","Users");
				throw exception;
			}  
		}
		
		/**
		 * This method is used to download an Excel File
		 * 
		 *
		 */
		public void downloadExcel() throws PLMCommonException {
			LOG.info("Entering downloadExcel Method");
			String reportName = "User Data Report";
			String fileName = "User Data Report";
			LOG.info("reportName>>> " + reportName);
			LOG.info("fileName>>> " + fileName);
			
			PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
			
			//Export to Excel for User related information
				PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
						  new PLMXlsxRptColumn("sso", "SSO ID", FormatType.TEXT),
						  new PLMXlsxRptColumn("userNm", "Name", FormatType.TEXT, null, null, 28),
						  new PLMXlsxRptColumn("email", "Email", FormatType.TEXT, null, null, 28),
						  new PLMXlsxRptColumn("roleName", "Role Type", FormatType.TEXT, null, null, 35)
				};
				
				excelUtil.export(userVOList, reportColumns, fileName, fileName, false, null, null);	
				LOG.info("Exiting downloadExcel Method");
		} 	
		
		/**
		 * This method is used for Generating Report in XLS
		 * 
		 * @return File
		 */
		public File generateUserDataReport(List<PWiUserVO> userVOListLcl,String reportName) throws IOException {
			LOG.info("Entering generateUserDataReport Method");
			File flexcelFile =null;
			FileOutputStream fileOut = null;
			InputStream fstream = null;
			BufferedOutputStream bos = null;
			OutputStream os = null;
			HSSFWorkbook workbook = null;
			HSSFSheet sheet = null;
			HSSFCell cell=null;
			try {
			   StringBuilder fileNameStr = new StringBuilder()
			   .append(PLMUtils.getMessage("OFFLINE_RPT_DIR","Reports"))
			   .append(reportName)
			   .append(".xls");
			   
			   flexcelFile = new File(fileNameStr.toString());
				workbook = new HSSFWorkbook();
					 
					sheet =  workbook.createSheet(reportName);
					HSSFFont fontstyle = workbook.createFont();
					fontstyle.setFontName(PLMConstants.EXCEL_FONT_NAME);
						
					HSSFCellStyle headerStyle = workbook.createCellStyle();
					
					headerStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
					headerStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
					headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
					headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
					HSSFFont font = workbook.createFont(); 
					font.setFontName(PLMConstants.EXCEL_FONT_NAME);
					font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
					headerStyle.setFont(font);
					headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
					headerStyle = setBorderStyle(headerStyle);
					
					HSSFCellStyle textCellStyle = workbook.createCellStyle(); 
					textCellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
					textCellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
					textCellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
					textCellStyle.setBorderTop((HSSFCellStyle.BORDER_THIN));
					textCellStyle.setFont(fontstyle);
					textCellStyle.setAlignment(CellStyle.ALIGN_LEFT);
				
					int rowcount = -1;
					
					if(!PLMUtils.isEmptyList(userVOListLcl)) {
						
						HSSFRow row = sheet.createRow(++rowcount);
							String[] colNames = {"SSO ID","Name","Email","Role Type"};
							
							for ( int i = 0 ; i < colNames.length; i++ ) {
								cell = row.createCell(i);
								cell. setCellValue(colNames[i]);
								cell.setCellStyle(headerStyle);
								headerStyle = cell.getCellStyle();
								cell.setCellStyle(headerStyle);
						    }
						
						for(int i = 0; i < userVOListLcl.size(); i++) {
							PWiUserVO	 dataObj = (PWiUserVO)userVOListLcl.get(i);
							row =  sheet.createRow(++rowcount);
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_ZERO);
							cell.setCellStyle(textCellStyle);
							cell.setCellValue(dataObj.getSso());
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellStyle(textCellStyle);
							cell.setCellValue(dataObj.getUserNm());
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_TWO);
							cell.setCellStyle(textCellStyle);
							cell.setCellValue(dataObj.getEmail());
							
							cell =   row.createCell(PLMConstants.EXCEL_COL_THREE);
							cell.setCellStyle(textCellStyle);
							cell.setCellValue(dataObj.getRoleName());
						}
						
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, (short) 3000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, (short) 5000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, (short) 9000);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE, (short) 25000);
					}
						
					fileOut = new FileOutputStream(flexcelFile);
					workbook.write(fileOut);
					String fileName = flexcelFile.getName();
					FacesContext context = FacesContext.getCurrentInstance();
					HttpServletResponse response = (HttpServletResponse) context
							.getExternalContext().getResponse();
					response.setContentType("application/vnd.ms-excel");
					response.setHeader("content-disposition",
							"attachment; filename="+ fileName);
					os = response.getOutputStream();
					workbook.write(os);
					fileOut.close();
					os.close();
					context.responseComplete();
					LOG.info("test file name" + fileName);
					LOG.info("test report-------" + flexcelFile);
					
			} catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@generateUserDataReport: ", e);
				throw e;
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@generateUserDataReport: ", e);
				throw e;
			}  
			finally {
				try {
					if (bos != null) {
						bos.close();
					}
				} catch (IOException exception) {
					LOG.log(Level.ERROR,"The Exception in generateUserDataReport " + exception);
				}
				try {
					if (os != null) {
						os.close();
					}
				} catch (IOException exception) {
					LOG.log(Level.ERROR,"The Exception in generateUserDataReport " + exception);
				}
				try {
					if (fstream != null) {
						fstream.close();
					}
				} catch (IOException exception) {
					LOG.log(Level.ERROR,"The Exception in generateUserDataReport " + exception);
				}
				try {
					if (flexcelFile != null) {
						PLMUtils.deleteDocument(flexcelFile.getAbsolutePath());
					}
				} catch (Exception exception) {
					LOG.log(Level.ERROR,"The Exception in generateUserDataReport " + exception);
				}
				try {
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException exception) {
					LOG.log(Level.ERROR,"The Exception in generateUserDataReport " + exception);
				}
			}
			LOG.info("Exiting generateUserDataReport Method");
			return flexcelFile;
	   }	
		
		
		/**
		 * This method is used for Bordering Cell in XLS
		 * 
		 * @return StringBuffer
		 */
		
		private HSSFCellStyle setBorderStyle(HSSFCellStyle style) {
			style.setBorderTop(HSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style.setBorderRight(HSSFCellStyle.BORDER_THIN);
			return style;
		}
		
		/**
		 * @return the selRoleList
		 * @throws PLMCommonException 
		 */
		public List<SelectItem> getSelRoleList() {
			return selRoleList;
		}
		
		public List<SelectItem> setRoleList() throws PLMCommonException {
			LOG.info("Entering setRoleList Method");
				alrtUserSrchMsg = PLMConstants.EMPTY;
				searchSso =null;
				searchFname=null;
				searchLname=null;
				statusInd="";
				roleId=null;
				if (!PLMUtils.isEmptyList(selRoleList)) {
					selRoleList.clear();
				} else {
					selRoleList = new ArrayList<SelectItem>();
				}
				List<PWiUserVO> getRolesList = userService.getRolesFromSelectedUsers();
				for (int i = 0; i < getRolesList.size(); i++) {
					selRoleList.add(new SelectItem(getRolesList.get(i).getRoleId(),
					getRolesList.get(i).getRoleName()));
				}
			if (!PLMUtils.isEmptyList(userVOList)) {
				showDataTable = false;
				userVOList.clear();
			}
				LOG.info("Exiting setRoleList Method");
			return selRoleList;
		}

		/**
		 * @param selRoleList the selRoleList to set
		 */
		public void setSelRoleList(List<SelectItem> selRoleList) {
			this.selRoleList = selRoleList;
		}

		/**
		 * @return the roleId
		 */
		public String getRoleId() {
			return roleId;
		}

		/**
		 * @param roleId the roleId to set
		 */
		public void setRoleId(String roleId) {
			this.roleId = roleId;
		}

		/**
		 * @return the searchSso
		 */
		public String getSearchSso() {
			return searchSso;
		}

		/**
		 * @param searchSso the searchSso to set
		 */
		public void setSearchSso(String searchSso) {
			this.searchSso = searchSso;
		}

		/**
		 * @return the searchFname
		 */
		public String getSearchFname() {
			return searchFname;
		}

		/**
		 * @param searchFname the searchFname to set
		 */
		public void setSearchFname(String searchFname) {
			this.searchFname = searchFname;
		}

		/**
		 * @return the searchLname
		 */
		public String getSearchLname() {
			return searchLname;
		}

		/**
		 * @param searchLname the searchLname to set
		 */
		public void setSearchLname(String searchLname) {
			this.searchLname = searchLname;
		}

		/**
		 * @return the statusInd
		 */
		public String getStatusInd() {
			return statusInd;
		}

		/**
		 * @param statusInd the statusInd to set
		 */
		public void setStatusInd(String statusInd) {
			this.statusInd = statusInd;
		}

		/**
		 * @return the userService
		 */
		public UserService getUserService() {
			return userService;
		}

		/**
		 * @return the alrtUserSrchMsg
		 */
		public String getAlrtUserSrchMsg() {
			return alrtUserSrchMsg;
		}

		/**
		 * @param alrtUserSrchMsg the alrtUserSrchMsg to set
		 */
		public void setAlrtUserSrchMsg(String alrtUserSrchMsg) {
			this.alrtUserSrchMsg = alrtUserSrchMsg;
		}

		/**
		 * @return the recordCount
		 */
		public int getRecordCount() {
			return recordCount;
		}

		/**
		 * @param recordCount the recordCount to set
		 */
		public void setRecordCount(int recordCount) {
			this.recordCount = recordCount;
		}

		/**
		 * @return the showDataTable
		 */
		public boolean isShowDataTable() {
			return showDataTable;
		}

		/**
		 * @param showDataTable the showDataTable to set
		 */
		public void setShowDataTable(boolean showDataTable) {
			this.showDataTable = showDataTable;
		}
		/**
		 * @return the commonMB
		 */
		public PLMCommonMB getCommonMB() {
			return commonMB;
		}

		/**
		 * @param commonMB the commonMB to set
		 */
		public void setCommonMB(PLMCommonMB commonMB) {
			this.commonMB = commonMB;
		}

		/**
		 * @return the userSssoVal
		 */
		public UIDataTable getUserSssoVal() {
			return userSssoVal;
		}

		/**
		 * @param userSssoVal the userSssoVal to set
		 */
		public void setUserSssoVal(UIDataTable userSssoVal) {
			this.userSssoVal = userSssoVal;
		}

		/**
		 * @return the createUsrFlg
		 */
		public boolean isCreateUsrFlg() {
			return createUsrFlg;
		}

		/**
		 * @param createUsrFlg the createUsrFlg to set
		 */
		public void setCreateUsrFlg(boolean createUsrFlg) {
			this.createUsrFlg = createUsrFlg;
		}

		
	}