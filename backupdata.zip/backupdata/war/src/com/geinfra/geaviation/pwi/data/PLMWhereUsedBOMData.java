/**
 * Copyright (C) 2017 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhereUsedBOMData.java
 * @Creation date: 16-November-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMWhereUsedBOMData {

	/**
	  * Holds the level
	  */
	private String bomLevel;
	/**
	  * Holds the level
	  */
	private int level;
	/**
	  * Holds the partNumber
	  */
	private String partNumber;
	/**
	  * Holds the levels
	  */
	private String levels;
	/**
	  * Holds the findNum
	  */
	private String findNum;
	/**
	  * Holds the refDes
	  */
	private String refDes;
	/**
	  * Holds the quantity
	  */
	private String quantity;
	/**
	  * Holds the partMode
	  */
	private String partMode;
	/**
	  * Holds the revision
	  */
	private String revision;
	/**
	  * Holds the partType
	  */
	private String partType;
	/**
	  * Holds the partState
	  */
	private String partState;
	/**
	  * Holds the description
	  */
	private String description;
	/**
	  * Holds the relationType
	  */
	private String relationType;
	/**
	  * Holds the matchingChild
	  */
	private String matchingChild;
	/**
	  * Holds the matchingCount
	  */
	private int matchingCount;
	/**
	  * Holds the matchPrcnt
	  */
	private int matchPrcnt;
	
	/**
	 * @return
	 */
	public String getBomLevel() {
		return bomLevel;
	}
	/**
	 * @param bomLevel
	 */
	public void setBomLevel(String bomLevel) {
		this.bomLevel = bomLevel;
	}
	/**
	 * @return
	 */
	public String getPartNumber() {
		return partNumber;
	}
	/**
	 * @param partNumber
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	/**
	 * @return
	 */
	public String getLevels() {
		return levels;
	}
	/**
	 * @param levels
	 */
	public void setLevels(String levels) {
		this.levels = levels;
	}
	/**
	 * @return
	 */
	public String getFindNum() {
		return findNum;
	}
	/**
	 * @param findNum
	 */
	public void setFindNum(String findNum) {
		this.findNum = findNum;
	}
	/**
	 * @return
	 */
	public String getRefDes() {
		return refDes;
	}
	/**
	 * @param refDes
	 */
	public void setRefDes(String refDes) {
		this.refDes = refDes;
	}
	/**
	 * @return
	 */
	public String getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity
	 */
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return
	 */
	public String getPartMode() {
		return partMode;
	}
	/**
	 * @param partMode
	 */
	public void setPartMode(String partMode) {
		this.partMode = partMode;
	}
	/**
	 * @return
	 */
	public String getRevision() {
		return revision;
	}
	/**
	 * @param revision
	 */
	public void setRevision(String revision) {
		this.revision = revision;
	}
	/**
	 * @return
	 */
	public String getPartType() {
		return partType;
	}
	/**
	 * @param partType
	 */
	public void setPartType(String partType) {
		this.partType = partType;
	}
	/**
	 * @return
	 */
	public String getPartState() {
		return partState;
	}
	/**
	 * @param partState
	 */
	public void setPartState(String partState) {
		this.partState = partState;
	}
	/**
	 * @return
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return
	 */
	public String getRelationType() {
		return relationType;
	}
	/**
	 * @param relationType
	 */
	public void setRelationType(String relationType) {
		this.relationType = relationType;
	}
	/**
	 * @return
	 */
	public int getMatchingCount() {
		return matchingCount;
	}
	/**
	 * @param matchingCount
	 */
	public void setMatchingCount(int matchingCount) {
		this.matchingCount = matchingCount;
	}
	/**
	 * @return
	 */
	public int getMatchPrcnt() {
		return matchPrcnt;
	}
	/**
	 * @param matchPrcnt
	 */
	public void setMatchPrcnt(int matchPrcnt) {
		this.matchPrcnt = matchPrcnt;
	}
	/**
	 * @return
	 */
	public String getMatchingChild() {
		return matchingChild;
	}
	/**
	 * @param matchingChild
	 */
	public void setMatchingChild(String matchingChild) {
		this.matchingChild = matchingChild;
	}
	/**
	 * @return
	 */
	public int getLevel() {
		return level;
	}
	/**
	 * @param level
	 */
	public void setLevel(int level) {
		this.level = level;
	}
	
}