package com.geinfra.geaviation.pwi.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.PWiBaseVO;
import com.geinfra.geaviation.pwi.model.QiOptionsVO;
import com.geinfra.geaviation.pwi.util.DaoUtil;

/**
 * Project : Product Lifecycle Management Date Written : Apr 12, 2011 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description :
 * 
 * Revision Log Apr 12, 2011 | v1.0.
 * --------------------------------------------------------------
 */
public class DefaultQiOptionsDAOImpl implements DefaultQiOptionsDAO {
	// Injected
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<QiOptionsVO> getDefaultQiOptions(String sso) {
		// Define row mapper
		DefaultQiOptionsRowMapper rowMapper = new DefaultQiOptionsRowMapper();

		// Define prepared statement setter
		GetDefaultQueriesSetter pss = new GetDefaultQueriesSetter(rowMapper,
				sso);

		// Run query on database
		@SuppressWarnings("unchecked")
		List<QiOptionsVO> defaultQiOptions = (List<QiOptionsVO>) jdbcTemplate
				.query(pss.getSql(), pss, rowMapper);

		return defaultQiOptions;
	}

	private static class GetDefaultQueriesSetter implements
			PreparedStatementSetter {
		private DefaultQiOptionsRowMapper rowMapper;
		private String sso;

		public GetDefaultQueriesSetter(DefaultQiOptionsRowMapper rowMapper,
				String sso) {
			this.rowMapper = rowMapper;
			this.sso = sso;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setString(1, sso);
		}

		public String getSql() {
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT ");
			sql.append(rowMapper.getSelectColumns());
			sql.append(" FROM ");
			sql.append(QiOptionsVO.TABLE);
			sql.append(" WHERE ");
			sql.append(QiOptionsVO.COLUMN_SSO_ID);
			sql.append("=? ORDER BY ");
			sql.append(QiOptionsVO.COLUMN_ORDER_INDEX);
			return sql.toString();
		}
	}

	private static class DefaultQiOptionsRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			Integer defaultQiOptionsId = Integer.valueOf(rs
					.getInt(QiOptionsVO.COLUMN_DFLT_QI_OPTN_SEQ_ID));
			Integer objectTypeId = Integer.valueOf(rs
					.getInt(QiOptionsVO.COLUMN_OBJ_TYP_SEQ_ID));
			Integer queryId = Integer.valueOf(rs
					.getInt(QiOptionsVO.COLUMN_QRY_SEQ_ID));
			boolean querySelected = "Y".equals(rs
					.getString(QiOptionsVO.COLUMN_QRY_SELECTED));
			boolean collapseResult = "Y".equals(rs
					.getString(QiOptionsVO.COLUMN_COLLAPSE_RESULT));
			Integer orderIndex = Integer.valueOf(rs
					.getInt(QiOptionsVO.COLUMN_ORDER_INDEX));

			return new QiOptionsVO(defaultQiOptionsId, objectTypeId, queryId,
					querySelected, collapseResult, orderIndex);
		}

		public String getSelectColumns() {
			String[] columns = new String[] {
					QiOptionsVO.COLUMN_DFLT_QI_OPTN_SEQ_ID,
					QiOptionsVO.COLUMN_OBJ_TYP_SEQ_ID,
					QiOptionsVO.COLUMN_QRY_SEQ_ID,
					QiOptionsVO.COLUMN_QRY_SELECTED,
					QiOptionsVO.COLUMN_COLLAPSE_RESULT,
					QiOptionsVO.COLUMN_ORDER_INDEX };
			return StringUtils.join(columns, ",");
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public int createDefaultQuery(String sso, int objectTypeId, int queryId,
			int orderIndex, boolean querySelected, boolean collapseResult)
			throws PWiException {
		StringBuilder builder = new StringBuilder();
		builder.append("BEGIN INSERT INTO ");
		builder.append(QiOptionsVO.TABLE);
		builder.append(" (");
		String[] insertColumns = new String[] {QiOptionsVO.COLUMN_DFLT_QI_OPTN_SEQ_ID,QiOptionsVO.COLUMN_SSO_ID,
				QiOptionsVO.COLUMN_OBJ_TYP_SEQ_ID,
				QiOptionsVO.COLUMN_QRY_SEQ_ID, QiOptionsVO.COLUMN_ORDER_INDEX,
				QiOptionsVO.COLUMN_QRY_SELECTED,
				QiOptionsVO.COLUMN_COLLAPSE_RESULT, PWiBaseVO.COLUMN_CRTN_DT,
				PWiBaseVO.COLUMN_CRTD_BY, PWiBaseVO.COLUMN_LST_UPDT_DT,
				PWiBaseVO.COLUMN_LST_UPDTD_BY };
		builder.append(StringUtils.join(insertColumns, ","));
		builder.append(") VALUES(PLMR.PWI_DFLT_QI_OPTN_SEQ.nextval,?,?,?,?,?,?,SYSDATE,?,SYSDATE,?) RETURNING ");
		builder.append(QiOptionsVO.COLUMN_DFLT_QI_OPTN_SEQ_ID);
		builder.append(" INTO ?; END;");

		Connection connection = null;
		CallableStatement statement = null;
		try {
			connection = jdbcTemplate.getDataSource().getConnection();
			statement = connection.prepareCall(builder.toString());

			// Set input parameters
			int index = 1;
			statement.setString(index, sso);
			index++;
			statement.setInt(index, objectTypeId);
			index++;
			statement.setInt(index, queryId);
			index++;
			statement.setInt(index, orderIndex);
			index++;
			statement.setString(index, querySelected ? "Y" : "N");
			index++;
			statement.setString(index, collapseResult ? "Y" : "N");
			index++;
			statement.setString(index, sso);
			index++;
			statement.setString(index, sso);
			index++;

			// Set output parameters
			statement.registerOutParameter(index, Types.NUMERIC);

			// Execute query
			statement.execute();

			// Retrieve primary key
			int id = statement.getInt(index);

			return id;
		} catch (SQLException e) {
			throw new PWiException(e);
		} finally {
			if (statement != null) {
				try {
					statement.close();
				} catch (SQLException e) {
					throw new PWiException(e);
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					throw new PWiException(e);
				}
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public int updateDefaultQiOption(int id, String sso, int objectTypeId,
			int queryId, int orderIndex, boolean querySelected,
			boolean collapseResult) {
		UpdateDefaultQueriesSetter pss = new UpdateDefaultQueriesSetter(sso,
				id, objectTypeId, queryId, orderIndex, querySelected,
				collapseResult);

		return jdbcTemplate.update(pss.getSql(), pss);
	}

	private static class UpdateDefaultQueriesSetter implements
			PreparedStatementSetter {
		private String sso;
		private int id;
		private int objectTypeId;
		private int queryId;
		private int orderIndex;
		private boolean selected;
		private boolean collapseResult;

		public UpdateDefaultQueriesSetter(String sso, int id, int objectTypeId,
				int queryId, int orderIndex, boolean selected,
				boolean collapseResult) {
			this.sso = sso;
			this.id = id;
			this.objectTypeId = objectTypeId;
			this.queryId = queryId;
			this.orderIndex = orderIndex;
			this.selected = selected;
			this.collapseResult = collapseResult;
		}

		public void setValues(PreparedStatement statement) throws SQLException {
			// Set input parameters
			int index = 1;
			statement.setString(index, sso);
			index++;
			statement.setInt(index, objectTypeId);
			index++;
			statement.setInt(index, queryId);
			index++;
			statement.setInt(index, orderIndex);
			index++;
			statement.setString(index, selected ? "Y" : "N");
			index++;
			statement.setString(index, collapseResult ? "Y" : "N");
			index++;
			statement.setString(index, sso);
			index++;
			statement.setInt(index, id);
		}

		public String getSql() {
			StringBuilder builder = new StringBuilder();
			builder.append("UPDATE ");
			builder.append(QiOptionsVO.TABLE);
			builder.append(" SET ");
			builder.append(QiOptionsVO.COLUMN_SSO_ID);
			builder.append(" = ?, ");
			builder.append(QiOptionsVO.COLUMN_OBJ_TYP_SEQ_ID);
			builder.append(" = ?, ");
			builder.append(QiOptionsVO.COLUMN_QRY_SEQ_ID);
			builder.append(" = ?, ");
			builder.append(QiOptionsVO.COLUMN_ORDER_INDEX);
			builder.append(" = ?, ");
			builder.append(QiOptionsVO.COLUMN_QRY_SELECTED);
			builder.append(" = ?, ");
			builder.append(QiOptionsVO.COLUMN_COLLAPSE_RESULT);
			builder.append(" = ?, ");
			builder.append(QiOptionsVO.COLUMN_LST_UPDT_DT);
			builder.append(" = SYSDATE, ");
			builder.append(QiOptionsVO.COLUMN_LST_UPDTD_BY);
			builder.append(" = ? WHERE ");
			builder.append(QiOptionsVO.COLUMN_DFLT_QI_OPTN_SEQ_ID);
			builder.append(" = ?");
			return builder.toString();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void deleteOptionsForQueryObject(Integer queryId,
			List<Integer> objectTypeIds) {
		// Define prepared statement setter
		RemoveOptionsForQueryObjectSetter pss = new RemoveOptionsForQueryObjectSetter(
				queryId, objectTypeIds);

		// Run delete statement on database
		jdbcTemplate.update(pss.getSql(), pss);
	}

	private static class RemoveOptionsForQueryObjectSetter implements
			PreparedStatementSetter {
		private Integer queryId;
		private List<Integer> objectTypeIds;

		public RemoveOptionsForQueryObjectSetter(Integer queryId,
				List<Integer> objectTypeIds) {
			this.queryId = queryId;
			this.objectTypeIds = objectTypeIds;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			int index = 1;
			ps.setInt(index, queryId.intValue());
			index++;
			for (Integer objectTypeId : objectTypeIds) {
				ps.setInt(index, objectTypeId.intValue());
				index++;
			}
		}

		public String getSql() {
			// Retrieve SQL with bind parameters
			StringBuilder builder = new StringBuilder();
			builder.append("DELETE FROM ");
			builder.append(QiOptionsVO.TABLE);
			builder.append(" WHERE ");
			builder.append(QiOptionsVO.COLUMN_QRY_SEQ_ID);
			builder.append("=? AND ");
			builder.append(QiOptionsVO.COLUMN_OBJ_TYP_SEQ_ID);
			builder.append(" IN (");
			builder.append(DaoUtil.getInstance().generateInClausePlaceholders(
					objectTypeIds.size()));
			builder.append(")");
			return builder.toString();
		}
	}
}
