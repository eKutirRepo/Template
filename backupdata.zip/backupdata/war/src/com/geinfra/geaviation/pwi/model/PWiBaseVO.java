package com.geinfra.geaviation.pwi.model;

import java.util.Date;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 11, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : PWiBaseVO - base object holding creation/update info.
 * 
 * Revision Log Aug 11, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiBaseVO {
	public static final String COLUMN_CRTN_DT = "CRTN_DT";
	public static final String COLUMN_CRTD_BY = "CRTD_BY";
	public static final String COLUMN_LST_UPDT_DT = "LST_UPDT_DT";
	public static final String COLUMN_LST_UPDTD_BY = "LST_UPDTD_BY";

	private Date crtnDt;
	private String crtdBy;
	private Date lstUpdtDt;
	private String lstUpdtdBy;

	public PWiBaseVO() {
	}

	public PWiBaseVO(Date crtDt, String crtBy, Date updDt, String updBy) {
		if (crtDt != null)
			this.crtnDt = new Date(crtDt.getTime());
		this.crtdBy = crtBy;
		if (updDt != null)
			this.lstUpdtDt = new Date(updDt.getTime());
		this.lstUpdtdBy = updBy;
	}

	public Date getCrtnDt() {
		return crtnDt != null ? new Date(crtnDt.getTime()) : null;
	}

	public void setCrtnDt(Date crtnDt) {
		if (crtnDt != null)
			this.crtnDt = new Date(crtnDt.getTime());
	}

	public String getCrtdBy() {
		return crtdBy;
	}

	public void setCrtdBy(String crtdBy) {
		this.crtdBy = crtdBy;
	}

	public Date getLstUpdtDt() {
		return lstUpdtDt != null ? new Date(lstUpdtDt.getTime()) : null;
	}

	public void setLstUpdtDt(Date lstUpdtDt) {
		if (lstUpdtDt != null)
			this.lstUpdtDt = new Date(lstUpdtDt.getTime());
	}

	public String getLstUpdtdBy() {
		return lstUpdtdBy;
	}

	public void setLstUpdtdBy(String lstUpdtdBy) {
		this.lstUpdtdBy = lstUpdtdBy;
	}
}
