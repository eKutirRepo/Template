package com.geinfra.geaviation.pwi.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.AdminSettingsVO;
import com.geinfra.geaviation.pwi.util.QueryConstants;
import com.geinfra.geaviation.pwi.util.QueryLoader;

/**
 * 
 * Project : Product Lifecycle Management Date Written : May 19, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : QueryGroupDAOImpl
 * 
 * Revision Log May 19, 2010 | v1.0.
 * --------------------------------------------------------------
 */

public class AdminSettingsDAOImpl extends PWiDAO implements AdminSettingsDAO {
	private static final Logger LOGGER = Logger
			.getLogger(AdminSettingsDAOImpl.class);

	public AdminSettingsVO getSetting(final String settingName)
			throws PWiException {
		String searchQuery = QueryLoader.getQuery(QueryConstants.GET_SETTING);
		try {
			PreparedStatementSetter pss = new GetSettingPreparedStatementSetter(
					settingName);

			ParameterizedRowMapper<AdminSettingsVO> mapper = new GetSettingParameterizedRowMapper();

			@SuppressWarnings("unchecked")
			List<AdminSettingsVO> result = (List<AdminSettingsVO>) getJdbcTemplate()
					.query(searchQuery, pss, mapper);
			if (result.size() > 0) {
				if (result.size() > 1) {
					LOGGER.warn("Query for setting with name " + settingName
							+ " returned more than one result!");
				}
				return result.get(0);
			}
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
		return null;
	}

	private static class GetSettingPreparedStatementSetter implements
			PreparedStatementSetter {
		private String settingName;

		public GetSettingPreparedStatementSetter(String settingName) {
			this.settingName = settingName;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setString(1, settingName);
		}
	}

	private static class GetSettingParameterizedRowMapper implements
			ParameterizedRowMapper<AdminSettingsVO> {
		public AdminSettingsVO mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			AdminSettingsVO adminSettingVO = new AdminSettingsVO();
			adminSettingVO.setAppSeqId(rs.getString("appSeqId"));
			adminSettingVO.setAppPrmNm(rs.getString("appPrmNm"));
			adminSettingVO.setAppParVal(rs.getString("appParVal"));
			adminSettingVO.setCrtrSsoid(rs.getString("crtrSsoId"));
			adminSettingVO.setAppparmdttm(rs.getString("appParmDtTm"));

			return adminSettingVO;
		}
	}

	/**
	 * Create the specified setting.
	 * 
	 * @param name
	 * @param value
	 * @param updateSso
	 * @throws PWiException
	 */
	public void createSetting(String name, String value, String updateSso)
			throws PWiException {
		try {
			StringBuilder builder = new StringBuilder();
			builder.append("INSERT INTO PWi_APPLCTN_PARAMETER");
			builder.append(" (APLCTN_PRM_SEQ_ID, APLCTN_PRM_NM, APLCTN_PRM_VAL");
			builder.append(", CRTR_SSO_ID, APLCTN_PRM_DTTM, CRTN_DT");
			builder.append(", CRTD_BY, LST_UPDT_DT, LST_UPDTD_BY)");
			builder.append(" VALUES (PLMR.PWI_APLCTN_PRM_SEQ.NEXTVAL,?,?,?,SYSDATE,SYSDATE,?,SYSDATE,?)");

			CreateSettingPreparedStatementSetter pss = new CreateSettingPreparedStatementSetter(
					name, value, updateSso);

			getJdbcTemplate().update(builder.toString(), pss);
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}

	private static class CreateSettingPreparedStatementSetter implements
			PreparedStatementSetter {
		private String settingName;
		private String settingValue;
		private String updateSso;

		public CreateSettingPreparedStatementSetter(String settingName,
				String settingValue, String updateSso) {
			this.settingName = settingName;
			this.settingValue = settingValue;
			this.updateSso = updateSso;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setString(1, settingName);
			ps.setString(2, settingValue);
			ps.setString(3, updateSso);
			ps.setString(4, updateSso);
			ps.setString(5, updateSso);
		}
	}

	/**
	 * Updates the value of an existing setting by name.
	 * 
	 * @param name
	 * @param value
	 * @param updateSso
	 * @throws PWiException
	 */
	public void updateSetting(String name, String value, String updateSso)
			throws PWiException {
		try {
			StringBuilder builder = new StringBuilder();
			builder.append("UPDATE PWi_APPLCTN_PARAMETER");
			builder
					.append(" SET APLCTN_PRM_VAL=?, LST_UPDT_DT=SYSDATE, LST_UPDTD_BY=?");
			builder.append(" WHERE APLCTN_PRM_NM=?");

			UpdateSettingPreparedStatementSetter pss = new UpdateSettingPreparedStatementSetter(
					name, value, updateSso);

			getJdbcTemplate().update(builder.toString(), pss);
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}

	private static class UpdateSettingPreparedStatementSetter implements
			PreparedStatementSetter {
		private String settingName;
		private String settingValue;
		private String updateSso;

		public UpdateSettingPreparedStatementSetter(String settingName,
				String settingValue, String updateSso) {
			this.settingName = settingName;
			this.settingValue = settingValue;
			this.updateSso = updateSso;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setString(1, settingValue);
			ps.setString(2, updateSso);
			ps.setString(3, settingName);
		}
	}
}
