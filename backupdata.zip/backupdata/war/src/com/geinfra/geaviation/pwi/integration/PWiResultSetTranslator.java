package com.geinfra.geaviation.pwi.integration;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBException;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.PWiResultSet;
import com.geinfra.geaviation.pwi.model.QueryResultColumn;

/**
 * 
 * Project      : Product Lifecycle Management Intelligence
 * Date Written : Aug 6, 2010
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : PWiResultSetTranslator - class to translate a result set into
 * data lists for display.
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * 2012.12.18 pH  replaced GEAEResultSet with PWiResultSet, renamed accordingly
 * --------------------------------------------------------------
 */
public class PWiResultSetTranslator {
	private static final PWiResultSetTranslator INSTANCE = new PWiResultSetTranslator();

	private PWiResultSetTranslator() {
		// nothing to do here.
		// private because this is a singleton.
	}

	public static PWiResultSetTranslator getInstance() {
		return INSTANCE;
	}

	/**
	 * Extracts the column headings from the result set
	 * 
	 * @param rs
	 * @return list of column headings
	 */
	public List<QueryResultColumn> getColumnList(PWiResultSet rs) {
		// Extract column headings from result set
		List<QueryResultColumn> columns = new ArrayList<QueryResultColumn>();
		int numCols = rs.getColumnCount();
		for (int resultSetIndex = 1; resultSetIndex <= numCols; resultSetIndex++) {
			QueryResultColumn column = new QueryResultColumn(rs
					.getColumnName(resultSetIndex), rs
					.getColumnHeading(resultSetIndex),rs.getColumnType(resultSetIndex));
			columns.add(column);
		}
		return columns;
	}

	/**
	 * Converts the result set into a table of query result value objects.
	 * 
	 * @param rs
	 * @return table of query result value objects
	 * @throws JAXBException
	 * @throws PWiException
	 */
	// TODO pH 2012.12: if we are using Strings in PWiResultSet, skip this.
	public List<List<String>> getDataList(PWiResultSet rs)
			throws JAXBException, PWiException {
		// Extract data from result set
		List<List<String>> resultTable = new ArrayList<List<String>>();
		int numCols = rs.getColumnCount();
		if (rs.size() > 0) {
			rs.first();
			do {
				List<String> resultRow = new java.util.ArrayList<String>();
				for (int columnIndex = 1; columnIndex <= numCols; columnIndex++) {
					// Extract value from result set
					Object object = rs.getObject(columnIndex);
					String value = object != null ? object.toString() : "";

					// Add to row
					resultRow.add(value);
				}
				resultTable.add(resultRow);
			} while (rs.next());
		}
		return resultTable;
	}
}
