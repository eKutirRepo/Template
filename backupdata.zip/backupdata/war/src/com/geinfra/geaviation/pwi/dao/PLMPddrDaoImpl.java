/**
 * Copyright (C) 2012 GE Infra.
 * All rights reserved 
 * @FileName PLMPddrDaoImpl.java
 * @Creation date: 27-Mar-2012
 * @version 2.0.1
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMPddrData;
import com.geinfra.geaviation.pwi.data.PLMPddrReportData;
import com.geinfra.geaviation.pwi.data.PLMPddrSearchData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.SpreadsheetWriter;


/**
 * PLMPddrDaoImpl s the DAO implementation class used for SBoM Add/Update
 * usecase.
 */
public class PLMPddrDaoImpl extends SimpleJdbcDaoSupport implements
   PLMPddrDaoIfc { 	
	
   	
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");

	/**
	 * Holds the Logger
	 */
	private static final Logger LOG = Logger.getLogger(PLMPddrDaoImpl.class);
	/**
	 * Holds the XML_ENCODING
	 */
	private static final String XML_ENCODING = "UTF-8";
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
		 
	}

	/**
	 * This method is used for getChildForParent
	 * 
	 * @param mplNumber
	 * @param level
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMPddrData> getChildForParent(List<String> mplNumber,
			String level) throws PLMCommonException {
		//LOG.info("Entering getChildForParent() method----PLMPddrDaoImpl---");
		List<PLMPddrData> searchData = new ArrayList<PLMPddrData>();
		List<PLMPddrData> searchDatatemp = null;
		for (String data : mplNumber) {
			
			//LOG.info("GET getChildForParent First Level Query :::::::  "+ PLMOfflineQueries.GETPARTFAMILYFORLIBRARY);

			searchDatatemp = getSimpleJdbcTemplate().query(
					PLMOfflineQueries.GETPARTFAMILYFORLIBRARY, new GetPartFamily(), data);
			searchData.addAll(searchDatatemp);
		}
		//LOG.info("Exiting getChildForParent() method----PLMPddrDaoImpl---");
		return searchData;
	}

	/**
	 * ParameterizedRowMapper for fetching the MPL ML data
	 */
	//private static ParameterizedRowMapper<PLMPddrData> getPartFamily = new ParameterizedRowMapper<PLMPddrData>() {
	private static final class GetPartFamily implements ParameterizedRowMapper<PLMPddrData>{	
	public PLMPddrData mapRow(ResultSet rs, int rowNum) throws SQLException {
			PLMPddrData data = new PLMPddrData();
			data.setParentItem(PLMUtils
					.checkNullVal(rs.getString("TO_NAME")));
			data.setChildItem(PLMUtils
					.checkNullVal(rs.getString("FROM_NAME")));
			data.setLevel(rs.getInt("LVL") + 1);
			data.setSbomID(rs.getString("TO_ID"));
			data.setTopLevelParentItem(PLMUtils.checkNullVal(rs
					.getString("FROM_NAME")));
			data.setState(rs.getString("STATE"));
			data.setDescription(PLMUtils.checkNullVal("TestDesc"));
			data.setChildItemPrefix(PLMUtils.checkNullVal("TestPref"));
			return data;
		}
	// };
	}

	/**
	 * This method is used for getChildForParentList
	 * 
	 * @param topmplNumber
	 * @param navigList
	 * @param level
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMPddrData> getChildForParentList(String topmplNumber,
			List<PLMPddrData> navigList, int level) throws PLMCommonException {
		//LOG.info("Entering getChildForParentList() method----PLMPddrDaoImpl---");
		List<String> childStr = new ArrayList<String>();
		for (PLMPddrData data : navigList) {
			childStr.add(data.getParentItem());
		}
		//LOG.info("Level>>>" + level);
		List<PLMPddrData> searchData = null;
		String makStr = PLMUtils.getChildString(childStr);
		if (makStr != null && makStr.length() > 2) {
			searchData = getSimpleJdbcTemplate().query(
					PLMOfflineQueries.GETCHILDFORPFONE + makStr
					+ PLMOfflineQueries.GETCHILDFORPFTWO,
					new GetPartFamily(), level);
		}
		//LOG.info("Exiting getChildForParentList() method----PLMPddrDaoImpl---");		
		return searchData;
	}

	/**
	 * This method is used for searchItemExplorer
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMPddrSearchData> searchItemExplorer() throws PLMCommonException {
		//LOG.info("Entering searchItemsExplore() method----PLMPddrDaoImpl---");
		List<PLMPddrSearchData> searchData = null;
		//LOG.info("Retrieval of Library Name Query is : " + PLMOfflineQueries.GET_LIBRARY_DETAILS);
		searchData = getSimpleJdbcTemplate().query(
				PLMOfflineQueries.GET_LIBRARY_DETAILS, new SearchLibraryMapper());
		//LOG.info("Exiting searchItemsExplore() method----PLMPddrDaoImpl---");		
		return searchData;
	}
	
	/**
	 * Row mapper for searching MPL number returns List of Strings
	 */
	//private static ParameterizedRowMapper<PLMPddrSearchData> searchLibraryMapper = new ParameterizedRowMapper<PLMPddrSearchData>() {
	private static final class SearchLibraryMapper implements ParameterizedRowMapper<PLMPddrSearchData>{	
	public PLMPddrSearchData mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PLMPddrSearchData data = new PLMPddrSearchData();
			data.setLibraryName(rs.getString("LIBRARY_NAME"));
			return data;			
		}
	//	};
	}
	
	/**
	 * This method is used for getPFDetails
	 * 
	 * @param nodeTitleP
	 * @throws PLMCommonException
	 */
	public PLMPddrData getPFDetails(String nodeTitleP) throws PLMCommonException {
		//LOG.info("Entering getPFDetails() method----");
		PLMPddrData searchData = null;
		
		//LOG.info("Selected Part Family:::::::::----"+nodeTitleP);
		//LOG.info("Part Family Details Retriveal Query:::::::::----"+PLMOfflineQueries.GET_PF_DETAILS);
			searchData = getSimpleJdbcTemplate().queryForObject(PLMOfflineQueries.GET_PF_DETAILS, 
					new GetDetailsMapper(), new Object[] { nodeTitleP });
			
		//LOG.info("Part Family Count Query:::::::::----"+PLMOfflineQueries.GET_PF_COUNT);
		int pfCount = getSimpleJdbcTemplate().queryForInt(PLMOfflineQueries.GET_PF_COUNT, 
				new Object[] { nodeTitleP });
			
		if(searchData == null){
			searchData = new PLMPddrData();
			searchData.setPartFamily("-");
			searchData.setPartDesc("-");
			searchData.setPartState("-");
			searchData.setPartOwnerSso("-");
			searchData.setPartOwnerName("-");
			searchData.setPartBaseNum("-");
			searchData.setPartRDO("-");
			searchData.setPartSrcOrgDate("-");
			searchData.setPartSrcModDate("-");
			searchData.setPartEEDWUpdateDate("-");
		} else {
			searchData.setPartCount(pfCount);
		}
		//LOG.info("Exiting getPFDetails() method----PLMPddrMB---");
		return searchData;
	}
	
	/**
	 * Row mapper for searching MPL number returns List of Strings
	 */
	//private static ParameterizedRowMapper<PLMPddrData> getDetailsMapper = new ParameterizedRowMapper<PLMPddrData>() {
	private static final class GetDetailsMapper implements ParameterizedRowMapper<PLMPddrData>{	
	public PLMPddrData mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
			PLMPddrData data = new PLMPddrData();
			data.setPartFamily(rs.getString("PART_FAMILY"));
			data.setPartDesc(rs.getString("DESCRIPTION"));
			data.setPartState(rs.getString("STATE"));
			data.setPartOwnerSso(rs.getString("OWNER_SSO"));
			data.setPartOwnerName(rs.getString("OWNER_NAME"));
			data.setPartBaseNum(rs.getString("PART_FAMILY_BASE_NUM"));
			data.setPartRDO(rs.getString("RDO"));
			data.setPartSrcOrgDate(df.format(rs.getDate("SOURCE_ORIG_DATE")));
			data.setPartSrcModDate(df.format(rs.getDate("SOURCE_MOD_DATE")));
			data.setPartEEDWUpdateDate(df.format(rs.getDate("EEDW_UPDATE_DT")));
			//data.setPartCount(rs.getInt("PF_COUNT"));
			return data;			
		}
	//	};
	}
	/**
	 * Row mapper for getting pddr Result count
	 */
	//private static ParameterizedRowMapper<PLMPddrData> tdPddrResultMapperCount = new ParameterizedRowMapper<PLMPddrData>() {
	private static final class TdPddrResultMapperCount implements ParameterizedRowMapper<PLMPddrData>{ 	
	public PLMPddrData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMPddrData tempData = new PLMPddrData();
			tempData.setTopPartName(rs.getString(PLMConstants.PDDR_COL_TOP_PART));
			tempData.setTopPartRev(rs.getString(PLMConstants.PDDR_COL_TOP_PART_REV));
			tempData.setCount(rs.getInt(PLMConstants.PDDR_COL_CNT));
			return tempData;
		}
	// };
	}
	
	/**
	 * Row mapper for getting pddr Result mapper1
	 */
	//private static ParameterizedRowMapper<PLMPddrReportData> tdPddrResultMapper1 = new ParameterizedRowMapper<PLMPddrReportData>() {
	private static final class TdPddrResultMapper1 implements ParameterizedRowMapper<PLMPddrReportData>{	
	public PLMPddrReportData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMPddrReportData tempData = new PLMPddrReportData();
			tempData.setTopPartName(rs.getString(PLMConstants.PDDR_COL_TOP_PART));
			tempData.setTopPartRev(rs.getString(PLMConstants.PDDR_COL_TOP_PART_REV));
			tempData.setParentPartName(rs.getString(PLMConstants.PDDR_COL_PARENT_ITEM));
			tempData.setParentPartRev(rs.getString(PLMConstants.PDDR_COL_PARENT_REV));
			tempData.setParentPartType(rs.getString(PLMConstants.PDDR_COL_PARENT_TYPE));
			tempData.setChildPartName(rs.getString(PLMConstants.PDDR_COL_CHILD_ITEM));
			tempData.setChildPartRev(rs.getString(PLMConstants.PDDR_COL_CHILD_REV));
			tempData.setChildPartType(rs.getString(PLMConstants.PDDR_COL_CHILD_TYPE));
			tempData.setChildPartState(rs.getString(PLMConstants.PDDR_COL_PART_STATE));
			tempData.setChildPartDesc(rs.getString(PLMConstants.PDDR_COL_PART_DESCRIPTION));
			tempData.setBomLevel(rs.getInt(PLMConstants.PDDR_COL_BOM_LEVEL));
			tempData.setLogicalIndicator(rs.getString(PLMConstants.PDDR_COL_LOGICAL_INDICATOR));
			tempData.setDocumentName(rs.getString(PLMConstants.PDDR_COL_DOC_NAME));
			tempData.setDocumentRev(rs.getString(PLMConstants.PDDR_COL_DOC_REV));
			tempData.setDocumentType(rs.getString(PLMConstants.PDDR_COL_DOC_TYPE));
			tempData.setDocumentState(rs.getString(PLMConstants.PDDR_COL_DOC_STATE));
			tempData.setDocumentDesc(rs.getString(PLMConstants.PDDR_COL_DOC_DESCRIPTION));
			//tempData.setTypeofDoc(rs.getString(PLMConstants.PDDR_COL_GE_TYPE_OF_DOC));
			//tempData.setRowKey(rs.getInt(PLMConstants.PDDR_COL_ROW_KEY));
			tempData.setRowKey(0);
			return tempData;
		}
	//	};
	}
	
	/**
	 * Row mapper for getting pddr Result mapper1
	 */
	//private static ParameterizedRowMapper<PLMPddrData> tdPddrResultMapper2 = new ParameterizedRowMapper<PLMPddrData>() {
	private static final class TdPddrResultMapper2 implements ParameterizedRowMapper<PLMPddrData>{	
	public PLMPddrData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMPddrData tempData = new PLMPddrData();
			tempData.setChildPartId(PLMUtils.checkNullVal(rs.getString("TO_ID")));
			tempData.setChildPartName(PLMUtils.checkNullVal(rs.getString("TO_NAME")));
			tempData.setChildPartRev(PLMUtils.checkNullVal(rs.getString("TO_REVISION")));
			tempData.setChildPartType(PLMUtils.checkNullVal(rs.getString("TO_TYPE")));
			tempData.setPathFlag("");
			return tempData;
		}
	//	};
	}
	
    
    /**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}
	
	/* (non-Javadoc)
	 * @see com.geinfra.geaviation.pwi.dao.PLMPddrDaoIfc#getTdPddrResult(java.lang.String, java.lang.String, boolean)
	 */
	
	
	/**
	 *  This method is used for getTdPddrResult
	 *  
	 *  @param pfName,sso
	 *  @return PLMPddrData
	 *  @throws PLMCommonException
	 * 
	 */
	@SuppressWarnings("unchecked")
	public PLMPddrData getTdPddrResult(String pfName, String sso) throws PLMCommonException {
		List<PLMPddrData> pddrTdResultList =  new ArrayList<PLMPddrData>();
		List<PLMPddrReportData> pddrTdRepResultList =  new ArrayList<PLMPddrReportData>();	
		List<PLMPddrReportData> excelPddrTdRepResultList =  new ArrayList<PLMPddrReportData>();
		List<PLMPddrData> pddrPFList =  new ArrayList<PLMPddrData>();
		LOG.info("Entering getTdPddrResult() method----");
		PLMPddrData searchData = null;
		Map<String, Object> varMap = new HashMap<String, Object>();
		Map<String,Double> compressedFilesWithSize = new HashMap<String,Double>();
		String filePathZip = "";
		String folderPath = "";
		String fileName = "";
		String pName = "";
		String pRev = "";
		PLMPddrData data = null;		
		List<List<String>> topPartList = null;
		List<String> topPartMaxList = null;
		List<String> topPartsLst = null;
		List<String> filePathXlsLst = new ArrayList<String>();
		int lstSize = 0;
		int prevLstSize = 0;
		fileName = resourceBundle.getString("OFFLINE_RPT_DIR") + 
						resourceBundle.getString("PDDR_TEMPLATE_NAME");
		
		int maxLimitVal = Integer.parseInt(PLMUtils.getMessage(PLMConstants.PDDR_MAX_LIMIT));
		int maxLimit = Integer.parseInt(PLMUtils.getMessage(PLMConstants.PDDR_EXCEL_MAX_LIMIT));
		
		int listCount = 0;
		int excelListCount = 0;
		int totlExcelListCount = 0;
		int lpCntr = Integer.parseInt(resourceBundle.getString("PDDR_LOOP_CNTR"));
		
		int recCount1 = 0;
	   	int recCount2 = lpCntr;   
	   	
	   	boolean fileFlag = true;
	   	//String tempXmlFile = "";
		Writer fw = null;
		SpreadsheetWriter sw = null;
		int rowNum = 3;
		 Map<String, Object> params = new HashMap<String, Object>();

		try{			
			String folPath = resourceBundle.getString("OFFLINE_RPT_DIR");
			Date uniqDate = new Date();
	    	final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
			String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
			folderPath = folPath + resourceBundle.getString("PDDR_REPORT_NAME") + " - " + sso + " - " + uniqTime;
			filePathZip = folderPath + ".zip";
			//String filePathXls = "";
			
			File fol = new File(folPath);
			if(fol.exists()){
				fol = new File(folderPath);
				fol.mkdir();
				filePathXlsLst = new ArrayList<String>();
			}
			//LOG.info("Create New Directory for files ---------- " + fol);
			
			LOG.info("Query to get Parts under PF: " + PLMOfflineQueries.SEL_PDDR_PF_DATA);
			pddrPFList = getSimpleJdbcTemplate().query(PLMOfflineQueries.SEL_PDDR_PF_DATA,
					new TdPddrResultMapper2(), new Object[]{pfName});
			
			int pfCount = pddrPFList.size();
			//LOG.info("Total Part Family Count in list >>> " + pddrPFList.size());
			
			
			int val = 0;
			int loopCount = 0;
			if (pfCount > lpCntr) {
				loopCount = pfCount/lpCntr;				
				val = pfCount - (lpCntr * loopCount);
				if (val > PLMConstants.N_0) {
					loopCount++;					
				}
			} else {
				loopCount = 1;
			}
			
			varMap.put("fileName", fileName);
			varMap.put("folderPath", folderPath);
			varMap.put("filePathXlsLst", filePathXlsLst);
			varMap.put("fileFlag", fileFlag);
			
			for (int i = 0; i < loopCount; i++) {
				LOG.info("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ LOOP COUNT: " + i + " of " + loopCount+" for report = "+pfName);
				if (i == loopCount - 1) {
					recCount2 = pfCount;			
					//LOG.info("when loop count - 1 then @@@@@@" + recCount2);
				}
				
				final List<PLMPddrData> pfList = new ArrayList<PLMPddrData>(pddrPFList.subList(recCount1, recCount2));
				//LOG.info("recCount1 >>>> " + recCount1);
				//LOG.info("recCount2 >>>> " + recCount2);
				

				LOG.info("Query to Insert Data into CDR_GTT_PFDDR_PF_DATA: " + PLMOfflineQueries.INSERT_PFDDR_PF_DATA);
				int[] updatePFCount = null;
				updatePFCount  = getSimpleJdbcTemplate().getJdbcOperations().batchUpdate(
						PLMOfflineQueries.INSERT_PFDDR_PF_DATA, new BatchPreparedStatementSetter() 
				{
				public void setValues(PreparedStatement ps,int iCount)throws SQLException {
					//ps.setInt(1, pfList.get(iCount).getRowKey());					
					ps.setString(1, pfList.get(iCount).getChildPartId());
					ps.setString(2, pfList.get(iCount).getChildPartType());
					ps.setString(3, pfList.get(iCount).getChildPartName());
					ps.setString(4, pfList.get(iCount).getChildPartRev());
				}
				public int getBatchSize() {
					return pfList.size();
				}
				});
				LOG.info("Total PF inserted Records : " + updatePFCount.length);
				LOG.info("Number of Parts Mapped to selected PF >>>> " + pfList.size());
				updatePFCount = null;
				pfList.clear();
				
				/*String INSERT_PDDR_PF_Query =  (PLMOfflineQueries.INSERT_PFDDR_PF_DATA).replace("FROM_NAME= ?", 
						"FROM_NAME= '" + pfName + "'");
				INSERT_PDDR_PF_Query = INSERT_PDDR_PF_Query.replace("ROW_KEY BETWEEN ? AND ?", "ROW_KEY BETWEEN " +
						+ recCount1 + " AND " + recCount2);
				//LOG.info("Query for insertion INSERT_PDDR_PF : " + INSERT_PDDR_PF_Query);
				getJdbcTemplate().execute(INSERT_PDDR_PF_Query);*/
				
				
				LOG.info("Collect Stats for PFDDR_PF_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_PF_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_PF_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_EBOM_DATA : " + PLMOfflineQueries.INSERT_PFDDR_EBOM_DATA);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_EBOM_DATA);
				
				LOG.info("Collect Stats for PFDDR_EBOM_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_EBOM_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_EBOM_DATA_COL_STATS);
				
				// PART_TO_DOC_DATA Query Starts Here
				/*LOG.info("Query for insertion INSERT_PFDDR_PART_TO_DOC_DATA : " + PLMOfflineQueries.INSERT_PFDDR_PART_TO_DOC_DATA);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_PART_TO_DOC_DATA);
				
				LOG.info("Collect Stats for PFDDR_PART_TO_DOC_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_PART_TO_DOC_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_PART_TO_DOC_DATA_COL_STATS);*/

				LOG.info("Query for insertion INSERT_PFDDR_PART_TO_DOC_DATA1 : " + PLMOfflineQueries.INSERT_PFDDR_PART_TO_DOC_DATA1);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_PART_TO_DOC_DATA1);
				
				LOG.info("Collect Stats for PFDDR_PART_TO_DOC_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_PART_TO_DOC_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_PART_TO_DOC_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_PART_TO_DOC_DATA2 : " + PLMOfflineQueries.INSERT_PFDDR_PART_TO_DOC_DATA2);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_PART_TO_DOC_DATA2);
				
				LOG.info("Collect Stats for PFDDR_PART_TO_DOC_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_PART_TO_DOC_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_PART_TO_DOC_DATA_COL_STATS);

				LOG.info("Query for insertion INSERT_PFDDR_PART_TO_DOC_DATA3 : " + PLMOfflineQueries.INSERT_PFDDR_PART_TO_DOC_DATA3);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_PART_TO_DOC_DATA3);
				
				LOG.info("Collect Stats for PFDDR_PART_TO_DOC_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_PART_TO_DOC_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_PART_TO_DOC_DATA_COL_STATS);
				// PART_TO_DOC_DATA Query Ends Here
				
				// REC_DATA Query Starts Here
				LOG.info("Query for insertion INSERT_PFDDR_REC_DATA_1 : " + PLMOfflineQueries.INSERT_PFDDR_REC_DATA_1);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_REC_DATA_1);
				
				LOG.info("Collect Stats for PFDDR_REC_DATA_COL_STATS 1 : " + PLMOfflineQueries.PFDDR_REC_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_REC_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_REC_DATA_2 : " + PLMOfflineQueries.INSERT_PFDDR_REC_DATA_2);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_REC_DATA_2);
				
				LOG.info("Collect Stats for PFDDR_REC_DATA_COL_STATS 2 : " + PLMOfflineQueries.PFDDR_REC_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_REC_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_REC_DATA_3 : " + PLMOfflineQueries.INSERT_PFDDR_REC_DATA_3);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_REC_DATA_3);
				
				LOG.info("Collect Stats for PFDDR_REC_DATA_COL_STATS 3 : " + PLMOfflineQueries.PFDDR_REC_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_REC_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_REC_DATA_4 : " + PLMOfflineQueries.INSERT_PFDDR_REC_DATA_4);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_REC_DATA_4);
				
				LOG.info("Collect Stats for PFDDR_REC_DATA_COL_STATS 4 : " + PLMOfflineQueries.PFDDR_REC_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_REC_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_REC_DATA_5 : " + PLMOfflineQueries.INSERT_PFDDR_REC_DATA_5);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_REC_DATA_5);
				
				LOG.info("Collect Stats for PFDDR_REC_DATA_COL_STATS 5 : " + PLMOfflineQueries.PFDDR_REC_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_REC_DATA_COL_STATS);
				
				//Commented for 2.1.6
				LOG.info("Collect Stats for PFDDR_REC_DATA_COL_STATS1 : " + PLMOfflineQueries.PFDDR_REC_DATA_COL_STATS1);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_REC_DATA_COL_STATS1);
				
				LOG.info("Collect Stats for PFDDR_REC_DATA_COL_STATS2 : " + PLMOfflineQueries.PFDDR_REC_DATA_COL_STATS2);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_REC_DATA_COL_STATS2); 
				// REC_DATA Query Ends Here
				
				// RPT_DATA Query Starts Here
				/*LOG.info("Query for insertion INSERT_PFDDR_RPT_DATA : " + PLMOfflineQueries.INSERT_PFDDR_RPT_DATA);
				getJdbcTemplate().execute(PLMQueryConstants.INSERT_PFDDR_RPT_DATA);
				
				LOG.info("Collect Stats for PFDDR_RPT_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMQueryConstants.PFDDR_RPT_DATA_COL_STATS);*/

				// Commented for 2.1.6
				LOG.info("Query for insertion INSERT_PFDDR_RPT_DATA1 : " + PLMOfflineQueries.INSERT_PFDDR_RPT_DATA1);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_RPT_DATA1);
				
				LOG.info("Collect Stats for PFDDR_RPT_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_RPT_DATA2 : " + PLMOfflineQueries.INSERT_PFDDR_RPT_DATA2);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_RPT_DATA2);
				
				LOG.info("Collect Stats for PFDDR_RPT_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_RPT_DATA3 : " + PLMOfflineQueries.INSERT_PFDDR_RPT_DATA3);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_RPT_DATA3);
				
				LOG.info("Collect Stats for PFDDR_RPT_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_RPT_DATA4 : " + PLMOfflineQueries.INSERT_PFDDR_RPT_DATA4);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_RPT_DATA4);
				
				LOG.info("Collect Stats for PFDDR_RPT_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_RPT_DATA5 : " + PLMOfflineQueries.INSERT_PFDDR_RPT_DATA5);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_RPT_DATA5);
				
				LOG.info("Collect Stats for PFDDR_RPT_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_RPT_DATA6 : " + PLMOfflineQueries.INSERT_PFDDR_RPT_DATA6);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_RPT_DATA6);
				
				LOG.info("Collect Stats for PFDDR_RPT_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_RPT_DATA7 : " + PLMOfflineQueries.INSERT_PFDDR_RPT_DATA7);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_RPT_DATA7);
				
				LOG.info("Collect Stats for PFDDR_RPT_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_RPT_DATA8 : " + PLMOfflineQueries.INSERT_PFDDR_RPT_DATA8);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_RPT_DATA8);
				
				LOG.info("Collect Stats for PFDDR_RPT_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_RPT_DATA9 : " + PLMOfflineQueries.INSERT_PFDDR_RPT_DATA9);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_RPT_DATA9);
				
				LOG.info("Collect Stats for PFDDR_RPT_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_RPT_DATA10 : " + PLMOfflineQueries.INSERT_PFDDR_RPT_DATA10);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_RPT_DATA10);
				
				LOG.info("Collect Stats for PFDDR_RPT_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_RPT_DATA11 : " + PLMOfflineQueries.INSERT_PFDDR_RPT_DATA11);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_RPT_DATA11);
				
				LOG.info("Collect Stats for PFDDR_RPT_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				
				LOG.info("Query for insertion INSERT_PFDDR_RPT_DATA12 : " + PLMOfflineQueries.INSERT_PFDDR_RPT_DATA12);
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PFDDR_RPT_DATA12);
				
				LOG.info("Collect Stats for PFDDR_RPT_DATA_COL_STATS : " + PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				getJdbcTemplate().execute(PLMOfflineQueries.PFDDR_RPT_DATA_COL_STATS);
				// RPT_DATA Query Ends Here
				
				LOG.info("Query to get Top Parts Count: " + PLMOfflineQueries.SEL_PFDDR_RPT_DATA_CNT);
				pddrTdResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.SEL_PFDDR_RPT_DATA_CNT,
						new TdPddrResultMapperCount());
				
				if (!PLMUtils.isEmptyList(pddrTdResultList)) {
				
					topPartMaxList = new ArrayList<String>();
					topPartList = new ArrayList<List<String>>();	
					int count = 0;
					int totCount = 0;
					topPartsLst = new ArrayList<String>();
					//LOG.info("*****************************************************************");
					//LOG.info("Form List to get results");
					int maxDiff = 0;
					
					if (i == 0) {
						maxDiff = maxLimitVal;
						//LOG.info("maxDiff = maxLimitVal @@@@@@@@@@@@@@@@@@@@@@@ " + i);
					} else {
						//LOG.info("maxDiff = maxLimitVal - lstSize; @@@@@@@@@@@@@@@@@@@@@@@ " + lstSize);
						//LOG.info("prevLstSize ---- " + prevLstSize);
						if (lstSize >= maxLimitVal) {
							lstSize = prevLstSize;
						}
						maxDiff = maxLimitVal - lstSize;
						//LOG.info("maxDiff = maxLimitVal - lstSize; @@@@@@@@@@@@@@@@@@@@@@@ " + lstSize);
					}
					//LOG.info("maxDiff value outside loop ====================== " + maxDiff);
					for (int k = 0; k < pddrTdResultList.size(); k++) {
						data = (PLMPddrData) pddrTdResultList.get(k);
						pName = data.getTopPartName();
						pRev = data.getTopPartRev();
						count = data.getCount();
						//LOG.info("Part Name >>> " + pName + " ---- Part Rev >>>> " + pRev + " -- Count >>> " + count);
						if (count > 0 && count < maxDiff) {
							totCount += count;
							topPartsLst.add(pName + "~" + pRev);
						} else if (count >= maxLimitVal) {
							//LOG.info("cond when count >= maxLimitVal");
							topPartMaxList.add(pName + "~" + pRev + "~" + count);
						}
						if (totCount >= maxDiff) {
							//LOG.info("totCount --- " + totCount);
							int diff = totCount - maxDiff;
							//LOG.info("diff ###### " + diff);
							if (diff > 0) { 
								totCount = totCount - count;
								//LOG.info("totCount after reducing by count ---- " + totCount);
								topPartList.remove(topPartsLst);
								topPartsLst.remove(pName + "~" + pRev);
							}
							maxDiff = maxLimitVal;
							//LOG.info("maxDiff value inside loop !!!!!!!!!!!!!!!!!! " + maxDiff);
							topPartList.add(topPartsLst);
							//LOG.info("topPartsLst size after diff cond --- " + topPartsLst.size());
							topPartsLst = new ArrayList<String>();
							totCount = 0;
							
							if (diff > 0) {
								topPartsLst.add(pName + "~" + pRev);
								totCount += count;
							}
						} 
					}	
					
					if (totCount < maxDiff && topPartsLst.size() > 0) {
						//LOG.info("totCount --- " + totCount);
						topPartList.add(topPartsLst);
						//LOG.info("topPartsLst size when totCount < maxLimitVal is false --- " + topPartsLst.size());
					}
					
					pddrTdResultList.clear();
					StringBuilder queryBldr = new StringBuilder();
					String query = "";
					String topPart = "";
					String[] top = new String[0];
					//LOG.info("*****************************************************************");
					LOG.info("topPartList size >>> " + topPartList.size()+" for report = "+pfName);
					for (int k = 0; k < topPartList.size(); k++) {
						topPartsLst = topPartList.get(k);
						LOG.info(pfName+" Parts Count <<<<<<<<<<<<<== "+topPartsLst.size());
						queryBldr = new StringBuilder();
						queryBldr.append(PLMOfflineQueries.SEL_PFDDR_RPT_DATA);
						
						// append where clause
						for (int x = 0; x < topPartsLst.size(); x++) {
							topPart = (String) topPartsLst.get(x);
							top = topPart.split("~");
							queryBldr.append("( TOP_PART = :TOPPRT"+x);
							params.put("TOPPRT"+x, top[0]);
							queryBldr.append(" AND TOP_PART_REV =:TOPREV"+x);
							params.put("TOPREV"+x, top[1]);
							queryBldr.append(") OR");
						}
						queryBldr = new StringBuilder(queryBldr.substring(0, queryBldr.length() - 2));
						queryBldr.append(" ) ORDER BY 1,2,3 ");
						
						
						topPartsLst.clear();
						LOG.info("Top Parts Query ****************START**************** ");
						pddrTdRepResultList = getNamedJdbcTemplate().query(queryBldr.toString(),params,new TdPddrResultMapper1());
						LOG.info("Top Parts Query ****************END**************** ");
						//LOG.info("*****************************************************************");
						if (!PLMUtils.isEmptyList(pddrTdRepResultList)) {
														
							listCount = pddrTdRepResultList.size();
							lstSize += listCount;
							prevLstSize = listCount;							
							totlExcelListCount += listCount;					
							//LOG.info("The results count for PDDR Report loop#" + k + " >>>> " + listCount);
							LOG.info("listCount = "+listCount+" excelListCount = "+excelListCount+" totlExcelListCount = "+totlExcelListCount+" maxLimit = "+maxLimit+" for report = "+pfName);
							if(totlExcelListCount > maxLimit){
								
								LOG.info("Writing data to excel rows count =========================================== "+(totlExcelListCount - listCount)+" for report = "+pfName);
								writeExcelFileUsingAppendedXML(varMap);
								LOG.info("Writing data to Excel completed....");
								prepareSpreadsheetWriter(varMap, pfName);
								rowNum = 3;
								totlExcelListCount = listCount;
								sw = (SpreadsheetWriter) varMap.get("sw");
								rowNum = appendDataToXML(sw, pddrTdRepResultList, rowNum);
								//varMap = writeExcelFileUsingXML(excelPddrTdRepResultList, pfName, varMap);
							}else{
								prepareSpreadsheetWriter(varMap, pfName);
								sw = (SpreadsheetWriter) varMap.get("sw");
								rowNum = appendDataToXML(sw, pddrTdRepResultList, rowNum);
								LOG.info("excelPddrTdRepResultList before adding "+totlExcelListCount+" for report = "+pfName);
							}
							
							pddrTdRepResultList.clear();
						}
					}
					int minCount;
					int maxCount;
					int diff = 0;
					query = PLMOfflineQueries.SEL_PFDDR_RPT_DATA_MAX;
					for (int k = 0; k < topPartMaxList.size(); k++) {
						topPart = (String) topPartMaxList.get(k);
						top = topPart.split("~");
						count = Integer.parseInt(top[2]);
						minCount = 1;
						maxCount = maxLimitVal;
						diff = count;
						while (diff >= 0) {
							LOG.info("Entered in to topPartMaxList >>>>>>>>>>>>>>>>> "+topPartMaxList.size());
							//LOG.info("Query to get top parts with max limit : " + query);
							pddrTdRepResultList = getSimpleJdbcTemplate().query(query,new TdPddrResultMapper1(),
									new Object[] {top[0], top[1], minCount, maxCount});
							
							if (!PLMUtils.isEmptyList(pddrTdRepResultList)) {								
								listCount = pddrTdRepResultList.size();
								lstSize += listCount;
								prevLstSize = listCount;
								excelListCount = excelPddrTdRepResultList.size();
								totlExcelListCount += listCount;
								//LOG.info("The results count for PDDR Report loop#" + k + " >>>> " + listCount);
								LOG.info("listCount = "+listCount+" excelListCount = "+excelListCount+" totlExcelListCount = "+totlExcelListCount+" maxLimit = "+maxLimit+" for report = "+pfName);
								if(totlExcelListCount > maxLimit){
									
									LOG.info("Writing data to excel rows count =========================================== "+(totlExcelListCount - listCount)+" for report = "+pfName);
									writeExcelFileUsingAppendedXML(varMap);
									LOG.info("Writing data to Excel completed....");
									prepareSpreadsheetWriter(varMap, pfName);
									
									rowNum = 3;
									totlExcelListCount = listCount;
									sw = (SpreadsheetWriter) varMap.get("sw");
									rowNum = appendDataToXML(sw, pddrTdRepResultList, rowNum);
														
								}else{
									prepareSpreadsheetWriter(varMap, pfName);
									sw = (SpreadsheetWriter) varMap.get("sw");
									rowNum = appendDataToXML(sw, pddrTdRepResultList, rowNum);
									LOG.info("excelPddrTdRepResultList before adding "+totlExcelListCount+" for report = "+pfName);
								}
								pddrTdRepResultList.clear();
							}
							minCount = maxCount + 1; 
							maxCount = maxCount + maxLimitVal; 
							diff = diff - maxLimitVal;
							if (diff >= 0 && diff <= maxLimitVal) {
								maxCount = count;
							}
							//LOG.info("The max results count for PDDR Report loop#" + k + " >>>> " + pddrTdResultList.size());
							//LOG.info("*****************************************************************");
							
						}
					}
				}
				// delete records from tables 
				LOG.info("Delete records for DELETE_PFDDR_PF_DATA : " + PLMOfflineQueries.DELETE_PFDDR_PF_DATA);
				getJdbcTemplate().execute(PLMOfflineQueries.DELETE_PFDDR_PF_DATA);
				                               
				LOG.info("Delete records for DELETE_PFDDR_EBOM_DATA : " + PLMOfflineQueries.DELETE_PFDDR_EBOM_DATA);
				getJdbcTemplate().execute(PLMOfflineQueries.DELETE_PFDDR_EBOM_DATA);
				
				LOG.info("Delete records for DELETE_PFDDR_PART_TO_DOC_DATA : " + PLMOfflineQueries.DELETE_PFDDR_PART_TO_DOC_DATA);
				getJdbcTemplate().execute(PLMOfflineQueries.DELETE_PFDDR_PART_TO_DOC_DATA);
				
				LOG.info("Delete records for DELETE_PFDDR_REC_DATA : " + PLMOfflineQueries.DELETE_PFDDR_REC_DATA);
				getJdbcTemplate().execute(PLMOfflineQueries.DELETE_PFDDR_REC_DATA);
				
				LOG.info("Delete records for DELETE_PFDDR_RPT_DATA : " + PLMOfflineQueries.DELETE_PFDDR_RPT_DATA);
				getJdbcTemplate().execute(PLMOfflineQueries.DELETE_PFDDR_RPT_DATA);
				 
				recCount1 = recCount1 + lpCntr;
				recCount2 = recCount2 + lpCntr;
				
				pddrTdResultList.clear();
			}
			
			writeExcelFileUsingAppendedXML(varMap);
			
			if (null != varMap.get("filePathXlsLst")) {
				filePathXlsLst = (List<String>) varMap.get("filePathXlsLst");
			} else {
				filePathXlsLst = new ArrayList<String>();
			}
			
		} catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
			LOG.info("DataAccessException Occured >>> " + e.getMessage());
		} catch(IOException e){
			PLMUtils.checkException(e.getMessage());
			LOG.info("Exception Occured >>> " + e.getMessage());			
		} finally {
			try {
				fw = (Writer) varMap.get("fw");
				if(fw != null){
					LOG.info("Closing Writer");
					try {
						fw.close();
					} catch (IOException e) {
						LOG.info("Exception occurred while Closing Writer: "+ e.getMessage());
						PLMUtils.checkException(e.getMessage());
					}
				}
				
				searchData = new PLMPddrData();
				searchData.setFilePathXls(filePathXlsLst);
				searchData.setFilePathZip(filePathZip);
				searchData.setFolderPath(folderPath);
				varMap.clear();
				
				try {					
					if (filePathZip != null) {
						//LOG.info("Enter to zip the file inside finally block ^^^^^^^^^^^^^^^^^^^");
						compressedFilesWithSize = PLMUtils.generateZipFile(filePathXlsLst,filePathZip, true);
						//LOG.info("Exiting from zip the file insde finally block ^^^^^^^^^^^^^^^^^^^");
					}
					searchData.setCompressedFilesWithSize(compressedFilesWithSize);
					//LOG.info("Delete records for DELETE_PFDDR_PF_DATA : " + PLMOfflineQueries.DELETE_PFDDR_PF_DATA);
					getJdbcTemplate().execute(PLMOfflineQueries.DELETE_PFDDR_PF_DATA);
					                               
					//LOG.info("Delete records for DELETE_PFDDR_EBOM_DATA : " + PLMOfflineQueries.DELETE_PFDDR_EBOM_DATA);
					getJdbcTemplate().execute(PLMOfflineQueries.DELETE_PFDDR_EBOM_DATA);
					
					//LOG.info("Delete records for DELETE_PFDDR_PART_TO_DOC_DATA : " + PLMOfflineQueries.DELETE_PFDDR_PART_TO_DOC_DATA);
					getJdbcTemplate().execute(PLMOfflineQueries.DELETE_PFDDR_PART_TO_DOC_DATA);
					
					//LOG.info("Delete records for DELETE_PFDDR_REC_DATA : " + PLMOfflineQueries.DELETE_PFDDR_REC_DATA);
					getJdbcTemplate().execute(PLMOfflineQueries.DELETE_PFDDR_REC_DATA);
					
					//LOG.info("Delete records for DELETE_PFDDR_RPT_DATA : " + PLMOfflineQueries.DELETE_PFDDR_RPT_DATA);
					getJdbcTemplate().execute(PLMOfflineQueries.DELETE_PFDDR_RPT_DATA);
					
				} catch (IOException e) {
					LOG.info("Exception occurred while zipping file: "+ e.getMessage());
					PLMUtils.checkException(e.getMessage());
				} catch (DataAccessException e) {
					LOG.info("Exception occurred while zipping file: "+ e.getMessage());
					PLMUtils.checkException(e.getMessage());
				}
			} catch(DataAccessException e) {
				LOG.info("Exception occurred while dropping the tables in dropVolatileTablesForPddrReport method : "+ e.getMessage());
				PLMUtils.checkException(e.getMessage());
			}
		}
		LOG.info("Exiting getTdPddrResult Method");		
		return searchData;
	}
	
	/**
	 * @param SpreadsheetWriter	 
	 */
	 private void beginSheet(SpreadsheetWriter sw) throws IOException{	 
		 sw.beginSheet(resourceBundle.getString(PLMConstants.SPREADSHEET_SCHEMA_URL));
	 }
	 
	 /**
	 * @param SpreadsheetWriter	 
	 */
	 private void endSheet(SpreadsheetWriter sw) throws IOException{	
		 sw.endSheet();
	 }
	
	/**
     * This method is used for createTempFile
	 * 
	 * @param String folderPath
	 * @return String fileName
	 * @throws IOException
	 */	
	 private String createTempFile(String folderPath) throws IOException{
		 File tmp = File.createTempFile("sheet", ".xml", new File(folderPath));
	     LOG.info("Temp File Name "+tmp.getName());
	     return tmp.getName();
	 }
	 
	 /**
     * This method is used for addExceHeaders
	 * 
	 * @param SpreadsheetWriter	 
	 * @param String selectedPF 
	 * @throws Exception
	 */
	 private void addExceHeaders(SpreadsheetWriter sw, String selectedPF) throws IOException { 
		 
		 sw.insertRow(0);	     
	     sw.createCell(0, "Part Family Definition Data Report for - "+selectedPF);
	     sw.endRow();
		 
		 String[] colNames = {"BOM Level","Top Part Name","Top Part Revision","Parent Part Name","Parent Part Revision","Parent Part Type","Child Part Name","Child Part Revision","Child Part Type","Child Part Description","Child Part State","Logical Indicator","Document Name","Document Revision","Document Type","Document Description","Document State","Row Key"};
	     sw.insertRow(2);
	     for ( int i = 0 ; i < colNames.length; i++ ) {
	    	 sw.createCell(i, colNames[i]);
		  }	     
	     sw.endRow();
	 }
	 
	 /**
     * This method is used for writeExcelFileUsingAppendedXML
	 * 
	 * @param SpreadsheetWriter	
	 * @param List pddrResultList
	 * @return int
	 * @throws PLMCommonException 
	 */
	 private int appendDataToXML(SpreadsheetWriter sw, List<PLMPddrReportData> pddrResultList, int rownum) throws PLMCommonException {			     
		 int rowVal=rownum;
		 try {
			 //write data rows
		     for (PLMPddrReportData dataObj : pddrResultList) {	    	
				sw.insertRow(rowVal);			
				sw.createCell(PLMConstants.EXCEL_COL_ZERO,dataObj.getBomLevel());
				sw.createCell(PLMConstants.EXCEL_COL_ONE,dataObj.getTopPartName());
				sw.createCell(PLMConstants.EXCEL_COL_TWO,dataObj.getTopPartRev());
				sw.createCell(PLMConstants.EXCEL_COL_THREE,dataObj.getParentPartName());		
				sw.createCell(PLMConstants.EXCEL_COL_FOUR,dataObj.getParentPartRev());	
				sw.createCell(PLMConstants.EXCEL_COL_FIVE,dataObj.getParentPartType());	 
				sw.createCell(PLMConstants.EXCEL_COL_SIX,dataObj.getChildPartName());	
				sw.createCell(PLMConstants.EXCEL_COL_SEVEN,dataObj.getChildPartRev());	 
				sw.createCell(PLMConstants.EXCEL_COL_EIGHT,dataObj.getChildPartType());	
				sw.createCell(PLMConstants.EXCEL_COL_NINE,dataObj.getChildPartDesc());	 
				sw.createCell(PLMConstants.EXCEL_COL_TEN,dataObj.getChildPartState());	 
				sw.createCell(PLMConstants.EXCEL_COL_ELEVEN,dataObj.getLogicalIndicator());	 
				sw.createCell(PLMConstants.EXCEL_COL_TWELVE,dataObj.getDocumentName());	
				sw.createCell(PLMConstants.EXCEL_COL_THIRTEEN,dataObj.getDocumentRev());	 
				sw.createCell(PLMConstants.EXCEL_COL_FOURTEEN,dataObj.getDocumentType());	 
				sw.createCell(PLMConstants.EXCEL_COL_FIFTEEN,dataObj.getDocumentDesc());	 
				sw.createCell(PLMConstants.EXCEL_COL_SIXTEEN,dataObj.getDocumentState());	
				sw.createCell(PLMConstants.EXCEL_COL_SEVENTEEN,dataObj.getRowKey());
				sw.endRow();
				rowVal++;
		     }
		 } catch (IOException e) {
			 LOG.log(Level.ERROR, "Exception@appendDataToXML : ", e);
		   	 PLMUtils.checkException(e.getMessage());
		}	         
	    return rowVal;
	 }    
	 
	 /**
     * This method is used for writeExcelFileUsingAppendedXML
	 * 
	 * @param varMap
	 * @throws PLMCommonException
	 */
	private void writeExcelFileUsingAppendedXML(Map<String, Object> varMap) throws PLMCommonException {
		String filePathXls;
		Map<String, Object> varMapVal=varMap;
		String folderPath = (String) varMapVal.get("folderPath");
		String fileName = (String) varMapVal.get("fileName");	
	    String tempXmlFile = (String) varMapVal.get("tempXmlFile");
	    Writer fw = (Writer) varMapVal.get("fw");
		SpreadsheetWriter sw = (SpreadsheetWriter) varMapVal.get("sw");
		boolean fileFlag = (Boolean) varMapVal.get("fileFlag");
    	LOG.info("fileFlag>> "+fileFlag);
    	FileOutputStream out=null;
	    try {   
	    	if(fw != null){
				endSheet(sw);
				fw.close();				 
			}
	    	varMapVal = createExcelFileMap(PLMConstants.EMPTY, varMapVal); 
			filePathXls = (String) varMapVal.get("filePathXls");											 
			File tmp = new File(folderPath + "/" + tempXmlFile);
			 out = new FileOutputStream(filePathXls);
			PLMUtils.substitute(new File(fileName), tmp, "xl/worksheets/sheet1.xml", out);
			//out.close();		
			
			varMapVal.put("fileFlag",true);
	        LOG.info("XML Temp File = "+tmp.getName()+" Deleted = "+tmp.delete());
			//LOG.info("Closed File successfully");
	    } catch (FileNotFoundException e) {
	   	 	LOG.log(Level.ERROR, "Exception@writeExcelFileUsingAppendedXML: ", e);
	   	 	PLMUtils.checkException(e.getMessage());
	    } catch (IOException e) {
	   	 	LOG.log(Level.ERROR, "Exception@writeExcelFileUsingAppendedXML: ", e);
	   	 	PLMUtils.checkException(e.getMessage());
	    } 	   
	    finally{
			   if(out != null ){
				   try {
					   out.close();
				} catch (IOException e) {
					PLMUtils.checkException(e.getMessage());
				}
			   }
	    }	   
	}
	
	/**
     * This method is used for prepareSpreadsheetWriter
	 * 
	 * @param varMap
	 * @param pfName
	 * @throws Exception 
	 */
	private void prepareSpreadsheetWriter(Map<String, Object> varMap, String pfName) throws IOException {
		String folderPath = (String) varMap.get("folderPath");
		String tempXmlFile = "";
		Writer fw = null;
		SpreadsheetWriter sw = (SpreadsheetWriter) varMap.get("sw");
		if(sw != null){
			LOG.info("sw--->"+sw.toString());
		}
		boolean fileFlag = (Boolean) varMap.get("fileFlag");
		
		if(fileFlag){
			tempXmlFile = createTempFile(folderPath);
			fw = new OutputStreamWriter(new FileOutputStream(folderPath + "/" + tempXmlFile, true), XML_ENCODING);
		    sw = new SpreadsheetWriter(fw);
		    fileFlag = false;
		    
			beginSheet(sw);
	    	addExceHeaders(sw, pfName);
	    	
	    	varMap.put("tempXmlFile", tempXmlFile);
	    	varMap.put("fileFlag", fileFlag);
	    	varMap.put("fw", fw);
	    	varMap.put("sw", sw);
		}		
	}
	
	 /**
       * This method is used for createExcelFileMap
	   * 
	   * @param selectedPF,varMap
	   * @return Map
       * @throws PLMCommonException
       */
    private Map<String, Object> createExcelFileMap(String selectedPF, Map<String, Object> varMap) throws PLMCommonException {
		String filePathXls = "";
		String folderPath = (String) varMap.get("folderPath");	
		List<String> filePathXlsLst = (ArrayList<String>) varMap.get("filePathXlsLst");		
	    	
	    	LOG.info("selectedPF>> "+selectedPF);
		try {
	
			Date uniqDate = new Date();
			final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat(
					"yyyyMMddHHmmss");
			String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
			filePathXls = folderPath + "/"
					+ resourceBundle.getString("PDDR_REPORT_NAME") + " "
					+ uniqTime + ".xlsm";
			filePathXlsLst.add(filePathXls);
			// LOG.info("folderPath--createNewFile---"+folderPath);
	
			varMap.put("filePathXls", filePathXls);
			varMap.put("filePathXlsLst", filePathXlsLst);
	
		} catch (Exception e) {
			LOG.log(Level.ERROR, "Exception@createNewFile: ", e);
			PLMUtils.checkException(e.getMessage());
		}
	    return varMap;
    }  
}