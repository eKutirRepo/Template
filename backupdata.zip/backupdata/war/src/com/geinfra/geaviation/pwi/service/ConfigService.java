package com.geinfra.geaviation.pwi.service;

import com.geinfra.geaviation.pwi.common.PWiException;

/**
*
* Project      : Product Lifecycle Management Intelligence
* Date Written : Jul 20, 2012
* Security     : GE Confidential
* Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
*
* Copyright(C) 2013 GE All rights reserved
*
* Description : ConfigService
*
* Revision Log Jul 20, 2011 | v1.0.
* --------------------------------------------------------------
*/
public class ConfigService {
	private boolean queryTimeoutOverridden;
	private int queryTimeoutOverride;

	private boolean resultSizeLimitOverridden;
	private int resultSizeLimitOverride;

	private AdminSettingsService adminSettingsService;

	public void setAdminSettingsService(
			AdminSettingsService adminSettingsService) {
		this.adminSettingsService = adminSettingsService;
	}

	/**
	 * The timeout for running a query. A value of 0 indicates no timeout.
	 * 
	 * @return query timeout
	 * @throws PWiException
	 */
	public int getQueryTimeoutSecs() throws PWiException {
		if (queryTimeoutOverridden) {
			return queryTimeoutOverride;
		} else {
			return adminSettingsService.getOnlineQueryTimeoutSecs();
		}
	}

	public void overrideQueryTimeoutSecs(int queryTimeout) {
		queryTimeoutOverride = queryTimeout;
		queryTimeoutOverridden = true;
	}

	/**
	 * The limit on the number of pieces of data to process from a query defined
	 * as the number of rows times the number of columns.
	 * 
	 * A value of 0 indicates no limit.
	 * 
	 * @return result size limit
	 * @throws PWiException
	 */
	public int getResultSizeLimit() throws PWiException {
		if (resultSizeLimitOverridden) {
			return resultSizeLimitOverride;
		} else {
			return adminSettingsService.getOnlineResultSizeLimit();
		}
	}

	public void overrideResultSizeLimit(int resultSizeLimit) {
		resultSizeLimitOverride = resultSizeLimit;
		resultSizeLimitOverridden = true;
	}
}
