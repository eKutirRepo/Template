/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName RptTypeRelMetaDataUtil.java
 * @Creation date: 18-June-2014
 * @version 1.0
  * @author : Tech Mahindra
 */

package com.geinfra.geaviation.pwi.bean.util;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.dao.RptTypeRelationDAO;
import com.geinfra.geaviation.pwi.dao.RptTypeRelationDAOImpl;
import com.geinfra.geaviation.pwi.service.RptTypeRelationService;
import com.geinfra.geaviation.pwi.service.vo.TypeRelationData;

public class RptTypeRelMetaDataUtil {

	private RptTypeRelationService rptTypeRelationService;

	private static List<TypeRelationData> listTypeRelData;

	public static List<TypeRelationData> getListTypeRelData() {

		return listTypeRelData;
	}

	public static void setListTypeRelData(List<TypeRelationData> listTypeRelData) {
		RptTypeRelMetaDataUtil.listTypeRelData = listTypeRelData;
	}
	
	public String getTypRelValFrEEDWFrm(String eedwType)
	{
		String eedwEnvVal = "";
		for(TypeRelationData typeRelationData : listTypeRelData)
		{
			if(typeRelationData.getFromTypeEedw().trim().equalsIgnoreCase(eedwType))
			{
				eedwEnvVal=typeRelationData.getFromTypeEedw().trim()+"-"+typeRelationData.getFromType().trim();
			}
		}
		return eedwEnvVal;
	}
	public String getTypRelValFrEEDWTo(String eedwType)
	{
		String eedwEnvVal = "";
		for(TypeRelationData typeRelationData : listTypeRelData)
		{
			if(typeRelationData.getToTypeEedw().trim().equalsIgnoreCase(eedwType))
			{
				eedwEnvVal=typeRelationData.getToTypeEedw().trim()+"-"+typeRelationData.getToType().trim();
			}
		}
		return eedwEnvVal;
	}
	public String getTypRelValFrEEDWRel(String eedwType)
	{
		String eedwEnvVal = "";
		for(TypeRelationData typeRelationData : listTypeRelData)
		{
			if(typeRelationData.getRelTypeEedw().trim().equalsIgnoreCase(eedwType))
			{
				eedwEnvVal=typeRelationData.getRelTypeEedw().trim()+"-"+typeRelationData.getRelType().trim();
			}
		}
		return eedwEnvVal;
	}

	public List<SelectItem> getAllFromType() {
		List<SelectItem> allFrmTyp = new ArrayList<SelectItem>();
		List<String> allFrmTypList = new ArrayList<String>();
		try {

			if (listTypeRelData != null) {
				for (TypeRelationData frmTyp : listTypeRelData) {
					//System.out.println(frmTyp.getFromType());
					if (!allFrmTypList.contains(frmTyp.getFromType())) {
						allFrmTypList.add(frmTyp.getFromType());
						allFrmTyp.add(new SelectItem(frmTyp.getFromTypeEedw().trim()
								+ "-" + frmTyp.getFromType().trim(), frmTyp
								.getFromType().trim()));
					}
				}
			}
		} finally {
			allFrmTypList = null;
		}
		return allFrmTyp;
	}

	public List<SelectItem> getRelationForFromType(String fromType) {
		List<SelectItem> allRelTyp = new ArrayList<SelectItem>();
		List<String> relFrFrmTypList = new ArrayList<String>();
		if (listTypeRelData != null) {
			for (TypeRelationData frmTyp : listTypeRelData) {

				// System.out.println(frmTyp.getFromType());
				if (fromType.equals(frmTyp.getFromType())) {
					if (!relFrFrmTypList.contains(frmTyp.getRelType()))
					{
						relFrFrmTypList.add(frmTyp.getRelType());
						allRelTyp.add(new SelectItem(frmTyp.getRelTypeEedw().trim()+ "-" + frmTyp.getRelType().trim(),
								frmTyp.getRelType().trim()));
					}
				}
			}
		}

		return allRelTyp;
	}

	public List<SelectItem> getToForFromRelType(String fromType, String relType) {
		List<SelectItem> allToTyp = new ArrayList<SelectItem>();
		List<String> toForFromRelTypList = new ArrayList<String>();
		if (listTypeRelData != null) {
			for (TypeRelationData frmTyp : listTypeRelData) {

				// System.out.println(frmTyp.getFromType());
				if (fromType.equals(frmTyp.getFromType())
						&& relType.equals(frmTyp.getRelType())) {
					if (!toForFromRelTypList.contains(frmTyp.getToType())) {
						toForFromRelTypList.add(frmTyp.getToType());
						allToTyp.add(new SelectItem(frmTyp.getToTypeEedw().trim()
								+ "-" + frmTyp.getToType().trim(), frmTyp.getToType().trim()));
					}
				}
			}
		}

		return allToTyp;
	}

	/*
	 * public List<TypeRelationData> getListTypeRelData() { System.out.println(
	 * "================================= inside RptTypeRelMetaDataUtil 2222 ============================== "
	 * ); if(listTypeRelData==null) { populateTypeRelData(); } return
	 * listTypeRelData; }
	 * 
	 * 
	 * 
	 * public void setListTypeRelData(List<TypeRelationData> listTypeRelData) {
	 * this.listTypeRelData = listTypeRelData; }
	 */

	public RptTypeRelationService getRptTypeRelationService() {
		return rptTypeRelationService;
	}

	public void setRptTypeRelationService(
			RptTypeRelationService rptTypeRelationService) {
		this.rptTypeRelationService = rptTypeRelationService;
	}

	@PostConstruct
	public void postConstruct() throws PWiException {

		populateTypeRelData();
	}

	public static List<TypeRelationData> populateTypeRelData()
			throws PWiException {

		RptTypeRelationDAO rptDao = new RptTypeRelationDAOImpl();
		listTypeRelData = rptDao.getTypeRelData();
		// listTypeRelData = rptTypeRelationService.getTypeRelData();
		return listTypeRelData;
	}

}
