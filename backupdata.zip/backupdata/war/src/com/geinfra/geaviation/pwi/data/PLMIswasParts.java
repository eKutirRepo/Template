/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMIswasParts.java
 * @Creation date: 14-April-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;

public class PLMIswasParts {
	/**
	  * Holds the stateExcel
	  */
	private String topLevelPrnt;
	/**
	  * Holds the stateExcel
	  */
	private String lvlOneParentName;
	/**
	  * Holds the stateExcel
	  */
	private String lvlOneParentRev;
	/**
	  * Holds the stateExcel
	  */
	private String affectItmName;
	/**
	  * Holds the stateExcel
	  */
	private String affectItmRev;
	/**
	  * Holds the stateExcel
	  */
	private String affectItmLvl;
	/**
	  * Holds the stateExcel
	  */
	private String parentPart;
	/**
	  * Holds the stateExcel
	  */
	private String geBomPrefix;
	/**
	  * Holds the stateExcel
	  */
	private String wasPartName;
	/**
	  * Holds the stateExcel
	  */
	private String wasPartRev;
	/**
	  * Holds the stateExcel
	  */
	private String wasGeCopicParent;
	/**
	  * Holds the stateExcel
	  */
	private String wasBomQty;
	/**
	  * Holds the stateExcel
	  */
	private String isPartName;
	/**
	  * Holds the stateExcel
	  */
	private String isPartRev;
	/**
	  * Holds the stateExcel
	  */
	private String isPartState;
	/**
	  * Holds the stateExcel
	  */
	private String isGeCopicParent;
	/**
	  * Holds the stateExcel
	  */
	private String isBomQty;
	/**
	  * Holds the stateExcel
	  */
	private String ecr;
	/**
	  * Holds the stateExcel
	  */
	private String ecrDescIwp;
	/**
	  * Holds the stateExcel
	  */
	private String ecoCtgryChange;
	/**
	  * Holds the stateExcel
	  */
	private String ecoSeverity;
	/**
	  * Holds the stateExcel
	  */
	private String eco;
	/**
	  * Holds the stateExcel
	  */
	private String ecoSubst;
	/**
	  * Holds the stateExcel
	  */
	private String ecoDesc;
	/**
	  * Holds the stateExcel
	  */
	private String ecoFastTrack;
	/**
	  * Holds the stateExcel
	  */
	private String ecrStatus;
	/**
	  * Holds the stateExcel
	  */
	private String ecoStatus;
	/**
	  * Holds the stateExcel
	  */
	private String requestChange;
	/**
	  * Holds the stateExcel
	  */
	private String dispInFeild;
	/**
	  * Holds the stateExcel
	  */
	private String dispInProcess;
	/**
	  * Holds the stateExcel
	  */
	private String dispInStock;
	/**
	  * Holds the stateExcel
	  */
	
	private String dispOnOrder;
	/**
	  * Holds the stateExcel
	  */
	private String ecoPolicy;
	/**
	  * Holds the stateExcel
	  */
	private String clsImpactStmtTxt;
	/**
	  * Holds the stateExcel
	  */
	private String bomMarkup;
	/**
	  * Holds the stateExcel
	  */
	private String bomMarkupType;
	/**
	  * Holds the stateExcel
	  */
	private String rdo;
	/**
	  * Holds the stateExcel
	  */
	private String ecrCtgryChange;
	/**
	  * Holds the stateExcel
	  */
	private String ecrOrig;
	/**
	  * Holds the stateExcel
	  */
	private String ecrOrigName;
	/**
	  * Holds the stateExcel
	  */
	private String ecrRespDesign;
	/**
	  * Holds the stateExcel
	  */
	private String  ecrRespDesignName;
	/**
	  * Holds the stateExcel
	  */
	private Date ecrModifedDate;
	/**
	  * Holds the stateExcel
	  */
	private Date ecoModifedDate;
	/**
	  * Holds the stateExcel
	  */
	private String dfsOrder;
	/**
	  * Holds the stateExcel
	  */
	private Date isPartStateDate;
	
	/**
	 * @return the topLevelPrnt
	 */
	public String getTopLevelPrnt() {
		return topLevelPrnt;
	}
	/**
	 * @param topLevelPrnt the topLevelPrnt to set
	 */
	public void setTopLevelPrnt(String topLevelPrnt) {
		this.topLevelPrnt = topLevelPrnt;
	}
	/**
	 * @return the topLevelparent
	 */
	/*public String getTopLevelparent() {
		return topLevelparent;
	}*/
	/**
	 * @param topLevelparent the topLevelparent to set
	 */
	/*public void setTopLevelparent(String topLevelparent) {
		this.topLevelparent = topLevelparent;
	}*/
	/**
	 * @return the lvlOneParentName
	 */
	public String getLvlOneParentName() {
		return lvlOneParentName;
	}
	/**
	 * @param lvlOneParentName the lvlOneParentName to set
	 */
	public void setLvlOneParentName(String lvlOneParentName) {
		this.lvlOneParentName = lvlOneParentName;
	}
	/**
	 * @return the lvlOneParentRev
	 */
	public String getLvlOneParentRev() {
		return lvlOneParentRev;
	}
	/**
	 * @param lvlOneParentRev the lvlOneParentRev to set
	 */
	public void setLvlOneParentRev(String lvlOneParentRev) {
		this.lvlOneParentRev = lvlOneParentRev;
	}
	/**
	 * @return the affectItmName
	 */
	public String getAffectItmName() {
		return affectItmName;
	}
	/**
	 * @param affectItmName the affectItmName to set
	 */
	public void setAffectItmName(String affectItmName) {
		this.affectItmName = affectItmName;
	}
	/**
	 * @return the affectItmRev
	 */
	public String getAffectItmRev() {
		return affectItmRev;
	}
	/**
	 * @param affectItmRev the affectItmRev to set
	 */
	public void setAffectItmRev(String affectItmRev) {
		this.affectItmRev = affectItmRev;
	}
	/**
	 * @return the affectItmLvl
	 */
	public String getAffectItmLvl() {
		return affectItmLvl;
	}
	/**
	 * @param affectItmLvl the affectItmLvl to set
	 */
	public void setAffectItmLvl(String affectItmLvl) {
		this.affectItmLvl = affectItmLvl;
	}
	/**
	 * @return the parentPart
	 */
	public String getParentPart() {
		return parentPart;
	}
	/**
	 * @param parentPart the parentPart to set
	 */
	public void setParentPart(String parentPart) {
		this.parentPart = parentPart;
	}
	/**
	 * @return the geBomPrefix
	 */
	public String getGeBomPrefix() {
		return geBomPrefix;
	}
	/**
	 * @param geBomPrefix the geBomPrefix to set
	 */
	public void setGeBomPrefix(String geBomPrefix) {
		this.geBomPrefix = geBomPrefix;
	}
	/**
	 * @return the wasPartName
	 */
	public String getWasPartName() {
		return wasPartName;
	}
	/**
	 * @param wasPartName the wasPartName to set
	 */
	public void setWasPartName(String wasPartName) {
		this.wasPartName = wasPartName;
	}
	/**
	 * @return the wasPartRev
	 */
	public String getWasPartRev() {
		return wasPartRev;
	}
	/**
	 * @param wasPartRev the wasPartRev to set
	 */
	public void setWasPartRev(String wasPartRev) {
		this.wasPartRev = wasPartRev;
	}
	/**
	 * @return the wasGeCopicParent
	 */
	public String getWasGeCopicParent() {
		return wasGeCopicParent;
	}
	/**
	 * @param wasGeCopicParent the wasGeCopicParent to set
	 */
	public void setWasGeCopicParent(String wasGeCopicParent) {
		this.wasGeCopicParent = wasGeCopicParent;
	}
	/**
	 * @return the wasBomQty
	 */
	public String getWasBomQty() {
		return wasBomQty;
	}
	/**
	 * @param wasBomQty the wasBomQty to set
	 */
	public void setWasBomQty(String wasBomQty) {
		this.wasBomQty = wasBomQty;
	}
	/**
	 * @return the isPartName
	 */
	public String getIsPartName() {
		return isPartName;
	}
	/**
	 * @param isPartName the isPartName to set
	 */
	public void setIsPartName(String isPartName) {
		this.isPartName = isPartName;
	}
	/**
	 * @return the isPartRev
	 */
	public String getIsPartRev() {
		return isPartRev;
	}
	/**
	 * @param isPartRev the isPartRev to set
	 */
	public void setIsPartRev(String isPartRev) {
		this.isPartRev = isPartRev;
	}
	/**
	 * @return the isPartState
	 */
	public String getIsPartState() {
		return isPartState;
	}
	/**
	 * @param isPartState the isPartState to set
	 */
	public void setIsPartState(String isPartState) {
		this.isPartState = isPartState;
	}
	/**
	 * @return the isGeCopicParent
	 */
	public String getIsGeCopicParent() {
		return isGeCopicParent;
	}
	/**
	 * @param isGeCopicParent the isGeCopicParent to set
	 */
	public void setIsGeCopicParent(String isGeCopicParent) {
		this.isGeCopicParent = isGeCopicParent;
	}
	/**
	 * @return the isBomQty
	 */
	public String getIsBomQty() {
		return isBomQty;
	}
	/**
	 * @param isBomQty the isBomQty to set
	 */
	public void setIsBomQty(String isBomQty) {
		this.isBomQty = isBomQty;
	}
	/**
	 * @return the ecr
	 */
	public String getEcr() {
		return ecr;
	}
	/**
	 * @param ecr the ecr to set
	 */
	public void setEcr(String ecr) {
		this.ecr = ecr;
	}
	
	
	/**
	 * @return the ecoCtgryChange
	 */
	public String getEcoCtgryChange() {
		return ecoCtgryChange;
	}
	/**
	 * @param ecoCtgryChange the ecoCtgryChange to set
	 */
	public void setEcoCtgryChange(String ecoCtgryChange) {
		this.ecoCtgryChange = ecoCtgryChange;
	}
	/**
	 * @return the ecoSeverity
	 */
	public String getEcoSeverity() {
		return ecoSeverity;
	}
	/**
	 * @param ecoSeverity the ecoSeverity to set
	 */
	public void setEcoSeverity(String ecoSeverity) {
		this.ecoSeverity = ecoSeverity;
	}
	/**
	 * @return the eco
	 */
	public String getEco() {
		return eco;
	}
	/**
	 * @param eco the eco to set
	 */
	public void setEco(String eco) {
		this.eco = eco;
	}
	/**
	 * @return the ecoSubst
	 */
	public String getEcoSubst() {
		return ecoSubst;
	}
	/**
	 * @param ecoSubst the ecoSubst to set
	 */
	public void setEcoSubst(String ecoSubst) {
		this.ecoSubst = ecoSubst;
	}
	/**
	 * @return the ecoDesc
	 */
	public String getEcoDesc() {
		return ecoDesc;
	}
	/**
	 * @param ecoDesc the ecoDesc to set
	 */
	public void setEcoDesc(String ecoDesc) {
		this.ecoDesc = ecoDesc;
	}
	/**
	 * @return the ecoFastTrack
	 */
	public String getEcoFastTrack() {
		return ecoFastTrack;
	}
	/**
	 * @param ecoFastTrack the ecoFastTrack to set
	 */
	public void setEcoFastTrack(String ecoFastTrack) {
		this.ecoFastTrack = ecoFastTrack;
	}
	/**
	 * @return the ecrStatus
	 */
	public String getEcrStatus() {
		return ecrStatus;
	}
	/**
	 * @param ecrStatus the ecrStatus to set
	 */
	public void setEcrStatus(String ecrStatus) {
		this.ecrStatus = ecrStatus;
	}
	/**
	 * @return the ecoStatus
	 */
	public String getEcoStatus() {
		return ecoStatus;
	}
	/**
	 * @param ecoStatus the ecoStatus to set
	 */
	public void setEcoStatus(String ecoStatus) {
		this.ecoStatus = ecoStatus;
	}
	/**
	 * @return the requestChange
	 */
	public String getRequestChange() {
		return requestChange;
	}
	/**
	 * @param requestChange the requestChange to set
	 */
	public void setRequestChange(String requestChange) {
		this.requestChange = requestChange;
	}
	/**
	 * @return the dispInFeild
	 */
	public String getDispInFeild() {
		return dispInFeild;
	}
	/**
	 * @param dispInFeild the dispInFeild to set
	 */
	public void setDispInFeild(String dispInFeild) {
		this.dispInFeild = dispInFeild;
	}
	/**
	 * @return the dispInProcess
	 */
	public String getDispInProcess() {
		return dispInProcess;
	}
	/**
	 * @param dispInProcess the dispInProcess to set
	 */
	public void setDispInProcess(String dispInProcess) {
		this.dispInProcess = dispInProcess;
	}
	/**
	 * @return the dispInStock
	 */
	public String getDispInStock() {
		return dispInStock;
	}
	/**
	 * @param dispInStock the dispInStock to set
	 */
	public void setDispInStock(String dispInStock) {
		this.dispInStock = dispInStock;
	}
	/**
	 * @return the dispOnOrder
	 */
	public String getDispOnOrder() {
		return dispOnOrder;
	}
	/**
	 * @param dispOnOrder the dispOnOrder to set
	 */
	public void setDispOnOrder(String dispOnOrder) {
		this.dispOnOrder = dispOnOrder;
	}
	/**
	 * @return the ecoPolicy
	 */
	public String getEcoPolicy() {
		return ecoPolicy;
	}
	/**
	 * @param ecoPolicy the ecoPolicy to set
	 */
	public void setEcoPolicy(String ecoPolicy) {
		this.ecoPolicy = ecoPolicy;
	}
	/**
	 * @return the clsImpactStmtTxt
	 */
	public String getClsImpactStmtTxt() {
		return clsImpactStmtTxt;
	}
	/**
	 * @param clsImpactStmtTxt the clsImpactStmtTxt to set
	 */
	public void setClsImpactStmtTxt(String clsImpactStmtTxt) {
		this.clsImpactStmtTxt = clsImpactStmtTxt;
	}
	/**
	 * @return the bomMarkup
	 */
	public String getBomMarkup() {
		return bomMarkup;
	}
	/**
	 * @param bomMarkup the bomMarkup to set
	 */
	public void setBomMarkup(String bomMarkup) {
		this.bomMarkup = bomMarkup;
	}
	/**
	 * @return the bomMarkupType
	 */
	public String getBomMarkupType() {
		return bomMarkupType;
	}
	/**
	 * @param bomMarkupType the bomMarkupType to set
	 */
	public void setBomMarkupType(String bomMarkupType) {
		this.bomMarkupType = bomMarkupType;
	}
	/**
	 * @return the rdo
	 */
	public String getRdo() {
		return rdo;
	}
	/**
	 * @param rdo the rdo to set
	 */
	public void setRdo(String rdo) {
		this.rdo = rdo;
	}
	/**
	 * @return the ecrCtgryChange
	 */
	public String getEcrCtgryChange() {
		return ecrCtgryChange;
	}
	/**
	 * @param ecrCtgryChange the ecrCtgryChange to set
	 */
	public void setEcrCtgryChange(String ecrCtgryChange) {
		this.ecrCtgryChange = ecrCtgryChange;
	}
	/**
	 * @return the ecrOrig
	 */
	public String getEcrOrig() {
		return ecrOrig;
	}
	/**
	 * @param ecrOrig the ecrOrig to set
	 */
	public void setEcrOrig(String ecrOrig) {
		this.ecrOrig = ecrOrig;
	}
	/**
	 * @return the ecrOrigName
	 */
	public String getEcrOrigName() {
		return ecrOrigName;
	}
	/**
	 * @param ecrOrigName the ecrOrigName to set
	 */
	public void setEcrOrigName(String ecrOrigName) {
		this.ecrOrigName = ecrOrigName;
	}
	/**
	 * @return the ecrRespDesign
	 */
	public String getEcrRespDesign() {
		return ecrRespDesign;
	}
	/**
	 * @param ecrRespDesign the ecrRespDesign to set
	 */
	public void setEcrRespDesign(String ecrRespDesign) {
		this.ecrRespDesign = ecrRespDesign;
	}
	/**
	 * @return the ecrRespDesignName
	 */
	public String getEcrRespDesignName() {
		return ecrRespDesignName;
	}
	/**
	 * @param ecrRespDesignName the ecrRespDesignName to set
	 */
	public void setEcrRespDesignName(String ecrRespDesignName) {
		this.ecrRespDesignName = ecrRespDesignName;
	}
	/**
	 * @return the ecrModifedDate
	 */
	public Date getEcrModifedDate() {
		Date ecrModifedDt =ecrModifedDate;
		return ecrModifedDt;
	}
	/**
	 * @param ecrModifedDate the ecrModifedDate to set
	 */
	public void setEcrModifedDate(Date ecrModifedDate) {
		Date ecrModifedDt =ecrModifedDate;
		this.ecrModifedDate = ecrModifedDt;
	}
	/**
	 * @return the ecoModifedDate
	 */
	public Date getEcoModifedDate() {
		Date ecoModifedDt =ecoModifedDate;
		return ecoModifedDt;
	}
	/**
	 * @param ecoModifedDate the ecoModifedDate to set
	 */
	public void setEcoModifedDate(Date ecoModifedDate) {
		Date ecoModifedDt =ecoModifedDate;
		this.ecoModifedDate = ecoModifedDt;
	}
	/**
	 * @return the dfsOrder
	 */
	public String getDfsOrder() {
		return dfsOrder;
	}
	/**
	 * @param dfsOrder the dfsOrder to set
	 */
	public void setDfsOrder(String dfsOrder) {
		this.dfsOrder = dfsOrder;
	}
	/**
	 * @return the isPartStateDate
	 */
	public Date getIsPartStateDate() {
		Date isPartStateDt =isPartStateDate;
		return isPartStateDt;
	}
	/**
	 * @param isPartStateDate the isPartStateDate to set
	 */
	public void setIsPartStateDate(Date isPartStateDate) {
		Date isPartStateDt =isPartStateDate;
		this.isPartStateDate = isPartStateDt;
	}
	/**
	 * @return the ecrDescIwp
	 */
	public String getEcrDescIwp() {
		return ecrDescIwp;
	}
	/**
	 * @param ecrDescIwp the ecrDescIwp to set
	 */
	public void setEcrDescIwp(String ecrDescIwp) {
		this.ecrDescIwp = ecrDescIwp;
	}

}
