package com.geinfra.geaviation.pwi.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;

import com.geinfra.geaviation.pwi.util.DaoUtil;
import com.geinfra.geaviation.pwi.util.QueryConstants;
import com.geinfra.geaviation.pwi.util.QueryLoader;

/**
 * 
 * Project : Product Lifecycle Management
 * Date Written : Apr 15, 2013
 * Security : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2013 GE All rights reserved
 * 
 * Description : Data access object for the group-object type relationship.
 * 
 * Revision Log Apr 15, 2013 | v1.0.
 * --------------------------------------------------------------
 */
public class GroupTypeDAOImpl implements GroupTypeDAO {
	// injected
	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	/**
	 * Add groups for Object Type
	 */
	public void addGroupsForObjectType(List<Integer> groupIdsToAddForObjectType,
			Integer objectTypeId, String sso) {
		AddGroupsForObjectTypeSetter pss = new AddGroupsForObjectTypeSetter(
				objectTypeId, groupIdsToAddForObjectType, sso);

		jdbcTemplate.batchUpdate(pss.getSql(), pss);
	}

	private static class AddGroupsForObjectTypeSetter implements
			BatchPreparedStatementSetter {
		private Integer objTypId;
		private List<Integer> groupIds;
		private String sso;

		public AddGroupsForObjectTypeSetter(Integer objTypId, List<Integer> groupIds,
				String sso) {
			this.objTypId = objTypId;
			this.groupIds = groupIds;
			this.sso = sso;
		}

		public String getSql() {
			return QueryLoader.getQuery(QueryConstants.PWi_GROUP_TYPE_INSERT);
		}

		public int getBatchSize() {
			return groupIds.size();
		}

		public void setValues(PreparedStatement ps, int grpIdIndex) throws SQLException {
			ps.setInt(1, objTypId.intValue());
			ps.setInt(2, groupIds.get(grpIdIndex).intValue());
			ps.setString(3, sso);
			ps.setString(4, sso);
		}
	}

	/**
	 * Remove groups for Object Type
	 */
	public void deleteGroupsForObjectType(List<Integer> groupIdsToRemoveForObjectType,
			Integer objectTypeId) {
		RemoveGroupsForObjectTypeSetter pss = new RemoveGroupsForObjectTypeSetter(
				objectTypeId, groupIdsToRemoveForObjectType);

		jdbcTemplate.update(pss.getSql(), pss);
	}

	private static class RemoveGroupsForObjectTypeSetter implements
			PreparedStatementSetter {
		private Integer objTypId;
		private List<Integer> groupIds;

		public RemoveGroupsForObjectTypeSetter(Integer objTypId,
				List<Integer> groupIds) {
			this.objTypId = objTypId;
			this.groupIds = groupIds;
		}

		public String getSql() {
			StringBuffer buffer = new StringBuffer();
			buffer.append(QueryLoader.getQuery(QueryConstants
					.PWi_GROUP_TYPE_DELETE));
			buffer.append(" (");
			buffer.append(DaoUtil.getInstance().generateInClausePlaceholders(
					groupIds.size()));
			buffer.append(")");

			return buffer.toString();
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			int index = 1;
			ps.setInt(index++, objTypId.intValue());
			for (Integer groupId : groupIds) {
				ps.setInt(index++, groupId.intValue());
			}
		}
	}
}
