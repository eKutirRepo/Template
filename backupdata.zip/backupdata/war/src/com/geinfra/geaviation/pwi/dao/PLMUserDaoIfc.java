/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMUserDaoIfc.java
 * @Creation date: 30-Oct-2010
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.SQLException;
import java.util.List;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

/**
 * PLMUserDaoIfc is the DAO interface used for ICM Add Item.
 */
public interface PLMUserDaoIfc {

	/**
	 * This method is used for validateUserDetails
	 * 
	 * @param loginData
	 * @return PLMLoginData
	 * @throws SQLException
	 */
	
	public PLMLoginData validateUserDetails(String userSSO)
	throws PLMCommonException;
	

	/**
	 * This method is used for getScreenAccess
	 * 
	 * @param userDetails
	 * @return PLMLoginData
	 * @throws SQLException
	 */
	public PLMLoginData getScreenAccess(PLMLoginData userDetails)
			throws SQLException;

	/**
	 * This method is used for validateUser
	 * 
	 * @param loginData
	 * @return booelan
	 * @throws SQLException
	 */
	public boolean validateUser(String loginData) throws SQLException;
	
	/**
	 * This method is used for fetchUserGroups
	 * 
	 * @param userSSO
	 * @return List
	 * @throws PLMCommonException
	 */

	public List<SelectItem> fetchUserGroups(String userSSO)
			throws PLMCommonException;
	
	/**
	 * This method is used for addSystemLogEvent
	 * 
	 * @param userSSO
	 * @param event
	 * @return boolean
	 * @throws PLMCommonException
	 */
	public void addSystemLogEvent(String userSSO, String event)
			throws PLMCommonException;
	
	/**
	 * This method is used for getPermissionDetails
	 * 
	 * @param userSSO
	 * @param userGrp
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMLoginData> getPermissionDetails(List<SelectItem> userGrp)
			throws PLMCommonException;
}
