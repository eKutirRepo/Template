/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMProjChngData.java
 * @Creation date: 23-Dec-2013
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */

package com.geinfra.geaviation.pwi.data;

/**
 * @author Ravindra Vadrevu
 *
 */
public class PLMProjChngData {
	
	/**
	  * Holds the contract
	  */
	private String contract;
	/**
	  * Holds the serialNumber
	  */
	private String serialNumber;
	/**
	  * Holds the issueId
	  */
	private String issueId;
	/**
	  * Holds the issueName
	  */
	private String issueName;
	/**
	  * Holds the issueCategory
	  */
	private String issueCategory;
	/**
	  * Holds the issueStatus
	  */
	private String issueStatus;
	/**
	  * Holds the buildName
	  */
	private String buildName;
	/**
	  * Holds the buildState
	  */
	private String buildState;
	
	//newly added for Ecr/Eco for pop up display
	private String description;
	/**
	 * @return the contract
	 */
	public String getContract() {
		return contract;
	}
	/**
	 * @param contract the contract to set
	 */
	public void setContract(String contract) {
		this.contract = contract;
	}
	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}
	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	/**
	 * @return the issueId
	 */
	public String getIssueId() {
		return issueId;
	}
	/**
	 * @param issueId the issueId to set
	 */
	public void setIssueId(String issueId) {
		this.issueId = issueId;
	}
	/**
	 * @return the issueName
	 */
	public String getIssueName() {
		return issueName;
	}
	/**
	 * @param issueName the issueName to set
	 */
	public void setIssueName(String issueName) {
		this.issueName = issueName;
	}
	/**
	 * @return the issueCategory
	 */
	public String getIssueCategory() {
		return issueCategory;
	}
	/**
	 * @param issueCategory the issueCategory to set
	 */
	public void setIssueCategory(String issueCategory) {
		this.issueCategory = issueCategory;
	}
	/**
	 * @return the issueStatus
	 */
	public String getIssueStatus() {
		return issueStatus;
	}
	/**
	 * @param issueStatus the issueStatus to set
	 */
	public void setIssueStatus(String issueStatus) {
		this.issueStatus = issueStatus;
	}
	/**
	 * @return the buildName
	 */
	public String getBuildName() {
		return buildName;
	}
	/**
	 * @param buildName the buildName to set
	 */
	public void setBuildName(String buildName) {
		this.buildName = buildName;
	}
	/**
	 * @return the buildState
	 */
	public String getBuildState() {
		return buildState;
	}
	/**
	 * @param buildState the buildState to set
	 */
	public void setBuildState(String buildState) {
		this.buildState = buildState;
	}
	
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	

}
