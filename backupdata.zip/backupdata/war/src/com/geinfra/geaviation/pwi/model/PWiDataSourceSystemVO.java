/*
//  @ Project : PWi
//  @ File Name : PWiUserCustomQueryVO.java
//  @ Date : 5/14/2010
//  @ Author : nisverma
 */
package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

/**
 * 
 * Project        :   Product Lifecycle Management
 * Date Written   :   Aug 6, 2010
 * Security       :   GE Confidential
 * Restrictions   :   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 * Copyright(C) 2010 GE 
 * All rights reserved
 *
 * Description    :  PWiDataSourceSystemVO - Data Source System object.
 *
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiDataSourceSystemVO extends PWiBaseVO implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer dataSrcSysSeqId;
	private String dataSrcSysNm;
	private String dataSrcSysDesc;
	private String dataSrcTypNm;
	private Object dataSrcCnfgrtnDtlDesc;
	
	private Collection<PWiQueryDataSourceVO> PWiQueryDataSourceCollection;

	public PWiDataSourceSystemVO() {
	}

	public PWiDataSourceSystemVO(Integer dataSrcSysSeqId) {
		this.dataSrcSysSeqId = dataSrcSysSeqId;
	}

	public PWiDataSourceSystemVO(Integer dataSrcSysSeqId, String dataSrcSysNm,
			Date crtnDt, String crtdBy, Date lstUpdtDt, String lstUpdtdBy) {
		super(crtnDt, crtdBy, lstUpdtDt, lstUpdtdBy);
		this.dataSrcSysSeqId = dataSrcSysSeqId;
		this.dataSrcSysNm = dataSrcSysNm;		
	}

	public Integer getDataSrcSysSeqId() {
		return dataSrcSysSeqId;
	}

	public void setDataSrcSysSeqId(Integer dataSrcSysSeqId) {
		this.dataSrcSysSeqId = dataSrcSysSeqId;
	}

	public String getDataSrcSysNm() {
		return dataSrcSysNm;
	}

	public void setDataSrcSysNm(String dataSrcSysNm) {
		this.dataSrcSysNm = dataSrcSysNm;
	}

	public String getDataSrcSysDesc() {
		return dataSrcSysDesc;
	}

	public void setDataSrcSysDesc(String dataSrcSysDesc) {
		this.dataSrcSysDesc = dataSrcSysDesc;
	}

	public String getDataSrcTypNm() {
		return dataSrcTypNm;
	}

	public void setDataSrcTypNm(String dataSrcTypNm) {
		this.dataSrcTypNm = dataSrcTypNm;
	}

	public Object getDataSrcCnfgrtnDtlDesc() {
		return dataSrcCnfgrtnDtlDesc;
	}

	public void setDataSrcCnfgrtnDtlDesc(Object dataSrcCnfgrtnDtlDesc) {
		this.dataSrcCnfgrtnDtlDesc = dataSrcCnfgrtnDtlDesc;
	}

	public Collection<PWiQueryDataSourceVO> getPWiQueryDataSourceCollection() {
		return PWiQueryDataSourceCollection;
	}

	public void setPWiQueryDataSourceCollection(
			Collection<PWiQueryDataSourceVO> PWiQueryDataSourceCollection) {
		this.PWiQueryDataSourceCollection = PWiQueryDataSourceCollection;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (dataSrcSysSeqId != null ? dataSrcSysSeqId.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof PWiDataSourceSystemVO)) {
			return false;
		}
		PWiDataSourceSystemVO other = (PWiDataSourceSystemVO) object;
		if ((this.dataSrcSysSeqId == null && other.dataSrcSysSeqId != null)
				|| (this.dataSrcSysSeqId != null && !this.dataSrcSysSeqId
						.equals(other.dataSrcSysSeqId))) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "com.geinfra.geaviation.pwi.model.PWiDataSourceSystem[dataSrcSysSeqId="
				+ dataSrcSysSeqId + "]";
	}

}
