package com.geinfra.geaviation.pwi.common.bean;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.context.PWiContext;
import com.geinfra.geaviation.pwi.util.PWiConstants;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 5, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : BaseBean - base display bean.
 * 
 * Revision Log Aug 5, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class BaseBean {

	/**
	 * Add a JSF user error with the default message and also logs the exception.
	 * 
	 * @param exception
	 */
	public void handleFacesError(Exception exception) {
		handleFacesError(PWiConstants.ERROR_COM_01, exception);
	}
	
	public void handleFacesError(String message, Exception exception) {
		FacesContext.getCurrentInstance().addMessage(
				message,
				new FacesMessage(FacesMessage.SEVERITY_ERROR, message, exception
						.getMessage()));
	}
	public void handleFacesError(String message) {
		FacesContext.getCurrentInstance()
				.addMessage(
						message,
						new FacesMessage(FacesMessage.SEVERITY_ERROR, message,
								message));
	}

	public void handleFacesError(String id, String message) {
		FacesContext.getCurrentInstance()
				.addMessage(
						id,
						new FacesMessage(FacesMessage.SEVERITY_ERROR, message,
								message));
	}

	public void handleFacesError(String message, Exception exception, FacesContext ctx) {
		ctx.addMessage(message, new FacesMessage(FacesMessage.SEVERITY_ERROR,
				message, exception.getMessage()));
	}

	public void handleFacesError(String message, FacesContext context) {
		context.addMessage(message, new FacesMessage(FacesMessage.SEVERITY_ERROR,
				message, message));
	}

	public void handleFacesInfo(String message, Exception exception) {
		FacesContext.getCurrentInstance().addMessage(
				message,
				new FacesMessage(FacesMessage.SEVERITY_INFO, message, exception
						.getMessage()));
	}

	public void handleFacesInfo(String message) {
		FacesContext.getCurrentInstance().addMessage(message,
				new FacesMessage(FacesMessage.SEVERITY_INFO, message, message));
	}

	public void handleFacesInfo(String message, Exception exception, FacesContext context) {
		context.addMessage(message, new FacesMessage(FacesMessage.SEVERITY_INFO,
				message, exception.getMessage()));
	}

	public void handleFacesInfo(String message, FacesContext context) {
		context.addMessage(message, new FacesMessage(FacesMessage.SEVERITY_INFO,
				message, message));
	}

	/**
	 * getSsoId is a convenience method to allow beans to call
	 * <code>PWiContext.getCurrentInstance().getUserSso()</code> without having
	 * to type it out every time
	 * @return the ssoId
	 * @throws PWiException if the user's SSO is not found
	 */
	public String getSsoId() throws PWiException {
		return PWiContext.getCurrentInstance().getUserSso();
	}

}
