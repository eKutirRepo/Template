package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.model.PWiObjectTypeVO;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 5, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Data access object for object types.
 * 
 * Revision Log Aug 5, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public interface ObjectTypeDAO {
	/**
	 * Used in Quick Intelligence and click-through menus
	 * @return all PWi Object Types for
	 */
	public List<PWiObjectTypeVO> findAllPWiObjectTypes();

	/**
	 * Used to administrate default QI options
	 * 
	 * @return all PWi Object Types visible in Quick Intelligence 
	 */
	public List<PWiObjectTypeVO> findPWiQiObjectTypes();

	/**
	 * @param map the current user's groups
	 * @return list of object types relevant in the specified groups
	 */
	public List<PWiObjectTypeVO> findPWiObjectTypesForGroups(List<String> groups);

	public PWiObjectTypeVO getObjectTypeById(Integer objectTypeId);
	
	/**
	 * Used to administrate Object Type visibility
	 * 
	 * @return all PLMi object types, including a string list of relevant groups
	 */
	public List<PWiObjectTypeVO> getAllObjectTypesWithGroups();

	/**
	 * Checks whether name or description is being used by another object type
	 * 
	 * @param objTypNm
	 * @param objTypDesc
	 * @param objTypSeqId
	 * @return the number of object types, besides this one, using the same name
	 * 		or description
	 */
	public int checkNamesEdit(String objTypNm, String objTypDesc,
			Integer objTypSeqId);

	public int checkNames(String objTypNm, String objTypDesc);

	public Integer createNewObjectType(final String objTypName,
			final String objTypDesc, final boolean shwInQi,
			final String sso);

	public void updateObjectType(PWiObjectTypeVO objectType, String sso);
}
