/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMProjChngDtlData.java
 * @Creation date: 1-Feb-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;
import java.util.List;

public class PLMProjChngDtlData {
	
	/**
	  * Holds the topLevelParentId
	  */
	private String topLevelParentId;
	/**
	  * Holds the topLevelParent
	  */
	private String topLvlPrntPrjChng;
	/**
	  * Holds the parentId
	  */
	private String parentId;
	/**
	  * Holds the parentPart
	  */
	private String parentPart;
	/**
	  * Holds the childId
	  */
	private String childId;
	/**
	  * Holds the childPart
	  */
	private String childPart;
	/**
	  * Holds the childPartDesc
	  */
	private String childPartDesc;
	/**
	  * Holds the partType
	  */
	private String partType;
	/**
	  * Holds the partRev
	  */
	private String partRev;
	/**
	  * Holds the partStatus
	  */
	private String partStatus;
	/**
	  * Holds the childPartDate
	  */
	private String childPartDate;
	/**
	  * Holds the ecrId
	  */
	private String ecrId;
	/**
	  * Holds the ecrName
	  */
	private String ecrName;
	/**
	  * Holds the ecrDesc
	  */
	private String ecrDescPrjChng;
	/**
	  * Holds the ecoId
	  */
	private String ecoId;
	/**
	  * Holds the ecoName
	  */
	private String ecoName;
	/**
	  * Holds the ecoDesc
	  */
	private String ecoDesc;
	/**
	  * Holds the ecoSubst
	  */
	private String ecoSubst;
	/**
	  * Holds the ecoFastTrack
	  */
	private String ecoFastTrack;
	/**
	  * Holds the ecrStatus
	  */
	private String ecrStatus;
	/**
	  * Holds the ecoStatus
	  */
	private String ecoStatus;
	/**
	  * Holds the requestedChange
	  */
	private String requestedChange;
	/**
	  * Holds the dispInField
	  */
	private String dispInField;
	/**
	  * Holds the dispInProcess
	  */
	private String dispInProcess;
	/**
	  * Holds the dispInStock
	  */
	private String dispInStock;
	/**
	  * Holds the dispOnOrder
	  */
	private String dispOnOrder;
	/**
	  * Holds the ecoPolicy
	  */
	private String ecoPolicy;
	/**
	  * Holds the ecoCtgChng
	  */
	private String ecoCtgChng;
	/**
	  * Holds the ecoSev
	  */
	
	private String ecoSev;
	/**
	  * Holds the impactStmt
	  */
	private String impactStmt;
	/**
	  * Holds the bomMarkup
	  */
	private String bomMarkup;
	/**
	  * Holds the bomMarkupType
	  */
	private String bomMarkupType;
	
	
	//newly added fields of project change summary
	/**
	  * Holds the rdo
	  */
	private String rdo;
	/**
	  * Holds the ecrModifiedDate
	  */
	private String ecrModifiedDate;
	/**
	  * Holds the ecoModifiedDate
	  */
	private String ecoModifiedDate;
	/**
	  * Holds the ecrCategoryChng
	  */
	private String ecrCategoryChng;
	/**
	  * Holds the ecrOrig
	  */
	private String ecrOrig;
	/**
	  * Holds the ecrRespDesign
	  */
	private String ecrRespDesign;
	/**
	  * Holds the ecrOrigName
	  */
	private String ecrOrigName;
	/**
	  * Holds the ecrRespDesignName
	  */
	private String ecrRespDesignName;
	/**
	  * Holds the ecrStartDate
	  */
	 private Date ecrStartDate;
		/**
	  * Holds the ecrEndDate
	  */
	 private Date ecrEndDate;
		/**
	  * Holds the ecoStrDate
	  */
	 private Date ecoStrDate;
		/**
	  * Holds the ecoEndDate
	  */
	 private Date ecoEndDate; 
		/**
	  * Holds the selRdoList
	  */
	 private List<String> selRdoList;
		/**
	  * Holds the selEcrStateList
	  */
	 private List<String> selEcrStateList;
		/**
	  * Holds the selCtgryList
	  */
	 private List<String> selCtgryList;
		/**
	  * Holds the allOpenEcr
	  */
	 private boolean allOpenEcr;
		/**
	  * Holds the selEcoStateList
	  */
	 private List<String> selEcoStateList;
		/**
	  * Holds the allOpenEco
	  */
	 private boolean allOpenEco;
	/**
	  * Holds the contractDtl
	  */
	 private String contractDtl;
	 /**
	  * Holds the topParts
	  */
	 private String  topParts;
	/**
	 * @return the topLevelParentId
	 */
	public String getTopLevelParentId() {
		return topLevelParentId;
	}
	/**
	 * @param topLevelParentId the topLevelParentId to set
	 */
	public void setTopLevelParentId(String topLevelParentId) {
		this.topLevelParentId = topLevelParentId;
	}
	
	/**
	 * @return the topLvlPrntPrjChng
	 */
	public String getTopLvlPrntPrjChng() {
		return topLvlPrntPrjChng;
	}
	/**
	 * @param topLvlPrntPrjChng the topLvlPrntPrjChng to set
	 */
	public void setTopLvlPrntPrjChng(String topLvlPrntPrjChng) {
		this.topLvlPrntPrjChng = topLvlPrntPrjChng;
	}
	/**
	 * @return the topLevelParent
	 */
	/*public String getTopLevelParent() {
		return topLevelParent;
	}*/
	/**
	 * @param topLevelParent the topLevelParent to set
	 */
	/*public void setTopLevelParent(String topLevelParent) {
		this.topLevelParent = topLevelParent;
	}*/
	/**
	 * @return the parentId
	 */
	public String getParentId() {
		return parentId;
	}
	/**
	 * @param parentId the parentId to set
	 */
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	/**
	 * @return the parentPart
	 */
	public String getParentPart() {
		return parentPart;
	}
	/**
	 * @param parentPart the parentPart to set
	 */
	public void setParentPart(String parentPart) {
		this.parentPart = parentPart;
	}
	/**
	 * @return the childId
	 */
	public String getChildId() {
		return childId;
	}
	/**
	 * @param childId the childId to set
	 */
	public void setChildId(String childId) {
		this.childId = childId;
	}
	/**
	 * @return the childPart
	 */
	public String getChildPart() {
		return childPart;
	}
	/**
	 * @param childPart the childPart to set
	 */
	public void setChildPart(String childPart) {
		this.childPart = childPart;
	}
	/**
	 * @return the childPartDesc
	 */
	public String getChildPartDesc() {
		return childPartDesc;
	}
	/**
	 * @param childPartDesc the childPartDesc to set
	 */
	public void setChildPartDesc(String childPartDesc) {
		this.childPartDesc = childPartDesc;
	}
	/**
	 * @return the partType
	 */
	public String getPartType() {
		return partType;
	}
	/**
	 * @param partType the partType to set
	 */
	public void setPartType(String partType) {
		this.partType = partType;
	}
	/**
	 * @return the partRev
	 */
	public String getPartRev() {
		return partRev;
	}
	/**
	 * @param partRev the partRev to set
	 */
	public void setPartRev(String partRev) {
		this.partRev = partRev;
	}
	/**
	 * @return the partStatus
	 */
	public String getPartStatus() {
		return partStatus;
	}
	/**
	 * @param partStatus the partStatus to set
	 */
	public void setPartStatus(String partStatus) {
		this.partStatus = partStatus;
	}
	/**
	 * @return the childPartDate
	 */
	public String getChildPartDate() {
		return childPartDate;
	}
	/**
	 * @param childPartDate the childPartDate to set
	 */
	public void setChildPartDate(String childPartDate) {
		this.childPartDate = childPartDate;
	}
	/**
	 * @return the ecrId
	 */
	public String getEcrId() {
		return ecrId;
	}
	/**
	 * @param ecrId the ecrId to set
	 */
	public void setEcrId(String ecrId) {
		this.ecrId = ecrId;
	}
	/**
	 * @return the ecrName
	 */
	public String getEcrName() {
		return ecrName;
	}
	/**
	 * @param ecrName the ecrName to set
	 */
	public void setEcrName(String ecrName) {
		this.ecrName = ecrName;
	}
	
	/**
	 * @return the ecrDescPrjChng
	 */
	public String getEcrDescPrjChng() {
		return ecrDescPrjChng;
	}
	/**
	 * @param ecrDescPrjChng the ecrDescPrjChng to set
	 */
	public void setEcrDescPrjChng(String ecrDescPrjChng) {
		this.ecrDescPrjChng = ecrDescPrjChng;
	}
	/**
	 * @return the ecrDesc
	 */
	/*public String getEcrDesc() {
		return ecrDesc;
	}*/
	/**
	 * @param ecrDesc the ecrDesc to set
	 */
	/*public void setEcrDesc(String ecrDesc) {
		this.ecrDesc = ecrDesc;
	}*/
	/**
	 * @return the ecoId
	 */
	public String getEcoId() {
		return ecoId;
	}
	/**
	 * @param ecoId the ecoId to set
	 */
	public void setEcoId(String ecoId) {
		this.ecoId = ecoId;
	}
	/**
	 * @return the ecoName
	 */
	public String getEcoName() {
		return ecoName;
	}
	/**
	 * @param ecoName the ecoName to set
	 */
	public void setEcoName(String ecoName) {
		this.ecoName = ecoName;
	}
	/**
	 * @return the ecoDesc
	 */
	public String getEcoDesc() {
		return ecoDesc;
	}
	/**
	 * @param ecoDesc the ecoDesc to set
	 */
	public void setEcoDesc(String ecoDesc) {
		this.ecoDesc = ecoDesc;
	}
	/**
	 * @return the ecoSubst
	 */
	public String getEcoSubst() {
		return ecoSubst;
	}
	/**
	 * @param ecoSubst the ecoSubst to set
	 */
	public void setEcoSubst(String ecoSubst) {
		this.ecoSubst = ecoSubst;
	}
	/**
	 * @return the ecoFastTrack
	 */
	public String getEcoFastTrack() {
		return ecoFastTrack;
	}
	/**
	 * @param ecoFastTrack the ecoFastTrack to set
	 */
	public void setEcoFastTrack(String ecoFastTrack) {
		this.ecoFastTrack = ecoFastTrack;
	}
	/**
	 * @return the ecrStatus
	 */
	public String getEcrStatus() {
		return ecrStatus;
	}
	/**
	 * @param ecrStatus the ecrStatus to set
	 */
	public void setEcrStatus(String ecrStatus) {
		this.ecrStatus = ecrStatus;
	}
	/**
	 * @return the ecoStatus
	 */
	public String getEcoStatus() {
		return ecoStatus;
	}
	/**
	 * @param ecoStatus the ecoStatus to set
	 */
	public void setEcoStatus(String ecoStatus) {
		this.ecoStatus = ecoStatus;
	}
	/**
	 * @return the requestedChange
	 */
	public String getRequestedChange() {
		return requestedChange;
	}
	/**
	 * @param requestedChange the requestedChange to set
	 */
	public void setRequestedChange(String requestedChange) {
		this.requestedChange = requestedChange;
	}
	/**
	 * @return the dispInField
	 */
	public String getDispInField() {
		return dispInField;
	}
	/**
	 * @param dispInField the dispInField to set
	 */
	public void setDispInField(String dispInField) {
		this.dispInField = dispInField;
	}
	/**
	 * @return the dispInProcess
	 */
	public String getDispInProcess() {
		return dispInProcess;
	}
	/**
	 * @param dispInProcess the dispInProcess to set
	 */
	public void setDispInProcess(String dispInProcess) {
		this.dispInProcess = dispInProcess;
	}
	/**
	 * @return the dispInStock
	 */
	public String getDispInStock() {
		return dispInStock;
	}
	/**
	 * @param dispInStock the dispInStock to set
	 */
	public void setDispInStock(String dispInStock) {
		this.dispInStock = dispInStock;
	}
	/**
	 * @return the dispOnOrder
	 */
	public String getDispOnOrder() {
		return dispOnOrder;
	}
	/**
	 * @param dispOnOrder the dispOnOrder to set
	 */
	public void setDispOnOrder(String dispOnOrder) {
		this.dispOnOrder = dispOnOrder;
	}
	/**
	 * @return the ecoPolicy
	 */
	public String getEcoPolicy() {
		return ecoPolicy;
	}
	/**
	 * @param ecoPolicy the ecoPolicy to set
	 */
	public void setEcoPolicy(String ecoPolicy) {
		this.ecoPolicy = ecoPolicy;
	}
	/**
	 * @return the ecoCtgChng
	 */
	public String getEcoCtgChng() {
		return ecoCtgChng;
	}
	/**
	 * @param ecoCtgChng the ecoCtgChng to set
	 */
	public void setEcoCtgChng(String ecoCtgChng) {
		this.ecoCtgChng = ecoCtgChng;
	}
	/**
	 * @return the ecoSev
	 */
	public String getEcoSev() {
		return ecoSev;
	}
	/**
	 * @param ecoSev the ecoSev to set
	 */
	public void setEcoSev(String ecoSev) {
		this.ecoSev = ecoSev;
	}
	/**
	 * @return the impactStmt
	 */
	public String getImpactStmt() {
		return impactStmt;
	}
	/**
	 * @param impactStmt the impactStmt to set
	 */
	public void setImpactStmt(String impactStmt) {
		this.impactStmt = impactStmt;
	}
	/**
	 * @return the bomMarkup
	 */
	public String getBomMarkup() {
		return bomMarkup;
	}
	/**
	 * @param bomMarkup the bomMarkup to set
	 */
	public void setBomMarkup(String bomMarkup) {
		this.bomMarkup = bomMarkup;
	}
	/**
	 * @return the bomMarkupType
	 */
	public String getBomMarkupType() {
		return bomMarkupType;
	}
	/**
	 * @param bomMarkupType the bomMarkupType to set
	 */
	public void setBomMarkupType(String bomMarkupType) {
		this.bomMarkupType = bomMarkupType;
	}
	/**
	 * @return the rdo
	 */
	public String getRdo() {
		return rdo;
	}
	/**
	 * @param rdo the rdo to set
	 */
	public void setRdo(String rdo) {
		this.rdo = rdo;
	}
	/**
	 * @return the ecrModifiedDate
	 */
	public String getEcrModifiedDate() {
		return ecrModifiedDate;
	}
	/**
	 * @param ecrModifiedDate the ecrModifiedDate to set
	 */
	public void setEcrModifiedDate(String ecrModifiedDate) {
		this.ecrModifiedDate = ecrModifiedDate;
	}
	/**
	 * @return the ecoModifiedDate
	 */
	public String getEcoModifiedDate() {
		return ecoModifiedDate;
	}
	/**
	 * @param ecoModifiedDate the ecoModifiedDate to set
	 */
	public void setEcoModifiedDate(String ecoModifiedDate) {
		this.ecoModifiedDate = ecoModifiedDate;
	}
	/**
	 * @return the ecrCategoryChng
	 */
	public String getEcrCategoryChng() {
		return ecrCategoryChng;
	}
	/**
	 * @param ecrCategoryChng the ecrCategoryChng to set
	 */
	public void setEcrCategoryChng(String ecrCategoryChng) {
		this.ecrCategoryChng = ecrCategoryChng;
	}
	/**
	 * @return the ecrOrig
	 */
	public String getEcrOrig() {
		return ecrOrig;
	}
	/**
	 * @param ecrOrig the ecrOrig to set
	 */
	public void setEcrOrig(String ecrOrig) {
		this.ecrOrig = ecrOrig;
	}
	/**
	 * @return the ecrRespDesign
	 */
	public String getEcrRespDesign() {
		return ecrRespDesign;
	}
	/**
	 * @param ecrRespDesign the ecrRespDesign to set
	 */
	public void setEcrRespDesign(String ecrRespDesign) {
		this.ecrRespDesign = ecrRespDesign;
	}
	/**
	 * @return the ecrOrigName
	 */
	public String getEcrOrigName() {
		return ecrOrigName;
	}
	/**
	 * @param ecrOrigName the ecrOrigName to set
	 */
	public void setEcrOrigName(String ecrOrigName) {
		this.ecrOrigName = ecrOrigName;
	}
	/**
	 * @return the ecrRespDesignName
	 */
	public String getEcrRespDesignName() {
		return ecrRespDesignName;
	}
	/**
	 * @param ecrRespDesignName the ecrRespDesignName to set
	 */
	public void setEcrRespDesignName(String ecrRespDesignName) {
		this.ecrRespDesignName = ecrRespDesignName;
	}
	/**
	 * @return the ecrStartDate
	 */
	public Date getEcrStartDate() {
		Date ecrStartDt=ecrStartDate;
		return ecrStartDt;
	}
	/**
	 * @param ecrStartDate the ecrStartDate to set
	 */
	public void setEcrStartDate(Date ecrStartDate) {
		Date ecrStartDt=ecrStartDate;
		this.ecrStartDate = ecrStartDt;
	}
	/**
	 * @return the ecrEndDate
	 */
	public Date getEcrEndDate() {
		Date ecrEndDt=ecrEndDate;
		return ecrEndDt;
	}
	/**
	 * @param ecrEndDate the ecrEndDate to set
	 */
	public void setEcrEndDate(Date ecrEndDate) {
		Date ecrEndDt=ecrEndDate;
		this.ecrEndDate = ecrEndDt;
	}
	/**
	 * @return the ecoStrDate
	 */
	public Date getEcoStrDate() {
		Date ecoStrDt=ecoStrDate;
		return ecoStrDt;
	}
	/**
	 * @param ecoStrDate the ecoStrDate to set
	 */
	public void setEcoStrDate(Date ecoStrDate) {
		Date ecoStrDt=ecoStrDate;
		this.ecoStrDate = ecoStrDt;
	}
	/**
	 * @return the ecoEndDate
	 */
	public Date getEcoEndDate() {
		Date ecoEndDt=ecoEndDate;
		return ecoEndDt;
	}
	/**
	 * @param ecoEndDate the ecoEndDate to set
	 */
	public void setEcoEndDate(Date ecoEndDate) {
		Date ecoEndDt=ecoEndDate;
		this.ecoEndDate = ecoEndDt;
	}
	/**
	 * @return the selRdoList
	 */
	public List<String> getSelRdoList() {
		return selRdoList;
	}
	/**
	 * @param selRdoList the selRdoList to set
	 */
	public void setSelRdoList(List<String> selRdoList) {
		this.selRdoList = selRdoList;
	}
	/**
	 * @return the selEcrStateList
	 */
	public List<String> getSelEcrStateList() {
		return selEcrStateList;
	}
	/**
	 * @param selEcrStateList the selEcrStateList to set
	 */
	public void setSelEcrStateList(List<String> selEcrStateList) {
		this.selEcrStateList = selEcrStateList;
	}
	/**
	 * @return the selCtgryList
	 */
	public List<String> getSelCtgryList() {
		return selCtgryList;
	}
	/**
	 * @param selCtgryList the selCtgryList to set
	 */
	public void setSelCtgryList(List<String> selCtgryList) {
		this.selCtgryList = selCtgryList;
	}
	/**
	 * @return the allOpenEcr
	 */
	public boolean isAllOpenEcr() {
		return allOpenEcr;
	}
	/**
	 * @param allOpenEcr the allOpenEcr to set
	 */
	public void setAllOpenEcr(boolean allOpenEcr) {
		this.allOpenEcr = allOpenEcr;
	}
	/**
	 * @return the selEcoStateList
	 */
	public List<String> getSelEcoStateList() {
		return selEcoStateList;
	}
	/**
	 * @param selEcoStateList the selEcoStateList to set
	 */
	public void setSelEcoStateList(List<String> selEcoStateList) {
		this.selEcoStateList = selEcoStateList;
	}
	/**
	 * @return the allOpenEco
	 */
	public boolean isAllOpenEco() {
		return allOpenEco;
	}
	/**
	 * @param allOpenEco the allOpenEco to set
	 */
	public void setAllOpenEco(boolean allOpenEco) {
		this.allOpenEco = allOpenEco;
	}
	/**
	 * @return the contractDtl
	 */
	public String getContractDtl() {
		return contractDtl;
	}
	/**
	 * @param contractDtl the contractDtl to set
	 */
	public void setContractDtl(String contractDtl) {
		this.contractDtl = contractDtl;
	}
	/**
	 * @return the topParts
	 */
	public String getTopParts() {
		return topParts;
	}
	/**
	 * @param topParts the topParts to set
	 */
	public void setTopParts(String topParts) {
		this.topParts = topParts;
	}
	
	
}
