/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMFmiDaoIfc.java
 * @Creation date: 12-June-2014
 * @version 1.0
 * @author : Srinivas
 */

package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMDocGenFmiData;
import com.geinfra.geaviation.pwi.data.PLMFmiAppReportData;
import com.geinfra.geaviation.pwi.data.PLMFmiTemplateData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

  public interface PLMFmiDaoIfc {
	
	public List<PLMDocGenFmiData> getFmiReqValues(List<String> reqNameList, List<String> ceiList, 
			List<String> mliList, List<PLMDocGenFmiData> tempMlidetailslist, 
			List<PLMDocGenFmiData> ceiDataList) throws PLMCommonException;
	
	//Newly Added for FMI Manage Text
	public Map<String, List<SelectItem>> getRequirementList() throws PLMCommonException;
	
	public Map<String, List<SelectItem>> fetchCeiNameList(List<String> selRequirementList)  throws PLMCommonException;
	
	public Map<String, List<SelectItem>> getMliNameList(List<String> selCeiList,List<String> selRequirment)  throws PLMCommonException;
	public List<SelectItem> getReqCeiNameList(List<String> selCei) throws PLMCommonException;
	public List<SelectItem> getselectRequirementNm(List<String> selRequirment) throws PLMCommonException;
	public List<PLMFmiTemplateData> getReqCeiMliNameList(List<String> selRequirment,List<String> selCei,List<String> selMli) throws PLMCommonException;
	public String saveRequirement(PLMFmiTemplateData templateData,String ssoId) throws PLMCommonException;
	public String saveCei(String reqSeqId, String ceiSeqid, String ceiName, String ceiDesc, String ssoId) throws PLMCommonException;
	public String saveMli(String fmiId,String mliSeqId,String mliName, String mliDesc, String mliNotes, String ssoId) throws PLMCommonException;
	public String uploadFmiManageText(List<PLMFmiTemplateData> fmiMngTextDataList, String ssoId)throws PLMCommonException;
	public List<SelectItem> getCeiNameList()throws PLMCommonException;
	public PLMFmiTemplateData getCeiDetails(String selCeiName)throws PLMCommonException;
	public List<SelectItem> getMliNameList()throws PLMCommonException;
	public PLMFmiTemplateData getMliDetails(String selMliName)throws PLMCommonException;
	
	
	//Newly Added for FMI Applicability Report
	/**
	 * This methods is used for getDropDownvaluesFmiAppRpt
	 * 
	 * @return Map
	 * throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getDropDownvaluesFmiAppRpt()	throws PLMCommonException;
	
	/**
	 * This method is used to Generate FMI Report
	 * 
	 * @param cntrtNm
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMFmiAppReportData> generateFmiAppReport(List<String> selfmiAppRequirment,boolean allOpenReq,List<String> selfmiAppFrame,boolean allOpenFrame) throws PLMCommonException;
	
	//Newly Added by srinvias
	/**
	 * This method is used for bulk upload of Requirement
	 * 
	 * @param ssoId
	 * @return List
	 * @throws PLMCommonException
	 */
	public String uploadBulkReqData(List<PLMFmiTemplateData> bulkRequirmntList, String ssoId)throws PLMCommonException;
	/**
	 * This method is used for retrieving Requirement Data
	 * 
	 * @param selRequirment
	 * @return List
	 * @throws PLMCommonException
	 */
	public PLMFmiTemplateData getReqDesc(String selRequirment) throws PLMCommonException;	
	/**
	 * This method is used for saving Bulk CEI Data
	 * 
	 * @param ssoId
	 * @return List
	 * @throws PLMCommonException
	 */
	public String addBulkCEIData(List<PLMFmiTemplateData> bulkCeiList, String ssoId)throws PLMCommonException;
	/**
	 * This method is used for saving Bulk MLI Data
	 * 
	 * @param ssoId
	 * @return List
	 * @throws PLMCommonException
	 */
	public String addBulkMLIData(List<PLMFmiTemplateData> bulkMliList, String ssoId)throws PLMCommonException;



}
