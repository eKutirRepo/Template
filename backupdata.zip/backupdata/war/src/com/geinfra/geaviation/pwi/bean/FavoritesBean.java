package com.geinfra.geaviation.pwi.bean;

//import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.json.JsonUtil;
import com.geinfra.geaviation.pwi.service.CustomQueryService;

/**
 * 
 * Project : Product Lifecycle Management Date Written : May 21, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Backing bean for the Favorites page.
 * 
 * Revision Log May 21, 2010 | v1.0.
 * --------------------------------------------------------------
 * 2013.03.18 pH  removed non-JSON favorites list, commented out Subscriptions.
 */
public class FavoritesBean extends BaseBean {
//	private static final Logger LOGGER = PWiUtil.getInstance().getLogger(FavoritesBean.class);

	// Injected
	private CustomQueryService customQueryService;

	private String favoritesJson;
//	private HtmlDataTable favoritesTable = new HtmlDataTable();

	public void setCustomQueryService(CustomQueryService customQueryService) {
		this.customQueryService = customQueryService;
	}

	public String getFavoritesJson() throws PWiException {
		if (favoritesJson == null) {
			loadFavorites();
		}
		return favoritesJson;
	}

	private void loadFavorites() throws PWiException {
		favoritesJson = JsonUtil.getInstance().listToJson(
				customQueryService.getAllFavoriteQueriesforUser(getSsoId()));
	}

//	public String viewSubscriptionRes() throws IOException, PWiException {
//		PWiUserCustomQueryVO selectedCustQry = (PWiUserCustomQueryVO) favoritesTable
//				.getRowData();
//
//		// Translate File into lists
//		List<List<String>> data = new ArrayList<List<String>>();
//		BufferedReader reader = null;
//		try {
//			String name = FilePathUtil.getInstance().subscriptionPath(
//					FilePathUtil.getInstance().appDataMountPathDefault(),
//					getSsoId())
//					+ selectedCustQry.getCmprsnRsltFlPthTxt();
//			File file = new File(name);
//			reader = new BufferedReader(new InputStreamReader(
//					new FileInputStream(file)));
//			String line = reader.readLine();
//			do {
//				String[] row = StringUtils.split(line, ",");
//
//				List<String> rowList = new ArrayList<String>();
//				for (String value : row) {
//					rowList.add(value);
//				}
//
//				data.add(rowList);
//			} while ((line = reader.readLine()) != null);
//		} finally {
//			if (reader != null) {
//				try {
//					reader.close();
//				} catch (IOException e) {
//					LOGGER.error("Error closing subscription comparison file.",
//							e);
//				}
//			}
//		}
//
//		// TODO getQueriesResultsBean().setSelectedCustQry(selectedCustQry);
//		// getQueriesResultsBean().setData(data);
//		// getQueriesResultsBean().setColumns(columns);
//
//		return "subscriptionResult";
//	}
//
//	public String modifySubscription() {
//		// TODO PWiUserCustomQueryVO selectedCustQry = (PWiUserCustomQueryVO)
//		// favoritesTable
//		// .getRowData();
//		return "subscribe";
//	}
//
//	public void cancelSubscription() throws PWiException {
//		PWiUserCustomQueryVO selectedCustQry = (PWiUserCustomQueryVO) favoritesTable
//				.getRowData();
//		int obj;
//		obj = customQueryService.cancelFavoriteQuerySubscriptionById(getSsoId(),
//				selectedCustQry.getPrtyCstmQrySeqId().intValue());
//		if (obj <= 0) {
//			throw new PWiException("Unable to cancel subscription.");
//		}
//	}
//
//	public HtmlDataTable getFavoritesTable() {
//		return favoritesTable;
//	}
//
//	public void setFavoritesTable(HtmlDataTable favoritesTable) {
//		this.favoritesTable = favoritesTable;
//	}
}
