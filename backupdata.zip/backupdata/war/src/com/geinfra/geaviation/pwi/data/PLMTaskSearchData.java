/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMTaskSearchData.java
 * @Creation date: 27-June-2011
 * @version 1.0
 * @author :Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "PLMTaskSearchData")
public class PLMTaskSearchData {
	/**
	 * Holds the name
	 */
	private String name;
	/**
	 * Holds the description
	 */
	private String description;
	/**
	 * Holds the owner
	 */
	private String owner;
	/**
	 * Holds the ownerName
	 */
	private String ownerName;
	/**
	 * Holds the orTaskPreTask
	 */
	private String orTaskPreTask;
	/**
	 * Holds the assignee
	 */
	private String assignee;
	/**
	 * Holds the assigneeName
	 */
	private String assigneeName;
	/**
	 * Holds the availableName
	 */
	private String availableName;
	/**
	 * Holds the desc
	 */
	private String desc;
	/**
	 * Holds the taskAndProject
	 */
	private String taskAndProject;
	/**
	 * Holds the predessorNum
	 */
	private String predessorNum;
	/**
	 * Holds the predessorTitle
	 */
	private String predessorTitle;
	/**
	 * Holds the dependencyType
	 */
	private String dependencyType;
	/**
	 * Holds the successorNum
	 */

	private String successorNum;
	/**
	 * Holds the successorTitle
	 */
	private String successorTitle;
	/**
	 * Holds the allOpen
	 */

	private boolean allOpen;
	/**
	 * Holds the state
	 */
	private String state;
	/**
	 * Holds the taskStateList
	 */
	private List<String> taskStateList;
	/**
	 * Holds the stateExcel
	 */
	private String stateExcel;
	/**
	 * Holds the percentageComplete
	 */
	private String percentageComplete;
	/**
	 * Holds the orginator
	 */

	private String orginator;
	/**
	 * Holds the orginatorName
	 */
	private String orginatorName;
	/**
	 * Holds the estimatedFinish
	 */
	private Date estimatedFinish;
	/**
	 * Holds the actualFinish
	 */
	private Date actualFinish;
	/**
	 * Holds the estimatedFinishFromDate
	 */
	private Date estimatedFinishFromDate;
	/**
	 * Holds the estimatedFinishToDate
	 */
	private Date estimatedFinishToDate;
	/**
	 * Holds the actualFinishFromDate
	 */
	private Date actualFinishFromDate;
	/**
	 * Holds the actualFinishToDate
	 */
	private Date actualFinishToDate;
	/**
	 * Holds the geActivityCode
	 */
	private String geActivityCode;
	/**
	 * Holds the orgTaskName
	 */
	private String orgTaskName;

	/**
	 * Holds the status
	 */
	private String status;
	/**
	 * Holds the taskApproval
	 */
	private String taskApproval;
	/**
	 * Holds the type
	 */
	private String type;
	/**
	 * Holds the voucherfind
	 */
	private String voucherfind;
	/**
	 * Holds the context
	 */
	private String context;
	/**
	 * Holds the policy
	 */
	private String policy;
	/**
	 * Holds the completedate
	 */
	private Date completedate;
	/**
	 * Holds the duedate
	 */
	private Date duedate;

	/**
	 * Holds the projectrole
	 */
	private String projectrole;
	/**
	 * Holds the taskReq
	 */
	private String taskReq;
	/**
	 * Holds the synopsis
	 */
	private String synopsis;
	/**
	 * Holds the note
	 */
	private String note;
	/**
	 * Holds the dependency
	 */
	private String dependency;
	/**
	 * Holds the action
	 */
	private String action;
	/**
	 * Holds the deliverable
	 */
	private String deliverable;
	/**
	 * Holds the associateitem
	 */
	private String associateitem;
	/**
	 * Holds the findSource
	 */
	private String findSource;
	/**
	 * Holds the statusapprove
	 */
	private String statusapprove;
	/**
	 * Holds the title
	 */
	private String title;
	/**
	 * Holds the projectName
	 */
	private String projectName;
	/**
	 * Holds the projectDesc
	 */
	private String projectDesc;
	/**
	 * Holds the contractName
	 */
	private String contractName;
	/**
	 * Holds the approveStatus
	 */
	private String approveStatus;
	/**
	 * Holds the taskActual
	 */
	private String taskActual;
	/**
	 * Holds the duration
	 */
	private String duration;
	/**
	 * Holds the taskResponsiblity
	 */
	private String taskResponsiblity;
	/**
	 * Holds the taskResponsiblityName
	 */
	private String taskResponsiblityName;
	/**
	 * Holds the requiredHours
	 */
	private String requiredHours;
	/**
	 * Holds the predecessors
	 */
	private String predecessors;
	/**
	 * Holds the successors
	 */
	private String successors;
	/**
	 * Holds the actualStart
	 */
	private Date actualStart;
	/**
	 * Holds the estimatedStart
	 */
	private Date estimatedStart;
	/**
	 * Holds the estimatedDuration
	 */
	private String estimatedDuration;
	/**
	 * Holds the actualHours
	 */
	private String actualHours;
	/**
	 * Holds the queryName
	 */
	private String queryName;
	/**
	 * Holds the seqID
	 */

	private String seqID;
	/**
	 * Holds the ssoId
	 */
	private String ssoId;
	/**
	 * Holds the queryTxt
	 */
	private String queryTxt;
	/**
	 * Holds the serialNo
	 */
	private int serialNo;
	/**
	 * Holds the fieldNm
	 */
	private String fieldNm;
	/**
	 * Holds the fieldVal
	 */
	private String fieldVal;
	/**
	 * Holds the unitSerialNo
	 */

	private String unitSerialNo;
	/**
	 * Holds the respPrsnNM
	 */
	private String respPrsnNM;
	/**
	 * Holds the respUnitCode
	 */
	private String respUnitCode;
	/**
	 * Holds the lateFinish
	 */
	private Date lateFinish;
	/**
	 * Holds the discussion
	 */
	private String discussion;
	/**
	 * Holds the dateEntered
	 */
	private String dateEntered;
	/**
	 * Holds the enteredByUsrNM
	 */
	private String enteredByUsrNM;
	/**
	 * Holds the custNM
	 */

	private String custNM;
	/**
	 * Holds the custNeedDate
	 */
	private Date custNeedDate;
	/**
	 * Holds the ecrNo
	 */
	private String ecrNo;
	/**
	 * Holds the ecoNo
	 */
	private String ecoNo;
	/**
	 * Holds the model
	 */
	private String model;
	/**
	 * Holds the taskId
	 */
	private String taskId;
	/**
	 * Holds the taskAstdTypeList
	 */
	private List<String> taskAstdTypeList;

	/**
	 * Holds the mfgFromDate
	 */

	private Date mfgFromDate;
	/**
	 * Holds the mfgToDate
	 */
	private Date mfgToDate;
	/**
	 * Holds the customerFromDate
	 */
	private Date customerFromDate;
	/**
	 * Holds the customerToDate
	 */
	private Date customerToDate;
	/**
	 * Holds the mfgIndicator
	 */
	private String mfgIndicator;
	/**
	 * Holds the taskResponsiblityUnit
	 */
	private String taskResponsiblityUnit;
	/**
	 * Holds the mfgFinish
	 */
	private Date mfgFinish;
	/**
	 * Holds the namecustomerFinish
	 */
	private Date customerFinish;
	/**
	 * Holds the associatedName
	 */
	private String associatedName;
	/**
	 * Holds the associatedExcel
	 */
	private String associatedExcel;
	/**
	 * Holds the rowCount
	 */

	private int rowCount;
	/**
	 * Holds the eccnRdo
	 */
	private String eccnRdo;
	/**
	 * Holds the eccnName
	 */
	private String eccnName;
	/**
	 * Holds the eccnRevision
	 */
	private String eccnRevision;
	/**
	 * Holds the eccnType1
	 */
	private String eccnType1;
	/**
	 * Holds the eccnPolicy
	 */
	private String eccnPolicy;
	/**
	 * Holds the eccnDescription
	 */
	private String eccnDescription;
	/**
	 * Holds the eccnState
	 */
	private String eccnState;
	/**
	 * Holds the eccnOriginationDate
	 */
	private Date eccnOriginationDate;
	/**
	 * Holds the eccnReleaseDate
	 */
	private Date eccnReleaseDate;
	/**
	 * Holds the eccnOriginatorSSO
	 */
	private String eccnOriginatorSSO;
	/**
	 * Holds the eccnEcn
	 */
	private String eccnEcn;

	// //ADDED BY SUDHAKAR FOR PREDESSOR SUCCESSOR PAGE
	/**
	 * Holds the predSuccName
	 */
	private String predSuccName;
	/**
	 * Holds the taskName
	 */
	private String taskName;
	/**
	 * Holds the taskTitle
	 */
	private String taskTitle;
	/**
	 * Holds the delay
	 */
	private String delay;
	/**
	 * Holds the lineBrkr
	 */
	private boolean lineBrkr;
	/**
	 * Holds the taskNameActive
	 */
	private boolean taskNameActive;
	/**
	 * Holds the task
	 */
	private String task;
	/**
	 * Holds the taskNamePredessorActive
	 */
	private boolean taskNamePredessorActive;
	/**
	 * Holds the taskNameSuccessorActive
	 */
	private boolean taskNameSuccessorActive;

	// newly added fields
	/**
	 * Holds the orignator
	 */
	private String orignator;
	/**
	 * Holds the orignatorName
	 */
	private String orignatorName;
	/**
	 * Holds the respSso
	 */
	private String respSso;
	/**
	 * Holds the geMfggDeliverableIndr
	 */
	private String geMfggDeliverableIndr;
	/**
	 * Holds the geMfggNeedDate
	 */
	private String geMfggNeedDate;
	/**
	 * Holds the geCstmrNeedDate
	 */
	private String geCstmrNeedDate;
	/**
	 * Holds the geTaskResponsibleUnit
	 */
	private String geTaskResponsibleUnit;
	/**
	 * Holds the taskAndProjectPred
	 */
	private String taskAndProjectPred;

	// ENDED BY SUDHAKAR FOR PREDESSOR SUCCESSOR PAGE

	/**
	 * Holds the checkTask
	 */
	private boolean checkTask;
	/**
	 * Holds the searchResultList
	 */
	private List<PLMTaskSearchData> searchResultList;

	/**
	 * Holds the geTotalFloat
	 */
	private String geTotalFloat;
	/**
	 * Holds the geLateFinishDate
	 */
	private Date geLateFinishDate;
	// Added by Shekhar for Early and Late Finish Date Filters
	/**
	 * Holds the geEarlyFinishDate
	 */
	private Date geEarlyFinishDate;
	/**
	 * Holds the earlyFinishFromDate
	 */
	private Date earlyFinishFromDate;
	/**
	 * Holds the earlyFinishToDate
	 */
	private Date earlyFinishToDate;
	/**
	 * Holds the lateFinishFromDate
	 */
	private Date lateFinishFromDate;
	/**
	 * Holds the earlyFinishToDate
	 */
	private Date lateFinishToDate;

	/**
	 * Holds the actualFnshFromDtExl
	 */
	private String actualFnshFromDtExl;

	/**
	 * Holds the actualFnshToDtExl
	 */
	private String actualFnshToDtExl;
	/**
	 * Holds the estimateFnshFromDtExl
	 */
	private String estimateFnshFromDtExl;
	/**
	 * Holds the estimateFnshToDtExl
	 */
	private String estimateFnshToDtExl;
	/**
	 * Holds the custNeedFromDtExl
	 */
	private String custNeedFromDtExl;
	/**
	 * Holds the custNeedToDtExl
	 */
	private String custNeedToDtExl;
	/**
	 * Holds the mfgNeedFromDtExl
	 */
	private String mfgNeedFromDtExl;
	/**
	 * Holds the mfgNeedTotExl
	 */
	private String mfgNeedTotExl;
	/**
	 * Holds the earlyFnshFromDtExl
	 */
	private String earlyFnshFromDtExl;
	/**
	 * Holds the earlyFnshToDtExl
	 */
	private String earlyFnshToDtExl;
	/**
	 * Holds the lateFnshFromDtExl
	 */
	private String lateFnshFromDtExl;
	/**
	 * Holds the lateFnshToDtExl
	 */
	private String lateFnshToDtExl;

	/**
	 * Holds the geMfggNeedDateExl
	 */
	private Date geMfggNeedDateExl;
	/**
	 * Holds the geCstmrNeedDateExl
	 */
	private Date geCstmrNeedDateExl;
	/**
	 * Holds the dateEnteredExl
	 */
	private Date dateEnteredExl;
	/**
	 * Holds the timeStamp
	 */
	private String timeStamp;

	/**
	 * Holds the vtTaskAndProject
	 */
	private String vtTaskAndProject;

	private Date creationDate;
	
	private Date creationFromDate;
	
	private String creationFromDateXl;
	
	private Date creationToDate;
	
	private String creationToDateXl;

	private String actionTaken;

	private Date expctdFinishDt;
	
	private Date expctdFinishFromDt;
	
	private String expctdFinishFromDtXl;
	
	private Date expctdFinishToDt;
	
	private String expctdFinishToDtXl;

	private Date lateStrtDt;

	private String pendingEffort;

	private String totalEffort;

	private String gePalnnedEffort;

	private String geRemainingHr;

	/**
	 * @return the taskResponsiblity
	 */
	public String getTaskResponsiblity() {
		return taskResponsiblity;
	}

	/**
	 * @param taskResponsiblity
	 *            the taskResponsiblity to set
	 */
	public void setTaskResponsiblity(String taskResponsiblity) {
		this.taskResponsiblity = taskResponsiblity;
	}

	/**
	 * @return the ownerName
	 */
	public String getOwnerName() {
		return ownerName;
	}

	/**
	 * @param ownerName
	 *            the ownerName to set
	 */
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	/**
	 * @return the assigneeName
	 */
	public String getAssigneeName() {
		return assigneeName;
	}

	/**
	 * @param assigneeName
	 *            the assigneeName to set
	 */
	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}

	/**
	 * @return the orginatorName
	 */
	public String getOrginatorName() {
		return orginatorName;
	}

	/**
	 * @param orginatorName
	 *            the orginatorName to set
	 */
	public void setOrginatorName(String orginatorName) {
		this.orginatorName = orginatorName;
	}

	/**
	 * @return the taskResponsiblityName
	 */
	public String getTaskResponsiblityName() {
		return taskResponsiblityName;
	}

	/**
	 * @param taskResponsiblityName
	 *            the taskResponsiblityName to set
	 */
	public void setTaskResponsiblityName(String taskResponsiblityName) {
		this.taskResponsiblityName = taskResponsiblityName;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title
	 *            the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName
	 *            the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	/**
	 * @return the projectDesc
	 */
	public String getProjectDesc() {
		return projectDesc;
	}

	/**
	 * @param projectDesc
	 *            the projectDesc to set
	 */
	public void setProjectDesc(String projectDesc) {
		this.projectDesc = projectDesc;
	}

	/**
	 * @return the approveStatus
	 */
	public String getApproveStatus() {
		return approveStatus;
	}

	/**
	 * @param approveStatus
	 *            the approveStatus to set
	 */
	public void setApproveStatus(String approveStatus) {
		this.approveStatus = approveStatus;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the owner
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * @param owner
	 *            the owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}

	/**
	 * @return the assignee
	 */
	public String getAssignee() {
		return assignee;
	}

	/**
	 * @param assignee
	 *            the assignee to set
	 */
	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param desc
	 *            the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state
	 *            the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the voucherfind
	 */
	public String getVoucherfind() {
		return voucherfind;
	}

	/**
	 * @param voucherfind
	 *            the voucherfind to set
	 */
	public void setVoucherfind(String voucherfind) {
		this.voucherfind = voucherfind;
	}

	/**
	 * @return the context
	 */
	public String getContext() {
		return context;
	}

	/**
	 * @param context
	 *            the context to set
	 */
	public void setContext(String context) {
		this.context = context;
	}

	/**
	 * @return the policy
	 */
	public String getPolicy() {
		return policy;
	}

	/**
	 * @param policy
	 *            the policy to set
	 */
	public void setPolicy(String policy) {
		this.policy = policy;
	}

	/**
	 * @return the projectrole
	 */
	public String getProjectrole() {
		return projectrole;
	}

	/**
	 * @param projectrole
	 *            the projectrole to set
	 */
	public void setProjectrole(String projectrole) {
		this.projectrole = projectrole;
	}

	/**
	 * @return the taskReq
	 */
	public String getTaskReq() {
		return taskReq;
	}

	/**
	 * @param taskReq
	 *            the taskReq to set
	 */
	public void setTaskReq(String taskReq) {
		this.taskReq = taskReq;
	}

	/**
	 * @return the synopsis
	 */
	public String getSynopsis() {
		return synopsis;
	}

	/**
	 * @param synopsis
	 *            the synopsis to set
	 */
	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}

	/**
	 * @return the note
	 */
	public String getNote() {
		return note;
	}

	/**
	 * @param note
	 *            the note to set
	 */
	public void setNote(String note) {
		this.note = note;
	}

	/**
	 * @return the dependency
	 */
	public String getDependency() {
		return dependency;
	}

	/**
	 * @param dependency
	 *            the dependency to set
	 */
	public void setDependency(String dependency) {
		this.dependency = dependency;
	}

	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @param action
	 *            the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * @return the deliverable
	 */
	public String getDeliverable() {
		return deliverable;
	}

	/**
	 * @param deliverable
	 *            the deliverable to set
	 */
	public void setDeliverable(String deliverable) {
		this.deliverable = deliverable;
	}

	/**
	 * @return the associateitem
	 */
	public String getAssociateitem() {
		return associateitem;
	}

	/**
	 * @param associateitem
	 *            the associateitem to set
	 */
	public void setAssociateitem(String associateitem) {
		this.associateitem = associateitem;
	}

	/**
	 * @return the findSource
	 */
	public String getFindSource() {
		return findSource;
	}

	/**
	 * @param findSource
	 *            the findSource to set
	 */
	public void setFindSource(String findSource) {
		this.findSource = findSource;
	}

	/**
	 * @return the statusapprove
	 */
	public String getStatusapprove() {
		return statusapprove;
	}

	/**
	 * @param statusapprove
	 *            the statusapprove to set
	 */
	public void setStatusapprove(String statusapprove) {
		this.statusapprove = statusapprove;
	}

	/**
	 * @return the contractName
	 */
	public String getContractName() {
		return contractName;
	}

	/**
	 * @param contractName
	 *            the contractName to set
	 */
	public void setContractName(String contractName) {
		this.contractName = contractName;
	}

	/**
	 * @return the checkTask
	 */
	public boolean isCheckTask() {
		return checkTask;
	}

	/**
	 * @param checkTask
	 *            the checkTask to set
	 */
	public void setCheckTask(boolean checkTask) {
		this.checkTask = checkTask;
	}

	/**
	 * @return the searchResultList
	 */
	public List<PLMTaskSearchData> getSearchResultList() {
		return searchResultList;
	}

	/**
	 * @param searchResultList
	 *            the searchResultList to set
	 */
	public void setSearchResultList(List<PLMTaskSearchData> searchResultList) {
		this.searchResultList = searchResultList;
	}

	/**
	 * @return the allOpen
	 */
	public boolean isAllOpen() {
		return allOpen;
	}

	/**
	 * @param allOpen
	 *            the allOpen to set
	 */
	public void setAllOpen(boolean allOpen) {
		this.allOpen = allOpen;
	}

	/**
	 * @return the taskStateList
	 */
	public List<String> getTaskStateList() {
		return taskStateList;
	}

	/**
	 * @param taskStateList
	 *            the taskStateList to set
	 */
	public void setTaskStateList(List<String> taskStateList) {
		this.taskStateList = taskStateList;
	}

	/**
	 * @return the stateExcel
	 */
	public String getStateExcel() {
		return stateExcel;
	}

	/**
	 * @param stateExcel
	 *            the stateExcel to set
	 */
	public void setStateExcel(String stateExcel) {
		this.stateExcel = stateExcel;
	}

	/**
	 * @return the percentageComplete
	 */
	public String getPercentageComplete() {
		return percentageComplete;
	}

	/**
	 * @param percentageComplete
	 *            the percentageComplete to set
	 */
	public void setPercentageComplete(String percentageComplete) {
		this.percentageComplete = percentageComplete;
	}

	/**
	 * @return the orginator
	 */
	public String getOrginator() {
		return orginator;
	}

	/**
	 * @param orginator
	 *            the orginator to set
	 */
	public void setOrginator(String orginator) {
		this.orginator = orginator;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the taskApproval
	 */
	public String getTaskApproval() {
		return taskApproval;
	}

	/**
	 * @param taskApproval
	 *            the taskApproval to set
	 */
	public void setTaskApproval(String taskApproval) {
		this.taskApproval = taskApproval;
	}

	/**
	 * @return the taskActual
	 */
	public String getTaskActual() {
		return taskActual;
	}

	/**
	 * @param taskActual
	 *            the taskActual to set
	 */
	public void setTaskActual(String taskActual) {
		this.taskActual = taskActual;
	}

	/**
	 * @return the duration
	 */
	public String getDuration() {
		return duration;
	}

	/**
	 * @param duration
	 *            the duration to set
	 */
	public void setDuration(String duration) {
		this.duration = duration;
	}

	public Date getEstimatedFinish() {
		Date temp = null;
		temp = estimatedFinish;
		return temp;
	}

	public void setEstimatedFinish(Date estimatedFinish) {
		Date temp = null;
		temp = estimatedFinish;
		this.estimatedFinish = temp;
	}

	public Date getActualFinish() {
		Date temp = null;
		temp = actualFinish;
		return temp;
	}

	public void setActualFinish(Date actualFinish) {
		Date temp = null;
		temp = actualFinish;
		this.actualFinish = temp;
	}

	public Date getCompletedate() {
		Date temp = null;
		temp = completedate;
		return temp;
	}

	public void setCompletedate(Date completedate) {
		Date temp = null;
		temp = completedate;
		this.completedate = temp;
	}

	public Date getDuedate() {
		Date temp = null;
		temp = duedate;
		return temp;
	}

	public void setDuedate(Date duedate) {
		Date temp = null;
		temp = duedate;
		this.duedate = temp;
	}

	public Date getEstimatedFinishFromDate() {
		Date temp = null;
		temp = estimatedFinishFromDate;
		return temp;
	}

	public void setEstimatedFinishFromDate(Date estimatedFinishFromDate) {
		Date temp = null;
		temp = estimatedFinishFromDate;
		this.estimatedFinishFromDate = temp;
	}

	public Date getEstimatedFinishToDate() {
		Date temp = null;
		temp = estimatedFinishToDate;
		return temp;
	}

	public void setEstimatedFinishToDate(Date estimatedFinishToDate) {
		Date temp = null;
		temp = estimatedFinishToDate;
		this.estimatedFinishToDate = temp;
	}

	public Date getActualFinishFromDate() {
		Date temp = null;
		temp = actualFinishFromDate;
		return temp;
	}

	public void setActualFinishFromDate(Date actualFinishFromDate) {
		Date temp = null;
		temp = actualFinishFromDate;
		this.actualFinishFromDate = temp;
	}

	public Date getActualFinishToDate() {
		Date temp = null;
		temp = actualFinishToDate;
		return temp;
	}

	public void setActualFinishToDate(Date actualFinishToDate) {
		Date temp = null;
		temp = actualFinishToDate;
		this.actualFinishToDate = temp;
	}

	/**
	 * @return the geActivityCode
	 */
	public String getGeActivityCode() {
		return geActivityCode;
	}

	/**
	 * @param geActivityCode
	 *            the geActivityCode to set
	 */
	public void setGeActivityCode(String geActivityCode) {
		this.geActivityCode = geActivityCode;
	}

	/**
	 * @return the requiredHours
	 */
	public String getRequiredHours() {
		return requiredHours;
	}

	/**
	 * @param requiredHours
	 *            the requiredHours to set
	 */
	public void setRequiredHours(String requiredHours) {
		this.requiredHours = requiredHours;
	}

	/**
	 * @return the predecessors
	 */
	public String getPredecessors() {
		return predecessors;
	}

	/**
	 * @param predecessors
	 *            the predecessors to set
	 */
	public void setPredecessors(String predecessors) {
		this.predecessors = predecessors;
	}

	/**
	 * @return the successors
	 */
	public String getSuccessors() {
		return successors;
	}

	/**
	 * @param successors
	 *            the successors to set
	 */
	public void setSuccessors(String successors) {
		this.successors = successors;
	}

	/**
	 * @return the actualStart
	 */
	public Date getActualStart() {
		Date temp = null;
		temp = actualStart;
		return temp;
	}

	/**
	 * @param actualStart
	 *            the actualStart to set
	 */
	public void setActualStart(Date actualStart) {
		Date temp = null;
		temp = actualStart;
		this.actualStart = temp;
	}

	/**
	 * @return the estimatedStart
	 */
	public Date getEstimatedStart() {
		Date temp = null;
		temp = estimatedStart;
		return temp;
	}

	/**
	 * @param estimatedStart
	 *            the estimatedStart to set
	 */
	public void setEstimatedStart(Date estimatedStart) {
		Date temp = null;
		temp = estimatedStart;
		this.estimatedStart = temp;
	}

	/**
	 * @return the estimatedDuration
	 */
	public String getEstimatedDuration() {
		return estimatedDuration;
	}

	/**
	 * @param estimatedDuration
	 *            the estimatedDuration to set
	 */
	public void setEstimatedDuration(String estimatedDuration) {
		this.estimatedDuration = estimatedDuration;
	}

	/**
	 * @return the actualHours
	 */
	public String getActualHours() {
		return actualHours;
	}

	/**
	 * @param actualHours
	 *            the actualHours to set
	 */
	public void setActualHours(String actualHours) {
		this.actualHours = actualHours;
	}

	/**
	 * @return the taskAndProject
	 */
	public String getTaskAndProject() {
		return taskAndProject;
	}

	/**
	 * @param taskAndProject
	 *            the taskAndProject to set
	 */
	public void setTaskAndProject(String taskAndProject) {
		this.taskAndProject = taskAndProject;
	}

	/**
	 * @return the queryName
	 */
	public String getQueryName() {
		return queryName;
	}

	/**
	 * @param queryName
	 *            the queryName to set
	 */
	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}

	/**
	 * @return the seqID
	 */
	public String getSeqID() {
		return seqID;
	}

	/**
	 * @param seqID
	 *            the seqID to set
	 */
	public void setSeqID(String seqID) {
		this.seqID = seqID;
	}

	/**
	 * @return the ssoId
	 */
	public String getSsoId() {
		return ssoId;
	}

	/**
	 * @param ssoId
	 *            the ssoId to set
	 */
	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}

	/**
	 * @return the queryTxt
	 */
	public String getQueryTxt() {
		return queryTxt;
	}

	/**
	 * @param queryTxt
	 *            the queryTxt to set
	 */
	public void setQueryTxt(String queryTxt) {
		this.queryTxt = queryTxt;
	}

	/**
	 * @return the serialNo
	 */
	public int getSerialNo() {
		return serialNo;
	}

	/**
	 * @param serialNo
	 *            the serialNo to set
	 */
	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}

	/**
	 * @return the fieldNm
	 */
	public String getFieldNm() {
		return fieldNm;
	}

	/**
	 * @param fieldNm
	 *            the fieldNm to set
	 */
	public void setFieldNm(String fieldNm) {
		this.fieldNm = fieldNm;
	}

	/**
	 * @return the fieldVal
	 */
	public String getFieldVal() {
		return fieldVal;
	}

	/**
	 * @param fieldVal
	 *            the fieldVal to set
	 */
	public void setFieldVal(String fieldVal) {
		this.fieldVal = fieldVal;
	}

	/**
	 * @return the unitSerialNo
	 */
	public String getUnitSerialNo() {
		return unitSerialNo;
	}

	/**
	 * @param unitSerialNo
	 *            the unitSerialNo to set
	 */
	public void setUnitSerialNo(String unitSerialNo) {
		this.unitSerialNo = unitSerialNo;
	}

	/**
	 * @return the respPrsnNM
	 */
	public String getRespPrsnNM() {
		return respPrsnNM;
	}

	/**
	 * @param respPrsnNM
	 *            the respPrsnNM to set
	 */
	public void setRespPrsnNM(String respPrsnNM) {
		this.respPrsnNM = respPrsnNM;
	}

	/**
	 * @return the respUnitCode
	 */
	public String getRespUnitCode() {
		return respUnitCode;
	}

	/**
	 * @param respUnitCode
	 *            the respUnitCode to set
	 */
	public void setRespUnitCode(String respUnitCode) {
		this.respUnitCode = respUnitCode;
	}

	/**
	 * @return the lateFinish
	 */
	public Date getLateFinish() {
		Date lateFinishDt = lateFinish;
		return lateFinishDt;
	}

	/**
	 * @param lateFinish
	 *            the lateFinish to set
	 */
	public void setLateFinish(Date lateFinish) {
		Date lateFinishDt = lateFinish;
		this.lateFinish = lateFinishDt;
	}

	/**
	 * @return the discussion
	 */
	public String getDiscussion() {
		return discussion;
	}

	/**
	 * @param discussion
	 *            the discussion to set
	 */
	public void setDiscussion(String discussion) {
		this.discussion = discussion;
	}

	/**
	 * @return the enteredByUsrNM
	 */
	public String getEnteredByUsrNM() {
		return enteredByUsrNM;
	}

	/**
	 * @param enteredByUsrNM
	 *            the enteredByUsrNM to set
	 */
	public void setEnteredByUsrNM(String enteredByUsrNM) {
		this.enteredByUsrNM = enteredByUsrNM;
	}

	/**
	 * @return the custNM
	 */
	public String getCustNM() {
		return custNM;
	}

	/**
	 * @param custNM
	 *            the custNM to set
	 */
	public void setCustNM(String custNM) {
		this.custNM = custNM;
	}

	/**
	 * @return the custNeedDate
	 */
	public Date getCustNeedDate() {
		Date custNeedDt = custNeedDate;
		return custNeedDt;
	}

	/**
	 * @param custNeedDate
	 *            the custNeedDate to set
	 */
	public void setCustNeedDate(Date custNeedDate) {
		Date custNeedDt = custNeedDate;
		this.custNeedDate = custNeedDt;
	}

	/**
	 * @return the ecrNo
	 */
	public String getEcrNo() {
		return ecrNo;
	}

	/**
	 * @param ecrNo
	 *            the ecrNo to set
	 */
	public void setEcrNo(String ecrNo) {
		this.ecrNo = ecrNo;
	}

	/**
	 * @return the ecoNo
	 */
	public String getEcoNo() {
		return ecoNo;
	}

	/**
	 * @param ecoNo
	 *            the ecoNo to set
	 */
	public void setEcoNo(String ecoNo) {
		this.ecoNo = ecoNo;
	}

	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * @param model
	 *            the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * @return the dateEntered
	 */
	public String getDateEntered() {
		return dateEntered;
	}

	/**
	 * @param dateEntered
	 *            the dateEntered to set
	 */
	public void setDateEntered(String dateEntered) {
		this.dateEntered = dateEntered;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	/**
	 * @return the taskAstdTypeList
	 */
	public List<String> getTaskAstdTypeList() {
		return taskAstdTypeList;
	}

	/**
	 * @param taskAstdTypeList
	 *            the taskAstdTypeList to set
	 */
	public void setTaskAstdTypeList(List<String> taskAstdTypeList) {
		this.taskAstdTypeList = taskAstdTypeList;
	}

	/**
	 * @return the predessorNum
	 */
	public String getPredessorNum() {
		return predessorNum;
	}

	/**
	 * @param predessorNum
	 *            the predessorNum to set
	 */
	public void setPredessorNum(String predessorNum) {
		this.predessorNum = predessorNum;
	}

	/**
	 * @return the predessorTitle
	 */
	public String getPredessorTitle() {
		return predessorTitle;
	}

	/**
	 * @param predessorTitle
	 *            the predessorTitle to set
	 */
	public void setPredessorTitle(String predessorTitle) {
		this.predessorTitle = predessorTitle;
	}

	/**
	 * @return the dependencyType
	 */
	public String getDependencyType() {
		return dependencyType;
	}

	/**
	 * @param dependencyType
	 *            the dependencyType to set
	 */
	public void setDependencyType(String dependencyType) {
		this.dependencyType = dependencyType;
	}

	/**
	 * @return the successorNum
	 */
	public String getSuccessorNum() {
		return successorNum;
	}

	/**
	 * @param successorNum
	 *            the successorNum to set
	 */
	public void setSuccessorNum(String successorNum) {
		this.successorNum = successorNum;
	}

	/**
	 * @return the successorTitle
	 */
	public String getSuccessorTitle() {
		return successorTitle;
	}

	/**
	 * @param successorTitle
	 *            the successorTitle to set
	 */
	public void setSuccessorTitle(String successorTitle) {
		this.successorTitle = successorTitle;
	}

	/**
	 * @return the mfgFromDate
	 */
	public Date getMfgFromDate() {
		Date mfgFromDt = mfgFromDate;
		return mfgFromDt;
	}

	/**
	 * @param mfgFromDate
	 *            the mfgFromDate to set
	 */
	public void setMfgFromDate(Date mfgFromDate) {
		Date mfgFromDt = mfgFromDate;
		this.mfgFromDate = mfgFromDt;
	}

	/**
	 * @return the mfgToDate
	 */
	public Date getMfgToDate() {
		Date mfgToDt = mfgToDate;
		return mfgToDt;
	}

	/**
	 * @param mfgToDate
	 *            the mfgToDate to set
	 */
	public void setMfgToDate(Date mfgToDate) {
		Date mfgToDt = mfgToDate;
		this.mfgToDate = mfgToDt;
	}

	/**
	 * @return the customerFromDate
	 */
	public Date getCustomerFromDate() {
		Date custFromDt = customerFromDate;
		return custFromDt;
	}

	/**
	 * @param customerFromDate
	 *            the customerFromDate to set
	 */
	public void setCustomerFromDate(Date customerFromDate) {
		Date custFromDt = customerFromDate;
		this.customerFromDate = custFromDt;
	}

	/**
	 * @return the customerToDate
	 */
	public Date getCustomerToDate() {
		Date custToDt = customerToDate;
		return custToDt;
	}

	/**
	 * @param customerToDate
	 *            the customerToDate to set
	 */
	public void setCustomerToDate(Date customerToDate) {
		Date custToDt = customerToDate;
		this.customerToDate = custToDt;
	}

	/**
	 * @return the mfgIndicator
	 */
	public String getMfgIndicator() {
		return mfgIndicator;
	}

	/**
	 * @param mfgIndicator
	 *            the mfgIndicator to set
	 */
	public void setMfgIndicator(String mfgIndicator) {
		this.mfgIndicator = mfgIndicator;
	}

	/**
	 * @return the taskResponsiblityUnit
	 */
	public String getTaskResponsiblityUnit() {
		return taskResponsiblityUnit;
	}

	/**
	 * @param taskResponsiblityUnit
	 *            the taskResponsiblityUnit to set
	 */
	public void setTaskResponsiblityUnit(String taskResponsiblityUnit) {
		this.taskResponsiblityUnit = taskResponsiblityUnit;
	}

	/**
	 * @return the mfgFinish
	 */
	public Date getMfgFinish() {
		Date mfgFinishDt = mfgFinish;
		return mfgFinishDt;
	}

	/**
	 * @param mfgFinish
	 *            the mfgFinish to set
	 */
	public void setMfgFinish(Date mfgFinish) {
		Date mfgFinishDt = mfgFinish;
		this.mfgFinish = mfgFinishDt;
	}

	/**
	 * @return the customerFinish
	 */
	public Date getCustomerFinish() {
		Date custFinishDt = customerFinish;
		return custFinishDt;
	}

	/**
	 * @param customerFinish
	 *            the customerFinish to set
	 */
	public void setCustomerFinish(Date customerFinish) {
		Date custFinishDt = customerFinish;
		this.customerFinish = custFinishDt;
	}

	/**
	 * @return the associatedName
	 */
	public String getAssociatedName() {
		return associatedName;
	}

	/**
	 * @param associatedName
	 *            the associatedName to set
	 */
	public void setAssociatedName(String associatedName) {
		this.associatedName = associatedName;
	}

	/**
	 * @return the associatedExcel
	 */
	public String getAssociatedExcel() {
		return associatedExcel;
	}

	/**
	 * @param associatedExcel
	 *            the associatedExcel to set
	 */
	public void setAssociatedExcel(String associatedExcel) {
		this.associatedExcel = associatedExcel;
	}

	/**
	 * @return the eccnRdo
	 */
	public String getEccnRdo() {
		return eccnRdo;
	}

	/**
	 * @param eccnRdo
	 *            the eccnRdo to set
	 */
	public void setEccnRdo(String eccnRdo) {
		this.eccnRdo = eccnRdo;
	}

	/**
	 * @return the eccnName
	 */
	public String getEccnName() {
		return eccnName;
	}

	/**
	 * @param eccnName
	 *            the eccnName to set
	 */
	public void setEccnName(String eccnName) {
		this.eccnName = eccnName;
	}

	/**
	 * @return the eccnRevision
	 */
	public String getEccnRevision() {
		return eccnRevision;
	}

	/**
	 * @param eccnRevision
	 *            the eccnRevision to set
	 */
	public void setEccnRevision(String eccnRevision) {
		this.eccnRevision = eccnRevision;
	}

	/**
	 * @return the eccnType1
	 */
	public String getEccnType1() {
		return eccnType1;
	}

	/**
	 * @param eccnType1
	 *            the eccnType1 to set
	 */
	public void setEccnType1(String eccnType1) {
		this.eccnType1 = eccnType1;
	}

	/**
	 * @return the eccnPolicy
	 */
	public String getEccnPolicy() {
		return eccnPolicy;
	}

	/**
	 * @param eccnPolicy
	 *            the eccnPolicy to set
	 */
	public void setEccnPolicy(String eccnPolicy) {
		this.eccnPolicy = eccnPolicy;
	}

	/**
	 * @return the eccnDescription
	 */
	public String getEccnDescription() {
		return eccnDescription;
	}

	/**
	 * @param eccnDescription
	 *            the eccnDescription to set
	 */
	public void setEccnDescription(String eccnDescription) {
		this.eccnDescription = eccnDescription;
	}

	/**
	 * @return the eccnState
	 */
	public String getEccnState() {
		return eccnState;
	}

	/**
	 * @param eccnState
	 *            the eccnState to set
	 */
	public void setEccnState(String eccnState) {
		this.eccnState = eccnState;
	}

	public Date getEccnOriginationDate() {
		Date eccnoriginateDt = eccnOriginationDate;
		return eccnoriginateDt;
	}

	public void setEccnOriginationDate(Date eccnOriginationDate) {
		Date eccnoriginateDt = eccnOriginationDate;
		this.eccnOriginationDate = eccnoriginateDt;
	}

	public Date getEccnReleaseDate() {
		Date eccnReleaseDt = eccnReleaseDate;
		return eccnReleaseDt;
	}

	public void setEccnReleaseDate(Date eccnReleaseDate) {
		Date eccnReleaseDt = eccnReleaseDate;
		this.eccnReleaseDate = eccnReleaseDt;
	}

	public String getEccnOriginatorSSO() {
		return eccnOriginatorSSO;
	}

	public void setEccnOriginatorSSO(String eccnOriginatorSSO) {
		this.eccnOriginatorSSO = eccnOriginatorSSO;
	}

	public String getEccnEcn() {
		return eccnEcn;
	}

	public void setEccnEcn(String eccnEcn) {
		this.eccnEcn = eccnEcn;
	}

	/**
	 * @return the predSuccName
	 */
	public String getPredSuccName() {
		return predSuccName;
	}

	/**
	 * @param predSuccName
	 *            the predSuccName to set
	 */
	public void setPredSuccName(String predSuccName) {
		this.predSuccName = predSuccName;
	}

	/**
	 * @return the taskName
	 */
	public String getTaskName() {
		return taskName;
	}

	/**
	 * @param taskName
	 *            the taskName to set
	 */
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	/**
	 * @return the taskTitle
	 */
	public String getTaskTitle() {
		return taskTitle;
	}

	/**
	 * @param taskTitle
	 *            the taskTitle to set
	 */
	public void setTaskTitle(String taskTitle) {
		this.taskTitle = taskTitle;
	}

	/**
	 * @return the delay
	 */
	public String getDelay() {
		return delay;
	}

	/**
	 * @param delay
	 *            the delay to set
	 */
	public void setDelay(String delay) {
		this.delay = delay;
	}

	/**
	 * @return the lineBrkr
	 */
	public boolean isLineBrkr() {
		return lineBrkr;
	}

	/**
	 * @param lineBrkr
	 *            the lineBrkr to set
	 */
	public void setLineBrkr(boolean lineBrkr) {
		this.lineBrkr = lineBrkr;
	}

	/**
	 * @return the taskNameActive
	 */
	public boolean isTaskNameActive() {
		return taskNameActive;
	}

	/**
	 * @param taskNameActive
	 *            the taskNameActive to set
	 */
	public void setTaskNameActive(boolean taskNameActive) {
		this.taskNameActive = taskNameActive;
	}

	/**
	 * @return the task
	 */
	public String getTask() {
		return task;
	}

	/**
	 * @param task
	 *            the task to set
	 */
	public void setTask(String task) {
		this.task = task;
	}

	/**
	 * @return the taskNamePredessorActive
	 */
	public boolean isTaskNamePredessorActive() {
		return taskNamePredessorActive;
	}

	/**
	 * @param taskNamePredessorActive
	 *            the taskNamePredessorActive to set
	 */
	public void setTaskNamePredessorActive(boolean taskNamePredessorActive) {
		this.taskNamePredessorActive = taskNamePredessorActive;
	}

	/**
	 * @return the taskNameSuccessorActive
	 */
	public boolean isTaskNameSuccessorActive() {
		return taskNameSuccessorActive;
	}

	/**
	 * @param taskNameSuccessorActive
	 *            the taskNameSuccessorActive to set
	 */
	public void setTaskNameSuccessorActive(boolean taskNameSuccessorActive) {
		this.taskNameSuccessorActive = taskNameSuccessorActive;
	}

	/**
	 * @return the orgTaskName
	 */
	public String getOrgTaskName() {
		return orgTaskName;
	}

	/**
	 * @param orgTaskName
	 *            the orgTaskName to set
	 */
	public void setOrgTaskName(String orgTaskName) {
		this.orgTaskName = orgTaskName;
	}

	/**
	 * @return the availableName
	 */
	public String getAvailableName() {
		return availableName;
	}

	/**
	 * @param availableName
	 *            the availableName to set
	 */
	public void setAvailableName(String availableName) {
		this.availableName = availableName;
	}

	/**
	 * @return the orTaskPreTask
	 */
	public String getOrTaskPreTask() {
		return orTaskPreTask;
	}

	/**
	 * @param orTaskPreTask
	 *            the orTaskPreTask to set
	 */
	public void setOrTaskPreTask(String orTaskPreTask) {
		this.orTaskPreTask = orTaskPreTask;
	}

	/**
	 * @return the orignator
	 */
	public String getOrignator() {
		return orignator;
	}

	/**
	 * @param orignator
	 *            the orignator to set
	 */
	public void setOrignator(String orignator) {
		this.orignator = orignator;
	}

	/**
	 * @return the orignatorName
	 */
	public String getOrignatorName() {
		return orignatorName;
	}

	/**
	 * @param orignatorName
	 *            the orignatorName to set
	 */
	public void setOrignatorName(String orignatorName) {
		this.orignatorName = orignatorName;
	}

	/**
	 * @return the respSso
	 */
	public String getRespSso() {
		return respSso;
	}

	/**
	 * @param respSso
	 *            the respSso to set
	 */
	public void setRespSso(String respSso) {
		this.respSso = respSso;
	}

	/**
	 * @return the geMfggDeliverableIndr
	 */
	public String getGeMfggDeliverableIndr() {
		return geMfggDeliverableIndr;
	}

	/**
	 * @param geMfggDeliverableIndr
	 *            the geMfggDeliverableIndr to set
	 */
	public void setGeMfggDeliverableIndr(String geMfggDeliverableIndr) {
		this.geMfggDeliverableIndr = geMfggDeliverableIndr;
	}

	/**
	 * @return the geMfggNeedDate
	 */
	public String getGeMfggNeedDate() {
		return geMfggNeedDate;
	}

	/**
	 * @param geMfggNeedDate
	 *            the geMfggNeedDate to set
	 */
	public void setGeMfggNeedDate(String geMfggNeedDate) {
		this.geMfggNeedDate = geMfggNeedDate;
	}

	/**
	 * @return the geCstmrNeedDate
	 */
	public String getGeCstmrNeedDate() {
		return geCstmrNeedDate;
	}

	/**
	 * @param geCstmrNeedDate
	 *            the geCstmrNeedDate to set
	 */
	public void setGeCstmrNeedDate(String geCstmrNeedDate) {
		this.geCstmrNeedDate = geCstmrNeedDate;
	}

	/**
	 * @return the geTaskResponsibleUnit
	 */
	public String getGeTaskResponsibleUnit() {
		return geTaskResponsibleUnit;
	}

	/**
	 * @param geTaskResponsibleUnit
	 *            the geTaskResponsibleUnit to set
	 */
	public void setGeTaskResponsibleUnit(String geTaskResponsibleUnit) {
		this.geTaskResponsibleUnit = geTaskResponsibleUnit;
	}

	/**
	 * @return the taskAndProjectPred
	 */
	public String getTaskAndProjectPred() {
		return taskAndProjectPred;
	}

	/**
	 * @param taskAndProjectPred
	 *            the taskAndProjectPred to set
	 */
	public void setTaskAndProjectPred(String taskAndProjectPred) {
		this.taskAndProjectPred = taskAndProjectPred;
	}

	/**
	 * @return the rowCount
	 */
	public int getRowCount() {
		return rowCount;
	}

	/**
	 * @param rowCount
	 *            the rowCount to set
	 */
	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	/**
	 * @return the geTotalFloat
	 */
	public String getGeTotalFloat() {
		return geTotalFloat;
	}

	/**
	 * @param geTotalFloat
	 *            the geTotalFloat to set
	 */
	public void setGeTotalFloat(String geTotalFloat) {
		this.geTotalFloat = geTotalFloat;
	}

	/**
	 * @return the geLateFinishDate
	 */
	public Date getGeLateFinishDate() {
		Date temp = null;
		temp = geLateFinishDate;
		return temp;
	}

	/**
	 * @param geLateFinishDate
	 *            the geLateFinishDate to set
	 */
	public void setGeLateFinishDate(Date geLateFinishDate) {
		Date temp = null;
		temp = geLateFinishDate;
		this.geLateFinishDate = temp;
	}

	/**
	 * @return the earlyFinishStartDate
	 */
	public Date getEarlyFinishFromDate() {
		Date temp = null;
		temp = earlyFinishFromDate;
		return temp;
	}

	/**
	 * @param earlyFinishStartDate
	 *            the earlyFinishStartDate to set
	 */
	public void setEarlyFinishFromDate(Date earlyFinishFromDate) {
		Date temp = null;
		temp = earlyFinishFromDate;
		this.earlyFinishFromDate = temp;
	}

	/**
	 * @return the earlyFinishToDate
	 */
	public Date getEarlyFinishToDate() {
		Date temp = null;
		temp = earlyFinishToDate;
		return temp;
	}

	/**
	 * @param earlyFinishToDate
	 *            the earlyFinishToDate to set
	 */
	public void setEarlyFinishToDate(Date earlyFinishToDate) {
		Date temp = null;
		temp = earlyFinishToDate;
		this.earlyFinishToDate = temp;
	}

	/**
	 * @return the lateFinishStartDate
	 */
	public Date getLateFinishFromDate() {
		Date temp = null;
		temp = lateFinishFromDate;
		return temp;
	}

	/**
	 * @param lateFinishStartDate
	 *            the lateFinishStartDate to set
	 */
	public void setLateFinishFromDate(Date lateFinishFromDate) {
		Date temp = null;
		temp = lateFinishFromDate;
		this.lateFinishFromDate = temp;
	}

	/**
	 * @return the lateFinishToDate
	 */
	public Date getLateFinishToDate() {
		Date temp = null;
		temp = lateFinishToDate;
		return temp;
	}

	/**
	 * @param lateFinishToDate
	 *            the lateFinishToDate to set
	 */
	public void setLateFinishToDate(Date lateFinishToDate) {
		Date temp = null;
		temp = lateFinishToDate;
		this.lateFinishToDate = temp;
	}

	/**
	 * @return the geEarlyFinishDate
	 */
	public Date getGeEarlyFinishDate() {
		Date temp = null;
		temp = geEarlyFinishDate;
		return temp;
	}

	/**
	 * @param geEarlyFinishDate
	 *            the geEarlyFinishDate to set
	 */
	public void setGeEarlyFinishDate(Date geEarlyFinishDate) {
		Date temp = null;
		temp = geEarlyFinishDate;
		this.geEarlyFinishDate = temp;
	}

	/**
	 * @return the actualFnshFromDtExl
	 */
	public String getActualFnshFromDtExl() {
		return actualFnshFromDtExl;
	}

	/**
	 * @param actualFnshFromDtExl
	 *            the actualFnshFromDtExl to set
	 */
	public void setActualFnshFromDtExl(String actualFnshFromDtExl) {
		this.actualFnshFromDtExl = actualFnshFromDtExl;
	}

	/**
	 * @return the actualFnshToDtExl
	 */
	public String getActualFnshToDtExl() {
		return actualFnshToDtExl;
	}

	/**
	 * @param actualFnshToDtExl
	 *            the actualFnshToDtExl to set
	 */
	public void setActualFnshToDtExl(String actualFnshToDtExl) {
		this.actualFnshToDtExl = actualFnshToDtExl;
	}

	/**
	 * @return the estimateFnshFromDtExl
	 */
	public String getEstimateFnshFromDtExl() {
		return estimateFnshFromDtExl;
	}

	/**
	 * @param estimateFnshFromDtExl
	 *            the estimateFnshFromDtExl to set
	 */
	public void setEstimateFnshFromDtExl(String estimateFnshFromDtExl) {
		this.estimateFnshFromDtExl = estimateFnshFromDtExl;
	}

	/**
	 * @return the estimateFnshToDtExl
	 */
	public String getEstimateFnshToDtExl() {
		return estimateFnshToDtExl;
	}

	/**
	 * @param estimateFnshToDtExl
	 *            the estimateFnshToDtExl to set
	 */
	public void setEstimateFnshToDtExl(String estimateFnshToDtExl) {
		this.estimateFnshToDtExl = estimateFnshToDtExl;
	}

	/**
	 * @return the custNeedFromDtExl
	 */
	public String getCustNeedFromDtExl() {
		return custNeedFromDtExl;
	}

	/**
	 * @param custNeedFromDtExl
	 *            the custNeedFromDtExl to set
	 */
	public void setCustNeedFromDtExl(String custNeedFromDtExl) {
		this.custNeedFromDtExl = custNeedFromDtExl;
	}

	/**
	 * @return the custNeedToDtExl
	 */
	public String getCustNeedToDtExl() {
		return custNeedToDtExl;
	}

	/**
	 * @param custNeedToDtExl
	 *            the custNeedToDtExl to set
	 */
	public void setCustNeedToDtExl(String custNeedToDtExl) {
		this.custNeedToDtExl = custNeedToDtExl;
	}

	/**
	 * @return the mfgNeedFromDtExl
	 */
	public String getMfgNeedFromDtExl() {
		return mfgNeedFromDtExl;
	}

	/**
	 * @param mfgNeedFromDtExl
	 *            the mfgNeedFromDtExl to set
	 */
	public void setMfgNeedFromDtExl(String mfgNeedFromDtExl) {
		this.mfgNeedFromDtExl = mfgNeedFromDtExl;
	}

	/**
	 * @return the mfgNeedTotExl
	 */
	public String getMfgNeedTotExl() {
		return mfgNeedTotExl;
	}

	/**
	 * @param mfgNeedTotExl
	 *            the mfgNeedTotExl to set
	 */
	public void setMfgNeedTotExl(String mfgNeedTotExl) {
		this.mfgNeedTotExl = mfgNeedTotExl;
	}

	/**
	 * @return the earlyFnshFromDtExl
	 */
	public String getEarlyFnshFromDtExl() {
		return earlyFnshFromDtExl;
	}

	/**
	 * @param earlyFnshFromDtExl
	 *            the earlyFnshFromDtExl to set
	 */
	public void setEarlyFnshFromDtExl(String earlyFnshFromDtExl) {
		this.earlyFnshFromDtExl = earlyFnshFromDtExl;
	}

	/**
	 * @return the earlyFnshToDtExl
	 */
	public String getEarlyFnshToDtExl() {
		return earlyFnshToDtExl;
	}

	/**
	 * @param earlyFnshToDtExl
	 *            the earlyFnshToDtExl to set
	 */
	public void setEarlyFnshToDtExl(String earlyFnshToDtExl) {
		this.earlyFnshToDtExl = earlyFnshToDtExl;
	}

	/**
	 * @return the lateFnshFromDtExl
	 */
	public String getLateFnshFromDtExl() {
		return lateFnshFromDtExl;
	}

	/**
	 * @param lateFnshFromDtExl
	 *            the lateFnshFromDtExl to set
	 */
	public void setLateFnshFromDtExl(String lateFnshFromDtExl) {
		this.lateFnshFromDtExl = lateFnshFromDtExl;
	}

	/**
	 * @return the lateFnshToDtExl
	 */
	public String getLateFnshToDtExl() {
		return lateFnshToDtExl;
	}

	/**
	 * @param lateFnshToDtExl
	 *            the lateFnshToDtExl to set
	 */
	public void setLateFnshToDtExl(String lateFnshToDtExl) {
		this.lateFnshToDtExl = lateFnshToDtExl;
	}

	/**
	 * @return the geMfggNeedDateExl
	 */
	public Date getGeMfggNeedDateExl() {
		Date temp = null;
		temp = geMfggNeedDateExl;
		return temp;
	}

	/**
	 * @param geMfggNeedDateExl
	 *            the geMfggNeedDateExl to set
	 */
	public void setGeMfggNeedDateExl(Date geMfggNeedDateExl) {
		Date temp = null;
		temp = geMfggNeedDateExl;
		this.geMfggNeedDateExl = temp;
	}

	/**
	 * @return the geCstmrNeedDateExl
	 */
	public Date getGeCstmrNeedDateExl() {
		Date temp = null;
		temp = geCstmrNeedDateExl;
		return temp;
	}

	/**
	 * @param geCstmrNeedDateExl
	 *            the geCstmrNeedDateExl to set
	 */
	public void setGeCstmrNeedDateExl(Date geCstmrNeedDateExl) {
		Date temp = null;
		temp = geCstmrNeedDateExl;
		this.geCstmrNeedDateExl = temp;
	}

	/**
	 * @return the dateEnteredExl
	 */
	public Date getDateEnteredExl() {
		Date temp = null;
		temp = dateEnteredExl;
		return temp;
	}

	/**
	 * @param dateEnteredExl
	 *            the dateEnteredExl to set
	 */
	public void setDateEnteredExl(Date dateEnteredExl) {
		Date temp = null;
		temp = dateEnteredExl;
		this.dateEnteredExl = temp;
	}

	/**
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param timeStamp
	 *            the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * @return the vtTaskAndProject
	 */
	public String getVtTaskAndProject() {
		return vtTaskAndProject;
	}

	/**
	 * @param vtTaskAndProject
	 *            the vtTaskAndProject to set
	 */
	public void setVtTaskAndProject(String vtTaskAndProject) {
		this.vtTaskAndProject = vtTaskAndProject;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getActionTaken() {
		return actionTaken;
	}

	public void setActionTaken(String actionTaken) {
		this.actionTaken = actionTaken;
	}

	public Date getExpctdFinishDt() {
		return expctdFinishDt;
	}

	public void setExpctdFinishDt(Date expctdFinishDt) {
		this.expctdFinishDt = expctdFinishDt;
	}

	public Date getLateStrtDt() {
		return lateStrtDt;
	}

	public void setLateStrtDt(Date lateStrtDt) {
		this.lateStrtDt = lateStrtDt;
	}

	public String getPendingEffort() {
		return pendingEffort;
	}

	public void setPendingEffort(String pendingEffort) {
		this.pendingEffort = pendingEffort;
	}

	public String getTotalEffort() {
		return totalEffort;
	}

	public void setTotalEffort(String totalEffort) {
		this.totalEffort = totalEffort;
	}

	public String getGePalnnedEffort() {
		return gePalnnedEffort;
	}

	public void setGePalnnedEffort(String gePalnnedEffort) {
		this.gePalnnedEffort = gePalnnedEffort;
	}

	public String getGeRemainingHr() {
		return geRemainingHr;
	}

	public void setGeRemainingHr(String geRemainingHr) {
		this.geRemainingHr = geRemainingHr;
	}

	public Date getCreationFromDate() {
		return creationFromDate;
	}

	public void setCreationFromDate(Date creationFromDate) {
		this.creationFromDate = creationFromDate;
	}

	public Date getCreationToDate() {
		return creationToDate;
	}

	public void setCreationToDate(Date creationToDate) {
		this.creationToDate = creationToDate;
	}

	public Date getExpctdFinishFromDt() {
		return expctdFinishFromDt;
	}

	public void setExpctdFinishFromDt(Date expctdFinishFromDt) {
		this.expctdFinishFromDt = expctdFinishFromDt;
	}

	public Date getExpctdFinishToDt() {
		return expctdFinishToDt;
	}

	public void setExpctdFinishToDt(Date expctdFinishToDt) {
		this.expctdFinishToDt = expctdFinishToDt;
	}

	public String getCreationFromDateXl() {
		return creationFromDateXl;
	}

	public void setCreationFromDateXl(String creationFromDateXl) {
		this.creationFromDateXl = creationFromDateXl;
	}

	public String getCreationToDateXl() {
		return creationToDateXl;
	}

	public void setCreationToDateXl(String creationToDateXl) {
		this.creationToDateXl = creationToDateXl;
	}

	public String getExpctdFinishFromDtXl() {
		return expctdFinishFromDtXl;
	}

	public void setExpctdFinishFromDtXl(String expctdFinishFromDtXl) {
		this.expctdFinishFromDtXl = expctdFinishFromDtXl;
	}

	public String getExpctdFinishToDtXl() {
		return expctdFinishToDtXl;
	}

	public void setExpctdFinishToDtXl(String expctdFinishToDtXl) {
		this.expctdFinishToDtXl = expctdFinishToDtXl;
	}
	

}
