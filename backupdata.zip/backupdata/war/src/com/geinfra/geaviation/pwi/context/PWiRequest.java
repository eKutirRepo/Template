package com.geinfra.geaviation.pwi.context;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.PWiRuntimeException;
import com.geinfra.geaviation.pwi.util.PWiConstants;

/**
 * Project : Product Lifecycle Management Date Written : Apr 13, 2011 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description :
 * 
 * Since the external context returns requests as type Object, retrieving
 * information from the request requires having to determine what type of object
 * the request is and then having to cast. This class abstracts away that
 * functionality so that we can get information from the request without
 * worrying about determining the class of the request.
 * 
 * This class has been written to handle the two common requests types we use --
 * ServletRequest and PortletRequest -- and provides methods to access
 * information common to both that we are interested in.
 * 
 * Revision Log Apr 13, 2011 | v1.0.
 * --------------------------------------------------------------
 */
public abstract class PWiRequest {
	public static PWiRequest getRequest(Object requestObject)
			throws PWiRuntimeException {
		if (requestObject instanceof HttpServletRequest) {
			return new ServletRequestAdapter((HttpServletRequest) requestObject);
		} else {
			throw new PWiRuntimeException("Unsupported request object type: "
					+ requestObject);
		}
	}

	public abstract String getServerName();

	public abstract int getServerPort();

	public abstract String getContextPath();

	public abstract Object getAttribute(String attributeName);

	public abstract PWiSession getSession() throws PWiException;

	public abstract String getSsoId();
	
	public abstract String getParameter(String param);

	private static class ServletRequestAdapter extends PWiRequest {
		HttpServletRequest servletRequest;
		public static final Pattern VALID_SSO_REGEX = 
			    Pattern.compile("^[0-9]{9}$", Pattern.CASE_INSENSITIVE);
		
		public ServletRequestAdapter(HttpServletRequest servletRequest) {
			this.servletRequest = servletRequest;
		}

		public String getServerName() {
			return servletRequest.getServerName();
		}

		public int getServerPort() {
			return servletRequest.getServerPort();
		}

		public Object getAttribute(String attributeName) {
			return servletRequest.getAttribute(attributeName);
		}

		public PWiSession getSession() throws PWiException {
			return PWiSession.getPWiSession(servletRequest.getSession());
		}
		
		public String getContextPath() {
			return servletRequest.getContextPath();
		}
		
		public String getSsoId() {
			String sso = null;
			sso = servletRequest.getHeader("sm_ssoid");
			if(sso!=null && isValidSSO(sso))
			{
				return sso;
			}
			else
			{
				return sso;
			}
		}
		
		public String getParameter(String param)
		{
			return servletRequest.getParameter(param);
		}
		
		private boolean isValidSSO(String sso) {
			
			boolean result = true;
			
			if (StringUtils.isBlank(sso)) {
				FacesContext.getCurrentInstance().addMessage(
						PWiConstants.ERROR_BLANK_SSO,
						new FacesMessage(FacesMessage.SEVERITY_ERROR,
								PWiConstants.ERROR_BLANK_NAME,
								PWiConstants.ERROR_BLANK_NAME));
				result = false;
			} else {
				Matcher matcher = VALID_SSO_REGEX.matcher(sso);
				if (!matcher.find()) {
					FacesContext.getCurrentInstance().addMessage(
							PWiConstants.ERROR_INVALID_SSO,
							new FacesMessage(FacesMessage.SEVERITY_ERROR,
									PWiConstants.ERROR_INVALID_SSO,
									PWiConstants.ERROR_INVALID_SSO));
					result = false;
				}
			}
			return result;
		}

	}

}