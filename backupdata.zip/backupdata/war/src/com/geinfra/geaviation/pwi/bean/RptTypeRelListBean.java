/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName RptTypeRelListBean.java
 * @Creation date: 18-June-2014
 * @version 1.0
  * @author : Tech Mahindra
 */


package com.geinfra.geaviation.pwi.bean;

import java.util.List;

import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

import com.geinfra.geaviation.pwi.bean.util.BeanUtil;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.QueriesVO;
import com.geinfra.geaviation.pwi.service.QueriesService;

public class RptTypeRelListBean extends BaseBean {
	private static final Logger LOG = Logger
			.getLogger(RptTypeRelListBean.class);

	private List<QueriesVO> queriesVOListDraft;
	private QueriesService queriesService;
	private HtmlDataTable queryTableDraft = new HtmlDataTable();	
	
	public List<QueriesVO> getQueriesVOListDraft() throws PWiException {
		
		queriesVOListDraft = queriesService.getAllDraftQueries(getSsoId());
	
	return queriesVOListDraft;
}

public void setQueriesVOListDraft(List<QueriesVO> queriesVOListDraft) {
	this.queriesVOListDraft = queriesVOListDraft;
}

public QueriesService getQueriesService() {
	return queriesService;
}

public void setQueriesService(QueriesService queriesService) {
	this.queriesService = queriesService;
}

public HtmlDataTable getQueryTableDraft() {
	return queryTableDraft;
}

public void setQueryTableDraft(HtmlDataTable queryTableDraft) {
	this.queryTableDraft = queryTableDraft;
}

public String actionEditQuery() throws NumberFormatException, PWiException {
	return BeanUtil.getInstance().getRptTypeRelationBean().actionEditQuery(
			((QueriesVO) queryTableDraft.getRowData()).getQueryId());
}

/**
 * Action method that responds to requests for creating a query in admin.
 * 
 * @return Faces navigation outcome
 * @throws PWiException
 */
public String actionCreateQuery() throws PWiException {
	return BeanUtil.getInstance().getRptTypeRelationBean().callDynRptBldrWiz();
}


}