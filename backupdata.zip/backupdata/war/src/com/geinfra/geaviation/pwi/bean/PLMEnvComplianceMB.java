 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEnvComplianceMB.java
 * @Creation date: 9-Jul-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMEnvComplianceData;
import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMEnvComplianceServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMEnvComplianceMB {
	/**
	 *  Holds the lOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMEnvComplianceMB.class);
	/**
	 *  Holds the plmEnvComplianceService
	 */
	private PLMEnvComplianceServiceIfc plmEnvComplianceService = null;
	/**
	 *  Holds the loginMB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	/**
	 *  Holds the contractNum
	 */
	private String contractNum = "";
	/**
	 *  Holds the casNum
	 */
	private String casNum = "";
	/**
	 *  Holds the alertMsg
	 */
	private String envAlertMsg;		
	/**
	 *  Holds the classificationList
	 *  
	 */
	private List<String> classificationList = new ArrayList<String>();
	/**
	 *  Holds the selClassificationList
	 *  
	 */
	private List<SelectItem> selClassificationList = new ArrayList<SelectItem>();
	/**
	 *  Holds the classification
	 */
	private String classification;
	
	 /**
	   *  Holds the cntrctList
	   */
	 private List<PLMEnvComplianceData> cntrctList = new ArrayList<PLMEnvComplianceData>();

	 /**
	   * Holds the Properties file
	   */
		private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
		/**
		 *  Holds the reportBasedFlg
		 */
		private String reportBasedFlg="BOM";
		/**
		 *  Holds the reportBasedFlg
		 */
		private int count;
		/**
		 *  Holds the envComplianceRptList
		 */
		private List<PLMEnvComplianceData> envComplianceRptList= new ArrayList<PLMEnvComplianceData>();
		
		 private PLMPwiUserData userDetails = null;
		
		private PLMLoginData userDataObj = (PLMLoginData) PLMUtils
		.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA);
		
	/**
	 * This method is used to load home page of Environment Compliance 
	 * 
	 * @return String
	 * @throws PLMCommonException 
	 */
	public String getEnvComplianceHomePage() throws PLMCommonException{
		LOG.info("Entering getEnvComplianceHomePage method");
		commonMB.insertCannedRptRecordHitInfo("Environment Compliance Report");
		
		LOG.info("PLMEnvComplianceMB class getEnvComplianceHomePage method and record insert count"+count);
		String fwdFlag="envComplianceSearchRpt";
		  contractNum = "";
		  casNum = "";
		  classification="";
		  envAlertMsg = "";
		  selClassificationList = new ArrayList<SelectItem>();
		  classificationList = plmEnvComplianceService.getClassificationList();
		  reportBasedFlg="BOM";
		  count=0;
		  envComplianceRptList = new ArrayList<PLMEnvComplianceData>();
		   for(int i=0;i<classificationList.size();i++){
			  selClassificationList.add(new SelectItem(classificationList.get(i),classificationList.get(i)));
	          }
		   
	    LOG.info("Exiting getEnvComplianceHomePage method");
		return fwdFlag;
		
	}

	/**
	 * This method is used for validating contract number
	 * 
	 *@return String
	 */
	public String validationForComplianceRpt(String contractNumLcl){
		envAlertMsg = "";
		if (PLMUtils.isEmpty(contractNumLcl)) {
			envAlertMsg = envAlertMsg + PLMConstants.ENVIRON_SMRY_RPT_SEARCH_CRITERIA_EMPTY_CHK;
		} 
		return envAlertMsg;
	}

	
	 /**
	 * @throws PWiException 
	 * This method is used for generateEnvComplianceRpt
	 * 
	 * @return String
	 * @throws
	 */
     public void generateEnvComplianceRpt() throws PLMCommonException, PWiException{
		LOG.info("Entering generateEnvComplianceRpt Method");
		userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		  envAlertMsg = validationForComplianceRpt(contractNum);
		  if(PLMUtils.isEmpty(envAlertMsg)){
			  
			  if(reportBasedFlg.equals("WBSE")){
			    count=plmEnvComplianceService.fetchWBSEContract(contractNum);
			     if(count==0){
			       envAlertMsg = PLMConstants.ENVIRON_RPT_INVALID_WBSE_CRITERIA;
			     }
			     else{
					 envAlertMsg =  PLMConstants.ENV_COMPLIANCE_MAIL_ALERT_MSG;
					 LOG.info("Mail send succesfulyy");
					taskExecutor.execute(new MailThread());
	        	  }
			     
			  }
			  else{
				 count=plmEnvComplianceService.fetchBOMContract(contractNum);
				   if(count==0){
				       envAlertMsg = PLMConstants.ENVIRON_RPT_INVALID_BOM_CRITERIA;
				     }
				   else{
						 envAlertMsg =  PLMConstants.ENV_COMPLIANCE_MAIL_ALERT_MSG;
						 LOG.info("Mail send succesfulyy");
						taskExecutor.execute(new MailThread());
		        	  }
			  }
  	     }
	 	
		LOG.info("Exiting generateEnvComplianceRpt Method");
		
	}
     
     /**
		 * Background Process Thread
		 */
		private class MailThread implements Runnable {
			public MailThread(){}
			public void run() {
				sendEnvComplianceRptMail();
			}
		}
		
		/**
		 * This method is used for Generating & Sending the Report to mail
		 * 
		 * @return String
		 */
		public void sendEnvComplianceRptMail() {
			LOG.info("Entering sendEnvComplianceRptMail Method");
			String reportTypeFlg = reportBasedFlg;
			
			LOG.info("contractNum>>>>>>>"+contractNum);
			if (contractNum!=null) {
			String from = PLMConstants.ENV_COMPLIANCE_MAIL_FROM;
			
			String to = userDetails.getUserEmailId();		
			String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
			
			toAddressee = "Dear " + toAddressee + ", \n\n";
			String subject = PLMConstants.ENV_COMPLIANCE_MAIL_FROM_MAIL_SUBJECT + contractNum;
			StringBuffer mailBody = new StringBuffer().append(toAddressee)
			.append(PLMConstants.ENV_COMPLIANCE_MAIL_FROM_MAIL_CONTENT)
			.append(contractNum)
			.append(".")
			.append(PLMConstants.ENV_COMPLIANCE_MAIL_SIGNATURE)
			.append(PLMConstants.ENV_COMPLIANCE_MAIL_FOOTER);
			
			StringBuffer mailNoDataBody = new StringBuffer()
			.append(toAddressee)
			.append(PLMConstants.ENV_COMPLIANCE_NO_CONTENT_BODY)
			.append(contractNum)
			.append(".")
			.append(PLMConstants.ENV_COMPLIANCE_MAIL_SIGNATURE)
			.append(PLMConstants.ENV_COMPLIANCE_MAIL_FOOTER);
			
			final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
			Date uniqDate = new Date();
			String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
			String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
			String filePathXlsx = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("ENV_CMPLNC_RPT_NM") +  contractNum + "_" + uniqTime + ".xlsx";
			String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("ENV_CMPLNC_RPT_NM") +  contractNum + "_" + uniqTime + ".zip";
			File file = null;
			try {
			
			 if(reportTypeFlg.equals("WBSE")){	
				 LOG.info("Executing WBSE based Report Flag");
				envComplianceRptList = plmEnvComplianceService.getWBSEReport(contractNum,classification,casNum);
			  }
			 else{
				 LOG.info("Executing BOM based Report Flag");
				 envComplianceRptList = plmEnvComplianceService.getBOMReport(contractNum,classification,casNum);
			 }
				
				if (envComplianceRptList!=null && envComplianceRptList.size()>0) {
					saveEnvComplianceFile(contractNum,envComplianceRptList,reportTypeFlg,fileDir,filePathXlsx);
					PLMUtils.generateZipFile(filePathXlsx,filePathZip);
					file = new File(filePathZip);
					// Get the number of bytes in the file
					float sizeInBytes = file.length();
					//transform in MB
					float sizeInMb = sizeInBytes / (1024 * 1024);
					LOG.info("Zip File Size for Environement Compliance Report "+sizeInMb+" MB");
					PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
					LOG.info("Report Attachment Mail sent successfully.");
					envComplianceRptList.clear();
				} else {				
					PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
					LOG.info("No data Mail sent successfully.");
				}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@sendEnvComplianceRptMail: ", exception);
				PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.ENV_COMPLIANCE_MAIL_SIGNATURE);
			} catch (Exception exception) {
				LOG.log(Level.ERROR, "Exception@sendEnvComplianceRptMail: ", exception);
				PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.ENV_COMPLIANCE_MAIL_SIGNATURE);
			} finally {
				deleteFiles(filePathXlsx,filePathZip);
				/*if (file!=null)
					file.delete();*/
			}
			LOG.info("Exiting sendEnvComplianceRptMail Method");
			} else {
				LOG.info("Not able to generate the report. The Contract Number selected is "+contractNum);
			}
		}
		
		/**
		 * This method is used for Generating Report in XLS
		 * 
		 * @param contractNum,envComplianceRptList,fileDir,filePathXlsx
		 * @return StringBuffer
		 * @throws IOException
		 */
		
		public void saveEnvComplianceFile(String contractNumLcl,
				List<PLMEnvComplianceData> envLclComplianceRptList,String reportFlg,
				String fileDir,String filePathXlsx) throws IOException {
			LOG.info("Entering saveEnvComplianceFile File Method");
			FileOutputStream fileOut = null;
			boolean createFileExist;
			try {
				/*File file = new File(fileDir);
				boolean dirExists = file.exists();
				if (!dirExists) {	
					file.mkdir();
				}*/
				File fileName = new File(filePathXlsx);
				boolean fileExist = fileName.exists();
				if(!fileExist) {
					createFileExist =fileName.createNewFile();
					LOG.info("createFileExist>>>>.."+createFileExist);
			 	}
				if (fileName.exists()) {
					fileOut = new FileOutputStream(filePathXlsx);
					SXSSFWorkbook workbook = new SXSSFWorkbook();
					SXSSFSheet sheet =  (SXSSFSheet) workbook.createSheet("Environment Compliance");
					XSSFCellStyle headerStyle = (XSSFCellStyle) workbook.createCellStyle();
					
					headerStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
					headerStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
					headerStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
					headerStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
					headerStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex()); 
					headerStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
					XSSFFont font = (XSSFFont) workbook.createFont(); 
					font.setFontName(PLMConstants.EXCEL_FONT_NAME);
					font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
					font.setFontHeightInPoints((short)10);
					headerStyle.setFont(font);
					headerStyle = setBorderStyle(headerStyle);
					
					XSSFCellStyle cellBoldStyle = (XSSFCellStyle) workbook.createCellStyle();
					cellBoldStyle = setBorderStyle(cellBoldStyle);
					cellBoldStyle.setFont(font);
					
					XSSFFont nonBoldFont = (XSSFFont) workbook.createFont();
					nonBoldFont.setFontHeightInPoints((short)10);
					nonBoldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
					XSSFCellStyle contentStyle = (XSSFCellStyle) workbook.createCellStyle();				
					contentStyle = setBorderStyle(contentStyle);
					contentStyle.setFont(nonBoldFont);
					XSSFCellStyle contentDecimalStyle = (XSSFCellStyle) workbook.createCellStyle();				
					contentDecimalStyle = setBorderStyle(contentDecimalStyle);
					contentDecimalStyle.setFont(nonBoldFont);
					DataFormat format = workbook.createDataFormat();
					contentDecimalStyle.setDataFormat(format.getFormat("0.00000"));
							
					XSSFFont noRecordFont = (XSSFFont) workbook.createFont(); 
					noRecordFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
					noRecordFont.setColor(Font.COLOR_RED);
					noRecordFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
					noRecordFont.setFontHeightInPoints((short)10);
					XSSFCellStyle noRecordCellStyle = (XSSFCellStyle) workbook.createCellStyle();
					noRecordCellStyle = setBorderStyle(noRecordCellStyle);
					noRecordCellStyle.setFont(noRecordFont);
					
					CreationHelper createHelper = workbook.getCreationHelper();
					 XSSFCellStyle dateStyle1 = (XSSFCellStyle) workbook.createCellStyle();
						dateStyle1.setDataFormat(createHelper.createDataFormat().getFormat("m/d/yy h:mm"));
						dateStyle1 = setBorderStyle(contentStyle);
						dateStyle1.setFont(nonBoldFont);
					

					int rowcount = -1;
					String[] colNames;
					if(!PLMUtils.isEmptyList(envLclComplianceRptList)) {
						if(reportFlg.equals("WBSE")){
						colNames = new String[] {"Contract","Project Name","WBSE Name","WBSE Part Name","MLI New","PO Number",
								"Purchase Folder Office DTTM","Supplier Name","Supplier Person","Supplier Email","Purchase Folder Name",
								"Supplier BAAN Code","MLI Reference","Part Level","Part Number","Part Revision","Part Type","Part Attribute",
								"Part Title","Material","Material Type","CAS Number","Substance","Chemical Name","Regulation","RDO"};
						} else {
							colNames = new String[] {"Contract","Hardware Product","GBOM Part","Part Level","Part Number",
									"Part Type","Part Attribute","Part Revision","Part Title","Material","Material Type",
									"CAS Number","Substance","Chemical Name","Regulation","RDO","DFSORDER"};
						}
						SXSSFRow row = (SXSSFRow)sheet.createRow(++rowcount);
						SXSSFCell cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						cell.setCellValue(PLMConstants.ENV_COMPLIANCE_CRITERIA_MLNO);
						cell.setCellStyle(cellBoldStyle);

						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellValue(contractNumLcl);
						cell.setCellStyle(cellBoldStyle);
						
						row = (SXSSFRow) sheet.createRow(++rowcount);
						row = (SXSSFRow) sheet.createRow(++rowcount);
						
						for ( int i = 0 ; i < colNames.length; i++ ) {
							cell = (SXSSFCell)  row.createCell(i);
							cell. setCellValue(colNames[i]);
							cell.setCellStyle(headerStyle);
						}
						for(int i = 0; i < envLclComplianceRptList.size(); i++) {
							PLMEnvComplianceData dataObj = (PLMEnvComplianceData) envLclComplianceRptList.get(i);
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
					 if(reportFlg.equals("WBSE")){				
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ZERO);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getContract());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getProjectNm());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWO);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getWsdeName());
							
						
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THREE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getWsdePartName());

							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOUR);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getMliNew());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIVE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPoNum());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SIX);
							 cell.setCellStyle(dateStyle1);
							 DateFormat dateFormat1 = new SimpleDateFormat("MM/dd/yyyy HH:mm aa");
							if(dataObj.getPurchaseFolderDt()!=null){
								cell.setCellValue(dateFormat1.format(dataObj.getPurchaseFolderDt()));
							}else{
								cell.setCellValue("");
							}
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SEVEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getSupplierName());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_EIGHT);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getSupplierPerson());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_NINE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getSupplierEmail());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPurchaseFolderNm());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getSupplierBannCode());
							
								
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWELVE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getMliReference());
							
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartLvl());
	
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartNum());
							
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartRevision());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
								cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartType());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartAttribute());
							
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_EIGHTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartTitle());
								
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_NINETEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getMaterial());
							
						
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTY);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getMaterialType());
								
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYONE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getSubCaseNm());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYTWO);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getSubName());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYTHREE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getChemicalName());
							
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYFOUR);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getRegulation());
						
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWENTYFIVE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getRdoName());
						}
						else{
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ZERO);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getContract());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getProjectNm());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWO);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getWsdePartName());
							
						
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THREE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartLvl());

							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOUR);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartNum());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIVE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartType());
							
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SIX);
								cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartAttribute());
					
						
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SEVEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartRevision());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_EIGHT);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getPartTitle());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_NINE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getMaterial());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getMaterialType());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getSubCaseNm());
							
								
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWELVE);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getSubName());
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getChemicalName());
							
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getRegulation());
	
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getRdoName());
							
							
							cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
							cell.setCellStyle(contentStyle);
							cell.setCellValue(dataObj.getDfsOrder());
							
							
						}
						
								
						}
						
						row = (SXSSFRow) sheet.createRow(++rowcount);
						row = (SXSSFRow) sheet.createRow(++rowcount);
					short colWidth = (short)6400;
					short colWidth1 = (short)6700;
					short colWidth2 = (short)7000;
					short colWidth3 = (short)7200;
					short colWidth4 = (short)7900;
					short colWidth5 = (short)8600;
									
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO,colWidth4);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE,colWidth2);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO,colWidth1);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE,colWidth);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR,colWidth2);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE,colWidth2);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN,colWidth);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT,colWidth);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE,colWidth);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN,colWidth);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN,colWidth);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWELVE,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTEEN,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTEEN,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTEEN,colWidth3);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIXTEEN,colWidth5);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVENTEEN,colWidth5);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHTEEN,colWidth);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINETEEN,colWidth2);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTY,colWidth2);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYONE,colWidth);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYTWO,colWidth4);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYTHREE,colWidth2);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYFOUR,colWidth2);
						sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYFIVE,colWidth2);
		

						
					} else {
						LOG.info("There is no record found for " + contractNumLcl+" in method saveEnvComplianceFile File");
						SXSSFRow row = (SXSSFRow) sheet.createRow(++rowcount);
						SXSSFCell cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
						String noRecordMsg = PLMConstants.ENV_COMPLIANCE_NO_RECORD_FOUND + contractNumLcl;
						cell.setCellValue(noRecordMsg);
						cell.setCellStyle(noRecordCellStyle);
						sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
					}	
					workbook.write(fileOut);
					fileOut.close();
				}
			} catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@saveEnvComplianceFile File: ", e);
				throw e;
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveEnvComplianceFile File: ", e);
				throw e;
			}  finally {
				try {
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@saveEnvComplianceFile: ", e);
					throw e;
				}
			}
			LOG.info("Exiting saveEnvComplianceFile File Method");
		}
		
		
		/**
		 * This method is used for Bordering Cell in XLSX
		 * 
		 * @return StringBuffer
		 */
		private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
			style.setBorderTop(XSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			style.setBorderRight(XSSFCellStyle.BORDER_THIN);
			return style;
		}
		/**
		 * This method is used for Deleting zip file and xls file
		 * 
		 *@param filePathXls,filePathZip
		 */
		public void deleteFiles(String filePathXls,String filePathZip){
			LOG.info("Entering deleteFiles method");
			boolean zipFileExist;
			boolean xlsFileExist;
			File zipFile = new File(filePathZip);
			zipFileExist = zipFile.exists();
			File xlsFile = new File(filePathXls);
			xlsFileExist = xlsFile.exists();
			if(zipFileExist){
				boolean deleted = zipFile.delete();
				LOG.info("Successfully deleted zip file : " + deleted);
			}
			if(xlsFileExist){
				boolean deleted = xlsFile.delete();
				LOG.info("Successfully deleted xls file : " + deleted);
			}
			LOG.info("Exiting deleteFiles Method");
		}
	/**
	 * @return the plmEnvComplianceService
	 */
	public PLMEnvComplianceServiceIfc getPlmEnvComplianceService() {
		return plmEnvComplianceService;
	}


	/**
	 * @param plmEnvComplianceService the plmEnvComplianceService to set
	 */
	public void setPlmEnvComplianceService(
			PLMEnvComplianceServiceIfc plmEnvComplianceService) {
		this.plmEnvComplianceService = plmEnvComplianceService;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}


	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}


	/**
	 * @return the contractNum
	 */
	public String getContractNum() {
		return contractNum;
	}


	/**
	 * @param contractNum the contractNum to set
	 */
	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}


	/**
	 * @return the casNum
	 */
	public String getCasNum() {
		return casNum;
	}


	/**
	 * @param casNum the casNum to set
	 */
	public void setCasNum(String casNum) {
		this.casNum = casNum;
	}


	/**
	 * @return the envAlertMsg
	 */
	public String getEnvAlertMsg() {
		return envAlertMsg;
	}

	/**
	 * @param envAlertMsg the envAlertMsg to set
	 */
	public void setEnvAlertMsg(String envAlertMsg) {
		this.envAlertMsg = envAlertMsg;
	}

	/**
	 * @return the classificationList
	 */
	public List<String> getClassificationList() {
		return classificationList;
	}


	/**
	 * @param classificationList the classificationList to set
	 */
	public void setClassificationList(List<String> classificationList) {
		this.classificationList = classificationList;
	}


	/**
	 * @return the selClassificationList
	 */
	public List<SelectItem> getSelClassificationList() {
		return selClassificationList;
	}


	/**
	 * @param selClassificationList the selClassificationList to set
	 */
	public void setSelClassificationList(List<SelectItem> selClassificationList) {
		this.selClassificationList = selClassificationList;
	}


	/**
	 * @return the classification
	 */
	public String getClassification() {
		return classification;
	}


	/**
	 * @param classification the classification to set
	 */
	public void setClassification(String classification) {
		this.classification = classification;
	}


	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return LOG;
	}

	/**
	 * @return the cntrctList
	 */
	public List<PLMEnvComplianceData> getCntrctList() {
		return cntrctList;
	}

	/**
	 * @param cntrctList the cntrctList to set
	 */
	public void setCntrctList(List<PLMEnvComplianceData> cntrctList) {
		this.cntrctList = cntrctList;
	}

	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return the reportBasedFlg
	 */
	public String getReportBasedFlg() {
		return reportBasedFlg;
	}

	/**
	 * @param reportBasedFlg the reportBasedFlg to set
	 */
	public void setReportBasedFlg(String reportBasedFlg) {
		this.reportBasedFlg = reportBasedFlg;
	}



	
	
	
}
