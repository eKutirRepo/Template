package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 9, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : PWiFrequencyTypeVO
 * 
 * Revision Log Aug 9, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiFrequencyTypeVO extends PWiBaseVO implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer frqncyTypSeqId;
	private String frqncyTypNm;
	private boolean selected;
	private Collection<PWiUserCustomQueryVO> PWiUserCustomQueryCollection;

	public PWiFrequencyTypeVO() {
	}

	public PWiFrequencyTypeVO(Integer frqncyTypSeqId) {
		this.frqncyTypSeqId = frqncyTypSeqId;
	}

	public PWiFrequencyTypeVO(Integer frqncyTypSeqId, String frqncyTypNm,
			Date crtnDt, String crtdBy, Date lstUpdtDt, String lstUpdtdBy) {
		super(crtnDt, crtdBy, lstUpdtDt, lstUpdtdBy);
		this.frqncyTypSeqId = frqncyTypSeqId;
		this.frqncyTypNm = frqncyTypNm;
	}

	public Integer getFrqncyTypSeqId() {
		return frqncyTypSeqId;
	}

	public void setFrqncyTypSeqId(Integer frqncyTypSeqId) {
		this.frqncyTypSeqId = frqncyTypSeqId;
	}

	public String getFrqncyTypNm() {
		return frqncyTypNm;
	}

	public void setFrqncyTypNm(String frqncyTypNm) {
		this.frqncyTypNm = frqncyTypNm;
	}

	public Collection<PWiUserCustomQueryVO> getPWiUserCustomQueryCollection() {
		return PWiUserCustomQueryCollection;
	}

	public void setPWiUserCustomQueryCollection(
			Collection<PWiUserCustomQueryVO> PWiUserCustomQueryCollection) {
		this.PWiUserCustomQueryCollection = PWiUserCustomQueryCollection;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (frqncyTypSeqId != null ? frqncyTypSeqId.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object instanceof PWiFrequencyTypeVO) {
			PWiFrequencyTypeVO other = (PWiFrequencyTypeVO) object;
			if (this.frqncyTypSeqId != null
					&& other.frqncyTypSeqId != null) {
				return other.frqncyTypSeqId.equals(this.frqncyTypSeqId);
			}
		}
		return false;
	}

	@Override
	public String toString() {
		return "com.geinfra.geaviation.pwi.model.PWiFrequencyType[frqncyTypSeqId="
				+ frqncyTypSeqId + "]";
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

}
