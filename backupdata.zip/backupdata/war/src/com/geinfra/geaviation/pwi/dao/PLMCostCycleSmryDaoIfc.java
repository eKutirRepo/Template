/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCostCycleSmryDaoIfc.java
 * @Creation date: 16-Jul-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import com.geinfra.geaviation.pwi.data.PLMCostCycleSmryData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMCostCycleSmryDaoIfc {

	/**
	 * This methods is used for getting CR count
	 * 
	 * @return int
	 * throws PLMCommonException
	 */
	public int getCrCount(String crNum) throws PLMCommonException;
	/**
	 * This method is used to get Contracts List
	 * 
	 * @return List<PLMCostCycleSmryData>
	 * @throws PLMCommonException
	 */
	public List<PLMCostCycleSmryData> getContractForCR(String crNum)	throws PLMCommonException;
	/**
	 * This method is used to get Cost Cycle Result List
	 * 
	 * @return List<PLMCostCycleSmryData>
	 * @throws PLMCommonException
	 */
	public Map<String, List<PLMCostCycleSmryData>> getCostCycleResult(String crNum)	throws PLMCommonException;
	
	
}
