/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMProjectTaskData.java
 * @Creation date: 16-June-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;
import java.util.List;

public class PLMProjectTaskData {
	/**
	  * Holds the dueDateFromProject
	  */
	private Date dueDateFromProject;
	/**
	  * Holds the dueDateToProject
	  */
	private Date dueDateToProject;
	/**
	  * Holds the policyTask
	  */
	private String policyTask;
	/**
	  * Holds the statusProject
	  */
	private String statusProject;
	/**
	  * Holds the statusProjectList
	  */
	private List<String> statusProjectList;
	/**
	  * Holds the statusProjectExcel
	  */
	private String statusProjectExcel;
	/**
	  * Holds the voucherFundingSource
	  */
	private String voucherFundingSource;
	/**
	  * Holds the prjNamesList
	  */
	private List<String> prjNamesList;
	/**
	  * Holds the prjName
	  */
	private String prjName;
	/**
	  * Holds the prjNamesExcel
	  */
	private String prjNamesExcel;
	/**
	  * Holds the selectedPrjName
	  */
	private String selectedPrjName;
	/**
	  * Holds the prjTaskCount
	  */
	private int prjTaskCount;
	/**
	  * Holds the routeTaskCount
	  */
	private int routeTaskCount;
	/**
	  * Holds the summaryCount
	  */
	private int summaryCount;
	/**
	  * Holds the prjTaskType
	  */
	private String prjTaskType;
		
	
	/**
	 * @return the dueDateFromProject
	 */
	public Date getDueDateFromProject() {
		Date temp = null;
		temp = dueDateFromProject;
		return temp;
	}
	/**
	 * @param dueDateFromProject the dueDateFromProject to set
	 */
	public void setDueDateFromProject(Date dueDateFromProject) {
		Date temp = null;
		temp = dueDateFromProject;
		this.dueDateFromProject = temp;
	}
	/**
	 * @return the dueDateToProject
	 */
	public Date getDueDateToProject() {
		Date temp = null;
		temp = dueDateToProject;
		return temp;
	}
	/**
	 * @param dueDateToProject the dueDateToProject to set
	 */
	public void setDueDateToProject(Date dueDateToProject) {
		Date temp = null;
		temp = dueDateToProject;
		this.dueDateToProject = temp;
	}
	/**
	 * @return the policyTask
	 */
	public String getPolicyTask() {
		return policyTask;
	}
	/**
	 * @param policyTask the policyTask to set
	 */
	public void setPolicyTask(String policyTask) {
		this.policyTask = policyTask;
	}
	/**
	 * @return the statusProject
	 */
	public String getStatusProject() {
		return statusProject;
	}
	/**
	 * @param statusProject the statusProject to set
	 */
	public void setStatusProject(String statusProject) {
		this.statusProject = statusProject;
	}
	/**
	 * @return the statusProjectList
	 */
	public List<String> getStatusProjectList() {
		return statusProjectList;
	}
	/**
	 * @param statusProjectList the statusProjectList to set
	 */
	public void setStatusProjectList(List<String> statusProjectList) {
		this.statusProjectList = statusProjectList;
	}
	/**
	 * @return the statusProjectExcel
	 */
	public String getStatusProjectExcel() {
		return statusProjectExcel;
	}
	/**
	 * @param statusProjectExcel the statusProjectExcel to set
	 */
	public void setStatusProjectExcel(String statusProjectExcel) {
		this.statusProjectExcel = statusProjectExcel;
	}
	/**
	 * @return the voucherFundingSource
	 */
	public String getVoucherFundingSource() {
		return voucherFundingSource;
	}
	/**
	 * @param voucherFundingSource the voucherFundingSource to set
	 */
	public void setVoucherFundingSource(String voucherFundingSource) {
		this.voucherFundingSource = voucherFundingSource;
	}
	/**
	 * @return the prjNamesList
	 */
	public List<String> getPrjNamesList() {
		return prjNamesList;
	}
	/**
	 * @param prjNamesList the prjNamesList to set
	 */
	public void setPrjNamesList(List<String> prjNamesList) {
		this.prjNamesList = prjNamesList;
	}
	/**
	 * @return the prjTaskCount
	 */
	public int getPrjTaskCount() {
		return prjTaskCount;
	}
	/**
	 * @param prjTaskCount the prjTaskCount to set
	 */
	public void setPrjTaskCount(int prjTaskCount) {
		this.prjTaskCount = prjTaskCount;
	}
	/**
	 * @return the routeTaskCount
	 */
	public int getRouteTaskCount() {
		return routeTaskCount;
	}
	/**
	 * @param routeTaskCount the routeTaskCount to set
	 */
	public void setRouteTaskCount(int routeTaskCount) {
		this.routeTaskCount = routeTaskCount;
	}
	/**
	 * @return the summaryCount
	 */
	public int getSummaryCount() {
		return summaryCount;
	}
	/**
	 * @param summaryCount the summaryCount to set
	 */
	public void setSummaryCount(int summaryCount) {
		this.summaryCount = summaryCount;
	}
	/**
	 * @return the selectedPrjName
	 */
	public String getSelectedPrjName() {
		return selectedPrjName;
	}
	/**
	 * @param selectedPrjName the selectedPrjName to set
	 */
	public void setSelectedPrjName(String selectedPrjName) {
		this.selectedPrjName = selectedPrjName;
	}
	/**
	 * @return the prjName
	 */
	public String getPrjName() {
		return prjName;
	}
	/**
	 * @param prjName the prjName to set
	 */
	public void setPrjName(String prjName) {
		this.prjName = prjName;
	}
	/**
	 * @return the prjNamesExcel
	 */
	public String getPrjNamesExcel() {
		return prjNamesExcel;
	}
	/**
	 * @param prjNamesExcel the prjNamesExcel to set
	 */
	public void setPrjNamesExcel(String prjNamesExcel) {
		this.prjNamesExcel = prjNamesExcel;
	}
	/**
	 * @return the prjTaskType
	 */
	public String getPrjTaskType() {
		return prjTaskType;
	}
	/**
	 * @param prjTaskType the prjTaskType to set
	 */
	public void setPrjTaskType(String prjTaskType) {
		this.prjTaskType = prjTaskType;
	}
	
}
