/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCRReportDaoImpl.java
 * @Creation date: 12-Aug-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMCRReportData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMCRReportDaoImpl extends SimpleJdbcDaoSupport  implements  PLMCRReportDaoIfc{
	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMCRReportDaoImpl.class);
	
	private boolean routeFlg;

	
	
	/**
	 * This method is used to get  List of States
	 * 
	 * @return List<SelectItem>
	 * @throws PLMCommonException
	 */
	public List<SelectItem> getCRStates()throws PLMCommonException{
		LOG.info("Entering getCRStates() method.");
		List<SelectItem> stateList = new ArrayList<SelectItem>();
      try{
    	stateList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_CR_STATES,new StateMapper());
	    LOG.info("Final Query state List is : " + PLMSearchQueries.GET_CR_STATES);
	    } catch (DataAccessException e) {
	  PLMUtils.checkException(e.getMessage());
     }
     return stateList;
	}
	/**
	 * Mapper for Getting List of States
	 */
	private static final class StateMapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs.getString("STATE"));
			return selectItem;
		}
	}
	
	/**
	 * This method is used to get CR Report List
	 * 
	 * @return List<PLMCRReportData>
	 * @throws PLMCommonException
	 */
	public List<PLMCRReportData> getCRReportData(PLMCRReportData reportData)	throws PLMCommonException{
		LOG.info("Entering getCRReportData() of DAO Impl"); 
		 List<PLMCRReportData> crReportList = new ArrayList<PLMCRReportData>();
		 StringBuffer sqlQuery =new StringBuffer();
		 boolean whereFlg=false;
		 routeFlg=false;
		 try{
			 if(reportData.getPlmCntrIps()!= null && reportData.getPlmCntrIps().length() > 0){
				 if(!reportData.isRouteTaskFlg()){
					 
					 sqlQuery.append(PLMSearchQueries.GET_CR_REPORT_DATA1.replace("?","'"+reportData.getPlmCntrIps()+"'"))
					 .append(PLMSearchQueries.GET_CR_REPORT_DATA3)
					 .append(PLMSearchQueries.GET_CR_REPORT_DATA5);
				 } else {

					 sqlQuery.append(PLMSearchQueries.GET_CR_REPORT_DATA1.replace("?","'"+reportData.getPlmCntrIps()+"'"))
					 .append(PLMSearchQueries.GET_CR_REPORT_DATA2)
					 .append(PLMSearchQueries.GET_CR_REPORT_DATA3)
					 .append(PLMSearchQueries.GET_CR_REPORT_DATA4)
					 .append(PLMSearchQueries.GET_CR_REPORT_DATA5)
					 .append(PLMSearchQueries.GET_CR_REPORT_DATA6);
					  routeFlg=true;
				 }
				 String finalQry = appendWhereCRReport(reportData, sqlQuery, whereFlg, false);

				 LOG.info("\nExecuting getCRReportData Query :: \n" +finalQry);
				 crReportList = getSimpleJdbcTemplate().query(finalQry,new CrReportMapper());
				
			}else {
				String timeStamp = PLMUtils.volTableFormatDate();
				String CR_VT1 = PLMConstants.CR_VT1.concat(timeStamp);
				String CR_VT2 = PLMConstants.CR_VT2.concat(timeStamp);
				
				if(!reportData.isRouteTaskFlg()){
					 
					 sqlQuery.append(PLMSearchQueries.GET_CR_RPT_NO_CTRCT_DATA1)
					 .append(PLMSearchQueries.GET_CR_RPT_NO_CTRCT_DATA3);
					 
				}else{
					  sqlQuery.append(PLMSearchQueries.GET_CR_RPT_NO_CTRCT_DATA1)
					 .append(PLMSearchQueries.GET_CR_REPORT_DATA2)
					 .append(PLMSearchQueries.GET_CR_RPT_NO_CTRCT_DATA3)
					 .append(PLMSearchQueries.GET_CR_REPORT_DATA4);
					  routeFlg=true;
				 }
				
				String crWhrQry = appendWhereCRReport(reportData, sqlQuery, whereFlg, true);
				
				StringBuffer finalQuery = new StringBuffer(crWhrQry)
				 .append(PLMSearchQueries.GET_CR_RPT_NO_CTRCT_DATA5);
				
				String finalQryCr = finalQuery.toString().replace(PLMConstants.CR_VT1,CR_VT1);
								
				LOG.info("\nExecuting getCRReportData VT1 Query :: \n" +finalQryCr);
				getJdbcTemplate().execute(finalQryCr);
				
				String crRptVt2Qry = PLMSearchQueries.GET_CR_RPT_VT2.replace(PLMConstants.CR_VT1,CR_VT1).replace(PLMConstants.CR_VT2,CR_VT2);
				
				LOG.info("\nExecuting getCRReportData VT2 Query :: \n" +crRptVt2Qry);
				getJdbcTemplate().execute(crRptVt2Qry);
				
				StringBuffer crRptSelQry = new StringBuffer();
				
				if(!reportData.isRouteTaskFlg()){
					crRptSelQry.append(PLMSearchQueries.GET_CR_RPT_FINAL_SEL1);
				 }else {
					 crRptSelQry.append(PLMSearchQueries.GET_CR_RPT_FINAL_SEL1)
					 .append(PLMSearchQueries.GET_CR_RPT_FINAL_SEL2);
					  routeFlg=true;
				 }
				crRptSelQry.append(PLMSearchQueries.GET_CR_RPT_FINAL_SEL3);
				
				String crRptSelFinalQry = crRptSelQry.toString().replace(PLMConstants.CR_VT1,CR_VT1).replace(PLMConstants.CR_VT2,CR_VT2);
				LOG.info("\nExecuting getCRReportData Query :: \n" +crRptSelFinalQry);
				crReportList = getSimpleJdbcTemplate().query(crRptSelFinalQry,new CrReportMapper());
				
			}
		   
		 } catch(DataAccessException e){
			 LOG.info("Exception on getCRReportData"+e.getMessage());
			 PLMUtils.checkException(e.getMessage());
		 }
		 LOG.info("Existing getCRReportData() of DAO Impl final List Size ::: "+crReportList.size()); 
		 return crReportList;
	}
	/**
	 * @param reportData
	 * @param sqlQuery
	 * @param whereFlg
	 */
	private String appendWhereCRReport(PLMCRReportData reportData,
			StringBuffer sqlQuery1, boolean whereFlglcl, boolean vtFlag) {

		final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
		"MM/dd/yyyy");
		boolean whereFlag=whereFlglcl;
		StringBuffer sqlTempQry = new StringBuffer(sqlQuery1);
		if(reportData.getCrName()!=null && reportData.getCrName().length()>0){
				LOG.info("CR Requirement Name : " + reportData.getCrName());
			
				if(whereFlag){
					sqlTempQry.append(" AND ");
				}else{
					sqlTempQry.append(" WHERE ");
					whereFlag=true; 
				}
		   	 	sqlTempQry.append(" CR_NAME = "+ "'"+reportData.getCrName()+"'") ;
		   	 whereFlag=true;
		 }
		 
		 //Appending Product List
		 if(reportData.getStateList().size() > 0){
			 LOG.info("List of States : " + PLMUtils.setListForQuery(reportData.getStateList()));
				
			 if(whereFlag){
			 sqlTempQry.append(" AND ");
			 }else{
				 sqlTempQry.append(" WHERE ");
				 whereFlag=true; 
			  }
			 
			 sqlTempQry.append("CR_STATE IN (" +PLMUtils.setListForQuery(reportData.getStateList())+ ")");
		 }
			
		
		 //Appending Originated Date Range
		 if(reportData.getOriginFromDate() != null && reportData.getOriginToDate() != null) { 
			 LOG.info("CR Originated Start  From Date: " + SIMPLE_DATE_FORMAT.format(reportData.getOriginFromDate()) +" To Date"+SIMPLE_DATE_FORMAT.format(reportData.getOriginToDate()));
				
			 if(whereFlag){
			 sqlTempQry.append(" AND ");
			 }else{
				 sqlTempQry.append(" WHERE ");
				 whereFlag=true; 
			  }
			 sqlTempQry.append("(CR_ORIGINATED_DATE IS NOT NULL AND CR_ORIGINATED_DATE BETWEEN CAST('");
			 sqlTempQry.append(SIMPLE_DATE_FORMAT.format(reportData.getOriginFromDate())+ "' AS DATE FORMAT 'MM/DD/YYYY') AND ");
			 sqlTempQry.append(" CAST('");
			 sqlTempQry.append(SIMPLE_DATE_FORMAT.format(reportData.getOriginToDate())+ "' AS DATE FORMAT 'MM/DD/YYYY'))");
		 }
		 
		 //Appending CR Originator SSO Names
			if (reportData.getCrOriginator() != null && reportData.getCrOriginator().length() > 0) {
				LOG.info("value of CR Originator : " +reportData.getCrOriginator());
				if(whereFlag){
					sqlTempQry.append(" AND ");
				}else{
					sqlTempQry.append(" WHERE ");
					whereFlag=true; 
				}
				if (PLMUtils.isInteger(reportData.getCrOriginator())) {
					sqlTempQry.append(PLMUtils.generateQueryWhereClauseWithEquals(PLMConstants.ORIG_SSO, reportData.getCrOriginator()));
				}else{
					sqlTempQry.append(PLMConstants.ORIG_SSO);
					sqlTempQry.append(" IN ");
					sqlTempQry.append("(");
					sqlTempQry.append(PLMSearchQueries.GET_SSO_NAMES + " ");
					sqlTempQry.append(PLMUtils.generateQueryWhereClauseForTaskSearch(PLMConstants.FIRST_NAME,reportData.getCrOriginator().trim()));
					sqlTempQry.append(" OR ");
					sqlTempQry.append(PLMUtils.generateQueryWhereClauseForTaskSearch(PLMConstants.LAST_NAME,reportData.getCrOriginator().trim()));
					sqlTempQry.append(")");
				}
			}
			//Appending CR Owner SSO Names
			if (reportData.getCrOwner() != null && reportData.getCrOwner().length() > 0) {
				LOG.info("value of CR Owner : " +reportData.getCrOwner());
				if(whereFlag){
					sqlTempQry.append(" AND ");
				}else{
					sqlTempQry.append(" WHERE ");
					whereFlag=true; 
				}
				if (PLMUtils.isInteger(reportData.getCrOwner())) {
					sqlTempQry.append(PLMUtils.generateQueryWhereClauseWithEquals(PLMConstants.OWNR_SSO, reportData.getCrOwner()));
				}else {
					sqlTempQry.append(PLMConstants.OWNR_SSO);
					sqlTempQry.append(" IN ");
					sqlTempQry.append("(");
					sqlTempQry.append(PLMSearchQueries.GET_SSO_NAMES + " ");
					sqlTempQry.append(PLMUtils.generateQueryWhereClauseForTaskSearch(PLMConstants.FIRST_NAME,reportData.getCrOwner().trim()));
					sqlTempQry.append(" OR ");
					sqlTempQry.append(PLMUtils.generateQueryWhereClauseForTaskSearch(PLMConstants.LAST_NAME,reportData.getCrOwner().trim()));
					sqlTempQry.append(")");
				}
				
			}
		 
			 //Appending CR title
			if(reportData.getCrTitleNm()!= null && reportData.getCrTitleNm().length() > 0){
				LOG.info("value of CR Title : " +reportData.getCrTitleNm());
				if(whereFlag){
					sqlTempQry.append(" AND ");
				}else{
					sqlTempQry.append(" WHERE ");
					whereFlag=true; 
				}
				sqlTempQry.append(PLMUtils.generateQueryWhereClauseForTaskSearch("CR_TITLE", reportData.getCrTitleNm().trim()));
			}
			
			 //Appending CR Desc
			if(reportData.getCrDescNm()!= null && reportData.getCrDescNm().length() > 0){
				LOG.info("value of CR desc : " +reportData.getCrDescNm());
				 if(whereFlag){
				 sqlTempQry.append(" AND ");
				 }else{
					 sqlTempQry.append(" WHERE ");
					 whereFlag=true; 
				 }
					sqlTempQry.append(PLMUtils.generateQueryWhereClauseForTaskSearch("CR_DESC", reportData.getCrDescNm().trim()));
	  		}
			
			
			 //Appending productList
			if(reportData.getProductList()!= null && reportData.getProductList().size() > 0){
				LOG.info("value of Product List desc : " +reportData.getProductList());
				 if(whereFlag){
				 sqlTempQry.append(" AND ");
				 }else{
					 sqlTempQry.append(" WHERE ");
					 whereFlag=true; 
				  }
				 sqlTempQry.append("COST_GRP IN (" +PLMUtils.setListForQuery(reportData.getProductList())+ ")");
			}
			
			//Appending route Task Flag
			if (!vtFlag) {
				if(!reportData.isRouteTaskFlg()){
					sqlTempQry.append(" ORDER BY H.TO_NAME ");
				}else {
					sqlTempQry.append(" ORDER BY H.TO_NAME, ROUTE_NAME, TASK_NAME ");
				 }
			}
		return sqlTempQry.toString();
	}
	
	
	/**
	 * Mapper for Getting Cr Report Data
	 */
	private class CrReportMapper implements ParameterizedRowMapper<PLMCRReportData>{
	public PLMCRReportData mapRow(ResultSet rs, int rowCount)
				throws SQLException {

		final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
		"MM/dd/yyyy");
		PLMCRReportData reportData = new PLMCRReportData();
		reportData.setCrId(rs.getString(PLMUtils.checkNullVal("CR_ID")));
		reportData.setCrName(rs.getString(PLMUtils.checkNullVal("CR_NAME")));
		reportData.setContractDesc(rs.getString(PLMUtils.checkNullVal("CONTRACT_DESC")));
		reportData.setCrState(rs.getString(PLMUtils.checkNullVal("CR_STATE")));
		
		Date crOrgDt = rs.getDate("CR_ORIGINATED_DATE");
		if (crOrgDt != null) {
			String strcrOrgDt = SIMPLE_DATE_FORMAT.format(crOrgDt);
			reportData.setCrOrigDt(strcrOrgDt);
		} 
		reportData.setOriginSSO(rs.getString(PLMUtils.checkNullVal("ORIGINATOR_SSO")));
		reportData.setOriginNM(rs.getString(PLMUtils.checkNullVal("ORIGINATOR_NM")));
		reportData.setOwnerSSO(rs.getString(PLMUtils.checkNullVal("OWNR_SSO")));
		reportData.setOwnerNM(rs.getString(PLMUtils.checkNullVal("OWNR_NM")));
		reportData.setCrTitleCst(rs.getString(PLMUtils.checkNullVal("CR_TITLE")));
		reportData.setCrDesc(rs.getString(PLMUtils.checkNullVal("CR_DESC")));
		reportData.setContract(rs.getString(PLMUtils.checkNullVal("CONTRACT")));
		reportData.setContractCrId(rs.getString(PLMUtils.checkNullVal("CR_ID"))+"~"+rs.getString(PLMUtils.checkNullVal("CONTRACT")));
		
		if(routeFlg){
		reportData.setRouteId(rs.getString(PLMUtils.checkNullVal("ROUTE_ID")));
		reportData.setRouteName(rs.getString(PLMUtils.checkNullVal("ROUTE_NAME")));
		reportData.setRouteOwnSSO(rs.getString(PLMUtils.checkNullVal("ROUTE_OWNR_SSO")));
		
		Date routeDueDt = rs.getDate("ROUTE_DUE_DATE");
		 if (routeDueDt != null) {
			String strrouteDueDt = SIMPLE_DATE_FORMAT.format(routeDueDt);
			reportData.setRouteDueDt(strrouteDueDt);
		 } 
		
		Date routeOrgDt = rs.getDate("ROUTE_ORIG_DATE");
		 if (routeOrgDt != null) {
			String strrouteOrgDt = SIMPLE_DATE_FORMAT.format(routeOrgDt);
			reportData.setRouteOrgDt(strrouteOrgDt);
		 } 
		reportData.setRouteState(rs.getString(PLMUtils.checkNullVal("ROUTE_STATE")));
		reportData.setTaskId(rs.getString(PLMUtils.checkNullVal("TASK_ID")));
		reportData.setTaskName(rs.getString(PLMUtils.checkNullVal("TASK_NAME")));
		reportData.setTaskState(rs.getString(PLMUtils.checkNullVal("TASK_STATE")));
		reportData.setTaskOwnerSSO(rs.getString(PLMUtils.checkNullVal("TASK_OWNR_SSO")));
		reportData.setTaskAprovStatus(rs.getString(PLMUtils.checkNullVal("TASK_APPROVAL_STATUS")));
		
		Date taskDueDt = rs.getDate("TASK_DUE_DATE");
		 if (taskDueDt != null) {
			String strtaskDueDt = SIMPLE_DATE_FORMAT.format(taskDueDt);
			reportData.setTaskDueDt(strtaskDueDt);
		 } 
		
		Date taskOrgDt = rs.getDate("TASK_ORIG_DATE");
		 if (taskOrgDt != null) {
			String strtaskOrgDt = SIMPLE_DATE_FORMAT.format(taskOrgDt);
			reportData.setTaskOrgDt(strtaskOrgDt);
		 } 
		
		Date taskCompleteDt = rs.getDate("TASK_COMPLETED_DATE");
		 if (taskCompleteDt != null) {
			String strtaskCompleteDt = SIMPLE_DATE_FORMAT.format(taskCompleteDt);
			reportData.setTaskCompleteDt(strtaskCompleteDt);
		 } 
		reportData.setDispositionCmts(rs.getString(PLMUtils.checkNullVal("DISPOSITION_TASK_CMTS")));
		}
		if (rs.getInt("LVL")==1) {
			reportData.setCrLvlStr("1 - Applicable CR");
		} else {
			if (reportData.getContract()!=null && !reportData.getContract().equals(""))
			reportData.setCrLvlStr("2 - Cancelled / In Progress / Not Applicable CR");
		}
		reportData.setCrLvl(rs.getInt("LVL"));
		reportData.setCostGrp(rs.getString(PLMUtils.checkNullVal("COST_GRP")));
		
		return reportData;
		}
	}
	

	/**
	 * This method is used to get CR Report Details List
	 * 
	 * @return List<PLMCRReportData>
	 * @throws PLMCommonException
	 */
	public List<PLMCRReportData> getCRReportDetailsData(List<String> crValuesList,PLMCRReportData reportData)	throws PLMCommonException{
		LOG.info("Entering getCRReportDetailsData() of DAO Impl"); 
		 List<PLMCRReportData> crDetailReportList = new ArrayList<PLMCRReportData>();
		 StringBuffer sqlQuery =new StringBuffer();
		 try{
			 String timeStamp = PLMUtils.volTableFormatDate();
		
		  if(reportData.getPlmCntrIps()!= null && reportData.getPlmCntrIps().length() > 0){
			 String CR_RPT_VT1 = PLMConstants.CR_RPT_VT1.concat(timeStamp);
			 if(!reportData.isRouteTaskFlg()){
				 sqlQuery.append(PLMSearchQueries.CREATE_CR_RPT_VT1_VOL.replace(PLMConstants.CR_RPT_VT1,CR_RPT_VT1))
				 .append(PLMSearchQueries.GET_CR_REPORT_DATA1.replace("?","'"+reportData.getPlmCntrIps()+"'"))
				 .append(PLMSearchQueries.GET_CR_REPORT_DATA3)
				 .append(PLMSearchQueries.GET_CR_REPORT_DATA5);
			 }else{
				 sqlQuery.append(PLMSearchQueries.CREATE_CR_RPT_VT1_VOL.replace(PLMConstants.CR_RPT_VT1,CR_RPT_VT1))
				 .append(PLMSearchQueries.GET_CR_REPORT_DATA1.replace("?","'"+reportData.getPlmCntrIps()+"'"))
				 .append(PLMSearchQueries.GET_CR_REPORT_DATA2)
				 .append(PLMSearchQueries.GET_CR_REPORT_DATA3)
				 .append(PLMSearchQueries.GET_CR_REPORT_DATA4)
				 .append(PLMSearchQueries.GET_CR_REPORT_DATA5)
				 .append(PLMSearchQueries.GET_CR_REPORT_DATA6);
				  routeFlg=true;
			   }
			  if(!PLMUtils.isEmptyList(crValuesList)){
				  sqlQuery.append(" WHERE ");
			      for(int i=0;i<crValuesList.size();i++){	
				      String[] crValueArr = crValuesList.get(i).split("~");
				      String crid=crValueArr[0];
				      String contract=PLMUtils.checkNullVal(crValueArr[1]);
				      sqlQuery.append(" (CR.ID ='"+crid+"'");
					  if(!PLMUtils.isEmpty(contract)){
						  sqlQuery.append(" AND H.CONTRACT ='"+contract+"'");
					  }
					  sqlQuery.append(") ");
					  sqlQuery.append("OR");
			      }
			  }
			 String strSqlQry1 = sqlQuery.substring(0, sqlQuery.length()-2);
			 sqlQuery = new StringBuffer(strSqlQry1);
			 String strSqlQry2 = appendWhereCRReport(reportData, sqlQuery, true, true);
		     sqlQuery = new StringBuffer(strSqlQry2)
		    .append(PLMSearchQueries.GET_CR_RPT_NO_CTRCT_DATA5);
		     LOG.info("Executing Volatile Query with Contract Number for CR Report Detail Query :: "+sqlQuery); 
		     getJdbcTemplate().execute(sqlQuery.toString());
		     LOG.info("Executing Finaly Query with Contract Number for CR Report Detail Query :: " +
		  		""+PLMSearchQueries.GET_CR_DETAIL_REPORT_DATA.replace(PLMConstants.CR_RPT_VT1,CR_RPT_VT1)); 
		     crDetailReportList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_CR_DETAIL_REPORT_DATA.replace(PLMConstants.CR_RPT_VT1,CR_RPT_VT1)
				  ,new CrDetailMapper());
	      }else {
			String CR_VT1 = PLMConstants.CR_VT1.concat(timeStamp);
			String CR_VT2 = PLMConstants.CR_VT2.concat(timeStamp);
			
			if(!reportData.isRouteTaskFlg()){
				 sqlQuery.append(PLMSearchQueries.GET_CR_RPT_NO_CTRCT_DATA1)
				 .append(PLMSearchQueries.GET_CR_RPT_NO_CTRCT_DATA3);
			}else{
				  sqlQuery.append(PLMSearchQueries.GET_CR_RPT_NO_CTRCT_DATA1)
				 .append(PLMSearchQueries.GET_CR_REPORT_DATA2)
				 .append(PLMSearchQueries.GET_CR_RPT_NO_CTRCT_DATA3)
				 .append(PLMSearchQueries.GET_CR_REPORT_DATA4);
				  routeFlg=true;
			 }
			 if(!PLMUtils.isEmptyList(crValuesList)){
				  sqlQuery.append(" WHERE ");
			      for(int i=0;i<crValuesList.size();i++){	
				      String[] crValueArr = crValuesList.get(i).split("~");
				      String crid=crValueArr[0];
				      String contract=PLMUtils.checkNullVal(crValueArr[1]);
				      sqlQuery.append(" (CR.ID ='"+crid+"'");
					  if(!PLMUtils.isEmpty(contract)){
						  sqlQuery.append(" AND CR.CONTRACT ='"+contract+"'");
					  }
					  sqlQuery.append(") ");
					  sqlQuery.append("OR");
			      }
		     }
			String strSqlQry1 = sqlQuery.substring(0, sqlQuery.length()-2);
			sqlQuery = new StringBuffer(strSqlQry1);
			String crWhrQry = appendWhereCRReport(reportData, sqlQuery, true, true);
			StringBuffer finalQuery = new StringBuffer(crWhrQry)
			.append(PLMSearchQueries.GET_CR_RPT_NO_CTRCT_DATA5);
			String finalQryCr = finalQuery.toString().replace(PLMConstants.CR_VT1,CR_VT1);
			LOG.info("\nExecuting getCRReportData VT1 Query :: \n" +finalQryCr);
			getJdbcTemplate().execute(finalQryCr);
			String crRptVt2Qry = PLMSearchQueries.GET_CR_RPT_VT2.replace(PLMConstants.CR_VT1,CR_VT1).replace(PLMConstants.CR_VT2,CR_VT2);
			LOG.info("\nExecuting getCRReportData VT2 Query :: \n" +crRptVt2Qry);
			getJdbcTemplate().execute(crRptVt2Qry);
			LOG.info("Executing Finaly Query with out Contract Number for CR Report Detail Query :: " +
				  	""+PLMSearchQueries.GET_CR_DETAIL_NO_CNT_REPORT.replace(PLMConstants.CR_VT1,CR_VT1).replace(PLMConstants.CR_VT2,CR_VT2));
			crDetailReportList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_CR_DETAIL_NO_CNT_REPORT
						  .replace(PLMConstants.CR_VT1,CR_VT1).replace(PLMConstants.CR_VT2,CR_VT2),new CrDetailMapper());
		     }
	     } catch(DataAccessException e){
		 LOG.info("Exception on getCRReportDetailsData"+e.getMessage());
		 PLMUtils.checkException(e.getMessage());
	   }
	 LOG.info("Existing getCRReportDetailsData() of DAO Impl"); 
		 return crDetailReportList;
	}
	/**
	 * Mapper for Getting CR Details
	 */
	private static final class CrDetailMapper implements ParameterizedRowMapper<PLMCRReportData>{
	//private class CrDetailMapper implements ParameterizedRowMapper<PLMCRReportData>{
		public PLMCRReportData mapRow(ResultSet rs, int rowCount)
					throws SQLException {
			PLMCRReportData tempData= new PLMCRReportData();
			tempData.setCoNameCst(PLMUtils.checkNullVal(rs.getString("CO_NAME")));
			tempData.setContract(PLMUtils.checkNullVal(rs.getString("CONTRACT")));
			tempData.setCostGrp(PLMUtils.checkNullVal(rs.getString("GE_COST_GRP")));
			tempData.setCoState(PLMUtils.checkNullVal(rs.getString("CO_STATE")));
			tempData.setCrId(rs.getString(PLMUtils.checkNullVal("CR_ID")));
			tempData.setCrNumber(PLMUtils.checkNullVal(rs.getString("CR_NUMBER")));
			tempData.setCrDesc(PLMUtils.checkNullVal(rs.getString("CR_DESCRIPTION")));
			tempData.setCrState(PLMUtils.checkNullVal(rs.getString("CR_STATE")));
			tempData.setLfName(PLMUtils.checkNullVal(rs.getString("LF_NAME")));
			tempData.setLfRev(PLMUtils.checkNullVal(rs.getString("LF_REV")));
			tempData.setLfType(PLMUtils.checkNullVal(rs.getString("LF_TYPE")));
			tempData.setTfMarketNm(PLMUtils.checkNullVal(rs.getString("TF_MARKETING_NAME")));
			tempData.setTfDesc(PLMUtils.checkNullVal(rs.getString("TF_DESCRIPTION")));
			tempData.setCycleTimeDwgs(PLMUtils.convertCostCycle(rs.getDouble("CYCLE_TIME_DRWNGS")));
			tempData.setEngHours(PLMUtils.convertCostCycle(rs.getDouble("ENG_HOURS")));
			tempData.setDrafHours(PLMUtils.convertCostCycle(rs.getDouble("DRAFTING_HOURS")));
			tempData.setMaterialLeadTm(PLMUtils.convertCostCycle(rs.getDouble("MATERIAL_LEAD_TIME")));
			tempData.setShipDirectCst(PLMUtils.convertCostCycle(rs.getDouble("GE_MATERIAL_SHIP_DIRECT_COST")));
			tempData.setRawInProcessCst(PLMUtils.convertCostCycle(rs.getDouble("GE_RAW_IN_PROCESS_COST")));
			tempData.setAppliedDirectLbr(PLMUtils.convertCostCycle(rs.getDouble("GE_APPLIED_DIRECT_LABOR")));
			tempData.setGeShopWrkLab(PLMUtils.convertCostCycle(rs.getDouble("GE_SHOP_WORKAND_LAB")));
			tempData.setPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
			tempData.setGeTransportCst(PLMUtils.convertCostCycle(rs.getDouble("GE_TRANSPORTATION_COST")));
			tempData.setGeFieldInstalCst(PLMUtils.convertCostCycle(rs.getDouble("FIELD_INSTLTN_COST")));
			tempData.setUnitMeasure(PLMUtils.checkNullVal(rs.getString("GE_UNITOF_MEASURE")));
			tempData.setProductConf(PLMUtils.checkNullVal(rs.getString("PRDT_CONFIG")));
			tempData.setGeMfgLbrHours(PLMUtils.convertCostCycle(rs.getDouble("GE_MFGG_LABOR_HOURS")));
			tempData.setEnginerDisposition(PLMUtils.checkNullVal(rs.getString("ENGRNG_DISPOSITION")));
			
			return tempData;
			
		}
	}
	
	
}
