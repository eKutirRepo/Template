/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCntrtSmryRptMB.java
 * @Creation date: 4-April-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */

package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.common.usermodel.Hyperlink;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFCreationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFHyperlink;
import org.apache.poi.xwpf.model.XWPFHeaderFooterPolicy;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.UnderlinePatterns;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRelation;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFStyles;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTColor;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTHMerge;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTHeight;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTHyperlink;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTP;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTR;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTRPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTShd;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTString;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTcPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTText;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTrPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTVerticalJc;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STMerge;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STShd;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STUnderline;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STVerticalJc;
import org.richfaces.component.html.HtmlDataTable;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMCntrtSmryRptData;
import com.geinfra.geaviation.pwi.data.PLMContractSmryData;
import com.geinfra.geaviation.pwi.service.PLMCntrtSmryRptServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMCntrtSmryRptMB {
	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMCntrtSmryRptMB.class);
	/**
	 * Holds the contractSumrReptService
	 */
	private PLMCntrtSmryRptServiceIfc contractSumrReptService = null;
	/**
	 * Holds the contractNum
	 */
	private String contractNum = "";
	/**
	 * Holds the hrdwarePrdctList1
	 */
	private List<PLMCntrtSmryRptData> hrdwarePrdctList1 = new ArrayList<PLMCntrtSmryRptData>();
	/**
	 * Holds the hrdwarePrdctList2
	 */
	private List<PLMCntrtSmryRptData> hrdwarePrdctList2 = new ArrayList<PLMCntrtSmryRptData>();
	/**
	 * Holds the combinedList
	 */
	private List<PLMCntrtSmryRptData> combinedList = new ArrayList<PLMCntrtSmryRptData>();
	/**
	 * Holds the subcomponentsList
	 */
	private List<String> subcomponentsList = new ArrayList<String>();
	/**
	 * Holds the subcomponentsList1
	 */
	private List<PLMCntrtSmryRptData> subcomponentsList1 = new ArrayList<PLMCntrtSmryRptData>();
	/**
	 * Holds the cntrctList
	 */
	private List<PLMCntrtSmryRptData> cntrctList = new ArrayList<PLMCntrtSmryRptData>();
	/**
	 * Holds the cstGrpList
	 */
	private List<String> cstGrpList = new ArrayList<String>();
	/**
	 * Holds the pcInfoList
	 */
	private List<PLMCntrtSmryRptData> pcInfoList = new ArrayList<PLMCntrtSmryRptData>();
	/**
	 * Holds the cstGrpListSI
	 */
	private List<SelectItem> cstGrpListSI = new ArrayList<SelectItem>();
	/**
	 * Holds the pcInfoListSI
	 */
	private List<SelectItem> pcInfoListSI = new ArrayList<SelectItem>();
	/**
	 * Holds the pcInfoListSI
	 */
	private String totalRecCountMsg;
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the pageNo
	 */
	private int pageNo = 1;
	/**
	 * Holds the commonMB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;
	/**
	 * Holds the checkBoxSel
	 */
	private boolean checkBoxSel = false;
	/**
	 * Holds the checkTopBoxSel
	 */
	private boolean checkTopBoxSel = true;
	/**
	 * Holds the conSummRepData
	 */
	private PLMCntrtSmryRptData conSummRepData;
	/**
	 * Holds the dataTable
	 */
	private HtmlDataTable dataTable = new HtmlDataTable();
	/**
	 * Holds the selComponentList
	 */
	private List<String> selComponentList = new ArrayList<String>();

	// List<String> tempList = new ArrayList<String>();
	/**
	 * Holds the hardwarePrdt
	 */
	private String hardwarePrdt;
	/**
	 * Holds the productConfg
	 */
	private String productConfg;
	/**
	 * Holds the rowKey
	 */
	private String rowKey;
	/**
	 * Holds the rowSubComp
	 */
	private String rowSubComp;
	/**
	 * Holds the finalDataMap
	 */
	private Map<String, List<String>> finalDataMap = new HashMap<String, List<String>>();

	// String tempHardwarePrdt;
	/**
	 * Holds the resourceBundle
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	// Map<String , PLMCntrtSmryRptData> tempMap = new HashMap<String ,
	// PLMCntrtSmryRptData>();
	/**
	 * Holds the topLvlHP
	 */
	String topLvlHP = "";
	/**
	 * Holds the alertMsg
	 */
	private String alertMsg;
	/**
	 * Holds the cgFlag
	 */
	private boolean cgFlag;
	/**
	 * Holds the pcFlag
	 */
	private boolean pcFlag;
	/**
	 * Holds the subCmpFlag
	 */
	private boolean subCmpFlag;
	/**
	 * Holds the cstGrpAllOpen
	 */
	private boolean cstGrpAllOpen;
	/**
	 * Holds the pcAllOpen
	 */
	private boolean pcAllOpen;
	/**
	 * Holds the cntrctSmryData
	 */
	PLMCntrtSmryRptData cntrctSmryData = new PLMCntrtSmryRptData();
	/**
	 * Holds the subCmpnt
	 */
	private String subCmpnt;
	/**
	 * Holds the selCstGrpList
	 */
	private List<String> selCstGrpList = new ArrayList<String>();
	/**
	 * Holds the selPcList
	 */
	private List<String> selPcList = new ArrayList<String>();
	/**
	 * Holds the tempcstGrpList
	 */
	List<String> tempcstGrpList = new ArrayList<String>();
	/**
	 * Holds the selSubComp
	 */
	private boolean selSubComp;
	private List<PLMContractSmryData> subcomponentsListInPage = new ArrayList<PLMContractSmryData>();
	private String level = "";
	private List<String> selectedPrdtType = new ArrayList<String>();
	private List<String> prdtTypeListCrs = new ArrayList<String>();
	private List<String> prdtTypeListClHb = new ArrayList<String>();
	/**
	 * Holds the notRequireFlg
	 */
	private boolean notRequireFlg=false;
	
	private String userEmail;
	private String userName;

	/**
	 * Holds the partTypeAllOpen
	 */
	private boolean partTypeAllOpen;

	/**
	 * Holds the disablePrdtType
	 */
	private boolean disablePrdtType;
	 /**
	   *  Holds the categoryFlag
	   */
	 private boolean categoryFlag;

	/**
	 * Background Process Thread
	 */
	private class DocGenerationThread implements Runnable {
		public DocGenerationThread() {
		}

		public void run() {
			List<PLMCntrtSmryRptData> pcInfoListOld = new ArrayList<PLMCntrtSmryRptData>(pcInfoList);
			List<String> hwList = new ArrayList<String>(finalDataMap.keySet());
			LOG.info("finalDataMap------------------>"+finalDataMap);
			if (!PLMUtils.isEmptyList(hwList)) {
				List<PLMCntrtSmryRptData> pcInfoListNew = new ArrayList<PLMCntrtSmryRptData>();
				 List<String> prdtTypeListCrsNew = new ArrayList<String>();
				 List<String> prdtTypeListClHbNew = new ArrayList<String>();
				 if (!PLMUtils.isEmptyList( prdtTypeListCrs)) {
					 for (String data : prdtTypeListCrs) {
							prdtTypeListCrsNew.add(data);
						}
				 }
				 if (!PLMUtils.isEmptyList( prdtTypeListClHb)) {
					 for (String data : prdtTypeListClHb) {
							prdtTypeListClHbNew.add(data);
						}
				 }
				 LOG.info("In DocGenerationThread prdtTypeListCrsNew  -------> " + prdtTypeListCrsNew);
				 LOG.info("In DocGenerationThread prdtTypeListClHbNew -------> " + prdtTypeListClHbNew);
				
				if (!PLMUtils.isEmptyList(pcInfoListOld)) {
					for (PLMCntrtSmryRptData data : pcInfoListOld) {
						LOG.info("In DocGenerationThread PC Name -------> " + data.getPrdtConfigNm() + "PC Desc ------>" + data.getPrdtConfigDesc());
						pcInfoListNew.add(data);
					}

				}

				boolean optSbTypFlg = notRequireFlg;
				String crsLvl = level;
				String contractLcl =contractNum;
				boolean partTypAllLcl = partTypeAllOpen;
				boolean categoryFlagLcl =categoryFlag;
				 List<String> selCstGrpListLcl =new ArrayList<String>();
				 if(cstGrpAllOpen==true){
					 for(SelectItem sel:cstGrpListSI){
						 selCstGrpListLcl.add(new String(sel.getLabel()));
					 }
				 }else{
					 selCstGrpListLcl =selCstGrpList;
				 }
				 
				 List<String> selPcListLcl =new ArrayList<String>();
				 if(pcAllOpen==true){
					 for(SelectItem sel:pcInfoListSI){
						 String str[]=new String(sel.getLabel()).split(PLMConstants.AS_TOKEN_SPACE);
						 selPcListLcl.add(str[0]);
					 }
				 }else{
					 selPcListLcl =selPcList;
				 }

				if (hwList.size() > 1) {
					List<String> hwList1 = new ArrayList<String>();

					for (int i = 0; i < hwList.size(); i++) {
						hwList1.add(hwList.get(i));
					}

					// List<String> subCompList = new ArrayList<String>();
					List<String> subCompList = finalDataMap.get(hwList.get(0));
					List<String> subCompList1 = new ArrayList<String>();

					for (int i = 0; i < subCompList.size(); i++) {
						subCompList1.add(subCompList.get(i));
					}
					
					LOG.info("Selected sub componenets in DocGenerationThread method --------------------> " + subCompList);
					generateDoc(hwList1, subCompList1, pcInfoListNew, prdtTypeListCrsNew, prdtTypeListClHbNew, optSbTypFlg,
							contractLcl, crsLvl,partTypAllLcl,categoryFlagLcl,selCstGrpListLcl,selPcListLcl);
					hwList1.clear();
					subCompList1.clear();
					pcInfoListNew.clear();
					prdtTypeListCrsNew.clear();
					prdtTypeListClHbNew.clear();
				} else {
					List<List<String>> valueList = new ArrayList<List<String>>(finalDataMap.values());
					List<String> hwList1 = new ArrayList<String>();

					for (int i = 0; i < hwList.size(); i++) {
						hwList1.add(hwList.get(i));
					}
					// List<String> subCompList = new ArrayList<String>();
					List<String> subCompList = valueList.get(0);
					List<String> subCompList1 = new ArrayList<String>();

					for (int i = 0; i < subCompList.size(); i++) {
						subCompList1.add(subCompList.get(i));
					}
					LOG.info("Selected sub componenets in DocGenerationThread method --------------------> " + subCompList);
					generateDoc(hwList1, subCompList1, pcInfoListNew, prdtTypeListCrsNew, prdtTypeListClHbNew, optSbTypFlg,
							contractLcl ,crsLvl,partTypAllLcl,categoryFlagLcl,selCstGrpListLcl,selPcListLcl);
					hwList1.clear();
					subCompList1.clear();
					pcInfoListNew.clear();
					prdtTypeListCrsNew.clear();
					prdtTypeListClHbNew.clear();
				}

			}
		}
	}

	/**
	 * This method is used for Generating Contract Summary Report
	 * @throws PWiException 
	 * 
	 * 
	 */

	public void generateContSmryRpt() throws PWiException {
		LOG.info("Levellllllllllllllllllllllll ---------------->" + level);
		LOG.info("not Required flag" + notRequireFlg);
		List<String> hwList = new ArrayList<String>(finalDataMap.keySet());
		LOG.info("finalDataMap in generateContSmryRpt >>>>>>>>>>>>>>>>>>>>"+finalDataMap);
		userName = UserInfoPortalUtil.getInstance().getUserName();
		userEmail = UserInfoPortalUtil.getInstance().getUserEmail();		
		
		if (!PLMUtils.isEmptyList(hwList) && subcomponentsList.size()!=0) {
			alertMsg = PLMConstants.CNTRCT_SMRY_RPT_MAIL_ALERT_MSG;
			taskExecutor.execute(new DocGenerationThread());
		} else if(PLMUtils.isEmptyList(hwList)){
			alertMsg = PLMConstants.CNTRCT_SMRY_RPT_SLECT_NONE_ALERT_MSG;
		} else if(subcomponentsList.size() == 0){
			alertMsg =  PLMConstants.CNTRCT_SMRY_SUB_COMP_UNCHK;
		}
	}

	/**
	 * This method is used for validating contract Report Summary
	 * 
	 * @return String
	 */
	String validationForCntrctSmryRpt(String contractNumLcl) {
		alertMsg = "";
		if (!PLMUtils.checkForSpecialChars(contractNumLcl)) {
			alertMsg = PLMConstants.PRJ_SMRY_WILD_CARD_TEST;
		} 
		else if (PLMUtils.isEmpty(contractNumLcl)) {
			alertMsg = PLMConstants.CNTRCT_SMRY_RPT_SEARCH_CRITERIA_EMPTY_CHK;
		}
		return alertMsg;
	}

	/**
	 * This method is used to load cost group information
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String cntrctSmryInfo() {
		subcomponentsList.clear();
		level = "";
		selectedPrdtType.clear();
		notRequireFlg=false;
		selCstGrpList.clear();
		String fwdFlag = "";
		alertMsg = "";
		cgFlag = false;
		pcFlag = false;
		subCmpFlag = false;
		cstGrpAllOpen = false;
		pcAllOpen = false;
		selSubComp = false;
 	    disablePrdtType=true;
		partTypeAllOpen = true;
		try {

			LOG.info("Entering cntrctSmryInfo method");
			LOG.info("contractNum---------->" + contractNum);

			alertMsg = validationForCntrctSmryRpt(contractNum);
			if (PLMUtils.isEmpty(alertMsg)) {
				cntrctList = contractSumrReptService.fetchCntrInfo(contractNum);
				if (PLMUtils.isEmptyList(cntrctList)) {
					alertMsg = PLMConstants.CNTRCT_SMRY_RPT_SEARCH_CRITERIA;
				} else {
					cstGrpList = new ArrayList<String>();
					pcInfoList = new ArrayList<PLMCntrtSmryRptData>();
					cstGrpList = contractSumrReptService.fetchCstGrpData();
					pcInfoList = contractSumrReptService.fetchPCInfo(contractNum);
					LOG.info("cstGrpList size --> " + cstGrpList.size());
					LOG.info("pcInfoList---> " + pcInfoList.size());
					cstGrpListSI = new ArrayList<SelectItem>();
					pcInfoListSI = new ArrayList<SelectItem>();
					for (int i = 0; i < cstGrpList.size(); i++) {
						cstGrpListSI.add(new SelectItem(cstGrpList.get(i), cstGrpList.get(i)));
					}
					/*
					 * for(int i=0;i<pcInfoList.size();i++){
					 * pcInfoListSI.add(new
					 * SelectItem(pcInfoList.get(i).getPrdtConfigNm(),
					 * pcInfoList
					 * .get(i).getPrdtConfigNm()+" "+pcInfoList.get(i).
					 * getPrdtConfigDesc())); }
					 */
					/*
					 * cstGrpAllOpen = true; pcAllOpen = true;
					 */
					subcomponentsListInPage = new ArrayList<PLMContractSmryData>();
					PLMContractSmryData tempData =new PLMContractSmryData();
			    	tempData.setSubComponent("Project Summary");
			    	tempData.setCheckBoxSel(false);
					subcomponentsListInPage.add(tempData);
					tempData =new PLMContractSmryData();
			    	tempData.setSubComponent("CLIN Data");
			    	tempData.setCheckBoxSel(false);
					subcomponentsListInPage.add(tempData);
					tempData =new PLMContractSmryData();
			    	tempData.setSubComponent("CRS Data");
			    	tempData.setCheckBoxSel(false);
					subcomponentsListInPage.add(tempData);
					tempData =new PLMContractSmryData();
			    	tempData.setSubComponent("PRS Data");
			    	tempData.setCheckBoxSel(false);
					subcomponentsListInPage.add(tempData);
					tempData =new PLMContractSmryData();
			    	tempData.setSubComponent("Configuration Features");
			    	tempData.setCheckBoxSel(false);
					subcomponentsListInPage.add(tempData);
					tempData =new PLMContractSmryData();
			    	tempData.setSubComponent("Logical Features (MLIs)");
			    	tempData.setCheckBoxSel(false);
					subcomponentsListInPage.add(tempData);
					tempData =new PLMContractSmryData();
			    	tempData.setSubComponent("Cost Objects Data");
			    	tempData.setCheckBoxSel(false);
					subcomponentsListInPage.add(tempData);
					
					cgFlag = true;
					pcFlag = true;
					subCmpFlag = true;
					// preparing Map
					/*
					 * for(PLMCntrtSmryRptData dataSum : pcInfoList) { String
					 * tempString = dataSum.getHwPrdctNm();
					 * finalDataMap.put(tempString, subcomponentsList); }
					 */
					LOG.info("finalDataMap.size()-------->" + finalDataMap.size());
					
					prdtTypeListCrs.add("Gas");
					prdtTypeListCrs.add("Gas - Options");
					prdtTypeListClHb.add("GT");
					prdtTypeListCrs.add("Steam");
					prdtTypeListCrs.add("Steam - Options");
					prdtTypeListClHb.add("ST");
					prdtTypeListCrs.add("Gen");
					prdtTypeListCrs.add("Gen - Options");
					prdtTypeListClHb.add("GTG");
					prdtTypeListClHb.add("STG");
					prdtTypeListCrs.add("PLANT");
					prdtTypeListClHb.add("Not Applicable");
					
					LOG.info("in prodtTypeListner method prdtTypeListCrs List >>>>>>>>>>>>  "+prdtTypeListCrs);
					LOG.info("in prodtTypeListner method prdtTypeListClHb List >>>>>>>>>>>>  "+prdtTypeListClHb);
					fwdFlag = "contractSummaryReport";
				}
			}

			/* subcomponentsList.add("Document Features"); */
			/* conSummRepData.setComponent(subcomponentsList); */
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@cntrctSmryInfo: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(), commonMB, "home", "Contract Summary Report");
		}
		LOG.info("Exiting cntrctSmryInfo method");
		return fwdFlag;
	}

	/**
	 * This method is used to reset Contract Summary Data
	 * 
	 * 
	 */
	public void resetContractSumryData() {
		selCstGrpList.clear();
		alertMsg = "";
		selPcList = new ArrayList<String>();
//		selCstGrpList = new ArrayList<String>();
		cstGrpAllOpen = false;
		pcAllOpen = false;
		selSubComp = false;
		cgFlag = false;
		pcFlag = false;
		subCmpFlag = false;
		checkBoxSel = false;
		checkTopBoxSel = true;
		finalDataMap = new HashMap<String, List<String>>();
		hrdwarePrdctList1 = new ArrayList<PLMCntrtSmryRptData>();
		hrdwarePrdctList2 = new ArrayList<PLMCntrtSmryRptData>();
		subcomponentsList1 = new ArrayList<PLMCntrtSmryRptData>();
		subcomponentsList = new ArrayList<String>();
		conSummRepData = new PLMCntrtSmryRptData();
		combinedList = new ArrayList<PLMCntrtSmryRptData>();
		contractNum = "";
		hardwarePrdt = "";
		rowSubComp = "";
		cstGrpList = new ArrayList<String>();
		pcInfoList = new ArrayList<PLMCntrtSmryRptData>();
		cstGrpListSI = new ArrayList<SelectItem>();
		pcInfoListSI = new ArrayList<SelectItem>();
		tempcstGrpList = new ArrayList<String>();
		subcomponentsListInPage = new ArrayList<PLMContractSmryData>();
		notRequireFlg=false;
		categoryFlag =false;
		level = "";
		selectedPrdtType.clear();
		prdtTypeListClHb.clear();
	}

	/**
	 * This method is used to get Contract Summary Report Home
	 * 
	 * @return String
	 * 
	 */
	public String getContractSummaryReportHome() {
		String fwdFlag = "contractSummaryReport";
		try {
			commonMB.insertCannedRptRecordHitInfo("Contract Summary Report (Email Report)");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		resetContractSumryData();
		return fwdFlag;
	}

	/**
	 * This method is used to get Cost Group List
	 * 
	 * @param ActionEvent
	 * 
	 */
	// This Action Listner method is to update Product Configuration(s) basedon
	// Cost Group(s) selection
	public void costGrpListener(ActionEvent ae) {
		LOG.info("Entering costGrpListener method" + selCstGrpList);

		try {
			//pcInfoList = new ArrayList<PLMCntrtSmryRptData>();
			pcInfoListSI = new ArrayList<SelectItem>();
			tempcstGrpList = new ArrayList<String>();
			selPcList.clear();
			if (pcAllOpen == true) {
				pcAllOpen = false;
			}
			if (!PLMUtils.isEmptyList(selCstGrpList)) {
				for (int k = 0; k < selCstGrpList.size(); k++) {
					String tempStr = selCstGrpList.get(k);
					if (!tempcstGrpList.contains(tempStr)) {
						tempcstGrpList.add(tempStr);
					}

				}
				//pcInfoList = contractSumrReptService.fetchPCInfo(contractNum, tempcstGrpList);
				if (!PLMUtils.isEmptyList(pcInfoList)) {
					for (int i = 0; i < pcInfoList.size(); i++) {
						for (String cstTmpGrp: tempcstGrpList) {
							if (cstTmpGrp.equalsIgnoreCase(pcInfoList.get(i).getPcCstGrp())) {
								pcInfoListSI.add(new SelectItem(pcInfoList.get(i).getPrdtConfigNm(), pcInfoList.get(i).getPrdtConfigNm() + " " + pcInfoList.get(i).getPrdtConfigDesc()));
							}
						}
					}
				}
				if (pcAllOpen == true) {
					// prparing map
					finalDataMap = new HashMap<String, List<String>>();
					if (selSubComp == true) {
						subcomponentsList = new ArrayList<String>();
						subcomponentsList.add("Project Summary");
						subcomponentsList.add("CLIN Data");
						subcomponentsList.add("CRS Data");
						subcomponentsList.add("PRS Data");
						subcomponentsList.add("Configuration Features");
						subcomponentsList.add("Logical Features (MLIs)");
						//subcomponentsList.add("Configuration End Items (MLIs)");
						subcomponentsList.add("Cost Objects Data");
					}
					for (PLMCntrtSmryRptData dataSum : pcInfoList) {
						String tempString = dataSum.getHwPrdctNm()+"~"+dataSum.getPrdtConfigNm();
						finalDataMap.put(tempString, subcomponentsList);
					}
				} else {
					finalDataMap = new HashMap<String, List<String>>();
				}
				LOG.info("Inside costGrpListener selPcList -------->" + selPcList);
				LOG.info("pcInfoList.size()-------->" + pcInfoList.size());
				LOG.info("finalDataMap.size()-------->" + finalDataMap.size());
				LOG.info("subcomponentsList.size()-------->" + subcomponentsList.size());
				LOG.info("subcomponents in Map-------->" + subcomponentsList);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method is used to get Product Configuration List
	 * 
	 * @param ActionEvent
	 * 
	 */
	public void prdCnfgListener(ActionEvent ae) {
		LOG.info("Entering prdCnfgListener method");
		String hwPrd = "";
		finalDataMap = new HashMap<String, List<String>>();
		//try {
			LOG.info("Inside prdCnfgListener selPcList -------->" + selPcList);
			if (!PLMUtils.isEmptyList(selPcList)) {
				// prparing map
				finalDataMap = new HashMap<String, List<String>>();
				/*
				 * for(PLMCntrtSmryRptData dataSum : pcInfoList) { String
				 * tempString = dataSum.getHwPrdctNm();
				 * finalDataMap.put(tempString, subcomponentsList); }
				 */
				if (selSubComp == true) {
					subcomponentsList = new ArrayList<String>();
					subcomponentsList.add("Project Summary");
					subcomponentsList.add("CLIN Data");
					subcomponentsList.add("CRS Data");
					subcomponentsList.add("PRS Data");
					subcomponentsList.add("Configuration Features");
					subcomponentsList.add("Logical Features (MLIs)");
					//subcomponentsList.add("Configuration End Items (MLIs)");
					subcomponentsList.add("Cost Objects Data");
				}
				for (String selPC : selPcList) {
					LOG.info("Selected Product Configuration Items-------->" + selPC);
					if (!PLMUtils.isEmptyList(pcInfoList)) {
						for (PLMCntrtSmryRptData data : pcInfoList) {
							if (data.getPrdtConfigNm().equals(selPC)) {
								hwPrd = data.getHwPrdctNm()+"~"+data.getPrdtConfigNm();
								finalDataMap.put(hwPrd, subcomponentsList);
								LOG.info("Selected HW Prdt for  Product Configuration Items-------->" + hwPrd);
								LOG.info("finalDataMap.size() in prdCnfgListener -------->" + finalDataMap.size());
								LOG.info("subcomponentsList.size()-------->" + subcomponentsList.size());
							}

						}
					}
				}
				LOG.info("subcomponents in Map-------->" + subcomponentsList);
				/*
				 * LOG.info("pcInfoList.size()-------->"+pcInfoList.size());
				 * LOG.info("finalDataMap.size()-------->"+finalDataMap.size());
				 */

			}
		/*} catch (Exception e) {
			e.printStackTrace();
		}*/
		
	}

	/**
	 * This method is used for to get sub Component List
	 * 
	 * @param ActionEvent
	 * 
	 */
	public void allSubCompListener(ActionEvent ae) {
		LOG.info("Entering allSubCompListener method");
		if (selSubComp == true) {
			LOG.info("Entering allSubCompListener method if condition"+selSubComp);
			subcomponentsList = new ArrayList<String>();
			subcomponentsList.add("Project Summary");
			subcomponentsList.add("CLIN Data");
			subcomponentsList.add("CRS Data");
			subcomponentsList.add("PRS Data");
			subcomponentsList.add("Configuration Features");
			subcomponentsList.add("Logical Features (MLIs)");
			//subcomponentsList.add("Configuration End Items (MLIs)");
			subcomponentsList.add("Cost Objects Data");
		} else {
			LOG.info("Entering allSubCompListener method else condition ");
			subcomponentsList = new ArrayList<String>();
		}
		LOG.info("Inside allSubCompListener --> After condition SET subcomponentsList ---------> "+subcomponentsList);
		LOG.info("Inside allSubCompListener --> After condition SET selPcList ---------> "+selPcList);
		LOG.info("Inside allSubCompListener --> After condition SET pcInfoList ---------> "+pcInfoList);
		//for (String selPc : selPcList) {

			for (PLMCntrtSmryRptData pcVal : pcInfoList) {

				//if (selPc.equalsIgnoreCase(pcVal.getPrdtConfigNm())) {
					String tempString = pcVal.getHwPrdctNm()+"~"+pcVal.getPrdtConfigNm();
					finalDataMap.put(tempString, subcomponentsList);
				//}
			}

		//}
		LOG.info("Inside allSubCompListener -->  selPcList---------> "+selPcList);
		LOG.info("In  allSubCompListener() method selected Subcomponents --->" + subcomponentsList);
		LOG.info("finalDataMap in allSubCompListener --->" + finalDataMap);
		LOG.info("finalDataMap size --->" + finalDataMap.size());
		LOG.info("subcomponentsList.size()----------> " + subcomponentsList.size());
		LOG.info("Exit form allSubCompListener method");
	}

	/**
	 * This method is used for to get product Configuration Check box
	 * 
	 * @param ActionEvent
	 * 
	 */
	public void prdCnfgChkBoxListener(ActionEvent ae) {
		LOG.info("Entering prdCnfgChkBoxListener method");
			if (pcAllOpen == true) {
				if (!PLMUtils.isEmptyList(pcInfoList)) {
					// prparing map
					finalDataMap = new HashMap<String, List<String>>();
					selPcList = new ArrayList<String>();
					for (int j = 0; j < pcInfoList.size(); j++) {
						selPcList.add(pcInfoList.get(j).getPrdtConfigNm());
					}
					for (PLMCntrtSmryRptData dataSum : pcInfoList) {
						String tempString = dataSum.getHwPrdctNm()+"~"+dataSum.getPrdtConfigNm();
						finalDataMap.put(tempString, subcomponentsList);
					}
				}
			} else {
				selPcList.clear();
				finalDataMap = new HashMap<String, List<String>>();
			}
			LOG.info("Inside prdCnfgChkBoxListener selPcList-------->" + selPcList);
			LOG.info("pcInfoList.size()-------->" + pcInfoList.size());
			LOG.info("finalDataMap.size()-------->" + finalDataMap.size());
			LOG.info("subcomponentsList.size()-------->" + subcomponentsList.size());
		
	}

	/**
	 * This method is used for to get sub Component List
	 * 
	 * @param ActionEvent
	 * 
	 */

	// This Action Listner method is to add or remove subcomponents dynamically
	// from UI
	public void subCompListener(ActionEvent ae) {
		LOG.info("Entering subCompListener method");
		Map<String, List<String>> tempDataMap = new HashMap<String, List<String>>();
		subCmpnt = (String) FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("rowSubCompName");
		LOG.info("subCmpnt in subCompListener--->" + subCmpnt);

			if(!subcomponentsList.contains(subCmpnt)){
				subcomponentsList.add(subCmpnt);
 				LOG.info("Added subcomponentsList in List --->"+subcomponentsList);
 		     }
 		  else{
	 		if(subcomponentsList.contains(subCmpnt)){
	 			subcomponentsList.remove(subCmpnt);
		 	LOG.info("Removed subcomponentsList from List  --->"+subcomponentsList);
	 		}	
 		  }
				LOG.info("Subcomponenet from List  --->" + subCmpnt);
				LOG.info("subcomponentsList size --->" + subcomponentsList.size());
				// preparing Map
				//for (String selPc : selPcList) {

					for (PLMCntrtSmryRptData pcVal : pcInfoList) {

						//if (selPc.equalsIgnoreCase(pcVal.getPrdtConfigNm())) {
							String tempString = pcVal.getHwPrdctNm()+"~"+pcVal.getPrdtConfigNm();
							tempDataMap.put(tempString, subcomponentsList);
						//}
					}

				//}
				LOG.info("finalDataMap size --->" + finalDataMap.size());

			finalDataMap = new HashMap<String, List<String>>(tempDataMap);
		LOG.info("finalDataMap size --->" + finalDataMap.size());
		LOG.info("Inside subCompListener selPcList-------->" + selPcList);
		LOG.info("finalDataMap in subCompListener method ----------------------->" + finalDataMap);
	}

	

	/**
	 * This method is used for selAllCstGrpListner
	 * 
	 * @param ActionEvent
	 * 
	 */
	public void selAllCstGrpListner(ActionEvent ae) {
		try {
			LOG.info("Entering into selAllCstGrpListner");
			if (pcAllOpen == true) {
				pcAllOpen = false;
			}
			if (cstGrpAllOpen == true) {
				//cstGrpList = new ArrayList<String>();
				//pcInfoList = new ArrayList<PLMCntrtSmryRptData>();
				selPcList.clear();
				//cstGrpList = contractSumrReptService.fetchCstGrpData();
				//pcInfoList = contractSumrReptService.fetchPCInfo(contractNum, cstGrpList);
				LOG.info("cstGrpListSI size --> " + cstGrpListSI.size());
				LOG.info("pcInfoList---> " + pcInfoList.size());
				//cstGrpListSI = new ArrayList<SelectItem>();
				pcInfoListSI = new ArrayList<SelectItem>();
				/*if (!PLMUtils.isEmptyList(cstGrpList)) {
					for (int i = 0; i < cstGrpList.size(); i++) {
						cstGrpListSI.add(new SelectItem(cstGrpList.get(i), cstGrpList.get(i)));
					}
				}*/
				if (!PLMUtils.isEmptyList(pcInfoList)) {
					for (int i = 0; i < pcInfoList.size(); i++) {
						pcInfoListSI.add(new SelectItem(pcInfoList.get(i).getPrdtConfigNm(), pcInfoList.get(i).getPrdtConfigNm() + " " + pcInfoList.get(i).getPrdtConfigDesc()));
					}
				}
			} else {
				pcInfoListSI.clear();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		LOG.info("selPcList-------->" + selPcList);
		LOG.info("Exiting from selAllCstGrpListner");
	}

	// Added By Raju to split string into parts to set width of table columns
	/**
	 * This method is used to split the string
	 * 
	 * @param String
	 * @return String
	 * 
	 */
	public String splitString(String str) {
		String combined = "";
		if (str != null) {
			if (!PLMUtils.isEmpty(str)) {
				if (str.length() < 20) {
					combined = str;
				} else if (str.length() > 20 && str.length() <= 40) {
					String part1 = str.substring(0, 19);
					String part2 = str.substring(19);
					combined = part1 + "\n" + part2;
				} else if (str.length() > 40 && str.length() <= 60) {
					String part1 = str.substring(0, 19);
					String part2 = str.substring(19, 39);
					String part3 = str.substring(39);
					combined = part1 + "\n" + part2 + "\n" + part3;
				} else if (str.length() > 60 && str.length() <= 80) {
					String part1 = str.substring(0, 19);
					String part2 = str.substring(19, 39);
					String part3 = str.substring(39, 59);
					String part4 = str.substring(59);
					combined = part1 + "\n" + part2 + "\n" + part3 + "\n" + part4;
				} else if (str.length() > 80 && str.length() <= 100) {
					String part1 = str.substring(0, 19);
					String part2 = str.substring(19, 39);
					String part3 = str.substring(39, 59);
					String part4 = str.substring(59, 79);
					String part5 = str.substring(79);
					combined = part1 + "\n" + part2 + "\n" + part3 + "\n" + part4 + "\n" + part5;
				} else if (str.length() > 100 && str.length() <= 120) {
					String part1 = str.substring(0, 19);
					String part2 = str.substring(19, 39);
					String part3 = str.substring(39, 59);
					String part4 = str.substring(59, 79);
					String part5 = str.substring(79, 99);
					String part6 = str.substring(99);
					combined = part1 + "\n" + part2 + "\n" + part3 + "\n" + part4 + "\n" + part5 + "\n" + part6;
				} else {
					combined = str;
				}
			}
		} else {
			combined = "";
		}
		return combined;

	}
	//Newly Added for 4.6 Release for width setting
	/**
	 * This method is used to split the character length for limited Range
	 * 
	 * @param String
	 * @return String
	 * 
	 */
	public String splitCharLengthData(String strVal,int limitRange){   
    int start = 0; 
    StringBuffer finalStrBfr = new StringBuffer();
    boolean endOfString = false; 
    if (!PLMUtils.isEmpty(strVal)) {
     char[] chars = strVal.toCharArray(); 
	    while(start <= chars.length-1) { 
	        int charCount = 0; 
	        int lastSpace = 0; 
	        while(charCount < limitRange) { 
	            if(chars[charCount+start] == ' ') { 
	                lastSpace = charCount; 
	            } 
	            charCount++; 
	            if(charCount+start == strVal.length()) { 
	                endOfString = true; 
	                break; 
	            } 
	        }  
	        int end = endOfString ? strVal.length() 
	                          : (lastSpace > 0) ? lastSpace+start : charCount+start; 
	        finalStrBfr.append("\n")
	        .append(strVal.substring(start, end).trim());
	        start = end; 
	   } 
    }else{
    	finalStrBfr.append("");
    }
    return finalStrBfr.toString();
    }
	/**
	 * This method is used to split the string
	 * 
	 * @param String
	 * @return String
	 * 
	 */
	public String splitStringForPRS(String str) {
		String combined = "";
		int iCtrPrs = 0;
		int jCtrPrs = 0;
		int kCtrPrs = 0;
		int lCtrPrs = 0;
		int mCtrPrs = 0;
		if (str != null) {
			if (!PLMUtils.isEmpty(str)) {
				if (str.length() < 20) {
					combined = str;
				} else if (str.length() > 20 && str.length() <= 40) {
					iCtrPrs=19;
					if(str.contains(" ")){
						while((str.charAt(iCtrPrs)) != ' ' && (iCtrPrs!=0)){
							if(str.charAt(iCtrPrs) == ' '){
								break;
							}
							--iCtrPrs;
						}
					}
					String part1 = str.substring(0, iCtrPrs);
					String part2 = str.substring(iCtrPrs);
					combined = part1 + "\n" + part2;
				} else if (str.length() > 40 && str.length() <= 60) {
					iCtrPrs=19;
					jCtrPrs=39;
					if(str.contains(" ")){
						while((str.charAt(iCtrPrs)) != ' ' && (iCtrPrs!=0)){
							if(str.charAt(iCtrPrs) == ' '){
								break;
							}
							--iCtrPrs;
						}
						while((str.charAt(jCtrPrs)) != ' '&& (jCtrPrs!=0)){
							if(str.charAt(jCtrPrs) == ' '){
								break;
							}
							--jCtrPrs;
						}
					}
					String part1 = str.substring(0, iCtrPrs);
					String part2 = str.substring(iCtrPrs, jCtrPrs);
					String part3 = str.substring(jCtrPrs);
					combined = part1 + "\n" + part2 + "\n" + part3;
				} else if (str.length() > 60 && str.length() <= 80) {
					iCtrPrs=19;
					jCtrPrs=39;
					kCtrPrs=59;
					if(str.contains(" ")){
						while((str.charAt(iCtrPrs)) != ' ' && (iCtrPrs!=0)){
							if(str.charAt(iCtrPrs) == ' '){
								break;
							}
							--iCtrPrs;
						}
						while((str.charAt(jCtrPrs)) != ' '&& (jCtrPrs!=0)){
							if(str.charAt(jCtrPrs) == ' '){
								break;
							}
							--jCtrPrs;
						}
						while((str.charAt(kCtrPrs)) != ' '&& (kCtrPrs!=0)){
							if(str.charAt(kCtrPrs) == ' '){
								break;
							}
							--kCtrPrs;
						}
					}
					String part1 = str.substring(0, iCtrPrs);
					String part2 = str.substring(iCtrPrs, jCtrPrs);
					String part3 = str.substring(jCtrPrs, kCtrPrs);
					String part4 = str.substring(kCtrPrs);
					combined = part1 + "\n" + part2 + "\n" + part3 + "\n" + part4;
				} else if (str.length() > 80 && str.length() <= 100) {
					iCtrPrs=19;
					jCtrPrs=39;
					kCtrPrs=59;
					lCtrPrs=79;
					if(str.contains(" ")){
						while((str.charAt(iCtrPrs)) != ' ' && (iCtrPrs!=0)){
							if(str.charAt(iCtrPrs) == ' '){
								break;
							}
							--iCtrPrs;
						}
						while((str.charAt(jCtrPrs)) != ' '&& (jCtrPrs!=0)){
							if(str.charAt(jCtrPrs) == ' '){
								break;
							}
							--jCtrPrs;
						}
						while((str.charAt(kCtrPrs)) != ' '&& (kCtrPrs!=0)){
							if(str.charAt(kCtrPrs) == ' '){
								break;
							}
							--kCtrPrs;
						}
						while((str.charAt(lCtrPrs)) != ' '&& (lCtrPrs!=0)){
							if(str.charAt(lCtrPrs) == ' '){
								break;
							}
							--lCtrPrs;
						}
					}
					String part1 = str.substring(0, iCtrPrs);
					String part2 = str.substring(iCtrPrs, jCtrPrs);
					String part3 = str.substring(jCtrPrs, kCtrPrs);
					String part4 = str.substring(kCtrPrs, lCtrPrs);
					String part5 = str.substring(lCtrPrs);
					combined = part1 + "\n" + part2 + "\n" + part3 + "\n" + part4 + "\n" + part5;
				} else if (str.length() > 100 && str.length() <= 120) {
					iCtrPrs=19;
					jCtrPrs=39;
					kCtrPrs=59;
					lCtrPrs=79;
					mCtrPrs=99;
					if(str.contains(" ")){
						while((str.charAt(iCtrPrs)) != ' ' && (iCtrPrs!=0)){
							if(str.charAt(iCtrPrs) == ' '){
								break;
							}
							--iCtrPrs;
						}
						while((str.charAt(jCtrPrs)) != ' '&& (jCtrPrs!=0)){
							if(str.charAt(jCtrPrs) == ' '){
								break;
							}
							--jCtrPrs;
						}
						while((str.charAt(kCtrPrs)) != ' '&& (kCtrPrs!=0)){
							if(str.charAt(kCtrPrs) == ' '){
								break;
							}
							--kCtrPrs;
						}
						while((str.charAt(lCtrPrs)) != ' '&& (lCtrPrs!=0)){
							if(str.charAt(lCtrPrs) == ' '){
								break;
							}
							--lCtrPrs;
						}
						while((str.charAt(mCtrPrs)) != ' '&& (mCtrPrs!=0)){
							if(str.charAt(mCtrPrs) == ' '){
								break;
							}
							--mCtrPrs;
						}
					}
					String part1 = str.substring(0, iCtrPrs);
					String part2 = str.substring(iCtrPrs, jCtrPrs);
					String part3 = str.substring(jCtrPrs, kCtrPrs);
					String part4 = str.substring(kCtrPrs, lCtrPrs);
					String part5 = str.substring(lCtrPrs, mCtrPrs);
					String part6 = str.substring(mCtrPrs);
					combined = part1 + "\n" + part2 + "\n" + part3 + "\n" + part4 + "\n" + part5 + "\n" + part6;
				} else {
					combined = str;
				}
			}
		} else {
			combined = "";
		}
		return combined;
	}
	
	// End

	/**
	 * This method is used to generate Document
	 * 
	 * @param hardwareLsit
	 * @param subCompList
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * 
	 */
	public void generateDoc(List<String> hwList, List<String> subCompList, List<PLMCntrtSmryRptData> pcInfoListOld, 
			List<String> prdtTypeListCrsNew, List<String> prdtTypeListClHbNew, boolean optSbTFlg, String contractNumRpt,
			String crsLvlVal,boolean partTypeAll,boolean categryFlag,List<String> selCstGrpListLcl,List<String> selPcListLcl) {

		boolean optSbTypFlg = optSbTFlg;
		String contractVal = contractNumRpt;
		String crsLvlLcl = crsLvlVal;
		boolean partTypeAllLcl=partTypeAll;
		boolean categryFlgLcl =categryFlag;
		List<String> selCstGrpListLocal= selCstGrpListLcl;
		List<String> selPcListLocal =selPcListLcl;
		List<PLMCntrtSmryRptData> pcInfoListNew = new ArrayList<PLMCntrtSmryRptData>();
		for (PLMCntrtSmryRptData data : pcInfoListOld) {
			LOG.info("In generateDoc PC Name -------> " + data.getPrdtConfigNm() + "PC Desc ------>" + data.getPrdtConfigDesc());
			pcInfoListNew.add(data);
		}

		List<String> hwList1 = new ArrayList<String>();
		for (int i = 0; i < hwList.size(); i++) {
			hwList1.add(hwList.get(i));
		}

		List<String> subCompList1 = new ArrayList<String>();
		for (int i = 0; i < subCompList.size(); i++) {
			subCompList1.add(subCompList.get(i));
		}

		String filePathDocx = "";
		String tempPathDocx = "";
		String cntrtSmryTempPath = "";
		FileOutputStream fos = null;
		try {
			final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
			Date uniqDate = new Date();
			String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
			String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
			filePathDocx = fileDir + resourceBundle.getString("CONTRACT_SMRY_REPORT_NAME") + contractVal + "_" + uniqTime + ".docx";
			tempPathDocx = fileDir + resourceBundle.getString("CONTRACT_SMRY_REPORT_TEMPLATE_NAME");
			cntrtSmryTempPath = fileDir + resourceBundle.getString("CONTRACT_SMRY_REPORT_TEMPLATE");
			LOG.info("filePathDocx--------->" + filePathDocx);
			fos = new FileOutputStream(new File(filePathDocx));
			saveContractSmryRprtDocxFile(fos, contractVal, filePathDocx, tempPathDocx, cntrtSmryTempPath, 
					hwList1, subCompList1, pcInfoListNew, prdtTypeListCrsNew, prdtTypeListClHbNew, optSbTypFlg, 
					crsLvlLcl,partTypeAllLcl,categryFlgLcl,selCstGrpListLocal,selPcListLocal);
		} catch (Exception e) {
			deleteFiles(filePathDocx);
			e.printStackTrace();
		} finally {
			pcInfoListNew.clear();
			hwList1.clear();
			subCompList1.clear();
			try {
				if (fos!=null){
					fos.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

	/**
	 * This method is used to save Contract Summary Report Document
	 * 
	 * @param FileOutputStream
	 * @param contractNum
	 * @param filePathDocx
	 * @param templatePath
	 * @param cntrtSmryTempPath
	 * @param hwList
	 * @param subCompList
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * 
	 */
	public void saveContractSmryRprtDocxFile(FileOutputStream fos, String contractNumRpt, String filePathDocx, 
			String templatePath, String cntrtSmryTempPath, List<String> hwList, List<String> subCompList, 
			List<PLMCntrtSmryRptData> pcInfoListOld, List<String> prdtTypeListCrsNew, 
			List<String> prdtTypeListClHbNew, boolean optSbTFlg, String crsLvlVal,
			boolean partTypeAll,boolean categryFlg,List<String> selCstGrpListLcl,List<String> selPcListLcl) throws Exception {
		boolean optSbTypFlg = optSbTFlg; 
		String contractNumInSaverpt = contractNumRpt;
		String crsLvlLcl = crsLvlVal;
		boolean partTypAllLcl=partTypeAll;
		boolean categryFlgLcl =categryFlg;
		List<String> selCstGrpListLocal =selCstGrpListLcl;
		List<String> selPcListLocal =selPcListLcl;
		LOG.info("contractNum in ---> saveContractSmryRprtDocxFile " + contractNumInSaverpt);
		List<PLMCntrtSmryRptData> pcInfoListNew = new ArrayList<PLMCntrtSmryRptData>();
		for (PLMCntrtSmryRptData data : pcInfoListOld) {
			LOG.info("In saveContractSmryRprtDocxFile PC Name -------> " + data.getPrdtConfigNm() + "PC Desc ------>" + data.getPrdtConfigDesc());
			pcInfoListNew.add(data);
		}

		List<String> hwList1 = new ArrayList<String>();
		for (int i = 0; i < hwList.size(); i++) {
			hwList1.add(hwList.get(i));
			LOG.info("Hardware product values in saveContractSmryRprtDocxFile method before queries execution **************" + hwList.get(i));
		}
		LOG.info("subCompList>>>>>>>>>>>>>>>>>>>"+subCompList);
		List<String> subCompList1 = new ArrayList<String>();
		for (int i = 0; i < subCompList.size(); i++) {
			subCompList1.add(subCompList.get(i));
			LOG.info("Subcomponent values in saveContractSmryRprtDocxFile method before queries execution ****************" + subCompList.get(i));
		}

		String from = PLMConstants.COST_CHG_MAIL_FROM;
	
		String to = userEmail;		
		LOG.info("userEmail >>>>>>>>>>>>>>>>>>>>"+to);
		String toAddressee = userName;
		LOG.info("userName >>>>>>>>>>>>>>>>>>>>"+toAddressee);
		
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.CNTRT_SMRY_RPT_MAIL_SUBJECT + contractNumInSaverpt;
		StringBuffer mailBody = new StringBuffer().append(toAddressee);
		StringBuffer mailNoDataBody = new StringBuffer();
		File file = null;
		String pcName = "";
		String pcDesc = "";
		String isOption = "";
		String str = "";
		String pcNameKey="";
		String hardwareKey="";
		try {

			LOG.info("contractNum>>>>>>>" + contractNumInSaverpt);
			if (contractNumInSaverpt != null) {
				/* toAddressee = "Dear " + toAddressee + ", \n\n"; */
				mailBody.append(PLMConstants.CNTRT_SMRY_RPT_MAIL_CONTENT).append(contractNumInSaverpt).append(".").append(PLMConstants.COST_CHG_MAIL_SIGNATURE).append(PLMConstants.COST_CHG_MAIL_FOOTER);

				mailNoDataBody.append(toAddressee).append(PLMConstants.COST_CHNG_NO_CONTENT_BODY).append(contractNumInSaverpt).append(".").append(PLMConstants.COST_CHG_MAIL_SIGNATURE).append(PLMConstants.COST_CHG_MAIL_FOOTER);

				
				LOG.info("Creating  New document");
				createDocument(filePathDocx, templatePath, cntrtSmryTempPath, contractNumInSaverpt); // 1
				LOG.info("End");

				for (int i = 0; i < hwList1.size(); i++) {
					LOG.info("Hardware product values in saveContractSmryRprtDocxFile method after queries execution **************" + hwList1.get(i));
				}
				
				for (int i = 0; i < subCompList1.size(); i++) {
					LOG.info("Subcomponent values in saveContractSmryRprtDocxFile method after queries execution **************" + subCompList.get(i));
				}
				for (int j = 0; j < subCompList1.size(); j++) {
					if (subCompList1.get(j).equalsIgnoreCase("Project Summary")) {
						//List<PLMCntrtSmryRptData> prjNameList = new ArrayList<PLMCntrtSmryRptData>();
						List<PLMCntrtSmryRptData> prjNameList = contractSumrReptService.fetchProjectNameList(contractNumInSaverpt);
						
						if (!PLMUtils.isEmptyList(prjNameList)) {
							LOG.info("prjNameList Size in saveContractSmryRprtDocxFile --------->" + prjNameList.size());
							for (int i = 0; i < prjNameList.size(); i++) {
								LOG.info("prjNameList values---------->" + prjNameList.get(i));
							}
							LOG.info("Creating  createProjectNameTable");
							createProjectNameTable(filePathDocx, prjNameList, templatePath); // 1
							LOG.info("End");
	
							Map<String, List<PLMCntrtSmryRptData>> nameRoleMap = new HashMap<String, List<PLMCntrtSmryRptData>>();
							//List<PLMCntrtSmryRptData> nrList = new ArrayList<PLMCntrtSmryRptData>();
							// List<PLMCntrtSmryRptData> tempNRList = new
							// ArrayList<PLMCntrtSmryRptData>();
							for (int a = 0; a < prjNameList.size(); a++) {
								List<PLMCntrtSmryRptData> nrList = contractSumrReptService.fetchEmpNamesNRoles(contractNumInSaverpt, prjNameList.get(a).getProjectName());
								if (!PLMUtils.isEmptyList(nrList)) {
									nameRoleMap.put(prjNameList.get(a).getProjectName(), nrList);
								}
							}
							if(!PLMUtils.isEmptyMap(nameRoleMap)) {
								LOG.info("nameRoleMap Size in saveContractSmryRprtDocxFile --------->" + nameRoleMap.size());
								LOG.info("Creating createEmpNameandRoleTable");
								createEmpNameandRoleTable(filePathDocx, nameRoleMap, templatePath); // 2
								LOG.info("End");
							}
						}
						//List<PLMCntrtSmryRptData> hardwareBuildDataList = new ArrayList<PLMCntrtSmryRptData>();
						List<PLMCntrtSmryRptData> hardwareBuildDataList = contractSumrReptService.fetchHardwareBuildInfo(contractNumInSaverpt, prdtTypeListClHbNew,partTypAllLcl);
						if (!PLMUtils.isEmptyList(hardwareBuildDataList)) {
							LOG.info("hardwareBuildDataList size -------> " + hardwareBuildDataList.size());
							LOG.info("hardwareBuildDataList Data -------> " + hardwareBuildDataList.toString());
							LOG.info("Creating createHrdwreBuildTable");
							createHrdwreBuildTable(filePathDocx, hardwareBuildDataList, templatePath); // 8
							LOG.info("End");
						}
						//List<PLMCntrtSmryRptData> PLPList = new ArrayList<PLMCntrtSmryRptData>();
						List<PLMCntrtSmryRptData> PLPList = contractSumrReptService.fetchPLPList(contractNumInSaverpt);
						if (!PLMUtils.isEmptyList(PLPList)) {
							LOG.info("PLPList size -------> " + PLPList.size());
							LOG.info("PLPList Data -------> " + PLPList.toString());
							LOG.info("Creating createPLPTable");
							createPLPTable(filePathDocx, PLPList, templatePath); // 9
							LOG.info("End");
						}
					}

					if (subCompList1.get(j).equalsIgnoreCase("CLIN Data")) {

						//List<PLMCntrtSmryRptData> clinDataList = new ArrayList<PLMCntrtSmryRptData>();
						List<PLMCntrtSmryRptData> clinDataList = contractSumrReptService.fetchClinInfo(contractNumInSaverpt,prdtTypeListClHbNew,partTypAllLcl);
						if (!PLMUtils.isEmptyList(clinDataList)) {
							LOG.info("clinDataList size -------> " + clinDataList.size());
							// LOG.info("clinDataList Data -------> "+clinDataList.toString());
							LOG.info("Creating createClinDataTable");
							createClinDataTable(filePathDocx, clinDataList, templatePath); // 3
							clinDataList.clear();
							LOG.info("End");
							LOG.info("End");
						}

					}
					if (subCompList1.get(j).equalsIgnoreCase("CRS Data")) {

						/*List<PLMCntrtSmryRptData> crsDataList = new ArrayList<PLMCntrtSmryRptData>();
						crsDataList = contractSumrReptService.fetchCRSInfo(contractNum);
						LOG.info("crsDataList size -------> " + crsDataList.size());
						LOG.info("crsDataList Data -------> " + crsDataList.toString());
						LOG.info("Creating createCRSTable");
						createCRSTable(filePathDocx, crsDataList, templatePath);
						LOG.info("End");*/
						
						Map<String, List<PLMCntrtSmryRptData>> crsMap = new HashMap<String, List<PLMCntrtSmryRptData>>();
						//List<PLMCntrtSmryRptData> crsList = new ArrayList<PLMCntrtSmryRptData>();
						List<PLMCntrtSmryRptData> crsList = contractSumrReptService.fetchCRSInfo(contractNumInSaverpt);
						if (!PLMUtils.isEmptyList(crsList)) {
							for (int a = 0; a < crsList.size(); a++) {
								//List<PLMCntrtSmryRptData> crsRecList = new ArrayList<PLMCntrtSmryRptData>();
								List<PLMCntrtSmryRptData> crsRecList = contractSumrReptService.fetchCRSRecursiveData(contractNumInSaverpt, crsList.get(a).getCrsName(), crsLvlLcl, prdtTypeListCrsNew,partTypAllLcl);
								if (!PLMUtils.isEmptyList(crsRecList)) {
									LOG.info("crsRecList.size() in MB ------------->   " + crsRecList.size());
									crsMap.put(crsList.get(a).getCrsName(), crsRecList);
								}
							}
							LOG.info("crsMap.size()------------->" + crsMap.size());
						}
						List<String> crsKeyList = new ArrayList<String>(crsMap.keySet());
						//List<PLMCntrtSmryRptData> cList = new ArrayList<PLMCntrtSmryRptData>();
						for (int i = 0; i < crsKeyList.size(); i++) {
							List<PLMCntrtSmryRptData> cList = crsMap.get(crsKeyList.get(i));
							LOG.info("creating createCRSRecursiveTable");
							createCRSRecursiveTable(filePathDocx, cList, templatePath, crsKeyList.get(i));// 7
							LOG.info("created createCRSRecursiveTable");
							LOG.info("cList.size()-------------->" + cList.size());
							cList.clear();
						}
						crsKeyList.clear();
					}
					if (subCompList1.get(j).equalsIgnoreCase("PRS Data")) {

						/*List<PLMCntrtSmryRptData> prdtRqmntSpecList1 = new ArrayList<PLMCntrtSmryRptData>();
						prdtRqmntSpecList1 = contractSumrReptService.fetchPrdtRqmntSpecInfo(contractNum);
						LOG.info("prdtRqmntSpecList1 size -------> " + prdtRqmntSpecList1.size());
						// LOG.info("prdtRqmntSpecList1 Data -------> "+prdtRqmntSpecList1.toString());
						LOG.info("Creating createPRSTable");
						createPRSTable(filePathDocx, prdtRqmntSpecList1, templatePath); // 4
						LOG.info("End");*/
						
						Map<String, List<PLMCntrtSmryRptData>> prsMap = new HashMap<String, List<PLMCntrtSmryRptData>>();
						//List<PLMCntrtSmryRptData> prdtRqmntSpecList = new ArrayList<PLMCntrtSmryRptData>();
						List<PLMCntrtSmryRptData> prdtRqmntSpecList = contractSumrReptService.fetchPrdtRqmntSpecInfo(contractNumInSaverpt);
						if (!PLMUtils.isEmptyList(prdtRqmntSpecList)) {
							for (int a = 0; a < prdtRqmntSpecList.size(); a++) {
								//List<PLMCntrtSmryRptData> prsRecList = new ArrayList<PLMCntrtSmryRptData>();
								List<PLMCntrtSmryRptData> prsRecList = contractSumrReptService.fetchPRSRecursiveData(prdtRqmntSpecList.get(a).getPrdtRqmntSpecNm());
								if (!PLMUtils.isEmptyList(prsRecList)) {
									LOG.info("prsRecList.size() in MB ------------->   " + prsRecList.size());
									prsMap.put(prdtRqmntSpecList.get(a).getPrdtRqmntSpecNm(), prsRecList);
								}
							}
							LOG.info("prsMap.size()------------->" + prsMap.size());
						}

						List<String> prsKeys = new ArrayList<String>(prsMap.keySet());
						//List<PLMCntrtSmryRptData> list = new ArrayList<PLMCntrtSmryRptData>();
						for (int i = 0; i < prsKeys.size(); i++) {
							List<PLMCntrtSmryRptData> list = prsMap.get(prsKeys.get(i));
							LOG.info("creating createPRSRecursiveTable" + prsKeys.get(i));
							createPRSRecursiveTable(filePathDocx, prsKeys.get(i), list, templatePath); // 5
							LOG.info("created createPRSRecursiveTable");
							LOG.info("list.size()-------------->" + list.size());
						}
						prsKeys.clear();

					}

				}
				
				for (int k = 0; k < subCompList1.size(); k++) {
					if (subCompList1.get(k).equalsIgnoreCase("Configuration Features") && isCategoryFlag()) {
						 boolean noSubTypeFlag=false;
							//adding pcNames based on Cost Groups
						 List<String> pcNmList = new ArrayList<String>();
						 Map<String, List<String>> finalCostMap = new HashMap<String, List<String>>();
						 for(int i=0;i<selCstGrpListLocal.size();i++){
							for (PLMCntrtSmryRptData pcNms : pcInfoListNew) {
								if(pcNms.getPcCstGrp().equalsIgnoreCase(selCstGrpListLocal.get(i))){
									for(String selPc :selPcListLocal){
										if(selPc.equalsIgnoreCase(pcNms.getPrdtConfigNm())){
									     pcNmList.add(pcNms.getPrdtConfigNm());
										}
									}
								}
							}
							finalCostMap.put(selCstGrpListLocal.get(i), pcNmList);
							pcNmList = new ArrayList<String>();
						}

						 String costGroup ="";
						 List<String> pcNameList = new ArrayList<String>();
						 for(int i=0;i<selCstGrpListLocal.size();i++){
								if(finalCostMap.containsKey(selCstGrpListLocal.get(i))){
								costGroup=selCstGrpListLocal.get(i);
								pcNameList=finalCostMap.get(selCstGrpListLocal.get(i));
								LOG.info("costGrpkey.getKey() >>>>>>>>>>>>>>"+costGroup);
								LOG.info("costGrpkey.getValue() >>>>>>>>>>>>>>"+pcNameList);
								if(!PLMUtils.isEmptyList(pcNameList)){
									List<PLMCntrtSmryRptData> tempData = contractSumrReptService.fetchConfFeaturesCostGrpData(contractNumInSaverpt,pcNameList,optSbTypFlg,noSubTypeFlag,categryFlgLcl); 
									createCostGrpConfigFeaturesTab(filePathDocx, tempData, costGroup,pcNameList, pcDesc, str, templatePath);
									tempData.clear();
								}
						}
					}
				 }
			   }
				
				
				List<PLMCntrtSmryRptData> pcInfoListSel = new ArrayList<PLMCntrtSmryRptData>();
				
				for(int i=0;i<selCstGrpListLocal.size();i++){
					for (PLMCntrtSmryRptData pcNms : pcInfoListNew) {
						if(pcNms.getPcCstGrp().equalsIgnoreCase(selCstGrpListLocal.get(i))){
							for(String selPc:selPcListLocal){
								if(selPc.equalsIgnoreCase(pcNms.getPrdtConfigNm())){
								 pcInfoListSel.add(pcNms);
								}
							}
						}
					}
				}
				
				for (int i = 0; i < hwList1.size(); i++) {
					String[] harWareKeyList = hwList1.get(i).split("~");
					hardwareKey=harWareKeyList[0];
					pcNameKey=harWareKeyList[1];
					if (!PLMUtils.isEmptyList(pcInfoListSel)) {
						for (PLMCntrtSmryRptData data : pcInfoListSel) {
							//LOG.info("At End of saveContractSmryRprtDocxFile PC Name -------> " + data.getPrdtConfigNm() + "PC Desc ------>" + data.getPrdtConfigDesc());
							 if (data.getHwPrdctNm().equals(hardwareKey) && data.getPrdtConfigNm().equals(pcNameKey)) {
								pcName = data.getPrdtConfigNm();
								pcDesc = data.getPrdtConfigDesc();
								isOption = data.getIsOption();
								
								if ("Yes".equalsIgnoreCase(isOption)) {
									str = " (OPTIONS PC)";
								} else {
									str = "";
								}
		//					}
		//				}
	//				}

					for (int j = 0; j < subCompList1.size(); j++) {
						//List<PLMCntrtSmryRptData> tempData = new ArrayList<PLMCntrtSmryRptData>();
						if (subCompList1.get(j).equalsIgnoreCase("Product Configuration")) {
							List<PLMCntrtSmryRptData> tempData = contractSumrReptService.fetchProductConfigData(hardwareKey);
							createProductConfigTable(filePathDocx, tempData, pcName, pcDesc, templatePath);
							tempData.clear();
						}
						if (subCompList1.get(j).equalsIgnoreCase("Configuration Features") && !isCategoryFlag()) {
							 boolean noSubTypeFlag=false;
							 List<PLMCntrtSmryRptData> tempData = contractSumrReptService.fetchConfFeaturesPCNmData(contractNumInSaverpt,pcName,optSbTypFlg,noSubTypeFlag,categryFlgLcl); 
							 createConfigurationFeaturesTable(filePathDocx, tempData, pcName, pcDesc, str, templatePath);
							 tempData.clear();
						}
						if (subCompList1.get(j).contains("Logical Features (MLI")) {
							//List<PLMCntrtSmryRptData> crsList = new ArrayList<PLMCntrtSmryRptData>();
							List<PLMCntrtSmryRptData> crsList = contractSumrReptService.fetchCRSInfo(contractNumInSaverpt);
							List<String> crsRecList = new ArrayList<String>();
							if(!PLMUtils.isEmptyList(crsList)) {
								 for (int a = 0; a < crsList.size(); a++) {
									 crsRecList.add(crsList.get(a).getCrsName());
							 	 }
							}
							List<PLMCntrtSmryRptData> tempData = contractSumrReptService.fetcLogicalFeauturesData(hardwareKey, contractNumInSaverpt,crsRecList);
							createLogicalFeaturesTable(filePathDocx, tempData, pcName, pcDesc, str, templatePath);
							tempData.clear();
							
						}
						if (subCompList1.get(j).contains("Configuration End Items (MLI")) {
							//List<PLMCntrtSmryRptData> crsList = new ArrayList<PLMCntrtSmryRptData>();
							List<PLMCntrtSmryRptData> crsList = contractSumrReptService.fetchCRSInfo(contractNumInSaverpt);
							List<String> crsRecList = new ArrayList<String>();
							if(!PLMUtils.isEmptyList(crsList)) {
								for (int a = 0; a < crsList.size(); a++) {
									crsRecList.add(crsList.get(a).getCrsName());
								}
							}
							List<PLMCntrtSmryRptData> tempData = contractSumrReptService.fetcConfigEndItemsData(hardwareKey, contractNumInSaverpt,crsRecList);
							createConfigurationeEndItemsTable(filePathDocx, tempData, pcName, pcDesc, str, templatePath);
							tempData.clear();
							
						}/*
						 * elseif(tempSubCompList.get(j).equalsIgnoreCase(
						 * "Customer Requirements")){ tempData =
						 * contractSumrReptService
						 * .fetchCustReqData(fianlDataMapKeyList.get(i));
						 * createCustomerRequirementsTable(fos, filePathDocx,
						 * tempData,pcName,pcDesc,templatePath); }
						 */
						if (subCompList1.get(j).equalsIgnoreCase("Cost Objects Data")) {
							List<PLMCntrtSmryRptData> tempData = contractSumrReptService.fetCostObjectsData(crsLvlLcl, prdtTypeListCrsNew,partTypAllLcl,contractNumInSaverpt,pcName);
							createcCostObjectsTable(filePathDocx, tempData, pcName, pcDesc, str, templatePath);
							tempData.clear();
						}/*
						 * elseif(tempSubCompList.get(j).equalsIgnoreCase(
						 * "Top Level BOM Part")){ tempData =
						 * contractSumrReptService
						 * .fetchTpLvlBomPrtData(fianlDataMapKeyList.get(i));
						 * createTpLvlBomPrtTable(fos, filePathDocx,
						 * tempData,pcName,pcDesc,templatePath); }
						 */
						//tempData.clear();
					}// for
				}
			}
		}

				}// for
				file = new File(filePathDocx);
				LOG.info("document has been generated with name : " + filePathDocx);

		/*		prdtRqmntSpecList.clear();
				prsMap.clear();
				crsList.clear();
				crsMap.clear();*/
				/*
				 * prjNameList.clear(); nrList.clear(); nameRoleMap.clear();
				 * hardwareBuildDataList.clear();
				 */

				//PLPList.clear();
			} /*else {
				LOG.info("Not able to generate the report. The Contract Number selected is " + contractNumInSaverpt);
			}*/
			long sizeInBytes = 0;
			if (file != null) {
				sizeInBytes = file.length();
			}
			if (sizeInBytes > 0) {
				LOG.info("File Size for Contract Summary Report " + sizeInBytes / 1000 + "KB");
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathDocx);
				LOG.info("Report Attachment Mail sent successfully.");
			} else {
				PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
				LOG.info("No data Mail sent successfully.");
			}

		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@saveContractSmryRprtDocxFile: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(), from, to, subject, toAddressee, PLMConstants.LTTR_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@saveContractSmryRprtDocxFile: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(), from, to, subject, toAddressee, PLMConstants.LTTR_MAIL_SIGNATURE);
		} finally {
			if (fos != null) {
				fos.close();
			}
			deleteFiles(filePathDocx);
			/*if (file != null) {
				file.delete();
			}*/
			pcInfoListNew.clear();
			hwList1.clear();
			subCompList1.clear();
		}
	}

	/**
	 * This method is used for Deleting docx file
	 * 
	 * @param String
	 */
	public void deleteFiles(String docx) {
		LOG.info("Entering deleteFiles method");
		boolean docxFileExist;
		File docxFile = new File(docx);
		docxFileExist = docxFile.exists();
		if (docxFileExist) {
			boolean deleted = docxFile.delete();
			LOG.info("Successfully deleted docx file : " + deleted);
		}
		LOG.info("Exiting deleteFiles Method");
	}

	/*
	 * public void saveContractSmryRprtDocxFile(List<PLMCntrtSmryRptData>
	 * hrdwarePrdctList2) throws Exception{ List<PLMCntrtSmryRptData> tempData =
	 * new ArrayList<PLMCntrtSmryRptData>(); for(int
	 * i=0;i<hrdwarePrdctList2.size();i++){ tempData =
	 * contractSumrReptService.fetchProductConfigData
	 * (hrdwarePrdctList2.get(i).getHardwareProduct());
	 * LOG.info("tempData size -------------->"+tempData.size());
	 * tempData.clear(); tempData =
	 * contractSumrReptService.fetchConfigFeauturesData
	 * (hrdwarePrdctList2.get(i).getHardwareProduct());
	 * LOG.info("tempData size -------------->"+tempData.size());
	 * tempData.clear(); tempData =
	 * contractSumrReptService.fetcLogicalFeauturesData
	 * (hrdwarePrdctList2.get(i).getHardwareProduct());
	 * LOG.info("tempData size -------------->"+tempData.size());
	 * tempData.clear(); tempData =
	 * contractSumrReptService.fetcConfigEndItemsData
	 * (hrdwarePrdctList2.get(i).getHardwareProduct());
	 * LOG.info("tempData size -------------->"+tempData.size());
	 * tempData.clear(); tempData =
	 * contractSumrReptService.fetchCustReqData(hrdwarePrdctList2
	 * .get(i).getHardwareProduct());
	 * LOG.info("tempData size -------------->"+tempData.size());
	 * tempData.clear(); tempData =
	 * contractSumrReptService.fetCostObjectsData(hrdwarePrdctList2
	 * .get(i).getHardwareProduct());
	 * LOG.info("tempData size -------------->"+tempData.size());
	 * tempData.clear(); } }
	 */

	/**
	 * This method is used to createPRSRecursiveTable
	 * 
	 * @param FileOutputStream
	 * @param prsName
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * @param templatePath
	 */
	public void createPRSRecursiveTable(String filePathDocx, String prsName, List<PLMCntrtSmryRptData> prsRecDataListOld, String templatePath) throws Exception {
		// open an existing empty document with styles already defined
		List<PLMCntrtSmryRptData> prsRecDataListNew = new ArrayList<PLMCntrtSmryRptData>();
		for (PLMCntrtSmryRptData data : prsRecDataListOld) {
			prsRecDataListNew.add(data);
		}

		LOG.info("Opening existing document -------> " + filePathDocx);

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3
		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setStyle("Heading2"); // 4
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.setColor("000000");
		tmpRun.setText("Product Requirement Spec Data - " + prsName);
		tmpRun.setBold(true);
		// tmpRun.setUnderline(UnderlinePatterns.THICK);
		tmpRun.setFontFamily("Geinspira");
		// tmpRun.setFontSize(10);
		// tmpRun.addBreak();
		// XWPFDocument doc = new XWPFDocument();

		int nRows = prsRecDataListNew.size() + 1;
		int nCols = 8;
		int index = 0;
		XWPFTable table = doc.createTable(nRows, nCols);
		// table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));

		// Set the table style. If the style is not defined, the table style
		// will become "Normal".
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("Normal");

		// Get a list of the rows in the table
		List<XWPFTableRow> rows = table.getRows();
		//int[] cols = { 20, 1000, 1000, 1000, 1000, 200, 2000 };
		int rowCt = 0;
		int colCt = 0;
		for (int i = 0; i < rows.size(); i++) {
			XWPFTableRow row = table.getRow(i);
			// get table row properties (trPr)
			CTTrPr trPr = row.getCtRow().addNewTrPr();
			// set row height; units = twentieth of a point, 360 = 0.25"
			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(10));

			// get the cells in this row
			List<XWPFTableCell> cells = row.getTableCells();
			// add content to each cell
			for (int j = 0; j < cells.size(); j++) {
				XWPFTableCell cell = row.getCell(j);
				// get a table cell properties element (tcPr)
				CTTcPr tcpr = cell.getCTTc().addNewTcPr();
				// set vertical alignment to "center"
				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				// create cell color element
				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {
					// header row
					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {
					// odd row
					ctshd.setFill("EDF2F8");
				}

				// get 1st paragraph in cell's paragraph list
				XWPFParagraph para = cell.getParagraphs().get(0);
				// create a run to contain the content
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");
				// style cell as desired
				/*
				 * if (colCt == nCols - 1) { // last column is 10pt Courier //
				 * rh.setFontSize(10); // rh.setFontFamily("Courier"); }
				 */
				if (rowCt == 0) {
					if (colCt == 0) {
						// header row
						rh.setText("Level");
					} else if (colCt == 1) {
						rh.setText("Name");
					} else if (colCt == 2) {
						rh.setText("Title");
					} else if (colCt == 3) {
						rh.setText("Description");
					} else if (colCt == 4) {
						rh.setText("Data Value");
					} else if (colCt == 5) {
						rh.setText("Unit of Measure (A)");
					} else if (colCt == 6) {
						rh.setText("Unit of Measure (B)");
					} else if (colCt == 7) {
						rh.setText("Requirement Notes");
					}/*
					 * else if(colCt == 7){ rh.setText("INDICATR"); }else
					 * if(colCt == 8){ rh.setText("UOM"); }else if(colCt == 9){
					 * rh.setText("REQUIREMENT_VALUE"); }else if(colCt == 10){
					 * rh.setText("PRS Flag"); }else if(colCt == 11){
					 * rh.setText("Path Flag"); }
					 */
					// rh.setFontSize(10);
					rh.setBold(true);
					para.setAlignment(ParagraphAlignment.CENTER);
				} else if (rowCt % 2 == 0) {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(prsRecDataListNew.get(index).getPrsLevel());
					} else if (colCt == 1) {
						if(prsRecDataListNew.get(index).isPrsReqFlag()){
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(4000));
							appendExternalHyperlink(resourceBundle.getString("PRS_REQ_HyperLink1")+ prsRecDataListNew.get(index).getChildName().toUpperCase(Locale.getDefault())
									+resourceBundle.getString("PRS_REQ_HyperLink2")+prsRecDataListNew.get(index).getPrsChildId()
									+resourceBundle.getString("PRS_REQ_HyperLink3")+prsRecDataListNew.get(index).getPrsChildId(),
									prsRecDataListNew.get(index).getChildName(),para);
						}else if(prsRecDataListNew.get(index).isPrsChapterFlg()){
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(4000));
							appendExternalHyperlink(resourceBundle.getString("Chapter_HyperLink1")+prsRecDataListNew.get(index).getPrsChildId()
									+resourceBundle.getString("Chapter_HyperLink2"),
									prsRecDataListNew.get(index).getChildName(),para);
						}else{
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(4000));
							appendExternalHyperlink(resourceBundle.getString("PRS_TOPLVL_HyperLink1")+prsRecDataListNew.get(index).getPrsChildId()
									+resourceBundle.getString("PRS_TOPLVL_HyperLink2"),
									prsRecDataListNew.get(index).getChildName(),para);
						}
					} else if (colCt == 2) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(splitCharLengthData(prsRecDataListNew.get(index).getChildTitle(),10));
						rh.setBold(true);
					}else if (colCt == 3) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(splitCharLengthData(prsRecDataListNew.get(index).getChildDesc(),10));
					} else if (colCt == 4) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(splitCharLengthData(prsRecDataListNew.get(index).getReqmtValue(),10));
					} else if (colCt == 5) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(splitCharLengthData(prsRecDataListNew.get(index).getUom(),10));
					} else if (colCt == 6) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(splitCharLengthData(prsRecDataListNew.get(index).getIndicator(),10));
					} else if (colCt == 7) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(splitCharLengthData(prsRecDataListNew.get(index).getPrsReqNotes(),40));
					}/*
					 * else if(colCt == 7){
					 * rh.setText(prsRecDataListNew.get(index).getIndicator());
					 * }else if(colCt == 8){
					 * rh.setText(prsRecDataListNew.get(index).getUom()); }else
					 * if(colCt == 9){
					 * rh.setText(prsRecDataListNew.get(index).getReqmtValue());
					 * }else if(colCt == 10){
					 * rh.setText(prsRecDataListNew.get(index).getPrsFlag());
					 * }else if(colCt == 11){
					 * rh.setText(prsRecDataListNew.get(index).getPathFlag()); }
					 */
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > prsRecDataListNew.size()) {
					break;
				} else {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(prsRecDataListNew.get(index).getPrsLevel());
					} else if (colCt == 1) {
						if(prsRecDataListNew.get(index).isPrsReqFlag()){
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(4000));
							appendExternalHyperlink(resourceBundle.getString("PRS_REQ_HyperLink1")+ prsRecDataListNew.get(index).getChildName().toUpperCase(Locale.getDefault())
									+resourceBundle.getString("PRS_REQ_HyperLink2")+prsRecDataListNew.get(index).getPrsChildId()
									+resourceBundle.getString("PRS_REQ_HyperLink3")+prsRecDataListNew.get(index).getPrsChildId(),
									prsRecDataListNew.get(index).getChildName(),para);
						}else if(prsRecDataListNew.get(index).isPrsChapterFlg()){
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(4000));
							appendExternalHyperlink(resourceBundle.getString("Chapter_HyperLink1")+prsRecDataListNew.get(index).getPrsChildId()
									+resourceBundle.getString("Chapter_HyperLink2"),
									prsRecDataListNew.get(index).getChildName(),para);
						}else{
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(4000));
							appendExternalHyperlink(resourceBundle.getString("PRS_TOPLVL_HyperLink1")+prsRecDataListNew.get(index).getPrsChildId()
									+resourceBundle.getString("PRS_TOPLVL_HyperLink2"),
									prsRecDataListNew.get(index).getChildName(),para);
						}
					} else if (colCt == 2) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(splitCharLengthData(prsRecDataListNew.get(index).getChildTitle(),10));
						rh.setBold(true);
					} else if (colCt == 3) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(splitCharLengthData(prsRecDataListNew.get(index).getChildDesc(),10));
					} else if (colCt == 4) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(splitCharLengthData(prsRecDataListNew.get(index).getReqmtValue(),10));
					} else if (colCt == 5) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(splitCharLengthData(prsRecDataListNew.get(index).getUom(),10));
					} else if (colCt == 6) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(splitCharLengthData(prsRecDataListNew.get(index).getIndicator(),10));
					} else if (colCt == 7) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(splitCharLengthData(prsRecDataListNew.get(index).getPrsReqNotes(),40));
					}/*
					 * else if(colCt == 7){
					 * rh.setText(prsRecDataListNew.get(index).getIndicator());
					 * }else if(colCt == 8){
					 * rh.setText(prsRecDataListNew.get(index).getUom()); }else
					 * if(colCt == 9){
					 * rh.setText(prsRecDataListNew.get(index).getReqmtValue());
					 * }else if(colCt == 10){
					 * rh.setText(prsRecDataListNew.get(index).getPrsFlag());
					 * }else if(colCt == 11){
					 * rh.setText(prsRecDataListNew.get(index).getPathFlag()); }
					 */
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell

			// odd row
			// rh.setText(clinDataListNew.get(rowCt).getEmpRole());
			// para.setAlignment(ParagraphAlignment.LEFT);

			colCt = 0;
			rowCt++;
		} // for row

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	/**
	 * This method is used to createCRSRecursiveTable
	 * 
	 * @param FileOutputStream
	 * @param filepathDocx
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * @param templatePath
	 */
	public void createCRSRecursiveTable(String filePathDocx, List<PLMCntrtSmryRptData> crsRecDataListOld, String templatePath, String crsName) throws Exception {
		// open an existing empty document with styles already defined

		LOG.info("Opening existing document -------> " + filePathDocx);

		List<PLMCntrtSmryRptData> crsRecDataListNew = new ArrayList<PLMCntrtSmryRptData>();
		for (PLMCntrtSmryRptData data : crsRecDataListOld) {
			crsRecDataListNew.add(data);
		}

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3
		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setStyle("Heading2"); // 4
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.setColor("000000");
		tmpRun.setText("Special Requirements � CRS Data -" + crsName);
		tmpRun.setBold(true);
		// tmpRun.setUnderline(UnderlinePatterns.THICK);
		tmpRun.setFontFamily("Geinspira");
		// tmpRun.setFontSize(10);
		// tmpRun.addBreak();
		// XWPFDocument doc = new XWPFDocument();

		int nRows = crsRecDataListNew.size() + 1;
		//int[] cols = { 20, 1500, 2000, 6000, 50 };
		int nCols = 6;
		int index = 0;
		XWPFTable table = doc.createTable(nRows, nCols);
		// table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));

		// Set the table style. If the style is not defined, the table style
		// will become "Normal".
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("Normal");

		// Get a list of the rows in the table
		List<XWPFTableRow> rows = table.getRows();
		int rowCt = 0;
		int colCt = 0;
		for (int i = 0; i < rows.size(); i++) {
			XWPFTableRow row = table.getRow(i);
			// get table row properties (trPr)
			CTTrPr trPr = row.getCtRow().addNewTrPr();
			// set row height; units = twentieth of a point, 360 = 0.25"
			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(10));

			// get the cells in this row
			List<XWPFTableCell> cells = row.getTableCells();
			// add content to each cell
			for (int j = 0; j < cells.size(); j++) {
				XWPFTableCell cell = row.getCell(j);
				// get a table cell properties element (tcPr)
				CTTcPr tcpr = cell.getCTTc().addNewTcPr();
				// tcpr.addNewTcW().setW(BigInteger.valueOf(2000));
				// set vertical alignment to "center"
				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				// create cell color element
				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {
					// header row
					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {
					// odd row
					ctshd.setFill("EDF2F8");
				}

				// get 1st paragraph in cell's paragraph list
				XWPFParagraph para = cell.getParagraphs().get(0);
				// create a run to contain the content
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");
				// style cell as desired
				/*
				 * if (colCt == nCols - 1) { // last column is 10pt Courier //
				 * rh.setFontSize(10); // rh.setFontFamily("Courier"); }
				 */
				if (rowCt == 0) {
					if (colCt == 0) {
						// header row
						rh.setText("Level");
					} else if (colCt == 1) {
						rh.setText("Name");
					} else if (colCt == 2) {
						rh.setText("Title");
					} else if (colCt == 3) {
						rh.setText("Affected MLI's");
					} else if (colCt == 4) {
						rh.setText("State");
					}else if (colCt == 5) {
						rh.setText("Product Type");
					}
					// rh.setFontSize(10);
					rh.setBold(true);
					para.setAlignment(ParagraphAlignment.CENTER);
				} else if (rowCt % 2 == 0) {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(crsRecDataListNew.get(index).getCrsrLevel());
					} else if (colCt == 1) {
						if(crsRecDataListNew.get(index).isCrsChapterFlg()){
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
							appendExternalHyperlink(resourceBundle.getString("Chapter_HyperLink1")+ crsRecDataListNew.get(index).getCrsrId()
									+resourceBundle.getString("Chapter_HyperLink2"),
									crsRecDataListNew.get(index).getCrsrName(),para);
						}else if(crsRecDataListNew.get(index).isTopCrsLvlFlag()){
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
							appendExternalHyperlink(resourceBundle.getString("CRS_TOPLVL_HyperLink1")+crsRecDataListNew.get(index).getCrsrId()
									+resourceBundle.getString("CRS_TOPLVL_HyperLink2"),
									crsRecDataListNew.get(index).getCrsrName(),para);
						}else{
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
							// rh.setText(crsRecDataListNew.get(index).getCrsrName());
							appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + crsRecDataListNew.get(index).getCrsrId(), 
									crsRecDataListNew.get(index).getCrsrName(), para);
						}
						
				    } else if (colCt == 2) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(splitCharLengthData(crsRecDataListNew.get(index).getCrsrTitle(),40));
					} else if (colCt == 3) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(splitCharLengthData(crsRecDataListNew.get(index).getCrsrRevision(),10));
					} else if (colCt == 4) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(crsRecDataListNew.get(index).getCrsrtoType());
					}else if (colCt == 5) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(crsRecDataListNew.get(index).getPcCstGrp());
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > crsRecDataListNew.size()) {
					break;
				} else {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(crsRecDataListNew.get(index).getCrsrLevel());
					} else if (colCt == 1) {
						if(crsRecDataListNew.get(index).isCrsChapterFlg()){
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
							appendExternalHyperlink(resourceBundle.getString("Chapter_HyperLink1")+ crsRecDataListNew.get(index).getCrsrId()
									+resourceBundle.getString("Chapter_HyperLink2"),
									crsRecDataListNew.get(index).getCrsrName(),para);
						}else if(crsRecDataListNew.get(index).isTopCrsLvlFlag()){
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
							appendExternalHyperlink(resourceBundle.getString("CRS_TOPLVL_HyperLink1")+crsRecDataListNew.get(index).getCrsrId()
									+resourceBundle.getString("CRS_TOPLVL_HyperLink2"),
									crsRecDataListNew.get(index).getCrsrName(),para);
						}else{
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
							// rh.setText(crsRecDataListNew.get(index).getCrsrName());
							appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + crsRecDataListNew.get(index).getCrsrId(), 
									crsRecDataListNew.get(index).getCrsrName(), para);
						}
					} else if (colCt == 2) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(splitCharLengthData(crsRecDataListNew.get(index).getCrsrTitle(),40));
					} else if (colCt == 3) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(splitCharLengthData(crsRecDataListNew.get(index).getCrsrRevision(),10));
					} else if (colCt == 4) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(crsRecDataListNew.get(index).getCrsrtoType());
					}else if (colCt == 5) {
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						rh.setText(crsRecDataListNew.get(index).getPcCstGrp());
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell

			// odd row
			// rh.setText(clinDataListNew.get(rowCt).getEmpRole());
			// para.setAlignment(ParagraphAlignment.LEFT);

			colCt = 0;
			rowCt++;
		} // for row

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	/**
	 * This method is used to createProjectNameTable
	 * 
	 * @param FileOutputStream
	 * @param filepathDocx
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * @param templatePath
	 * @param cntrtSmryTempPath
	 */
	public void createDocument(String filePathDocx, String templatePath, String cntrtSmryTempPath, String contractNumRpt) throws Exception {
		LOG.info("Creating New document document -------> " + filePathDocx);
		LOG.info("templatePath------------->" + templatePath);
		String contractNumInSaverpt = contractNumRpt;
 		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFDocument doc = new XWPFDocument(new FileInputStream(new File(cntrtSmryTempPath)));
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3

		XWPFParagraph titlePara = doc.createParagraph();
		titlePara.setStyle("Heading1"); // 4
		titlePara.setAlignment(ParagraphAlignment.CENTER);
		XWPFRun title = titlePara.createRun();
		title.setColor("000000");
		title.setText("Contract Summary Report");
		title.addBreak();

		XWPFParagraph tmpParagraph1 = doc.createParagraph();
		tmpParagraph1.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun boldRun = tmpParagraph1.createRun();
		boldRun.setBold(true);
		boldRun.setFontSize(10);
		XWPFRun unboldRun = tmpParagraph1.createRun();
		unboldRun.setFontSize(10);
		XWPFParagraph tmpParagraph2 = doc.createParagraph();
		tmpParagraph2.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun boldRun1 = tmpParagraph2.createRun();
		boldRun1.setBold(true);
		boldRun1.setFontSize(10);
		XWPFRun unboldRun1 = tmpParagraph2.createRun();
		unboldRun1.setFontSize(10);

		boldRun.setText("Contract Name: ");
		unboldRun.setText(contractNumInSaverpt);
		if (null != cntrctList && cntrctList.size() > 0) {
			boldRun1.setText("Contract Description: ");
			unboldRun1.setText(cntrctList.get(0).getCntrtDesc());
		} else {
			unboldRun1.setText("Contract Description: ");
		}
		
		/*fos = new FileOutputStream(new File(filePathDocx));
		doc.write(fos);
		fos.close();*/

		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}

	}

	public void createProjectNameTable(String filePathDocx, List<PLMCntrtSmryRptData> prjNameListOld, String templatePath) throws Exception {
		// open an existing empty document with styles already defined
		/* LOG.info("Creating New document document -------> "+filePathDocx); */
		// XWPFDocument doc = new XWPFDocument(new
		// FileInputStream(filePathDocx));
		// FileInputStream fileIn=null;
		List<PLMCntrtSmryRptData> prjNameListNew = new ArrayList<PLMCntrtSmryRptData>();

		for (PLMCntrtSmryRptData data : prjNameListOld) {
			prjNameListNew.add(data);
		}

		/*
		 * LOG.info("templatePath------------->"+templatePath); XWPFDocument
		 * template = new XWPFDocument(new FileInputStream(new
		 * File(templatePath))); //1 XWPFDocument doc = new XWPFDocument(new
		 * FileInputStream(new File(cntrtSmryTempPath))); XWPFStyles headStyle =
		 * doc.createStyles(); //2 headStyle.setStyles(template.getStyle()); //3
		 * 
		 * XWPFParagraph titlePara = doc.createParagraph();
		 * titlePara.setStyle("Heading1"); //4
		 * titlePara.setAlignment(ParagraphAlignment.CENTER); XWPFRun title =
		 * titlePara.createRun(); title.setColor("000000");
		 * title.setText("Contract Summary Report"); title.addBreak();
		 */
		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath)));
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3
		XWPFParagraph tmpParagraph1 = doc.createParagraph();
		tmpParagraph1.setAlignment(ParagraphAlignment.LEFT);
		/*XWPFRun boldRun = tmpParagraph1.createRun();
		boldRun.setBold(true);
		boldRun.setFontSize(10);
		XWPFRun unboldRun = tmpParagraph1.createRun();
		unboldRun.setFontSize(10);
		XWPFParagraph tmpParagraph2 = doc.createParagraph();
		tmpParagraph2.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun boldRun1 = tmpParagraph2.createRun();
		boldRun1.setBold(true);
		boldRun1.setFontSize(10);
		XWPFRun unboldRun1 = tmpParagraph2.createRun();
		unboldRun1.setFontSize(10);

		boldRun.setText("Contract Name: ");
		unboldRun.setText(contractNum);
		if (null != cntrctList && cntrctList.size() > 0) {
			boldRun1.setText("Contract Description: ");
			unboldRun1.setText(cntrctList.get(0).getCntrtDesc());
		} else {
			unboldRun1.setText("Contract Description: ");
		}*/

		XWPFParagraph brkPara = doc.createParagraph();
		brkPara.setAlignment(ParagraphAlignment.CENTER);
		XWPFRun brkRun = tmpParagraph1.createRun();
		brkRun.addBreak();

		// title.setUnderline(UnderlinePatterns.THICK); //5
		// title.setFontSize(10);
		// title.addBreak(); //6

		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setStyle("Heading2");
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.setColor("000000");
		tmpRun.setText("Projects");
		tmpRun.setBold(true);
		// tmpRun.setUnderline(UnderlinePatterns.THICK);
		// tmpRun.setFontSize(10);
		tmpRun.addBreak();
		XWPFParagraph itopara = doc.createParagraph();
		itopara.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun itoRun = tmpParagraph.createRun();
		itoRun.setColor("000000");
		itoRun.setFontSize(10);
		itoRun.setBold(true);
		XWPFParagraph tmpPar = doc.createParagraph();
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun tmpRun1 = tmpPar.createRun();
		tmpRun1.setColor("000000");
		tmpRun1.setFontSize(10);

		PLMCntrtSmryRptData itoPrj = new PLMCntrtSmryRptData();
		PLMCntrtSmryRptData otrPrj = new PLMCntrtSmryRptData();
		for (int i = 0; i < prjNameListNew.size(); i++) {
			if (prjNameListNew.get(i).getProjectName().contains("ITO")) {
				itoPrj = prjNameListNew.get(i);
			} else {
				otrPrj = prjNameListNew.get(i);
			}
		}

		itoRun.setText("ITO Project Name : ");
		itoRun.setText(itoPrj.getProjectName() + "          ");
		itoRun.setText("ITO Project Title : ");
		itoRun.setText(itoPrj.getProjectTitle() + "        ");
		itoRun.addBreak();
		itoRun.setText("OTR Project Name : ");
		itoRun.setText(otrPrj.getProjectName() + "                ");
		itoRun.setText("OTR Project Title : ");
		itoRun.setText(otrPrj.getProjectTitle() + "        ");
		// tmpRun1.setBold(true);

		// setting Footer start
		SimpleDateFormat dtfrmt = new SimpleDateFormat("MM/dd/yyyy hh:mm aa");
		Date uniqDate = new Date();
		String cDate = dtfrmt.format(uniqDate);
		System.out.println(cDate);
		String text = "Contract Summary Report as on: " + cDate;
		XWPFHeaderFooterPolicy policy = doc.getHeaderFooterPolicy();
		if (policy == null) {
			policy = new XWPFHeaderFooterPolicy(doc);
		}
		CTP ctP1 = CTP.Factory.newInstance();
		CTR ctR1 = ctP1.addNewR();
		CTText crsTxt = ctR1.addNewT();
		crsTxt.setStringValue(text);
		XWPFParagraph codePara = new XWPFParagraph(ctP1, doc);

		XWPFParagraph[] newparagraphs = new XWPFParagraph[1];
		newparagraphs[0] = codePara;
		policy.createFooter(XWPFHeaderFooterPolicy.DEFAULT, newparagraphs);
		// End footer

		/*
		 * int nRows = prjNameList.size()+1; int nCols = 1; int index = 0;
		 * XWPFTable table = doc.createTable(nRows, nCols);
		 * table.getCTTbl().addNewTblPr
		 * ().addNewTblW().setW(BigInteger.valueOf(10000));
		 * 
		 * // Set the table style. If the style is not defined, the table style
		 * // will become "Normal". CTTblPr tblPr = table.getCTTbl().getTblPr();
		 * CTString styleStr = tblPr.addNewTblStyle();
		 * styleStr.setVal("Normal");
		 * 
		 * // Get a list of the rows in the table List<XWPFTableRow> rows =
		 * table.getRows(); int rowCt = 0; int colCt = 0; for (XWPFTableRow row
		 * : rows) { // get table row properties (trPr) CTTrPr trPr =
		 * row.getCtRow().addNewTrPr(); // set row height; units = twentieth of
		 * a point, 360 = 0.25" CTHeight ht = trPr.addNewTrHeight();
		 * ht.setVal(BigInteger.valueOf(10));
		 * 
		 * // get the cells in this row List<XWPFTableCell> cells =
		 * row.getTableCells(); // add content to each cell for (XWPFTableCell
		 * cell : cells) { // get a table cell properties element (tcPr) CTTcPr
		 * tcpr = cell.getCTTc().addNewTcPr(); // set vertical alignment to
		 * "center" CTVerticalJc va = tcpr.addNewVAlign();
		 * va.setVal(STVerticalJc.CENTER);
		 * 
		 * // create cell color element CTShd ctshd = tcpr.addNewShd();
		 * ctshd.setColor("auto"); ctshd.setVal(STShd.CLEAR); if (rowCt == 0) {
		 * // header row ctshd.setFill("A7BFDE"); } else if (rowCt % 2 == 0) {
		 * 
		 * ctshd.setFill("D3DFEE"); } else { // odd row ctshd.setFill("EDF2F8");
		 * }
		 * 
		 * // get 1st paragraph in cell's paragraph list XWPFParagraph para =
		 * cell.getParagraphs().get(0); // create a run to contain the content
		 * XWPFRun rh = para.createRun(); rh.setFontSize(8);
		 * rh.setFontFamily("Geinspira"); // style cell as desired if (colCt ==
		 * nCols - 1) { // last column is 10pt Courier /*rh.setFontSize(8);
		 * rh.setFontFamily("Geinspira");
		 */
		/*
		 * } if (rowCt == 0) { // header row rh.setText("Project Name");
		 * rh.setBold(true);
		 * 
		 * para.setAlignment(ParagraphAlignment.CENTER); }
		 * 
		 * else if (rowCt % 2 == 0) {
		 * 
		 * index = rowCt; index = index-1; if(colCt == 0)
		 * rh.setText(prjNameList.get(index)); // rh.setFontSize(10);
		 * para.setAlignment(ParagraphAlignment.LEFT); }else if(rowCt >
		 * prjNameList.size()){ break; } else { // odd row index = rowCt; index
		 * = index-1; if(colCt == 0) rh.setText(prjNameList.get(index)); //
		 * rh.setFontSize(10); para.setAlignment(ParagraphAlignment.LEFT); }
		 * colCt++; } // for cell colCt = 0; rowCt++; }
		 */// for row

		// write the file
		// fileIn = new FileInputStream("filePathDocx");
		/*fos = new FileOutputStream(new File(filePathDocx));
		doc.write(fos);
		fos.close();*/
		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	/**
	 * This method is used to createClinDataTable
	 * 
	 * @param FileOutputStream
	 * @param filePathDocx
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * @param templatePath
	 */
	public void createClinDataTable(String filePathDocx, List<PLMCntrtSmryRptData> clinDataListOld, String templatePath) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);

		List<PLMCntrtSmryRptData> clinDataListNew = new ArrayList<PLMCntrtSmryRptData>();
		for (PLMCntrtSmryRptData data : clinDataListOld) {
			clinDataListNew.add(data);
		}

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3
		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		tmpParagraph.setStyle("Heading2"); // 4
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.setColor("000000");
		tmpRun.setText("Customer Deliverables � CLIN Data");
		tmpRun.setBold(true);
		tmpRun.setColor("000000");
		// tmpRun.setUnderline(UnderlinePatterns.THICK);
		tmpRun.setFontFamily("Geinspira");
		// tmpRun.setFontSize(10);
		// tmpRun.addBreak();
		// XWPFDocument doc = new XWPFDocument();

		int nRows = clinDataListNew.size() + 1;
		int nCols = 10;
		int index = 0;
		XWPFTable table = doc.createTable(nRows, nCols);
		// table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));

		// Set the table style. If the style is not defined, the table style
		// will become "Normal".
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("Normal");

		// Get a list of the rows in the table
		List<XWPFTableRow> rows = table.getRows();
		int rowCt = 0;
		int colCt = 0;
		for (XWPFTableRow row : rows) {
			// get table row properties (trPr)
			CTTrPr trPr = row.getCtRow().addNewTrPr();
			// set row height; units = twentieth of a point, 360 = 0.25"
			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(10));

			// get the cells in this row
			List<XWPFTableCell> cells = row.getTableCells();
			// add content to each cell
			for (XWPFTableCell cell : cells) {
				// get a table cell properties element (tcPr)
				CTTcPr tcpr = cell.getCTTc().addNewTcPr();
				tcpr.addNewTcW().setW(BigInteger.valueOf(2000));
				// set vertical alignment to "center"
				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				// create cell color element
				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {
					// header row
					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {
					// odd row
					ctshd.setFill("EDF2F8");
				}

				// get 1st paragraph in cell's paragraph list
				XWPFParagraph para = cell.getParagraphs().get(0);
				// create a run to contain the content
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");
				// style cell as desired
				/*
				 * if (colCt == nCols - 1) { // last column is 10pt Courier //
				 * rh.setFontSize(10); // rh.setFontFamily("Courier"); }
				 */
				if (rowCt == 0) {
					if (colCt == 0) {
						// header row
						rh.setText("Name");
					} else if (colCt == 1) {
						rh.setText("Description");
					} else if (colCt == 2) {
						rh.setText("Product");
					} else if (colCt == 3) {
						rh.setText("Type");
					} else if (colCt == 4) {
						rh.setText("Initial Delivery Date");
					} else if (colCt == 5) {
						rh.setText("Status");
					} else if (colCt == 6) {
						rh.setText("Liquidated Damages Indicator");
					} else if (colCt == 7) {
						rh.setText("Satisfied By Schedule Task");
					} else if (colCt == 8) {
						rh.setText("CI Number");
					} else if (colCt == 9) {
						rh.setText("CEI Quantity");
					}
					// rh.setFontSize(10);
					rh.setBold(true);
					para.setAlignment(ParagraphAlignment.CENTER);
				} else if (rowCt % 2 == 0) {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getClinNameParent()));
					} else if (colCt == 1) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getClinDesc()));
					} else if (colCt == 2) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getSowParagraph()));
					} else if (colCt == 3) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getClinTasking()));
					} else if (colCt == 4) {
						if (clinDataListNew.get(index).getClinInitialDeliveryDate() != null) {
							SimpleDateFormat dtfrmt = new SimpleDateFormat("MMM dd, yyyy");
							Date uniqDate = clinDataListNew.get(index).getClinInitialDeliveryDate();
							String cDate = dtfrmt.format(uniqDate);
							rh.setText(cDate);
						}
					} else if (colCt == 5) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getClinStatus()));
					} else if (colCt == 6) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getClinIndicator()));
					} else if (colCt == 7) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getSatisfiedByTask()));
					} else if (colCt == 8) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getCiNumber()));
					} else if (colCt == 9) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getCeiQuantity()));
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > clinDataListNew.size()) {
					break;
				} else {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getClinNameParent()));
					} else if (colCt == 1) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getClinDesc()));
					} else if (colCt == 2) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getSowParagraph()));
					} else if (colCt == 3) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getClinTasking()));
					} else if (colCt == 4) {
						if (clinDataListNew.get(index).getClinInitialDeliveryDate() != null) {
							SimpleDateFormat dtfrmt = new SimpleDateFormat("MMM dd, yyyy");
							Date uniqDate = clinDataListNew.get(index).getClinInitialDeliveryDate();
							String cDate = dtfrmt.format(uniqDate);
							rh.setText(cDate);
						}
					} else if (colCt == 5) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getClinStatus()));
					} else if (colCt == 6) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getClinIndicator()));
					} else if (colCt == 7) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getSatisfiedByTask()));
					} else if (colCt == 8) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getCiNumber()));
					} else if (colCt == 9) {
						rh.setText(PLMUtils.checkNullVal(clinDataListNew.get(index).getCeiQuantity()));
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell

			colCt = 0;
			rowCt++;
		} // for row

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne){
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos!=null)
				fos.close();
		}
	}

	/**
	 * This method is used to createEmpNameandRoleTable
	 * 
	 * @param FileOutputStream
	 * @param filepathDocx
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * @param templatepath
	 */
	public void createEmpNameandRoleTable(String filePathDocx, Map<String, List<PLMCntrtSmryRptData>> nameRoleMapOld, String templatePath) throws Exception {
		List<String> keyList1 = new ArrayList<String>(nameRoleMapOld.keySet());
		Map<String, List<PLMCntrtSmryRptData>> nameRoleMapNew = new HashMap<String, List<PLMCntrtSmryRptData>>();
		for (int i = 0; i < keyList1.size(); i++) {
			nameRoleMapNew.put(keyList1.get(i), nameRoleMapOld.get(keyList1.get(i)));
		}

		List<String> keyList = new ArrayList<String>(nameRoleMapNew.keySet());
		for (int i = 0; i < keyList.size(); i++) {
			// List<PLMCntrtSmryRptData> tempNRList = new
			// ArrayList<PLMCntrtSmryRptData>();
			List<PLMCntrtSmryRptData> tempNRList = nameRoleMapNew.get(keyList.get(i));
			if (!PLMUtils.isEmptyList(tempNRList)) {
				LOG.info(tempNRList.get(0));
			}
			// open an existing empty document with styles already defined
			LOG.info("Opening existing document -------> " + filePathDocx);

			XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
			XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
			XWPFStyles headStyle = doc.createStyles(); // 2
			headStyle.setStyles(template.getStyle()); // 3
			XWPFParagraph tmpParagraph = doc.createParagraph();
			tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
			tmpParagraph.setStyle("Heading2"); // 4
			XWPFRun tmpRun = tmpParagraph.createRun();
			tmpRun.setColor("000000");
			if (keyList.get(i).endsWith("ITO")) {
				tmpRun.setText("ITO Project Members : " + keyList.get(i));
			} else {
				tmpRun.setText("OTR Project Members : " + keyList.get(i));
			}
			tmpRun.setBold(true);
			// tmpRun.setUnderline(UnderlinePatterns.THICK);
			// tmpRun.setFontSize(10);
			// tmpRun.addBreak();
			// XWPFDocument doc = new XWPFDocument();

			int nRows = tempNRList.size() + 1;
			int[] cols = { 3000, 3000, 3000 };
			int nCols = 3;
			int index = 0;
			XWPFTable table = doc.createTable(nRows, nCols);
			table.getCTTbl().getTblPr().unsetTblBorders();
			// table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));

			// Set the table style. If the style is not defined, the table style
			// will become "Normal".
			CTTblPr tblPr = table.getCTTbl().getTblPr();
			CTString styleStr = tblPr.addNewTblStyle();
			styleStr.setVal("StyledTable");

			// Get a list of the rows in the table
			List<XWPFTableRow> rows = table.getRows();
			int rowCt = 0;
			int colCt = 0;
			for (int a = 0; a < rows.size(); a++) {
				XWPFTableRow row = table.getRow(a);
				// get table row properties (trPr)
				CTTrPr trPr = row.getCtRow().addNewTrPr();
				// set row height; units = twentieth of a point, 360 = 0.25"
				CTHeight ht = trPr.addNewTrHeight();
				ht.setVal(BigInteger.valueOf(10));

				// get the cells in this row
				List<XWPFTableCell> cells = row.getTableCells();
				// add content to each cell
				for (int j = 0; j < cells.size(); j++) {
					XWPFTableCell cell = row.getCell(j);
					// get a table cell properties element (tcPr)
					CTTcPr tcpr = cell.getCTTc().addNewTcPr();
					// set vertical alignment to "center"
					CTVerticalJc va = tcpr.addNewVAlign();
					va.setVal(STVerticalJc.CENTER);

					// create cell color element
					CTShd ctshd = tcpr.addNewShd();
					ctshd.setColor("auto");
					ctshd.setVal(STShd.CLEAR);
					/*
					 * if (rowCt == 0) { // header row //
					 * ctshd.setFill("A7BFDE"); } else if (rowCt % 2 == 0) {
					 * 
					 * // ctshd.setFill("D3DFEE"); } else { // odd row //
					 * ctshd.setFill("EDF2F8"); }
					 */

					// get 1st paragraph in cell's paragraph list
					XWPFParagraph para = cell.getParagraphs().get(0);
					// create a run to contain the content
					XWPFRun rh = para.createRun();
					rh.setFontSize(8);
					rh.setFontFamily("Geinspira");
					// style cell as desired
					/*
					 * if (colCt == nCols - 1) { // last column is 10pt Courier
					 * // rh.setFontSize(10); // rh.setFontFamily("Courier"); }
					 */
					if (rowCt == 0) {
						if (colCt == 0) {
							// header row
							rh.setText("NAME");
						} else if (colCt == 1) {
							rh.setText("GE ROLE");
						} else if (colCt == 2) {
							rh.setText("SSO");
						}

						rh.setBold(true);
						para.setAlignment(ParagraphAlignment.LEFT);
					} else if (rowCt % 2 == 0) {

						index = rowCt;
						index = index - 1;
						if (colCt == 0) {
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
							rh.setText(tempNRList.get(index).getEmpName());
						} else if (colCt == 1) {
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
							rh.setText(tempNRList.get(index).getEmpRole());
						} else if (colCt == 2) {
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
							rh.setText(tempNRList.get(index).getSso());
						}
						// rh.setFontSize(10);
						para.setAlignment(ParagraphAlignment.LEFT);
					} else if (rowCt > tempNRList.size()) {
						break;
					} else {

						index = rowCt;
						index = index - 1;
						if (colCt == 0) {
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
							rh.setText(tempNRList.get(index).getEmpName());

						} else if (colCt == 1) {
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
							rh.setText(tempNRList.get(index).getEmpRole());
						} else if (colCt == 2) {
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
							rh.setText(tempNRList.get(index).getSso());
						}
						// rh.setFontSize(10);
						para.setAlignment(ParagraphAlignment.LEFT);
					}
					colCt++;
				} // for cell

				colCt = 0;
				rowCt++;
			} // for row

			XWPFParagraph brkParagraph = doc.createParagraph();
			brkParagraph.setAlignment(ParagraphAlignment.LEFT);
			XWPFRun brkRun = tmpParagraph.createRun();
			brkRun.addBreak();
			// brkRun.addBreak();
			// brkRun.addBreak();

			// write the file
			FileOutputStream fos = null;
			try {
				fos = new FileOutputStream(new File(filePathDocx));
				doc.write(fos);
			} catch (FileNotFoundException exp) {
				if (fos != null) {
					fos.close();
				}
			}

		}
	}

	/**
	 * This method is used to createPRSTable
	 * 
	 * @param FileOutputStream
	 * @param filepathDocx
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * @param templatepath
	 */
	public void createPRSTable(String filePathDocx, List<PLMCntrtSmryRptData> prdtRqmntSpecListOld, String templatePath) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);

		List<PLMCntrtSmryRptData> prdtRqmntSpecListNew = new ArrayList<PLMCntrtSmryRptData>();
		for (PLMCntrtSmryRptData data : prdtRqmntSpecListOld) {
			prdtRqmntSpecListNew.add(data);
		}

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3
		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setStyle("Heading2"); // 4
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.setColor("000000");
		tmpRun.setText("Product Requirement Spec Data");
		tmpRun.setBold(true);
		// tmpRun.setUnderline(UnderlinePatterns.THICK);
		// tmpRun.setFontSize(10);
		// tmpRun.addBreak();
		// XWPFDocument doc = new XWPFDocument();

		int nRows = prdtRqmntSpecListNew.size() + 1;
		int nCols = 3;
		int index = 0;
		XWPFTable table = doc.createTable(nRows, nCols);
		table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));
		// Set the table style. If the style is not defined, the table style
		// will become "Normal".
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("StyledTable");

		// Get a list of the rows in the table
		List<XWPFTableRow> rows = table.getRows();
		int rowCt = 0;
		int colCt = 0;
		for (XWPFTableRow row : rows) {
			// get table row properties (trPr)
			CTTrPr trPr = row.getCtRow().addNewTrPr();
			// set row height; units = twentieth of a point, 360 = 0.25"
			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(10));

			// get the cells in this row
			List<XWPFTableCell> cells = row.getTableCells();
			// add content to each cell
			for (XWPFTableCell cell : cells) {
				// get a table cell properties element (tcPr)
				CTTcPr tcpr = cell.getCTTc().addNewTcPr();
				// set vertical alignment to "center"
				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				// create cell color element
				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {
					// header row
					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {
					// odd row
					ctshd.setFill("EDF2F8");
				}

				// get 1st paragraph in cell's paragraph list
				XWPFParagraph para = cell.getParagraphs().get(0);
				// create a run to contain the content
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");
				// style cell as desired
				/*
				 * if (colCt == nCols - 1) { // last column is 10pt Courier //
				 * rh.setFontSize(10); // rh.setFontFamily("Courier"); }
				 */
				if (rowCt == 0) {
					if (colCt == 0) {
						// header row
						rh.setText("Name");
					} else if (colCt == 1) {
						rh.setText("Description");
					}/*
					 * else if(colCt == 2){ rh.setText("Title"); }
					 */else if (colCt == 2) {
						rh.setText("Notes");
					}

					rh.setBold(true);
					para.setAlignment(ParagraphAlignment.CENTER);
				} else if (rowCt % 2 == 0) {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(prdtRqmntSpecListNew.get(index).getPrdtRqmntSpecNm());
					} else if (colCt == 1) {
						rh.setText(prdtRqmntSpecListNew.get(index).getPrdtRqmntSpecDesc());
					}/*
					 * else if(colCt == 2){
					 * rh.setText(prdtRqmntSpecListNew.get(index
					 * ).getPrdtRqmntSpecTitleCol()); }
					 */else if (colCt == 2) {
						rh.setText(prdtRqmntSpecListNew.get(index).getPrdtRqmntSpecNotes());
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > prdtRqmntSpecListNew.size()) {
					break;
				} else {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(prdtRqmntSpecListNew.get(index).getPrdtRqmntSpecNm());
					} else if (colCt == 1) {
						rh.setText(prdtRqmntSpecListNew.get(index).getPrdtRqmntSpecDesc());
					}/*
					 * else if(colCt == 2){
					 * rh.setText(prdtRqmntSpecListNew.get(index
					 * ).getPrdtRqmntSpecTitleCol()); }
					 */else if (colCt == 2) {
						rh.setText(prdtRqmntSpecListNew.get(index).getPrdtRqmntSpecNotes());
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell

			colCt = 0;
			rowCt++;
		} // for row

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	/**
	 * This method is used to createCRSTable
	 * 
	 * @param FileOutputStream
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * @param templatepath
	 */
	public void createCRSTable(String filePathDocx, List<PLMCntrtSmryRptData> crsDataList, String templatePath) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3
		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setStyle("Heading2"); // 4
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.setColor("000000");
		tmpRun.setText("Customer Requirements Spec Data");
		tmpRun.setBold(true);
		/*
		 * tmpRun.setUnderline(UnderlinePatterns.THICK); tmpRun.setFontSize(10);
		 * tmpRun.addBreak();
		 */
		// XWPFDocument doc = new XWPFDocument();

		int nRows = crsDataList.size() + 1;
		int nCols = 4;
		int index = 0;
		XWPFTable table = doc.createTable(nRows, nCols);
		table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));
		// Set the table style. If the style is not defined, the table style
		// will become "Normal".
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("StyledTable");

		// Get a list of the rows in the table
		List<XWPFTableRow> rows = table.getRows();
		int rowCt = 0;
		int colCt = 0;
		for (XWPFTableRow row : rows) {
			// get table row properties (trPr)
			CTTrPr trPr = row.getCtRow().addNewTrPr();
			// set row height; units = twentieth of a point, 360 = 0.25"
			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(10));

			// get the cells in this row
			List<XWPFTableCell> cells = row.getTableCells();
			// add content to each cell
			for (XWPFTableCell cell : cells) {
				// get a table cell properties element (tcPr)
				CTTcPr tcpr = cell.getCTTc().addNewTcPr();
				// set vertical alignment to "center"
				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				// create cell color element
				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {
					// header row
					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {
					// odd row
					ctshd.setFill("EDF2F8");
				}

				// get 1st paragraph in cell's paragraph list
				XWPFParagraph para = cell.getParagraphs().get(0);
				// create a run to contain the content
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");
				// style cell as desired
				/*
				 * if (colCt == nCols - 1) { // last column is 10pt Courier //
				 * rh.setFontSize(10); // rh.setFontFamily("Courier"); }
				 */
				if (rowCt == 0) {
					if (colCt == 0) {
						// header row
						rh.setText("Name");
					} else if (colCt == 1) {
						rh.setText("CRS Title");
					} else if (colCt == 2) {
						rh.setText("Revision");
					} else if (colCt == 3) {
						rh.setText("State");
					}

					rh.setBold(true);
					para.setAlignment(ParagraphAlignment.CENTER);
				} else if (rowCt % 2 == 0) {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(crsDataList.get(index).getCrsName());
					} else if (colCt == 1) {
						rh.setText(crsDataList.get(index).getCrsTitle());
					} else if (colCt == 2) {
						rh.setText(crsDataList.get(index).getCrsRevision());
					} else if (colCt == 3) {
						rh.setText(crsDataList.get(index).getCrsTitle());
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > crsDataList.size()) {
					break;
				} else {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(crsDataList.get(index).getCrsName());
					} else if (colCt == 1) {
						rh.setText(crsDataList.get(index).getCrsTitle());
					} else if (colCt == 2) {
						rh.setText(crsDataList.get(index).getCrsRevision());
					} else if (colCt == 3) {
						rh.setText(crsDataList.get(index).getCrsTitle());
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell

			colCt = 0;
			rowCt++;
		} // for row

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	/**
	 * This method is used to createHrdwreBuildTable
	 * 
	 * @param FileOutputStream
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * @param templatepath
	 */
	public void createHrdwreBuildTable(String filePathDocx, List<PLMCntrtSmryRptData> hardwareBuildDataListOld, String templatePath) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);

		List<PLMCntrtSmryRptData> hardwareBuildDataListNew = new ArrayList<PLMCntrtSmryRptData>();
		for (PLMCntrtSmryRptData data : hardwareBuildDataListOld) {
			hardwareBuildDataListNew.add(data);
		}

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3
		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setStyle("Heading2"); // 4
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.setColor("000000");
		tmpRun.setText("Hardware Build Data");
		tmpRun.setBold(true);
		/*
		 * tmpRun.setUnderline(UnderlinePatterns.THICK); tmpRun.setFontSize(10);
		 * tmpRun.addBreak();
		 */
		// XWPFDocument doc = new XWPFDocument();

		int nRows = hardwareBuildDataListNew.size() + 1;
		int nCols = 7;
		int index = 0;
		XWPFTable table = doc.createTable(nRows, nCols);
		table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));
		// Set the table style. If the style is not defined, the table style
		// will become "Normal".
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("StyledTable");

		// Get a list of the rows in the table
		List<XWPFTableRow> rows = table.getRows();
		int rowCt = 0;
		int colCt = 0;
		for (XWPFTableRow row : rows) {
			// get table row properties (trPr)
			CTTrPr trPr = row.getCtRow().addNewTrPr();
			// set row height; units = twentieth of a point, 360 = 0.25"
			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(10));

			// get the cells in this row
			List<XWPFTableCell> cells = row.getTableCells();
			// add content to each cell
			for (XWPFTableCell cell : cells) {
				// get a table cell properties element (tcPr)
				CTTcPr tcpr = cell.getCTTc().addNewTcPr();
				// set vertical alignment to "center"
				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				// create cell color element
				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {
					// header row
					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {
					// odd row
					ctshd.setFill("EDF2F8");
				}

				// get 1st paragraph in cell's paragraph list
				XWPFParagraph para = cell.getParagraphs().get(0);
				// create a run to contain the content
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");
				// style cell as desired
				/*
				 * if (colCt == nCols - 1) { // last column is 10pt Courier //
				 * rh.setFontSize(10); // rh.setFontFamily("Courier"); }
				 */
				if (rowCt == 0) {
					if (colCt == 0) {
						// header row
						rh.setText("Clin Name");
					} else if (colCt == 1) {
						rh.setText("Build Name");
					} else if (colCt == 2) {
						rh.setText("Unit Serial Number");
					} else if (colCt == 3) {
						rh.setText("Shop Order Number");
					} else if (colCt == 4) {
						rh.setText("Build Type");
					} else if (colCt == 5) {
						rh.setText("State");
					} else if (colCt == 6) {
						rh.setText("Part Number");
					}

					rh.setBold(true);
					para.setAlignment(ParagraphAlignment.CENTER);
				} else if (rowCt % 2 == 0) {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(hardwareBuildDataListNew.get(index).getHbClinNm());
					} else if (colCt == 1) {
						rh.setText(hardwareBuildDataListNew.get(index).getHbldNm());
					} else if (colCt == 2) {
						rh.setText(hardwareBuildDataListNew.get(index).getHbSrlNum());
					} else if (colCt == 3) {
						rh.setText(hardwareBuildDataListNew.get(index).getShpOrdrNum());
					} else if (colCt == 4) {
						rh.setText(hardwareBuildDataListNew.get(index).getHbldType());
					} else if (colCt == 5) {
						rh.setText(hardwareBuildDataListNew.get(index).getHbldState());
					} else if (colCt == 6) {
						rh.setText(hardwareBuildDataListNew.get(index).getHbPartNum());
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > hardwareBuildDataListNew.size()) {
					break;
				} else {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(hardwareBuildDataListNew.get(index).getHbClinNm());
					} else if (colCt == 1) {
						rh.setText(hardwareBuildDataListNew.get(index).getHbldNm());
					} else if (colCt == 2) {
						rh.setText(hardwareBuildDataListNew.get(index).getHbSrlNum());
					} else if (colCt == 3) {
						rh.setText(hardwareBuildDataListNew.get(index).getShpOrdrNum());
					} else if (colCt == 4) {
						rh.setText(hardwareBuildDataListNew.get(index).getHbldType());
					} else if (colCt == 5) {
						rh.setText(hardwareBuildDataListNew.get(index).getHbldState());
					} else if (colCt == 6) {
						rh.setText(hardwareBuildDataListNew.get(index).getHbPartNum());
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell

			colCt = 0;
			rowCt++;
		} // for row

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	/**
	 * This method is used to createPLPTable
	 * 
	 * @param FileOutputStream
	 * @param filepathDocx
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * @param templatepath
	 */
	public void createPLPTable(String filePathDocx, List<PLMCntrtSmryRptData> plpListOld, String templatePath) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);
		List<PLMCntrtSmryRptData> plpListNew = new ArrayList<PLMCntrtSmryRptData>();
		for (PLMCntrtSmryRptData data : plpListOld) {
			plpListNew.add(data);
		}

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3
		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setStyle("Heading2"); // 4
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.setColor("000000");
		tmpRun.setBold(true);

		XWPFParagraph tmpPar = doc.createParagraph();
		tmpPar.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun tmpRun1 = tmpPar.createRun();
		if (plpListNew.size() > 0) {
			tmpRun.setText("Plant Level Part Name : ");
			tmpRun1.setText(plpListNew.get(0).getPLPName());
			tmpRun1.addBreak();
		} else {
			tmpRun.setText("Plant Level Part Name : ");
			tmpRun1.setText("");
			tmpRun1.addBreak();
		}

		/*
		 * tmpRun.setUnderline(UnderlinePatterns.THICK); tmpRun.setFontSize(10);
		 * tmpRun.addBreak();
		 */
		// XWPFDocument doc = new XWPFDocument();

		/*
		 * int nRows = PLPList.size()+1; int nCols = 1; int index = 0; XWPFTable
		 * table = doc.createTable(nRows, nCols);
		 * table.getCTTbl().addNewTblPr().
		 * addNewTblW().setW(BigInteger.valueOf(10000)); // Set the table style.
		 * If the style is not defined, the table style // will become "Normal".
		 * CTTblPr tblPr = table.getCTTbl().getTblPr(); CTString styleStr =
		 * tblPr.addNewTblStyle(); styleStr.setVal("StyledTable");
		 * 
		 * // Get a list of the rows in the table List<XWPFTableRow> rows =
		 * table.getRows(); int rowCt = 0; int colCt = 0; for (XWPFTableRow row
		 * : rows) { // get table row properties (trPr) CTTrPr trPr =
		 * row.getCtRow().addNewTrPr(); // set row height; units = twentieth of
		 * a point, 360 = 0.25" CTHeight ht = trPr.addNewTrHeight();
		 * ht.setVal(BigInteger.valueOf(10));
		 * 
		 * // get the cells in this row List<XWPFTableCell> cells =
		 * row.getTableCells(); // add content to each cell for (XWPFTableCell
		 * cell : cells) { // get a table cell properties element (tcPr) CTTcPr
		 * tcpr = cell.getCTTc().addNewTcPr(); // set vertical alignment to
		 * "center" CTVerticalJc va = tcpr.addNewVAlign();
		 * va.setVal(STVerticalJc.CENTER);
		 * 
		 * // create cell color element CTShd ctshd = tcpr.addNewShd();
		 * ctshd.setColor("auto"); ctshd.setVal(STShd.CLEAR); if (rowCt == 0) {
		 * // header row ctshd.setFill("A7BFDE"); } else if (rowCt % 2 == 0) {
		 * 
		 * ctshd.setFill("D3DFEE"); } else { // odd row ctshd.setFill("EDF2F8");
		 * }
		 * 
		 * // get 1st paragraph in cell's paragraph list XWPFParagraph para =
		 * cell.getParagraphs().get(0); // create a run to contain the content
		 * XWPFRun rh = para.createRun(); rh.setFontSize(8);
		 * rh.setFontFamily("Geinspira"); // style cell as desired if (colCt ==
		 * nCols - 1) { // last column is 10pt Courier // rh.setFontSize(10); //
		 * rh.setFontFamily("Courier"); } if (rowCt == 0 ) { if(colCt == 0){ //
		 * header row rh.setText("Name"); }
		 * 
		 * rh.setBold(true); para.setAlignment(ParagraphAlignment.CENTER); }
		 * else if (rowCt % 2 == 0) {
		 * 
		 * index = rowCt; index = index-1; if(colCt == 0){
		 * rh.setText(PLPList.get(index).getPLPName()); // rh.setFontSize(10); }
		 * }else if(rowCt > PLPList.size()){ break; } else {
		 * 
		 * index = rowCt; index = index-1; if(colCt == 0){
		 * rh.setText(PLPList.get(index).getPLPName()); // rh.setFontSize(10); }
		 * } colCt++; } // for cell
		 * 
		 * 
		 * 
		 * colCt = 0; rowCt++; } // for row
		 */

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	/**
	 * This method is used to createProductConfigTable
	 * 
	 * @param FileOutputStream
	 * @param file
	 *            path
	 * @param List
	 *            of PLMCntrtSmryRptData
	 * @param pc
	 *            Name
	 * @param pc
	 *            Desc
	 * @param templatePath
	 */
	public void createProductConfigTable(String filePathDocx, List<PLMCntrtSmryRptData> dataList, String pcName, String pcDesc, String templatePath) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3

		XWPFParagraph titlePara = doc.createParagraph();
		titlePara.setAlignment(ParagraphAlignment.CENTER);
		titlePara.setStyle("Heading2"); // 4
		XWPFRun title = titlePara.createRun();
		title.setColor("000000");
		title.setBold(true);
		/*
		 * title.setUnderline(UnderlinePatterns.THICK); title.setFontSize(10);
		 * title.addBreak();
		 */

		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		tmpParagraph.setStyle("Heading3");
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.setColor("000000");
		tmpRun.setText("Product Configuration Data - " + pcName + "  :  " + pcDesc);
		tmpRun.setBold(true);
		tmpRun.setUnderline(UnderlinePatterns.THICK);
		tmpRun.setFontSize(10);
		tmpRun.addBreak();
		// XWPFDocument doc = new XWPFDocument();

		int nRows = dataList.size() + 1;
		int nCols = 8;
		int index = 0;
		XWPFTable table = doc.createTable(nRows, nCols);
		table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));
		// Set the table style. If the style is not defined, the table style
		// will become "Normal".
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("StyledTable");

		// Get a list of the rows in the table
		List<XWPFTableRow> rows = table.getRows();
		int rowCt = 0;
		int colCt = 0;
		for (XWPFTableRow row : rows) {
			// get table row properties (trPr)
			CTTrPr trPr = row.getCtRow().addNewTrPr();
			// set row height; units = twentieth of a point, 360 = 0.25"
			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(10));

			// get the cells in this row
			List<XWPFTableCell> cells = row.getTableCells();
			// add content to each cell
			for (XWPFTableCell cell : cells) {
				// get a table cell properties element (tcPr)
				CTTcPr tcpr = cell.getCTTc().addNewTcPr();
				// set vertical alignment to "center"
				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				// create cell color element
				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {
					// header row
					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {
					// odd row
					ctshd.setFill("EDF2F8");
				}

				// get 1st paragraph in cell's paragraph list
				XWPFParagraph para = cell.getParagraphs().get(0);
				// create a run to contain the content
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");
				// style cell as desired
				/*
				 * if (colCt == nCols - 1) { // last column is 10pt Courier //
				 * rh.setFontSize(10); // rh.setFontFamily("Courier"); }
				 */
				if (rowCt == 0) {
					if (colCt == 0) {
						// header row
						rh.setText("Name");
					} else if (colCt == 1) {
						rh.setText("Description");
					} else if (colCt == 2) {
						rh.setText("Based On");
					} else if (colCt == 3) {
						rh.setText("State");
					} else if (colCt == 4) {
						rh.setText("Parent Pc");
					} else if (colCt == 5) {
						rh.setText("Top Level Parent");
					} else if (colCt == 6) {
						rh.setText("Derived From");
					} else if (colCt == 7) {
						rh.setText("Purpose");
					}

					rh.setBold(true);
					para.setAlignment(ParagraphAlignment.CENTER);
				} else if (rowCt % 2 == 0) {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(dataList.get(index).getPcName());
					} else if (colCt == 1) {
						rh.setText(dataList.get(index).getPcDesc());
					} else if (colCt == 2) {
						rh.setText(dataList.get(index).getPcBasedOn());
					} else if (colCt == 3) {
						rh.setText(dataList.get(index).getPcState());
					} else if (colCt == 4) {
						rh.setText(dataList.get(index).getPcParentPc());
					} else if (colCt == 5) {
						rh.setText(dataList.get(index).getPcTopLevelParent());
					} else if (colCt == 6) {
						rh.setText(dataList.get(index).getPcDerviedFrom());
					} else if (colCt == 7) {
						rh.setText(dataList.get(index).getPcPurpose());
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > dataList.size()) {
					break;
				} else {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(dataList.get(index).getPcName());
					} else if (colCt == 1) {
						rh.setText(dataList.get(index).getPcDesc());
					} else if (colCt == 2) {
						rh.setText(dataList.get(index).getPcBasedOn());
					} else if (colCt == 3) {
						rh.setText(dataList.get(index).getPcState());
					} else if (colCt == 4) {
						rh.setText(dataList.get(index).getPcParentPc());
					} else if (colCt == 5) {
						rh.setText(dataList.get(index).getPcTopLevelParent());
					} else if (colCt == 6) {
						rh.setText(dataList.get(index).getPcDerviedFrom());
					} else if (colCt == 7) {
						rh.setText(dataList.get(index).getPcPurpose());
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell

			colCt = 0;
			rowCt++;
		} // for row

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	/**
	 * This method is used to createConfigurationFeaturesTable
	 * 
	 * @param FileOutputStream
	 * @param file
	 *            path
	 * @param List
	 *            of PLMCntrtSmryRptData
	 * @param pc
	 *            Name
	 */
	public void createCostGrpConfigFeaturesTab(String filePathDocx, List<PLMCntrtSmryRptData> dataList, String costGroup,List<String> pcNameList, 
			String pcDesc, String isOption, String templatePath) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);
		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3

		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		tmpParagraph.setStyle("Heading2"); // 4
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.setColor("000000");
		tmpRun.setText("Configuration Features Data - " +costGroup +": "+ pcNameList);
		tmpRun.setBold(true);
		XWPFRun tmpRun1 = tmpParagraph.createRun();
		tmpRun1.setColor("FF0000");
		tmpRun1.setText(isOption);
		tmpRun1.setBold(true);
		tmpParagraph.addRun(tmpRun1);
		
		/*
		 * tmpRun.setUnderline(UnderlinePatterns.THICK); tmpRun.setFontSize(10);
		 * tmpRun.addBreak();
		 */
		// XWPFDocument doc = new XWPFDocument();

		int nRows = dataList.size() + 1;
		//int[] cols = {2000, 4000, 2000, 4000,1500,1500};
		int nCols = 7;
		int index = 0;
		XWPFTable table = doc.createTable(nRows, nCols);
		// table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));
		// Set the table style. If the style is not defined, the table style
		// will become "Normal".
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("StyledTable");

		// Get a list of the rows in the table
		List<XWPFTableRow> rows = table.getRows();
		int rowCt = 0;
		int colCt = 0;
		for (XWPFTableRow row : rows) {
			// get table row properties (trPr)
			CTTrPr trPr = row.getCtRow().addNewTrPr();
			// set row height; units = twentieth of a point, 360 = 0.25"
			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(10));

			// get the cells in this row
			List<XWPFTableCell> cells = row.getTableCells();
			// add content to each cell
			for (int j = 0; j < cells.size(); j++) {
				XWPFTableCell cell = row.getCell(j);
				// get a table cell properties element (tcPr)
				CTTcPr tcpr = cell.getCTTc().addNewTcPr();
				// tcpr.addNewTcW().setW(BigInteger.valueOf(200));
				// set vertical alignment to "center"
				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				// create cell color element
				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {
					// header row
					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {
					// odd row
					ctshd.setFill("EDF2F8");
				}

				// get 1st paragraph in cell's paragraph list
				XWPFParagraph para = cell.getParagraphs().get(0);
				// create a run to contain the content
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");
				// style cell as desired
				/*
				 * if (colCt == nCols - 1) { // last column is 10pt Courier //
				 * rh.setFontSize(10); // rh.setFontFamily("Courier"); }
				 */
				if (rowCt == 0) {
					if (colCt == 0) {
						// header row
						rh.setText("Config Feature Header Name");
					} else if (colCt == 1) {
						rh.setText("Config Feature Header");
					} else if (colCt == 2) {
						rh.setText("Configuration Selected Option");
					} else if (colCt == 3) {
						rh.setText("Configuration Selected Option Display Name");

					}else if (colCt == 4) {
						rh.setText("Legacy F&A Code");
					}else if (colCt == 5) {
						rh.setText("Option Sub Type");
					}else if(colCt==6){
						rh.setText("Key_In_Value");
					}
					/*else if (colCt == 4) {
						rh.setText("Related CR");
					} else if (colCt == 5) {
						rh.setText("CR Title");
					}*/

					rh.setBold(true);
					para.setAlignment(ParagraphAlignment.CENTER);
				} else if (rowCt % 2 == 0) {
					index = rowCt;
					index = index - 1;
					
					if(dataList.get(index).isSystemFlag()){
						if (colCt == 0) {
							rh.setText(dataList.get(index).getSystemName());
							rh.setBold(true);
							rh.setFontSize(12);
			                rh.setUnderline(UnderlinePatterns.SINGLE);
			                mergeCellHorizontally(table,ctshd,rowCt,0,6);
						}

					}else{
						if (colCt == 0) {
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
							appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCfId(), dataList.get(index).getCfName(), para);
							// rh.setText(dataList.get(index).getCfName());
						} else if (colCt == 1) {
							rh.setText(splitCharLengthData(dataList.get(index).getCfDisplyName(),20));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));

						} else if (colCt == 2) {
							appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCfConfId(), dataList.get(index).getCfConfigOption(), para);
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));

							// rh.setText(dataList.get(index).getCfConfigOption());
						} else if (colCt == 3) {
							rh.setText(splitCharLengthData(dataList.get(index).getCfConfOptDispName(),20));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						}else if (colCt == 4) {
							rh.setText(splitCharLengthData(dataList.get(index).getLegacyFACode(),10));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						}else if (colCt == 5) {
							rh.setText(splitCharLengthData(dataList.get(index).getOptSubType(),10));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						}
						else if (colCt == 6) {
							rh.setText(splitCharLengthData(dataList.get(index).getKeyInValue(),10));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						}
					}
					
					
					/*else if (colCt == 4) {
						if (!PLMUtils.isEmpty(dataList.get(index).getCrName())) {
							appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCrId(), dataList.get(index).getCrName(), para);
						}
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));

					} else if (colCt == 5) {
						rh.setText(dataList.get(index).getCrTitle());
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
					}*/
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > dataList.size()) {
					break;
				} else {

					index = rowCt;
					index = index - 1;
					if(dataList.get(index).isSystemFlag()){
						if (colCt == 0) {
							rh.setText(dataList.get(index).getSystemName());
							rh.setBold(true);
							rh.setFontSize(12);
			                rh.setUnderline(UnderlinePatterns.SINGLE);
			                mergeCellHorizontally(table,ctshd, rowCt,  0,  6);
						}
					}else{
						if (colCt == 0) {
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
							appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCfId(), dataList.get(index).getCfName(), para);
							// rh.setText(dataList.get(index).getCfName());
						} else if (colCt == 1) {
							rh.setText(splitCharLengthData(dataList.get(index).getCfDisplyName(),20));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));

						} else if (colCt == 2) {
							appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCfConfId(), dataList.get(index).getCfConfigOption(), para);
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));

							// rh.setText(dataList.get(index).getCfConfigOption());
						} else if (colCt == 3) {
							rh.setText(splitCharLengthData(dataList.get(index).getCfConfOptDispName(),20));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						}else if (colCt == 4) {
							rh.setText(splitCharLengthData(dataList.get(index).getLegacyFACode(),10));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						}else if (colCt == 5) {
							rh.setText(splitCharLengthData(dataList.get(index).getOptSubType(),10));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						} 
						else if (colCt == 6) {
							rh.setText(splitCharLengthData(dataList.get(index).getKeyInValue(),10));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						} 
					}
					
					/*else if (colCt == 4) {
						if (!PLMUtils.isEmpty(dataList.get(index).getCrName())) {
							appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCrId(), dataList.get(index).getCrName(), para);
						}
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));

					} else if (colCt == 5) {
						rh.setText(dataList.get(index).getCrTitle());
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
					}*/
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell

			colCt = 0;
			rowCt++;
		} // for row

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	/**
	 * This method is used to createConfigurationFeaturesTable
	 * 
	 * @param FileOutputStream
	 * @param file
	 *            path
	 * @param List
	 *            of PLMCntrtSmryRptData
	 * @param pc
	 *            Name
	 */
	public void createConfigurationFeaturesTable(String filePathDocx, List<PLMCntrtSmryRptData> dataList, String pcName, 
			String pcDesc, String isOption, String templatePath) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);
		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3

		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		tmpParagraph.setStyle("Heading2"); // 4
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.setColor("000000");
		tmpRun.setText("Configuration Features Data - " + pcName + " : " + pcDesc);
		tmpRun.setBold(true);
		XWPFRun tmpRun1 = tmpParagraph.createRun();
		tmpRun1.setColor("FF0000");
		tmpRun1.setText(isOption);
		tmpRun1.setBold(true);
		tmpParagraph.addRun(tmpRun1);
		
		/*
		 * tmpRun.setUnderline(UnderlinePatterns.THICK); tmpRun.setFontSize(10);
		 * tmpRun.addBreak();
		 */
		// XWPFDocument doc = new XWPFDocument();

		int nRows = dataList.size() + 1;
		//int[] cols = {2000, 4000, 2000, 4000,1500,1500};
		//int nCols = 6;
		int nCols = 7;
		int index = 0;
		XWPFTable table = doc.createTable(nRows, nCols);
		// table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));
		// Set the table style. If the style is not defined, the table style
		// will become "Normal".
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("StyledTable");

		// Get a list of the rows in the table
		List<XWPFTableRow> rows = table.getRows();
		int rowCt = 0;
		int colCt = 0;
		for (XWPFTableRow row : rows) {
			// get table row properties (trPr)
			CTTrPr trPr = row.getCtRow().addNewTrPr();
			// set row height; units = twentieth of a point, 360 = 0.25"
			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(10));

			// get the cells in this row
			List<XWPFTableCell> cells = row.getTableCells();
			// add content to each cell
			for (int j = 0; j < cells.size(); j++) {
				XWPFTableCell cell = row.getCell(j);
				// get a table cell properties element (tcPr)
				CTTcPr tcpr = cell.getCTTc().addNewTcPr();
				// tcpr.addNewTcW().setW(BigInteger.valueOf(200));
				// set vertical alignment to "center"
				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				// create cell color element
				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {
					// header row
					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {
					// odd row
					ctshd.setFill("EDF2F8");
				}

				// get 1st paragraph in cell's paragraph list
				XWPFParagraph para = cell.getParagraphs().get(0);
				// create a run to contain the content
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");
				// style cell as desired
				/*
				 * if (colCt == nCols - 1) { // last column is 10pt Courier //
				 * rh.setFontSize(10); // rh.setFontFamily("Courier"); }
				 */
				if (rowCt == 0) {
					if (colCt == 0) {
						// header row
						rh.setText("Config Feature Header Name");
					} else if (colCt == 1) {
						rh.setText("Config Feature Header");
					} else if (colCt == 2) {
						rh.setText("Configuration Selected Option");
					} else if (colCt == 3) {
						rh.setText("Configuration Selected Option Display Name");

					}else if (colCt == 4) {
						rh.setText("Legacy F&A Code");
					}else if (colCt == 5) {
						rh.setText("Option Sub Type");
					}
					else if (colCt == 6) {
						rh.setText("Key_In_Value");
					}
					/*else if (colCt == 4) {
						rh.setText("Related CR");
					} else if (colCt == 5) {
						rh.setText("CR Title");
					}*/

					rh.setBold(true);
					para.setAlignment(ParagraphAlignment.CENTER);
				} else if (rowCt % 2 == 0) {
					index = rowCt;
					index = index - 1;

						if (colCt == 0) {
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
							appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCfId(), dataList.get(index).getCfName(), para);
							// rh.setText(dataList.get(index).getCfName());
						} else if (colCt == 1) {
							rh.setText(splitCharLengthData(dataList.get(index).getCfDisplyName(),20));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));

						} else if (colCt == 2) {
							appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCfConfId(), dataList.get(index).getCfConfigOption(), para);
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));

							// rh.setText(dataList.get(index).getCfConfigOption());
						} else if (colCt == 3) {
							rh.setText(splitCharLengthData(dataList.get(index).getCfConfOptDispName(),20));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						}else if (colCt == 4) {
							rh.setText(splitCharLengthData(dataList.get(index).getLegacyFACode(),10));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						}else if (colCt == 5) {
							rh.setText(splitCharLengthData(dataList.get(index).getOptSubType(),10));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						}
						else if (colCt == 6) {
							rh.setText(splitCharLengthData(dataList.get(index).getKeyInValue(),10));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						}
					
					
					/*else if (colCt == 4) {
						if (!PLMUtils.isEmpty(dataList.get(index).getCrName())) {
							appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCrId(), dataList.get(index).getCrName(), para);
						}
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));

					} else if (colCt == 5) {
						rh.setText(dataList.get(index).getCrTitle());
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
					}*/
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > dataList.size()) {
					break;
				} else {
					index = rowCt;
					index = index - 1;
						if (colCt == 0) {
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
							appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCfId(), dataList.get(index).getCfName(), para);
							// rh.setText(dataList.get(index).getCfName());
						} else if (colCt == 1) {
							rh.setText(splitCharLengthData(dataList.get(index).getCfDisplyName(),20));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));

						} else if (colCt == 2) {
							appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCfConfId(), dataList.get(index).getCfConfigOption(), para);
							cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));

							// rh.setText(dataList.get(index).getCfConfigOption());
						} else if (colCt == 3) {
							rh.setText(splitCharLengthData(dataList.get(index).getCfConfOptDispName(),20));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						}else if (colCt == 4) {
							rh.setText(splitCharLengthData(dataList.get(index).getLegacyFACode(),10));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						}else if (colCt == 5) {
							rh.setText(splitCharLengthData(dataList.get(index).getOptSubType(),10));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						} 
						else if (colCt == 6) {
							rh.setText(splitCharLengthData(dataList.get(index).getKeyInValue(),10));
							//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
						} 
					
					/*else if (colCt == 4) {
						if (!PLMUtils.isEmpty(dataList.get(index).getCrName())) {
							appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCrId(), dataList.get(index).getCrName(), para);
						}
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));

					} else if (colCt == 5) {
						rh.setText(dataList.get(index).getCrTitle());
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
					}*/
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell

			colCt = 0;
			rowCt++;
		} // for row

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}


	 private  void mergeCellHorizontally(XWPFTable table,CTShd ctshd, int row, int fromCol, int toCol) {
		  for(int colIndex = fromCol; colIndex <= toCol; colIndex++){
		   CTHMerge hmerge = CTHMerge.Factory.newInstance();
		   if(colIndex == fromCol){
		    // The first merged cell is set with RESTART merge value
		    hmerge.setVal(STMerge.RESTART);
		   } else {
		    // Cells which join (merge) the first one, are set with CONTINUE
		    hmerge.setVal(STMerge.CONTINUE);
		   }
		   XWPFTableCell cell = table.getRow(row).getCell(colIndex);
		   // Try getting the TcPr. Not simply setting an new one every time.
		   CTTcPr tcPr = cell.getCTTc().getTcPr();
		   if (tcPr != null) {
		    tcPr.setHMerge(hmerge);
		   } else {
		    // only set an new TcPr if there is not one already
		    tcPr = CTTcPr.Factory.newInstance();
		    tcPr.setHMerge(hmerge);
		    cell.getCTTc().setTcPr(tcPr);
		    ctshd.setFill("F2DCDB");
		   }
		  }
		 }
	/**
	 * Appends an external hyperlink to the paragraph.
	 * 
	 * @param url
	 *            The URL to the external target
	 * @param text
	 *            The linked text
	 * @param paragraph
	 *            the paragraph the link will be appended to.
	 */
	public static void appendExternalHyperlink(String url, String text, XWPFParagraph paragraph) {

		// Add the link as External relationship
		String id = paragraph.getDocument().getPackagePart().addExternalRelationship(url, XWPFRelation.HYPERLINK.getRelation()).getId();

		// Append the link and bind it to the relationship
		CTHyperlink cLink = paragraph.getCTP().addNewHyperlink();
		cLink.setId(id);

		// Create the linked text
		CTText ctText = CTText.Factory.newInstance();
		ctText.setStringValue(text);
		CTR ctr = CTR.Factory.newInstance();
		ctr.setTArray(new CTText[] { ctText });

		CTRPr rpr = ctr.addNewRPr();
		CTColor colour = CTColor.Factory.newInstance();
		colour.setVal("0000FF");
		rpr.setColor(colour);
		CTRPr rpr1 = ctr.addNewRPr();
		rpr1.addNewU().setVal(STUnderline.SINGLE);

		// Insert the linked text into the link
		cLink.setRArray(new CTR[] { ctr });

	}

	public void createLogicalFeaturesTable(String filePathDocx, List<PLMCntrtSmryRptData> dataList, String pcName, 
			String pcDesc, String isOption, String templatePath) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);
		
		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3
		// Sorting list
		Collections.sort(dataList, new SortFeatureDispName());

		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setStyle("Heading2"); // 4
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.setColor("000000");
		tmpRun.setText("Logical Features (MLIs) - " + pcName + "  :  " + pcDesc);
		tmpRun.setBold(true);
		XWPFRun tmpRun1 = tmpParagraph.createRun();
		tmpRun1.setColor("FF0000");
		tmpRun1.setText(isOption);
		tmpRun1.setBold(true);
		tmpParagraph.addRun(tmpRun1);
		/*
		 * tmpRun.setUnderline(UnderlinePatterns.THICK); tmpRun.setFontSize(10);
		 * tmpRun.addBreak();
		 */
		// XWPFDocument doc = new XWPFDocument();

		int nRows = dataList.size() + 1;
		//int[] cols = { 20, 1000, 1000, 2000, 5000 };
		int nCols = 5;
		int index = 0;
		XWPFTable table = doc.createTable(nRows, nCols);
		// table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));
		// Set the table style. If the style is not defined, the table style
		// will become "Normal".
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("StyledTable");

		// Get a list of the rows in the table
		List<XWPFTableRow> rows = table.getRows();
		int rowCt = 0;
		int colCt = 0;
		for (int i = 0; i < rows.size(); i++) {
			XWPFTableRow row = table.getRow(i);
			// get table row properties (trPr)
			CTTrPr trPr = row.getCtRow().addNewTrPr();
			// set row height; units = twentieth of a point, 360 = 0.25"
			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(10));

			// get the cells in this row
			List<XWPFTableCell> cells = row.getTableCells();
			// add content to each cell
			for (int j = 0; j < cells.size(); j++) {
				XWPFTableCell cell = row.getCell(j);
				// get a table cell properties element (tcPr)
				CTTcPr tcpr = cell.getCTTc().addNewTcPr();
				// set vertical alignment to "center"
				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				// create cell color element
				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {
					// header row
					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {
					// odd row
					ctshd.setFill("EDF2F8");
				}

				// get 1st paragraph in cell's paragraph list
				XWPFParagraph para = cell.getParagraphs().get(0);
				// create a run to contain the content
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");
				// style cell as desired
				/*
				 * if (colCt == nCols - 1) { // last column is 10pt Courier //
				 * rh.setFontSize(10); // rh.setFontFamily("Courier"); }
				 */
				if (rowCt == 0) {
					if (colCt == 0) {
						// header row
						rh.setText("Level");
					} else if (colCt == 1) {
						rh.setText("Feature Display Name");
					} else if (colCt == 2) {
						rh.setText("Feature Name");
					} else if (colCt == 3) {
						rh.setText("Feature Description");
					} else if (colCt == 4) {
						rh.setText("Related CR");
					}

					rh.setBold(true);
					para.setAlignment(ParagraphAlignment.CENTER);
				} else if (rowCt % 2 == 0) {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(dataList.get(index).getLfLevel());
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					} else if (colCt == 1) {
						rh.setText(dataList.get(index).getLfFeatDsplName());
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					} else if (colCt == 2) {
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
						appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getLfFeatId(), dataList.get(index).getLfFeatName(), para);
						// rh.setText(dataList.get(index).getLfFeatName());
						
					} else if (colCt == 3) {
						rh.setText(splitCharLengthData(dataList.get(index).getLfFeatDesc(),40));
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					} else if (colCt == 4) {
						rh.setText(splitCharLengthData(dataList.get(index).getCrName(),20));
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > dataList.size()) {
					break;
				} else {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(dataList.get(index).getLfLevel());
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					} else if (colCt == 1) {
						rh.setText(dataList.get(index).getLfFeatDsplName());
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					} else if (colCt == 2) {
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
						appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getLfFeatId(), dataList.get(index).getLfFeatName(), para);
						// rh.setText(dataList.get(index).getLfFeatName());
						} else if (colCt == 3) {
						rh.setText(splitCharLengthData(dataList.get(index).getLfFeatDesc(),40));
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					} else if (colCt == 4) {
						rh.setText(splitCharLengthData(dataList.get(index).getCrName(),20));
						//cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell

			colCt = 0;
			rowCt++;
		} // for row

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	/**
	 * This method is used to createConfigurationeEndItemsTable
	 * 
	 * @param FileOutputStream
	 * @param filepathDocx
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * @param pcName
	 * @param pcDesc
	 * @param templatePath
	 */

	public void createConfigurationeEndItemsTable(String filePathDocx, List<PLMCntrtSmryRptData> dataList, String pcName, 
			String pcDesc, String isOption, String templatePath) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3
		// Sorting list
		Collections.sort(dataList, new SortCIDisplayName());

		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		tmpParagraph.setStyle("Heading2"); // 4
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.setColor("000000");
		tmpRun.setText("Configuration End Items (MLIs) - " + pcName + "  :  " + pcDesc);
		tmpRun.setBold(true);
		XWPFRun tmpRun1 = tmpParagraph.createRun();
		tmpRun1.setColor("FF0000");
		tmpRun1.setText(isOption);
		tmpRun1.setBold(true);
		tmpParagraph.addRun(tmpRun1);
		/*
		 * tmpRun.setUnderline(UnderlinePatterns.THICK); tmpRun.setFontSize(10);
		 * tmpRun.addBreak();
		 */
		// XWPFDocument doc = new XWPFDocument();

		int nRows = dataList.size() + 1;
		int[] cols = { 20, 1000, 1000, 2000, 5000 };
		int nCols = 5;
		int index = 0;
		XWPFTable table = doc.createTable(nRows, nCols);
		// table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));
		// Set the table style. If the style is not defined, the table style
		// will become "Normal".
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("StyledTable");

		// Get a list of the rows in the table
		List<XWPFTableRow> rows = table.getRows();
		int rowCt = 0;
		int colCt = 0;
		for (int i = 0; i < rows.size(); i++) {
			XWPFTableRow row = table.getRow(i);
			// get table row properties (trPr)
			CTTrPr trPr = row.getCtRow().addNewTrPr();
			// set row height; units = twentieth of a point, 360 = 0.25"
			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(10));

			// get the cells in this row
			List<XWPFTableCell> cells = row.getTableCells();
			// add content to each cell
			for (int j = 0; j < cells.size(); j++) {
				XWPFTableCell cell = row.getCell(j);
				// get a table cell properties element (tcPr)
				CTTcPr tcpr = cell.getCTTc().addNewTcPr();
				// tcpr.addNewTcW().setW(BigInteger.valueOf(2000));
				// set vertical alignment to "center"
				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				// create cell color element
				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {
					// header row
					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {
					// odd row
					ctshd.setFill("EDF2F8");
				}

				// get 1st paragraph in cell's paragraph list
				XWPFParagraph para = cell.getParagraphs().get(0);
				// create a run to contain the content
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");
				// style cell as desired
				/*
				 * if (colCt == nCols - 1) { // last column is 10pt Courier //
				 * rh.setFontSize(10); // rh.setFontFamily("Courier"); }
				 */
				if (rowCt == 0) {
					if (colCt == 0) {
						// header row
						rh.setText("Level");
					} else if (colCt == 1) {
						rh.setText("CI Display Name");
					} else if (colCt == 2) {
						rh.setText("CI Name");
					} else if (colCt == 3) {
						rh.setText("CI Description");
					} else if (colCt == 4) {
						rh.setText("Related CR");
					}
					rh.setBold(true);
					para.setAlignment(ParagraphAlignment.CENTER);
				} else if (rowCt % 2 == 0) {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(dataList.get(index).getCeLevel());
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					} else if (colCt == 1) {
						rh.setText(dataList.get(index).getCeDispName());
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					} else if (colCt == 2) {
						appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCeId(), dataList.get(index).getCeName(), para);
						// rh.setText(dataList.get(index).getCeName());
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					} else if (colCt == 3) {

						rh.setText(splitString(dataList.get(index).getCeDesc()));
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					} else if (colCt == 4) {
						rh.setText(dataList.get(index).getCrName());
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > dataList.size()) {
					break;
				} else {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(dataList.get(index).getCeLevel());
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					} else if (colCt == 1) {
						rh.setText(dataList.get(index).getCeDispName());
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					} else if (colCt == 2) {
						appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCeId(), dataList.get(index).getCeName(), para);
						// rh.setText(dataList.get(index).getCeName());
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					} else if (colCt == 3) {

						rh.setText(splitString(dataList.get(index).getCeDesc()));
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					} else if (colCt == 4) {
						rh.setText(dataList.get(index).getCrName());
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(cols[j]));
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell

			colCt = 0;
			rowCt++;
		} // for row

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	/**
	 * This method is used to createCustomerRequirementsTable
	 * 
	 * @param FileOutputStream
	 * @param filepathDocx
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * @param pcName
	 * @param pcDesc
	 * @param templatePath
	 */
	public void createCustomerRequirementsTable(String filePathDocx, List<PLMCntrtSmryRptData> dataList, String pcName, String pcDesc, String templatePath) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3

		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		tmpParagraph.setStyle("Heading3"); // 4
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.setColor("000000");
		tmpRun.setText("CustomerRequirements Data - " + pcName + " : " + pcDesc);
		tmpRun.setBold(true);
		/*
		 * tmpRun.setUnderline(UnderlinePatterns.THICK); tmpRun.setFontSize(10);
		 * tmpRun.addBreak();
		 */
		// XWPFDocument doc = new XWPFDocument();

		int nRows = dataList.size() + 1;
		int nCols = 5;
		int index = 0;
		XWPFTable table = doc.createTable(nRows, nCols);
		table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));
		// Set the table style. If the style is not defined, the table style
		// will become "Normal".
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("StyledTable");

		// Get a list of the rows in the table
		List<XWPFTableRow> rows = table.getRows();
		int rowCt = 0;
		int colCt = 0;
		for (XWPFTableRow row : rows) {
			// get table row properties (trPr)
			CTTrPr trPr = row.getCtRow().addNewTrPr();
			// set row height; units = twentieth of a point, 360 = 0.25"
			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(10));

			// get the cells in this row
			List<XWPFTableCell> cells = row.getTableCells();
			// add content to each cell
			for (XWPFTableCell cell : cells) {
				// get a table cell properties element (tcPr)
				CTTcPr tcpr = cell.getCTTc().addNewTcPr();
				// set vertical alignment to "center"
				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				// create cell color element
				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {
					// header row
					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {
					// odd row
					ctshd.setFill("EDF2F8");
				}

				// get 1st paragraph in cell's paragraph list
				XWPFParagraph para = cell.getParagraphs().get(0);
				// create a run to contain the content
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");
				// style cell as desired
				/*
				 * if (colCt == nCols - 1) { // last column is 10pt Courier //
				 * rh.setFontSize(10); // rh.setFontFamily("Courier"); }
				 */
				if (rowCt == 0) {
					if (colCt == 0) {
						// header row
						rh.setText("CR Name");
					} else if (colCt == 1) {
						rh.setText("CR Title");
					} else if (colCt == 2) {
						rh.setText("CR State");
					} else if (colCt == 3) {
						rh.setText("Satisfied By");
					} else if (colCt == 4) {
						rh.setText("Enterprise IDNFR");
					}

					rh.setBold(true);
					para.setAlignment(ParagraphAlignment.CENTER);
				} else if (rowCt % 2 == 0) {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(dataList.get(index).getCrName());
					} else if (colCt == 1) {
						rh.setText(dataList.get(index).getCrTitle());
					} else if (colCt == 2) {
						rh.setText(dataList.get(index).getCrState());
					} else if (colCt == 3) {
						rh.setText(dataList.get(index).getCrSatisfiedBy());
					} else if (colCt == 4) {
						rh.setText(dataList.get(index).getCrEntrpIdnFr());
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > dataList.size()) {
					break;
				} else {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(dataList.get(index).getCrName());
					} else if (colCt == 1) {
						rh.setText(dataList.get(index).getCrTitle());
					} else if (colCt == 2) {
						rh.setText(dataList.get(index).getCrState());
					} else if (colCt == 3) {
						rh.setText(dataList.get(index).getCrSatisfiedBy());
					} else if (colCt == 4) {
						rh.setText(dataList.get(index).getCrEntrpIdnFr());
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell

			colCt = 0;
			rowCt++;
		} // for row

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	/**
	 * This method is used to createcCostObjectsTable
	 * 
	 * @param FileOutputStream
	 * @param filepathDocx
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * @param pcName
	 * @param pcDesc
	 * @param templatePath
	 */

	public void createcCostObjectsTable(String filePathDocx, List<PLMCntrtSmryRptData> dataList, String pcName, 
			String pcDesc, String isOption, String templatePath) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3

		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		tmpParagraph.setStyle("Heading2"); // 4
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.setColor("000000");
		tmpRun.setText("Cost Objects Data - " + pcName + "  :  " + pcDesc);
		tmpRun.setBold(true);
		XWPFRun tmpRun1 = tmpParagraph.createRun();
		tmpRun1.setColor("FF0000");
		tmpRun1.setText(isOption);
		tmpRun1.setBold(true);
		tmpParagraph.addRun(tmpRun1);
		/*
		 * tmpRun.setUnderline(UnderlinePatterns.THICK); tmpRun.setFontSize(10);
		 * tmpRun.addBreak();
		 */
		// XWPFDocument doc = new XWPFDocument();

		int nRows = dataList.size() + 1;
		int nCols = 6;
		int index = 0;
		XWPFTable table = doc.createTable(nRows, nCols);
		table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));
		// Set the table style. If the style is not defined, the table style
		// will become "Normal".
		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("StyledTable");

		// Get a list of the rows in the table
		List<XWPFTableRow> rows = table.getRows();
		int rowCt = 0;
		int colCt = 0;
		for (XWPFTableRow row : rows) {
			// get table row properties (trPr)
			CTTrPr trPr = row.getCtRow().addNewTrPr();
			// set row height; units = twentieth of a point, 360 = 0.25"
			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(10));

			// get the cells in this row
			List<XWPFTableCell> cells = row.getTableCells();
			// add content to each cell
			for (XWPFTableCell cell : cells) {
				// get a table cell properties element (tcPr)
				CTTcPr tcpr = cell.getCTTc().addNewTcPr();
				// set vertical alignment to "center"
				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				// create cell color element
				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {
					// header row
					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {
					// odd row
					ctshd.setFill("EDF2F8");
				}

				// get 1st paragraph in cell's paragraph list
				XWPFParagraph para = cell.getParagraphs().get(0);
				// create a run to contain the content
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");
				// style cell as desired
				/*
				 * if (colCt == nCols - 1) { // last column is 10pt Courier //
				 * rh.setFontSize(10); // rh.setFontFamily("Courier"); }
				 */
				if (rowCt == 0) {
					if (colCt == 0) {
						// header row
						rh.setText("Name");
					} else if (colCt == 1) {
						rh.setText("CR Name");
					} else if (colCt == 2) {
						rh.setText("CO State");
					} else if (colCt == 3) {
						rh.setText("CR State");
					} else if (colCt == 4) {
						rh.setText("CO Logical Feature");
					} else if (colCt == 5) {
						rh.setText("CO Logical Feature Desc");
					}

					rh.setBold(true);
					para.setAlignment(ParagraphAlignment.CENTER);
				} else if (rowCt % 2 == 0) {
					// even row
					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						// rh.setText(dataList.get(index).getCoName());
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
						appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCoId(), dataList.get(index).getCoName(), para);
					} else if (colCt == 1) {
						// rh.setText(dataList.get(index).getCoCrName());
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
						appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCoCrId(), dataList.get(index).getCoCrName(), para);
					} else if (colCt == 2) {
						rh.setText(dataList.get(index).getCoState());
					} else if (colCt == 3) {
						rh.setText(dataList.get(index).getCoCrState());
					} else if (colCt == 4) {
						rh.setText(dataList.get(index).getCoFeatName());
					} else if (colCt == 5) {
						rh.setText(splitCharLengthData(dataList.get(index).getCoDesc(),40));
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > dataList.size()) {
					break;
				} else {
					// even row
					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						// rh.setText(dataList.get(index).getCoName());
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
						appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCoId(), dataList.get(index).getCoName(), para);
					} else if (colCt == 1) {
						cell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(2000));
						appendExternalHyperlink(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataList.get(index).getCoCrId(), dataList.get(index).getCoCrName(), para);
						// rh.setText(dataList.get(index).getCoCrName());
					} else if (colCt == 2) {
						rh.setText(dataList.get(index).getCoState());
					} else if (colCt == 3) {
						rh.setText(dataList.get(index).getCoCrState());
					} else if (colCt == 4) {
						rh.setText(dataList.get(index).getCoFeatName());
					} else if (colCt == 5) {
						rh.setText(splitCharLengthData(dataList.get(index).getCoDesc(),40));
					}
					// rh.setFontSize(10);
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell

			colCt = 0;
			rowCt++;
		} // for row

		// write the file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	/**
	 * This method is used to createTpLvlBomPrtTable
	 * 
	 * @param FileOutputStream
	 * @param filepathDocx
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * @param pcName
	 * @param pcDesc
	 * @param templatePath
	 */
	public void createTpLvlBomPrtTable(String filePathDocx, List<PLMCntrtSmryRptData> dataList, String pcName, String pcDesc, String templatePath) throws Exception {
		// open an existing empty document with styles already defined
		LOG.info("Opening existing document -------> " + filePathDocx);

		XWPFDocument doc = new XWPFDocument(new FileInputStream(filePathDocx));
		XWPFDocument template = new XWPFDocument(new FileInputStream(new File(templatePath))); // 1
		XWPFStyles headStyle = doc.createStyles(); // 2
		headStyle.setStyles(template.getStyle()); // 3

		XWPFParagraph tmpParagraph = doc.createParagraph();
		tmpParagraph.setAlignment(ParagraphAlignment.LEFT);
		tmpParagraph.setStyle("Heading3"); // 4
		XWPFRun tmpRun = tmpParagraph.createRun();
		tmpRun.setColor("000000");
		tmpRun.setText("Top Level BOM Part - " + pcName + "  :  " + pcDesc);
		tmpRun.setBold(true);
		/*
		 * tmpRun.setUnderline(UnderlinePatterns.THICK); tmpRun.setFontSize(10);
		 * tmpRun.addBreak();
		 */
		// XWPFDocument doc = new XWPFDocument();

		int nRows = dataList.size() + 1;
		int nCols = 1;
		int index = 0;
		XWPFTable table = doc.createTable(nRows, nCols);
		table.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));

		CTTblPr tblPr = table.getCTTbl().getTblPr();
		CTString styleStr = tblPr.addNewTblStyle();
		styleStr.setVal("StyledTable");

		List<XWPFTableRow> rows = table.getRows();
		int rowCt = 0;
		int colCt = 0;
		for (XWPFTableRow row : rows) {

			CTTrPr trPr = row.getCtRow().addNewTrPr();

			CTHeight ht = trPr.addNewTrHeight();
			ht.setVal(BigInteger.valueOf(10));

			List<XWPFTableCell> cells = row.getTableCells();

			for (XWPFTableCell cell : cells) {

				CTTcPr tcpr = cell.getCTTc().addNewTcPr();

				CTVerticalJc va = tcpr.addNewVAlign();
				va.setVal(STVerticalJc.CENTER);

				CTShd ctshd = tcpr.addNewShd();
				ctshd.setColor("auto");
				ctshd.setVal(STShd.CLEAR);
				if (rowCt == 0) {

					ctshd.setFill("A7BFDE");
				} else if (rowCt % 2 == 0) {

					ctshd.setFill("D3DFEE");
				} else {

					ctshd.setFill("EDF2F8");
				}

				XWPFParagraph para = cell.getParagraphs().get(0);
				XWPFRun rh = para.createRun();
				rh.setFontSize(8);
				rh.setFontFamily("Geinspira");

				/*
				 * if (colCt == nCols - 1) { }
				 */
				if (rowCt == 0) {
					if (colCt == 0) {
						rh.setText("To Name");
					}
					rh.setBold(true);
					para.setAlignment(ParagraphAlignment.CENTER);
				} else if (rowCt % 2 == 0) {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(dataList.get(index).getTopName());
					}
					para.setAlignment(ParagraphAlignment.LEFT);
				} else if (rowCt > dataList.size()) {
					break;
				} else {

					index = rowCt;
					index = index - 1;
					if (colCt == 0) {
						rh.setText(dataList.get(index).getTopName());
					}
					para.setAlignment(ParagraphAlignment.LEFT);
				}
				colCt++;
			} // for cell
			colCt = 0;
			rowCt++;
		} // for row
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filePathDocx));
			doc.write(fos);
		} catch (FileNotFoundException fne) {
			PLMUtils.checkException(fne.getMessage());
		} finally {
			if (fos != null) {
				fos.close();
			}
		}
	}

	/**
	 * 
	 * class to sort list of object of type String.
	 * 
	 */
	private static class SortFeatureDispName implements Comparator<PLMCntrtSmryRptData>, Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMCntrtSmryRptData aString, PLMCntrtSmryRptData bString) {
			return PLMUtils.chkNull(aString.getLfFeatDsplName()).compareTo(PLMUtils.chkNull(bString.getLfFeatDsplName()));
		}
	}

	/**
	 * 
	 * class to sort list of object of type String.
	 * 
	 */
	private static class SortCIDisplayName implements Comparator<PLMCntrtSmryRptData>, Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMCntrtSmryRptData aString, PLMCntrtSmryRptData bString) {
			return PLMUtils.chkNull(aString.getCeDispName()).compareTo(PLMUtils.chkNull(bString.getCeDispName()));
		}
	}

	
	/*Added By Raju to create Excel file*/
	
	
	/**
	 * This method is used for Generating Contract Summary Report
	 * @throws PWiException 
	 * 
	 * 
	 */

	public void generateContSmryRptExcel() throws PWiException {
		LOG.info("Levellllllllllllllllllllllll ---------------->" + level);
		List<String> hwList = new ArrayList<String>(finalDataMap.keySet());
		LOG.info("finalDataMap in generateContSmryRpt >>>>>>>>>>>>>>>>>>>>"+finalDataMap);
		userName = UserInfoPortalUtil.getInstance().getUserName();
		userEmail = UserInfoPortalUtil.getInstance().getUserEmail();	
		
		if (!PLMUtils.isEmptyList(hwList)&& subcomponentsList.size() != 0) {
			alertMsg = PLMConstants.CNTRCT_SMRY_RPT_MAIL_ALERT_MSG;
			taskExecutor.execute(new ExcelGenerationThread());
		} else if(PLMUtils.isEmptyList(hwList)){
			alertMsg = PLMConstants.CNTRCT_SMRY_RPT_SLECT_NONE_ALERT_MSG;
		} else if(subcomponentsList.size() == 0){
			alertMsg =  PLMConstants.CNTRCT_SMRY_SUB_COMP_UNCHK;
		}
	}
	
	
	/**
	 * Background Process Thread
	 */
	private class ExcelGenerationThread implements Runnable {
		public ExcelGenerationThread() {
		}

		public void run() {
			List<PLMCntrtSmryRptData> pcInfoListOld = new ArrayList<PLMCntrtSmryRptData>(pcInfoList);
			List<String> hwList = new ArrayList<String>(finalDataMap.keySet());
			LOG.info("finalDataMap------------------>"+finalDataMap);
			if (!PLMUtils.isEmptyList(hwList)) {
				List<PLMCntrtSmryRptData> pcInfoListNew = new ArrayList<PLMCntrtSmryRptData>();
				if (!PLMUtils.isEmptyList(pcInfoListOld)) {
					for (PLMCntrtSmryRptData data : pcInfoListOld) {
						LOG.info("In DocGenerationThread PC Name -------> " + data.getPrdtConfigNm() + "PC Desc ------>" + data.getPrdtConfigDesc());
						pcInfoListNew.add(data);
					}

				}
				 List<String> prdtTypeListCrsNew = new ArrayList<String>();
				 List<String> prdtTypeListClHbNew = new ArrayList<String>();
				
				if (!PLMUtils.isEmptyList( prdtTypeListCrs)) {
					 for (String data : prdtTypeListCrs) {
							prdtTypeListCrsNew.add(data);
						}
				 }
				 if (!PLMUtils.isEmptyList( prdtTypeListClHb)) {
					 for (String data : prdtTypeListClHb) {
							prdtTypeListClHbNew.add(data);
						}
				 }
				 LOG.info("In DocGenerationThread prdtTypeListCrsNew  -------> " + prdtTypeListCrsNew);
				 LOG.info("In DocGenerationThread prdtTypeListClHbNew -------> " + prdtTypeListClHbNew);
				 String contractNumLcl =contractNum;
				 String levelLcl =level;
				 boolean optSubTypFlg = notRequireFlg;
				 boolean partTypeOpenLcl=partTypeAllOpen;
				 boolean categoryFlagLcl =categoryFlag;
				 List<String> selCstGrpListLcl =new ArrayList<String>();
				 if(cstGrpAllOpen==true){
					 for(SelectItem sel:cstGrpListSI){
						 selCstGrpListLcl.add(new String(sel.getLabel()));
					 }
				 }else{
					 selCstGrpListLcl =selCstGrpList;
				 }
				 
				 List<String> selPcListLcl =new ArrayList<String>();
				 if(pcAllOpen==true){
					 for(SelectItem sel:pcInfoListSI){
						 String str[]=new String(sel.getLabel()).split(" ");
						 selPcListLcl.add(str[0]);
					 }
				 }else{
					 selPcListLcl =selPcList;
				 }
				if (hwList.size() > 1) {
					List<String> hwList1 = new ArrayList<String>();

					for (int i = 0; i < hwList.size(); i++) {
						hwList1.add(hwList.get(i));
					}

					// List<String> subCompList = new ArrayList<String>();
					List<String> subCompList = finalDataMap.get(hwList.get(0));
					List<String> subCompList1 = new ArrayList<String>();

					for (int i = 0; i < subCompList.size(); i++) {
						subCompList1.add(subCompList.get(i));
					}
					LOG.info("Selected sub componenets in DocGenerationThread method --------------------> " + subCompList);
					generateExcel(hwList1, subCompList1, pcInfoListNew, prdtTypeListCrsNew, prdtTypeListClHbNew, contractNumLcl,
							levelLcl,optSubTypFlg,partTypeOpenLcl,categoryFlagLcl,selCstGrpListLcl,selPcListLcl);
					hwList1.clear();
					subCompList1.clear();
					pcInfoListNew.clear();
				} else {
					List<List<String>> valueList = new ArrayList<List<String>>(finalDataMap.values());
					List<String> hwList1 = new ArrayList<String>();

					for (int i = 0; i < hwList.size(); i++) {
						hwList1.add(hwList.get(i));
					}
					// List<String> subCompList = new ArrayList<String>();
					List<String> subCompList = valueList.get(0);
					List<String> subCompList1 = new ArrayList<String>();

					for (int i = 0; i < subCompList.size(); i++) {
						subCompList1.add(subCompList.get(i));
					}
					LOG.info("Selected sub componenets in DocGenerationThread method --------------------> " + subCompList);
					generateExcel(hwList1, subCompList1, pcInfoListNew, prdtTypeListCrsNew, prdtTypeListClHbNew, contractNumLcl,
							levelLcl,optSubTypFlg,partTypeOpenLcl,categoryFlagLcl,selCstGrpListLcl,selPcListLcl);
					hwList1.clear();
					subCompList1.clear();
					pcInfoListNew.clear();
				}

			}
		}
	}
	
	
	/**
	 * This method is used to generate Document
	 * 
	 * @param hardwareLsit
	 * @param subCompList
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * 
	 */
	public void generateExcel(List<String> hwList, List<String> subCompList, 
			List<PLMCntrtSmryRptData> pcInfoListOld, List<String> prdtTypeListCrsNew, 
			List<String> prdtTypeListClHbNew,String contractNumRpt,String levelclVal,boolean optSbTFlg,boolean partTypeAll,boolean categryFlag,
			 List<String> selCstGrpListLcl,List<String> selPcListLcl) {
		
		boolean optSubTypFlg = optSbTFlg;
		String contractNumVal = contractNumRpt;
		String crsLvlLcl = levelclVal;
        boolean partTypeOpenLcl=partTypeAll;
        boolean categoryFlagLcl=categryFlag;
		List<PLMCntrtSmryRptData> pcInfoListNew = new ArrayList<PLMCntrtSmryRptData>();
		List<String> selCstGrpListLocal =selCstGrpListLcl;
		List<String> selPcListLocal =selPcListLcl;
		for (PLMCntrtSmryRptData data : pcInfoListOld) {
			LOG.info("In generateDoc PC Name -------> " + data.getPrdtConfigNm() + "PC Desc ------>" + data.getPrdtConfigDesc());
			pcInfoListNew.add(data);
		}

		List<String> hwList1 = new ArrayList<String>();
		for (int i = 0; i < hwList.size(); i++) {
			hwList1.add(hwList.get(i));
		}

		List<String> subCompList1 = new ArrayList<String>();
		for (int i = 0; i < subCompList.size(); i++) {
			subCompList1.add(subCompList.get(i));
		}

		String filePathExcel = "";
//		String tempPathDocx = "";
		String cntrtSmryTempPath = "";
		try {
			final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
			Date uniqDate = new Date();
			String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
			String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
			filePathExcel = fileDir + resourceBundle.getString("CONTRACT_SMRY_REPORT_NAME") + contractNumVal + "_" + uniqTime + ".xlsx";
//			tempPathDocx = fileDir + resourceBundle.getString("CONTRACT_SMRY_REPORT_TEMPLATE_NAME");
			cntrtSmryTempPath = fileDir + resourceBundle.getString("CONTRACT_SMRY_REPORT_TEMPLATE_EXCEL");//template
			LOG.info("filePathDocx--------->" + filePathExcel);
//			FileOutputStream fos = new FileOutputStream(new File(filePathExcel));
			saveContractSmryRprtExcelFile(contractNumVal, filePathExcel, cntrtSmryTempPath, hwList1, subCompList1, 
					pcInfoListNew, prdtTypeListCrsNew, prdtTypeListClHbNew, optSubTypFlg, crsLvlLcl,partTypeOpenLcl,categoryFlagLcl,selCstGrpListLocal,selPcListLocal);
		} catch (Exception e) {
			deleteFiles(filePathExcel);
			e.printStackTrace();
		} finally {
			pcInfoListNew.clear();
			hwList1.clear();
			subCompList1.clear();
		}
	}
	
	
	
	/**
	 * This method is used to save Contract Summary Report Document
	 * 
	 * @param FileOutputStream
	 * @param contractNum
	 * @param filePathDocx
	 * @param templatePath
	 * @param cntrtSmryTempPath
	 * @param hwList
	 * @param subCompList
	 * @param List
	 *            <PLMCntrtSmryRptData>
	 * 
	 */
	public void saveContractSmryRprtExcelFile(String contractNumRpt, String filePathExcel, 
			String cntrtSmryTempPath, List<String> hwList, List<String> subCompList, 
			List<PLMCntrtSmryRptData> pcInfoListOld, List<String> prdtTypeListCrsNew, 
			List<String> prdtTypeListClHbNew, boolean optSbTFlg, String crsLvlVal,boolean partTypeAll,boolean categryFlg,
			List<String> selCstGrpListLcl,List<String> selPcListLcl) throws Exception {
		boolean optSubTypFlg = optSbTFlg;
		String contractNumInSaverpt = contractNumRpt;
		String crsLvlLcl = crsLvlVal;
		boolean partTypeOpenLcl=partTypeAll;
		boolean categoryFlagLcl=categryFlg;
		List<String> selCstGrpListLocal = selCstGrpListLcl;
		List<String> selPcListLocal = selPcListLcl;
		LOG.info("contractNum in ---> saveContractSmryRprtDocxFile " + contractNumInSaverpt);
		List<PLMCntrtSmryRptData> pcInfoListNew = new ArrayList<PLMCntrtSmryRptData>();
		for (PLMCntrtSmryRptData data : pcInfoListOld) {
			LOG.info("In saveContractSmryRprtDocxFile PC Name -------> " + data.getPrdtConfigNm() + "PC Desc ------>" + data.getPrdtConfigDesc());
			pcInfoListNew.add(data);
		}

		List<String> hwList1 = new ArrayList<String>();
		for (int i = 0; i < hwList.size(); i++) {
			hwList1.add(hwList.get(i));
			LOG.info("Hardware product values in saveContractSmryRprtDocxFile method before queries execution **************" + hwList.get(i));
		}
		LOG.info("subCompList>>>>>>>>>>>>>>>>>>>"+subCompList);
		List<String> subCompList1 = new ArrayList<String>();
		for (int i = 0; i < subCompList.size(); i++) {
			subCompList1.add(subCompList.get(i));
			LOG.info("Subcomponent values in saveContractSmryRprtDocxFile method before queries execution ****************" + subCompList.get(i));
		}

		String from = PLMConstants.COST_CHG_MAIL_FROM;	
		
		String to = userEmail;		
		LOG.info("userEmail >>>>>>>>>>>>>>>>>>>>"+to);
		String toAddressee = userName;
		LOG.info("userName >>>>>>>>>>>>>>>>>>>>"+toAddressee);
			
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.CNTRT_SMRY_RPT_MAIL_SUBJECT + contractNumInSaverpt;
		StringBuffer mailBody = new StringBuffer().append(toAddressee);
		StringBuffer mailNoDataBody = new StringBuffer();
		File file = null;
		try {

			LOG.info("contractNum>>>>>>>" + contractNumInSaverpt);
			if (contractNumInSaverpt != null) {
				mailBody.append(PLMConstants.CNTRT_SMRY_RPT_MAIL_CONTENT).append(contractNumInSaverpt).append(".").append(PLMConstants.COST_CHG_MAIL_SIGNATURE).append(PLMConstants.COST_CHG_MAIL_FOOTER);

				mailNoDataBody.append(toAddressee).append(PLMConstants.COST_CHNG_NO_CONTENT_BODY).append(contractNumInSaverpt).append(".").append(PLMConstants.COST_CHG_MAIL_SIGNATURE).append(PLMConstants.COST_CHG_MAIL_FOOTER);
				
				LOG.info("Creating  New document");
				createExcelDocument(contractNumInSaverpt, filePathExcel, cntrtSmryTempPath, subCompList1, 
						hwList1, prdtTypeListCrsNew, prdtTypeListClHbNew, pcInfoListNew, optSubTypFlg, crsLvlLcl,partTypeOpenLcl,categoryFlagLcl,selCstGrpListLocal,selPcListLocal); // 1
				LOG.info("End");

				file = new File(filePathExcel);
				LOG.info("document has been generated with name : " + filePathExcel);

			} else {
				LOG.info("Not able to generate the Contract Sumamry report.");
			}
			long sizeInBytes = 0;
			if (file != null) {
				sizeInBytes = file.length();
			}
			if (sizeInBytes > 0) {
				LOG.info("File Size for Contract Summary Report " + sizeInBytes / 1000 + "KB");
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathExcel);
				LOG.info("Report Attachment Mail sent successfully.");
			} else {
				PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
				LOG.info("No data Mail sent successfully.");
			}

		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@saveContractSmryRprtDocxFile: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(), from, to, subject, toAddressee, PLMConstants.LTTR_MAIL_SIGNATURE);
		} finally {
			deleteFiles(filePathExcel);
			/*if (file != null) {
				file.delete();
			}*/
			pcInfoListNew.clear();
			hwList1.clear();
			subCompList1.clear();
		}
	}
	
	
	
	public void createExcelDocument(String contractNumRpt, String filePathExcel, String cntrtSmryTempPath, 
			List<String> subCompList, List<String> hwList1, List<String> prdtTypeListCrsNew, 
			List<String> prdtTypeListClHbNew, List<PLMCntrtSmryRptData> pcInfoListOld,
			boolean optSbTFlg, String crsLvlVal,boolean partTypeAll,boolean categryFlag,
			 List<String> selCstGrpListLcl,List<String> selPcListLcl) throws IOException {
		
		boolean optSubTypFlg = optSbTFlg;
		String contractNumInSaverpt = contractNumRpt;
		String crsLvlLcl = crsLvlVal;
		boolean partTypeOpenLcl=partTypeAll;
		boolean categoryFlagLcl=categryFlag;
		List<String> selCstGrpListLocal =selCstGrpListLcl;
		List<String> selPcListLocal =selPcListLcl;
		List<PLMCntrtSmryRptData> pcInfoListNew = new ArrayList<PLMCntrtSmryRptData>();
		if (!PLMUtils.isEmptyList(pcInfoListOld)) {
			for (PLMCntrtSmryRptData data : pcInfoListOld) {
				LOG.info("In saveContractSmryRprtDocxFile PC Name -------> " + data.getPrdtConfigNm() + "PC Desc ------>" + data.getPrdtConfigDesc());
				pcInfoListNew.add(data);
			}
		}
		
		LOG.info("Creating New document -------> " + filePathExcel);
		LOG.info("templatePath------------->" + filePathExcel);
		FileOutputStream fileOut = null;
		try{
		fileOut = new FileOutputStream(filePathExcel);
		SXSSFWorkbook workbook = new SXSSFWorkbook(); // 1
		SXSSFSheet sheet =  (SXSSFSheet) workbook.createSheet(contractNumInSaverpt);
		XSSFCellStyle headerStyle = (XSSFCellStyle) workbook.createCellStyle();
		headerStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		headerStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		headerStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		headerStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		headerStyle.setFillForegroundColor(IndexedColors.WHITE.getIndex()); 
		headerStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
		XSSFFont font = (XSSFFont) workbook.createFont(); 
		font.setFontName(PLMConstants.EXCEL_FONT_NAME);
		font.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		font.setFontHeightInPoints((short)10);
		headerStyle.setFont(font);
		headerStyle = setBorderStyle(headerStyle);
		headerStyle.setFillForegroundColor(HSSFColor.PALE_BLUE.index);
		
		XSSFCellStyle cellBoldStyle = (XSSFCellStyle) workbook.createCellStyle();
		cellBoldStyle = setBorderStyle(cellBoldStyle);
		cellBoldStyle.setFont(font);
		
        XSSFFont underLinedFont = (XSSFFont) workbook.createFont();
        underLinedFont.setUnderline(HSSFFont.U_SINGLE);
        underLinedFont.setColor(IndexedColors.BLUE.getIndex());
		XSSFCellStyle hyperLinkStyle = (XSSFCellStyle) workbook.createCellStyle();				
		hyperLinkStyle = setBorderStyle(hyperLinkStyle);
		hyperLinkStyle.setFont(underLinedFont);
		hyperLinkStyle.setWrapText(true);
       
		
		XSSFFont nonBoldFont = (XSSFFont) workbook.createFont();
		nonBoldFont.setFontHeightInPoints((short)10);
		nonBoldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
		XSSFCellStyle contentStyle = (XSSFCellStyle) workbook.createCellStyle();				
		contentStyle = setBorderStyle(contentStyle);
		contentStyle.setFont(nonBoldFont);
		contentStyle.setWrapText(true);
		XSSFCellStyle contentDecimalStyle = (XSSFCellStyle) workbook.createCellStyle();				
		contentDecimalStyle = setBorderStyle(contentDecimalStyle);
		contentDecimalStyle.setFont(nonBoldFont);
		DataFormat format = workbook.createDataFormat();
		contentDecimalStyle.setDataFormat(format.getFormat("0.00000"));
				
		XSSFFont noRecordFont = (XSSFFont) workbook.createFont(); 
		noRecordFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		noRecordFont.setColor(Font.COLOR_RED);
		noRecordFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
		noRecordFont.setFontHeightInPoints((short)10);
		XSSFCellStyle noRecordCellStyle = (XSSFCellStyle) workbook.createCellStyle();
		noRecordCellStyle = setBorderStyle(noRecordCellStyle);
		noRecordCellStyle.setFont(noRecordFont);

		int count = 0;
		SXSSFRow row = (SXSSFRow)sheet.createRow(count);
		SXSSFCell cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
		
		cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
		cell.setCellValue("Contract Summary Report");
		cell.setCellStyle(cellBoldStyle);
		++count;
		row = (SXSSFRow)sheet.createRow(++count);
		cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
		cell.setCellValue("Contract Name: "+contractNumInSaverpt);
		cell.setCellStyle(cellBoldStyle);
		
		row = (SXSSFRow)sheet.createRow(++count);
		cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
		cntrctList.clear();
		cntrctList = contractSumrReptService.fetchCntrInfo(contractNumInSaverpt);
		if (null != cntrctList && cntrctList.size() > 0) {
			cell.setCellValue("Contract Description: "+cntrctList.get(0).getCntrtDesc());
		} else {
			cell.setCellValue("Contract Description: ");
		}
		cell.setCellStyle(cellBoldStyle);
		
		List<PLMCntrtSmryRptData> prjNameList = contractSumrReptService.fetchProjectNameList(contractNumInSaverpt);
	
	
		for (int j = 0; j < subCompList.size(); j++) {
			if (subCompList.get(j).equalsIgnoreCase("Project Summary")) {
				count = createProjectsDataTable(workbook, sheet, count, prjNameList, cellBoldStyle);
				count = createNameRoleDataTable(workbook, sheet, count, prjNameList, cellBoldStyle, contentStyle, headerStyle, contractNumInSaverpt);
				count = createHardwareBuildDataTable(workbook, sheet, count, cellBoldStyle, contentStyle, headerStyle, prdtTypeListClHbNew, contractNumInSaverpt,partTypeOpenLcl);
				count = createPlantLevelPartDataTable(workbook, sheet, count, cellBoldStyle, contentStyle, headerStyle, contractNumInSaverpt);		
			}

			else if (subCompList.get(j).equalsIgnoreCase("CLIN Data")) {
				count = createClinDataTable(workbook, sheet, count, cellBoldStyle, contentStyle, headerStyle, prdtTypeListClHbNew, contractNumInSaverpt,partTypeOpenLcl);
			}
			else if (subCompList.get(j).equalsIgnoreCase("CRS Data")) {
				count = createCrsDataTable(workbook, sheet, count, cellBoldStyle, contentStyle, headerStyle,hyperLinkStyle, prdtTypeListCrsNew, contractNumInSaverpt, crsLvlLcl,partTypeOpenLcl);
			}
			else if (subCompList.get(j).equalsIgnoreCase("PRS Data")) {
				count = createPrsDataTable(workbook, sheet, count, cellBoldStyle, contentStyle, headerStyle,hyperLinkStyle, contractNumInSaverpt);
			}

		}

		if(subCompList.size()>0 && subCompList.contains("Configuration Features") && isCategoryFlag()){
			//for(Map.Entry<String, List<String>> costGrpkey : finalCostMapLocal.entrySet()){
				createConfigFeatureTab(contractNumInSaverpt, workbook, hwList1, subCompList, filePathExcel, 
						cellBoldStyle, contentStyle, headerStyle, hyperLinkStyle, pcInfoListNew, optSubTypFlg,categoryFlagLcl,selCstGrpListLocal,selPcListLocal);
			//}
				
		}
		
		
		
		if(subCompList.size()>0){
			boolean flag = (subCompList.contains("Configuration Features") && !isCategoryFlag())||
			subCompList.contains("Logical Features (MLIs)") ||
			subCompList.contains("Configuration End Items (MLIs)") ||
			subCompList.contains("Cost Objects Data");
			LOG.info("******************** flag**************"+flag);
			if(flag){
				for (int i = 0; i < hwList1.size(); i++) {
					createNewTab(contractNumInSaverpt, workbook, hwList1, subCompList, i, filePathExcel, 
							cellBoldStyle, contentStyle, headerStyle, hyperLinkStyle, pcInfoListNew, optSubTypFlg,categoryFlagLcl,selCstGrpListLocal,selPcListLocal,
							crsLvlLcl,prdtTypeListClHbNew,partTypeOpenLcl);
				}// for
				
			}
		}
		workbook.write(fileOut);
		fileOut.close();
		}catch (PLMCommonException e) {
			deleteFiles(filePathExcel);
			e.printStackTrace();
		}finally{
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@createExcelDocument: ", e);
				throw e;
			}
		}
	}
	
	//Adding Configuration Feature Tab for System name Caterigozation
	public void  createConfigFeatureTab(String contractNumRpt, SXSSFWorkbook workbook, List<String> hwList1, 
			List<String> subCompList, String filePathExcel,XSSFCellStyle cellBoldStyle, 
			XSSFCellStyle contentStyle, XSSFCellStyle headerStyle, XSSFCellStyle hyperLinkStyle, 
			List<PLMCntrtSmryRptData> pcInfoListOld, boolean optSbTFlg,boolean categryFlag,
			List<String> selCstGrpListLcl,List<String> selPcListLcl) throws PLMCommonException, IOException{
		boolean optSubTypFlg = optSbTFlg;
		String contractNumInSaverpt = contractNumRpt;
		boolean categoryFlagLcl=categryFlag;
		LOG.info("Entering createConfigFeatureTab File Method");
		FileOutputStream fileOut = null;
		List<String> selCstGrpListLocal =selCstGrpListLcl;
		List<String> selPcListLocal =selPcListLcl;
		List<PLMCntrtSmryRptData> pcInfoListNew = new ArrayList<PLMCntrtSmryRptData>();
		if (!PLMUtils.isEmptyList(pcInfoListOld)) {
			for (PLMCntrtSmryRptData data : pcInfoListOld) {
				pcInfoListNew.add(data);
			}
		}
		try{
					fileOut = new FileOutputStream(filePathExcel);
					Map<String, List<String>> finalCostMap = new HashMap<String, List<String>>();
					
					//adding pcNames based on Cost Groups
					 List<String> pcNmList = new ArrayList<String>();
					for(int i=0;i<selCstGrpListLocal.size();i++){
						for (PLMCntrtSmryRptData pcNms : pcInfoListNew) {
							if(pcNms.getPcCstGrp().equalsIgnoreCase(selCstGrpListLocal.get(i))){
								for(String selPc :selPcListLocal){
									if(selPc.equalsIgnoreCase(pcNms.getPrdtConfigNm())){
								     pcNmList.add(pcNms.getPrdtConfigNm());
									}
								}
							}
						}
						finalCostMap.put(selCstGrpListLocal.get(i), pcNmList);
						pcNmList = new ArrayList<String>();
					}
					
					int count = 0;
					SXSSFSheet sheet = (SXSSFSheet) workbook.createSheet("Configuration Features");
					SXSSFRow row = (SXSSFRow)sheet.createRow(count);
					row.createCell(PLMConstants.EXCEL_COL_ZERO);
				for (int j = 0; j < subCompList.size(); j++) {
						if (subCompList.get(j).equalsIgnoreCase("Configuration Features") && isCategoryFlag()) {
							boolean noSubTypeFlag=false;
							List<String> pcNameList=new ArrayList<String>();
							String costGroup="";
							//for(Map.Entry<String, List<String>> costGrpkey : finalCostMap.entrySet()){
							for(int i=0;i<selCstGrpListLocal.size();i++){
								if(finalCostMap.containsKey(selCstGrpListLocal.get(i))){
								costGroup=selCstGrpListLocal.get(i);
								pcNameList=finalCostMap.get(selCstGrpListLocal.get(i));
								LOG.info("costGrpkey.getKey() >>>>>>>>>>>>>>"+costGroup);
								LOG.info("costGrpkey.getValue() >>>>>>>>>>>>>>"+pcNameList);
								if(!PLMUtils.isEmptyList(pcNameList)){
									List<PLMCntrtSmryRptData> tempData = contractSumrReptService.fetchConfFeaturesCostGrpData(contractNumInSaverpt,pcNameList,optSubTypFlg,noSubTypeFlag,categoryFlagLcl);
									count = createCstGrpConfFeatDataTable(workbook, sheet, count, cellBoldStyle, contentStyle, headerStyle, costGroup, pcNameList, tempData, filePathExcel, hyperLinkStyle);
								}
							  }
							}
							
						} 
				}// for
		}catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@createConfigFeatureTab File: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@createConfigFeatureTab: ", e);
				throw e;
			}
		}
		LOG.info("Exiting createConfigFeatureTab File Method");
		}

	
	
public void  createNewTab(String contractNumRpt, SXSSFWorkbook workbook, List<String> hwList1, 
		List<String> subCompList, int objIndr, String filePathExcel,XSSFCellStyle cellBoldStyle, 
		XSSFCellStyle contentStyle, XSSFCellStyle headerStyle, XSSFCellStyle hyperLinkStyle, 
		List<PLMCntrtSmryRptData> pcInfoListOld, boolean optSbTFlg,boolean categryFlag,List<String>selCstGrpListLocal,List<String>selPcListLcl,
		String crsLvlLcl,List<String> prdtTypeListClHbNew, boolean partTypeOpen) throws PLMCommonException, IOException{
	boolean optSubTypFlg = optSbTFlg;
	String contractNumInSaverpt = contractNumRpt;
	boolean categoryFlagLcl=categryFlag;
	List<String>selCstGrpListLcl =selCstGrpListLocal;
	List<String> selPcListLocal =selPcListLcl;
	String crsLvl =crsLvlLcl;
	List<String> prdtTypeListLcl =prdtTypeListClHbNew;
	boolean partTypeOpenLcl =partTypeOpen;
	
	LOG.info("Entering createNewTab File Method");
	FileOutputStream fileOut = null;
	
	List<PLMCntrtSmryRptData> pcInfoListNew = new ArrayList<PLMCntrtSmryRptData>();
	for (PLMCntrtSmryRptData data : pcInfoListOld) {
		LOG.info("In saveContractSmryRprtDocxFile PC Name -------> " + data.getPrdtConfigNm() + "PC Desc ------>" + data.getPrdtConfigDesc());
		pcInfoListNew.add(data);
	}
	try{

				fileOut = new FileOutputStream(filePathExcel);
				String pcName = "";
				String pcDesc = "";
				String str = "";
				String hardwareKey="";
				String pcNameKey="";
				String[] harWareKeyList =hwList1.get(objIndr).split("~");
				hardwareKey = harWareKeyList[0];
				pcNameKey =harWareKeyList[1];
				
				
				List<PLMCntrtSmryRptData> pcInfoListSel = new ArrayList<PLMCntrtSmryRptData>();
				
				for(int i=0;i<selCstGrpListLcl.size();i++){
					for (PLMCntrtSmryRptData pcNms : pcInfoListNew) {
						if(pcNms.getPcCstGrp().equalsIgnoreCase(selCstGrpListLcl.get(i))){
							for(String selPc:selPcListLocal){
								if(selPc.equalsIgnoreCase(pcNms.getPrdtConfigNm())){
								 pcInfoListSel.add(pcNms);
								}
							}
						}
					}
				}
				
				if (!PLMUtils.isEmptyList(pcInfoListSel)) {
					for (PLMCntrtSmryRptData data : pcInfoListSel) {
						if (data.getHwPrdctNm().equals(hardwareKey) && data.getPrdtConfigNm().equals(pcNameKey)) {
							pcName = data.getPrdtConfigNm();
							pcDesc = data.getPrdtConfigDesc();
							
							if ("Yes".equalsIgnoreCase(data.getIsOption())) {
								str = " (OPTIONS PC)";
							} else {
								str = "";
							}
//						}
//					}
//				}

						int count = 0;
				SXSSFSheet sheet = (SXSSFSheet) workbook.createSheet(pcName + str);
				SXSSFRow row = (SXSSFRow)sheet.createRow(count);
				row.createCell(PLMConstants.EXCEL_COL_ZERO);
				for (int j = 0; j < subCompList.size(); j++) {
						if (subCompList.get(j).equalsIgnoreCase("Configuration Features") && !isCategoryFlag()) {
							boolean noSubTypeFlag=false;
							List<PLMCntrtSmryRptData> tempData = contractSumrReptService.fetchConfFeaturesPCNmData(contractNumInSaverpt,pcName,optSubTypFlg,noSubTypeFlag,categoryFlagLcl);
						 	count = createConfFeatDataTable(workbook, sheet, count, cellBoldStyle, contentStyle, headerStyle, pcName, pcDesc, str, tempData, filePathExcel, hyperLinkStyle);
							
						} else if (subCompList.get(j).contains("Logical Features (MLI")) {
							List<PLMCntrtSmryRptData> crsList = contractSumrReptService.fetchCRSInfo(contractNumInSaverpt);
							List<String> crsRecList = new ArrayList<String>();
							 for (int a = 0; a < crsList.size(); a++) {
								crsRecList.add(crsList.get(a).getCrsName());
						 	  }
							 List<PLMCntrtSmryRptData> tempData = contractSumrReptService.fetcLogicalFeauturesData(hardwareKey, contractNumInSaverpt,crsRecList);
							count = createLogicalFeatDataTable(workbook, sheet, count, cellBoldStyle, contentStyle, headerStyle, pcName, pcDesc, str, tempData, filePathExcel, hyperLinkStyle);
						   
						} else if (subCompList.get(j).contains("Configuration End Items (MLI")) {
							List<PLMCntrtSmryRptData> crsList = contractSumrReptService.fetchCRSInfo(contractNumInSaverpt);
							List<String> crsRecList = new ArrayList<String>();
							 for (int a = 0; a < crsList.size(); a++) {
								crsRecList.add(crsList.get(a).getCrsName());
						 	  }
							 List<PLMCntrtSmryRptData> tempData = contractSumrReptService.fetcConfigEndItemsData(hardwareKey, contractNumInSaverpt,crsRecList);
							count = createConfEndItmsDataTable(workbook, sheet, count, cellBoldStyle, contentStyle, headerStyle, pcName, pcDesc, str, tempData, filePathExcel, hyperLinkStyle);
						   
						} else if (subCompList.get(j).equalsIgnoreCase("Cost Objects Data")) {
							List<PLMCntrtSmryRptData> tempData = contractSumrReptService.fetCostObjectsData(crsLvl,prdtTypeListLcl,partTypeOpenLcl,contractNumInSaverpt,pcName);
							count = createcCostObjectsTable(workbook, sheet, count, cellBoldStyle, contentStyle, headerStyle, pcName, pcDesc, str, tempData, filePathExcel, hyperLinkStyle);
						}
				}// for
			   }
			 }
	      }
	}catch (FileNotFoundException e) {
		LOG.log(Level.ERROR, "Exception@createSummaryReportTab File: ", e);
		throw e;
	}  finally {
		try {
			if (fileOut != null) {
				fileOut.close();
			}
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@createNewTab: ", e);
			throw e;
		}
	}
	LOG.info("Exiting createNewTab File Method");
	}
	
	public int createProjectsDataTable(SXSSFWorkbook workbook, SXSSFSheet sheet, int count, List<PLMCntrtSmryRptData> prjNameList, XSSFCellStyle cellBoldStyle) {

		// Code to display Projects data
		int countLcl = count;

		if (!PLMUtils.isEmptyList(prjNameList)) {

			PLMCntrtSmryRptData itoPrj = new PLMCntrtSmryRptData();
			PLMCntrtSmryRptData otrPrj = new PLMCntrtSmryRptData();

			for (int i = 0; i < prjNameList.size(); i++) {
				if (prjNameList.get(i).getProjectName().contains("ITO")) {
					itoPrj = prjNameList.get(i);
				} else {
					otrPrj = prjNameList.get(i);
				}
			}
			
			++countLcl;
			SXSSFRow row = (SXSSFRow)sheet.createRow(++countLcl);
			SXSSFCell cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
			cell.setCellValue("Projects");
			cell.setCellStyle(cellBoldStyle);

			++countLcl;
			row = (SXSSFRow) sheet.createRow(++countLcl);
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
			cell.setCellValue("ITO Project Name : " + itoPrj.getProjectName() + "          " + "ITO Project Title : " + itoPrj.getProjectTitle() + "        ");
			cell.setCellStyle(cellBoldStyle);
			++countLcl;
			row = (SXSSFRow) sheet.createRow(++countLcl);
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
			cell.setCellValue("OTR Project Name : " + otrPrj.getProjectName() + "           " + "OTR Project Title : " + otrPrj.getProjectTitle() + "        ");
			cell.setCellStyle(cellBoldStyle);

		}
		// End Projects Data

		return countLcl;

	}
	
	public int createNameRoleDataTable(SXSSFWorkbook workbook, SXSSFSheet sheet, 
			int count, List<PLMCntrtSmryRptData> prjNameList, XSSFCellStyle cellBoldStyle, 
			XSSFCellStyle contentStyle, XSSFCellStyle headerStyle, String contractNumRpt) throws PLMCommonException {
		//Code to display Name and role table
		String contractLcl = contractNumRpt;
		int countLcl = count;
		++countLcl;
		SXSSFRow row = (SXSSFRow)sheet.createRow(++countLcl);
		SXSSFCell cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
		cell.setCellValue("ITO Project Members");
		cell.setCellStyle(cellBoldStyle);
		
		Map<String, List<PLMCntrtSmryRptData>> nameRoleMap = new HashMap<String, List<PLMCntrtSmryRptData>>();
		for (int a = 0; a < prjNameList.size(); a++) {
			List<PLMCntrtSmryRptData> nrList = contractSumrReptService.fetchEmpNamesNRoles(contractLcl, prjNameList.get(a).getProjectName());
			nameRoleMap.put(prjNameList.get(a).getProjectName(), nrList);
		}
				List<String> keyList = new ArrayList<String>(nameRoleMap.keySet());
		
		for (int i = 0; i < keyList.size(); i++) {
			
			List<PLMCntrtSmryRptData> tempNRList = nameRoleMap.get(keyList.get(i));
			
			if (keyList.get(i).endsWith("ITO")) {			
				++countLcl;
				row = (SXSSFRow)sheet.createRow(++countLcl);
				cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
				cell.setCellValue("ITO Project Members : " + keyList.get(i));
				cell.setCellStyle(cellBoldStyle);
			} else {
				++countLcl;
				row = (SXSSFRow)sheet.createRow(++countLcl);
				cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
				cell.setCellValue("OTR Project Members : " + keyList.get(i));
				cell.setCellStyle(cellBoldStyle);
			}
		
		LOG.info("nameRoleMap Size in saveContractSmryRprtDocxFile --------->" + nameRoleMap.size());
		LOG.info("Creating createEmpNameandRoleTable");
		
	    List<PLMCntrtSmryRptData> nameRoleList = new ArrayList<PLMCntrtSmryRptData>(tempNRList);
		
		
		if(!PLMUtils.isEmptyList(nameRoleList)) {
			
			String[] colNames = {"Name","GE ROLE","SSO"};						
			
			row = (SXSSFRow) sheet.createRow(++countLcl);
			row = (SXSSFRow) sheet.createRow(++countLcl);
			
			for ( int j = 0 ; j < colNames.length; j++ ) {
				cell = (SXSSFCell)  row.createCell(j);
				cell. setCellValue(colNames[j]);
				cell.setCellStyle(headerStyle);
			}
			
			for(int k = 0; k < nameRoleList.size(); k++) {
				PLMCntrtSmryRptData dataObj = nameRoleList.get(k);
				row = (SXSSFRow) sheet.createRow(++countLcl);
				
				cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellStyle(contentStyle);
				cell.setCellValue(dataObj.getEmpName());
				
				cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellStyle(contentStyle);
				cell.setCellValue(dataObj.getEmpRole());
				
				cell = (SXSSFCell)  row.createCell(PLMConstants.EXCEL_COL_TWO);
				cell.setCellStyle(contentStyle);
				cell.setCellValue(dataObj.getSso());
				
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, (short) 7000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, (short) 9000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, (short) 7000);
			
		}
					
		}
	}
	//End Code to display Name and role table
	return countLcl;
	}
	
	public int createHardwareBuildDataTable(SXSSFWorkbook workbook, SXSSFSheet sheet, int count, 
			XSSFCellStyle cellBoldStyle, XSSFCellStyle contentStyle, XSSFCellStyle headerStyle, 
			List<String> prdtTypeListClHbNew, String contractNumInSaverpt,boolean partTypeAll) throws PLMCommonException {
		// Code to display Hardware Build Data table
		String contractLcl = contractNumInSaverpt;
		int countLcl = count;
		++countLcl;
		SXSSFRow row = (SXSSFRow) sheet.createRow(++countLcl);
		SXSSFCell cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
		cell.setCellValue("Hardware Build Data");
		cell.setCellStyle(cellBoldStyle);

		List<PLMCntrtSmryRptData> hardwareBuildDataList = contractSumrReptService.fetchHardwareBuildInfo(contractLcl, prdtTypeListClHbNew,partTypeAll);
		LOG.info("hardwareBuildDataList size -------> " + hardwareBuildDataList.size());
		LOG.info("hardwareBuildDataList Data -------> " + hardwareBuildDataList.toString());
		LOG.info("Creating createHrdwreBuildTable");

		if (!PLMUtils.isEmptyList(hardwareBuildDataList)) {

			String[] colNames = { "Clin Name", "Build Name", "Unit Serial Number", "Shop Order Number", "Build Type", "State", "Part Number" };

			sheet.createRow(++countLcl);
			SXSSFRow row2 = (SXSSFRow) sheet.createRow(++countLcl);

			for (int j = 0; j < colNames.length; j++) {
				cell = (SXSSFCell) row2.createCell(j);
				cell.setCellValue(colNames[j]);
				cell.setCellStyle(headerStyle);
			}

			for (int k = 0; k < hardwareBuildDataList.size(); k++) {
				PLMCntrtSmryRptData dataObj = hardwareBuildDataList.get(k);
				SXSSFRow row3 = (SXSSFRow) sheet.createRow(++countLcl);

				SXSSFCell cell2 = (SXSSFCell) row3.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell2.setCellStyle(contentStyle);
				cell2.setCellValue(dataObj.getHbClinNm());

				SXSSFCell cell3 = (SXSSFCell) row3.createCell(PLMConstants.EXCEL_COL_ONE);
				cell3.setCellStyle(contentStyle);
				cell3.setCellValue(dataObj.getHbldNm());

				SXSSFCell cell4 = (SXSSFCell) row3.createCell(PLMConstants.EXCEL_COL_TWO);
				cell4.setCellStyle(contentStyle);
				cell4.setCellValue(dataObj.getHbSrlNum());

				SXSSFCell cell5 = (SXSSFCell) row3.createCell(PLMConstants.EXCEL_COL_THREE);
				cell5.setCellStyle(contentStyle);
				cell5.setCellValue(dataObj.getShpOrdrNum());

				SXSSFCell cell6 = (SXSSFCell) row3.createCell(PLMConstants.EXCEL_COL_FOUR);
				cell6.setCellStyle(contentStyle);
				cell6.setCellValue(dataObj.getHbldType());

				SXSSFCell cell7 = (SXSSFCell) row3.createCell(PLMConstants.EXCEL_COL_FIVE);
				cell7.setCellStyle(contentStyle);
				cell7.setCellValue(dataObj.getHbldState());

				SXSSFCell cell8 = (SXSSFCell) row3.createCell(PLMConstants.EXCEL_COL_SIX);
				cell8.setCellStyle(contentStyle);
				cell8.setCellValue(dataObj.getHbPartNum());

				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, (short) 9800);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, (short) 8000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, (short) 4800);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE, (short) 4800);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR, (short) 4800);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE, (short) 4500);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX, (short) 4000);

			}

		}
		// End Code to display Hardware Build Data table
		return countLcl;
	}
	
	public int createPlantLevelPartDataTable(SXSSFWorkbook workbook, SXSSFSheet sheet, int count, 
			XSSFCellStyle cellBoldStyle, XSSFCellStyle contentStyle, XSSFCellStyle headerStyle,
			String contractNumVal) throws PLMCommonException {
		
		// Code to display Plant Level Part Name  Data table
		String contractLcl = contractNumVal;
		int countLcl = count;
		 List<PLMCntrtSmryRptData> PLPList = contractSumrReptService.fetchPLPList(contractLcl);
		LOG.info("PLPList size -------> " + PLPList.size());
		LOG.info("PLPList Data -------> " + PLPList.toString());
		LOG.info("Creating createPLPTable");
		if(PLPList.size()>0){
			++countLcl;
			SXSSFRow row = (SXSSFRow)sheet.createRow(++countLcl);
			SXSSFCell cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
			cell.setCellValue("Plant Level Part Name : " +PLPList.get(0).getPLPName() );
			cell.setCellStyle(cellBoldStyle);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, (short) 7000);
		}else{
			++countLcl;
			SXSSFRow row = (SXSSFRow)sheet.createRow(++countLcl);
			SXSSFCell cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
			cell.setCellValue("Plant Level Part Name : ");
			cell.setCellStyle(cellBoldStyle);
			sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, (short) 7000);
		}
			
		//End Code to display Plant Level Part Name  Data table	
		return countLcl;
	}
	

	public int createClinDataTable(SXSSFWorkbook workbook, SXSSFSheet sheet, int count, 
			XSSFCellStyle cellBoldStyle, XSSFCellStyle contentStyle, XSSFCellStyle headerStyle, 
			List<String> prdtTypeListClHbNew, String contractNumVal,boolean partTypeAll) throws PLMCommonException {
		// Code to display Customer Deliverables � CLIN Data table

		int countLcl = count;
		String contractLcl = contractNumVal;
		++countLcl;
		SXSSFRow row = (SXSSFRow) sheet.createRow(++countLcl);
		SXSSFCell cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
		cell.setCellValue("Customer Deliverables � CLIN Data");
		cell.setCellStyle(cellBoldStyle);

		List<PLMCntrtSmryRptData> clinDataList = contractSumrReptService.fetchClinInfo(contractLcl,prdtTypeListClHbNew,partTypeAll);
		LOG.info("clinDataList size -------> " + clinDataList.size());

		if (!PLMUtils.isEmptyList(clinDataList)) {

			String[] colNames = { "Name", "Description", "Product", "Type", "Initial Delivery Date", "Status", "Liquidated Damages Indicator", "Satisfied By Schedule Task", "CI Number", "CEI Quantity" };

			sheet.createRow(++countLcl);
			SXSSFRow row1 = (SXSSFRow) sheet.createRow(++countLcl);

			for (int j = 0; j < colNames.length; j++) {
				SXSSFCell cell1 = (SXSSFCell) row1.createCell(j);
				cell1.setCellValue(colNames[j]);
				cell1.setCellStyle(headerStyle);
			}

			for (int k = 0; k < clinDataList.size(); k++) {
				PLMCntrtSmryRptData dataObj = clinDataList.get(k);
				SXSSFRow row2 = (SXSSFRow) sheet.createRow(++countLcl);

				SXSSFCell cell2 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell2.setCellStyle(contentStyle);
				cell2.setCellValue(dataObj.getClinNameParent());

				SXSSFCell cell3 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ONE);
				cell3.setCellStyle(contentStyle);
				cell3.setCellValue(dataObj.getClinDesc());

				SXSSFCell cell4 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_TWO);
				cell4.setCellStyle(contentStyle);
				cell4.setCellValue(dataObj.getSowParagraph());

				SXSSFCell cell5 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_THREE);
				cell5.setCellStyle(contentStyle);
				cell5.setCellValue(dataObj.getClinTasking());

				SXSSFCell cell6 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_FOUR);
				if (dataObj.getClinInitialDeliveryDate() != null) {
					SimpleDateFormat dtfrmt = new SimpleDateFormat("MMM dd, yyyy");
					Date uniqDate = dataObj.getClinInitialDeliveryDate();
					String cDate = dtfrmt.format(uniqDate);
					cell6.setCellValue(cDate);
				}
				cell6.setCellStyle(contentStyle);

				SXSSFCell cell7 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_FIVE);
				cell7.setCellStyle(contentStyle);
				cell7.setCellValue(dataObj.getClinStatus());

				SXSSFCell cell8 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_SIX);
				cell8.setCellStyle(contentStyle);
				cell8.setCellValue(dataObj.getClinIndicator());

				SXSSFCell cell9 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_SEVEN);
				cell9.setCellStyle(contentStyle);
				cell9.setCellValue(dataObj.getSatisfiedByTask());

				SXSSFCell cell10 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_EIGHT);
				cell10.setCellStyle(contentStyle);
				cell10.setCellValue(dataObj.getCiNumber());

				SXSSFCell cell11 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_NINE);
				cell11.setCellStyle(contentStyle);
				cell11.setCellValue(dataObj.getCeiQuantity());

				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, (short) 7000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, (short) 9000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, (short) 7000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE, (short) 13000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR, (short) 3000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE, (short) 4000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX, (short) 8000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN, (short) 8000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT, (short) 4000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE, (short) 4000);
			}

		}

		// End Code to display Customer Deliverables � CLIN Data table

		return countLcl;
	}
	
	
	public int createCrsDataTable(SXSSFWorkbook workbook, SXSSFSheet sheet, 
			int count, XSSFCellStyle cellBoldStyle, 
			XSSFCellStyle contentStyle, XSSFCellStyle headerStyle, XSSFCellStyle hyperLinkStyle, 
			List<String> prdtTypeListCrsNew, String contractNumVal, String crsLvlVal,boolean partTypeAll) throws PLMCommonException {

		// Code to display Special Requirements � CRS Data table
		int countLcl = count;
		String contractLcl = contractNumVal;
		String crsLvlLcl = crsLvlVal;
		XSSFCreationHelper helper= (XSSFCreationHelper) workbook.getCreationHelper();
		Map<String, List<PLMCntrtSmryRptData>> crsMap = new HashMap<String, List<PLMCntrtSmryRptData>>();
		List<PLMCntrtSmryRptData> crsList = contractSumrReptService.fetchCRSInfo(contractLcl);
		for (int a = 0; a < crsList.size(); a++) {
			List<PLMCntrtSmryRptData> crsRecList = contractSumrReptService.fetchCRSRecursiveData(contractLcl, crsList.get(a).getCrsName(), crsLvlLcl, prdtTypeListCrsNew,partTypeAll);
			LOG.info("crsRecList.size() in MB ------------->   " + crsRecList.size());
			crsMap.put(crsList.get(a).getCrsName(), crsRecList);
		}
		LOG.info("crsMap.size()------------->" + crsMap.size());

		List<String> crsKeyList = new ArrayList<String>(crsMap.keySet());
		for (int i = 0; i < crsKeyList.size(); i++) {
			List<PLMCntrtSmryRptData>  cList = crsMap.get(crsKeyList.get(i));
			LOG.info("creating createCRSRecursiveTable");

			++countLcl;
			SXSSFRow row = (SXSSFRow) sheet.createRow(++countLcl);
			SXSSFCell cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
			cell.setCellValue("Special Requirements � CRS Data : " + crsKeyList.get(i));
			cell.setCellStyle(cellBoldStyle);
		
			if (!PLMUtils.isEmptyList(cList)) {

				String[] colNames = { "Level", "Name", "Title", "Type", "State", "Product Type" };
				
				

				sheet.createRow(++countLcl);
				SXSSFRow row1 = (SXSSFRow) sheet.createRow(++countLcl);

				for (int j = 0; j < colNames.length; j++) {
					SXSSFCell cell1 = (SXSSFCell) row1.createCell(j);
					cell1.setCellValue(colNames[j]);
					cell1.setCellStyle(headerStyle);
				}

				for (int k = 0; k < cList.size(); k++) {
					PLMCntrtSmryRptData dataObj = cList.get(k);
					SXSSFRow row2 = (SXSSFRow) sheet.createRow(++countLcl);

					SXSSFCell cell2 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell2.setCellStyle(contentStyle);
					cell2.setCellValue(dataObj.getCrsrLevel());
					
					SXSSFCell cell3 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ONE);
					cell3.setCellStyle(hyperLinkStyle);
					XSSFHyperlink url_link=helper.createHyperlink(Hyperlink.LINK_URL);
					
					 if(dataObj.isTopCrsLvlFlag()){
							url_link.setAddress(resourceBundle.getString("CRS_TOPLVL_HyperLink1")+ dataObj.getCrsrId()
									+resourceBundle.getString("CRS_TOPLVL_HyperLink2"));
							cell3.setHyperlink(url_link);
							cell3.setCellValue(dataObj.getCrsrName());
					 }else if(dataObj.isCrsChapterFlg()){
						 url_link.setAddress(resourceBundle.getString("Chapter_HyperLink1")+ dataObj.getCrsrId()
										+resourceBundle.getString("Chapter_HyperLink2"));
							cell3.setHyperlink(url_link);
							cell3.setCellValue(dataObj.getCrsrName());
					}else{
						url_link.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataObj.getCrsrId());
						cell3.setHyperlink(url_link);
						cell3.setCellValue(dataObj.getCrsrName());
					}

				    SXSSFCell cell4 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_TWO);
					cell4.setCellStyle(contentStyle);
					cell4.setCellValue(dataObj.getCrsrTitle());

					SXSSFCell cell5 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_THREE);
					cell5.setCellStyle(contentStyle);
					cell5.setCellValue(dataObj.getCrsrRevision());

					SXSSFCell cell6 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell6.setCellStyle(contentStyle);
					cell6.setCellValue(dataObj.getCrsrtoType());
					
					SXSSFCell cell7 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell7.setCellStyle(contentStyle);
					cell7.setCellValue(dataObj.getPcCstGrp());
					
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, (short) 7000);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, (short) 9000);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, (short) 7000);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE, (short) 13000);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR, (short) 3000);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE, (short) 3500);
				}

			}
		}
		// End Code to display Special Requirements � CRS Data table

		return countLcl;
	}
	
	
	public int createPrsDataTable(SXSSFWorkbook workbook, SXSSFSheet sheet, int count, 
			XSSFCellStyle cellBoldStyle, XSSFCellStyle contentStyle, 
			XSSFCellStyle headerStyle, XSSFCellStyle hyperLinkStyle,String contractNumVal) throws PLMCommonException {
		
// Code to display Product Requirement Spec Data table

		int countLcl = count;
		String contractLcl = contractNumVal;
		XSSFCreationHelper helper= (XSSFCreationHelper) workbook.getCreationHelper();
		Map<String, List<PLMCntrtSmryRptData>> prsMap = new HashMap<String, List<PLMCntrtSmryRptData>>();
		List<PLMCntrtSmryRptData> prdtRqmntSpecList = contractSumrReptService.fetchPrdtRqmntSpecInfo(contractLcl);
		for (int a = 0; a < prdtRqmntSpecList.size(); a++) {
			List<PLMCntrtSmryRptData>  prsRecList = contractSumrReptService.fetchPRSRecursiveData(prdtRqmntSpecList.get(a).getPrdtRqmntSpecNm());
			LOG.info("prsRecList.size() in MB ------------->   " + prsRecList.size());
			prsMap.put(prdtRqmntSpecList.get(a).getPrdtRqmntSpecNm(), prsRecList);
		}
		LOG.info("prsMap.size()------------->" + prsMap.size());
		
		List<String> prsRecKeyList = new ArrayList<String>(prsMap.keySet());
		for (int i = 0; i < prsRecKeyList.size(); i++) {
			List<PLMCntrtSmryRptData> pList = prsMap.get(prsRecKeyList.get(i));
			LOG.info("creating createPRSRecursiveTable");
		
		++countLcl;
		SXSSFRow row = (SXSSFRow)sheet.createRow(++countLcl);
		SXSSFCell cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO); 
		cell.setCellValue("Product Requirement Spec Data : "+prsRecKeyList.get(i));
		cell.setCellStyle(cellBoldStyle);
		
		if(!PLMUtils.isEmptyList(pList)) {
			String[] colNames = {"Level","Name","Title","Description","Data Value","Unit of Measure (A)", "Unit of Measure (B)", "Requirement Notes"};						
			
			sheet.createRow(++countLcl);
			SXSSFRow row1 = (SXSSFRow) sheet.createRow(++countLcl);
			
			for ( int j = 0 ; j < colNames.length; j++ ) {
				SXSSFCell cell1 = (SXSSFCell)  row1.createCell(j);
				cell1. setCellValue(colNames[j]);
				cell1.setCellStyle(headerStyle);
			}
			
			for(int k = 0; k < pList.size(); k++) {
				PLMCntrtSmryRptData dataObj = pList.get(k);
				SXSSFRow row2 = (SXSSFRow) sheet.createRow(++countLcl);
				
				SXSSFCell cell1 = (SXSSFCell)  row2.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell1.setCellStyle(contentStyle);
				cell1.setCellValue(dataObj.getPrsLevel());
				
				SXSSFCell cell2 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ONE);
				cell2.setCellStyle(hyperLinkStyle);
				XSSFHyperlink url_link1 = helper.createHyperlink(Hyperlink.LINK_URL);
				
				 if(dataObj.isPrsReqFlag()){
					url_link1.setAddress(resourceBundle.getString("PRS_REQ_HyperLink1")+ dataObj.getChildName().toUpperCase(Locale.getDefault())
							+resourceBundle.getString("PRS_REQ_HyperLink2")+ dataObj.getPrsChildId()
							+resourceBundle.getString("PRS_REQ_HyperLink3")+ dataObj.getPrsChildId());
					cell2.setHyperlink(url_link1);
					cell2.setCellValue(dataObj.getChildName());

				 }else if(dataObj.isTopPrsLvlFlag()){
					url_link1.setAddress(resourceBundle.getString("PRS_TOPLVL_HyperLink1")+ dataObj.getPrsChildId()
							+resourceBundle.getString("PRS_TOPLVL_HyperLink2"));
					cell2.setHyperlink(url_link1);
					cell2.setCellValue(dataObj.getChildName());
				 }else if(dataObj.isPrsChapterFlg()){
						url_link1.setAddress(resourceBundle.getString("Chapter_HyperLink1")+ dataObj.getPrsChildId()
								+resourceBundle.getString("Chapter_HyperLink2"));
						cell2.setHyperlink(url_link1);
						cell2.setCellValue(dataObj.getChildName());
					 }
				
				SXSSFCell cell3 = (SXSSFCell)  row2.createCell(PLMConstants.EXCEL_COL_TWO);
				cell3.setCellStyle(contentStyle);
				cell3.setCellValue(dataObj.getChildTitle());
				
				SXSSFCell cell4 = (SXSSFCell)  row2.createCell(PLMConstants.EXCEL_COL_THREE);
				cell4.setCellStyle(contentStyle);
				cell4.setCellValue(dataObj.getChildDesc());
				
				SXSSFCell cell5 = (SXSSFCell)  row2.createCell(PLMConstants.EXCEL_COL_FOUR);
				cell5.setCellStyle(contentStyle);
				cell5.setCellValue(dataObj.getReqmtValue());
							
				SXSSFCell cell6 = (SXSSFCell)  row2.createCell(PLMConstants.EXCEL_COL_FIVE);
				cell6.setCellStyle(contentStyle);
				cell6.setCellValue(dataObj.getUom());
				
				SXSSFCell cell7 = (SXSSFCell)  row2.createCell(PLMConstants.EXCEL_COL_SIX);
				cell7.setCellStyle(contentStyle);
				cell7.setCellValue(dataObj.getIndicator());
				
				SXSSFCell cell8 = (SXSSFCell)  row2.createCell(PLMConstants.EXCEL_COL_SEVEN);
				cell8.setCellStyle(contentStyle);
				cell8.setCellValue(dataObj.getPrsReqNotes());
				
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, (short) 7000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, (short) 7000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, (short) 9000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE, (short) 7000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR, (short) 13000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE, (short) 3000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX, (short) 4000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN, (short) 8000);
			}
					
		}
		}	
		// End Code to display Product Requirement Spec Data table
		
		return countLcl;
	}
	
	public int createCstGrpConfFeatDataTable(SXSSFWorkbook workbook, SXSSFSheet sheet, int count, XSSFCellStyle cellBoldStyle, 
			XSSFCellStyle contentStyle, XSSFCellStyle headerStyle, String costGroup, List<String> pcNameList, List<PLMCntrtSmryRptData> cnfFeatList, 
			String filePathExcel, XSSFCellStyle hyperLinkStyle) throws PLMCommonException, IOException {
		// Code to display Customer Deliverables � CLIN Data table

		int countLcl = count;
		SXSSFRow row = (SXSSFRow) sheet.createRow(countLcl);
		SXSSFCell cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
		cell.setCellValue("Configuration Features Data -" + costGroup + " : "+ pcNameList);
		cell.setCellStyle(cellBoldStyle);		
		XSSFCreationHelper helper= (XSSFCreationHelper) workbook.getCreationHelper();
		
		XSSFColor PINK = new XSSFColor(new java.awt.Color(242, 220, 219));  
		
		XSSFFont font = (XSSFFont) workbook.createFont();
		font.setFontName(PLMConstants.EXCEL_FONT_NAME);
		font.setFontHeightInPoints((short)10);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		
		XSSFCellStyle boldStyle = (XSSFCellStyle) workbook.createCellStyle();
		boldStyle = setBorderStyle(boldStyle);
		font.setUnderline(HSSFFont.U_SINGLE);
		boldStyle.setFont(font);
		boldStyle.setAlignment(CellStyle.ALIGN_LEFT);
		boldStyle.setFillForegroundColor(PINK); 
		boldStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
		
		if (!PLMUtils.isEmptyList(cnfFeatList)) {

			String[] colNames = { "Config Feature Header Name", "Config Feature Header", "Configuration Selected Option", "Configuration Selected Option Display Name","Legacy F&A Code","Option Sub Type","Key_In_Value"};

			sheet.createRow(++countLcl);
			SXSSFRow row1 = (SXSSFRow) sheet.createRow(++countLcl);
			SXSSFRow row2 =null;
			for (int j = 0; j < colNames.length; j++) {
				SXSSFCell cell1 = (SXSSFCell) row1.createCell(j);
				cell1.setCellValue(colNames[j]);
				cell1.setCellStyle(headerStyle);
			}

			for (int k = 0; k < cnfFeatList.size(); k++) {
				PLMCntrtSmryRptData dataObj = cnfFeatList.get(k);
				 row2 = (SXSSFRow) sheet.createRow(++countLcl);

				if(dataObj.isSystemFlag()){
					SXSSFCell	cell2 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell2.setCellValue(dataObj.getSystemName());
					cell2.setCellStyle(boldStyle);
					SXSSFCell	cell3 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ONE);
					cell3.setCellStyle(boldStyle);
					SXSSFCell	cell4 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_TWO);
					cell4.setCellStyle(boldStyle);
					SXSSFCell	cell5 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_THREE);
					cell5.setCellStyle(boldStyle);
					SXSSFCell	cell6 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell6.setCellStyle(boldStyle);
					SXSSFCell	cell7 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell7.setCellStyle(boldStyle);
					SXSSFCell	cell8 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_SIX);
					cell8.setCellStyle(boldStyle);
					
					sheet.addMergedRegion(new CellRangeAddress(countLcl,countLcl,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_FIVE));
	
				}else{
				
					SXSSFCell cell2 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell2.setCellStyle(hyperLinkStyle);
					XSSFHyperlink url_link1=helper.createHyperlink(Hyperlink.LINK_URL);
					url_link1.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataObj.getCfId());
					cell2.setHyperlink(url_link1);
					cell2.setCellValue(dataObj.getCfName());
	
					SXSSFCell cell3 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ONE);
					cell3.setCellStyle(contentStyle);
					cell3.setCellValue(dataObj.getCfDisplyName());
	
					SXSSFCell cell4 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_TWO);
					cell4.setCellStyle(hyperLinkStyle);
					XSSFHyperlink url_link2=helper.createHyperlink(Hyperlink.LINK_URL);
					url_link2.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataObj.getCfConfId());
					cell4.setHyperlink(url_link2);			
					cell4.setCellValue(dataObj.getCfConfigOption());
	
					SXSSFCell cell5 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_THREE);
					cell5.setCellStyle(contentStyle);
					cell5.setCellValue(dataObj.getCfConfOptDispName());
					
					SXSSFCell cell6 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell6.setCellStyle(contentStyle);
					cell6.setCellValue(dataObj.getLegacyFACode());
					
	
					SXSSFCell cell7 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell7.setCellStyle(contentStyle);
					cell7.setCellValue(dataObj.getOptSubType());
					
					
					SXSSFCell cell8 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_SIX);
					cell8.setCellStyle(contentStyle);
					cell8.setCellValue(dataObj.getKeyInValue());
					
					
				}
				
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, (short) 7000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, (short) 9000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, (short) 7000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE, (short) 13000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR, (short) 9000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE, (short) 9000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX, (short) 9000);
				
			}
			row2 = (SXSSFRow) sheet.createRow(++countLcl);
			row2 = (SXSSFRow) sheet.createRow(++countLcl);

		}

		// End Code to display Customer Deliverables � CLIN Data table

		return countLcl;
	}

	
	public int createConfFeatDataTable(SXSSFWorkbook workbook, SXSSFSheet sheet, int count, XSSFCellStyle cellBoldStyle, 
			XSSFCellStyle contentStyle, XSSFCellStyle headerStyle, String pcName, String pcDesc, String isOption, List<PLMCntrtSmryRptData> cnfFeatList, 
			String filePathExcel, XSSFCellStyle hyperLinkStyle) throws PLMCommonException, IOException {
		// Code to display Customer Deliverables � CLIN Data table

		int countLcl = count;
		SXSSFRow row = (SXSSFRow) sheet.createRow(countLcl);
		SXSSFCell cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
		cell.setCellValue("Configuration Features Data -" + pcName + " : " + pcDesc + isOption);
		cell.setCellStyle(cellBoldStyle);		
		XSSFCreationHelper helper= (XSSFCreationHelper) workbook.getCreationHelper();
		
		XSSFColor PINK = new XSSFColor(new java.awt.Color(242, 220, 219));  
		
		XSSFFont font = (XSSFFont) workbook.createFont();
		font.setFontName(PLMConstants.EXCEL_FONT_NAME);
		font.setFontHeightInPoints((short)10);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		
		XSSFCellStyle boldStyle = (XSSFCellStyle) workbook.createCellStyle();
		boldStyle = setBorderStyle(boldStyle);
		font.setUnderline(HSSFFont.U_SINGLE);
		boldStyle.setFont(font);
		boldStyle.setAlignment(CellStyle.ALIGN_LEFT);
		boldStyle.setFillForegroundColor(PINK); 
		boldStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
		
		if (!PLMUtils.isEmptyList(cnfFeatList)) {

			String[] colNames = { "Config Feature Header Name", "Config Feature Header", "Configuration Selected Option", "Configuration Selected Option Display Name","Legacy F&A Code","Option Sub Type","Key_In_Value"};

			sheet.createRow(++countLcl);
			SXSSFRow row1 = (SXSSFRow) sheet.createRow(++countLcl);

			for (int j = 0; j < colNames.length; j++) {
				SXSSFCell cell1 = (SXSSFCell) row1.createCell(j);
				cell1.setCellValue(colNames[j]);
				cell1.setCellStyle(headerStyle);
			}

			for (int k = 0; k < cnfFeatList.size(); k++) {
				PLMCntrtSmryRptData dataObj = cnfFeatList.get(k);
				SXSSFRow row2 = (SXSSFRow) sheet.createRow(++countLcl);
				
					SXSSFCell cell2 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell2.setCellStyle(hyperLinkStyle);
					XSSFHyperlink url_link1=helper.createHyperlink(Hyperlink.LINK_URL);
					url_link1.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataObj.getCfId());
					cell2.setHyperlink(url_link1);
					cell2.setCellValue(dataObj.getCfName());
	
					SXSSFCell cell3 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ONE);
					cell3.setCellStyle(contentStyle);
					cell3.setCellValue(dataObj.getCfDisplyName());
	
					SXSSFCell cell4 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_TWO);
					cell4.setCellStyle(hyperLinkStyle);
					XSSFHyperlink url_link2=helper.createHyperlink(Hyperlink.LINK_URL);
					url_link2.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataObj.getCfConfId());
					cell4.setHyperlink(url_link2);			
					cell4.setCellValue(dataObj.getCfConfigOption());
	
					SXSSFCell cell5 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_THREE);
					cell5.setCellStyle(contentStyle);
					cell5.setCellValue(dataObj.getCfConfOptDispName());
					
					SXSSFCell cell6 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell6.setCellStyle(contentStyle);
					cell6.setCellValue(dataObj.getLegacyFACode());
					
	
					SXSSFCell cell7 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell7.setCellStyle(contentStyle);
					cell7.setCellValue(dataObj.getOptSubType());
					
					SXSSFCell cell8 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_SIX);
					cell8.setCellStyle(contentStyle);
					cell8.setCellValue(dataObj.getKeyInValue());
				
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, (short) 7000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, (short) 9000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, (short) 7000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE, (short) 13000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR, (short) 9000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE, (short) 9000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX, (short) 9000);
				
				
				
			}
		}

		// End Code to display Customer Deliverables � CLIN Data table

		return countLcl;
	}

	public int createLogicalFeatDataTable(SXSSFWorkbook workbook, SXSSFSheet sheet, int count, XSSFCellStyle cellBoldStyle, 
			XSSFCellStyle contentStyle, XSSFCellStyle headerStyle, String pcName, String pcDesc, String isOption, List<PLMCntrtSmryRptData> cnfFeatList, 
			String filePathExcel, XSSFCellStyle hyperLinkStyle) throws PLMCommonException, IOException {
		// Code to display Customer Deliverables � CLIN Data table


		int countLcl = count;
		XSSFCreationHelper helper= (XSSFCreationHelper) workbook.getCreationHelper();

		++countLcl;
		SXSSFRow row = (SXSSFRow) sheet.createRow(++countLcl);
		SXSSFCell cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
		cell.setCellValue("Logical Features (MLIs) - " + pcName + " : " + pcDesc + isOption);
		cell.setCellStyle(cellBoldStyle);

		if (!PLMUtils.isEmptyList(cnfFeatList)) {

			String[] colNames = { "Level", "Feature Display Name", "Feature Name", "Feature Description","Related CR"};

			sheet.createRow(++countLcl);
			SXSSFRow row1 = (SXSSFRow) sheet.createRow(++countLcl);

			for (int j = 0; j < colNames.length; j++) {
				SXSSFCell cell1 = (SXSSFCell) row1.createCell(j);
				cell1.setCellValue(colNames[j]);
				cell1.setCellStyle(headerStyle);
			}

			for (int k = 0; k < cnfFeatList.size(); k++) {
				PLMCntrtSmryRptData dataObj = cnfFeatList.get(k);
				SXSSFRow row2 = (SXSSFRow) sheet.createRow(++countLcl);

				SXSSFCell cell2 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell2.setCellStyle(contentStyle);
				cell2.setCellValue(dataObj.getLfLevel());

				SXSSFCell cell3 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ONE);
				cell3.setCellStyle(contentStyle);
				cell3.setCellValue(dataObj.getLfFeatDsplName());

				SXSSFCell cell4 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_TWO);
				cell4.setCellStyle(hyperLinkStyle);
				XSSFHyperlink url_link=helper.createHyperlink(Hyperlink.LINK_URL);
				url_link.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataObj.getLfFeatId());
				cell4.setHyperlink(url_link);
				cell4.setCellValue(dataObj.getLfFeatName());

				SXSSFCell cell5 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_THREE);
				cell5.setCellStyle(contentStyle);
				cell5.setCellValue(dataObj.getLfFeatDesc());	
				
				SXSSFCell cell6 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_FOUR);
				cell6.setCellStyle(contentStyle);
				cell6.setCellValue(dataObj.getCrName());
				
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, (short) 7000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, (short) 9000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, (short) 7000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE, (short) 13000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR, (short) 9000);
			}
		}

		// End Code to display Customer Deliverables � CLIN Data table

		return countLcl;
	}
	
	
	public int createConfEndItmsDataTable(SXSSFWorkbook workbook, SXSSFSheet sheet, int count, XSSFCellStyle cellBoldStyle, 
			XSSFCellStyle contentStyle, XSSFCellStyle headerStyle, String pcName, String pcDesc, String isOption, List<PLMCntrtSmryRptData> cnfFeatList, 
			String filePathExcel, XSSFCellStyle hyperLinkStyle) throws PLMCommonException, IOException {
		// Code to display Customer Deliverables � CLIN Data table
		int countLcl = count;
		XSSFCreationHelper helper= (XSSFCreationHelper) workbook.getCreationHelper();
		++countLcl;
		SXSSFRow row = (SXSSFRow) sheet.createRow(++countLcl);
		SXSSFCell cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
		cell.setCellValue("Configuration End Items (MLIs) -" + pcName + " : " + pcDesc + isOption);
		cell.setCellStyle(cellBoldStyle);

		if (!PLMUtils.isEmptyList(cnfFeatList)) {

			String[] colNames = { "Level", "CI Display Name", "CI Name", "CI Description","Related CR"};

			sheet.createRow(++countLcl);
			SXSSFRow row1 = (SXSSFRow) sheet.createRow(++countLcl);

			for (int j = 0; j < colNames.length; j++) {
				SXSSFCell cell1 = (SXSSFCell) row1.createCell(j);
				cell1.setCellValue(colNames[j]);
				cell1.setCellStyle(headerStyle);
			}

			for (int k = 0; k < cnfFeatList.size(); k++) {
				PLMCntrtSmryRptData dataObj = cnfFeatList.get(k);
				SXSSFRow row2 = (SXSSFRow) sheet.createRow(++countLcl);

				SXSSFCell cell2 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell2.setCellStyle(contentStyle);
				cell2.setCellValue(dataObj.getCeLevel());

				SXSSFCell cell3 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ONE);
				cell3.setCellStyle(contentStyle);
				cell3.setCellValue(dataObj.getCeDispName());

				SXSSFCell cell4 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_TWO);
				cell4.setCellStyle(hyperLinkStyle);
				XSSFHyperlink url_link=helper.createHyperlink(Hyperlink.LINK_URL);
				url_link.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataObj.getCeId());
				cell4.setHyperlink(url_link);			
				cell4.setCellValue(dataObj.getCeName());

				SXSSFCell cell5 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_THREE);
				cell5.setCellStyle(contentStyle);
				cell5.setCellValue(dataObj.getCeDesc());	
				
				SXSSFCell cell6 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_FOUR);
				cell6.setCellStyle(contentStyle);
				cell6.setCellValue(dataObj.getCrName());	
				
				
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, (short) 7000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, (short) 9000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, (short) 7000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE, (short) 13000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR, (short) 3000);
			}
		}

		// End Code to display Customer Deliverables � CLIN Data table

		return countLcl;
	}
	
	
	public int createcCostObjectsTable(SXSSFWorkbook workbook, SXSSFSheet sheet, int count, XSSFCellStyle cellBoldStyle, XSSFCellStyle contentStyle, 
			XSSFCellStyle headerStyle, String pcName, String pcDesc, String isOption, List<PLMCntrtSmryRptData> cnfFeatList, String filePathExcel, 
			XSSFCellStyle hyperLinkStyle) throws PLMCommonException , IOException{
		// Code to display Customer Deliverables � CLIN Data table
		int countLcl = count;
		XSSFCreationHelper helper= (XSSFCreationHelper) workbook.getCreationHelper();
		++countLcl;
		SXSSFRow row = (SXSSFRow) sheet.createRow(++countLcl);
		SXSSFCell cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
		cell.setCellValue("Cost Objects Data - " + pcName + " : " + pcDesc + isOption);
		cell.setCellStyle(cellBoldStyle);

		if (!PLMUtils.isEmptyList(cnfFeatList)) {

			String[] colNames = { "Name", "CR Name", "CO State", "CR State","CO Logical Feature","CO Logical Feature Desc"};
			
			sheet.createRow(++countLcl);
			SXSSFRow row1 = (SXSSFRow) sheet.createRow(++countLcl);

			for (int j = 0; j < colNames.length; j++) {
				SXSSFCell cell1 = (SXSSFCell) row1.createCell(j);
				cell1.setCellValue(colNames[j]);
				cell1.setCellStyle(headerStyle);
			}

			for (int k = 0; k < cnfFeatList.size(); k++) {
				PLMCntrtSmryRptData dataObj = cnfFeatList.get(k);
				SXSSFRow row2 = (SXSSFRow) sheet.createRow(++countLcl);

				SXSSFCell cell2 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell2.setCellStyle(hyperLinkStyle);
				XSSFHyperlink url_link1=helper.createHyperlink(Hyperlink.LINK_URL);
				url_link1.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataObj.getCoId());
				cell2.setHyperlink(url_link1);
				cell2.setCellValue(dataObj.getCoName());

				SXSSFCell cell3 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_ONE);
				cell3.setCellStyle(hyperLinkStyle);
				XSSFHyperlink url_link2=helper.createHyperlink(Hyperlink.LINK_URL);
				url_link2.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL") + dataObj.getCoCrId());
				cell3.setHyperlink(url_link2);
				cell3.setCellValue(dataObj.getCoCrName());

				SXSSFCell cell4 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_TWO);
				cell4.setCellStyle(contentStyle);
				cell4.setCellValue(dataObj.getCoState());

				SXSSFCell cell5 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_THREE);
				cell5.setCellStyle(contentStyle);
				cell5.setCellValue(dataObj.getCoCrState());	
				
				cell = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_FOUR);
				cell.setCellStyle(contentStyle);
				cell.setCellValue(dataObj.getCoFeatName());	
				
				SXSSFCell cell6 = (SXSSFCell) row2.createCell(PLMConstants.EXCEL_COL_FIVE);
				cell6.setCellStyle(contentStyle);
				cell6.setCellValue(dataObj.getCoDesc());	
				
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, (short) 7000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, (short) 9000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, (short) 7000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE, (short) 13000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR, (short) 3000);
				sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE, (short) 4000);
			}
		}

		// End Code to display Customer Deliverables � CLIN Data table

		return countLcl;
	}
	
	
	/**
	 * This method is used for Bordering Cell in XLS
	 * 
	 * @return StringBuffer
	 */
	
	private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
		style.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style.setBorderRight(XSSFCellStyle.BORDER_THIN);
		return style;
	}
	
	
	
	/*End Raju*/
	
	
	//Added by Raju to add Product Type
	
	public void prodtTypeListner(ActionEvent ae) {
		LOG.info("in prodtTypeListner method");
		prdtTypeListCrs = new ArrayList<String>();
		prdtTypeListClHb = new ArrayList<String>();
		if(selectedPrdtType.contains("Gas")){
			prdtTypeListCrs.add("Gas");
			prdtTypeListCrs.add("Gas - Options");
			prdtTypeListClHb.add("GT");
		}
		if(selectedPrdtType.contains("Steam")){
			prdtTypeListCrs.add("Steam");
			prdtTypeListCrs.add("Steam - Options");
			prdtTypeListClHb.add("ST");
		}
		if(selectedPrdtType.contains("Gen")){
			prdtTypeListCrs.add("Gen");
			prdtTypeListCrs.add("Gen - Options");
			prdtTypeListClHb.add("GTG");
			prdtTypeListClHb.add("STG");
		}
		if(selectedPrdtType.contains("Plant")){
			prdtTypeListCrs.add("PLANT");
			prdtTypeListClHb.add("Not Applicable");
		}
		LOG.info("in prodtTypeListner method prdtTypeListCrs List >>>>>>>>>>>>  "+prdtTypeListCrs);
		LOG.info("in prodtTypeListner method prdtTypeListClHb List >>>>>>>>>>>>  "+prdtTypeListClHb);
	}
	//End Raju
	
	/**
	 * This method is used for to get Part Type Check box
	 * 
	 * @param ActionEvent
	 * 
	 */
	public void partTypeChkBoxListener(ActionEvent ae) {
		LOG.info("Entering partTypeChkBoxListener method");
		selectedPrdtType.clear();
		prdtTypeListCrs = new ArrayList<String>();
		prdtTypeListClHb = new ArrayList<String>();
			if (partTypeAllOpen) {
				disablePrdtType=true;
				prdtTypeListCrs.add("Gas");
				prdtTypeListCrs.add("Gas - Options");
				prdtTypeListClHb.add("GT");
				prdtTypeListCrs.add("Steam");
				prdtTypeListCrs.add("Steam - Options");
				prdtTypeListClHb.add("ST");
				prdtTypeListCrs.add("Gen");
				prdtTypeListCrs.add("Gen - Options");
				prdtTypeListClHb.add("GTG");
				prdtTypeListClHb.add("STG");
				prdtTypeListCrs.add("PLANT");
				prdtTypeListClHb.add("Not Applicable");
			}else{
				disablePrdtType=false;
			}
			LOG.info("in prodtTypeListner method prdtTypeListCrs List >>>>>>>>>>>>  "+prdtTypeListCrs);
			LOG.info("in prodtTypeListner method prdtTypeListClHb List >>>>>>>>>>>>  "+prdtTypeListClHb);
	}

	/**
	 * @param contractNum
	 *            the contractNum to set
	 */
	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}

	/**
	 * @return the contractSumrReptService
	 */
	public PLMCntrtSmryRptServiceIfc getContractSumrReptService() {
		return contractSumrReptService;
	}

	/**
	 * @param contractSumrReptService
	 *            the contractSumrReptService to set
	 */
	public void setContractSumrReptService(PLMCntrtSmryRptServiceIfc contractSumrReptService) {
		this.contractSumrReptService = contractSumrReptService;
	}

	/**
	 * @return the contractNum
	 */
	public String getContractNum() {
		return contractNum;
	}

	/**
	 * @return the hrdwarePrdctList1
	 */
	public List<PLMCntrtSmryRptData> getHrdwarePrdctList1() {
		return hrdwarePrdctList1;
	}

	/**
	 * @param hrdwarePrdctList1
	 *            the hrdwarePrdctList1 to set
	 */
	public void setHrdwarePrdctList1(List<PLMCntrtSmryRptData> hrdwarePrdctList1) {
		this.hrdwarePrdctList1 = hrdwarePrdctList1;
	}

	/**
	 * @return the hrdwarePrdctList2
	 */
	public List<PLMCntrtSmryRptData> getHrdwarePrdctList2() {
		return hrdwarePrdctList2;
	}

	/**
	 * @param hrdwarePrdctList2
	 *            the hrdwarePrdctList2 to set
	 */
	public void setHrdwarePrdctList2(List<PLMCntrtSmryRptData> hrdwarePrdctList2) {
		this.hrdwarePrdctList2 = hrdwarePrdctList2;
	}

	/**
	 * @return the totalRecCountMsg
	 */
	public String getTotalRecCountMsg() {
		return totalRecCountMsg;
	}

	/**
	 * @param totalRecCountMsg
	 *            the totalRecCountMsg to set
	 */
	public void setTotalRecCountMsg(String totalRecCountMsg) {
		this.totalRecCountMsg = totalRecCountMsg;
	}

	/**
	 * @return the pageNo
	 */
	public int getPageNo() {
		return pageNo;
	}

	/**
	 * @param pageNo
	 *            the pageNo to set
	 */
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	/**
	 * @return the combinedList
	 */
	public List<PLMCntrtSmryRptData> getCombinedList() {
		return combinedList;
	}

	/**
	 * @param combinedList
	 *            the combinedList to set
	 */
	public void setCombinedList(List<PLMCntrtSmryRptData> combinedList) {
		this.combinedList = combinedList;
	}

	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @param recordCounts
	 *            the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}

	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount
	 *            the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/**
	 * @return the subcomponentsList
	 */
	public List<String> getSubcomponentsList() {
		return subcomponentsList;
	}

	/**
	 * @param subcomponentsList
	 *            the subcomponentsList to set
	 */
	public void setSubcomponentsList(List<String> subcomponentsList) {
		this.subcomponentsList = subcomponentsList;
	}

	/**
	 * @return the checkBoxSel
	 */
	public boolean isCheckBoxSel() {
		return checkBoxSel;
	}

	/**
	 * @param checkBoxSel
	 *            the checkBoxSel to set
	 */
	public void setCheckBoxSel(boolean checkBoxSel) {
		this.checkBoxSel = checkBoxSel;
	}

	/**
	 * @return the subcomponentsList1
	 */
	public List<PLMCntrtSmryRptData> getSubcomponentsList1() {
		return subcomponentsList1;
	}

	/**
	 * @param subcomponentsList1
	 *            the subcomponentsList1 to set
	 */
	public void setSubcomponentsList1(List<PLMCntrtSmryRptData> subcomponentsList1) {
		this.subcomponentsList1 = subcomponentsList1;
	}

	/**
	 * @return the conSummRepData
	 */
	public PLMCntrtSmryRptData getConSummRepData() {
		return conSummRepData;
	}

	/**
	 * @param conSummRepData
	 *            the conSummRepData to set
	 */
	public void setConSummRepData(PLMCntrtSmryRptData conSummRepData) {
		this.conSummRepData = conSummRepData;
	}

	/**
	 * @return the dataTable
	 */
	public HtmlDataTable getDataTable() {
		return dataTable;
	}

	/**
	 * @param dataTable
	 *            the dataTable to set
	 */
	public void setDataTable(HtmlDataTable dataTable) {
		this.dataTable = dataTable;
	}

	/**
	 * @return the selComponentList
	 */
	public List<String> getSelComponentList() {
		return selComponentList;
	}

	/**
	 * @param selComponentList
	 *            the selComponentList to set
	 */
	public void setSelComponentList(List<String> selComponentList) {
		this.selComponentList = selComponentList;
	}

	/**
	 * @return the hardwarePrdt
	 */
	public String getHardwarePrdt() {
		return hardwarePrdt;
	}

	/**
	 * @param hardwarePrdt
	 *            the hardwarePrdt to set
	 */
	public void setHardwarePrdt(String hardwarePrdt) {
		this.hardwarePrdt = hardwarePrdt;
	}

	/**
	 * @return the productConfg
	 */
	public String getProductConfg() {
		return productConfg;
	}

	/**
	 * @param productConfg
	 *            the productConfg to set
	 */
	public void setProductConfg(String productConfg) {
		this.productConfg = productConfg;
	}

	/**
	 * @return the finalDataMap
	 */
	public Map<String, List<String>> getFinalDataMap() {
		return finalDataMap;
	}

	/**
	 * @param finalDataMap
	 *            the finalDataMap to set
	 */
	public void setFinalDataMap(Map<String, List<String>> finalDataMap) {
		this.finalDataMap = finalDataMap;
	}

	/**
	 * @return the checkTopBoxSel
	 */
	public boolean isCheckTopBoxSel() {
		return checkTopBoxSel;
	}

	/**
	 * @param checkTopBoxSel
	 *            the checkTopBoxSel to set
	 */
	public void setCheckTopBoxSel(boolean checkTopBoxSel) {
		this.checkTopBoxSel = checkTopBoxSel;
	}

	/**
	 * @return the rowKey
	 */
	public String getRowKey() {
		return rowKey;
	}

	/**
	 * @param rowKey
	 *            the rowKey to set
	 */
	public void setRowKey(String rowKey) {
		this.rowKey = rowKey;
	}

	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor
	 *            the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the topLvlHP
	 */
	public String getTopLvlHP() {
		return topLvlHP;
	}

	/**
	 * @param topLvlHP
	 *            the topLvlHP to set
	 */
	public void setTopLvlHP(String topLvlHP) {
		this.topLvlHP = topLvlHP;
	}

	/**
	 * @return the rowSubComp
	 */
	public String getRowSubComp() {
		return rowSubComp;
	}

	/**
	 * @param rowSubComp
	 *            the rowSubComp to set
	 */
	public void setRowSubComp(String rowSubComp) {
		this.rowSubComp = rowSubComp;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the alertMsg
	 */
	public String getAlertMsg() {
		return alertMsg;
	}

	/**
	 * @param alertMsg
	 *            the alertMsg to set
	 */
	public void setAlertMsg(String alertMsg) {
		this.alertMsg = alertMsg;
	}

	/**
	 * @param cgFlag
	 *            the cgFlag to set
	 */
	public void setCgFlag(boolean cgFlag) {
		this.cgFlag = cgFlag;
	}

	/**
	 * @param pcFlag
	 *            the pcFlag to set
	 */
	public void setPcFlag(boolean pcFlag) {
		this.pcFlag = pcFlag;
	}

	/**
	 * @param subCmpFlag
	 *            the subCmpFlag to set
	 */
	public void setSubCmpFlag(boolean subCmpFlag) {
		this.subCmpFlag = subCmpFlag;
	}

	/**
	 * @return the cntrctSmryData
	 */
	public PLMCntrtSmryRptData getCntrctSmryData() {
		return cntrctSmryData;
	}

	/**
	 * @param cntrctSmryData
	 *            the cntrctSmryData to set
	 */
	public void setCntrctSmryData(PLMCntrtSmryRptData cntrctSmryData) {
		this.cntrctSmryData = cntrctSmryData;
	}

	/**
	 * @return the cgFlag
	 */
	public boolean isCgFlag() {
		return cgFlag;
	}

	/**
	 * @return the pcFlag
	 */
	public boolean isPcFlag() {
		return pcFlag;
	}

	/**
	 * @return the subCmpFlag
	 */
	public boolean isSubCmpFlag() {
		return subCmpFlag;
	}

	/**
	 * @return the cstGrpAllOpen
	 */
	public boolean isCstGrpAllOpen() {
		return cstGrpAllOpen;
	}

	/**
	 * @param cstGrpAllOpen
	 *            the cstGrpAllOpen to set
	 */
	public void setCstGrpAllOpen(boolean cstGrpAllOpen) {
		this.cstGrpAllOpen = cstGrpAllOpen;
	}

	/**
	 * @return the pcAllOpen
	 */
	public boolean isPcAllOpen() {
		return pcAllOpen;
	}

	/**
	 * @param pcAllOpen
	 *            the pcAllOpen to set
	 */
	public void setPcAllOpen(boolean pcAllOpen) {
		this.pcAllOpen = pcAllOpen;
	}

	/**
	 * @return the cntrctList
	 */
	public List<PLMCntrtSmryRptData> getCntrctList() {
		return cntrctList;
	}

	/**
	 * @param cntrctList
	 *            the cntrctList to set
	 */
	public void setCntrctList(List<PLMCntrtSmryRptData> cntrctList) {
		this.cntrctList = cntrctList;
	}

	/**
	 * @return the cstGrpList
	 */
	public List<String> getCstGrpList() {
		return cstGrpList;
	}

	/**
	 * @param cstGrpList
	 *            the cstGrpList to set
	 */
	public void setCstGrpList(List<String> cstGrpList) {
		this.cstGrpList = cstGrpList;
	}

	/**
	 * @return the pcInfoList
	 */
	public List<PLMCntrtSmryRptData> getPcInfoList() {
		return pcInfoList;
	}

	/**
	 * @param pcInfoList
	 *            the pcInfoList to set
	 */
	public void setPcInfoList(List<PLMCntrtSmryRptData> pcInfoList) {
		this.pcInfoList = pcInfoList;
	}

	/**
	 * @return the cstGrpListSI
	 */
	public List<SelectItem> getCstGrpListSI() {
		return cstGrpListSI;
	}

	/**
	 * @param cstGrpListSI
	 *            the cstGrpListSI to set
	 */
	public void setCstGrpListSI(List<SelectItem> cstGrpListSI) {
		this.cstGrpListSI = cstGrpListSI;
	}

	/**
	 * @return the pcInfoListSI
	 */
	public List<SelectItem> getPcInfoListSI() {
		return pcInfoListSI;
	}

	/**
	 * @param pcInfoListSI
	 *            the pcInfoListSI to set
	 */
	public void setPcInfoListSI(List<SelectItem> pcInfoListSI) {
		this.pcInfoListSI = pcInfoListSI;
	}

	/**
	 * @return the subCmpnt
	 */
	public String getSubCmpnt() {
		return subCmpnt;
	}

	/**
	 * @param subCmpnt
	 *            the subCmpnt to set
	 */
	public void setSubCmpnt(String subCmpnt) {
		this.subCmpnt = subCmpnt;
	}

	/**
	 * @return the selCstGrpList
	 */
	public List<String> getSelCstGrpList() {
		return selCstGrpList;
	}

	/**
	 * @param selCstGrpList
	 *            the selCstGrpList to set
	 */
	public void setSelCstGrpList(List<String> selCstGrpList) {
		this.selCstGrpList = selCstGrpList;
	}

	/**
	 * @return the selPcList
	 */
	public List<String> getSelPcList() {
		return selPcList;
	}

	/**
	 * @param selPcList
	 *            the selPcList to set
	 */
	public void setSelPcList(List<String> selPcList) {
		this.selPcList = selPcList;
	}

	/**
	 * @return the selSubComp
	 */
	public boolean isSelSubComp() {
		return selSubComp;
	}

	/**
	 * @param selSubComp
	 *            the selSubComp to set
	 */
	public void setSelSubComp(boolean selSubComp) {
		this.selSubComp = selSubComp;
	}

	/**
	 * @return the subcomponentsListInPage
	 */
	public List<PLMContractSmryData> getSubcomponentsListInPage() {
		return subcomponentsListInPage;
	}

	/**
	 * @param subcomponentsListInPage
	 *            the subcomponentsListInPage to set
	 */
	public void setSubcomponentsListInPage(List<PLMContractSmryData> subcomponentsListInPage) {
		this.subcomponentsListInPage = subcomponentsListInPage;
	}

	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}

	/**
	 * @param level
	 *            the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}
	/**
	 * @return the notRequireFlg
	 */
	public boolean isNotRequireFlg() {
		return notRequireFlg;
	}

	/**
	 * @param notRequireFlg the notRequireFlg to set
	 */
	public void setNotRequireFlg(boolean notRequireFlg) {
		this.notRequireFlg = notRequireFlg;
	}

	/**
	 * @return the selectedPrdtType
	 */
	public List<String> getSelectedPrdtType() {
		return selectedPrdtType;
	}

	/**
	 * @param selectedPrdtType the selectedPrdtType to set
	 */
	public void setSelectedPrdtType(List<String> selectedPrdtType) {
		this.selectedPrdtType = selectedPrdtType;
	}
	/**
	 * @return the partTypeAllOpen
	 */
	public boolean isPartTypeAllOpen() {
		return partTypeAllOpen;
	}
	/**
	 * @param partTypeAllOpen the partTypeAllOpen to set
	 */
	public void setPartTypeAllOpen(boolean partTypeAllOpen) {
		this.partTypeAllOpen = partTypeAllOpen;
	}
	/**
	 * @return the disablePrdtType
	 */
	public boolean isDisablePrdtType() {
		return disablePrdtType;
	}
	/**
	 * @param disablePrdtType the disablePrdtType to set
	 */
	public void setDisablePrdtType(boolean disablePrdtType) {
		this.disablePrdtType = disablePrdtType;
	}
	/**
	 * @return the categoryFlag
	 */
	public boolean isCategoryFlag() {
		return categoryFlag;
	}
	/**
	 * @param categoryFlag the categoryFlag to set
	 */
	public void setCategoryFlag(boolean categoryFlag) {
		this.categoryFlag = categoryFlag;
	}

}
