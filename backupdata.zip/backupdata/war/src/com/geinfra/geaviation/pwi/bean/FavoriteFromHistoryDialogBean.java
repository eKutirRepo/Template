package com.geinfra.geaviation.pwi.bean;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.QueryAccessException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.PWiQueryExctnEventVO;
import com.geinfra.geaviation.pwi.service.CustomQueryService;
import com.geinfra.geaviation.pwi.service.HistoryService;
import com.geinfra.geaviation.pwi.service.QuerySubmissionService;
import com.geinfra.geaviation.pwi.service.vo.QueryUserOptions;

/**
 * 
 * Project : Product Lifecycle Management Date Written : May 21, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2013 GE All rights reserved
 * 
 * Description : Bean to allow favorite queries to be created from
 *               history (query execution events)
 * 
 * Revision Log May 21, 2010 | v1.0.
 * --------------------------------------------------------------
 */

public class FavoriteFromHistoryDialogBean extends BaseBean {
	private Integer historyId;
	private String favoriteName;

	// Injected properties
	private CustomQueryService customQueryService;
	private QuerySubmissionService querySubmissionService;
	private HistoryService historyService;

	public String actionCreateFavorite() throws PWiException,
			QueryAccessException {
		PWiQueryExctnEventVO event = historyService
				.getExecutionEventById(historyId);
		QueryUserOptions options = querySubmissionService
				.getQueryUserOptionsFromHistory(event);

		customQueryService.createFavorite(event.getQueryId(), favoriteName,
				options);

		return null;
	}
	
	public String actionCreateFavoriteHome() throws PWiException,
	QueryAccessException {
		PWiQueryExctnEventVO event = historyService
				.getExecutionEventById(historyId);
		QueryUserOptions options = querySubmissionService
				.getQueryUserOptionsFromHistory(event);
		
		customQueryService.createFavorite(event.getQueryId(), favoriteName,
		options); 
		handleFacesInfo("Query '"+favoriteName+"' successfully added to favorite.");
			return "landOnHome";
	}
	public String actionCreateFavoriteHistory() throws PWiException,
	QueryAccessException {
		PWiQueryExctnEventVO event = historyService
				.getExecutionEventById(historyId);
		QueryUserOptions options = querySubmissionService
				.getQueryUserOptionsFromHistory(event);
		
		customQueryService.createFavorite(event.getQueryId(), favoriteName,
		options);
		handleFacesInfo("Query '"+favoriteName+"' successfully added to favorite.");
			return "DownloadQueryGeneratorTools";
	}

	public Integer getHistoryId() {
		return historyId;
	}

	public void setHistoryId(Integer historyId) {
		this.historyId = historyId;
	}

	public String getFavoriteName() {
		return favoriteName;
	}

	public void setFavoriteName(String favoriteName) {
		this.favoriteName = favoriteName;
	}

	public void setCustomQueryService(CustomQueryService customQueryService) {
		this.customQueryService = customQueryService;
	}

	public void setQuerySubmissionService(
			QuerySubmissionService querySubmissionService) {
		this.querySubmissionService = querySubmissionService;
	}

	public void setHistoryService(HistoryService historyService) {
		this.historyService = historyService;
	}
}
