/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBomSpecPartData.java
 * @Creation date: 11-Sept-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMBomSpecPartData {

	
	// PROPERTIES *************************************************************

	private String partId;		
	private String logicalIndicator;
	private String partName;
	private String partRevision;
	private String partState;
	private String partQty;
	private String partUoMDlvrbl;
	private String partDescription;	
	
	// CONSTRUCTOR ************************************************************

	/**
	 * Creates a new instance of the class Deliverable
	 * 
	 */
	public PLMBomSpecPartData (String logicalIndicator, String partName, String partRevision,
							String partState, String partQty, String partUoM, String partDescription) {  
		//this.partId = partId;
		this.logicalIndicator = logicalIndicator;
		this.partName = partName;		
		this.partRevision = partRevision;
		this.partState = partState;
		this.partQty = partQty;
		this.partUoMDlvrbl = partUoM;
		this.partDescription = partDescription;
	}
	
	// ACCESSOR METHODS *******************************************************

	public String getPartId() {
		return partId;
	}

	public void setPartId(String partId) {
		this.partId = partId;
	}

	public String getLogicalIndicator() {
		return logicalIndicator;
	}

	public void setLogicalIndicator(String logicalIndicator) {
		this.logicalIndicator = logicalIndicator;
	}

	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}

	public String getPartRevision() {
		return partRevision;
	}

	public void setPartRevision(String partRevision) {
		this.partRevision = partRevision;
	}

	public String getPartState() {
		return partState;
	}

	public void setPartState(String partState) {
		this.partState = partState;
	}

	public String getPartQty() {
		return partQty;
	}

	public void setPartQty(String partQty) {
		this.partQty = partQty;
	}

	/*public String getPartUoM() {
		return partUoM;
	}

	public void setPartUoM(String partUoM) {
		this.partUoM = partUoM;
	}*/
	
	/**
	 * @return the partUoMDlvrbl
	 */
	public String getPartUoMDlvrbl() {
		return partUoMDlvrbl;
	}

	/**
	 * @param partUoMDlvrbl the partUoMDlvrbl to set
	 */
	public void setPartUoMDlvrbl(String partUoMDlvrbl) {
		this.partUoMDlvrbl = partUoMDlvrbl;
	}
	
	public String getPartDescription() {
		return partDescription;
	}

	public void setPartDescription(String partDescription) {
		this.partDescription = partDescription;
	}

	
	// OVERRIDEN METHODS ******************************************************
	/**
	 * Returns the BomSpecPart information as a String
	 * 
	 * @return type (String) 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer strBomSpecPart = new StringBuffer();
		
		strBomSpecPart
			.append(partId).append(" ")
			.append(logicalIndicator).append(" ")
			.append(partName).append(" ")
			.append(partRevision).append(" ")
			.append(partState).append(" ")
			.append(partQty).append(" ")
			.append(partUoMDlvrbl).append(" ")
			.append(partDescription);
		
		return strBomSpecPart.toString();
	}
	
}
