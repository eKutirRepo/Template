package com.geinfra.geaviation.pwi.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import javax.faces.context.FacesContext;

import org.apache.commons.lang.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMPwiRolesData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.model.PWiRoleVO;
import com.geinfra.geaviation.pwi.util.ColumnConstants;
import com.geinfra.geaviation.pwi.util.DaoUtil;
import com.geinfra.geaviation.pwi.util.MapperConstants.RowCounter;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.util.QueryConstants;
import com.geinfra.geaviation.pwi.util.QueryLoader;

/**
 * Project : Product Lifecycle Management Date Written : Apr 12, 2011 Security : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : RoleDAOImpl
 * 
 * Revision Log Jan 20, 2012 | v1.0. --------------------------------------------------------------
 */
public class RoleDAOImpl implements RoleDAO {

	private JdbcTemplate jdbcTemplate;


	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {

		this.jdbcTemplate = jdbcTemplate;
	}


	/*
	 * public List<PWiRoleVO> findAllPWiRoles() {
	 * 
	 * final ParameterizedRowMapper<PWiRoleVO> mapper = new PWiRoleVORowMapper();
	 * 
	 * @SuppressWarnings("unchecked") List<PWiRoleVO> result = (List<PWiRoleVO>)
	 * jdbcTemplate.query(QueryLoader.getQuery(QueryConstants.PWi_ROLE_LIST), mapper); return
	 * result; }
	 */

	@SuppressWarnings("unchecked")
	public List<PWiRoleVO> findAllPWiRoles() {

		String getAllRoles = QueryLoader.getQuery(QueryConstants.PWi_ROLE_LIST);

		PLMPwiUserData userdata = (PLMPwiUserData) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get(PWiConstants.USER_DATA);
		String roleTypes = "";
		int i = 0;
		for (PLMPwiRolesData roles : userdata.getRoleDtlList()) {
			if (i == 0) {
				roleTypes = "'" + roles.getUserRoleType() + "'";
				i++;
			} else {
				roleTypes = roleTypes + "," + "'" + roles.getUserRoleType() + "'";
				i++;
			}

		}
		getAllRoles = getAllRoles + roleTypes + ") GROUP BY A.PWI_RID,A.PWI_NAME,A.PWI_DISPLAYNAME,A.PWI_ROLE_TYPE ";
		ParameterizedRowMapper<PWiRoleVO> rlTypeMapper = new PWiRoleFrTypeVORowMapper();
		// final PreparedStatementSetter setter = new GetRoleByTypeSetter(roleTypes);

		List<PWiRoleVO> result = (List<PWiRoleVO>) jdbcTemplate.query(getAllRoles, rlTypeMapper);

		return result;
	}


	/**
	 * PWiRoleVORowMapper retrieves the column names and set to VO list to display in roleList page
	 */

	public static class PWiRoleVORowMapper implements ParameterizedRowMapper<PWiRoleVO> {

		public PWiRoleVO mapRow(ResultSet rs, int rowNum) throws SQLException {

			PWiRoleVO PWiRoleVO = new PWiRoleVO();
			PWiRoleVO.setRoleSeqId(Integer.valueOf(rs.getString(ColumnConstants.PWI_RID)));
			PWiRoleVO.setRoleNm(rs.getString(ColumnConstants.PWI_NAME));
			PWiRoleVO.setRoleDesc(rs.getString(ColumnConstants.PWI_DISPLAYNAME));
			PWiRoleVO.setRoleType(rs.getString(ColumnConstants.PWI_ROLE_TYPE));
			return PWiRoleVO;
		}
	}


	public static class PWiRoleFrTypeVORowMapper implements ParameterizedRowMapper<PWiRoleVO> {

		public PWiRoleVO mapRow(ResultSet rs, int rowNum) throws SQLException {

			PWiRoleVO PWiRoleVO = new PWiRoleVO();
			PWiRoleVO.setRoleSeqId(Integer.valueOf(rs.getString(ColumnConstants.PWI_RID)));
			PWiRoleVO.setRoleNm(rs.getString(ColumnConstants.PWI_NAME));
			PWiRoleVO.setRoleDesc(rs.getString(ColumnConstants.PWI_DISPLAYNAME));
			PWiRoleVO.setRoleType(rs.getString(ColumnConstants.PWI_ROLE_TYPE));
			if (rs.getString(ColumnConstants.PWI_ROLE_DEL_FLAG).equals("YES")) {
				PWiRoleVO.setEligibleFrDlt(true);
			} else {
				PWiRoleVO.setEligibleFrDlt(false);
			}
			return PWiRoleVO;
		}
	}



	public PWiRoleVO getRoleById(Integer roleId) {

		// Retrieve SQL with bind parameters
		String sql = QueryLoader.getQuery(QueryConstants.PWi_ROLE_ID);

		// Define prepared statement setter
		PreparedStatementSetter pss = new GetRoleByIdSetter(roleId);

		// Define row mapper
		RowMapper rowMapper = new PWiRoleVORowMapper();

		// Run query on database
		@SuppressWarnings("unchecked")
		List<PWiRoleVO> roles = jdbcTemplate.query(sql, pss, rowMapper);
		if (roles.size() == 1) {
			return roles.get(0);
		} else if (roles.size() == 0) {
			return null;
		}
		throw new IllegalStateException("Failed to return one or zero templates for Role ID: " + roleId + ", roles: " + roles);
	}


	private static class GetRoleByIdSetter implements PreparedStatementSetter {

		private Integer roleId;


		public GetRoleByIdSetter(Integer roleId) {

			this.roleId = roleId;
		}


		public void setValues(PreparedStatement ps) throws SQLException {

			ps.setInt(1, roleId.intValue());
		}

	}



	public int checkNames(String roleNm, String roleDesc) {

		RowCounter counter = new RowCounter();
		String sql = QueryLoader.getQuery(QueryConstants.SEARCH_ROLE_WITH_NAME);
		Object[] parameters = {roleNm, roleDesc};

		jdbcTemplate.query(sql, parameters, counter);

		return counter.getCount();
	}


	public int checkNamesEdit(String roleNm, String roleDesc, Integer roleSeqId) {

		RowCounter counter = new RowCounter();
		String sql = QueryLoader.getQuery(QueryConstants.SEARCH_ROLE_EDIT_NAME);
		Object[] parameters = {roleNm, roleDesc, roleSeqId};

		jdbcTemplate.query(sql, parameters, counter);

		return counter.getCount();
	}


	public void updateRole(PWiRoleVO role) {

		jdbcTemplate.update(new UpdateRolePSCreator(role));
	}


	public void updateRole(PWiRoleVO role, List<Integer> selectedGroupIds, String userId) {

	}


	private static class UpdateRolePSCreator implements PreparedStatementCreator {

		private PWiRoleVO role;


		// private String userId;//commented on 31-Oct-2014 as per Nimble report

		public UpdateRolePSCreator(PWiRoleVO role) {

			this.role = role;
			// this.userId = userId;
		}


		public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {

			String sql = QueryLoader.getQuery(QueryConstants.PWi_ROLE_UPDATE);
			PreparedStatement ps = connection.prepareStatement(sql);

			int idx = 1; // parameter index
			ps.setString(idx++, role.getRoleNm());
			ps.setString(idx++, role.getRoleDesc());
			ps.setString(idx++, role.getRoleType());
			ps.setInt(idx++, role.getRoleSeqId().intValue());
			return ps;
		}
	}


	// Create & Save new Role in DB =============

	public int createNewRole(final String roleName, final String roleDesc, final String roleType, final String sso) throws RuntimeException {

		String sql = QueryLoader.getQuery(QueryConstants.PWi_ROLE_INSERT);
		Connection connection = null;
		CallableStatement statement = null;
		try {
			connection = jdbcTemplate.getDataSource().getConnection();
			statement = connection.prepareCall(sql);

			// Set input parameters
			int idx = 1; // parameter index
			statement.setString(idx++, roleName);
			statement.setString(idx++, roleDesc);
			statement.setString(idx++, roleType);
			statement.setString(idx++, sso);
			statement.setString(idx++, sso);

			// Set output parameters
			statement.registerOutParameter(idx, Types.NUMERIC);

			// Execute role
			statement.execute();

			// Retrieve primary key
			Integer roleId = Integer.valueOf(statement.getInt(idx));
			return roleId;
		} catch (SQLException e) {
			// Throw runtime exception to trigger rollback
			throw new RuntimeException(e);
		} finally {
			// close everything
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				// Throw runtime exception to trigger rollback
				throw new RuntimeException(e);
			}
		}

	}


	// === USER screen Role changes============
	public List<PWiRoleVO> findPWiRolesForGroups(List<String> groups) {

		// Construct SQL
		String sql = QueryLoader.getQuery(QueryConstants.PWi_OBJECT_TYPES_BY_GROUP);
		int inPos = StringUtils.lastIndexOf(sql, "?");
		String sub1 = StringUtils.substring(sql, 0, inPos);
		String sub2 = StringUtils.substring(sql, inPos, sql.length());
		StringBuffer sqlBuffer = new StringBuffer(sub1);
		for (int i = 1; i < groups.size(); i++) {
			sqlBuffer.append("?,");
		}


		sql = sqlBuffer.append(sub2).toString();

		final ParameterizedRowMapper<PWiRoleVO> mapper = new PWiRoleVORowMapper();
		final PreparedStatementSetter setter = new GroupNamesSetter(groups);

		@SuppressWarnings("unchecked")
		List<PWiRoleVO> result = (List<PWiRoleVO>) jdbcTemplate.query(sql, setter, mapper);
		return result;
	}


	private static class GroupNamesSetter implements PreparedStatementSetter {

		private List<String> groups;


		public GroupNamesSetter(List<String> groups) {

			this.groups = groups;
		}


		public void setValues(PreparedStatement ps) throws SQLException {

			int parameterIndex = 1;
			for (String group : groups) {
				ps.setString(parameterIndex, group);
				parameterIndex++;
			}
		}
	}


	public void addRolesForUser(List<Integer> roleIdsToAddForUser, Integer userId) {

		AddRolesForUserSetter pss = new AddRolesForUserSetter(userId, roleIdsToAddForUser);

		jdbcTemplate.batchUpdate(pss.getSql(), pss);
	}


	private static class AddRolesForUserSetter implements BatchPreparedStatementSetter {

		private Integer userId;


		private List<Integer> roleIds;


		// private String sso;//commented on 31-Oct-2014 as per Nimble report

		public AddRolesForUserSetter(Integer userId, List<Integer> roleIds) {

			this.userId = userId;
			this.roleIds = roleIds;
			// this.sso = sso;
		}


		public String getSql() {

			return QueryLoader.getQuery(QueryConstants.PWi_ROLE_USER_INSERT);
		}


		public int getBatchSize() {

			return roleIds.size();
		}


		public void setValues(PreparedStatement ps, int roleIndex) throws SQLException {

			ps.setInt(1, userId.intValue());
			ps.setInt(2, roleIds.get(roleIndex).intValue());
		}

	}


	public void deleteRolesForUser(List<Integer> roleIdsToRemoveForUser, Integer userId) {

		RemoveRolesForUserSetter pss = new RemoveRolesForUserSetter(userId, roleIdsToRemoveForUser);

		jdbcTemplate.update(pss.getSql(), pss);
	}


	private static class RemoveRolesForUserSetter implements PreparedStatementSetter {

		private Integer userId;


		private List<Integer> roleIds;


		public RemoveRolesForUserSetter(Integer userId, List<Integer> roleIds) {

			this.userId = userId;
			this.roleIds = roleIds;
		}


		public String getSql() {

			StringBuffer buffer = new StringBuffer();
			buffer.append(QueryLoader.getQuery(QueryConstants.PWi_ROLE_USER_DELETE));
			buffer.append(" (");
			buffer.append(DaoUtil.getInstance().generateInClausePlaceholders(roleIds.size()));
			buffer.append(")");

			return buffer.toString();
		}


		public void setValues(PreparedStatement ps) throws SQLException {

			int index = 1;
			ps.setInt(index++, userId.intValue());
			for (Integer roleId : roleIds) {
				ps.setInt(index++, roleId.intValue());
			}
		}
	}


	public List<PWiRoleVO> findSelectedRolesForUser(Integer userid) throws PWiException {

		List<PWiRoleVO> result = null;
		Object[] parameter = {userid};
		try {
			final ParameterizedRowMapper<PWiRoleVO> mapper = new FindSelectedGroupsMapper();
			result = (List<PWiRoleVO>) jdbcTemplate.query(QueryLoader.getQuery(QueryConstants.SELECTED_ROLES_FOR_USER), parameter, mapper);
			return result;
		} catch (DataAccessException e) {
			throw new PWiException(e);
		}
	}


	private static class FindSelectedGroupsMapper implements ParameterizedRowMapper<PWiRoleVO> {

		public PWiRoleVO mapRow(ResultSet rs, int rowNum) throws SQLException {

			PWiRoleVO roleVO = new PWiRoleVO();
			roleVO.setRoleSeqId(Integer.valueOf(rs.getInt("roleid")));
			roleVO.setRoleNm(rs.getString("rolename"));
			roleVO.setRoleDesc(rs.getString("roledesc"));
			return roleVO;
		}


	}


	/**
	 * Add groups for RoleType
	 */
	public void addGroupsForRole(List<Integer> groupIdsToAddForRole, Integer roleId, String sso) {

		AddGroupsForRoleSetter pss = new AddGroupsForRoleSetter(roleId, groupIdsToAddForRole, sso);

		jdbcTemplate.batchUpdate(pss.getSql(), pss);
	}


	private static class AddGroupsForRoleSetter implements BatchPreparedStatementSetter {

		private Integer roleId;


		private List<Integer> groupIds;


		private String sso;


		public AddGroupsForRoleSetter(Integer roleId, List<Integer> groupIds, String sso) {

			this.roleId = roleId;
			this.groupIds = groupIds;
			this.sso = sso;
		}


		public String getSql() {

			return QueryLoader.getQuery(QueryConstants.PWi_GROUP_ROLE_INSERT);
		}


		public int getBatchSize() {

			return groupIds.size();
		}


		public void setValues(PreparedStatement ps, int grpIdIndex) throws SQLException {

			ps.setInt(1, roleId.intValue());
			ps.setInt(2, groupIds.get(grpIdIndex).intValue());
			ps.setString(3, sso);
			ps.setString(4, sso);
		}
	}


	/**
	 * Remove groups for Object Type
	 */
	public void deleteGroupsForRole(List<Integer> groupIdsToRemoveForRole, Integer roleId) {

		RemoveGroupsForRoleSetter pss = new RemoveGroupsForRoleSetter(roleId, groupIdsToRemoveForRole);

		jdbcTemplate.update(pss.getSql(), pss);
	}


	private static class RemoveGroupsForRoleSetter implements PreparedStatementSetter {

		private Integer roleId;


		private List<Integer> groupIds;


		public RemoveGroupsForRoleSetter(Integer roleId, List<Integer> groupIds) {

			this.roleId = roleId;
			this.groupIds = groupIds;
		}


		public String getSql() {

			StringBuffer buffer = new StringBuffer();
			buffer.append(QueryLoader.getQuery(QueryConstants.PWi_GROUP_ROLE_DELETE));
			buffer.append(" (");
			buffer.append(DaoUtil.getInstance().generateInClausePlaceholders(groupIds.size()));
			buffer.append(")");

			return buffer.toString();
		}


		public void setValues(PreparedStatement ps) throws SQLException {

			int index = 1;
			ps.setInt(index++, roleId.intValue());
			for (Integer groupId : groupIds) {
				ps.setInt(index++, groupId.intValue());
			}
		}
	}



	@Override
	public void deleteRole(Integer roleSeqId) {

		RemoveRoleSetter pss = new RemoveRoleSetter(roleSeqId);

		jdbcTemplate.update(pss.getSql(), pss);
	}


	private static class RemoveRoleSetter implements PreparedStatementSetter {

		private Integer roleId;


		public RemoveRoleSetter(Integer roleId) {

			this.roleId = roleId;
		}


		public String getSql() {

			StringBuffer buffer = new StringBuffer();
			buffer.append(QueryLoader.getQuery(QueryConstants.PWi_ROLE_DELETE));
			return buffer.toString();
		}


		public void setValues(PreparedStatement ps) throws SQLException {

			int index = 1;
			ps.setInt(index++, roleId.intValue());
		}
	}



	@Override
	public List<String> getRoleTypelistList() {
		
		@SuppressWarnings("unchecked")
		List<String> result = (List<String>) jdbcTemplate.query(QueryLoader.getQuery(QueryConstants.PWi_ROLE_TYPES), new RowMapper() {
		      public Object mapRow(ResultSet resultSet, int i) throws SQLException {
		          return resultSet.getString(1);
		        }
		      });
		return result;
	}
	
}
