package com.geinfra.geaviation.pwi.bean.helpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.model.TemplateVO;
import com.geinfra.geaviation.pwi.service.helpers.ExecutionOutputTuple;
import com.geinfra.geaviation.pwi.service.vo.ExecutionMode;
import com.geinfra.geaviation.pwi.service.vo.OutputType;

/**
 * Project      : Product Lifecycle Management Intelligence
 * Date Written : Sep 23, 2011
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2013 GE All rights reserved
 * 
 * Description :
 * 
 * Revision Log Sep 23, 2011 | v1.0.
 * --------------------------------------------------------------
 */
public class ExecutionOutputViewUtil {
	private static final ExecutionOutputViewUtil INSTANCE = new ExecutionOutputViewUtil();
	
	private ExecutionOutputViewUtil() {
		// nothing to do here.
		// private because it's a singleton.
	}
	
	public static ExecutionOutputViewUtil getInstance() {
		return INSTANCE;
	}

	public List<SelectItem> getExecutionModes(
			List<ExecutionOutputTuple> available) {
		// Get unique list of execution modes in the order they first occur in
		// available
		List<ExecutionMode> executionModes = new ArrayList<ExecutionMode>();
		for (ExecutionOutputTuple tuple : available) {
			if (!executionModes.contains(tuple.getExecutionMode())) {
				executionModes.add(tuple.getExecutionMode());
			}
		}

		// Convert to list of select items
		List<SelectItem> executionModeItems = new ArrayList<SelectItem>();
		for (ExecutionMode executionMode : executionModes) {
			executionModeItems.add(new SelectItem(executionMode.getId(),
					executionMode.getLabel()));
		}

		return executionModeItems;
	}

	public String getSelectedExecutionMode(ExecutionOutputTuple initial) {
		return initial.getExecutionMode().getId();
	}

	public Map<String, List<SelectItem>> getOutputTypesPerExecutionMode(
			List<ExecutionOutputTuple> available) {
		// Get unique list of execution modes in the order they first occur in
		// available
		Map<String, List<SelectItem>> outputTypesPerExecutionMode = new HashMap<String, List<SelectItem>>();
		for (ExecutionOutputTuple tuple : available) {
			List<SelectItem> outputTypes = outputTypesPerExecutionMode
					.get(tuple.getExecutionMode().getId());
			if (outputTypes == null) {
				outputTypes = new ArrayList<SelectItem>();
				outputTypesPerExecutionMode.put(tuple.getExecutionMode()
						.getId(), outputTypes);
			}

			String value = getOutputTypeIdFromTuple(tuple);
			String label = null;
			if (OutputType.TEMPLATE.equals(tuple.getOutputType())) {
				label = tuple.getTemplate().getTemplateName();
			} else {
				label = tuple.getOutputType().getLabel();
			}

			outputTypes.add(new SelectItem(value, label));
		}

		return outputTypesPerExecutionMode;
	}

	public Map<String, String> getDefaultOutputTypePerExecutionMode(
			Map<ExecutionMode, ExecutionOutputTuple> defaults) {
		Map<String, String> defaultOutputTypePerExecutionMode = new HashMap<String, String>();
		for (Map.Entry<ExecutionMode, ExecutionOutputTuple> entry : defaults
				.entrySet()) {
			ExecutionMode executionMode = entry.getKey();
			ExecutionOutputTuple tuple = entry.getValue();

			String outputTypeId = getOutputTypeIdFromTuple(tuple);

			defaultOutputTypePerExecutionMode.put(executionMode.getId(),
					outputTypeId);
		}
		return defaultOutputTypePerExecutionMode;
	}

	public String getSelectedOutputType(ExecutionOutputTuple initial) {
		return getOutputTypeIdFromTuple(initial);
	}

	public Map<String, OutputType> getOutputTypeDecoder(
			List<ExecutionOutputTuple> available) {
		// Get unique lists of output types and templates
		Set<OutputType> outputTypes = new HashSet<OutputType>();
		Set<TemplateVO> templates = new HashSet<TemplateVO>();
		for (ExecutionOutputTuple tuple : available) {
			outputTypes.add(tuple.getOutputType());
			if (tuple.getTemplate() != null) {
				templates.add(tuple.getTemplate());
			}
		}

		// Convert to map
		Map<String, OutputType> outputTypeDecoder = new HashMap<String, OutputType>();
		for (OutputType outputType : outputTypes) {
			if (OutputType.TEMPLATE.equals(outputType)) {
				for (TemplateVO template : templates) {
					String id = outputType.getId()
							+ template.getTemplateId();
					outputTypeDecoder.put(id, outputType);
				}
			} else {
				outputTypeDecoder.put(outputType.getId(), outputType);
			}
		}

		return outputTypeDecoder;
	}

	public Map<String, TemplateVO> getTemplateDecoder(
			List<ExecutionOutputTuple> available) {
		// Get unique lists of output types and templates
		Set<OutputType> outputTypes = new HashSet<OutputType>();
		Set<TemplateVO> templates = new HashSet<TemplateVO>();
		for (ExecutionOutputTuple tuple : available) {
			outputTypes.add(tuple.getOutputType());
			if (tuple.getTemplate() != null) {
				templates.add(tuple.getTemplate());
			}
		}

		// Convert to map
		Map<String, TemplateVO> templateDecoder = new HashMap<String, TemplateVO>();
		for (OutputType outputType : outputTypes) {
			if (OutputType.TEMPLATE.equals(outputType)) {
				for (TemplateVO template : templates) {
					String id = outputType.getId()
							+ template.getTemplateId();
					templateDecoder.put(id, template);
				}
			}
		}

		return templateDecoder;
	}

	private String getOutputTypeIdFromTuple(ExecutionOutputTuple tuple) {
		String outputTypeId = null;
		if (OutputType.TEMPLATE.equals(tuple.getOutputType())) {
			outputTypeId = tuple.getOutputType().getId()
					+ tuple.getTemplate().getTemplateId();
		} else {
			outputTypeId = tuple.getOutputType().getId();
		}
		return outputTypeId;
	}
}
