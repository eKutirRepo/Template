package com.geinfra.geaviation.pwi.batch;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.common.AppEnv;
import com.geinfra.geaviation.pwi.common.MainExecution;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.PWiQueryExctnEventVO;
import com.geinfra.geaviation.pwi.model.QueryResult;
import com.geinfra.geaviation.pwi.model.QueryResult.ResultStatus;
import com.geinfra.geaviation.pwi.service.QuerySubmissionService;
import com.geinfra.geaviation.pwi.service.QuerySubmissionService.EventStatus;
import com.geinfra.geaviation.pwi.util.LoadProps;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.util.PWiMailMessage;
import com.geinfra.geaviation.pwi.xml.QueryXmlReader;
import com.geinfra.geaviation.pwi.xml.SearchInputXmlReader;
import com.geinfra.geaviation.pwi.xml.SelectedColumnsXmlReader;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.search.util.SearchJaxbUtil;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;

/**
 * 
 * Project : Product Lifecycle Management
 * Date Written : Aug 5, 2010
 * Security : GE Confidential 
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : BatchExecutionJob - Main class for Batch Execution Appworx Job
 * 
 * Revision Log Aug  5, 2010 | v1.0.
 *         pH | Oct 16, 2012 | updated emails, add exp_dt, survive query failure
 *         pH | Oct 30, 2012 | record success before writing results,
 *                             different handling of 0 results
 * -----------------------------------------------------------------------------
 */
public class BatchExecutionJob {
	private static final Logger LOGGER = Logger
			.getLogger(BatchExecutionJob.class);
	/*private static final SimpleDateFormat REQUEST_DATE_FORMAT = new
			SimpleDateFormat("MM/dd/yyyy', \n' hh:mm a");
	private static final SimpleDateFormat EXPIRATION_DATE_FORMAT = new
			SimpleDateFormat("MM/dd/yyyy");*/

	// Injected
	private QuerySubmissionService querySubmissionService;

	public void setQuerySubmissionService(
			QuerySubmissionService querySubmissionService) {
		this.querySubmissionService = querySubmissionService;
	}

	public void executeBatch(MainExecution mainExecution) throws Exception {
		PWiQueryExctnEventVO nextBatchQry = null;
		while ((nextBatchQry = querySubmissionService
				.getNextBatchExecutionQuery()) != null) {
			LOGGER.info("Processing batch query: " + nextBatchQry.getEventId());
			performBatchExecution(nextBatchQry, mainExecution);
			LOGGER.info("Completed executing batch query: "
					+ nextBatchQry.getEventId());
		}
	}

	private void performBatchExecution(PWiQueryExctnEventVO cstmQry,
			MainExecution mainExecution) throws Exception {
		try {
			LOGGER.info("Translating XML...");
			QueryType query = new QueryXmlReader().translateXml(cstmQry
					.getQuery().getQryXml());
			Search search = new SearchInputXmlReader().translateXml(cstmQry
					.getSearchCriteriaXml());
			SelectedColumns selCol = new SelectedColumnsXmlReader()
					.translateXml(cstmQry.getSelectedColumnsXml());

			LOGGER.info("Executing query...");
			// TODO Consider changing API because a public execute query method
			// in the service tier creates ambiguity as to whether to use this
			// or the submit methods to submit queries normally. Might have an
			// executeBatch method or factor out execute query into a
			// separate interface? Also, consider combining the execution with
			// the writing of the result as done in the submit methods?
			QueryResult queryResult = querySubmissionService.executeQuery(
					query, search, selCol, cstmQry.getQueryProcessorName(),
					cstmQry.getExecutedBy(),null);
			
			// Check for cancellation before processing results
			if (!querySubmissionService
					.getExecutionEventById(cstmQry.getEventId())
					.getExecutionStatus().equals(
							EventStatus.CANCELLED.toString())) {
				// Check for failure
				LOGGER.info("Query Execute status..."+queryResult.getResultStatus());
				if (queryResult.getResultStatus() != ResultStatus.SUCCESS) {
					recordFailure(cstmQry, queryResult.getException(),mainExecution);
				} else {
					// The query was not canceled and it ran successfully.
					
					LOGGER.info("Updating to complete...");
					querySubmissionService.updateExecutionEventStatus(
							EventStatus.SUCCESS.toString(),
							cstmQry.getEventId(),
							Integer.valueOf(queryResult.getColumnCount()),
							Integer.valueOf(queryResult.getRowCount()),
							queryResult.getDuration());

					if (queryResult.getRowCount() > 0) {
						LOGGER.info("Writing results...");
						querySubmissionService.writeBatchResults(queryResult,
								search, cstmQry.getOutputType(),
								cstmQry.getTemplateId(),
								cstmQry.getQuery().getQryNm(),
								cstmQry.getExecutedBy(),
								mainExecution.getAppDataPath(),
								cstmQry.getEventId());
					}
		
					LOGGER.info("Sending success email...");
					sendSuccessMail(querySubmissionService.getExecutionEventById(cstmQry.getEventId()),mainExecution);
				}
			}
			// TODO pH 2013.01: see how CheckDBForUpdates handles exceptions
		} catch (Exception e) {
			// Catch Exception so we can send a failure email, then re-throw
			try {
				recordFailure(cstmQry, e, mainExecution);
			} catch (Exception e2) {
				// Log and suppress so it doesn't hide original exception
				LOGGER.fatal("Exception occurred handling exception.", e2);
			}
			throw e;
		}
	}

	/**
	 * Sends a failure message and mark the execution event as failed
	 * 
	 * @param customQuery has the eventID and other info about the failed query
	 * @param exception the cause of the failure
	 * @param mainExecution command line arguments to this batch job
	 * @throws MessagingException
	 */
	private void recordFailure(PWiQueryExctnEventVO customQuery,
		Exception exception, MainExecution mainExecution)
		throws MessagingException {
			sendFailureMail(customQuery, exception, mainExecution);
			querySubmissionService.updateExecutionEventStatus(
					EventStatus.FAIL.toString(),
					customQuery.getEventId().intValue());
	}
	
	private void sendFailureMail(PWiQueryExctnEventVO customQuery,
			Exception exception, MainExecution mainExecution)
			throws MessagingException {
		String emailPostfix = LoadProps.getInstance().loadProps(
				PWiConstants.MAIL_ADDRESS);

		// Send failure message to user
		// ----------------------------

		String userEmail = customQuery.getExecutedBy() + emailPostfix;
		String sender = userEmail;
		List<String> recipients = new ArrayList<String>();
		recipients.add(userEmail);
		if (mainExecution.isSendAdminAllEmail()) {
			recipients.addAll(mainExecution.getAdminEmails());
		}

		StringBuilder subject = new StringBuilder("Power Warehouse Intelligence - Query Failed");
		subject.append(" - ").append(customQuery.getQuery().getQryNm());
		if (AppEnv.DEV.equals(mainExecution.getAppEnv())) {
			subject.append(" (Dev)");
		} else if (AppEnv.QA.equals(mainExecution.getAppEnv())) {
			subject.append(" (QA)");
		}

		StringBuilder body = new StringBuilder()
				.append("An error occurred while executing your query.")
				.append("  Please try again or contact the Help Desk.  ");
		body.append(getModifyLink(mainExecution.getToolsUrl(),
				customQuery.getEventId()));
		body.append('.');
		appendSubmissionInfo(body, customQuery);

		PWiMailMessage.sendAsHtml(sender, recipients, subject.toString(),
				body.toString());

		// Send failure message to admin
		// -----------------------------

		// Create subject
		StringBuilder adminSubject = new StringBuilder(
				"Power Warehouse Intelligence - Query Execution with ID ");
		adminSubject.append(customQuery.getEventId());
		adminSubject.append(" Failed");
		if (AppEnv.DEV.equals(mainExecution.getAppEnv())) {
			adminSubject.append(" (Dev)");
		} else if (AppEnv.QA.equals(mainExecution.getAppEnv())) {
			adminSubject.append(" (QA)");
		}

		// Append stack trace to body
		body.append("<br/><br/>Stack trace:<br/><br/>");
		StringWriter stackTraceWriter = new StringWriter();
		exception.printStackTrace(new PrintWriter(stackTraceWriter));
		body.append(stackTraceWriter.toString());

		// Send mail
		PWiMailMessage.sendAsHtml(sender, mainExecution.getAdminEmails(),
				adminSubject.toString(), body.toString());
	}
	
	private void appendSubmissionInfo(StringBuilder msgBody,
			PWiQueryExctnEventVO cstmQry) {
		SimpleDateFormat REQUEST_DATE_FORMAT = new
							SimpleDateFormat("MM/dd/yyyy', \n' hh:mm a");
		msgBody.append("<br/><br/>Query Name: ");
		msgBody.append(cstmQry.getQuery().getQryNm());
		msgBody.append("<br/>Executed: ");
		msgBody.append(REQUEST_DATE_FORMAT.format(cstmQry.getDateExecuted()));
		msgBody.append("<br/>Input Parameters: ");
		try {
			String params = SearchJaxbUtil.getSearchParametersForDisplay(
					cstmQry.getSearchCriteriaXml());
			msgBody.append(SearchJaxbUtil.abbreviatedSearchParameters(params));
			if (SearchJaxbUtil.isSearchParametersLong(params)) {
				msgBody.append(" (...)");
			}
		} catch (PWiException e) {
			LOGGER.error("Unable to append Parameters: ", e);
			msgBody.append("<Error retrieving parameters>");
		}
	}

	private void sendSuccessMail(PWiQueryExctnEventVO customQuery,
			MainExecution mainExecution) throws MessagingException {
		SimpleDateFormat EXPIRATION_DATE_FORMAT = new
							SimpleDateFormat("MM/dd/yyyy");
		// Get email postfix
		String emailPostfix = LoadProps.getInstance().loadProps(
				PWiConstants.MAIL_ADDRESS);

		String userEmail = customQuery.getExecutedBy() + emailPostfix;

		// Create sender
		String sender = userEmail;

		// Create recipients
		List<String> recipients = new ArrayList<String>();
		recipients.add(userEmail);
		if (mainExecution.isSendAdminAllEmail()) {
			recipients.addAll(mainExecution.getAdminEmails());
		}

		// Create subject
		StringBuilder subject = new StringBuilder(PWiConstants.MAIL_SUBJECT);
		subject.append(" - ").append(customQuery.getQuery().getQryNm());
		if (AppEnv.DEV.equals(mainExecution.getAppEnv())) {
			subject.append(" (Dev)");
		} else if (AppEnv.QA.equals(mainExecution.getAppEnv())) {
			subject.append(" (QA)");
		}

		// Create body
		StringBuilder body = new StringBuilder();
		if (customQuery.getRowCount() > 0) {
			body.append(getBatchLink(mainExecution.getToolsUrl()));
		} else {
			body.append("Your query returned 0 results.  ");
			body.append(getModifyLink(mainExecution.getToolsUrl(),
					customQuery.getEventId()));
			body.append('.');
		}
		appendSubmissionInfo(body, customQuery);
		if (customQuery.getRowCount() > 0) {
			body.append("<br/>Number of Results: ");
			body.append(customQuery.getRowCount());
			body.append("<br/>Result Expiration: ");
			body.append(EXPIRATION_DATE_FORMAT.format(
					customQuery.getExpirationDate()));
		}

		PWiMailMessage.sendAsHtml(sender, recipients, subject.toString(),
				body.toString());
	}

	private String getBatchLink(String url) {
		return (new StringBuilder()).append("<a href=\"").append(url).append(
				"/pwi/pages/batchResult.jsf\">Query Results<a>").toString();
		//update the code as pwi is not using auth porta
				//"/portal/auth/portal/main/PWiBatch-Home\">Query Results<a>")
				
	}

	private String getModifyLink(String url, Integer id) {
		return (new StringBuilder()).append("<a href=\"").append(url).append(
				"/pwi/Bookmark?type=history&historyId=")
				.append(id).append("&action=modify\">Click here to modify your query<a>")
				.toString();
	}
}
