package com.geinfra.geaviation.pwi.common;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.naming.NamingException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;

import com.geinfra.geaviation.pwi.service.ConfigService;
import com.geinfra.geaviation.pwi.util.BookmarkableLinkUtil;
import com.geinfra.geaviation.pwi.util.PWiMailMessage;

/**
 * 
 * Project      : Product Lifecycle Management Intelligence
 * Date Written : Aug 11, 2010
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : MainExecution - common class for executing Appworx jobs
 * 
 * Revision Log Aug 11, 2010 | v1.0.
 * 2013.01.07 pH  Added an argument for the mail server
 * --------------------------------------------------------------
 */
public final class MainExecution {
	public static final int FAILED_EXIT_STATUS = -1;
	public static final int SUCCEEDED_EXIT_STATUS = 0;
	private static final Logger LOGGER = Logger.getLogger(MainExecution.class);

	private AppEnv appEnv;
	private String toolsUrl;
	private String appDataPath;
	private String primLogin;
	private String primPwd;
	private String primPwdKey;
	private String secLogin;
	private String secPwd;
	private String secPwdKey;
	private String mailServer;
	private List<String> adminEmails;
	private boolean sendAdminAllEmail;
	private int queryTimeoutSeconds;
	private Map<String, String> connectionUrls = new HashMap<String, String>();
	private Map<String, LoginType> connectionLoginTypes = new HashMap<String, LoginType>();
	private String logLevel;

	private enum LoginType {
		PRIMARY, SECONDARY;

		public static LoginType fromString(String loginType) {
			if ("p".equalsIgnoreCase(loginType)) {
				return PRIMARY;
			} else if ("s".equalsIgnoreCase(loginType)) {
				return SECONDARY;
			}
			return null;
		}
	}

	private ApplicationContext context;

	public MainExecution(String appCtx, String[] args) throws PWiException,
			NamingException, IOException {
		// Init Spring context
		context = new ClassPathXmlApplicationContext("/spring/" + appCtx
				+ "Context.xml");

		checkAndSetArgs(args);
		initDbConnections();
		//connectToMailServer();
		overrideConfiguration();
		setLoggerConfiguration();
	}

	private void checkAndSetArgs(String[] args) throws PWiException, IOException {
		
		//DecryptPassword decPass = new DecryptPassword();
		
		if (args.length < 12) {
			LOGGER.fatal("Please provide following:");
			LOGGER.fatal("\t 1  - Application Environment (dev/qa/prod)");
			LOGGER.fatal("\t 2  - Tools Portal URL");
			LOGGER.fatal("\t 3  - Application Data Path");
			LOGGER.fatal("\t 4  - Primary DB User");
			LOGGER.fatal("\t 5  - Primary DB Password");
			LOGGER.fatal("\t 6  - Primary DB Password Key");
			LOGGER.fatal("\t 7  - Secondary DB User");
			LOGGER.fatal("\t 8  - Secondary DB Password");
			LOGGER.fatal("\t 9  - Secondary DB Password key");
			LOGGER.fatal("\t 10  - Mail Server URL");
			LOGGER.fatal("\t 11  - Admin Email Addresses (semi-colon delimited)");
			LOGGER.fatal("\t 12  - Send Admin All Email Flag (T or F)");
			LOGGER.fatal("\t 13  - Query timeout in seconds");
			LOGGER.fatal("\t 14  - Log level");
			LOGGER.fatal("\t 15+ - JDCB connections specified in the form loginType:name=jdbcUrl");
			throw new PWiException(
					"Incorrect number of arguments. Argument count: "
							+ args.length);
		}

		int argIndex = 0;
		appEnv = AppEnv.fromString(args[argIndex++]);
		LOGGER.info("Application Environment: " + appEnv);
		// pass toolsURL w/o http:// to BookmarkableLinkUtil
		BookmarkableLinkUtil.setBatchURL(args[argIndex]);
		toolsUrl = "http://" + args[argIndex++];
		LOGGER.info("Tools Portal URL: " + toolsUrl);
		appDataPath = args[argIndex++];
		LOGGER.info("Application Data Path: " + appDataPath);
		primLogin = args[argIndex++];
		
		LOGGER.info("Primary DB User: " + primLogin);
		primPwd = args[argIndex++];
		//primPwdKey =  args[argIndex++];
		//primPwd = decPass.decrypt(primPwd, primPwdKey);
		
		secLogin = args[argIndex++];
		LOGGER.info("Secondary DB User: " + secLogin);
		secPwd = args[argIndex++];
		//secPwdKey = args[argIndex++];
		//secPwd = decPass.decrypt(secPwd, secPwdKey);
		
		// Extract mail server URL
		mailServer = args[argIndex++];
		LOGGER.info("Mail server: " + mailServer);

		// Extract admin email addresses
		adminEmails = Arrays.asList(StringUtils.split(args[argIndex++], ","));
		LOGGER.info("Admin email addresses: " + adminEmails);

		// Extract flag to send admin all email
		sendAdminAllEmail = Boolean.parseBoolean(args[argIndex++]);
		LOGGER.info("Send admin all email: " + sendAdminAllEmail);

		// Extract query timeout in seconds
		queryTimeoutSeconds = Integer.parseInt(args[argIndex++]);
		LOGGER.info("Query timeout in seconds: " + queryTimeoutSeconds);

		// Extract log level
		logLevel = args[argIndex++];
		LOGGER.info("Log level: " + logLevel);
		// Extract remaining arguments as data source connection information
		for (; argIndex < args.length; argIndex++) {
			LoginType loginType = LoginType.fromString(StringUtils
					.substringBefore(args[argIndex], ":"));

			String remaining = StringUtils.substringAfter(args[argIndex], ":");
			String name = StringUtils.substringBefore(remaining, "=");
			String jdbcUrl = StringUtils.substringAfter(remaining, "=");

			connectionUrls.put(name, jdbcUrl);
			connectionLoginTypes.put(name, loginType);
			LOGGER.info("Connection: " + loginType + ":" + name + "="
							+ jdbcUrl);
		}
	}

	private void initDbConnections() throws NamingException {
		// Init data sources
		SimpleNamingContextBuilder contextBuilder = SimpleNamingContextBuilder
				.emptyActivatedContextBuilder();
		for (String name : connectionUrls.keySet()) {
			String url = connectionUrls.get(name);
			LoginType loginType = connectionLoginTypes.get(name);

			// Determine username/password to use
			String username = null;
			String password = null;
			if (loginType == LoginType.PRIMARY) {
				username = primLogin;
				password = primPwd;
			} else if (loginType == LoginType.SECONDARY) {
				username = secLogin;
				password = secPwd;
			} else {
				LOGGER.warn(new StringBuffer()
						.append("Failed to recognize login type for connnection \"")
						.append(name)
						.append("\" as either primary or secondary, so no")
						.append(" username or password set!  loginType: ")
						.append(loginType).toString());
			}

			// Find and update data source
			DriverManagerDataSource ds = (DriverManagerDataSource) context
					.getBean(name);
			ds.setUrl(url);
			ds.setUsername(username);
			ds.setPassword(password);
			contextBuilder.bind("java:/" + name, ds);
			
			LOGGER.info(new StringBuffer("Bound ").append(name)
					.append(" to data source with url ").append(url)
					.append(", login type: ").append(loginType)
					.append(", and username: ").append(username).toString());
		}
	}
	
	private void connectToMailServer() {
		try {
			LOGGER.info("Mail server: connected : " + mailServer);
			PWiMailMessage.setServer(mailServer);
			LOGGER.info("Successfully connected to mail server " + mailServer);
		} catch (MessagingException me) {
			LOGGER.error(new StringBuffer("Unable to connect to mail server ")
					.append(mailServer)
					.append(". No email notifications will be sent.")
					.toString(), me);
		}
	}

	private void overrideConfiguration() throws PWiException {
		ConfigService configService = (ConfigService) getBeanFromContext("configService");

		LOGGER.info("Overriding query timeout setting...");
		configService.overrideQueryTimeoutSecs(queryTimeoutSeconds);
		LOGGER.info("Query timeout set to: "
				+ configService.getQueryTimeoutSecs());

		LOGGER.info("Overriding result size limit setting...");
		configService.overrideResultSizeLimit(0);
		LOGGER.info("Result size limit set to: "
				+ configService.getResultSizeLimit());
	}

	private void setLoggerConfiguration() {
		Logger root = Logger.getRootLogger();
		if (Level.DEBUG.toString().equals(logLevel)) {
			root.setLevel(Level.DEBUG);
			String message = "Log level changed to debug.";
			LOGGER.info(message);
			LOGGER.debug("See?");
		} else if (Level.INFO.toString().equals(logLevel)) {
			root.setLevel(Level.INFO);
			String message = "Log level changed to info.";
			LOGGER.info(message);
		} else if (Level.WARN.toString().equals(logLevel)) {
			root.setLevel(Level.WARN);
			String message = "Log level changed to warn.";
			LOGGER.info(message);
		} else if (Level.ERROR.toString().equals(logLevel)) {
			root.setLevel(Level.ERROR);
			String message = "Log level changed to error.";
			LOGGER.info(message);
		} else if (Level.FATAL.toString().equals(logLevel)) {
			root.setLevel(Level.FATAL);
			String message = "Log level changed to fatal.";
			LOGGER.info(message);
		} else {
			String message = "Failed to change log level.  Log level \""
					+ logLevel + "\" not recognized.";
			LOGGER.warn(message);
		}
	}

	public Object getBeanFromContext(String beanName) {
		return context.getBean(beanName);
	}

	public AppEnv getAppEnv() {
		return appEnv;
	}

	public String getToolsUrl() {
		return toolsUrl;
	}

	public String getAppDataPath() {
		return appDataPath;
	}

	public List<String> getAdminEmails() {
		return adminEmails;
	}

	public boolean isSendAdminAllEmail() {
		return sendAdminAllEmail;
	}

	public int getQueryTimeoutSeconds() {
		return queryTimeoutSeconds;
	}
}
