 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCntSmryOnScrnMB.java
 * @Creation date: 11-Jul-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.common.usermodel.Hyperlink;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFCreationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFHyperlink;
import org.richfaces.component.UIDataTable;

import com.geinfra.geaviation.pwi.data.PLMCFCRPRSRptData;
import com.geinfra.geaviation.pwi.data.PLMCntrtSmryRptData;
import com.geinfra.geaviation.pwi.data.PLMContractSmryData;
import com.geinfra.geaviation.pwi.service.PLMCntrtSmryRptServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

public class PLMCntSmryOnScrnMB {
	/**
	 *  Holds the lOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMCntSmryOnScrnMB.class);
	/**
	 *  Holds the contractSumrReptService
	 */
	private PLMCntrtSmryRptServiceIfc contractSumrReptService = null;
	/**
	 *  Holds the loginMB
	 */
	private PLMCommonMB commonMB;
	/**
	 *  Holds the contractNum
	 */
	private String contractNum = "";
	/**
	 *  Holds the alertMsg
	 */
	private String alertMsg;
	/**
	 *  Holds the cgFlag
	 */
	private boolean cgFlag;
	/**
	 *  Holds the pcFlag
	 */
	private boolean pcFlag;
	/**
	 *  Holds the cstGrpList
	 */
	private List<String> cstGrpList = new ArrayList<String>();
	/**
	 *  Holds the selCstGrpList
	 */
	private List<SelectItem> selCstGrpList = new ArrayList<SelectItem>();
	/**
	 *  Holds the costGroup
	 */
	private String costGroup;
	/**
	 *  Holds the pcInfoList
	 */
	private List<PLMContractSmryData> pcInfoList = new ArrayList<PLMContractSmryData>();
	/**
	 *  Holds the selPcList
	 */
	private List<SelectItem> selPcList = new ArrayList<SelectItem>();
	/**
	 *  Holds the productConf
	 */
	private String productConf;
	/**
	 *  Holds the subCmpnt
	 */
	 private String subCmpnt;
	 /**
	   *  Holds the finalSubcomponents
	   */
	 private List<String> finalSubcomponents = new ArrayList<String>();
	 /**
	   *  Holds the contractInfoFlag
	   */ 
	 private boolean contractInfoFlag;
	 /**
	   *  Holds the projectInfoFlag
	   */
	 private boolean projectInfoFlag;
	 /**
	   *  Holds the hardwareBuilFlag
	   */
	 private boolean hardwareBuilFlag;
	 /**
	   *  Holds the prsDataFlag
	   */
	 private boolean prsDataFlag;
	 /**
	   *  Holds the clinsFlag
	   */
	 private boolean clinsFlag;
	 /**
	   *  Holds the crsDataFlag
	   */
	 private boolean crsDataFlag;
	 /**
	   *  Holds the confFeatureFlag
	   */
	 private boolean confFeatureFlag;
	 /**
	   *  Holds the logicFeatureFlag
	   */
	 private boolean logicFeatureFlag;
	 /**
	   *  Holds the confEndItmFlag
	   */
	 private boolean confEndItmFlag;
	 /**
	   *  Holds the costObjectFlag
	   */
	 private boolean costObjectFlag;
	 /**
	   *  Holds the prjNameList
	   */
	 private List<PLMCntrtSmryRptData> prjNameList = new ArrayList<PLMCntrtSmryRptData>();
	 /**
	   *  Holds the crsList
	   */
	 private List<PLMCntrtSmryRptData> crsList = new ArrayList<PLMCntrtSmryRptData>();
	 /**
	   *  Holds the hardwareBuildDataList
	   */
	 private  List<PLMCntrtSmryRptData> hardwareBuildDataList = new ArrayList<PLMCntrtSmryRptData>();
	 /**
	   *  Holds the cntrctList
	   */
	 private List<PLMCntrtSmryRptData> cntrctList = new ArrayList<PLMCntrtSmryRptData>();
	 /**
	   *  Holds the clinDataList
	   */
	 private List<PLMCntrtSmryRptData> clinDataList = new ArrayList<PLMCntrtSmryRptData>();
	 /**
	   *  Holds the confFeatureDataList
	   */
	 private List<PLMCntrtSmryRptData> confFeatureDataList = new ArrayList<PLMCntrtSmryRptData>();
	 /**
	   *  Holds the logicFeatureDataList
	   */
	 private List<PLMCntrtSmryRptData> logicFeatureDataList = new ArrayList<PLMCntrtSmryRptData>();
	 /**
	   *  Holds the confEndItemDataList
	   */
	 private List<PLMCntrtSmryRptData> confEndItemDataList = new ArrayList<PLMCntrtSmryRptData>();
	 /**
	   *  Holds the costObjectDtList
	   */
	 private List<PLMCntrtSmryRptData> costObjectDtList = new ArrayList<PLMCntrtSmryRptData>();
	 /**
	   *  Holds the prdtRqmntSpecList
	   */
	 private List<PLMCntrtSmryRptData>  prdtRqmntSpecList = new ArrayList<PLMCntrtSmryRptData>();
	 /**
	   *  Holds the cntrctIfoList
	   */
	 private List<PLMCntrtSmryRptData>  cntrctIfoList = new ArrayList<PLMCntrtSmryRptData>();
	 /**
	  * Holds the prsRecList
	  */
	 private List<PLMCntrtSmryRptData> prsRecList = new ArrayList<PLMCntrtSmryRptData>();
	 /**
	  * Holds the crsRecList
	  */
	 private List<PLMCntrtSmryRptData> crsRecList = new ArrayList<PLMCntrtSmryRptData>();
	 /**
	   *  Holds the showFlag
	   */
	 private boolean showFlag;
	 /**
	   *  Holds the prsVal
	   */
	 private UIDataTable prsVal = null;
	 /**
	   *  Holds the crsVal
	   */
	 private UIDataTable crsVal = null;
	 /**
	   *  Holds the prsRecFlag
	   */
	 private boolean prsRecFlag;
	 /**
	   *  Holds the crsRecFlag
	   */
	 private boolean crsRecFlag;
	 /**
	  * Holds the subComponentList
	  */
	 private List<PLMContractSmryData> subComponentList = new ArrayList<PLMContractSmryData>();
	 /**
	  * Holds the chkAllSubComponent
	  */
	 private boolean chkAllSubComponent;
	 /**
	  * Holds the projectDataList
	  */
	 private List<PLMCntrtSmryRptData> projectDataList = new ArrayList<PLMCntrtSmryRptData>();
	 /**
	  * Holds the fetchProjectFlag
	  */
	 private boolean fetchProjectFlag;
	 /**
	   *  Holds the projNmVal
	   */
	 private UIDataTable projNmVal = null;
	 /**
	  * Holds the prsResultmsg
	  */
	 private String prsResultmsg;
	 /**
	  * Holds the crsResultmsg
	  */
	 private String crsResultmsg;
	 /**
	  * Holds the prjResultmsg
	  */
	 private String prjResultmsg;
	 /**
	  * Holds the confFeatureMsg
	  */
	 private String confFeatureMsg;
	 /**
	  * Holds the logfFeatureMsg
	  */
	 private String logFeatureMsg;
	 /**
	  * Holds the confEndItmMsg
	  */
	 private String confEndItmMsg;
	 /**
	  * Holds the costObjectsMsg
	  */
	 private String costObjectsMsg;
	 /**
	  * Holds the contractFlg
	  */
	 private boolean contractFlg;
	 /**
	  * Holds the projectFlg
	  */
	 private boolean projectFlg;
	 /**
	  * Holds the projectDescFlg
	  */
	 private boolean projectDescFlg;
	 /**
	  * Holds the hardbuildFlag
	  */
	 private boolean hardbuildFlag;
	 /**
	  * Holds the prsFlag
	  */
	 private boolean prsFlag;
	 /**
	  * Holds the prsrecFlag
	  */
	 //private boolean prsrecFlag;
	 /**
	  * Holds the clinFlag
	  */
	 private boolean clinFlag;
	 /**
	  * Holds the prsFlag
	  */
	 private boolean crsFlag;
	 /**
	  * Holds the prsrecFlag
	  */
	 private boolean crsrecFlag;
	 /**
	  * Holds the confFtrFlag
	  */
	 private boolean confFtrFlag;
	 /**
	  * Holds the logFtrFlag
	  */
	 private boolean logFtrFlag;
	 /**
	  * Holds the confEndFlag
	  */
	 private boolean confEndFlag;
	 /** 
	  * Holds the costObjFlag
	  */
	 private boolean costObjFlag;
	 /**
	  * Holds the noContractFound
	  */
	 private String noContractFound;
	 /**
	  * Holds the noPCFound
	  */
	 private String noPCFound;
	 /**
	  * Holds the noprsRecFnd
	  */
	 private String noprsRecFnd;
	 /**
	  * Holds the nocrsRecFnd
	  */
	 private String nocrsRecFnd;
	 /**
	  * Holds the nocrsRecFnd
	  */
	 private String noPrjData;
	 /**
	  * Holds the level
	  */
	 private String level = "";
	 /**
	 * Holds the notRequireFlg
	 */
	private boolean notRequireFlg=false;
	 /**
	 * Holds the selectedPrdtType
	 */	
	private List<String> selectedPrdtType = new ArrayList<String>();
	 /**
	 * Holds the prdtTypeListCrs
	 */
	private List<String> prdtTypeListCrs;
	 /**
	 * Holds the prdtTypeListClHb
	 */
	private List<String> prdtTypeListClHb;
	 /**
	  * Holds the pcName
	  */
	 private String pcName;
	 /**
		* Holds the noSubTypeFlg
	 */
	private boolean noSubTypeFlg=false;
	/**
	  * Holds the optionFlag
	  */
	 private boolean optionFlag;
	 /**
	  * Holds the reportNameXls
	  */
	 private String reportNameXls;
	 /**
	  * Holds the fileNameXls
	  */
	 private String fileNameXls;
	 
	 private PLMCntrtSmryRptData plmCntrSmryRptdt;
	/**
	 * Holds the partTypeAllOpen
	 */
	private boolean partTypeAllOpen;

	/**
	 * Holds the disablePrdtType
	 */
	private boolean disablePrdtType;
	 
    /**
	  * Holds the resourceBundle
	  */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");

	 /**
	   *  Holds the categoryFlag
	   */
	 private boolean categoryFlag;


	/**
	 * This method is used to load home page of contract summary On Screen 
	 * 
	 * @return String
	 * @throws PLMCommonException 
	 */
	public String getCntOnScrnHomePage() {
		LOG.info("Entering getCntOnScrnHomePage method");
		
		try {
			commonMB.insertCannedRptRecordHitInfo("Contract Summary Report (On-Screen Report)");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		String fwdFlag="contractSmrySearch";
		  cstGrpList = new ArrayList<String>();
		  pcInfoList = new ArrayList<PLMContractSmryData>();
		  selCstGrpList = new ArrayList<SelectItem>();
		  selPcList = new ArrayList<SelectItem>();
		  alertMsg = "";
		  showFlag =false;
		  contractNum = "";
		  contractInfoFlag=false;
		  projectInfoFlag=false;
		  hardwareBuilFlag=false;
		  prsDataFlag=false;
		  clinsFlag=false;
		  crsDataFlag=false;
		  confFeatureFlag=false;
		  logicFeatureFlag=false;
		  confEndItmFlag=false;
		  costObjectFlag=false;
		  cntrctIfoList= new ArrayList<PLMCntrtSmryRptData>();
		  prjNameList = new ArrayList<PLMCntrtSmryRptData>();
		  projectDataList= new ArrayList<PLMCntrtSmryRptData>();
		  crsList = new ArrayList<PLMCntrtSmryRptData>();
		  crsRecList =new ArrayList<PLMCntrtSmryRptData>();
		  clinDataList = new ArrayList<PLMCntrtSmryRptData>();
		  confFeatureDataList = new ArrayList<PLMCntrtSmryRptData>();
		  logicFeatureDataList = new ArrayList<PLMCntrtSmryRptData>();
		  confEndItemDataList = new ArrayList<PLMCntrtSmryRptData>();
		  costObjectDtList = new ArrayList<PLMCntrtSmryRptData>();
		  prdtRqmntSpecList = new ArrayList<PLMCntrtSmryRptData>();
		  crsRecList = new ArrayList<PLMCntrtSmryRptData>();
		  prsRecList = new ArrayList<PLMCntrtSmryRptData>();
		  hardwareBuildDataList = new ArrayList<PLMCntrtSmryRptData>();
		  prsRecFlag =false;
		  crsRecFlag =false;
		  fetchProjectFlag=false;
		  chkAllSubComponent=false;
    	  finalSubcomponents = new ArrayList<String>();
    	  noContractFound="";
    	  noPCFound="";    	
    	  noprsRecFnd="";
    	  nocrsRecFnd="";
    	  noPrjData="";
    	  contractFlg=false;
    	  projectFlg=false;
    	  projectDescFlg=false;
    	  hardbuildFlag=false;
    	  prsFlag=false;
    	  //prsrecFlag=false;
    	  clinFlag=false;
    	  crsFlag=false;
    	  crsrecFlag=false;
    	  confFtrFlag=false;
    	  logFtrFlag=false;
    	  confEndFlag=false;
    	  costObjFlag=false;
    	  level = "";
    	  notRequireFlg=false;
    	  noSubTypeFlg=false;
    	  pcName="";
    	  reportNameXls="";
    	  fileNameXls="";
    	  optionFlag=false;
    	  categoryFlag =false;
    	  selectedPrdtType.clear();
    	  prdtTypeListCrs = new ArrayList<String>();
    	  prdtTypeListClHb = new ArrayList<String>();
    	  subComponentList = new ArrayList<PLMContractSmryData>();
    	  PLMContractSmryData tempData =new PLMContractSmryData();
    	  tempData.setSubComponent("Contract Info");
    	  tempData.setCheckBoxSel(contractInfoFlag);
    	  subComponentList.add(tempData);
    	  
    	  tempData =new PLMContractSmryData();
    	  tempData.setSubComponent("Project Info");
    	  tempData.setCheckBoxSel(projectInfoFlag);
    	  subComponentList.add(tempData);
    	  
    	  tempData =new PLMContractSmryData();
    	  tempData.setSubComponent("Hardware Builds");
    	  tempData.setCheckBoxSel(hardwareBuilFlag);
    	  subComponentList.add(tempData);
    	  
    	  tempData =new PLMContractSmryData();
    	  tempData.setSubComponent("PRS Data");
    	  tempData.setCheckBoxSel(prsDataFlag);
    	  subComponentList.add(tempData);
    	  
    	  tempData =new PLMContractSmryData();
    	  tempData.setSubComponent("CLIN Data");
    	  tempData.setCheckBoxSel(clinsFlag);
    	  subComponentList.add(tempData);
    	  
    	  tempData =new PLMContractSmryData();
    	  tempData.setSubComponent("CRS Data");
    	  tempData.setCheckBoxSel(crsDataFlag);
    	  subComponentList.add(tempData);
    	  
    	  tempData =new PLMContractSmryData();
    	  tempData.setSubComponent("Configuration Features");
    	  tempData.setCheckBoxSel(confFeatureFlag);
    	  subComponentList.add(tempData);
    	  
    	  tempData =new PLMContractSmryData();
    	  tempData.setSubComponent("Logical Features (MLIs)");
    	  tempData.setCheckBoxSel(logicFeatureFlag);
    	  subComponentList.add(tempData);
    	  
    	 /* tempData =new PLMContractSmryData();
    	  tempData.setSubComponent("Configuration End Items");
    	  tempData.setCheckBoxSel(confEndItmFlag);
    	  subComponentList.add(tempData);*/
    	  
    	  tempData =new PLMContractSmryData();
    	  tempData.setSubComponent("Cost Objects Data");
    	  tempData.setCheckBoxSel(costObjectFlag);
    	  subComponentList.add(tempData);
    	  
	    LOG.info("Exiting getCntOnScrnHomePage method");
		return fwdFlag;
		
	}
	/**
	 * This method is used for validating contract number
	 * 
	 * @param ctrtNum
	 * @return String
	 */
	public String validationForCntrctSmryRpt(String ctrtNum){
		alertMsg = "";
		if (PLMUtils.isEmpty(ctrtNum)) {
			alertMsg = alertMsg + PLMConstants.CNTRCT_SMRY_ONSCN_SEARCH_CRITERIA_EMPTY_CHK;
		} 
		return alertMsg;
	}
	/**
	 * This method is used retrieve Cost group
	 * 
	 *@return String
	 */
	public String getCostGroups(){
		LOG.info("Entering getCostGroups method");
		String fwdFlag="contractSmrySearch";
		try{
			   alertMsg = "";
			   chkAllSubComponent=false;
				  contractInfoFlag=false;
				  projectInfoFlag=false;
				  hardwareBuilFlag=false;
				  prsDataFlag=false;
				  clinsFlag=false;
				  crsDataFlag=false;
				  confFeatureFlag=false;
				  logicFeatureFlag=false;
				  confEndItmFlag=false;
				  costObjectFlag=false;
				  level="";
				  notRequireFlg=false;
				  noSubTypeFlg=false;
				  disablePrdtType=true;
				  partTypeAllOpen = true;
				  pcName="";
				  selectedPrdtType.clear();
		    	  prdtTypeListCrs = new ArrayList<String>();
		    	  prdtTypeListClHb = new ArrayList<String>();
		    	  subComponentList = new ArrayList<PLMContractSmryData>();
		    	  PLMContractSmryData tempData =new PLMContractSmryData();
		    	  tempData.setSubComponent("Contract Info");
		    	  tempData.setCheckBoxSel(contractInfoFlag);
		    	  subComponentList.add(tempData);
		    	  
		    	  tempData =new PLMContractSmryData();
		    	  tempData.setSubComponent("Project Info");
		    	  tempData.setCheckBoxSel(projectInfoFlag);
		    	  subComponentList.add(tempData);
		    	  
		    	  tempData =new PLMContractSmryData();
		    	  tempData.setSubComponent("Hardware Builds");
		    	  tempData.setCheckBoxSel(hardwareBuilFlag);
		    	  subComponentList.add(tempData);
		    	  
		    	  tempData =new PLMContractSmryData();
		    	  tempData.setSubComponent("PRS Data");
		    	  tempData.setCheckBoxSel(prsDataFlag);
		    	  subComponentList.add(tempData);
		    	  
		    	  tempData =new PLMContractSmryData();
		    	  tempData.setSubComponent("CLIN Data");
		    	  tempData.setCheckBoxSel(clinsFlag);
		    	  subComponentList.add(tempData);
		    	  
		    	  tempData =new PLMContractSmryData();
		    	  tempData.setSubComponent("CRS Data");
		    	  tempData.setCheckBoxSel(crsDataFlag);
		    	  subComponentList.add(tempData);
		    	  
		    	  tempData =new PLMContractSmryData();
		    	  tempData.setSubComponent("Configuration Features");
		    	  tempData.setCheckBoxSel(confFeatureFlag);
		    	  subComponentList.add(tempData);
		    	  
		    	  tempData =new PLMContractSmryData();
		    	  tempData.setSubComponent("Logical Features (MLIs)");
		    	  tempData.setCheckBoxSel(logicFeatureFlag);
		    	  subComponentList.add(tempData);
		    	  
		    	  /*tempData =new PLMContractSmryData();
		    	  tempData.setSubComponent("Configuration End Items");
		    	  tempData.setCheckBoxSel(confEndItmFlag);
		    	  subComponentList.add(tempData);*/
		    	  
		    	  tempData =new PLMContractSmryData();
		    	  tempData.setSubComponent("Cost Objects Data");
		    	  tempData.setCheckBoxSel(costObjectFlag);
		    	  subComponentList.add(tempData);
				  
				finalSubcomponents = new ArrayList<String>();
			alertMsg = validationForCntrctSmryRpt(contractNum);
			  if(PLMUtils.isEmpty(alertMsg)){
				  if (plmCntrSmryRptdt==null) {
					  plmCntrSmryRptdt = new PLMCntrtSmryRptData();
				  }
				  plmCntrSmryRptdt.setContractExcel(contractNum);
					cntrctList = contractSumrReptService.fetchCntrInfo(contractNum);
			  	   if(PLMUtils.isEmptyList(cntrctList)){
			  		   showFlag =false;
						alertMsg = PLMConstants.CNTRCT_SMRY_ONSCN_SEARCH_CRITERIA;
					 }else{
						  showFlag =true;
						  costGroup="";
						  cstGrpList = new ArrayList<String>();
						  selCstGrpList = new ArrayList<SelectItem>();
						  productConf="";
						  pcInfoList = new ArrayList<PLMContractSmryData>();
						  selPcList = new ArrayList<SelectItem>();
						  cstGrpList = contractSumrReptService.fetchCstGrpData();
						  pcInfoList = contractSumrReptService.fetchProductConf(contractNum);
			             for(int i=0;i<cstGrpList.size();i++){
				          selCstGrpList.add(new SelectItem(cstGrpList.get(i), cstGrpList.get(i)));
				          }
							prdtTypeListCrs.add("Gas");
							prdtTypeListCrs.add("Gas - Options");
							prdtTypeListClHb.add("GT");
							prdtTypeListCrs.add("Steam");
							prdtTypeListCrs.add("Steam - Options");
							prdtTypeListClHb.add("ST");
							prdtTypeListCrs.add("Gen");
							prdtTypeListCrs.add("Gen - Options");
							prdtTypeListClHb.add("GTG");
							prdtTypeListClHb.add("STG");
							prdtTypeListCrs.add("PLANT");
							prdtTypeListClHb.add("Not Applicable");
							
							LOG.info("in prodtTypeListner method prdtTypeListCrs List >>>>>>>>>>>>  "+prdtTypeListCrs);
							LOG.info("in prodtTypeListner method prdtTypeListClHb List >>>>>>>>>>>>  "+prdtTypeListClHb);
		        	  }
			       }
			    }
			catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getCostGroups: ", exception);
				fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Contract Summary Report");
			} 
			return fwdFlag;
	}
	
	/**
	 * This method is used to get Product Configuration
	 * 
	 * @param event
	 */
	public void getPrdouctConf(ActionEvent event){
		LOG.info("Entering getPrdouctConf method");
		try{
			  productConf="";
			  //pcInfoList = new ArrayList<PLMContractSmryData>();
			  selPcList = new ArrayList<SelectItem>();
			  //pcInfoList = contractSumrReptService.fetchProductConf(contractNum,costGroup);
			  if (!PLMUtils.isEmptyList(pcInfoList)) {
			   for(int i=0;i<pcInfoList.size();i++){
				   if (costGroup.equalsIgnoreCase(pcInfoList.get(i).getPcCstGrp())) {
					   selPcList.add(new SelectItem(pcInfoList.get(i).getHwPrdctNm(), 
						    pcInfoList.get(i).getPrdtConfigNm()+" "+pcInfoList.get(i).getPrdtConfigDesc()));
				   }
				}
			  }/* else {
				  pcInfoList = contractSumrReptService.fetchProductConf(contractNum);
				  for(int i=0;i<pcInfoList.size();i++){
					   selPcList.add(new SelectItem(pcInfoList.get(i).getHwPrdctNm(), 
							    pcInfoList.get(i).getPrdtConfigNm()+" "+pcInfoList.get(i).getPrdtConfigDesc()));
					}
			  }*/
			
		 }catch (Exception e) {
			e.printStackTrace();
		}	
	
	}
	/**
	 * This method is used to get sub Component Listener
	 * 
	 * @param event
	 */
	public void subCompListener(ActionEvent ae){
		LOG.info("Entering subCompListener method");
		subCmpnt = (String) FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("rowSubCompName");
		LOG.info("subCmpnt in subCompListener--->"+subCmpnt);
		 			if(!finalSubcomponents.contains(subCmpnt)){
		 				finalSubcomponents.add(subCmpnt);
		 				LOG.info("Added finalSubcomponents in List --->"+finalSubcomponents);
		 		     }
		 		  else{
			 		if(finalSubcomponents.contains(subCmpnt)){
				 	finalSubcomponents.remove(subCmpnt);
				 	LOG.info("Removed finalSubcomponents from List  --->"+finalSubcomponents);
			 		}	
		 		  }
		 
		 if(finalSubcomponents.size()!=0){
			 for(int i=0;i<finalSubcomponents.size();i++){
				 LOG.info("value of finalSubcomponents "+finalSubcomponents.get(i));
			 }
			 LOG.info("value of finalSubcomponents "+finalSubcomponents.size());
		 }	 
   }
	
	
	/**
	 * This method is used for to get sub Component List
	 * 
	 * @param ActionEvent
	 * 
	 */
	public void allSubCompListener(ActionEvent ae){
		LOG.info("Entering allSubCompListener method");
		if(chkAllSubComponent == true){
			finalSubcomponents = new ArrayList<String>();
			finalSubcomponents.add("Contract Info");
			finalSubcomponents.add("Project Info");
			finalSubcomponents.add("Hardware Builds");
			finalSubcomponents.add("PRS Data");
			finalSubcomponents.add("CLIN Data");
			finalSubcomponents.add("CRS Data");
			finalSubcomponents.add("Configuration Features");
			finalSubcomponents.add("Logical Features (MLIs)");
			//finalSubcomponents.add("Configuration End Items");
			finalSubcomponents.add("Cost Objects Data");
			
		}else{
			finalSubcomponents = new ArrayList<String>();
			 contractInfoFlag=false;
			  projectInfoFlag=false;
			  hardwareBuilFlag=false;
			  prsDataFlag=false;
			  clinsFlag=false;
			  crsDataFlag=false;
			  confFeatureFlag=false;
			  logicFeatureFlag=false;
			  confEndItmFlag=false;
			  costObjectFlag=false;
		
		}
		
			LOG.info("subcomponentsList.size()----------> "+finalSubcomponents.size());
		LOG.info("Exit form allSubCompListener method");
	}

	/**
	 * This method is used for validating contract number
	 * 
	 *@return String
	 */
	public String validationForGeneratingRpt(){
		alertMsg = "";
		if (PLMUtils.isEmpty(contractNum)) {
			alertMsg =  PLMConstants.CNTRCT_SMRY_RPT_SEARCH_CRITERIA_EMPTY_CHK;
		} 
		else if(PLMUtils.isEmpty(costGroup)){
			alertMsg =  PLMConstants.CNTRCT_SMRY_RPT_COST_GRP_EMPTY_CHK;
		}
		else if(PLMUtils.isEmpty(productConf)){
			alertMsg =  PLMConstants.CNTRCT_SMRY_RPT_PRD_CONF_EMPTY_CHK;
		}
		else if(finalSubcomponents.size() == 0){
			alertMsg =  PLMConstants.CNTRCT_SMRY_SUB_COMP_UNCHK;
		}
		return alertMsg;
	}
	/**
	 * This method is used to Generate Contract Summary onscreen Report
	 * 
	 * @return String
	 * @throws PLMCommonException 
	 */
	public String generateOnScreenRpt() throws PLMCommonException{
	  LOG.info("Entering generateOnScreenRpt method");
	  String fwdFlag="";
	  contractInfoFlag=false;
	  projectInfoFlag=false;
	  hardwareBuilFlag=false;
	  prsDataFlag=false;
	  clinsFlag=false;
	  crsDataFlag=false;
	  confFeatureFlag=false;
	  logicFeatureFlag=false;
	  confEndItmFlag=false;
	  costObjectFlag=false;
	  fetchProjectFlag=false;
	  prsFlag=false;
	  prsRecFlag=false;
	  crsFlag=false;
	  crsRecFlag=false;
	  logFtrFlag = false;
	  confFtrFlag = false;
	  costObjFlag = false;
	  clinFlag = false;
	  cntrctIfoList= new ArrayList<PLMCntrtSmryRptData>();
	  prjNameList = new ArrayList<PLMCntrtSmryRptData>();
	  projectDataList= new ArrayList<PLMCntrtSmryRptData>();
	  crsList = new ArrayList<PLMCntrtSmryRptData>();
	  crsRecList =new ArrayList<PLMCntrtSmryRptData>();
	  clinDataList = new ArrayList<PLMCntrtSmryRptData>();
	  confFeatureDataList = new ArrayList<PLMCntrtSmryRptData>();
	  logicFeatureDataList = new ArrayList<PLMCntrtSmryRptData>();
	  confEndItemDataList = new ArrayList<PLMCntrtSmryRptData>();
	  costObjectDtList = new ArrayList<PLMCntrtSmryRptData>();
	  prdtRqmntSpecList = new ArrayList<PLMCntrtSmryRptData>();
	  crsRecList = new ArrayList<PLMCntrtSmryRptData>();
	  prsRecList = new ArrayList<PLMCntrtSmryRptData>();
	  hardwareBuildDataList = new ArrayList<PLMCntrtSmryRptData>();
	  optionFlag=false;
	  alertMsg = "";
	  
	  alertMsg = validationForGeneratingRpt();
	   if(PLMUtils.isEmpty(alertMsg)){
	     if(finalSubcomponents.size()!=0){
			 for(int i=0;i<finalSubcomponents.size();i++){
				 if(finalSubcomponents.get(i).equals("Contract Info")){
					 contractInfoFlag =true;
				 }
				 if(finalSubcomponents.get(i).equals("Project Info")){
					 projectInfoFlag=true;
				 }
				 if(finalSubcomponents.get(i).equals("Hardware Builds")){
					 hardwareBuilFlag=true;
				 }
				 if(finalSubcomponents.get(i).equals("PRS Data")){
					 prsDataFlag=true;
				 }
				 if(finalSubcomponents.get(i).equals("CLIN Data")){
					 clinsFlag=true;
				 }
				 if(finalSubcomponents.get(i).equals("CRS Data")){
					 crsDataFlag=true;
				 }
				 if(finalSubcomponents.get(i).equals("Configuration Features")){
						confFeatureFlag=true;
				 }
				 if(finalSubcomponents.get(i).equals("Logical Features (MLIs)")){
					 logicFeatureFlag=true;
				 }
				 /*if(finalSubcomponents.get(i).equals("Configuration End Items")){
					 confEndItmFlag=true;
					 }*/
				 if(finalSubcomponents.get(i).equals("Cost Objects Data")){
						costObjectFlag=true;
				 }
				 
				 LOG.info("value of finalSubcomponents "+finalSubcomponents.get(i));
			 }
		 
		 LOG.info("value of finalSubcomponents "+finalSubcomponents.size());
		 
		 if (!PLMUtils.isEmptyList(pcInfoList)) {
				for (PLMContractSmryData data : pcInfoList) {
					LOG.info("At Configuration Features PC Name -------> " + data.getPrdtConfigNm() + "PC Desc ------>" + data.getPrdtConfigDesc());
					if (data.getHwPrdctNm().equals(productConf)) {
						if ("Yes".equalsIgnoreCase(data.getIsOption())) {
							optionFlag = true;
						} else {
							optionFlag = false;
						}
						confFeatureMsg="Configuration Features Data - "+  data.getPrdtConfigNm()+" "+ data.getPrdtConfigDesc();
						logFeatureMsg="Logical Features (MLIs) - "+  data.getPrdtConfigNm()+" "+ data.getPrdtConfigDesc();
						confEndItmMsg="Configuration End Items (MLIs) - "+  data.getPrdtConfigNm()+" "+ data.getPrdtConfigDesc();
						costObjectsMsg="Cost Objects Data - "+  data.getPrdtConfigNm()+" "+ data.getPrdtConfigDesc();
						pcName=data.getPrdtConfigNm();

						plmCntrSmryRptdt.setPcNameExl(data.getPrdtConfigNm()+" "+ data.getPrdtConfigDesc());
					}
				}
			}
		 noContractFound="No records found for the input Contract - "+contractNum;
		 noPCFound="No records found for the selected PC.";
		 
			 if(finalSubcomponents.contains("Contract Info")){
				 LOG.info("Executed contract info");
				 reportNameXls= "contractInfoExcel";
				 fileNameXls="Contract Report";
				 cntrctIfoList = contractSumrReptService.fetchCntrInfo(contractNum);
				 if(cntrctIfoList.size()>0){
					 contractFlg=true;
				 }
				 else{
					 contractFlg=false;
				 }
				 
			 }else if(finalSubcomponents.contains("Project Info")){
				 LOG.info("Executed Project info");
				 reportNameXls= "projectInfoExcel";
				 fileNameXls="Project Report";
				  prjNameList = contractSumrReptService.fetchProjectNameList(contractNum);
				  if(prjNameList.size()>0){
					  projectFlg=true;
					 }
					 else{
					 projectFlg=false;
					 }
				 
			 }else if(finalSubcomponents.contains("Hardware Builds")){
				 LOG.info("Executed Hardware Builds");
				 reportNameXls= "hardwareBuildExcel";
				 fileNameXls="HardWareBuild Report";
				 hardwareBuildDataList = contractSumrReptService.fetchHardwareBuildInfo(contractNum, prdtTypeListClHb,partTypeAllOpen);
				  if(hardwareBuildDataList.size()>0){
					  hardbuildFlag=true;
					 }
					 else{
						 hardbuildFlag=false;
					 }
			 }else if(finalSubcomponents.contains("PRS Data")){
				 LOG.info("Executed PRS Data");
				 reportNameXls= "prsDataExcel";
				 fileNameXls="PRS Report";
				  prdtRqmntSpecList = contractSumrReptService.fetchPrdtRqmntSpecInfo(contractNum);
				  if(prdtRqmntSpecList.size()>0){
					  prsFlag=true;
					 }
					 else{
						 prsFlag=false;
					 }
			 }else if(finalSubcomponents.contains("CLIN Data")){
				 LOG.info("Executed CLINs");
				 reportNameXls= "clinDataExcel";
				 fileNameXls="Clin Report";
				  clinDataList = contractSumrReptService.fetchClinInfo(contractNum,prdtTypeListClHb,partTypeAllOpen);
				  if(clinDataList.size()>0){
					  clinFlag=true;
					 }
					 else{
						 clinFlag=false;
					 }
			 }else if(finalSubcomponents.contains("CRS Data")){
			  setCrsList(contractSumrReptService.fetchCRSInfo(contractNum));
			  reportNameXls= "crsDataExcel";
			  fileNameXls="CRS Report";
				 LOG.info("Executed CRS Data");
				 if(getCrsList().size()>0){
					 crsFlag=true;
				 }else{
					crsFlag=false;
					 }
			 }else if(finalSubcomponents.contains("Configuration Features")){
				 LOG.info("Executed Configuration Features");
				 reportNameXls= "confFeaturesExcel";
				 fileNameXls="Configuration Features Report";
				 /*List<PLMCntrtSmryRptData>  crsListCF = contractSumrReptService.fetchCRSInfo(contractNum);
					List<String> crsRecListTemp = new ArrayList<String>();
					 for (int a = 0; a < crsListCF.size(); a++) {
						crsRecListTemp.add(crsListCF.get(a).getCrsName());
				 	  }
					 if(crsRecListTemp.size()>0){*/
				       confFeatureDataList = contractSumrReptService.fetchConfFeaturesPCNmData(contractNum,pcName,notRequireFlg,noSubTypeFlg,categoryFlag); 
					 //}
				 if(confFeatureDataList.size()>0){
					 confFtrFlag=true;
				 }else{
					 confFtrFlag=false;
					 }
			 }else if(finalSubcomponents.contains("Logical Features (MLIs)")){
				 LOG.info("Executed Logical Features");
				 reportNameXls= "logicFeaturesExcel";
				 fileNameXls="Logical Features Report";
				 List<PLMCntrtSmryRptData> crsListLF = contractSumrReptService.fetchCRSInfo(contractNum);
					List<String> crsRecListTemp = new ArrayList<String>();
					 for (int a = 0; a < crsListLF.size(); a++) {
						crsRecListTemp.add(crsListLF.get(a).getCrsName());
				 	  }
						 logicFeatureDataList = contractSumrReptService.fetcLogicalFeauturesData(productConf, contractNum,crsRecListTemp);
				 if(logicFeatureDataList.size()>0){
					 logFtrFlag=true;
				  }else{
					 logFtrFlag=false;
					 }
			 }else if(finalSubcomponents.contains("Configuration End Items")){
				 LOG.info("Executed Configuration End Items");
				 reportNameXls= "confEndItemsExcel";
				 fileNameXls="Conf End Item Report";
				 List<PLMCntrtSmryRptData> crsListCEI = contractSumrReptService.fetchCRSInfo(contractNum);
					List<String> crsRecListTemp = new ArrayList<String>();
					 for (int a = 0; a < crsListCEI.size(); a++) {
						crsRecListTemp.add(crsListCEI.get(a).getCrsName());
				 	  }
					 		confEndItemDataList = contractSumrReptService.fetcConfigEndItemsData(productConf, contractNum,crsRecListTemp);
				 if(confEndItemDataList.size()>0){
					 confEndFlag=true;
				 }else{
					 confEndFlag=false;
					 }
			 }else if(finalSubcomponents.contains("Cost Objects Data")){
				 LOG.info("Executed Cost Objects");
				 reportNameXls= "costObjectsExcel";
				 fileNameXls="Cost Object Report";
				 costObjectDtList = contractSumrReptService.fetCostObjectsData(level,prdtTypeListCrs,partTypeAllOpen,contractNum,pcName);
				 if(costObjectDtList.size()>0){
					 costObjFlag=true;
				  }else{
					costObjFlag=false;
					 }
			}
	   } 
	   fwdFlag="contractSmryReport";
	 }  
	 else{
		 fwdFlag="contractSmrySearch";
	 }
	   
		return fwdFlag;
	 }
	
	/**
	 * This method is used for getProjectInfo
	 * 
	 * @throws PLMCommonException 
	 */
	public void getContractInfo() throws PLMCommonException {

		LOG.info("Entering in to getContractInfo");
		reportNameXls = "contractInfoExcel";
		fileNameXls = "Contract Report";
		prsRecFlag = false;
		crsRecFlag = false;
		fetchProjectFlag = false;
		logFtrFlag = false;
		confFtrFlag = false;
		costObjFlag = false;
		clinFlag = false;
		if (PLMUtils.isEmptyList(cntrctIfoList)) {
			cntrctIfoList = contractSumrReptService.fetchCntrInfo(contractNum);

		}
		if (cntrctIfoList.size() > 0) {
			contractFlg = true;
		} else {
			contractFlg = false;
		}
	}
	
	/**
	 * This method is used for getProjectInfo
	 * 
	 * @throws PLMCommonException 
	 */
	public void getProjectInfo() throws PLMCommonException {

		LOG.info("Entering in to getProjectInfo");
		fetchProjectFlag = false;
		prsRecFlag = false;
		crsRecFlag = false;
		logFtrFlag = false;
		confFtrFlag = false;
		costObjFlag = false;
		clinFlag = false;
		reportNameXls = "projectInfoExcel";
		fileNameXls = "Project Report";
		if (PLMUtils.isEmptyList(prjNameList)) {
			prjNameList = contractSumrReptService.fetchProjectNameList(contractNum);

		}
		if (prjNameList.size() > 0) {
			projectFlg = true;
		} else {
			projectFlg = false;
		}
	}
	
	
	/**
	 * This method is used for getProjectInfo Data
	 * 
	 * @throws PLMCommonException 
	 */
	public void getProjectInfoData() throws PLMCommonException{
		LOG.info("Entering in to getProjectInfoData");
		prsRecFlag=false;
		crsRecFlag=false;
		logFtrFlag = false;
		confFtrFlag = false;
		costObjFlag = false;
		clinFlag = false;
		projectDataList =new ArrayList<PLMCntrtSmryRptData>();
		PLMCntrtSmryRptData tempData = (PLMCntrtSmryRptData)projNmVal.getRowData();
		reportNameXls="projectInfoDataExcel";
		 fileNameXls="Project Detail Report";
		projectDataList = contractSumrReptService.fetchEmpNamesNRoles(contractNum,tempData.getProjectName());
		if(projectDataList.size()>0){
			projectDescFlg=true;
		
		 if(tempData.getProjectName().contains("ITO")){
			 prjResultmsg="ITO Project Members : "+tempData.getProjectName();
		  }else{
			 prjResultmsg="OTR Project Members : "+tempData.getProjectName();
		   }
		 plmCntrSmryRptdt.setProjectNameExcel(tempData.getProjectName());
		}
		else{
			noPrjData="No Project Members found";
			projectDescFlg=false;
		}
		fetchProjectFlag =true;
	  
	 }
	/**
	 * This method is used for getCRSData
	 * 
	 * @throws PLMCommonException 
	 */
	public void getCRSData() throws PLMCommonException {

		LOG.info("Entering in to getCRSData");
		crsRecFlag = false;
		prsRecFlag = false;
		fetchProjectFlag = false;
		confFtrFlag = false;
		logFtrFlag = false;
		costObjFlag = false;
		clinFlag = false;
		reportNameXls = "crsDataExcel";
		fileNameXls = "CRS Report";
		if (PLMUtils.isEmptyList(crsList)) {
			crsList = contractSumrReptService.fetchCRSInfo(contractNum);

		}
		if (crsList.size() > 0) {
			crsFlag = true;
		} else {
			crsFlag = false;
			nocrsRecFnd = "No records found for CRS Data";
		}
	}
	
	/**
	 * This method is used for 
	 *
	 * @throws PLMCommonException 
	 */
	public void getCrsRecursiveData()throws PLMCommonException{
		LOG.info("Entering in to ");
			prsRecFlag=false;
			fetchProjectFlag =false;
			confFtrFlag = false;
			logFtrFlag = false;
			costObjFlag = false;
			clinFlag = false;
		    crsRecList =new ArrayList<PLMCntrtSmryRptData>();
			 PLMCntrtSmryRptData tempData = (PLMCntrtSmryRptData)crsVal.getRowData();
			 reportNameXls ="crsRecursiveExcel";
			 fileNameXls="CRS Recursive Report";
			 plmCntrSmryRptdt.setCrsName(tempData.getCrsName());
			LOG.info(" CRS prdtTypeListCrs List ------------->"+prdtTypeListCrs);
			crsRecList = contractSumrReptService.fetchCRSRecursiveData(contractNum, tempData.getCrsName(), level, prdtTypeListCrs,partTypeAllOpen);
			if(crsRecList.size()>0){
				crsRecFlag=true;
			}else{
				crsRecFlag=false;
			 nocrsRecFnd="No records found for CRS Data";
			  }
			 crsResultmsg ="Special Requirements CRS Data - "+tempData.getCrsName();
	}
	/**
	 * This method is used for getPRSData
	 * 
	 * @throws PLMCommonException 
	 */
	public void getPRSData() throws PLMCommonException {

		LOG.info("Entering in to getPRSData");
		prsRecFlag = false;
		crsRecFlag = false;
		fetchProjectFlag = false;
		confFtrFlag = false;
		logFtrFlag = false;
		costObjFlag = false;
		clinFlag = false;
		reportNameXls = "prsDataExcel";
		fileNameXls = "PRS Report";
		if (PLMUtils.isEmptyList(prdtRqmntSpecList)) {
			prdtRqmntSpecList = contractSumrReptService.fetchPrdtRqmntSpecInfo(contractNum);

		}
		if (prdtRqmntSpecList.size() > 0) {
			prsFlag = true;
		} else {
			prsFlag = false;
			noprsRecFnd = "No records found for PRS Data";
		}
	}
	
	/**
	 * This method is used for getPrsRecursiveData
	 * 
	 * @throws PLMCommonException 
	 */
	public void getPrsRecursiveData() throws PLMCommonException{
		LOG.info("Entering in to getPrsRecursiveData");
			crsRecFlag=false;
			fetchProjectFlag =false;
			confFtrFlag = false;
			logFtrFlag = false;
			costObjFlag = false;
			clinFlag = false;
			prsRecList =new ArrayList<PLMCntrtSmryRptData>();
			PLMCntrtSmryRptData tempData = (PLMCntrtSmryRptData)prsVal.getRowData();
			reportNameXls="prsRecursiveExcel";
			plmCntrSmryRptdt.setPrdtRqmntSpecNm(tempData.getPrdtRqmntSpecNm());
			 fileNameXls="PRS Recursive Report";
		     prsRecList = contractSumrReptService.fetchPRSRecursiveData(tempData.getPrdtRqmntSpecNm());
		     if(prsRecList.size()>0){
		    	 prsRecFlag=true;
			 }else{
				 prsRecFlag=false;
			 }
		     prsResultmsg ="Product Requirement Spec Data - "+tempData.getPrdtRqmntSpecNm();
			 noprsRecFnd="No records found for PRS Data";
		     //prsRecFlag =true;
	}
	

	/**
	 * This method is used for getPrsRecursiveData
	 * 
	 * @throws PLMCommonException 
	 */
	public void getPrsRecDataCfRpt1() throws PLMCommonException{
		PLMCFCRPRSRptData tempData = (PLMCFCRPRSRptData)prsVal.getRowData();
		getPrsRecDataCfRpt(tempData.getPrsName1());
	}
	/**
	 * This method is used for getPrsRecursiveData
	 * 
	 * @throws PLMCommonException 
	 */
	public void getPrsRecDataCfRpt2() throws PLMCommonException{
		PLMCFCRPRSRptData tempData = (PLMCFCRPRSRptData)prsVal.getRowData();
		getPrsRecDataCfRpt(tempData.getPrsName2());
	}
	/**
	 * This method is used for getPrsRecursiveData
	 * 
	 * @throws PLMCommonException 
	 */
	public void getPrsRecDataCfRpt3() throws PLMCommonException{
		PLMCFCRPRSRptData tempData = (PLMCFCRPRSRptData)prsVal.getRowData();
		getPrsRecDataCfRpt(tempData.getPrsName3());
	}
	/**
	 * This method is used for getPrsRecursiveData
	 * 
	 * @throws PLMCommonException 
	 */
	public void getPrsRecDataCfRpt(String prsName) throws PLMCommonException{
		LOG.info("Entering in to getPrsRecDataCfRpt");
			crsRecFlag=false;
			fetchProjectFlag =false;
			confFtrFlag = false;
			logFtrFlag = false;
			costObjFlag = false;
			clinFlag = false;
			prsRecList =new ArrayList<PLMCntrtSmryRptData>();
			reportNameXls="prsRecursiveExcel";
			 fileNameXls="PRS Recursive Report";
		     prsRecList = contractSumrReptService.fetchPRSRecursiveData(prsName);
		     if(prsRecList.size()>0){
		    	 prsRecFlag=true;
			 }else{
				 prsRecFlag=false;
			 }
		     prsResultmsg ="Product Requirement Spec Data - "+prsName;
			 noprsRecFnd="No records found for PRS Data";
		     //prsRecFlag =true;
	}
	
	/**
	 * This method is used for getClinData
	 * 
	 * @throws PLMCommonException 
	 */
	public void getClinData() throws PLMCommonException {

		LOG.info("Entering in to getClinData");
		crsRecFlag = false;
		prsRecFlag = false;
		fetchProjectFlag = false;
		logFtrFlag = false;
		confFtrFlag = false;
		costObjFlag = false;
		reportNameXls = "clinDataExcel";
		fileNameXls = "Clin Report";
		if (PLMUtils.isEmptyList(clinDataList)) {
			clinDataList = contractSumrReptService.fetchClinInfo(contractNum, prdtTypeListClHb,partTypeAllOpen);

		}
		if (clinDataList.size() > 0) {
			clinFlag = true;
		} else {
			clinFlag = false;
		}
	}
	
	/**
	 * This method is used for getHardWareBuidData
	 * 
	 * @throws PLMCommonException 
	 */
	public void getHardWareBuidData() throws PLMCommonException {

		LOG.info("Entering in to getHardWareBuidData");
		crsRecFlag = false;
		prsRecFlag = false;
		fetchProjectFlag = false;
		logFtrFlag = false;
		confFtrFlag = false;
		costObjFlag = false;
		clinFlag = false;
		reportNameXls = "hardwareBuildExcel";
		fileNameXls = "HardWareBuild Report";
		if (PLMUtils.isEmptyList(hardwareBuildDataList)) {
			hardwareBuildDataList = contractSumrReptService.fetchHardwareBuildInfo(contractNum, prdtTypeListClHb,partTypeAllOpen);

		}
		if (hardwareBuildDataList.size() > 0) {
			hardbuildFlag = true;
		} else {
			hardbuildFlag = false;
		}
	}
	
	/**
	 * This method is used for getConfFeatureData
	 * 
	 * @throws PLMCommonException 
	 */
	public void getConfFeatureData() throws PLMCommonException{
		LOG.info("Entering in to getConfFeatureData");
		crsRecFlag=false;
		prsRecFlag=false;
		fetchProjectFlag =false;
		logFtrFlag = false;
		costObjFlag = false;
		clinFlag = false;
		reportNameXls= "confFeaturesExcel";
		fileNameXls="Configuration Features Report";
		if(PLMUtils.isEmptyList(confFeatureDataList)){
		     confFeatureDataList = contractSumrReptService.fetchConfFeaturesPCNmData(contractNum,pcName,notRequireFlg,noSubTypeFlg,categoryFlag);  
		} 
		if(confFeatureDataList.size()>0){
			confFtrFlag=true;
		}else{
			confFtrFlag=false;
		}
	 }
	
	/**
	 * This method is used for getlogicFeatureData
	 * 
	 * @throws PLMCommonException 
	 */
	public void getlogicFeatureData() throws PLMCommonException {

		LOG.info("Entering in to getlogicFeatureData");
		crsRecFlag = false;
		prsRecFlag = false;
		fetchProjectFlag = false;
		confFtrFlag = false;
		costObjFlag = false;
		clinFlag = false;
		reportNameXls = "logicFeaturesExcel";
		fileNameXls = "Logical Features Report";
		if (PLMUtils.isEmptyList(logicFeatureDataList)) {
			List<PLMCntrtSmryRptData> crsListTemp = contractSumrReptService.fetchCRSInfo(contractNum);
			List<String> crsRecListTemp = new ArrayList<String>();
			for (int a = 0; a < crsListTemp.size(); a++) {
				crsRecListTemp.add(crsListTemp.get(a).getCrsName());
			}
			logicFeatureDataList = contractSumrReptService.fetcLogicalFeauturesData(productConf, contractNum, crsRecListTemp);


		}
		if (logicFeatureDataList.size() > 0) {
			logFtrFlag = true;
		} else {
			logFtrFlag = false;
		}
	}
	
	/**
	 * This method is used for getConfEndItemData
	 * 
	 * @throws PLMCommonException 
	 */
	public void getConfEndItemData() throws PLMCommonException{
		LOG.info("Entering in to getConfEndItemData");
		 crsRecFlag=false;
		 prsRecFlag=false;
		 fetchProjectFlag =false;
		reportNameXls= "confEndItemsExcel";
		fileNameXls="Conf End Item Report";
		if(PLMUtils.isEmptyList(confEndItemDataList)){
			List<PLMCntrtSmryRptData>	crsListTemp = contractSumrReptService.fetchCRSInfo(contractNum);
				List<String> crsRecListTemp = new ArrayList<String>();
				 for (int a = 0; a < crsListTemp.size(); a++) {
					crsRecListTemp.add(crsListTemp.get(a).getCrsName());
			 	  }
					 confEndItemDataList = contractSumrReptService.fetcConfigEndItemsData(productConf, contractNum,crsRecListTemp);
			if(confEndItemDataList.size()>0){
				 confEndFlag=true;
			 } else{
			 confEndFlag=false;
			  }
		}
	 }
	
	
	/**
	 * This method is used for getCostObjectData
	 * 
	 * @throws PLMCommonException 
	 */
	public void getCostObjectData() throws PLMCommonException {

		LOG.info("Entering in to getCostObjectData");
		crsRecFlag = false;
		prsRecFlag = false;
		fetchProjectFlag = false;
		logFtrFlag = false;
		confFtrFlag = false;
		clinFlag = false;
		reportNameXls = "costObjectsExcel";
		fileNameXls = "Cost Object Report";
		if (PLMUtils.isEmptyList(costObjectDtList)) {
			costObjectDtList = contractSumrReptService.fetCostObjectsData(level,prdtTypeListCrs,partTypeAllOpen,contractNum,pcName);

		}
		if (costObjectDtList.size() > 0) {
			costObjFlag = true;
		} else {
			costObjFlag = false;
		}
	}
	
	/**
	 * This method is used for backtoProjectInfo
	 * 
	 */
	public void backtoProjectInfo(){
		 reportNameXls= "projectInfoExcel";
		 fileNameXls="Project Report";
		fetchProjectFlag =false;
	}
	
	/**
	 * This method is used for backtoPrsData
	 * 
	 */
	public void backtoPrsData(){
		reportNameXls= "prsDataExcel";
		fileNameXls="PRS Report";
		prsRecFlag =false;
	}
	/**
	 * This method is used for backtoPrsData
	 * 
	 */
	public void backtoPrsDataCfRpt(){
		prsRecFlag =false;
	}
	
	/**
	 * This method is used for backtoCrsData
	 * 
	 */
	public void backtoCrsData(){
		 reportNameXls= "crsDataExcel";
		 fileNameXls="CRS Report";
		crsRecFlag =false;
	}
	
	/**
	 * This method is used for prodtTypeListner
	 * 
	 */
	public void prodtTypeListner(ActionEvent ae) {
		LOG.info("in prodtTypeListner method");
		prdtTypeListCrs = new ArrayList<String>();
		prdtTypeListClHb = new ArrayList<String>();
		if(selectedPrdtType.contains("Gas")){
			prdtTypeListCrs.add("Gas");
			prdtTypeListCrs.add("Gas - Options");
			prdtTypeListClHb.add("GT");
		}
		if(selectedPrdtType.contains("Steam")){
			prdtTypeListCrs.add("Steam");
			prdtTypeListCrs.add("Steam - Options");
			prdtTypeListClHb.add("ST");
		}
		if(selectedPrdtType.contains("Gen")){
			prdtTypeListCrs.add("Gen");
			prdtTypeListCrs.add("Gen - Options");
			prdtTypeListClHb.add("GTG");
			prdtTypeListClHb.add("STG");
		}
		if(selectedPrdtType.contains("Plant")){
			prdtTypeListCrs.add("PLANT");
			prdtTypeListClHb.add("Not Applicable");
		}
		LOG.info("in prodtTypeListner method prdtTypeListCrs List >>>>>>>>>>>>  "+prdtTypeListCrs);
		LOG.info("in prodtTypeListner method prdtTypeListClHb List >>>>>>>>>>>>  "+prdtTypeListClHb);
	}
	
	/**
	 * This method is used for to get Part Type Check box
	 * 
	 * @param ActionEvent
	 * 
	 */
	public void partTypeChkBoxListener(ActionEvent ae) {
		LOG.info("Entering partTypeChkBoxListener method");
		selectedPrdtType.clear();
		prdtTypeListCrs = new ArrayList<String>();
		prdtTypeListClHb = new ArrayList<String>();
			if (partTypeAllOpen) {
				disablePrdtType=true;
				prdtTypeListCrs.add("Gas");
				prdtTypeListCrs.add("Gas - Options");
				prdtTypeListClHb.add("GT");
				prdtTypeListCrs.add("Steam");
				prdtTypeListCrs.add("Steam - Options");
				prdtTypeListClHb.add("ST");
				prdtTypeListCrs.add("Gen");
				prdtTypeListCrs.add("Gen - Options");
				prdtTypeListClHb.add("GTG");
				prdtTypeListClHb.add("STG");
				prdtTypeListCrs.add("PLANT");
				prdtTypeListClHb.add("Not Applicable");
			}else{
				disablePrdtType=false;
			}
			LOG.info("in prodtTypeListner method prdtTypeListCrs List >>>>>>>>>>>>  "+prdtTypeListCrs);
			LOG.info("in prodtTypeListner method prdtTypeListClHb List >>>>>>>>>>>>  "+prdtTypeListClHb);
	}

	public void downloadExcel() throws PLMCommonException {
		LOG.info("Entering downloadExcel Method");
		String reportName=reportNameXls;
		String fileName=fileNameXls;
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		
		//Contract Info Tab
		if (reportName.equals("contractInfoExcel")) {

			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					new PLMXlsxRptColumn("cntrtNm", "Contract Name",FormatType.TEXT, null, null, 20),
					new PLMXlsxRptColumn("cntrtDesc", "Contract Description",FormatType.TEXT, null, null, 50) 
					};
			PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] { 
					new PLMXlsxRptColumn("contractExcel", "Contract Number", FormatType.TEXT) 
					};
			excelUtil.export(cntrctIfoList, reportColumns, fileName, fileName,true, critcolumns, plmCntrSmryRptdt);
		}
		
		//Project Info Tab
				if (reportName.equals("projectInfoExcel")) {

					PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
							new PLMXlsxRptColumn("projectName", "Project Name",FormatType.TEXT, null, null, 20),
							new PLMXlsxRptColumn("projectTitle", "Project Title",FormatType.TEXT, null, null, 50)  
							};
					PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] { 
							new PLMXlsxRptColumn("contractExcel", "Contract Number", FormatType.TEXT) 
							};
					excelUtil.export(prjNameList, reportColumns, fileName, fileName,true, critcolumns, plmCntrSmryRptdt);
				}
				
				if (reportName.equals("projectInfoDataExcel")) {

					PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
							new PLMXlsxRptColumn("empName", "Name",FormatType.TEXT, null, null, 30),  
							new PLMXlsxRptColumn("empRole", "GE Role",FormatType.TEXT, null, null, 30),
							new PLMXlsxRptColumn("sso", "SSO",FormatType.TEXT)
							};
					PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] { 
							new PLMXlsxRptColumn("contractExcel", "Contract Number", FormatType.TEXT) ,
							new PLMXlsxRptColumn("projectNameExcel",(plmCntrSmryRptdt.getProjectNameExcel().contains("ITO"))? 
									"ITO Project Members" : "OTR Project Members", FormatType.TEXT) 
							};
					excelUtil.export(projectDataList, reportColumns, fileName, fileName,true, critcolumns, plmCntrSmryRptdt);
				}
				
				//HARDWARE BUILD DATA Tab
				if (reportName.equals("hardwareBuildExcel")) {

					PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
							new PLMXlsxRptColumn("hbClinNm", "Clin Name",FormatType.TEXT, null, null, 25),
							new PLMXlsxRptColumn("hbldNm", "Build Name",FormatType.TEXT, null, null, 25),
							new PLMXlsxRptColumn("hbSrlNum", "Unit Serial Number",FormatType.TEXT, null, null, 20),
							new PLMXlsxRptColumn("shpOrdrNum", "Shop Order Number",FormatType.TEXT, null, null, 20),
							new PLMXlsxRptColumn("hbldType", "Build Type",FormatType.TEXT),
							new PLMXlsxRptColumn("hbldState", "State",FormatType.TEXT, null, null, 15),
							new PLMXlsxRptColumn("hbPartNum", "Part Number",FormatType.TEXT, null, null, 25)
							};
					
					PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] { 
							new PLMXlsxRptColumn("contractExcel", "Contract Number", FormatType.TEXT) 
							};
					excelUtil.export(hardwareBuildDataList, reportColumns, fileName, fileName,true, critcolumns, plmCntrSmryRptdt);
				}
				
				//PRS DATA Tab
				if (reportName.equals("prsDataExcel")) {

					PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
							new PLMXlsxRptColumn("prdtRqmntSpecNm", "Name", FormatType.TEXT, null, null, 20),
							new PLMXlsxRptColumn("prdtRqmntSpecDesc", "Description",FormatType.TEXT, null, null, 45),
							new PLMXlsxRptColumn("prdtRqmntSpecNotes", "Notes",FormatType.TEXT, null, null, 35)
							};
					PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] { 
							new PLMXlsxRptColumn("contractExcel", "Contract Number", FormatType.TEXT) 
							};
					excelUtil.export(prdtRqmntSpecList, reportColumns, fileName, fileName,true, critcolumns, plmCntrSmryRptdt);
				}
				
				if (reportName.equals("prsRecursiveExcel")) {

					PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
							new PLMXlsxRptColumn("prsLevel", "Level",FormatType.TEXT, null, null, 20),
							new PLMXlsxRptColumn("childName", "Name",FormatType.LINK, null, null, 20, "prsChildId"),
							new PLMXlsxRptColumn("childTitle", "Title",FormatType.TEXT, null, null, 30),
							new PLMXlsxRptColumn("childDesc", "Description",FormatType.TEXT, null, null, 30),
							new PLMXlsxRptColumn("reqmtValue", "Data value",FormatType.TEXT, null, null, 25),
							new PLMXlsxRptColumn("uom", "Unit of Measure (A)",FormatType.TEXT),
							new PLMXlsxRptColumn("indicator", "Unit of Measure (B)",FormatType.TEXT),
							new PLMXlsxRptColumn("prsReqNotes", "Requirement Notes",FormatType.TEXT, null, null, 40)
							};
					PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] { 
							new PLMXlsxRptColumn("contractExcel", "Contract Number", FormatType.TEXT), 
							new PLMXlsxRptColumn("prdtRqmntSpecNm", "Product Requirement Spec Data ", FormatType.TEXT)
							};
					excelUtil.export(prsRecList, reportColumns, fileName, fileName,true, critcolumns, plmCntrSmryRptdt);
				}
				
				//CLIN DATA Tab
				if (reportName.equals("clinDataExcel")) {

					PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
							new PLMXlsxRptColumn("clinNameParent", "Name",FormatType.TEXT, null, null, 20),
							new PLMXlsxRptColumn("clinDesc", "Description",FormatType.TEXT, null, null, 35),
							new PLMXlsxRptColumn("sowParagraph", "Product",FormatType.TEXT, null, null, 10),
							new PLMXlsxRptColumn("clinTasking", "Type",FormatType.TEXT, null, null, 10),
							new PLMXlsxRptColumn("clinInitialDeliveryDate", "Initial Delivery Date",FormatType.DATE),
							new PLMXlsxRptColumn("clinStatus", "Status",FormatType.TEXT),
							new PLMXlsxRptColumn("clinIndicator", "Liquidated Damages Indicator",FormatType.TEXT),
							new PLMXlsxRptColumn("satisfiedByTask", "Satisfied By Schedule Task",FormatType.TEXT),
							new PLMXlsxRptColumn("ciNumber", "Cl Number",FormatType.TEXT),
							new PLMXlsxRptColumn("ceiQuantity", "CEI Quantity",FormatType.TEXT)
							};
					PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] { 
							new PLMXlsxRptColumn("contractExcel", "Contract Number", FormatType.TEXT) 
							};
					excelUtil.export(clinDataList, reportColumns, fileName, fileName,true, critcolumns, plmCntrSmryRptdt);
				}
				
				//CRS DATA Tab
				if (reportName.equals("crsDataExcel")) {

					PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
							new PLMXlsxRptColumn("crsName", "Name",FormatType.TEXT, null, null, 20),
							new PLMXlsxRptColumn("crsTitle", "Title",FormatType.TEXT, null, null, 40),
							new PLMXlsxRptColumn("crsRevision", "Revision",FormatType.TEXT, null, null, 9),
							new PLMXlsxRptColumn("crsState", "State",FormatType.TEXT, null, null, 10)
							};
					PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] { 
							new PLMXlsxRptColumn("contractExcel", "Contract Number", FormatType.TEXT) 
							};
					excelUtil.export(crsList, reportColumns, fileName, fileName,true, critcolumns, plmCntrSmryRptdt);
				}
				
				if (reportName.equals("crsRecursiveExcel")) {

					PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
							new PLMXlsxRptColumn("crsrLevel", "Level", FormatType.TEXT, null, null, 20),
							new PLMXlsxRptColumn("crsrName", "Name", FormatType.LINK, null, null, 15, "crsrId"),
							new PLMXlsxRptColumn("crsrTitle", "CRS Title", FormatType.TEXT, null, null, 40),
							new PLMXlsxRptColumn("crsrDesc", "CRS Description", FormatType.TEXT, null, null, 55),
							new PLMXlsxRptColumn("crsrRevision", "Affected MLI's", FormatType.TEXT, null, null, 30),
							new PLMXlsxRptColumn("crsrtoType", "State", FormatType.TEXT),
							new PLMXlsxRptColumn("pcCstGrp", "Product Type", FormatType.TEXT)
							};
					PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] { 
							new PLMXlsxRptColumn("contractExcel", "Contract Number", FormatType.TEXT),
							new PLMXlsxRptColumn("crsName", "Special Requirements CRS Data ", FormatType.TEXT)
							};
					excelUtil.export(crsRecList, reportColumns, fileName, fileName,true, critcolumns, plmCntrSmryRptdt);
				}
				
				
				//CONFIG FEATURE DATA Tab
				if (reportName.equals("confFeaturesExcel")) {
					generateConfigFeatureExl(confFeatureDataList);
					/*PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
							new PLMXlsxRptColumn("cfName", "Config Feature Header Name",FormatType.LINK, null, null, 20, "cfId"),
							new PLMXlsxRptColumn("cfDisplyName", "Config Feature Header",FormatType.TEXT, null, null, 45),
							new PLMXlsxRptColumn("cfConfigOption", "Configuration Selected Option",FormatType.LINK, null, null, 16, "cfConfId"),
							new PLMXlsxRptColumn("cfConfOptDispName", "Configuration Selected Option Display Name",FormatType.TEXT, null, null, 45),
							new PLMXlsxRptColumn("feqSeqOrder", "Sequence Order",FormatType.TEXT, null, null, 10),
							new PLMXlsxRptColumn("legacyFACode", "Legacy F&A Code",FormatType.TEXT, null, null, 25),
							new PLMXlsxRptColumn("optSubType", "Option Sub Type",FormatType.TEXT, null, null, 20)
							};
					PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] { 
							new PLMXlsxRptColumn("contractExcel", "Contract Number", FormatType.TEXT), 
							new PLMXlsxRptColumn("pcNameExl", "Configuration Features Data ", FormatType.TEXT) 
							};
					excelUtil.export(confFeatureDataList, reportColumns, fileName, fileName,true, critcolumns, plmCntrSmryRptdt);*/
					
				}
				
				//LOGICAL FEATURE DATA Tab
				if (reportName.equals("logicFeaturesExcel")) {

					PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
							new PLMXlsxRptColumn("lfLevel", "Level",FormatType.TEXT, null, null, 20),
							new PLMXlsxRptColumn("lfFeatDsplName", "Feature Display Name",FormatType.TEXT, null, null, 20),
							new PLMXlsxRptColumn("lfFeatName", "Feature Name", FormatType.LINK, null, null, 20, "lfFeatId"),
							new PLMXlsxRptColumn("lfFeatDesc", "Feature Description",FormatType.TEXT, null, null, 50),
							new PLMXlsxRptColumn("crName", "Related CR",FormatType.TEXT, null, null, 35)
							};
					PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] { 
							new PLMXlsxRptColumn("contractExcel", "Contract Number", FormatType.TEXT), 
							new PLMXlsxRptColumn("pcNameExl", "Logical Features (MLIs) ", FormatType.TEXT) 
							};
					excelUtil.export(logicFeatureDataList, reportColumns, fileName, fileName,true, critcolumns, plmCntrSmryRptdt);
				}
				
				//COST OBJECT DATA Tab
				if (reportName.equals("costObjectsExcel")) {

					PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
							new PLMXlsxRptColumn("coName", "Name",FormatType.LINK, null, null, 20, "coId"),
							new PLMXlsxRptColumn("coCrName", "CR Name",FormatType.LINK, null, null, 15, "coCrId"),
							new PLMXlsxRptColumn("coState", "CO State",FormatType.TEXT),
							new PLMXlsxRptColumn("coCrState", "CR State",FormatType.TEXT),
							new PLMXlsxRptColumn("coFeatName", "CO Logical Feature",FormatType.TEXT, null, null, 20),
							new PLMXlsxRptColumn("coDesc", "CO Logical Feature Desc",FormatType.TEXT, null, null, 45)
							};
					PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] { 
							new PLMXlsxRptColumn("contractExcel", "Contract Number", FormatType.TEXT), 
							new PLMXlsxRptColumn("pcNameExl", "Cost Objects ", FormatType.TEXT) 
							};
					excelUtil.export(costObjectDtList, reportColumns, fileName, fileName,true, critcolumns, plmCntrSmryRptdt);
				}
		
	}
	
	 private XSSFFont headerFont(SXSSFWorkbook wb, int size){
			XSSFFont font = (XSSFFont) wb.createFont();
			font.setFontName(PLMConstants.EXCEL_FONT_NAME);
			font.setFontHeightInPoints((short)size);
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			return font;
		}
		
		private XSSFFont normalFont(SXSSFWorkbook wb, int size){
			XSSFFont font = (XSSFFont) wb.createFont();
			font.setFontName(PLMConstants.EXCEL_FONT_NAME);
			font.setFontHeightInPoints((short)size);
			return font;
		}
		
		private XSSFCellStyle headerCell(SXSSFWorkbook wb, XSSFFont font, short bgcolor, boolean wrap){
			XSSFCellStyle hCell = normalCell(wb, font, XSSFCellStyle.SOLID_FOREGROUND, wrap);
			//FONT
			hCell.setFont(font);
			
			//HORIZONTAL ALIGNMENT
			hCell.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			
			//COLOR
			hCell.setFillForegroundColor(bgcolor);
			return hCell;
		}

		private XSSFCellStyle normalCell(SXSSFWorkbook wb, XSSFFont font, short fillPattern, boolean wrap){
			// Cell Style
			XSSFCellStyle cellStyle = (XSSFCellStyle)wb.createCellStyle();
			
			//Set Font
			cellStyle.setFont(font);
			//WRAP TEXT
			cellStyle.setWrapText(wrap);
			
			//VERTICAL ALIGNMENT
			cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			
			//BORDERS
			cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			
			//FILL PATTERN
			cellStyle.setFillPattern(fillPattern);
			return cellStyle;
		}
		
		/**
		 * This method is used for Bordering Cell in XLS
		 * 
		 * @return StringBuffer
		 */
		private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
			style.setBorderTop(XSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			style.setBorderRight(XSSFCellStyle.BORDER_THIN);
			return style;
		}
	

	/**
	 * This method is used for download Excel sheet for Configuration Features report
	 * 
	 */
	public void generateConfigFeatureExl(List<PLMCntrtSmryRptData> confFeatureDataListLcl) throws PLMCommonException {
		LOG.info("Entering generateConfigFeatureExl Method");
		FacesContext facesContext = FacesContext.getCurrentInstance();
	  	try {
			HttpServletResponse response = 
				(HttpServletResponse)facesContext.getExternalContext().getResponse();
			
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			
			response.setHeader("Content-disposition", 
					"attachment; filename="+"Configuration Features Report.xlsx");
			
			OutputStream outputStream = response.getOutputStream();
			
			SXSSFWorkbook workbook = new SXSSFWorkbook();
			
			XSSFFont font = headerFont(workbook, 10);
			
			XSSFFont font1 = headerFont(workbook, 10);
			
			// Header Style
			XSSFCellStyle headerStyle = headerCell(workbook, font, HSSFColor.PALE_BLUE.index, true);
			
			
			XSSFColor PINK = new XSSFColor(new java.awt.Color(242, 220, 219));   

			XSSFCellStyle boldStyle = (XSSFCellStyle) workbook.createCellStyle();
			boldStyle = setBorderStyle(boldStyle);
			font1.setUnderline(HSSFFont.U_SINGLE);
			boldStyle.setFont(font1);
			boldStyle.setAlignment(CellStyle.ALIGN_LEFT);
			boldStyle.setFillForegroundColor(PINK); 
			boldStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);

			XSSFFont cellfont = normalFont(workbook, 10);
			// Cell Style
			XSSFCellStyle cellStyle = normalCell(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
			
			// cell hyper link
			XSSFCreationHelper helper= (XSSFCreationHelper) workbook.getCreationHelper();
			
		    XSSFFont underLinedFont = (XSSFFont) workbook.createFont();
	        underLinedFont.setUnderline(HSSFFont.U_SINGLE);
	        underLinedFont.setColor(IndexedColors.BLUE.getIndex());
			XSSFCellStyle hyperLinkStyle = (XSSFCellStyle) workbook.createCellStyle();				
			hyperLinkStyle = setBorderStyle(hyperLinkStyle);
			hyperLinkStyle.setFont(underLinedFont);
			
			SXSSFSheet sheet = (SXSSFSheet) workbook.createSheet("Config Feature");
			
			int rowcount = 0;
			
			SXSSFCell cell=null;
		    
		    SXSSFRow row = (SXSSFRow) sheet.createRow(rowcount);
		    
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
			cell.setCellValue("Contract Number");
			cell.setCellStyle(headerStyle);
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(plmCntrSmryRptdt.getContractExcel());
			cell.setCellStyle(cellStyle);
			row = (SXSSFRow) sheet.createRow(++rowcount);
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
			cell.setCellValue("Configuration Features Data");
			cell.setCellStyle(headerStyle);
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(plmCntrSmryRptdt.getPcNameExl());
			cell.setCellStyle(cellStyle);
			row = (SXSSFRow) sheet.createRow(++rowcount);
			row = (SXSSFRow) sheet.createRow(++rowcount);
			
				String[] colNames1 = {"Config Feature Header Name","Config Feature Header","Configuration Selected Option",
						"Configuration Selected Option Display Name","Sequence Order","Legacy F&A Code","Option Sub Type","Key_In_Value"};
				for ( int i = 0 ; i < colNames1.length; i++ ) {
					cell = (SXSSFCell) row.createCell(i);
					cell. setCellValue(colNames1[i]);
					cell.setCellStyle(headerStyle);
					headerStyle = (XSSFCellStyle) cell.getCellStyle();
					cell.setCellStyle(headerStyle);
				}
				

			for(int i = 0; i < confFeatureDataListLcl.size(); i++) {
				PLMCntrtSmryRptData	 dataObj = (PLMCntrtSmryRptData)confFeatureDataListLcl.get(i);
				row =  (SXSSFRow) sheet.createRow(++rowcount);
				
				if(dataObj.isSystemFlag()){
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellValue(dataObj.getSystemName());
					cell.setCellStyle(boldStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(boldStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellStyle(boldStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
					cell.setCellStyle(boldStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell.setCellStyle(boldStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell.setCellStyle(boldStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
					cell.setCellStyle(boldStyle);
					cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
					cell.setCellStyle(boldStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_SEVEN));
					cell.setCellStyle(boldStyle);
				}else{
					cell =   (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
					if(!PLMUtils.isEmpty(dataObj.getCfId())){
						cell.setCellStyle(hyperLinkStyle);
						XSSFHyperlink url_link1 = helper.createHyperlink(Hyperlink.LINK_URL);
						url_link1.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getCfId());
						cell.setHyperlink(url_link1);
						cell.setCellValue(dataObj.getCfName());
					}else{
						cell.setCellStyle(cellStyle);
						cell.setCellValue("");
					}
					
					cell =   (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getCfDisplyName());
					
					cell =   (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
					if(!PLMUtils.isEmpty(dataObj.getCfConfId())){
						cell.setCellStyle(hyperLinkStyle);
						XSSFHyperlink url_link1 = helper.createHyperlink(Hyperlink.LINK_URL);
						url_link1.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getCfConfId());
						cell.setHyperlink(url_link1);
						cell.setCellValue(dataObj.getCfConfigOption());
					}else{
						cell.setCellStyle(cellStyle);
						cell.setCellValue("");
					}
					
					cell =   (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getCfConfOptDispName());
					
					cell =   (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getFeqSeqOrder());
					
					cell =  (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getLegacyFACode());
					
					cell =  (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getOptSubType());
					
					cell =  (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getKeyInValue());

				}
				
			}
             	row = (SXSSFRow) sheet.createRow(++rowcount);
             	row = (SXSSFRow) sheet.createRow(++rowcount);
             	
			    XSSFCellStyle ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
			    ftrStyle.setFont(font);
			    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
			    cell.setCellStyle(ftrStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_TWO));

				sheet.setColumnWidth(0,20*256);
				sheet.setColumnWidth(1,35*256);
				sheet.setColumnWidth(2,15*256);
				sheet.setColumnWidth(3,35*256);
				sheet.setColumnWidth(4,15*256);
				sheet.setColumnWidth(5,35*256);
				sheet.setColumnWidth(6,15*256);
				sheet.setColumnWidth(7,35*256);
				
			sheet.createFreezePane( 0, 4 );
            workbook.write(outputStream);
			
			outputStream.flush();
			
			outputStream.close();
			
		} catch (IOException ioex) {
			ioex.printStackTrace();
		} finally {
			facesContext.responseComplete();
	  	}
			LOG.info("Exiting generateConfigFeatureExl Method");
	} 	

	
	/**
	 * @return the contractSumrReptService
	 */
	public PLMCntrtSmryRptServiceIfc getContractSumrReptService() {
		return contractSumrReptService;
	}

	/**
	 * @param contractSumrReptService the contractSumrReptService to set
	 */
	public void setContractSumrReptService(
			PLMCntrtSmryRptServiceIfc contractSumrReptService) {
		this.contractSumrReptService = contractSumrReptService;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the contractNum
	 */
	public String getContractNum() {
		return contractNum;
	}

	/**
	 * @param contractNum the contractNum to set
	 */
	public void setContractNum(String contractNum) {
		this.contractNum = contractNum;
	}

	/**
	 * @return the alertMsg
	 */
	public String getAlertMsg() {
		return alertMsg;
	}

	/**
	 * @param alertMsg the alertMsg to set
	 */
	public void setAlertMsg(String alertMsg) {
		this.alertMsg = alertMsg;
	}

	/**
	 * @return the cgFlag
	 */
	public boolean isCgFlag() {
		return cgFlag;
	}

	/**
	 * @param cgFlag the cgFlag to set
	 */
	public void setCgFlag(boolean cgFlag) {
		this.cgFlag = cgFlag;
	}

	/**
	 * @return the pcFlag
	 */
	public boolean isPcFlag() {
		return pcFlag;
	}

	/**
	 * @param pcFlag the pcFlag to set
	 */
	public void setPcFlag(boolean pcFlag) {
		this.pcFlag = pcFlag;
	}

	/**
	 * @return the cstGrpList
	 */
	public List<String> getCstGrpList() {
		return cstGrpList;
	}

	/**
	 * @param cstGrpList the cstGrpList to set
	 */
	public void setCstGrpList(List<String> cstGrpList) {
		this.cstGrpList = cstGrpList;
	}

	/**
	 * @return the selCstGrpList
	 */
	public List<SelectItem> getSelCstGrpList() {
		return selCstGrpList;
	}

	/**
	 * @param selCstGrpList the selCstGrpList to set
	 */
	public void setSelCstGrpList(List<SelectItem> selCstGrpList) {
		this.selCstGrpList = selCstGrpList;
	}

	/**
	 * @return the costGroup
	 */
	public String getCostGroup() {
		return costGroup;
	}

	/**
	 * @param costGroup the costGroup to set
	 */
	public void setCostGroup(String costGroup) {
		this.costGroup = costGroup;
	}

	/**
	 * @return the pcInfoList
	 */
	public List<PLMContractSmryData> getPcInfoList() {
		return pcInfoList;
	}

	/**
	 * @param pcInfoList the pcInfoList to set
	 */
	public void setPcInfoList(List<PLMContractSmryData> pcInfoList) {
		this.pcInfoList = pcInfoList;
	}

	/**
	 * @return the selPcList
	 */
	public List<SelectItem> getSelPcList() {
		return selPcList;
	}

	/**
	 * @param selPcList the selPcList to set
	 */
	public void setSelPcList(List<SelectItem> selPcList) {
		this.selPcList = selPcList;
	}

	/**
	 * @return the productConf
	 */
	public String getProductConf() {
		return productConf;
	}

	/**
	 * @param productConf the productConf to set
	 */
	public void setProductConf(String productConf) {
		this.productConf = productConf;
	}

	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return LOG;
	}

	/**
	 * @return the subCmpnt
	 */
	public String getSubCmpnt() {
		return subCmpnt;
	}

	/**
	 * @param subCmpnt the subCmpnt to set
	 */
	public void setSubCmpnt(String subCmpnt) {
		this.subCmpnt = subCmpnt;
	}

	/**
	 * @return the finalSubcomponents
	 */
	public List<String> getFinalSubcomponents() {
		return finalSubcomponents;
	}

	/**
	 * @param finalSubcomponents the finalSubcomponents to set
	 */
	public void setFinalSubcomponents(List<String> finalSubcomponents) {
		this.finalSubcomponents = finalSubcomponents;
	}

	/**
	 * @return the contractInfoFlag
	 */
	public boolean isContractInfoFlag() {
		return contractInfoFlag;
	}

	/**
	 * @param contractInfoFlag the contractInfoFlag to set
	 */
	public void setContractInfoFlag(boolean contractInfoFlag) {
		this.contractInfoFlag = contractInfoFlag;
	}

	/**
	 * @return the projectInfoFlag
	 */
	public boolean isProjectInfoFlag() {
		return projectInfoFlag;
	}

	/**
	 * @param projectInfoFlag the projectInfoFlag to set
	 */
	public void setProjectInfoFlag(boolean projectInfoFlag) {
		this.projectInfoFlag = projectInfoFlag;
	}

	/**
	 * @return the hardwareBuilFlag
	 */
	public boolean isHardwareBuilFlag() {
		return hardwareBuilFlag;
	}

	/**
	 * @param hardwareBuilFlag the hardwareBuilFlag to set
	 */
	public void setHardwareBuilFlag(boolean hardwareBuilFlag) {
		this.hardwareBuilFlag = hardwareBuilFlag;
	}

	/**
	 * @return the prsDataFlag
	 */
	public boolean isPrsDataFlag() {
		return prsDataFlag;
	}

	/**
	 * @param prsDataFlag the prsDataFlag to set
	 */
	public void setPrsDataFlag(boolean prsDataFlag) {
		this.prsDataFlag = prsDataFlag;
	}

	/**
	 * @return the clinsFlag
	 */
	public boolean isClinsFlag() {
		return clinsFlag;
	}

	/**
	 * @param clinsFlag the clinsFlag to set
	 */
	public void setClinsFlag(boolean clinsFlag) {
		this.clinsFlag = clinsFlag;
	}

	/**
	 * @return the crsDataFlag
	 */
	public boolean isCrsDataFlag() {
		return crsDataFlag;
	}

	/**
	 * @param crsDataFlag the crsDataFlag to set
	 */
	public void setCrsDataFlag(boolean crsDataFlag) {
		this.crsDataFlag = crsDataFlag;
	}

	/**
	 * @return the confFeatureFlag
	 */
	public boolean isConfFeatureFlag() {
		return confFeatureFlag;
	}

	/**
	 * @param confFeatureFlag the confFeatureFlag to set
	 */
	public void setConfFeatureFlag(boolean confFeatureFlag) {
		this.confFeatureFlag = confFeatureFlag;
	}

	/**
	 * @return the logicFeatureFlag
	 */
	public boolean isLogicFeatureFlag() {
		return logicFeatureFlag;
	}

	/**
	 * @param logicFeatureFlag the logicFeatureFlag to set
	 */
	public void setLogicFeatureFlag(boolean logicFeatureFlag) {
		this.logicFeatureFlag = logicFeatureFlag;
	}

	/**
	 * @return the confEndItmFlag
	 */
	public boolean isConfEndItmFlag() {
		return confEndItmFlag;
	}

	/**
	 * @param confEndItmFlag the confEndItmFlag to set
	 */
	public void setConfEndItmFlag(boolean confEndItmFlag) {
		this.confEndItmFlag = confEndItmFlag;
	}

	/**
	 * @return the costObjectFlag
	 */
	public boolean isCostObjectFlag() {
		return costObjectFlag;
	}

	/**
	 * @param costObjectFlag the costObjectFlag to set
	 */
	public void setCostObjectFlag(boolean costObjectFlag) {
		this.costObjectFlag = costObjectFlag;
	}

	/**
	 * @return the prjNameList
	 */
	public List<PLMCntrtSmryRptData> getPrjNameList() {
		return prjNameList;
	}

	/**
	 * @param prjNameList the prjNameList to set
	 */
	public void setPrjNameList(List<PLMCntrtSmryRptData> prjNameList) {
		this.prjNameList = prjNameList;
	}

	/**
	 * @return the crsList
	 */
	public List<PLMCntrtSmryRptData> getCrsList() {
		return crsList;
	}

	/**
	 * @param crsList the crsList to set
	 */
	public void setCrsList(List<PLMCntrtSmryRptData> crsList) {
		this.crsList = crsList;
	}

	/**
	 * @return the hardwareBuildDataList
	 */
	public List<PLMCntrtSmryRptData> getHardwareBuildDataList() {
		return hardwareBuildDataList;
	}

	/**
	 * @param hardwareBuildDataList the hardwareBuildDataList to set
	 */
	public void setHardwareBuildDataList(
			List<PLMCntrtSmryRptData> hardwareBuildDataList) {
		this.hardwareBuildDataList = hardwareBuildDataList;
	}
	/**
	 * @return the cntrctList
	 */
	public List<PLMCntrtSmryRptData> getCntrctList() {
		return cntrctList;
	}
	/**
	 * @param cntrctList the cntrctList to set
	 */
	public void setCntrctList(List<PLMCntrtSmryRptData> cntrctList) {
		this.cntrctList = cntrctList;
	}
	/**
	 * @return the showFlag
	 */
	public boolean isShowFlag() {
		return showFlag;
	}
	/**
	 * @param showFlag the showFlag to set
	 */
	public void setShowFlag(boolean showFlag) {
		this.showFlag = showFlag;
	}
	/**
	 * @return the clinDataList
	 */
	public List<PLMCntrtSmryRptData> getClinDataList() {
		return clinDataList;
	}
	/**
	 * @param clinDataList the clinDataList to set
	 */
	public void setClinDataList(List<PLMCntrtSmryRptData> clinDataList) {
		this.clinDataList = clinDataList;
	}
	/**
	 * @return the confFeatureDataList
	 */
	public List<PLMCntrtSmryRptData> getConfFeatureDataList() {
		return confFeatureDataList;
	}
	/**
	 * @param confFeatureDataList the confFeatureDataList to set
	 */
	public void setConfFeatureDataList(List<PLMCntrtSmryRptData> confFeatureDataList) {
		this.confFeatureDataList = confFeatureDataList;
	}
	/**
	 * @return the logicFeatureDataList
	 */
	public List<PLMCntrtSmryRptData> getLogicFeatureDataList() {
		return logicFeatureDataList;
	}
	/**
	 * @param logicFeatureDataList the logicFeatureDataList to set
	 */
	public void setLogicFeatureDataList(
			List<PLMCntrtSmryRptData> logicFeatureDataList) {
		this.logicFeatureDataList = logicFeatureDataList;
	}
	/**
	 * @return the confEndItemDataList
	 */
	public List<PLMCntrtSmryRptData> getConfEndItemDataList() {
		return confEndItemDataList;
	}
	/**
	 * @param confEndItemDataList the confEndItemDataList to set
	 */
	public void setConfEndItemDataList(List<PLMCntrtSmryRptData> confEndItemDataList) {
		this.confEndItemDataList = confEndItemDataList;
	}
	/**
	 * @return the costObjectDtList
	 */
	public List<PLMCntrtSmryRptData> getCostObjectDtList() {
		return costObjectDtList;
	}
	/**
	 * @param costObjectDtList the costObjectDtList to set
	 */
	public void setCostObjectDtList(List<PLMCntrtSmryRptData> costObjectDtList) {
		this.costObjectDtList = costObjectDtList;
	}
	/**
	 * @return the prdtRqmntSpecList
	 */
	public List<PLMCntrtSmryRptData> getPrdtRqmntSpecList() {
		return prdtRqmntSpecList;
	}
	/**
	 * @param prdtRqmntSpecList the prdtRqmntSpecList to set
	 */
	public void setPrdtRqmntSpecList(List<PLMCntrtSmryRptData> prdtRqmntSpecList) {
		this.prdtRqmntSpecList = prdtRqmntSpecList;
	}
	/**
	 * @return the cntrctIfoList
	 */
	public List<PLMCntrtSmryRptData> getCntrctIfoList() {
		return cntrctIfoList;
	}
	/**
	 * @param cntrctIfoList the cntrctIfoList to set
	 */
	public void setCntrctIfoList(List<PLMCntrtSmryRptData> cntrctIfoList) {
		this.cntrctIfoList = cntrctIfoList;
	}
	
	/**
	 * @return the prsVal
	 */
	public UIDataTable getPrsVal() {
		return prsVal;
	}
	/**
	 * @param prsVal the prsVal to set
	 */
	public void setPrsVal(UIDataTable prsVal) {
		this.prsVal = prsVal;
	}
	/**
	 * @return the crsVal
	 */
	public UIDataTable getCrsVal() {
		return crsVal;
	}
	/**
	 * @param crsVal the crsVal to set
	 */
	public void setCrsVal(UIDataTable crsVal) {
		this.crsVal = crsVal;
	}
	/**
	 * @return the prsRecList
	 */
	public List<PLMCntrtSmryRptData> getPrsRecList() {
		return prsRecList;
	}
	/**
	 * @param prsRecList the prsRecList to set
	 */
	public void setPrsRecList(List<PLMCntrtSmryRptData> prsRecList) {
		this.prsRecList = prsRecList;
	}
	/**
	 * @return the crsRecList
	 */
	public List<PLMCntrtSmryRptData> getCrsRecList() {
		return crsRecList;
	}
	/**
	 * @param crsRecList the crsRecList to set
	 */
	public void setCrsRecList(List<PLMCntrtSmryRptData> crsRecList) {
		this.crsRecList = crsRecList;
	}
	/**
	 * @return the prsRecFlag
	 */
	public boolean isPrsRecFlag() {
		return prsRecFlag;
	}
	/**
	 * @param prsRecFlag the prsRecFlag to set
	 */
	public void setPrsRecFlag(boolean prsRecFlag) {
		this.prsRecFlag = prsRecFlag;
	}
	/**
	 * @return the crsRecFlag
	 */
	public boolean isCrsRecFlag() {
		return crsRecFlag;
	}
	/**
	 * @param crsRecFlag the crsRecFlag to set
	 */
	public void setCrsRecFlag(boolean crsRecFlag) {
		this.crsRecFlag = crsRecFlag;
	}
	/**
	 * @return the subComponentList
	 */
	public List<PLMContractSmryData> getSubComponentList() {
		return subComponentList;
	}
	/**
	 * @param subComponentList the subComponentList to set
	 */
	public void setSubComponentList(List<PLMContractSmryData> subComponentList) {
		this.subComponentList = subComponentList;
	}
	/**
	 * @return the chkAllSubComponent
	 */
	public boolean isChkAllSubComponent() {
		return chkAllSubComponent;
	}
	/**
	 * @param chkAllSubComponent the chkAllSubComponent to set
	 */
	public void setChkAllSubComponent(boolean chkAllSubComponent) {
		this.chkAllSubComponent = chkAllSubComponent;
	}
	/**
	 * @return the projectDataList
	 */
	public List<PLMCntrtSmryRptData> getProjectDataList() {
		return projectDataList;
	}
	/**
	 * @param projectDataList the projectDataList to set
	 */
	public void setProjectDataList(List<PLMCntrtSmryRptData> projectDataList) {
		this.projectDataList = projectDataList;
	}
	/**
	 * @return the fetchProjectFlag
	 */
	public boolean isFetchProjectFlag() {
		return fetchProjectFlag;
	}
	/**
	 * @param fetchProjectFlag the fetchProjectFlag to set
	 */
	public void setFetchProjectFlag(boolean fetchProjectFlag) {
		this.fetchProjectFlag = fetchProjectFlag;
	}
	/**
	 * @return the projNmVal
	 */
	public UIDataTable getProjNmVal() {
		return projNmVal;
	}
	/**
	 * @param projNmVal the projNmVal to set
	 */
	public void setProjNmVal(UIDataTable projNmVal) {
		this.projNmVal = projNmVal;
	}
	/**
	 * @return the prsResultmsg
	 */
	public String getPrsResultmsg() {
		return prsResultmsg;
	}
	/**
	 * @param prsResultmsg the prsResultmsg to set
	 */
	public void setPrsResultmsg(String prsResultmsg) {
		this.prsResultmsg = prsResultmsg;
	}
	/**
	 * @return the crsResultmsg
	 */
	public String getCrsResultmsg() {
		return crsResultmsg;
	}
	/**
	 * @param crsResultmsg the crsResultmsg to set
	 */
	public void setCrsResultmsg(String crsResultmsg) {
		this.crsResultmsg = crsResultmsg;
	}
	/**
	 * @return the prjResultmsg
	 */
	public String getPrjResultmsg() {
		return prjResultmsg;
	}
	/**
	 * @param prjResultmsg the prjResultmsg to set
	 */
	public void setPrjResultmsg(String prjResultmsg) {
		this.prjResultmsg = prjResultmsg;
	}
	
	/**
	 * @return the confFeatureMsg
	 */
	public String getConfFeatureMsg() {
		return confFeatureMsg;
	}
	/**
	 * @param confFeatureMsg the confFeatureMsg to set
	 */
	public void setConfFeatureMsg(String confFeatureMsg) {
		this.confFeatureMsg = confFeatureMsg;
	}
	/**
	 * @return the logFeatureMsg
	 */
	public String getLogFeatureMsg() {
		return logFeatureMsg;
	}
	/**
	 * @param logFeatureMsg the logFeatureMsg to set
	 */
	public void setLogFeatureMsg(String logFeatureMsg) {
		this.logFeatureMsg = logFeatureMsg;
	}
	/**
	 * @return the confEndItmMsg
	 */
	public String getConfEndItmMsg() {
		return confEndItmMsg;
	}
	/**
	 * @param confEndItmMsg the confEndItmMsg to set
	 */
	public void setConfEndItmMsg(String confEndItmMsg) {
		this.confEndItmMsg = confEndItmMsg;
	}
	/**
	 * @return the costObjectsMsg
	 */
	public String getCostObjectsMsg() {
		return costObjectsMsg;
	}
	/**
	 * @param costObjectsMsg the costObjectsMsg to set
	 */
	public void setCostObjectsMsg(String costObjectsMsg) {
		this.costObjectsMsg = costObjectsMsg;
	}
	/**
	 * @return the contractFlg
	 */
	public boolean isContractFlg() {
		return contractFlg;
	}
	/**
	 * @param contractFlg the contractFlg to set
	 */
	public void setContractFlg(boolean contractFlg) {
		this.contractFlg = contractFlg;
	}
	/**
	 * @return the projectFlg
	 */
	public boolean isProjectFlg() {
		return projectFlg;
	}
	/**
	 * @param projectFlg the projectFlg to set
	 */
	public void setProjectFlg(boolean projectFlg) {
		this.projectFlg = projectFlg;
	}
	/**
	 * @return the projectDescFlg
	 */
	public boolean isProjectDescFlg() {
		return projectDescFlg;
	}
	/**
	 * @param projectDescFlg the projectDescFlg to set
	 */
	public void setProjectDescFlg(boolean projectDescFlg) {
		this.projectDescFlg = projectDescFlg;
	}
	/**
	 * @return the hardbuildFlag
	 */
	public boolean isHardbuildFlag() {
		return hardbuildFlag;
	}
	/**
	 * @param hardbuildFlag the hardbuildFlag to set
	 */
	public void setHardbuildFlag(boolean hardbuildFlag) {
		this.hardbuildFlag = hardbuildFlag;
	}
	/**
	 * @return the prsFlag
	 */
	public boolean isPrsFlag() {
		return prsFlag;
	}
	/**
	 * @param prsFlag the prsFlag to set
	 */
	public void setPrsFlag(boolean prsFlag) {
		this.prsFlag = prsFlag;
	}
	/**
	 * @return the prsrecFlag
	 */
	/*public boolean isPrsrecFlag() {
		return prsrecFlag;
	}*/
	/**
	 * @param prsrecFlag the prsrecFlag to set
	 */
	/*public void setPrsrecFlag(boolean prsrecFlag) {
		this.prsrecFlag = prsrecFlag;
	}*/
	/**
	 * @return the clinFlag
	 */
	public boolean isClinFlag() {
		return clinFlag;
	}
	/**
	 * @param clinFlag the clinFlag to set
	 */
	public void setClinFlag(boolean clinFlag) {
		this.clinFlag = clinFlag;
	}
	/**
	 * @return the crsFlag
	 */
	public boolean isCrsFlag() {
		return crsFlag;
	}
	/**
	 * @param crsFlag the crsFlag to set
	 */
	public void setCrsFlag(boolean crsFlag) {
		this.crsFlag = crsFlag;
	}
	/**
	 * @return the crsrecFlag
	 */
	public boolean isCrsrecFlag() {
		return crsrecFlag;
	}
	/**
	 * @param crsrecFlag the crsrecFlag to set
	 */
	public void setCrsrecFlag(boolean crsrecFlag) {
		this.crsrecFlag = crsrecFlag;
	}
	/**
	 * @return the confFtrFlag
	 */
	public boolean isConfFtrFlag() {
		return confFtrFlag;
	}
	/**
	 * @param confFtrFlag the confFtrFlag to set
	 */
	public void setConfFtrFlag(boolean confFtrFlag) {
		this.confFtrFlag = confFtrFlag;
	}
	/**
	 * @return the logFtrFlag
	 */
	public boolean isLogFtrFlag() {
		return logFtrFlag;
	}
	/**
	 * @param logFtrFlag the logFtrFlag to set
	 */
	public void setLogFtrFlag(boolean logFtrFlag) {
		this.logFtrFlag = logFtrFlag;
	}
	/**
	 * @return the confEndFlag
	 */
	public boolean isConfEndFlag() {
		return confEndFlag;
	}
	/**
	 * @param confEndFlag the confEndFlag to set
	 */
	public void setConfEndFlag(boolean confEndFlag) {
		this.confEndFlag = confEndFlag;
	}
	/**
	 * @return the costObjFlag
	 */
	public boolean isCostObjFlag() {
		return costObjFlag;
	}
	/**
	 * @param costObjFlag the costObjFlag to set
	 */
	public void setCostObjFlag(boolean costObjFlag) {
		this.costObjFlag = costObjFlag;
	}
	/**
	 * @return the noContractFound
	 */
	public String getNoContractFound() {
		return noContractFound;
	}
	/**
	 * @param noContractFound the noContractFound to set
	 */
	public void setNoContractFound(String noContractFound) {
		this.noContractFound = noContractFound;
	}
	/**
	 * @return the noPCFound
	 */
	public String getNoPCFound() {
		return noPCFound;
	}
	/**
	 * @param noPCFound the noPCFound to set
	 */
	public void setNoPCFound(String noPCFound) {
		this.noPCFound = noPCFound;
	}
	/**
	 * @return the noprsRecFnd
	 */
	public String getNoprsRecFnd() {
		return noprsRecFnd;
	}
	/**
	 * @param noprsRecFnd the noprsRecFnd to set
	 */
	public void setNoprsRecFnd(String noprsRecFnd) {
		this.noprsRecFnd = noprsRecFnd;
	}
	/**
	 * @return the nocrsRecFnd
	 */
	public String getNocrsRecFnd() {
		return nocrsRecFnd;
	}
	/**
	 * @param nocrsRecFnd the nocrsRecFnd to set
	 */
	public void setNocrsRecFnd(String nocrsRecFnd) {
		this.nocrsRecFnd = nocrsRecFnd;
	}
	/**
	 * @return the noPrjData
	 */
	public String getNoPrjData() {
		return noPrjData;
	}
	/**
	 * @param noPrjData the noPrjData to set
	 */
	public void setNoPrjData(String noPrjData) {
		this.noPrjData = noPrjData;
	}
	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}
	/**
	 * @return the notRequireFlg
	 */
	public boolean isNotRequireFlg() {
		return notRequireFlg;
	}
	/**
	 * @param notRequireFlg the notRequireFlg to set
	 */
	public void setNotRequireFlg(boolean notRequireFlg) {
		this.notRequireFlg = notRequireFlg;
	}
	/**
	 * @return the selectedPrdtType
	 */
	public List<String> getSelectedPrdtType() {
		return selectedPrdtType;
	}
	/**
	 * @param selectedPrdtType the selectedPrdtType to set
	 */
	public void setSelectedPrdtType(List<String> selectedPrdtType) {
		this.selectedPrdtType = selectedPrdtType;
	}
	/**
	 * @return the pcName
	 */
	public String getPcName() {
		return pcName;
	}
	/**
	 * @param pcName the pcName to set
	 */
	public void setPcName(String pcName) {
		this.pcName = pcName;
	}
	/**
	 * @return the noSubTypeFlg
	 */
	public boolean isNoSubTypeFlg() {
		return noSubTypeFlg;
	}
	/**
	 * @param noSubTypeFlg the noSubTypeFlg to set
	 */
	public void setNoSubTypeFlg(boolean noSubTypeFlg) {
		this.noSubTypeFlg = noSubTypeFlg;
	}
	/**
	 * @return
	 */
	public boolean isOptionFlag() {
		return optionFlag;
	}
	/**
	 * @param optionFlag
	 */
	public void setOptionFlag(boolean optionFlag) {
		this.optionFlag = optionFlag;
	}
	/**
	 * @return the plmCntrSmryRptdt
	 */
	public PLMCntrtSmryRptData getPlmCntrSmryRptdt() {
		return plmCntrSmryRptdt;
	}
	/**
	 * @param plmCntrSmryRptdt the plmCntrSmryRptdt to set
	 */
	public void setPlmCntrSmryRptdt(PLMCntrtSmryRptData plmCntrSmryRptdt) {
		this.plmCntrSmryRptdt = plmCntrSmryRptdt;
	}
	/**
	 * @return the partTypeAllOpen
	 */
	public boolean isPartTypeAllOpen() {
		return partTypeAllOpen;
	}
	/**
	 * @param partTypeAllOpen the partTypeAllOpen to set
	 */
	public void setPartTypeAllOpen(boolean partTypeAllOpen) {
		this.partTypeAllOpen = partTypeAllOpen;
	}
	/**
	 * @return the disablePrdtType
	 */
	public boolean isDisablePrdtType() {
		return disablePrdtType;
	}
	/**
	 * @param disablePrdtType the disablePrdtType to set
	 */
	public void setDisablePrdtType(boolean disablePrdtType) {
		this.disablePrdtType = disablePrdtType;
	}
	/**
	 * @return the categoryFlag
	 */
	public boolean isCategoryFlag() {
		return categoryFlag;
	}
	/**
	 * @param categoryFlag the categoryFlag to set
	 */
	public void setCategoryFlag(boolean categoryFlag) {
		this.categoryFlag = categoryFlag;
	}
	
}