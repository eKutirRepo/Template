/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEBomToMBomData.java
 * @Creation date: 06-Sept-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMEBomToMBomData {
	/**
	 *  Holds the plantId
	 */
	private String plantId;
	
	/**
	 *  Holds the bomLevel
	 */
	private String bomLevel;
	/**
	 *  Holds the mlNum
	 */
	private String mlNum;
	/**
	 *  Holds the partName
	 */
	private String partName;
	/**
	 *  Holds the bomRevision
	 */
	private String bomRevision;
	/**
	 *  Holds the description
	 */
	private String description;
	/**
	 *  Holds the state
	 */
	private String state;
	/**
	 *  Holds the quantity
	 */
	private String quantity;
	/**
	 *  Holds the unitOfMeasure
	 */
	private String unitOfMeasure;
	/**
	 *  Holds the prodStatus
	 */
	private String prodStatus;
	/**
	 *  Holds the plantId
	 */
	private boolean compared;
	/**
	 *  Holds the eid
	 */
	private String eid;
	/**
	 *  Holds the pathFlag
	 */
	private boolean pathFlag;
	/**
	 *  Holds the bomPrefix
	 */
	private String bomPrefix;
	/**
	 *  Holds the parentName
	 */
	private String parentName;
	/**
	 *  Holds the quantityDb
	 */
	private double quantityDb;
	/**
	 *  Holds the consumState
	 */
	private String consumState;
	/**
	 *  Holds the consumFlag
	 */
	private boolean consumFlag;
	/**
	 *  Holds the contractNm
	 */
	private String contractNm;

	/**
	 *  Holds the contractDesc
	 */
	private String contractDesc;

	/**
	 *  Holds the partNm
	 */
	private String partNm;

	/**
	 * @return the pathFlag
	 */
	public boolean isPathFlag() {
		return pathFlag;
	}
	/**
	 * @param pathFlag the pathFlag to set
	 */
	public void setPathFlag(boolean pathFlag) {
		this.pathFlag = pathFlag;
	}
	/**
	 * @return the plantId
	 */
	public String getPlantId() {
		return plantId;
	}
	/**
	 * @return the eid
	 */
	public String getEid() {
		return eid;
	}
	/**
	 * @param eid the eid to set
	 */
	public void setEid(String eid) {
		this.eid = eid;
	}
	/**
	 * @param plantId the plantId to set
	 */
	public void setPlantId(String plantId) {
		this.plantId = plantId;
	}
	/**
	 * @return the bomLevel
	 */
	public String getBomLevel() {
		return bomLevel;
	}
	/**
	 * @param bomLevel the bomLevel to set
	 */
	public void setBomLevel(String bomLevel) {
		this.bomLevel = bomLevel;
	}
	/**
	 * @return the mlNum
	 */
	public String getMlNum() {
		return mlNum;
	}
	/**
	 * @param mlNum the mlNum to set
	 */
	public void setMlNum(String mlNum) {
		this.mlNum = mlNum;
	}
	/**
	 * @return the partName
	 */
	public String getPartName() {
		return partName;
	}
	/**
	 * @param partName the partName to set
	 */
	public void setPartName(String partName) {
		this.partName = partName;
	}
	/**
	 * @return the bomRevision
	 */
	public String getBomRevision() {
		return bomRevision;
	}
	/**
	 * @param bomRevision the bomRevision to set
	 */
	public void setBomRevision(String bomRevision) {
		this.bomRevision = bomRevision;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the quantity
	 */
	public String getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return the unitOfMeasure
	 */
	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}
	/**
	 * @param unitOfMeasure the unitOfMeasure to set
	 */
	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}
	/**
	 * @return the prodStatus
	 */
	public String getProdStatus() {
		return prodStatus;
	}
	/**
	 * @param prodStatus the prodStatus to set
	 */
	public void setProdStatus(String prodStatus) {
		this.prodStatus = prodStatus;
	}
	/**
	 * @return the compared
	 */
	public boolean isCompared() {
		return compared;
	}
	/**
	 * @param compared the compared to set
	 */
	public void setCompared(boolean compared) {
		this.compared = compared;
	}
	/**
	 * @return the bomPrefix
	 */
	public String getBomPrefix() {
		return bomPrefix;
	}
	/**
	 * @param bomPrefix the bomPrefix to set
	 */
	public void setBomPrefix(String bomPrefix) {
		this.bomPrefix = bomPrefix;
	}
	/**
	 * @return the parentName
	 */
	public String getParentName() {
		return parentName;
	}
	/**
	 * @param parentName the parentName to set
	 */
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	/**
	 * @return the quantityDb
	 */
	public double getQuantityDb() {
		return quantityDb;
	}
	/**
	 * @param quantityDb the quantityDb to set
	 */
	public void setQuantityDb(double quantityDb) {
		this.quantityDb = quantityDb;
	}
	/**
	 * @return the consumState
	 */
	public String getConsumState() {
		return consumState;
	}
	/**
	 * @param consumState the consumState to set
	 */
	public void setConsumState(String consumState) {
		this.consumState = consumState;
	}
	/**
	 * @return the consumFlag
	 */
	public boolean isConsumFlag() {
		return consumFlag;
	}
	/**
	 * @param consumFlag the consumFlag to set
	 */
	public void setConsumFlag(boolean consumFlag) {
		this.consumFlag = consumFlag;
	}
	/**
	 * @return the contractNm
	 */
	public String getContractNm() {
		return contractNm;
	}
	/**
	 * @param contractNm the contractNm to set
	 */
	public void setContractNm(String contractNm) {
		this.contractNm = contractNm;
	}
	/**
	 * @return the contractDesc
	 */
	public String getContractDesc() {
		return contractDesc;
	}
	/**
	 * @param contractDesc the contractDesc to set
	 */
	public void setContractDesc(String contractDesc) {
		this.contractDesc = contractDesc;
	}
	/**
	 * @return the partNm
	 */
	public String getPartNm() {
		return partNm;
	}
	/**
	 * @param partNm the partNm to set
	 */
	public void setPartNm(String partNm) {
		this.partNm = partNm;
	}

}
