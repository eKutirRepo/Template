 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName AdminUserEditorBean.java
 * @Creation date: 18-June-2014
 * @version 1.0
 * @author : Tech Mahindra
 */
package com.geinfra.geaviation.pwi.bean;

import java.util.ArrayList;
import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.PWiRoleVO;
import com.geinfra.geaviation.pwi.model.PWiUserVO;
import com.geinfra.geaviation.pwi.service.RoleService;
import com.geinfra.geaviation.pwi.service.UserService;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PWiConstants;

public class AdminUserEditorBean extends BaseBean {
	
	// Dependency-injected services
	private UserService userService;
    private int usrId;
	private String ssoId;
	private String firstName;
	private String lastName;
	private String email;
	private List<PWiUserVO> allUserList;
	
	private RoleService roleService;
	private boolean enabled;
	private List<PWiRoleVO> selectedRolesList;
	private List<PWiRoleVO> availableRolesList;
	private List<PWiRoleVO> originalSelectedRoles;
	
	private boolean renderCreateButton;
	private boolean renderUpdateButton;
	private String emailNotification;
	
	
	/**
	 * @return the emailNotification
	 */
	public String getEmailNotification() {
		return emailNotification;
	}
	/**
	 * @param emailNotification the emailNotification to set
	 */
	public void setEmailNotification(String emailNotification) {
		this.emailNotification = emailNotification;
	}
	public boolean isRenderCreateButton() {
		return renderCreateButton;
	}
	public void setRenderCreateButton(boolean renderCreateButton) {
		this.renderCreateButton = renderCreateButton;
	}
	public boolean isRenderUpdateButton() {
		return renderUpdateButton;
	}
	public void setRenderUpdateButton(boolean renderUpdateButton) {
		this.renderUpdateButton = renderUpdateButton;
	}
	public String initEdit(Integer theUserId) throws PWiException {
		//this.enabled = false;

		this.usrId = theUserId;

		// Initialize object type-related state
		PWiUserVO resultUser = userService.getUserById(this.usrId);
		this.firstName = resultUser.getUserNm();
		this.email = resultUser.getEmail();
		this.lastName= resultUser.getUserLastNm();
		this.ssoId= resultUser.getSso();
		this.enabled =  resultUser.isEnabled();
		renderCreateButton = false;
		renderUpdateButton = true;
		
		if (!resultUser.isEnabled()) {
			handleFacesError(this.firstName + " {" +this.ssoId+"} Status is Disabled. Please check Enabled Checkbox before clicking on Update Button.");
		}
		
		// Initialize role-related state
				this.originalSelectedRoles = roleService.findSelectedRolesForUser(usrId);
						
				this.selectedRolesList = new ArrayList<PWiRoleVO>();
				this.selectedRolesList.addAll(this.originalSelectedRoles);
				this.availableRolesList = (List<PWiRoleVO>) roleService
						.getAllPWiRoles();
				this.availableRolesList.removeAll(selectedRolesList);
				
				return PWiConstants.NAV_ADMIN_USER_EDITOR;

				
		
	}
	
	public String validateUserSSO() throws PLMCommonException
	{
		if(userService.isValidSSO(this.ssoId))
		{
			PWiUserVO userInfo = userService.getUserInfoForSSO(this.ssoId);
			
			this.firstName = userInfo.getUserNm();
			this.email = userInfo.getEmail();
			this.lastName= userInfo.getUserLastNm();
			this.ssoId= userInfo.getSso();
			this.enabled =  userInfo.isEnabled();
			this.originalSelectedRoles = new ArrayList<PWiRoleVO>();
			this.selectedRolesList = new ArrayList<PWiRoleVO>();
			this.availableRolesList = (List<PWiRoleVO>) roleService.getAllPWiRoles();
		}
		
		return PWiConstants.NAV_ADMIN_USER_EDITOR;
		
	}
	
	/*public String initEdit(Integer theRoleSequenceId) throws PWiException {
		this.isNew = false;

		this.roleId = theRoleSequenceId;

		// Initialize object type-related state
		PWiRoleVO resultRole = roleService.getRoleById(this.roleId);
		this.roleName = resultRole.getRoleNm();
		this.roleDesc = resultRole.getRoleDesc();
		this.shwInQi = resultRole.isShwInQi();

		// Initialize group-related state
		this.selectedQueryGroupsList = new ArrayList<PWiQueryGroupVO>();
		this.selectedQueryGroupsList.addAll(this.originalSelectedGroups);
		this.availableQueryGroupList = (List<PWiQueryGroupVO>) queryGroupService
				.getAllQueryGroups();
		this.availableQueryGroupList.removeAll(selectedQueryGroupsList);

		return PWiConstants.NAV_ADMIN_OBJ_TYP_EDITOR;
	}
	
*/
	/**
	 * @return the selectedQueryGroupsList
	 */
	public List<PWiRoleVO> getSelectedRolesList() {
		return selectedRolesList;
	}

	/**
	 * @param selectedQueryGroupsList
	 *            the selectedQueryGroupsList to set
	 */
	public void setSelectedRolesList(
			List<PWiRoleVO> selectedRolesList) {
		this.selectedRolesList = selectedRolesList;
	}

	public List<PWiRoleVO> getAvailableRolesList() {
		return availableRolesList;
	}

	/**
	 * @param availableQueryGroupList
	 *            the availableQueryGroupList to set
	 */
	public void setAvailableRolesList(
			List<PWiRoleVO> availableRolesList) {
		this.availableRolesList = availableRolesList;
	}

	
	
	public String getSsoId() {
		return ssoId;
	}



	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}



	public int getUsrId() {
		return usrId;
	}



	public void setUsrId(int usrId) {
		this.usrId = usrId;
	}





	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public boolean isEnabled() {
		return enabled;
	}



	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}



	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public void setRoleService(RoleService roleService) {
		this.roleService = roleService;
	}

	/*public String getSql() {
		return QueryLoader.getQuery(QueryConstants.PWi_ROLE_USER_INSERT);
	}
*/

	public List<PWiUserVO> getAllUserList() {
		return allUserList;
	}
	public void setAllUserList(List<PWiUserVO> allUserList) {
		this.allUserList = allUserList;
	}
	public String initCreate() {
		//this.enabled= true;
		this.ssoId = null;
		this.usrId = 0;
		this.firstName = null;
		this.email = null;
		this.lastName=null;
		renderCreateButton = true;
		renderUpdateButton = false;
		this.enabled = true;
		this.emailNotification="Y";
		//Initialize group-related state
				this.originalSelectedRoles = new ArrayList<PWiRoleVO>();
				this.selectedRolesList = new ArrayList<PWiRoleVO>();
				this.availableRolesList = (List<PWiRoleVO>) roleService.getAllPWiRoles();
		return PWiConstants.NAV_ADMIN_USER_EDITOR;
	}

	
	public String actionUpdateUser() throws PWiException {
		/*boolean valid = userService.validateName(this.firstName,this.lastName,this.email,this.ssoId);
		if (userService.checkNamesForEdit(this.firstName, this.lastName, this.email,this.ssoId, this.usrId) > 0)
		{
			handleFacesError(PWiConstants.ERROR_DUPLICATE_NAME);
			valid = false;
		}*/
		boolean valid = true;
		if(selectedRolesList.size()==0)
		{
			handleFacesError(PWiConstants.ERROR_MANDATORY_ROLE);
			valid = false;
		}

		if (!valid) {
			// Validation errors exist, return to same page to display
			// validation error messages
			return PWiConstants.NAV_ADMIN_USER_EDITOR;
		}

		String userId = getSsoId(); //FOR SESSION PURPOSE

		// Initialize query
		PWiUserVO userLst = new PWiUserVO();
		userLst.setSso(ssoId);
		userLst.setUserNm(firstName);		
		userLst.setUserLastNm(lastName);
		userLst.setEmail(email);
		userLst.setUserId(usrId);
		userLst.setEnabled(enabled);	
		
		List<Integer> selectedRoleIds = new ArrayList<Integer>();
		for (PWiRoleVO role : selectedRolesList) {
			selectedRoleIds.add(role.getRoleSeqId());
		}	
		// Persist updated object type
		
		userService.updateUser(userLst, selectedRoleIds, userId);

		handleFacesInfo("User " + this.firstName + " updated successfully.");
		return PWiConstants.NAV_ADMIN_USER_LIST;
	}
		public String actionCancel() {
			return PWiConstants.NAV_ADMIN_USER_LIST;
		}
		
		public String actionSaveNewUser() throws PWiException {
			// Check for validation errors
			boolean valid = userService.validateName(firstName,lastName,email,ssoId);
			if (userService.checkNames(firstName,lastName, email,ssoId) > 0) {
				handleFacesError(PWiConstants.ERROR_DUPLICATE_NAME);
				valid = false;
			}
			if(selectedRolesList.size()==0)
			{
				handleFacesError(PWiConstants.ERROR_MANDATORY_ROLE);
				valid = false;
			}
	
			if (!valid) {
				// Validation errors exist, return to same page to display
				// validation error messages
				return PWiConstants.NAV_ADMIN_USER_EDITOR;
			}
	
			List<Integer> selectedRoleIds = new ArrayList<Integer>();
			List<String> selectedRoleNms = new ArrayList<String>();
			for (PWiRoleVO user : selectedRolesList) {
				selectedRoleIds.add(user.getRoleSeqId());
				selectedRoleNms.add(user.getRoleDesc());
			}
			
			// Persist new role
			this.usrId =userService.createNewUser(firstName, lastName,ssoId,email,enabled ,selectedRoleIds,selectedRoleNms,emailNotification);
				
				
				handleFacesInfo("User " + this.firstName + " created successfully.");
	
				
				//return "NAV_ADMIN_USER_EDITOR";
				return PWiConstants.NAV_ADMIN_USER_LIST;
	}
		
		/*private boolean validate(String text) {
			boolean valid = true;

			// Validate text
			if (StringUtils.contains(StringUtils.upperCase(text),
					JAVASCRIPT_START_TAG)
					|| StringUtils.contains(StringUtils.upperCase(text),
							JAVASCRIPT)
					|| StringUtils.contains(StringUtils.upperCase(text),
							JAVASCRIPT_CLOSE_TAG)||StringUtils.contains(StringUtils.upperCase(text),
									JAVASCRIPT_GT)||StringUtils.contains(StringUtils.upperCase(text),
											JAVASCRIPT_LT)) {
				handleFacesError("Validation Failed! Please remove JavaScript from all custom text.");
				valid = false;
			}

			return valid;
		}*/
		
		
	/*	//-----------------METHOD FOR SAVING THE NEW USER  ----------------------
		public String actionSaveNewUser() throws PWiException {
			// Check for validation errors
			boolean valid = userService.validateName(firstName);
			if (userService.checkNames(firstName, lastName,email,ssoId) > 0) {
				handleFacesError(PWiConstants.ERROR_DUPLICATE_NAME);
				valid = false;
			}

			if (!valid) {
				// Validation errors exist, return to same page to display
				// validation error messages
				return PWiConstants.NAV_ADMIN_USER_EDITOR;
			}
			// Persist new role
			
			
			List<Integer> selectedGroupIds = new ArrayList<Integer>();
			for (PWiRoleVO role : selectedQueryGroupsList) {
				selectedGroupIds.add(group.getQueryGroupId());
			}
			
			this.usrId =userService.createNewUser(ssoId,
					firstName, lastName,email );
				
				
				handleFacesInfo("User " + this.firstName + " created successfully.");

				
				//return "NAV_ADMIN_USER_EDITOR";
				return PWiConstants.NAV_ADMIN_USER_LIST;
			
			}

}
	*/
	
	
	

	/**
	 * Action method that responds to requests to save a newly created objectType.
	 * 
	 * @return Faces navigation outcome
	 * @throws PWiException
	 */
	/*public String actionSaveNewUser() throws PWiException {
		// Check for validation errors
		boolean valid = userService.validateName(firstName);
		if (userService.checkNames(firstName, lastName,email,ssoId) > 0) {
			handleFacesError(PWiConstants.ERROR_DUPLICATE_NAME);
			valid = false;
		}

		if (!valid) {
			// Validation errors exist, return to same page to display
			// validation error messages
			return PWiConstants.NAV_ADMIN_USER_EDITOR;
		}

		List<Integer> selectedGroupIds = new ArrayList<Integer>();
		for (PWiQueryGroupVO group : selectedQueryGroupsList) {
			selectedGroupIds.add(group.getQueryGroupId());
		}

		// Persist new user
		this.userId = userService.createNewUser(
				firstName, lastName, email, 
				getSsoId());

		handleFacesInfo("firstName " + this.firstName + " created successfully.");

		return PWiConstants.NAV_ADMIN_USER_LIST;
	}



	*//**
	 * Initializes state necessary to display admin object type editor to create
	 * a new object type.
	 * 
	 * @return JSF navigation string
	 *//*
	public String initCreate() {
		this.isNew = true;

		// Initialize object type-related state
		this.objTypId = null;
		this.objectTypeName = null;
		this.objectTypeDesc = null;
		this.shwInQi = true;

		// Initialize group-related state
		this.originalSelectedGroups = new ArrayList<PWiQueryGroupVO>();
		this.selectedQueryGroupsList = new ArrayList<PWiQueryGroupVO>();
		this.availableQueryGroupList = (List<PWiQueryGroupVO>) queryGroupService
				.getAllQueryGroups();

		return PWiConstants.NAV_ADMIN_OBJ_TYP_EDITOR;
	}

	*//**
	 * Initializes state necessary to display the admin object type editor to
	 * edit the specified object type.
	 * 
	 * @param theObjectTypeSequenceId
	 *            ID of the object type to edit
	 * @return JSF navigation string
	 * @throws PWiException
	 *//*
	public String initEdit(Integer theObjectTypeSequenceId) throws PWiException {
		this.isNew = false;

		this.objTypId = theObjectTypeSequenceId;

		// Initialize object type-related state
		PWiObjectTypeVO resultObjectType = objectTypeService.getObjectTypeById(this.objTypId);
		this.objectTypeName = resultObjectType.getObjTypNm();
		this.objectTypeDesc = resultObjectType.getObjTypDesc();
		this.shwInQi = resultObjectType.isShwInQi();

		// Initialize group-related state
		this.originalSelectedGroups = queryGroupService
				.findSelectedGroupsForObjectType(this.objTypId);
		this.selectedQueryGroupsList = new ArrayList<PWiQueryGroupVO>();
		this.selectedQueryGroupsList.addAll(this.originalSelectedGroups);
		this.availableQueryGroupList = (List<PWiQueryGroupVO>) queryGroupService
				.getAllQueryGroups();
		this.availableQueryGroupList.removeAll(selectedQueryGroupsList);

		return PWiConstants.NAV_ADMIN_OBJ_TYP_EDITOR;
	}

	public void getNonSelectedGroups(List<PWiQueryGroupVO> availList,
			List<PWiQueryGroupVO> selectList) {
		for (PWiQueryGroupVO queryGroupVO : selectList) {
			removeVO(availList, queryGroupVO);
		}
	}

	private void removeVO(List<PWiQueryGroupVO> searchList,
			PWiQueryGroupVO queryGroupVO) {
		ListIterator<PWiQueryGroupVO> itr = searchList.listIterator();
		while (itr.hasNext()) {
			PWiQueryGroupVO QueryGroupVO1 = (PWiQueryGroupVO) itr.next();
			if (QueryGroupVO1.equals(queryGroupVO)) {
				itr.remove();
			}
		}
	}

	*//**
	 * Action method that responds to requests to save changes to an edited
	 * query.
	 * 
	 * @return a Faces navigation outcome.
	 * @throws PWiException
	 *//*
	public String actionUpdateObjectType() throws PWiException {
		// Check for validation errors
		boolean valid = objectTypeService.validateName(this.objectTypeName);
		if (objectTypeService.checkNamesForEdit(
				this.objectTypeName, this.objectTypeDesc, this.objTypId) > 0) {
			handleFacesError(PWiConstants.ERROR_DUPLICATE_NAME);
			valid = false;
		}

		if (!valid) {
			// Validation errors exist, return to same page to display
			// validation error messages
			return PWiConstants.NAV_ADMIN_OBJ_TYP_EDITOR;
		}

		String userId = getSsoId();

		// Initialize query
		PWiObjectTypeVO objectType = new PWiObjectTypeVO();
		objectType.setObjTypSeqId(objTypId);
		objectType.setObjTypNm(objectTypeName);
		objectType.setObjTypDesc(objectTypeDesc);
		objectType.setShwInQi(shwInQi);

		List<Integer> selectedGroupIds = new ArrayList<Integer>();
		for (PWiQueryGroupVO group : selectedQueryGroupsList) {
			selectedGroupIds.add(group.getQueryGroupId());
		}

		// Persist updated object type
		objectTypeService.updateObjectType(objectType, selectedGroupIds, userId);

		handleFacesInfo("ObjectType " + this.objectTypeName + " updated successfully.");
		return PWiConstants.NAV_ADMIN_OBJ_TYP_LIST;
	}
	
	public String actionCancel() {
		return PWiConstants.NAV_ADMIN_OBJ_TYP_LIST;
	}

	public boolean isNew() {
		return isNew;
	}

	public String getObjectTypeName() {
		return objectTypeName;
	}
	public void setObjectTypeName(String objectTypeName) {
		this.objectTypeName = objectTypeName;
	}

	*//**
	 * @return the allQueryGroups
	 *//*
	public String getAllQueryGroups() {
		return allQueryGroups;
	}

	*//**
	 * @param allQueryGroups
	 *//*
	public void setAllQueryGroups(String allQueryGroups) {
		this.allQueryGroups = allQueryGroups;
	}

	*//**
	 * @return the selectedQueryGroupsList
	 *//*
	public List<PWiQueryGroupVO> getSelectedQueryGroupsList() {
		return selectedQueryGroupsList;
	}

	*//**
	 * @param selectedQueryGroupsList
	 *            the selectedQueryGroupsList to set
	 *//*
	public void setSelectedQueryGroupsList(
			List<PWiQueryGroupVO> selectedQueryGroupsList) {
		this.selectedQueryGroupsList = selectedQueryGroupsList;
	}

	*//**
	 * @return the availableQueryGroupList
	 *//*
	public List<PWiQueryGroupVO> getAvailableQueryGroupList() {
		return availableQueryGroupList;
	}

	*//**
	 * @param availableQueryGroupList
	 *            the availableQueryGroupList to set
	 *//*
	public void setAvailableQueryGroupList(
			List<PWiQueryGroupVO> availableQueryGroupList) {
		this.availableQueryGroupList = availableQueryGroupList;
	}

	public Integer getObjectTypeSequenceId() {
		return objTypId;
	}

	public void setObjectTypeSequenceId(Integer objTypId) {
		this.objTypId = objTypId;
	}

	public String getEmail() {
		return emailId;
	}

	public void setObjectTypeDesc(String objectTypeDescription) {
		this.objectTypeDesc = objectTypeDescription;
	}

	public void setShwInQi(boolean shwInQi) {
		this.shwInQi = shwInQi;
	}

	public boolean isShwInQi() {
		return shwInQi;
	}*/
	
	/**
	 * Action method that responds to requests to save a newly created role.
	 * 
	 * @return Faces navigation outcome
	 * @throws PWiException
	 */
	
	}
