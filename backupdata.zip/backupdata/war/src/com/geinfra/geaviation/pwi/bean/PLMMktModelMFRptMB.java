/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMMktModelMB.java
 * @Creation date: 12-June-2017
 * @version 1.0
 * @author : Tech Mahindra (PWi Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.TreeMap;

import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMCFQLCompareData;
import com.geinfra.geaviation.pwi.data.PLMMktModelRptData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMCFQLCompareServiceIfc;
import com.geinfra.geaviation.pwi.service.PLMMktModelRptServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMMktModelMFRptMB {
	
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMCustBomRptMB.class);
	
	/**
	 *  Holds the contractSumrReptService
	 */
	private PLMMktModelRptServiceIfc plmMktModelRptService = null;
	/**
	 * Holds the PLMEBomToMBomServiceIfc
	 */
	private PLMCFQLCompareServiceIfc plmCFQLCompareService  = null;
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	
	/**
	 * Holds user information
	 */
	private PLMPwiUserData userDetails = null;

	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	/**
	 * Holds the resourceBundle
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the productNamesLst
	 */
	private List<SelectItem> productNamesLst = new ArrayList<SelectItem>();
	/**
	 * Holds the productNamesLst
	 */
	private List<SelectItem> productLinesLst = new ArrayList<SelectItem>();
	/**
	 * Holds the modelsLst
	 */
	private List<PLMMktModelRptData> modelsAndHwPrdtsLst = new ArrayList<PLMMktModelRptData>();
	/**
	 * Holds the selProduct
	 */
	private String selProduct;
	/**
	 * Holds the selProductLines
	 */
	private List<String> selProductLines = new ArrayList<String>();
	/**
	 * Holds the selHardwareProduct
	 */
	private String selHardwareProduct;
	/**
	 * Holds the prodManagementFlag
	 */
	private boolean prodManagementFlag;
	/**
	 * Holds the preliminaryFlag
	 */
	private boolean preliminaryFlag;
	/**
	 * Holds the compareFlag
	 */
	private boolean compareFlag;
	/**
	 * Holds the nocompareFlag
	 */
	private boolean nocompareFlag;
	/**
	 * Holds the totalContractsCnt
	 */
	private int totalModelsAndHwPrdtsCnt;

	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;
	/**
	 * Holds the bulkHwPRdListFinal
	 */
	List<PLMCFQLCompareData> bulkHwPRdListFinal=new ArrayList<PLMCFQLCompareData>();
	/**
	 * @return
	 */
	public String getProductList() {
		LOG.info("getProductList() Method");
		String fwdFlag = "";
		alertMessage = "";
		productNamesLst = new ArrayList<SelectItem>();
		productNamesLst.add(new SelectItem("Gas"));
		productNamesLst.add(new SelectItem("Steam"));
		productNamesLst.add(new SelectItem("Gen"));
		productNamesLst.add(new SelectItem("PLANT"));
		try {
			 commonMB.insertCannedRptRecordHitInfo("Marketing Model MF Report");
			 
			 prodManagementFlag = true;
			 preliminaryFlag = false;
			 compareFlag = false;
			 nocompareFlag = false;
			 productLinesLst = new ArrayList<SelectItem>();
			 modelsAndHwPrdtsLst = new ArrayList<PLMMktModelRptData>();
			 selProduct = "";
			 selProductLines = new ArrayList<String>();
			 selHardwareProduct = "";
			 bulkHwPRdListFinal = new ArrayList<PLMCFQLCompareData>();
			 fwdFlag = "mktModelMFSearch";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getProductList: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Marketing Model MF Report");
		} 
		return fwdFlag;
	}
	
	/**
	 * @return
	 */
	public String getProductLinesList() {
		LOG.info("Entering getProductLinesList method");
		String fwdFlag = "mktModelMFSearch";
		alertMessage = validationForMktModelMFRpt();
		LOG.info("alertMessage >>>>>>>> "+ alertMessage);
		try {
			if(PLMUtils.isEmpty(alertMessage)){
				LOG.info("Selected Product >>>>>> "+ selProduct);
				LOG.info("Selected prodManagementFlag >>>>>> "+ prodManagementFlag);
				LOG.info("Selected preliminaryFlag >>>>>> "+ preliminaryFlag);
				productLinesLst = plmMktModelRptService.getProductLines(selProduct, prodManagementFlag, preliminaryFlag);
				
				if (PLMUtils.isEmptyList(productLinesLst)) {
					productLinesLst = new ArrayList<SelectItem>();
				} 
				
				LOG.info("productLinesLst size >>>>> "+ productLinesLst.size());
				
				modelsAndHwPrdtsLst = new ArrayList<PLMMktModelRptData>();
			}
		
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getProductLinesList: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Marketing Model MF Report");
		} 
		return fwdFlag;
	}
	
	/**
	 * @return
	 */
	public String getModelsAndHwPrdts() {
		LOG.info("Entering getModelsAndHwPrdts method");
		String fwdflag = "";
		alertMessage = "";
		alertMessage = validationForPL();
		LOG.info("alertMessage >>>>>>>> "+ alertMessage);
		try {
			if(PLMUtils.isEmpty(alertMessage)){
				LOG.info("Selected Product >>>>>> "+ selProduct);
				LOG.info("Selected prodManagementFlag >>>>>> "+ prodManagementFlag);
				LOG.info("Selected preliminaryFlag >>>>>> "+ preliminaryFlag);
				modelsAndHwPrdtsLst = plmMktModelRptService.getModelsAndHwPrdts(selProduct, selProductLines, prodManagementFlag, preliminaryFlag);
				
				if(modelsAndHwPrdtsLst.size() == 0) {
					alertMessage = PLMConstants.NO_HP_DATA_ALERT_MSG;
				}else {
					totalModelsAndHwPrdtsCnt = modelsAndHwPrdtsLst.size();
				    LOG.info("The number of results from modelsAndHwPrdtsLst List >> "+ totalModelsAndHwPrdtsCnt);
				    recordCounts = PLMConstants.N_100;
				 }
				LOG.info("modelsAndHwPrdtsLst size >>>>> "+ modelsAndHwPrdtsLst.size());
				
			}
		
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getModelsAndHwPrdts: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Marketing Model MF Report");
		} 
		return fwdflag;
	}
	
	/**
	 * 
	 * @return String
	 */
	public String validationForMktModelMFRpt(){
		alertMessage = "";
		if (PLMUtils.isEmpty(selProduct) && prodManagementFlag == false && preliminaryFlag == false) {
			alertMessage = alertMessage + PLMConstants.MKT_MODEL_REQ_RPT_ALL_EMPTY_CHK;
		} else if (prodManagementFlag == false && preliminaryFlag == false) {
			alertMessage = alertMessage + PLMConstants.MKT_MODEL_REQ_RPT_STATE_EMPTY_CHK;
		} else if (PLMUtils.isEmpty(selProduct)) {
			alertMessage = alertMessage + PLMConstants.MKT_MODEL_REQ_RPT_PRDT_EMPTY_CHK;
		} 
		return alertMessage;
	}
	
	/**
	 * 
	 * @return String
	 */
	public String validationForPL(){
		alertMessage = "";
		if (PLMUtils.isEmptyList(selProductLines)) {
			alertMessage = alertMessage + PLMConstants.MKT_MODEL_MF_RPT_PL_EMPTY_CHK;
		} else if (compareFlag == false && nocompareFlag == false) {
			alertMessage = alertMessage + PLMConstants.MKT_MODEL_REQ_RPT_TYPE_EMPTY_CHK;
		}
		return alertMessage;
	}
	
	/**
	 * 
	 */
	public void resetMktModelMFRpt() {
		selProduct = "";
		prodManagementFlag = true;
		preliminaryFlag = false;
		compareFlag = false;
		nocompareFlag = false;
		selProductLines = new ArrayList<String>();
		selHardwareProduct = "";
		productNamesLst = new ArrayList<SelectItem>();
		productNamesLst.add(new SelectItem("Gas"));
		productNamesLst.add(new SelectItem("Steam"));
		productNamesLst.add(new SelectItem("Gen"));
		productNamesLst.add(new SelectItem("PLANT"));
		alertMessage = "";
		productLinesLst = new ArrayList<SelectItem>();
		modelsAndHwPrdtsLst = new ArrayList<PLMMktModelRptData>();
		bulkHwPRdListFinal = new ArrayList<PLMCFQLCompareData>();
	}
	
	/**
	 * 
	 */
	public String sendEmail() throws PWiException {
		LOG.info("Entering sendEmail method");
		String fwdFlag="mktModelMFSearch";
		if (null != selHardwareProduct) {
			LOG.info("selHardwareProduct >>>>> "+ selHardwareProduct);
			
			List<String> hpValuesList = new ArrayList<String>();

			if (selHardwareProduct != null) {
				StringTokenizer strTok = new StringTokenizer(selHardwareProduct, ",");
				while (strTok.hasMoreTokens()) {
					hpValuesList.add(strTok.nextToken());
				}
			}
			
			if (!PLMUtils.isEmptyList(hpValuesList) && hpValuesList.size() > 20) {
				alertMessage = PLMConstants.MKT_MODEL_REQ_RPT_MODEL_CNT_CHK;
			}
			
			PLMCFQLCompareData tempData = new PLMCFQLCompareData();
			userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
			try {
				if(PLMUtils.isEmpty(alertMessage)) {
					bulkHwPRdListFinal = new ArrayList<PLMCFQLCompareData>();
					for (int i = 0; i < hpValuesList.size(); i++) {
						tempData = new PLMCFQLCompareData();
						String str = hpValuesList.get(i);
						StringTokenizer strTok = new StringTokenizer(str, "~");
						tempData.setHwPrdctNm(strTok.nextToken());
						if (strTok.hasMoreTokens()) {
							tempData.setRevNm(strTok.nextToken());
						}
						bulkHwPRdListFinal.add(tempData);
						LOG.info("HP Name >>>>> "+ tempData.getHwPrdctNm() + " HP Rev >>>>> "+ tempData.getRevNm());
					}
					
					LOG.info("Compare Flag Value >>>>> "+ compareFlag + " Non-Compare Flag Value >>>>> "+ nocompareFlag);
					if (compareFlag || nocompareFlag) {
					
						String invalidMessage = plmCFQLCompareService.getValidHardwrPrd(bulkHwPRdListFinal);
						if(PLMUtils.isEmpty(invalidMessage)){
							if (compareFlag && nocompareFlag) {
								alertMessage =  PLMConstants.MKT_MODEL_MF_BOTH_RPT_MAIL_ALERT_MSG;
							} else if (nocompareFlag) {
								alertMessage =  PLMConstants.MKT_MODEL_MF_NOC_RPT_MAIL_ALERT_MSG;
							} else if (compareFlag) {
								alertMessage =  PLMConstants.MKT_MODEL_MF_RPT_MAIL_ALERT_MSG;
							}
							taskExecutor.execute(new MailThread());
						}else{
							alertMessage =invalidMessage;
						}
					}
					
				}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@sendEmail: ", exception);
				fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"mktModelMFSearch","Marketing Model MF Report");
			}
			LOG.info("Exiting sendEmail Method");
		}
		return fwdFlag;
	}
	
	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			if (compareFlag && nocompareFlag) {
				sendCFQLCompareRptMail();
				sendCFQLNoCompareRptMail();
			} else if (nocompareFlag) {
				sendCFQLNoCompareRptMail();
			} else if (compareFlag) {
				sendCFQLCompareRptMail();
			}
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return void
	 */
	public void sendCFQLNoCompareRptMail() {
		LOG.info("Entering sendCFQLNoCompareRptMail Method");
		String from = PLMConstants.OMM_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.MKTMODELMFNOCOMPARE_SUBJECT;
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("MKTMODELMF_NOCOMPARISON_RPT") +  uniqTime + ".xlsx";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("MKTMODELMF_NOCOMPARISON_RPT") +  uniqTime + ".zip";
		TreeMap <Integer,Object> cfQlCompareTreeMap = new TreeMap<Integer,Object>();
		List<PLMCFQLCompareData> bulkHwPRdListFinalLcl =bulkHwPRdListFinal;
		boolean subtypeLcl=true;
		boolean defaultTypeLcl =true;
		boolean sequenceNmLcl= true;
		boolean chapterFlagLcl =true;
		try {
			cfQlCompareTreeMap = plmCFQLCompareService.getCFQLNonCompareRpt(bulkHwPRdListFinalLcl);
			List<PLMCFQLCompareData> cfQlCompareListLcl = (List<PLMCFQLCompareData>) cfQlCompareTreeMap.get(0);
			StringBuffer mailBody = new StringBuffer().append(toAddressee);
			if(PLMUtils.isEmptyList(cfQlCompareListLcl)){
				mailBody.append(PLMConstants.MKTMODELMFNOCOMPARE_MAIL_CONTENT_NO_RECORD)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				PLMUtils.sendMail(from, to, subject, mailBody.toString());
			} else {
				mailBody.append(PLMConstants.MKTMODELMFNOCOMPARE_MAIL_CONTENT)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				saveCFQLNoCompareRptXLSFile(cfQlCompareListLcl,subtypeLcl,defaultTypeLcl,sequenceNmLcl,chapterFlagLcl,fileDir,filePathXls);
				cfQlCompareListLcl.clear();
				PLMUtils.generateZipFile(filePathXls,filePathZip);
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendCFQLNoCompareRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendCFQLNoCompareRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} finally {
			PLMUtils.deleteFiles(filePathXls,filePathZip);
			cfQlCompareTreeMap.clear();
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendCFQLNoCompareRptMail Method");
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return void
	 */
	public void sendCFQLCompareRptMail() {
		LOG.info("Entering sendCFQLCompareRptMail Method");
		String from = PLMConstants.OMM_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.MKTMODELMFCOMPARE_SUBJECT;
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("MKTMODELMF_COMPARISON_RPT") +  uniqTime + ".xlsx";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("MKTMODELMF_COMPARISON_RPT") +  uniqTime + ".zip";
		TreeMap <Integer,Object> cfQlCompareTreeMap = new TreeMap<Integer,Object>();
		List<PLMCFQLCompareData> bulkHwPRdListFinalLcl =bulkHwPRdListFinal;
		boolean subtypeLcl=true;
		boolean defaultTypeLcl =true;
		boolean sequenceNmLcl= true;
		boolean chapterFlagLcl =true;
		try {
			cfQlCompareTreeMap = plmCFQLCompareService.getCFQLCompareRpt(bulkHwPRdListFinalLcl);
			List<String> marketNameListLcl = (List<String>) cfQlCompareTreeMap.get(0);
			List<PLMCFQLCompareData> cfQlCompareListLcl = (List<PLMCFQLCompareData>) cfQlCompareTreeMap.get(1);
			StringBuffer mailBody = new StringBuffer().append(toAddressee);
			if(PLMUtils.isEmptyList(cfQlCompareListLcl)){
				mailBody.append(PLMConstants.MKTMODELMFCOMPARE_MAIL_CONTENT_NO_RECORD)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				PLMUtils.sendMail(from, to, subject, mailBody.toString());
			} else {
				mailBody.append(PLMConstants.MKTMODELMFCOMPARE_MAIL_CONTENT)
				.append(".")
				.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				saveCFQLCompareRptXLSFile(marketNameListLcl,cfQlCompareListLcl,subtypeLcl,defaultTypeLcl,sequenceNmLcl,chapterFlagLcl,fileDir,filePathXls);
				marketNameListLcl.clear();
				cfQlCompareListLcl.clear();
				PLMUtils.generateZipFile(filePathXls,filePathZip);
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendCFQLCompareRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendCFQLCompareRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} finally {
			PLMUtils.deleteFiles(filePathXls,filePathZip);
			cfQlCompareTreeMap.clear();
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendCFQLCompareRptMail Method");
	}
	
	
	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return void
	 */
	public void saveCFQLNoCompareRptXLSFile(List<PLMCFQLCompareData> cfQlCompareListLcl,
			boolean subtypeLcl,boolean defaultTypeLcl,boolean sequenceNmLcl,boolean chapterFlagLcl,String fileDir,String filePathXls) throws IOException {
		LOG.info("Entering saveCFQLNoCompareRptXLSFile Method");
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXls);
				XSSFWorkbook workbook = new XSSFWorkbook();
				
				XSSFFont font = headerFont(workbook, 10);
				
				// Header Style
				XSSFCellStyle headerStyle = headerCell(workbook, font, HSSFColor.PALE_BLUE.index, true);

				
				// Header Style
				XSSFCellStyle dateheaderStyle = dateStyleheaderCell(workbook, font, HSSFColor.WHITE.index, true);

				XSSFFont cellfont = normalFont(workbook, 10);
				// Cell Style
				XSSFCellStyle cellStyle = normalCell(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
				XSSFCellStyle cellStyleLeft = normalCellLeft(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
				XSSFCellStyle cellStyleRight = normalCellRight(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
				
				XSSFCellStyle cellStyleCF = ((XSSFWorkbook) workbook).createCellStyle();
				cellStyleCF.setAlignment(CellStyle.ALIGN_CENTER);
				cellStyleCF.setFillForegroundColor(new XSSFColor(new java.awt.Color(242, 220, 219)));
				cellStyleCF.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
				cellStyleCF.setFont(font);
				
				XSSFCellStyle cellStyleCFLeft = ((XSSFWorkbook) workbook).createCellStyle();
				cellStyleCFLeft.setAlignment(CellStyle.ALIGN_LEFT);
				cellStyleCFLeft.setFillForegroundColor(new XSSFColor(new java.awt.Color(242, 220, 219)));
				cellStyleCFLeft.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
				cellStyleCFLeft.setFont(font);
				
				XSSFCellStyle cellStyleCFRight = ((XSSFWorkbook) workbook).createCellStyle();
				cellStyleCFRight.setAlignment(CellStyle.ALIGN_RIGHT);
				cellStyleCFRight.setFillForegroundColor(new XSSFColor(new java.awt.Color(242, 220, 219)));
				cellStyleCFRight.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
				cellStyleCFRight.setFont(font);

				XSSFSheet sheet =  (XSSFSheet) workbook.createSheet("Model MF Non-Comparison Report");
				
				int rowcount = 0;
				
				XSSFCell cell=null;
				
			    XSSFRow row = (XSSFRow) sheet.createRow(rowcount);		
			    
			    cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell. setCellValue(commonMB.getDateStampEtl());
				cell.setCellStyle(dateheaderStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,0,3));
			    
			    //String hpMktNm = "";
			   // String prevHpMktNm = "";
			    //int rowStart = 3;
			    //int rowEnd = 0;
			    row = (XSSFRow) sheet.createRow(++rowcount);
			    for (int i=0;i<cfQlCompareListLcl.size();i++) {
			    	//hpMktNm = cfQlCompareListLcl.get(i).getHpMarketingNm();
			    	
			    //if (i == 0 || (!PLMUtils.isEmpty(prevHpMktNm) && !hpMktNm.equalsIgnoreCase(prevHpMktNm)) ) {
			    	
				    
				    /*if (i > 0) {
				    	rowEnd = rowcount - 1;
				    	sheet.groupRow(rowStart, rowEnd);
				    	sheet.setRowGroupCollapsed(rowStart, false);
				    	rowStart = rowcount + 2;
				    }*/
				    
				    if (i==0) {
					cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellValue("Product Type");
					cell.setCellStyle(headerStyle);
					
					cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellValue("Product Line");
					cell.setCellStyle(headerStyle);
					
					cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellValue("Model");
					cell.setCellStyle(headerStyle);
					
					cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
					cell.setCellValue("Hardware Product");
					cell.setCellStyle(headerStyle);
					
					cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell.setCellValue("HP Rev");
					cell.setCellStyle(headerStyle);
					
					cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell.setCellValue("HP State");
					cell.setCellStyle(headerStyle);
					
					cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_SIX);
					cell.setCellValue("Level");
					cell.setCellStyle(headerStyle);
					
					cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_SEVEN);
					cell. setCellValue("Display Name");
					cell.setCellStyle(headerStyle);
					
					cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_EIGHT);
					cell. setCellValue("MF Option Name");
					cell.setCellStyle(headerStyle);
	
					cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_NINE);
					cell. setCellValue("Rev");
					cell.setCellStyle(headerStyle);
					
					cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_TEN);
					cell. setCellValue("Pegasus Code");
					cell.setCellStyle(headerStyle);
					
					/*cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
					cell.setCellValue(hpMktNm + " " + cfQlCompareListLcl.get(i).getHwPrdctNm());
					cell.setCellStyle(headerStyle);
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
					cell.setCellStyle(headerStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ELEVEN,PLMConstants.EXCEL_COL_SIXTEEN));
					cell.setCellStyle(headerStyle);
					
					row = (XSSFRow) sheet.createRow(++rowcount);
					
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellStyle(headerStyle);
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellStyle(headerStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount-1,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ZERO));
					cell.setCellStyle(headerStyle);
				
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(headerStyle);
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(headerStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount-1,rowcount,PLMConstants.EXCEL_COL_ONE,PLMConstants.EXCEL_COL_ONE));
					cell.setCellStyle(headerStyle);
	
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellStyle(headerStyle);
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellStyle(headerStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount-1,rowcount,PLMConstants.EXCEL_COL_TWO,PLMConstants.EXCEL_COL_TWO));
					cell.setCellStyle(headerStyle);
	
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
					cell.setCellStyle(headerStyle);
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
					cell.setCellStyle(headerStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount-1,rowcount,PLMConstants.EXCEL_COL_THREE,PLMConstants.EXCEL_COL_THREE));
					cell.setCellStyle(headerStyle);
					
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell.setCellStyle(headerStyle);
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell.setCellStyle(headerStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount-1,rowcount,PLMConstants.EXCEL_COL_FOUR,PLMConstants.EXCEL_COL_FOUR));
					cell.setCellStyle(headerStyle);
					
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell.setCellStyle(headerStyle);
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell.setCellStyle(headerStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount-1,rowcount,PLMConstants.EXCEL_COL_FIVE,PLMConstants.EXCEL_COL_FIVE));
					cell.setCellStyle(headerStyle);
					
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
					cell.setCellStyle(headerStyle);
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
					cell.setCellStyle(headerStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount-1,rowcount,PLMConstants.EXCEL_COL_SIX,PLMConstants.EXCEL_COL_SIX));
					cell.setCellStyle(headerStyle);
					
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
					cell.setCellStyle(headerStyle);
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
					cell.setCellStyle(headerStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount-1,rowcount,PLMConstants.EXCEL_COL_SEVEN,PLMConstants.EXCEL_COL_SEVEN));
					cell.setCellStyle(headerStyle);
					
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
					cell.setCellStyle(headerStyle);
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
					cell.setCellStyle(headerStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount-1,rowcount,PLMConstants.EXCEL_COL_EIGHT,PLMConstants.EXCEL_COL_EIGHT));
					cell.setCellStyle(headerStyle);
					
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
					cell.setCellStyle(headerStyle);
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
					cell.setCellStyle(headerStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount-1,rowcount,PLMConstants.EXCEL_COL_NINE,PLMConstants.EXCEL_COL_NINE));
					cell.setCellStyle(headerStyle);
					
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TEN);
					cell.setCellStyle(headerStyle);
					cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TEN);
					cell.setCellStyle(headerStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount-1,rowcount,PLMConstants.EXCEL_COL_TEN,PLMConstants.EXCEL_COL_TEN));
					cell.setCellStyle(headerStyle);*/
					
					int colHdrTypeIncr=11;
						
					if(chapterFlagLcl){
							cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
							cell. setCellValue("Display Name Chapter");
							cell.setCellStyle(headerStyle);
							
							cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
							cell. setCellValue("MF Chapter");
							cell.setCellStyle(headerStyle);
		
							cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
							cell. setCellValue("Rev. Chapter");
							cell.setCellStyle(headerStyle);
					    }
						
						if(subtypeLcl){
							cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
							cell. setCellValue("Option Subtype");
							cell.setCellStyle(headerStyle);
						}
						
						if(defaultTypeLcl){
							cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
							cell. setCellValue("Default Selection");
							cell.setCellStyle(headerStyle);
						}
	
						if(sequenceNmLcl){
							cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
							cell. setCellValue("Sequence Number");
							cell.setCellStyle(headerStyle);
						}
						
				    }
			   // } // Header ends here 
			    
					///prevHpMktNm = hpMktNm;
					
					PLMCFQLCompareData	 dataObj = (PLMCFQLCompareData)cfQlCompareListLcl.get(i);
					
					row = (XSSFRow) sheet.createRow(++rowcount);
					
					if ("2".equalsIgnoreCase(dataObj.getLevel())) {
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellStyle(cellStyleCFRight);
						cell.setCellValue(dataObj.getProductType());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(cellStyleCFRight);
						cell.setCellValue(dataObj.getProductLine());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellStyle(cellStyleCFRight);
						cell.setCellValue(dataObj.getModel());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
						cell.setCellStyle(cellStyleCFRight);
						cell.setCellValue(dataObj.getHwPrdctNm());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
						cell.setCellStyle(cellStyleCFRight);
						cell.setCellValue(dataObj.getRevNm());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
						cell.setCellStyle(cellStyleCFRight);
						cell.setCellValue(dataObj.getHpState());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
						cell.setCellStyle(cellStyleCFRight);
						cell.setCellValue(dataObj.getLevel());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
						cell.setCellStyle(cellStyleCFLeft);
						cell.setCellValue(dataObj.getDisplayNm());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
						cell.setCellStyle(cellStyleCFLeft);
						cell.setCellValue(dataObj.getConfOption());
		
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
						cell.setCellStyle(cellStyleCF);
						cell.setCellValue(dataObj.getRev());
		
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TEN);
						cell.setCellStyle(cellStyleCFLeft);
						cell.setCellValue(dataObj.getPegasusCode());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
						cell.setCellStyle(cellStyleCFLeft);
						cell.setCellValue(dataObj.getChDisplayNm());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWELVE);
						cell.setCellStyle(cellStyleCFLeft);
						cell.setCellValue(dataObj.getMfChapter());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
						cell.setCellStyle(cellStyleCFLeft);
						cell.setCellValue(dataObj.getRevChapter());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
						cell.setCellStyle(cellStyleCFLeft);
						cell.setCellValue(dataObj.getSubType());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
						cell.setCellStyle(cellStyleCFLeft);
						cell.setCellValue(dataObj.getDefaultType());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
						cell.setCellStyle(cellStyleCFLeft);
						cell.setCellValue(dataObj.getSequenceNum());
					} else if ("3".equalsIgnoreCase(dataObj.getLevel())) {
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellStyle(cellStyleRight);
						cell.setCellValue(dataObj.getProductType());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(cellStyleRight);
						cell.setCellValue(dataObj.getProductLine());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellStyle(cellStyleRight);
						cell.setCellValue(dataObj.getModel());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
						cell.setCellStyle(cellStyleRight);
						cell.setCellValue(dataObj.getHwPrdctNm());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
						cell.setCellStyle(cellStyleRight);
						cell.setCellValue(dataObj.getRevNm());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
						cell.setCellStyle(cellStyleRight);
						cell.setCellValue(dataObj.getHpState());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
						cell.setCellStyle(cellStyleRight);
						cell.setCellValue(dataObj.getLevel());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
						cell.setCellStyle(cellStyleLeft);
						cell.setCellValue(dataObj.getDisplayNm());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
						cell.setCellStyle(cellStyleLeft);
						cell.setCellValue(dataObj.getConfOption());

						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(dataObj.getRev());

						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TEN);
						cell.setCellStyle(cellStyleLeft);
						cell.setCellValue(dataObj.getPegasusCode());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
						cell.setCellStyle(cellStyleLeft);
						cell.setCellValue(dataObj.getChDisplayNm());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWELVE);
						cell.setCellStyle(cellStyleLeft);
						cell.setCellValue(dataObj.getMfChapter());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
						cell.setCellStyle(cellStyleLeft);
						cell.setCellValue(dataObj.getRevChapter());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
						cell.setCellStyle(cellStyleLeft);
						cell.setCellValue(dataObj.getSubType());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
						cell.setCellStyle(cellStyleLeft);
						cell.setCellValue(dataObj.getDefaultType());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
						cell.setCellStyle(cellStyleRight);
						cell.setCellValue(dataObj.getSequenceNum());
					}
			
				}
				
			    //rowEnd = rowcount+1;
		    	//sheet.groupRow(rowStart, rowEnd);
		    	//sheet.setRowGroupCollapsed(rowStart, false);
		    	
				row = (XSSFRow) sheet.createRow(++rowcount);
				row = (XSSFRow) sheet.createRow(++rowcount);
				
			    XSSFCellStyle ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
			    ftrStyle.setFont(font);
			    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			    cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
			    cell.setCellStyle(ftrStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_THREE));
				
				sheet.createFreezePane( 0, 2 );
				sheet.setColumnWidth(3, 4000);
				sheet.setColumnWidth(5, 5000);
				sheet.setColumnWidth(7, 8000);
				sheet.setColumnWidth(8, 4500);
				sheet.setColumnWidth(10, 4000);
				sheet.setColumnWidth(11, 8000);
				sheet.setColumnWidth(12, 4500);
				sheet.setColumnWidth(14, 4000);
				
				//sheet.groupColumn(PLMConstants.EXCEL_COL_TEN, PLMConstants.EXCEL_COL_FOURTEEN);
				//sheet.setColumnGroupCollapsed(PLMConstants.EXCEL_COL_TEN, false);

				sheet.setZoom(85);
				workbook.write(fileOut);
				fileOut.close();
		  }	
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveCFQLNoCompareRptXLSFile: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveCFQLNoCompareRptXLSFile: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveCFQLNoCompareRptXLSFile: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveCFQLNoCompareRptXLSFile Method");
	}
	
		
	
	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return void
	 */
	public void saveCFQLCompareRptXLSFile(List<String> marketNameListLcl,List<PLMCFQLCompareData> cfQlCompareListLcl,
			boolean subtypeLcl,boolean defaultTypeLcl,boolean sequenceNmLcl,boolean chapterFlagLcl,String fileDir,String filePathXls) throws IOException {
		LOG.info("Entering saveCFQLCompareRptXLSFile Method");
		FileOutputStream fileOut = null;
		boolean createFileExist;
		try {
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXls);
				XSSFWorkbook workbook = new XSSFWorkbook();
				
				XSSFFont font = headerFont(workbook, 10);
				
				// Header Style
				XSSFCellStyle headerStyle = headerCell(workbook, font, HSSFColor.PALE_BLUE.index, true);

				
				// Header Style
				XSSFCellStyle dateheaderStyle = dateStyleheaderCell(workbook, font, HSSFColor.WHITE.index, true);

				XSSFFont cellfont = normalFont(workbook, 10);
				// Cell Style
				XSSFCellStyle cellStyle = normalCell(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
				XSSFCellStyle cellStyleLeft = normalCellLeft(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
				XSSFCellStyle cellStyleRight = normalCellRight(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
				
				XSSFCellStyle cellStyleGreen = headerCell(workbook, font, HSSFColor.GREEN.index, true);
				XSSFCellStyle cellStyleRed = headerCell(workbook, font, HSSFColor.RED.index, true);
				
				XSSFCellStyle cellStyleCF = ((XSSFWorkbook) workbook).createCellStyle();
				cellStyleCF.setAlignment(CellStyle.ALIGN_CENTER);
				cellStyleCF.setFillForegroundColor(new XSSFColor(new java.awt.Color(242, 220, 219)));
				cellStyleCF.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
				cellStyleCF.setFont(font);
				
				XSSFCellStyle cellStyleCFLeft = ((XSSFWorkbook) workbook).createCellStyle();
				cellStyleCFLeft.setAlignment(CellStyle.ALIGN_LEFT);
				cellStyleCFLeft.setFillForegroundColor(new XSSFColor(new java.awt.Color(242, 220, 219)));
				cellStyleCFLeft.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
				cellStyleCFLeft.setFont(font);
				
				XSSFCellStyle cellStyleCFRight = ((XSSFWorkbook) workbook).createCellStyle();
				cellStyleCFRight.setAlignment(CellStyle.ALIGN_RIGHT);
				cellStyleCFRight.setFillForegroundColor(new XSSFColor(new java.awt.Color(242, 220, 219)));
				cellStyleCFRight.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
				cellStyleCFRight.setFont(font);

				XSSFSheet sheet =  (XSSFSheet) workbook.createSheet("Model MF Comparison Report");
				
				int rowcount = 0;
				
				XSSFCell cell=null;
				
			    XSSFRow row = (XSSFRow) sheet.createRow(rowcount);		
			    
			    cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell. setCellValue(commonMB.getDateStampEtl());
				cell.setCellStyle(dateheaderStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,0,2));
			    
			    row = (XSSFRow) sheet.createRow(++rowcount);
				
				cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell. setCellValue("Level");
				cell.setCellStyle(headerStyle);
				
				cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell. setCellValue("Display Name");
				cell.setCellStyle(headerStyle);
				
				cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
				cell. setCellValue("MF Option Name");
				cell.setCellStyle(headerStyle);

				cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
				cell. setCellValue("Rev");
				cell.setCellStyle(headerStyle);
				
				cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_FOUR);
				cell. setCellValue("Pegasus Code");
				cell.setCellStyle(headerStyle);
				
				int colHdrIncrSt=0;
				int colHdrIncrEd=0;
				
				if(chapterFlagLcl && sequenceNmLcl &&  subtypeLcl && defaultTypeLcl){
					 colHdrIncrSt=5;
					 colHdrIncrEd=11;
				}else if((chapterFlagLcl) && ((!sequenceNmLcl &&  subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl))){
					 colHdrIncrSt=5;
					 colHdrIncrEd=10;
				}else if((chapterFlagLcl) && ((sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl))){
					 colHdrIncrSt=5;
					 colHdrIncrEd=9;
				}else if(chapterFlagLcl && !sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl){
					 colHdrIncrSt=5;
					 colHdrIncrEd=8;
				}else if(!chapterFlagLcl && sequenceNmLcl &&  subtypeLcl && defaultTypeLcl){
					 colHdrIncrSt=5;
					 colHdrIncrEd=8;
				}else if((!chapterFlagLcl) && ((!sequenceNmLcl &&  subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl))){
					 colHdrIncrSt=5;
					 colHdrIncrEd=7;
				}else if((!chapterFlagLcl) && ((sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl))){
					 colHdrIncrSt=5;
					 colHdrIncrEd=6;
				}
				
				for ( int j = 0 ;j < marketNameListLcl.size(); j++ ) {
					if(chapterFlagLcl && sequenceNmLcl &&  subtypeLcl && defaultTypeLcl){
						cell = (XSSFCell) row.createCell(colHdrIncrSt);
						cell.setCellValue(marketNameListLcl.get(j));
						cell.setCellStyle(headerStyle);
						cell = (XSSFCell) row.createCell(colHdrIncrEd);
						cell.setCellStyle(headerStyle);
						sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,colHdrIncrSt,colHdrIncrEd));
						cell.setCellStyle(headerStyle);
						colHdrIncrSt =colHdrIncrSt+7;
						colHdrIncrEd =colHdrIncrEd+7;
					}else if((chapterFlagLcl) && ((!sequenceNmLcl &&  subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl))){
						cell = (XSSFCell) row.createCell(colHdrIncrSt);
						cell.setCellValue(marketNameListLcl.get(j));
						cell.setCellStyle(headerStyle);
						cell = (XSSFCell) row.createCell(colHdrIncrEd);
						cell.setCellStyle(headerStyle);
						sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,colHdrIncrSt,colHdrIncrEd));
						cell.setCellStyle(headerStyle);
						colHdrIncrSt =colHdrIncrSt+6;
						colHdrIncrEd =colHdrIncrEd+6;
					}else if((chapterFlagLcl) && ((sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl))){
						cell = (XSSFCell) row.createCell(colHdrIncrSt);
						cell.setCellValue(marketNameListLcl.get(j));
						cell.setCellStyle(headerStyle);
						cell = (XSSFCell) row.createCell(colHdrIncrEd);
						cell.setCellStyle(headerStyle);
						sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,colHdrIncrSt,colHdrIncrEd));
						cell.setCellStyle(headerStyle);
						colHdrIncrSt =colHdrIncrSt+5;
						colHdrIncrEd =colHdrIncrEd+5;
					}else if(chapterFlagLcl && !sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl){
						cell = (XSSFCell) row.createCell(colHdrIncrSt);
						cell.setCellValue(marketNameListLcl.get(j));
						cell.setCellStyle(headerStyle);
						cell = (XSSFCell) row.createCell(colHdrIncrEd);
						cell.setCellStyle(headerStyle);
						sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,colHdrIncrSt,colHdrIncrEd));
						cell.setCellStyle(headerStyle);
						colHdrIncrSt =colHdrIncrSt+4;
						colHdrIncrEd =colHdrIncrEd+4;
					}else if(!chapterFlagLcl && sequenceNmLcl &&  subtypeLcl && defaultTypeLcl){
						cell = (XSSFCell) row.createCell(colHdrIncrSt);
						cell.setCellValue(marketNameListLcl.get(j));
						cell.setCellStyle(headerStyle);
						cell = (XSSFCell) row.createCell(colHdrIncrEd);
						cell.setCellStyle(headerStyle);
						sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,colHdrIncrSt,colHdrIncrEd));
						cell.setCellStyle(headerStyle);
						colHdrIncrSt =colHdrIncrSt+4;
						colHdrIncrEd =colHdrIncrEd+4;
					}else if((!chapterFlagLcl) && ((!sequenceNmLcl &&  subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl))){
						cell = (XSSFCell) row.createCell(colHdrIncrSt);
						cell.setCellValue(marketNameListLcl.get(j));
						cell.setCellStyle(headerStyle);
						cell = (XSSFCell) row.createCell(colHdrIncrEd);
						cell.setCellStyle(headerStyle);
						sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,colHdrIncrSt,colHdrIncrEd));
						cell.setCellStyle(headerStyle);
						colHdrIncrSt =colHdrIncrSt+3;
						colHdrIncrEd =colHdrIncrEd+3;
					}else if((!chapterFlagLcl) && ((sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl))){
						cell = (XSSFCell) row.createCell(colHdrIncrSt);
						cell.setCellValue(marketNameListLcl.get(j));
						cell.setCellStyle(headerStyle);
						cell = (XSSFCell) row.createCell(colHdrIncrEd);
						cell.setCellStyle(headerStyle);
						sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,colHdrIncrSt,colHdrIncrEd));
						cell.setCellStyle(headerStyle);
						colHdrIncrSt =colHdrIncrSt+2;
						colHdrIncrEd =colHdrIncrEd+2;
					}

				}
		
				row = (XSSFRow) sheet.createRow(++rowcount);
				
				int colHdrTypeIncr=5;
				for ( int j = 0 ;j < marketNameListLcl.size(); j++ ) {
					
					if(chapterFlagLcl){
						cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
						cell. setCellValue("Display Name Chapter");
						cell.setCellStyle(headerStyle);
						
						cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
						cell. setCellValue("MF Chapter");
						cell.setCellStyle(headerStyle);
	
						cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
						cell. setCellValue("Rev. Chapter");
						cell.setCellStyle(headerStyle);
				    }
					
					if(subtypeLcl){
						cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
						cell. setCellValue("Option Subtype");
						cell.setCellStyle(headerStyle);
					}
					
					if(defaultTypeLcl){
						cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
						cell. setCellValue("Default Selection");
						cell.setCellStyle(headerStyle);
					}

					if(sequenceNmLcl){
						cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
						cell. setCellValue("Sequence Number");
						cell.setCellStyle(headerStyle);
					}
					
					cell = (XSSFCell)row.createCell(colHdrTypeIncr++);
					cell. setCellValue("Available");
					cell.setCellStyle(headerStyle);
					
				}
				
				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellStyle(headerStyle);
				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellStyle(headerStyle);
				sheet.addMergedRegion(new CellRangeAddress(1,2,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_ZERO));
				cell.setCellStyle(headerStyle);
			
				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellStyle(headerStyle);
				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellStyle(headerStyle);
				sheet.addMergedRegion(new CellRangeAddress(1,2,PLMConstants.EXCEL_COL_ONE,PLMConstants.EXCEL_COL_ONE));
				cell.setCellStyle(headerStyle);

				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
				cell.setCellStyle(headerStyle);
				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
				cell.setCellStyle(headerStyle);
				sheet.addMergedRegion(new CellRangeAddress(1,2,PLMConstants.EXCEL_COL_TWO,PLMConstants.EXCEL_COL_TWO));
				cell.setCellStyle(headerStyle);

				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
				cell.setCellStyle(headerStyle);
				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
				cell.setCellStyle(headerStyle);
				sheet.addMergedRegion(new CellRangeAddress(1,2,PLMConstants.EXCEL_COL_THREE,PLMConstants.EXCEL_COL_THREE));
				cell.setCellStyle(headerStyle);
				
				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
				cell.setCellStyle(headerStyle);
				cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
				cell.setCellStyle(headerStyle);
				sheet.addMergedRegion(new CellRangeAddress(1,2,PLMConstants.EXCEL_COL_FOUR,PLMConstants.EXCEL_COL_FOUR));
				cell.setCellStyle(headerStyle);

				int colIncr=0;
				for (int i=0;i<cfQlCompareListLcl.size();i++) {
					
					colIncr=5;
					PLMCFQLCompareData	 dataObj = (PLMCFQLCompareData)cfQlCompareListLcl.get(i);
					
					row = (XSSFRow) sheet.createRow(++rowcount);
					
					if ("2".equalsIgnoreCase(dataObj.getLevel())) {
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellStyle(cellStyleCFRight);
						cell.setCellValue(dataObj.getLevel());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(cellStyleCFLeft);
						cell.setCellValue(dataObj.getDisplayNm());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellStyle(cellStyleCFLeft);
						cell.setCellValue(dataObj.getConfOption());
		
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
						cell.setCellStyle(cellStyleCF);
						cell.setCellValue(dataObj.getRev());
		
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
						cell.setCellStyle(cellStyleCFLeft);
						cell.setCellValue(dataObj.getPegasusCode());
		
						for ( int j = 0 ; j < dataObj.getTypeList().size(); j++ ) {
							
							if(chapterFlagLcl){
							cell = (XSSFCell) row.createCell(colIncr++);
							cell.setCellStyle(cellStyleCFLeft);
							cell.setCellValue(dataObj.getTypeList().get(j).getChDisplayNm());
		
							cell = (XSSFCell) row.createCell(colIncr++);
							cell.setCellStyle(cellStyleCFLeft);
							cell.setCellValue(dataObj.getTypeList().get(j).getMfChapter());
		
							cell = (XSSFCell) row.createCell(colIncr++);
							cell.setCellStyle(cellStyleCFLeft);
							cell.setCellValue(dataObj.getTypeList().get(j).getRevChapter());
							}
							
							if(subtypeLcl){
								cell = (XSSFCell) row.createCell(colIncr++);
								cell.setCellStyle(cellStyleCFLeft);
								cell.setCellValue(dataObj.getTypeList().get(j).getSubType());
							}
							
							if(defaultTypeLcl){
								cell = (XSSFCell) row.createCell(colIncr++);
								cell.setCellStyle(cellStyleCFLeft);
								cell.setCellValue(dataObj.getTypeList().get(j).getDefaultType());
							}
		
							if(sequenceNmLcl){
								cell = (XSSFCell) row.createCell(colIncr++);
								cell.setCellStyle(cellStyleCFRight);
								cell.setCellValue(dataObj.getTypeList().get(j).getSequenceNum());
							}
							
							cell = (XSSFCell) row.createCell(colIncr++);
							cell.setCellValue("");
			                if (dataObj.getTypeList().get(j).isAvailable()) {
			                	cell.setCellStyle(cellStyleGreen);
			                } else {
			                	cell.setCellStyle(cellStyleRed);
			                }
						}
					} else if ("3".equalsIgnoreCase(dataObj.getLevel())) {
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
						cell.setCellStyle(cellStyleRight);
						cell.setCellValue(dataObj.getLevel());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(cellStyleLeft);
						cell.setCellValue(dataObj.getDisplayNm());
						
						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellStyle(cellStyleLeft);
						cell.setCellValue(dataObj.getConfOption());

						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
						cell.setCellStyle(cellStyle);
						cell.setCellValue(dataObj.getRev());

						cell = (XSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
						cell.setCellStyle(cellStyleLeft);
						cell.setCellValue(dataObj.getPegasusCode());

						for ( int j = 0 ; j < dataObj.getTypeList().size(); j++ ) {
							
							if(chapterFlagLcl){
							cell = (XSSFCell) row.createCell(colIncr++);
							cell.setCellStyle(cellStyleLeft);
							cell.setCellValue(dataObj.getTypeList().get(j).getChDisplayNm());

							cell = (XSSFCell) row.createCell(colIncr++);
							cell.setCellStyle(cellStyleLeft);
							cell.setCellValue(dataObj.getTypeList().get(j).getMfChapter());

							cell = (XSSFCell) row.createCell(colIncr++);
							cell.setCellStyle(cellStyleLeft);
							cell.setCellValue(dataObj.getTypeList().get(j).getRevChapter());
							}
							
							if(subtypeLcl){
								cell = (XSSFCell) row.createCell(colIncr++);
								cell.setCellStyle(cellStyleLeft);
								cell.setCellValue(dataObj.getTypeList().get(j).getSubType());
							}
							
							if(defaultTypeLcl){
								cell = (XSSFCell) row.createCell(colIncr++);
								cell.setCellStyle(cellStyleLeft);
								cell.setCellValue(dataObj.getTypeList().get(j).getDefaultType());
							}

							if(sequenceNmLcl){
								cell = (XSSFCell) row.createCell(colIncr++);
								cell.setCellStyle(cellStyleRight);
								cell.setCellValue(dataObj.getTypeList().get(j).getSequenceNum());
							}
							
							cell = (XSSFCell) row.createCell(colIncr++);
							cell.setCellValue("");
			                if (dataObj.getTypeList().get(j).isAvailable()) {
			                	cell.setCellStyle(cellStyleGreen);
			                } else {
			                	cell.setCellStyle(cellStyleRed);
			                }
						}
					}
				}
								
				row = (XSSFRow) sheet.createRow(++rowcount);
				row = (XSSFRow) sheet.createRow(++rowcount);
				
			    XSSFCellStyle ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
			    ftrStyle.setFont(font);
			    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			    cell = (XSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
			    cell.setCellStyle(ftrStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_THREE));
				
				sheet.createFreezePane( 0, 3 );
				sheet.setColumnWidth(1, 8000);
				sheet.setColumnWidth(2, 4500);
				sheet.setColumnWidth(4, 4000);
				
				int colStart = 0;
				int colEnd = 0;
				
				if(chapterFlagLcl && sequenceNmLcl &&  subtypeLcl && defaultTypeLcl){
					colStart = 5;
					colEnd = 10;
					for ( int j = 0 ;j < marketNameListLcl.size(); j++ ) {
						sheet.groupColumn(colStart, colEnd);
						sheet.setColumnGroupCollapsed(colStart, false);
						colStart = colStart + 7;
						colEnd = colEnd + 7;
					}
				}else if((chapterFlagLcl) && ((!sequenceNmLcl &&  subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl))){
					colStart = 5;
					colEnd = 9;
					for ( int j = 0 ;j < marketNameListLcl.size(); j++ ) {
						sheet.groupColumn(colStart, colEnd);
						sheet.setColumnGroupCollapsed(colStart, false);
						colStart = colStart + 6;
						colEnd = colEnd + 6;
					}
				}else if((chapterFlagLcl) && ((sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl))){
					colStart = 5;
					colEnd = 8;
					for ( int j = 0 ;j < marketNameListLcl.size(); j++ ) {
						sheet.groupColumn(colStart, colEnd);
						sheet.setColumnGroupCollapsed(colStart, false);
						colStart = colStart + 5;
						colEnd = colEnd + 5;
					}
				}else if(chapterFlagLcl && !sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl){
					colStart = 5;
					colEnd = 7;
					for ( int j = 0 ;j < marketNameListLcl.size(); j++ ) {
						sheet.groupColumn(colStart, colEnd);
						sheet.setColumnGroupCollapsed(colStart, false);
						colStart = colStart + 4;
						colEnd = colEnd + 4;
					}
				}else if(!chapterFlagLcl && sequenceNmLcl &&  subtypeLcl && defaultTypeLcl){
					colStart = 5;
					colEnd = 7;
					for ( int j = 0 ;j < marketNameListLcl.size(); j++ ) {
						sheet.groupColumn(colStart, colEnd);
						sheet.setColumnGroupCollapsed(colStart, false);
						colStart = colStart + 4;
						colEnd = colEnd + 4;
					}
				}else if((!chapterFlagLcl) && ((!sequenceNmLcl &&  subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl) || (sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl))){
					colStart = 5;
					colEnd = 6;
					for ( int j = 0 ;j < marketNameListLcl.size(); j++ ) {
						sheet.groupColumn(colStart, colEnd);
						sheet.setColumnGroupCollapsed(colStart, false);
						colStart = colStart + 3;
						colEnd = colEnd + 3;
					}
				}else if((!chapterFlagLcl) && ((sequenceNmLcl &&  !subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  subtypeLcl && !defaultTypeLcl) || (!sequenceNmLcl &&  !subtypeLcl && defaultTypeLcl))){
					colStart = 5;
					colEnd = 5;
					for ( int j = 0 ;j < marketNameListLcl.size(); j++ ) {
						sheet.groupColumn(colStart, colEnd);
						sheet.setColumnGroupCollapsed(colStart, false);
						colStart = colStart + 2;
						colEnd = colEnd + 2;
					}
				}
				sheet.setZoom(85);
				workbook.write(fileOut);
				fileOut.close();
		  }	
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveCFQLCompareRptXLSFile: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveCFQLCompareRptXLSFile: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveCFQLCompareRptXLSFile: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveCFQLCompareRptXLSFile Method");
	}
	
	/**
	 * @param wb
	 * @param size
	 * @return
	 */
	private XSSFFont headerFont(XSSFWorkbook wb, int size){
		XSSFFont font = (XSSFFont) wb.createFont();
		font.setFontName(PLMConstants.EXCEL_FONT_NAME_CALIBRI);
		font.setFontHeightInPoints((short)size);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		return font;
	}
	
	/**
	 * @param wb
	 * @param size
	 * @return
	 */
	private XSSFFont normalFont(XSSFWorkbook wb, int size){
		XSSFFont font = (XSSFFont) wb.createFont();
		font.setFontName(PLMConstants.EXCEL_FONT_NAME_CALIBRI);
		font.setFontHeightInPoints((short)size);
		return font;
	}
	
	/**
	 * @param wb
	 * @param font
	 * @param bgcolor
	 * @param wrap
	 * @return
	 */
	private XSSFCellStyle headerCell(XSSFWorkbook wb, XSSFFont font, short bgcolor, boolean wrap){
		XSSFCellStyle hCell = normalCell(wb, font, XSSFCellStyle.SOLID_FOREGROUND, wrap);
		//FONT
		hCell.setFont(font);
		//WRAP TEXT
		hCell.setWrapText(wrap);
		
		//HORIZONTAL ALIGNMENT
		hCell.setAlignment(XSSFCellStyle.ALIGN_CENTER);
		
		//COLOR
		hCell.setFillForegroundColor(bgcolor);
		return hCell;
	}
	
	/**
	 * @param wb
	 * @param font
	 * @param bgcolor
	 * @param wrap
	 * @return
	 */
	private XSSFCellStyle dateStyleheaderCell(XSSFWorkbook wb, XSSFFont font, short bgcolor, boolean wrap){
		XSSFCellStyle hCell = normalCellLeft(wb, font, XSSFCellStyle.NO_FILL, wrap);
		//FONT
		hCell.setFont(font);
		
		//HORIZONTAL ALIGNMENT
		hCell.setAlignment(XSSFCellStyle.ALIGN_LEFT);
		
		//COLOR
		//hCell.setFillForegroundColor(bgcolor);
		return hCell;
	}
	
	/**
	 * @param wb
	 * @param font
	 * @param fillPattern
	 * @param wrap
	 * @return
	 */
	private XSSFCellStyle normalCell(XSSFWorkbook wb, XSSFFont font, short fillPattern, boolean wrap){
		// Cell Style
		XSSFCellStyle cellStyle = (XSSFCellStyle)wb.createCellStyle();
		
		//Set Font
		cellStyle.setFont(font);
		//WRAP TEXT
		//cellStyle.setWrapText(wrap);
		
		//VERTICAL ALIGNMENT
		cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
		
		//BORDERS
		cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		
		//FILL PATTERN
		cellStyle.setFillPattern(fillPattern);
		return cellStyle;
	}
	/**
	 * @param wb
	 * @param font
	 * @param fillPattern
	 * @param wrap
	 * @return
	 */
	private XSSFCellStyle normalCellLeft(XSSFWorkbook wb, XSSFFont font, short fillPattern, boolean wrap){
		// Cell Style
		XSSFCellStyle cellStyle = (XSSFCellStyle)wb.createCellStyle();
		
		//Set Font
		cellStyle.setFont(font);
		//WRAP TEXT
		//cellStyle.setWrapText(wrap);
		
		//VERTICAL ALIGNMENT
		cellStyle.setAlignment(XSSFCellStyle.ALIGN_LEFT);
		
		//BORDERS
		cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		
		//FILL PATTERN
		cellStyle.setFillPattern(fillPattern);
		return cellStyle;
	}
	
	/**
	 * @param wb
	 * @param font
	 * @param fillPattern
	 * @param wrap
	 * @return
	 */
	private XSSFCellStyle normalCellRight(XSSFWorkbook wb, XSSFFont font, short fillPattern, boolean wrap){
		// Cell Style
		XSSFCellStyle cellStyle = (XSSFCellStyle)wb.createCellStyle();
		
		//Set Font
		cellStyle.setFont(font);
		//WRAP TEXT
		//cellStyle.setWrapText(wrap);
		
		//VERTICAL ALIGNMENT
		cellStyle.setAlignment(XSSFCellStyle.ALIGN_RIGHT);
		
		//BORDERS
		cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		
		//FILL PATTERN
		cellStyle.setFillPattern(fillPattern);
		return cellStyle;
	}
	
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}


	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor
	 *            the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}
	/**
	 * @return the userDetails
	 */
	public PLMPwiUserData getUserDetails() {
		return userDetails;
	}
	/**
	 * @param userDetails the userDetails to set
	 */
	public void setUserDetails(PLMPwiUserData userDetails) {
		this.userDetails = userDetails;
	}
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}
	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}
	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}
	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return
	 */
	public String getSelProduct() {
		return selProduct;
	}

	/**
	 * @param selProduct
	 */
	public void setSelProduct(String selProduct) {
		this.selProduct = selProduct;
	}

	/**
	 * @return
	 */
	public List<SelectItem> getProductNamesLst() {
		return productNamesLst;
	}

	/**
	 * @param productNamesLst
	 */
	public void setProductNamesLst(List<SelectItem> productNamesLst) {
		this.productNamesLst = productNamesLst;
	}

	/**
	 * @return
	 */
	public boolean isProdManagementFlag() {
		return prodManagementFlag;
	}

	/**
	 * @param prodManagementFlag
	 */
	public void setProdManagementFlag(boolean prodManagementFlag) {
		this.prodManagementFlag = prodManagementFlag;
	}

	/**
	 * @return
	 */
	public boolean isPreliminaryFlag() {
		return preliminaryFlag;
	}

	/**
	 * @param preliminaryFlag
	 */
	public void setPreliminaryFlag(boolean preliminaryFlag) {
		this.preliminaryFlag = preliminaryFlag;
	}

	/**
	 * @return
	 */
	public PLMMktModelRptServiceIfc getPlmMktModelRptService() {
		return plmMktModelRptService;
	}

	/**
	 * @param plmMktModelRptService
	 */
	public void setPlmMktModelRptService(
			PLMMktModelRptServiceIfc plmMktModelRptService) {
		this.plmMktModelRptService = plmMktModelRptService;
	}

	/**
	 * @return
	 */
	public int getTotalModelsAndHwPrdtsCnt() {
		return totalModelsAndHwPrdtsCnt;
	}

	/**
	 * @param totalModelsAndHwPrdtsCnt
	 */
	public void setTotalModelsAndHwPrdtsCnt(int totalModelsAndHwPrdtsCnt) {
		this.totalModelsAndHwPrdtsCnt = totalModelsAndHwPrdtsCnt;
	}

	/**
	 * @return
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @param recordCounts
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}

	/**
	 * @return
	 */
	public List<SelectItem> getProductLinesLst() {
		return productLinesLst;
	}

	/**
	 * @param productLinesLst
	 */
	public void setProductLinesLst(List<SelectItem> productLinesLst) {
		this.productLinesLst = productLinesLst;
	}

	/**
	 * @return
	 */
	public List<String> getSelProductLines() {
		return selProductLines;
	}

	/**
	 * @param selProductLines
	 */
	public void setSelProductLines(List<String> selProductLines) {
		this.selProductLines = selProductLines;
	}

	/**
	 * @return
	 */
	public List<PLMMktModelRptData> getModelsAndHwPrdtsLst() {
		return modelsAndHwPrdtsLst;
	}

	/**
	 * @param modelsAndHwPrdtsLst
	 */
	public void setModelsAndHwPrdtsLst(List<PLMMktModelRptData> modelsAndHwPrdtsLst) {
		this.modelsAndHwPrdtsLst = modelsAndHwPrdtsLst;
	}

	/**
	 * @return
	 */
	public String getSelHardwareProduct() {
		return selHardwareProduct;
	}

	/**
	 * @param selHardwareProduct
	 */
	public void setSelHardwareProduct(String selHardwareProduct) {
		this.selHardwareProduct = selHardwareProduct;
	}

	/**
	 * @return
	 */
	public PLMCFQLCompareServiceIfc getPlmCFQLCompareService() {
		return plmCFQLCompareService;
	}

	/**
	 * @param plmCFQLCompareService
	 */
	public void setPlmCFQLCompareService(
			PLMCFQLCompareServiceIfc plmCFQLCompareService) {
		this.plmCFQLCompareService = plmCFQLCompareService;
	}

	/**
	 * @return
	 */
	public List<PLMCFQLCompareData> getBulkHwPRdListFinal() {
		return bulkHwPRdListFinal;
	}

	/**
	 * @param bulkHwPRdListFinal
	 */
	public void setBulkHwPRdListFinal(List<PLMCFQLCompareData> bulkHwPRdListFinal) {
		this.bulkHwPRdListFinal = bulkHwPRdListFinal;
	}

	/**
	 * @return
	 */
	public boolean isCompareFlag() {
		return compareFlag;
	}

	/**
	 * @param compareFlag
	 */
	public void setCompareFlag(boolean compareFlag) {
		this.compareFlag = compareFlag;
	}

	/**
	 * @return
	 */
	public boolean isNocompareFlag() {
		return nocompareFlag;
	}

	/**
	 * @param nocompareFlag
	 */
	public void setNocompareFlag(boolean nocompareFlag) {
		this.nocompareFlag = nocompareFlag;
	}
}