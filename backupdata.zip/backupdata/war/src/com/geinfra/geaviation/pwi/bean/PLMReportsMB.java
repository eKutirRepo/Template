/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMReportsMB.java
 * @Creation date: 17-Jul-2009
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.validator.ValidatorException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.data.PLMReportData;
import com.geinfra.geaviation.pwi.service.PLMAdminServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;


/**
 * ICMReportsMB is the managed bean class used for ICM Reports.
 */
public class PLMReportsMB extends BaseBean{
	/**
	 * Holds the Logger.
	 */
	private static final Logger LOG = Logger.getLogger(PLMReportsMB.class);

	/**
	 * The List systemLogsList
	 */
	private List<PLMReportData> systemLogsList;
	/**
	 * The String beginDate
	 */
	private String beginDate;
	/**
	 * The String endDate
	 */
	private String endDate;
	/**
	 * The String message
	 */
	private String message;
	/**
	 * The String startDate
	 */
	private Date startDate;
	/**
	 * The String endingDate
	 */
	private Date endingDate;
	/**
	 * The String excelFlag
	 */
	private String excelFlag;
	/**
	 * The boolean renderingMsg
	 */
	private boolean renderingMsg;
	/**
	 * The String recordsMsg
	 */
	private String recordsMsg;
	/**
	 * The String validationMsg
	 */
	private String validationMsg;
	/**
	 * The String queryingFlag
	 */
	private String queryingFlag;
	/**
	 * The String strReturn
	 */
	private String strReturn;
	
	/**
	 * Service Handler for ICMAdminServiceIfc
	 */
	public PLMAdminServiceIfc adminServiceIfc;
	/**
	 * Holds the recordCount
	 */
	private int recordCount = PLMConstants.N_100;

	/**
	 * The constructor
	 */
	public PLMReportsMB() {
		super();
	}
	
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	
	/**
	 * This method is used to Validate Date Inputs
	 * @param cont
	 * @param ucom
	 * @param ob
	 * @throws PLMCommonException
	 */
	public void validateDate(FacesContext cont, UIComponent ucom, Object ob) throws ValidatorException {
        try {
        	Date dateVal = (Date) ob;
        	LOG.info("validated date.."+dateVal);
        } catch (Exception ex) {
        	LOG.log(Level.ERROR, "validateDate method error", ex);
            FacesMessage message1 = new FacesMessage("Invalid date");
            throw new ValidatorException(message1);
        }
    }
	
	public String loadSysLogPage() {
		String strReturnLcl = "adminsyslogs";
		if (!PLMUtils.isEmptyList(systemLogsList)) {
			systemLogsList.clear();
		}
		validationMsg = null;
		startDate = null;
		endingDate = null;
		renderingMsg = false;
		excelFlag = null;
		recordsMsg = "";
		return strReturnLcl;
	}

	/**
	 * This method is used for getSysLogContents
	 * 
	 * return String
	 */
	public String getSysLogContents() {
		try {
			if (queryingFlag != null
					&& queryingFlag.equals(PLMConstants.QUERYING_FLAG)) {
				LOG.info("Entered into validation loop");
				validationMsg = checkForDates(startDate, endingDate);
				handleFacesError(validationMsg);
				renderingMsg = false;
				recordsMsg = "";
			} else {
				validationMsg = null;
			}
			if (validationMsg != null && validationMsg.equals("")) {
				if (startDate != null && endingDate != null) {
					beginDate = startDate.toString();
					endDate = endingDate.toString();

					Locale loc = Locale.US;
					SimpleDateFormat requiredFrmt = new SimpleDateFormat(
							(PLMConstants.DATE_FORMAT), loc);
					beginDate = requiredFrmt.format(startDate);
					endDate = requiredFrmt.format(endingDate);
					LOG
							.info("Dates in String format >>>" + beginDate
									+ endDate);
				}

				systemLogsList = adminServiceIfc.getSysLogContents(beginDate,
						endDate);
				if (systemLogsList != null && !systemLogsList.isEmpty()) {
					recordsMsg = "";
					renderingMsg = true;
					validationMsg = null;
					recordCount = PLMConstants.N_100;
					LOG.info("systemLogsList size "+systemLogsList.size());
				} else {
					renderingMsg = false;
					LOG.info("No more Record Exist for selected criteria");
					recordsMsg = PLMConstants.NO_REC_MSG_SYS_LOG;
					setRecordsMsg(recordsMsg);
					handleFacesError(recordsMsg);
				}
			}
			if (excelFlag != null
					&& excelFlag.equalsIgnoreCase(PLMConstants.EXCEL_FLAG)) {
				strReturn = "SysLogsExportExcel";
			} else {
				strReturn = "adminsyslogs";
			}

		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getSysLogContents: ", exception);
			strReturn = PLMUtils.setCommonException(exception.getMessage(),commonMB,"adminsyslogs","System Logs");
		} 
		return strReturn;
	}

	/**
	 * This method is used for getQueryFlag
	 * 
	 * @param event
	 */
	public void getQueryFlag(ActionEvent event) {
		queryingFlag = (String) event.getComponent().getAttributes().get(
				PLMConstants.QUERY_FLAG);
		excelFlag = null;
	}

	/**
	 * This method is used for messageNull
	 * 
	 * @param event
	 */
	public void messageNull(ActionEvent event) {
		queryingFlag = null;
		startDate = null;
		endingDate = null;
		beginDate = null;
		endDate = null;
		excelFlag = null;
		renderingMsg = false;
		systemLogsList = null;
		recordsMsg = null;
	}

	/**
	 * This method is used for checkForDates
	 * 
	 * return String
	 * 
	 * @param stDate
	 * @param edDate
	 */
	private String checkForDates(Date stDate, Date edDate) {
		StringBuffer strBuffer = new StringBuffer("");
		Calendar cal = Calendar.getInstance();
		Date currentDate = cal.getTime();
		LOG.info("currentDate is >>>>" + currentDate);
		LOG.info("stDate is >>>>" + stDate);
		LOG.info("edDate is >>>>" + edDate);
		if (stDate == null && edDate == null) {
			strBuffer.append((PLMConstants.STREND_DATE) + "\n");
		} else {
			if (stDate == null) {
				strBuffer.append((PLMConstants.STR_DATE) + "\n");
			}
			if (edDate == null) {
				strBuffer.append((PLMConstants.END_DATE) + "\n");
			}
			if (stDate != null && edDate != null) {
				if (currentDate.compareTo(stDate) == PLMConstants.N_NEG_1) {
					strBuffer.append((PLMConstants.START_FUTURE_DATE)
							+ "\n");
				}
				if (currentDate.compareTo(edDate) == PLMConstants.N_NEG_1) {
					strBuffer.append((PLMConstants.END_FUTURE_DATE)
							+ "\n");
				}
				if (currentDate.compareTo(stDate) != PLMConstants.N_NEG_1
						&& currentDate.compareTo(edDate) != PLMConstants.N_NEG_1) {
					if (edDate.compareTo(stDate) == PLMConstants.N_NEG_1) {
						strBuffer.append((PLMConstants.START_END)
								+ "\n");
					}
				}

			}
		}
		return strBuffer.toString();
	}

	/**
	 * This method is used to download an Excel File
	 * 
	 *
	 */
	public void downloadSyslogExcel() throws PLMCommonException {
		LOG.info("Entering downloadSyslogExcel Method");
		String reportName = "System log Report";
		String fileName = "System log Report";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		 
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		//Export to Excel for System logs
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					  new PLMXlsxRptColumn("logDate", "Date", FormatType.TEXT, null, null, 28),
					  new PLMXlsxRptColumn("userSsoId", "Single Sign On ID ", FormatType.TEXT, null, null, 18),
					  new PLMXlsxRptColumn("userName", "User Name", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("logEvent", "Event", FormatType.TEXT, null, null,35)
			};
			
			excelUtil.export(systemLogsList, reportColumns, fileName, fileName, false, null, null);	
			LOG.info("Exiting downloadSyslogExcel Method");
	} 	
	/**
	 * This method for assignValues
	 * 
	 * @param event
	 */
	public void recordsPerPageListner(ActionEvent event) {
		LOG.info("Entering recordsPerPageListner method");
		LOG.info("Action listner called.....--------------------------->"
				+ recordCount);
		if (recordCount == PLMConstants.N_100) {
			LOG.info("100");
			recordCount = PLMConstants.N_100;
		} else if (recordCount == PLMConstants.N_200) {
			LOG.info("200");
			recordCount = PLMConstants.N_200;
		} else if (recordCount == PLMConstants.N_500) {
			LOG.info("500");
			recordCount = PLMConstants.N_500;
		}
		LOG.info("final value.....--------------------------->" + recordCount);
	}
	
	/**
	 * This method is used for getExcelFlag
	 * 
	 * @param event
	 */
	public void getExcelFlag(ActionEvent event) {
		excelFlag = (String) event.getComponent().getAttributes().get(
				PLMConstants.EXPT_EXCEL);
	}

	/**
	 * @return Returns the systemLogsList.
	 */
	public List<PLMReportData> getSystemLogsList() {
		return systemLogsList;
	}

	/**
	 * @param listSystemLogsList
	 *            The systemLogsList to set.
	 */
	public void setSystemLogsList(List<PLMReportData> listSystemLogsList) {
		this.systemLogsList = listSystemLogsList;
	}

	/**
	 * @return Returns the beginDate.
	 */
	public String getBeginDate() {
		return beginDate;
	}

	/**
	 * @param strBeginDate
	 *            The beginDate to set.
	 */
	public void setBeginDate(String strBeginDate) {
		this.beginDate = strBeginDate;
	}

	/**
	 * @return Returns the endDate.
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @param strEndDate
	 *            The endDate to set.
	 */
	public void setEndDate(String strEndDate) {
		this.endDate = strEndDate;
	}

	/**
	 * @return Returns the message.
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param strMessage
	 *            The message to set.
	 */
	public void setMessage(String strMessage) {
		this.message = strMessage;
	}

	/**
	 * @return Returns the endingDate.
	 */
	public Date getEndingDate() {
		Date temp = null;
		temp = endingDate;
		return temp;
	}

	/**
	 * @param dtEndingDate
	 *            The endingDate to set.
	 */
	public void setEndingDate(Date dtEndingDate) {
		Date temp1 = null;
		temp1 = dtEndingDate;
		this.endingDate = temp1;
	}

	/**
	 * @return Returns the startDate.
	 */
	public Date getStartDate() {
		Date temp = null;
		temp = startDate;
		return temp;
	}

	/**
	 * @param dtStartDate
	 *            The startDate to set.
	 */
	public void setStartDate(Date dtStartDate) {
		Date temp1 = null;
		temp1 = dtStartDate;
		this.startDate = temp1;
	}

	/**
	 * @return Returns the recordsMsg.
	 */
	public String getRecordsMsg() {
		return recordsMsg;
	}

	/**
	 * @param strRecordsMsg
	 *            The recordsMsg to set.
	 */
	public void setRecordsMsg(String strRecordsMsg) {
		this.recordsMsg = strRecordsMsg;
	}

	/**
	 * @return Returns the renderingMsg.
	 */
	public boolean isRenderingMsg() {
		return renderingMsg;
	}

	/**
	 * @param blRenderingMsg
	 *            The renderingMsg to set.
	 */
	public void setRenderingMsg(boolean blRenderingMsg) {
		this.renderingMsg = blRenderingMsg;
	}

	/**
	 * @return Returns the validationMsg.
	 */
	public String getValidationMsg() {
		return validationMsg;
	}

	/**
	 * @param strValidationMsg
	 *            The validationMsg to set.
	 */
	public void setValidationMsg(String strValidationMsg) {
		this.validationMsg = strValidationMsg;
	}
	/**
	 * @return adminServiceIfc
	 */
	public PLMAdminServiceIfc getAdminServiceIfc() {
		return adminServiceIfc;
	}

	/**
	 * @param adminServiceIfc
	 */
	public void setAdminServiceIfc(PLMAdminServiceIfc objAdminServiceIfc) {
		this.adminServiceIfc = objAdminServiceIfc;
	}
	
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the recordCount
	 */
	public int getRecordCount() {
		return recordCount;
	}

	/**
	 * @param recordCount the recordCount to set
	 */
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
	
}
