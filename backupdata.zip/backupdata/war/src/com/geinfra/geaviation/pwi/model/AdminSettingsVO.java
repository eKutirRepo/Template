/**
 * Project        :   Product Lifecycle Management 
 * Date Written   :   ${date} 
 * Security       :   GE Confidential 
 * Restrictions   :   GE PROPRIETARY INFORMATION, FOR GE USE ONLY 
 * 
 * Copyright(C) ${year} GE 
 * All rights reserved 
 * 
 * Description    :  AdminSettingsVO 
 * 
 * Revision Log May 20, 2010 | v1.0. 
 * -------------------------------------------------------------- 

 */

package com.geinfra.geaviation.pwi.model;

import com.geinfra.geaviation.pwi.common.model.BaseVO;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : AdminSettingsVO - Object representing Admin Settings text.
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class AdminSettingsVO extends BaseVO {
	private String settingsText;
	private String appSeqId;
	private String appPrmNm;
	private String appParVal;
	private String crtrSsoid;
	private String appparmdttm;

	/**
	 * @return the settingsText
	 */
	public String getSettingsText() {
		return settingsText;
	}

	/**
	 * @param settingsText
	 *            the settingsText to set
	 */
	public void setSettingsText(String settingsText) {
		this.settingsText = settingsText;
	}

	/**
	 * @return the appSeqId
	 */
	public String getAppSeqId() {
		return appSeqId;
	}

	/**
	 * @param appSeqId
	 *            the appSeqId to set
	 */
	public void setAppSeqId(String appSeqId) {
		this.appSeqId = appSeqId;
	}

	/**
	 * @return the appPrmNm
	 */
	public String getAppPrmNm() {
		return appPrmNm;
	}

	/**
	 * @param appPrmNm
	 *            the appPrmNm to set
	 */
	public void setAppPrmNm(String appPrmNm) {
		this.appPrmNm = appPrmNm;
	}

	/**
	 * @return the appParVal
	 */
	public String getAppParVal() {
		return appParVal;
	}

	/**
	 * @param appParVal
	 *            the appParVal to set
	 */
	public void setAppParVal(String appParVal) {
		this.appParVal = appParVal;
	}

	/**
	 * @return the crtrssoid
	 */
	public String getCrtrSsoid() {
		return crtrSsoid;
	}

	/**
	 * @param crtrSsoid 
	 *            the crtrssoid to set
	 */
	public void setCrtrSsoid(String crtrSsoid) {
		this.crtrSsoid = crtrSsoid;
	}

	/**
	 * @return the appparmdttm
	 */
	public String getAppparmdttm() {
		return appparmdttm;
	}

	/**
	 * @param appparmdttm
	 *            the appparmdttm to set
	 */
	public void setAppparmdttm(String appparmdttm) {
		this.appparmdttm = appparmdttm;
	}
}
