/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMEcrSearchMB.java
 * @Creation date: 18-June-2010
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.bean;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.common.usermodel.Hyperlink;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFCreationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFHyperlink;

import com.geinfra.geaviation.pwi.data.PLMEcrSearchData;
import com.geinfra.geaviation.pwi.service.PLMkpiReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

/**
 * PLMIssuesReportMB is the managed bean class .
 */
public class PLMEcrSearchMB {

	private static final Logger LOG = Logger.getLogger(PLMEcrSearchMB.class);

	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB = null;

	/**
	 * Holds the plmKpiReportService
	 */
	private PLMkpiReportServiceIfc plmKpiReportService = null;
	/**
	 * Holds the ecrSearchResultList
	 */
	private List<PLMEcrSearchData> ecrSearchResultList;
	/**
	 * Holds the ecrSearchResultDetailList
	 */
	private List<PLMEcrSearchData> ecrSearchResultDetailList;
	/**
	 * Holds the ecrSearchDetails
	 */
	private PLMEcrSearchData ecrSearchDetails = new PLMEcrSearchData();
	/**
	 * Holds the dropdownlist
	 */
	private Map<String, List<SelectItem>> dropdownlist = null;

	/**
	 * Holds the ecrAffectedItemList
	 */
	private List<PLMEcrSearchData> ecrAffectedItemList;
	/**
	 * Holds the count
	 */
	private int count;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;
	/**
	 * Holds the recordCounts
	 */
	private int detailRecordCounts = PLMConstants.N_100;
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the totalRecCount
	 */
	private int totalDetailRecCount;
	/**
	 * Holds the totalRecCountMsg
	 */
	private String totalRecCountMsg;
	/**
	 * Holds the totalDetailRecCountMsg
	 */
	private String totalDetailRecCountMsg;
	/**
	 * Holds the totalDetailRecCountMsg
	 */
	private int totalAffctCount;
	private String totalAffctCountMsg;
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the selectedecrs
	 */
	private String selectedecrs = "";
	/**
	 * Holds the catListDatas
	 */
	private List<SelectItem> catListData;
	/**
	 * Holds the sevListData
	 */
	private List<SelectItem> sevListData;
	/**
	 * Holds the stateListData
	 */
	private List<SelectItem> stateListData = new ArrayList<SelectItem>();
	/**
	 * Holds the ecrsessionvalue
	 */
	private String ecrsessionvalue;

	private String reportName;

	/**
	 * Holds the partNameList
	 */
	private List<String> partNameList = new ArrayList<String>();
	/**
	 * Holds the resourceBundle
	 */
	
	private List<PLMEcrSearchData> partsToBeConsider = new ArrayList<PLMEcrSearchData>();
	
	private ResourceBundle resourceBundle = ResourceBundle
			.getBundle("com.geinfra.geaviation.pwi.resources.Reports");

	/**
	 * This method is used for getEcrSearchData
	 * 
	 * @return String
	 */
	public String getEcrSearchData() {
		String fwdFlag = "";
		totalRecCount = 0;
		LOG.info("plmEcrSearchService...." + plmKpiReportService);
		Date fromecrStrtDate = ecrSearchDetails.getFromecrStrtDate();
		Date toecrEndDate = ecrSearchDetails.getToecrEndDate();

		if (ecrSearchDetails.isAllOpen()) {
			if (!PLMUtils.isEmptyList(stateListData)) {
				List<String> allOpenStateList = new ArrayList<String>();
				for (int i = 0; i < stateListData.size(); i++) {
					String stateValue = stateListData.get(i).getLabel();
					if (!stateValue.equals("Complete")) {
						allOpenStateList.add(stateValue);
					}
				}
				ecrSearchDetails.setEcrStateList(allOpenStateList);
			}
		}

		if (PLMUtils.isEmpty(ecrSearchDetails.getEcrName())
				&& PLMUtils.isEmpty(ecrSearchDetails.getEcrOwner())
				&& PLMUtils.isEmpty(ecrSearchDetails.getEcrOriginator())
				&& PLMUtils.isEmptyList(ecrSearchDetails.getEcrCategChngList())
				&& PLMUtils.isEmptyList(ecrSearchDetails.getEcrSevList())
				&& PLMUtils.isEmptyList(ecrSearchDetails.getEcrStateList())
				&& PLMUtils.isEmptyDate(fromecrStrtDate)
				&& PLMUtils.isEmptyDate(toecrEndDate)
				&& PLMUtils.isEmpty(ecrSearchDetails.getCcbchair())
				&& PLMUtils.isEmpty(ecrSearchDetails.getResdesigneng())) {
			alertMessage = PLMConstants.ANY_SRCH_CRIT;
		} else {
			String ownerWithOutAsterisk = null;
			String originatorWithOutAsterisk = null;
			String respDesignEngrWithOutAsterisk = null;

			if (!PLMUtils.isEmpty(ecrSearchDetails.getEcrOwner())) {
				ownerWithOutAsterisk = PLMUtils
						.removeAsteriskAndSpaceFromSSOFields(ecrSearchDetails
								.getEcrOwner());
			}
			if (!PLMUtils.isEmpty(ecrSearchDetails.getEcrOriginator())) {
				originatorWithOutAsterisk = PLMUtils
						.removeAsteriskAndSpaceFromSSOFields(ecrSearchDetails
								.getEcrOriginator());
			}
			if (!PLMUtils.isEmpty(ecrSearchDetails.getResdesigneng())) {
				respDesignEngrWithOutAsterisk = PLMUtils
						.removeAsteriskAndSpaceFromSSOFields(ecrSearchDetails
								.getResdesigneng());
			}

			if (!PLMUtils.checkForSpecialChars(ecrSearchDetails.getEcrName())) {
				alertMessage = alertMessage + PLMConstants.EcrName_ValMsg;
				fwdFlag = "ecrsearch";
			}
			if (!PLMUtils.checkForSpecialChars(ecrSearchDetails.getEcrOwner())) {
				alertMessage = alertMessage + PLMConstants.EcrOwner_ValMsg;
				fwdFlag = "ecrsearch";
			} else if (PLMUtils.isInteger(ownerWithOutAsterisk)) {
				if (ownerWithOutAsterisk.length() != 9)
					alertMessage = alertMessage
							+ PLMConstants.EcrOwnerdigt_ValMsg;
				fwdFlag = "ecrsearch";
			}
			if (!PLMUtils.checkForSpecialChars(ecrSearchDetails
					.getEcrOriginator())) {
				alertMessage = alertMessage + PLMConstants.EcrOriginator_ValMsg;
				fwdFlag = "ecrsearch";
			} else if (PLMUtils.isInteger(originatorWithOutAsterisk)) {
				if (originatorWithOutAsterisk.length() != 9)
					alertMessage = alertMessage
							+ PLMConstants.EcrOriginatordigt_ValMsg;
				fwdFlag = "ecrsearch";
			}

			if (!PLMUtils.checkForSpecialChars(ecrSearchDetails.getCcbchair())) {
				alertMessage = alertMessage + PLMConstants.EcrCcbchair_ValMsg;
				fwdFlag = "ecrsearch";
			} else {
				String ccbChairs = ecrSearchDetails.getCcbchair();
				StringTokenizer tokens = new StringTokenizer(ccbChairs, ",");
				boolean validCcbChair = true;

				while (tokens.hasMoreTokens()) {
					String ccbChair = tokens.nextToken();
					String ccbChairWithOutAsterisk = PLMUtils
							.removeAsteriskAndSpaceFromSSOFields(ccbChair);
					if (PLMUtils.isInteger(ccbChairWithOutAsterisk)) {
						if (ccbChairWithOutAsterisk.length() != 9) {
							validCcbChair = false;
						}
					}
				}
				if (!validCcbChair) {
					alertMessage = alertMessage
							+ PLMConstants.EcrCcbchairdigt_ValMsg;
					fwdFlag = "ecrsearch";
				}
			}
			if (!PLMUtils.checkForSpecialChars(ecrSearchDetails
					.getResdesigneng())) {
				alertMessage = alertMessage
						+ PLMConstants.EcrResdesigneng_ValMsg;
				fwdFlag = "ecrsearch";
			} else if (PLMUtils.isInteger(respDesignEngrWithOutAsterisk)) {
				if (respDesignEngrWithOutAsterisk.length() != 9)
					alertMessage = alertMessage
							+ PLMConstants.EcrResdesignengdigt_ValMsg;
				fwdFlag = "ecrsearch";
			}
			if (PLMUtils.checkForNullOfTwoDates(fromecrStrtDate, toecrEndDate)) {
				alertMessage = alertMessage + PLMConstants.Dates_NullCheck_Msg;
			} else if (PLMUtils.checkForFromAndToDate(fromecrStrtDate,
					toecrEndDate)) {
				alertMessage = alertMessage + PLMConstants.Date_ValMsg;
				fwdFlag = "ecrsearch";
			}
		}
		if (PLMUtils.isEmpty(alertMessage)) {
			try {
				ecrSearchResultList = plmKpiReportService
						.getEcrSearchData(ecrSearchDetails);
				if (ecrSearchResultList != null) {
					totalRecCount = ecrSearchResultList.size();
				} else {
					totalRecCount = 0;
				}
				totalRecCountMsg = "Total Results Count : " + totalRecCount;
				LOG.info("totalRecCount::::::::::::::::::" + totalRecCount);
				if (totalRecCount == 0) {
					fwdFlag = "invalidEcr";
				} else {
					recordCounts = PLMConstants.N_100;
					reportName = "ecrHdrReport";
					fwdFlag = "ecrSearchResult";
				}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getEcrSearchData: ", exception);
				fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
						commonMB, "ecrsearch", "ECR Search");
			}
		}
		return fwdFlag;
	}

	/**
	 * This method is used for getEcrDetailedReport
	 * 
	 * @return String
	 */
	public String getEcrDetailedReport() {
		String fwdFlag = "";
		try {
			ecrSearchResultDetailList = plmKpiReportService
					.getecrNameBySelection(ecrsessionvalue);
			if (ecrSearchResultDetailList != null) {
				totalDetailRecCount = ecrSearchResultDetailList.size();
			} else {
				totalDetailRecCount = 0;
			}
			totalDetailRecCountMsg = "Total Results Count : "
					+ totalDetailRecCount;
			LOG.info("totalDetailRecCount::::::::::::::::::"
					+ totalDetailRecCount);
			if (totalDetailRecCount == 0) {
				fwdFlag = "invalidEcr";
			} else {
				detailRecordCounts = PLMConstants.N_100;
				reportName = "ecrDetailReport";
				fwdFlag = "ecrdetails";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getEcrDetailedReport: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "ecrSearchResult", "ECR Search");
		}
		return fwdFlag;
	}

	/**
	 * This method is used for getecrNameBySelection
	 * 
	 * @return String
	 */
	public String getecrNameBySelection() {
		String fwdFlag = "";
		if (selectedecrs.equalsIgnoreCase("null")) {
			fwdFlag = "";
		} else {
			try {
				ecrSearchResultDetailList = plmKpiReportService
						.getecrNameBySelection(selectedecrs);
				if (ecrSearchResultDetailList != null) {
					totalDetailRecCount = ecrSearchResultDetailList.size();
				} else {
					totalDetailRecCount = 0;
				}
				totalDetailRecCountMsg = "Total Results Detail Count : "
						+ totalDetailRecCount;
				LOG.info("totalDetailRecCount::::::::::::::::::"
						+ totalDetailRecCount);
				if (totalDetailRecCount == 0) {

					fwdFlag = "invalidEcr";
				} else {
					detailRecordCounts = PLMConstants.N_100;
					reportName = "ecrDetailReport";
					fwdFlag = "ecrdetails";
				}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getecrNameBySelection: ",
						exception);
				fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
						commonMB, "ecrSearchResult", "ECR Search");
			}
		}
		return fwdFlag;
	}

	/**
	 * This method is used for ECR Affected Items
	 * 
	 * @return String
	 */
	public String getEcrAffectedItems() {
		String fwdFlagAff = "";
		if (selectedecrs.equalsIgnoreCase("null")) {
			fwdFlagAff = "";
			partNameList = new ArrayList<String>();
		} else {
			try {
				List<String> uniquePartNames = new ArrayList<String>();
				List<String> uniquePartNamesForECR = new ArrayList<String>();
				List<PLMEcrSearchData> partsToBeConsiderd = new ArrayList<PLMEcrSearchData>();
				ecrSearchDetails.setSelEcrName(selectedecrs);
				ecrAffectedItemList = plmKpiReportService
						.getEcrAffectedItems(selectedecrs);
				
				uniquePartNamesForECR = plmKpiReportService.getUniquePartNamesForECR(selectedecrs);
				
				if (ecrAffectedItemList != null) {
					totalAffctCount = ecrAffectedItemList.size();
					// Get Unique List of Part Names under To be Added Due to
					// Forced Part Revision= Yes column
					for (PLMEcrSearchData data : ecrAffectedItemList) {
						if (!PLMUtils.isEmpty(data.getAffectedforceRev())
								&& !uniquePartNames.contains(data
										.getAffectedforceRev())) {
							uniquePartNames.add(data.getAffectedforceRev());
						}
					}
/*
					for (int i = 0; i < ecrAffectedItemList.size(); i++) {
						int lvl = Integer.parseInt(ecrAffectedItemList.get(i)
								.getEcrLevel());
						if (lvl == 1
								&& ("Part".equalsIgnoreCase(ecrAffectedItemList
										.get(i).getType())
										|| "GE Mfg/Svcs Kit Part"
												.equalsIgnoreCase(ecrAffectedItemList
														.get(i).getType())
										|| "Synthetic Part"
												.equalsIgnoreCase(ecrAffectedItemList
														.get(i).getType()) || "GE Vendor Part"
											.equalsIgnoreCase(ecrAffectedItemList
													.get(i).getType()))) {
							uniquePartNames.remove(ecrAffectedItemList.get(i)
									.getAffctdItmName());
						}
					}*/
										
					
					/*List<PLMEcrSearchData> uniquePartsDependsForECR = plmKpiReportService.getPartsNotHavingRevOthrECR(selectedecrs);
					
					for(PLMEcrSearchData partSearchData :uniquePartsDependsForECR )
					{
						if(partSearchData.isPartInOtherEcr())
						{
							uniquePartNames.remove(partSearchData.getPartItmName());
						}
					}
					*/
					if(uniquePartNamesForECR!=null)
					{
						for(String uniquePartNamesForEcr:uniquePartNamesForECR)
						{
							uniquePartNames.remove(uniquePartNamesForEcr);
						}
						
					}	
					
					
					for (int i = 0; i < ecrAffectedItemList.size(); i++) {
						int lvl = Integer.parseInt(ecrAffectedItemList.get(i)
								.getEcrLevel());
						if (lvl == 2)
						{
							if((ecrAffectedItemList.get(i)
									.getRevision().equals("000") && !ecrAffectedItemList.get(i).getState().equals("Release"))||ecrAffectedItemList.get(i).isPartInOtherEcr()) {
								uniquePartNames.remove(ecrAffectedItemList.get(i)
										.getAffectedforceRev());
								PLMEcrSearchData partsToConsDta = new PLMEcrSearchData();
								partsToConsDta.setPartItmName(ecrAffectedItemList.get(i).getAffectedforceRev());
								partsToConsDta.setPartItmState(ecrAffectedItemList.get(i).getState());
								partsToConsDta.setPartItmRev(ecrAffectedItemList.get(i).getRevision());
								partsToConsDta.setPartInOtherEcrStr(ecrAffectedItemList.get(i).isPartInOtherEcr() ? "Yes" : "No");
								partsToBeConsiderd.add(partsToConsDta);
							}
						}
					}
					
				 
					partNameList = uniquePartNames;
					partsToBeConsider = partsToBeConsiderd;
					LOG.info("partNameList.size ---- " + partNameList.size());
				} else {
					totalAffctCount = 0;
				}
				totalAffctCountMsg = "Total Results of Affected Items for "
						+ selectedecrs + ": " + totalAffctCount;
 				LOG.info("totalAffctCount::::::::::::::::::" + totalAffctCount);
				if (totalAffctCount == 0) {

					fwdFlagAff = "invalidEcr";
				} else {
					reportName = "ecrAffectedDetlRpt";
					fwdFlagAff = "ecrAffctItemDetails";
				}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getecrNameBySelection: ",
						exception);
				fwdFlagAff = PLMUtils.setCommonException(
						exception.getMessage(), commonMB, "ecrSearchResult",
						"ECR Search");
			}
		}
		return fwdFlagAff;
	}

	/**
	 * This method is used for getDropDownvaluesecr
	 * 
	 * @return String
	 */
	public String getDropDownvaluesecr() {
		LOG.info("getDropDownvaluesecr() Method");
		String fwdFlag = "";
		alertMessage = "";
		partNameList = new ArrayList<String>();
		try {
			commonMB.insertCannedRptRecordHitInfo("ECR Search");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			dropdownlist = plmKpiReportService.getDropDownvaluesecr();
			resetEcrSearchData();
			catListData = (List<SelectItem>) dropdownlist.get("ecrcategory");
			sevListData = (List<SelectItem>) dropdownlist.get("ecrsev");
			stateListData = (List<SelectItem>) dropdownlist.get("ecrstate");
			fwdFlag = "ecrsearch";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getDropDownvaluesecr: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "home", "ECR Search");
		}

		/*
		 * try { commonMB.getPLMDateStamp(PLMConstants.ECR_TABLE); } catch
		 * (PLMCommonException exception) { LOG.log(Level.ERROR,
		 * "Exception@getPLMDateStamp: ", exception); }
		 */

		return fwdFlag;
	}

	/**
	 * This method is used for resetEcrSearchData
	 * 
	 * @return String
	 */
	public String resetEcrSearchData() {
		String fwdFlag = "ecrsearch";
		ecrSearchDetails.setEcrName("");
		ecrSearchDetails.setEcrOwner("");
		ecrSearchDetails.setEcrOriginator("");
		ecrSearchDetails.setEcrSevList(null);
		ecrSearchDetails.setEcrCategChngList(null);
		ecrSearchDetails.setEcrStateList(null);
		ecrSearchDetails.setFromecrStrtDate(null);
		ecrSearchDetails.setToecrEndDate(null);
		ecrSearchDetails.setResdesigneng("");
		ecrSearchDetails.setCcbchair("");
		ecrSearchDetails.setAllOpen(false);
		return fwdFlag;
	}

	/**
	 * This method is used to Validate Date Inputs
	 * 
	 * @param cont
	 * @param ucom
	 * @param ob
	 * @throws PLMCommonException
	 */
	public void validateDate(FacesContext cont, UIComponent ucom, Object ob)
			throws ValidatorException {
		try {
			Date dateVal = (Date) ob;
			LOG.info("validated date.." + dateVal);
		} catch (Exception ex) {
			LOG.log(Level.ERROR, "validateDate method error", ex);
			throw new ValidatorException(new FacesMessage("Invalid date"));
		}
	}

	/**
	 * This method is used for Generating ECO Report in Excel
	 * 
	 * @throws PLMCommonException
	 */
	public void downloadEcrExcel() throws PLMCommonException {

		String reportNm = reportName;
		String fileName;
		LOG.info("Inside downloadEcrExcel reportName>>> " + reportNm);

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();

		if (reportNm.equals("ecrHdrReport")) {
			fileName = "ECR Report";

			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					new PLMXlsxRptColumn("ecrName", "ECR Name", FormatType.TEXT),
					new PLMXlsxRptColumn("ecrRevision", "ECR REV",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecrOwner", "ECR Owner",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecrOwnerName", "ECR Owner Name",
							FormatType.TEXT, null, null, 20),
					new PLMXlsxRptColumn("ecrOriginator", "ECR Originator",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecrOriginatorName",
							"ECR Originator Name", FormatType.TEXT, null, null,
							20),
					new PLMXlsxRptColumn("ecrdesc", "ECR Description",
							FormatType.TEXT, null, null, 35),
					new PLMXlsxRptColumn("ecrState", "ECR State",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecrSev", "ECR Severity",
							FormatType.TEXT, null, null, 10),
					new PLMXlsxRptColumn("ecrCategChng", "ECR Category Change",
							FormatType.TEXT, null, null, 20),
					new PLMXlsxRptColumn("ecrevaluator", "ECR Evaluator",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecocount", "ECO Count",
							FormatType.TEXT, null, null, 7),
					new PLMXlsxRptColumn("resdesigneng", "Responsible Engr",
							FormatType.TEXT),
					new PLMXlsxRptColumn("resdesignengName",
							"Responsible Engr Name", FormatType.TEXT, null,
							null, 20),
					new PLMXlsxRptColumn("ccbchair", "CCB Chairman",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ccbChairmanName",
							"CCB Chairman Name", FormatType.TEXT, null, null,
							20)

			};

			PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] {
					new PLMXlsxRptColumn("ecrName", "ECR Name", FormatType.TEXT),
					new PLMXlsxRptColumn("ecrOwner", "ECR Owner",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecrOriginator", "ECR Originator",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecrStateExcel", "ECR State",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecrSevExcel", "ECR Severity",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecrCategChngExcel",
							"ECR Category Change", FormatType.TEXT),
					new PLMXlsxRptColumn("fromecrStrtDate",
							"ECR Start Date From", FormatType.DATEFR),
					new PLMXlsxRptColumn("toecrEndDate", "ECR Start Date To",
							FormatType.DATEFR),
					new PLMXlsxRptColumn("resdesigneng", "Responsible Engr",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ccbchair", "CCB Chairman",
							FormatType.TEXT)

			};

			excelUtil.export(ecrSearchResultList, reportColumns, fileName,
					fileName, true, critcolumns, ecrSearchDetails);

		} else if (reportNm.equals("ecrDetailReport")) {
			fileName = "ECR Details";
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					new PLMXlsxRptColumn("ecrName", "ECR Name", FormatType.TEXT),
					new PLMXlsxRptColumn("ecrRevision", "ECR REV",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecrOwner", "ECR Owner",
							FormatType.TEXT, null, null, 12),
					new PLMXlsxRptColumn("ecrOwnerName", "ECR Owner Name",
							FormatType.TEXT, null, null, 20),
					new PLMXlsxRptColumn("ecrdesc", "ECR Description",
							FormatType.TEXT, null, null, 35),
					new PLMXlsxRptColumn("ecrState", "ECR State",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecrLastUpdateExl", "ECR Last Update",
							FormatType.DATEFR, null, null, 20),
					new PLMXlsxRptColumn("reasonforchange",
							"Reason For Change", FormatType.TEXT, null, null,
							45),
					new PLMXlsxRptColumn("ecrOriginator", "ECR Originator",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecrOriginatorName",
							"ECR Originator Name", FormatType.TEXT, null, null,
							20),
					new PLMXlsxRptColumn("ecrCategChng", "ECR Category Change",
							FormatType.TEXT, null, null, 18),
					new PLMXlsxRptColumn("ecrSev", "ECR Severity",
							FormatType.TEXT, null, null, 10),
					new PLMXlsxRptColumn("reasonforcancel",
							"Reason for Cancel", FormatType.TEXT),
					new PLMXlsxRptColumn("generaldescrchange",
							"General Descr Change", FormatType.TEXT),
					new PLMXlsxRptColumn("resdesigneng", "Responsible Engr",
							FormatType.TEXT),
					new PLMXlsxRptColumn("resdesignengName",
							"Responsible Engr Name", FormatType.TEXT, null,
							null, 20),
					new PLMXlsxRptColumn("ecrevaluator", "ECR Evaluator",
							FormatType.TEXT),
					new PLMXlsxRptColumn("fromecrStrtDate", "ECR Start Date",
							FormatType.DATEFR, null, null, 15),
					new PLMXlsxRptColumn("toecrEndDate", "ECR End Date",
							FormatType.DATEFR, null, null, 15),
					new PLMXlsxRptColumn("ageindays", "Age in Days",
							FormatType.TEXT, null, null, 8),
					new PLMXlsxRptColumn("ISDeviation", "IS Deviation",
							FormatType.TEXT, null, null, 9),
					new PLMXlsxRptColumn("reviewerscomments",
							"Reviewers Comments", FormatType.TEXT, null, null,
							20),
					new PLMXlsxRptColumn("ecoName", "ECO Name", FormatType.TEXT),
					new PLMXlsxRptColumn("ECODescription", "ECO Description",
							FormatType.TEXT, null, null, 35),
					new PLMXlsxRptColumn("ecoOwner", "ECO Owner",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecoOwnerName", "ECO Owner Name",
							FormatType.TEXT, null, null, 20),
					new PLMXlsxRptColumn("ecoState", "ECO State",
							FormatType.TEXT, null, null, 12),
					new PLMXlsxRptColumn("ccbchair", "CCB Chairman",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ccbChairmanName",
							"CCB Chairman Name", FormatType.TEXT, null, null,
							20)

			};

			PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] {
					new PLMXlsxRptColumn("ecrName", "ECR Name", FormatType.TEXT),
					new PLMXlsxRptColumn("ecrOwner", "ECR Owner",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecrOriginator", "ECR Originator",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecrStateExcel", "ECR State",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecrSevExcel", "ECR Severity",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ecrCategChngExcel",
							"ECR Category Change", FormatType.TEXT),
					new PLMXlsxRptColumn("fromecrStrtDate",
							"ECR Start Date From", FormatType.DATEFR),
					new PLMXlsxRptColumn("toecrEndDate", "ECR Start Date To",
							FormatType.DATEFR),
					new PLMXlsxRptColumn("resdesigneng", "Responsible Engr",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ccbchair", "CCB Chairman",
							FormatType.TEXT)

			};

			excelUtil.export(ecrSearchResultDetailList, reportColumns,
					fileName, fileName, true, critcolumns, ecrSearchDetails);

		}/*
		 * else{ fileName = "ECR Affected Items"; PLMXlsxRptColumn[]
		 * reportColumns = new PLMXlsxRptColumn[] { new
		 * PLMXlsxRptColumn("ecrLevel", "Level", FormatType.TEXT), new
		 * PLMXlsxRptColumn("affectedItemName",
		 * "Affected Items",FormatType.LINK, null, null, 23, "affectedItemId"),
		 * new PLMXlsxRptColumn("affectedforceRev",
		 * "To be Added Due to Forced Part Revision= Yes",FormatType.LINK, null,
		 * null, 20, "affectedforceRevId"), new
		 * PLMXlsxRptColumn("whereUsedName", "Where Used",FormatType.LINK, null,
		 * null, 20, "whereUsedId"), new PLMXlsxRptColumn("type", "Type",
		 * FormatType.TEXT, null, null, 22), new PLMXlsxRptColumn("state",
		 * "State", FormatType.TEXT) };
		 * 
		 * PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] {new
		 * PLMXlsxRptColumn("selEcrName", "ECR Name", FormatType.TEXT) };
		 * 
		 * excelUtil.export(ecrAffectedItemList, reportColumns, fileName,
		 * fileName, true, critcolumns, ecrSearchDetails);
		 * 
		 * }
		 */

	}

	private XSSFFont headerFont(SXSSFWorkbook wb, int size) {
		XSSFFont font = (XSSFFont) wb.createFont();
		font.setFontName(PLMConstants.EXCEL_FONT_NAME);
		font.setFontHeightInPoints((short) size);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		return font;
	}

	private XSSFFont normalFont(SXSSFWorkbook wb, int size) {
		XSSFFont font = (XSSFFont) wb.createFont();
		font.setFontName(PLMConstants.EXCEL_FONT_NAME);
		font.setFontHeightInPoints((short) size);
		return font;
	}

	private XSSFCellStyle headerCell(SXSSFWorkbook wb, XSSFFont font,
			short bgcolor, boolean wrap) {
		XSSFCellStyle hCell = normalCell(wb, font,
				XSSFCellStyle.SOLID_FOREGROUND, wrap);
		// FONT
		hCell.setFont(font);

		// HORIZONTAL ALIGNMENT
		hCell.setAlignment(XSSFCellStyle.ALIGN_CENTER);

		// COLOR
		hCell.setFillForegroundColor(bgcolor);
		return hCell;
	}

	private XSSFCellStyle normalCell(SXSSFWorkbook wb, XSSFFont font,
			short fillPattern, boolean wrap) {
		// Cell Style
		XSSFCellStyle cellStyle = (XSSFCellStyle) wb.createCellStyle();

		// Set Font
		cellStyle.setFont(font);
		// WRAP TEXT
		cellStyle.setWrapText(wrap);

		// VERTICAL ALIGNMENT
		cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);

		// BORDERS
		cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);

		// FILL PATTERN
		cellStyle.setFillPattern(fillPattern);
		return cellStyle;
	}

	/**
	 * This method is used for Bordering Cell in XLS
	 * 
	 * @return StringBuffer
	 */
	private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
		style.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style.setBorderRight(XSSFCellStyle.BORDER_THIN);
		return style;
	}

	/**
	 * This method is used for download Excel sheet for ECR Affected Items
	 * report
	 * 
	 */
	public void downloadEcrAffctdReport() throws PLMCommonException {
		LOG.info("Entering downloadEcrAffctdReport Method");
		FacesContext facesContext = FacesContext.getCurrentInstance();
		try {
			HttpServletResponse response = (HttpServletResponse) facesContext
					.getExternalContext().getResponse();

			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

			response.setHeader("Content-disposition", "attachment; filename="
					+ "ECR Affected Items.xlsx");

			OutputStream outputStream = response.getOutputStream();

			SXSSFWorkbook workbook = new SXSSFWorkbook();

			XSSFFont font = headerFont(workbook, 10);

			// Header Style
			XSSFCellStyle headerStyle = headerCell(workbook, font,
					HSSFColor.PALE_BLUE.index, true);

			XSSFFont cellfont = normalFont(workbook, 10);
			// Cell Style
			XSSFCellStyle cellStyle = normalCell(workbook, cellfont,
					XSSFCellStyle.NO_FILL, true);

			// cell hyper link
			XSSFCreationHelper helper = (XSSFCreationHelper) workbook
					.getCreationHelper();

			XSSFFont underLinedFont = (XSSFFont) workbook.createFont();
			underLinedFont.setUnderline(HSSFFont.U_SINGLE);
			underLinedFont.setColor(IndexedColors.BLUE.getIndex());
			XSSFCellStyle hyperLinkStyle = (XSSFCellStyle) workbook
					.createCellStyle();
			hyperLinkStyle = setBorderStyle(hyperLinkStyle);
			hyperLinkStyle.setFont(underLinedFont);

			SXSSFSheet sheet = (SXSSFSheet) workbook
					.createSheet("ECR Affected Items");

			int rowcount = 0;

			SXSSFCell cell = null;

			SXSSFRow row = (SXSSFRow) sheet.createRow(rowcount);

			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
			cell.setCellValue("ECR Name");
			cell.setCellStyle(headerStyle);
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
			cell.setCellValue(ecrSearchDetails.getSelEcrName());
			cell.setCellStyle(cellStyle);
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
			cell.setCellValue("");

			row = (SXSSFRow) sheet.createRow(++rowcount);
			row = (SXSSFRow) sheet.createRow(++rowcount);

			String[] columns = { "Level", "Affected Items",
					"Forced Part Revision=Yes",
					"Where Used", "Type", "State" };

			for (int i = 0; i < columns.length; i++) {
				cell = (SXSSFCell) row.createCell(i);
				cell.setCellValue(columns[i]);
				cell.setCellStyle(headerStyle);
			}

			for (int i = 0; i < ecrAffectedItemList.size(); i++) {

				PLMEcrSearchData dataObj = (PLMEcrSearchData) ecrAffectedItemList
						.get(i);

				row = (SXSSFRow) sheet.createRow(++rowcount);

				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getEcrLevel());

				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
				if (!PLMUtils.isEmpty(dataObj.getAffectedItemId())) {
					cell.setCellStyle(hyperLinkStyle);
					XSSFHyperlink url_link1 = helper
							.createHyperlink(Hyperlink.LINK_URL);
					url_link1.setAddress(resourceBundle
							.getString("TASK_SEARCH_REDIRECT_URL")
							+ dataObj.getAffectedItemId());
					cell.setHyperlink(url_link1);
					cell.setCellValue(dataObj.getAffectedItemName());
				} else {
					cell.setCellStyle(cellStyle);
					cell.setCellValue("");
				}

				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
				if (!PLMUtils.isEmpty(dataObj.getAffectedforceRevId())) {
					cell.setCellStyle(hyperLinkStyle);
					XSSFHyperlink url_link1 = helper
							.createHyperlink(Hyperlink.LINK_URL);
					url_link1.setAddress(resourceBundle
							.getString("TASK_SEARCH_REDIRECT_URL")
							+ dataObj.getAffectedforceRevId());
					cell.setHyperlink(url_link1);
					cell.setCellValue(dataObj.getAffectedforceRev());
				} else {
					cell.setCellStyle(cellStyle);
					cell.setCellValue("");
				}

				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
				if (!PLMUtils.isEmpty(dataObj.getWhereUsedId())) {
					cell.setCellStyle(hyperLinkStyle);
					XSSFHyperlink url_link1 = helper
							.createHyperlink(Hyperlink.LINK_URL);
					url_link1.setAddress(resourceBundle
							.getString("TASK_SEARCH_REDIRECT_URL")
							+ dataObj.getWhereUsedId());
					cell.setHyperlink(url_link1);
					cell.setCellValue(dataObj.getWhereUsedName());
				} else {
					cell.setCellStyle(cellStyle);
					cell.setCellValue("");
				}

				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getType());

				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getState());

			}

			row = (SXSSFRow) sheet.createRow(++rowcount);
			row = (SXSSFRow) sheet.createRow(++rowcount);

			cell = (SXSSFCell) row.createCell(0);
			cell.setCellValue("Parts To Add");
			cell.setCellStyle(headerStyle);

			for (int j = 0; j < partNameList.size(); j++) {

				String partName = (String) partNameList.get(j);
				row = (SXSSFRow) sheet.createRow(++rowcount);

				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(partName);
			}

			row = (SXSSFRow) sheet.createRow(++rowcount);
			XSSFCellStyle ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
			ftrStyle.setFont(font);
			ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
			


			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			row = (SXSSFRow) sheet.createRow(++rowcount);

			String[] columnsPartsCons = { "Parts To Consider", "Rev",
					"State","On Another ECR?" };

			for (int i = 0; i < columnsPartsCons.length; i++) {
				cell = (SXSSFCell) row.createCell(i);
				cell.setCellValue(columnsPartsCons[i]);
				cell.setCellStyle(headerStyle);
			}

			for (int i = 0; i < partsToBeConsider.size(); i++) {

				PLMEcrSearchData dataObj = (PLMEcrSearchData) partsToBeConsider
						.get(i);

				row = (SXSSFRow) sheet.createRow(++rowcount);

				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getPartItmName());
				
				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getPartItmRev());
				
				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getPartItmState());
				
				cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(dataObj.getPartInOtherEcrStr());

			}
			
			row = (SXSSFRow) sheet.createRow(++rowcount);
			row = (SXSSFRow) sheet.createRow(++rowcount);
		
			cell = (SXSSFCell) row.createCell(0);
			cell.setCellValue("GE Proprietary Information - For GE Use Only ");
			cell.setCellStyle(ftrStyle);
			sheet.addMergedRegion(new CellRangeAddress(rowcount, rowcount,
					PLMConstants.EXCEL_COL_ZERO, PLMConstants.EXCEL_COL_TWO));

			sheet.setColumnWidth(0, 15 * 256);
			sheet.setColumnWidth(1, 15 * 256);
			sheet.setColumnWidth(2, 35 * 256);
			sheet.setColumnWidth(3, 30 * 256);
			sheet.setColumnWidth(4, 30 * 256);
			sheet.setColumnWidth(5, 15 * 256);

			workbook.write(outputStream);

			outputStream.flush();

			outputStream.close();

		} catch (IOException ioex) {
			ioex.printStackTrace();
		} finally {
			facesContext.responseComplete();
		}
		LOG.info("Exiting downloadEcrAffctdReport Method");
	}

	/**
	 * This method is used for Generating ECO Report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	public void downloadEcrCsv() throws PLMCommonException {

		String reportNm = reportName;
		String fileName;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy",
				Locale.ENGLISH);
		LOG.info("Inside downloadEcrCsv reportName>>> " + reportNm);

		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();

		if (reportNm.equals("ecrHdrReport")) {

			fileName = "ECR Report";
			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					new PLMCsvRptColumn("ecrName", "ECR Name",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ecrRevision", "ECR REV",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ecrOwner", "ECR Owner",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ecrOwnerName", "ECR Owner Name",
							FormatTypeCsv.TEXT, null, null, 20),
					new PLMCsvRptColumn("ecrOriginator", "ECR Originator",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ecrOriginatorName",
							"ECR Originator Name", FormatTypeCsv.TEXT, null,
							null, 20),
					new PLMCsvRptColumn("ecrdesc", "ECR Description",
							FormatTypeCsv.TEXT, null, null, 35),
					new PLMCsvRptColumn("ecrState", "ECR State",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ecrSev", "ECR Severity",
							FormatTypeCsv.TEXT, null, null, 10),
					new PLMCsvRptColumn("ecrCategChng", "ECR Category Change",
							FormatTypeCsv.TEXT, null, null, 20),
					new PLMCsvRptColumn("ecrevaluator", "ECR Evaluator",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ecocount", "ECO Count",
							FormatTypeCsv.TEXT, null, null, 7),
					new PLMCsvRptColumn("resdesigneng", "Responsible Engr",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("resdesignengName",
							"Responsible Engr Name", FormatTypeCsv.TEXT, null,
							null, 20),
					new PLMCsvRptColumn("ccbchair", "CCB Chairman",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ccbChairmanName", "CCB Chairman Name",
							FormatTypeCsv.TEXT, null, null, 20)

			};

			csvUtil.exportCsv(ecrSearchResultList, reportColumns, fileName,
					dateFormat, false, null, null, ",");

		} else if (reportNm.equals("ecrDetailReport")) {

			fileName = "ECR Details";
			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					new PLMCsvRptColumn("ecrName", "ECR Name",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ecrRevision", "ECR REV",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ecrOwner", "ECR Owner",
							FormatTypeCsv.TEXT, null, null, 12),
					new PLMCsvRptColumn("ecrOwnerName", "ECR Owner Name",
							FormatTypeCsv.TEXT, null, null, 20),
					new PLMCsvRptColumn("ecrdesc", "ECR Description",
							FormatTypeCsv.TEXT, null, null, 35),
					new PLMCsvRptColumn("ecrState", "ECR State",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ecrLastUpdateExl", "ECR Last Update",
							FormatTypeCsv.DATEFR, null, null, 12),
					new PLMCsvRptColumn("reasonforchange", "Reason For Change",
							FormatTypeCsv.TEXT, null, null, 45),
					new PLMCsvRptColumn("ecrOriginator", "ECR Originator",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ecrOriginatorName",
							"ECR Originator Name", FormatTypeCsv.TEXT, null,
							null, 20),
					new PLMCsvRptColumn("ecrCategChng", "ECR Category Change",
							FormatTypeCsv.TEXT, null, null, 18),
					new PLMCsvRptColumn("ecrSev", "ECR Severity",
							FormatTypeCsv.TEXT, null, null, 10),
					new PLMCsvRptColumn("reasonforcancel", "Reason for Cancel",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("generaldescrchange",
							"General Descr Change", FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("resdesigneng", "Responsible Engr",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("resdesignengName",
							"Responsible Engr Name", FormatTypeCsv.TEXT, null,
							null, 20),
					new PLMCsvRptColumn("ecrevaluator", "ECR Evaluator",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("fromecrStrtDate", "ECR Start Date",
							FormatTypeCsv.DATEFR, null, null, 10),
					new PLMCsvRptColumn("toecrEndDate", "ECR End Date",
							FormatTypeCsv.DATEFR, null, null, 10),
					new PLMCsvRptColumn("ageindays", "Age in Days",
							FormatTypeCsv.TEXT, null, null, 8),
					new PLMCsvRptColumn("ISDeviation", "IS Deviation",
							FormatTypeCsv.TEXT, null, null, 9),
					new PLMCsvRptColumn("reviewerscomments",
							"Reviewers Comments", FormatTypeCsv.TEXT, null,
							null, 20),
					new PLMCsvRptColumn("ecoName", "ECO Name",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ECODescription", "ECO Description",
							FormatTypeCsv.TEXT, null, null, 35),
					new PLMCsvRptColumn("ecoOwner", "ECO Owner",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ecoOwnerName", "ECO Owner Name",
							FormatTypeCsv.TEXT, null, null, 20),
					new PLMCsvRptColumn("ecoState", "ECO State",
							FormatTypeCsv.TEXT, null, null, 12),
					new PLMCsvRptColumn("ccbchair", "CCB Chairman",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ccbChairmanName", "CCB Chairman Name",
							FormatTypeCsv.TEXT, null, null, 20)

			};

			csvUtil.exportCsv(ecrSearchResultDetailList, reportColumns,
					fileName, dateFormat, false, null, null, ",");

		} else {
			fileName = "ECR Affected Items";
			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					new PLMCsvRptColumn("ecrLevel", "Level", FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("affectedItemName", "Affected Items",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("affectedforceRev",
							"Forced Part Revision=Yes",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("whereUsedName", "Where Used",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("type", "Type", FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("state", "State", FormatTypeCsv.TEXT) };

			csvUtil.exportCsv(ecrAffectedItemList, reportColumns, fileName,
					dateFormat, false, null, null, ",");

		}

	}

	public void downloadEcrAffctdCVSReport() throws PLMCommonException {

		String fileName = "ECR Affected Items";
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy",
				Locale.ENGLISH);
		LOG.info("Inside downloadEcrCsv reportName>>> " + fileName);
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		FacesContext facesContext = FacesContext.getCurrentInstance();
		PrintWriter pwriter = null;

		try {

			HttpServletResponse response = (HttpServletResponse) facesContext
					.getExternalContext().getResponse();

			pwriter = response.getWriter();

			response.setContentType("application/CSV");

			response.setHeader("Content-disposition", "attachment; filename="
					+ fileName + ".csv");

			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					new PLMCsvRptColumn("ecrLevel", "Level", FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("affectedItemName", "Affected Items",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("affectedforceRev",
							"Forced Part Revision=Yes",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("whereUsedName", "Where Used",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("type", "Type", FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("state", "State", FormatTypeCsv.TEXT) };

			int numCols = reportColumns.length;

			// Loop over all the column beans and populate the report headers
			for (int i = 0; i < numCols; i++) {
				// Get the header text from the bean and write it to the cell
				csvUtil.writeValue(reportColumns[i].getHeader(), pwriter,
						FormatTypeCsv.TEXT, dateFormat, ",");
			}
			pwriter.println();

			appendPrintWriter(pwriter, reportColumns, ecrAffectedItemList, ",",csvUtil);

			PLMCsvRptColumn[] reportColumns1 = new PLMCsvRptColumn[] { new PLMCsvRptColumn(
					"partsToAdd", "Parts To Add", FormatTypeCsv.TEXT), };

			int numCols1 = reportColumns1.length;

			// Loop over all the column beans and populate the report headers
			for (int i = 0; i < numCols1; i++) {
				// Get the header text from the bean and write it to the cell
				csvUtil.writeValue(reportColumns1[i].getHeader(), pwriter,
						FormatTypeCsv.TEXT, dateFormat, ",");
			}
			pwriter.println();

			appendPrintWriter(pwriter, reportColumns1, partNameList, ",",csvUtil);
			
			
			

			PLMCsvRptColumn[] reportColumnsFrPartConsider = new PLMCsvRptColumn[] {
					new PLMCsvRptColumn("partItmName", "Parts To Consider", FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("partItmRev", "Rev",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("partItmState",
							"State",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("partInOtherEcrStr", "On Another ECR?",
							FormatTypeCsv.TEXT) };

			int numColsFrPartConsider = reportColumnsFrPartConsider.length;

			// Loop over all the column beans and populate the report headers
			for (int i = 0; i < numColsFrPartConsider; i++) {
				// Get the header text from the bean and write it to the cell
				csvUtil.writeValue(reportColumnsFrPartConsider[i].getHeader(), pwriter,
						FormatTypeCsv.TEXT, dateFormat, ",");
			}
			
			pwriter.println();
			
			appendPrintWriter(pwriter, reportColumnsFrPartConsider, partsToBeConsider, ",",csvUtil);
			
			pwriter.println();
			

			pwriter.write("GE Proprietary Information - For GE Use Only ");

			pwriter.flush();
			pwriter.close();

		} catch (IOException ioex) {
			ioex.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Caught Generate Error exception: "
					+ e.getMessage());
		} finally {
			facesContext.responseComplete();
			try {
				if (pwriter != null) {
					pwriter.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
		}
	}

	public void appendPrintWriter(PrintWriter pwriter1,
			PLMCsvRptColumn[] columns, List<?> data, String delimiter, PLMCsvRptUtil csvUtil) {

		int numCols = columns.length;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy",
				Locale.ENGLISH);
		// Write report rows
		try {
			for (int i = 0; i < data.size(); i++) {
				// get the bean for the current row
				Object bean = data.get(i);
				// For each column object, create a column on the current row
				for (int y = 0; y < numCols; y++) {

					if (bean instanceof String) {
						csvUtil.writeValue(data.get(i), pwriter1,
								FormatTypeCsv.TEXT, dateFormat, delimiter);
					} else {
						Object value = PropertyUtils.getProperty(bean,
								columns[y].getMethod());
						if (value != null) {
							csvUtil.writeValue(value, pwriter1,
									columns[y].getType(), dateFormat, delimiter);
						} else {
							csvUtil.writeValue(value, pwriter1,
									FormatTypeCsv.TEXT, dateFormat, delimiter);
						}
					}
				}
				pwriter1.println();
			}
			pwriter1.println();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String backToEcrReport() {
		LOG.info("-----back To EcrReport---");
		reportName = "ecrHdrReport";
		return "ecrSearchResult";
	}

	/*
	 * public void downloadEcrRptExcel() throws PLMCommonException {
	 * LOG.info("Entering downloadEcrRptExcel Method");
	 * 
	 * String reportName="ECR Report"; String fileName="ecrsearchreportexcel";
	 * LOG.info("reportName>>> " +reportName); LOG.info("fileName>>> "
	 * +fileName);
	 * 
	 * PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
	 * 
	 * PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] { new
	 * PLMXlsxRptColumn("ecrName", "ECR Name", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecrRevision", "ECR REV", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecrOwner", "ECR Owner", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecrOwnerName", "ECR Owner Name", FormatType.TEXT, null,
	 * null, 20), new PLMXlsxRptColumn("ecrOriginator", "ECR Originator",
	 * FormatType.TEXT), new PLMXlsxRptColumn("ecrOriginatorName",
	 * "ECR Originator Name", FormatType.TEXT, null, null, 20), new
	 * PLMXlsxRptColumn("ecrdesc", "ECR Description", FormatType.TEXT, null,
	 * null, 35), new PLMXlsxRptColumn("ecrState", "ECR State",
	 * FormatType.TEXT), new PLMXlsxRptColumn("ecrSev", "ECR Severity",
	 * FormatType.TEXT, null, null, 10), new PLMXlsxRptColumn("ecrCategChng",
	 * "ECR Category Change", FormatType.TEXT, null, null, 20), new
	 * PLMXlsxRptColumn("ecrevaluator", "ECR Evaluator", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecocount", "ECO Count", FormatType.TEXT, null, null,
	 * 7), new PLMXlsxRptColumn("resdesigneng", "Responsible Engr",
	 * FormatType.TEXT), new PLMXlsxRptColumn("resdesignengName",
	 * "Responsible Engr Name", FormatType.TEXT, null, null, 20), new
	 * PLMXlsxRptColumn("ccbchair", "CCB Chairman", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ccbChairmanName", "CCB Chairman Name", FormatType.TEXT,
	 * null, null, 20)
	 * 
	 * };
	 * 
	 * 
	 * PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] {new
	 * PLMXlsxRptColumn("ecrName", "ECR Name", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecrOwner", "ECR Owner", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecrOriginator", "ECR Originator", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecrStateExcel", "ECR State", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecrSevExcel", "ECR Severity", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecrCategChngExcel", "ECR Category Change",
	 * FormatType.TEXT), new PLMXlsxRptColumn("fromecrStrtDate",
	 * "ECR Start Date From", FormatType.TEXT), new
	 * PLMXlsxRptColumn("toecrEndDate", "ECR Start Date To", FormatType.TEXT),
	 * new PLMXlsxRptColumn("resdesigneng", "Responsible Engr",
	 * FormatType.TEXT), new PLMXlsxRptColumn("ccbchair", "CCB Chairman",
	 * FormatType.TEXT)
	 * 
	 * };
	 * 
	 * excelUtil.export(ecrSearchResultList, reportColumns, fileName, fileName,
	 * true, critcolumns, ecrSearchDetails);
	 * 
	 * }
	 * 
	 * public void downloadEcrDtlExcel() throws PLMCommonException {
	 * LOG.info("Entering downloadEcrDtlExcel Method");
	 * 
	 * String reportName="ECR Detail"; String fileName="ecrsearchdetailsexcel";
	 * LOG.info("reportName>>> " +reportName); LOG.info("fileName>>> "
	 * +fileName);
	 * 
	 * PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
	 * 
	 * PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] { new
	 * PLMXlsxRptColumn("ecrName", "ECR Name", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecrRevision", "ECR REV", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecrOwner", "ECR Owner", FormatType.TEXT, null, null,
	 * 12), new PLMXlsxRptColumn("ecrOwnerName", "ECR Owner Name",
	 * FormatType.TEXT, null, null, 20), new PLMXlsxRptColumn("ecrdesc",
	 * "ECR Description", FormatType.TEXT, null, null, 35), new
	 * PLMXlsxRptColumn("ecrState", "ECR State", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ECRLastUpdate", "ECR Last Update", FormatType.TEXT,
	 * null, null, 12), new PLMXlsxRptColumn("reasonforchange",
	 * "Reason For Change", FormatType.TEXT, null, null, 45), new
	 * PLMXlsxRptColumn("ecrOriginator", "ECR Originator", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecrOriginatorName", "ECR Originator Name",
	 * FormatType.TEXT, null, null, 20), new PLMXlsxRptColumn("ecrCategChng",
	 * "ECR Category Change", FormatType.TEXT, null, null, 18), new
	 * PLMXlsxRptColumn("ecrSev", "ECR Severity", FormatType.TEXT, null, null,
	 * 10), new PLMXlsxRptColumn("reasonforcancel", "Reason for Cancel",
	 * FormatType.TEXT), new PLMXlsxRptColumn("generaldescrchange",
	 * "General Descr Change", FormatType.TEXT), new
	 * PLMXlsxRptColumn("resdesigneng", "Responsible Engr", FormatType.TEXT),
	 * new PLMXlsxRptColumn("resdesignengName", "Responsible Engr Name",
	 * FormatType.TEXT, null, null, 20), new PLMXlsxRptColumn("ecrevaluator",
	 * "ECR Evaluator", FormatType.TEXT), new
	 * PLMXlsxRptColumn("fromecrStrtDate", "ECR Start Date", FormatType.DATE,
	 * null, null, 10), new PLMXlsxRptColumn("toecrEndDate", "ECR End Date",
	 * FormatType.DATE, null, null, 10), new PLMXlsxRptColumn("ageindays",
	 * "Age in Days", FormatType.TEXT, null, null, 8), new
	 * PLMXlsxRptColumn("ISDeviation", "IS Deviation", FormatType.TEXT, null,
	 * null, 9), new PLMXlsxRptColumn("reviewerscomments", "Reviewers Comments",
	 * FormatType.TEXT, null, null, 20), new PLMXlsxRptColumn("ecoName",
	 * "ECO Name", FormatType.TEXT), new PLMXlsxRptColumn("ECODescription",
	 * "ECO Description", FormatType.TEXT, null, null, 35), new
	 * PLMXlsxRptColumn("ecoOwner", "ECO Owner", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecoOwnerName", "ECO Owner Name", FormatType.TEXT, null,
	 * null, 20), new PLMXlsxRptColumn("ecoState", "ECO State", FormatType.TEXT,
	 * null, null, 12), new PLMXlsxRptColumn("ccbchair", "CCB Chairman",
	 * FormatType.TEXT), new PLMXlsxRptColumn("ccbChairmanName",
	 * "CCB Chairman Name", FormatType.TEXT, null, null, 20)
	 * 
	 * };
	 * 
	 * 
	 * PLMXlsxRptColumn[] critcolumns = new PLMXlsxRptColumn[] {new
	 * PLMXlsxRptColumn("ecrName", "ECR Name", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecrOwner", "ECR Owner", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecrOriginator", "ECR Originator", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecrStateExcel", "ECR State", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecrSevExcel", "ECR Severity", FormatType.TEXT), new
	 * PLMXlsxRptColumn("ecrCategChngExcel", "ECR Category Change",
	 * FormatType.TEXT), new PLMXlsxRptColumn("fromecrStrtDate",
	 * "ECR Start Date From", FormatType.TEXT), new
	 * PLMXlsxRptColumn("toecrEndDate", "ECR Start Date To", FormatType.TEXT),
	 * new PLMXlsxRptColumn("resdesigneng", "Responsible Engr",
	 * FormatType.TEXT), new PLMXlsxRptColumn("ccbchair", "CCB Chairman",
	 * FormatType.TEXT)
	 * 
	 * };
	 * 
	 * excelUtil.export(ecrSearchResultDetailList, reportColumns, fileName,
	 * fileName, true, critcolumns, ecrSearchDetails);
	 * 
	 * }
	 * 
	 * 
	 * public void downloadEcrRptCsv() throws PLMCommonException {
	 * LOG.info("Entering downloadEcrRptCsv Method"); PrintWriter pwriter =
	 * null; OutputStream os = null; try { FacesContext facesContext =
	 * FacesContext.getCurrentInstance(); HttpServletResponse response =
	 * (HttpServletResponse) facesContext.getExternalContext().getResponse();
	 * response
	 * .setHeader("content-disposition","attachment; filename=ECR Report.csv");
	 * response.setContentType("application/CSV"); pwriter =
	 * response.getWriter();
	 * 
	 * pwriter.write("ECR Name"); pwriter.write(","); pwriter.write("ECR REV");
	 * pwriter.write(","); pwriter.write("ECR Owner"); pwriter.write(",");
	 * pwriter.write("ECR Owner Name"); pwriter.write(",");
	 * pwriter.write("ECR Originator"); pwriter.write(",");
	 * pwriter.write("ECR Originator Name"); pwriter.write(",");
	 * pwriter.write("ECR Description"); pwriter.write(",");
	 * pwriter.write("ECR State"); pwriter.write(",");
	 * pwriter.write("ECR Severity"); pwriter.write(",");
	 * pwriter.write("ECR Category Change"); pwriter.write(",");
	 * pwriter.write("ECR Evaluator"); pwriter.write(",");
	 * pwriter.write("ECO Count"); pwriter.write(",");
	 * pwriter.write("Responsible Engr"); pwriter.write(",");
	 * pwriter.write("Responsible Engr Name"); pwriter.write(",");
	 * pwriter.write("CCB Chairman"); pwriter.write(",");
	 * pwriter.write("CCB Chairman Name"); pwriter.write("\n");
	 * 
	 * for(int i=0; i<ecrSearchResultList.size(); i++) { PLMEcrSearchData
	 * dataObj = (PLMEcrSearchData)ecrSearchResultList.get(i);
	 * if(dataObj.getEcrName()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrName())); }
	 * pwriter.write(","); if(dataObj.getEcrRevision()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrRevision())); }
	 * pwriter.write(","); if(dataObj.getEcrOwner()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrOwner())); }
	 * pwriter.write(","); if(dataObj.getEcrOwnerName()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrOwnerName())); }
	 * pwriter.write(","); if(dataObj.getEcrOriginator()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrOriginator())); }
	 * pwriter.write(","); if(dataObj.getEcrOriginatorName()!= null){
	 * pwriter.write
	 * (PLMUtils.convertToCsvValue(dataObj.getEcrOriginatorName())); }
	 * pwriter.write(","); if(dataObj.getEcrdesc()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrdesc())); }
	 * pwriter.write(","); if(dataObj.getEcrState()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrState())); }
	 * pwriter.write(","); if(dataObj.getEcrSev()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrSev())); }
	 * pwriter.write(","); if(dataObj.getEcrCategChng()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrCategChng())); }
	 * pwriter.write(","); if(dataObj.getEcrevaluator()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrevaluator())); }
	 * pwriter.write(","); if(dataObj.getEcocount()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcocount())); }
	 * pwriter.write(","); if(dataObj.getResdesigneng()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getResdesigneng()));
	 * 
	 * } pwriter.write(","); if(dataObj.getResdesignengName()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getResdesignengName()));
	 * 
	 * } pwriter.write(","); if(dataObj.getCcbchair()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getCcbchair()));
	 * 
	 * } pwriter.write(","); if(dataObj.getCcbChairmanName()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getCcbChairmanName()));
	 * 
	 * } pwriter.write("\n");
	 * 
	 * } pwriter.flush(); } catch (FileNotFoundException e) {
	 * System.out.println("the exception is---" + e); } catch (Exception e1) {
	 * System.out.println("IOException " + e1.getMessage()); } finally { try {
	 * if (pwriter != null) { pwriter.close(); } } catch (Exception exc) {
	 * exc.printStackTrace(); } try { if (os != null) { os.close(); } } catch
	 * (Exception exc) { exc.printStackTrace(); } }
	 * LOG.info("Exiting downloadEcrRptCsv Method"); }
	 * 
	 * public void downloadEcrDtlCsv() throws PLMCommonException {
	 * LOG.info("Entering downloadEcrDtlCsv Method"); PrintWriter pwriter =
	 * null; OutputStream os = null; SimpleDateFormat dateFormat= new
	 * SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH); try { FacesContext
	 * facesContext = FacesContext.getCurrentInstance(); HttpServletResponse
	 * response = (HttpServletResponse)
	 * facesContext.getExternalContext().getResponse();
	 * response.setHeader("content-disposition"
	 * ,"attachment; filename=ECR Detail.csv");
	 * response.setContentType("application/CSV"); pwriter =
	 * response.getWriter();
	 * 
	 * pwriter.write("ECR Name"); pwriter.write(","); pwriter.write("ECR REV");
	 * pwriter.write(","); pwriter.write("ECR Owner"); pwriter.write(",");
	 * pwriter.write("ECR Owner Name"); pwriter.write(",");
	 * pwriter.write("ECR Description"); pwriter.write(",");
	 * pwriter.write("ECR State"); pwriter.write(",");
	 * pwriter.write("ECR Last Update"); pwriter.write(",");
	 * pwriter.write("Reason For Change"); pwriter.write(",");
	 * pwriter.write("ECR Originator"); pwriter.write(",");
	 * pwriter.write("ECR Originator Name"); pwriter.write(",");
	 * pwriter.write("ECR Category Change"); pwriter.write(",");
	 * pwriter.write("ECR Severity"); pwriter.write(",");
	 * pwriter.write("Reason for Cancel"); pwriter.write(",");
	 * pwriter.write("General Descr Change"); pwriter.write(",");
	 * pwriter.write("Responsible Engr"); pwriter.write(",");
	 * pwriter.write("Responsible Engr Name"); pwriter.write(",");
	 * pwriter.write("ECR Evaluator"); pwriter.write(",");
	 * pwriter.write("ECR Start Date"); pwriter.write(",");
	 * pwriter.write("ECR End Date"); pwriter.write(",");
	 * pwriter.write("Age in Days"); pwriter.write(",");
	 * pwriter.write("IS Deviation"); pwriter.write(",");
	 * pwriter.write("Reviewers Comments"); pwriter.write(",");
	 * pwriter.write("ECO Name"); pwriter.write(",");
	 * pwriter.write("ECO Description"); pwriter.write(",");
	 * pwriter.write("ECO Owner"); pwriter.write(",");
	 * pwriter.write("ECO Owner Name"); pwriter.write(",");
	 * pwriter.write("ECO State"); pwriter.write(",");
	 * pwriter.write("CCB Chairman"); pwriter.write(",");
	 * pwriter.write("CCB Chairman Name"); pwriter.write("\n");
	 * 
	 * 
	 * for(int i=0; i<ecrSearchResultDetailList.size(); i++) { PLMEcrSearchData
	 * dataObj = (PLMEcrSearchData)ecrSearchResultDetailList.get(i);
	 * if(dataObj.getEcrName()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrName())); }
	 * pwriter.write(","); if(dataObj.getEcrRevision()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrRevision())); }
	 * pwriter.write(","); if(dataObj.getEcrOwner()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrOwner())); }
	 * pwriter.write(","); if(dataObj.getEcrOwnerName()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrOwnerName())); }
	 * pwriter.write(","); if(dataObj.getEcrdesc()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrdesc())); }
	 * pwriter.write(","); if(dataObj.getEcrState()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrState())); }
	 * pwriter.write(","); if(dataObj.getECRLastUpdate()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getECRLastUpdate())); }
	 * pwriter.write(","); if(dataObj.getReasonforchange()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getReasonforchange()));
	 * } pwriter.write(","); if(dataObj.getEcrOriginator()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrOriginator())); }
	 * pwriter.write(","); if(dataObj.getEcrOriginatorName()!= null){
	 * pwriter.write
	 * (PLMUtils.convertToCsvValue(dataObj.getEcrOriginatorName())); }
	 * pwriter.write(","); if(dataObj.getEcrCategChng()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrCategChng())); }
	 * pwriter.write(","); if(dataObj.getEcrSev()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrSev())); }
	 * pwriter.write(","); if(dataObj.getReasonforcancel()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getReasonforcancel()));
	 * } pwriter.write(","); if(dataObj.getGeneraldescrchange()!= null){
	 * pwriter.
	 * write(PLMUtils.convertToCsvValue(dataObj.getGeneraldescrchange()));
	 * 
	 * } pwriter.write(","); if(dataObj.getResdesigneng() != null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getResdesigneng()));
	 * 
	 * } pwriter.write(","); if(dataObj.getResdesignengName() != null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getResdesignengName()));
	 * 
	 * } pwriter.write(","); if(dataObj.getEcrevaluator()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcrevaluator()));
	 * 
	 * } pwriter.write(","); if(dataObj.getFromecrStrtDate()!= null){ String
	 * ecr_start_date=dateFormat.format(dataObj.getFromecrStrtDate());
	 * pwriter.write(ecr_start_date); } pwriter.write(",");
	 * if(dataObj.getToecrEndDate()!= null){ String
	 * ecr_end_date=dateFormat.format(dataObj.getToecrEndDate());
	 * pwriter.write(ecr_end_date); } pwriter.write(",");
	 * if(dataObj.getAgeindays()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getAgeindays()));
	 * 
	 * } pwriter.write(","); if(dataObj.getISDeviation()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getISDeviation()));
	 * 
	 * } pwriter.write(","); if(dataObj.getReviewerscomments()!= null){
	 * pwriter.write
	 * (PLMUtils.convertToCsvValue(dataObj.getReviewerscomments()));
	 * 
	 * } pwriter.write(","); if(dataObj.getEcoName()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoName()));
	 * 
	 * } pwriter.write(","); if(dataObj.getECODescription()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getECODescription()));
	 * 
	 * } pwriter.write(","); if(dataObj.getEcoOwner()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoOwner()));
	 * 
	 * } pwriter.write(","); if(dataObj.getEcoOwnerName()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoOwnerName()));
	 * 
	 * } pwriter.write(","); if(dataObj.getEcoState()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoState()));
	 * 
	 * } pwriter.write(","); if(dataObj.getCcbchair()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getCcbchair()));
	 * 
	 * } pwriter.write(","); if(dataObj.getCcbChairmanName()!= null){
	 * pwriter.write(PLMUtils.convertToCsvValue(dataObj.getCcbChairmanName()));
	 * 
	 * } pwriter.write("\n");
	 * 
	 * } pwriter.flush(); } catch (FileNotFoundException e) {
	 * System.out.println("the exception is---" + e); } catch (Exception e1) {
	 * System.out.println("IOException " + e1.getMessage()); } finally { try {
	 * if (pwriter != null) { pwriter.close(); } } catch (Exception exc) {
	 * exc.printStackTrace(); } try { if (os != null) { os.close(); } } catch
	 * (Exception exc) { exc.printStackTrace(); } }
	 * LOG.info("Exiting downloadEcrDtlCsv Method"); }
	 */

	/**
	 * @return the plmKpiReportService
	 */
	public PLMkpiReportServiceIfc getPlmKpiReportService() {
		return plmKpiReportService;
	}

	/**
	 * @param plmKpiReportService
	 *            the plmKpiReportService to set
	 */
	public void setPlmKpiReportService(
			PLMkpiReportServiceIfc plmKpiReportService) {
		this.plmKpiReportService = plmKpiReportService;
	}

	/**
	 * @return the searchResultList
	 */
	public List<PLMEcrSearchData> getEcrSearchResultList() {
		return ecrSearchResultList;
	}

	/**
	 * @param searchResultList
	 *            the searchResultList to set
	 */
	public void setEcrSearchResultList(
			List<PLMEcrSearchData> ecrSearchResultList) {
		this.ecrSearchResultList = ecrSearchResultList;
	}

	/**
	 * @return the searchDetails
	 */
	public PLMEcrSearchData getEcrSearchDetails() {
		return ecrSearchDetails;
	}

	/**
	 * @param searchDetails
	 *            the searchDetails to set
	 */
	public void setEcrSearchDetails(PLMEcrSearchData ecrSearchDetails) {
		this.ecrSearchDetails = ecrSearchDetails;
	}

	/**
	 * @return the count
	 */
	public int getCount() {
		return count;
	}

	/**
	 * @param count
	 *            the count to set
	 */
	public void setCount(int count) {
		this.count = count;
	}

	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount
	 *            the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/**
	 * @return the totalRecCountMsg
	 */
	public String getTotalRecCountMsg() {
		return totalRecCountMsg;
	}

	/**
	 * @param totalRecCountMsg
	 *            the totalRecCountMsg to set
	 */
	public void setTotalRecCountMsg(String totalRecCountMsg) {
		this.totalRecCountMsg = totalRecCountMsg;
	}

	/**
	 * @return the totalDetailRecCountMsg
	 */
	public String getTotalDetailRecCountMsg() {
		return totalDetailRecCountMsg;
	}

	/**
	 * @param totalDetailRecCountMsg
	 *            the totalDetailRecCountMsg to set
	 */
	public void setTotalDetailRecCountMsg(String totalDetailRecCountMsg) {
		this.totalDetailRecCountMsg = totalDetailRecCountMsg;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage
	 *            the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}

	/**
	 * @return the catListData
	 */
	public List<SelectItem> getCatListData() {
		return catListData;
	}

	/**
	 * @param catListData
	 *            the catListData to set
	 */
	public void setCatListData(List<SelectItem> catListData) {
		this.catListData = catListData;
	}

	/**
	 * @return the sevListData
	 */
	public List<SelectItem> getSevListData() {
		return sevListData;
	}

	/**
	 * @param sevListData
	 *            the sevListData to set
	 */
	public void setSevListData(List<SelectItem> sevListData) {
		this.sevListData = sevListData;
	}

	/**
	 * @return the stateListData
	 */
	public List<SelectItem> getStateListData() {
		return stateListData;
	}

	/**
	 * @param stateListData
	 *            the stateListData to set
	 */
	public void setStateListData(List<SelectItem> stateListData) {
		this.stateListData = stateListData;
	}

	/**
	 * @return the ecrsessionvalue
	 */
	public String getEcrsessionvalue() {
		return ecrsessionvalue;
	}

	/**
	 * @param ecrsessionvalue
	 *            the ecrsessionvalue to set
	 */
	public void setEcrsessionvalue(String ecrsessionvalue) {
		this.ecrsessionvalue = ecrsessionvalue;
	}

	/**
	 * @return the selectedecrs
	 */
	public String getSelectedecrs() {
		return selectedecrs;
	}

	/**
	 * @param selectedecrs
	 *            the selectedecrs to set
	 */
	public void setSelectedecrs(String selectedecrs) {
		this.selectedecrs = selectedecrs;
	}

	/**
	 * @return the ecrSearchResultDetailList
	 */
	public List<PLMEcrSearchData> getEcrSearchResultDetailList() {
		return ecrSearchResultDetailList;
	}

	/**
	 * @param ecrSearchResultDetailList
	 *            the ecrSearchResultDetailList to set
	 */
	public void setEcrSearchResultDetailList(
			List<PLMEcrSearchData> ecrSearchResultDetailList) {
		this.ecrSearchResultDetailList = ecrSearchResultDetailList;
	}

	/**
	 * @return the totalDetailRecCount
	 */
	public int getTotalDetailRecCount() {
		return totalDetailRecCount;
	}

	/**
	 * @param totalDetailRecCount
	 *            the totalDetailRecCount to set
	 */
	public void setTotalDetailRecCount(int totalDetailRecCount) {
		this.totalDetailRecCount = totalDetailRecCount;
	}

	/**
	 * @return the detailRecordCounts
	 */
	public int getDetailRecordCounts() {
		return detailRecordCounts;
	}

	/**
	 * @param detailRecordCounts
	 *            the detailRecordCounts to set
	 */
	public void setDetailRecordCounts(int detailRecordCounts) {
		this.detailRecordCounts = detailRecordCounts;
	}

	/**
	 * @param recordCounts
	 *            the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB
	 *            the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the reportName
	 */
	public String getReportName() {
		return reportName;
	}

	/**
	 * @param reportName
	 *            the reportName to set
	 */
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	/**
	 * @return the ecrAffectedItemList
	 */
	public List<PLMEcrSearchData> getEcrAffectedItemList() {
		return ecrAffectedItemList;
	}

	/**
	 * @param ecrAffectedItemList
	 *            the ecrAffectedItemList to set
	 */
	public void setEcrAffectedItemList(
			List<PLMEcrSearchData> ecrAffectedItemList) {
		this.ecrAffectedItemList = ecrAffectedItemList;
	}

	/**
	 * @return the totalAffctCount
	 */
	public int getTotalAffctCount() {
		return totalAffctCount;
	}

	/**
	 * @param totalAffctCount
	 *            the totalAffctCount to set
	 */
	public void setTotalAffctCount(int totalAffctCount) {
		this.totalAffctCount = totalAffctCount;
	}

	/**
	 * @return the totalAffctCountMsg
	 */
	public String getTotalAffctCountMsg() {
		return totalAffctCountMsg;
	}

	/**
	 * @param totalAffctCountMsg
	 *            the totalAffctCountMsg to set
	 */
	public void setTotalAffctCountMsg(String totalAffctCountMsg) {
		this.totalAffctCountMsg = totalAffctCountMsg;
	}

	/**
	 * @return the partNameList
	 */
	public List<String> getPartNameList() {
		return partNameList;
	}

	/**
	 * @param partNameList
	 *            the partNameList to set
	 */
	public void setPartNameList(List<String> partNameList) {
		this.partNameList = partNameList;
	}

	public List<PLMEcrSearchData> getPartsToBeConsider() {
		return partsToBeConsider;
	}

	public void setPartsToBeConsider(List<PLMEcrSearchData> partsToBeConsider) {
		this.partsToBeConsider = partsToBeConsider;
	}
	
	

}