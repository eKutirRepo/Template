package com.geinfra.geaviation.pwi.integration;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.PWiQueryTimeoutException;
import com.geinfra.geaviation.pwi.common.PWiResultSizeLimitExceededException;
import com.geinfra.geaviation.pwi.model.PWiResultSet;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;

/**
 * Project      : Product Lifecycle Management
 * Date Written : May 18, 2010
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : BaseDAO - Defines interface for executing queries for a given
 * QueryType.
 * 
 * Revision Log May 18, 2010 | v1.0.
 * 2012.12.18 pH  replaced GEAEResultSet with PWiResultSet
 * --------------------------------------------------------------
 */
public abstract class QueryingDao {
	private int queryTimeoutSecs;
	private int resultSizeLimit;

	public QueryingDao(int queryTimeoutSecs, int resultSizeLimit) {
		this.queryTimeoutSecs = queryTimeoutSecs;
		this.resultSizeLimit = resultSizeLimit;
	}

	public abstract PWiResultSet executeQuery(QueryType queryType,
			Search search, SelectedColumns selectedColumns, String sso)
			throws PWiException, PWiQueryTimeoutException,
			PWiResultSizeLimitExceededException;

	public abstract String getExecutedQuery();

	protected int getQueryTimeoutSecs() {
		return queryTimeoutSecs;
	}

	public int getResultSizeLimit() {
		return resultSizeLimit;
	}

	public void setResultSizeLimit(int resultSizeLimit) {
		this.resultSizeLimit = resultSizeLimit;
	}
}
