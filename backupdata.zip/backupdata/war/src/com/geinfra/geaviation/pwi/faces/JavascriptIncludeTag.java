/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName JavascriptIncludeTag.java
 * @Creation date: 18-Aug-2014
 * @version 1.0
  * @author : Tech Mahindra
 */

package com.geinfra.geaviation.pwi.faces;

import javax.faces.webapp.UIComponentTag;

public class JavascriptIncludeTag extends UIComponentTag {

	@Override
	public String getComponentType() {
		return "javascriptInclude";
	}

	@Override
	public String getRendererType() {
		// Use default supplied in UI component
		return null;
	}
}
