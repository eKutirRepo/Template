/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMDlvrblRptDaoIfc.java
 * @Creation date: 11-Sept-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.Map;

import com.geinfra.geaviation.pwi.data.PLMBomSpecPartData;
import com.geinfra.geaviation.pwi.data.PLMMessageData;
import com.geinfra.geaviation.pwi.data.PLMPRSData;
import com.geinfra.geaviation.pwi.data.PLMPRSRouteData;
import com.geinfra.geaviation.pwi.data.PLMPRSTaskRouteData;
import com.geinfra.geaviation.pwi.data.PLMRouteTaskOwnerData;
import com.geinfra.geaviation.pwi.data.PLMSalesOrderData;
import com.geinfra.geaviation.pwi.data.PLMTaskDlvrblData;
import com.geinfra.geaviation.pwi.data.PLMTaskRouteData;

public interface PLMDlvrblRptDaoIfc {

	/**
	 * Returns the PLM Project Info
	 *  @param projectName(String)
	 * @return project_info (Map<String, String>)
	 */	
	public Map<String, String> project_info(String projectName);
	
	/**
	 * Returns the BOM most recent revision
	 *  @param bomNumber(String)
	 * @return max_revision (String)
	 */
	public abstract String max_revision(String bomNumber);

	
	/**
	 * Returns PRS Object
	 * @param projectName
	 * @return prs (PRS)
	 */
	public PLMPRSData prs(String projectName);

	/**
	 * Returns Chapters List from PRS
	 * @param id
	 * @param strPRSId
	 * @return  prs_chapters (List<PRS>)
	 */
	public List<PLMPRSData> prs_chapters(String projectName, String strPRSId);
	
	/**
	 * Returns Chapters & Requirements List from PRS
	 * @param id
	 * @return  prsChaptersRequirements (List<PRS>)
	 */
	public Map<String, PLMPRSData> prsChaptersRequirementsComments(String id);
	//public abstract Map<String, BomSpecPart> bom_parts(String projectName);
	
	/**
	 * Returns Map of tasks deliverables with its ids
	 *  @param projectName(String)
	 * @return tasks_deliverables (List<TaskDeliverable>)
	 */
	public abstract List<PLMTaskDlvrblData> tasks_deliverables(String projectName);
	
	/**
	 * Returns the list of bom parts
	 *  @param bomNumber(String)
	 *  @param maxRevision(String)
	 * @return bom_parts (List<BomSpecPart>)
	 */
	public abstract Map<String, PLMBomSpecPartData> bom_parts(List<String> topPartsList);

	/**
	 * Returns the list of spec parts
	 *  @param bomNumber(String)
	 *  @param maxRevision(String)  
	 * @return spec_parts (List<BomSpecPart>)
	 */
	public abstract Map<String, PLMBomSpecPartData> spec_parts(List<String> topPartsList);

	/**
	 * Returns the list of messages
	 *  @param projectName(String)
	 * @return messages (List<Message>)
	 */
	public abstract List<PLMMessageData> messages(String projectName);
	
	/**
	 * Returns the list route-task owners
	 *  @param projectName(String)
	 * @return routeTaskOwners (List<RouteTaskOwner>)
	 */
	public abstract List<PLMRouteTaskOwnerData> routeTaskOwners(String projectName);

	/**
	 * Returns the list route-task owners
	 *  @param projectName(String)
	 * @return routeTaskOwners (List<RouteTaskOwner>)
	 */
	public abstract List<PLMTaskRouteData> tasks_routes(String projectName);
	
	/**
	 * Returns the list sales_orders owners
	 *  @param projectName(String)
	 * @return sales_orders (List<SalesOrder>)
	 */
	public abstract List<PLMSalesOrderData> sales_orders(String projectName);
	

	/**
	 * Returns the list of PRS Routes
	 *  @param projectName(String)
	 * @return prs_routes (List<PRSRoute>)
	 */
	public abstract List<PLMPRSRouteData> prs_routes(String projectName);
	
	/**
	 * Returns the list of PRS Route Tasks
	 *  @param prsRouteID(String)
	 * @return prs_route_tasks (List<PRSRouteTask>)
	 */
	public abstract List<PLMPRSTaskRouteData> prs_route_tasks(String prsRouteID);
	/**
	 * Returns the list 
	 *  @param projectName(String)
	 * @return getTopLevelPart (List<String>)
	 */
	public List<String> getTopLevelPart(String prjName);

}
