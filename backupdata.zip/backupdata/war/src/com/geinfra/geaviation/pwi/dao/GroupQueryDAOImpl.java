package com.geinfra.geaviation.pwi.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

import com.geinfra.geaviation.pwi.dao.QueriesDAOImpl.PWiQueryNoXmlVORowMapper;
import com.geinfra.geaviation.pwi.dao.QueryGroupDAOImpl.PWiQueryGroupVORowMapper;
import com.geinfra.geaviation.pwi.model.PWiGroupQueryVO;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.model.PWiQueryNoXmlVO;
import com.geinfra.geaviation.pwi.model.PWiUserVO;
import com.geinfra.geaviation.pwi.util.ColumnConstants;
import com.geinfra.geaviation.pwi.util.DaoUtil;
import com.geinfra.geaviation.pwi.util.QueryConstants;
import com.geinfra.geaviation.pwi.util.QueryLoader;

/**
 * 
 * Project : Product Lifecycle Management Date Written : May 19, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : QueryGroupDAOImpl
 * 
 * Revision Log May 19, 2010 | v1.0.
 * --------------------------------------------------------------
 */

public class GroupQueryDAOImpl extends PWiDAO implements GroupQueryDAO {
	// TODO pH 2013.02: convert to final instance of anonymous class?
	private static class PWiGroupQueryVORowMapper implements
			ParameterizedRowMapper<PWiGroupQueryVO> {
		PWiQueryGroupVORowMapper groupRowMapper = new PWiQueryGroupVORowMapper();
		PWiQueryNoXmlVORowMapper queryRowMapper = new PWiQueryNoXmlVORowMapper();

		public PWiGroupQueryVO mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PWiQueryGroupVO group = groupRowMapper.mapRow(rs, rowNum);
			PWiQueryNoXmlVO query = queryRowMapper.mapRow(rs, rowNum);

			PWiGroupQueryVO groupQuery = new PWiGroupQueryVO();
			groupQuery.setGroup(group);
			groupQuery.setQuery(query);

			return groupQuery;
		}
	}

	public List<PWiGroupQueryVO> getGroupQueriesForQuery(Integer queryId) {
		GetGroupQuerysForQuerySetter pss = new GetGroupQuerysForQuerySetter(
				queryId);

		@SuppressWarnings("unchecked")
		List<PWiGroupQueryVO> result = (List<PWiGroupQueryVO>) getJdbcTemplate()
				.query(pss.getSql(), pss, new PWiGroupQueryVORowMapper());

		return result;
	}

	private static class GetGroupQuerysForQuerySetter implements
			PreparedStatementSetter {
		private Integer queryId;

		public GetGroupQuerysForQuerySetter(Integer queryId) {
			this.queryId = queryId;
		}

		public String getSql() {
			// TODO pH 2012.11: add this to query.properties
			StringBuilder builder = new StringBuilder();
			builder.append("SELECT * FROM ");
			builder.append(ColumnConstants.TBL_PWi_GROUP_QUERY);
			builder.append(" gq, ");
			builder.append(ColumnConstants.TBL_PWi_QUERY_GROUP);
			builder.append(" grp, ");
			builder.append(ColumnConstants.TBL_PWi_QUERY);
			builder.append(" qry WHERE gq.");
			builder.append(ColumnConstants.QRY_SEQ_ID);
			builder.append(" = ? AND qry.");
			builder.append(ColumnConstants.QRY_SEQ_ID);
			builder.append(" = gq.");
			builder.append(ColumnConstants.QRY_SEQ_ID);
			builder.append(" AND grp.");
			builder.append(ColumnConstants.QRY_GRP_SEQ_ID);
			builder.append(" = gq.");
			builder.append(ColumnConstants.QRY_GRP_SEQ_ID);

			return builder.toString();
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			int index = 1;
			ps.setInt(index, queryId.intValue());
		}
	}

	public void addGroupsForQuery(List<Integer> groupIds,
			Integer queryId, String sso) {
		AddGroupsForQuerySetter pss = new AddGroupsForQuerySetter(queryId,
				groupIds, sso);

		getJdbcTemplate().batchUpdate(pss.getSql(), pss);
	}

	private static class AddGroupsForQuerySetter implements
			BatchPreparedStatementSetter {
		private Integer queryId;
		private List<Integer> groupIds;
		private String sso;

		public AddGroupsForQuerySetter(Integer queryId,
				List<Integer> groupIds, String sso) {
			this.queryId = queryId;
			this.groupIds = groupIds;
			this.sso = sso;
		}

		public String getSql() {
			StringBuilder builder = new StringBuilder();
			builder.append("INSERT INTO ");
			builder.append(ColumnConstants.TBL_PWi_GROUP_QUERY);
			builder.append(" (");
			builder.append(ColumnConstants.QRY_SEQ_ID);
			builder.append(", ");
			builder.append(ColumnConstants.QRY_GRP_SEQ_ID);
			builder.append(", Crtn_Dt, Crtd_by, Lst_Updt_dt, Lst_Updtd_By)");
			builder.append(" VALUES (?,?,SYSDATE,?,SYSDATE,?)");

			return builder.toString();
		}

		public int getBatchSize() {
			return groupIds.size();
		}

		public void setValues(PreparedStatement ps, int grpIdIndex) throws SQLException {
			ps.setInt(1, queryId.intValue());
			ps.setInt(2, groupIds.get(grpIdIndex).intValue());
			ps.setString(3, sso);
			ps.setString(4, sso);
		}
	}

	public void deleteGroupsForQuery(List<Integer> groupIds,
			Integer queryId) {
		RemoveGroupsForQuerySetter pss = new RemoveGroupsForQuerySetter(
				queryId, groupIds);

		getJdbcTemplate().update(pss.getSql(), pss);
	}

	private static class RemoveGroupsForQuerySetter implements
			PreparedStatementSetter {
		private Integer queryId;
		private List<Integer> groupIds;

		public RemoveGroupsForQuerySetter(Integer queryId,
				List<Integer> groupIds) {
			this.queryId = queryId;
			this.groupIds = groupIds;
		}

		public String getSql() {
			StringBuilder builder = new StringBuilder();
			builder.append("DELETE FROM ");
			builder.append(ColumnConstants.TBL_PWi_GROUP_QUERY);
			builder.append(" WHERE ");
			builder.append(ColumnConstants.QRY_SEQ_ID);
			builder.append("=? AND ");
			builder.append(ColumnConstants.QRY_GRP_SEQ_ID);
			builder.append(" IN (");
			builder.append(DaoUtil.getInstance().generateInClausePlaceholders(
					groupIds.size()));
			builder.append(")");

			return builder.toString();
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			int index = 1;
			ps.setInt(index, queryId.intValue());
			index++;
			for (Integer groupId : groupIds) {
				ps.setInt(index, groupId.intValue());
				index++;
			}
		}
	}
	@Override
	public List<PWiUserVO> getUserGroupQueriesForQuery(Integer queryId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addDeleteUserGroupsForQuery(Integer queryId, String sso,
			Map<String, List<PWiUserVO>> tempGrpUsrMap) {

		String removeUserAccSql = QueryLoader
				.getQuery(QueryConstants.PWi_GROUP_QUERY_USER_REMOVE);
		Object[] paramsUserForQuery = new Object[] { queryId };
		getJdbcTemplate().update(removeUserAccSql, paramsUserForQuery);
		String revUserAccSql1 = QueryLoader
				.getQuery(QueryConstants.PWi_GROUP_QUERY_USER_INSERT);
		for (Map.Entry<String, List<PWiUserVO>> entry : tempGrpUsrMap
				.entrySet()) {
			
			
			String groupId = entry.getKey();
			List<PWiUserVO> userList = entry.getValue();
			if (userList != null) {
				for (PWiUserVO user : userList) {
					if (!user.isUserSelected()) {
						Object[] paramsUser = new Object[] { queryId, groupId.substring(0, groupId.indexOf(':')),
								user.getUserId(), sso, sso };
						getJdbcTemplate().update(revUserAccSql1, paramsUser);
					}
				}

			}
		}
	}
}
