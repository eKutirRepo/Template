package com.geinfra.geaviation.pwi.model;

import com.geinfra.geaviation.pwi.common.RecordStatus;

/**
 * 
 * Project        :   Product Lifecycle Management
 * Date Written   :   Aug 6, 2010
 * Security       :   GE Confidential
 * Restrictions   :   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 * Copyright(C) 2010 GE 
 * All rights reserved
 *
 * Description    :  QueryResultComparisonVO - Subscription comparison object
 *
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class QueryResultComparisonVO {
	private RecordStatus cmprsnStatus;
	private String columnHeaderName;
	private String columnValue;

	public QueryResultComparisonVO() {
	}

	/**
	 * @return the columnHeaderName
	 */
	public String getColumnHeaderName() {
		return columnHeaderName;
	}

	/**
	 * @param columnHeaderName
	 *            the columnHeaderName to set
	 */
	public void setColumnHeaderName(String columnHeaderName) {
		this.columnHeaderName = columnHeaderName;
	}

	/**
	 * @return the columnValue
	 */
	public String getColumnValue() {
		return columnValue;
	}

	/**
	 * @param columnValue
	 *            the columnValue to set
	 */
	public void setColumnValue(String columnValue) {
		this.columnValue = columnValue;
	}

	/**
	 * @return the status
	 */

	/**
	 * @return the cmprsnStatus
	 */
	public RecordStatus getCmprsnStatus() {
		return cmprsnStatus;
	}

	/**
	 * @param cmprsnStatus
	 *            the cmprsnStatus to set
	 */
	public void setCmprsnStatus(RecordStatus cmprsnStatus) {
		this.cmprsnStatus = cmprsnStatus;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((columnValue == null) ? 0 : columnValue.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final QueryResultComparisonVO other = (QueryResultComparisonVO) obj;
		if (columnValue == null) {
			if (other.columnValue != null)
				return false;
		} else if (!columnValue.equals(other.columnValue))
			return false;
		return true;
	}

}
