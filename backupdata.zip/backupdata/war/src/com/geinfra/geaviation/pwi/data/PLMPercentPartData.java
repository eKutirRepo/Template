/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMPercentPartData.java
 * @Creation date: 15-June-2011
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team) 
 */

package com.geinfra.geaviation.pwi.data;

/**
 * PLMPercentPartData is the Data Storage Class for Percent Part Reuse Report.
 */

public class PLMPercentPartData {
	/**
	  * Holds the turbineNumber
	  */
	private String turbineNumber;
	/**
	  * Holds the productLine
	  */
	private String productLine;
	/**
	  * Holds the serialNumber
	  */
	private String serialNumber;
	/**
	  * Holds the customerName
	  */
	private String customerName;
	/**
	  * Holds the siteLoc
	  */
	private String siteLoc;
	/**
	  * Holds the mfgDatePercent
	  */
	private String mfgDatePercent;
	/**
	  * Holds the todayDatePercent
	  */
	private String todayDatePercent;
	/**
	  * Holds the mfgDateHeader
	  */
	private String mfgDateHeader;
	/**
	  * Holds the todayDateHeader
	  */
	private String todayDateHeader;
	/**
	  * Holds the ML number
	  */
	private String mlNumber;
	
	/**
	 * @return the productLine
	 */
	public String getProductLine() {
		return productLine;
	}
	/**
	 * @param productLine the productLine to set
	 */
	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}
	
	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}
	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	/**
	 * @return the siteLoc
	 */
	public String getSiteLoc() {
		return siteLoc;
	}
	/**
	 * @param siteLoc the siteLoc to set
	 */
	public void setSiteLoc(String siteLoc) {
		this.siteLoc = siteLoc;
	}
	/**
	 * @return the mfgDatePercent
	 */
	public String getMfgDatePercent() {
		return mfgDatePercent;
	}
	/**
	 * @param mfgDatePercent the mfgDatePercent to set
	 */
	public void setMfgDatePercent(String mfgDatePercent) {
		this.mfgDatePercent = mfgDatePercent;
	}
	/**
	 * @return the todayDatePercent
	 */
	public String getTodayDatePercent() {
		return todayDatePercent;
	}
	/**
	 * @param todayDatePercent the todayDatePercent to set
	 */
	public void setTodayDatePercent(String todayDatePercent) {
		this.todayDatePercent = todayDatePercent;
	}
	/**
	 * @return the turbineNumber
	 */
	public String getTurbineNumber() {
		return turbineNumber;
	}
	/**
	 * @param turbineNumber the turbineNumber to set
	 */
	public void setTurbineNumber(String turbineNumber) {
		this.turbineNumber = turbineNumber;
	}
	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}
	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	/**
	 * @return the mfgDateHeader
	 */
	public String getMfgDateHeader() {
		return mfgDateHeader;
	}
	/**
	 * @param mfgDateHeader the mfgDateHeader to set
	 */
	public void setMfgDateHeader(String mfgDateHeader) {
		this.mfgDateHeader = mfgDateHeader;
	}
	/**
	 * @return the todayDateHeader
	 */
	public String getTodayDateHeader() {
		return todayDateHeader;
	}
	/**
	 * @param todayDateHeader the todayDateHeader to set
	 */
	public void setTodayDateHeader(String todayDateHeader) {
		this.todayDateHeader = todayDateHeader;
	}
	/**
	 * @return the mlNumber
	 */
	public String getMlNumber() {
		return mlNumber;
	}
	/**
	 * @param mlNumber the mlNumber to set
	 */
	public void setMlNumber(String mlNumber) {
		this.mlNumber = mlNumber;
	}
	
}