package com.geinfra.geaviation.pwi.executors;

import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.PWiQueryTimeoutException;
import com.geinfra.geaviation.pwi.common.PWiResultSizeLimitExceededException;
import com.geinfra.geaviation.pwi.model.PWiResultSet;
import com.geinfra.geaviation.pwi.util.QueryProcessingUtil;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;

/**
 * 
 * Project      : Product Lifecycle Management Intelligence
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description :
 * 
 * Revision Log
 * 2012.12.18 pH  replaced GEAEResultSet with PWiResultSet
 * --------------------------------------------------------------
 */
public class AppendExecutor implements Executor {
	List<Executor> executors;

	public AppendExecutor(List<Executor> executors) {
		this.executors = executors;
	}

	/*
	 * A pipeline executor should call each of its child executors in order
	 * passing the columns/rows from a previous child executor to the next child
	 * executor. The first child executor will get the columns/rows passed in
	 * (likely null).
	 */

	public PWiResultSet execute(QueryType queryType, Search search,
			SelectedColumns selectedColumns, String sso, String[] columns,
			List<Object[]> rows) throws PWiException,
			PWiResultSizeLimitExceededException, PWiQueryTimeoutException {
		PWiResultSet finalResultSet = null;

		if (!executors.isEmpty()) {
			// Execute first executor with passed in columns/rows
			finalResultSet = executors.get(0).execute(queryType, search,
					selectedColumns, sso, columns, rows);

			// Execute remaining executors with column/rows from the previous
			// result set
			for (int index = 1; index < executors.size(); index++) {
				// Execute
				PWiResultSet newResultSet = executors.get(index).execute(
						queryType, search, selectedColumns, sso, columns, rows);

				// Check that pipeline results has same number of
				// columns as previous result set

				int newColumnCount = newResultSet.getColumnCount();

				int finalColumnCount = finalResultSet.getColumnCount();

				if (newColumnCount != finalColumnCount) {
					StringBuilder builder = new StringBuilder();
					builder.append("Pipeline has different number of columns");
					builder.append(" than the previous result set.");
					throw new PWiException(builder.toString());
				}

				try {
					QueryProcessingUtil.getInstance().appendResultSet(
							finalResultSet, newResultSet);
				} finally {
					closeResultSet(newResultSet);
				}
			}
		}

		return finalResultSet;
	}

	private void closeResultSet(PWiResultSet resultSet) {
		if (resultSet != null) {
			resultSet.close();
		}
	}

	public String getExecutedQuery() {
		return "Getting query string not supported for append queries.";
	}
}
