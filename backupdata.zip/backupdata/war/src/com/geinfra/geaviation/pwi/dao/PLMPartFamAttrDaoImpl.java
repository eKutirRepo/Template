/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMPartFamAttrDaoImpl.java
 * @Creation date: 24-Feb-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.common.usermodel.Hyperlink;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFCreationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFHyperlink;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMInterfaceAttrData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMPartFamAttrDaoImpl extends SimpleJdbcDaoSupport implements PLMPartFamAttrDaoIfc {
	
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMPartFamAttrDaoImpl.class);
	private static List<String> selAttributeList =new ArrayList<String>();
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");

	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
		 
	}

	
	/**
	 * This method is used to getDropDownData
	 * @return java.util.Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getPartFamilyDropDownData() throws PLMCommonException {
		Map<String, List<SelectItem>> dropDownDataMap = new HashMap<String, List<SelectItem>>();
		List<SelectItem> partFamilyDDList = null;
		try{
			
		LOG.info("Query to get partFamilyDDList is: " + PLMSearchQueries.GET_PART_FAMILY_DD_LIST);
			
		partFamilyDDList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_PART_FAMILY_DD_LIST, new PartFamilyDDListMapper());
	
		dropDownDataMap.put("partFamilyDDList",partFamilyDDList);
				
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}catch(Exception e){
			e.printStackTrace();
		}
		return dropDownDataMap;
	}
	/**
	 * @return SelectItem objects.
	 */
	private static final class PartFamilyDDListMapper implements ParameterizedRowMapper<SelectItem> {
	
			public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
		   SelectItem selectItem = new SelectItem(rs.getString("NM"));
			return selectItem;
			}
		}
	
	/**
	 * This method is used to getAttrNameForPartFamily
	 * @return java.util.Map
	 * @param selectedPartFamily
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public Map<String, List<SelectItem>> getAttrNameForPartFamily(String selectedPartFamily) throws PLMCommonException {
		Map<String, List<SelectItem>> dropDownDataMap = new HashMap<String, List<SelectItem>>();
		
		try{
		LOG.info("Query to get Attribute Name for Part Family is: "+PLMSearchQueries.GET_ATTRIBUTE_NAME_FOR_PART_FAMILY);

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("PFNM", selectedPartFamily);
		List<SelectItem>attrNameForPartFamily = getNamedJdbcTemplate().
		query(PLMSearchQueries.GET_ATTRIBUTE_NAME_FOR_PART_FAMILY, params, new AttributeNameMapper());
		
		if (!PLMUtils.isEmptyList(attrNameForPartFamily)) {
			Collections.sort(attrNameForPartFamily, new PLMUtils.SortListSelItmLbl());
		}
		
		dropDownDataMap.put("attrNameForPartFamily", attrNameForPartFamily);
		
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return dropDownDataMap;
	}
	/**
	 * This method is to get count for Part Family
	 * 
	 * @param partFamily
	 * @return int
	 * @throws PLMCommonException
	 */
	public int getPartFamilyCount(String partFamily)throws PLMCommonException{
		LOG.info("Entering getPartFamilyCount");
		LOG.info("Selected Part Family:::::::::----"+partFamily);
		LOG.info("Part Family Count Query:::::::::----"+PLMSearchQueries.PART_FAMILY_ATTR_MASTER_COUNT);
		int pfCount = getSimpleJdbcTemplate().queryForInt(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_COUNT, 
				new Object[] { partFamily });
		return pfCount;
	}
	/**
	 * @return SelectItem objects.
	 */
	private static final class AttributeNameMapper implements ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
	   SelectItem selectItem = new SelectItem(rs.getString("ATTRIBUTE_NM"));
		return selectItem;
		}
	}
	
	@SuppressWarnings("unchecked")
	public Map<String,String> getPartFamilyAttrMasterResultList(PLMInterfaceAttrData partFamilyIntAttrData,String optionType,boolean hyperLinkFlag
			,boolean partAttribFlag,boolean partFamilyAttribFlag) throws PLMCommonException {
	
		LOG.info("Inside getPartFamilyAttrMasterResultList(PLMPartFamilyIntAttrData partFamilyIntAttrData) in DAO Impl");
		
		Map<String,String> filepathMap = new HashMap<String,String>();
		
		List<String> attrbuteNameList = new ArrayList<String>();
		
		List<PLMInterfaceAttrData> resultList = new ArrayList<PLMInterfaceAttrData>();
		List<PLMInterfaceAttrData> finalresultList = new ArrayList<PLMInterfaceAttrData>();
		
		StringBuffer partFamilyMstrQry1 = new StringBuffer();
		StringBuffer partFamilyMstrQry2 = new StringBuffer();
		StringBuffer partFamilyMstrQry3 = new StringBuffer();
		StringBuffer partFamilyMstrQry4 = new StringBuffer();
		StringBuffer partFamilyMstrQry5 = new StringBuffer();
		StringBuffer partFamilyMstrQry6 = new StringBuffer();
		StringBuffer partFamilyMstrQry7 = new StringBuffer();
		StringBuffer partFamilyMstrQry8 = new StringBuffer();
		StringBuffer partFamilyMstrQry9 = new StringBuffer();
		StringBuffer partFamilyMstrQry10 = new StringBuffer();
		StringBuffer partFamilyMstrQry11 = new StringBuffer();
		StringBuffer partFamilyMstrQry12 = new StringBuffer();
		StringBuffer partFamilyMstrQry13 = new StringBuffer();
		StringBuffer partFamilyMstrQry14 = new StringBuffer();
		StringBuffer partFamilyMstrQry15 = new StringBuffer();
		StringBuffer partFamilyMstrQry16 = new StringBuffer();
		StringBuffer partFamilyMstrQry17 = new StringBuffer();
		StringBuffer partFamilyMstrQry18 = new StringBuffer();
		StringBuffer partFamilyMstrQry19 = new StringBuffer();
		StringBuffer partFamilyMstrQry20 = new StringBuffer();
		
		StringBuffer partFamilyMstrVt = new StringBuffer();
		StringBuffer partFamilyMstrQryFinalVT = new StringBuffer();
		StringBuffer partFamilyVtPartsVT = new StringBuffer();
		StringBuffer partFamilyMstrVtRows = new StringBuffer();
		
		String timeStamp = null;
		String VT_PART_MSTR =null;
		String VT_FINALDT =null;
		String VT_PARTS =null;
		
		String paramVal1= "";
		String paramVal2= "";
		String grpBy = " GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40";
		
		timeStamp = PLMUtils.volTableFormatDate();
		VT_PART_MSTR = PLMConstants.VT_PART_MSTR.concat(timeStamp);
		VT_FINALDT = PLMConstants.VT_FINALDT.concat(timeStamp);
		VT_PARTS =PLMConstants.VT_PARTS.concat(timeStamp);
		if(partFamilyIntAttrData.getSelectedPartFamily()!=null && !partFamilyIntAttrData.getSelectedPartFamily().equals(""))
		{
			paramVal1= " AND PART_FAMILY_NM = '"+partFamilyIntAttrData.getSelectedPartFamily()+"' ";
		}
		if(partFamilyIntAttrData.getSelectedPartNum()!=null && !partFamilyIntAttrData.getSelectedPartNum().equals(""))
		{
			paramVal2= " AND PART_NAME in ("+PLMUtils.setListForPartNames(partFamilyIntAttrData.getPartNumlist())+")"; 
		}		
		
		partFamilyMstrVt.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_VT.replace(PLMConstants.VT_PART_MSTR, VT_PART_MSTR));
		
		if(optionType.equalsIgnoreCase("All Parts")){
			LOG.info("Entering into All Parts of optionType >>>>>>>>>>>>>>>"+optionType);
			partFamilyMstrQry1.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT1).append(PLMSearchQueries.PART_FAMILY_ATTR_T_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry2.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT2).append(PLMSearchQueries.PART_FAMILY_ATTR_KIT_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry3.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT3).append(PLMSearchQueries.PART_FAMILY_ATTR_SYNT_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry4.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT4).append(PLMSearchQueries.PART_FAMILY_ATTR_VNDR_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry5.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT5).append(PLMSearchQueries.PART_FAMILY_ATTR_T_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry6.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT6).append(PLMSearchQueries.PART_FAMILY_ATTR_KIT_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry7.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT7).append(PLMSearchQueries.PART_FAMILY_ATTR_SYNT_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry8.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT8).append(PLMSearchQueries.PART_FAMILY_ATTR_VNDR_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry9.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT9).append(PLMSearchQueries.PART_FAMILY_ATTR_T_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry10.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT10).append(PLMSearchQueries.PART_FAMILY_ATTR_KIT_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry11.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT11).append(PLMSearchQueries.PART_FAMILY_ATTR_SYNT_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry12.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT12).append(PLMSearchQueries.PART_FAMILY_ATTR_VNDR_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry13.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT13).append(PLMSearchQueries.PART_FAMILY_ATTR_T_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry14.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT14).append(PLMSearchQueries.PART_FAMILY_ATTR_KIT_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry15.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT15).append(PLMSearchQueries.PART_FAMILY_ATTR_SYNT_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry16.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT16).append(PLMSearchQueries.PART_FAMILY_ATTR_VNDR_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry17.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT17).append(PLMSearchQueries.PART_FAMILY_ATTR_KIT_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry18.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT18).append(PLMSearchQueries.PART_FAMILY_ATTR_SYNT_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry19.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT19).append(PLMSearchQueries.PART_FAMILY_ATTR_VNDR_PART_ALL).append(paramVal1).append(paramVal2).append(grpBy);
		}else if(optionType.equalsIgnoreCase("Highest Revision Parts")){
			LOG.info("Entering into Highest Revision Parts of optionType >>>>>>>>>>>>>>>"+optionType);
			partFamilyMstrQry1.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT1).append(PLMSearchQueries.PART_FAMILY_ATTR_T_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry2.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT2).append(PLMSearchQueries.PART_FAMILY_ATTR_KIT_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry3.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT3).append(PLMSearchQueries.PART_FAMILY_ATTR_SYNT_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry4.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT4).append(PLMSearchQueries.PART_FAMILY_ATTR_VNDR_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry5.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT5).append(PLMSearchQueries.PART_FAMILY_ATTR_T_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry6.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT6).append(PLMSearchQueries.PART_FAMILY_ATTR_KIT_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry7.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT7).append(PLMSearchQueries.PART_FAMILY_ATTR_SYNT_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry8.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT8).append(PLMSearchQueries.PART_FAMILY_ATTR_VNDR_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry9.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT9).append(PLMSearchQueries.PART_FAMILY_ATTR_T_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry10.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT10).append(PLMSearchQueries.PART_FAMILY_ATTR_KIT_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry11.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT11).append(PLMSearchQueries.PART_FAMILY_ATTR_SYNT_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry12.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT12).append(PLMSearchQueries.PART_FAMILY_ATTR_VNDR_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry13.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT13).append(PLMSearchQueries.PART_FAMILY_ATTR_T_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry14.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT14).append(PLMSearchQueries.PART_FAMILY_ATTR_KIT_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry15.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT15).append(PLMSearchQueries.PART_FAMILY_ATTR_SYNT_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry16.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT16).append(PLMSearchQueries.PART_FAMILY_ATTR_VNDR_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry17.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT17).append(PLMSearchQueries.PART_FAMILY_ATTR_KIT_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry18.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT18).append(PLMSearchQueries.PART_FAMILY_ATTR_SYNT_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry19.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT19).append(PLMSearchQueries.PART_FAMILY_ATTR_VNDR_PART_HIGH_REV).append(paramVal1).append(paramVal2).append(grpBy);
	}else if(optionType.equalsIgnoreCase("Highest Revision-Released Parts")){
		LOG.info("Entering into Highest Revision-Released Parts of optionType >>>>>>>>>>>>>>>"+optionType);
			partFamilyMstrQry1.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT1).append(PLMSearchQueries.PART_FAMILY_ATTR_T_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry2.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT2).append(PLMSearchQueries.PART_FAMILY_ATTR_KIT_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry3.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT3).append(PLMSearchQueries.PART_FAMILY_ATTR_SYNT_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry4.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT4).append(PLMSearchQueries.PART_FAMILY_ATTR_VNDR_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry5.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT5).append(PLMSearchQueries.PART_FAMILY_ATTR_T_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry6.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT6).append(PLMSearchQueries.PART_FAMILY_ATTR_KIT_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry7.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT7).append(PLMSearchQueries.PART_FAMILY_ATTR_SYNT_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry8.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT8).append(PLMSearchQueries.PART_FAMILY_ATTR_VNDR_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry9.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT9).append(PLMSearchQueries.PART_FAMILY_ATTR_T_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry10.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT10).append(PLMSearchQueries.PART_FAMILY_ATTR_KIT_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry11.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT11).append(PLMSearchQueries.PART_FAMILY_ATTR_SYNT_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry12.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT12).append(PLMSearchQueries.PART_FAMILY_ATTR_VNDR_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry13.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT13).append(PLMSearchQueries.PART_FAMILY_ATTR_T_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry14.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT14).append(PLMSearchQueries.PART_FAMILY_ATTR_KIT_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry15.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT15).append(PLMSearchQueries.PART_FAMILY_ATTR_SYNT_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry16.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT16).append(PLMSearchQueries.PART_FAMILY_ATTR_VNDR_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry17.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT17).append(PLMSearchQueries.PART_FAMILY_ATTR_KIT_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry18.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT18).append(PLMSearchQueries.PART_FAMILY_ATTR_SYNT_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy).append(" UNION ALL ");
			partFamilyMstrQry19.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_RESULT19).append(PLMSearchQueries.PART_FAMILY_ATTR_VNDR_PART_HIGH_REV_REL).append(paramVal1).append(paramVal2).append(grpBy);
		}

		partFamilyMstrQry20.append(" ) X ) ")
				.append(" WITH DATA PRIMARY INDEX  (PART_ID) ON COMMIT PRESERVE ROWS ");

		partFamilyMstrQryFinalVT.append(partFamilyMstrVt).append(partFamilyMstrQry1).append(partFamilyMstrQry2).append(partFamilyMstrQry3);
		
		partFamilyMstrQryFinalVT.append(partFamilyMstrQry4).append(partFamilyMstrQry5).append(partFamilyMstrQry6).append(partFamilyMstrQry7);
		
		partFamilyMstrQryFinalVT.append(partFamilyMstrQry8).append(partFamilyMstrQry9).append(partFamilyMstrQry10).append(partFamilyMstrQry11);
		
		partFamilyMstrQryFinalVT.append(partFamilyMstrQry12).append(partFamilyMstrQry13).append(partFamilyMstrQry14).append(partFamilyMstrQry15);
		
		partFamilyMstrQryFinalVT.append(partFamilyMstrQry16).append(partFamilyMstrQry17).append(partFamilyMstrQry18).append(partFamilyMstrQry19);
		
		partFamilyMstrQryFinalVT.append(partFamilyMstrQry20);
		try
		{
		LOG.info("Executing create volatile Query :VT_PART_FAM_ATTR_MASTER  "
				+ partFamilyMstrQryFinalVT + "\n");
		getJdbcTemplate().execute(partFamilyMstrQryFinalVT.toString());
		
		LOG.info("Query for getting Attribute Master Result List::"+PLMSearchQueries.PART_FAMILY_ATTR_MASTER_LIST.replace(PLMConstants.VT_PART_MSTR, VT_PART_MSTR));
		attrbuteNameList = getJdbcTemplate().queryForList(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_LIST.replace(PLMConstants.VT_PART_MSTR, VT_PART_MSTR),String.class);

		selAttributeList =attrbuteNameList;
		
		partFamilyVtPartsVT.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_FINALDT_VT_1.replace(PLMConstants.VT_FINALDT, VT_FINALDT));
		for(int i=0;i<attrbuteNameList.size();i++){
			partFamilyVtPartsVT.append(",ATTRIB"+i+" VARCHAR(255)");
		}
		partFamilyVtPartsVT.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_FINALDT_VT_2);
		LOG.info("Executing create volatile Query :VT Part Final "+ partFamilyVtPartsVT + "\n");
		getJdbcTemplate().execute(partFamilyVtPartsVT.toString());
		
		partFamilyMstrVtRows.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_ROWS.replace(PLMConstants.VT_PART_MSTR, VT_PART_MSTR).replace(PLMConstants.VT_PARTS, VT_PARTS));
		LOG.info("Executing create volatile Query :partFamilyMstrVt parts  "+ partFamilyMstrVtRows + "\n");
		getJdbcTemplate().execute(partFamilyMstrVtRows.toString());
		
		LOG.info("Executing Count Query :partFamilyMstrVt  "+ PLMSearchQueries.PART_FAMILY_ATTR_MASTER_ROWS_COUNT.replace(PLMConstants.VT_PARTS, VT_PARTS) + "\n");
		int resultCount = getJdbcTemplate().queryForInt(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_ROWS_COUNT.replace(PLMConstants.VT_PARTS, VT_PARTS));

		int vtCntInt =1;
		int vtCntIncr=Integer.parseInt(resourceBundle.getString("PART_FMY_VIEW_LOOP_CNT"));
		int vtCntLimit=Integer.parseInt(resourceBundle.getString("PART_FMY_VIEW_LOOP_CNT"));
		int val = 0;
		int loopCount = 0;

		if(resultCount <=vtCntLimit){
			loopCount = 1;
		}else{
			loopCount = resultCount/vtCntLimit;				
			val = resultCount - (vtCntLimit * loopCount);
			  if (val > 0) {
				loopCount++;					
			   }
		}

		List<PLMInterfaceAttrData> tempfinalResultList = new ArrayList<PLMInterfaceAttrData>();
		List<PLMInterfaceAttrData> tempResultList = new ArrayList<PLMInterfaceAttrData>();
		PLMInterfaceAttrData attributeData = new PLMInterfaceAttrData();
		PLMInterfaceAttrData tempData = new PLMInterfaceAttrData();
		List<PLMInterfaceAttrData> attributeResultList = new ArrayList<PLMInterfaceAttrData>();

		StringBuffer partFamilyMstrQryFinal = new StringBuffer();
		for (int i=0;i<loopCount;i++) {
			if(vtCntLimit > resultCount){
				vtCntIncr=resultCount;
			 }
			LOG.info("-------------------Loop Rotating from Row key "+vtCntInt +" and "+vtCntIncr);
			
			partFamilyMstrQryFinal = new StringBuffer();
			partFamilyMstrQryFinal.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_FINAL_RESULT_VT_1.replace(PLMConstants.VT_PART_MSTR, VT_PART_MSTR)
					.replace(PLMConstants.VT_PARTS, VT_PARTS))
			.append("  WHERE R_NUM BETWEEN "+ vtCntInt +" AND "+vtCntIncr )
			.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_FINAL_RESULT_VT_2);
			LOG.info("Final Query for partFamilyMstrQryFinalVT Result List::"+partFamilyMstrQryFinal);
			resultList =  getSimpleJdbcTemplate().query(partFamilyMstrQryFinal.toString(),new PartFamilyMasterResultMapper());
			LOG.info("size for partFamilyMstrQryFinalVT Result List::"+resultList.size());
			
			vtCntInt =vtCntInt+Integer.parseInt(resourceBundle.getString("PART_FMY_VIEW_LOOP_CNT"));
			if(vtCntLimit > resultCount){
				vtCntIncr=resultCount;
			 }else{
			  vtCntIncr =vtCntIncr+Integer.parseInt(resourceBundle.getString("PART_FMY_VIEW_LOOP_CNT"));
			 }
			
			String partId="";

			boolean rowMatchFlag=false;
			for(int j=0;j<resultList.size();j++){
				rowMatchFlag=false;
				if(!resultList.get(j).getPartId().equalsIgnoreCase(partId)){
					
					if(!PLMUtils.isEmptyList(attributeResultList)){
						tempData.setAttributeListData(attributeResultList);
						tempResultList.add(tempData);
						rowMatchFlag =true;
					 }

					tempData =new PLMInterfaceAttrData();
					tempData.setPartId(resultList.get(j).getPartId());
					tempData.setPartName(resultList.get(j).getPartName());
					tempData.setPartTitle(resultList.get(j).getPartTitle());
					tempData.setRevision(resultList.get(j).getRevision());
					tempData.setPartType(resultList.get(j).getPartType());
					tempData.setPartState(resultList.get(j).getPartState());		
					tempData.setProdStatus(resultList.get(j).getProdStatus());
					tempData.setProdMakeBuyCd(resultList.get(j).getProdMakeBuyCd());
					tempData.setDesignPurchase(resultList.get(j).getDesignPurchase());
					tempData.setSparePart(resultList.get(j).getSparePart());
					tempData.setMaterialCatgry(resultList.get(j).getMaterialCatgry());
					tempData.setOrign(resultList.get(j).getOrign());
					tempData.setSourceModifiedDt(resultList.get(j).getSourceModifiedDt());
					tempData.setSourceOriginatedDt(resultList.get(j).getSourceOriginatedDt());
					tempData.setUnitMeasure(resultList.get(j).getUnitMeasure());
					tempData.setTargetCost(resultList.get(j).getTargetCost());
					tempData.setEstimatedCost(resultList.get(j).getEstimatedCost());
					tempData.setWeight(resultList.get(j).getWeight());
					tempData.setEndItem(resultList.get(j).getEndItem());
					tempData.setPartClsf(resultList.get(j).getPartClsf());
					tempData.setServiceMakeBuyCd(resultList.get(j).getServiceMakeBuyCd());
					tempData.setGeChemicalCode(resultList.get(j).getGeChemicalCode());
					tempData.setGeBaseDwgNm(resultList.get(j).getGeBaseDwgNm());
					tempData.setGePartMaterialSpec(resultList.get(j).getGePartMaterialSpec());
					tempData.setGePartCmplcStatus(resultList.get(j).getGePartCmplcStatus());
					tempData.setEndItemOverideEnbl(resultList.get(j).getEndItemOverideEnbl());
					tempData.setEffectivityDt(resultList.get(j).getEffectivityDt());
					tempData.setGeSyncDpoStatus(resultList.get(j).getGeSyncDpoStatus());
					tempData.setLeadTime(resultList.get(j).getLeadTime());
					tempData.setEbaseDwgNumNm(resultList.get(j).getEbaseDwgNumNm());
					tempData.setIsAccountable(resultList.get(j).getIsAccountable());
					tempData.setIsSerializable(resultList.get(j).getIsSerializable());
					tempData.setAllLvlMbomGenerate(resultList.get(j).getAllLvlMbomGenerate());
					tempData.setPartFamilyNm(resultList.get(j).getPartFamilyNm());
					tempData.setPartFamilyDescription(resultList.get(j).getPartFamilyDescription());
					tempData.setInterfaceName(resultList.get(j).getInterfaceName());
					tempData.setGeShowinPddr(resultList.get(j).getGeShowinPddr());
					
					
					attributeData =new PLMInterfaceAttrData();
					attributeResultList = new ArrayList<PLMInterfaceAttrData>();
					
					attributeData.setAttributeNm(resultList.get(j).getAttributeNm());
					attributeData.setAttributeValue(resultList.get(j).getAttributeValue());
					attributeResultList.add(attributeData);

			    }else{
			    	attributeData =new PLMInterfaceAttrData();
			    	attributeData.setAttributeNm(resultList.get(j).getAttributeNm());
					attributeData.setAttributeValue(resultList.get(j).getAttributeValue());
					attributeResultList.add(attributeData);
			    }
				
			 partId = resultList.get(j).getPartId();
			}
			
			if(!rowMatchFlag){
				tempData.setAttributeListData(attributeResultList);
				tempResultList.add(tempData);
			}
			
			resultList.clear();
			attributeResultList = new ArrayList<PLMInterfaceAttrData>();
			attributeData =new PLMInterfaceAttrData();
			
			for(int k=0;k<tempResultList.size();k++){
				
				PLMInterfaceAttrData data =new PLMInterfaceAttrData();
				data.setPartId(tempResultList.get(k).getPartId());
				data.setPartName(tempResultList.get(k).getPartName());
				data.setPartTitle(tempResultList.get(k).getPartTitle());
				data.setRevision(tempResultList.get(k).getRevision());
				data.setPartType(tempResultList.get(k).getPartType());
				data.setPartState(tempResultList.get(k).getPartState());		
				data.setProdStatus(tempResultList.get(k).getProdStatus());
				data.setProdMakeBuyCd(tempResultList.get(k).getProdMakeBuyCd());
				data.setDesignPurchase(tempResultList.get(k).getDesignPurchase());
				data.setSparePart(tempResultList.get(k).getSparePart());
				data.setMaterialCatgry(tempResultList.get(k).getMaterialCatgry());
				data.setOrign(tempResultList.get(k).getOrign());
				data.setSourceModifiedDt(tempResultList.get(k).getSourceModifiedDt());
				data.setSourceOriginatedDt(tempResultList.get(k).getSourceOriginatedDt());
				data.setUnitMeasure(tempResultList.get(k).getUnitMeasure());
				data.setTargetCost(tempResultList.get(k).getTargetCost());
				data.setEstimatedCost(tempResultList.get(k).getEstimatedCost());
				data.setWeight(tempResultList.get(k).getWeight());
				data.setEndItem(tempResultList.get(k).getEndItem());
				data.setPartClsf(tempResultList.get(k).getPartClsf());
				data.setServiceMakeBuyCd(tempResultList.get(k).getServiceMakeBuyCd());
				data.setGeChemicalCode(tempResultList.get(k).getGeChemicalCode());
				data.setGeBaseDwgNm(tempResultList.get(k).getGeBaseDwgNm());
				data.setGePartMaterialSpec(tempResultList.get(k).getGePartMaterialSpec());
				data.setGePartCmplcStatus(tempResultList.get(k).getGePartCmplcStatus());
				data.setEndItemOverideEnbl(tempResultList.get(k).getEndItemOverideEnbl());
				data.setEffectivityDt(tempResultList.get(k).getEffectivityDt());
				data.setGeSyncDpoStatus(tempResultList.get(k).getGeSyncDpoStatus());
				data.setLeadTime(tempResultList.get(k).getLeadTime());
				data.setEbaseDwgNumNm(tempResultList.get(k).getEbaseDwgNumNm());
				data.setIsAccountable(tempResultList.get(k).getIsAccountable());
				data.setIsSerializable(tempResultList.get(k).getIsSerializable());
				data.setAllLvlMbomGenerate(tempResultList.get(k).getAllLvlMbomGenerate());
				data.setPartFamilyNm(tempResultList.get(k).getPartFamilyNm());
				data.setPartFamilyDescription(tempResultList.get(k).getPartFamilyDescription());
				data.setInterfaceName(tempResultList.get(k).getInterfaceName());
				data.setGeShowinPddr(tempResultList.get(k).getGeShowinPddr());
				
				 
				attributeResultList = new ArrayList<PLMInterfaceAttrData>();
				
				 for(int attr=0;attr<attrbuteNameList.size();attr++){
					boolean matchFlag=false;
					attributeData =new PLMInterfaceAttrData();
					for(int l=0;l<tempResultList.get(k).getAttributeListData().size();l++){
					   if(attrbuteNameList.get(attr).equalsIgnoreCase(tempResultList.get(k).getAttributeListData().get(l).getAttributeNm())){
						   attributeData.setAttributeValue(tempResultList.get(k).getAttributeListData().get(l).getAttributeValue());
						   attributeResultList.add(attributeData);
						   matchFlag=true;
						   break;
					   }
				   }
					if(!matchFlag){
						attributeData.setAttributeValue("");
					  attributeResultList.add(attributeData);
					}
				}
				 
			  data.setAttributeListData(attributeResultList);
			  tempfinalResultList.add(data);
			}
			
			
			final List<PLMInterfaceAttrData> finalResultList=new ArrayList<PLMInterfaceAttrData>();
			if (!PLMUtils.isEmptyList(tempfinalResultList)) {
				finalResultList.addAll(tempfinalResultList);
			}
			
			int[] insertCount =null;
			StringBuffer setVTFinalQuery = new StringBuffer();
			StringBuffer setVTValues = new StringBuffer();
			setVTFinalQuery.append("INSERT INTO "+ VT_FINALDT+"(PART_ID");
			setVTValues.append("VALUES(?");
			for(int attr=0;attr<attrbuteNameList.size();attr++){
				setVTFinalQuery.append(",ATTRIB"+attr);
				setVTValues.append(",?");
			}
			setVTFinalQuery.append(")");
			setVTValues.append(")");
			
			setVTFinalQuery.append(setVTValues);
			
			LOG.info("Insert Query :  " + setVTFinalQuery);
			insertCount  = getSimpleJdbcTemplate().getJdbcOperations().batchUpdate(setVTFinalQuery.toString(),new BatchPreparedStatementSetter() 
			{
			public void setValues(PreparedStatement ps,int iCount)throws SQLException {
			ps.setString(1, finalResultList.get(iCount).getPartId());
			int counter =2;
			final List<PLMInterfaceAttrData> attribList=finalResultList.get(iCount).getAttributeListData();
			for(PLMInterfaceAttrData attributeData:attribList){
				ps.setString(counter,attributeData.getAttributeValue());
				counter++;
			 }
			}
			public int getBatchSize() {
				return finalResultList.size();
			}
			});
			
			if(tempfinalResultList.size()==insertCount.length){
				LOG.info("Successfully Added" );
			}
			
			finalResultList.clear();
			tempResultList.clear();
			tempfinalResultList.clear();
			attributeResultList.clear();
			
		}

		StringBuffer finalResultDataQry =new StringBuffer();
		
		finalResultDataQry.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_FINAL_DATA1);
		for(int attr=0;attr<attrbuteNameList.size();attr++){
			finalResultDataQry.append(",VT1.ATTRIB"+attr);
		}
		finalResultDataQry.append(PLMSearchQueries.PART_FAMILY_ATTR_MASTER_FINAL_DATA2.replace(PLMConstants.VT_FINALDT, VT_FINALDT)
				.replace(PLMConstants.VT_PARTS, VT_PARTS));
		
		LOG.info("Final Query for finalResultDataQry Result List::"+finalResultDataQry);
		finalresultList =  getSimpleJdbcTemplate().query(finalResultDataQry.toString(),new PartFamilyMasterResultMapper1());

		LOG.info("finalResultDataQry Result List Size::"+finalresultList.size());

		
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		//String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + PLMConstants.PART_FAMILY_ATTR_MASTER_NAME + "_" + selectedPartFamily + "_" + uniqTime + ".xlsx";
		//String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + PLMConstants.PART_FAMILY_ATTR_MASTER_NAME + "_" + selectedPartFamily + "_" + uniqTime + ".zip";
		String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + PLMConstants.PART_FAMILY_ATTR_MASTER_NAME + "_" + uniqTime + ".xlsx";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + PLMConstants.PART_FAMILY_ATTR_MASTER_NAME + "_" + uniqTime + ".zip";

		savePartFamilyExcel(partFamilyIntAttrData.getSelectedPartFamily(),partFamilyIntAttrData.getSelectedPartNum(),partFamilyIntAttrData.getPartNumlist(),
				finalresultList,attrbuteNameList,filePathXls,hyperLinkFlag,partAttribFlag,partFamilyAttribFlag);
		PLMUtils.generateZipFile(filePathXls,filePathZip);
		filepathMap.put("filePathXls", filePathXls);
		filepathMap.put("filePathZip", filePathZip);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return filepathMap;
		
	}
	
	public void savePartFamilyExcel(String selectedPartFamily,String selectedPartNum,List<String> partNumList,List<PLMInterfaceAttrData> resultList,
			List<String> resultListForAttribute,String filePathXls,boolean hyperLinkFlg,boolean partAttribFlag,boolean partFamilyAttribFlag)
			throws IOException {
		LOG.info("Entering savePartFamilyExcel Method");
		FileOutputStream fileOut = null;
		boolean createFileExist;
		 List<PLMInterfaceAttrData> resultListLcl = resultList;
		 List<String> resultListForAttributeLcl = resultListForAttribute;
		try {
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist = fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXls);
				SXSSFWorkbook workbook = null;
				SXSSFSheet sheet = null;
				SXSSFCell cell = null;
				workbook = new SXSSFWorkbook();
			
				if (workbook != null) {
				sheet = (SXSSFSheet) workbook.createSheet("Part Family Attribute Master");
				sheet.createFreezePane(0, 1);
				XSSFFont fontstyle = (XSSFFont) workbook.createFont();
				fontstyle.setFontName(PLMConstants.EXCEL_FONT_NAME);

				XSSFCellStyle unLockedTextStyle = (XSSFCellStyle) workbook.createCellStyle();
				unLockedTextStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				unLockedTextStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				unLockedTextStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
				unLockedTextStyle.setBorderTop((HSSFCellStyle.BORDER_THIN));
				unLockedTextStyle.setFont(fontstyle);
				unLockedTextStyle.setWrapText(true);
				unLockedTextStyle.setLocked(false);
				unLockedTextStyle.setAlignment(CellStyle.ALIGN_CENTER);

				XSSFCellStyle headerStyle1 = (XSSFCellStyle) workbook.createCellStyle();
				headerStyle1.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				headerStyle1.setBorderLeft(HSSFCellStyle.BORDER_THIN);
				headerStyle1.setBorderRight(HSSFCellStyle.BORDER_THIN);
				headerStyle1.setBorderTop((HSSFCellStyle.BORDER_THIN));
				headerStyle1.setFillForegroundColor(HSSFColor.PALE_BLUE.index);

				// cell hyper link
				XSSFCreationHelper helper= (XSSFCreationHelper) workbook.getCreationHelper();
			    XSSFFont underLinedFont = (XSSFFont) workbook.createFont();
		        underLinedFont.setUnderline(HSSFFont.U_SINGLE);
		        underLinedFont.setColor(IndexedColors.BLUE.getIndex());
				XSSFCellStyle hyperLinkStyle = (XSSFCellStyle) workbook.createCellStyle();				
				hyperLinkStyle = setBorderStyle(hyperLinkStyle);
				hyperLinkStyle.setAlignment(CellStyle.ALIGN_CENTER);
				hyperLinkStyle.setFont(underLinedFont);

				
				XSSFFont font = headerFont(workbook, 11);
				XSSFCellStyle headerStyle =headerCell(workbook, font, HSSFColor.PALE_BLUE.index, true);
				
				int rowcount = -1;
				
				if (!PLMUtils.isEmptyList(resultListLcl)) {
					
					String[] colNames1 = { "Part Number", "Part Revision","Part State",
							"Part Description","Production Status","Production Make Buy CD", 
							"Design Purchase","Spare Part","Material Category","Orig","Source Modified Date","Soruce Originated Date",
							"Unit Measure","Target Cost","Estimated Cost","Weight","End Item","Part CLSF","Service Make Buy CD",
							"GE Chemical code","GE Base Dwg Num","GE Part Material Spec","GE Part Compliance Status",
							"End Item Override Enabled","Effectivity Date","GE Sync DPO Parts","Lead Time","GE Base Dwg Name",
							"Is Accountable","Is Serialized","All Level MBOM Generated","Part Family","Part Family Description","GE Show in PDDR"};
					
					String[] colNames2 = { "Part Number", "Part Revision","Part State",
							"Part Description","Production Status","Unit Measure",
							"Part Family","Part Family Description","GE Show in PDDR"};

					SXSSFRow row = (SXSSFRow) sheet.createRow(++rowcount);

					int countFrHead =0;
					
					if(partAttribFlag){
						for (int i = 0; i < colNames1.length; i++) {
							cell = (SXSSFCell) row.createCell(i);
							cell.setCellValue(colNames1[i]);
							cell.setCellStyle(headerStyle);
							countFrHead = colNames1.length;	
						}
					}else{
						for (int i = 0; i < colNames2.length; i++) {
						cell = (SXSSFCell) row.createCell(i);
						cell.setCellValue(colNames2[i]);
						cell.setCellStyle(headerStyle);
						countFrHead = colNames2.length;	
						}
					}
					
					
					if(partFamilyAttribFlag){
						
						for (int k = 0; k < resultListForAttributeLcl.size();k++) {
							cell = (SXSSFCell) row.createCell(countFrHead);
							cell.setCellValue(resultListForAttributeLcl.get(k));
							headerStyle1.setRotation((short)60);
							cell.setCellStyle(headerStyle1);
							countFrHead = countFrHead +1;
						}
					}

					for (PLMInterfaceAttrData plmInterfaceAttrData:resultListLcl) {
					    
						 row = (SXSSFRow) sheet.createRow(++rowcount);
					    
						 if(hyperLinkFlg){
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
							if(!PLMUtils.isEmpty(plmInterfaceAttrData.getPartId())){
								cell.setCellStyle(hyperLinkStyle);
								XSSFHyperlink url_link = helper.createHyperlink(Hyperlink.LINK_URL);
								url_link.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ plmInterfaceAttrData.getPartId());
								cell.setHyperlink(url_link);
								cell.setCellValue(plmInterfaceAttrData.getPartName());
							}else{
								 cell.setCellStyle(unLockedTextStyle);
								 cell.setCellValue("");
							}
						 }else{
						 cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
						 cell.setCellStyle(unLockedTextStyle);
						 cell.setCellValue(plmInterfaceAttrData.getPartName());
						 }

						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(plmInterfaceAttrData.getRevision());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(plmInterfaceAttrData.getPartState());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(plmInterfaceAttrData.getPartTitle());
						
						cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
						cell.setCellStyle(unLockedTextStyle);
						cell.setCellValue(plmInterfaceAttrData.getProdStatus());
						
						int counter = 0;
						
						if(partAttribFlag){
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getProdMakeBuyCd());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getDesignPurchase());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getSparePart());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getMaterialCatgry());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getOrign());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getSourceModifiedDt());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getSourceOriginatedDt());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWELVE);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getUnitMeasure());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THIRTEEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getTargetCost());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOURTEEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getEstimatedCost());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIFTEEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getWeight());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIXTEEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getEndItem());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVENTEEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getPartClsf());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHTEEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getServiceMakeBuyCd());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINETEEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getGeChemicalCode());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWENTY);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getGeBaseDwgNm());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWENTYONE);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getGePartMaterialSpec());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWENTYTWO);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getGePartCmplcStatus());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWENTYTHREE);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getEndItemOverideEnbl());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWENTYFOUR);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getEffectivityDt());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWENTYFIVE);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getGeSyncDpoStatus());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWENTYSIX);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getLeadTime());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWENTYSEVEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getEbaseDwgNumNm());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWENTYEIGHT);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getIsAccountable());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWENTYNINE);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getIsSerializable());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THIRTY);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getAllLvlMbomGenerate());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THIRTYONE);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getPartFamilyNm());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THIRTYTWO);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getPartFamilyDescription());
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THIRTYTHREE);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getGeShowinPddr());
							
							counter = PLMConstants.EXCEL_COL_THIRTYFOUR;
						}else{
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getUnitMeasure());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getPartFamilyNm());
	
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getPartFamilyDescription());
							
							cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
							cell.setCellStyle(unLockedTextStyle);
							cell.setCellValue(plmInterfaceAttrData.getGeShowinPddr());
							
							counter = PLMConstants.EXCEL_COL_NINE;
						}
						
						if(partFamilyAttribFlag){
	
							String[] attribueVal = plmInterfaceAttrData.getAttributeValArr();
							
							for (int i=0;i<attribueVal.length;i++) {
								cell = (SXSSFCell) row.createCell(counter);
								cell.setCellStyle(unLockedTextStyle);
								cell.setCellValue(attribueVal[i]);
								counter++;
							}
						}
						
					}
					short colWidth = (short) 6400;
					short colWidth1 = (short) 6700;
					short colWidth2 = (short) 4000;
					short colWidth4 = (short) 6000;
					
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, colWidth4);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE, colWidth1);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TEN, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_ELEVEN, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWELVE, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTEEN, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOURTEEN, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIFTEEN, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIXTEEN, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVENTEEN, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHTEEN, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINETEEN, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTY, colWidth2);
					
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYONE, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYTWO, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYTHREE, colWidth2);
					
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYFOUR, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYFIVE, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYSIX, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYSEVEN, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYEIGHT, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWENTYNINE, colWidth2);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTY, colWidth2);
					
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYONE, colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYTWO, colWidth);
					sheet.setColumnWidth(PLMConstants.EXCEL_COL_THIRTYTHREE, colWidth);
					sheet.setZoom(4,5);
				}else {
					SXSSFRow row = (SXSSFRow) sheet.createRow(++rowcount);
					SXSSFCell cell1 = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO); 
					String noRecordMsg="";
					if(!PLMUtils.isEmpty(selectedPartFamily) && !PLMUtils.isEmpty(selectedPartNum)){
					noRecordMsg = PLMConstants.PART_FAMILY_ATTR_MASTER_NO_RECORD_FOUND + " Part Family : " +selectedPartFamily +" and Part Numbers : "+partNumList;
					}else if(!PLMUtils.isEmpty(selectedPartFamily) && PLMUtils.isEmpty(selectedPartNum)){
					noRecordMsg = PLMConstants.PART_FAMILY_ATTR_MASTER_NO_RECORD_FOUND + " Part Family : " +selectedPartFamily;
					}else if(PLMUtils.isEmpty(selectedPartFamily) && !PLMUtils.isEmpty(selectedPartNum)){
						noRecordMsg = PLMConstants.PART_FAMILY_ATTR_MASTER_NO_RECORD_FOUND + " Part Numbers : "+partNumList;
					}
					cell1.setCellValue(noRecordMsg);
					
					cell1.setCellStyle(unLockedTextStyle);
					sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
				}
				
				workbook.write(fileOut);
				fileOut.close();
			    }
		} 
		}catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@savePartFamilyExcel: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@savePartFamilyExcel: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@savePartFamilyExcel: ", e);
				throw e;
			}
		}
		LOG.info("Exiting savePartFamilyExcel Method");
	}

	
	 private XSSFFont headerFont(SXSSFWorkbook workbook, int size){
			XSSFFont font = (XSSFFont) workbook.createFont();
			font.setFontName(PLMConstants.EXCEL_FONT_NAME);
			font.setFontHeightInPoints((short)size);
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			return font;
		}
	 
		private XSSFCellStyle headerCell(SXSSFWorkbook workbook, XSSFFont font, short bgcolor, boolean wrap){
			XSSFCellStyle hCell = normalCell(workbook, font, XSSFCellStyle.SOLID_FOREGROUND, wrap);
			//FONT
			hCell.setFont(font);
			
			//HORIZONTAL ALIGNMENT
			hCell.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			
			//COLOR
			hCell.setFillForegroundColor(bgcolor);
			return hCell;
		}

		
		private XSSFCellStyle normalCell(SXSSFWorkbook workbook, XSSFFont font, short fillPattern, boolean wrap){
			// Cell Style
			XSSFCellStyle cellStyle = (XSSFCellStyle)workbook.createCellStyle();
			
			//Set Font
			cellStyle.setFont(font);
			//WRAP TEXT
			cellStyle.setWrapText(wrap);
			
			//VERTICAL ALIGNMENT
			cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			
			//BORDERS
			cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			
			//FILL PATTERN
			cellStyle.setFillPattern(fillPattern);
			return cellStyle;
		}
		
		/**
		 * This method is used for Bordering Cell in XLS
		 * 
		 * @return StringBuffer
		 */

		private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
			style.setBorderTop(HSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style.setBorderRight(HSSFCellStyle.BORDER_THIN);
			return style;
		}
		
		/**
		 * @return .
		 */
		private static final class PartFamilyMasterResultMapper implements ParameterizedRowMapper<PLMInterfaceAttrData> {
				public PLMInterfaceAttrData mapRow(ResultSet rs, int rowCount) throws SQLException {
					PLMInterfaceAttrData resultList = new PLMInterfaceAttrData();
					resultList.setPartId(PLMUtils.checkNullVal(rs.getString("PART_ID")));
					resultList.setPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
					resultList.setPartTitle(PLMUtils.checkNullVal(rs.getString("PART_TITLE")));
					resultList.setRevision(PLMUtils.checkNullVal(rs.getString("REVISION")));
					resultList.setPartType(PLMUtils.checkNullVal(rs.getString("PART_TYPE")));
					resultList.setPartState(PLMUtils.checkNullVal(rs.getString("PART_STATE")));		
					resultList.setProdStatus(PLMUtils.checkNullVal(rs.getString("PRODUCTION_STATUS")));
					resultList.setProdMakeBuyCd(PLMUtils.checkNullVal(rs.getString("PRODUCTION_MAKE_BUY_CD")));
					resultList.setDesignPurchase(PLMUtils.checkNullVal(rs.getString("DESIGN_PURCHASE")));
					resultList.setSparePart(PLMUtils.checkNullVal(rs.getString("SPARE_PART")));
					resultList.setMaterialCatgry(PLMUtils.checkNullVal(rs.getString("MTRL_CATEGORY")));
					resultList.setOrign(PLMUtils.checkNullVal(rs.getString("ORIG")));
					resultList.setSourceModifiedDt(PLMUtils.checkNullVal(rs.getString("SOURCE_MODIFIED_DT")));
					resultList.setSourceOriginatedDt(PLMUtils.checkNullVal(rs.getString("SOURCE_ORIGINATED_DT")));
					resultList.setUnitMeasure(PLMUtils.checkNullVal(rs.getString("UNIT_MEASURE")));
					resultList.setTargetCost(PLMUtils.checkNullVal(rs.getString("TARGET_COST")));
					resultList.setEstimatedCost(PLMUtils.checkNullVal(rs.getString("ESTIMATED_COST")));
					resultList.setWeight(PLMUtils.checkNullVal(rs.getString("WEIGHT")));
					resultList.setEndItem(PLMUtils.checkNullVal(rs.getString("END_ITEM")));
					resultList.setPartClsf(PLMUtils.checkNullVal(rs.getString("PART_CLSF")));
					resultList.setServiceMakeBuyCd(PLMUtils.checkNullVal(rs.getString("SERVICE_MAKE_BUY_CD")));
					resultList.setGeChemicalCode(PLMUtils.checkNullVal(rs.getString("GE_CHEMICAL_CODE")));
					resultList.setGeBaseDwgNm(PLMUtils.checkNullVal(rs.getString("GE_BASE_DWG_NUM")));
					resultList.setGePartMaterialSpec(PLMUtils.checkNullVal(rs.getString("GE_PART_MATERIAL_SPEC")));
					resultList.setGePartCmplcStatus(PLMUtils.checkNullVal(rs.getString("GE_PART_CMPLC_STATUS")));
					resultList.setEndItemOverideEnbl(PLMUtils.checkNullVal(rs.getString("END_ITEM_OVERRIDE_ENABLED")));
					resultList.setEffectivityDt(PLMUtils.checkNullVal(rs.getString("EFFECTIVITY_DT")));
					resultList.setGeSyncDpoStatus(PLMUtils.checkNullVal(rs.getString("GE_SYNC_DPO_PARTS")));
					resultList.setLeadTime(PLMUtils.checkNullVal(rs.getString("LEAD_TIME")));
					resultList.setEbaseDwgNumNm(PLMUtils.checkNullVal(rs.getString("GE_BASE_DWG_NUM_NAME")));
					resultList.setIsAccountable(PLMUtils.checkNullVal(rs.getString("IS_ACCOUNTABLE")));
					resultList.setIsSerializable(PLMUtils.checkNullVal(rs.getString("IS_SERIALIZED")));
					resultList.setAllLvlMbomGenerate(PLMUtils.checkNullVal(rs.getString("ALL_LEVEL_MBOM_GENERATED")));
					resultList.setPartFamilyNm(PLMUtils.checkNullVal(rs.getString("PART_FAMILY_NM")));
					resultList.setPartFamilyDescription(PLMUtils.checkNullVal(rs.getString("PART_FAMILY_DESCRIPTION")));
					resultList.setInterfaceName(PLMUtils.checkNullVal(rs.getString("INTERFACE_NAME")));
					//resultList.setAttributeGroup(PLMUtils.checkNullVal(rs.getString("ATTRIBUTE_GROUP")));
					//resultList.setAttributeNm(PLMUtils.checkNullVal(rs.getString("ATTRIBUTE_LIST")));
					resultList.setGeShowinPddr(PLMUtils.checkNullVal(rs.getString("GE_SHOW_IN_PDDR")));
					resultList.setAttributeNm(PLMUtils.checkNullVal(rs.getString("ATTRIBUTE_NM")));
					resultList.setAttributeValue(PLMUtils.checkNullVal(rs.getString("ATTRIBUTE_VALUE")));
				return resultList;
				}
		}
		
		/**
		 * @return .
		 */
			private static final class PartFamilyMasterResultMapper1 implements ParameterizedRowMapper<PLMInterfaceAttrData> {
				public PLMInterfaceAttrData mapRow(ResultSet rs, int rowCount) throws SQLException {
					PLMInterfaceAttrData resultList = new PLMInterfaceAttrData();
					String[] attributeVal=new String[selAttributeList.size()]; 
					resultList.setPartId(PLMUtils.checkNullVal(rs.getString("PART_ID")));
					resultList.setPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
					resultList.setPartTitle(PLMUtils.checkNullVal(rs.getString("PART_TITLE")));
					resultList.setRevision(PLMUtils.checkNullVal(rs.getString("REVISION")));
					resultList.setPartType(PLMUtils.checkNullVal(rs.getString("PART_TYPE")));
					resultList.setPartState(PLMUtils.checkNullVal(rs.getString("PART_STATE")));		
					resultList.setProdStatus(PLMUtils.checkNullVal(rs.getString("PRODUCTION_STATUS")));
					resultList.setProdMakeBuyCd(PLMUtils.checkNullVal(rs.getString("PRODUCTION_MAKE_BUY_CD")));
					resultList.setDesignPurchase(PLMUtils.checkNullVal(rs.getString("DESIGN_PURCHASE")));
					resultList.setSparePart(PLMUtils.checkNullVal(rs.getString("SPARE_PART")));
					resultList.setMaterialCatgry(PLMUtils.checkNullVal(rs.getString("MTRL_CATEGORY")));
					resultList.setOrign(PLMUtils.checkNullVal(rs.getString("ORIG")));
					resultList.setSourceModifiedDt(PLMUtils.checkNullVal(rs.getString("SOURCE_MODIFIED_DT")));
					resultList.setSourceOriginatedDt(PLMUtils.checkNullVal(rs.getString("SOURCE_ORIGINATED_DT")));
					resultList.setUnitMeasure(PLMUtils.checkNullVal(rs.getString("UNIT_MEASURE")));
					resultList.setTargetCost(PLMUtils.checkNullVal(rs.getString("TARGET_COST")));
					resultList.setEstimatedCost(PLMUtils.checkNullVal(rs.getString("ESTIMATED_COST")));
					resultList.setWeight(PLMUtils.checkNullVal(rs.getString("WEIGHT")));
					resultList.setEndItem(PLMUtils.checkNullVal(rs.getString("END_ITEM")));
					resultList.setPartClsf(PLMUtils.checkNullVal(rs.getString("PART_CLSF")));
					resultList.setServiceMakeBuyCd(PLMUtils.checkNullVal(rs.getString("SERVICE_MAKE_BUY_CD")));
					resultList.setGeChemicalCode(PLMUtils.checkNullVal(rs.getString("GE_CHEMICAL_CODE")));
					resultList.setGeBaseDwgNm(PLMUtils.checkNullVal(rs.getString("GE_BASE_DWG_NUM")));
					resultList.setGePartMaterialSpec(PLMUtils.checkNullVal(rs.getString("GE_PART_MATERIAL_SPEC")));
					resultList.setGePartCmplcStatus(PLMUtils.checkNullVal(rs.getString("GE_PART_CMPLC_STATUS")));
					resultList.setEndItemOverideEnbl(PLMUtils.checkNullVal(rs.getString("END_ITEM_OVERRIDE_ENABLED")));
					resultList.setEffectivityDt(PLMUtils.checkNullVal(rs.getString("EFFECTIVITY_DT")));
					resultList.setGeSyncDpoStatus(PLMUtils.checkNullVal(rs.getString("GE_SYNC_DPO_PARTS")));
					resultList.setLeadTime(PLMUtils.checkNullVal(rs.getString("LEAD_TIME")));
					resultList.setEbaseDwgNumNm(PLMUtils.checkNullVal(rs.getString("GE_BASE_DWG_NUM_NAME")));
					resultList.setIsAccountable(PLMUtils.checkNullVal(rs.getString("IS_ACCOUNTABLE")));
					resultList.setIsSerializable(PLMUtils.checkNullVal(rs.getString("IS_SERIALIZED")));
					resultList.setAllLvlMbomGenerate(PLMUtils.checkNullVal(rs.getString("ALL_LEVEL_MBOM_GENERATED")));
					resultList.setPartFamilyNm(PLMUtils.checkNullVal(rs.getString("PART_FAMILY_NM")));
					resultList.setPartFamilyDescription(PLMUtils.checkNullVal(rs.getString("PART_FAMILY_DESCRIPTION")));
					resultList.setInterfaceName(PLMUtils.checkNullVal(rs.getString("INTERFACE_NAME")));
					//resultList.setAttributeGroup(PLMUtils.checkNullVal(rs.getString("ATTRIBUTE_GROUP")));
					//resultList.setAttributeNm(PLMUtils.checkNullVal(rs.getString("ATTRIBUTE_LIST")));
					resultList.setGeShowinPddr(PLMUtils.checkNullVal(rs.getString("GE_SHOW_IN_PDDR")));
					//resultList.setAttributeNm(PLMUtils.checkNullVal(rs.getString("ATTRIBUTE_NM")));
					//resultList.setAttributeValue(PLMUtils.checkNullVal(rs.getString("ATTRIBUTE_VALUE")));
					
					for (int i = 0; i < selAttributeList.size();i++){
						attributeVal [i]=PLMUtils.checkNullVal(rs.getString("ATTRIB"+i));	
						}
					resultList.setAttributeValArr(attributeVal);
					
				return resultList;
				}
		   }
		/**
		 * @return the resourceBundle
		 */
		public ResourceBundle getResourceBundle() {
			return resourceBundle;
		}

		/**
		 * @param resourceBundle the resourceBundle to set
		 */
		public void setResourceBundle(ResourceBundle resourceBundle) {
			this.resourceBundle = resourceBundle;
		}


}
