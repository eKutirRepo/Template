/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMStGenDlvrblRptDaoImpl.java
 * @Creation date: 28-May-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMBomSpecPartData;
import com.geinfra.geaviation.pwi.data.PLMMessageData;
import com.geinfra.geaviation.pwi.data.PLMRouteTaskOwnerData;
import com.geinfra.geaviation.pwi.data.PLMSalesOrderData;
import com.geinfra.geaviation.pwi.data.PLMTaskDlvrblData;
import com.geinfra.geaviation.pwi.data.PLMTaskRouteData;
import com.geinfra.geaviation.pwi.util.PLMDlvrblRptQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMStGenDlvrblRptDaoImpl extends SimpleJdbcDaoSupport implements PLMStGenDlvrblRptDaoIfc {
	

	// PROPERTIES *************************************************************
	
	/**
	 * Logger
	 */
	private static Logger logger = Logger.getLogger(PLMStGenDlvrblRptDaoImpl.class);
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
		 
	}
	//PRIVATE METHODS *********************************************************	
	
	private List<PLMTaskDlvrblData> getDeliverables(String tableName, String tableAlias, String projectName){
		logger.info("Entering into getDeliverables()");
		logger.info("tableName>> "+tableName +" tableAlias>> " +tableAlias +" projectName>> "+ projectName);
		StringBuffer query = new StringBuffer();
		
		query
		.append(PLMDlvrblRptQueries.GET_DELIVRABLES1)
		.append(tableAlias).append(PLMDlvrblRptQueries.GET_DELIVRABLES2)
		.append(tableAlias).append(PLMDlvrblRptQueries.GET_DELIVRABLES3)
		.append(tableAlias).append(PLMDlvrblRptQueries.GET_DELIVRABLES4);

		if (tableName.equals("CDR_ODS_T_DOC")){
			query.append(tableAlias).append(".STATE1 DLVRBL_STATE, ");
		} else {
			query.append(tableAlias).append(".STATE DLVRBL_STATE, ");
		}

		query
		.append(PLMDlvrblRptQueries.GET_DELIVRABLES5).append(tableName+" "+tableAlias).append(PLMDlvrblRptQueries.GET_DELIVRABLES6)
		.append(tableAlias).append(PLMDlvrblRptQueries.GET_DELIVRABLES7);
				
		logger.info(tableName + " query: " + query.toString());
		
		List<PLMTaskDlvrblData> deliverables = getSimpleJdbcTemplate().query(query.toString(),(ParameterizedRowMapper<PLMTaskDlvrblData>) new TaskDeliverableRowMapper(),new Object[] {projectName});
		
		return deliverables;

	}
	
	private static final class TaskDeliverableRowMapper implements ParameterizedRowMapper<PLMTaskDlvrblData> {

		/**
		 * @see org.springframework.jdbc.core.RowMapper
		 * 		#mapRow(java.sql.ResultSet, int)
		 */
		public PLMTaskDlvrblData mapRow(ResultSet rs, int rowNumber) throws SQLException {
			PLMTaskDlvrblData task_deliverable = null;
			
			if (rs != null) {
				task_deliverable = new PLMTaskDlvrblData(
										rs.getString("DLVRBL_TO_ID"),
										rs.getString("DLVRBL_NAME"),
										rs.getString("DLVRBL_REV"),
										rs.getString("DLVRBL_DESCRIPTION"),
										rs.getString("DLVRBL_TYPE"),
										rs.getString("DLVRBL_STATE"),
										rs.getString("TASK_ID"),
										rs.getString("TASK_NAME"),
										rs.getString("TASK_STATE"),
										rs.getString("ESTIMATED_FINISH"),
										rs.getString("ACTUAL_FINISH"),
										rs.getString("TASK_OWNR"),
										rs.getString("PRJ_OWNR")
										);
			}
			
			return task_deliverable;
		}

	}
	
	// IMPLEMENTED METHODS ****************************************************
	
	/**
	 * @see com.ge.energy.reqeng.model.dao.mapper.IEnhandedDeliverablesReportDAO#max_revision()
	 */
	public String max_revision(List<String> topPartsList){
		logger.info("Entering into max_revision()");
		logger.info("topPartsList>> "+ topPartsList.size());
		String maxRevision="000";
	
		try {
			 String strTopParts = "";
				StringBuffer topParts = new StringBuffer();
				for (String topPrts : topPartsList){
					topParts = topParts.append("'").append(topPrts).append("',");
				}
				
				strTopParts = topParts.substring(0, topParts.length()-1);
				logger.info("strTopParts>> "+ strTopParts);
				logger.info("Max Revision query: " + PLMDlvrblRptQueries.GET_MAX_BOM_NUMBER.replace("?", strTopParts));

		    Object bomRev = (String) getJdbcTemplate().queryForObject(PLMDlvrblRptQueries.GET_MAX_BOM_NUMBER.replace("?", strTopParts),String.class);
		    maxRevision = (String) bomRev;
		} catch (EmptyResultDataAccessException e) {
		    e.printStackTrace();
		}

		return maxRevision;
	
	}
	
	/**
	 * @see com.ge.energy.reqeng.model.dao.mapper.IEnhandedDeliverablesReportDAO#tasks_deliverables()
	 */
	public List<PLMTaskDlvrblData> tasks_deliverables(String projectName) {
		logger.info("Entering into tasks_deliverables()");
		logger.info("projectName>> "+ projectName);
		List<PLMTaskDlvrblData> tasks_deliverables = new ArrayList<PLMTaskDlvrblData>();
		// ----------------------------------------------- NO DELIVERALES QUERY --------------------------------------------------------//
		logger.info("No Deliverables() query: " + PLMDlvrblRptQueries.GET_TASK_DELIVRABLES);
		List<PLMTaskDlvrblData>  no_deliverables = getSimpleJdbcTemplate().query(PLMDlvrblRptQueries.GET_TASK_DELIVRABLES,(ParameterizedRowMapper<PLMTaskDlvrblData>) new TaskDeliverableRowMapper(),new Object[] {projectName});
		
		//no_deliverables = (LinkedHashMap<String, TaskDeliverable>)getJdbcTemplate().query(query.toString(), new TaskDeliverableResultSetExtractor());

		if (!PLMUtils.isEmptyList(no_deliverables)) {
			tasks_deliverables.addAll(no_deliverables);
		}
		
		// ----------------------------------------------- PARTS QUERY --------------------------------------------------------//
		List<PLMTaskDlvrblData>  parts = this.getDeliverables("CDR_ODS_T_PART", "TPRT", projectName);
		if (!PLMUtils.isEmptyList(parts)) {
			tasks_deliverables.addAll(parts);
		}
		
		// ----------------------------------------------- DOCUMENTS QUERY --------------------------------------------------------//
		List<PLMTaskDlvrblData>  docs = this.getDeliverables("CDR_ODS_T_DOC", "TDOC", projectName);
		if (!PLMUtils.isEmptyList(docs)) {
			tasks_deliverables.addAll(docs);
		}
		// ----------------------------------------------- GE TECHNICAL DOCUMENTS QUERY --------------------------------------------------------//
		List<PLMTaskDlvrblData>  ge_tech_docs = this.getDeliverables("CDR_ODS_T_GE_TECHNICAL_DOC", "T_TCDC", projectName);
		if (!PLMUtils.isEmptyList(ge_tech_docs)) {
			tasks_deliverables.addAll(ge_tech_docs);
		}
		// ----------------------------------------------- GE PROCEDURES QUERY --------------------------------------------------------//
		List<PLMTaskDlvrblData>  ge_procedures = this.getDeliverables("CDR_ODS_T_GE_PROCEDURE", "T_PRCDR", projectName);
		if (!PLMUtils.isEmptyList(ge_procedures)) {
			tasks_deliverables.addAll(ge_procedures);
		}
		// ----------------------------------------------- ISSSUES QUERY --------------------------------------------------------//
		List<PLMTaskDlvrblData>  issues = this.getDeliverables("CDR_ODS_T_ISSUE", "T_ISS", projectName);
		if (!PLMUtils.isEmptyList(issues)) {
			tasks_deliverables.addAll(issues);
		}		
		// ----------------------------------------------- GE MFG/SVCS KIT PART QUERY --------------------------------------------------------//
		List<PLMTaskDlvrblData>  mfg_svc_parts = this.getDeliverables("CDR_ODS_T_GE_MFG_SVC_KT_PRT", "MSPRT", projectName);
		if (!PLMUtils.isEmptyList(mfg_svc_parts)) {
			tasks_deliverables.addAll(mfg_svc_parts);
		}
		// ----------------------------------------------- Synthetic Part QUERY --------------------------------------------------------//
		List<PLMTaskDlvrblData>  synthetic_parts = this.getDeliverables("CDR_ODS_T_SYNTHETIC_PART", "SPARTS", projectName);
		if (!synthetic_parts.isEmpty()) {
			tasks_deliverables.addAll(synthetic_parts);
		}
		// ----------------------------------------------- GE EXTERNALLY MANAGED QUERY --------------------------------------------------------//
		List<PLMTaskDlvrblData>  ge_ext_managed = this.getDeliverables("CDR_ODS_T_GE_EXT_MANAGED", "T_EXMG", projectName);
		if (!PLMUtils.isEmptyList(ge_ext_managed)) {
			tasks_deliverables.addAll(ge_ext_managed);
		}
		//Order by taskName
		Collections.sort(tasks_deliverables, new Comparator<PLMTaskDlvrblData>() {
			
		    public int compare(PLMTaskDlvrblData one, PLMTaskDlvrblData other) {
		    	String oneTaskName = one.getTaskName();
				String otherTaskName = other.getTaskName();
				
				int comparison = 0;
				
				comparison = oneTaskName.compareTo(otherTaskName);
				
		    	//return one.getTaskName().compareTo(other.getTaskName());
		    	
		    	return comparison;
		    }
		});
		
		return tasks_deliverables;
	}

	
	/**
	 * @see com.ge.energy.reqeng.model.dao.mapper.IEnhandedDeliverablesReportDAO#bom_parts()
	 */
	@SuppressWarnings("unchecked")
	public Map<String, PLMBomSpecPartData> bom_parts(List<String> topPartsList, String genSteamFlag) {
		logger.info("Entering into bom_parts()");
		logger.info("topPartsList >> "+ topPartsList.size());//) +" maxRevision>>" +maxRevision);
		// ----------------------------------------------- TOP LEVEL QUERY --------------------------------------------------------//
		 String strTopParts = "";
			StringBuffer topParts = new StringBuffer();
			for (String topPrts : topPartsList){
				topParts = topParts.append("'").append(topPrts).append("',");
			}
			
			strTopParts = topParts.substring(0, topParts.length()-1);
			logger.info("strTopParts>> "+ strTopParts);
			
			String topPartQry="";
			topPartQry =PLMDlvrblRptQueries.GET_TOP_LVL_DATA.replace("#", strTopParts);
			logger.info("Top Level() query: " + topPartQry);
			
			 Map<String, PLMBomSpecPartData> bom_parts = new HashMap<String, PLMBomSpecPartData>();
			
			if(genSteamFlag.equals("STEAM")){
		      bom_parts = (LinkedHashMap<String, PLMBomSpecPartData>)getJdbcTemplate().query(topPartQry
				,new BomSpecPartResultSteamExtractor());
			}else{
			 bom_parts = (LinkedHashMap<String, PLMBomSpecPartData>)getJdbcTemplate().query(topPartQry
							,new BomSpecPartResultGenExtractor());
			}
		
		// ----------------------------------------------- BOM PARTS QUERY --------------------------------------------------------//
		String bomPartQry="";
		bomPartQry=PLMDlvrblRptQueries.GET_BOM_PART_DATA.replace("#", strTopParts);
		logger.info("Bom Parts() query: " + bomPartQry);
		
		if(genSteamFlag.equals("STEAM")){
		  bom_parts.putAll((LinkedHashMap<String, PLMBomSpecPartData>)getJdbcTemplate().query(bomPartQry,new BomSpecPartResultSteamExtractor()));
		}else{
		  bom_parts.putAll((LinkedHashMap<String, PLMBomSpecPartData>)getJdbcTemplate().query(bomPartQry,new BomSpecPartResultGenExtractor()));
		}
		
		if(genSteamFlag.equalsIgnoreCase("STEAM")){
			String bomPartLwrLvlQry = "";
			bomPartLwrLvlQry=PLMDlvrblRptQueries.GET_BOM_PRT_LWR_LVL_STEAM.replace("#", strTopParts);
			logger.info("Bom Parts() Lower level query: " + bomPartLwrLvlQry);
			bom_parts.putAll((LinkedHashMap<String, PLMBomSpecPartData>)getJdbcTemplate().query(bomPartLwrLvlQry,new BomSpecPartResultSteamExtractor()));
			
		}
		
		return bom_parts;
	}
	
	private static final class  BomSpecPartResultSteamExtractor implements ResultSetExtractor {

		/**
		 * @see org.springframework.jdbc.core.ResultSetExtractor#extractData(java.sql.ResultSet)
		 */
		public Object extractData(ResultSet rs) throws SQLException,
				DataAccessException {
			Map<String, PLMBomSpecPartData> bom_spec_parts = new LinkedHashMap<String, PLMBomSpecPartData>();
			
			if (rs != null) {
				while (rs.next()) {
					PLMBomSpecPartData bom_spec_part = new PLMBomSpecPartData(
												rs.getString("LI"), 
												rs.getString("PART_NAME"),
												rs.getString("PART_REV"),
												rs.getString("PART_STATE"),
												rs.getString("PART_QTY"),
												rs.getString("PART_UoM"),
												rs.getString("PART_DESC")
												);
					
					//bom_spec_parts.put(rs.getString("PART_NAME"), bom_spec_part);
					bom_spec_parts.put(rs.getString("LI"), bom_spec_part);
				}
			}
			
			return bom_spec_parts;
		}

	}
	
	private static final class  BomSpecPartResultGenExtractor implements ResultSetExtractor {

		/**
		 * @see org.springframework.jdbc.core.ResultSetExtractor#extractData(java.sql.ResultSet)
		 */
		public Object extractData(ResultSet rs) throws SQLException,
				DataAccessException {
			Map<String, PLMBomSpecPartData> bom_spec_parts = new LinkedHashMap<String, PLMBomSpecPartData>();
			
			if (rs != null) {
				while (rs.next()) {
					PLMBomSpecPartData bom_spec_part = new PLMBomSpecPartData(
												rs.getString("LI"), 
												rs.getString("PART_NAME"),
												rs.getString("PART_REV"),
												rs.getString("PART_STATE"),
												rs.getString("PART_QTY"),
												rs.getString("PART_UoM"),
												rs.getString("PART_DESC")
												);
					
					bom_spec_parts.put(rs.getString("PART_NAME"), bom_spec_part);
				}
			}
			
			return bom_spec_parts;
		}

	}

	/**
	 * @see com.ge.energy.reqeng.model.dao.mapper.IEnhandedDeliverablesReportDAO#spec_parts()
	 */
	@SuppressWarnings("unchecked")
	public Map<String, PLMBomSpecPartData> spec_parts(List<String> topPartsList,String genSteamFlag) {
		logger.info("Entering into spec_parts()");
		logger.info("topPartsList>> "+ topPartsList.size());// +" maxRevision>>" +maxRevision);

		 String strTopParts = "";
		StringBuffer topParts = new StringBuffer();
		for (String topPrts : topPartsList){
			topParts = topParts.append("'").append(topPrts).append("',");
		}
		
		strTopParts = topParts.substring(0, topParts.length()-1);
		logger.info("strTopParts>> "+ strTopParts);
		// ----------------------------------------------- SPECIFICATION PARTS QUERY --------------------------------------------------------//
		String specPartQry="";
		specPartQry = PLMDlvrblRptQueries.GET_SPEC_PART_DATA.replace("#", strTopParts);
		logger.info("Spec Parts() query: " + specPartQry);
		
		Map<String, PLMBomSpecPartData> spec_parts = new HashMap<String, PLMBomSpecPartData>();
		
		if(genSteamFlag.equals("STEAM")){
		  spec_parts  = (LinkedHashMap<String, PLMBomSpecPartData>)
				  getJdbcTemplate().query(specPartQry,new BomSpecPartResultSteamExtractor());
		}else{
			 spec_parts  = (LinkedHashMap<String, PLMBomSpecPartData>)
					  getJdbcTemplate().query(specPartQry,new BomSpecPartResultGenExtractor());
		}
		//spec_parts = (ArrayList<BomSpecPart>)getJdbcTemplate().query(query.toString(), new BomSpecPartRowMapper());
		return spec_parts;
	}
	
	
	
	/**
	 * @see com.ge.energy.reqeng.model.dao.mapper.IEnhandedDeliverablesReportDAO#messages()
	 */
	public List<PLMMessageData> messages(String projectName) {
		logger.info("Entering into messages()");
		logger.info("projectName>> "+ projectName);
	
		// * * * * * * * * * * * * * D E F I N I T I O N S * * * * * * * * * * * * * * *
		List<PLMMessageData> messages = new ArrayList<PLMMessageData>();
		// * * * * * * * * * * * * * G E T   M E S S A G E S * * * * * * * * * * * * * * *
		logger.info("messages() query: " + PLMDlvrblRptQueries.GET_MESSEGES);
		List<PLMMessageData> msgsList = getSimpleJdbcTemplate().query(PLMDlvrblRptQueries.GET_MESSEGES,(ParameterizedRowMapper<PLMMessageData>) new MessageRowMapper(),new Object[] {projectName});
		
		if (msgsList.isEmpty()){
			return msgsList;
		}
		
		messages.addAll(msgsList);
		
		// * * * * * * * * * * * * * G E T   M E S S A G E S   I D ' s * * * * * * * * * * * * * * *
		
		String messagesIds = "";
		StringBuffer msgIds = new StringBuffer();
		for (PLMMessageData msg : msgsList){
			msgIds = msgIds.append("'").append(msg.getId()).append("',");
			//messagesIds += "'" + msg.getId() + "',";
		}
		
		messagesIds = msgIds.substring(0, msgIds.length()-1);
		logger.info("messagesIds>> "+ messagesIds);
		
		// * * * * * * * * * * * * * G E T   R E P L I E S * * * * * * * * * * * * * * *
		
		logger.info("replies() query: " + PLMDlvrblRptQueries.GET_REPLIES);
		List<PLMMessageData> replyList = getSimpleJdbcTemplate().query((PLMDlvrblRptQueries.GET_REPLIES).replace("#", messagesIds), (ParameterizedRowMapper<PLMMessageData>)  new MessageRowMapper(),new Object[] {projectName});
		messages.addAll(replyList);

		// * * * * * * * * * * * * * O R D E R   B Y * * * * * * * * * * * * * * *
		// * * * * * * * * * T A S K   N A M E  -  D A T E * * * * * * * * * * * * 
		
		Collections.sort(messages, new Comparator<PLMMessageData>() {
		    public int compare(PLMMessageData one, PLMMessageData other) {
		    	String oneTaskName = one.getTaskName();
		    	String otherTaskName = other.getTaskName();
		    	
		    	Date oneDate = new Date();
		    	Date otherDate = new Date();
		    	try{
			    	oneDate = new SimpleDateFormat("MMM dd, yyyy").parse(one.getDate());
		    		otherDate = new SimpleDateFormat("MMM dd, yyyy").parse(other.getDate());
		    	} catch (ParseException e) {
					e.printStackTrace();
				}
	    	
		    	int comparison = 0;
		    	
		    	if (oneTaskName.equals(otherTaskName)){
		    		if (oneDate.equals(otherDate)){
		    			comparison = one.getSubject().compareTo(other.getSubject());
		    		} else {
		    			comparison = oneDate.compareTo(otherDate);
		    		}
		    	} else {
		    		comparison = oneTaskName.compareTo(otherTaskName);
		    	}
		    	
		        return comparison;
		    }
		});
		
		return messages;
	}
	
	private static final class  MessageRowMapper implements ParameterizedRowMapper<PLMMessageData> {

		/**
		 * @see org.springframework.jdbc.core.RowMapper
		 * 		#mapRow(java.sql.ResultSet, int)
		 */
		public PLMMessageData mapRow(ResultSet rs, int rowNumber) throws SQLException {
			PLMMessageData message = null;
			
			if (rs != null) {
				message = new PLMMessageData(rs.getString("PROJECT_NAME"),
										rs.getString("TASK_NAME"),
										rs.getString("ID"),
										rs.getString("NM"),
										rs.getString("SUBJECT"),
										rs.getString("DESCRIPTION"),
										rs.getString("SOURCE_ORIGINATED_DATE"),
										rs.getString("OWNR"),
										rs.getString("LAST_NM"),
										rs.getString("FIRST_NM"),
										rs.getString("EMAIL_ADDR"));
			}
			
			return message;
		}

	}
	/**
	 * @see com.ge.energy.reqeng.model.dao.mapper.IEnhandedDeliverablesReportDAO#tasks_routes()
	 */
	public List<PLMTaskRouteData> tasks_routes(String projectName){
		logger.info("Entering into tasks_routes()");
		logger.info("projectName>> "+ projectName);

		// * * * * * * * * * * * * * G E T   T A S K S  -  R O U T E S * * * * * * * * * * * * * * *
		logger.info("tasks_routes() query: " + PLMDlvrblRptQueries.GET_TASK_ROUTES);
		
		List<PLMTaskRouteData> tasksRoutes = getSimpleJdbcTemplate().query(PLMDlvrblRptQueries.GET_TASK_ROUTES,(ParameterizedRowMapper<PLMTaskRouteData>) new TaskRouteRowMapper(),new Object[] {projectName});
		
		return tasksRoutes;
	}

	private static final class  TaskRouteRowMapper implements ParameterizedRowMapper<PLMTaskRouteData> {

		/**
		 * @see org.springframework.jdbc.core.RowMapper
		 * 		#mapRow(java.sql.ResultSet, int)
		 */
		public PLMTaskRouteData mapRow(ResultSet rs, int rowNumber) throws SQLException {
			PLMTaskRouteData task_route = null;
			
			if (rs != null) {
				task_route = new PLMTaskRouteData(
										rs.getString("TASK_NAME"),
										rs.getString("TASK_STATE"),
										rs.getString("TASK_OWNR"),
										rs.getString("PRJ_OWNR"),
										rs.getString("ROUTE_ID"),
										rs.getString("ROUTE_NAME"),
										rs.getString("DESCRIPTION"),
										rs.getString("TASK_STATE_ROUTE_INITIATED"),
										rs.getString("ROUTE_STATUS"),
										rs.getString("ROUTE_APPROVAL_DATE"),
										rs.getString("ROUTE_TASK_OWNER")
										);


			}
			
			return task_route;
		}

	}
	
	/**
	 * @see com.ge.energy.reqeng.model.dao.mapper.IEnhandedDeliverablesReportDAO#routeTaskOwners()
	 */
	public List<PLMRouteTaskOwnerData> routeTaskOwners(String projectName){
		logger.info("Entering into routeTaskOwners()");
		logger.info("projectName>> "+ projectName);
		// * * * * * * * * * * * * * G E T   R O U T E - T A S K  O W N E R S * * * * * * * * * * * * * * *
		logger.info("routeTaskOwners() query: " + PLMDlvrblRptQueries.GET_TASK_ROUTES_OWNER);
		List<PLMRouteTaskOwnerData> owners = getSimpleJdbcTemplate().query(PLMDlvrblRptQueries.GET_TASK_ROUTES_OWNER,(ParameterizedRowMapper<PLMRouteTaskOwnerData>) new RouteTaskOwnerRowMapper(),new Object[] {projectName});
		
		return owners;
	}

	private static final class  RouteTaskOwnerRowMapper implements ParameterizedRowMapper<PLMRouteTaskOwnerData> {

		/**
		 * @see org.springframework.jdbc.core.RowMapper
		 * 		#mapRow(java.sql.ResultSet, int)
		 */
		public PLMRouteTaskOwnerData mapRow(ResultSet rs, int rowNumber) throws SQLException {
			PLMRouteTaskOwnerData owner = null;
			
			if (rs != null) {
				owner = new PLMRouteTaskOwnerData(rs.getString("ROUTE_ID"),
										rs.getString("ROUTE_TASK_OWNER"));
			}
			
			return owner;
		}

	}
	/**
	 * @see com.ge.energy.reqeng.model.dao.mapper.IEnhandedDeliverablesReportDAO#sales_orders()
	 */
	public List<PLMSalesOrderData> sales_orders(String projectName){
		logger.info("Entering into sales_orders()");
		logger.info("projectName>> "+ projectName);
		// * * * * * * * * * * * * *   G E T   S A L E S   O R D E R S   * * * * * * * * * * * * * * *
		logger.info("sales_orders() query: " + PLMDlvrblRptQueries.GET_SALES_ORDER);
		List<PLMSalesOrderData> listSalesOrders = getSimpleJdbcTemplate().query(PLMDlvrblRptQueries.GET_SALES_ORDER,(ParameterizedRowMapper<PLMSalesOrderData>) new SalesOrderRowMapper(),new Object[] {projectName});
		return listSalesOrders;
	}
	
	private static final class  SalesOrderRowMapper implements ParameterizedRowMapper<PLMSalesOrderData> {

		/**
		 * @see org.springframework.jdbc.core.RowMapper
		 * 		#mapRow(java.sql.ResultSet, int)
		 */
		public PLMSalesOrderData mapRow(ResultSet rs, int rowNumber) throws SQLException {
			PLMSalesOrderData sales_order = null;
			
			if (rs != null) {
				sales_order = new PLMSalesOrderData(
											rs.getString("ID"),
											rs.getString("NM"),
											rs.getString("DESCRIPTION"),
											rs.getString("LIFECYCLE"),
											rs.getString("ERP_ORDER_STATUS"),
											rs.getString("ORDER_ADMINISTRATOR"),
											rs.getString("CUSTOMER"),
											rs.getString("UNIT_SERIAL_NUMBER"),
											rs.getString("ICN")
										);
			}
			
			return sales_order;
		}

	}
	
	/**
	 * Returns the list of getTopPartNames
	 *  @param projectNmLcl(String)
	 * @return String (List<String>)
	 */
	public List<String> getTopPartNames(String projectNmLcl,String genSteamFlag){
		StringBuffer getTopPartQry=new StringBuffer();
		logger.info("Selected genSteamFlag"+genSteamFlag);
		List<String> partIds = null;
		if(genSteamFlag.equalsIgnoreCase("STEAM")){
			getTopPartQry.append(PLMDlvrblRptQueries.GET_TOP_PART_FOR_STEAM);
		}else{
			getTopPartQry.append(PLMDlvrblRptQueries.GET_TOP_PART_FOR_GEN);
		}
		logger.info("Query for gettting Top Part Names>> "+getTopPartQry);
		 
		List<String> partNames = getSimpleJdbcTemplate().query(getTopPartQry.toString(), new TopLevelMapper(),new Object[] {projectNmLcl,projectNmLcl});
		//GET_TOP_PART_IDS
		Map<String, Object> params = new HashMap<String, Object>();
		 if(!PLMUtils.isEmptyList(partNames)){
			 params.put("PRTNMS", partNames);
			 logger.info("Query for gettting Top Part Ids >> "+PLMDlvrblRptQueries.GET_TOP_PART_IDS);
			 partIds = getNamedJdbcTemplate().query(PLMDlvrblRptQueries.GET_TOP_PART_IDS,params, new TopLevelPrtIdMapper());
		} 
		return partIds;
	}
	
	/**
	 * @return String objects.
	 */
	private static final class TopLevelMapper implements ParameterizedRowMapper<String> {
		public String mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			String topLvlNms = rs.getString(PLMUtils.checkNullVal("TOP_PART"));
			return topLvlNms;
		}
	}
	/**
	 * @return String objects.
	 */
	private static final class TopLevelPrtIdMapper implements ParameterizedRowMapper<String> {
		public String mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			String topLvlPrtId = rs.getString(PLMUtils.checkNullVal("ID"));
			return topLvlPrtId;
		}
	}
	
	
}
