package com.geinfra.geaviation.pwi.executors;

import java.util.ArrayList;
import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.PWiQueryTimeoutException;
import com.geinfra.geaviation.pwi.common.PWiResultSizeLimitExceededException;
import com.geinfra.geaviation.pwi.integration.HierarchicalExecutor;
import com.geinfra.geaviation.pwi.integration.QueryingDao;
import com.geinfra.geaviation.pwi.model.PWiResultSet;
import com.geinfra.geaviation.pwi.xml.query.AbstractExecutorXml;
import com.geinfra.geaviation.pwi.xml.query.AppendExecutorXml;
import com.geinfra.geaviation.pwi.xml.query.DataInvestigationToolExecutorXml;
import com.geinfra.geaviation.pwi.xml.query.HierarchicalExecutorXml;
import com.geinfra.geaviation.pwi.xml.query.PipelineExecutorXml;
import com.geinfra.geaviation.pwi.xml.query.PipelineSingleExecutorXml;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.query.SqlExecutorXml;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;

/**
 * 
 * Project      : Product Lifecycle Management
 * Date Written : Aug 1, 2011
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description : DAO providing the new and preferred mechanism for executing a
 * query from a QueryType. The new mechanism provides a way to hook any number
 * of sub-queries together in different ways to meet custom query needs based on
 * the Executor interface.
 * 
 * Ideally, this should be how all query execution is specified, but other DAOs
 * exist in order to support the older ways of defining queries.
 * 
 * Revision Log Aug 1, 2011 | v1.0.
 * 2012.12.18 pH  replaced GEAEResultSet with PWiResultSet
 * --------------------------------------------------------------
 */
public class ExecutorQueryingDao extends QueryingDao {
	private Executor executor;

	public ExecutorQueryingDao(int queryTimeoutSecs, int resultSizeLimit) {
		super(queryTimeoutSecs, resultSizeLimit);
	}

	@Override
	public PWiResultSet executeQuery(QueryType queryType, Search search,
			SelectedColumns selectedColumns, String sso) throws PWiException,
			PWiQueryTimeoutException, PWiResultSizeLimitExceededException {
		executor = createExecutor(queryType);

		return executor.execute(queryType, search, selectedColumns, sso, null,
				null);
	}

	@Override
	public String getExecutedQuery() {
		return executor.getExecutedQuery();
	}

	private Executor createExecutor(QueryType queryType) throws PWiException {
		AbstractExecutorXml executorType = queryType.getQuerydefinition()
				.getExecutor();
		return getExecutorFromXml(executorType);
	}

	private Executor getExecutorFromXml(AbstractExecutorXml executorXmlType)
			throws PWiException {
		Executor resultExecutor = null;
		if (executorXmlType instanceof SqlExecutorXml) {
			SqlExecutorXml sqlExecutorXmlType = (SqlExecutorXml) executorXmlType;
			String dataSource = sqlExecutorXmlType.getDsn();
			String sqlTemplate = sqlExecutorXmlType.getSql();

			resultExecutor = new SqlTemplateExecutor(dataSource, sqlTemplate,
					getQueryTimeoutSecs(), getResultSizeLimit());
		} else if (executorXmlType instanceof AppendExecutorXml) {
			// TODO pH 2013.01 tabbed: similar block for Tabbed pipeline queries
			AppendExecutorXml appendExecutorXmlType = (AppendExecutorXml) executorXmlType;

			// Get child executors
			// Get child executors
			List<AbstractExecutorXml> childExecutorsXml = appendExecutorXmlType
					.getExecutor();
			List<Executor> childExecutors = getExecutorsFromXml(childExecutorsXml);

			resultExecutor = new AppendExecutor(childExecutors);
		} else if (executorXmlType instanceof PipelineExecutorXml) {
			PipelineExecutorXml pipelineExecutorXmlType = (PipelineExecutorXml) executorXmlType;

			// Get child executors
			List<AbstractExecutorXml> childExecutorsXml = pipelineExecutorXmlType
					.getExecutor();
			List<Executor> childExecutors = getExecutorsFromXml(childExecutorsXml);

			resultExecutor = new PipelineExecutor(childExecutors);
		} else if (executorXmlType instanceof PipelineSingleExecutorXml) {
			PipelineSingleExecutorXml pipelineSingleExecutorXmlType =
					(PipelineSingleExecutorXml) executorXmlType;

			// Get child executors
			List<AbstractExecutorXml> childExecutorsXml = pipelineSingleExecutorXmlType
					.getExecutor();
			List<Executor> childExecutors = getExecutorsFromXml(childExecutorsXml);

			resultExecutor = new PipelineSingleExecutor(childExecutors);
		} else if (executorXmlType instanceof HierarchicalExecutorXml) {
			HierarchicalExecutorXml hierarchicalExecutorXml = (HierarchicalExecutorXml) executorXmlType;

			// Get child executors
			AbstractExecutorXml childExecutorXml = hierarchicalExecutorXml
					.getExecutor();
			Executor childExecutor = getExecutorFromXml(childExecutorXml);

			String searchColumnId = hierarchicalExecutorXml.getSearchColumnId();
			String childColumnId = hierarchicalExecutorXml.getChildColumnId();

			resultExecutor = new HierarchicalExecutor(childExecutor,
					searchColumnId, childColumnId);
		} else if (executorXmlType instanceof DataInvestigationToolExecutorXml) {
			resultExecutor = new DataInvestigationToolExecutor(
					getQueryTimeoutSecs(), getResultSizeLimit(),
					(DataInvestigationToolExecutorXml) executorXmlType);
		} else {
			throw new PWiException("Failed to recognize executor XML type: "
					+ executorXmlType);
		}

		return resultExecutor;
	}

	private List<Executor> getExecutorsFromXml(
			List<AbstractExecutorXml> abstractExecutorXmls)
			throws PWiException {
		List<Executor> executors = new ArrayList<Executor>();
		for (AbstractExecutorXml abstractExecutorXml : abstractExecutorXmls) {
			Executor aExecutor = getExecutorFromXml(abstractExecutorXml);
			executors.add(aExecutor);
		}
		return executors;
	}
}
