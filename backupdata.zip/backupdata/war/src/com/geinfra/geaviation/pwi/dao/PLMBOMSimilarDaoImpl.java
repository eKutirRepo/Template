/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBOMSimilarDaoImpl.java
 * @Creation date: 28-Oct-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMBOMSimilarData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMBOMSimilarDaoImpl extends SimpleJdbcDaoSupport implements PLMBOMSimilarDaoIfc { 
	/**
	 *  Holds the lOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMBOMSimilarDaoImpl.class);
	/**
	 * Holds the SIMPLE_DATE_FORMAT
	 */
	

	/**
	 * This method is used to get getBOMSmrltyRptDetails
	 * 
	 * @param partGrpInterst,bomMatchLvl
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<PLMBOMSimilarData>> getBOMSmrltyRptDetails(String partGrpInterst,String bomMatchLvl,Date efftStrDate, Date efftEndDate) throws PLMCommonException{

		final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
		"MM/dd/yyyy");
		
		LOG.info("Entering getBOMSmrltyRptDetails() of PLMBOMSimilarDaoImpl ");
		
		Map<String, List<PLMBOMSimilarData>> bomSmlrtyRptMap = new HashMap<String, List<PLMBOMSimilarData>>(); 
		List<PLMBOMSimilarData> commonmSmlrtyRptList =new ArrayList<PLMBOMSimilarData>();
		
		List<String> partIdList = new ArrayList<String>();
		StringBuffer validBomQuery =new StringBuffer();
		validBomQuery.append(PLMOfflineQueries.GET_VALID_PARTS_OF_SMLR_BOM1);
		 
		if(efftStrDate != null && efftEndDate != null) {
			validBomQuery.append(" AND ");
			validBomQuery.append("(B.START_EFFECTIVITY_DT BETWEEN CAST('");
			validBomQuery.append(SIMPLE_DATE_FORMAT.format(efftStrDate)+ "' AS DATE FORMAT 'MM/DD/YYYY') AND ");
			validBomQuery.append(" CAST('");
			validBomQuery.append(SIMPLE_DATE_FORMAT.format(efftEndDate)+ "' AS DATE FORMAT 'MM/DD/YYYY'))");
		}
		  
		validBomQuery.append(PLMOfflineQueries.GET_VALID_PARTS_OF_SMLR_BOM2);
		
		if(efftStrDate != null && efftEndDate != null) {
			validBomQuery.append(" AND ");
			validBomQuery.append("(A.START_EFFECTIVITY_DT BETWEEN CAST('");
			validBomQuery.append(SIMPLE_DATE_FORMAT.format(efftStrDate)+ "' AS DATE FORMAT 'MM/DD/YYYY') AND ");
			validBomQuery.append(" CAST('");
			validBomQuery.append(SIMPLE_DATE_FORMAT.format(efftEndDate)+ "' AS DATE FORMAT 'MM/DD/YYYY'))");
			
		}
		validBomQuery.append(PLMOfflineQueries.GET_VALID_PARTS_OF_SMLR_BOM3.replace("?", bomMatchLvl));
		
		LOG.info("Input Part of Interest "+partGrpInterst);
		LOG.info("BOM % Match Value "+bomMatchLvl);	
		LOG.info("Executing Valid query of Part Similarity Query "+validBomQuery.toString());
		
		List<PLMBOMSimilarData> partIbomSmlrtyRptList= getSimpleJdbcTemplate().query(validBomQuery.toString(),
			new PartsSmlrMpr(),new Object[]{partGrpInterst,partGrpInterst,partGrpInterst});

		LOG.info("partIbomSmlrtyRptList size "+partIbomSmlrtyRptList.size());
		
		if(!PLMUtils.isEmptyList(partIbomSmlrtyRptList) && partIbomSmlrtyRptList.size()>0){
			
			for(int i=0;i<partIbomSmlrtyRptList.size();i++){
				partIdList.add(partIbomSmlrtyRptList.get(i).getSimilarId());
			}	  
			bomSmlrtyRptMap.put("partIbomSmlrtyRptList", partIbomSmlrtyRptList);
		}
		  
		if(!PLMUtils.isEmptyList(partIdList)){
		
			StringBuffer commonSmlrBOMQry=new StringBuffer();
			commonSmlrBOMQry.append(PLMOfflineQueries.GET_COMMON_OF_SMLR_BOM1);
			commonSmlrBOMQry.append("(");
			commonSmlrBOMQry.append(PLMUtils.setListForQuery(partIdList));
			commonSmlrBOMQry.append(")");
			if(efftStrDate != null && efftEndDate != null) {
				commonSmlrBOMQry.append(" AND ");
				commonSmlrBOMQry.append("(B.START_EFFECTIVITY_DT BETWEEN CAST('");
				commonSmlrBOMQry.append(SIMPLE_DATE_FORMAT.format(efftStrDate)+ "' AS DATE FORMAT 'MM/DD/YYYY') AND ");
				commonSmlrBOMQry.append(" CAST('");
				commonSmlrBOMQry.append(SIMPLE_DATE_FORMAT.format(efftEndDate)+ "' AS DATE FORMAT 'MM/DD/YYYY'))");
			}
			commonSmlrBOMQry.append(PLMOfflineQueries.GET_COMMON_OF_SMLR_BOM2);
			LOG.info("Executing common Part Similarity Query "+commonSmlrBOMQry);
					
			commonmSmlrtyRptList= getSimpleJdbcTemplate().query(commonSmlrBOMQry.toString(), 
				  new CommonRptMpr(),new Object[] {partGrpInterst, partGrpInterst});
			   
			bomSmlrtyRptMap.put("commonmSmlrtyRptList", commonmSmlrtyRptList);
				
			for(int j=0;j<partIbomSmlrtyRptList.size();j++){
					
				String[] partIdBomSimilar = partIbomSmlrtyRptList.get(j).getSimilarPartParentId().split("~");
				String partId = partIdBomSimilar[0];
				LOG.info("partId>>> "+partId);
				String parentName =partIdBomSimilar[1];
				LOG.info("parentName>>> "+parentName);
				String similarId = partIdBomSimilar[2];
				LOG.info("similarId>>> "+similarId);
				  
				LOG.info("Executing item Search Similarity Query "+PLMOfflineQueries.GET_ITEMS_SEARCH_PART);
				List<PLMBOMSimilarData> itemPartBomRptList= getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_ITEMS_SEARCH_PART, 
						new ItemPartMapper(),new Object[] {partId, similarId});
				LOG.info(parentName +" of itemPartBomRptList size "+itemPartBomRptList.size());
				bomSmlrtyRptMap.put(parentName+"~a", itemPartBomRptList);
				
				LOG.info("Executing item Similarity Query "+PLMOfflineQueries.GET_ITEMS_SIMILAR_PART);
				List<PLMBOMSimilarData> itemSmlrtyRptList= getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_ITEMS_SIMILAR_PART, 
						new ItemPartMapper(),new Object[] {similarId, partId});
				LOG.info(parentName +" of itemSmlrtyRptList size "+itemSmlrtyRptList.size());
				bomSmlrtyRptMap.put(parentName+"~b", itemSmlrtyRptList);
			}
				
			LOG.info("commonmSmlrtyRptList size "+commonmSmlrtyRptList.size());
				
		  } else{
			bomSmlrtyRptMap.put("partIbomSmlrtyRptList", partIbomSmlrtyRptList);
			bomSmlrtyRptMap.put("commonmSmlrtyRptList", commonmSmlrtyRptList);
		  }
		return bomSmlrtyRptMap;
	}

	/**
	 * 
	 * This mapper is used to get the part ids
	 *
	 */
	private static class PartsSmlrMpr implements ParameterizedRowMapper<PLMBOMSimilarData> {
		public PLMBOMSimilarData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMBOMSimilarData tempData = new PLMBOMSimilarData();
			tempData.setSimilarId(rs.getString("PRNT_SIMILAR_ID"));
			tempData.setParent(rs.getString("PRNT_WITH_SIMILAR_BOM"));
			tempData.setPartId(rs.getString("PARNT_ID"));
			tempData.setSimilarPartParentId(tempData.getPartId()+"~"+tempData.getParent()+"~"+tempData.getSimilarId());
		return tempData;
		}
	}
	
	/**
	 * 
	 * This mapper is used to get the commonPartMapper
	 *
	 */
	private static class CommonRptMpr implements ParameterizedRowMapper<PLMBOMSimilarData> {
		public PLMBOMSimilarData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMBOMSimilarData tempData = new PLMBOMSimilarData();
			tempData.setParent(rs.getString("PRNT_WITH_SIMILAR_BOM"));
			tempData.setItem(rs.getString("CHILD_NAME"));
			tempData.setDescription(rs.getString("CHILD_DESC"));
			tempData.setQuantity(rs.getString("QTY"));
		return tempData;
		}
	}
	
	/**
	 * 
	 * This mapper is used to get the commonPartMapper
	 *
	 */
	private static class ItemPartMapper implements ParameterizedRowMapper<PLMBOMSimilarData> {
		public PLMBOMSimilarData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMBOMSimilarData tempData = new PLMBOMSimilarData();
			tempData.setItem(rs.getString("CHILD_ITEM"));
			tempData.setDescription(rs.getString("CHILD_DESC"));
		return tempData;
		}
	}
}
