/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhrUsdSubstncDaoImpl.java
 * @Creation date: 01-Jan-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMWhrUsdSubstncData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMWhrUsdSubstncDaoImpl extends SimpleJdbcDaoSupport implements PLMWhrUsdSubstncDaoIfc{
	private static final Logger LOG = Logger.getLogger(PLMWhrUsdSubstncDaoImpl.class);
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
		 
	}
	/**
	 * This method is used for getDropDownvalues
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<SelectItem> getDropDownvalues(String substance,String casSubstanceNum) throws PLMCommonException {
		List<SelectItem> dropdownlist = new ArrayList<SelectItem>();
		StringBuffer sqlQury=new StringBuffer();
		boolean whereFlag=false;
		Map<String, Object> params = new HashMap<String, Object>();
		try {
			sqlQury.append(PLMOfflineQueries.GET_MATERIAL_LIST);
			
			if(substance != null && substance.length() > 0){
				sqlQury.append(" WHERE T_SUB.NM = :SUBNM");
				whereFlag=true;
				params.put("SUBNM", substance);
			}
			if(casSubstanceNum != null && casSubstanceNum.length() > 0){
				if(!whereFlag){
				sqlQury.append(" WHERE T_SUB.CAS_NUM = :CASSUBNM");
				whereFlag=true;
				}else{
					sqlQury.append(" AND T_SUB.CAS_NUM = :CASSUBNM");
				}
				params.put("CASSUBNM", casSubstanceNum);
			}
			LOG.info("Executed Query for Drop down list"+sqlQury);
			dropdownlist = getNamedJdbcTemplate().query(sqlQury.toString(),params, new DropdownlistMapper());	
			
					
			
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return dropdownlist;
	}
	/**
	 * Row mapper for getting dropMapper
	 */
	
	private static final class DropdownlistMapper implements ParameterizedRowMapper<SelectItem>{ 	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {

			SelectItem selectItem = new SelectItem(rs.getString("MATERIAL"),rs.getString("MATERIAL"));

			return selectItem;

		}
	
}
	
	/**
	 * This method is used to getGBOMData
	 * @return java.util.List
	 * @param varMap, hwPrdMap
	 * @throws PLMCommonException
	 */
	public List<PLMWhrUsdSubstncData> getWhUsedCASSubData(String substance,String casubstanceNum,String material) throws PLMCommonException{
		LOG.info("Inside getWhUsedCASSubData() of DAOImpl......");
		String timeStamp = null;
		String ENVR_VT1 = "ENVR_VT1";
		String ENVR_VT2 = "ENVR_VT2";
		String ENVR_VT3 = "ENVR_VT3";
		String ENVR_VT4 = "ENVR_VT4";
		String ENVR_VT5 = "ENVR_VT5";
		String ENVR_VT6 = "ENVR_VT6";
		List<PLMWhrUsdSubstncData> resultList = new ArrayList<PLMWhrUsdSubstncData>();
		StringBuffer createVt1Qry =new StringBuffer();
		 try{
		   if((!PLMUtils.isEmpty(substance)||!PLMUtils.isEmpty(casubstanceNum))&&!PLMUtils.isEmpty(material)){
			   LOG.info("Substance in DAO Impl"+substance);
			   LOG.info("casubstanceNum in DAO Impl"+casubstanceNum);
			   LOG.info("Material in DAO Impl"+material);
			   timeStamp = PLMUtils.volTableFormatDate();
				LOG.info("The timeStamp for the Report "+timeStamp);
				
				ENVR_VT1 = ENVR_VT1.concat(timeStamp);
				ENVR_VT2 = ENVR_VT2.concat(timeStamp);
				ENVR_VT3 = ENVR_VT3.concat(timeStamp);
				ENVR_VT4 = ENVR_VT4.concat(timeStamp); 
				ENVR_VT5 = ENVR_VT5.concat(timeStamp);
				ENVR_VT6 = ENVR_VT6.concat(timeStamp);
				
				//VT1
				createVt1Qry.append(PLMOfflineQueries.CREATE_ENVR_VT1_FIRST.replace("ENVR_VT1", ENVR_VT1).replace("?", material));
				
				if(substance != null && substance.length() > 0){
					createVt1Qry.append("AND T_SUB.NM ="+ "'"+substance+"'");
				}
				if(casubstanceNum != null && casubstanceNum.length() > 0){
					createVt1Qry.append(" AND T_SUB.CAS_NUM =" + "'"+casubstanceNum+"'");
				}
				createVt1Qry.append(PLMOfflineQueries.CREATE_ENVR_VT1_SECOND);
				
				LOG.info("Query for Creating ENVR_VT1 : "+createVt1Qry);
				
				getJdbcTemplate().execute(createVt1Qry.toString());
				
				LOG.info("Query for Collect STATS ENVR_VT1 : " + PLMOfflineQueries.COLLECT_STATS_ENVR_VT1.replace("ENVR_VT1", ENVR_VT1));
				getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ENVR_VT1.replace("ENVR_VT1", ENVR_VT1));
				
				LOG.info("************VT1 DONE************");
				
				//VT2
				LOG.info("Query for Creating ENVR_VT2 : "+PLMOfflineQueries.CREATE_ENVR_VT2.replace("ENVR_VT2", ENVR_VT2));
				getJdbcTemplate().execute(PLMOfflineQueries.CREATE_ENVR_VT2.replace("ENVR_VT2", ENVR_VT2));
				
				LOG.info("Query for Inserting into ENVR_VT2 : "+PLMOfflineQueries.INSERT_ENVR_VT2.replace("ENVR_VT2", ENVR_VT2).
						replace("ENVR_VT1", ENVR_VT1));
				getJdbcTemplate().execute(PLMOfflineQueries.INSERT_ENVR_VT2.replace("ENVR_VT2", ENVR_VT2).
						replace("ENVR_VT1", ENVR_VT1));
				
				LOG.info("Query for Collect STATS ENVR_VT2 : " + PLMOfflineQueries.COLLECT_STATS_ENVR_VT2.replace("ENVR_VT2", ENVR_VT2));
				getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ENVR_VT2.replace("ENVR_VT2", ENVR_VT2));
				
				LOG.info("************VT2 DONE************");
				
				//VT3
				LOG.info("Query for Creating ENVR_VT3 : "+PLMOfflineQueries.CREATE_ENVR_VT3.replace("ENVR_VT3", ENVR_VT3)
						.replace("ENVR_VT2", ENVR_VT2)
						);
				getJdbcTemplate().execute(PLMOfflineQueries.CREATE_ENVR_VT3.replace("ENVR_VT3", ENVR_VT3)
						.replace("ENVR_VT2", ENVR_VT2));
				
				LOG.info("Query for Collect STATS ENVR_VT3 : " + PLMOfflineQueries.COLLECT_STATS_ENVR_VT3.replace("ENVR_VT3", ENVR_VT3));
				getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ENVR_VT3.replace("ENVR_VT3", ENVR_VT3));
				
				LOG.info("************VT3 DONE************");
				
				//VT4
				LOG.info("Query for Creating ENVR_VT4 : "+PLMOfflineQueries.CREATE_ENVR_VT4.replace("ENVR_VT4", ENVR_VT4)
						.replace("ENVR_VT3", ENVR_VT3)
						);
				getJdbcTemplate().execute(PLMOfflineQueries.CREATE_ENVR_VT4.replace("ENVR_VT4", ENVR_VT4)
						.replace("ENVR_VT3", ENVR_VT3));
				
				LOG.info("Query for Collect STATS ENVR_VT4 : " + PLMOfflineQueries.COLLECT_STATS_ENVR_VT4.replace("ENVR_VT4", ENVR_VT4));
				getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ENVR_VT4.replace("ENVR_VT4", ENVR_VT4));
				
				LOG.info("************VT4 DONE************");
				
				//VT5
				LOG.info("Query for Creating ENVR_VT5 : "+PLMOfflineQueries.CREATE_ENVR_VT5.replace("ENVR_VT5", ENVR_VT5)
						.replace("ENVR_VT3", ENVR_VT3)
						);
				getJdbcTemplate().execute(PLMOfflineQueries.CREATE_ENVR_VT5.replace("ENVR_VT5", ENVR_VT5)
						.replace("ENVR_VT3", ENVR_VT3));
				
				LOG.info("Query for Collect STATS ENVR_VT5 : " + PLMOfflineQueries.COLLECT_STATS_ENVR_VT5.replace("ENVR_VT5", ENVR_VT5));
				getJdbcTemplate().execute(PLMOfflineQueries.COLLECT_STATS_ENVR_VT5.replace("ENVR_VT5", ENVR_VT5));
				
				LOG.info("************VT5 DONE************");
				
				//VT6
				LOG.info("Query for Creating ENVR_VT6 : "+PLMOfflineQueries.CREATE_ENVR_VT6.replace("ENVR_VT6", ENVR_VT6)
						.replace("ENVR_VT2", ENVR_VT2)
						);
				getJdbcTemplate().execute(PLMOfflineQueries.CREATE_ENVR_VT6.replace("ENVR_VT6", ENVR_VT6)
						.replace("ENVR_VT2", ENVR_VT2));
			
				LOG.info("************VT6 DONE************");
				
				LOG.info("Executed Query for Final Result List : "+
						PLMOfflineQueries.GET_CAS_SUB_DATALIST.replace("ENVR_VT1", ENVR_VT1).replace("ENVR_VT2", ENVR_VT2).
						replace("ENVR_VT3", ENVR_VT3).replace("ENVR_VT4", ENVR_VT4).replace("ENVR_VT5", ENVR_VT5).
						replace("ENVR_VT6", ENVR_VT6));
				resultList = getSimpleJdbcTemplate().query(
						PLMOfflineQueries.GET_CAS_SUB_DATALIST.replace("ENVR_VT1", ENVR_VT1).replace("ENVR_VT2", ENVR_VT2).
						replace("ENVR_VT3", ENVR_VT3).replace("ENVR_VT4", ENVR_VT4).replace("ENVR_VT5", ENVR_VT5).
						replace("ENVR_VT6", ENVR_VT6), new ResultListMapper());
		   }	 
		 }catch(DataAccessException e){
			 PLMUtils.checkException(e.getMessage());
		 }
		 
		LOG.info("Existing getWhUsedCASSubData() of DAO Impl"); 
		return resultList;
	}
	/**
	 * @return .
	 */
	private static final class ResultListMapper implements ParameterizedRowMapper<PLMWhrUsdSubstncData> {
		public PLMWhrUsdSubstncData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMWhrUsdSubstncData resultList = new PLMWhrUsdSubstncData();
			resultList.setContract(PLMUtils.checkNullVal(rs.getString("CONTRACT_NAME")));
			resultList.setProject(PLMUtils.checkNullVal(rs.getString("TOP_WBSE")));
			resultList.setWbseName(PLMUtils.checkNullVal(rs.getString("WBSE_NAME")));
			//resultList.setWbsePartName(PLMUtils.checkNullVal(rs.getString("WBSE_NAME")));
			resultList.setMliNew(PLMUtils.checkNullVal(rs.getString("MLI_NEW")));
			resultList.setPoNumber(PLMUtils.checkNullVal(rs.getString("PO_NUMBER")));
			resultList.setPurFoldOffDTTM(PLMUtils.checkNullVal(rs.getString("PURCHASE_FOLDER_OFFICDTTM")));
			resultList.setSuppName(PLMUtils.checkNullVal(rs.getString("SUPPLIER_NAME")));
			resultList.setSuppPerson(PLMUtils.checkNullVal(rs.getString("SUPPLIER_PERSON")));
			resultList.setSuppEmail(PLMUtils.checkNullVal(rs.getString("SUPPLIER_EMAIL")));
			resultList.setPurFoldName(PLMUtils.checkNullVal(rs.getString("PURCHASE_FOLDER_NAME")));
			resultList.setSuppBAANCode(PLMUtils.checkNullVal(rs.getString("SUPPLIER_BAAN_CODE")));
			resultList.setMliRef(PLMUtils.checkNullVal(rs.getString("MLI_REFERENCE_PART")));
			resultList.setPartLevel(PLMUtils.checkNullVal(rs.getString("PART_LEVEL")));
			resultList.setPartNumber(PLMUtils.checkNullVal(rs.getString("PART_NUMBER")));
			resultList.setPartRevision(PLMUtils.checkNullVal(rs.getString("PART_REVISION")));
			resultList.setPartType(PLMUtils.checkNullVal(rs.getString("PART_TYPE")));
			resultList.setPartAttribute(PLMUtils.checkNullVal(rs.getString("PART_ATTRIBUTE")));
			resultList.setPartTitle(PLMUtils.checkNullVal(rs.getString("PART_TITLE")));
		//	resultList.setMaterial(PLMUtils.checkNullVal(rs.getString("MATERIAL")));
		//	resultList.setMaterialType(PLMUtils.checkNullVal(rs.getString("MATERIAL_TYPE")));
			resultList.setSubCASNum(PLMUtils.checkNullVal(rs.getString("SUB_CAS_NUM")));
		//	resultList.setSubstance(PLMUtils.checkNullVal(rs.getString("SUB_NM")));
			resultList.setRegulation(PLMUtils.checkNullVal(rs.getString("REGULATION")));
			resultList.setRdo(PLMUtils.checkNullVal(rs.getString("RDO")));
			
			
		return resultList;
		}
	}
}
