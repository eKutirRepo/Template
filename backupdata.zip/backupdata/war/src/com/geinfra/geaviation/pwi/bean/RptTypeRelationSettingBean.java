package com.geinfra.geaviation.pwi.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.el.ELContext;
import javax.faces.context.FacesContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.namespace.QName;

import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.QueryAccessException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.RptTypeRelationVo;
import com.geinfra.geaviation.pwi.service.RptTypeRelationService;
import com.geinfra.geaviation.pwi.util.LoadProps;
import com.geinfra.geaviation.pwi.xml.QueryXmlReader;
import com.geinfra.geaviation.pwi.xml.query.AllowedoperatorsType;
import com.geinfra.geaviation.pwi.xml.query.AvailableType;
import com.geinfra.geaviation.pwi.xml.query.ColumnType;
import com.geinfra.geaviation.pwi.xml.query.ColumnlistType;
import com.geinfra.geaviation.pwi.xml.query.ColumnrefType;
import com.geinfra.geaviation.pwi.xml.query.DatepickerType;
import com.geinfra.geaviation.pwi.xml.query.DbfieldType;
import com.geinfra.geaviation.pwi.xml.query.DbobjectType;
import com.geinfra.geaviation.pwi.xml.query.DbobjectlistType;
import com.geinfra.geaviation.pwi.xml.query.DbobjectrefType;
import com.geinfra.geaviation.pwi.xml.query.InputtypeType;
import com.geinfra.geaviation.pwi.xml.query.PdfinfoType;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.query.QuerycustomizationType;
import com.geinfra.geaviation.pwi.xml.query.QuerydefinitionType;
import com.geinfra.geaviation.pwi.xml.query.QueryfeaturesType;
import com.geinfra.geaviation.pwi.xml.query.SelectType;
import com.geinfra.geaviation.pwi.xml.query.SelectedType;
import com.geinfra.geaviation.pwi.xml.query.SelectionType;
import com.geinfra.geaviation.pwi.xml.query.SelectionitemType;
import com.geinfra.geaviation.pwi.xml.query.SqlExecutorXml;
import com.healthmarketscience.sqlbuilder.SelectQuery;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbSchema;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbSpec;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbTable;

/**
 * 
 * Project : Product Lifecycle Management Intelligence Date Written : Jan 30,
 * 2015 Security : GE Confidential Restrictions : GE PROPRIETARY INFORMATION,
 * FOR GE USE ONLY
 * 
 * Copyright(C) 2015 GE All rights reserved
 * 
 * Revision Log Jan 30, 2015 | v1.0.
 * --------------------------------------------------------------
 */
public class RptTypeRelationSettingBean extends BaseBean {
	private static final Logger LOGGER = Logger
			.getLogger(RptTypeRelationSettingBean.class);
	protected static final String DB_SCHEMA = "dbschema";

	private String tableName;
	private String selectedType;
	private List<RptTypeRelationVo> columnsList;
	private boolean columnsFlag;
	private String checkStatus;
	private String columnName;
	private boolean checkFlg = false;
	// private RptTypeRelationVo RptTypeRelationVo;
	private Map<String, RptTypeRelationVo> columnTypeMap;
	private Map<String, Map<String, RptTypeRelationVo>> tableTypeMap = new HashMap<String, Map<String, RptTypeRelationVo>>();
	private RptTypeRelationBean rpttyperelationbean;
	private List<RptTypeRelationVo> rptSetngTypeRelList;
	private int tableTypeMapCnt;
	private int columnTypeMapCnt;
	private String generatedXml;
	private boolean loadStat = false;
	private RptTypeRelationService rptTypeRelationService;

	
	public String getSelectedType() {
		return selectedType;
	}

	public void setSelectedType(String selectedType) {
		this.selectedType = selectedType;
	}

	public boolean isLoadStat() {
		return loadStat;
	}

	public void setLoadStat(boolean loadStat) {
		this.loadStat = loadStat;
	}

	public String getGeneratedXml() {
		return generatedXml;
	}

	public void setGeneratedXml(String generatedXml) {
		this.generatedXml = generatedXml;
	}

	public void setRptTypeRelationService(
			RptTypeRelationService rptTypeRelationService) {
		this.rptTypeRelationService = rptTypeRelationService;
	}

	public RptTypeRelationBean getRpttyperelationbean() {
		return rpttyperelationbean;
	}

	public void setRpttyperelationbean(RptTypeRelationBean rpttyperelationbean) {
		this.rpttyperelationbean = rpttyperelationbean;
	}

	public List<RptTypeRelationVo> getRptSetngTypeRelList() {
		if(rptSetngTypeRelList==null)
		{
			rptSetngTypeRelList  = new ArrayList<RptTypeRelationVo>();
		}
		
		return rptSetngTypeRelList;
	}
	
	

	public void setRptSetngTypeRelList(
			List<RptTypeRelationVo> rptSetngTypeRelList) {
		this.rptSetngTypeRelList = rptSetngTypeRelList;
	}
	
	public void configureTypeSettings() throws PWiException
	{
		if(rpttyperelationbean.isGenNewRptTemp())
		{
			checkFlg = false;
			rptSetngTypeRelList = new ArrayList<RptTypeRelationVo>();
			String typeName = "";
			Map<String, Map<String, RptTypeRelationVo>> temptableTypeMap = new HashMap<String, Map<String, RptTypeRelationVo>>();

			for (int i = 0; i < rpttyperelationbean.getRowType().size(); i++) {

				RptTypeRelationVo ronVo = rpttyperelationbean.getRowType().get(i);
				String selTypeRelVal = ronVo.getSelTypeRelVal();

				if (selTypeRelVal.indexOf("-") != -1) {

					String tblKey = selTypeRelVal.substring(0,
							selTypeRelVal.indexOf("-")).trim();
					if (tableTypeMap.containsKey(tblKey)) {
						temptableTypeMap.put(tblKey, tableTypeMap.get(tblKey));
					}
					ronVo.setSelTypeRelVal(selTypeRelVal);
					ronVo.setSelTypeRelValEedw(selTypeRelVal
							.substring(selTypeRelVal.indexOf("-") + 1));
				} else {
					if (tableTypeMap.containsKey(selTypeRelVal)) {
						temptableTypeMap.put(selTypeRelVal,
								tableTypeMap.get(selTypeRelVal));
					}
					ronVo.setSelTypeRelVal(selTypeRelVal);
					ronVo.setSelTypeRelValEedw(selTypeRelVal);
				}
				if (i == 0) {
					typeName = ronVo.getSelTypeRelVal();
				}
				rptSetngTypeRelList.add(ronVo);

				ronVo = null;
			}

				getColumnsFrType(typeName);
			// typeRelList=rpttyperelationbean.getRowType();
			tableTypeMap = temptableTypeMap;
		}
		else
		{
			rptSetngTypeRelList = new ArrayList<RptTypeRelationVo>();
			String typeName = "";
			Map<String, Map<String, RptTypeRelationVo>> temptableTypeMap = new HashMap<String, Map<String, RptTypeRelationVo>>();

			for (int i = 0; i < rpttyperelationbean.getRowType().size(); i++) {

				RptTypeRelationVo ronVo = rpttyperelationbean.getRowType().get(i);
				String selTypeRelVal = ronVo.getSelTypeRelVal();

				if (selTypeRelVal.indexOf("-") != -1) {

					String tblKey = selTypeRelVal.substring(0,
							selTypeRelVal.indexOf("-")).trim();
					if (rpttyperelationbean.getRowMap().containsKey(tblKey)) {
						temptableTypeMap.put(tblKey, rpttyperelationbean.getRowMap().get(tblKey));
					}
					ronVo.setSelTypeRelVal(selTypeRelVal);
					ronVo.setSelTypeRelValEedw(selTypeRelVal
							.substring(selTypeRelVal.indexOf("-") + 1));
				} else {
					if (rpttyperelationbean.getRowMap().containsKey(selTypeRelVal)) {
						temptableTypeMap.put(selTypeRelVal,
								rpttyperelationbean.getRowMap().get(selTypeRelVal));
					}
					ronVo.setSelTypeRelVal(selTypeRelVal);
					ronVo.setSelTypeRelValEedw(selTypeRelVal);
				}
				if (i == 0) {
					typeName = ronVo.getSelTypeRelVal();
				}
				rptSetngTypeRelList.add(ronVo);

				ronVo = null;
			}

			if (!loadStat) {
				tableTypeMap = rpttyperelationbean.getRowMap();
				getColumnsFrType(typeName);
			}
			// typeRelList=rpttyperelationbean.getRowType();
			tableTypeMap = temptableTypeMap;
		}
		
	}

	public void getColumnsFrType() throws PWiException {
		LOGGER.info("Entering getColumnsFrType");
		tableTypeMapCnt = 0;
		columnTypeMapCnt = 2;
		columnsList = new ArrayList<RptTypeRelationVo>();
		Map<String, RptTypeRelationVo> columnTypeMapLcl = new HashMap<String, RptTypeRelationVo>();
		LOGGER.info("Selected tableName >> " + tableName);
		if (tableName.indexOf("-") != -1) {
			selectedType = tableName.substring(tableName.indexOf("-") + 1)
					.trim();
			tableName = tableName.substring(0, tableName.indexOf("-")).trim();

		}
		else{
			selectedType = tableName.trim();
		}
		if (tableTypeMap.containsKey(tableName.trim())) {
			RptTypeRelationVo tempData = new RptTypeRelationVo();
			columnTypeMapLcl = tableTypeMap.get(tableName);
			for (Entry<String, RptTypeRelationVo> entry : columnTypeMapLcl
					.entrySet()) {
				tempData = columnTypeMapLcl.get(entry.getKey());
				columnsList.add(tempData);
			}
			Collections.sort(columnsList, new SortRowNumbers());

		} else {
			columnsList = rptTypeRelationService.getColumnsFrType(tableName);
		}

		if (columnsList.size() > 0) {
			columnsFlag = true;
		} else {
			columnsFlag = false;
		}
		LOGGER.info("columnsList size " + columnsList.size());
	}

	public void getColumnsFrType(String typName) throws PWiException {

		tableName = typName;
		getColumnsFrType();

	}

	private static class SortRowNumbers implements
			Comparator<RptTypeRelationVo>, Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(RptTypeRelationVo aInteger,
				RptTypeRelationVo bInteger) {
			int aInt;
			int bInt;
			int result = 0;
			aInt = aInteger.getRownum();
			bInt = bInteger.getRownum();
			if (aInt != 0 && bInt != 0) {
				result = aInt - bInt;
			}
			return result;

		}

	}

	public void saveColumnConfig() throws PWiException {
		LOGGER.info("Entering in to saveColumnConfig");
		columnTypeMap = new HashMap<String, RptTypeRelationVo>();
		boolean flag = true;
		for (RptTypeRelationVo relData : columnsList) {
			columnTypeMap.put(relData.getCoulmnName(), relData);
		}
		RptTypeRelationVo tempData = new RptTypeRelationVo();
		for (Entry<String, RptTypeRelationVo> entry : columnTypeMap.entrySet()) {
			tempData = columnTypeMap.get(entry.getKey());
			if (tempData.isToDelete()
					&& (tempData.getDisplayName().equals("")
							|| tempData.getInputType().equals("")
							|| tempData.getSearchOptr().size() == 0 || tempData
							.getSubstPlaceHldr().equals(""))) {
				handleFacesError("Please enter all required fields for the selected columns.");
				flag = false;
			}
		}

		if (flag) {
			if (tableTypeMap.containsKey(tableName)) {
				tableTypeMap.remove(tableName);
			}
			tableTypeMap.put(tableName, columnTypeMap);
			handleFacesInfo("Column configuration details for " + selectedType
					+ " has been saved");
		} else {
			if (tableTypeMap.containsKey(tableName)) {
				tableTypeMap.remove(tableName);
			}
		}
		tableTypeMapCnt = tableTypeMap.size();

	}

	/**
	 * @return the queryColumnService
	 */
	public RptTypeRelationService getRptTypeRelationService() {
		return rptTypeRelationService;
	}

	/**
	 * @param queryColumnService
	 *            the queryColumnService to set
	 */
	public void setQueryColumnService(
			RptTypeRelationService rptTypeRltnSvc) {
		this.rptTypeRelationService = rptTypeRltnSvc;
	}

	/**
	 * @return the tableName
	 */
	public String getTableName() {
		return tableName;
	}

	/**
	 * @param tableName
	 *            the tableName to set
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	/**
	 * @return the columnsList
	 */
	public List<RptTypeRelationVo> getColumnsList() {

		return columnsList;
	}

	/**
	 * @param columnsList
	 *            the columnsList to set
	 */
	public void setColumnsList(List<RptTypeRelationVo> columnsList1) {
		this.columnsList = columnsList1;
	}

	/**
	 * @return the columnsFlag
	 */
	public boolean isColumnsFlag() {
		return columnsFlag;
	}

	/**
	 * @param columnsFlag
	 *            the columnsFlag to set
	 */
	public void setColumnsFlag(boolean columnsFlag) {
		this.columnsFlag = columnsFlag;
	}

	/**
	 * @return
	 */
	public String getCheckStatus() {
		checkStatus = "";
		return checkStatus;
	}

	/**
	 * @param checkStatus1
	 */
	public void setCheckStatus(String checkStatus) {
		this.checkStatus = checkStatus;
	}

	/**
	 * @return the columnName
	 */
	public String getColumnName() {
		return columnName;
	}

	/**
	 * @param columnName
	 *            the columnName to set
	 */
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	/**
	 * @return the checkFlg
	 */
	public boolean isCheckFlg() {
	if(tableTypeMap!=null)
	{
		
		if (tableTypeMap.size() > 0) {
			checkFlg = true;
		}
	}

		return checkFlg;
	}

	/**
	 * @param checkFlg
	 *            the checkFlg to set
	 */
	public void setCheckFlg(boolean checkFlg) {
		this.checkFlg = checkFlg;
	}

	/*	*//**
	 * @return the RptTypeRelationVo
	 */
	/*
	 * public RptTypeRelationVo getRptTypeRelationVo() { return
	 * RptTypeRelationVo; }
	 *//**
	 * @param RptTypeRelationVo
	 *            the RptTypeRelationVo to set
	 */
	/*
	 * public void setRptTypeRelationVo(RptTypeRelationVo RptTypeRelationVo) {
	 * this.RptTypeRelationVo = RptTypeRelationVo; }
	 */

	/**
	 * @return the columnTypeMap
	 */
	public Map<String, RptTypeRelationVo> getColumnTypeMap() {
		return columnTypeMap;
	}

	/**
	 * @param columnTypeMap
	 *            the columnTypeMap to set
	 */
	public void setColumnTypeMap(Map<String, RptTypeRelationVo> columnTypeMap) {
		this.columnTypeMap = columnTypeMap;
	}

	/**
	 * @return the tableTypeMap
	 */
	public Map<String, Map<String, RptTypeRelationVo>> getTableTypeMap() {
		if(rpttyperelationbean!=null && rpttyperelationbean.getRowMap()!=null)
		{
			tableTypeMap = rpttyperelationbean.getRowMap();
		}
		return tableTypeMap;
	}

	/**
	 * @param tableTypeMap
	 *            the tableTypeMap to set
	 */
	public void setTableTypeMap(
			Map<String, Map<String, RptTypeRelationVo>> tableTypeMap) {
		this.tableTypeMap = tableTypeMap;
	}

	public void generateXML() throws JAXBException, PWiException,
			QueryAccessException {
		List<ColumnType> clmnTypeLst = new ArrayList<ColumnType>();
		List<DbobjectType> dbObjtypLst = new ArrayList<DbobjectType>();
		List<ColumnrefType> colRefTypLst = new ArrayList<ColumnrefType>();
		int count = 0;

		for (RptTypeRelationVo relTypVo : rpttyperelationbean.getRowType()) {

			String key = "";

			String selTypeRelVal = relTypVo.getSelTypeRelVal();
			if (selTypeRelVal.indexOf("-") != -1) {

				key = selTypeRelVal.substring(0, selTypeRelVal.indexOf("-"))
						.trim();

			} else {
				key = selTypeRelVal;
			}

			Map<String, RptTypeRelationVo> columnDtlsMap = tableTypeMap
					.get(key);
			
			DbobjectType dbObjTyp = new DbobjectType();
			dbObjTyp.setId(key.toLowerCase());
			dbObjTyp.setAlias("T" + count);
			dbObjtypLst.add(dbObjTyp);

			if (columnDtlsMap != null) {

				for (String key1 : columnDtlsMap.keySet()) {

					RptTypeRelationVo rptTypeRelationVo = columnDtlsMap
							.get(key1);
					if (rptTypeRelationVo.isToDelete()) {
						ColumnType clmnType = new ColumnType();
						List<AllowedoperatorsType> allowedoperators = new ArrayList<AllowedoperatorsType>();
						String colName = rptTypeRelationVo.getCoulmnName()
								.trim();
						clmnType.setColumndescription(colName);
						clmnType.setDisplayname(rptTypeRelationVo
								.getDisplayName().trim());
						if (rptTypeRelationVo.getSelectedSrchMandtry().equals(
								"yes")) {
							clmnType.setSearchcondmandatory(true);
						} else {
							clmnType.setSearchcondmandatory(false);
						}
						clmnType.setSearchable(true);
						clmnType.setId("T" + count + colName);
						DbfieldType dbFldTyp = new DbfieldType();
						dbFldTyp.setColumnref(colName);
						dbFldTyp.setFieldname(colName);
						clmnType.setDbfield(dbFldTyp);
						DbobjectrefType dbObjRefTyp = new DbobjectrefType();
						dbObjRefTyp.setRef(key.toLowerCase());
						clmnType.setDbobjectref(dbObjRefTyp);

						for (String alwdOprtr : rptTypeRelationVo
								.getSearchOptr()) {
							AllowedoperatorsType alwdOpType = new AllowedoperatorsType();
							ArrayList<JAXBElement<String>> opEqualOrOpLikeOrOpValue = new ArrayList<JAXBElement<String>>();
							if (alwdOprtr.equals("op_equal")) {
								JAXBElement<String> opEq = new JAXBElement<String>(
										new QName(
												"http://www.xml.pwi.geaviation.geinfra.com/query",
												"op_equal"), String.class,
										"op_equal");

								opEqualOrOpLikeOrOpValue.add(opEq);
							}

							if (alwdOprtr.equals("op_like")) {
								JAXBElement<String> opEq = new JAXBElement<String>(
										new QName(
												"http://www.xml.pwi.geaviation.geinfra.com/query",
												"op_like"), String.class,
										"op_like");

								opEqualOrOpLikeOrOpValue.add(opEq);
							}
							if (alwdOprtr.equals("op_value")) {
								JAXBElement<String> opEq = new JAXBElement<String>(
										new QName(
												"http://www.xml.pwi.geaviation.geinfra.com/query",
												"op_value"), String.class,
										"op_value");

								opEqualOrOpLikeOrOpValue.add(opEq);
							}
							if (alwdOprtr.equals("op_gt")) {
								JAXBElement<String> opEq = new JAXBElement<String>(
										new QName(
												"http://www.xml.pwi.geaviation.geinfra.com/query",
												"op_gt"), String.class, "op_gt");

								opEqualOrOpLikeOrOpValue.add(opEq);
							}
							if (alwdOprtr.equals("op_lt")) {
								JAXBElement<String> opEq = new JAXBElement<String>(
										new QName(
												"http://www.xml.pwi.geaviation.geinfra.com/query",
												"op_lt"), String.class, "op_lt");

								opEqualOrOpLikeOrOpValue.add(opEq);
							}
							if (alwdOprtr.equals("op_ne")) {
								JAXBElement<String> opEq = new JAXBElement<String>(
										new QName(
												"http://www.xml.pwi.geaviation.geinfra.com/query",
												"op_ne"), String.class, "op_ne");

								opEqualOrOpLikeOrOpValue.add(opEq);
							}
							if (alwdOprtr.equals("op_ge")) {
								JAXBElement<String> opEq = new JAXBElement<String>(
										new QName(
												"http://www.xml.pwi.geaviation.geinfra.com/query",
												"op_ge"), String.class, "op_ge");

								opEqualOrOpLikeOrOpValue.add(opEq);
							}
							if (alwdOprtr.equals("op_le")) {
								JAXBElement<String> opEq = new JAXBElement<String>(
										new QName(
												"http://www.xml.pwi.geaviation.geinfra.com/query",
												"op_le"), String.class, "op_le");

								opEqualOrOpLikeOrOpValue.add(opEq);
							}
							if (alwdOprtr.equals("op_nlike")) {
								JAXBElement<String> opEq = new JAXBElement<String>(
										new QName(
												"http://www.xml.pwi.geaviation.geinfra.com/query",
												"op_nlike"), String.class,
										"op_nlike");

								opEqualOrOpLikeOrOpValue.add(opEq);
							}
							if (alwdOprtr.equals("op_ge")) {
								JAXBElement<String> opEq = new JAXBElement<String>(
										new QName(
												"http://www.xml.pwi.geaviation.geinfra.com/query",
												"op_ge"), String.class, "op_ge");

								opEqualOrOpLikeOrOpValue.add(opEq);
							}

							alwdOpType
									.setOpEqualOrOpLikeOrOpValue(opEqualOrOpLikeOrOpValue);

							allowedoperators.add(alwdOpType);
						}
						clmnType.setAllowedoperators(allowedoperators);

						InputtypeType inptType = new InputtypeType();
						SelectionType slctTyp = new SelectionType();
						List<SelectionitemType> lstSelItmTyp = new ArrayList<SelectionitemType>();
						if (rptTypeRelationVo.getFillDesc() != null) {
							String[] multiVal = rptTypeRelationVo.getFillDesc()
									.split(",");
							if (multiVal != null) {
								for (String selMulVal : multiVal) {
									SelectionitemType selectionitemType = new SelectionitemType();
									selectionitemType.setLabel(selMulVal);
									selectionitemType.setValue(selMulVal);
									lstSelItmTyp.add(selectionitemType);
								}
							}
						}

						slctTyp.setItem(lstSelItmTyp);
						if (rptTypeRelationVo.getInputType().equals("combobox")) {
							inptType.setCombobox(slctTyp);
						} else if (rptTypeRelationVo.getInputType().equals(
								"multiselect")) {
							inptType.setMultiselect(slctTyp);
						} else if (rptTypeRelationVo.getInputType().equals(
								"lookup")) {
							inptType.setLookup(slctTyp);
						} else if (rptTypeRelationVo.getInputType().equals(
								"dropdown")) {
							inptType.setDropdown(slctTyp);
						} else if (rptTypeRelationVo.getInputType().equals(
								"datepicker")) {
							DatepickerType dtPckr = new DatepickerType();
							dtPckr.setFormat("MM/dd/yyyy");
							inptType.setDatepicker(dtPckr);
						} else if (rptTypeRelationVo.getInputType().equals(
								"text")) {
							inptType = null;
						}

						clmnType.setInputtype(inptType);
						clmnTypeLst.add(clmnType);

						

						ColumnrefType clmRefTyp = new ColumnrefType();
						clmRefTyp.setRef("T" + count + colName);
						colRefTypLst.add(clmRefTyp);
					}
				}
			}
			count++;
		}
		QuerycustomizationType querycustomizationType = new QuerycustomizationType();
		SelectType slctTyp = new SelectType();
		SelectedType selctedTyp = new SelectedType();
		selctedTyp.setColumnref(colRefTypLst);
		AvailableType avlTyp = new AvailableType();
		avlTyp.setColumnref(colRefTypLst);
		slctTyp.setAvailable(avlTyp);
		slctTyp.setSelected(selctedTyp);
		querycustomizationType.setSelect(slctTyp);
		PdfinfoType pdfinfoTyp = new PdfinfoType();
		pdfinfoTyp.setPdfheader("");
		pdfinfoTyp.setPdffooter("");
		QueryfeaturesType queryfeaturesType = new QueryfeaturesType();
		queryfeaturesType.setPdfinfo(pdfinfoTyp);
		ColumnlistType columnlistType = new ColumnlistType();
		columnlistType.setColumn(clmnTypeLst);
		DbobjectlistType dbobjectlistType = new DbobjectlistType();
		dbobjectlistType.setDbobject(dbObjtypLst);
		SqlExecutorXml sqlExcXml = new SqlExecutorXml();
		sqlExcXml.setDsn("plmrterads");
		sqlExcXml.setSql(getSql());
		QuerydefinitionType querydefinitionType = new QuerydefinitionType();
		querydefinitionType.setColumnlist(columnlistType);
		querydefinitionType.setDbobjectlist(dbobjectlistType);
		querydefinitionType.setExecutor(sqlExcXml);
		querydefinitionType.setQuerycustomization(querycustomizationType);
		querydefinitionType.setQueryfeatures(queryfeaturesType);
		QueryType queryType = new QueryType();
		queryType.setQuerydescription("Report Template 1");
		queryType.setTitle("Report Template tit 1");
		queryType.setAppid("Report Template app 1");
		queryType.setQuerydefinition(querydefinitionType);
		// NeighborlistType
		QueryXmlReader queryXmlReader = new QueryXmlReader();
		generatedXml = queryXmlReader.generateXml(queryType);
		generatedXml = generatedXml.replace("&lt;", "<").replace("&gt;", ">");
		
		ELContext elContext = FacesContext.getCurrentInstance().getELContext();
		QueryBuilderBean queryBuilderBean = (QueryBuilderBean) elContext
				.getELResolver().getValue(elContext, null, "queryBuilderBean");
		queryBuilderBean.actionxmlQuery();

		LOGGER.info("Selected tab before========"
				+ rpttyperelationbean.getSelectedTabName());
		rpttyperelationbean.setSelectedTabName("tab3");
		LOGGER.info("Selected tab after========"
				+ rpttyperelationbean.getSelectedTabName());

	}

	public int getTableTypeMapCnt() {
		return tableTypeMapCnt;
	}

	/**
	 * @param tableTypeMapCnt
	 *            the tableTypeMapCnt to set
	 */
	public void setTableTypeMapCnt(int tableTypeMapCnt) {
		this.tableTypeMapCnt = tableTypeMapCnt;
	}

	/**
	 * @return the columnTypeMapCnt
	 */
	public int getColumnTypeMapCnt() {
		return columnTypeMapCnt;
	}

	/**
	 * @param columnTypeMapCnt
	 *            the columnTypeMapCnt to set
	 */
	public void setColumnTypeMapCnt(int columnTypeMapCnt) {
		this.columnTypeMapCnt = columnTypeMapCnt;
	}

	public String getSql() {
		List<String> tblList = new ArrayList<String>();
		StringBuilder plcHoldr = new StringBuilder("");
		plcHoldr.append(System.getProperty("line.separator"));
		plcHoldr.append(" WHERE 1=1 ");
		for (String key : tableTypeMap.keySet()) {

			tblList.add(key);

		}

		DbSpec spec = new DbSpec();
		DbSchema schema = spec.addSchema(LoadProps.getInstance().loadProps(
				DB_SCHEMA));

		// add table with basic customer info
		DbTable customerTable = null;
		SelectQuery sqr = new SelectQuery();
		for (int countTbl = 0; countTbl < rpttyperelationbean.getRowType()
				.size(); countTbl++) {

			String tableNameLcl = "";
			RptTypeRelationVo ronVo = rpttyperelationbean.getRowType().get(
					countTbl);
			String selTypeRelVal = ronVo.getSelTypeRelVal();
			if (selTypeRelVal.indexOf("-") != -1) {

				tableNameLcl = selTypeRelVal.substring(0,
						selTypeRelVal.indexOf("-")).trim();

			} else {
				tableNameLcl = selTypeRelVal;
			}

			// String tableName = tblList.get(a);
			DbTable customerTable1 = customerTable;
			customerTable = schema.addTable(tableNameLcl);
			Map<String, RptTypeRelationVo> columnDtlsMap = tableTypeMap
					.get(tableNameLcl);

			if (columnDtlsMap != null) {
				for (String colName : columnDtlsMap.keySet()) {

					RptTypeRelationVo rptTypeRelationVo = columnDtlsMap
							.get(colName);
					if (rptTypeRelationVo.isToDelete()) {
						sqr.addAliasedColumn(
								customerTable.addColumn(colName.trim()), "T"
										+ countTbl + colName.trim());
						if (rptTypeRelationVo.getSubstPlaceHldr().equals("and")) {
							plcHoldr.append(System
									.getProperty("line.separator"));
							plcHoldr.append(" $and$substitute{");
							plcHoldr.append("T" + countTbl + colName.trim());
							plcHoldr.append("}$");
							plcHoldr.append(System
									.getProperty("line.separator"));

						} else if (rptTypeRelationVo.getSubstPlaceHldr()
								.equals("or")) {
							plcHoldr.append(System
									.getProperty("line.separator"));
							plcHoldr.append(" $or$substitute{");
							plcHoldr.append("T" + countTbl + colName.trim());
							plcHoldr.append("}$");

						} else if (rptTypeRelationVo.getSubstPlaceHldr()
								.equals("date")) {
							plcHoldr.append(System
									.getProperty("line.separator"));
							plcHoldr.append(" $date$substitute{");
							plcHoldr.append("T" + countTbl + colName.trim());
							plcHoldr.append("}$");
							plcHoldr.append(System
									.getProperty("line.separator"));
						}
					}

				}
			}

			if (countTbl != 0) {
				if (countTbl % 2 == 0) {
					sqr.addJoin(SelectQuery.JoinType.INNER, customerTable1,
							customerTable, customerTable1.addColumn("to_id"),
							customerTable.addColumn("id"));

				} else {
					sqr.addJoin(SelectQuery.JoinType.INNER, customerTable1,
							customerTable, customerTable1.addColumn("id"),
							customerTable.addColumn("from_id"));
				}

			}
			// sqr.addJoin(
		}

		String genSql = sqr.toString();
		genSql = "<![CDATA[ " + genSql + plcHoldr + " ]]>";
		LOGGER.debug("generated Query= " + genSql);
		return genSql;
	}

}
