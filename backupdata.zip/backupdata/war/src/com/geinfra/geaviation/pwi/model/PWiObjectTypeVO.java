package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;
import java.util.Date;

import com.geinfra.geaviation.pwi.json.JsonBuilder;
import com.geinfra.geaviation.pwi.json.Jsonable;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : PWiObjectTypeVO - Object Type object.
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiObjectTypeVO extends PWiBaseVO implements Serializable,
		Jsonable {
	private static final long serialVersionUID = 2L;
	private Integer objTypSeqId;
	private String objTypNm;
	private String objTypDesc;
	private boolean shwInQi;
	private StringBuffer groupNames = new StringBuffer();

	public PWiObjectTypeVO() {
	}

	public PWiObjectTypeVO(Integer objTypSeqId) {
		this.objTypSeqId = objTypSeqId;
	}

	public PWiObjectTypeVO(Integer objTypSeqId, String objTypNm, String objTypDesc, Date crtnDt,
			String crtdBy, Date lstUpdtDt, String lstUpdtdBy) {
		super(crtnDt, crtdBy, lstUpdtDt, lstUpdtdBy);
		this.objTypSeqId = objTypSeqId;
		this.objTypNm = objTypNm;
		this.objTypDesc = objTypDesc;
	}

	public Integer getObjTypSeqId() {
		return objTypSeqId;
	}

	public void setObjTypSeqId(Integer objTypSeqId) {
		this.objTypSeqId = objTypSeqId;
	}

	public String getObjTypNm() {
		return objTypNm;
	}

	public void setObjTypNm(String objTypNm) {
		this.objTypNm = objTypNm;
	}

	public String getObjTypDesc() {
		return objTypDesc;
	}

	public void setObjTypDesc(String objTypDesc) {
		this.objTypDesc = objTypDesc;
	}

	public boolean isShwInQi() {
		return shwInQi;
	}

	public void setShwInQi(boolean shwInQi) {
		this.shwInQi = shwInQi;
	}
	
	public String getGroupNames() {
		return groupNames.toString();
	}
	
	public void clearGroupNames() {
		groupNames = new StringBuffer();
	}
	
	public void addGroupName(String groupName) {
		if (groupNames.length() > 0) {
			// if this is not the first group name, delimit with a line break
			groupNames.append("<br/>");
		}
		// add the new group name
		groupNames.append(groupName != null ? groupName : "");
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (objTypSeqId != null ? objTypSeqId.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object instanceof PWiObjectTypeVO) {
			PWiObjectTypeVO other = (PWiObjectTypeVO) object;
			if (this.objTypSeqId != null && other.objTypSeqId != null) {
				return this.objTypSeqId.equals(other.objTypSeqId);
			}
		}
		return false;
	}

	@Override
	public String toString() {
		return (null != this.getObjTypNm() ? this.getObjTypNm() : "");
	}

	public String toJson() {
		JsonBuilder builder = new JsonBuilder();
		builder.startObject();
		builder.addStringProperty("id", objTypSeqId);
		builder.addStringProperty("name", objTypNm);
		builder.addStringProperty("description", objTypDesc);
		builder.addBooleanProperty("showInQi", shwInQi);
		builder.endObject();
		return builder.toString();
	}
}
