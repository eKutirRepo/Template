/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PWiOdsTypes.java
 * @Creation date: 18-Aug-2014
 * @version 1.0
  * @author : Tech Mahindra
 */
package com.geinfra.geaviation.pwi.model;

import java.util.Enumeration;

import javax.swing.tree.TreeNode;

public class PWiOdsTypes  extends NamedNode implements TreeNode {
   
 
    public PWiOdsTypes() {
        this.setType("types");
    }
 
    public TreeNode getChildAt(int childIndex) {
        return null;
    }
 
    public int getChildCount() {
        return 0;
    }
 
    public TreeNode getParent() {
        return null;
    }
 
    public int getIndex(TreeNode node) {
        return 0;
    }
 
    public boolean getAllowsChildren() {
        return true;
    }

	@Override
	public boolean isLeaf() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Enumeration children() {
		// TODO Auto-generated method stub
		return null;
	}
 
  
}
