/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBomHealthMB.java
 * @Creation date: 15-June-2011
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team) 
 */

package com.geinfra.geaviation.pwi.bean;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.data.PLMBomHealthData;
import com.geinfra.geaviation.pwi.service.PLMMetricsServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

/**
 * PLMBomHealthMB is the managed bean class .
 */

public class PLMBomHealthMB {
	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMBomHealthMB.class);
	/**
	 * Holds the bomHealthData
	 */
	private PLMBomHealthData bomHealthData = null;
	/**
	 * Holds the PLMMetricsServiceIfc
	 */
	private PLMMetricsServiceIfc plmMetricsService  = null;
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB=null;
	
	/**
	 * Holds the alert messgae
	 */
	private String alertMessage;
	/**
	 * Holds the searchResultList
	 */
	private List<PLMBomHealthData> searchResultList;
	/**
	 * Holds the partSearchResultList
	 */
	private List<PLMBomHealthData> partSearchResultList;
	/**
	 * Holds the ppartSearchResultList
	 */
	private List<PLMBomHealthData> ppartSearchResultList;
	/**
	 * Holds the qpartSearchResultList
	 */
	private List<PLMBomHealthData> qpartSearchResultList;
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the partRecCountMsg
	 */
	private String partRecCountMsg;
	/**
	 * Holds the partRecCounts
	 */
	private int partRecCounts = PLMConstants.N_100;

	/**
	 * This method is used for Load Bom Health Page
	 * 
	 * @return String
	 */
	public String loadBomHealthPage() {
		LOG.info("Entering loadBomHealthPage Method ");
		String fwdflag = "";
		
		bomHealthData = new PLMBomHealthData();
		fwdflag = "bomhealthsearch";
		
		try {	
			commonMB.insertCannedRptRecordHitInfo("BOM-Health");
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", exception);
		} 
		
		try {	
			commonMB.getLegacyDateStamp();
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getLegacyDateStamp: ", exception);
		} 
		
		LOG.info("Exiting loadBomHealthPage Method ");
		return fwdflag;
	}

	/**
	 * This method is used for Load Bom Health Report
	 * 
	 * @return String
	 */
	public String getBomHealthReport() {
		LOG.info("Entering getBomHealthReport Method ");
		String fwdflag = "";
		if (PLMUtils.isEmpty(bomHealthData.getMlno())) {
			alertMessage = PLMConstants.BOM_SEARCH_CRITERIA;
		}
		else if(!PLMUtils.checkForSpecialChars(bomHealthData.getMlno())){
			alertMessage = PLMConstants.BOM_SEARCH_SPL_CRITERIA;
		}
		else {
			try {
				searchResultList = plmMetricsService
						.getBomHealthReport(bomHealthData);
				if (searchResultList != null) {
					totalRecCount = searchResultList.size();
				} else {
					totalRecCount = 0;
				}
				if (totalRecCount == 0)
					fwdflag = "invalidbomhealthsearch";
				else
					fwdflag = "bomhealthreport";
				LOG.info("Total Results Count" + totalRecCount);
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getBomHealthReport: ", exception);
				fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"bomhealthsearch","BOM Health");
			} 
		}
		LOG.info("Exiting getBomHealthReport Method ");
		return fwdflag;
	}
	/**
	 * This method is used for Load Part Report
	 * 
	 * @return String
	 */
	public String getPartReport() {
		LOG.info("Entering getPartReport Method ");
		String fwdflag = "";
		try {
			partSearchResultList = plmMetricsService
					.getPartReport(bomHealthData);
			if (partSearchResultList != null) {
				totalRecCount = partSearchResultList.size();
			} else {
				totalRecCount = 0;
			}
			if (totalRecCount == 0)
				fwdflag = "";
			else {
				if (PLMUtils.getServletSession(true)
						.getAttribute("RecDropDown") != null
						&& !""
								.equals((PLMUtils.getServletSession(true)
										.getAttribute("RecDropDown"))
										.toString().trim())) {
					if (!PLMUtils.setNewDropDownValue(Integer.parseInt(PLMUtils
							.getServletSession(true)
							.getAttribute("RecDropDown").toString()))) {
						partRecCounts = Integer.parseInt(PLMUtils
								.getServletSession(true).getAttribute(
										"RecDropDown").toString());
					} else {
						partRecCounts = totalRecCount;
					}
				} else {
					partRecCounts = PLMConstants.N_100;
				}
				fwdflag = "bompartreport";
				partRecCountMsg = "Total Results Count : " + totalRecCount;
			}
			LOG.info("Total Results Count" + totalRecCount);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPartReport: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"bomhealthreport","BOM Health");
		} 
		LOG.info("Exiting getPartReport Method ");
		return fwdflag;
	}

	/**
	 * This method is used for Load Quantity Part Report
	 * 
	 * @return String
	 */
	public String getQPartReport() {
		LOG.info("Entering getQPartReport Method ");
		String fwdflag = "";
		try {
			qpartSearchResultList = plmMetricsService
					.getQPartReport(bomHealthData);
			if (qpartSearchResultList != null) {
				totalRecCount = qpartSearchResultList.size();
			} else {
				totalRecCount = 0;
			}
			if (totalRecCount == 0)
				fwdflag = "";
			else {
				if (PLMUtils.getServletSession(true)
						.getAttribute("RecDropDown") != null
						&& !""
								.equals((PLMUtils.getServletSession(true)
										.getAttribute("RecDropDown"))
										.toString().trim())) {
					if (!PLMUtils.setNewDropDownValue(Integer.parseInt(PLMUtils
							.getServletSession(true)
							.getAttribute("RecDropDown").toString()))) {
						partRecCounts = Integer.parseInt(PLMUtils
								.getServletSession(true).getAttribute(
										"RecDropDown").toString());
					} else {
						partRecCounts = totalRecCount;
					}
				} else {
					partRecCounts = PLMConstants.N_100;
				}
				fwdflag = "bomqpartreport";
				partRecCountMsg = "Total Results Count : " + totalRecCount;
			}
			LOG.info("Total Results Count" + totalRecCount);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getQPartReport: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"bomhealthreport","BOM Health");
		} 
		LOG.info("Exiting getQPartReport Method ");
		return fwdflag;
	}

	/**
	 * This method is used for Load Parent Part Report
	 * 
	 * @return String
	 */
	public String getPPartReport() {
		LOG.info("Entering getPPartReport Method ");
		String fwdflag = "";
		try {
			ppartSearchResultList = plmMetricsService
					.getPPartReport(bomHealthData);
			if (ppartSearchResultList != null) {
				totalRecCount = ppartSearchResultList.size();
			} else {
				totalRecCount = 0;
			}
			if (totalRecCount == 0)
				fwdflag = "";
			else {
				if (PLMUtils.getServletSession(true)
						.getAttribute("RecDropDown") != null
						&& !""
								.equals((PLMUtils.getServletSession(true)
										.getAttribute("RecDropDown"))
										.toString().trim())) {
					if (!PLMUtils.setNewDropDownValue(Integer.parseInt(PLMUtils
							.getServletSession(true)
							.getAttribute("RecDropDown").toString()))) {
						partRecCounts = Integer.parseInt(PLMUtils
								.getServletSession(true).getAttribute(
										"RecDropDown").toString());
					} else {
						partRecCounts = totalRecCount;
					}
				} else {
					partRecCounts = PLMConstants.N_100;
				}
				fwdflag = "bomppartreport";
				partRecCountMsg = "Total Results Count : " + totalRecCount;
			}
			LOG.info("Total Results Count" + totalRecCount);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPPartReport: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"bomhealthreport","BOM Health");
		} 
		LOG.info("Exiting getPPartReport Method ");
		return fwdflag;
	}
	
	/**
	 * This method is used to download excel for BOM health report results
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadBOMHealthReportExcel() throws PLMCommonException {
		LOG.info("Entering downloadBOMHealthReportExcel Method");
		String reportName = "bomHealthReport";
		String fileName = "bomHealthReport";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		//Export to Excel for BOM Health Report
		
		PLMXlsxRptColumn[] critcolumns  = new PLMXlsxRptColumn[] {
                new PLMXlsxRptColumn("mlno", "ML/MPL #:", FormatType.TEXT)
                };
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					  new PLMXlsxRptColumn("mlno", "ML/MPL #", FormatType.TEXT, null, null, 20),
					  new PLMXlsxRptColumn("defectsbypartnumber", "Config. Feature Option Name", FormatType.TEXT, null, null, 28),
					  new PLMXlsxRptColumn("defectsbyqpartnumber", "# of Changes by Quantity of Part number", FormatType.TEXT, null, null, 35),
					  new PLMXlsxRptColumn("defectsbyppartnumber", "# of Changes by Parent", FormatType.TEXT, null, null, 21),
					  new PLMXlsxRptColumn("opportunites", "# of Opportunities", FormatType.TEXT)
			};
			
			excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, bomHealthData);	
		
			LOG.info("Exiting downloadBOMHealthReportExcel Method");
	}
	
	/**
	 * This method is used to download excel for BOM part report results
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	
	public void downloadBOMPartReportExcel() throws PLMCommonException {
		LOG.info("Entering downloadBOMPartReportExcel Method");
		String reportName = "PartDefectsResults";
		String fileName = "PartDefectsResults";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		//Export to Excel for Parts Defect Report
				PLMXlsxRptColumn[] critcolumns  = new PLMXlsxRptColumn[] {
		                new PLMXlsxRptColumn("mlno", "ML/MPL #:", FormatType.TEXT)
		                };
					
					PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
							  new PLMXlsxRptColumn("parentitemnumber", "Parent Item Number", FormatType.TEXT, null, null, 20),
							  new PLMXlsxRptColumn("wasitemnumber", "Was Item Number", FormatType.TEXT, null, null, 28),
							  new PLMXlsxRptColumn("isitemnumber", "Is Item Number", FormatType.TEXT, null, null, 28),
							  new PLMXlsxRptColumn("dcinumber", "DCI Number", FormatType.TEXT),
							  new PLMXlsxRptColumn("actionflag", "Action Flag",FormatType.TEXT),
							  new PLMXlsxRptColumn("newitemindicator", "New Item Indicator", FormatType.TEXT),
							  new PLMXlsxRptColumn("icnnumber", "ICN Number", FormatType.TEXT),
							  new PLMXlsxRptColumn("rootcause", "Root Cause", FormatType.TEXT),
							  new PLMXlsxRptColumn("ordernumber", "Order Number", FormatType.TEXT)
					};
					
			excelUtil.export(partSearchResultList, reportColumns, fileName, fileName, true, critcolumns, bomHealthData);
			
			LOG.info("Exiting downloadBOMPartReportExcel Method");
	}	
	/**
	 * This method is used to download excel for BOM Q part report results
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadBOMQPartReportExcel() throws PLMCommonException {
		LOG.info("Entering downloadBOMQPartReportExcel Method");
		String reportName = "QuantityPartDefectsResults";
		String fileName = "QuantityPartDefectsResults";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		//Export to Excel for Quantity Parts Report
				PLMXlsxRptColumn[] critcolumns  = new PLMXlsxRptColumn[] {
		                new PLMXlsxRptColumn("mlno", "ML/MPL #:", FormatType.TEXT)
		                };
					
					PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
							  new PLMXlsxRptColumn("parentitemnumber", "Parent Item Number", FormatType.TEXT, null, null, 20),
							  new PLMXlsxRptColumn("isitemnumber", "Is Item Number", FormatType.TEXT, null, null, 28),
							  new PLMXlsxRptColumn("wasitemquantity", "Was Item Qty", FormatType.TEXT),
							  new PLMXlsxRptColumn("isitemquantity", "Is Item Qty", FormatType.TEXT),
							  new PLMXlsxRptColumn("dcinumber", "DCI Number", FormatType.TEXT),
							  new PLMXlsxRptColumn("actionflag", "Action Flag",FormatType.TEXT),
							  new PLMXlsxRptColumn("newitemindicator", "New Item Indicator", FormatType.TEXT),
							  new PLMXlsxRptColumn("icnnumber", "ICN Number", FormatType.TEXT),
							  new PLMXlsxRptColumn("rootcause", "Root Cause", FormatType.TEXT),
							  new PLMXlsxRptColumn("ordernumber", "Order Number", FormatType.TEXT)
					};
					
			excelUtil.export(qpartSearchResultList, reportColumns, fileName, fileName, true, critcolumns, bomHealthData);
			
			LOG.info("Exiting downloadBOMQPartReportExcel Method");
	}
	
	/**
	 * This method is used to download excel for BOM P part report results
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadBOMPPartReportExcel() throws PLMCommonException {
		LOG.info("Entering downloadBOMPPartReportExcel Method");
		String reportName = "ParentPartDefectsResults";
		String fileName = "ParentPartDefectsResults";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		//Export to Excel for Parent Parts Report
		PLMXlsxRptColumn[] critcolumns  = new PLMXlsxRptColumn[] {
                new PLMXlsxRptColumn("mlno", "ML/MPL #:", FormatType.TEXT)
                };
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					  new PLMXlsxRptColumn("parentitemnumber", "Parent Item Number", FormatType.TEXT, null, null, 20),
					  new PLMXlsxRptColumn("isitemnumber", "Is Item Number", FormatType.TEXT, null, null, 28),
					  new PLMXlsxRptColumn("dcinumber", "DCI Number", FormatType.TEXT),
					  new PLMXlsxRptColumn("actionflag", "Action Flag", FormatType.TEXT),
					  new PLMXlsxRptColumn("icnnumber", "ICN Number", FormatType.TEXT),
					  new PLMXlsxRptColumn("rootcause", "Root Cause", FormatType.TEXT),
					  new PLMXlsxRptColumn("ordernumber", "Order Number", FormatType.TEXT)
			};
			
			excelUtil.export(ppartSearchResultList, reportColumns, fileName, fileName, true, critcolumns, bomHealthData);	
		
			LOG.info("Exiting downloadBOMPPartReportExcel Method");
	}
	
	/**
	 * This method is used to download csv for BOM health report results
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	
	public void downloadBOMHealthReportCSV() throws PLMCommonException {
		LOG.info("Entering downloadBOMHealthReportCSV Method");
		String reportName = "bomHealthReport";
		String fileName = "bomHealthReport";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
				
		//Export to CSV for BOM Health Report
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					  new PLMCsvRptColumn("mlno", "ML/MPL #", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("defectsbypartnumber", "Config. Feature Option Name", FormatTypeCsv.INTEGER),
					  new PLMCsvRptColumn("defectsbyqpartnumber", "# of Changes by Quantity of Part number", FormatTypeCsv.INTEGER),
					  new PLMCsvRptColumn("defectsbyppartnumber", "# of Changes by Parent", FormatTypeCsv.INTEGER),
					  new PLMCsvRptColumn("opportunites", "# of Opportunities", FormatTypeCsv.INTEGER)
			};
		
			csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, false, null, null, ",");
			LOG.info("Exiting downloadBOMHealthReportCSV Method");
		
		/*PrintWriter pwriter = null;

		try {
			
			FacesContext facesContext = FacesContext.getCurrentInstance();

			HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
			HttpServletRequest resquest = (HttpServletRequest) facesContext.getExternalContext().getRequest();
			
			HttpSession session = resquest.getSession();
			
			response.setContentType("application/CSV");
			   response.setHeader("content-disposition","attachment; filename=bomHealthReport.csv");
			   
			   pwriter = response.getWriter();
			   
			   PLMBomHealthMB searchMB = (PLMBomHealthMB)session.getAttribute("plmBomHealthMB");
			   
			   	pwriter.write("ML/MPL #");
	 			pwriter.write(",");
	  			pwriter.write("# of Changes by Part Number");
	 			pwriter.write(",");
	 			pwriter.write("# of Changes by Quantity of Part number");
	 			pwriter.write(",");
	 			pwriter.write("# of Changes by Parent");
	 			pwriter.write(",");
	 			pwriter.write("# of Opportunities");
	 			
	  			pwriter.write("\n");
	 			
			   if(searchMB != null && searchMB.getSearchResultList() != null &&  searchMB.getSearchResultList().size() > 0) {
				 		     		
			   		for(int i=0; i<searchMB.getSearchResultList().size(); i++) {
			   			PLMBomHealthData dataObj = (PLMBomHealthData)searchMB.getSearchResultList().get(i);
			   			if(dataObj.getMlno()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getMlno()));
				   		}	
			   			pwriter.write(",");
			   			pwriter.write(Integer.toString(dataObj.getDefectsbypartnumber()));
			   			pwriter.write(",");
			   			pwriter.write(Integer.toString(dataObj.getDefectsbyqpartnumber()));
			   			pwriter.write(",");
			   			pwriter.write(Integer.toString(dataObj.getDefectsbyppartnumber()));
			   			pwriter.write(",");
			   			pwriter.write(Integer.toString(dataObj.getOpportunites()));		   			
			   			pwriter.write("\n");
			   			
			   		}
			   		
			   }
			   pwriter.flush(); 
		} catch (FileNotFoundException e) {
			System.out.println("The exception is : " + e);
		} catch (Exception e1) {
			System.out.println("IOException : " + e1.getMessage());
		} finally {
			try {
				if (pwriter != null) {
					pwriter.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
		}*/
	}
	
	/**
	 * This method is used to download csv for BOM part report results
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadBOMPartReportCSV() throws PLMCommonException {
		LOG.info("Entering downloadBOMPartReportCSV Method");
		String reportName = "ParentPartDefectsResults";
		String fileName = "ParentPartDefectsResults";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		//Export to CSV for Parent Parts Report
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
				 new PLMCsvRptColumn("parentitemnumber", "Parent Item Number", FormatTypeCsv.TEXT),
				  new PLMCsvRptColumn("wasitemnumber", "Was Item Number", FormatTypeCsv.TEXT),
				  new PLMCsvRptColumn("isitemnumber", "Is Item Number", FormatTypeCsv.TEXT),
				  new PLMCsvRptColumn("dcinumber", "DCI Number", FormatTypeCsv.TEXT),
				  new PLMCsvRptColumn("actionflag", "Action Flag",FormatTypeCsv.TEXT),
				  new PLMCsvRptColumn("newitemindicator", "New Item Indicator", FormatTypeCsv.TEXT),
				  new PLMCsvRptColumn("icnnumber", "ICN Number", FormatTypeCsv.TEXT),
				  new PLMCsvRptColumn("rootcause", "Root Cause", FormatTypeCsv.TEXT),
				  new PLMCsvRptColumn("ordernumber", "Order Number", FormatTypeCsv.TEXT)
			};
			
		   csvUtil.exportCsv(partSearchResultList, reportColumns, fileName, dateFormat, false, null, null, ",");
		   
		 LOG.info("Exiting downloadBOMPartReportCSV Method");
		 
		 /*PrintWriter pwriter = null;

		try {
			
			FacesContext facesContext = FacesContext.getCurrentInstance();

			HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
			HttpServletRequest resquest = (HttpServletRequest) facesContext.getExternalContext().getRequest();
			
			HttpSession session = resquest.getSession();
			
			response.setContentType("application/CSV");
			   response.setHeader("content-disposition","attachment; filename=bompartreport.csv");
			   pwriter = response.getWriter();
			   PLMBomHealthMB partreportMB = (PLMBomHealthMB)session.getAttribute("plmBomHealthMB");
			   
			    pwriter.write("Parent Item Number");
	 			pwriter.write(",");
	  			pwriter.write("Was Item Number");
	 			pwriter.write(",");
	 			pwriter.write("Is Item Number");
	 			pwriter.write(",");
	 			pwriter.write("DCI Number");
	 			pwriter.write(",");
	 			pwriter.write("Action Flag");
	 			pwriter.write(",");
	 			pwriter.write("New Item Indicator");
	 			pwriter.write(",");
	 			pwriter.write("ICN Number");
	  			pwriter.write(",");
	  			pwriter.write("Root Cause");
	 			pwriter.write(",");
	 			pwriter.write("Order Number");
	 			pwriter.write(",");
	 			pwriter.write("\n");
	 			
			   if(partreportMB != null && partreportMB.getPartSearchResultList()!= null &&  partreportMB.getPartSearchResultList().size() > 0) {
					     		
			   		for(int i=0; i<partreportMB.getPartSearchResultList().size(); i++) {
			   			PLMBomHealthData dataObj = (PLMBomHealthData)partreportMB.getPartSearchResultList().get(i);
			   			if(dataObj.getParentitemnumber()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getParentitemnumber()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getWasitemnumber()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getWasitemnumber()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getIsitemnumber()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getIsitemnumber()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getDcinumber()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDcinumber()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getActionflag()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getActionflag()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getNewitemindicator()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getNewitemindicator()));
			   			}
			   			pwriter.write(",");
			   			if(dataObj.getIcnnumber()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getIcnnumber()));
			   			}
			   			pwriter.write(",");
			   			if(dataObj.getRootcause()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRootcause()));
			   			}
			   			pwriter.write(",");
			   			if(dataObj.getOrdernumber()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOrdernumber()));
			   			}
			   			pwriter.write("\n");
			   		}
				}
			   	pwriter.flush(); 
		} catch (FileNotFoundException e) {
			System.out.println("The exception is : " + e);
		} catch (Exception e1) {
			System.out.println("IOException : " + e1.getMessage());
		} finally {
			try {
				if (pwriter != null) {
					pwriter.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
		}*/
	}
	
	/**
	 * This method is used to download csv for BOM Q part report results
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadBOMQPartReportCSV() throws PLMCommonException {
		
		LOG.info("Entering downloadBOMQPartReportCSV Method");
		String reportName = "QuantityPartDefectsResults";
		String fileName = "QuantityPartDefectsResults";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		//Export to CSV for Quantity Parts Report
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
							  new PLMCsvRptColumn("parentitemnumber", "Parent Item Number", FormatTypeCsv.TEXT),
							  new PLMCsvRptColumn("isitemnumber", "Is Item Number", FormatTypeCsv.TEXT),
							  new PLMCsvRptColumn("wasitemquantity", "Was Item Qty", FormatTypeCsv.TEXT),
							  new PLMCsvRptColumn("isitemquantity", "Is Item Qty", FormatTypeCsv.TEXT),
							  new PLMCsvRptColumn("dcinumber", "DCI Number", FormatTypeCsv.TEXT),
							  new PLMCsvRptColumn("actionflag", "Action Flag",FormatTypeCsv.TEXT),
							  new PLMCsvRptColumn("newitemindicator", "New Item Indicator", FormatTypeCsv.TEXT),
							  new PLMCsvRptColumn("icnnumber", "ICN Number", FormatTypeCsv.TEXT),
							  new PLMCsvRptColumn("rootcause", "Root Cause", FormatTypeCsv.TEXT),
							  new PLMCsvRptColumn("ordernumber", "Order Number", FormatTypeCsv.TEXT)
					};
		    csvUtil.exportCsv(qpartSearchResultList, reportColumns, fileName, dateFormat, false, null, null, ",");	
			LOG.info("Exiting downloadBOMQPartReportCSV Method");

		/*PrintWriter pwriter = null;

		try {
			
			FacesContext facesContext = FacesContext.getCurrentInstance();

			HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
			HttpServletRequest resquest = (HttpServletRequest) facesContext.getExternalContext().getRequest();
			
			HttpSession session = resquest.getSession();
			
			response.setContentType("application/CSV");
			   response.setHeader("content-disposition","attachment; filename=bomqpartreport.csv");
			   pwriter = response.getWriter();
			   PLMBomHealthMB qpartreportMB = (PLMBomHealthMB)session.getAttribute("plmBomHealthMB");
			   
			    pwriter.write("Parent Item Number");
	 			pwriter.write(",");
	  			pwriter.write("Is Item Number");
	 			pwriter.write(",");
	 			pwriter.write("Was Item Qty");
	 			pwriter.write(",");
	 			pwriter.write("Is Item Qty");
	 			pwriter.write(",");
	 			pwriter.write("DCI Number");
	 			pwriter.write(",");
	 			pwriter.write("Action Flag");
	 			pwriter.write(",");
	 			pwriter.write("New Item Indicator");
	 			pwriter.write(",");
	 			pwriter.write("ICN Number");
	  			pwriter.write(",");
	  			pwriter.write("Root Cause");
	  			pwriter.write(",");
	 			pwriter.write("Order Number");
	 			pwriter.write(",");
	 			pwriter.write("\n");
	 			
	 			SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
	   		
			   if(qpartreportMB != null && qpartreportMB.getQpartSearchResultList()!= null &&  qpartreportMB.getQpartSearchResultList().size() > 0) {
					     		
			   		for(int i=0; i<qpartreportMB.getQpartSearchResultList().size(); i++) {
			   			PLMBomHealthData dataObj = (PLMBomHealthData)qpartreportMB.getQpartSearchResultList().get(i);
			   			if(dataObj.getParentitemnumber()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getParentitemnumber()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getIsitemnumber()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getIsitemnumber()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getIsitemquantity()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getIsitemquantity()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getWasitemquantity()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getWasitemquantity()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getDcinumber()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDcinumber()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getActionflag()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getActionflag()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getNewitemindicator()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getNewitemindicator()));
			   			}
			   			pwriter.write(",");
			   			if(dataObj.getIcnnumber()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getIcnnumber()));
			   			}
			   			pwriter.write(",");
			   			if(dataObj.getRootcause()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRootcause()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getOrdernumber()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOrdernumber()));
			   			}
			   			pwriter.write("\n");
			   		}
				}
			   	pwriter.flush();  
		} catch (FileNotFoundException e) {
			System.out.println("The exception is : " + e);
		} catch (Exception e1) {
			System.out.println("IOException : " + e1.getMessage());
		} finally {
			try {
				if (pwriter != null) {
					pwriter.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
		}*/
	}
	
	/**
	 * This method is used to download csv for BOM P part report results
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadBOMPPartReportCSV() throws PLMCommonException {

		LOG.info("Entering downloadBOMPPartReportCSV Method");
		String reportName = "ParentPartDefectsResults";
		String fileName = "ParentPartDefectsResults";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		//Export to CSV for Parent Parts Report
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					  new PLMCsvRptColumn("parentitemnumber", "Parent Item Number", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("isitemnumber", "Is Item Number", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("dcinumber", "DCI Number", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("actionflag", "Action Flag", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("icnnumber", "ICN Number", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("rootcause", "Root Cause", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("ordernumber", "Order Number", FormatTypeCsv.TEXT)
			};
			
		   csvUtil.exportCsv(ppartSearchResultList, reportColumns, fileName, dateFormat, false, null, null, ",");
		   
		 LOG.info("Exiting downloadBOMPPartReportCSV Method");
		
		/*PrintWriter pwriter = null;

		try {
			
			FacesContext facesContext = FacesContext.getCurrentInstance();

			HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
			HttpServletRequest resquest = (HttpServletRequest) facesContext.getExternalContext().getRequest();
			
			HttpSession session = resquest.getSession();
			
			response.setContentType("application/CSV");
			   response.setHeader("content-disposition","attachment; filename=bomppartreport.csv");
			   pwriter = response.getWriter();
			   PLMBomHealthMB ppartreportMB = (PLMBomHealthMB)session.getAttribute("plmBomHealthMB");
			   
			    pwriter.write("Parent Item Number");
	 			pwriter.write(",");
	 			pwriter.write("Is Item Number");
	 			pwriter.write(",");
	 			pwriter.write("DCI Number");
	 			pwriter.write(",");
	  			pwriter.write("Action Flag");
	 			pwriter.write(",");
	 			pwriter.write("ICN Number");
	  			pwriter.write(",");
	  			pwriter.write("Root Cause");
	  			pwriter.write(",");
	 			pwriter.write("Order Number");
	 			pwriter.write(",");
	 			pwriter.write("\n");
	 			
	 			SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
	   		
			   if(ppartreportMB != null && ppartreportMB.getPpartSearchResultList()!= null &&  ppartreportMB.getPpartSearchResultList().size() > 0) {
					     		
			   		for(int i=0; i<ppartreportMB.getPpartSearchResultList().size(); i++) {
			   			PLMBomHealthData dataObj = (PLMBomHealthData)ppartreportMB.getPpartSearchResultList().get(i);
			   			if(dataObj.getParentitemnumber()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getParentitemnumber()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getIsitemnumber()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getIsitemnumber()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getDcinumber()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDcinumber()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getActionflag()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getActionflag()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getIcnnumber()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getIcnnumber()));
			   			}
			   			pwriter.write(",");
			   			if(dataObj.getRootcause()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRootcause()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getOrdernumber()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOrdernumber()));
			   			}
			   			pwriter.write("\n");
			   		}
				}
			   	pwriter.flush();  
		} catch (FileNotFoundException e) {
			System.out.println("The exception is : " + e);
		} catch (Exception e1) {
			System.out.println("IOException : " + e1.getMessage());
		} finally {
			try {
				if (pwriter != null) {
					pwriter.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
		}*/
	}
	
	/**
	 * This method is used for Resetting the Form Data
	 * 
	 * @return String
	 */
	public String resetData() {
		LOG.info("Entering Reset Method");
		String fwdflag = "bomhealthsearch";
		if (bomHealthData.getMlno() != null)
			bomHealthData.setMlno("");
		LOG.info("Exiting Reset Method");
		return fwdflag;
	}

	/**
	 * Start of Setters and Getters
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	public PLMBomHealthData getBomHealthData() {
		return bomHealthData;
	}

	public void setBomHealthData(PLMBomHealthData bomHealthData) {
		this.bomHealthData = bomHealthData;
	}

	public PLMMetricsServiceIfc getPlmMetricsService() {
		return plmMetricsService;
	}

	public void setPlmMetricsService(PLMMetricsServiceIfc plmMetricsService) {
		this.plmMetricsService = plmMetricsService;
	}

	public List<PLMBomHealthData> getSearchResultList() {
		return searchResultList;
	}

	public void setSearchResultList(List<PLMBomHealthData> searchResultList) {
		this.searchResultList = searchResultList;
	}

	public int getTotalRecCount() {
		return totalRecCount;
	}

	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	public List<PLMBomHealthData> getPartSearchResultList() {
		return partSearchResultList;
	}

	public void setPartSearchResultList(
			List<PLMBomHealthData> partSearchResultList) {
		this.partSearchResultList = partSearchResultList;
	}

	public String getPartRecCountMsg() {
		return partRecCountMsg;
	}

	public void setPartRecCountMsg(String partRecCountMsg) {
		this.partRecCountMsg = partRecCountMsg;
	}

	public int getPartRecCounts() {
		return partRecCounts;
	}

	public void setPartRecCounts(int partRecCounts) {
		this.partRecCounts = partRecCounts;
	}

	public List<PLMBomHealthData> getPpartSearchResultList() {
		return ppartSearchResultList;
	}

	public void setPpartSearchResultList(
			List<PLMBomHealthData> ppartSearchResultList) {
		this.ppartSearchResultList = ppartSearchResultList;
	}

	public List<PLMBomHealthData> getQpartSearchResultList() {
		return qpartSearchResultList;
	}

	public void setQpartSearchResultList(
			List<PLMBomHealthData> qpartSearchResultList) {
		this.qpartSearchResultList = qpartSearchResultList;
	}	
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * End of Setters and Getters
	 */
}