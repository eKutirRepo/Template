/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMMetricsDaoImpl.java
 * @Creation date: 15-June-2011
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.dao;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMBomCopicsData;
import com.geinfra.geaviation.pwi.data.PLMBomHealthData;
import com.geinfra.geaviation.pwi.data.PLMIswasParts;
import com.geinfra.geaviation.pwi.data.PLMPercentPartData;
import com.geinfra.geaviation.pwi.data.PLMProductConfData;
import com.geinfra.geaviation.pwi.data.PLMProjChngData;
import com.geinfra.geaviation.pwi.data.PLMProjChngDtlData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMMetricsQueries;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMQueryConstants;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMMetricsDaoImpl extends SimpleJdbcDaoSupport implements PLMMetricsDaoIfc {

	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMMetricsDaoImpl.class);
	/**
	 * This method is used for getBomHealthReport
	 * 
	 * @param mlno
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomHealthData> getBomHealthReport(String mlno)
			throws PLMCommonException {
		List<PLMBomHealthData> searchResultList = null;
		try{
		searchResultList = getSimpleJdbcTemplate().query(
				PLMMetricsQueries.GET_BOM_HEALTH_REPORT, new BomHealthMapper(),
				new Object[] { mlno, mlno, mlno, mlno });
		LOG.info("Query for Parts Counts : "
				+ PLMMetricsQueries.GET_BOM_HEALTH_REPORT);
		if (searchResultList != null && searchResultList.size() > 0) {
			LOG.info("Query for Opportunity : "
					+ PLMMetricsQueries.GET_BOM_HEALTH_OPPORTUNITY);
			int opportunity = getSimpleJdbcTemplate().queryForInt(
					PLMMetricsQueries.GET_BOM_HEALTH_OPPORTUNITY, mlno);
			((PLMBomHealthData) searchResultList.get(0))
					.setOpportunites(opportunity);
		}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return searchResultList;
	}
	/**
	 * Row mapper for getting bomHealthMapper
	 */
	//private static ParameterizedRowMapper<PLMBomHealthData> bomHealthMapper = new ParameterizedRowMapper<PLMBomHealthData>() {
	private static final class BomHealthMapper implements ParameterizedRowMapper<PLMBomHealthData>{	
	public PLMBomHealthData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMBomHealthData tempData = new PLMBomHealthData();
			tempData.setMlno(rs.getString("UNIT_NO"));
			tempData.setDefectsbypartnumber(rs.getInt("PART_NO"));
			tempData.setDefectsbyqpartnumber(rs.getInt("QPART_NO"));
			tempData.setDefectsbyppartnumber(rs.getInt("PPART_NO"));
			return tempData;
		}
	//	};
	}

	/**
	 * This method is used for getPartReport
	 * 
	 * @param mlno
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomHealthData> getPartReport(String mlno)
			throws PLMCommonException {
		List<PLMBomHealthData> searchResultList = null;
		try{
		searchResultList = getSimpleJdbcTemplate().query(
				PLMMetricsQueries.GET_BOMPART_REPORT, new BomPartMapper(), mlno);
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return searchResultList;
	}

	/**
	 * Row mapper for getting bomPartMapper
	 */
	//private static ParameterizedRowMapper<PLMBomHealthData> bomPartMapper = new ParameterizedRowMapper<PLMBomHealthData>() {
	private static final class BomPartMapper implements ParameterizedRowMapper<PLMBomHealthData>{	
	public PLMBomHealthData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMBomHealthData tempPartData = new PLMBomHealthData();
			tempPartData.setParentitemnumber(PLMUtils.checkNullVal(rs
					.getString("PARENT_ITEM_NO")));
			tempPartData.setWasitemnumber(PLMUtils.checkNullVal(rs
					.getString("WAS_ITEM_NUM")));
			tempPartData.setIsitemnumber(PLMUtils.checkNullVal(rs
					.getString("IS_ITEM_NUM")));
			tempPartData.setDcinumber(PLMUtils.checkNullVal(rs
					.getString("DCI_NUMBER")));
			tempPartData.setActionflag(PLMUtils.checkNullVal(rs
					.getString("ACTION_FLAG")));
			tempPartData.setNewitemindicator(PLMUtils.checkNullVal(rs
					.getString("NEW_ITEM_INDICATOR")));
			tempPartData.setIcnnumber(PLMUtils.checkNullVal(rs
					.getString("ICN_NUMBER")));
			tempPartData.setRootcause(PLMUtils.checkNullVal(rs
					.getString("ROOT_CAUSE")));
			tempPartData.setOrdernumber(PLMUtils.checkNullVal(rs
					.getString("ORDER_NUMBER")));
			return tempPartData;
		}
	//	};
	}
	/**
	 * This method is used for getQPartReport
	 * 
	 * @param mlno
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomHealthData> getQPartReport(String mlno)
			throws PLMCommonException {
		List<PLMBomHealthData> searchResultList = null;
		try{
		searchResultList = getSimpleJdbcTemplate().query(
				PLMMetricsQueries.GET_BOMQPART_REPORT, new BomQPartMapper(), mlno);
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return searchResultList;
	}
	/**
	 * Row mapper for getting bomQPartMapper
	 */
	//private static ParameterizedRowMapper<PLMBomHealthData> bomQPartMapper = new ParameterizedRowMapper<PLMBomHealthData>() {
	private static final class BomQPartMapper implements ParameterizedRowMapper<PLMBomHealthData>{ 	
	public PLMBomHealthData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMBomHealthData tempQPartData = new PLMBomHealthData();
			tempQPartData.setParentitemnumber(PLMUtils.checkNullVal(rs
					.getString("PARENT_ITEM_NO")));
			tempQPartData.setIsitemnumber(PLMUtils.checkNullVal(rs
					.getString("IS_ITEM_NUM")));
			tempQPartData.setIsitemquantity(PLMUtils.checkNullVal(rs
					.getString("IS_ITEM_QTY")));
			tempQPartData.setWasitemquantity(PLMUtils.checkNullVal(rs
					.getString("WAS_ITEM_QTY")));
			tempQPartData.setDcinumber(PLMUtils.checkNullVal(rs
					.getString("DCI_NUMBER")));
			tempQPartData.setActionflag(PLMUtils.checkNullVal(rs
					.getString("ACTION_FLAG")));
			tempQPartData.setNewitemindicator(PLMUtils.checkNullVal(rs
					.getString("NEW_ITEM_INDICATOR")));
			tempQPartData.setIcnnumber(PLMUtils.checkNullVal(rs
					.getString("ICN_NUMBER")));
			tempQPartData.setRootcause(PLMUtils.checkNullVal(rs
					.getString("ROOT_CAUSE")));
			tempQPartData.setOrdernumber(PLMUtils.checkNullVal(rs
					.getString("ORDER_NUMBER")));
			return tempQPartData;
		}
	//	};
	}
	/**
	 * This method is used for getPPartReport
	 * 
	 * @param mlno
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomHealthData> getPPartReport(String mlno)
			throws PLMCommonException {
		List<PLMBomHealthData> searchResultList = null;
		try{
		searchResultList = getSimpleJdbcTemplate().query(
				PLMMetricsQueries.GET_BOMPPART_REPORT, new BomPPartMapper(), mlno);
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return searchResultList;
	}
	/**
	 * Row mapper for getting bomPPartMapper
	 */
	//private static ParameterizedRowMapper<PLMBomHealthData> bomPPartMapper = new ParameterizedRowMapper<PLMBomHealthData>() {
	private static final class BomPPartMapper implements ParameterizedRowMapper<PLMBomHealthData>{	
	public PLMBomHealthData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMBomHealthData tempPPartData = new PLMBomHealthData();
			tempPPartData.setParentitemnumber(PLMUtils.checkNullVal(rs
					.getString("PARENT_ITEM_NO")));
			tempPPartData.setIsitemnumber(PLMUtils.checkNullVal(rs
					.getString("IS_ITEM_NUM")));
			tempPPartData.setDcinumber(PLMUtils.checkNullVal(rs
					.getString("DCI_NUMBER")));
			tempPPartData.setActionflag(PLMUtils.checkNullVal(rs
					.getString("ACTION_FLAG")));
			tempPPartData.setIcnnumber(PLMUtils.checkNullVal(rs
					.getString("ICN_NUMBER")));
			tempPPartData.setRootcause(PLMUtils.checkNullVal(rs
					.getString("ROOT_CAUSE")));
			tempPPartData.setOrdernumber(PLMUtils.checkNullVal(rs
					.getString("ORDER_NUMBER")));
			return tempPPartData;
		}
	//	};
	}
	public static Logger getLOG() {
		return LOG;
	}
	
	
	
	/**
	 * This method is used for getPercentReuseDataFromDB
	 * 
	 * @param mlNumbr,prodLine
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMPercentPartData> getPercentReuseDataFromDB(String mlNumber, String prodLine)
		throws PLMCommonException {
		
		LOG.info("Entering getPercentReuseDataFromDB Method");
		
		List<PLMPercentPartData> searchResults = null;
		NumberFormat numberFormat = NumberFormat.getInstance();
		numberFormat.setMaximumFractionDigits(2);
		String timeStamp = null;
		String VT_STRT_DT = null;
		String volTableVT0 = null;
		String volTableVT1 = null;
		String VT_SYS_DT = null;
		String VT_COMPL_DT = null;
		
		boolean query1Executed = false;
		boolean query2Executed = false;
		boolean query3Executed = false;
		boolean query4Executed = false;
		boolean query5Executed = false;
		
		try {
			LOG.info("Entered ML / MPL Number : " + mlNumber + "\n");
			LOG.info("Selected Product Line : " + prodLine + "\n");
			LOG.info("QUERY FOR ML / MPL DETAILS : " + PLMMetricsQueries.GET_PERCENTPARTREUSE_DETAILS + "\n");
			searchResults = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_PERCENTPARTREUSE_DETAILS, new Detailmapper() , new Object[] { mlNumber,mlNumber });
			if (searchResults != null && searchResults.size() > 0) {
				timeStamp = PLMUtils.volTableFormatDate();
				VT_STRT_DT = PLMConstants.VT_CNT_BFR_MFG_STRT_DT_QRY.concat(timeStamp);
				volTableVT0 = PLMConstants.VOLQRYVT0.concat(timeStamp);
				volTableVT1 = PLMConstants.VOLQRYVT1.concat(timeStamp);
				VT_SYS_DT = PLMConstants.VT_CNT_BFR_SYS_DT_QRY.concat(timeStamp);
				VT_COMPL_DT = PLMConstants.VT_CNT_BFR_MFG_COMPL_DT_QRY.concat(timeStamp);
				
				
				
				String mfgdatequery1 = PLMMetricsQueries.GET_MFG_COMPLETE_DATE_PERCENT1.replace("?", mlNumber).replace(PLMConstants.VT_CNT_BFR_MFG_STRT_DT_QRY, VT_STRT_DT);
				String mfgdatequery2 = PLMMetricsQueries.GET_MFG_COMPLETE_DATE_PERCENT2.replace("?", mlNumber).replace(PLMConstants.VOLQRYVT0, volTableVT0);
				String mfgdatequery3 = PLMMetricsQueries.GET_MFG_COMPLETE_DATE_PERCENT3.replace(PLMConstants.VOLQRYVT1, volTableVT1).replace(PLMConstants.VOLQRYVT0, volTableVT0);
				String mfgdatequery4_MPL = PLMMetricsQueries.GET_MFG_COMPLETE_DATE_PERCENT4_FOR_MPL.replace("?", mlNumber).replace(PLMConstants.VT_CNT_BFR_MFG_COMPL_DT_QRY, VT_COMPL_DT).replace(PLMConstants.VOLQRYVT1, volTableVT1);
				String mfgdatequery4_ML = PLMMetricsQueries.GET_MFG_COMPLETE_DATE_PERCENT4_FOR_ML.replace("?", mlNumber).replace(PLMConstants.VT_CNT_BFR_MFG_COMPL_DT_QRY, VT_COMPL_DT).replace(PLMConstants.VOLQRYVT1, volTableVT1);
				String todaydatequery1 = PLMMetricsQueries.GET_TODAY_DATE_PERCENT1.replace("?", mlNumber).replace(PLMConstants.VT_CNT_BFR_SYS_DT_QRY, VT_SYS_DT);
				String mfgdatepercent = PLMMetricsQueries.GET_MFG_COMPLETE_DATE_PERCENT_RESULT.replace(PLMConstants.VT_CNT_BFR_MFG_STRT_DT_QRY, VT_STRT_DT).replace(PLMConstants.VT_CNT_BFR_MFG_COMPL_DT_QRY, VT_COMPL_DT);
				String mfgCompleteDateQuery = PLMMetricsQueries.GET_MFG_COMPLETE_DATE_FOR_MPL.replace("?", mlNumber);
				String mfgdateQury = PLMMetricsQueries.GET_MFG_COMPLETE_DATE_FOR_ML.replace(PLMConstants.VOLQRYVT1, volTableVT1);
				String todaydatepercentQury = PLMMetricsQueries.GET_TODAY_DATE_PERCENT_RESULT.replace(PLMConstants.VT_CNT_BFR_MFG_STRT_DT_QRY, VT_STRT_DT).replace(PLMConstants.VT_CNT_BFR_SYS_DT_QRY, VT_SYS_DT);
				
				if (prodLine.equals(PLMConstants.PERCENT_PART_PROD_LINE)) {
					LOG.info("GENERATOR Condition is true Replacing REF with GFA");
					mfgdatequery1 = mfgdatequery1.replace(PLMConstants.PERCENT_PART_REF_VAL, PLMConstants.PERCENT_PART_GFA_VAL);
				}
				LOG.info("Query for MFG Complete Date Percent 1 : " + mfgdatequery1 + "\n");
				getJdbcTemplate().execute(mfgdatequery1);
				query1Executed = true;
				
				
				if (prodLine.equals(PLMConstants.PERCENT_PART_PROD_LINE)) {
					LOG.info("GENERATOR Condition is true Replacing REF with GFA");
					mfgdatequery2 = mfgdatequery2.replace(PLMConstants.PERCENT_PART_REF_VAL, PLMConstants.PERCENT_PART_GFA_VAL);
				}
				LOG.info("Query for MFG Complete Date Percent 2 : " + mfgdatequery2 + "\n");
				getJdbcTemplate().execute(mfgdatequery2);
				query2Executed = true;
				
				
								
				LOG.info("Query for MFG Complete Date Percent 3 : " + mfgdatequery3 + "\n");
				getJdbcTemplate().execute(mfgdatequery3);
				query3Executed = true;
										
					
				if (mlNumber.contains("MPL")) {
					LOG.info("Query for MFG Complete Date Percent 4 for MPL Number: " + mfgdatequery4_MPL + "\n");
					getJdbcTemplate().execute(mfgdatequery4_MPL); 
					query4Executed = true;
				} else {
					LOG.info("Query for MFG Complete Date Percent 4 for ML Number: " + mfgdatequery4_ML + "\n");
					getJdbcTemplate().execute(mfgdatequery4_ML);
					query4Executed = true;
				}
				LOG.info("Query for Today Date Percent 1 : " + todaydatequery1 + "\n");
				getJdbcTemplate().execute(todaydatequery1);
				query5Executed = true;
					
				LOG.info("Query for MFG Complete Date Percent Result :" + mfgdatepercent + "\n");
				String mfgdatepercentQuryRest = getSimpleJdbcTemplate().queryForObject(mfgdatepercent,new Mfgdatepercentmapper());
				mfgdatepercent = numberFormat.format(Double.parseDouble(mfgdatepercentQuryRest));
				((PLMPercentPartData) searchResults.get(0)).setMfgDatePercent(mfgdatepercent + PLMConstants.PERCENT_SYMBOL);
					
				if (mlNumber.contains("MPL")) {
					LOG.info("Query for MFG Complete Date for MPL : " + mfgCompleteDateQuery + "\n");
					String mfgdate = getSimpleJdbcTemplate().queryForObject(mfgCompleteDateQuery, new Mfgdatemapper()); 
					((PLMPercentPartData) searchResults.get(0)).setMfgDateHeader(PLMConstants.MFG_DATE_DISPLAY + PLMConstants.OPEN_BRACE + mfgdate + PLMConstants.CLOSE_BRACE);
				} else {
					LOG.info("Query for MFG Complete Date for ML : " + mfgdateQury + "\n");
						
					String mfgdate = getSimpleJdbcTemplate().queryForObject(mfgdateQury,new Mfgdatemapper());
					((PLMPercentPartData) searchResults.get(0)).setMfgDateHeader(PLMConstants.MFG_DATE_DISPLAY + PLMConstants.OPEN_BRACE + mfgdate + PLMConstants.CLOSE_BRACE);
				}
					
				LOG.info("Query for Today Date Percent Result : " + todaydatepercentQury + "\n");
					
				String todaydatepercent = getSimpleJdbcTemplate().queryForObject(todaydatepercentQury,new Todaydatepercentmapper());
				todaydatepercent = numberFormat.format(Double.parseDouble(todaydatepercent));
				((PLMPercentPartData) searchResults.get(0)).setTodayDatePercent(todaydatepercent + PLMConstants.PERCENT_SYMBOL);
					
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				String todaydate = dateFormat.format(new Date());
				((PLMPercentPartData) searchResults.get(0)).setTodayDateHeader(PLMConstants.TODAY_DATE_DISPLAY + PLMConstants.OPEN_BRACE + todaydate + PLMConstants.CLOSE_BRACE);
			
			} 
		} catch (DataAccessException e) {
			LOG.info("Exception occurred while executing the query in getPercentReuseDataFromDB method : " + e.getMessage());
			PLMUtils.checkException(e.getMessage());
		} finally {
			try {
				if (query1Executed) {
					LOG.info("Query for Drop MFG Complete Date Percent 1 : " + PLMMetricsQueries.DROP_MFG_COMPLETE_DATE_PERCENT1.replace(PLMConstants.VT_CNT_BFR_MFG_STRT_DT_QRY, VT_STRT_DT));
					getJdbcTemplate().execute(PLMMetricsQueries.DROP_MFG_COMPLETE_DATE_PERCENT1.replace(PLMConstants.VT_CNT_BFR_MFG_STRT_DT_QRY, VT_STRT_DT));
					query1Executed = false;
				}
				
				if (query2Executed) {
					LOG.info("Query for Drop MFG Complete Date Percent 2 : " + PLMMetricsQueries.DROP_MFG_COMPLETE_DATE_PERCENT2.replace(PLMConstants.VOLQRYVT0, volTableVT0));
					getJdbcTemplate().execute(PLMMetricsQueries.DROP_MFG_COMPLETE_DATE_PERCENT2.replace(PLMConstants.VOLQRYVT0, volTableVT0));
					query2Executed = false;
				}

				if (query3Executed) {
					LOG.info("Query for Drop MFG Complete Date Percent 3 : " + PLMMetricsQueries.DROP_MFG_COMPLETE_DATE_PERCENT3.replace(PLMConstants.VOLQRYVT1, volTableVT1));
					getJdbcTemplate().execute(PLMMetricsQueries.DROP_MFG_COMPLETE_DATE_PERCENT3.replace(PLMConstants.VOLQRYVT1, volTableVT1));
					query3Executed = false;
				}

				if (query4Executed) {
					LOG.info("Query for Drop MFG Complete Date Percent 4 : " + PLMMetricsQueries.DROP_MFG_COMPLETE_DATE_PERCENT4.replace(PLMConstants.VT_CNT_BFR_MFG_COMPL_DT_QRY, VT_COMPL_DT));
					getJdbcTemplate().execute(PLMMetricsQueries.DROP_MFG_COMPLETE_DATE_PERCENT4.replace(PLMConstants.VT_CNT_BFR_MFG_COMPL_DT_QRY, VT_COMPL_DT));
					query4Executed = false;
				}

				if (query5Executed) {
					LOG.info("Query for Drop Today Date Percent 1 : " + PLMMetricsQueries.DROP_TODAY_DATE_PERCENT1.replace(PLMConstants.VT_CNT_BFR_SYS_DT_QRY, VT_SYS_DT));
					getJdbcTemplate().execute(PLMMetricsQueries.DROP_TODAY_DATE_PERCENT1.replace(PLMConstants.VT_CNT_BFR_SYS_DT_QRY, VT_SYS_DT));
					query5Executed = false;
				}
			} catch(DataAccessException e) {
				LOG.info("Exception occurred while dropping the tables in dropVolatileTablesForPercentPartReuse method : " + e.getMessage());
				PLMUtils.checkException(e.getMessage());
			}
		}
		return searchResults;
	}
	
	/**
	 * Row mapper for getting detailmapper
	 */
	//private static ParameterizedRowMapper<PLMPercentPartData> detailmapper = new ParameterizedRowMapper<PLMPercentPartData>() {
	private static final class Detailmapper implements ParameterizedRowMapper<PLMPercentPartData>{ 	
	public PLMPercentPartData mapRow(ResultSet rs, int rowNum) throws SQLException {
			PLMPercentPartData result = new PLMPercentPartData();
			result.setTurbineNumber(rs.getString(PLMUtils.checkNullVal(PLMConstants.TURBINE_NM)));
			result.setSerialNumber(rs.getString(PLMUtils.checkNullVal(PLMConstants.SERIAL_NUM)));
			result.setProductLine(rs.getString(PLMUtils.checkNullVal(PLMConstants.PRODUCT_LINE)));
			result.setCustomerName(rs.getString(PLMUtils.checkNullVal(PLMConstants.CUSTOMER_NAME)));
			result.setSiteLoc(rs.getString(PLMUtils.checkNullVal(PLMConstants.SITE_LOCATION)));
			return result;
		}
	//	};
	}
	/**
	 * Row mapper for getting mfgdatemapper
	 */
	//private static ParameterizedRowMapper <String> mfgdatemapper = new ParameterizedRowMapper<String>() {
	private static final class Mfgdatemapper implements ParameterizedRowMapper <String>{	
	public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			String result ;
			result=rs.getString(PLMUtils.checkNullVal(PLMConstants.MFG_COMPLETE_DATE));
			return result;
		}          
	//	};
	}
	/**
	 * Row mapper for getting mfgdatepercentmapper
	 */
	//private static ParameterizedRowMapper <String> mfgdatepercentmapper = new ParameterizedRowMapper<String>() {
	private static final class Mfgdatepercentmapper implements ParameterizedRowMapper <String>{	
	public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			String result ;
			//result=rs.getString(PLMUtils.checkNullVal(PLMConstants.MFG_COMPLETE_DATE_PERCENT));
			result=rs.getString(PLMUtils.checkNullVal(PLMConstants.PCT_REUSE_MFG_CPL_DT));
			return result;
		}          
	//	};
	}
	/**
	 * Row mapper for getting todaydatepercentmapper
	 */
	//private static ParameterizedRowMapper <String> todaydatepercentmapper = new ParameterizedRowMapper<String>() {
	private static final class Todaydatepercentmapper implements ParameterizedRowMapper <String>{ 	
	public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			String result ;
			result=rs.getString(PLMUtils.checkNullVal(PLMConstants.TODAY_DATE_PERCENT));
			return result;
		}          
	//	};
	}
	/**
	 * This method is used for getBomCopicsComparisonReport
	 * 
	 * @param copicsInputList,plmInputList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomCopicsData> getBomCopicsComparisonReport(List<String> copicsInputList,List<String> plmInputList) throws PLMCommonException{
		LOG.info("Entering getBomCopicsComparisonReport Method");
		List<PLMBomCopicsData> bomCopicsResultList = new ArrayList <PLMBomCopicsData>();
		List<String> createdTables = new ArrayList <String>(); 
		try {
			if (!PLMUtils.isEmptyList(copicsInputList)){
				for(int i = 0 ; i < copicsInputList.size() ; i++) {
					String bomCopicsQuery = PLMQueryConstants.CREATE_BOM_COPICS_TABLE.replace("_TABLE_INDEX", Integer.toString(i + 1));
					String bomCopicsInput = copicsInputList.get(i);
					bomCopicsQuery = bomCopicsQuery.replace("?", bomCopicsInput);
					LOG.info("BOM COPICS Query " + (i + 1) + " : " + bomCopicsQuery + "\n");
					getJdbcTemplate().execute(bomCopicsQuery);
					createdTables.add("COPICS_BOM" + Integer.toString (i + 1));
				}
			}
			if (!PLMUtils.isEmptyList(plmInputList)){
				for(int i = 0 ; i < plmInputList.size() ; i++) {
					String plmEmbomQuery = PLMQueryConstants.CREATE_PLM_EMBOM_TABLE.replace("_TABLE_INDEX", Integer.toString(i + 1));
					String plmEmbomInput = plmInputList.get(i);
					plmEmbomQuery = plmEmbomQuery.replace("?", plmEmbomInput);
					LOG.info("PLM EMBOM Query " + (i + 1) + " : " + plmEmbomQuery + "\n");
					getJdbcTemplate().execute(plmEmbomQuery);
					createdTables.add("PLM_EBOM" + Integer.toString (i + 1));
				}
			}
			
			/* Comparison Code has to be written here for the created volatile table*/
			
			/* As of now Comparison Logic is not clear */
			
			/* Comparison Code has to be written here for the created volatile table */
			
			LOG.info("Created Table Size : " + createdTables.size());
			if(!PLMUtils.isEmptyList(createdTables)){
				for(int i = 0 ; i < createdTables.size(); i++) {
					String tableName = createdTables.get(i);
					String selectTableQuery = PLMQueryConstants.SELECT_PLM_COPICS_TABLE.replace("?", tableName);
					LOG.info("Query for select Table " + tableName + " : " + selectTableQuery);
					List<PLMBomCopicsData> tempResultList = getSimpleJdbcTemplate().query(selectTableQuery, new BomCopicsMapper());
					if(!PLMUtils.isEmptyList(tempResultList)){
						PLMBomCopicsData plmBomCopicsData = new PLMBomCopicsData();
						plmBomCopicsData.setResultList(tempResultList);
						bomCopicsResultList.add(plmBomCopicsData);
					}
				}
			}
		} catch (DataAccessException d) {
			LOG.info("Exception occurred in SQL statement : " + d.getMessage());
		} finally {
			try {
				dropVolatileTablesForBomCopics(createdTables);
			} catch(Exception e) {
				LOG.info("Exception occurred while dropping the tables : " + e.getMessage());
			}
		}
		return bomCopicsResultList;
	}
	
	/**
	 * Row mapper for getting bomCopicsMapper
	 */
	//private static ParameterizedRowMapper<PLMBomCopicsData> bomCopicsMapper = new ParameterizedRowMapper<PLMBomCopicsData>() {
	private static final class BomCopicsMapper	implements ParameterizedRowMapper<PLMBomCopicsData>{ 
	public PLMBomCopicsData mapRow(ResultSet rs, int rowNum) throws SQLException {
			PLMBomCopicsData result = new PLMBomCopicsData();
			result.setLevel(rs.getString(PLMUtils.checkNullVal(PLMConstants.LEVEL)));
			result.setChildPrefix(rs.getString(PLMUtils.checkNullVal(PLMConstants.CHILD_PREFIX)));
			result.setParentPrefix(rs.getString(PLMUtils.checkNullVal(PLMConstants.PARENT_PREFIX)));
			result.setChildItem(rs.getString(PLMUtils.checkNullVal(PLMConstants.CHILD_ITEM)));
			result.setParentItem(rs.getString(PLMUtils.checkNullVal(PLMConstants.PARENT_ITEM)));
			result.setQty(rs.getString(PLMUtils.checkNullVal(PLMConstants.QUANTITY)));
			return result;
		}
	//	};
	}
	/**
	 * This method is used for dropVolatileTablesForBomCopics
	 * 
	 * @param createdTables
	 * @throws PLMCommonException
	 */
	private void dropVolatileTablesForBomCopics(List<String> createdTables) throws PLMCommonException {
		LOG.info("Entering dropVolatileTablesForBomCopics Method");
		if(!PLMUtils.isEmptyList(createdTables)){
			for(int i = 0 ; i < createdTables.size(); i++){
				String tableName = createdTables.get(i);
				String dropTableQuery = PLMQueryConstants.DROP_PLM_COPICS_TABLE.replace("?", tableName);
				LOG.info("Query for Drop Table " + tableName + " : " + dropTableQuery);
				getJdbcTemplate().execute(dropTableQuery);
			}
		}
		LOG.info("Exiting dropVolatileTablesForBomCopics Method");	
	}
	
	/**
	 * This method is used for getProjChngHdr
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMProjChngData> getProjChngHdr() throws PLMCommonException {
		
		List<PLMProjChngData> searchResultList = null;
		try{
			StringBuffer hdrQry = new StringBuffer()
			.append(PLMOfflineQueries.GET_PRJ_CHNG_HDR_DATA)
			.append(PLMOfflineQueries.GET_PRJ_CHNG_HDR_DATA1);
			LOG.info("Query to pull Contracts with Issues in Proj Chng Summary --> "
					+hdrQry);
			searchResultList = getSimpleJdbcTemplate().query(
					hdrQry.toString(), new PrjChngHdrMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return searchResultList;
		
	}
	/**
	 * Row mapper for getting prjChngHdrMapper
	 */
	//private static ParameterizedRowMapper<PLMProjChngData> prjChngHdrMapper = new ParameterizedRowMapper<PLMProjChngData>() {
	private static final class PrjChngHdrMapper implements ParameterizedRowMapper<PLMProjChngData>{	
	public PLMProjChngData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			com.geinfra.geaviation.pwi.data.PLMProjChngData tempPPartData = new PLMProjChngData();
			tempPPartData.setContract(PLMUtils.checkNullVal(rs
					.getString("CONTRACT")));
			tempPPartData.setSerialNumber(PLMUtils.checkNullVal(rs
					.getString("GE_ORIGINAL_SERIAL_NUM")));
			tempPPartData.setIssueId(PLMUtils.checkNullVal(rs
					.getString("ISSUE_ID")));
			tempPPartData.setIssueName(PLMUtils.checkNullVal(rs
					.getString("ISSUE_NAME")));
			tempPPartData.setIssueCategory(PLMUtils.checkNullVal(rs
					.getString("ISSUE_CATEGORY")));
			tempPPartData.setIssueStatus(PLMUtils.checkNullVal(rs
					.getString("ISSUE_STATUS")));
			tempPPartData.setBuildName(PLMUtils.checkNullVal(rs
					.getString("BUILD")));
			tempPPartData.setBuildState(PLMUtils.checkNullVal(rs
					.getString("HW_BUILD_STATE")));
			return tempPPartData;
		}
	//	};
	}
	
	/**
	 * This method is used for getProjChngDtls
	 * 
	 * @param contract,prjChngDtlData
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMProjChngDtlData> getProjChngDtls(String contract,PLMProjChngDtlData prjChngDtlData) throws PLMCommonException {
		
		LOG.info("Entering getProjChngDtls method");
		List<PLMProjChngDtlData> dtlSrchResltList = null;
		final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
		"MM/dd/yyyy");
		try{	
			
			// INSERT QUERIES FOR REC_DATA STARTS HERE
			LOG.info("Proj Chng Summary Report INSERT_PRJ_CHNG_DATA1 Query is : " + PLMOfflineQueries.INSERT_PRJ_CHNG_DATA1);
			getJdbcTemplate().update(PLMOfflineQueries.INSERT_PRJ_CHNG_DATA1,new Object[]{contract});
			// INSERT QUERIES FOR FTR_DATA ENDS HERE
			
			//COLLECT STATUS QUERIES

			LOG.info("Proj Chng Summary Report PRJ_CHNG_DATA_COL_STATS1 Query is : " + PLMOfflineQueries.PRJ_CHNG_DATA_COL_STATS1);
			getJdbcTemplate().execute(PLMOfflineQueries.PRJ_CHNG_DATA_COL_STATS1);

			LOG.info("Proj Chng Summary Report PRJ_CHNG_DATA_COL_STATS2 Query is : " + PLMOfflineQueries.PRJ_CHNG_DATA_COL_STATS2);
			getJdbcTemplate().execute(PLMOfflineQueries.PRJ_CHNG_DATA_COL_STATS2);

			LOG.info("Proj Chng Summary Report PRJ_CHNG_DATA_COL_STATS3 Query is : " + PLMOfflineQueries.PRJ_CHNG_DATA_COL_STATS3);
			getJdbcTemplate().execute(PLMOfflineQueries.PRJ_CHNG_DATA_COL_STATS3);

			LOG.info("Proj Chng Summary Report PRJ_CHNG_DATA_COL_STATS4 Query is : " + PLMOfflineQueries.PRJ_CHNG_DATA_COL_STATS4);
			getJdbcTemplate().execute(PLMOfflineQueries.PRJ_CHNG_DATA_COL_STATS4);

			LOG.info("Proj Chng Summary Report PRJ_CHNG_DATA_COL_STATS5 Query is : " + PLMOfflineQueries.PRJ_CHNG_DATA_COL_STATS5);
			getJdbcTemplate().execute(PLMOfflineQueries.PRJ_CHNG_DATA_COL_STATS5);
			
			
			
			//END: COLLECT STATUS QUERIES
			
			// FINAL QUERY STARTS HERE
			StringBuffer searchResultsQry =new StringBuffer();
			boolean whereFlag=false;
			searchResultsQry.append(PLMOfflineQueries.PRJ_CHNG_DTLS);
			if (prjChngDtlData.getSelRdoList().size() > 0) {
				LOG.info("List of RDO : " + PLMUtils.setListForQuery(prjChngDtlData.getSelRdoList()));
				if(!whereFlag){
				searchResultsQry.append(" WHERE ");
				whereFlag=true;
				}
				else{
					searchResultsQry.append(" AND ");
				}
				searchResultsQry.append("RDO_OF_PART IN (" +PLMUtils.setListForQuery(prjChngDtlData.getSelRdoList())+ ")");
			}
			
			if (prjChngDtlData.getSelEcoStateList().size() > 0) {
				LOG.info("List of ECO States : " + PLMUtils.setListForQuery(prjChngDtlData.getSelEcoStateList()));
				if(!whereFlag){
				searchResultsQry.append(" WHERE ");
				whereFlag=true;
				}
				else{
					searchResultsQry.append(" AND ");
				}
				searchResultsQry.append("ECO_STATUS IN (" +PLMUtils.setListForQuery(prjChngDtlData.getSelEcoStateList())+ ")");
			}
			
			if (prjChngDtlData.getEcoStrDate() != null && prjChngDtlData.getEcoEndDate()!=null) {
				LOG.info("ECO Modifed  From Date: " + SIMPLE_DATE_FORMAT.format(prjChngDtlData.getEcoStrDate()) +" To Date: "+SIMPLE_DATE_FORMAT.format(prjChngDtlData.getEcoEndDate()));
				
				if(!whereFlag){
					searchResultsQry.append(" WHERE ");
					whereFlag=true;
					}
					else{
						searchResultsQry.append(" AND ");
					}
				searchResultsQry.append("(ECO_LAST_MODIFIED IS NOT NULL AND ECO_LAST_MODIFIED BETWEEN CAST('");
				searchResultsQry.append(SIMPLE_DATE_FORMAT.format(prjChngDtlData.getEcoStrDate())+ "' AS DATE FORMAT 'MM/DD/YYYY') AND ");
				searchResultsQry.append(" CAST('");
				searchResultsQry.append(SIMPLE_DATE_FORMAT.format(prjChngDtlData.getEcoEndDate())+ "' AS DATE FORMAT 'MM/DD/YYYY'))");
			}
			
			if (prjChngDtlData.getSelEcrStateList().size() > 0) {
				LOG.info("List of ECR States : " + PLMUtils.setListForQuery(prjChngDtlData.getSelEcrStateList()));
				if(!whereFlag){
				searchResultsQry.append(" WHERE ");
				whereFlag=true;
				}
				else{
					searchResultsQry.append(" AND ");
				}
				searchResultsQry.append("ECR_STATUS IN (" +PLMUtils.setListForQuery(prjChngDtlData.getSelEcrStateList())+ ")");
			}
			
			
			if (prjChngDtlData.getSelCtgryList().size() > 0) {
				LOG.info("List of ECR Catergory : " + PLMUtils.setListForQuery(prjChngDtlData.getSelCtgryList()));
				if(!whereFlag){
				searchResultsQry.append(" WHERE ");
				whereFlag=true;
				}
				else{
					searchResultsQry.append(" AND ");
				}
				searchResultsQry.append("ECO_CATEGORY_OF_CHANGE IN (" +PLMUtils.setListForQuery(prjChngDtlData.getSelCtgryList())+ ")");
			}
			
			
			if (prjChngDtlData.getEcrOrig() != null && prjChngDtlData.getEcrOrig().length() > 0) {
				LOG.info("value of ECR Orig : " +prjChngDtlData.getEcrOrig());
				String ecrOrig = PLMUtils.generatePrjQuryForSsoIds("ECR_ORIGINATOR", prjChngDtlData.getEcrOrig().trim());
				String ecrOrigName = PLMUtils.generatePrjQuryForSsoNames("ECR_ORIG_NAME", prjChngDtlData.getEcrOrig().trim());
				boolean ecrOrigFlag =false;
			
				  if(ecrOrig!=null && ecrOrig.length() >0){
					  ecrOrigFlag =true;
						if(!whereFlag){
							searchResultsQry.append(" WHERE ");
							searchResultsQry.append("(");
							whereFlag=true;
							}
							else{
								searchResultsQry.append(" AND ");
								searchResultsQry.append("(");
							}
						    
							searchResultsQry.append(ecrOrig);
						 }
				  
					if(ecrOrigName!=null && ecrOrigName.length() >0){
						if(!whereFlag){
							searchResultsQry.append(" WHERE ");
							searchResultsQry.append("(");
							whereFlag=true;
							}
							else{
								if(!ecrOrigFlag){
								searchResultsQry.append(" AND ");
								searchResultsQry.append("(");
								}
								else{
									searchResultsQry.append(" OR ");
								}
							}
							searchResultsQry.append(ecrOrigName);
						 }
					searchResultsQry.append(")");
					}
				
			
			if (prjChngDtlData.getEcrRespDesign() != null && prjChngDtlData.getEcrRespDesign().length() > 0) {
				LOG.info("value of ECR Resp Design : " +prjChngDtlData.getEcrRespDesign());
				String ecrResp = PLMUtils.generatePrjQuryForSsoIds("ECR_RSP_DESIGN_ENGR", prjChngDtlData.getEcrRespDesign().trim());
				String ecrRespName = PLMUtils.generatePrjQuryForSsoNames("ECR_RSP_DSG_ENGR_NAME", prjChngDtlData.getEcrRespDesign().trim());
				boolean ecrRespFlag =false;
				
				  if(ecrResp!=null && ecrResp.length() >0){
					  ecrRespFlag =true;
						if(!whereFlag){
							searchResultsQry.append(" WHERE ");
							searchResultsQry.append("(");
							whereFlag=true;
							}
							else{
								searchResultsQry.append(" AND ");
								searchResultsQry.append("(");
							}
							searchResultsQry.append(ecrResp);
						 }
				  
					if(ecrRespName!=null && ecrRespName.length() >0){
						if(!whereFlag){
							searchResultsQry.append(" WHERE ");
							searchResultsQry.append("(");
							whereFlag=true;
							}
							else{
								if(!ecrRespFlag){
									searchResultsQry.append(" AND ");
									searchResultsQry.append("(");
									}
								  else{
								  	searchResultsQry.append(" OR ");
									}
							   }
							searchResultsQry.append(ecrRespName);
						 }
					   searchResultsQry.append(")");
					}
			
			if (prjChngDtlData.getEcrStartDate() != null && prjChngDtlData.getEcrEndDate()!=null) {
				LOG.info("ECR Modifed  From Date: " + SIMPLE_DATE_FORMAT.format(prjChngDtlData.getEcrStartDate()) +" To Date: "+SIMPLE_DATE_FORMAT.format(prjChngDtlData.getEcrEndDate()));
				
				if(!whereFlag){
					searchResultsQry.append(" WHERE ");
					whereFlag=true;
					}
					else{
						searchResultsQry.append(" AND ");
					}
				searchResultsQry.append("(ECR_LAST_MODIFIED IS NOT NULL AND ECR_LAST_MODIFIED BETWEEN CAST('");
				searchResultsQry.append(SIMPLE_DATE_FORMAT.format(prjChngDtlData.getEcrStartDate())+ "' AS DATE FORMAT 'MM/DD/YYYY') AND ");
				searchResultsQry.append(" CAST('");
				searchResultsQry.append(SIMPLE_DATE_FORMAT.format(prjChngDtlData.getEcrEndDate())+ "' AS DATE FORMAT 'MM/DD/YYYY'))");
			}
			
			LOG.info("Proj Chng Summary Report Select Query3 is : " + searchResultsQry);
			dtlSrchResltList = getSimpleJdbcTemplate().query(searchResultsQry.toString(), new DtlSrchRsltMapper());
			
			LOG.info("Report Output before Sorting"); 
			Collections.sort(dtlSrchResltList, new SortList());
			LOG.info("Report Output After Sorting"); 
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		} finally {
			LOG.info("Proj Chng Summary Report delete Query is : " + PLMOfflineQueries.PRJ_CHNG_DATA_DEL);
			getJdbcTemplate().execute(PLMOfflineQueries.PRJ_CHNG_DATA_DEL);
		}
		LOG.info("Exiting getProjChngDtls method");
		
		return dtlSrchResltList;
		
	}
	
	/**
	 * 
	 * class to sort list of object of type selected item.
	 * 
	 */
	private static class SortList implements Comparator<PLMProjChngDtlData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMProjChngDtlData aString,
				PLMProjChngDtlData bString) {
			String aStr;
			String bStr;
			aStr = aString.getTopLvlPrntPrjChng();
			bStr = bString.getTopLvlPrntPrjChng();
			return aStr.compareTo(bStr);
		}
	}
	/**
	 * Row mapper for getting dtlSrchRsltMapper
	 */
	//private static ParameterizedRowMapper<PLMProjChngDtlData> dtlSrchRsltMapper = new ParameterizedRowMapper<PLMProjChngDtlData>() {
	private static final class DtlSrchRsltMapper implements ParameterizedRowMapper<PLMProjChngDtlData>{	
	public PLMProjChngDtlData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
			"MM/dd/yyyy");
			PLMProjChngDtlData prjChngDtlData = new PLMProjChngDtlData();
			prjChngDtlData.setTopLevelParentId(PLMUtils.checkNullVal(rs.getString("TOP_LEVEL_PARENT_ID")));
			prjChngDtlData.setTopLvlPrntPrjChng(PLMUtils.checkNullVal(rs.getString("TOP_LEVEL_PARENT_NAME")));
			prjChngDtlData.setParentId(PLMUtils.checkNullVal(rs.getString("PARENT_ID")));
			prjChngDtlData.setParentPart(PLMUtils.checkNullVal(rs.getString("PARENT_PART")));
			prjChngDtlData.setChildId(PLMUtils.checkNullVal(rs.getString("CHILD_ID")));
			prjChngDtlData.setChildPart(PLMUtils.checkNullVal(rs.getString("CHILD_PART")));
			prjChngDtlData.setChildPartDesc(PLMUtils.checkNullVal(rs.getString("CHILD_PART_DESCRIPTION")));
			prjChngDtlData.setPartType(PLMUtils.checkNullVal(rs.getString("PART_TYPE")));
			prjChngDtlData.setPartRev(PLMUtils.checkNullVal(rs.getString("PART_REVISION")));
			prjChngDtlData.setPartStatus(PLMUtils.checkNullVal(rs.getString("PART_STATUS")));
			prjChngDtlData.setChildPartDate(PLMUtils.checkNullVal(rs.getString("DATE_OF_CHILD_PART_STATE")));
			prjChngDtlData.setEcrId(PLMUtils.checkNullVal(rs.getString("ECR_ID_VALUE")));
			prjChngDtlData.setEcrName(PLMUtils.checkNullVal(rs.getString("ECR_NAME")));
			prjChngDtlData.setEcrDescPrjChng(PLMUtils.checkNullVal(rs.getString("ECR_DESCRIPTION")));
			prjChngDtlData.setEcoId(PLMUtils.checkNullVal(rs.getString("ECO_ID_VALUE")));
			prjChngDtlData.setEcoName(PLMUtils.checkNullVal(rs.getString("ECO_NAME")));
			prjChngDtlData.setEcoDesc(PLMUtils.checkNullVal(rs.getString("ECO_DESCRIPTION")));
			prjChngDtlData.setEcoSubst(PLMUtils.checkNullVal(rs.getString("ECO_SUBSTANTIATION")));
			prjChngDtlData.setEcoFastTrack(PLMUtils.checkNullVal(rs.getString("ECO_FAST_TRACK")));
			prjChngDtlData.setEcrStatus(PLMUtils.checkNullVal(rs.getString("ECR_STATUS")));
			prjChngDtlData.setEcoStatus(PLMUtils.checkNullVal(rs.getString("ECO_STATUS")));
			prjChngDtlData.setRequestedChange(PLMUtils.checkNullVal(rs.getString("REQSTD_CHNG")));
			prjChngDtlData.setDispInField(PLMUtils.checkNullVal(rs.getString("DISPOSITION_IN_FIELD")));
			prjChngDtlData.setDispInProcess(PLMUtils.checkNullVal(rs.getString("DISPOSITION_IN_PROCESS")));
			prjChngDtlData.setDispInStock(PLMUtils.checkNullVal(rs.getString("DISPOSITION_IN_STOCK")));
			prjChngDtlData.setDispOnOrder(PLMUtils.checkNullVal(rs.getString("DISPOSITION_ON_ORDER")));
			prjChngDtlData.setEcoPolicy(PLMUtils.checkNullVal(rs.getString("ECO_POLICY")));
			prjChngDtlData.setEcoCtgChng(PLMUtils.checkNullVal(rs.getString("ECO_CATEGORY_OF_CHANGE")));
			prjChngDtlData.setEcoSev(PLMUtils.checkNullVal(rs.getString("ECO_SEVERITY")));
			prjChngDtlData.setImpactStmt(PLMUtils.checkNullVal(rs.getString("CLS_I_IMPACT_STMT_TXT")));
			prjChngDtlData.setBomMarkup(PLMUtils.checkNullVal(rs.getString("BOM_MARKUP")));
			prjChngDtlData.setBomMarkupType(PLMUtils.checkNullVal(rs.getString("BOM_MARKUP_TYPE")));
			prjChngDtlData.setRdo(PLMUtils.checkNullVal(rs.getString("RDO_OF_PART")));
			prjChngDtlData.setEcrCategoryChng(PLMUtils.checkNullVal(rs.getString("ECO_CATEGORY_OF_CHANGE")));
			prjChngDtlData.setEcrOrig(PLMUtils.checkNullVal(rs.getString("ECR_ORIGINATOR")));
			prjChngDtlData.setEcrOrigName(PLMUtils.checkNullVal(rs.getString("ECR_ORIG_NAME")));
			prjChngDtlData.setEcrRespDesign(PLMUtils.checkNullVal(rs.getString("ECR_RSP_DESIGN_ENGR")));
			prjChngDtlData.setEcrRespDesignName(PLMUtils.checkNullVal(rs.getString("ECR_RSP_DSG_ENGR_NAME")));
			
			if(!PLMUtils.isEmpty(rs.getString("ECO_LAST_MODIFIED"))){
			prjChngDtlData.setEcoModifiedDate(SIMPLE_DATE_FORMAT.format(rs.getDate("ECO_LAST_MODIFIED")));
			}
			else {
				prjChngDtlData.setEcoModifiedDate("");
			}
			if(!PLMUtils.isEmpty(rs.getString("ECR_LAST_MODIFIED"))){
    			prjChngDtlData.setEcrModifiedDate(SIMPLE_DATE_FORMAT.format(rs.getDate("ECR_LAST_MODIFIED")));
			}
			else {
				prjChngDtlData.setEcrModifiedDate("");
			}
			return prjChngDtlData;
		}
	//	};
	}
	
	
	//Newly added for Project summary
	/**
	 * This method is used for getPrjSumryReport
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMProjChngData> getPrjSumryReport(StringBuffer searchResultsQry) throws PLMCommonException{
		List<PLMProjChngData> prjSumrtsearchList = null;
		try{
			
			prjSumrtsearchList = getSimpleJdbcTemplate().query(
					searchResultsQry.toString(), new PrjChngHdrMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return prjSumrtsearchList;
	}
	
	/**
	 * Row mapper for getting dtlContrSrchMapper
	 */
	
	//private static ParameterizedRowMapper<PLMProjChngData> dtlContrSrchMapper = new ParameterizedRowMapper<PLMProjChngData>() {
	private static final class DtlContrSrchMapper implements ParameterizedRowMapper<PLMProjChngData>{	
	public PLMProjChngData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			
			PLMProjChngData prjChngDtlData = new PLMProjChngData();
			
			
			prjChngDtlData.setContract(PLMUtils.checkNullVal(rs
					.getString("CONTRACT")));
			
			prjChngDtlData.setDescription(PLMUtils.checkNullVal(rs
					.getString("CONTRACT_DESCRIPTION")));;

			
			return prjChngDtlData;
		}
	//	};
	}
	/**
	 * This method is used for getprjContractDescdata
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMProjChngData> getprjContractDescdata(StringBuffer searchResultsQry) throws PLMCommonException{
		List<PLMProjChngData> prjCntrtsearchList = null;
		try{
			
			prjCntrtsearchList = getSimpleJdbcTemplate().query(
					searchResultsQry.toString(), new DtlContrSrchMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return prjCntrtsearchList;
	}
	
	/**
	 * This method is used for getprjChangeList
	 * 
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getprjChangeList()	throws PLMCommonException {
		LOG.info("Entering getprjChangeList() method.");
				Map<String, List<SelectItem>> prjChgList = new HashMap<String, List<SelectItem>>();
				
				List<SelectItem> rdoList = null;
				List<SelectItem> ecrStateList = null;
				List<SelectItem> ecoState = null;
				List<SelectItem> ecrCatgryLst = null;
			
		try {
			rdoList = getJdbcTemplate().query(PLMOfflineQueries.PRJ_CHNG_RDO, new RdoMapper());
			LOG.info("Final Query rdo is : " + PLMOfflineQueries.PRJ_CHNG_RDO);
			Collections.sort(rdoList, new PLMUtils.SortListSelItmLbl());
			prjChgList.put("rdo", rdoList);
			
			ecrStateList = getJdbcTemplate().query(PLMSearchQueries.GET_ECR_STATE,new EcrstateMapper());
			LOG.info("Final Query ecrState is : " + PLMSearchQueries.GET_ECR_STATE);
			Collections.sort(ecrStateList, new PLMUtils.SortListSelItmLbl());
			prjChgList.put("ecrState", ecrStateList);
			
			ecrCatgryLst = getJdbcTemplate().query(PLMSearchQueries.GET_ECR_CATEGORY,new EcrCatgryMapper());
			LOG.info("Final Query ecrCatgry is : " + PLMSearchQueries.GET_ECR_CATEGORY);
			Collections.sort(ecrCatgryLst, new PLMUtils.SortListSelItmLbl());
			prjChgList.put("ecrCategory", ecrCatgryLst);
			
			ecoState = getJdbcTemplate().query(PLMSearchQueries.GET_DROP_VALUE_ST, new EcostateMapper());
			LOG.info("Final Query ecoState is : " + PLMSearchQueries.GET_DROP_VALUE_ST);
			prjChgList.put("ecoState", ecoState);
			
			
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return prjChgList;
		}
		
	/**
	 * Row mapper for getting rdoMapper
	 */
	//private static ParameterizedRowMapper<SelectItem> rdoMapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class RdoMapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs.getString("RDO"));
			return selectItem;
		}
	//	};
	}
	/**
	 * Row mapper for getting ecrstateMapper
	 */
	//private static ParameterizedRowMapper<SelectItem> ecrstateMapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class EcrstateMapper implements ParameterizedRowMapper<SelectItem>{ 	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs.getString("STATE"));
			return selectItem;
		}
	//	};
	}
	/**
	 * Row mapper for getting ecrCatgryMapper
	 */
	//private static ParameterizedRowMapper<SelectItem> ecrCatgryMapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class EcrCatgryMapper	implements ParameterizedRowMapper<SelectItem>{ 
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs.getString("CATEGORY_CHANGE"));
			return selectItem;
		}
	//	};
	}
	/**
	 * Row mapper for getting ecostateMapper
	 */
	//private static ParameterizedRowMapper<SelectItem> ecostateMapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class EcostateMapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs.getString("ECO_STATE"));
			return selectItem;
		}
	//	};
	}
	
	//newly Added for Contract summary report
	/**
	 * This method is used for getProductCnfgDesc
	 * 
	 * @param contractNameList
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getProductCnfgDesc(String contractNameList) throws PLMCommonException{
		
		LOG.info("Executing getProductCnfgDesc");
		Map<String, List<SelectItem>> prdConfList = new HashMap<String, List<SelectItem>>();
		List<SelectItem> prdConfDesc = null;
		LOG.info("contractNameList in DAO------------->"+contractNameList);
		StringBuffer searchQuery =new StringBuffer();
		try {
			searchQuery.append(PLMQueryConstants.GET_PRODUCT_CONFG_DESC1);
			searchQuery.append(PLMUtils.generatePrjQuryForMultipleNames(" CTRCT.NM" ,contractNameList));
			searchQuery.append(PLMQueryConstants.GET_PRODUCT_CONFG_DESC2);
			searchQuery.append(PLMUtils.generatePrjQuryForMultipleNames(" CTRCT.NM" ,contractNameList));
			prdConfDesc = getSimpleJdbcTemplate().query(searchQuery.toString(), new PrdConfDescMapper());
			LOG.info("Final Query prd conf desc is : " + searchQuery.toString());
			prdConfList.put("prdConfDes", prdConfDesc);
			
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return prdConfList;
		}
	/**
	 * Row mapper for getting prdConfDescMapper
	 */
	//private static ParameterizedRowMapper<SelectItem> prdConfDescMapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class PrdConfDescMapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			SelectItem selectItem = new SelectItem(rs.getString("PRDT_CFGN"),rs.getString("PRDT_CFGN_DESC"));
			return selectItem;
		}
	//	};
	}
	
	/**
	 * This method is used for getProductCnfgSummary
	 * 
	 * @param conSummRepData
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<PLMProductConfData>>  getProductCnfgSummary(PLMProductConfData conSummRepData) throws PLMCommonException{
		LOG.info("Executing getProductCnfgSummary");
//		List<PLMProductConfData> productConfSmryList = new ArrayList<PLMProductConfData>();
		List<PLMProductConfData> productConfSmryFinalList = new ArrayList<PLMProductConfData>();
//		List<PLMProductConfData> customerReqSmryList = new ArrayList<PLMProductConfData>();
		Map<String, List<PLMProductConfData>> getPrdSummaryData =new HashMap<String, List<PLMProductConfData>>();
			StringBuffer searchResultQuery =new StringBuffer();
		try {
			//Retrieving selected options configuration summary Data
			searchResultQuery.append(PLMQueryConstants.GET_PRODUCT_CONFG_SUMMARY1);
			if(conSummRepData.getSelPrdConfList().size() > 0){
				searchResultQuery.append(" SEL_OPT.FROM_NAME IN (" +PLMUtils.setListForQuery(conSummRepData.getSelPrdConfList())+ ")");
			}
			
			searchResultQuery.append(PLMQueryConstants.GET_PRODUCT_CONFG_SUMMARY2);
			if(conSummRepData.getSelPrdConfList().size() > 0){
				searchResultQuery.append(" SEL_OPT.FROM_NAME IN (" +PLMUtils.setListForQuery(conSummRepData.getSelPrdConfList())+ ")");
			}
			
			//Query for appending Adding CDR_ODS_R_MANDATORY_CFGN_F table
			searchResultQuery.append(PLMQueryConstants.GET_PRODUCT_CONFG_SUMMARY3);
			if(conSummRepData.getSelPrdConfList().size() > 0){
				searchResultQuery.append(" SEL_OPT.FROM_NAME IN (" +PLMUtils.setListForQuery(conSummRepData.getSelPrdConfList())+ ")");
			}
			
			//Query for appending Adding CDR_ODS_R_VARIES_BY  table
			searchResultQuery.append(PLMQueryConstants.GET_PRODUCT_CONFG_SUMMARY4);
			if(conSummRepData.getSelPrdConfList().size() > 0){
				searchResultQuery.append(" SEL_OPT.FROM_NAME IN (" +PLMUtils.setListForQuery(conSummRepData.getSelPrdConfList())+ ")");
			}
			searchResultQuery.append(PLMQueryConstants.GET_PRODUCT_CONFG_SUMMARY5);
			
			
			LOG.info("Final Query getProductCnfgSummary is : " + searchResultQuery.toString());
			List<PLMProductConfData> productConfSmryList = getSimpleJdbcTemplate().query(searchResultQuery.toString(), new PrdConfSummaryMapper());
			if(!PLMUtils.isEmptyList(productConfSmryList)){
					LOG.info("first value in productConfSmryList"+productConfSmryList.get(0));
			}
			
			
//			PLMProductConfData reportData =new PLMProductConfData();
			String initialName="";
			
			for(int i=0; i < productConfSmryList.size();i++){
			if(!initialName.equals(productConfSmryList.get(i).getCfnameCns())){
				PLMProductConfData reportData = new PLMProductConfData();
			    reportData.setLevel(PLMConstants.ONE);
			    reportData.setCfId(productConfSmryList.get(i).getCfId());
			    reportData.setCfnameCns(productConfSmryList.get(i).getCfnameCns());
			    reportData.setCfdesc(productConfSmryList.get(i).getCfdesc());
			    reportData.setSeqorder(productConfSmryList.get(i).getCfseqorder());
			    productConfSmryFinalList.add(reportData);
			}
			    
				PLMProductConfData reportData = new PLMProductConfData();
			    reportData.setLevel(PLMConstants.TWO);
			    reportData.setCfId(productConfSmryList.get(i).getCoId());
			    reportData.setCfnameCns(productConfSmryList.get(i).getCfnameCns());
			    reportData.setCfdesc(productConfSmryList.get(i).getCodescPcnf());
			    reportData.setSeqorder(productConfSmryList.get(i).getCoseqorder());
			    productConfSmryFinalList.add(reportData);
				
			    initialName=productConfSmryList.get(i).getCfnameCns();
			}
			getPrdSummaryData.put("prdSummaryList", productConfSmryFinalList);
			
			//Retrieving Customer Requirement Data	
			searchResultQuery =new StringBuffer();
			searchResultQuery.append(PLMQueryConstants.GET_CUSTOMER_REQ_DATA);
			if(conSummRepData.getSelPrdConfList().size() > 0){
				searchResultQuery.append(" SEL_OPT.FROM_NAME IN (" +PLMUtils.setListForQuery(conSummRepData.getSelPrdConfList())+ ")");
				}
			LOG.info("Final Query getCustomerReq is : " + searchResultQuery.toString());
			List<PLMProductConfData> customerReqSmryList = getSimpleJdbcTemplate().query(searchResultQuery.toString(), new CustReqMapper());
			if(!PLMUtils.isEmptyList(customerReqSmryList)){
								LOG.info("first value in customerReqSmryList"+customerReqSmryList.get(0));
			}
			getPrdSummaryData.put("custReqList", customerReqSmryList);
		
	    }
		catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return getPrdSummaryData;
		}
	
	/**
	 * Row mapper for getting prdConfSummaryMapper
	 */
	//private static ParameterizedRowMapper<PLMProductConfData> prdConfSummaryMapper = new ParameterizedRowMapper<PLMProductConfData>() {
	private static final class PrdConfSummaryMapper implements ParameterizedRowMapper<PLMProductConfData>{	
	public PLMProductConfData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			
			PLMProductConfData reportData = new PLMProductConfData();
			reportData.setCfId(PLMUtils.checkNullVal(rs.getString("CF_ID")));
			reportData.setCfnameCns(PLMUtils.checkNullVal(rs.getString("CF_NAME"))); 
			reportData.setCfdesc(PLMUtils.checkNullVal(rs.getString("CF_DESC")));
			reportData.setCoId(PLMUtils.checkNullVal(rs.getString("CO_ID")));
			reportData.setConameCns(PLMUtils.checkNullVal(rs.getString("CO_NAME")));
			reportData.setCodescPcnf(PLMUtils.checkNullVal(rs.getString("CO_DESC")));
			reportData.setCoseqorder(PLMUtils.checkNullVal(rs.getString("OPT_SEQ_ORDER")));
			reportData.setCfseqorder(PLMUtils.checkNullVal(rs.getString("FEAT_SEQ_ORDER")));
			return reportData;
		}
	// };
	}
	/**
	 * Row mapper for getting custReqMapper
	 */
	//private static ParameterizedRowMapper<PLMProductConfData> custReqMapper = new ParameterizedRowMapper<PLMProductConfData>() {
	private static final class CustReqMapper implements ParameterizedRowMapper<PLMProductConfData>{	
	public PLMProductConfData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMProductConfData reportData = new PLMProductConfData();
			reportData.setCustId(PLMUtils.checkNullVal(rs.getString("CR_ID")));
			reportData.setCrIdCns(PLMUtils.checkNullVal(rs.getString("TO_NAME")));
			reportData.setCrTitleCns(PLMUtils.checkNullVal(rs.getString("CR_TITLE")));
			reportData.setCrDescCns(PLMUtils.checkNullVal(rs.getString("CR_DESC")));
			return reportData;
		}
	//	};
	}
	
	
	
	
	///newly Added for IS/Was Parts Reports
	/**
	 * This method is used for getIsWasPartsReport
	 * 
	 * @param contractName
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMIswasParts> getIsWasPartsReport(String contractName)
			throws PLMCommonException{
		 
		  LOG.info("Entering getIsWasPartsReport Method");
		  
		  List<PLMIswasParts> isWasPartsList = new ArrayList<PLMIswasParts>();
		  
//		  List<PLMIswasParts> isWasPartsList2 = new ArrayList<PLMIswasParts>();
			
			boolean GTT1Executed = false;
			boolean GTT2Executed = false;
			boolean GTT3Executed = false;
			
			try{
			
				LOG.info("Query for INSERT INTO CDR_GTT_CST_PRNTLVL : " + PLMOfflineQueries.INSERT_COST_CHNG_DATA1);
							
				getJdbcTemplate().update(PLMOfflineQueries.INSERT_COST_CHNG_DATA1,new Object[]{contractName});
				
				GTT1Executed = true;
				
				if (GTT1Executed) {
					LOG.info("Query for Collect STATS CDR_GTT_CST_PRNTLVL : " + PLMOfflineQueries.COST_CHNG_DATA1_COL_STATS1);
					getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA1_COL_STATS1);
				}
				
				int prntCount = getJdbcTemplate().queryForInt(PLMOfflineQueries.COST_CHNG_DATA1_CNT);
				
				if (prntCount >0) {
					
					LOG.info("Query for INSERT into CDR_GTT_CST_BOM : " + PLMOfflineQueries.INSERT_COST_CHNG_DATA2);
					
					getJdbcTemplate().execute(PLMOfflineQueries.INSERT_COST_CHNG_DATA2);
					GTT2Executed = true;
					
					if (GTT2Executed) {
						LOG.info("Query for Collect STATS CDR_GTT_CST_BOM 1 : " + PLMOfflineQueries.COST_CHNG_DATA2_COL_STATS1);
						getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA2_COL_STATS1);
						LOG.info("Query for Collect STATS CDR_GTT_CST_BOM 2 : " + PLMOfflineQueries.COST_CHNG_DATA2_COL_STATS2);
						getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA2_COL_STATS2);
						LOG.info("Query for Collect STATS CDR_GTT_CST_BOM 3 : " + PLMOfflineQueries.COST_CHNG_DATA2_COL_STATS3);
						getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA2_COL_STATS3);
						LOG.info("Query for Collect STATS CDR_GTT_CST_BOM 4 : " + PLMOfflineQueries.COST_CHNG_DATA2_COL_STATS4);
						getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA2_COL_STATS4);
					}
					
					
					int bomCount = getJdbcTemplate().queryForInt(PLMOfflineQueries.COST_CHNG_DATA2_CNT);
					
					if (bomCount>0) {					

						LOG.info("Query for INSERT into CDR_GTT_CST_BOM_CHLDCHNG : " + PLMOfflineQueries.INSERT_COST_CHNG_DATA3);
						
						getJdbcTemplate().execute(PLMOfflineQueries.INSERT_COST_CHNG_DATA3);
						GTT3Executed = true;
						
						if (GTT3Executed) {
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 1 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS1);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS1);
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 2 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS2);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS2);
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 3 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS3);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS3);
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 4 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS4);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS4);
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 5 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS5);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS5);
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 6 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS6);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS6);
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 7 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS7);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS7);
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 8 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS8);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS8);
							LOG.info("Query for Collect STATS CDR_GTT_CST_BOM_CHLDCHNG 9 : " + PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS9);
							getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_DATA3_COL_STATS9);
						}
						
						LOG.info("Query for UPDATE to CDR_GTT_CST_BOM_CHLDCHNG : " + PLMOfflineQueries.UPDATE_COST_CHNG_DATA);
						getJdbcTemplate().execute(PLMOfflineQueries.UPDATE_COST_CHNG_DATA);
												
						final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("HHmmss");
						Date uniqDate = new Date();
						String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
						
						StringBuffer tblName =  new StringBuffer().append(PLMConstants.VT_PARENT_CHANGES)
						.append(uniqTime);
						
						String parentChngQry = PLMOfflineQueries.PARENT_CHANGES.replace(PLMConstants.VT_PARENT_CHANGES, tblName);
						
						LOG.info("Query to create PARENT_CHANGES table : " + parentChngQry);
						getJdbcTemplate().execute(parentChngQry);				
						
						LOG.info("Query for INSERT to INSERT_PARENT_CHANGES : " + PLMOfflineQueries.INSERT_PARENT_CHANGES.replace(PLMConstants.VT_PARENT_CHANGES, tblName));
						getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PARENT_CHANGES.replace(PLMConstants.VT_PARENT_CHANGES, tblName));
						LOG.info("Query for INSERT to INSERT_PARENT_CHANGES1 : " + PLMOfflineQueries.INSERT_PARENT_CHANGES1.replace(PLMConstants.VT_PARENT_CHANGES, tblName));
						getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PARENT_CHANGES1.replace(PLMConstants.VT_PARENT_CHANGES, tblName));
						LOG.info("Query for INSERT to INSERT_PARENT_CHANGES2 : " + PLMOfflineQueries.INSERT_PARENT_CHANGES2.replace(PLMConstants.VT_PARENT_CHANGES, tblName));
						getJdbcTemplate().execute(PLMOfflineQueries.INSERT_PARENT_CHANGES2.replace(PLMConstants.VT_PARENT_CHANGES, tblName));
						
						LOG.info("Query for SELECT output from COST_CHNG_SMRY_DATA_SEL : " + PLMOfflineQueries.GET_IS_WAS_PARTS_DATA1);
						
						isWasPartsList = getJdbcTemplate().query(PLMOfflineQueries.GET_IS_WAS_PARTS_DATA1, new IsWasPartsMapper());
						LOG.info("The Is/Was part of isWasPartsList size "+isWasPartsList.size());
						
						LOG.info("Query for SELECT output from COST_CHNG_SMRY_DATA_SEL1 : " + PLMOfflineQueries.GET_IS_WAS_PARTS_DATA2.replace(PLMConstants.VT_PARENT_CHANGES, tblName));
						
						List<PLMIswasParts> isWasPartsList2 = getJdbcTemplate().query(PLMOfflineQueries.GET_IS_WAS_PARTS_DATA2.replace(PLMConstants.VT_PARENT_CHANGES, tblName), new IsWasPartsMapper1());
						LOG.info("The Is/Was part of isWasPartsList2 size "+isWasPartsList2.size());
						
						if(!PLMUtils.isEmptyList(isWasPartsList2)){
							LOG.info("first value in isWasPartsList2"+isWasPartsList2.get(0));
						}
						isWasPartsList.addAll(isWasPartsList2);
						
						LOG.info("The IS/WAS Parts Result Total count "+isWasPartsList.size());
						
						// add new select query for Parent Changes 
					}	
				}
			} catch(DataAccessException e){
				PLMUtils.checkException(e.getMessage());
			} finally {
				try {
					if (GTT1Executed) {
						LOG.info("Query for Delete COST_CHNG_SMRY_DATA1_DEL  : " + PLMOfflineQueries.COST_CHNG_SMRY_DATA1_DEL);
						getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_SMRY_DATA1_DEL);
					}
					if (GTT2Executed) {
						LOG.info("Query for Delete COST_CHNG_SMRY_DATA2_DEL : " + PLMOfflineQueries.COST_CHNG_SMRY_DATA2_DEL);
						getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_SMRY_DATA2_DEL);
					}
					if (GTT3Executed) {
						LOG.info("Query for Delete COST_CHNG_SMRY_DATA3_DEL : " + PLMOfflineQueries.COST_CHNG_SMRY_DATA3_DEL);
						getJdbcTemplate().execute(PLMOfflineQueries.COST_CHNG_SMRY_DATA3_DEL);
					}
				} catch(DataAccessException e) {
					LOG.info("Exception occurred while deleting data " +
							"from GTT tables in getCostChngReport method : " + e.getMessage());
					PLMUtils.checkException(e.getMessage());
				}
			}
			LOG.info("Exiting getCostChngReport Method");
			if (isWasPartsList.size()>0)
				Collections.sort(isWasPartsList, new SortList1());
			return isWasPartsList;
		}
	

	/**
	 * Row mapper for getting isWasPartsMapper
	 */
//private static ParameterizedRowMapper<PLMIswasParts> isWasPartsMapper = new ParameterizedRowMapper<PLMIswasParts>() {
	private static final class IsWasPartsMapper implements ParameterizedRowMapper<PLMIswasParts>{	
		public PLMIswasParts mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMIswasParts tempData = new PLMIswasParts();
			
			tempData.setTopLevelPrnt(PLMUtils.checkNullVal(rs.getString("TOP_LEVEL_PARENT_NAME")));
			tempData.setLvlOneParentName(PLMUtils.checkNullVal(rs.getString("LVL_ONE_PARENT_NAME")));
			tempData.setLvlOneParentRev(PLMUtils.checkNullVal(rs.getString("LVL_ONE_PARENT_REV")));
        	tempData.setAffectItmLvl(PLMUtils.checkNullVal(rs.getString("AFFCT_ITEM_LVL")));
			tempData.setAffectItmName(PLMUtils.checkNullVal(rs.getString("AFFCT_ITEM_NAME")));
			tempData.setAffectItmRev(PLMUtils.checkNullVal(rs.getString("AFFCT_ITEM_REV")));
			tempData.setParentPart(PLMUtils.checkNullVal(rs.getString("PARENT_NAME")));
			tempData.setGeBomPrefix(PLMUtils.checkNullVal(rs.getString("BOM_PREFIX")));
			tempData.setIsPartName(PLMUtils.checkNullVal(rs.getString("IS_PART_NAME")));
			tempData.setIsPartRev(PLMUtils.checkNullVal(rs.getString("IS_PART_REV")));
			tempData.setIsPartStateDate(rs.getTimestamp("DATE_OF_IS_PART_STATE"));
			tempData.setRdo(PLMUtils.checkNullVal(rs.getString("RDO_OF_IS_PART")));
			tempData.setIsBomQty(PLMUtils.checkNullVal(rs.getString("IS_BOM_QUANTITY")));
			tempData.setIsGeCopicParent(PLMUtils.checkNullVal(rs.getString("IS_COPICS_PARENT")));
			tempData.setWasPartName(PLMUtils.checkNullVal(rs.getString("WAS_PART_NAME")));
			tempData.setWasPartRev(PLMUtils.checkNullVal(rs.getString("WAS_PART_REV")));
			tempData.setEcr(PLMUtils.checkNullVal(rs.getString("ECR_NAME")));
			tempData.setEcrModifedDate(rs.getTimestamp("ECR_LAST_MODIFIED"));
			tempData.setEcrDescIwp(PLMUtils.checkNullVal(rs.getString("ECR_DESCRIPTION")));
			tempData.setEcrCtgryChange(PLMUtils.checkNullVal(rs.getString("ECR_CATEGORY_CHANGE")));
			tempData.setEcrOrig(PLMUtils.checkNullVal(rs.getString("ECR_ORIGINATOR")));
			tempData.setEcrOrigName(PLMUtils.checkNullVal(rs.getString("ECR_ORIG_NAME")));
			tempData.setEcrRespDesign(PLMUtils.checkNullVal(rs.getString("ECR_RSP_DESIGN_ENGR")));
			tempData.setEcrRespDesignName(PLMUtils.checkNullVal(rs.getString("ECR_RSP_DSG_ENGR_NAME")));
			tempData.setEco(PLMUtils.checkNullVal(rs.getString("ECO_NAME")));
			tempData.setEcoModifedDate(rs.getTimestamp("ECO_LAST_MODIFIED"));
			tempData.setEcoCtgryChange(PLMUtils.checkNullVal(rs.getString("ECO_CATEGORY_CHANGE")));
			tempData.setEcoSeverity(PLMUtils.checkNullVal(rs.getString("ECO_SEVERITY")));
			tempData.setEcoSubst(PLMUtils.checkNullVal(rs.getString("ECO_SUBSTANTIATION"))); 
			tempData.setEcoDesc(PLMUtils.checkNullVal(rs.getString("ECO_DESCRIPTION"))); 
			tempData.setEcoFastTrack(PLMUtils.checkNullVal(rs.getString("ECO_FAST_TRACK"))); 
			tempData.setEcrStatus(PLMUtils.checkNullVal(rs.getString("ECR_STATUS"))); 
			tempData.setEcoStatus(PLMUtils.checkNullVal(rs.getString("ECO_STATUS")));
			tempData.setRequestChange(PLMUtils.checkNullVal(rs.getString("REQSTD_CHNG")));
			tempData.setDispInStock(PLMUtils.checkNullVal(rs.getString("DISPOSITION_IN_STOCK")));
			tempData.setDispInProcess(PLMUtils.checkNullVal(rs.getString("DISPOSITION_IN_PROCESS")));
        	tempData.setDispOnOrder(PLMUtils.checkNullVal(rs.getString("DISPOSITION_ON_ORDER")));
			tempData.setEcoPolicy(PLMUtils.checkNullVal(rs.getString("ECO_POLICY")));
			tempData.setClsImpactStmtTxt(PLMUtils.checkNullVal(rs.getString("CLS_I_IMPACT_STMT_TXT")));
			tempData.setBomMarkup(PLMUtils.checkNullVal(rs.getString("BOM_MARKUP")));
			tempData.setBomMarkupType(PLMUtils.checkNullVal(rs.getString("BOM_MARKUP_TYPE")));
			tempData.setDfsOrder(PLMUtils.checkNullVal(rs.getString("DFSORDER")));
			return tempData;
		}
	//	};
	}
	
	/**
	 * Row mapper for getting isWasPartsMapper1
	 */
//private static ParameterizedRowMapper<PLMIswasParts> isWasPartsMapper1 = new ParameterizedRowMapper<PLMIswasParts>() {
	private static final class IsWasPartsMapper1 implements ParameterizedRowMapper<PLMIswasParts>{	
		public PLMIswasParts mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMIswasParts tempData = new PLMIswasParts();
			
			tempData.setIsGeCopicParent(PLMUtils.checkNullVal(rs.getString("IS_COPICS_PARENT")));
			tempData.setIsBomQty(PLMUtils.checkNullVal(rs.getString("IS_BOM_QUANTITY")));
			tempData.setWasGeCopicParent(PLMUtils.checkNullVal(rs.getString("WAS_COPICS_PARENT")));
			tempData.setWasBomQty(PLMUtils.checkNullVal(rs.getString("WAS_BOM_QUANTITY")));
			tempData.setTopLevelPrnt(PLMUtils.checkNullVal(rs.getString("TOP_LEVEL_PARENT_NAME")));
			tempData.setLvlOneParentName(PLMUtils.checkNullVal(rs.getString("LVL_ONE_PARENT_NAME")));
			tempData.setLvlOneParentRev(PLMUtils.checkNullVal(rs.getString("LVL_ONE_PARENT_REV")));
			tempData.setAffectItmLvl(PLMUtils.checkNullVal(rs.getString("AFFCT_ITEM_LVL")));
			tempData.setAffectItmName(PLMUtils.checkNullVal(rs.getString("AFFCT_ITEM_NAME")));
			tempData.setAffectItmRev(PLMUtils.checkNullVal(rs.getString("AFFCT_ITEM_REV")));
			tempData.setParentPart(PLMUtils.checkNullVal(rs.getString("PARENT_NAME")));
			tempData.setGeBomPrefix(PLMUtils.checkNullVal(rs.getString("GE_BOM_PREFIX")));
			tempData.setIsPartName(PLMUtils.checkNullVal(rs.getString("IS_PART_NAME")));
			tempData.setIsPartRev(PLMUtils.checkNullVal(rs.getString("IS_PART_REV")));
			tempData.setRdo(PLMUtils.checkNullVal(rs.getString("RDO_OF_IS_PART")));
			tempData.setIsPartStateDate(rs.getTimestamp("DATE_OF_IS_PART_STATE"));
			tempData.setWasPartName(PLMUtils.checkNullVal(rs.getString("WAS_PART_NAME")));
			tempData.setWasPartRev(PLMUtils.checkNullVal(rs.getString("WAS_PART_REV")));
			tempData.setEcr(PLMUtils.checkNullVal(rs.getString("ECR_NAME")));
			tempData.setEcrModifedDate(rs.getTimestamp("ECR_LAST_MODIFIED"));
			tempData.setEcrDescIwp(PLMUtils.checkNullVal(rs.getString("ECR_DESCRIPTION")));
			tempData.setEcrCtgryChange(PLMUtils.checkNullVal(rs.getString("ECR_CATEGORY_CHANGE")));
			tempData.setEcrOrig(PLMUtils.checkNullVal(rs.getString("ECR_ORIGINATOR")));
			tempData.setEcrOrigName(PLMUtils.checkNullVal(rs.getString("ECR_ORIG_NAME")));
        	tempData.setEcrRespDesign(PLMUtils.checkNullVal(rs.getString("ECR_RSP_DESIGN_ENGR")));
			tempData.setEcrRespDesignName(PLMUtils.checkNullVal(rs.getString("ECR_RSP_DSG_ENGR_NAME")));
			tempData.setEco(PLMUtils.checkNullVal(rs.getString("ECO_NAME")));
			tempData.setEcoModifedDate(rs.getTimestamp("ECO_LAST_MODIFIED"));
			tempData.setEcoCtgryChange(PLMUtils.checkNullVal(rs.getString("ECO_CATEGORY_CHANGE")));
			tempData.setEcoSeverity(PLMUtils.checkNullVal(rs.getString("ECO_SEVERITY")));
			tempData.setEcoSubst(PLMUtils.checkNullVal(rs.getString("ECO_SUBSTANTIATION"))); 
			tempData.setEcoDesc(PLMUtils.checkNullVal(rs.getString("ECO_DESCRIPTION"))); 
			tempData.setEcoFastTrack(PLMUtils.checkNullVal(rs.getString("ECO_FAST_TRACK"))); 
			tempData.setEcrStatus(PLMUtils.checkNullVal(rs.getString("ECR_STATUS"))); 
			tempData.setEcoStatus(PLMUtils.checkNullVal(rs.getString("ECO_STATUS")));
			tempData.setRequestChange(PLMUtils.checkNullVal(rs.getString("REQSTD_CHNG")));
			tempData.setDispInFeild(PLMUtils.checkNullVal(rs.getString("DISPOSITION_IN_FIELD")));
			tempData.setDispInStock(PLMUtils.checkNullVal(rs.getString("DISPOSITION_IN_STOCK")));
			tempData.setDispInProcess(PLMUtils.checkNullVal(rs.getString("DISPOSITION_IN_PROCESS")));
			tempData.setDispOnOrder(PLMUtils.checkNullVal(rs.getString("DISPOSITION_ON_ORDER")));
			tempData.setEcoPolicy(PLMUtils.checkNullVal(rs.getString("ECO_POLICY")));
			tempData.setClsImpactStmtTxt(PLMUtils.checkNullVal(rs.getString("CLS_I_IMPACT_STMT_TXT")));
			tempData.setBomMarkup(PLMUtils.checkNullVal(rs.getString("BOM_MARKUP")));
			tempData.setBomMarkupType(PLMUtils.checkNullVal(rs.getString("BOM_MARKUP_TYPE")));
			tempData.setDfsOrder(PLMUtils.checkNullVal(rs.getString("DFSORDER")));
		
			return tempData;
		}
	// };
	}
	
	/**
	 * 
	 * class to sort list of object of type selected item.
	 * 
	 */
	private static class SortList1 implements Comparator<PLMIswasParts>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMIswasParts aString,
				PLMIswasParts bString) {
			/*String aStr;
			String bStr;
			aStr = aString.getTopLevelparent();
			bStr = bString.getTopLevelparent();
			return aStr.compareTo(bStr);*/			
			int result = aString.getTopLevelPrnt().compareTo(bString.getTopLevelPrnt());
			if (result != 0)
		    {
				return result;
		    }
			return aString.getDfsOrder().compareTo(bString.getDfsOrder());
			
		}
	}
	
	
}
	
	
	