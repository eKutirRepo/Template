package com.geinfra.geaviation.pwi.faces;

import java.io.IOException;

import javax.el.ValueExpression;
import javax.faces.component.UIComponentBase;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;

/**
 * Copyright(C) 2013 GE All rights reserved
 * @deprecated
 */
public class UIAnchor extends UIComponentBase {

	@Override
	public String getFamily() {
		return "a";
	}

	public String getRendererType() {
		return "renderer";
	}

	public void encodeBegin(FacesContext context) throws IOException {
		if (getBoolean("rendered")) {
			ResponseWriter writer = context.getResponseWriter();
			writer.startElement("a", this);
			writer.writeAttribute("href", getString("href"), null);
			writer.writeAttribute("class", getString("styleClass"), null);
			writer.write(getString("text"));
			writer.endElement("a");
		}
	}

	public void encodeEnd(FacesContext context) throws IOException {
		return;
	}

	public void decode(FacesContext context) {
		return;
	}

	private boolean getBoolean(String name) {
		boolean rendered = false;
		ValueExpression ve = getValueExpression(name);
		if (ve != null) {
			rendered = ((Boolean) ve.getValue(getFacesContext().getELContext()))
					.booleanValue();
		}
		return rendered;
	}

	private String getString(String name) {
		String value = null;
		ValueExpression ve = getValueExpression(name);
		if (ve != null) {
			value = (String) ve.getValue(getFacesContext().getELContext());
		} else {
			value = (String) getAttributes().get(name);
		}
		return value;
	}
}
