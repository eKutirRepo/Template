/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhereUsedLogIndicatorMB.java
 * @Creation date: 23-July-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.data.PLMWhereUsedData;
import com.geinfra.geaviation.pwi.service.PLMWhereUsedServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

public class PLMWhereUsedLogIndicatorMB {

	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMWhereUsedLogIndicatorMB.class);
	
	/**
	 * Holds the plmWhereUsedService
	 */
	private PLMWhereUsedServiceIfc plmWhereUsedService = null;
	
	/**
	 * Holds the plmWhereUsedData
	 */
	private PLMWhereUsedData plmWhereUsedData = new PLMWhereUsedData();
	
	/**
	 * Holds the whereUsedLogIndicatorSearchList
	 */
	private List<PLMWhereUsedData> whereUsedLogIndicatorSearchList;
	
	/**
	 * Holds the recordCount
	 */
	private int recordCount = PLMConstants.N_100;
	
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	
	/**
	 * Holds the totalRecCountMsg
	 */
	private String totalRecCountMsg;
	
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;	
	
	/**
	 * This method is used for loadWhereUsedLogicalIndicator
	 * 
	 * @return String
	 */
	public String loadWhereUsedLogicalIndicator() {
		LOG.info("Entering into the PLMWhereUsedLogIndicatorMB loadWhereUsedLogicalIndicator()");
		
		try {
			commonMB.insertCannedRptRecordHitInfo("Where Used Logical Indicator (PLM)");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		String fwdflag = "";
		plmWhereUsedData = new PLMWhereUsedData();
		fwdflag = PLMConstants.WHERE_USED_LOGICAL_INDICATOR_SEARCH; 
		LOG.info("Exiting from the PLMWhereUsedLogIndicatorMB loadWhereUsedLogicalIndicator()");
		return fwdflag;
	}
	
	/**
	 * This method is used for populateWhereUsedLogIndicatorSearchList
	 * 
	 * @return String
	 */
	public String populateWhereUsedLogIndicatorSearchList() {
	String fwdflag = "";
	if (PLMUtils.isEmpty(plmWhereUsedData.getLogicalIndicator())&& PLMUtils.isEmpty(plmWhereUsedData.getProject()) &&
			PLMUtils.isEmpty(plmWhereUsedData.getRelatedName())){
		alertMessage = PLMConstants.LOGICAL_INDICATOR_ALERTMESSAGE;
		fwdflag = PLMConstants.WHERE_USED_LOGICAL_INDICATOR_SEARCH;
	} else {
		if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmWhereUsedData.getLogicalIndicator())
					&& !PLMUtils.isEmpty(plmWhereUsedData.getLogicalIndicator())) {
			alertMessage = alertMessage	+ PLMConstants.LOGICAL_INDICATOR_SPECCHARMESSAGE;
			fwdflag = PLMConstants.WHERE_USED_LOGICAL_INDICATOR_SEARCH;
		}
		if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmWhereUsedData.getProject())
				&& !PLMUtils.isEmpty(plmWhereUsedData.getProject())) {
			alertMessage = alertMessage	+ PLMConstants.PROJECT_NAME_SPECCHARMESSAGE;
			fwdflag = PLMConstants.WHERE_USED_LOGICAL_INDICATOR_SEARCH;
		}
		
		if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmWhereUsedData.getRelatedName())
				&& !PLMUtils.isEmpty(plmWhereUsedData.getRelatedName())) {
			alertMessage = alertMessage	+ PLMConstants.RELATED_NAME_SPECCHARMESSAGE;
			fwdflag = PLMConstants.WHERE_USED_LOGICAL_INDICATOR_SEARCH;
		}
	}		
	if (plmWhereUsedData.isDocument() == false && plmWhereUsedData.isPartSpecification() == false && plmWhereUsedData.isRefDocument() == false){
		alertMessage = alertMessage + PLMConstants.LOGICAL_INDICATOR_CHECKBOXALERTMESSAGE;
		fwdflag = PLMConstants.WHERE_USED_LOGICAL_INDICATOR_SEARCH;
	}	
	
	if (PLMUtils.isEmpty(alertMessage)) {
	try {		 
	whereUsedLogIndicatorSearchList = plmWhereUsedService.getWhereUsedLogIndicatorData(plmWhereUsedData);
	if (PLMUtils.isEmptyList(whereUsedLogIndicatorSearchList)) {
		recordCount = 0;
		totalRecCount = 0;
		fwdflag = "invalidLogicalIndicator";
	} else { 
		recordCount = PLMConstants.N_100;
		totalRecCount = whereUsedLogIndicatorSearchList.size();
		totalRecCountMsg = "Total Results Count : " + totalRecCount;
		fwdflag = PLMConstants.WHERE_USED_LOGICAL_INDICATOR_REPORT;
	}
	LOG.info("The Total Record Count is : " + totalRecCount);
	} catch (PLMCommonException exception) {
		LOG.log(Level.ERROR, "Exception@populateWhereUsedLogIndicatorSearchList: ", exception);
		fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"whereUsedLogicalIndicatorSearch","Where Used Logical Indicator (PLM)");
	} 
	}
	return fwdflag;
	}
		
	/**
	 * This method is used for resetData
	 * 
	 * @return String
	 */
	public String resetData(){
		plmWhereUsedData.setLogicalIndicator("");
		plmWhereUsedData.setProject("");
		plmWhereUsedData.setRelatedName("");
		alertMessage="";
		plmWhereUsedData.setDocument(false);
		plmWhereUsedData.setPartSpecification(false);
		plmWhereUsedData.setRefDocument(false);
		return PLMConstants.WHERE_USED_LOGICAL_INDICATOR_SEARCH;
	}
	
	/**
	 * This method is used to download excel for Where Used Logical Indicator report
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadWhereUsedLogIndicatorExcel(){

		LOG.info("Entering downloadWhereUsedLogIndicatorExcel Method");
		String reportName = "whereUsedLogicalIndicator";
		String fileName = "whereUsedLogicalIndicator";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		//Export to Excel for Where used Logical Indicator Report
		
		PLMXlsxRptColumn[] critcolumns  = new PLMXlsxRptColumn[] {
                new PLMXlsxRptColumn("logicalIndicator", "Logical Indicator", FormatType.TEXT),
                new PLMXlsxRptColumn("project", "Project Name", FormatType.TEXT),
                new PLMXlsxRptColumn("relatedName", "Related Item Name", FormatType.TEXT), 
                new PLMXlsxRptColumn("document", "Document", FormatType.TEXT),
                new PLMXlsxRptColumn("partSpecification", "Part Specification", FormatType.TEXT),
                new PLMXlsxRptColumn("refDocument", "Reference Doc", FormatType.TEXT)
                };
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					  new PLMXlsxRptColumn("contract", "Contract", FormatType.TEXT),
					  new PLMXlsxRptColumn("project", "Project", FormatType.TEXT),
					  new PLMXlsxRptColumn("relatedItem", "Related Item Name", FormatType.TEXT, null, null, 22),
					  new PLMXlsxRptColumn("relatedItemType", "Related Item Type", FormatType.TEXT, null, null, 22),
					  new PLMXlsxRptColumn("docName", "Document Name", FormatType.TEXT, null, null, 22),
					  new PLMXlsxRptColumn("type", "Document Type", FormatType.TEXT, null, null, 22),
					  new PLMXlsxRptColumn("rev", "Rev", FormatType.TEXT, null, null, 8),
					  new PLMXlsxRptColumn("docTitle", "Document Title", FormatType.TEXT, null, null,35),
					  new PLMXlsxRptColumn("logicalIndicator", "GE Logical Indicator", FormatType.TEXT, null, null,22),
					  new PLMXlsxRptColumn("typeOfLogicalIndicator", "Type of Logical Indicator", FormatType.TEXT)
			};
			
			excelUtil.export(whereUsedLogIndicatorSearchList, reportColumns, fileName, fileName, true, critcolumns, plmWhereUsedData);	
			LOG.info("Exiting downloadWhereUsedLogIndicatorExcel Method");
	}
	
	/**
	 * This method is used for Generating Where Used Logical Indicator report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	
	public void createDownloadLogIndicatorCSV() throws PLMCommonException {
		LOG.info("Entering createDownloadLogIndicatorCSV Method");
		String reportName = "whereUsedLogicalIndicator";
		String fileName = "whereUsedLogicalIndicator";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		//Export to CSV for Where used Logical Indicator Report
		
			PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
					  new PLMCsvRptColumn("contract", "Contract", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("project", "Project", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("relatedItem", "Related Item Name", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("relatedItemType", "Related Item Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("docName", "Document Name", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("type", "Document Type", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("rev", "Rev", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("docTitle", "Document Title", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("logicalIndicator", "GE Logical Indicator", FormatTypeCsv.TEXT),
					  new PLMCsvRptColumn("typeOfLogicalIndicator", "Type of Logical Indicator", FormatTypeCsv.TEXT)
			};
			csvUtil.exportCsv(whereUsedLogIndicatorSearchList, reportColumns, fileName, dateFormat, false, null, null, ",");
			
			LOG.info("Exiting createDownloadLogIndicatorCSV Method");
	}

	/**
	 * @return the plmWhereUsedService
	 */
	public PLMWhereUsedServiceIfc getPlmWhereUsedService() {
		return plmWhereUsedService;
	}

	/**
	 * @param plmWhereUsedService the plmWhereUsedService to set
	 */
	public void setPlmWhereUsedService(PLMWhereUsedServiceIfc plmWhereUsedService) {
		this.plmWhereUsedService = plmWhereUsedService;
	}

	/**
	 * @return the plmWhereUsedData
	 */
	public PLMWhereUsedData getPlmWhereUsedData() {
		return plmWhereUsedData;
	}

	/**
	 * @param plmWhereUsedData the plmWhereUsedData to set
	 */
	public void setPlmWhereUsedData(PLMWhereUsedData plmWhereUsedData) {
		this.plmWhereUsedData = plmWhereUsedData;
	}

	/**
	 * @return the recordCount
	 */
	public int getRecordCount() {
		return recordCount;
	}

	/**
	 * @param recordCount the recordCount to set
	 */
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the totalRecCountMsg
	 */
	public String getTotalRecCountMsg() {
		return totalRecCountMsg;
	}

	/**
	 * @param totalRecCountMsg the totalRecCountMsg to set
	 */
	public void setTotalRecCountMsg(String totalRecCountMsg) {
		this.totalRecCountMsg = totalRecCountMsg;
	}
	/**
	 * @return the whereUsedLogIndicatorSearchList
	 */
	public List<PLMWhereUsedData> getWhereUsedLogIndicatorSearchList() {
		return whereUsedLogIndicatorSearchList;
	}
	/**
	 * @param whereUsedLogIndicatorSearchList the whereUsedLogIndicatorSearchList to set
	 */
	public void setWhereUsedLogIndicatorSearchList(
			List<PLMWhereUsedData> whereUsedLogIndicatorSearchList) {
		this.whereUsedLogIndicatorSearchList = whereUsedLogIndicatorSearchList;
	}

	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}
}