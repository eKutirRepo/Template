package com.geinfra.geaviation.pwi.executors;

import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.PWiQueryTimeoutException;
import com.geinfra.geaviation.pwi.common.PWiResultSizeLimitExceededException;
import com.geinfra.geaviation.pwi.model.PWiResultSet;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;

/**
 * 
 * Project      : Product Lifecycle Management Intelligence
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description :
 * 
 * Revision Log
 * 2012.12.18 pH  replaced GEAEResultSet with PWiResultSet
 * --------------------------------------------------------------
 */
public interface Executor {
	/**
	 * Executes a query based on the provided user-specified criteria and any
	 * previous result.
	 * 
	 * @param queryType
	 * 
	 * @param search
	 *            cannot be null
	 * @param selectedColumns
	 *            cannot be null
	 * @param sso
	 *            cannot be null
	 * @param columns
	 * @param rows
	 * 
	 * @return result of the query
	 * @throws PWiException
	 * @throws PWiResultSizeLimitExceededException
	 * @throws PWiQueryTimeoutException
	 */
	public PWiResultSet execute(QueryType queryType, Search search,
			SelectedColumns selectedColumns, String sso, String[] columns,
			List<Object[]> rows) throws PWiException,
			PWiResultSizeLimitExceededException, PWiQueryTimeoutException;

	/**
	 * Returns a string representing the last query that was executed. Undefined
	 * if no query has been executed.
	 * 
	 * @return string representing the last query that was executed
	 */
	public String getExecutedQuery();
}
