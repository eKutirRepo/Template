/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCFCRPRSRptServiceIfc.java
 * @Creation date: 30-July-2015
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.service;

import java.util.List;

import com.geinfra.geaviation.pwi.data.PLMCFCRPRSRptData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMCFCRPRSRptServiceIfc {
	
	/**
	 * This method is used to validateContracts
	 * 
	 * @param List
	 * @return String
	 * @throws PLMCommonException
	 */
	public String validateContracts(List<String> contractList) throws PLMCommonException;
	
	/**
	 * This method is used to fetch Customer Grp Data
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<String> fetchCstGrpData() throws PLMCommonException;
	/**
	 * This method is used to fetch PC Info
	 * 
	 * @param cntrtNm
	 * @param cstGrpList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMCFCRPRSRptData> fetchPCInfo(String cntrtNm,List<String> cstGrpList) throws PLMCommonException;
	/**
	 * This method is used to get CF Data Report
	 * 
	 * @param contractList
	 * @param pcList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMCFCRPRSRptData> getCFReportData(String contract1,String contract2,String contract3,String selPcName1,String selPcName2,String selPcName3) throws PLMCommonException;
	/**
	 * This method is used to get CR Data Report
	 * 
	 * @param contractList
	 * @param contract1,contract2,contract3
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMCFCRPRSRptData> getCRReportData(List<String> contractList,String contract1,String contract2,String contract3,
			List<String> selCstGrpList1,List<String> selCstGrpList2,List<String> selCstGrpList3) throws PLMCommonException;
	
	/**
	 * This method is used to get CR Data Report
	 * @param contract1,contract2,contract3
	 * @param contractList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMCFCRPRSRptData> getPRSData(List<String> contractList,String contract1,String contract2,String contract3) throws PLMCommonException;



}
