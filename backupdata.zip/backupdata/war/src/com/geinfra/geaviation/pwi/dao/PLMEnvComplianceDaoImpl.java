/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEnvComplianceDaoImpl.java
 * @Creation date: 9-Jul-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMEnvComplianceData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMEnvComplianceDaoImpl extends SimpleJdbcDaoSupport implements  PLMEnvComplianceDaoIfc{
	/**
	 *  Holds the lOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMEnvComplianceDaoImpl.class);
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
		 
	}
	
	/**
	 * This method is used to get Classification List
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<String> getClassificationList() throws PLMCommonException {
		LOG.info("Executing GET_CLASSIFICATION Query : " + PLMOfflineQueries.GET_CLASSIFICATION + "\n");
		List<String> clsfctnList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_CLASSIFICATION, new ClassificationMapper());
		Collections.sort(clsfctnList, new PLMUtils.SortStringList());
		return clsfctnList;
	}

	
	/**
	 * @return String objects.
	 */
	private static final class ClassificationMapper implements ParameterizedRowMapper<String> {
		public String mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			String classify = rs.getString("REGULATION");
			return classify;
		}
	}
	
	
	/**
	 * This method is used to fetchCntrInfo
	 * @param cntrtNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMEnvComplianceData> fetchCntrInfo(String cntrtNm) throws PLMCommonException{
		LOG.info("Executing GET_CNTRT_INFO Query : " + PLMOfflineQueries.GET_CNTRT_INFO_RPT + "\n");
		LOG.info("Contract Name in DAO------------->"+cntrtNm);
		return getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_CNTRT_INFO_RPT, new CntrInfoMapper(),new Object[]{cntrtNm});
	}
	
	/**
	 * @return PLMEnvComplianceData objects.
	 */
	private static final class CntrInfoMapper implements ParameterizedRowMapper<PLMEnvComplianceData> {
		public PLMEnvComplianceData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMEnvComplianceData data = new PLMEnvComplianceData();
			data.setCntrtNm(rs.getString("NM"));
			data.setCntrtDesc(rs.getString("DESCRIPTION"));
			return data;
		}
	}
	
	
	/**
	 * This method is used for getWBSEReport
	 * 
	 * @param contractName,classification,casNum
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMEnvComplianceData> getWBSEReport(String contractName,String classification,String casNum)
			throws PLMCommonException{
		  LOG.info("Entering getWBSEReport Method");
		  List<PLMEnvComplianceData> wbseList = new ArrayList<PLMEnvComplianceData>();
		  String timeStamp = PLMUtils.volTableFormatDate();
		  String VT_0 = PLMConstants.ENVIRON_COMPLIANCE_VT0.concat(timeStamp);
		  String VT_1 = PLMConstants.ENVIRON_COMPLIANCE_VT1.concat(timeStamp);
		  String VT_2 = PLMConstants.ENVIRON_COMPLIANCE_VT2.concat(timeStamp);
		  String VT_3 = PLMConstants.ENVIRON_COMPLIANCE_VT3.concat(timeStamp);
		  String VT_4 = PLMConstants.ENVIRON_COMPLIANCE_VT4.concat(timeStamp);
		  String VT_5 = PLMConstants.ENVIRON_COMPLIANCE_VT5.concat(timeStamp);
		  StringBuffer finalQuery =new StringBuffer();
		  boolean whereFlag=false;
		  Map<String, Object> params = new HashMap<String, Object>();
		  try{
			String createVT0 = PLMOfflineQueries.CREATE_VT0_ENVCOMPLIANCE.replace("?",  "'"+contractName+"'").replace(PLMConstants.ENVIRON_COMPLIANCE_VT0, VT_0);
			LOG.info("Executing createVT0 Query : " + createVT0 + "\n");
			getJdbcTemplate().execute(createVT0);
			
			String createVT1 = PLMOfflineQueries.CREATE_VT1_ENVCOMPLIANCE.replace(PLMConstants.ENVIRON_COMPLIANCE_VT0, VT_0).replace(PLMConstants.ENVIRON_COMPLIANCE_VT1, VT_1);
			LOG.info("Executing createVT1 Query : " + createVT1 + "\n");
			getJdbcTemplate().execute(createVT1);
			
			String createVT2 = PLMOfflineQueries.CREATE_VT2_ENVCOMPLIANCE.replace(PLMConstants.ENVIRON_COMPLIANCE_VT0, VT_0).replace(PLMConstants.ENVIRON_COMPLIANCE_VT2, VT_2);
			LOG.info("Executing createVT2 Query : " + createVT2 + "\n");
			getJdbcTemplate().execute(createVT2);
		
			
			String createVT3 = PLMOfflineQueries.CREATE_VT3_ENVCOMPLIANCE.replace(PLMConstants.ENVIRON_COMPLIANCE_VT2, VT_2).replace(PLMConstants.ENVIRON_COMPLIANCE_VT3, VT_3);
			LOG.info("Executing createVT3 Query : " + createVT3 + "\n");
			getJdbcTemplate().execute(createVT3);
		
			String createVT4 = PLMOfflineQueries.CREATE_VT4_ENVCOMPLIANCE.replace(PLMConstants.ENVIRON_COMPLIANCE_VT3, VT_3).replace(PLMConstants.ENVIRON_COMPLIANCE_VT4, VT_4);
			LOG.info("Executing createVT4 Query : " + createVT4 + "\n");
			getJdbcTemplate().execute(createVT4);
		
			String createVT5 = PLMOfflineQueries.CREATE_VT5_ENVCOMPLIANCE.replace(PLMConstants.ENVIRON_COMPLIANCE_VT4, VT_4).replace(PLMConstants.ENVIRON_COMPLIANCE_VT5, VT_5);
			LOG.info("Executing createVT5 Query : " + createVT5 + "\n");
			getJdbcTemplate().execute(createVT5);
		
			String getWBSEData = PLMOfflineQueries.GET_ENVCOMPLIANCE_DATA.replace(PLMConstants.ENVIRON_COMPLIANCE_VT0, VT_0).replace(PLMConstants.ENVIRON_COMPLIANCE_VT1, VT_1).replace(PLMConstants.ENVIRON_COMPLIANCE_VT2, VT_2).replace(PLMConstants.ENVIRON_COMPLIANCE_VT5, VT_5);
			
			finalQuery.append(getWBSEData);
			
			if(classification!=null && classification.length()>0){
				whereFlag =true;
				params.put("REGL", classification);
				finalQuery.append(" WHERE REGULATION = :REGL");
			}
			if(casNum!=null && casNum.length()>0){
				params.put("CASNM", casNum);
				if(!whereFlag){
					finalQuery.append(" WHERE SUB_CAS_NUM = :CASNM");
				}
				else{
					finalQuery.append(" AND SUB_CAS_NUM = :CASNM");
				}
			}
			LOG.info("Executing getWBSEReport Query : " + finalQuery + "\n");
			wbseList = getNamedJdbcTemplate().query(finalQuery.toString(),params, new WBSEMapper());
			
			} catch(DataAccessException e){
				PLMUtils.checkException(e.getMessage());
			} 
			LOG.info("Exiting getWBSEReport Method");
			
			return wbseList;
		}


	/**
	 * @return PLMEnvComplianceData objects.
	 */
	private static final class WBSEMapper implements ParameterizedRowMapper<PLMEnvComplianceData> {
		public PLMEnvComplianceData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMEnvComplianceData data = new PLMEnvComplianceData();
			data.setContract(rs.getString("CONTRACT"));
			data.setProjectNm(rs.getString("PRJ_NM"));
			data.setWsdeName(rs.getString("WBSE_NAME"));
			data.setWsdePartName(rs.getString("WBSE_PART_NAME"));
			data.setMliNew(rs.getString("MLI_NEW"));
			data.setPoNum(rs.getString("PO_NUMBER"));
			data.setPurchaseFolderDt(rs.getTimestamp("PURCHASE_FOLDER_OFFICDTTM"));
			data.setSupplierName(rs.getString("SUPPLIER_NAME"));
			data.setSupplierPerson(rs.getString("SUPPLIER_PERSON"));
			data.setSupplierEmail(rs.getString("SUPPLIER_EMAIL"));
			data.setPurchaseFolderNm(rs.getString("PURCHASE_FOLDER_NAME"));
			data.setSupplierBannCode(rs.getString("SUPPLIER_BAAN_CODE"));
			data.setMliReference(rs.getString("MLI_REFERENCE"));
			data.setPartLvl(rs.getString("PART_LEVEL"));
			data.setPartNum(rs.getString("PART_NUMBER"));
			data.setPartRevision(rs.getString("PART_REVISION"));
			data.setPartType(rs.getString("PART_TYPE"));
			data.setPartAttribute(rs.getString("PART_ATTRIBUTE"));
			data.setPartTitle(rs.getString("PART_TITLE"));
			data.setMaterial(rs.getString("MATERIAL"));
			data.setMaterialType(rs.getString("MATERIAL_TYPE"));
			data.setSubCaseNm(rs.getString("SUB_CAS_NUM"));
			data.setSubName(rs.getString("SUB_NM")); 
			data.setChemicalName(rs.getString("CHEMICAL_NAME")); 
			data.setRegulation(rs.getString("REGULATION"));
			data.setRdoName(rs.getString("RDO_NAME"));
			return data;
			
			
		}
	}
	
		
	/**
	 * This method is used for getBOMReport
	 * 
	 * @param contractName,classification,casNum
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMEnvComplianceData> getBOMReport(String contractName,String classification,String casNum)
			throws PLMCommonException{
		  LOG.info("Entering getBOMReport Method");
		  List<PLMEnvComplianceData> bomList = new ArrayList<PLMEnvComplianceData>();
		  String timeStamp = PLMUtils.volTableFormatDate();
		  String RPT2_VT0 = PLMConstants.RPT2_VT0.concat(timeStamp);
		  String RPT2_VT1 = PLMConstants.RPT2_VT1.concat(timeStamp);
		  String RPT2_VT2 = PLMConstants.RPT2_VT2.concat(timeStamp);
		  String RPT2_VT3 = PLMConstants.RPT2_VT3.concat(timeStamp);
		  StringBuffer finalQuery =new StringBuffer();
		  Map<String, Object> params = new HashMap<String, Object>();
		  boolean whereFlag=false;
			try{
			String CreateRPT2_VT0 = PLMOfflineQueries.CREATE_RPT2_VT0_ENVCOMPLIANCE.replace("?",  "'"+contractName+"'").replace(PLMConstants.RPT2_VT0, RPT2_VT0);
			LOG.info("Executing CreateRPT2_VT0 Query : " + CreateRPT2_VT0 + "\n");
			getJdbcTemplate().execute(CreateRPT2_VT0);
		
			LOG.info("Query for COLLECT STATISTICS ON  RPT2_VT0 : " + PLMOfflineQueries.COLLECTS_RPT2_VT0_ENVCOMPLIANCE.replace(PLMConstants.RPT2_VT0, RPT2_VT0));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECTS_RPT2_VT0_ENVCOMPLIANCE.replace(PLMConstants.RPT2_VT0, RPT2_VT0));
		
			//LOG.info("Query for COLLECTS_CDR_ODS_R_EBOM : " + PLMOfflineQueries.COLLECTS_CDR_ODS_R_EBOM);
			//getJdbcTemplate().execute(PLMOfflineQueries.COLLECTS_CDR_ODS_R_EBOM);
		   
			String CreateRPT2_VT1 = PLMOfflineQueries.CREATE_RPT2_VT1_ENVCOMPLIANCE.replace(PLMConstants.RPT2_VT0, RPT2_VT0).replace(PLMConstants.RPT2_VT1, RPT2_VT1);
			LOG.info("Executing CreateRPT2_VT1 Query : " + CreateRPT2_VT1 + "\n");
			getJdbcTemplate().execute(CreateRPT2_VT1);
			
			String CreateRPT2_VT2 = PLMOfflineQueries.CREATE_RPT2_VT2_ENVCOMPLIANCE.replace(PLMConstants.RPT2_VT1, RPT2_VT1).replace(PLMConstants.RPT2_VT2, RPT2_VT2);
			LOG.info("Executing CreateRPT2_VT2 Query : " + CreateRPT2_VT2 + "\n");
			getJdbcTemplate().execute(CreateRPT2_VT2);
		
			String CreateRPT2_VT3 = PLMOfflineQueries.CREATE_RPT2_VT3_ENVCOMPLIANCE.replace(PLMConstants.RPT2_VT2, RPT2_VT2).replace(PLMConstants.RPT2_VT3, RPT2_VT3);
			LOG.info("Executing CreateRPT2_VT3 Query : " + CreateRPT2_VT3 + "\n");
			getJdbcTemplate().execute(CreateRPT2_VT3);
			
			LOG.info("Query for COLLECT STATISTICS ON  RPT2_VT0 : " + PLMOfflineQueries.COLLECTS_RPT2_VT0_ENVCOMPLIANCE.replace(PLMConstants.RPT2_VT0, RPT2_VT0));
			getJdbcTemplate().execute(PLMOfflineQueries.COLLECTS_RPT2_VT0_ENVCOMPLIANCE.replace(PLMConstants.RPT2_VT0, RPT2_VT0));
		
			LOG.info("Query for COLLECT STATISTICS ON  RPT2_VT3 : " + PLMOfflineQueries.ENV_RPT2_VT3_COL_STATS.replace(PLMConstants.RPT2_VT3, RPT2_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.ENV_RPT2_VT3_COL_STATS.replace(PLMConstants.RPT2_VT3, RPT2_VT3));
		
			String getBomComplianceData = PLMOfflineQueries.GET_ENVCOMPLIANCE_BOM_DATA.replace(PLMConstants.RPT2_VT0, RPT2_VT0).replace(PLMConstants.RPT2_VT3, RPT2_VT3);
			
			finalQuery.append(getBomComplianceData);
			
			if(classification!=null && classification.length()>0){
				whereFlag =true;
				params.put("REGL", classification);
				finalQuery.append(" WHERE REGULATION = :REGL");
			}
			if(casNum!=null && casNum.length()>0){
				params.put("CASNM", casNum);
				if(!whereFlag){
					finalQuery.append(" WHERE SUB_CAS_NUM = :CASNM");
				}
				else{
					finalQuery.append(" AND SUB_CAS_NUM = :CASNM");
				}
			}
			LOG.info("Executing getBOMReport Query : " + finalQuery + "\n");
			bomList = getNamedJdbcTemplate().query(finalQuery.toString(),params, new BOMMapper());

			LOG.info("After Execution of getBOMReport Query : " + bomList.size() + "\n");
			Collections.sort(bomList, new SortDfsOrder());
			LOG.info("After Sorting Bom LIST Env BOM Rpt : ");
			
			} catch(DataAccessException e){
				PLMUtils.checkException(e.getMessage());
			}
			LOG.info("Exiting getBOMReport Method");
			return bomList;
		}
	
	/**
	 * @return PLMEnvComplianceData objects.
	 */
	private static final class BOMMapper implements ParameterizedRowMapper<PLMEnvComplianceData> {
		public PLMEnvComplianceData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMEnvComplianceData data = new PLMEnvComplianceData();
				
			data.setContract(rs.getString("CONTRACT"));
			data.setProjectNm(rs.getString("HW_PRDT"));
			data.setWsdePartName(rs.getString("GBOM_PART"));
			data.setPartLvl(rs.getString("PART_LEVEL"));
			data.setPartNum(rs.getString("PART_NUMBER"));
			data.setPartType(rs.getString("PART_TYPE"));
			data.setPartAttribute(rs.getString("PART_ATTRIBUTE"));
			data.setPartRevision(rs.getString("PART_REVISION"));
			data.setPartTitle(rs.getString("PART_TITLE"));
			data.setMaterial(rs.getString("MATERIAL"));
			data.setMaterialType(rs.getString("MATERIAL_TYPE"));
			data.setSubCaseNm(rs.getString("SUB_CAS_NUM"));
			data.setSubName(rs.getString("SUB_NM")); 
			data.setChemicalName(rs.getString("CHEMICAL_NAME")); 
			data.setRegulation(rs.getString("REGULATION"));
			data.setRdoName(rs.getString("RDO_NAME"));
			data.setDfsOrder(rs.getString("DFSORDER"));
			return data;
			
			
		}
	}
	
	/**
	 * 
	 * class to sort list of object of type PLMEnvComplianceData.
	 * 
	 */
	private static class SortDfsOrder implements Comparator<PLMEnvComplianceData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMEnvComplianceData aString,
				PLMEnvComplianceData bString) {
			String aStr;
			String bStr;
			int result=0;
			aStr = aString.getDfsOrder();
			bStr = bString.getDfsOrder();
			if(aStr != null && bStr != null){
			result = aStr.compareTo(bStr);
			}
			return result;
			
		}
	}
		
	/**
	 * This method is used to fetchWBSEContract
	 * 
	 * @param cntrtNm
	 * @return int
	 * @throws PLMCommonException
	 */
	public int fetchWBSEContract(String cntrtNm) throws PLMCommonException{
		LOG.info("Entering into fetchWBSEContract "+cntrtNm);
		int count=0;
		LOG.info("Executing fetchWBSEContract Query  : " + PLMOfflineQueries.GET_COUNT_WBSE_CONTRACT);
		count = getJdbcTemplate().queryForInt(PLMOfflineQueries.GET_COUNT_WBSE_CONTRACT, 
					new Object[] {cntrtNm});
		LOG.info("fetchWBSEContract count>> "+count);
		return count;
	}
	
	
	/**
	 * This method is used to fetchBOMContract
	 * 
	 * @param cntrtNm
	 * @return int
	 * @throws PLMCommonException
	 */
	public int fetchBOMContract(String cntrtNm) throws PLMCommonException{
		LOG.info("Entering into fetchBOMContract "+cntrtNm);
		int count=0;
		LOG.info("Executing fetchBOMContract Query  : " + PLMOfflineQueries.GET_COUNT_BOM_CONTRACT);
		
		count = getJdbcTemplate().queryForInt(PLMOfflineQueries.GET_COUNT_BOM_CONTRACT, 
				new Object[] {cntrtNm});
		LOG.info("fetchBOMContract count>> "+count);
		return count;
	}
	
}
