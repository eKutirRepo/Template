/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMEccnTagDaoIfc.java
 * @Creation date: 18-Aug-2009
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.util.PLMCommonException;



/**
 * ICMAdminDaoIfc is the DAO interface used for ICM Administrator Menu.
 */
public interface PLMEccnTagDaoIfc {
	
	/**
	 * This method is used to displayEccnTag
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<String> displayEccnTag() throws PLMCommonException;

}
