/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCFCRPRSRptDaoImpl.java
 * @Creation date: 30-July-2015
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMCFCRPRSRptData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMCFCRPRSRptDaoImpl extends SimpleJdbcDaoSupport implements PLMCFCRPRSRptDaoIfc{
	/**
	 * Holds the Logger.
	 */
	
	private static final Logger LOG = Logger.getLogger(PLMCFCRPRSRptDaoImpl.class);
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
		 
	}
	
	/**
	 * This method is used to validateContracts
	 * 
	 * @param List
	 * @return String
	 * @throws PLMCommonException
	 */
	public String validateContracts(List<String> contractList) throws PLMCommonException{
		LOG.info("Entering into validateContracts");
		String validateCntrts="";
		int count=0;
		 if(!PLMUtils.isEmptyList(contractList)){
			 for(int i=0;i<contractList.size();i++){
			 LOG.info("Executing Validate Query for Contract# "+contractList.get(i) +" >>>"+ PLMSearchQueries.VALIDATE_CONTRACTS);
			 count = getJdbcTemplate().queryForInt(PLMSearchQueries.VALIDATE_CONTRACTS, 
						new Object[] {contractList.get(i)});
			   if(count==0){
				   validateCntrts=contractList.get(i) +" is not Valid Contract";
				   break;
			   }else{
				   validateCntrts="";
			   }
			 }
 
		 }
		 LOG.info("Exiting into validateContracts");
		return validateCntrts;
	}
	
	/**
	 * This method is used to fetchCstGrpData
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<String> fetchCstGrpData() throws PLMCommonException{
		LOG.info("Executing GET_CST_GRP_DATA Query : " + PLMSearchQueries.GET_CST_GRP_DATA + "\n");
		return getSimpleJdbcTemplate().query(PLMSearchQueries.GET_CST_GRP_DATA, new CstGrpMapper());
	}
	
	/**
	 * @return  objects.
	 */
	private static final class CstGrpMapper implements ParameterizedRowMapper<String> {
		public String mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			String cstGrpNm = rs.getString(PLMUtils.checkNullVal("GE_COST_GRP"));
			return cstGrpNm;
		}
	}
	
	/**
	 * This method is used to fetch PC Info
	 * 
	 * @param cntrtNm
	 * @param cstGrpList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMCFCRPRSRptData> fetchPCInfo(String cntrtNm,List<String> cstGrpList) throws PLMCommonException{
		StringBuffer searchQuery =new StringBuffer();
		Map<String, Object> params = new HashMap<String, Object>();
		searchQuery.append(PLMSearchQueries.GET_PC_INFO_QUERY);
		params.put("CNTRT", cntrtNm);
		params.put("CSTGRP", cstGrpList);
		LOG.info("Executing GET_PC_INFO_QUERY : " + searchQuery.toString() + "\n");
		LOG.info("Contract Name in DAO------------->"+cntrtNm);
		return getNamedJdbcTemplate().query(searchQuery.toString(),params, new PcInfoMapper());
	}
	
	/**
	 * @return PLMCFCRPRSRptData objects.
	 */
	private static final class PcInfoMapper implements ParameterizedRowMapper<PLMCFCRPRSRptData> {
		public PLMCFCRPRSRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCFCRPRSRptData data = new PLMCFCRPRSRptData();
			data.setHwPrdctNm(PLMUtils.checkNullVal(rs.getString("HW_PRDT")));
			data.setPrdtConfigNm(PLMUtils.checkNullVal(rs.getString("PRDT_CFGN")));
			data.setPrdtConfigDesc(PLMUtils.checkNullVal(rs.getString("PRDT_CFGN_DESC")));
			data.setIsOption(PLMUtils.checkNullVal(rs.getString("IS_OPTION")));
			return data;
		}
	}
	/**
	 * This method is used to get CF Data Report
	 * 
	 * @param contractList
	 * @param pcList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMCFCRPRSRptData> getCFReportData(String contract1,String contract2,String contract3,String selPcName1,String selPcName2,String selPcName3) throws PLMCommonException{
		LOG.info("Entering getCFReportData");
		List<PLMCFCRPRSRptData> tempDataList= new ArrayList<PLMCFCRPRSRptData>();
		List<PLMCFCRPRSRptData> tempCFDataList= new ArrayList<PLMCFCRPRSRptData>();
		List<PLMCFCRPRSRptData> tempCODataList= new ArrayList<PLMCFCRPRSRptData>();
		List<PLMCFCRPRSRptData> finalCFDataList= new ArrayList<PLMCFCRPRSRptData>();
		StringBuffer sqlQuery = new StringBuffer();
		boolean whereFlag=false;
		
		sqlQuery.append(PLMSearchQueries.GET_CF_COMPARE_QUERY_ONE);
		if(!PLMUtils.isEmpty(contract1) && !PLMUtils.isEmpty(selPcName1)){
			sqlQuery.append(" WHERE (CONTRACT ='"+contract1+"' AND PC_NAME = '"+selPcName1+"')");
			whereFlag=true;
		}
		
		if(!PLMUtils.isEmpty(contract2) && !PLMUtils.isEmpty(selPcName2)){
			if(whereFlag){
				sqlQuery.append(" OR ");
			}else{
				sqlQuery.append(" WHERE ");
				whereFlag=true;
			}
			sqlQuery.append("(CONTRACT ='"+contract2+"' AND PC_NAME = '"+selPcName2+"')");
		}
		
		if(!PLMUtils.isEmpty(contract3) && !PLMUtils.isEmpty(selPcName3)){
			if(whereFlag){
				sqlQuery.append(" OR ");
			}else{
				sqlQuery.append(" WHERE ");
				whereFlag=true;
			}
			sqlQuery.append("(CONTRACT ='"+contract3+"' AND PC_NAME = '"+selPcName3+"')");
		}

		sqlQuery.append(PLMSearchQueries.GET_CF_COMPARE_QUERY_TWO);
		
		LOG.info("Executing CF Compare Query : " + sqlQuery + "\n");
		tempDataList= getSimpleJdbcTemplate().query(sqlQuery.toString(), new CFReportMapper());
		if(!PLMUtils.isEmptyList(tempDataList)){
			LOG.info("Before comparing Total Record Count of cf Data List : " + tempDataList.size());
			String cfName="";
			String coName="";
			boolean finalAddFlg=false;
			PLMCFCRPRSRptData tempCfData = new PLMCFCRPRSRptData();
			PLMCFCRPRSRptData tempCoData = new PLMCFCRPRSRptData();
			 
			for(int i=0;i<tempDataList.size();i++){
				
				if(!cfName.equalsIgnoreCase(tempDataList.get(i).getCfName())){ 
					if(!PLMUtils.isEmpty(cfName)){
						tempCFDataList.add(tempCfData);
						finalAddFlg=true;
					 }
					tempCfData = new PLMCFCRPRSRptData();
					tempCfData.setLevel("1");
					tempCfData.setCfoId(tempDataList.get(i).getCfId());
					tempCfData.setCfoName(tempDataList.get(i).getCfName());
					tempCfData.setDisplayNm(tempDataList.get(i).getCfDisplayNm());
					tempCfData.setFeatureType(tempDataList.get(i).getCfType());

					if(selPcName1.equalsIgnoreCase(tempDataList.get(i).getPcName())){
						tempCfData.setPc1("X");
					}else if(selPcName2.equalsIgnoreCase(tempDataList.get(i).getPcName())){
						tempCfData.setPc2("X");
					}else if(selPcName3.equalsIgnoreCase(tempDataList.get(i).getPcName())){
						tempCfData.setPc3("X");
					}
					finalAddFlg=false;
			     }else{
			    	 if(selPcName1.equalsIgnoreCase(tempDataList.get(i).getPcName())){
			    		 tempCfData.setPc1("X");
						}else if(selPcName2.equalsIgnoreCase(tempDataList.get(i).getPcName())){
						 tempCfData.setPc2("X");
						}else if(selPcName3.equalsIgnoreCase(tempDataList.get(i).getPcName())){
						 tempCfData.setPc3("X");
						}
			    	     finalAddFlg=false;
			     }
				
				if(!coName.equalsIgnoreCase(tempDataList.get(i).getCoName())){ 
					if(!PLMUtils.isEmpty(coName)){
						tempCODataList.add(tempCoData);
						finalAddFlg=true;
					 }
					 tempCoData = new PLMCFCRPRSRptData();
					 tempCoData.setLevel("2");
					 tempCoData.setCfoId(tempDataList.get(i).getCoId());
					 tempCoData.setCfName(tempDataList.get(i).getCfName());
					 tempCoData.setCfoName(tempDataList.get(i).getCoName());
					 tempCoData.setDisplayNm(tempDataList.get(i).getCoDisplayNm());
					 tempCoData.setFeatureType(tempDataList.get(i).getCoType());
					if(selPcName1.equalsIgnoreCase(tempDataList.get(i).getPcName())){
						tempCoData.setPc1("X");
					}else if(selPcName2.equalsIgnoreCase(tempDataList.get(i).getPcName())){
						tempCoData.setPc2("X");
					}else if(selPcName3.equalsIgnoreCase(tempDataList.get(i).getPcName())){
						tempCoData.setPc3("X");
					}
					finalAddFlg=false;
			     }else{
			    	 if(selPcName1.equalsIgnoreCase(tempDataList.get(i).getPcName())){
			    		  tempCoData.setPc1("X");
						}else if(selPcName2.equalsIgnoreCase(tempDataList.get(i).getPcName())){
						  tempCoData.setPc2("X");
						}else if(selPcName3.equalsIgnoreCase(tempDataList.get(i).getPcName())){
						  tempCoData.setPc3("X");
						}
			    	 	finalAddFlg=false;
			     }
				
				cfName=tempDataList.get(i).getCfName();
				coName=tempDataList.get(i).getCoName();
			 }
			
			
			if(!finalAddFlg && !PLMUtils.isEmptyList(tempDataList)){
				tempCFDataList.add(tempCfData);
				tempCODataList.add(tempCoData);
			}
			
			PLMCFCRPRSRptData finalData= new PLMCFCRPRSRptData();
			for (int i = 0; i < tempCFDataList.size(); i++) {
				
				finalData= new PLMCFCRPRSRptData();
				
				finalData.setLevel(tempCFDataList.get(i).getLevel());
				finalData.setCfoId(tempCFDataList.get(i).getCfoId());
				finalData.setCfoName(tempCFDataList.get(i).getCfoName());
				finalData.setDisplayNm(tempCFDataList.get(i).getDisplayNm());
				finalData.setFeatureType(tempCFDataList.get(i).getFeatureType());
				finalData.setPc1(tempCFDataList.get(i).getPc1());
				finalData.setPc2(tempCFDataList.get(i).getPc2());
				finalData.setPc3(tempCFDataList.get(i).getPc3());
				finalCFDataList.add(finalData);
				
				for(int j=0; j<tempCODataList.size(); j++){
					
				  if(tempCFDataList.get(i).getCfoName().equalsIgnoreCase(tempCODataList.get(j).getCfName())){
					
					finalData= new PLMCFCRPRSRptData();
					
					finalData.setLevel(tempCODataList.get(j).getLevel());
					finalData.setCfoId(tempCODataList.get(j).getCfoId());
					finalData.setCfoName(tempCODataList.get(j).getCfoName());
					finalData.setDisplayNm(tempCODataList.get(j).getDisplayNm());
					finalData.setFeatureType(tempCODataList.get(j).getFeatureType());
					finalData.setPc1(tempCODataList.get(j).getPc1());
					finalData.setPc2(tempCODataList.get(j).getPc2());
					finalData.setPc3(tempCODataList.get(j).getPc3());
					finalCFDataList.add(finalData);
				  }
				
			 }
		}
			LOG.info("After comparing Total Record Count of cf Data List : " + finalCFDataList.size());
		}
		LOG.info("Exiting getCFReportData");
		return finalCFDataList;
	}
	/**
	 * @return PLMCFCRPRSRptData objects.
	 */
	private static final class CFReportMapper implements ParameterizedRowMapper<PLMCFCRPRSRptData> {
		public PLMCFCRPRSRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCFCRPRSRptData data = new PLMCFCRPRSRptData();
			data.setPcName(PLMUtils.checkNullVal(rs.getString("PC_NAME")));
			data.setCfDisplayNm(PLMUtils.checkNullVal(rs.getString("CF_DISP_NM")));
			data.setCfId(PLMUtils.checkNullVal(rs.getString("CF_ID")));
			data.setCfName(PLMUtils.checkNullVal(rs.getString("CF_NAME")));
			data.setCfType(PLMUtils.checkNullVal(rs.getString("CF_TYPE")));
			data.setCoDisplayNm(PLMUtils.checkNullVal(rs.getString("CO_DISP_NM")));
			data.setCoId(PLMUtils.checkNullVal(rs.getString("CO_ID")));
			data.setCoName(PLMUtils.checkNullVal(rs.getString("CO_NAME")));
			data.setCoType(PLMUtils.checkNullVal(rs.getString("CO_TYPE")));
			return data;
		}
	}
	
	
	/**
	 * This method is used to get CR Data Report
	 * 
	 * @param contractList
	 * @param contract1,contract2,contract3
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMCFCRPRSRptData> getCRReportData(List<String> contractList,String contract1,String contract2,String contract3,
					List<String> selCstGrpList1,List<String> selCstGrpList2,List<String> selCstGrpList3) throws PLMCommonException{
				LOG.info("Entering getCRReportData");
				List<PLMCFCRPRSRptData> tempCRDataList1= new ArrayList<PLMCFCRPRSRptData>();
				List<PLMCFCRPRSRptData> tempCRDataList2= new ArrayList<PLMCFCRPRSRptData>();
				List<PLMCFCRPRSRptData> tempCRDataList3= new ArrayList<PLMCFCRPRSRptData>();
				Set<String> mliSet= new HashSet<String>();
				
				List<PLMCFCRPRSRptData> finalcrDataList= new ArrayList<PLMCFCRPRSRptData>();
				
				StringBuffer sqlQuery1 = new StringBuffer();
				StringBuffer sqlQuery2 = new StringBuffer();
				StringBuffer sqlQuery3 = new StringBuffer();
				
				if(!PLMUtils.isEmpty(contract1) && !PLMUtils.isEmptyList(selCstGrpList1)){
					sqlQuery1.append(PLMSearchQueries.GET_CR_COMPARE_QUERY_ONE);
					sqlQuery1.append(" WHERE PRDT.FROM_NAME='"+contract1+"'");
					sqlQuery1.append(PLMSearchQueries.GET_CR_COMPARE_QUERY_TWO);
					sqlQuery1.append(" WHERE R_CONTRACT.FROM_NAME='"+contract1+"' AND (PC_FTR.GE_COST_GRP IN("+PLMUtils.setListForQuery(selCstGrpList1)+") OR PC_FTR.PC_NAME IS NULL) ");
					sqlQuery1.append(PLMSearchQueries.GET_CR_COMPARE_QUERY_THREE);
					LOG.info("Executing CR Compare Query for  "+contract1+"  >>>>" + sqlQuery1 + "\n");
					tempCRDataList1= getSimpleJdbcTemplate().query(sqlQuery1.toString(), new CRReportMapper());
					LOG.info("List for  "+contract1+"  >>>> "+tempCRDataList1.size());
				}
				
				
				if(!PLMUtils.isEmpty(contract2) && !PLMUtils.isEmptyList(selCstGrpList2)){
					sqlQuery2.append(PLMSearchQueries.GET_CR_COMPARE_QUERY_ONE);
					sqlQuery2.append(" WHERE PRDT.FROM_NAME='"+contract2+"'");
					sqlQuery2.append(PLMSearchQueries.GET_CR_COMPARE_QUERY_TWO);
					sqlQuery2.append(" WHERE R_CONTRACT.FROM_NAME='"+contract2+"' AND (PC_FTR.GE_COST_GRP IN("+PLMUtils.setListForQuery(selCstGrpList2)+") OR PC_FTR.PC_NAME IS NULL) ");
					sqlQuery2.append(PLMSearchQueries.GET_CR_COMPARE_QUERY_THREE);
					LOG.info("Executing CR Compare Query for  "+contract2+"  >>>>" + sqlQuery2 + "\n");
					tempCRDataList2= getSimpleJdbcTemplate().query(sqlQuery2.toString(), new CRReportMapper());
					LOG.info("List for  "+contract2+"  >>>> "+tempCRDataList2.size());
				}
			
				if(!PLMUtils.isEmpty(contract3) && !PLMUtils.isEmptyList(selCstGrpList3)){
					sqlQuery3.append(PLMSearchQueries.GET_CR_COMPARE_QUERY_ONE);
					sqlQuery3.append(" WHERE PRDT.FROM_NAME='"+contract3+"'");
					sqlQuery3.append(PLMSearchQueries.GET_CR_COMPARE_QUERY_TWO);
					sqlQuery3.append(" WHERE R_CONTRACT.FROM_NAME='"+contract3+"' AND (PC_FTR.GE_COST_GRP IN("+PLMUtils.setListForQuery(selCstGrpList3)+") OR PC_FTR.PC_NAME IS NULL) ");
					sqlQuery3.append(PLMSearchQueries.GET_CR_COMPARE_QUERY_THREE);
					LOG.info("Executing CR Compare Query for  "+contract3+"  >>>>" + sqlQuery3 + "\n");
					tempCRDataList3= getSimpleJdbcTemplate().query(sqlQuery3.toString(), new CRReportMapper());
					LOG.info("List for  "+contract3+"  >>>> "+tempCRDataList3.size());
				}
				
				for(int i=0;i<tempCRDataList1.size()||i<tempCRDataList2.size()||i<tempCRDataList3.size();i++){
					
					 if (i < tempCRDataList1.size()) {
						 mliSet.add(tempCRDataList1.get(i).getMli());
					 }
					
					 if (i < tempCRDataList2.size()) {
						 mliSet.add(tempCRDataList2.get(i).getMli());
					 }
		 
					 if (i < tempCRDataList3.size()) {
						 mliSet.add(tempCRDataList3.get(i).getMli());
					 }
					
				}
				
				PLMCFCRPRSRptData tempData = new PLMCFCRPRSRptData();
				List<PLMCFCRPRSRptData> crDataList1= new ArrayList<PLMCFCRPRSRptData>();
				List<PLMCFCRPRSRptData> crDataList2= new ArrayList<PLMCFCRPRSRptData>();
				List<PLMCFCRPRSRptData> crDataList3= new ArrayList<PLMCFCRPRSRptData>();
				HashMap <String,List<PLMCFCRPRSRptData>> cntrtListMap = new HashMap<String,List<PLMCFCRPRSRptData>>();
				TreeMap <String, HashMap<String,List<PLMCFCRPRSRptData>>> cntrtTreeMap = new TreeMap<String, HashMap<String,List<PLMCFCRPRSRptData>>>();
				
				for (String mli : mliSet) {
				   
				   for(int c1=0;c1<tempCRDataList1.size();c1++){
					   if(mli.equalsIgnoreCase(tempCRDataList1.get(c1).getMli())){
						   tempData = new PLMCFCRPRSRptData();
							tempData.setMli(tempCRDataList1.get(c1).getMli());
							tempData.setLfName1(tempCRDataList1.get(c1).getLfName());
							tempData.setLfRev1(tempCRDataList1.get(c1).getLfRev());
							tempData.setLfDesc1(tempCRDataList1.get(c1).getLfDesc());
							tempData.setCrId1(tempCRDataList1.get(c1).getCrId());
							tempData.setCrNm1(tempCRDataList1.get(c1).getCrNm());
							tempData.setCrTitile1(tempCRDataList1.get(c1).getCrTitile());
							tempData.setCoId1(tempCRDataList1.get(c1).getCoId());
							tempData.setCoNm1(tempCRDataList1.get(c1).getCoNm());
							tempData.setPcName1(tempCRDataList1.get(c1).getCrPcName());
							tempData.setCostGrp1(tempCRDataList1.get(c1).getCostGrp());
							crDataList1.add(tempData);
					   }
				   }
				   
				   for(int c2=0;c2<tempCRDataList2.size();c2++){
					   if(mli.equalsIgnoreCase(tempCRDataList2.get(c2).getMli())){
						   tempData = new PLMCFCRPRSRptData();
							tempData.setMli(tempCRDataList2.get(c2).getMli());
							tempData.setLfName2(tempCRDataList2.get(c2).getLfName());
							tempData.setLfRev2(tempCRDataList2.get(c2).getLfRev());
							tempData.setLfDesc2(tempCRDataList2.get(c2).getLfDesc());
							tempData.setCrId2(tempCRDataList2.get(c2).getCrId());
							tempData.setCrNm2(tempCRDataList2.get(c2).getCrNm());
							tempData.setCrTitile2(tempCRDataList2.get(c2).getCrTitile());
							tempData.setCoId2(tempCRDataList2.get(c2).getCoId());
							tempData.setCoNm2(tempCRDataList2.get(c2).getCoNm());
							tempData.setPcName2(tempCRDataList2.get(c2).getCrPcName());
							tempData.setCostGrp2(tempCRDataList2.get(c2).getCostGrp());
							crDataList2.add(tempData);
					   }
				   }
				   
				   for(int c3=0;c3<tempCRDataList3.size();c3++){
					   if(mli.equalsIgnoreCase(tempCRDataList3.get(c3).getMli())){
						   tempData = new PLMCFCRPRSRptData();
							tempData.setMli(tempCRDataList3.get(c3).getMli());
							tempData.setLfName3(tempCRDataList3.get(c3).getLfName());
							tempData.setLfRev3(tempCRDataList3.get(c3).getLfRev());
							tempData.setLfDesc3(tempCRDataList3.get(c3).getLfDesc());
							tempData.setCrId3(tempCRDataList3.get(c3).getCrId());
							tempData.setCrNm3(tempCRDataList3.get(c3).getCrNm());
							tempData.setCrTitile3(tempCRDataList3.get(c3).getCrTitile());
							tempData.setCoId3(tempCRDataList3.get(c3).getCoId());
							tempData.setCoNm3(tempCRDataList3.get(c3).getCoNm());
							tempData.setPcName3(tempCRDataList3.get(c3).getCrPcName());
							tempData.setCostGrp3(tempCRDataList3.get(c3).getCostGrp());
							crDataList3.add(tempData);
					   }
				   }
				   
					cntrtListMap.put("C1", crDataList1);
					cntrtListMap.put("C2", crDataList2);
					cntrtListMap.put("C3", crDataList3);
					cntrtTreeMap.put(mli, cntrtListMap);
					
					crDataList1= new ArrayList<PLMCFCRPRSRptData>();
					crDataList2= new ArrayList<PLMCFCRPRSRptData>();
					crDataList3= new ArrayList<PLMCFCRPRSRptData>();
					cntrtListMap = new HashMap<String,List<PLMCFCRPRSRptData>>();
			    }
			
					PLMCFCRPRSRptData finalData= new PLMCFCRPRSRptData();
					cntrtListMap = new HashMap<String,List<PLMCFCRPRSRptData>>();
					crDataList1= new ArrayList<PLMCFCRPRSRptData>();
					crDataList2= new ArrayList<PLMCFCRPRSRptData>();
					crDataList3= new ArrayList<PLMCFCRPRSRptData>();
				
					
					for (Map.Entry<String, HashMap<String,List<PLMCFCRPRSRptData>>> treekey : cntrtTreeMap.entrySet()) {					
				   		
						cntrtListMap= treekey.getValue(); // Set of Maps for each MLI
						
						crDataList1 = cntrtListMap.get("C1"); // list of PLMCFCRPRSRptData object for Contract 1
						crDataList2 = cntrtListMap.get("C2"); // list of PLMCFCRPRSRptData object for Contract 2 
						crDataList3 = cntrtListMap.get("C3"); // list of PLMCFCRPRSRptData object for Contract 3
						 			
						for (int i = 0; i < crDataList1.size() || i < crDataList2.size() || i < crDataList3.size(); i++) {
							 
							 finalData= new PLMCFCRPRSRptData();
							 if("ZZZZ".equalsIgnoreCase(treekey.getKey())){
								 finalData.setMli("");
							 }else{
							  finalData.setMli(treekey.getKey());
							 }
							 if (i < crDataList1.size()) {
								 finalData.setLfName1(crDataList1.get(i).getLfName1());
								 finalData.setLfRev1(crDataList1.get(i).getLfRev1());
								 finalData.setLfDesc1(crDataList1.get(i).getLfDesc1());
								 finalData.setCrId1(crDataList1.get(i).getCrId1());
								 finalData.setCrNm1(crDataList1.get(i).getCrNm1());
								 finalData.setCrTitile1(crDataList1.get(i).getCrTitile1());
								 finalData.setCoId1(crDataList1.get(i).getCoId1());
								 finalData.setCoNm1(crDataList1.get(i).getCoNm1());
								 finalData.setPcName1(crDataList1.get(i).getPcName1());
								 finalData.setCostGrp1(crDataList1.get(i).getCostGrp1());
							 }
							 if (i < crDataList2.size()) {
								 finalData.setLfName2(crDataList2.get(i).getLfName2());
								 finalData.setLfRev2(crDataList2.get(i).getLfRev2());
								 finalData.setLfDesc2(crDataList2.get(i).getLfDesc2());
								 finalData.setCrId2(crDataList2.get(i).getCrId2());
								 finalData.setCrNm2(crDataList2.get(i).getCrNm2());
								 finalData.setCrTitile2(crDataList2.get(i).getCrTitile2());
								 finalData.setCoId2(crDataList2.get(i).getCoId2());
								 finalData.setCoNm2(crDataList2.get(i).getCoNm2());
								 finalData.setPcName2(crDataList2.get(i).getPcName2());
								 finalData.setCostGrp2(crDataList2.get(i).getCostGrp2());
							 }
							 if (i < crDataList3.size()) {
								 finalData.setLfName3(crDataList3.get(i).getLfName3());
								 finalData.setLfRev3(crDataList3.get(i).getLfRev3());
								 finalData.setLfDesc3(crDataList3.get(i).getLfDesc3());
								 finalData.setCrId3(crDataList3.get(i).getCrId3());
								 finalData.setCrNm3(crDataList3.get(i).getCrNm3());
								 finalData.setCrTitile3(crDataList3.get(i).getCrTitile3());
								 finalData.setCoId3(crDataList3.get(i).getCoId3());
								 finalData.setCoNm3(crDataList3.get(i).getCoNm3());
								 finalData.setPcName3(crDataList3.get(i).getPcName3());
								 finalData.setCostGrp3(crDataList3.get(i).getCostGrp3());
							 }
							 
							 finalcrDataList.add(finalData);
						 }
					}
					
					
				 LOG.info("List of finalcrDataList Report>> "+finalcrDataList.size());
				
				  LOG.info("Exiting getCRReportData");
				return finalcrDataList;
			}
			
			/**
			 * @return PLMCFCRPRSRptData objects.
			 */
			private static final class CRReportMapper implements ParameterizedRowMapper<PLMCFCRPRSRptData> {
				public PLMCFCRPRSRptData mapRow(ResultSet rs, int rowcount)
						throws SQLException {
					PLMCFCRPRSRptData data = new PLMCFCRPRSRptData();
					data.setLfName(PLMUtils.checkNullVal(rs.getString("LF_NAME")));
					data.setLfRev(PLMUtils.checkNullVal(rs.getString("LF_REV")));
					data.setLfDesc(PLMUtils.checkNullVal(rs.getString("LF_DESC")));
					data.setContract(PLMUtils.checkNullVal(rs.getString("CONTRACT")));
					data.setMli(PLMUtils.checkNullVal(rs.getString("MLI")));
					data.setCrId(PLMUtils.checkNullVal(rs.getString("CR_ID")));
					data.setCrNm(PLMUtils.checkNullVal(rs.getString("CR_NAME")));
					data.setCrTitile(PLMUtils.checkNullVal(rs.getString("CR_TITLE")));
					data.setCoId(PLMUtils.checkNullVal(rs.getString("CO_ID")));
					data.setCoNm(PLMUtils.checkNullVal(rs.getString("CO_NAME")));
					data.setCostGrp(PLMUtils.checkNullVal(rs.getString("GE_COST_GRP")));
					data.setCrPcName(PLMUtils.checkNullVal(rs.getString("PC_NAME")));
					return data;
				}
			}
	/**
	 * This method is used to get CR Data Report
	 * 
	 * @param contractList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMCFCRPRSRptData> getPRSData(List<String> contractList,String contract1,String contract2,String contract3) throws PLMCommonException{
		LOG.info("Entering getPRSData");
		List<PLMCFCRPRSRptData> prsDataList= new ArrayList<PLMCFCRPRSRptData>();
		List<PLMCFCRPRSRptData> finalPrsDataList= new ArrayList<PLMCFCRPRSRptData>();
	    List<PLMCFCRPRSRptData> prsDataList1= new ArrayList<PLMCFCRPRSRptData>();
	    List<PLMCFCRPRSRptData> prsDataList2= new ArrayList<PLMCFCRPRSRptData>();
	    List<PLMCFCRPRSRptData> prsDataList3= new ArrayList<PLMCFCRPRSRptData>();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("CNTRLIST", contractList);
		LOG.info("Executing PRS Compare Query : " + PLMSearchQueries.GET_PRS_COMPARE_QUERY + "\n");
		prsDataList= getNamedJdbcTemplate().query(PLMSearchQueries.GET_PRS_COMPARE_QUERY,params, new PRSReportMapper());
		if(!PLMUtils.isEmptyList(prsDataList)){
			PLMCFCRPRSRptData temData = new PLMCFCRPRSRptData();
		     
		   	for(int i=0;i<prsDataList.size();i++){
				temData = new PLMCFCRPRSRptData();
				if(contract1.equalsIgnoreCase(prsDataList.get(i).getPrsContract())){
					temData.setPrsId1(prsDataList.get(i).getPrsId());
					temData.setPrsName1(prsDataList.get(i).getPrsName());
					prsDataList1.add(temData);
				}
				if(contract2.equalsIgnoreCase(prsDataList.get(i).getPrsContract())){
					temData.setPrsId2(prsDataList.get(i).getPrsId());
					temData.setPrsName2(prsDataList.get(i).getPrsName());
					prsDataList2.add(temData);
				}
				if(contract3.equalsIgnoreCase(prsDataList.get(i).getPrsContract())){
					temData.setPrsId3(prsDataList.get(i).getPrsId());
					temData.setPrsName3(prsDataList.get(i).getPrsName());
					prsDataList3.add(temData);
				}
			}
		   	
		   	PLMCFCRPRSRptData finalData= new PLMCFCRPRSRptData();
		   	
		   	for (int i = 0; i < prsDataList1.size() || i < prsDataList2.size() || i < prsDataList3.size(); i++) {
				 
				 finalData= new PLMCFCRPRSRptData();
				
				 if (i < prsDataList1.size()) {
					 finalData.setPrsId1(prsDataList1.get(i).getPrsId1());
					 finalData.setPrsName1(prsDataList1.get(i).getPrsName1());
				 }
				 if (i < prsDataList2.size()) {
					 finalData.setPrsId2(prsDataList2.get(i).getPrsId2());
					 finalData.setPrsName2(prsDataList2.get(i).getPrsName2());
				 }
				 if (i < prsDataList3.size()) {
					 finalData.setPrsId3(prsDataList3.get(i).getPrsId3());
					 finalData.setPrsName3(prsDataList3.get(i).getPrsName3());
				 }
				 
				 finalPrsDataList.add(finalData);
			 }
		   	
			LOG.info("List of PRS Report>> "+finalPrsDataList.size());
		  }

		LOG.info("Exiting getPRSData");
		return finalPrsDataList;
	}
	/**
	 * @return PLMCFCRPRSRptData objects.
	 */
	private static final class PRSReportMapper implements ParameterizedRowMapper<PLMCFCRPRSRptData> {
		public PLMCFCRPRSRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCFCRPRSRptData data = new PLMCFCRPRSRptData();
			data.setPrsContract(PLMUtils.checkNullVal(rs.getString("CONTRACT")));
			data.setPrsId(PLMUtils.checkNullVal(rs.getString("PRS_ID")));
			data.setPrsName(PLMUtils.checkNullVal(rs.getString("PRS_NAME")));
			return data;
		}
	}
}
