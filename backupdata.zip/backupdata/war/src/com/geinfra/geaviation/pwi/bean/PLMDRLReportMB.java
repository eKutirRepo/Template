/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMInterfaceAttrMB.java
 * @Creation date: 29-Aug-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;



import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.data.PLMDRLReportData;
import com.geinfra.geaviation.pwi.service.PLMDRLReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;



public class PLMDRLReportMB {
	
	/**
	 * Holds the Loggger
	 */
	private static final Logger LOG = Logger.getLogger(PLMDRLReportMB.class);
	
	/**
	 * Holds the drlReportService
	 */
	private PLMDRLReportServiceIfc drlReportService = null;

	/**
	 * Holds the alertMessage
	 */
	private String alertMessage="";
	/**
	 * Holds the drlReportData
	 */
	
	private PLMDRLReportData plmDRLReportData = new PLMDRLReportData();
	/**
	 * Holds the resultList
	 */
	private List<PLMDRLReportData> resultList = null;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = 100;

	/**
	 * Holds the resultListCountMsg
	 */
	private String resultListCountMsg = "";
	/**
	 * Holds the searchCriteriaMsg
	 */
	private String searchCriteriaMsg = "";
	/**
	 * Holds the reportDate
	 */
	private String reportDate = "";
	/**
	 * Holds the resultListCount
	 */
	private int resultListCount = 0;
	/**
	 * Holds the commonMB
	 */
	private PLMCommonMB commonMB;


	/**
	 * This method is used for loadDRLReportSearchPage
	 * 
	 * @return String
	 */
	public String loadDRLReportSearchPage() {
		LOG.info("Entering loadDRLReportSearchPage Method");
		String fwdFlag="";
		try {
			commonMB.insertCannedRptRecordHitInfo("DRL Report");
			resetSearchData();
			alertMessage="";
			plmDRLReportData = new PLMDRLReportData();
			fwdFlag="drlReportSearch";

			} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadGBomReportSearchPage:", exception);
		}
		LOG.info("Exiting loadDRLReportSearchPage Method");
		return fwdFlag;
	}
	


	
	public String resetSearchData() {
		LOG.info("Entering resetSearchData");
		String fwdFlag = "drlReportSearch";
 	 try{
			
 		plmDRLReportData.setEnteredContractNum("");
 		plmDRLReportData.setEnteredDrlName("");
 		plmDRLReportData.setEnteredProjName("");
	
			
		 
		  }catch (Exception exception) {
		  LOG.log(Level.ERROR, "Exception@resetSearchData PLMDRLReportMB:", exception); 
		  
		  }
		  
		  LOG.info("Existing resetSearchData"); 
		return fwdFlag;

	}
	
	public void downloadDRLExcel() throws PLMCommonException {
		LOG.info("Entering downloadDRLExcel Method");
		String reportName = "DRLReport";
		String fileName = "DRL Report";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		//Export to Excel for DRL Report
		
		PLMXlsxRptColumn[] critcolumns  = new PLMXlsxRptColumn[] {
                new PLMXlsxRptColumn("enteredDrlName", "DRL Name", FormatType.TEXT),
                new PLMXlsxRptColumn("enteredContractNum", "Contract Number", FormatType.TEXT),
                new PLMXlsxRptColumn("enteredProjName", "Project Name", FormatType.TEXT),
                new PLMXlsxRptColumn("reportDate", "Report Date", FormatType.TEXT)
                };
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					  new PLMXlsxRptColumn("contractName", "Contract Name", FormatType.TEXT),
					  new PLMXlsxRptColumn("prjName", "Project Name", FormatType.TEXT, null, null, 23),
					  new PLMXlsxRptColumn("prjDesc", "Project Description", FormatType.TEXT, null, null, 18),
					  new PLMXlsxRptColumn("submittalName", "Submittal Name", FormatType.TEXT, null, null, 20),
					  new PLMXlsxRptColumn("submittalRev", "Submittal Revision", FormatType.TEXT),
					  new PLMXlsxRptColumn("submittalStatus", "Submittal Status", FormatType.TEXT),
					  new PLMXlsxRptColumn("submittalDate", "Submittal Date", FormatType.TEXT),
					  new PLMXlsxRptColumn("concernedEquipt", "Concerned Equipt", FormatType.TEXT),
					  new PLMXlsxRptColumn("concernedEquiptDesc", "Concerned Equipt Description", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("concernedDiscipline", "Concerned Discipline", FormatType.TEXT, null, null, 20),
					  new PLMXlsxRptColumn("docName", "Document Name", FormatType.TEXT),
					  new PLMXlsxRptColumn("docRev", "Document Revision", FormatType.TEXT),
					  new PLMXlsxRptColumn("docType", "Document Type", FormatType.TEXT),
					  new PLMXlsxRptColumn("docCriticalCode", "GE Drawing Critical Code", FormatType.TEXT),
					  new PLMXlsxRptColumn("docTitle", "Document Title", FormatType.TEXT, null, null, 28),
					  new PLMXlsxRptColumn("frenchTitle", "French Document Title", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("pldDocName", "PLD Document Name", FormatType.TEXT),
					  new PLMXlsxRptColumn("pldDocRev", "PLD Document Revision", FormatType.TEXT),
					  new PLMXlsxRptColumn("customerCode", "Customer Code", FormatType.TEXT),
					  new PLMXlsxRptColumn("customerCodeRev", "Customer Code Revision", FormatType.TEXT),
					  new PLMXlsxRptColumn("distributionCode", "Distribution Code", FormatType.TEXT, null, null, 18),
					  new PLMXlsxRptColumn("clusterNm", "Cluster", FormatType.TEXT, null, null, 21),
					  new PLMXlsxRptColumn("clusterRev", "Cluster Revision", FormatType.TEXT),
					  new PLMXlsxRptColumn("clusterState", "Cluster State", FormatType.TEXT),
					  new PLMXlsxRptColumn("wbseName", "Prod/PartWBSE Name", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("wbseRev", "Prod/PartWBSE Revision", FormatType.TEXT),
					  new PLMXlsxRptColumn("dstbLstName", "Distribution List Name", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("routeState", "Submittal Route State", FormatType.TEXT),
					  new PLMXlsxRptColumn("routeStartDate", "Submittal Route Starting Date", FormatType.TEXT)
			};
			
			excelUtil.export(resultList, reportColumns, fileName, fileName, true, critcolumns, plmDRLReportData);	
		
			LOG.info("Exiting downloadDRLExcel Method");
	}
	
	
	public void downloadDRLCSV() throws PLMCommonException {
		LOG.info("Entering downloadDRLCSV Method");
		String reportName = "DRLReport";
		String fileName = "DRL Report";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);

		// Export to CSV for DRL Report
			PLMCsvRptColumn[] reportColumns =
					new PLMCsvRptColumn[] {new PLMCsvRptColumn("contractName", "Contract Name", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("prjName", "Project Name", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("prjDesc", "Project Description", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("submittalName", "Submittal Name", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("submittalRev", "Submittal Revision", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("submittalStatus", "Submittal Status", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("submittalDate", "Submittal Date", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("concernedEquipt", "Concerned Equipt", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("concernedEquiptDesc", "Concerned Equipt Description", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("concernedDiscipline", "Concerned Discipline", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("docName", "Document Name", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("docRev", "Document Revision", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("docType", "Document Type", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("docCriticalCode", "GE Drawing Critical Code", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("docTitle", "Document Title", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("frenchTitle", "French Document Title", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("pldDocName", "PLD Document Name", FormatTypeCsv.TEXT),
					 					  new PLMCsvRptColumn("pldDocRev", "PLD Document Revision", FormatTypeCsv.TEXT),
					 					  new PLMCsvRptColumn("customerCode", "Customer Code", FormatTypeCsv.TEXT),
					 					  new PLMCsvRptColumn("customerCodeRev", "Customer Code Revision", FormatTypeCsv.TEXT),
					 					  new PLMCsvRptColumn("distributionCode", "Distribution Code", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("clusterNm", "Cluster", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("clusterRev", "Cluster Revision", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("clusterState", "Cluster State", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("wbseName", "Prod/PartWBSE Name", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("wbseRev", "Prod/PartWBSE Revision", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("dstbLstName", "Distribution List Name", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("routeState", "Submittal Route State", FormatTypeCsv.TEXT),
										  new PLMCsvRptColumn("routeStartDate", "Submittal Route Starting Date", FormatTypeCsv.TEXT)};
			
			csvUtil.exportCsv(resultList, reportColumns, fileName, dateFormat, false, null, null, ",");
			
	  LOG.info("Exiting downloadDRLCSV Method");
	}
	
	public String getDRLReportResult(){
		LOG.info("Entering getDRLReportResult");
		String fwdFlag = "drlReportResult";
		SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
				"MM/dd/yyyy");
 	 try{
 		Date currentDate =new Date();
 		reportDate=SIMPLE_DATE_FORMAT.format(currentDate);
 		plmDRLReportData.setReportDate(reportDate);
 		LOG.info("Report Date is:"+plmDRLReportData.getReportDate());
		LOG.info("Selected DRL Name:"+plmDRLReportData.getEnteredDrlName());
		LOG.info("Selected Contract Num:"+plmDRLReportData.getEnteredContractNum());
		LOG.info("Selected Proj Name:"+plmDRLReportData.getEnteredProjName());
		if(PLMUtils.isEmpty(plmDRLReportData.getEnteredDrlName())){
		
			LOG.info("DRL Name Not Entered.........");
			alertMessage=PLMConstants.ENTER_DRL_NAME;
			return "drlReportSearch";
		}
		else{
			LOG.info("DRL Name Entered.........");
			resultList=new ArrayList<PLMDRLReportData>();
			resultList=drlReportService.getDRLReportResult(plmDRLReportData);
			resultListCount =resultList.size();
			LOG.info("Fetched DRL Report resultList of Size"+resultList.size());
			
			Collections.sort(resultList, new SortDRLResult());
			LOG.info("DRL Report resultList Size after SORTING"+resultList.size());
			
			StringBuffer searchCriteriaMsg_temp = new StringBuffer();
			searchCriteriaMsg_temp.append("DRL Name: "+plmDRLReportData.getEnteredDrlName()+"  ");
			if(!plmDRLReportData.getEnteredContractNum().equalsIgnoreCase("")){
				searchCriteriaMsg_temp.append("   Contract Number: "+plmDRLReportData.getEnteredContractNum()+"  ");
			}
			if(!plmDRLReportData.getEnteredProjName().equalsIgnoreCase("")){
				searchCriteriaMsg_temp.append("   Project Name: "+plmDRLReportData.getEnteredProjName());
			}
			searchCriteriaMsg=searchCriteriaMsg_temp.toString();
			resultListCountMsg="Total Results Count : "+ resultList.size();
			LOG.info("searchCriteriaMsg==="+searchCriteriaMsg);
			LOG.info("resultListCountMsg==="+resultListCountMsg);
			
			if(resultList.size()==0){
				LOG.info("No records found. Redirecting to Invalid Page");
				fwdFlag="invalidDrlReport";
			}
		}	
	  }catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getDRLReportResult: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"drlReportSearch","DRL Report Search");
	  }
		  LOG.info("Existing getDRLReportResult"); 
		  return fwdFlag;
	}
	
		public void recordsPerPageListner(ActionEvent event) {
		LOG.info("Entering recordsPerPageListner method");
		LOG.info("Action listner called.....--------------------------->"
				+ recordCounts);
		if (recordCounts == 15) {
			LOG.info("15");
			recordCounts = 15;
		} else if (recordCounts == 30) {
			LOG.info("30");
			recordCounts = 30;
		} else if (recordCounts == 50) {
			LOG.info("50");
			recordCounts = 50;
		} else if (recordCounts == 100) {
			LOG.info("100");
			recordCounts = 100;
		} else if (recordCounts == 200) {
			LOG.info("200");
			recordCounts = 200;
		}

		else if (recordCounts == resultListCount) {
			LOG.info("All");
			recordCounts = resultListCount;
		}
		LOG.info("final value.....--------------------------->" + recordCounts);
	}
		
		/**
		 * 
		 * class to sort List of object of type PLMDRLReportData.
		 * 
		 */
		private static class SortDRLResult implements Comparator<PLMDRLReportData>,
				Serializable {
			/**
			 * long serialVersionUID
			 */
			private static final long serialVersionUID = 1L;

			/**
			 * used for comparision..
			 */
			public int compare(PLMDRLReportData aList,
					PLMDRLReportData bList) {
				String aStr;
				String bStr;
				int result=0;
				aStr = aList.getSubmittalName();
				bStr = bList.getSubmittalName();
				if(aStr != null && bStr != null){
				result = aStr.compareTo(bStr);
				}
				return result;
				
			}
		}
		

	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return LOG;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the drlReportService
	 */
	public PLMDRLReportServiceIfc getDrlReportService() {
		return drlReportService;
	}
	/**
	 * @param drlReportService the drlReportService to set
	 */
	public void setDrlReportService(PLMDRLReportServiceIfc drlReportService) {
		this.drlReportService = drlReportService;
	}

	/**
	 * @return the plmDRLReportData
	 */
	public PLMDRLReportData getPlmDRLReportData() {
		return plmDRLReportData;
	}
	/**
	 * @param plmDRLReportData the plmDRLReportData to set
	 */
	public void setPlmDRLReportData(PLMDRLReportData plmDRLReportData) {
		this.plmDRLReportData = plmDRLReportData;
	}
	/**
	 * @return the resultList
	 */
	public List<PLMDRLReportData> getResultList() {
		return resultList;
	}

	/**
	 * @param resultList the resultList to set
	 */
	public void setResultList(List<PLMDRLReportData> resultList) {
		this.resultList = resultList;
	}

	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @param recordCounts the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}

	/**
	 * @return the searchCriteriaMsg
	 */
	public String getSearchCriteriaMsg() {
		return searchCriteriaMsg;
	}

	/**
	 * @param searchCriteriaMsg the searchCriteriaMsg to set
	 */
	public void setSearchCriteriaMsg(String searchCriteriaMsg) {
		this.searchCriteriaMsg = searchCriteriaMsg;
	}

	/**
	 * @return the resultListCountMsg
	 */
	public String getResultListCountMsg() {
		return resultListCountMsg;
	}

	/**
	 * @param resultListCountMsg the resultListCountMsg to set
	 */
	public void setResultListCountMsg(String resultListCountMsg) {
		this.resultListCountMsg = resultListCountMsg;
	}

	/**
	 * @return the reportDate
	 */
	public String getReportDate() {
		return reportDate;
	}
	/**
	 * @param reportDate the reportDate to set
	 */
	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}
	/**
	 * @return the resultListCount
	 */
	public int getResultListCount() {
		return resultListCount;
	}

	/**
	 * @param resultListCount the resultListCount to set
	 */
	public void setResultListCount(int resultListCount) {
		this.resultListCount = resultListCount;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}
	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	
}
