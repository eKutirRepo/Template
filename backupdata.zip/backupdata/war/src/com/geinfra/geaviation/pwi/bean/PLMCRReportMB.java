/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCRReportMB.java
 * @Creation date: 12-Aug-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.StringTokenizer;

import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.data.PLMCRReportData;
import com.geinfra.geaviation.pwi.service.PLMCRReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

public class PLMCRReportMB {
	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMCRReportMB.class);
	/**
	 * Holds PLMCRReportServiceIfc
	 */
	private PLMCRReportServiceIfc plmCRReportService = null;

	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;

	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;

	/**
	 * Holds the PLMCRReportData
	 */
	private PLMCRReportData plmCRReportData = null;

	/**
	 * Holds the stateList
	 */
	private List<SelectItem> stateList = new ArrayList<SelectItem>();

	/**
	 * Holds the productList
	 */
	private List<SelectItem> productList = new ArrayList<SelectItem>();
	/**
	 * Holds the crReportList
	 */
	private List<PLMCRReportData> crReportList = new ArrayList<PLMCRReportData>();
	/**
	 * Holds the rowCrReport
	 */
	private int rowCrReport = 100;

	/**
	 * Holds the crRecCount
	 */
	private int crRecCount;

	/**
	 * Holds the totalcrReportMsg
	 */
	private String totalcrReportMsg;

	/**
	 * Holds the selectedCRs
	 */
	private String selectedCRs;

	/**
	 * Holds the crDetailsReportList
	 */
	private List<PLMCRReportData> crDetailsReportList = new ArrayList<PLMCRReportData>();
	/**
	 * Holds the crDetailRecCount
	 */
	private int crDetailRecCount;

	/**
	 * Holds the totalcrDetailReportMsg
	 */
	private String totalcrDetailReportMsg;
	/**
	 * Holds the rowCrDetailReport
	 */
	private int rowCrDetailReport = 100;

	/**
	 * This methods is used to reset CR Data
	 * 
	 */
	public void restCRData() {
		plmCRReportData = new PLMCRReportData();
		crReportList = new ArrayList<PLMCRReportData>();
		totalcrReportMsg = "";
		crRecCount = 0;
		crDetailRecCount = 0;
		rowCrReport = 100;
		crDetailsReportList = new ArrayList<PLMCRReportData>();
		totalcrDetailReportMsg = "";
		rowCrDetailReport = 100;
		selectedCRs = "";
		alertMessage = "";
	}

	/**
	 * This methods is used to load CR Report Search Page
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String loadCRReportHomePage() {
		LOG.info("Entering loadCRReportHomePage() method");
		String fwdFlag = "crReportSearch";
		try {
			commonMB.insertCannedRptRecordHitInfo("CR Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			plmCRReportData = new PLMCRReportData();
			stateList = new ArrayList<SelectItem>();
			productList = new ArrayList<SelectItem>();
			crReportList = new ArrayList<PLMCRReportData>();
			totalcrReportMsg = "";
			crRecCount = 0;
			crDetailRecCount = 0;
			rowCrReport = 100;
			crDetailsReportList = new ArrayList<PLMCRReportData>();
			totalcrDetailReportMsg = "";
			rowCrDetailReport = 100;
			selectedCRs = "";
			alertMessage = "";
			stateList = plmCRReportService.getCRStates();
			productList.add(new SelectItem("Gas,Gas - Options", "Gas"));
			productList.add(new SelectItem("Steam,Steam - Options", "Steam"));
			productList.add(new SelectItem("Gen,Gen - Options", "Gen"));
			productList.add(new SelectItem("PLANT", "PLANT"));
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadWhereUsedReportHome: ",
					exception);
		}
		LOG.info("Exiting loadCRReportHomePage() method");

		return fwdFlag;
	}

	/**
	 * This method is used for validateCRreportData
	 * 
	 * @return String
	 */
	public String validateCRreportData() throws PLMCommonException {
		alertMessage = "";
		if (PLMUtils.isEmpty(plmCRReportData.getCrName())
				&& PLMUtils.isEmptyList(plmCRReportData.getStateList())
				&& PLMUtils.isEmptyDate(plmCRReportData.getOriginFromDate())
				&& PLMUtils.isEmptyDate(plmCRReportData.getOriginToDate())
				&& PLMUtils.isEmptyList(plmCRReportData.getProductList())
				&& PLMUtils.isEmpty(plmCRReportData.getCrOriginator())
				&& PLMUtils.isEmpty(plmCRReportData.getCrOwner())
				&& PLMUtils.isEmpty(plmCRReportData.getCrTitleNm())
				&& PLMUtils.isEmpty(plmCRReportData.getCrDescNm())
				&& PLMUtils.isEmpty(plmCRReportData.getPlmCntrIps())
				&& PLMUtils.isEmpty(plmCRReportData.getSatisfyImpact())
				&& !plmCRReportData.isRouteTaskFlg()
				&& !plmCRReportData.isAllOpen()) {
			alertMessage = PLMConstants.SEARCH_CRITERIA;
			LOG.info("Please enter any criteria and click on search");
		} else if ((!PLMUtils.isEmptyDate(plmCRReportData.getOriginFromDate()) && PLMUtils
				.isEmptyDate(plmCRReportData.getOriginToDate()))
				|| (PLMUtils.isEmptyDate(plmCRReportData.getOriginFromDate()) && !PLMUtils
						.isEmptyDate(plmCRReportData.getOriginToDate()))) {
			alertMessage = PLMConstants.CR_ORIGINATE_DATE;
		}

		else if (PLMUtils.checkForFromAndToDate(
				plmCRReportData.getOriginFromDate(),
				plmCRReportData.getOriginToDate())) {
			alertMessage = PLMConstants.WHERE_USED_DATE;
		}

		else if (PLMUtils.checkSplCharsProjSumry(plmCRReportData.getCrName())
				&& PLMUtils.checkSplCharsProjSumry(plmCRReportData
						.getCrOriginator())
				&& PLMUtils
						.checkSplCharsProjSumry(plmCRReportData.getCrOwner())
				&& PLMUtils.checkSplCharsProjSumry(plmCRReportData
						.getCrTitleNm())
				&& PLMUtils.checkSplCharsProjSumry(plmCRReportData
						.getCrDescNm())
				&& PLMUtils.checkSplCharsProjSumry(plmCRReportData
						.getPlmCntrIps())
				&& PLMUtils.checkSplCharsProjSumry(plmCRReportData
						.getSatisfyImpact())) {
			alertMessage = PLMConstants.WHERE_USED_SPL_CRITERIA;
		}

		return alertMessage;
	}

	/**
	 * This method is used for generateCRreportData
	 * 
	 * @return String
	 */
	public String generateCRreportData() {
		String fwdFlag = "";
		LOG.info("Entering generateCRreportData() method");
		try {
			alertMessage = "";
			totalcrReportMsg = "";
			crRecCount = 0;
			crDetailRecCount = 0;
			crReportList = new ArrayList<PLMCRReportData>();
			alertMessage = validateCRreportData();

			if (PLMUtils.isEmpty(alertMessage)) {

				if (plmCRReportData.isAllOpen()) {
					if (!PLMUtils.isEmptyList(stateList)) {
						List<String> allOpenCrStateList = new ArrayList<String>();
						for (int i = 0; i < stateList.size(); i++) {
							String stateCrValue = stateList.get(i).getLabel();
							if (!stateCrValue.equals("Release")
									&& !stateCrValue.equals("Review")
									&& !stateCrValue.equals("Obsolete")) {
								allOpenCrStateList.add(stateCrValue);
							}
						}
						plmCRReportData.setStateList(allOpenCrStateList);
					}
				}

				if ((PLMUtils.isEmpty(plmCRReportData.getCrName())
						&& PLMUtils.isEmptyList(plmCRReportData.getStateList())
						&& PLMUtils.isEmptyDate(plmCRReportData
								.getOriginFromDate())
						&& PLMUtils.isEmptyDate(plmCRReportData
								.getOriginToDate())
						&& PLMUtils.isEmpty(plmCRReportData.getCrOriginator())
						&& PLMUtils.isEmpty(plmCRReportData.getCrOwner())
						&& PLMUtils.isEmpty(plmCRReportData.getCrTitleNm())
						&& PLMUtils.isEmpty(plmCRReportData.getCrDescNm())
						&& PLMUtils.isEmpty(plmCRReportData.getPlmCntrIps())
						&& !plmCRReportData.isRouteTaskFlg()
						&& !plmCRReportData.isAllOpen() && PLMUtils
							.isEmptyList(plmCRReportData.getProductList()))
						&& (!PLMUtils.isEmpty(plmCRReportData
								.getSatisfyImpact()))) {

					fwdFlag = "invalidCRReport";
				} else {
					crReportList = plmCRReportService
							.getCRReportData(plmCRReportData);

					if (crReportList.size() > 0) {
						crRecCount = crReportList.size();
						totalcrReportMsg = "Total Records of CR Report "
								+ crRecCount;
						fwdFlag = "crReportDetails";
					} else {
						crRecCount = 0;
						fwdFlag = "invalidCRReport";
					}
				}
			} else {
				fwdFlag = "crReportSearch";
			}

		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@generateCRreportData: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "crReportSearch", "CR Report Search");
		}
		LOG.info("Existing generateCRreportData() method");
		return fwdFlag;

	}

	/**
	 * This method is used for changeCRreportListner
	 * 
	 * @param event
	 */
	public void changeCRreportListner(ActionEvent event) {
		LOG.info("Action listner called.....--------------------------->"
				+ rowCrReport);
		if (rowCrReport == 100) {
			LOG.info("100");
			rowCrReport = 100;
		} else if (rowCrReport == 200) {
			LOG.info("200");
			rowCrReport = 200;
		} else if (rowCrReport == 500) {
			LOG.info("500");
			rowCrReport = 500;
		} else if (rowCrReport == 1000) {
			LOG.info("1000");
			rowCrReport = 1000;
		} else if (rowCrReport == 2000) {
			LOG.info("2000");
			rowCrReport = 2000;
		} else if (rowCrReport == 5000) {
			LOG.info("5000");
			rowCrReport = 5000;
		} else if (rowCrReport == crRecCount) {
			LOG.info("All");
			rowCrReport = crRecCount;
		}
		LOG.info("final value.....--------------------------->" + rowCrReport);
	}

	/**
	 * This method is used for getCRDetailedResult
	 * 
	 * @return String
	 */
	public String getCRDetailedResult() {
		String fwdFlag = "";
		try {
			List<String> crValuesList = new ArrayList<String>();

			if (selectedCRs != null) {
				StringTokenizer strTok = new StringTokenizer(selectedCRs, ",");
				while (strTok.hasMoreTokens()) {
					crValuesList.add(strTok.nextToken());
				}
			}
			crDetailsReportList = plmCRReportService.getCRReportDetailsData(
					crValuesList, plmCRReportData);
			if (crDetailsReportList.size() > 0) {
				crDetailRecCount = crDetailsReportList.size();

				totalcrDetailReportMsg = "Total CRs Detail Results Count : "
						+ crDetailRecCount;
				LOG.info("CR Details totalRecCount::::::::::::::::::"
						+ crDetailRecCount);
				fwdFlag = "crReportResults";
			} else {
				fwdFlag = "invalidCRDetails";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getCRDetailedResult: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "crReportDetails", "CR Details Report Search");
		}
		return fwdFlag;
	}

	/**
	 * This method is used for chgCRDetailrptListner
	 * 
	 * @param event
	 */
	public void chgCRDetailrptListner(ActionEvent event) {
		LOG.info("Action listner called.....--------------------------->"
				+ rowCrDetailReport);
		if (rowCrDetailReport == 100) {
			LOG.info("100");
			rowCrDetailReport = 100;
		} else if (rowCrDetailReport == 200) {
			LOG.info("200");
			rowCrDetailReport = 200;
		} else if (rowCrDetailReport == 500) {
			LOG.info("500");
			rowCrDetailReport = 500;
		} else if (rowCrDetailReport == 1000) {
			LOG.info("1000");
			rowCrDetailReport = 1000;
		} else if (rowCrDetailReport == 2000) {
			LOG.info("2000");
			rowCrDetailReport = 2000;
		} else if (rowCrDetailReport == 5000) {
			LOG.info("5000");
			rowCrDetailReport = 5000;
		} else if (rowCrDetailReport == crDetailRecCount) {
			LOG.info("All");
			rowCrDetailReport = crDetailRecCount;
		}
		LOG.info("final value.....--------------------------->"
				+ rowCrDetailReport);
	}

	/**
	 * @return the plmCRReportService
	 */
	public PLMCRReportServiceIfc getPlmCRReportService() {
		return plmCRReportService;
	}

	/**
	 * @param plmCRReportService
	 *            the plmCRReportService to set
	 */
	public void setPlmCRReportService(PLMCRReportServiceIfc plmCRReportService) {
		this.plmCRReportService = plmCRReportService;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB
	 *            the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the plmCRReportData
	 */
	public PLMCRReportData getPlmCRReportData() {
		return plmCRReportData;
	}

	/**
	 * @param plmCRReportData
	 *            the plmCRReportData to set
	 */
	public void setPlmCRReportData(PLMCRReportData plmCRReportData) {
		this.plmCRReportData = plmCRReportData;
	}

	/**
	 * @return the stateList
	 */
	public List<SelectItem> getStateList() {
		return stateList;
	}

	/**
	 * @param stateList
	 *            the stateList to set
	 */
	public void setStateList(List<SelectItem> stateList) {
		this.stateList = stateList;
	}

	/**
	 * @return the productList
	 */
	public List<SelectItem> getProductList() {
		return productList;
	}

	/**
	 * @param productList
	 *            the productList to set
	 */
	public void setProductList(List<SelectItem> productList) {
		this.productList = productList;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage
	 *            the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the crReportList
	 */
	public List<PLMCRReportData> getCrReportList() {
		return crReportList;
	}

	/**
	 * @param crReportList
	 *            the crReportList to set
	 */
	public void setCrReportList(List<PLMCRReportData> crReportList) {
		this.crReportList = crReportList;
	}

	/**
	 * @return the rowCrReport
	 */
	public int getRowCrReport() {
		return rowCrReport;
	}

	/**
	 * @param rowCrReport
	 *            the rowCrReport to set
	 */
	public void setRowCrReport(int rowCrReport) {
		this.rowCrReport = rowCrReport;
	}

	/**
	 * @return the crRecCount
	 */
	public int getCrRecCount() {
		return crRecCount;
	}

	/**
	 * @param crRecCount
	 *            the crRecCount to set
	 */
	public void setCrRecCount(int crRecCount) {
		this.crRecCount = crRecCount;
	}

	/**
	 * @return the totalcrReportMsg
	 */
	public String getTotalcrReportMsg() {
		return totalcrReportMsg;
	}

	/**
	 * @param totalcrReportMsg
	 *            the totalcrReportMsg to set
	 */
	public void setTotalcrReportMsg(String totalcrReportMsg) {
		this.totalcrReportMsg = totalcrReportMsg;
	}

	/**
	 * @return the selectedCRs
	 */
	public String getSelectedCRs() {
		return selectedCRs;
	}

	/**
	 * @param selectedCRs
	 *            the selectedCRs to set
	 */
	public void setSelectedCRs(String selectedCRs) {
		this.selectedCRs = selectedCRs;
	}

	/**
	 * @return the crDetailsReportList
	 */
	public List<PLMCRReportData> getCrDetailsReportList() {
		return crDetailsReportList;
	}

	/**
	 * @param crDetailsReportList
	 *            the crDetailsReportList to set
	 */
	public void setCrDetailsReportList(List<PLMCRReportData> crDetailsReportList) {
		this.crDetailsReportList = crDetailsReportList;
	}

	/**
	 * @return the crDetailRecCount
	 */
	public int getCrDetailRecCount() {
		return crDetailRecCount;
	}

	/**
	 * @param crDetailRecCount
	 *            the crDetailRecCount to set
	 */
	public void setCrDetailRecCount(int crDetailRecCount) {
		this.crDetailRecCount = crDetailRecCount;
	}

	/**
	 * @return the totalcrDetailReportMsg
	 */
	public String getTotalcrDetailReportMsg() {
		return totalcrDetailReportMsg;
	}

	/**
	 * @param totalcrDetailReportMsg
	 *            the totalcrDetailReportMsg to set
	 */
	public void setTotalcrDetailReportMsg(String totalcrDetailReportMsg) {
		this.totalcrDetailReportMsg = totalcrDetailReportMsg;
	}

	/**
	 * @return the rowCrDetailReport
	 */
	public int getRowCrDetailReport() {
		return rowCrDetailReport;
	}

	/**
	 * @param rowCrDetailReport
	 *            the rowCrDetailReport to set
	 */
	public void setRowCrDetailReport(int rowCrDetailReport) {
		this.rowCrDetailReport = rowCrDetailReport;
	}

	public void downloadExcel() throws PLMCommonException {
		LOG.info("Entering downloadCR Report Excel Method");
		String reportName = "CR Report";
		String fileName = "CR Report";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();

		// Export to Excel for Where used SBOM Report
		PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
				new PLMXlsxRptColumn("coNameCst", "Name", FormatType.TEXT,
						null, null, 18),
				new PLMXlsxRptColumn("contract", "Contract", FormatType.TEXT),
				new PLMXlsxRptColumn("costGrp", "Cost Group", FormatType.TEXT),
				new PLMXlsxRptColumn("coState", "CO State", FormatType.TEXT),
				new PLMXlsxRptColumn("crNumber", "Customer Requirement",
						FormatType.TEXT),
				new PLMXlsxRptColumn("crDesc",
						"Customer Requirement Description", FormatType.TEXT,
						null, null, 25),
				new PLMXlsxRptColumn("crState", "CR State", FormatType.TEXT),
				new PLMXlsxRptColumn("lfName", "Logical Feature",
						FormatType.TEXT),
				new PLMXlsxRptColumn("lfRev", "Logical Feature Revision",
						FormatType.TEXT),
				new PLMXlsxRptColumn("lfType", "Logical Feature Type",
						FormatType.TEXT),
				new PLMXlsxRptColumn("tfMarketNm", "TF Marketing Name",
						FormatType.TEXT),
				new PLMXlsxRptColumn("tfDesc", "TF Description",
						FormatType.TEXT),
				new PLMXlsxRptColumn("cycleTimeDwgs",
						"Cycle Time Drawing (Wks)", FormatType.TEXT),
				new PLMXlsxRptColumn("engHours", "Engineering Hours",
						FormatType.TEXT, null, null, 25),
				new PLMXlsxRptColumn("drafHours", "Drafting Hours",
						FormatType.TEXT),
				new PLMXlsxRptColumn("materialLeadTm",
						"Engineering Effort(per Site)", FormatType.TEXT),
				new PLMXlsxRptColumn("shipDirectCst",
						"Material Ship Direct Cost", FormatType.TEXT),
				new PLMXlsxRptColumn("rawInProcessCst", "Raw In Process Cost",
						FormatType.TEXT),
				new PLMXlsxRptColumn("appliedDirectLbr",
						"Applied Direct Labor", FormatType.TEXT),
				new PLMXlsxRptColumn("geShopWrkLab", "Ship Work and Lab",
						FormatType.TEXT),
				new PLMXlsxRptColumn("partName", "Part Number", FormatType.TEXT),
				new PLMXlsxRptColumn("geTransportCst",
						"Transport Cost (Per Site)", FormatType.TEXT, null,
						null, 25),
				new PLMXlsxRptColumn("geFieldInstalCst",
						"Feild Installation Cost (Per Site)", FormatType.TEXT),
				new PLMXlsxRptColumn("unitMeasure", "Unit of Measure",
						FormatType.TEXT),
				new PLMXlsxRptColumn("productConf", "Product Configuration",
						FormatType.TEXT),
				new PLMXlsxRptColumn("geMfgLbrHours", "Mfg Labor Hours",
						FormatType.TEXT),
				new PLMXlsxRptColumn("enginerDisposition",
						"Engineering Disposition", FormatType.TEXT)

		};
		excelUtil.export(crDetailsReportList, reportColumns, fileName,
				fileName, false, null, null);
		LOG.info("Exiting downloadCR Report Method");
	}

	public void createDownloadCSV() throws PLMCommonException {
		LOG.info("Entering downloadWhereUsedRCMUExcel Method");
		String reportName = "CR Report";
		String fileName = "CR Report";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy",
				Locale.ENGLISH);

		// Export to CSV for Where used Requirement Report
		PLMCsvRptColumn[] reportColumns = new PLMCsvRptColumn[] {
						new PLMCsvRptColumn("coNameCst", "Name", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("contract", "Contract", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("costGrp", "Cost Group", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("coState", "CO State", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("crNumber", "Customer Requirement",
								FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("crDesc",
								"Customer Requirement Description", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("crState", "CR State", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("lfName", "Logical Feature",
								FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("lfRev", "Logical Feature Revision",
								FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("lfType", "Logical Feature Type",
								FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("tfMarketNm", "TF Marketing Name",
								FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("tfDesc", "TF Description",
								FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("cycleTimeDwgs",
								"Cycle Time Drawing (Wks)", FormatTypeCsv.DOUBLE),
						new PLMCsvRptColumn("engHours", "Engineering Hours",
								FormatTypeCsv.DOUBLE),
						new PLMCsvRptColumn("drafHours", "Drafting Hours",
								FormatTypeCsv.DOUBLE),
						new PLMCsvRptColumn("materialLeadTm",
								"Engineering Effort(per Site)", FormatTypeCsv.DOUBLE),
						new PLMCsvRptColumn("shipDirectCst",
								"Material Ship Direct Cost", FormatTypeCsv.DOUBLE),
						new PLMCsvRptColumn("rawInProcessCst", "Raw In Process Cost",
								FormatTypeCsv.DOUBLE),
						new PLMCsvRptColumn("appliedDirectLbr",
								"Applied Direct Labor", FormatTypeCsv.DOUBLE),
						new PLMCsvRptColumn("geShopWrkLab", "Ship Work and Lab",
								FormatTypeCsv.DOUBLE),
						new PLMCsvRptColumn("partName", "Part Number", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("geTransportCst",
								"Transport Cost (Per Site)", FormatTypeCsv.DOUBLE),
						new PLMCsvRptColumn("geFieldInstalCst",
								"Feild Installation Cost (Per Site)", FormatTypeCsv.DOUBLE),
						new PLMCsvRptColumn("unitMeasure", "Unit of Measure",
								FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("productConf", "Product Configuration",
								FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("geMfgLbrHours", "Mfg Labor Hours",
								FormatTypeCsv.DOUBLE),
						new PLMCsvRptColumn("enginerDisposition",
								"Engineering Disposition", FormatTypeCsv.TEXT) };

		csvUtil.exportCsv(crDetailsReportList, reportColumns, fileName, dateFormat,
				false, null, null, ",");

		LOG.info("Exiting downloadWhereUsedRCMUExcel Method");
	}

	public void downloadCRDetailExcel() throws PLMCommonException {
		LOG.info("Entering downloadCR Details Report Excel Method");
		String reportName = "CR Report Details";
		String fileName = "CR Report Details";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		PLMXlsxRptColumn[] reportColumns = null;
		// Export to Excel for Where used SBOM Report

		if (!plmCRReportData.isRouteTaskFlg()) {

			reportColumns = new PLMXlsxRptColumn[] {
					new PLMXlsxRptColumn("crName", "CR Name", FormatType.TEXT,
							null, null, 18),
					new PLMXlsxRptColumn("contract", "Contract",
							FormatType.TEXT),
					new PLMXlsxRptColumn("contractDesc",
							"Contract Description", FormatType.TEXT, null, null, 30),
					new PLMXlsxRptColumn("crLvlStr", "CR Level / Status",
							FormatType.TEXT),
					new PLMXlsxRptColumn("crState", "CR State", FormatType.TEXT),
					new PLMXlsxRptColumn("costGrp", "Cost Group",
							FormatType.TEXT, null, null, 25),
					new PLMXlsxRptColumn("ownerNM", "Owner Name",
							FormatType.TEXT),
					new PLMXlsxRptColumn("crTitleCst", "CR Title",
							FormatType.TEXT),
					new PLMXlsxRptColumn("crDesc", "CR Description",
							FormatType.TEXT, null, null, 100),
					new PLMXlsxRptColumn("crOrigDt", "CR Originated Date",
							FormatType.TEXT),
					new PLMXlsxRptColumn("originSSO", "Orig SSO",
							FormatType.TEXT),
					new PLMXlsxRptColumn("originNM", "Orig Name",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ownerSSO", "Owner SSO",
							FormatType.TEXT)

			};
		} else {
			reportColumns = new PLMXlsxRptColumn[] {
					new PLMXlsxRptColumn("crName", "CR Name", FormatType.TEXT,
							null, null, 18),
					new PLMXlsxRptColumn("contract", "Contract",
							FormatType.TEXT),
					new PLMXlsxRptColumn("contractDesc",
							"Contract Description", FormatType.TEXT),
					new PLMXlsxRptColumn("crLvlStr", "CR Level / Status",
							FormatType.TEXT),
					new PLMXlsxRptColumn("crState", "CR State", FormatType.TEXT),
					new PLMXlsxRptColumn("costGrp", "Cost Group",
							FormatType.TEXT, null, null, 25),
					new PLMXlsxRptColumn("ownerNM", "Owner Name",
							FormatType.TEXT),
					new PLMXlsxRptColumn("crTitleCst", "CR Title",
							FormatType.TEXT),
					new PLMXlsxRptColumn("crDesc", "CR Description",
							FormatType.TEXT),
					new PLMXlsxRptColumn("crOrigDt", "CR Originated Date",
							FormatType.TEXT),
					new PLMXlsxRptColumn("originSSO", "Orig SSO",
							FormatType.TEXT),
					new PLMXlsxRptColumn("originNM", "Orig Name",
							FormatType.TEXT),
					new PLMXlsxRptColumn("ownerSSO", "Owner SSO",
							FormatType.TEXT),
					new PLMXlsxRptColumn("routeName", "Route Name",
							FormatType.TEXT, null, null, 25),
					new PLMXlsxRptColumn("routeOwnSSO", "Route Owner SSO",
							FormatType.TEXT),
					new PLMXlsxRptColumn("routeOrgDt", "Route Originated Date",
							FormatType.TEXT),
					new PLMXlsxRptColumn("routeState", "Route State",
							FormatType.TEXT),
					new PLMXlsxRptColumn("taskName", "Task Name",
							FormatType.TEXT),
					new PLMXlsxRptColumn("taskState", "Task State",
							FormatType.TEXT),
					new PLMXlsxRptColumn("taskOwnerSSO", "Task Owner SSO",
							FormatType.TEXT),
					new PLMXlsxRptColumn("taskAprovStatus",
							"Task Approval Status", FormatType.TEXT, null,
							null, 25),
					new PLMXlsxRptColumn("taskDueDt", "Task Due Date",
							FormatType.TEXT),
					new PLMXlsxRptColumn("taskOrgDt", "Task Originated Date",
							FormatType.TEXT),
					new PLMXlsxRptColumn("taskCompleteDt",
							"Task Complete Date", FormatType.TEXT),
					new PLMXlsxRptColumn("dispositionCmts",
							"Disposition Comments", FormatType.TEXT) };
		}
		excelUtil.export(crReportList, reportColumns, fileName, fileName,
				false, null, null);
		LOG.info("Exiting downloadCR Details Report Method");
	}

	public void createDownloadDetailCSV() throws PLMCommonException {
		LOG.info("Entering downloadWhereUsedRCMUExcel Method");
		String reportName = "CR Report Details";
		String fileName = "CR Report Details";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		PLMCsvRptColumn[] reportColumns = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy",
				Locale.ENGLISH);

		// Export to CSV for Where used Requirement Report

		if (!plmCRReportData.isRouteTaskFlg()) {
			reportColumns = new PLMCsvRptColumn[] {
					new PLMCsvRptColumn("crName", "CR Name", FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("contract", "Contract",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("contractDesc", "Contract Description",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("crLvlStr", "CR Level / Status",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("crState", "CR State",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("costGrp", "Cost Group",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ownerNM", "Owner Name",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("crTitleCst", "CR Title",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("crDesc", "CR Description",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("crOrigDt", "CR Originated Date",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("originSSO", "Orig SSO",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("originNM", "Orig Name",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ownerSSO", "Owner SSO",
							FormatTypeCsv.TEXT) };

		} else {

			reportColumns = new PLMCsvRptColumn[] {
					new PLMCsvRptColumn("crName", "CR Name", FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("contract", "Contract",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("contractDesc", "Contract Description",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("crLvlStr", "CR Level / Status",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("crState", "CR State",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("costGrp", "Cost Group",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ownerNM", "Owner Name",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("crTitleCst", "CR Title",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("crDesc", "CR Description",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("crOrigDt", "CR Originated Date",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("originSSO", "Orig SSO",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("originNM", "Orig Name",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("ownerSSO", "Owner SSO",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("routeName", "Route Name",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("routeOwnSSO", "Route Owner SSO",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("routeOrgDt", "Route Originated Date",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("routeState", "Route State",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("taskName", "Task Name",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("taskState", "Task State",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("taskOwnerSSO", "Task Owner SSO",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("taskAprovStatus",
							"Task Approval Status", FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("taskDueDt", "Task Due Date",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("taskOrgDt", "Task Originated Date",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("taskCompleteDt", "Task Complete Date",
							FormatTypeCsv.TEXT),
					new PLMCsvRptColumn("dispositionCmts",
							"Disposition Comments", FormatTypeCsv.TEXT) };
		}

		csvUtil.exportCsv(crReportList, reportColumns, fileName, dateFormat,
				false, null, null, ",");

		LOG.info("Exiting downloadWhereUsedRCMUExcel Method");
	}

}
