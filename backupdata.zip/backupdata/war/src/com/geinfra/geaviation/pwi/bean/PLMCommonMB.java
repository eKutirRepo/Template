/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCommonMB.java
 * @Creation date: 31-Oct-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.data.PLMAdminData;
import com.geinfra.geaviation.pwi.service.PLMAdminServiceIfc;
import com.geinfra.geaviation.pwi.service.PLMCommonReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMCommonMB {
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMCommonMB.class);
	/**
	 * Holds the login User dateStampPlm
	 */
	private String dateStampPlm;
	/**
	 * Holds the login User dateStampLegacy
	 */
	private String dateStampLegacy;
	/**
	 * Holds the login User dateStampEtl
	 */
	private String dateStampEtl;
	/**
	 * Holds the login User plmCommonReportService
	 */
	private PLMCommonReportServiceIfc plmCommonReportService = null;
	
	/**
	 * Holds the Exception currentPage
	 */
	private String currentPage;
	/**
	 * Holds the login User errorMessage
	 */
	private String errorMessage;
	/**
	 * Holds the login User errorPageBack
	 */
	private String errorPageBack;
	
	/**
	 * Service Handler for PLMAdminServiceIfc
	 */
	public PLMAdminServiceIfc adminServiceIfc;
	
	/**
	 * List of PLMAdmindata.
	 */
	private List<PLMAdminData> listOfReports = new ArrayList<PLMAdminData>();

	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the User dateStampCOPICS
	 */
	private String dateStampCOPICS;

	/*
	 * 
	 */
	public void getLegacyDateStamp() throws PLMCommonException {
		try {
			if(dateStampLegacy == null){
				String dateLegacy = plmCommonReportService.getLegacyDateStamp();
				dateStampLegacy = "Last Legacy Data Refresh as of : " + (dateLegacy!=null?dateLegacy:"");
			}
			LOG.info("Legacy Date Stamp : " + dateStampLegacy);
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Error in getting the Legacy Date Stamp : " + ex.getMessage());
			throw ex;
		}
	}
	
	/**
	 * This method is used for Destroy the Session
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	
	public void getPLMDateStamp(String tablename) throws PLMCommonException {
		try {
			dateStampPlm = "Last PLM Data Refresh as of : " + plmCommonReportService.getPLMDateStamp(tablename);
			LOG.info("PLM Date Stamp : " + dateStampPlm);
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Error in getting the PLM Date Stamp : " + ex.getMessage());
			throw ex;
		}
	}
	

	public void getETLDateStamp() { //throws PLMCommonException {
		String tempDate = null;
		try {
			tempDate = plmCommonReportService.getETLRunDateStamp();
			LOG.info("Original Max Date------ : " + tempDate);
			char txt =':';
			tempDate = tempDate.substring(0, tempDate.lastIndexOf(txt));
			LOG.info("Original Max Date with out seconds--- : " + TimeZone.getTimeZone(tempDate));
			dateFormatTimeZone(tempDate);
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Error in getting the PLM Date Stamp : " + ex.getMessage());
			//throw ex;
		}

	}
	
	/**
	 * @param reportName
	 */
	public void insertCannedRptRecordHitInfo(String reportName) throws PLMCommonException {
		int count = 0;
		try {
			String sso = UserInfoPortalUtil.getInstance().getUserSSO();
			count=plmCommonReportService.insertCannedRptRecordHitInfo(reportName, sso);
			LOG.info("CommonMB class insertCannedRptRecordHitInfo method and record insert count"+count);
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Error insertCannedRptRecordHitInfo : " + ex.getMessage());
		} catch (Exception ex) {
			LOG.log(Level.ERROR, "Error insertCannedRptRecordHitInfo : " + ex.getMessage());
		}

	}
	
	public void dateFormatTimeZone(String dateStampEtl1) {
		String tempString = null;
		try {
		SimpleDateFormat parseFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
		Date date = parseFormat.parse(dateStampEtl1);
		TimeZone zone = TimeZone.getTimeZone("America/New_York");
		boolean flag = zone.inDaylightTime(date);
		String zoneName = zone.getDisplayName(true, 1, Locale.US);
		LOG.info("zoneName>> "+zoneName);
		if(flag){
			zoneName = "EDT";
		}else {
			zoneName = "EST";
		}
		tempString = dateStampEtl1 +" "+zoneName;
		dateStampEtl = "Last PLM-ODS to EEDW Sync: " + tempString;
		LOG.info("ETL Date Stamp------ : " + dateStampEtl);
		}catch(ParseException e){
			LOG.error("error------ : " + e.getMessage());
		}
	}
	/**
	 * This method is used to load Home page
	 * @return String
	 */
	public String loadHomePage() throws PLMCommonException{
		try{
			listOfReports = adminServiceIfc.getListOfReports();
			if (listOfReports != null) {
				totalRecCount = listOfReports.size();
			}
			 getETLDateStamp();
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@loadHomePage: " + exception.getMessage());
				throw exception;
			}
		return "home";
	}
	
	//Start Added methods for getting Last Refresh COPICS Date
	public void getCopicsDateStamp() { //throws PLMCommonException {
		String initialCopicsDate = "";
		try {
			initialCopicsDate = plmCommonReportService.getCOPICSRunDateStamp();
			if(!PLMUtils.isEmpty(initialCopicsDate)){
			 LOG.info("Original Max Date------ : " + initialCopicsDate);
			 //char txt =':';
			 //initialCopicsDate = initialCopicsDate.substring(0, initialCopicsDate.lastIndexOf(txt));
			 LOG.info("Original Max Date with out seconds--- : " + TimeZone.getTimeZone(initialCopicsDate));
			dateFormatTimeZoneCopics(initialCopicsDate);
			}
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Error in getting the PLM Date Stamp : " + ex.getMessage());
			//throw ex;
		}

	}
	
	public void dateFormatTimeZoneCopics(String dateStampCopics) {
		String timeString = null;
		try {
		SimpleDateFormat parseFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
		Date date = parseFormat.parse(dateStampCopics);
		TimeZone zone = TimeZone.getTimeZone("America/New_York");
		boolean flag = zone.inDaylightTime(date);
		String zoneName = zone.getDisplayName(true, 1, Locale.US);
		LOG.info("zoneName>> "+zoneName);
		if(flag){
			zoneName = "EDT";
		}else {
			zoneName = "EST";
		}
		timeString = dateStampCopics +" "+zoneName;
		dateStampCOPICS = "Last COPICS Data Refresh: " + timeString;
		LOG.info("COPICS Date Stamp------ : " + dateStampCOPICS);
		}catch(ParseException e){
			LOG.error("error------ : " + e.getMessage());
		}
	}
	//End Added methods for getting Last Refresh DOPICS Date
	
	/**
	 * This method is used to load back page of scenario
	 * @return String
	 */
	public String loadErrorPageBack() {
		return errorPageBack;
	}
	
	/**
	 * @return the currentPage
	 */
	public String getCurrentPage() {
		return currentPage;
	}

	/**
	 * @param currentPage the currentPage to set
	 */
	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * @return the errorPageBack
	 */
	public String getErrorPageBack() {
		return errorPageBack;
	}

	/**
	 * @param errorPageBack the errorPageBack to set
	 */
	public void setErrorPageBack(String errorPageBack) {
		this.errorPageBack = errorPageBack;
	}

	/**
	 * @return the plmCommonReportService
	 */
	public PLMCommonReportServiceIfc getPlmCommonReportService() {
		return plmCommonReportService;
	}

	/**
	 * @param plmCommonReportService the plmCommonReportService to set
	 */
	public void setPlmCommonReportService(
			PLMCommonReportServiceIfc plmCommonReportService) {
		this.plmCommonReportService = plmCommonReportService;
	}
	
	/**
	 * @return the dateStampPlm
	 */
	public String getDateStampPlm() {
		return dateStampPlm;
	}

	/**
	 * @param dateStampPlm the dateStampPlm to set
	 */
	public void setDateStampPlm(String dateStampPlm) {
		this.dateStampPlm = dateStampPlm;
	}

	/**
	 * @return the dateStampLegacy
	 */
	public String getDateStampLegacy() {
		return dateStampLegacy;
	}

	/**
	 * @param dateStampLegacy the dateStampLegacy to set
	 */
	public void setDateStampLegacy(String dateStampLegacy) {
		this.dateStampLegacy = dateStampLegacy;
	}

	/**
	 * @return the dateStampEtl
	 */
	public String getDateStampEtl() {
		if (PLMUtils.isEmpty(dateStampEtl)) {
			getETLDateStamp();
		}
		return dateStampEtl;
	}

	/**
	 * @param dateStampEtl the dateStampEtl to set
	 */
	public void setDateStampEtl(String dateStampEtl) {
		this.dateStampEtl = dateStampEtl;
	}

	/**
	 * @return the adminServiceIfc
	 */
	public PLMAdminServiceIfc getAdminServiceIfc() {
		return adminServiceIfc;
	}

	/**
	 * @param adminServiceIfc the adminServiceIfc to set
	 */
	public void setAdminServiceIfc(PLMAdminServiceIfc adminServiceIfc) {
		this.adminServiceIfc = adminServiceIfc;
	}

	/**
	 * @return the listOfReports
	 */
	public List<PLMAdminData> getListOfReports() {
		return listOfReports;
	}

	/**
	 * @param listOfReports the listOfReports to set
	 */
	public void setListOfReports(List<PLMAdminData> listOfReports) {
		this.listOfReports = listOfReports;
	}
	
	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/**
	 * @return the dateStampCOPICS
	 */
	public String getDateStampCOPICS() {
		return dateStampCOPICS;
	}

	/**
	 * @param dateStampCOPICS the dateStampCOPICS to set
	 */
	public void setDateStampCOPICS(String dateStampCOPICS) {
		this.dateStampCOPICS = dateStampCOPICS;
	}
	
}
