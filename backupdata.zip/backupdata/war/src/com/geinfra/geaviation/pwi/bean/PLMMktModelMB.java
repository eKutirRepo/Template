/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMMktModelMB.java
 * @Creation date: 12-June-2017
 * @version 1.0
 * @author : Tech Mahindra (PWi Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.data.PLMBoilerReportData;
import com.geinfra.geaviation.pwi.data.PLMMktModelRptData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMMktModelRptServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMMktModelMB {
	
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMCustBomRptMB.class);
	
	/**
	 *  Holds the contractSumrReptService
	 */
	private PLMMktModelRptServiceIfc plmMktModelRptService = null;
	
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds user information
	 */
	private PLMPwiUserData userDetails = null;

	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	/**
	 * Holds the resourceBundle
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the productNamesLst
	 */
	private List<SelectItem> productNamesLst = new ArrayList<SelectItem>();
	/**
	 * Holds the modelsLst
	 */
	private List<SelectItem> modelsLst = new ArrayList<SelectItem>();
	/**
	 * Holds the configOptionsLst
	 */
	private List<SelectItem> configOptionsLst = new ArrayList<SelectItem>();
	/**
	 * Holds the configOptionsLst
	 */
	private List<PLMMktModelRptData> requirementsLst = new ArrayList<PLMMktModelRptData>();
	/**
	 * Holds the configOptionsLst
	 */
	private List<String> selConfigOptions = new ArrayList<String>();
	/**
	 * Holds the selProduct
	 */
	private String selProduct;
	/**
	 * Holds the selModel
	 */
	private String selModel;
	/**
	 * Holds the prodManagementFlag
	 */
	private boolean prodManagementFlag;
	/**
	 * Holds the preliminaryFlag
	 */
	private boolean preliminaryFlag;
	/**
	 * Holds the totalRecordMktModelMsg
	 */
	private String totalRecordMktModelMsg;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_15;
	
	/**
	 * @return
	 */
	public String getProductList() {
		LOG.info("getProductList() Method");
		String fwdFlag = "";
		alertMessage = "";
		productNamesLst = new ArrayList<SelectItem>();
		productNamesLst.add(new SelectItem("Gas"));
		productNamesLst.add(new SelectItem("Steam"));
		productNamesLst.add(new SelectItem("Gen"));
		productNamesLst.add(new SelectItem("PLANT"));
		try {
			 commonMB.insertCannedRptRecordHitInfo("Marketing Model Requirements Report");
			 
			 prodManagementFlag = true;
			 preliminaryFlag = false;
			 modelsLst = new ArrayList<SelectItem>();
			 configOptionsLst = new ArrayList<SelectItem>();
			 requirementsLst = new ArrayList<PLMMktModelRptData>();
			 fwdFlag = "mktModelReqSearch";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getProductList: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Marketing Model Requirements Report");
		} 
		return fwdFlag;
	}
	
	/**
	 * @return
	 */
	public String getModels() {
		LOG.info("Entering getModels method");
		String fwdFlag = "mktModelReqSearch";
		alertMessage = validationForMktModelReqRpt();
		LOG.info("alertMessage >>>>>>>> "+ alertMessage);
		try {
			if(PLMUtils.isEmpty(alertMessage)){
				LOG.info("Selected Product >>>>>> "+ selProduct);
				LOG.info("Selected prodManagementFlag >>>>>> "+ prodManagementFlag);
				LOG.info("Selected preliminaryFlag >>>>>> "+ preliminaryFlag);
				modelsLst = plmMktModelRptService.getModels(selProduct, prodManagementFlag, preliminaryFlag);
				
				if (PLMUtils.isEmptyList(modelsLst)) {
					modelsLst = new ArrayList<SelectItem>();
				} 
				
				LOG.info("modelsLst size >>>>> "+ modelsLst.size());
				
				configOptionsLst = new ArrayList<SelectItem>();
				requirementsLst = new ArrayList<PLMMktModelRptData>();
			}
		
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getModels: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Marketing Model Requirements Report");
		} 
		return fwdFlag;
	}
	
	/**
	 * 
	 * @return String
	 */
	public String validationForMktModelReqRpt(){
		alertMessage = "";
		if (PLMUtils.isEmpty(selProduct) && prodManagementFlag == false && preliminaryFlag == false) {
			alertMessage = alertMessage + PLMConstants.MKT_MODEL_REQ_RPT_ALL_EMPTY_CHK;
		} else if (prodManagementFlag == false && preliminaryFlag == false) {
			alertMessage = alertMessage + PLMConstants.MKT_MODEL_REQ_RPT_STATE_EMPTY_CHK;
		} else if (PLMUtils.isEmpty(selProduct)) {
			alertMessage = alertMessage + PLMConstants.MKT_MODEL_REQ_RPT_PRDT_EMPTY_CHK;
		} 
		return alertMessage;
	}
	
	/**
	 * 
	 * @return String
	 */
	public String validationForModel(){
		alertMessage = "";
		if (PLMUtils.isEmpty(selModel)) {
			alertMessage = alertMessage + PLMConstants.MKT_MODEL_REQ_RPT_MODEL_EMPTY_CHK;
		} 
		return alertMessage;
	}
	
	/**
	 * This method is used for validating contract number
	 * 
	 * @param ctrtNum
	 * @return String
	 */
	public String validationForGenerateRpt(){
		alertMessage = "";
		if (PLMUtils.isEmptyList(selConfigOptions)) {
			alertMessage = alertMessage + PLMConstants.MKT_MODEL_REQ_RPT_MF_EMPTY_CHK;
		} 
		return alertMessage;
	}
	
	/**
	 * @param event
	 * @return
	 */
	public String getConfigOptions(ActionEvent event) {
		String fwdFlag = "mktModelReqSearch";
		alertMessage = validationForModel();
		LOG.info("alertMessage >>>>>>>> "+ alertMessage);
		try {
			if(PLMUtils.isEmpty(alertMessage)){
				
				LOG.info("Selected Model >>>>>> "+ selModel);
				configOptionsLst = plmMktModelRptService.getConfigOptions(selProduct, selModel, prodManagementFlag, preliminaryFlag);
				
				if (PLMUtils.isEmptyList(configOptionsLst)) {
					configOptionsLst = new ArrayList<SelectItem>();
				} 
				
				LOG.info("configOptionsLst size >>>>> "+ configOptionsLst.size());
				
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getConfigOptions: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Marketing Model Requirements Report");
		} 
		return fwdFlag;
	}
	
	/**
	 * @return
	 */
	public String getRequirementsList() {
		String fwdFlag = "";
		alertMessage = validationForGenerateRpt();
		LOG.info("alertMessage >>>>>>>> "+ alertMessage);
		try {
			if(PLMUtils.isEmpty(alertMessage)) {
				
				LOG.info("Selected Model >>>>>> "+ selModel);
				requirementsLst = plmMktModelRptService.getRequirementsList(selProduct, selModel, selConfigOptions, prodManagementFlag, preliminaryFlag);
				
				if (!PLMUtils.isEmptyList(requirementsLst) && requirementsLst.size() > 0) {
					totalRecordMktModelMsg = "Total Records of Marketing Model Requirements Report:: "+ requirementsLst.size();
					fwdFlag = "mktModelReqResult";
					recordCounts = PLMConstants.N_15;
				} else {
					requirementsLst = new ArrayList<PLMMktModelRptData>();
					alertMessage = "No Records Found for the Selected combination";
					fwdFlag = "mktModelReqSearch";
				}
				LOG.info("Requiements List size >>>>> "+ requirementsLst.size());
			} else {
				fwdFlag = "mktModelReqSearch";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getRequirementsList: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Marketing Model Requirements Report");
		} 
		
		return fwdFlag;
	}
	
	/**
	 * 
	 */
	public void resetMktModelReqRpt() {
		selProduct = "";
		prodManagementFlag = true;
		preliminaryFlag = false;
		selModel = "";
		selConfigOptions = new ArrayList<String>();
		productNamesLst = new ArrayList<SelectItem>();
		productNamesLst.add(new SelectItem("Gas"));
		productNamesLst.add(new SelectItem("Steam"));
		productNamesLst.add(new SelectItem("Gen"));
		productNamesLst.add(new SelectItem("PLANT"));
		alertMessage = "";
		modelsLst = new ArrayList<SelectItem>();
		configOptionsLst = new ArrayList<SelectItem>();
		requirementsLst = new ArrayList<PLMMktModelRptData>();
		totalRecordMktModelMsg = "";
	}
	
	/**
	 * This method is used for download Excel sheet for Marketing Model Requirements report
	 * 
	 */
	public void downloadMktModelReqSrchExcel() throws PLMCommonException {
		LOG.info("Entering downloadMktModelReqSrchExcel Method");
		FacesContext facesContext = FacesContext.getCurrentInstance();
	  	try {
			HttpServletResponse response = 
				(HttpServletResponse)facesContext.getExternalContext().getResponse();
			
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			
			response.setHeader("Content-disposition", 
					"attachment; filename="+"mktModelReqReport.xlsx");
			
			OutputStream outputStream = response.getOutputStream();
			
			SXSSFWorkbook workbook = new SXSSFWorkbook();
			
			XSSFFont font = headerFont(workbook, 10);
			
			// Header Style
			XSSFCellStyle headerStyle = headerCell(workbook, font, HSSFColor.PALE_BLUE.index, true);
			
			XSSFFont cellfont = normalFont(workbook, 10);
			// Cell Style
			XSSFCellStyle cellStyle = normalCell(workbook, cellfont, XSSFCellStyle.NO_FILL, true);
			
			SXSSFSheet sheet = (SXSSFSheet) workbook.createSheet("Marketing Model Requirements Report");
			
			int rowcount = 0;
			
			SXSSFCell cell=null;
		    
		    SXSSFRow row = (SXSSFRow) sheet.createRow(rowcount);
		    String[] columns = {"Model","MF Name","MF Rev","MF Description","MF State","MF Display Name","MF Display Text","Requirement Type","Requirement Name",
		    		"Requirement Description","Requirement Rev","Requirement Indicator","Estimated Cost"};
			
		    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			cell.setCellValue(commonMB.getDateStampEtl());
			LOG.info(commonMB.getDateStampEtl());
			cell.setCellStyle(cellStyle);
			sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,0,4));
			
			rowcount++;
			row = (SXSSFRow) sheet.createRow(rowcount);
        	for ( int i = 0 ; i < columns.length; i++ ) {
				cell = (SXSSFCell)row.createCell(i);
				cell. setCellValue(columns[i]);
				cell.setCellStyle(headerStyle);
			}
            	
				for(int i=0;i<requirementsLst.size();i++){
				
					PLMMktModelRptData dataObj = (PLMMktModelRptData) requirementsLst.get(i);
					
					row = (SXSSFRow) sheet.createRow(++rowcount);
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getModel());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getCoName());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getCoRev());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_THREE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getCoDesc());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FOUR);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getCoState());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_FIVE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getCoDisplayName());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_SIX);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getCoDisplayText());
					/*if(!PLMUtils.isEmpty(dataObj.getTaskEstdFinishDate())){
						cell.setCellValue(dataObj.getTaskEstdFinishDate());
					}else{
						cell.setCellValue("");
					}*/
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_SEVEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getReqType());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_EIGHT);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getReqName());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_NINE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getReqDesc());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getReqRev());
					
					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ELEVEN);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getReqGeIndr());

					cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWELVE);
					cell.setCellStyle(cellStyle);
					cell.setCellValue(dataObj.getReqEstimatedCost());
					
		  	   }
			
             	row = (SXSSFRow) sheet.createRow(++rowcount);
             	row = (SXSSFRow) sheet.createRow(++rowcount);
             	
			    XSSFCellStyle ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
			    ftrStyle.setFont(font);
			    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
			    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
			    cell.setCellStyle(ftrStyle);
				sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_TWO));

				sheet.setColumnWidth(0,15*256);
				sheet.setColumnWidth(1,15*256);
				sheet.setColumnWidth(2,15*256);
				sheet.setColumnWidth(3,15*256);
				sheet.setColumnWidth(4,15*256);
				sheet.setColumnWidth(5,15*256);
				sheet.setColumnWidth(6,15*256);
				sheet.setColumnWidth(7,15*256);
				sheet.setColumnWidth(8,15*256);
				sheet.setColumnWidth(9,15*256);
				sheet.setColumnWidth(10,15*256);
				sheet.setColumnWidth(11,15*256);
				sheet.setColumnWidth(12,15*256);
				
				/*rowcount =0;
				sheet = (SXSSFSheet) workbook.createSheet("Input Filters");
				 row = (SXSSFRow) sheet.createRow(rowcount);
				    String[] columns1 = {"Project Name","Task State","Task Name"};
		        	for ( int i = 0 ; i < columns1.length; i++ ) {
						cell = (SXSSFCell)row.createCell(i);
						cell. setCellValue(columns1[i]);
						cell.setCellStyle(headerStyle);
					}
		        	
		         	for (int i = 0; i < selBacklogProjectName.size() || i < selBacklogTaskName.size() || i < selTaskStateForBacklogRpt.size(); i++) {
		         		row = (SXSSFRow) sheet.createRow(++rowcount);
						
		         		if (i < selBacklogProjectName.size()) {
		         			cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
							cell.setCellStyle(cellStyle);
							cell.setCellValue(selBacklogProjectName.get(i));
						 }
						 if (i < selTaskStateForBacklogRpt.size()) {
							 cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellStyle(cellStyle);
								cell.setCellValue(selTaskStateForBacklogRpt.get(i));
						 }
						 if (i < selBacklogTaskName.size()) {
							 cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_TWO);
							 cell.setCellStyle(cellStyle);
							 cell.setCellValue(selBacklogTaskName.get(i));
						 }
					}
		         	row = (SXSSFRow) sheet.createRow(++rowcount);
	             	row = (SXSSFRow) sheet.createRow(++rowcount);
	             	
				    ftrStyle = (XSSFCellStyle) workbook.createCellStyle();
				    ftrStyle.setFont(font);
				    ftrStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
				    ftrStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
				    cell = (SXSSFCell)row.createCell(PLMConstants.EXCEL_COL_ZERO);
				    cell.setCellValue("GE Proprietary Information - For GE Use Only ");
				    cell.setCellStyle(ftrStyle);
					sheet.addMergedRegion(new CellRangeAddress(rowcount,rowcount,PLMConstants.EXCEL_COL_ZERO,PLMConstants.EXCEL_COL_TWO));

					sheet.setColumnWidth(0,15*256);
					sheet.setColumnWidth(1,15*256);
					sheet.setColumnWidth(2,15*256);*/
            workbook.write(outputStream);
			
			outputStream.flush();
			
			outputStream.close();
			
		} catch (IOException ioex) {
			ioex.printStackTrace();
		} finally {
			facesContext.responseComplete();
	  	}
	  	LOG.info("Exiting downloadBacklogSrchExcel Method");
	}
	
	private XSSFFont headerFont(SXSSFWorkbook wb, int size){
		XSSFFont font = (XSSFFont) wb.createFont();
		font.setFontName(PLMConstants.EXCEL_FONT_NAME);
		font.setFontHeightInPoints((short)size);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		return font;
	}
	
	private XSSFFont normalFont(SXSSFWorkbook wb, int size){
		XSSFFont font = (XSSFFont) wb.createFont();
		font.setFontName(PLMConstants.EXCEL_FONT_NAME);
		font.setFontHeightInPoints((short)size);
		return font;
	}
	
	private XSSFCellStyle headerCell(SXSSFWorkbook wb, XSSFFont font, short bgcolor, boolean wrap){
		XSSFCellStyle hCell = normalCell(wb, font, XSSFCellStyle.SOLID_FOREGROUND, wrap);
		//FONT
		hCell.setFont(font);
		
		//HORIZONTAL ALIGNMENT
		hCell.setAlignment(XSSFCellStyle.ALIGN_CENTER);
		
		//COLOR
		hCell.setFillForegroundColor(bgcolor);
		return hCell;
	}
	
	private XSSFCellStyle normalCell(SXSSFWorkbook wb, XSSFFont font, short fillPattern, boolean wrap){
		// Cell Style
		XSSFCellStyle cellStyle = (XSSFCellStyle)wb.createCellStyle();
		
		//Set Font
		cellStyle.setFont(font);
		//WRAP TEXT
		cellStyle.setWrapText(wrap);
		
		//VERTICAL ALIGNMENT
		cellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
		
		//BORDERS
		cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		
		//FILL PATTERN
		cellStyle.setFillPattern(fillPattern);
		return cellStyle;
	}
	/**
	 * This method is used for Bordering Cell in XLS
	 * 
	 * @return StringBuffer
	 */
	private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
		style.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style.setBorderRight(XSSFCellStyle.BORDER_THIN);
		return style;
	}
	
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}


	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor
	 *            the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}
	/**
	 * @return the userDetails
	 */
	public PLMPwiUserData getUserDetails() {
		return userDetails;
	}
	/**
	 * @param userDetails the userDetails to set
	 */
	public void setUserDetails(PLMPwiUserData userDetails) {
		this.userDetails = userDetails;
	}
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}
	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}
	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}
	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return
	 */
	public String getSelProduct() {
		return selProduct;
	}

	/**
	 * @param selProduct
	 */
	public void setSelProduct(String selProduct) {
		this.selProduct = selProduct;
	}

	/**
	 * @return
	 */
	public List<SelectItem> getProductNamesLst() {
		return productNamesLst;
	}

	/**
	 * @param productNamesLst
	 */
	public void setProductNamesLst(List<SelectItem> productNamesLst) {
		this.productNamesLst = productNamesLst;
	}

	/**
	 * @return
	 */
	public boolean isProdManagementFlag() {
		return prodManagementFlag;
	}

	/**
	 * @param prodManagementFlag
	 */
	public void setProdManagementFlag(boolean prodManagementFlag) {
		this.prodManagementFlag = prodManagementFlag;
	}

	/**
	 * @return
	 */
	public boolean isPreliminaryFlag() {
		return preliminaryFlag;
	}

	/**
	 * @param preliminaryFlag
	 */
	public void setPreliminaryFlag(boolean preliminaryFlag) {
		this.preliminaryFlag = preliminaryFlag;
	}

	/**
	 * @return
	 */
	public List<SelectItem> getModelsLst() {
		return modelsLst;
	}

	/**
	 * @param modelsLst
	 */
	public void setModelsLst(List<SelectItem> modelsLst) {
		this.modelsLst = modelsLst;
	}

	/**
	 * @return
	 */
	public String getSelModel() {
		return selModel;
	}

	/**
	 * @param selModel
	 */
	public void setSelModel(String selModel) {
		this.selModel = selModel;
	}

	/**
	 * @return
	 */
	public PLMMktModelRptServiceIfc getPlmMktModelRptService() {
		return plmMktModelRptService;
	}

	/**
	 * @param plmMktModelRptService
	 */
	public void setPlmMktModelRptService(
			PLMMktModelRptServiceIfc plmMktModelRptService) {
		this.plmMktModelRptService = plmMktModelRptService;
	}

	/**
	 * @return
	 */
	public List<SelectItem> getConfigOptionsLst() {
		return configOptionsLst;
	}

	/**
	 * @param configOptionsLst
	 */
	public void setConfigOptionsLst(List<SelectItem> configOptionsLst) {
		this.configOptionsLst = configOptionsLst;
	}

	/**
	 * @return
	 */
	public List<String> getSelConfigOptions() {
		return selConfigOptions;
	}

	/**
	 * @param selconfigOptions
	 */
	public void setSelConfigOptions(List<String> selConfigOptions) {
		this.selConfigOptions = selConfigOptions;
	}

	/**
	 * @return
	 */
	public List<PLMMktModelRptData> getRequirementsLst() {
		return requirementsLst;
	}

	/**
	 * @param requirementsLst
	 */
	public void setRequirementsLst(List<PLMMktModelRptData> requirementsLst) {
		this.requirementsLst = requirementsLst;
	}

	/**
	 * @return
	 */
	public String getTotalRecordMktModelMsg() {
		return totalRecordMktModelMsg;
	}

	/**
	 * @param totalRecordMktModelMsg
	 */
	public void setTotalRecordMktModelMsg(String totalRecordMktModelMsg) {
		this.totalRecordMktModelMsg = totalRecordMktModelMsg;
	}

	public int getRecordCounts() {
		return recordCounts;
	}

	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}
}