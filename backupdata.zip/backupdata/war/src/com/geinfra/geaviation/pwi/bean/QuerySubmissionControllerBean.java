package com.geinfra.geaviation.pwi.bean;

import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.PWiQueryVO;
import com.geinfra.geaviation.pwi.service.vo.QuerySubmissionResult;

/**
 * 
 * Project : Product Lifecycle Management Intelligence Date Written : December
 * 9, 2010 Security : GE Confidential Restrictions : GE PROPRIETARY INFORMATION,
 * FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : QueryBuilderBean
 * 
 * Revision Log December 9, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class QuerySubmissionControllerBean extends BaseBean {
	private PWiQueryVO query;
	private QuerySubmissionResult querySubmissionResult;

	public PWiQueryVO getQuery() {
		return query;
	}

	public void setQuery(PWiQueryVO query) {
		this.query = query;
	}

	public QuerySubmissionResult getQuerySubmissionResult() {
		return querySubmissionResult;
	}

	public void setQuerySubmissionResult(
			QuerySubmissionResult querySubmissionResult) {
		this.querySubmissionResult = querySubmissionResult;
	}
}