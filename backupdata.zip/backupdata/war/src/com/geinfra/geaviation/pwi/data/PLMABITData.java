/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMABITData.java
 * @Creation date: 03-Nov-2011
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;

public class PLMABITData {
	/**
	  * Holds the itemID
	  */
	private String itemID = "";
	/**
	  * Holds the itemComments
	  */
	private String itemComments = "";
	/**
	  * Holds the itemSource
	  */
	private String itemSource = "";
	
	private String nasFileName;
	private Date fileCreation;
	private boolean checkFile;
	private String fileType;
	
	/**
	 * @return the itemID
	 */
	public String getItemID() {
		return this.itemID;
	}
	
	/**
	 * @param itemID
	 *            the itemID to set
	 */
	public void setItemID(String itemID) {
		this.itemID = itemID;
	}

	/**
	 * @return the itemComments
	 */
	public String getItemComments() {
		return this.itemComments;
	}
	/**
	 * @param itemComments
	 *            the itemComments to set
	 */
	public void setItemComments(String itemComments) {
		this.itemComments = itemComments;
	}
	
	/**
	 * @return the itemSource
	 */
	public String getItemSource() {
		return this.itemSource;
	}
	/**
	 * @param itemSource
	 *            the itemSource to set
	 */
	public void setItemSource(String itemSource) {
		this.itemSource = itemSource;
	}
	
	/**
	 * @return the checkFile
	 */
	public boolean isCheckFile() {
		return checkFile;
	}
	/**
	 * @param checkFile the checkFile to set
	 */
	public void setCheckFile(boolean checkFile) {
		this.checkFile = checkFile;
	}
	/**
	 * @return the nasFileName
	 */
	public String getNasFileName() {
		return nasFileName;
	}
	/**
	 * @param nasFileName the nasFileName to set
	 */
	public void setNasFileName(String nasFileName) {
		this.nasFileName = nasFileName;
	}
	/**
	 * @return the fileCreation
	 */
	public Date getFileCreation() {
		Date temp = null;
		temp = fileCreation;
		return temp;
	}
	/**
	 * @param fileCreation the fileCreation to set
	 */
	public void setFileCreation(Date fileCreation) {
		Date temp = null;
		temp = fileCreation;
		this.fileCreation = temp;
	}
	
	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}
	/**
	 * @param fileType the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
}