/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEBomToMBomMB.java
 * @Creation date: 06-Sept-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TreeMap;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMEBomToMBomData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMEBomToMBomServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.SpreadsheetWriter;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMEBomToMBomMB {
	/**
	 * Holds the LOG
	 */
	private static Logger LOG = Logger.getLogger(PLMEBomToMBomMB.class);
	/**
	 * Holds the PLMEBomToMBomServiceIfc
	 */
	private PLMEBomToMBomServiceIfc plmEBomToMBomService  = null;
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the alertEMBoMMessage
	 */
	private String alertEMBoMMessage;
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	/**
	 * Holds user information
	 */
	private PLMPwiUserData userDetails = null;
	
	private List<String> partList=new ArrayList<String>();
	/**
	 * Holds the part1
	 */
	private String part1;
	/**
	 * Holds the part2
	 */
	private String part2;
	/**
	 * Holds the part3
	 */
	private String part3;
	/**
	 * Holds the part4
	 */
	private String part4;
	/**
	 * Holds the part5
	 */
	private String part5;
	/**
	 * Holds the part6
	 */
	private String part6;
	/**
	 * Holds the part7
	 */
	private String part7;
	/**
	 * Holds the part8
	 */
	private String part8;
	
	/**
	 * Holds the bomType1
	 */
	private String bomType1;
	/**
	 * Holds the bomType2
	 */
	private String bomType2;
	/**
	 * Holds the bomType3
	 */
	private String bomType3;
	/**
	 * Holds the bomType4
	 */
	private String bomType4;
	/**
	 * Holds the bomType5
	 */
	private String bomType5;
	/**
	 * Holds the bomType6
	 */
	private String bomType6;
	/**
	 * Holds the bomType7
	 */
	private String bomType7;
	/**
	 * Holds the bomType8
	 */
	private String bomType8;
	
	private TreeMap <String, Object> partTreeMap = new TreeMap<String, Object>();
	
	/**
	 * Holds the XML_ENCODING
	 */
	private static final String XML_ENCODING = "UTF-8";
	
	/**
	 * Holds the bomsFlag
	 */
	private boolean bomsFlag;

	/**
	 * This method is used for Loading compare for EBom to Mbom 
	 * @return String
	 */
	public String loadEbomToMbomHome() {
		LOG.info("Entering loadEbomToMbomHome Method");
		try {
			commonMB.insertCannedRptRecordHitInfo("Compare EBOM to MBOM Report");
			
			alertEMBoMMessage = "";
			part1="";
			part2="";
			part3="";
			part4="";
			part5="";
			part6="";
			part7="";
			part8="";
			bomType1="";
			bomType2="";
			bomType3="";
			bomType4="";
			bomType5="";
			bomType6="";
			bomType7="";
			bomType8="";
			partList=new ArrayList<String>();
			partTreeMap = new TreeMap<String, Object>();
			bomsFlag =true;
			} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadEbomToMbomHome:", exception);
		}
		LOG.info("Exiting loadEbomToMbomHome Method");
		return "ebomToMbomCompare";
	}
	
	/**
	 * This method is used for Validating part number User Input
	 * 
	 * @return String
	 */
	public String validateEbomToMbomInput() {
		LOG.info("Entering validateEbomToMbomInput Method");
		String alertMsg = "";
		partTreeMap = new TreeMap<String, Object>();
		int partCount=0;
		Set<String> partSet =new HashSet<String>();
		partList=new ArrayList<String>();
		
		if(PLMUtils.isEmpty(part1) &&  PLMUtils.isEmpty(part2) && PLMUtils.isEmpty(part3) &&  PLMUtils.isEmpty(part4)
				&& PLMUtils.isEmpty(part5) &&  PLMUtils.isEmpty(part6) && PLMUtils.isEmpty(part7) &&  PLMUtils.isEmpty(part8)
				&& PLMUtils.isEmpty(bomType1) &&  PLMUtils.isEmpty(bomType2) && PLMUtils.isEmpty(bomType3) &&  PLMUtils.isEmpty(bomType4)
				&& PLMUtils.isEmpty(bomType5) &&  PLMUtils.isEmpty(bomType6) && PLMUtils.isEmpty(bomType7) &&  PLMUtils.isEmpty(bomType8)){
			alertMsg = PLMConstants.EBOM_TO_MBOM_EMTPY_CRITERIA;
		}else if(!PLMUtils.checkForSpecialChars(part1)){
			alertMsg = "Part 1 " + PLMConstants.EBOM_TO_MBOM_SPLCHAR_CRITERIA;
		}else if((PLMUtils.isEmpty(part1) && !PLMUtils.isEmpty(bomType1))){
			alertMsg ="Part 1 "+PLMConstants.EBOM_TO_MBOM_PART_CRITERIA +" BOM Type 1";
		}else if((!PLMUtils.isEmpty(part1) && PLMUtils.isEmpty(bomType1))){
			alertMsg ="BOM Type 1 "+PLMConstants.EBOM_TO_MBOM_TYPE_CRITERIA +" Part 1";
		}else if(!PLMUtils.checkForSpecialChars(part2)){
			alertMsg ="Part 2 " + PLMConstants.EBOM_TO_MBOM_SPLCHAR_CRITERIA;
		}else if((PLMUtils.isEmpty(part2) && !PLMUtils.isEmpty(bomType2))){
			alertMsg ="Part 2 "+PLMConstants.EBOM_TO_MBOM_PART_CRITERIA +" BOM Type 2";
		}else if((!PLMUtils.isEmpty(part2) && PLMUtils.isEmpty(bomType2))){
			alertMsg ="BOM Type 2 "+PLMConstants.EBOM_TO_MBOM_TYPE_CRITERIA +" Part 2";
		}else if(!PLMUtils.checkForSpecialChars(part3)){
			alertMsg ="Part 3 " +  PLMConstants.EBOM_TO_MBOM_SPLCHAR_CRITERIA;
		}else if((PLMUtils.isEmpty(part3) && !PLMUtils.isEmpty(bomType3))){
			alertMsg ="Part 3 "+PLMConstants.EBOM_TO_MBOM_PART_CRITERIA +" BOM Type 3";
		}else if((!PLMUtils.isEmpty(part3) && PLMUtils.isEmpty(bomType3))){
			alertMsg ="BOM Type 3 "+PLMConstants.EBOM_TO_MBOM_TYPE_CRITERIA +" Part 3";
		}else if(!PLMUtils.checkForSpecialChars(part4)){
			alertMsg = "Part 4 " + PLMConstants.EBOM_TO_MBOM_SPLCHAR_CRITERIA;
		}else if((PLMUtils.isEmpty(part4) && !PLMUtils.isEmpty(bomType4))){
			alertMsg ="Part 4 "+PLMConstants.EBOM_TO_MBOM_PART_CRITERIA +" BOM Type 4";
		}else if((!PLMUtils.isEmpty(part4) && PLMUtils.isEmpty(bomType4))){
			alertMsg ="BOM Type 4 "+PLMConstants.EBOM_TO_MBOM_TYPE_CRITERIA +" Part 4";
		}else if(!PLMUtils.checkForSpecialChars(part5)){
			alertMsg = "Part 5 " + PLMConstants.EBOM_TO_MBOM_SPLCHAR_CRITERIA;
		}else if((PLMUtils.isEmpty(part5) && !PLMUtils.isEmpty(bomType5))){
			alertMsg ="Part 5 "+PLMConstants.EBOM_TO_MBOM_PART_CRITERIA +" BOM Type 5";
		}else if((!PLMUtils.isEmpty(part5) && PLMUtils.isEmpty(bomType5))){
			alertMsg ="BOM Type 5 "+PLMConstants.EBOM_TO_MBOM_TYPE_CRITERIA +" Part 5";
		}else if(!PLMUtils.checkForSpecialChars(part6)){
			alertMsg = "Part 6 " + PLMConstants.EBOM_TO_MBOM_SPLCHAR_CRITERIA;
		}else if((PLMUtils.isEmpty(part6) && !PLMUtils.isEmpty(bomType6))){
			alertMsg ="Part 6 "+PLMConstants.EBOM_TO_MBOM_PART_CRITERIA +" BOM Type 6";
		}else if((!PLMUtils.isEmpty(part6) && PLMUtils.isEmpty(bomType6))){
			alertMsg ="BOM Type 6 "+PLMConstants.EBOM_TO_MBOM_TYPE_CRITERIA +" Part 6";
		}else if(!PLMUtils.checkForSpecialChars(part7)){
			alertMsg = "Part 7 " + PLMConstants.EBOM_TO_MBOM_SPLCHAR_CRITERIA;
		}else if((PLMUtils.isEmpty(part7) && !PLMUtils.isEmpty(bomType7))){
			alertMsg ="Part 7 "+PLMConstants.EBOM_TO_MBOM_PART_CRITERIA +" BOM Type 7";
		}else if((!PLMUtils.isEmpty(part7) && PLMUtils.isEmpty(bomType7))){
			alertMsg ="BOM Type 7 "+PLMConstants.EBOM_TO_MBOM_TYPE_CRITERIA +" Part 7";
		}else if(!PLMUtils.checkForSpecialChars(part8)){
			alertMsg = "Part 8 " + PLMConstants.EBOM_TO_MBOM_SPLCHAR_CRITERIA;
		}else if((PLMUtils.isEmpty(part8) && !PLMUtils.isEmpty(bomType8))){
			alertMsg ="Part 8 "+PLMConstants.EBOM_TO_MBOM_PART_CRITERIA +" BOM Type 8";
		}else if((!PLMUtils.isEmpty(part8) && PLMUtils.isEmpty(bomType8))){
			alertMsg ="BOM Type 8 "+PLMConstants.EBOM_TO_MBOM_TYPE_CRITERIA +" Part 8";
		}
		
		
		if(PLMUtils.isEmpty(alertMsg)){
			if((!PLMUtils.isEmpty(part1) && !PLMUtils.isEmpty(bomType1))){
				partTreeMap.put("1", part1+PLMConstants.TILDA_SYMBOL+bomType1);
				partSet.add(part1+PLMConstants.TILDA_SYMBOL+bomType1);
				partList.add(part1);
				partCount++;
			}
			if((!PLMUtils.isEmpty(part2) && !PLMUtils.isEmpty(bomType2))){
				partTreeMap.put("2", part2+PLMConstants.TILDA_SYMBOL+bomType2);
				partSet.add(part2+PLMConstants.TILDA_SYMBOL+bomType2);
				partList.add(part2);
				partCount++;
			}
			if((!PLMUtils.isEmpty(part3) && !PLMUtils.isEmpty(bomType3))){
				partTreeMap.put("3", part3+PLMConstants.TILDA_SYMBOL+bomType3);
				partSet.add(part3+PLMConstants.TILDA_SYMBOL+bomType3);
				partList.add(part3);
				partCount++;
			}
			if((!PLMUtils.isEmpty(part4) && !PLMUtils.isEmpty(bomType4))){
				partTreeMap.put("4", part4+PLMConstants.TILDA_SYMBOL+bomType4);
				partSet.add(part4+PLMConstants.TILDA_SYMBOL+bomType4);
				partList.add(part4);
				partCount++;
			}
			if((!PLMUtils.isEmpty(part5) && !PLMUtils.isEmpty(bomType5))){
				partTreeMap.put("5", part5+PLMConstants.TILDA_SYMBOL+bomType5);
				partSet.add(part5+PLMConstants.TILDA_SYMBOL+bomType5);
				partList.add(part5);
				partCount++;
			}
			if((!PLMUtils.isEmpty(part6) && !PLMUtils.isEmpty(bomType6))){
				partTreeMap.put("6", part6+PLMConstants.TILDA_SYMBOL+bomType6);
				partSet.add(part6+PLMConstants.TILDA_SYMBOL+bomType6);
				partList.add(part6);
				partCount++;
			}
			if((!PLMUtils.isEmpty(part7) && !PLMUtils.isEmpty(bomType7))){
				partTreeMap.put("7", part7+PLMConstants.TILDA_SYMBOL+bomType7);
				partSet.add(part7+PLMConstants.TILDA_SYMBOL+bomType7);
				partList.add(part7);
				partCount++;
			}
			if((!PLMUtils.isEmpty(part8) && !PLMUtils.isEmpty(bomType8))){
				partTreeMap.put("8", part8+PLMConstants.TILDA_SYMBOL+bomType8);
				partSet.add(part8+PLMConstants.TILDA_SYMBOL+bomType8);
				partList.add(part8);
				partCount++;
			}
		}
		
		 if(partCount == 1){
			 if ((PLMUtils.isEmpty(part1) && PLMUtils.isEmpty(bomType1))) {
				 alertMsg = PLMConstants.EBOM_TO_MBOM_PART_SEQ;
			 }
		 }
		 
		 if(partCount == 2){
			 if ((PLMUtils.isEmpty(part2) && PLMUtils.isEmpty(bomType2))) {
				 alertMsg = PLMConstants.EBOM_TO_MBOM_PART_SEQ;
			 }
		 }
		 
		 if(partCount == 3){
			 if ((PLMUtils.isEmpty(part2) && PLMUtils.isEmpty(bomType2))||
				  (PLMUtils.isEmpty(part3) && PLMUtils.isEmpty(bomType3))) {
				 alertMsg = PLMConstants.EBOM_TO_MBOM_PART_SEQ;
			 }
		 }
		 
		 if(partCount == 4){
			 if ((PLMUtils.isEmpty(part2) && PLMUtils.isEmpty(bomType2))||
					 (PLMUtils.isEmpty(part3) && PLMUtils.isEmpty(bomType3))||
					 (PLMUtils.isEmpty(part4) && PLMUtils.isEmpty(bomType4))) {
				 	alertMsg = PLMConstants.EBOM_TO_MBOM_PART_SEQ;
			 }
		 }
		 
		 if(partCount == 5){
			 if ((PLMUtils.isEmpty(part2) && PLMUtils.isEmpty(bomType2))||
				  (PLMUtils.isEmpty(part3) && PLMUtils.isEmpty(bomType3))||
				  (PLMUtils.isEmpty(part4) && PLMUtils.isEmpty(bomType4))||
				  (PLMUtils.isEmpty(part5) && PLMUtils.isEmpty(bomType5))) {
				 alertMsg = PLMConstants.EBOM_TO_MBOM_PART_SEQ;
			 }
		 }
		 
		 if(partCount == 6){
			 if ((PLMUtils.isEmpty(part2) && PLMUtils.isEmpty(bomType2))||
					 (PLMUtils.isEmpty(part3) && PLMUtils.isEmpty(bomType3))||
					  (PLMUtils.isEmpty(part4) && PLMUtils.isEmpty(bomType4))||
					  (PLMUtils.isEmpty(part5) && PLMUtils.isEmpty(bomType5))||
					  (PLMUtils.isEmpty(part6) && PLMUtils.isEmpty(bomType6))) {
				 	alertMsg = PLMConstants.EBOM_TO_MBOM_PART_SEQ;
				 }
		 }
		 
		 if(partCount == 7){
			 if ((PLMUtils.isEmpty(part2) && PLMUtils.isEmpty(bomType2))||
					 (PLMUtils.isEmpty(part3) && PLMUtils.isEmpty(bomType3))||
					  (PLMUtils.isEmpty(part4) && PLMUtils.isEmpty(bomType4))||
					  (PLMUtils.isEmpty(part5) && PLMUtils.isEmpty(bomType5))||
					  (PLMUtils.isEmpty(part6) && PLMUtils.isEmpty(bomType6))||
					  (PLMUtils.isEmpty(part7) && PLMUtils.isEmpty(bomType7))) {
				 	alertMsg = PLMConstants.EBOM_TO_MBOM_PART_SEQ;
			 }
		 }
		 
		 if(PLMUtils.isEmpty(alertMsg)){
			 if(partSet.size()!=partCount){
			 alertMsg = PLMConstants.EBOM_TO_MBOM_PART_COMB;
			 }else if(partCount > 1 && !bomsFlag){
			 alertMsg = PLMConstants.EBOM_TO_MBOM_TYPE_1;
			 }else if(partCount == 1 && bomsFlag){
			 alertMsg = PLMConstants.EBOM_TO_MBOM_TYPE_1_AND_2;
			 }
		 }
		 
		
		LOG.info("Exiting validateEbomToMbomInput Method");
		return alertMsg;
	}
	
	/**
	 * This method is used for Generating EBOM TO MBOM Report
	 * 
	 * @return String
	 * @throws PWiException 
	 * @throws PLMCommonException 
	 */
	public String getEbomToMbomRpt() throws PLMCommonException, PWiException {
		LOG.info("Entering getEbomToMbomRpt Method");
		String fwdflag = "";
		alertEMBoMMessage = "";
		alertEMBoMMessage = validateEbomToMbomInput();
		String invalidParts="";
			try {
				if(PLMUtils.isEmpty(alertEMBoMMessage)) {
				   List<String> partListLcl = plmEBomToMBomService.getValidPartList(partList);
				    for(String partNm:partList){
				    	if(!partListLcl.contains(partNm)){
				    		invalidParts = invalidParts.concat(partNm+",");
				    	}
				    }
				    if(!PLMUtils.isEmpty(invalidParts)) {
				    	alertEMBoMMessage = invalidParts.substring(0,invalidParts.length() - 1) + PLMConstants.EBOM_TO_MBOMMAIL_INVALID_MSG;
				     }else {
				    	commonMB.getCopicsDateStamp();
				    	alertEMBoMMessage = PLMConstants.EBOM_TO_MBOMMAIL_ALERT_MSG;
					    userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
					    taskExecutor.execute(new MailThread());
				     }
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		LOG.info("Exiting getEbomToMbomRpt Method");
		return fwdflag;
	}

	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendEbomToMbomThroughMail();
		}
	}

	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return void
	 * @throws PLMCommonException 
	 */
	public void sendEbomToMbomThroughMail() {
		LOG.info("Entering sendEbomToMbomThroughMail Method");		
		Map<String, Object> varMap = new HashMap<String, Object>();
		TreeMap <String, Object> bomListMap = new TreeMap<String, Object>();
		TreeMap <String, Object> partBoMTreeMap = new TreeMap<String, Object>();
		TreeMap <String, Object> partTreeMapLcl = partTreeMap;
		List<String> partListlcl=partList;
		List<PLMEBomToMBomData> contractDataList = new ArrayList<PLMEBomToMBomData>();
		boolean fileExist=false;
		String filePathZip = "";
		String folderPath = "";
		String fileName = "";
		Writer fw = null;
		SpreadsheetWriter sw = null;
		boolean fileFlag = true;
		String deltempXmlFile="";
		StringBuffer criteriaInputs=new StringBuffer();
		try {			
			
			contractDataList = plmEBomToMBomService.getContractForPartName(partListlcl);
			
			//Iterating the parts with BOM Type
			for (Map.Entry<String, Object> treekey : partTreeMapLcl.entrySet()) {
				
				String[] partBomType = ((String) treekey.getValue())
						.split(PLMConstants.TILDA_SYMBOL);
				String partVal = partBomType[0];
				String bomTypeVal = partBomType[1];
				
				criteriaInputs.append(bomTypeVal+"->"+partVal+"\n");
				if(bomTypeVal.equalsIgnoreCase("EBOM")){
					LOG.info("EBOM Type Part Number>>> "+partVal);
					List<PLMEBomToMBomData> plmEbomDataResultList = plmEBomToMBomService.getEBOMDataForPartName(partVal);
					if(!PLMUtils.isEmptyList(plmEbomDataResultList)){
						partBoMTreeMap.put(treekey.getKey(), plmEbomDataResultList);
					}
				}else if(bomTypeVal.equalsIgnoreCase("PLM MBOM")){
					LOG.info("PLM MBOM Type Part Number>>> "+partVal);
					List<PLMEBomToMBomData> plmMbomDataResultList = plmEBomToMBomService.getPlmMBOMDataForPartName(partVal);
					if(!PLMUtils.isEmptyList(plmMbomDataResultList)){
						partBoMTreeMap.put(treekey.getKey(), plmMbomDataResultList);
					 }
				}else{
					LOG.info("Copics MBOM Type Part Number>>> "+partVal);
					List<PLMEBomToMBomData> copicsMbomDataResultList = plmEBomToMBomService.getCopicsMBOMDataForPartName(partVal);
					if(!PLMUtils.isEmptyList(copicsMbomDataResultList)){
						partBoMTreeMap.put(treekey.getKey(), copicsMbomDataResultList);
					 }
				}
			}
			LOG.info("partBoMTreeMap.size()>>>>>>>>>>"+partBoMTreeMap.size());
			LOG.info("criteriaInputs>>>>>>>>>>"+criteriaInputs);
			varMap.put("criteriaInputs", criteriaInputs);
			int partCount=0;
			if(!PLMUtils.isEmptyMap(partBoMTreeMap) && partBoMTreeMap.size() >=1){
				partCount =partBoMTreeMap.size();
				   String folPath = resourceBundle.getString("OFFLINE_RPT_DIR");
					fileName = folPath + resourceBundle.getString("COMPARE_MBOM_TO_EBOM_XLSM");
					Date uniqDate = new Date();
			    	final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
					String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
					folderPath = folPath + resourceBundle.getString("COMPARE_MBOM_TO_EBOM") + uniqTime;
					filePathZip = folderPath + ".zip";
					
					File fol = new File(folPath);
					if(fol.exists()){
						fol = new File(folderPath);
						fol.mkdir();
					}
					varMap.put("fileName", fileName);
					varMap.put("folderPath", folderPath);
					varMap.put("fileFlag", fileFlag);
					varMap.put("filePathZip", filePathZip);
				Map<String, String> eidsUniqueMap = new TreeMap<String, String>();
				prepareEBOMVsMBOMDataForComparison(partBoMTreeMap, bomListMap, eidsUniqueMap);
				prepareSpreadsheetWriter(varMap,partCount,bomListMap,partTreeMapLcl,contractDataList);
				sw = (SpreadsheetWriter) varMap.get("sw");
				compareEBOMVsMBOMData(varMap,sw,bomListMap,partTreeMapLcl,eidsUniqueMap);
				writeExcelFileUsingAppendedXML(varMap);
				PLMUtils.generateZipFile((String)varMap.get("filePathXls"), (String)varMap.get("filePathZip"));		
				sendMail(varMap);
				deltempXmlFile=folderPath+"/"+(String)varMap.get("tempXmlFile");
				fileExist=true;
			}else{				
				sendNoDataMail(varMap);
				LOG.info("No data Mail sent");
			}
		} catch (IOException ioexception) {	
			LOG.log(Level.ERROR, "Exception@sendBVSComparisonReportThroughMail: ", ioexception);
			PLMUtils.checkExceptionAndMail(ioexception.getMessage(), PLMConstants.BVS_MAIL_FROM, (String)varMap.get("to"), (String)varMap.get("subject"), (String)varMap.get("toAddressee"), PLMConstants.BVS_MAIL_SIGNATURE + PLMConstants.BVS_MAIL_FOOTER);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendBVSComparisonReportThroughMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(), PLMConstants.BVS_MAIL_FROM, (String)varMap.get("to"), (String)varMap.get("subject"), (String)varMap.get("toAddressee"), PLMConstants.BVS_MAIL_SIGNATURE + PLMConstants.BVS_MAIL_FOOTER);
		}
		finally {
			
			fw = (Writer) varMap.get("fw");
			if(fw != null){
				LOG.info("Closing Writer");
				try {
					fw.close();
				} catch (IOException e) {
					LOG.info("Exception occurred while Closing Writer: "+ e.getMessage());
					try {
						PLMUtils.checkException(e.getMessage());
					} catch (PLMCommonException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
			
			if(fileExist){
				 PLMUtils.deleteFiles((String)varMap.get("filePathXls"),(String)varMap.get("filePathZip"));
				 PLMUtils.deleteFiles(folderPath,deltempXmlFile);
			 }
			
		}
		LOG.info("Exiting sendEbomToMbomThroughMail Method");
	}
	
	/**
	 * This method is used for Sendng Mail
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void sendMail(Map<String, Object> varMap) throws PLMCommonException{
		LOG.info("Entering sendMail Method");
		String from = PLMConstants.BVS_MAIL_FROM;
		
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		
		toAddressee = "Dear " + toAddressee + ", \n\n";
		
		String subject = PLMConstants.EBOM_TO_MBOMMAIL_SUBJECT;
		StringBuffer mailBody = new StringBuffer().append(toAddressee);
		boolean isCompared = (Boolean) varMap.get("isCompared");
		
		varMap.put("to", to);
		varMap.put("toAddressee", toAddressee);
		varMap.put("subject", subject);
		
		if(!isCompared){
			mailBody.append(PLMConstants.BOM_TO_MBOMMAIL_NO_RECORD);
		} else {
			mailBody.append(PLMConstants.BOM_TO_MBOMMAIL_CONTENT + "\n");
			StringBuffer criteriaData = (StringBuffer) varMap.get("criteriaInputs");
			mailBody.append(criteriaData);
		}
		mailBody.append(PLMConstants.MBVS_MAIL_SIGNATURE);
		mailBody.append(PLMConstants.MBVS_MAIL_FOOTER);
		PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), (String)varMap.get("filePathZip"));
		
		LOG.info("Exiting sendMail Method");
	}
	/**
	 * This method is used for Sending No Mail Mail
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void sendNoDataMail(Map<String, Object> varMap) throws PLMCommonException{
		LOG.info("Entering sendNoDataMail Method");
		String from = PLMConstants.BVS_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.EBOM_TO_MBOMMAIL_SUBJECT;
		StringBuffer mailBody = new StringBuffer().append(toAddressee);
		
		varMap.put("to", to);
		varMap.put("toAddressee", toAddressee);
		varMap.put("subject", subject);
		
		mailBody.append(PLMConstants.BOM_TO_MBOMMAIL_NO_RECORD+ "\n");
		StringBuffer criteriaData = (StringBuffer) varMap.get("criteriaInputs");
		mailBody.append(criteriaData);
		mailBody.append(PLMConstants.BVS_MAIL_SIGNATURE);
		mailBody.append(PLMConstants.BVS_MAIL_FOOTER);
		PLMUtils.sendMail(from, to, subject, mailBody.toString());
		
		LOG.info("Exiting sendNoDataMail Method");
	}

	/**
	 * This method is used for preparing data ready for Comparison with EBOM Vs MBOM
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void prepareEBOMVsMBOMDataForComparison(TreeMap <String, Object> partBoMTreeMapLcl, TreeMap <String, Object> bomListMapLcl, 
			Map<String, String> eidsUniqueMap) throws PLMCommonException{
		LOG.info("Entering prepareEBOMVsMBOMDataForComoparison Method");
		//List<PLMEBomToMBomData> emptyListData = new ArrayList<PLMEBomToMBomData>();
		for (Map.Entry<String, Object> treekey : partBoMTreeMapLcl.entrySet()) {	
			LOG.info("Starting for Converting EBOM to MBOM Data for comparison key Value >>>>>" +treekey.getKey());
			Map<String, List<PLMEBomToMBomData>> bomListMap = convertListToMapForComparison((List<PLMEBomToMBomData>)treekey.getValue());
			getUniqueEids(bomListMap, eidsUniqueMap);
			LOG.info("EMBOM Map size before adding missing Eid "+bomListMap.size());
			
			for (Map.Entry<String, String> entry : eidsUniqueMap.entrySet()) {
				if(bomListMap.get(entry.getKey()) == null){
					bomListMap.put(entry.getKey(), new ArrayList<PLMEBomToMBomData>());
				}
			}
			
			LOG.info("EMBOM Map size after adding missing Eid "+bomListMap.size());
			  
			  if(!PLMUtils.isEmptyMap(bomListMap)){
					List<String> list = new ArrayList<String>(bomListMap.keySet());
					LOG.info(" Key in bomListMap------>"+list.get(0));
					list.clear();
				}
			  bomListMapLcl.put(treekey.getKey(), bomListMap);
			}
	}
	/**
     * This method is used for createExcelFileMap
	   * 
	   * @param selectedPF,varMap
	   * @return Map
     * @throws PLMCommonException
     */
  private Map<String, Object> createExcelFileMap(Map<String, Object> varMap) throws PLMCommonException {
		String filePathXls = "";
		String folderPath = (String) varMap.get("folderPath");	
		try {
			Date uniqDate = new Date();
			final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat(
					"yyyyMMddHHmmss");
			String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
			filePathXls = folderPath + "/"
					+ resourceBundle.getString("COMPARE_MBOM_TO_EBOM") + " "
					+ uniqTime + ".xlsx";
	
			varMap.put("filePathXls", filePathXls);
	
		} catch (Exception e) {
			LOG.log(Level.ERROR, "Exception@createNewFile: ", e);
			PLMUtils.checkException(e.getMessage());
		}
	    return varMap;
  }  
	 /**
     * This method is used for writeExcelFileUsingAppendedXML
	 * 
	 * @param varMap
	 * @throws PLMCommonException
	 */
	private void writeExcelFileUsingAppendedXML(Map<String, Object> varMap) throws PLMCommonException {
		String filePathXls;
		Map<String, Object> varMapVal=varMap;
		String folderPath = (String) varMapVal.get("folderPath");
		String fileName = (String) varMapVal.get("fileName");	
	    String tempXmlFile = (String) varMapVal.get("tempXmlFile");
	    Writer fw = (Writer) varMapVal.get("fw");
		SpreadsheetWriter sw = (SpreadsheetWriter) varMapVal.get("sw");
		boolean fileFlag = (Boolean) varMapVal.get("fileFlag");
    	LOG.info("fileFlag>> "+fileFlag);
    	FileOutputStream out=null;
	    try {   
	    	if(fw != null){
				endSheet(sw);
				fw.close();				 
			}
	    	varMapVal = createExcelFileMap(varMapVal); 
			filePathXls = (String) varMapVal.get("filePathXls");											 
			File tmp = new File(folderPath + "/" + tempXmlFile);
			 out = new FileOutputStream(filePathXls);
			PLMUtils.substitute(new File(fileName), tmp, "xl/worksheets/sheet1.xml", out);
			//out.close();		
			
			varMapVal.put("fileFlag",true);
	        //LOG.info("XML Temp File = "+tmp.getName()+" Deleted = "+tmp.delete());
			//LOG.info("Closed File successfully");
	    } catch (FileNotFoundException e) {
	   	 	LOG.log(Level.ERROR, "Exception@writeExcelFileUsingAppendedXML: ", e);
	   	 	PLMUtils.checkException(e.getMessage());
	    } catch (IOException e) {
	   	 	LOG.log(Level.ERROR, "Exception@writeExcelFileUsingAppendedXML: ", e);
	   	 	PLMUtils.checkException(e.getMessage());
	    } 	   
	    finally{
			   if(out != null ){
				   try {
					   out.close();
				} catch (IOException e) {
					PLMUtils.checkException(e.getMessage());
				}
			   }
	    }	   
	}

	/**
     * This method is used for prepareSpreadsheetWriter
	 * 
	 * @param varMap
	 * @param pfName
	 * @throws Exception 
	 */
	private void prepareSpreadsheetWriter(Map<String, Object> varMap,int partCount,TreeMap <String, Object> bomListMapLcl,
			TreeMap <String, Object> partTreeMapLcl,List<PLMEBomToMBomData>contractDataListLcl) throws IOException {
		String folderPath = (String) varMap.get("folderPath");
		String tempXmlFile = "";
		Writer fw = null;
		SpreadsheetWriter sw = (SpreadsheetWriter) varMap.get("sw");
		if(sw != null){
			LOG.info("sw--->"+sw.toString());
		}
		boolean fileFlag = (Boolean) varMap.get("fileFlag");
		
		if(fileFlag){
			tempXmlFile = createTempFile(folderPath);
			fw = new OutputStreamWriter(new FileOutputStream(folderPath + "/" + tempXmlFile, true), XML_ENCODING);
		    sw = new SpreadsheetWriter(fw);
		    fileFlag = false;
		    
			beginSheet(sw);
			 List <String> bomTypeList =new ArrayList<String>();
	    	addExceHeaders(sw,partCount,bomListMapLcl,partTreeMapLcl,bomTypeList,contractDataListLcl);
	    	
	    	varMap.put("bomTypeList", bomTypeList);
	    	varMap.put("tempXmlFile", tempXmlFile);
	    	varMap.put("fileFlag", fileFlag);
	    	varMap.put("fw", fw);
	    	varMap.put("sw", sw);
		}		
	}
	
	 /**
     * This method is used for addExceHeaders
	 * 
	 * @param SpreadsheetWriter	 
	 * @param String selectedPF 
	 * @throws Exception
	 */
	 private void addExceHeaders(SpreadsheetWriter sw,int partCount,TreeMap <String, Object> bomListMapLcl,
				TreeMap <String, Object> partTreeMapLcl,List <String> bomTypeList,List<PLMEBomToMBomData>contractDataListLcl) throws IOException { 

		 XSSFWorkbook wb = new XSSFWorkbook();
	     XSSFCellStyle style = wb.createCellStyle();
	     XSSFFont headerFont = wb.createFont();
	     headerFont.setBold(true);
	     style.setFont(headerFont);
	     
	     int styleIndex =style.getIndex();
		 sw.insertRow(0);	     
	     sw.createCell(0, commonMB.getDateStampEtl(),styleIndex);
	     sw.endRow();
	     
	     sw.insertRow(1);	     
	     sw.createCell(0, commonMB.getDateStampCOPICS(),styleIndex);
	     sw.endRow();
	     
	     sw.insertRow(2);	
	     int cellInitial =2;
	     String[] partContrtBomType =null;
	     for (Map.Entry<String, Object> treekey : bomListMapLcl.entrySet()) { // Map carrying BOM Data for each input value. BOM count 0 are not included
			if(partTreeMapLcl.get(treekey.getKey()) != null){ // Input Parts added to Map key is number and value is PartNumber~BomType
				partContrtBomType = ((String) partTreeMapLcl.get(treekey.getKey()))
							.split(PLMConstants.TILDA_SYMBOL);  
			   String partName = partContrtBomType[0];
			   String bomType = partContrtBomType[1];
			   for(PLMEBomToMBomData contractDt :contractDataListLcl){
				   if(contractDt.getPartNm().equalsIgnoreCase(partName)){
					   sw.createCell(cellInitial, " Contract Name - "+contractDt.getContractNm(),styleIndex);
					   break;
				   }  
			   }
		      if(bomType.equalsIgnoreCase("PLM MBOM")){
			     cellInitial =cellInitial+9;
			   }else{
				 cellInitial =cellInitial+8;
			   }
			}
		 }
	     sw.endRow();	
	     
	     sw.insertRow(3);	
	     cellInitial =2;
	      partContrtBomType =null;
	     for (Map.Entry<String, Object> treekey : bomListMapLcl.entrySet()) { // Map carrying BOM Data for each input value. BOM count 0 are not included
			if(partTreeMapLcl.get(treekey.getKey()) != null){ // Input Parts added to Map key is number and value is PartNumber~BomType
				partContrtBomType = ((String) partTreeMapLcl.get(treekey.getKey()))
							.split(PLMConstants.TILDA_SYMBOL);  
			   String partName = partContrtBomType[0];
			   String bomType = partContrtBomType[1];
			   for(PLMEBomToMBomData contractDt :contractDataListLcl){
				   if(contractDt.getPartNm().equalsIgnoreCase(partName)){
					   sw.createCell(cellInitial, " Contract Desc - "+contractDt.getContractDesc(),styleIndex);
					   break;
				   }  
			   }
		      if(bomType.equalsIgnoreCase("PLM MBOM")){
			     cellInitial =cellInitial+9;
			   }else{
				 cellInitial =cellInitial+8;
			   }
			}
		 }
	     sw.endRow();		

	     sw.insertRow(4);	
	     String[] partBomType =null;
	     cellInitial =2;
	     for (Map.Entry<String, Object> treekey : bomListMapLcl.entrySet()) { // Map carrying BOM Data for each input value. BOM count 0 are not included
				if(partTreeMapLcl.get(treekey.getKey()) != null){ // Input Parts added to Map key is number and value is PartNumber~BomType
				   partBomType = ((String) partTreeMapLcl.get(treekey.getKey()))
								.split(PLMConstants.TILDA_SYMBOL);  
				   String partName = partBomType[0];
				   String bomType = partBomType[1];
				   bomTypeList.add(bomType);
				   sw.createCell(cellInitial, bomType+" Part Number - "+partName,styleIndex);
				   if(bomType.equalsIgnoreCase("PLM MBOM")){
				     cellInitial =cellInitial+9;
				   }else{
					 cellInitial =cellInitial+8;
				   }
				}
		    }
			
	     sw.endRow();	
	     
	     sw.insertRow(5);
	     sw.createCell(0, "EID",styleIndex);
	     sw.createCell(1, "BOM Prefix",styleIndex);
	     
	     String[] colNames1 ={"Level","Consumption Status","Part Name","Parent Name","Rev", "Description", "Quantity", "Production Status", "State"};
	     String[] colNames2 ={"Level","Part Name","Parent Name","Rev", "Description", "Quantity", "Production Status", "State"};
		 int hdrCellStr =2;
	 	 
	     for(int cnt=0;cnt<bomTypeList.size();cnt++){
	    	 if(bomTypeList.get(cnt).equalsIgnoreCase("PLM MBOM")){
	 			for(int i = 0 ; i < colNames1.length; i++){
					sw.createCell(hdrCellStr, colNames1[i],styleIndex);
					hdrCellStr++;
				}
	    	 }else{
	 			for(int i = 0 ; i < colNames2.length; i++){
					sw.createCell(hdrCellStr, colNames2[i],styleIndex);
					hdrCellStr++;
				}
	    	 }
		 }
	     sw.endRow();
	 }

	
	/**
     * This method is used for createTempFile
	 * 
	 * @param String folderPath
	 * @return String fileName
	 * @throws IOException
	 */	
	 private String createTempFile(String folderPath) throws IOException{
		 File tmp = File.createTempFile("sheet", ".xml", new File(folderPath));
	     LOG.info("Temp File Name "+tmp.getName());
	     return tmp.getName();
	 }
	 
	 /**
	   * @param SpreadsheetWriter	 
	   */
	 private void beginSheet(SpreadsheetWriter sw) throws IOException{	 
		 sw.beginSheet(resourceBundle.getString(PLMConstants.SPREADSHEET_SCHEMA_URL));
	 }
		 
	 /**
	 * @param SpreadsheetWriter	 
	 */
	 private void endSheet(SpreadsheetWriter sw) throws IOException{	
		 sw.endSheet();
	 }
	 
	
	/**
	 * This method is used for removing duplicate MLI's from EBOM and MBOM
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private void getUniqueEids(Map<String, List<PLMEBomToMBomData>> bvsMLIMap, Map<String, String> eidsUniqueMap) throws PLMCommonException{
		for (Map.Entry<String, List<PLMEBomToMBomData>> entry : bvsMLIMap.entrySet()) {			
			if(eidsUniqueMap.get(entry.getKey()) == null){
				eidsUniqueMap.put(entry.getKey(), entry.getKey());
			}
		}
	}
	
	/**
	 * This method is used for converting List to Map which will simplify comparison of BOM Vs Sales
	 * 
	 * @return void
	 * @throws PLMCommonException
	 */
	private Map<String, List<PLMEBomToMBomData>> convertListToMapForComparison(List<PLMEBomToMBomData> bvsDataList) throws PLMCommonException{
		List<PLMEBomToMBomData> bvsList = new ArrayList<PLMEBomToMBomData>();
		Map<String, List<PLMEBomToMBomData>> bvsMLIMap = new TreeMap<String, List<PLMEBomToMBomData>>();
		String eidNumber = "";					
		for (PLMEBomToMBomData bvsData : bvsDataList) {
			eidNumber = bvsData.getEid();
			if(bvsMLIMap.get(eidNumber) == null){					
				bvsList = new ArrayList<PLMEBomToMBomData>();					
				bvsMLIMap.put(eidNumber,bvsList);	
			}				
			bvsList.add(bvsData);
		}	
		return bvsMLIMap;		
	}

	/**
	 * This method is used for Comparing EBOM to MBOM Data
	 * 
	 * @return void
	 * @throws PLMCommonException
	 * @throws IOException 
	 */
	@SuppressWarnings("unchecked")
	private void compareEBOMVsMBOMData(Map<String, Object> varMap,SpreadsheetWriter sw,TreeMap <String, Object> bomListMapLcl,TreeMap <String, Object> partTreeMapLcl,
			Map<String, String> eidsUniqueMap) throws PLMCommonException, IOException{
			
			boolean isCompared = false;
			
			int rowCount=6;
			
			List<String> partDataList = new ArrayList<String>();
			for (Map.Entry<String, Object> treekey : bomListMapLcl.entrySet()) { // Map carrying BOM Data for each input value. BOM count 0 are not included
				if(partTreeMapLcl.get(treekey.getKey()) != null){ // Input Parts added to Map key is number and value is PartNumber~BomType
				   partDataList.add(treekey.getKey());
				}
		    }
		
			List<PLMEBomToMBomData> bomData1 = new ArrayList<PLMEBomToMBomData>();
			List<PLMEBomToMBomData> bomData2 = new ArrayList<PLMEBomToMBomData>();
			List<PLMEBomToMBomData> bomData3 = new ArrayList<PLMEBomToMBomData>();
			List<PLMEBomToMBomData> bomData4 = new ArrayList<PLMEBomToMBomData>();
			List<PLMEBomToMBomData> bomData5 = new ArrayList<PLMEBomToMBomData>();
			List<PLMEBomToMBomData> bomData6 = new ArrayList<PLMEBomToMBomData>();
			List<PLMEBomToMBomData> bomData7 = new ArrayList<PLMEBomToMBomData>();
			List<PLMEBomToMBomData> bomData8 = new ArrayList<PLMEBomToMBomData>();

			for (Map.Entry<String, String> entry : eidsUniqueMap.entrySet()) {
				bomData1 = new ArrayList<PLMEBomToMBomData>();
				bomData2 = new ArrayList<PLMEBomToMBomData>();
				bomData3 = new ArrayList<PLMEBomToMBomData>();
				bomData4 = new ArrayList<PLMEBomToMBomData>();
				bomData5 = new ArrayList<PLMEBomToMBomData>();
				bomData6 = new ArrayList<PLMEBomToMBomData>();
				bomData7 = new ArrayList<PLMEBomToMBomData>();
				bomData8 = new ArrayList<PLMEBomToMBomData>();
				
				String eid = eidsUniqueMap.get(entry.getKey());

				for(int cnt=0; cnt < partDataList.size(); cnt++){
					if(cnt==0){
						if(((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).get(eid) != null){
							bomData1.addAll(((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).get(eid));
							 Collections.sort(bomData1, new SortPartNamesQty());
						}
					}else if(cnt==1){
						if(((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).get(eid) != null){
							bomData2.addAll(((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).get(eid));
							Collections.sort(bomData2, new SortPartNamesQty());
						}
						
					}else if(cnt==2){
						if(((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).get(eid) != null){
							bomData3.addAll(((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).get(eid));
							Collections.sort(bomData3, new SortPartNamesQty());
						}
						
					}else if(cnt==3){
						if(((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).get(eid) != null){
							bomData4.addAll(((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).get(eid));
							 Collections.sort(bomData4, new SortPartNamesQty());
						}
						
					}else if(cnt==4){
						if(((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).get(eid) != null){
							bomData5.addAll(((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).get(eid));
							 Collections.sort(bomData5, new SortPartNamesQty());
						}
						
					}else if(cnt==5){
						if(((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).get(eid) != null){
							bomData6.addAll(((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).get(eid));
							 Collections.sort(bomData6, new SortPartNamesQty());
						}
						
					}else if(cnt==6){
						if(((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).get(eid) != null){
							bomData7.addAll(((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).get(eid));
							 Collections.sort(bomData7, new SortPartNamesQty());
						}
						
					}else if(cnt==7){
						if(((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).get(eid) != null){
							bomData8.addAll(((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).get(eid));
							 Collections.sort(bomData8, new SortPartNamesQty());
						}
						
					}
				}
				
					int index1=0; 
					int index2=0;
					int index3=0;
					int index4=0;
					int index5=0;
					int index6=0;
					int index7=0;
					int index8=0;
					
					
					int consumStincr=0;
					
					 while (index1 < bomData1.size() || index2 < bomData2.size() || index3 < bomData3.size() || index4 < bomData4.size() || 
							index5 < bomData5.size() || index6 < bomData6.size() || index7 < bomData7.size() || index8 < bomData8.size()){
						
						 sw.insertRow(rowCount);	
						 sw.createCell(PLMConstants.EXCEL_COL_ZERO,eid);
						 
						 List<String> bomTypeListDt =(List<String>) varMap.get("bomTypeList");
						 int cellCount2=0;
						 int cellCount3=0;
						 int cellCount4=0;
						 int cellCount5=0;
						 int cellCount6=0;
						 int cellCount7=0;
						 int cellCount8=0;
						 
						 for(int i=0;i<bomTypeListDt.size();i++){
							 
							 if(cellCount2==0){
								if(bomTypeListDt.get(i).equalsIgnoreCase("PLM MBOM")){
									 cellCount2 =10;
								 }else{
									 cellCount2 = 9;
								  }
							 }else if(cellCount3==0){
								if(bomTypeListDt.get(i).equalsIgnoreCase("PLM MBOM")){
									 cellCount3 =cellCount2+9;
								 }else{
									 cellCount3 =cellCount2+8;
								  }
							 }else if(cellCount4==0){
								if(bomTypeListDt.get(i).equalsIgnoreCase("PLM MBOM")){
									 cellCount4 =cellCount3+9;
								 }else{
									 cellCount4 =cellCount3+8;
								  }
							 }else if(cellCount5==0){
								if(bomTypeListDt.get(i).equalsIgnoreCase("PLM MBOM")){
									 cellCount5 =cellCount4+9;
								 }else{
									 cellCount5 =cellCount4+8;
								  }
							 }else if(cellCount6==0){
								if(bomTypeListDt.get(i).equalsIgnoreCase("PLM MBOM")){
									 cellCount6 =cellCount5+9;
								 }else{
									 cellCount6 =cellCount5+8;
								  }
							 }else if(cellCount7==0){
								if(bomTypeListDt.get(i).equalsIgnoreCase("PLM MBOM")){
									 cellCount7 =cellCount6+9;
								 }else{
									 cellCount7 =cellCount6+8;
								  }
							 }else if(cellCount8==0){
								if(bomTypeListDt.get(i).equalsIgnoreCase("PLM MBOM")){
									 cellCount8 =cellCount7+9;
								 }else{
									 cellCount8 =cellCount7+8;
								  }
							 }
							 
						 }
						 
						
						/*int cellCount2=9;
						int cellCount3=17;
						int cellCount4=25;
						int cellCount5=33;
						int cellCount6=41;
						int cellCount7=49;
						int cellCount8=57;*/
						
						String part1 = "";
						String part2 = "";
						String part3 = "";
						String part4 = "";
						String part5 = "";
						String part6 = "";
						String part7 = "";
						
						boolean hasBom1 = false;
						boolean hasBom2 = false;
						boolean hasBom3 = false;
						boolean hasBom4 = false;
						boolean hasBom5 = false;
						boolean hasBom6 = false;
						boolean hasBom7 = false;	
						
						if (index1 < bomData1.size()) {
							 part1 = bomData1.get(index1).getPartName()+PLMConstants.TILDA_SYMBOL+bomData1.get(index1).getQuantityDb();
							 if(bomData1.get(index1).isConsumFlag()){
								 sw.createCell(PLMConstants.EXCEL_COL_ONE,bomData1.get(index1).getBomPrefix());
								 sw.createCell(PLMConstants.EXCEL_COL_TWO,bomData1.get(index1).getBomLevel());
								 sw.createCell(PLMConstants.EXCEL_COL_THREE,bomData1.get(index1).getConsumState());
								 sw.createCell(PLMConstants.EXCEL_COL_FOUR,bomData1.get(index1).getPartName());
								 sw.createCell(PLMConstants.EXCEL_COL_FIVE,bomData1.get(index1).getParentName());
								 sw.createCell(PLMConstants.EXCEL_COL_SIX,bomData1.get(index1).getBomRevision());
								 sw.createCell(PLMConstants.EXCEL_COL_SEVEN,bomData1.get(index1).getDescription());
								 sw.createCell(PLMConstants.EXCEL_COL_EIGHT,bomData1.get(index1).getQuantity());
								 sw.createCell(PLMConstants.EXCEL_COL_NINE,bomData1.get(index1).getProdStatus());
								 sw.createCell(PLMConstants.EXCEL_COL_TEN,bomData1.get(index1).getState());
								 bomData1.get(index1).setPathFlag(true);
								 index1++;
								 hasBom1 = true;
							 }else{
								 sw.createCell(PLMConstants.EXCEL_COL_ONE,bomData1.get(index1).getBomPrefix());
								 sw.createCell(PLMConstants.EXCEL_COL_TWO,bomData1.get(index1).getBomLevel());
								 sw.createCell(PLMConstants.EXCEL_COL_THREE,bomData1.get(index1).getPartName());
								 sw.createCell(PLMConstants.EXCEL_COL_FOUR,bomData1.get(index1).getParentName());
								 sw.createCell(PLMConstants.EXCEL_COL_FIVE,bomData1.get(index1).getBomRevision());
								 sw.createCell(PLMConstants.EXCEL_COL_SIX,bomData1.get(index1).getDescription());
								 sw.createCell(PLMConstants.EXCEL_COL_SEVEN,bomData1.get(index1).getQuantity());
								 sw.createCell(PLMConstants.EXCEL_COL_EIGHT,bomData1.get(index1).getProdStatus());
								 sw.createCell(PLMConstants.EXCEL_COL_NINE,bomData1.get(index1).getState());
								 bomData1.get(index1).setPathFlag(true);
								 index1++;
								 hasBom1 = true;
							 }
						 }else{
							 hasBom1 = false; 
							 part1 = "";
						 }
						 
						 if (index2 < bomData2.size()) {
							boolean matchFlg2 = false;
							 if (!hasBom1) {
								 for (PLMEBomToMBomData data2 :bomData2) {
									 if(!data2.isPathFlag()){
									 part2 = data2.getPartName()+PLMConstants.TILDA_SYMBOL+data2.getQuantityDb();
									 sw.createCell(PLMConstants.EXCEL_COL_ONE,data2.getBomPrefix());
									 sw.createCell(++cellCount2,data2.getBomLevel());
									 if(data2.isConsumFlag()){
									  sw.createCell(++cellCount2,data2.getConsumState());
									 }
									 sw.createCell(++cellCount2,data2.getPartName());
									 sw.createCell(++cellCount2,data2.getParentName());
									 sw.createCell(++cellCount2,data2.getBomRevision());
									 sw.createCell(++cellCount2,data2.getDescription());
									 sw.createCell(++cellCount2,data2.getQuantity());
									 sw.createCell(++cellCount2,data2.getProdStatus());
									 sw.createCell(++cellCount2,data2.getState());
									 data2.setPathFlag(true);
									 index2++;
									 hasBom2 = true;
									 break;
									 }
								 }
						 	 }else if (hasBom1) {
						 		 for(PLMEBomToMBomData data2 :bomData2){
						 			 if(part1.equals(data2.getPartName()+PLMConstants.TILDA_SYMBOL+data2.getQuantityDb()) && !data2.isPathFlag()){
						 				 part2 = data2.getPartName()+PLMConstants.TILDA_SYMBOL+data2.getQuantityDb();
						 				 sw.createCell(++cellCount2,data2.getBomLevel());
						 				if(data2.isConsumFlag()){
										  sw.createCell(++cellCount2,data2.getConsumState());
										 }
										 sw.createCell(++cellCount2,data2.getPartName());
										 sw.createCell(++cellCount2,data2.getParentName());
										 sw.createCell(++cellCount2,data2.getBomRevision());
										 sw.createCell(++cellCount2,data2.getDescription());
										 sw.createCell(++cellCount2,data2.getQuantity());
										 sw.createCell(++cellCount2,data2.getProdStatus());
										 sw.createCell(++cellCount2,data2.getState());
						 				data2.setPathFlag(true);
						 				matchFlg2 =true;
						 				index2++;
						 				hasBom2 = true;
						 				break;
						 			 }
						 		 }
						 		 if(!matchFlg2){
						 			 part2 = "";
						 		 }
							 } 
							
						 }else {
							 hasBom2 = false;
							 part2 = "";
						 }

						 if (index3 < bomData3.size()) {
							 boolean matchFlg3 = false;
							 if (!hasBom1 && !hasBom2) {
								 for (PLMEBomToMBomData data3 :bomData3) {
									 if(!data3.isPathFlag()){
									 part3 = data3.getPartName()+PLMConstants.TILDA_SYMBOL+data3.getQuantityDb();
									 sw.createCell(PLMConstants.EXCEL_COL_ONE,data3.getBomPrefix());
									 sw.createCell(++cellCount3,data3.getBomLevel());
									 if(data3.isConsumFlag()){
									  sw.createCell(++cellCount3,data3.getConsumState());
									 }
									 sw.createCell(++cellCount3,data3.getPartName());
									 sw.createCell(++cellCount3,data3.getParentName());
									 sw.createCell(++cellCount3,data3.getBomRevision());
									 sw.createCell(++cellCount3,data3.getDescription());
									 sw.createCell(++cellCount3,data3.getQuantity());
									 sw.createCell(++cellCount3,data3.getProdStatus());
									 sw.createCell(++cellCount3,data3.getState());
									 data3.setPathFlag(true);
									 index3++;
									 hasBom3 = true;
									 break;
									 }
								}
						 	 }else if (hasBom1 || hasBom2) {
						 		 for(PLMEBomToMBomData data3 :bomData3){
						 			 if(part1.equals(data3.getPartName()+PLMConstants.TILDA_SYMBOL+data3.getQuantityDb()) && !data3.isPathFlag()){
						 				part3 = data3.getPartName()+PLMConstants.TILDA_SYMBOL+data3.getQuantityDb();
				 				         sw.createCell(++cellCount3,data3.getBomLevel());
										 if(data3.isConsumFlag()){
										  sw.createCell(++cellCount3,data3.getConsumState());
										 }
				 				         sw.createCell(++cellCount3,data3.getPartName());
				 				         sw.createCell(++cellCount3,data3.getParentName());
				 				         sw.createCell(++cellCount3,data3.getBomRevision());
				 				         sw.createCell(++cellCount3,data3.getDescription());
				 				         sw.createCell(++cellCount3,data3.getQuantity());
				 				         sw.createCell(++cellCount3,data3.getProdStatus());
				 				         sw.createCell(++cellCount3,data3.getState());
						 				 data3.setPathFlag(true);
						 				 matchFlg3 =true;
						 				 index3++;
						 				 hasBom3 = true;
						 				 break;
						 			 }else if(part2.equals(data3.getPartName()+PLMConstants.TILDA_SYMBOL+data3.getQuantityDb()) && !data3.isPathFlag()){
						 				part3 = data3.getPartName()+PLMConstants.TILDA_SYMBOL+data3.getQuantityDb();
				 				         sw.createCell(++cellCount3,data3.getBomLevel());
										 if(data3.isConsumFlag()){
											sw.createCell(++cellCount3,data3.getConsumState());
										 }
				 				         sw.createCell(++cellCount3,data3.getPartName());
				 				         sw.createCell(++cellCount3,data3.getParentName());
				 				         sw.createCell(++cellCount3,data3.getBomRevision());
				 				         sw.createCell(++cellCount3,data3.getDescription());
				 				         sw.createCell(++cellCount3,data3.getQuantity());
				 				         sw.createCell(++cellCount3,data3.getProdStatus());
				 				         sw.createCell(++cellCount3,data3.getState());
							 			 data3.setPathFlag(true);
							 			 matchFlg3 =true;
							 			 index3++;
							 			 hasBom3 = true;
							 			 break;
						 			 }
						 		 }
						 		 if(!matchFlg3){
						 			 part3 = "";
							 	}
							 } 
						 }else {
							 hasBom3 = false;
							 part3 = "";
						 }
						 
						 if (index4 < bomData4.size()) {
							 boolean matchFlg4 = false;
							 if (!hasBom1 && !hasBom2 && !hasBom3) {
								 for (PLMEBomToMBomData data4 :bomData4) {
									 if(!data4.isPathFlag()){
									 part4 = data4.getPartName()+PLMConstants.TILDA_SYMBOL+data4.getQuantityDb();
									 sw.createCell(PLMConstants.EXCEL_COL_ONE,data4.getBomPrefix());
									 sw.createCell(++cellCount4,data4.getBomLevel());
									 if(data4.isConsumFlag()){
									  sw.createCell(++cellCount4,data4.getConsumState());
									 }
									 sw.createCell(++cellCount4,data4.getPartName());
									 sw.createCell(++cellCount4,data4.getParentName());
									 sw.createCell(++cellCount4,data4.getBomRevision());
									 sw.createCell(++cellCount4,data4.getDescription());
									 sw.createCell(++cellCount4,data4.getQuantity());
									 sw.createCell(++cellCount4,data4.getProdStatus());
									 sw.createCell(++cellCount4,data4.getState());
									 data4.setPathFlag(true);
									 index4++;
									 hasBom4 = true;
									 break;
									 }
								 }
						 	 } else if (hasBom1 || hasBom2 || hasBom3) {
						 		 for(PLMEBomToMBomData data4 :bomData4){
						 			 if(part1.equals(data4.getPartName()+PLMConstants.TILDA_SYMBOL+data4.getQuantityDb()) && !data4.isPathFlag()){
						 				part4 = data4.getPartName()+PLMConstants.TILDA_SYMBOL+data4.getQuantityDb();
				 				         sw.createCell(++cellCount4,data4.getBomLevel());
										 if(data4.isConsumFlag()){
										   sw.createCell(++cellCount4,data4.getConsumState());
										 }
				 				         sw.createCell(++cellCount4,data4.getPartName());
				 				         sw.createCell(++cellCount4,data4.getParentName());
				 				         sw.createCell(++cellCount4,data4.getBomRevision());
				 				         sw.createCell(++cellCount4,data4.getDescription());
				 				         sw.createCell(++cellCount4,data4.getQuantity());
				 				         sw.createCell(++cellCount4,data4.getProdStatus());
				 				         sw.createCell(++cellCount4,data4.getState());
						 				 data4.setPathFlag(true);
						 				 matchFlg4 =true;
						 				 index4++;
						 				hasBom4 = true;
						 				 break;
						 			 }else if(part2.equals(data4.getPartName()+PLMConstants.TILDA_SYMBOL+data4.getQuantityDb()) && !data4.isPathFlag()){
						 				part4 = data4.getPartName()+PLMConstants.TILDA_SYMBOL+data4.getQuantityDb();
				 				         sw.createCell(++cellCount4,data4.getBomLevel());
										 if(data4.isConsumFlag()){
										  sw.createCell(++cellCount4,data4.getConsumState());
										 }
				 				         sw.createCell(++cellCount4,data4.getPartName());
				 				         sw.createCell(++cellCount4,data4.getParentName());
				 				         sw.createCell(++cellCount4,data4.getBomRevision());
				 				         sw.createCell(++cellCount4,data4.getDescription());
				 				         sw.createCell(++cellCount4,data4.getQuantity());
				 				         sw.createCell(++cellCount4,data4.getProdStatus());
				 				         sw.createCell(++cellCount4,data4.getState());
							 			data4.setPathFlag(true);
							 			matchFlg4 =true;
							 			index4++;
							 			hasBom4 = true;
							 			break;
						 			 }else if(part3.equals(data4.getPartName()+PLMConstants.TILDA_SYMBOL+data4.getQuantityDb()) && !data4.isPathFlag()){
						 				part4 = data4.getPartName()+PLMConstants.TILDA_SYMBOL+data4.getQuantityDb();
				 				         sw.createCell(++cellCount4,data4.getBomLevel());
										 if(data4.isConsumFlag()){
										  sw.createCell(++cellCount4,data4.getConsumState());
										 }
				 				         sw.createCell(++cellCount4,data4.getPartName());
				 				         sw.createCell(++cellCount4,data4.getParentName());
				 				         sw.createCell(++cellCount4,data4.getBomRevision());
				 				         sw.createCell(++cellCount4,data4.getDescription());
				 				         sw.createCell(++cellCount4,data4.getQuantity());
				 				         sw.createCell(++cellCount4,data4.getProdStatus());
				 				         sw.createCell(++cellCount4,data4.getState());
								 		data4.setPathFlag(true);
								 		matchFlg4 =true;
								 		index4++;
								 		hasBom4 = true;
								 		break;
							 		 }
						 		 }
						 		 if(!matchFlg4){
						 			 part4 = "";
							 	}
							 } 
						  }else {
							 hasBom4 = false;
							 part4 = "";
						 }
						 
						 if (index5 < bomData5.size()) {
							 boolean matchFlg5 = false;
							 if (!hasBom1 && !hasBom2 && !hasBom3 && !hasBom4) {
								 for (PLMEBomToMBomData data5 :bomData5) {
									 if(!data5.isPathFlag()){
									 part5 = data5.getPartName()+PLMConstants.TILDA_SYMBOL+data5.getQuantityDb();
									 sw.createCell(PLMConstants.EXCEL_COL_ONE,data5.getBomPrefix());
									 sw.createCell(++cellCount5,data5.getBomLevel());
									 if(data5.isConsumFlag()){
									  sw.createCell(++cellCount5,data5.getConsumState());
									 }
									 sw.createCell(++cellCount5,data5.getPartName());
									 sw.createCell(++cellCount5,data5.getParentName());
									 sw.createCell(++cellCount5,data5.getBomRevision());
									 sw.createCell(++cellCount5,data5.getDescription());
									 sw.createCell(++cellCount5,data5.getQuantity());
									 sw.createCell(++cellCount5,data5.getProdStatus());
									 sw.createCell(++cellCount5,data5.getState());
									 data5.setPathFlag(true);
									 index5++;
									 hasBom5 = true;
									 break;
									 }
								 }
						 	 } else if (hasBom1 || hasBom2 || hasBom3 || hasBom4) {
						 		 for(PLMEBomToMBomData data5 :bomData5){
						 			 if(part1.equals(data5.getPartName()+PLMConstants.TILDA_SYMBOL+data5.getQuantityDb()) && !data5.isPathFlag()){
						 				part5 = data5.getPartName()+PLMConstants.TILDA_SYMBOL+data5.getQuantityDb();
				 				         sw.createCell(++cellCount5,data5.getBomLevel());
				 				         if(data5.isConsumFlag()){
										   sw.createCell(++cellCount5,data5.getConsumState());
										 }
				 				         sw.createCell(++cellCount5,data5.getPartName());
										 sw.createCell(++cellCount5,data5.getParentName());
										 sw.createCell(++cellCount5,data5.getBomRevision());
										 sw.createCell(++cellCount5,data5.getDescription());
										 sw.createCell(++cellCount5,data5.getQuantity());
										 sw.createCell(++cellCount5,data5.getProdStatus());
										 sw.createCell(++cellCount5,data5.getState());
						 				data5.setPathFlag(true);
						 				matchFlg5 =true;
						 				index5++;
						 				hasBom5 = true;
						 				break;
						 			 }else if(part2.equals(data5.getPartName()+PLMConstants.TILDA_SYMBOL+data5.getQuantityDb()) && !data5.isPathFlag()){
						 				part5 = data5.getPartName()+PLMConstants.TILDA_SYMBOL+data5.getQuantityDb();
				 				         sw.createCell(++cellCount5,data5.getBomLevel());
				 				         if(data5.isConsumFlag()){
										   sw.createCell(++cellCount5,data5.getConsumState());
										 }
				 				         sw.createCell(++cellCount5,data5.getPartName());
										 sw.createCell(++cellCount5,data5.getParentName());
										 sw.createCell(++cellCount5,data5.getBomRevision());
										 sw.createCell(++cellCount5,data5.getDescription());
										 sw.createCell(++cellCount5,data5.getQuantity());
										 sw.createCell(++cellCount5,data5.getProdStatus());
										 sw.createCell(++cellCount5,data5.getState());
							 			data5.setPathFlag(true);
							 			matchFlg5 =true;
							 			index5++;
							 			hasBom5 = true;
							 			break;
						 			 }else if(part3.equals(data5.getPartName()+PLMConstants.TILDA_SYMBOL+data5.getQuantityDb()) && !data5.isPathFlag()){
						 				part5 = data5.getPartName()+PLMConstants.TILDA_SYMBOL+data5.getQuantityDb();
				 				         sw.createCell(++cellCount5,data5.getBomLevel());
				 				         if(data5.isConsumFlag()){
										   sw.createCell(++cellCount5,data5.getConsumState());
										 }
				 				         sw.createCell(++cellCount5,data5.getPartName());
										 sw.createCell(++cellCount5,data5.getParentName());
										 sw.createCell(++cellCount5,data5.getBomRevision());
										 sw.createCell(++cellCount5,data5.getDescription());
										 sw.createCell(++cellCount5,data5.getQuantity());
										 sw.createCell(++cellCount5,data5.getProdStatus());
										 sw.createCell(++cellCount5,data5.getState());
								 		data5.setPathFlag(true);
								 		matchFlg5 =true;
								 		index5++;
								 		hasBom5 = true;
								 		break;
							 		 }else if(part4.equals(data5.getPartName()+PLMConstants.TILDA_SYMBOL+data5.getQuantityDb()) && !data5.isPathFlag()){
							 			part5 = data5.getPartName()+PLMConstants.TILDA_SYMBOL+data5.getQuantityDb();
				 				         sw.createCell(++cellCount5,data5.getBomLevel());
				 				         if(data5.isConsumFlag()){
										   sw.createCell(++cellCount5,data5.getConsumState());
										 }
				 				         sw.createCell(++cellCount5,data5.getPartName());
										 sw.createCell(++cellCount5,data5.getParentName());
										 sw.createCell(++cellCount5,data5.getBomRevision());
										 sw.createCell(++cellCount5,data5.getDescription());
										 sw.createCell(++cellCount5,data5.getQuantity());
										 sw.createCell(++cellCount5,data5.getProdStatus());
										 sw.createCell(++cellCount5,data5.getState());
									 	data5.setPathFlag(true);
									 	matchFlg5 =true;
									 	index5++;
									 	hasBom5 = true;
									 	break;
								 	  }
						 		 }
						 		 if(!matchFlg5){
						 			part5 = "";
							 	}
							 } 
						   }else {
							 hasBom5 = false;
							 part5 = "";
						 }
						 
						 if (index6 < bomData6.size()) {
							 boolean matchFlg6 = false;
							 if (!hasBom1 && !hasBom2 && !hasBom3 && !hasBom4 && !hasBom5) {
								 for (PLMEBomToMBomData data6 :bomData6) {
									 if(!data6.isPathFlag()){
									 part6 = data6.getPartName()+PLMConstants.TILDA_SYMBOL+data6.getQuantityDb();
									 sw.createCell(PLMConstants.EXCEL_COL_ONE,data6.getBomPrefix());
									 sw.createCell(++cellCount6,data6.getBomLevel());
			 				         if(data6.isConsumFlag()){
									   sw.createCell(++cellCount6,data6.getConsumState());
									 }
									 sw.createCell(++cellCount6,data6.getPartName());
									 sw.createCell(++cellCount6,data6.getParentName());
									 sw.createCell(++cellCount6,data6.getBomRevision());
									 sw.createCell(++cellCount6,data6.getDescription());
									 sw.createCell(++cellCount6,data6.getQuantity());
									 sw.createCell(++cellCount6,data6.getProdStatus());
									 sw.createCell(++cellCount6,data6.getState());
									 data6.setPathFlag(true);
									 index6++;
									 hasBom6 = true;
									 break;
									 }
								 }
						 	 } else if (hasBom1 || hasBom2 || hasBom3 || hasBom4 || hasBom5) {
						 		
						 		 for(PLMEBomToMBomData data6 :bomData6){
						 			 if(part1.equals(data6.getPartName()+PLMConstants.TILDA_SYMBOL+data6.getQuantityDb()) && !data6.isPathFlag()){
						 				part6 = data6.getPartName()+PLMConstants.TILDA_SYMBOL+data6.getQuantityDb();
				 				         sw.createCell(++cellCount6,data6.getBomLevel());
				 				         if(data6.isConsumFlag()){
										  sw.createCell(++cellCount6,data6.getConsumState());
										 }
										 sw.createCell(++cellCount6,data6.getPartName());
										 sw.createCell(++cellCount6,data6.getParentName());
										 sw.createCell(++cellCount6,data6.getBomRevision());
										 sw.createCell(++cellCount6,data6.getDescription());
										 sw.createCell(++cellCount6,data6.getQuantity());
										 sw.createCell(++cellCount6,data6.getProdStatus());
										 sw.createCell(++cellCount6,data6.getState());
						 				data6.setPathFlag(true);
						 				matchFlg6 =true;
						 				index6++;
						 				hasBom6 = true;
						 				break;
						 			 }else if(part2.equals(data6.getPartName()+PLMConstants.TILDA_SYMBOL+data6.getQuantityDb()) && !data6.isPathFlag()){
						 				part6 = data6.getPartName()+PLMConstants.TILDA_SYMBOL+data6.getQuantityDb();
				 				         sw.createCell(++cellCount6,data6.getBomLevel());
				 				         if(data6.isConsumFlag()){
										  sw.createCell(++cellCount6,data6.getConsumState());
										 }
				 				         sw.createCell(++cellCount6,data6.getPartName());
										 sw.createCell(++cellCount6,data6.getParentName());
										 sw.createCell(++cellCount6,data6.getBomRevision());
										 sw.createCell(++cellCount6,data6.getDescription());
										 sw.createCell(++cellCount6,data6.getQuantity());
										 sw.createCell(++cellCount6,data6.getProdStatus());
										 sw.createCell(++cellCount6,data6.getState());
							 			matchFlg6 =true;
							 			data6.setPathFlag(true);
							 			index6++;
							 			hasBom6 = true;
							 			break;
						 			 }else if(part3.equals(data6.getPartName()+PLMConstants.TILDA_SYMBOL+data6.getQuantityDb()) && !data6.isPathFlag()){
						 				part6 = data6.getPartName()+PLMConstants.TILDA_SYMBOL+data6.getQuantityDb();
				 				         sw.createCell(++cellCount6,data6.getBomLevel());
				 				         if(data6.isConsumFlag()){
										  sw.createCell(++cellCount6,data6.getConsumState());
										 }
				 				         sw.createCell(++cellCount6,data6.getPartName());
										 sw.createCell(++cellCount6,data6.getParentName());
										 sw.createCell(++cellCount6,data6.getBomRevision());
										 sw.createCell(++cellCount6,data6.getDescription());
										 sw.createCell(++cellCount6,data6.getQuantity());
										 sw.createCell(++cellCount6,data6.getProdStatus());
										 sw.createCell(++cellCount6,data6.getState());
								 		matchFlg6 =true;
								 		data6.setPathFlag(true);
								 		index6++;
								 		hasBom6 = true;
								 		break;
							 		 }else if(part4.equals(data6.getPartName()+PLMConstants.TILDA_SYMBOL+data6.getQuantityDb()) && !data6.isPathFlag()){
							 			part6 = data6.getPartName()+PLMConstants.TILDA_SYMBOL+data6.getQuantityDb();
				 				         sw.createCell(++cellCount6,data6.getBomLevel());
				 				         if(data6.isConsumFlag()){
										  sw.createCell(++cellCount6,data6.getConsumState());
										 }
				 				         sw.createCell(++cellCount6,data6.getPartName());
										 sw.createCell(++cellCount6,data6.getParentName());
										 sw.createCell(++cellCount6,data6.getBomRevision());
										 sw.createCell(++cellCount6,data6.getDescription());
										 sw.createCell(++cellCount6,data6.getQuantity());
										 sw.createCell(++cellCount6,data6.getProdStatus());
										 sw.createCell(++cellCount6,data6.getState());
									 	matchFlg6 =true;
									 	data6.setPathFlag(true);
									 	index6++;
									 	hasBom6 = true;
									 	break;
								 	  }else if(part5.equals(data6.getPartName()+PLMConstants.TILDA_SYMBOL+data6.getQuantityDb()) && !data6.isPathFlag()){
								 		part6 = data6.getPartName()+PLMConstants.TILDA_SYMBOL+data6.getQuantityDb();
				 				         sw.createCell(++cellCount6,data6.getBomLevel());
				 				         if(data6.isConsumFlag()){
										  sw.createCell(++cellCount6,data6.getConsumState());
										 }
				 				         sw.createCell(++cellCount6,data6.getPartName());
										 sw.createCell(++cellCount6,data6.getParentName());
										 sw.createCell(++cellCount6,data6.getBomRevision());
										 sw.createCell(++cellCount6,data6.getDescription());
										 sw.createCell(++cellCount6,data6.getQuantity());
										 sw.createCell(++cellCount6,data6.getProdStatus());
										 sw.createCell(++cellCount6,data6.getState());
										matchFlg6 =true;
										data6.setPathFlag(true);
										index6++;
										hasBom6 = true;
										break;
									  }
						 		 }
						 		 if(!matchFlg6){
						 			part6 = "";
							 	}
							 } 
						   }else {
							 hasBom6 = false;
							 part6 = "";
						 }
						 
						 if (index7 < bomData7.size()) {
							 boolean matchFlg7 = false;
							 if (!hasBom1 && !hasBom2 && !hasBom3 && !hasBom4 && !hasBom5 && !hasBom6) {
								 for (PLMEBomToMBomData data7 :bomData7) {
									 if(!data7.isPathFlag()){
									 part7 = data7.getPartName()+PLMConstants.TILDA_SYMBOL+data7.getQuantityDb();
									 sw.createCell(PLMConstants.EXCEL_COL_ONE,data7.getBomPrefix());
									 sw.createCell(++cellCount7,data7.getBomLevel());
			 				         if(data7.isConsumFlag()){
									  sw.createCell(++cellCount7,data7.getConsumState());
									 }
									 sw.createCell(++cellCount7,data7.getPartName());
									 sw.createCell(++cellCount7,data7.getParentName());
									 sw.createCell(++cellCount7,data7.getBomRevision());
									 sw.createCell(++cellCount7,data7.getDescription());
									 sw.createCell(++cellCount7,data7.getQuantity());
									 sw.createCell(++cellCount7,data7.getProdStatus());
									 sw.createCell(++cellCount7,data7.getState());
									 data7.setPathFlag(true);
									 index7++;
									 hasBom7 = true;
									 break;
									 }
								 }
						 	 } else if (hasBom1 || hasBom2 || hasBom3 || hasBom4 || hasBom5 || hasBom6) {
						 		 for(PLMEBomToMBomData data7 :bomData7){
						 			 if(part1.equals(data7.getPartName()+PLMConstants.TILDA_SYMBOL+data7.getQuantityDb())&& !data7.isPathFlag()){
						 				part7 = data7.getPartName()+PLMConstants.TILDA_SYMBOL+data7.getQuantityDb();
				 				         sw.createCell(++cellCount7,data7.getBomLevel());
				 				         if(data7.isConsumFlag()){
										  sw.createCell(++cellCount7,data7.getConsumState());
										 }
				 				         sw.createCell(++cellCount7,data7.getPartName());
				 				         sw.createCell(++cellCount7,data7.getParentName());
				 				         sw.createCell(++cellCount7,data7.getBomRevision());
				 				         sw.createCell(++cellCount7,data7.getDescription());
				 				         sw.createCell(++cellCount7,data7.getQuantity());
				 				         sw.createCell(++cellCount7,data7.getProdStatus());
				 				         sw.createCell(++cellCount7,data7.getState());
						 				 matchFlg7 =true;
						 				data7.setPathFlag(true);
						 				index7++;
						 				hasBom7 = true;
						 				break;
						 			 }else if(part2.equals(data7.getPartName()+PLMConstants.TILDA_SYMBOL+data7.getQuantityDb()) && !data7.isPathFlag()){
						 				part7 = data7.getPartName()+PLMConstants.TILDA_SYMBOL+data7.getQuantityDb();
				 				         sw.createCell(++cellCount7,data7.getBomLevel());
				 				         if(data7.isConsumFlag()){
										  sw.createCell(++cellCount7,data7.getConsumState());
										 }
				 				         sw.createCell(++cellCount7,data7.getPartName());
				 				         sw.createCell(++cellCount7,data7.getParentName());
				 				         sw.createCell(++cellCount7,data7.getBomRevision());
				 				         sw.createCell(++cellCount7,data7.getDescription());
				 				         sw.createCell(++cellCount7,data7.getQuantity());
				 				         sw.createCell(++cellCount7,data7.getProdStatus());
				 				         sw.createCell(++cellCount7,data7.getState());
							 			matchFlg7 =true;
							 			data7.setPathFlag(true);
							 			index7++;
							 			hasBom7 = true;
							 			break;
						 			 }else if(part3.equals(data7.getPartName()+PLMConstants.TILDA_SYMBOL+data7.getQuantityDb()) && !data7.isPathFlag()){
						 				part7 = data7.getPartName()+PLMConstants.TILDA_SYMBOL+data7.getQuantityDb();
				 				         sw.createCell(++cellCount7,data7.getBomLevel());
				 				         if(data7.isConsumFlag()){
										  sw.createCell(++cellCount7,data7.getConsumState());
										 }
				 				         sw.createCell(++cellCount7,data7.getPartName());
				 				         sw.createCell(++cellCount7,data7.getParentName());
				 				         sw.createCell(++cellCount7,data7.getBomRevision());
				 				         sw.createCell(++cellCount7,data7.getDescription());
				 				         sw.createCell(++cellCount7,data7.getQuantity());
				 				         sw.createCell(++cellCount7,data7.getProdStatus());
				 				         sw.createCell(++cellCount7,data7.getState());
								 		matchFlg7 =true;
								 		data7.setPathFlag(true);
								 		index7++;
								 		hasBom7 = true;
								 		break;
							 		 }else if(part4.equals(data7.getPartName()+PLMConstants.TILDA_SYMBOL+data7.getQuantityDb()) && !data7.isPathFlag()){
							 			part7 = data7.getPartName()+PLMConstants.TILDA_SYMBOL+data7.getQuantityDb();
				 				         sw.createCell(++cellCount7,data7.getBomLevel());
				 				         if(data7.isConsumFlag()){
										  sw.createCell(++cellCount7,data7.getConsumState());
										 }
				 				         sw.createCell(++cellCount7,data7.getPartName());
				 				         sw.createCell(++cellCount7,data7.getParentName());
				 				         sw.createCell(++cellCount7,data7.getBomRevision());
				 				         sw.createCell(++cellCount7,data7.getDescription());
				 				         sw.createCell(++cellCount7,data7.getQuantity());
				 				         sw.createCell(++cellCount7,data7.getProdStatus());
				 				         sw.createCell(++cellCount7,data7.getState());
									 	matchFlg7 =true;
									 	data7.setPathFlag(true);
									 	index7++;
									 	hasBom7 = true;
									 	break;
								 	  }else if(part5.equals(data7.getPartName()+PLMConstants.TILDA_SYMBOL+data7.getQuantityDb()) && !data7.isPathFlag()){
								 		part7 = data7.getPartName()+PLMConstants.TILDA_SYMBOL+data7.getQuantityDb();
				 				         sw.createCell(++cellCount7,data7.getBomLevel());
				 				         if(data7.isConsumFlag()){
										  sw.createCell(++cellCount7,data7.getConsumState());
										 }
				 				         sw.createCell(++cellCount7,data7.getPartName());
				 				         sw.createCell(++cellCount7,data7.getParentName());
				 				         sw.createCell(++cellCount7,data7.getBomRevision());
				 				         sw.createCell(++cellCount7,data7.getDescription());
				 				         sw.createCell(++cellCount7,data7.getQuantity());
				 				         sw.createCell(++cellCount7,data7.getProdStatus());
				 				         sw.createCell(++cellCount7,data7.getState());
										matchFlg7 =true;
										data7.setPathFlag(true);
										index7++;
										hasBom7 = true;
										break;
									  }else if(part6.equals(data7.getPartName()+PLMConstants.TILDA_SYMBOL+data7.getQuantityDb()) && !data7.isPathFlag()){
										part7 = data7.getPartName()+PLMConstants.TILDA_SYMBOL+data7.getQuantityDb();
				 				         sw.createCell(++cellCount7,data7.getBomLevel());
				 				         if(data7.isConsumFlag()){
										  sw.createCell(++cellCount7,data7.getConsumState());
										 }
				 				         sw.createCell(++cellCount7,data7.getPartName());
				 				         sw.createCell(++cellCount7,data7.getParentName());
				 				         sw.createCell(++cellCount7,data7.getBomRevision());
				 				         sw.createCell(++cellCount7,data7.getDescription());
				 				         sw.createCell(++cellCount7,data7.getQuantity());
				 				         sw.createCell(++cellCount7,data7.getProdStatus());
				 				         sw.createCell(++cellCount7,data7.getState());
										matchFlg7 =true;
										data7.setPathFlag(true);
										index7++;
										hasBom7 = true;
										break;
									  }
						 		 }
						 		 if(!matchFlg7){
						 			 part7 = "";
							 	}
							 } 
						   }else {
							 hasBom7 = false;
							 part7 = "";
						 }
						 
						 if (index8 < bomData8.size()) {
							 if (!hasBom1 && !hasBom2 && !hasBom3 && !hasBom4 && !hasBom5 && !hasBom6 && !hasBom7) {
								 for (PLMEBomToMBomData data8 :bomData8) {
									 if(!data8.isPathFlag()){
									 sw.createCell(PLMConstants.EXCEL_COL_ONE,data8.getBomPrefix());
									 sw.createCell(++cellCount8,data8.getBomLevel());
			 				         if(data8.isConsumFlag()){
									  sw.createCell(++cellCount8,data8.getConsumState());
									 }
									 sw.createCell(++cellCount8,data8.getPartName());
									 sw.createCell(++cellCount8,data8.getParentName());
									 sw.createCell(++cellCount8,data8.getBomRevision());
									 sw.createCell(++cellCount8,data8.getDescription());
									 sw.createCell(++cellCount8,data8.getQuantity());
									 sw.createCell(++cellCount8,data8.getProdStatus());
									 sw.createCell(++cellCount8,data8.getState());
									 data8.setPathFlag(true);
									 index8++;
									 break;
									 }
								 }
						 	 }else if (hasBom1 || hasBom2 || hasBom3 || hasBom4 || hasBom5 || hasBom6 || hasBom7) {
						 		 for(PLMEBomToMBomData data8 :bomData8){
						 			 if(part1.equals(data8.getPartName()+PLMConstants.TILDA_SYMBOL+data8.getQuantityDb()) && !data8.isPathFlag()){
				 				         sw.createCell(++cellCount8,data8.getBomLevel());
				 				         if(data8.isConsumFlag()){
										  sw.createCell(++cellCount8,data8.getConsumState());
										 }
				 				         sw.createCell(++cellCount8,data8.getPartName());
				 				         sw.createCell(++cellCount8,data8.getParentName());
				 				         sw.createCell(++cellCount8,data8.getBomRevision());
				 				         sw.createCell(++cellCount8,data8.getDescription());
				 				         sw.createCell(++cellCount8,data8.getQuantity());
				 				         sw.createCell(++cellCount8,data8.getProdStatus());
				 				         sw.createCell(++cellCount8,data8.getState());
						 				data8.setPathFlag(true);
						 				index8++;
						 				break;
						 			 }else if(part2.equals(data8.getPartName()+PLMConstants.TILDA_SYMBOL+data8.getQuantityDb()) && !data8.isPathFlag()){
				 				         sw.createCell(++cellCount8,data8.getBomLevel());
				 				         if(data8.isConsumFlag()){
										  sw.createCell(++cellCount8,data8.getConsumState());
										 }
				 				         sw.createCell(++cellCount8,data8.getPartName());
				 				         sw.createCell(++cellCount8,data8.getParentName());
				 				         sw.createCell(++cellCount8,data8.getBomRevision());
				 				         sw.createCell(++cellCount8,data8.getDescription());
				 				         sw.createCell(++cellCount8,data8.getQuantity());
				 				         sw.createCell(++cellCount8,data8.getProdStatus());
				 				         sw.createCell(++cellCount8,data8.getState());
							 			data8.setPathFlag(true);
							 			index8++;
							 			break;
						 			 }else if(part3.equals(data8.getPartName()+PLMConstants.TILDA_SYMBOL+data8.getQuantityDb()) && !data8.isPathFlag()){
				 				         sw.createCell(++cellCount8,data8.getBomLevel());
				 				         if(data8.isConsumFlag()){
										  sw.createCell(++cellCount8,data8.getConsumState());
										 }
				 				         sw.createCell(++cellCount8,data8.getPartName());
				 				         sw.createCell(++cellCount8,data8.getParentName());
				 				         sw.createCell(++cellCount8,data8.getBomRevision());
				 				         sw.createCell(++cellCount8,data8.getDescription());
				 				         sw.createCell(++cellCount8,data8.getQuantity());
				 				         sw.createCell(++cellCount8,data8.getProdStatus());
				 				         sw.createCell(++cellCount8,data8.getState());
								 		data8.setPathFlag(true);
								 		index8++;
								 		break;
							 		 }else if(part4.equals(data8.getPartName()+PLMConstants.TILDA_SYMBOL+data8.getQuantityDb()) && !data8.isPathFlag()){
				 				         sw.createCell(++cellCount8,data8.getBomLevel());
				 				         if(data8.isConsumFlag()){
										  sw.createCell(++cellCount8,data8.getConsumState());
										 }
				 				         sw.createCell(++cellCount8,data8.getPartName());
				 				         sw.createCell(++cellCount8,data8.getParentName());
				 				         sw.createCell(++cellCount8,data8.getBomRevision());
				 				         sw.createCell(++cellCount8,data8.getDescription());
				 				         sw.createCell(++cellCount8,data8.getQuantity());
				 				         sw.createCell(++cellCount8,data8.getProdStatus());
				 				         sw.createCell(++cellCount8,data8.getState());
									 	data8.setPathFlag(true);
									 	index8++;
									 	break;
								 	  }else if(part5.equals(data8.getPartName()+PLMConstants.TILDA_SYMBOL+data8.getQuantityDb()) && !data8.isPathFlag()){
				 				         sw.createCell(++cellCount8,data8.getBomLevel());
				 				         if(data8.isConsumFlag()){
										  sw.createCell(++cellCount8,data8.getConsumState());
										 }
				 				         sw.createCell(++cellCount8,data8.getPartName());
				 				         sw.createCell(++cellCount8,data8.getParentName());
				 				         sw.createCell(++cellCount8,data8.getBomRevision());
				 				         sw.createCell(++cellCount8,data8.getDescription());
				 				         sw.createCell(++cellCount8,data8.getQuantity());
				 				         sw.createCell(++cellCount8,data8.getProdStatus());
				 				         sw.createCell(++cellCount8,data8.getState());
										data8.setPathFlag(true);
										index8++;
										break;
									  }else if(part6.equals(data8.getPartName()+PLMConstants.TILDA_SYMBOL+data8.getQuantityDb()) && !data8.isPathFlag()){
				 				         sw.createCell(++cellCount8,data8.getBomLevel());
				 				         if(data8.isConsumFlag()){
										  sw.createCell(++cellCount8,data8.getConsumState());
										 }
				 				         sw.createCell(++cellCount8,data8.getPartName());
				 				         sw.createCell(++cellCount8,data8.getParentName());
				 				         sw.createCell(++cellCount8,data8.getBomRevision());
				 				         sw.createCell(++cellCount8,data8.getDescription());
				 				         sw.createCell(++cellCount8,data8.getQuantity());
				 				         sw.createCell(++cellCount8,data8.getProdStatus());
				 				         sw.createCell(++cellCount8,data8.getState());
										data8.setPathFlag(true);
										index8++;
										break;
									  }else if(part7.equals(data8.getPartName()+PLMConstants.TILDA_SYMBOL+data8.getQuantityDb()) && !data8.isPathFlag()){
				 				         sw.createCell(++cellCount8,data8.getBomLevel());
				 				         if(data8.isConsumFlag()){
										  sw.createCell(++cellCount8,data8.getConsumState());
										 }
				 				         sw.createCell(++cellCount8,data8.getPartName());
				 				         sw.createCell(++cellCount8,data8.getParentName());
				 				         sw.createCell(++cellCount8,data8.getBomRevision());
				 				         sw.createCell(++cellCount8,data8.getDescription());
				 				         sw.createCell(++cellCount8,data8.getQuantity());
				 				         sw.createCell(++cellCount8,data8.getProdStatus());
				 				         sw.createCell(++cellCount8,data8.getState());
										data8.setPathFlag(true);
										index8++;
										break;
									  }
						 		 }
							 } 
						  }
						 
						 sw.endRow();
						 rowCount++;
				  }
					 
					 bomData1.clear();
					 bomData2.clear();
					 bomData3.clear();
					 bomData4.clear();
					 bomData5.clear();
					 bomData6.clear();
					 bomData7.clear();
					 bomData8.clear();
					 for(int cnt=0; cnt < partDataList.size(); cnt++){
						((TreeMap<String, List<PLMEBomToMBomData>>) bomListMapLcl.get(partDataList.get(cnt))).remove(eid);
					 }
			}
			bomListMapLcl.clear();
			partDataList.clear();
			eidsUniqueMap.clear();
			
			isCompared = true;
			varMap.put("isCompared", isCompared);
			LOG.info("compareEBOMVsMBOMData logic completed");
	}
	
	/**
	 * 
	 * class to sort list of object of type PLMEBomToMBomData
	 * 
	 */
	private static class SortPartNamesQty implements Comparator<PLMEBomToMBomData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;
		/**
		 * used for comparision..
		 */
		public int compare(PLMEBomToMBomData aString,
				PLMEBomToMBomData bString) {
			int result= aString.getPartName().compareTo(bString.getPartName());
		       if (result != 0)
		       {
		           return result;
		       }
		      return aString.getQuantity().compareTo(bString.getQuantity());
		}
	}
	
	/**
	 * @return the plmEBomToMBomService
	 */
	public PLMEBomToMBomServiceIfc getPlmEBomToMBomService() {
		return plmEBomToMBomService;
	}
	/**
	 * @param plmEBomToMBomService the plmEBomToMBomService to set
	 */
	public void setPlmEBomToMBomService(PLMEBomToMBomServiceIfc plmEBomToMBomService) {
		this.plmEBomToMBomService = plmEBomToMBomService;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}
	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}
	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}
	/**
	 * @return the alertEMBoMMessage
	 */
	public String getAlertEMBoMMessage() {
		return alertEMBoMMessage;
	}

	/**
	 * @param alertEMBoMMessage the alertEMBoMMessage to set
	 */
	public void setAlertEMBoMMessage(String alertEMBoMMessage) {
		this.alertEMBoMMessage = alertEMBoMMessage;
	}
	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}
	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}
	/**
	 * @return the userDetails
	 */
	public PLMPwiUserData getUserDetails() {
		return userDetails;
	}
	/**
	 * @param userDetails the userDetails to set
	 */
	public void setUserDetails(PLMPwiUserData userDetails) {
		this.userDetails = userDetails;
	}
	/**
	 * @return the part1
	 */
	public String getPart1() {
		return part1;
	}
	/**
	 * @param part1 the part1 to set
	 */
	public void setPart1(String part1) {
		this.part1 = part1;
	}
	/**
	 * @return the part2
	 */
	public String getPart2() {
		return part2;
	}
	/**
	 * @param part2 the part2 to set
	 */
	public void setPart2(String part2) {
		this.part2 = part2;
	}
	/**
	 * @return the part3
	 */
	public String getPart3() {
		return part3;
	}
	/**
	 * @param part3 the part3 to set
	 */
	public void setPart3(String part3) {
		this.part3 = part3;
	}
	/**
	 * @return the part4
	 */
	public String getPart4() {
		return part4;
	}
	/**
	 * @param part4 the part4 to set
	 */
	public void setPart4(String part4) {
		this.part4 = part4;
	}
	/**
	 * @return the part5
	 */
	public String getPart5() {
		return part5;
	}
	/**
	 * @param part5 the part5 to set
	 */
	public void setPart5(String part5) {
		this.part5 = part5;
	}
	/**
	 * @return the part6
	 */
	public String getPart6() {
		return part6;
	}
	/**
	 * @param part6 the part6 to set
	 */
	public void setPart6(String part6) {
		this.part6 = part6;
	}
	/**
	 * @return the part7
	 */
	public String getPart7() {
		return part7;
	}
	/**
	 * @param part7 the part7 to set
	 */
	public void setPart7(String part7) {
		this.part7 = part7;
	}
	/**
	 * @return the part8
	 */
	public String getPart8() {
		return part8;
	}
	/**
	 * @param part8 the part8 to set
	 */
	public void setPart8(String part8) {
		this.part8 = part8;
	}
	/**
	 * @return the bomType1
	 */
	public String getBomType1() {
		return bomType1;
	}
	/**
	 * @param bomType1 the bomType1 to set
	 */
	public void setBomType1(String bomType1) {
		this.bomType1 = bomType1;
	}
	/**
	 * @return the bomType2
	 */
	public String getBomType2() {
		return bomType2;
	}
	/**
	 * @param bomType2 the bomType2 to set
	 */
	public void setBomType2(String bomType2) {
		this.bomType2 = bomType2;
	}
	/**
	 * @return the bomType3
	 */
	public String getBomType3() {
		return bomType3;
	}
	/**
	 * @param bomType3 the bomType3 to set
	 */
	public void setBomType3(String bomType3) {
		this.bomType3 = bomType3;
	}
	/**
	 * @return the bomType4
	 */
	public String getBomType4() {
		return bomType4;
	}
	/**
	 * @param bomType4 the bomType4 to set
	 */
	public void setBomType4(String bomType4) {
		this.bomType4 = bomType4;
	}
	/**
	 * @return the bomType5
	 */
	public String getBomType5() {
		return bomType5;
	}
	/**
	 * @param bomType5 the bomType5 to set
	 */
	public void setBomType5(String bomType5) {
		this.bomType5 = bomType5;
	}
	/**
	 * @return the bomType6
	 */
	public String getBomType6() {
		return bomType6;
	}
	/**
	 * @param bomType6 the bomType6 to set
	 */
	public void setBomType6(String bomType6) {
		this.bomType6 = bomType6;
	}
	/**
	 * @return the bomType7
	 */
	public String getBomType7() {
		return bomType7;
	}
	/**
	 * @param bomType7 the bomType7 to set
	 */
	public void setBomType7(String bomType7) {
		this.bomType7 = bomType7;
	}

	/**
	 * @return the bomType8
	 */
	public String getBomType8() {
		return bomType8;
	}
	/**
	 * @param bomType8 the bomType8 to set
	 */
	public void setBomType8(String bomType8) {
		this.bomType8 = bomType8;
	}

	/**
	 * @return the bomsFlag
	 */
	public boolean isBomsFlag() {
		return bomsFlag;
	}

	/**
	 * @param bomsFlag the bomsFlag to set
	 */
	public void setBomsFlag(boolean bomsFlag) {
		this.bomsFlag = bomsFlag;
	}

}
