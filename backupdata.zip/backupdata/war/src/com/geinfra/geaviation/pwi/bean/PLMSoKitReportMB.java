/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMSoKitReportMB.java
 * @Creation date: 01-Jan-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.data.PLMSoKitReportData;
import com.geinfra.geaviation.pwi.service.PLMSoKitReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMSoKitReportMB {
	
	/**
	 * Holds the Loggger
	 */
	private static final Logger LOG = Logger.getLogger(PLMSoKitReportMB.class);
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;

	/**
	 * Holds the plmGenSOKitReportService
	 */
	private PLMSoKitReportServiceIfc plmSoKitReportService = null;
	/**
	 * Holds the plmGenSOKitReportData
	 */
	private PLMSoKitReportData plmGenSOKitReportData = null;
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor=null;
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage="";
	
	private PLMLoginData userDataObj = (PLMLoginData) PLMUtils
	.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA);
	
	/**
	 * Holds the genSOKitRptDataList
	 */
	private List<PLMSoKitReportData> genSOKitRptDataList=new ArrayList<PLMSoKitReportData>();
	/**
	 * Holds the genSOKitRptDataList
	 */
	private List<PLMSoKitReportData> partDataList=new ArrayList<PLMSoKitReportData>();
	/**
	 * Holds the genSOKitRptDataCount
	 */
	private int genSOKitRptDataCount = 0;
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	
	/**
	 * Holds user details
	 */
	private PLMPwiUserData userDetails;
	
	private List<String> requiredParts;
	
	/**
	 * This constructor is used for user details
	 * 
	 * @return String
	 */
	public PLMSoKitReportMB() {
		try {
			userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		} catch (PWiException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This method is used for Loading GeneratorSOKitReportPage
	 * 
	 * @return String
	 */
	public String loadGeneratorSOKitReportPage() {
		LOG.info("Entering loadGeneratorSOKitReportPage Method");
		
		try {
			commonMB.insertCannedRptRecordHitInfo("SO Kit-BOM Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			//plmGenSOKitReportService = new PLMGenSOKitReportServiceImpl();
			plmGenSOKitReportData = new PLMSoKitReportData();
			plmGenSOKitReportData.setInputRadio("AccordSalesOrderNumber");
			alertMessage = "";
			
			} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@loadGeneratorSOKitReportPage:", exception);
		}
		LOG.info("Exiting loadGeneratorSOKitReportPage Method");
		return "genSOKitRptSearch";
	}
	
	public String resetData(){
		plmGenSOKitReportData.setErpNo("");
		plmGenSOKitReportData.setInputRadio("AccordSalesOrderNumber");
		alertMessage = "";
		
		return "genSOKitRptSearch";
	}
	
	 /**
	 * This method is used for sendEmail
	 * 
	 */
	public void sendEmail(){
		if(!PLMUtils.isEmpty(plmGenSOKitReportData.getErpNo()))
		{
		alertMessage = PLMConstants.GENSOKITRPT_MAIL_ALERT_MSG;
		taskExecutor.execute(new GenSOKitRptEmailThread());
		}else{
		alertMessage = PLMConstants.ENTER_ERP_NUM;
		}
		}
	/**
	 * Background Process Thread
	 */
	private class GenSOKitRptEmailThread implements Runnable {
		public GenSOKitRptEmailThread(){}
		public void run() {
			try{
			generateGenSOKitEmailReport();
			}catch (Exception exception) {	
				LOG.log(Level.ERROR, "Exception@run() of GenSOKitRptEmailThread: ", exception);
			}
		}
	}
	 /**
	 * This method is used for generateGBOMEmailReport
	 * 
	 * @return String
	 * @throws Exception 
	 * @throws PLMCommonException
	 */
	public String generateGenSOKitEmailReport() throws Exception {
		LOG.info("Entering generateGenSOKitEmailReport Method");		
		Map<String, Object> varMap = new HashMap<String, Object>();
		
		String toEmailId = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String erpNum =plmGenSOKitReportData.getErpNo();
		varMap.put("erpNum", erpNum);
		varMap.put("inputRadio", plmGenSOKitReportData.getInputRadio());
		
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("GENSOKIT_REPORT_NAME") +  varMap.get("erpNum") + "_" + uniqTime + ".zip";
		
		File file = null;
		int tab1DataLstCnt=0;
		try {
			//Start
			if(!PLMUtils.isEmpty(erpNum))
			{	
			LOG.info("ERP Number entered..inside if...=="+erpNum);
			LOG.info("before fetching the list");
			 Map<String,Object> dataMap = plmSoKitReportService.getGenSOKitRptData(varMap);
			
			tab1DataLstCnt = (Integer) dataMap.get("tab1DataLstCnt");
			String filePathEbom=(String) dataMap.get("filePathEbom");;
			String filePathErp=(String) dataMap.get("filePathErp");;
							
			if(tab1DataLstCnt!=0){
				
			genSOKitRptDataCount=genSOKitRptDataList.size();
			LOG.info("Inside MB, fetched tab1DataList with size====="+tab1DataLstCnt);
				
			generateZipFile(filePathErp,filePathEbom,filePathZip);
			file = new File(filePathZip);
			// Get the number of bytes in the file
			float sizeInBytes = file.length();
			//transform in MB
			float sizeInMb = sizeInBytes / (1024 * 1024);
			LOG.info("Zip File Size for Cost Chng Report "+sizeInMb+" MB");
			LOG.info("After generating the ZIP File........");
			varMap.put("filePathZip", filePathZip);
			sendGenSOKitRptMail(varMap);
			deleteFiles(filePathErp,filePathEbom,filePathZip);
			}else{
				StringBuffer noDataMailBody = new StringBuffer().append(toAddressee);
				noDataMailBody.append(PLMConstants.GENSOKITRPT_NO_CONTENT_BODY+"\n");
				noDataMailBody.append("Search Criteria"+"\n");
				noDataMailBody.append("---------------"+"\n");
				noDataMailBody.append("PLM SO # / ERP EPN # : "+erpNum+"\n");
				
				StringBuffer subject = new StringBuffer().append(PLMConstants.GENSOKITRPT_MAIL_SUBJECT);
				subject.append("- PLM SO # / ERP EPN # : "+erpNum);
				
				noDataMailBody.append(PLMConstants.GBOM_MAIL_SIGNATURE)
				.append(PLMConstants.GBOM_MAIL_FOOTER);
				PLMUtils.sendMail(PLMConstants.BVS_MAIL_FROM, toEmailId, subject.toString(), noDataMailBody.toString());
				LOG.info("No data mail has been sent");
			}
		}
		//End
		} catch (IOException ioexception) {	
			LOG.log(Level.ERROR, "Exception@generateGenSOKitEmailReport: ", ioexception);
			PLMUtils.checkExceptionAndMail(ioexception.getMessage(),PLMConstants.BVS_MAIL_FROM,toEmailId,PLMConstants.GENSOKITRPT_MAIL_SUBJECT,toAddressee,PLMConstants.COST_CHG_MAIL_SIGNATURE);
		} catch (PLMCommonException exception) {
			String fwdflag="";
			LOG.log(Level.ERROR, "Exception@generateGenSOKitEmailReport: ",
					exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "genSOKitRptSearch", "Generator SO Kit Report");
			LOG.info("exception.getMessage()---------------->"+exception.getMessage());
			PLMUtils.checkExceptionAndMail(exception.getMessage(),PLMConstants.BVS_MAIL_FROM,toEmailId,PLMConstants.GENSOKITRPT_MAIL_SUBJECT,toAddressee,PLMConstants.COST_CHG_MAIL_SIGNATURE);
			return fwdflag;
		}
		
		LOG.info("Exiting generateGenSOKitEmailReport Method");
		return"genSOKitRptSearch";
	}
	
	/**
	 * This method is used for generating zip file
	 * 
	 * @return void
	 */
	public static void generateZipFile(String filePathXls,String filePathXls1,String filePathZip) throws IOException {
		LOG.info("Entering generateZipFile method in MB");
		FileOutputStream fileOut = null;
		BufferedOutputStream bufferOut = null;
		ZipOutputStream zipOut = null;
		//BufferedInputStream bufferIn = null;
		FileInputStream fileIn = null;
		FileInputStream fileIn1 = null;
		File xlsFile = new File(filePathXls); 
		File xlsFile1 = new File(filePathXls1);
		try {
			fileOut = new FileOutputStream(filePathZip);
			bufferOut = new BufferedOutputStream(fileOut);
			zipOut = new ZipOutputStream(bufferOut);
			fileIn = new FileInputStream(filePathXls);
			fileIn1 = new FileInputStream(filePathXls1);
			int count;
			byte[] data = new byte[1000];
			zipOut.putNextEntry(new ZipEntry(xlsFile.getName()));
			while((count = fileIn.read(data,0,1000)) != -1){  
			zipOut.write(data, 0, count);
			}
			
			zipOut.putNextEntry(new ZipEntry(xlsFile1.getName()));
			while((count = fileIn1.read(data,0,1000)) != -1){  
			zipOut.write(data, 0, count);
			}
			zipOut.flush();
			zipOut.close();
   		 }catch (FileNotFoundException e) {
			 LOG.log(Level.ERROR, "FileNotFoundException@generateZipFile: ", e);
			 throw e;
		 }catch (IOException e) {
			 LOG.log(Level.ERROR, "IOException@generateZipFile: ", e);
			 throw e;
		 }finally {
				try {
					if (bufferOut != null) {
						bufferOut.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@generateZipFile: closing bufferOut", e);
					throw e;
				} finally {
					try {
					if (zipOut != null) {
						zipOut.close();
					}
					} catch(IOException ie){
						LOG.log(Level.ERROR, "Exception@generateZipFile: closing zipOut", ie);
						throw ie;
					} finally {
						try{
							if (fileOut != null) {
								fileOut.close();
							}
							
						} catch (IOException ie) {

							LOG.log(Level.ERROR, "Exception@generateZipFile: closing fileOut", ie);
							throw ie;
						} finally {
							try {
								if (fileIn != null) {
									fileIn.close();
								}
								
							} catch(IOException ie) {

								LOG.log(Level.ERROR, "Exception@generateZipFile: closing fileIn", ie);
								throw ie;
							} finally {
								try {
								if (fileIn1 != null) {
									fileIn1.close();
								}
								} catch(IOException ie) {

									LOG.log(Level.ERROR, "Exception@generateZipFile: closing fileIn1", ie);
									throw ie;
								}
							}
						}
					}
					
				}
				
			}
		LOG.info("Exiting generateZipFile Method in MB");
	}
	
	public void deleteFiles(String filePathXls,String filePathXls2,String filePathZip){
		LOG.info("Entering deleteFiles method");
		boolean zipFileExist;
		boolean xlsFileExist;
		boolean xlsFile2Exist;
		File zipFile = new File(filePathZip);
		zipFileExist = zipFile.exists();
		File xlsFile = new File(filePathXls);
		xlsFileExist = xlsFile.exists();
		File xlsFile2 = new File(filePathXls2);
		xlsFile2Exist = xlsFile2.exists();
		if(zipFileExist){
			boolean deleted = zipFile.delete();
			LOG.info("Successfully deleted zip file : " + deleted);
		}
		if(xlsFileExist){
			boolean deleted = xlsFile.delete();
			LOG.info("Successfully deleted CSV1 file : " + deleted);
		}
		if(xlsFile2Exist){
			boolean deleted = xlsFile2.delete();
			LOG.info("Successfully deleted CSV2 file : " + deleted);
		}
		LOG.info("Exiting deleteFiles Method");
	}
	
	/**
	 * This method is used for sendGBOMMail
	 * 
	 * @param varMap
	 * @throws PLMCommonException
	 */
	private void sendGenSOKitRptMail(Map<String, Object> varMap) throws PLMCommonException{
		LOG.info("Entering sendGenSOKitRptMail Method");
		String from = PLMConstants.BVS_MAIL_FROM;
		String toEmailId = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		StringBuffer subject = new StringBuffer().append(PLMConstants.GENSOKITRPT_MAIL_SUBJECT);
		subject.append(" - PLM SO # / ERP EPN # : "+varMap.get("erpNum"));
		StringBuffer mailBody = new StringBuffer().append(toAddressee);
		
		varMap.put("to", toEmailId);
		varMap.put("toAddressee", toAddressee);
		varMap.put("subject", subject.toString());
		mailBody.append(PLMConstants.GENSOKITRPT_MAIL_CONTENT+"\n");
		mailBody.append("Search Criteria"+"\n");
		mailBody.append("---------------"+"\n");
		mailBody.append("PLM SO # / ERP EPN # :"+varMap.get("erpNum")+"\n");
		
		mailBody.append(PLMConstants.GBOM_MAIL_SIGNATURE)
		.append(PLMConstants.GBOM_MAIL_FOOTER);
		PLMUtils.sendMailWithAttachment(from, toEmailId, subject.toString(), mailBody.toString(), (String)varMap.get("filePathZip"));
		LOG.info("Exiting sendGenSOKitRptMail Method");
	}
	
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the plmSoKitReportService
	 */
	public PLMSoKitReportServiceIfc getPlmSoKitReportService() {
		return plmSoKitReportService;
	}

	/**
	 * @param plmSoKitReportService the plmSoKitReportService to set
	 */
	public void setPlmSoKitReportService(
			PLMSoKitReportServiceIfc plmSoKitReportService) {
		this.plmSoKitReportService = plmSoKitReportService;
	}

	/**
	 * @return the plmGenSOKitReportData
	 */
	public PLMSoKitReportData getPlmGenSOKitReportData() {
		return plmGenSOKitReportData;
	}

	/**
	 * @param plmGenSOKitReportData the plmGenSOKitReportData to set
	 */
	public void setPlmGenSOKitReportData(PLMSoKitReportData plmGenSOKitReportData) {
		this.plmGenSOKitReportData = plmGenSOKitReportData;
	}

	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return LOG;
	}

	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the userDataObj
	 */
	public PLMLoginData getUserDataObj() {
		return userDataObj;
	}

	/**
	 * @param userDataObj the userDataObj to set
	 */
	public void setUserDataObj(PLMLoginData userDataObj) {
		this.userDataObj = userDataObj;
	}

	/**
	 * @return the genSOKitRptDataList
	 */
	public List<PLMSoKitReportData> getGenSOKitRptDataList() {
		return genSOKitRptDataList;
	}

	/**
	 * @param genSOKitRptDataList the genSOKitRptDataList to set
	 */
	public void setGenSOKitRptDataList(
			List<PLMSoKitReportData> genSOKitRptDataList) {
		this.genSOKitRptDataList = genSOKitRptDataList;
	}

	/**
	 * @return the genSOKitRptDataCount
	 */
	public int getGenSOKitRptDataCount() {
		return genSOKitRptDataCount;
	}

	/**
	 * @param genSOKitRptDataCount the genSOKitRptDataCount to set
	 */
	public void setGenSOKitRptDataCount(int genSOKitRptDataCount) {
		this.genSOKitRptDataCount = genSOKitRptDataCount;
	}

	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return the partDataList
	 */
	public List<PLMSoKitReportData> getPartDataList() {
		return partDataList;
	}

	/**
	 * @param partDataList the partDataList to set
	 */
	public void setPartDataList(List<PLMSoKitReportData> partDataList) {
		this.partDataList = partDataList;
	}

	/**
	 * @return the requiredParts
	 */
	public List<String> getRequiredParts() {
		return requiredParts;
	}

	/**
	 * @param requiredParts the requiredParts to set
	 */
	public void setRequiredParts(List<String> requiredParts) {
		this.requiredParts = requiredParts;
	}

	

}
