package com.geinfra.geaviation.pwi.bean;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.richfaces.component.html.HtmlDataTable;

import com.geinfra.geaviation.pwi.bean.HistoryView.HistoryItemBean;
import com.geinfra.geaviation.pwi.bean.util.BeanUtil;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.QueryAccessException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.MinimalQueryExctnEventVO;
import com.geinfra.geaviation.pwi.service.HistoryService;

/**
 * 
 * Project : Product Lifecycle Management Date Written : May 21, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : PWiHomeBean
 * 
 * Revision Log May 21, 2010 | v1.0.
 * --------------------------------------------------------------
 */

public class PWiHomeBean extends BaseBean {
	// Injected beans
	private QueriesBean queriesBean;
	private HistoryService historyService;

	private String searchCriteria;
	private List<HistoryItemBean> historyItems;
	private HtmlDataTable historyTable;
	
	public void setQueriesBean(QueriesBean queriesBean) {
		this.queriesBean = queriesBean;
	}

	public void setHistoryService(HistoryService historyService) {
		this.historyService = historyService;
	}

	public List<String> suggestionActionQuerySearch(Object theSearchCriteria)
			throws PWiException {
		return queriesBean.getQuerySearchTypeahead((String) theSearchCriteria);
	}

	public String actionQuerySearch() throws NumberFormatException,
			PWiException, QueryAccessException {
		return queriesBean.querySearch(searchCriteria);
	}

	public String actionCreateFavoriteFromHistory() throws PWiException {
		
		
		
		// Get selected history item
		HistoryItemBean historyItem = (HistoryItemBean) historyTable
				.getRowData();

		// Set history ID into dialog for creating a favorite from history
		FavoriteFromHistoryDialogBean bean = BeanUtil.getInstance()
				.getFavoriteFromHistoryDialogBean();
		bean.setHistoryId(historyItem.getEventId());
		bean.setFavoriteName(historyItem.getQueryName());

		return null;
	}

	public String getSearchCriteria() {

		return searchCriteria;
	}
	
	public void setSearchCriteria(String searchCriteria) {
		if (searchCriteria == null || searchCriteria.trim().equals("")) {
			this.searchCriteria = null;
		} else {
			this.searchCriteria = searchCriteria;
		}
	}

	/**
	 * @return the recentQueryHistoryRs
	 * @throws PWiException
	 * @throws JAXBException
	 */
	public List<HistoryItemBean> getRecentQueryHistoryRs()
			throws JAXBException, PWiException {

		if (historyItems == null) {
			// Get recent query events
			List<MinimalQueryExctnEventVO> recentQueryHistoryRs = historyService
					.getExecutionEvents(getSsoId(), 5);

			// Create history items from query events
			historyItems = new ArrayList<HistoryItemBean>();
			for (MinimalQueryExctnEventVO event : recentQueryHistoryRs) {
				historyItems.add(new HistoryItemBean(event));
			}
		}
		return historyItems;
	}

	public HtmlDataTable getHistoryTable() {
		return historyTable;
	}

	public void setHistoryTable(HtmlDataTable historyTable) {
		this.historyTable = historyTable;
	}
}
