package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;
import java.util.List;

import com.geinfra.geaviation.pwi.common.model.BaseVO;
import com.geinfra.geaviation.pwi.json.JsonBuilder;
import com.geinfra.geaviation.pwi.json.Jsonable;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : QueryGroupVO - Query Group object
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiQueryGroupVO extends BaseVO implements Serializable, Jsonable {
	private static final long serialVersionUID = 1L;
	
	private Integer queryGroupId;
	private String queryGroupName;
	private String queryGroupDescription;
	private List<QueriesVO> queriesList;
	private boolean alwaysShow;
	private String groupDisplayName;
	private Integer queryId;
	/**
	 * @return the queryId
	 */
	public Integer getQueryId() {
		return queryId;
	}

	/**
	 * @param queryId the queryId to set
	 */
	public void setQueryId(Integer queryId) {
		this.queryId = queryId;
	}

	/**
	 * @return the grpDispName
	 */
	public String getGroupDisplayName() {
		return groupDisplayName;
	}

	/**
	 * @param groupDisplayName
	 *            the grpDispName to set
	 */
	public void setGroupDisplayName(String groupDisplayName) {
		this.groupDisplayName = groupDisplayName;
	}

	/**
	 * @return the queryGroupName
	 */
	public String getQueryGroupName() {
		return queryGroupName;
	}

	/**
	 * @param queryGroupName
	 *            the queryGroupName to set
	 */
	public void setQueryGroupName(String queryGroupName) {
		this.queryGroupName = queryGroupName;
	}

	/**
	 * @return the queryGroupDescription
	 */
	public String getQueryGroupDescription() {
		return queryGroupDescription;
	}

	/**
	 * @param queryGroupDescription
	 *            the queryGroupDescription to set
	 */
	public void setQueryGroupDescription(String queryGroupDescription) {
		this.queryGroupDescription = queryGroupDescription;
	}

	/**
	 * @return the queriesList
	 */
	public List<QueriesVO> getQueriesList() {
		return queriesList;
	}

	/**
	 * @param queriesList
	 *            the queriesList to set
	 */
	public void setQueriesList(List<QueriesVO> queriesList) {
		this.queriesList = queriesList;
	}

	public boolean isAlwaysShow() {
		return alwaysShow;
	}

	public void setAlwaysShow(boolean alwaysShow) {
		this.alwaysShow = alwaysShow;
	}

	/**
	 * @return the queryGroupId
	 */
	public Integer getQueryGroupId() {
		return queryGroupId;
	}

	/**
	 * @param queryGroupId
	 *            the queryGroupId to set
	 */
	public void setQueryGroupId(Integer queryGroupId) {
		this.queryGroupId = queryGroupId;
	}

	public String toString() {
		if (queryGroupId == null && queryGroupName == null
				&& queryGroupDescription == null) {
			return "";
		} else {
			return new StringBuffer().append(queryGroupId).append("$")
					.append(queryGroupName).append("$")
					.append(queryGroupDescription).toString();
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * ((queryGroupId == null) ? 0 : queryGroupId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		boolean retval = true;
		if (null != obj) {
			if (getClass() != obj.getClass()) {
				retval = false;
			} else {
				final PWiQueryGroupVO other = (PWiQueryGroupVO) obj;
				if (other.queryGroupId != null) {
					retval = this.queryGroupId.equals(other.queryGroupId);
				} else {
					retval = false;
				}
			}
		} else {
			retval = false;
		}

		return retval;
	}

	public String toJson() {
		JsonBuilder builder = new JsonBuilder();
		builder.startObject();
		builder.addStringProperty("id", queryGroupId);
		builder.addStringProperty("name", queryGroupName);
		builder.addStringProperty("displayName", groupDisplayName);
		builder.addStringProperty("description", queryGroupDescription); // TODO pH 2013.03: ensure this is here for the queries page
		builder.endObject();
		return builder.toString();
	}
}
