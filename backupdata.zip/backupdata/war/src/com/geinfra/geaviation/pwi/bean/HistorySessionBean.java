package com.geinfra.geaviation.pwi.bean;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.geinfra.geaviation.pwi.bean.HistoryView.HistoryItemBean;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;

/**
 * 
 * Project : Product Lifecycle Management Date Written : May 21, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Stored
 * 
 * Revision Log May 21, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class HistorySessionBean extends BaseBean {
	private static final int DAYS_TO_ADD_FOR_DATE_RUN_DEFAULT = -30;

	private Date dateRunSince;
	private List<HistoryItemBean> historyItems;

	public Date getDateRunSince() {

		if (dateRunSince == null) {
			
			// Set to 30 days ago by default
			Calendar cal = Calendar.getInstance();
			cal.setTime(new Date());
			cal.add(Calendar.DAY_OF_MONTH, DAYS_TO_ADD_FOR_DATE_RUN_DEFAULT);
			dateRunSince = cal.getTime();
		}
		return new Date(dateRunSince.getTime());
	}

	public void setDateRunSince(Date dateRunSince) {
		this.dateRunSince = dateRunSince != null ? new Date(dateRunSince
				.getTime()) : null;
	}

	public List<HistoryItemBean> getHistoryItems() {
		return historyItems;
	}

	public void setHistoryItems(List<HistoryItemBean> historyItems) {
		this.historyItems = historyItems;
	}
}
