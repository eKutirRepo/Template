/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCopicsSearchDaoIfc.java
 * @Creation date: 03-Nov-2011
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import com.geinfra.geaviation.pwi.data.PLMABITData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public abstract interface PLMCopicsSearchDaoIfc
{
	/**
	 * This method is used to getSearchDetails
	 * @param paramString1, paramString2, paramString3
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
  public abstract List<PLMABITData> getSearchDetails(String paramString1, String paramString2, String paramString3)
    throws PLMCommonException;

  
}