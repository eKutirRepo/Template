/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMDashboardDaoImpl.java
 * @Creation date: 4-April-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMDwgDashboardData;
import com.geinfra.geaviation.pwi.data.PLMkpiCostEngData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMMetricsQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMDashboardDaoImpl extends SimpleJdbcDaoSupport implements PLMDashboardDaoIfc{
	
	/**
	 * Holds the Logger.
	 */
	private static final Logger LOG = Logger.getLogger(PLMDashboardDaoImpl.class);
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
		 
	}
	/**
	 * This method is used to getDropDownData
	 * @return List
	 * @param dashboardData, dashboardDetailList, selectedContractNamesList, activeTask
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getDropDownData() throws PLMCommonException {
		Map<String, List<SelectItem>> dropDownDataMap = new HashMap<String, List<SelectItem>>();
		List<SelectItem> contractNamesList = null;
		
		try{
		LOG.info("Query to get ContractName is: " + PLMMetricsQueries.GET_DASHBOARD_CONTRACT_NAME_LIST);
		contractNamesList = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_DASHBOARD_CONTRACT_NAME_LIST, new ContractNameListMapper());
		
		dropDownDataMap.put("contractNamesList", contractNamesList);
		
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return dropDownDataMap;
	}
	
	/**
	 * @return SelectItem objects.
	 */
	private static final class ContractNameListMapper implements ParameterizedRowMapper<SelectItem> {
//	private static ParameterizedRowMapper<SelectItem> contractNameListMapper = new ParameterizedRowMapper<SelectItem>() {
		public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
	   SelectItem selectItem = new SelectItem(rs.getString("CONTRACT_NAME"));
		return selectItem;
		}
	}
	
	/**
	 * This method is used to loadDwgDashboardReport
	 * @return List
	 * @param dashboardData, dashboardList, selectedContractNamesList, activeTask
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMDwgDashboardData> loadDwgDashboardReport(PLMDwgDashboardData dashboardData,List<PLMDwgDashboardData> dashboardList,List<String> selectedContractNamesList,boolean activeTask) throws PLMCommonException {
		LOG.info("Entering loadDwgDashboardReport of DaoImpl");
		List<PLMDwgDashboardData> dashbrdDataList =new ArrayList<PLMDwgDashboardData>();
		Map<String, Object> params = new HashMap<String, Object>();
		try{
		
			if(!activeTask){
			params.put("CNTR", selectedContractNamesList);
			LOG.info("Executed Query:"+PLMMetricsQueries.GET_DWG_DASHBOARD1);
			dashbrdDataList = getNamedJdbcTemplate().query(PLMMetricsQueries.GET_DWG_DASHBOARD1, params, new DwgDashboardMapper());
			}
			if(activeTask){
				params.put("CNTR", selectedContractNamesList);
				LOG.info("Executed Query:"+PLMMetricsQueries.GET_DWG_DASHBOARD2);
				dashbrdDataList = getNamedJdbcTemplate().query(PLMMetricsQueries.GET_DWG_DASHBOARD2, params, new DwgDashboardMapper());
				}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Dashboard Percent data fetched successfully:"+dashbrdDataList.size()+" Records fetched...");
		LOG.info("Exiting loadDwgDashboardReport of DaoImpl");
		return dashbrdDataList;
	}
	/**
	 * @return PLMDwgDashboardData objects.
	 */
	private static final class DwgDashboardMapper implements ParameterizedRowMapper<PLMDwgDashboardData> {
//	private static ParameterizedRowMapper<PLMDwgDashboardData> dwgdashboardmapper = new ParameterizedRowMapper<PLMDwgDashboardData>() {
	public PLMDwgDashboardData mapRow(ResultSet rs, int rowCount)	throws SQLException {
		PLMDwgDashboardData tempdashboardldata = new PLMDwgDashboardData();
		
		String tskTypFull = "";
		tskTypFull=PLMUtils.checkNullVal(rs.getString("TASK_TYPE"));
        String tskTypDesc1 = "";
        String tskTypDesc2 = "";
        if(tskTypFull.equalsIgnoreCase("CUSTOMER_DRWGS")){
              
              tskTypFull="CLIN DELVS.";
              tskTypDesc1="(Customer";
              tskTypDesc2="Drawings)";
        }
        else{
              tskTypFull="ALL BOM DELVS.";
              tskTypDesc1="(Hardware";
              tskTypDesc2="Drawings)";
        }
        tempdashboardldata.setTskTypFull(tskTypFull);
        tempdashboardldata.setTskTypDesc1(tskTypDesc1);
        tempdashboardldata.setTskTypDesc2(tskTypDesc2);

      
        
		tempdashboardldata.setTskTyp(PLMUtils.checkNullVal(rs.getString("TASK_TYPE")));
		
		tempdashboardldata.setGroup(PLMUtils.checkNullVal(rs.getString("BUSS_GROUP")));
		double perTskCmp1=rs.getDouble("PRCNT_TASKS_COMPLETE");
		double perTskCmp=(double) Math.round(perTskCmp1 * 100) / 100;
		tempdashboardldata.setPercTskCmpl(perTskCmp);
		double perTskOTD1=rs.getDouble("PRCNT_TASKS_OTD");
		double perTskOTD=(double) Math.round(perTskOTD1 * 100) / 100;
		tempdashboardldata.setPercTskOtd(perTskOTD);
		tempdashboardldata.setNumTskLate(PLMUtils.checkNullVal(rs.getString("LATE_BACKLOG")));
		tempdashboardldata.setNumTskToGo(PLMUtils.checkNullVal(rs.getString("NUMB_TASKS_TO_GO")));
		tempdashboardldata.setNumTsk30DyAhead(PLMUtils.checkNullVal(rs.getString("NUMB_TASKS_30_DAYS_AHEAD")));
		tempdashboardldata.setClosedLate(PLMUtils.checkNullVal(rs.getString("CLOSED_LATE")));
		tempdashboardldata.setClosedOnTime(PLMUtils.checkNullVal(rs.getString("CLOSED_ON_TIME")));
		tempdashboardldata.setSumOfDelvs(PLMUtils.checkNullVal(rs.getString("SUM_OF_DELVS")));
		
		
		return tempdashboardldata;
	}
}

/**
 * This method is used to loadDwgDashboardDetailReport
 * @return List
 * @param dashboardData, dashboardDetailList, selectedContractNamesList, activeTask
 * @throws PLMCommonException
 */
@SuppressWarnings("unchecked")
public List<PLMDwgDashboardData> loadDwgDashboardDetailReport(PLMDwgDashboardData dashboardData,List<PLMDwgDashboardData> dashboardDetailList,List<String> selectedContractNamesList,boolean activeTask) throws PLMCommonException {
	LOG.info("Entering loadDwgDashboardReport of DaoImpl");
	List<PLMDwgDashboardData> dashboardDtlList = new ArrayList<PLMDwgDashboardData>();
	try{
	String selectedGrp=dashboardData.getSelectedGroup();
	String selectedTskType=dashboardData.getSelectedTaskType();
	String selectedTskStatus=dashboardData.getSelectedTaskStatus();
	
	String selectedContractNames=PLMUtils.setListForQuery(selectedContractNamesList);
	Map<String, Object> params = new HashMap<String, Object>();
	LOG.info("selectedGrp"+selectedGrp);
	LOG.info("selectedTskType"+selectedTskType);
	LOG.info("selectedTskStatus"+selectedTskStatus);
	LOG.info("selectedContractNames"+selectedContractNames);
	LOG.info("activeTask Selected:"+activeTask);
	String[] tskTypArr = selectedTskStatus.split(",");
	
	List<String> taskStsLst = Arrays.asList(tskTypArr);
	
	params.put("BSGRP",   dashboardData.getSelectedGroup());
	params.put("TSKTYP",  dashboardData.getSelectedTaskType());
	params.put("TSKST",  taskStsLst);
	params.put("CNT", selectedContractNamesList);
	
	 if(!activeTask){
	   LOG.info("Executed Query: "+PLMMetricsQueries.GET_DWG_DASHBOARD_DETAILS1);
	    dashboardDtlList = getNamedJdbcTemplate().query(PLMMetricsQueries.GET_DWG_DASHBOARD_DETAILS1,params,new DwgDashboardDetailMapper());
	 }else {
	    LOG.info("Executed Query: "+PLMMetricsQueries.GET_DWG_DASHBOARD_DETAILS2);
	    dashboardDtlList = getNamedJdbcTemplate().query(PLMMetricsQueries.GET_DWG_DASHBOARD_DETAILS2,params, new DwgDashboardDetailMapper());
     }
	}catch(DataAccessException e){
		PLMUtils.checkException(e.getMessage());
	}
	
	LOG.info("Details data fetched successfully:"+dashboardDtlList.size()+" Records fetched...");
	LOG.info("Exiting loadDwgDashboardReport of DaoImpl");
	return dashboardDtlList;
}
/**
 * @return PLMDwgDashboardData objects.
 */
private static final class DwgDashboardDetailMapper implements ParameterizedRowMapper<PLMDwgDashboardData> {
//private static ParameterizedRowMapper<PLMDwgDashboardData> dwgdashboarddetailmapper = new ParameterizedRowMapper<PLMDwgDashboardData>() {
	public PLMDwgDashboardData mapRow(ResultSet rs, int rowCount)	throws SQLException {
		PLMDwgDashboardData tempdashboardldata = new PLMDwgDashboardData();
		tempdashboardldata.setTaskType(PLMUtils.checkNullVal(rs.getString("TASK_TYPE")));
		tempdashboardldata.setBussGroup(PLMUtils.checkNullVal(rs.getString("BUSS_GROUP")));
		tempdashboardldata.setTaskStatus(PLMUtils.checkNullVal(rs.getString("TASK_STATUS")));
		tempdashboardldata.setContractName(PLMUtils.checkNullVal(rs.getString("CONTRACT_NAME")));
		tempdashboardldata.setProjectName(PLMUtils.checkNullVal(rs.getString("PROJECT_NAME")));
		tempdashboardldata.setProjectDescription(PLMUtils.checkNullVal(rs.getString("PROJECT_DESCRIPTION")));
		tempdashboardldata.setGeActivityCode(PLMUtils.checkNullVal(rs.getString("GE_ACTIVITY_CODE")));
		tempdashboardldata.setState(PLMUtils.checkNullVal(rs.getString("STATE")));
		tempdashboardldata.setEstimatedFinishDte(PLMUtils.checkNullVal(rs.getString("ESTIMATED_FINISH_DTE")));
		tempdashboardldata.setCstmrNeedDte(PLMUtils.checkNullVal(rs.getString("CSTMR_NEED_DTE")));
		tempdashboardldata.setClinInitialDeliveryDte(PLMUtils.checkNullVal(rs.getString("CLIN_INITIAL_DELIVERY_DTE")));
		tempdashboardldata.setActualFinishDte(PLMUtils.checkNullVal(rs.getString("ACTUAL_FINISH_DTE")));
		tempdashboardldata.setOwnerName(PLMUtils.checkNullVal(rs.getString("OWNER_NAME")));
		tempdashboardldata.setTaskOwnr(PLMUtils.checkNullVal(rs.getString("TASK_OWNR")));
		tempdashboardldata.setGeMfggDeliverableIndr(PLMUtils.checkNullVal(rs.getString("GE_MFGG_DELIVERABLE_INDR")));
		tempdashboardldata.setGeTaskResponsibleUnit(PLMUtils.checkNullVal(rs.getString("GE_TASK_RESPONSIBLE_UNIT")));
		tempdashboardldata.setGeVoucherFundingSource(PLMUtils.checkNullVal(rs.getString("GE_VOUCHER_FUNDING_SOURCE")));
		
		
		
		return tempdashboardldata;
	}
}

	//Newly Added method of 1269 Req for 3.0.10 release
	/**
	 * This method is used to get KPI Cost Eng report details
	 * 
	 * @param dashboardData
	 * @throws PLMCommonException
	 */
	public List<PLMkpiCostEngData> getKPICostEngReport(String ecoEcrName) throws PLMCommonException{
		LOG.info("Entering getKPICostEngReport of DaoImpl");
		List<PLMkpiCostEngData> finalkpiCstEngList = new ArrayList<PLMkpiCostEngData>();
		double wasTargetcst=0;
	    double iTargetcst= 0;
		try{
		LOG.info("Executed Query: "+PLMMetricsQueries.GET_KPI_COST_ENG_DATA);
		
		List<PLMkpiCostEngData> kpiCstEngList = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_KPI_COST_ENG_DATA,new KpiCostEngineMapper(),
				ecoEcrName,ecoEcrName,ecoEcrName,ecoEcrName,ecoEcrName,ecoEcrName);
		
		LOG.info("Details KPI Cost Eng data :"+kpiCstEngList.size()+" Records...");
		
			if(kpiCstEngList.size()>0){
			  for(int i=0;i<kpiCstEngList.size();i++){	
				  PLMkpiCostEngData tempData = new PLMkpiCostEngData();
			     wasTargetcst=wasTargetcst +kpiCstEngList.get(i).getWasTargetCst();
			     iTargetcst= iTargetcst +kpiCstEngList.get(i).getIsTargetCst();
			     
				 tempData.setParentPart(kpiCstEngList.get(i).getParentPart());
				 tempData.setPartLvl(kpiCstEngList.get(i).getPartLvl());
				 tempData.setWasPart(kpiCstEngList.get(i).getWasPart());
				 tempData.setWasPartRev(kpiCstEngList.get(i).getWasPartRev());
				 tempData.setWasPartDesc(kpiCstEngList.get(i).getWasPartDesc());
				 tempData.setWasTargetCst(PLMUtils.convertCostCycle(kpiCstEngList.get(i).getWasTargetCst()));
				 tempData.setIsPart(kpiCstEngList.get(i).getIsPart());
				 tempData.setIsPartRev(kpiCstEngList.get(i).getIsPartRev());
				 tempData.setIsPartDesc(kpiCstEngList.get(i).getIsPartDesc());
				 tempData.setIsTargetCst(PLMUtils.convertCostCycle(kpiCstEngList.get(i).getIsTargetCst()));
				 finalkpiCstEngList.add(tempData);
			   }
			  PLMkpiCostEngData tempData1 = new PLMkpiCostEngData();
			  tempData1.setWasPartDesc("Total Was Target Cost:");
			  tempData1.setWasTargetCst(PLMUtils.convertCostCycle(wasTargetcst));
			  tempData1.setIsPartDesc("Total Is Target Cost:");
			  tempData1.setIsTargetCst(PLMUtils.convertCostCycle(iTargetcst));
			  tempData1.setSumTargetFlag(true);
			  finalkpiCstEngList.add(tempData1);
		  }
		
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getKPICostEngReport of DaoImpl");
		return finalkpiCstEngList;
	}
	
	/**
	 * @return PLMkpiCostEngData objects.
	 */
	private static final class KpiCostEngineMapper implements ParameterizedRowMapper<PLMkpiCostEngData> {
		public PLMkpiCostEngData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMkpiCostEngData tempData = new PLMkpiCostEngData();
			tempData.setParentPart(PLMUtils.checkNullVal(rs.getString("PARENT_PART")));
			tempData.setPartLvl(PLMUtils.checkNullVal(rs.getString("LVL")));
			tempData.setWasPart(PLMUtils.checkNullVal(rs.getString("WAS_PART")));
			tempData.setWasPartRev(PLMUtils.checkNullVal(rs.getString("WAS_PART_REVISON")));
			tempData.setWasPartDesc(PLMUtils.checkNullVal(rs.getString("WAS_PART_DESCRIPTION")));
			tempData.setWasTargetCst(rs.getDouble("WAS_PART_TARGET_COST"));
			tempData.setIsPart(PLMUtils.checkNullVal(rs.getString("IS_PART")));
			tempData.setIsPartRev(PLMUtils.checkNullVal(rs.getString("IS_PART_REVISON")));
			tempData.setIsPartDesc(PLMUtils.checkNullVal(rs.getString("IS_PART_DESCRIPTION")));
			tempData.setIsTargetCst(rs.getDouble("IS_PART_TARGET_COST"));
			return tempData;
		}
	}

	
	

}
 