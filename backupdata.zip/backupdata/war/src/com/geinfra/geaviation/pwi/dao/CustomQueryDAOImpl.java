package com.geinfra.geaviation.pwi.dao;

import java.sql.Clob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

import com.geinfra.geaviation.pwi.model.PWiFrequencyTypeVO;
import com.geinfra.geaviation.pwi.model.PWiUserCustomQueryVO;
import com.geinfra.geaviation.pwi.util.ColumnConstants;
import com.geinfra.geaviation.pwi.util.DaoUtil;
import com.geinfra.geaviation.pwi.util.QueryConstants;
import com.geinfra.geaviation.pwi.util.QueryLoader;

/**
 * Project : Product Lifecycle Management Date Written : Apr 12, 2011 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : CustomQueryDAOImpl
 * 
 * Revision Log Apr 12, 2011 | v1.0.
 * --------------------------------------------------------------
 */
public class CustomQueryDAOImpl implements CustomQueryDAO {
	private static final Logger LOGGER = Logger
			.getLogger(CustomQueryDAOImpl.class);

	// Injected
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public boolean addQueriesAsFavorite(final PWiUserCustomQueryVO vo) {
		boolean retval = false;
		String query = QueryLoader
				.getQuery(QueryConstants.INSERT_PWi_USER_CUSTOM_QUERY_FOR_SEARCH);

		int returnInt = jdbcTemplate.update(query,
				new AddQueriesAsFavoriteSetter(vo));
		if (returnInt > 0) {
			retval = true;
		} else {
			retval = false;
		}
		return retval;
	}
		

	private static class AddQueriesAsFavoriteSetter implements
			PreparedStatementSetter {
		private PWiUserCustomQueryVO vo;

		public AddQueriesAsFavoriteSetter(PWiUserCustomQueryVO vo) {
			this.vo = vo;
		}

		public void setValues(PreparedStatement pstatement)
				throws SQLException {
			pstatement.setString(1, vo.getUsrSsoId());
			pstatement.setInt(2, vo.getQueryId().intValue());
			pstatement.setString(3, vo.getCstmQryNm());
			pstatement.setTimestamp(4,
					new Timestamp(System.currentTimeMillis()));
			pstatement.setString(5, vo.getUsrSsoId());
			pstatement.setString(6, vo.getUsrSsoId());
		}
	}

	public List<PWiFrequencyTypeVO> getSubscriptionFrquencies() {
		final String query = QueryLoader
				.getQuery(QueryConstants.ALL_SUBSCRIPTION_OPTION);

		final ParameterizedRowMapper<PWiFrequencyTypeVO> mapper = new GetSubscriptionFrequenciesMapper();
		@SuppressWarnings("unchecked")
		List<PWiFrequencyTypeVO> qryForUser = (List<PWiFrequencyTypeVO>) jdbcTemplate
				.query(query, mapper);
		return qryForUser;

	}

	private static class GetSubscriptionFrequenciesMapper implements
			ParameterizedRowMapper<PWiFrequencyTypeVO> {
		public PWiFrequencyTypeVO mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PWiFrequencyTypeVO frequencyTypeVO = new PWiFrequencyTypeVO();
			frequencyTypeVO.setFrqncyTypSeqId(Integer.valueOf(rs
					.getInt(ColumnConstants.FRQNCY_TYP_SEQ_ID)));
			frequencyTypeVO.setFrqncyTypNm(rs
					.getString(ColumnConstants.FRQNCY_TYP_NM));
			return frequencyTypeVO;
		}
	}

	public int cancelFavoriteQuerySubscriptionById(String strUserSSOId,
			int prtyCstmQrySeqId) {

		final String query = QueryLoader
				.getQuery(QueryConstants.CANCEL_FAVORITE_QUERY_SUBSCRIPTION_BY_ID);
		return jdbcTemplate.update(query, new Object[] {
				new Timestamp(System.currentTimeMillis()), strUserSSOId,
				Integer.valueOf(prtyCstmQrySeqId) });
	}

	public int modifySubscrptnFavoriteQueriesforUser(String strUserSSOId,
			Integer prtyCstmQrySeqId, Integer frqncyTypSeqId,
			Timestamp nextExeDate, String currQryRsltFlPthTxt,
			String prrQryRsltFlPthTxt) {
		final String query = QueryLoader
				.getQuery(QueryConstants.MODIFY_QUERIES_SUBSCRIPTION_FOR_USER);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 6);
		Date subscriptionEndDate = cal.getTime();
		return jdbcTemplate.update(query, new Object[] { frqncyTypSeqId,
				new Timestamp(System.currentTimeMillis()), strUserSSOId,
				nextExeDate, currQryRsltFlPthTxt, prrQryRsltFlPthTxt,
				prtyCstmQrySeqId, subscriptionEndDate });
	}

	public int deleteFavoriteQueryById(Integer prtyCstmQrySeqId) {
		final String query = QueryLoader
				.getQuery(QueryConstants.DELETE_FAVORITE_QUERY_BY_ID);
		return jdbcTemplate.update(query, new Object[] { prtyCstmQrySeqId });
	}
	
	public int deleteFavoriteQueriesForSearch(String strUserSSOId,
			Integer queryId) {
		final String query = QueryLoader
				.getQuery(QueryConstants.DELETE_FAVORITE_QUERIES_FOR_SEARCH);
		return jdbcTemplate.update(query,
				new Object[] { strUserSSOId, queryId });
	}

	public int insertCustomQuery(final String sso, final Integer queryId,
			final String customName, final String searchXml,
			final String selectedColumnsXml, final String currentResultPath,
			final String previousResultPath, final String queryProcessorId) {
		String query = QueryLoader
				.getQuery(QueryConstants.INSERT_FAV_CUSTOM_QUERY);
		int ret = jdbcTemplate.update(query, new InsertCustomQuerySetter(sso,
				queryId, customName, searchXml, selectedColumnsXml,
				currentResultPath, previousResultPath, queryProcessorId));

		return ret;
	}

	private static class InsertCustomQuerySetter implements
			PreparedStatementSetter {
		private String sso;
		private Integer queryId;
		private String customName;
		private String searchXml;
		private String selectedColumnsXml;
		private String currentResultPath;
		private String previousResultPath;
		private String queryProcessorId;

		public InsertCustomQuerySetter(String sso, Integer queryId,
				String customName, String searchXml, String selectedColumnsXml,
				String currentResultPath, String previousResultPath,
				String queryProcessorId) {
			this.sso = sso;
			this.queryId = queryId;
			this.customName = customName;
			this.searchXml = searchXml;
			this.selectedColumnsXml = selectedColumnsXml;
			this.currentResultPath = currentResultPath;
			this.previousResultPath = previousResultPath;
			this.queryProcessorId = queryProcessorId;
		}

		public void setValues(PreparedStatement pstatement) {
			try {
				pstatement.setString(1, sso);
				pstatement.setInt(2, queryId.intValue());
				pstatement.setString(3, customName);
				pstatement.setTimestamp(4, new Timestamp(System
						.currentTimeMillis()));
				pstatement.setString(5, sso);
				pstatement.setString(6, sso);

				DaoUtil.getInstance().setXmlType(pstatement.getConnection(), pstatement, 7,
						selectedColumnsXml);
				DaoUtil.getInstance().setXmlType(pstatement.getConnection(), pstatement, 8,
						searchXml);

				if (currentResultPath != null) {
					pstatement.setTimestamp(9, new Timestamp(System
							.currentTimeMillis()));
				} else {
					pstatement.setTimestamp(9, null);
				}
				pstatement.setString(10, currentResultPath);
				pstatement.setString(11, previousResultPath);
				pstatement.setString(12, queryProcessorId);
			} catch (SQLException e) {
				LOGGER.error(e.getMessage(), e);
			}

		}
	}

	public List<PWiUserCustomQueryVO> getSubscribedQueries() {
		String sql = getStandardUserCustomQuerySelect()
				+ " WHERE Qry_Sbscrptn_Ind = 'Y' AND Qry_Nxt_Exctn_Dttm BETWEEN (SYSDATE-1) AND (SYSDATE+1)";

		@SuppressWarnings("unchecked")
		List<PWiUserCustomQueryVO> subscriptions = (List<PWiUserCustomQueryVO>) jdbcTemplate
				.query(sql, new UserCustomQueryRowMapper());

		return subscriptions;
	}

	public boolean updateSubscriptionResult(final Integer cstmQrySeqId,
			final Date nxtdt, final String prevFile, final String currFile,
			final String comparisonFile) {
		// Define prepared statement setter
		PreparedStatementSetter pss = new UpdateSubscriptionResultSetter(
				cstmQrySeqId, nxtdt, prevFile, currFile, comparisonFile);

		// Execute update
		int upd = jdbcTemplate.update(QueryLoader
				.getQuery(QueryConstants.UPDATE_USER_CSTM_QRY), pss);

		// Successful if updated at least one row
		boolean success = false;
		if (upd > 0)
			success = true;

		return success;
	}

	private static class UpdateSubscriptionResultSetter implements
			PreparedStatementSetter {
		private Integer cstmQrySeqId;
		private Date nxtdt;
		private String prevFile;
		private String currFile;
		private String comparisonFile;

		public UpdateSubscriptionResultSetter(Integer cstmQrySeqId, Date nxtdt,
				String prevFile, String currFile, String comparisonFile) {
			this.cstmQrySeqId = cstmQrySeqId;
			this.nxtdt = nxtdt;
			this.prevFile = prevFile;
			this.currFile = currFile;
			this.comparisonFile = comparisonFile;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setTimestamp(1, new Timestamp(nxtdt.getTime()));
			ps.setString(2, currFile);
			ps.setString(3, prevFile);
			ps.setString(4, comparisonFile);
			if (cstmQrySeqId != null) {
				ps.setInt(5, cstmQrySeqId.intValue());
			} else {
				ps.setNull(5, Types.INTEGER);
			}
		}
	}

	public PWiUserCustomQueryVO getUserCustomQueryById(final Integer customId) {
		String sql = getStandardUserCustomQuerySelect()
				+ " WHERE PRTY_CSTM_QRY_SEQ_ID=?";

		PreparedStatementSetter pss = new GetUserCustomQueryByIdSetter(customId);

		@SuppressWarnings("unchecked")
		List<PWiUserCustomQueryVO> resultList = (List<PWiUserCustomQueryVO>) jdbcTemplate
				.query(sql, pss, new UserCustomQueryRowMapper());
		if (resultList.size() > 1) {
			throw new IllegalStateException(
					"Multiple rows returned for custom query id!  custom id: "
							+ customId);
		}
		if (resultList.isEmpty()) {
			return null;
		}
		return resultList.get(0);
	};

	private static class GetUserCustomQueryByIdSetter implements
			PreparedStatementSetter {
		private Integer customId;

		public GetUserCustomQueryByIdSetter(Integer customId) {
			this.customId = customId;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setInt(1, customId.intValue());
		}
	}

	public List<PWiUserCustomQueryVO> getAllFavoriteQueriesforUser(String sso) {
		String sql = getStandardUserCustomQuerySelect()
				+ " WHERE USR_SSO_ID=? AND QRY_FVRT_IND='Y' ORDER BY UPPER(CSTM_QRY_NM) ASC";

		@SuppressWarnings("unchecked")
		List<PWiUserCustomQueryVO> favorites = (List<PWiUserCustomQueryVO>) jdbcTemplate
				.query(sql, new Object[] { sso },
						new UserCustomQueryRowMapper());

		return favorites;
	}

	/**
	 * Standard row mapper for the user custom query table which maps all
	 * columns from the user custom query table to a user custom query value
	 * object.
	 */
	private static class UserCustomQueryRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			PWiUserCustomQueryVO customVo = new PWiUserCustomQueryVO();
			customVo.setPrtyCstmQrySeqId(Integer.valueOf(rs
					.getInt(PWiUserCustomQueryVO.PRTY_CSTM_QRY_SEQ_ID)));
			customVo
					.setUsrSsoId(rs.getString(PWiUserCustomQueryVO.USR_SSO_ID));
			customVo.setQueryId(Integer.valueOf(rs
					.getInt(PWiUserCustomQueryVO.QRY_SEQ_ID)));
			customVo.setCstmQryNm(rs
					.getString(PWiUserCustomQueryVO.CSTM_QRY_NM));
			Clob selectedColumnsClob = rs
					.getClob(PWiUserCustomQueryVO.QRY_SLCTD_COL_NM);
			if (selectedColumnsClob != null) {
				String xml = selectedColumnsClob.getSubString(1L,
						(int) selectedColumnsClob.length());
				customVo.setQrySlctdColNm(xml);
			}
			Clob searchCriteriaClob = rs
					.getClob(PWiUserCustomQueryVO.QRY_SRCH_CRTR_TXT);
			if (searchCriteriaClob != null) {
				String xml = searchCriteriaClob.getSubString(1L,
						(int) searchCriteriaClob.length());
				customVo.setQrySrchCrtrTxt(xml);
			}
			customVo.setQryCstmDttm(rs
					.getTimestamp(PWiUserCustomQueryVO.QRY_CSTM_DTTM));
			customVo.setQryNxtExctnDttm(rs
					.getTimestamp(PWiUserCustomQueryVO.QRY_NXT_EXCTN_DTTM));
			int freqId = rs
					.getInt(PWiUserCustomQueryVO.QRY_EXCTN_FRQNCY_SEQ_ID);
			customVo.setExecutionFrequencyId(freqId == 0 ? null : Integer
					.valueOf(freqId));
			customVo.setCurrQryRsltFlPthTxt(rs
					.getString(PWiUserCustomQueryVO.CURR_QRY_RSLT_FL_PTH_TXT));
			customVo.setPrrQryRsltFlPthTxt(rs
					.getString(PWiUserCustomQueryVO.PRR_QRY_RSLT_FL_PTH_TXT));
			customVo.setCmprsnRsltFlPthTxt(rs
					.getString(PWiUserCustomQueryVO.CMPRSN_RSLT_FL_PTH_TXT));
			customVo.setQrySbscrptnInd(rs
					.getString(PWiUserCustomQueryVO.QRY_SBSCRPTN_IND));
			customVo.setQryFvrtInd(rs
					.getString(PWiUserCustomQueryVO.QRY_FVRT_IND));
			customVo.setQrySbscrptnEndDttm(rs
					.getTimestamp(PWiUserCustomQueryVO.QRY_SBSCRPTN_END_DTTM));
			customVo.setQryLstExctnDttm(rs
					.getTimestamp(PWiUserCustomQueryVO.QRY_LST_EXCTN_DTTM));
			customVo
					.setSbscrptnLstExctnDttm(rs
							.getTimestamp(PWiUserCustomQueryVO.SBSCRPTN_LST_EXCTN_DTTM));
			customVo.setCrtnDt(rs.getTimestamp(PWiUserCustomQueryVO.CRTN_DT));
			customVo.setCrtdBy(rs.getString(PWiUserCustomQueryVO.CRTD_BY));
			customVo.setLstUpdtDt(rs
					.getTimestamp(PWiUserCustomQueryVO.LST_UPDT_DT));
			customVo.setLstUpdtdBy(rs
					.getString(PWiUserCustomQueryVO.LST_UPDTD_BY));
			customVo.setQueryProcessorId(rs
					.getString(PWiUserCustomQueryVO.QRY_PROCESSOR_NM));

			return customVo;
		}
	}

	private String getStandardUserCustomQuerySelect() {
		StringBuilder builder = new StringBuilder();
		builder
				.append("SELECT PRTY_CSTM_QRY_SEQ_ID,USR_SSO_ID,QRY_SEQ_ID,CSTM_QRY_NM,");
		builder
				.append("XMLSerialize(DOCUMENT QRY_SLCTD_COL_NM AS CLOB) QRY_SLCTD_COL_NM,");
		builder
				.append("XMLSerialize(DOCUMENT QRY_SRCH_CRTR_TXT AS CLOB) QRY_SRCH_CRTR_TXT,");
		builder
				.append("QRY_CSTM_DTTM,QRY_NXT_EXCTN_DTTM,QRY_EXCTN_FRQNCY_SEQ_ID,CURR_QRY_RSLT_FL_PTH_TXT,");
		builder
				.append("PRR_QRY_RSLT_FL_PTH_TXT,CMPRSN_RSLT_FL_PTH_TXT,QRY_SBSCRPTN_IND,QRY_FVRT_IND,");
		builder
				.append("QRY_SBSCRPTN_END_DTTM,QRY_LST_EXCTN_DTTM,SBSCRPTN_LST_EXCTN_DTTM,CRTN_DT,");
		builder
				.append("CRTD_BY,LST_UPDT_DT,LST_UPDTD_BY,QRY_PROCESSOR_NM FROM PLMR.PWi_USER_CUSTOM_QUERY");
		return builder.toString();
	}
}
