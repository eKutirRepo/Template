/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEPEBoMData.java
 * @Creation date: 05-Nov-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMEPEBoMData {

 /**
  * Holds the partId
  */
 private String partId;
 /**
  * Holds the partName
  */
 private String partName;

 /**
  * Holds the partRev
  */
 private String partRev;

 /**
  * Holds the partDesc
  */
 private String partDesc;
 /**
  * Holds the partType
  */
 private String partType;
 
 /**
  * Holds the dfsOrder
  */
 private String dfsOrder;
 
 /**
  * Holds the mli
  */
 private String mli;
 
 /**
  * Holds the partBomLvl
  */
 private String partBomLvl;
 /**
  * Holds the parentPart
  */
 private String parentPart;
 
 /**
  * Holds the partState
  */
 private String partState;
 
 /**
  * Holds the findNum
  */
 private String findNum;

 /**
  * Holds the quantity
  */
 private String quantity;

 /**
  * Holds the uom
  */
 private String uom;
 /**
  * Holds the replacePart
  */
 private String replacePart;
 /**
  * Holds the docBomLvl
  */
 private String docBomLvl;

 /**
  * Holds the docParent
  */
 private String docParent;

 /**
  * Holds the docName
  */
 private String docName;

 /**
  * Holds the logicIndr
  */
 private String logicIndr;
 /**
  * Holds the docRev
  */
 private String docRev;
 /**
  * Holds the docType
  */
 private String docType;
 /**
  * Holds the docState
  */
 private String docState;
 /**
  * Holds the docTitle
  */
 private String docTitle;
 /**
  * Holds the docClass
  */
 private String docClass;
 /**
  * Holds the dwgCrtlCode
  */
 private String dwgCrtlCode;
 /**
  * Holds the exportCntrl
  */
 private String exportCntrl;
 
 /**
  * Holds the docId
  */
 private String docId;
 
 /**
  * Holds the topDocId
  */
 private String topDocId;
 /**
  * Holds the modelValidated
  */
 private String modelValidated;
 /**
  * Holds the mliNew
  */
 private String mliNew;
 /**
  * Holds the geMBPD
  */
 private String geMBPD;
/**
 * @return the partId
 */
public String getPartId() {
	return partId;
}
/**
 * @param partId the partId to set
 */
public void setPartId(String partId) {
	this.partId = partId;
}
/**
 * @return the partName
 */
public String getPartName() {
	return partName;
}
/**
 * @param partName the partName to set
 */
public void setPartName(String partName) {
	this.partName = partName;
}
/**
 * @return the partRev
 */
public String getPartRev() {
	return partRev;
}
/**
 * @param partRev the partRev to set
 */
public void setPartRev(String partRev) {
	this.partRev = partRev;
}
/**
 * @return the partDesc
 */
public String getPartDesc() {
	return partDesc;
}
/**
 * @param partDesc the partDesc to set
 */
public void setPartDesc(String partDesc) {
	this.partDesc = partDesc;
}
/**
 * @return the partType
 */
public String getPartType() {
	return partType;
}
/**
 * @param partType the partType to set
 */
public void setPartType(String partType) {
	this.partType = partType;
}
/**
 * @return the dfsOrder
 */
public String getDfsOrder() {
	return dfsOrder;
}
/**
 * @param dfsOrder the dfsOrder to set
 */
public void setDfsOrder(String dfsOrder) {
	this.dfsOrder = dfsOrder;
}
/**
 * @return the mli
 */
public String getMli() {
	return mli;
}
/**
 * @param mli the mli to set
 */
public void setMli(String mli) {
	this.mli = mli;
}
/**
 * @return the partBomLvl
 */
public String getPartBomLvl() {
	return partBomLvl;
}
/**
 * @param partBomLvl the partBomLvl to set
 */
public void setPartBomLvl(String partBomLvl) {
	this.partBomLvl = partBomLvl;
}
/**
 * @return the parentPart
 */
public String getParentPart() {
	return parentPart;
}
/**
 * @param parentPart the parentPart to set
 */
public void setParentPart(String parentPart) {
	this.parentPart = parentPart;
}
/**
 * @return the partState
 */
public String getPartState() {
	return partState;
}
/**
 * @param partState the partState to set
 */
public void setPartState(String partState) {
	this.partState = partState;
}
/**
 * @return the findNum
 */
public String getFindNum() {
	return findNum;
}
/**
 * @param findNum the findNum to set
 */
public void setFindNum(String findNum) {
	this.findNum = findNum;
}
/**
 * @return the quantity
 */
public String getQuantity() {
	return quantity;
}
/**
 * @param quantity the quantity to set
 */
public void setQuantity(String quantity) {
	this.quantity = quantity;
}
/**
 * @return the uom
 */
public String getUom() {
	return uom;
}
/**
 * @param uom the uom to set
 */
public void setUom(String uom) {
	this.uom = uom;
}
/**
 * @return the replacePart
 */
public String getReplacePart() {
	return replacePart;
}
/**
 * @param replacePart the replacePart to set
 */
public void setReplacePart(String replacePart) {
	this.replacePart = replacePart;
}
/**
 * @return the docBomLvl
 */
public String getDocBomLvl() {
	return docBomLvl;
}
/**
 * @param docBomLvl the docBomLvl to set
 */
public void setDocBomLvl(String docBomLvl) {
	this.docBomLvl = docBomLvl;
}
/**
 * @return the docParent
 */
public String getDocParent() {
	return docParent;
}
/**
 * @param docParent the docParent to set
 */
public void setDocParent(String docParent) {
	this.docParent = docParent;
}
/**
 * @return the docName
 */
public String getDocName() {
	return docName;
}
/**
 * @param docName the docName to set
 */
public void setDocName(String docName) {
	this.docName = docName;
}
/**
 * @return the logicIndr
 */
public String getLogicIndr() {
	return logicIndr;
}
/**
 * @param logicIndr the logicIndr to set
 */
public void setLogicIndr(String logicIndr) {
	this.logicIndr = logicIndr;
}
/**
 * @return the docRev
 */
public String getDocRev() {
	return docRev;
}
/**
 * @param docRev the docRev to set
 */
public void setDocRev(String docRev) {
	this.docRev = docRev;
}
/**
 * @return the docType
 */
public String getDocType() {
	return docType;
}
/**
 * @param docType the docType to set
 */
public void setDocType(String docType) {
	this.docType = docType;
}
/**
 * @return the docState
 */
public String getDocState() {
	return docState;
}
/**
 * @param docState the docState to set
 */
public void setDocState(String docState) {
	this.docState = docState;
}
/**
 * @return the docTitle
 */
public String getDocTitle() {
	return docTitle;
}
/**
 * @param docTitle the docTitle to set
 */
public void setDocTitle(String docTitle) {
	this.docTitle = docTitle;
}
/**
 * @return the docClass
 */
public String getDocClass() {
	return docClass;
}
/**
 * @param docClass the docClass to set
 */
public void setDocClass(String docClass) {
	this.docClass = docClass;
}
/**
 * @return the dwgCrtlCode
 */
public String getDwgCrtlCode() {
	return dwgCrtlCode;
}
/**
 * @param dwgCrtlCode the dwgCrtlCode to set
 */
public void setDwgCrtlCode(String dwgCrtlCode) {
	this.dwgCrtlCode = dwgCrtlCode;
}
/**
 * @return the exportCntrl
 */
public String getExportCntrl() {
	return exportCntrl;
}
/**
 * @param exportCntrl the exportCntrl to set
 */
public void setExportCntrl(String exportCntrl) {
	this.exportCntrl = exportCntrl;
}
/**
 * @return the docId
 */
public String getDocId() {
	return docId;
}
/**
 * @param docId the docId to set
 */
public void setDocId(String docId) {
	this.docId = docId;
}
/**
 * @return the topDocId
 */
public String getTopDocId() {
	return topDocId;
}
/**
 * @param topDocId the topDocId to set
 */
public void setTopDocId(String topDocId) {
	this.topDocId = topDocId;
}
/**
 * @return the modelValidated
 */
public String getModelValidated() {
	return modelValidated;
}
/**
 * @param modelValidated the modelValidated to set
 */
public void setModelValidated(String modelValidated) {
	this.modelValidated = modelValidated;
}
/**
 * @return the mliNew
 */
public String getMliNew() {
	return mliNew;
}
/**
 * @param mliNew the mliNew to set
 */
public void setMliNew(String mliNew) {
	this.mliNew = mliNew;
}
/**
 * @return the geMBPD
 */
public String getGeMBPD() {
	return geMBPD;
}
/**
 * @param geMBPD the geMBPD to set
 */
public void setGeMBPD(String geMBPD) {
	this.geMBPD = geMBPD;
}


}
