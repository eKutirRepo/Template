/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMBoilerShippingBomReportMB.java
 * @Creation date: 21-Feb-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.data.PLMBoilerShipBomReportData;
import com.geinfra.geaviation.pwi.service.PLMBoilerShippingBomReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;


public class PLMBoilerShippingBomReportMB {

	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMBoilerShippingBomReportMB.class);
	private List<SelectItem> projectList = new ArrayList<SelectItem>();
	private List<SelectItem> contractNameList = new ArrayList<SelectItem>();
	private List<SelectItem> topLvlPartList = new ArrayList<SelectItem>();
	private List<SelectItem> topLvlPartListReset = new ArrayList<SelectItem>();
	private List<SelectItem> projectListReset = new ArrayList<SelectItem>();
	private List<SelectItem> projPartList = new ArrayList<SelectItem>();
	private List<SelectItem> projPartListNew = new ArrayList<SelectItem>();
	private List<PLMBoilerShipBomReportData> shippingBomBoilerReportList = new ArrayList<PLMBoilerShipBomReportData>();
	private List<PLMBoilerShipBomReportData> shippingHeaderList = new ArrayList<PLMBoilerShipBomReportData>();
	private boolean showDocRev;
	
	/**
	 * @return the shippingBomBoilerReportList
	 */
	public List<PLMBoilerShipBomReportData> getShippingBomBoilerReportList() {
		return shippingBomBoilerReportList;
	}

	/**
	 * @param shippingBomBoilerReportList the shippingBomBoilerReportList to set
	 */
	public void setShippingBomBoilerReportList(
			List<PLMBoilerShipBomReportData> shippingBomBoilerReportList) {
		this.shippingBomBoilerReportList = shippingBomBoilerReportList;
	}

	/**
	 * @return the plmBoilerShippingBomReportService
	 */
	public PLMBoilerShippingBomReportServiceIfc getPlmBoilerShippingBomReportService() {
		return plmBoilerShippingBomReportService;
	}

	/**
	 * @param plmBoilerShippingBomReportService the plmBoilerShippingBomReportService to set
	 */
	public void setPlmBoilerShippingBomReportService(
			PLMBoilerShippingBomReportServiceIfc plmBoilerShippingBomReportService) {
		this.plmBoilerShippingBomReportService = plmBoilerShippingBomReportService;
	}

	/**
	 * @return the projPartList
	 */
	public List<SelectItem> getProjPartList() {
		return projPartList;
	}

	/**
	 * @param projPartList the projPartList to set
	 */
	public void setProjPartList(List<SelectItem> projPartList) {
		this.projPartList = projPartList;
	}
	
	/**
	 * @return the projPartListNew
	 */
	public List<SelectItem> getProjPartListNew() {
		return projPartListNew;
	}

	/**
	 * @param projPartListNew the projPartListNew to set
	 */
	public void setProjPartListNew(List<SelectItem> projPartListNew) {
		this.projPartListNew = projPartListNew;
	}

	private String totalRecordShippingBomAptMsg;
	private String customerNameHeader;
	private String stationNameHeader;
	private String  unitNoHeader;
	private String  stationLocationHeader;
	private String  contractNameHeader;
	private String  productDescHeader;
	private int recordCounts = PLMConstants.N_15;
	private PLMBoilerShipBomReportData pwiReportvo = new PLMBoilerShipBomReportData();
	private String alertMessage;
	/**
	 * Holds the allOpenPrjName
	 */
	private boolean allOpenPrjName;
	
	/**
	 * Holds the allOpenContractName
	 */
	private boolean allOpenContractName;
	/**
	 * Holds the allOpenTopLvlPart
	 */
	private boolean allOpenTopLvlPart;
	/**
	 * Holds the projectNameList
	 */
	private List<String> selShipBomProjectName = new ArrayList<String>();
	/**
	 * Holds the taskStateList
	 */
	private String selShipBomCntractName = new String();
	private List<String> selShipBomTopLvlPartName = new ArrayList<String>();
	private PLMBoilerShippingBomReportServiceIfc plmBoilerShippingBomReportService = null;
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	
	

	/**
	 * @return the customerNameHeader
	 */
	public String getCustomerNameHeader() {
		return customerNameHeader;
	}

	/**
	 * @param customerNameHeader the customerNameHeader to set
	 */
	public void setCustomerNameHeader(String customerNameHeader) {
		this.customerNameHeader = customerNameHeader;
	}

	/**
	 * @return the stationNameHeader
	 */
	public String getStationNameHeader() {
		return stationNameHeader;
	}

	/**
	 * @param stationNameHeader the stationNameHeader to set
	 */
	public void setStationNameHeader(String stationNameHeader) {
		this.stationNameHeader = stationNameHeader;
	}

	

	/**
	 * @return the unitNoHeader
	 */
	public String getUnitNoHeader() {
		return unitNoHeader;
	}

	/**
	 * @param unitNoHeader the unitNoHeader to set
	 */
	public void setUnitNoHeader(String unitNoHeader) {
		this.unitNoHeader = unitNoHeader;
	}

	/**
	 * @return the stationLocationHeader
	 */
	public String getStationLocationHeader() {
		return stationLocationHeader;
	}

	/**
	 * @param stationLocationHeader the stationLocationHeader to set
	 */
	public void setStationLocationHeader(String stationLocationHeader) {
		this.stationLocationHeader = stationLocationHeader;
	}

	/**
	 * @return the contractNameHeader
	 */
	public String getContractNameHeader() {
		return contractNameHeader;
	}

	/**
	 * @param contractNameHeader the contractNameHeader to set
	 */
	public void setContractNameHeader(String contractNameHeader) {
		this.contractNameHeader = contractNameHeader;
	}

	/**
	 * @return the productDescHeader
	 */
	public String getProductDescHeader() {
		return productDescHeader;
	}

	/**
	 * @param productDescHeader the productDescHeader to set
	 */
	public void setProductDescHeader(String productDescHeader) {
		this.productDescHeader = productDescHeader;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @return the pwiReportvo
	 */
	public PLMBoilerShipBomReportData getPwiReportvo() {
		return pwiReportvo;
	}

	/**
	 * @param pwiReportvo the pwiReportvo to set
	 */
	public void setPwiReportvo(PLMBoilerShipBomReportData pwiReportvo) {
		this.pwiReportvo = pwiReportvo;
	}

	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the allOpenPrjName
	 */
	public boolean isAllOpenPrjName() {
		return allOpenPrjName;
	}

	/**
	 * @param allOpenPrjName the allOpenPrjName to set
	 */
	public void setAllOpenPrjName(boolean allOpenPrjName) {
		this.allOpenPrjName = allOpenPrjName;
	}

	/**
	 * @return the allOpenContractName
	 */
	public boolean isAllOpenContractName() {
		return allOpenContractName;
	}

	/**
	 * @param allOpenContractName the allOpenContractName to set
	 */
	public void setAllOpenContractName(boolean allOpenContractName) {
		this.allOpenContractName = allOpenContractName;
	}

	/**
	 * @return the allOpenTopLvlPart
	 */
	public boolean isAllOpenTopLvlPart() {
		return allOpenTopLvlPart;
	}

	/**
	 * @param allOpenTopLvlPart the allOpenTopLvlPart to set
	 */
	public void setAllOpenTopLvlPart(boolean allOpenTopLvlPart) {
		this.allOpenTopLvlPart = allOpenTopLvlPart;
	}

	/**
	 * @return the selShipBomProjectName
	 */
	public List<String> getSelShipBomProjectName() {
		return selShipBomProjectName;
	}

	/**
	 * @param selShipBomProjectName the selShipBomProjectName to set
	 */
	public void setSelShipBomProjectName(List<String> selShipBomProjectName) {
		this.selShipBomProjectName = selShipBomProjectName;
	}

	/**
	 * @return the selShipBomCntractName
	 */
	public String getSelShipBomCntractName() {
		return selShipBomCntractName;
	}

	/**
	 * @param selShipBomCntractName the selShipBomCntractName to set
	 */
	public void setSelShipBomCntractName(String selShipBomCntractName) {
		this.selShipBomCntractName = selShipBomCntractName;
	}

	/**
	 * @return the selShipBomTopLvlPartName
	 */
	public List<String> getSelShipBomTopLvlPartName() {
		return selShipBomTopLvlPartName;
	}

	/**
	 * @param selShipBomTopLvlPartName the selShipBomTopLvlPartName to set
	 */
	public void setSelShipBomTopLvlPartName(List<String> selShipBomTopLvlPartName) {
		this.selShipBomTopLvlPartName = selShipBomTopLvlPartName;
	}

	/**
	 * @return the plmBoilerReportService
	 */
	public PLMBoilerShippingBomReportServiceIfc getPlmBoilerReportService() {
		return plmBoilerShippingBomReportService;
	}

	/**
	 * @param plmBoilerReportService the plmBoilerReportService to set
	 */
	public void setPlmBoilerReportService(
			PLMBoilerShippingBomReportServiceIfc plmBoilerShippingBomReportService) {
		this.plmBoilerShippingBomReportService = plmBoilerShippingBomReportService;
	}

	/**
	 * @return the projectList
	 */
	public List<SelectItem> getProjectList() {
		return projectList;
	}

	/**
	 * @param projectList the projectList to set
	 */
	public void setProjectList(List<SelectItem> projectList) {
		this.projectList = projectList;
	}

	/**
	 * @return the contractNameList
	 */
	public List<SelectItem> getContractNameList() {
		return contractNameList;
	}

	/**
	 * @param contractNameList the contractNameList to set
	 */
	public void setContractNameList(List<SelectItem> contractNameList) {
		this.contractNameList = contractNameList;
	}

	/**
	 * @return the topLvlPartList
	 */
	public List<SelectItem> getTopLvlPartList() {
		return topLvlPartList;
	}

	/**
	 * @param topLvlPartList the topLvlPartList to set
	 */
	public void setTopLvlPartList(List<SelectItem> topLvlPartList) {
		this.topLvlPartList = topLvlPartList;
	}

	
	/**
	 * @return the totalRecordShippingBomAptMsg
	 */
	public String getTotalRecordShippingBomAptMsg() {
		return totalRecordShippingBomAptMsg;
	}

	/**
	 * @param totalRecordShippingBomAptMsg the totalRecordShippingBomAptMsg to set
	 */
	public void setTotalRecordShippingBomAptMsg(String totalRecordShippingBomAptMsg) {
		this.totalRecordShippingBomAptMsg = totalRecordShippingBomAptMsg;
	}

	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @param recordCounts the recordCounts to set
	 */
	
	public void setRecordCounts(int recordCounts) {
		LOG.info("::::::::::::::::::" + recordCounts);
		PLMUtils.getServletSession(true).setAttribute("RecDropDown",
				recordCounts);
		this.recordCounts = recordCounts;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}


	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}


	/**
	 * This method is used for getProjectNameAndContractNameList
	 *  for project name and contract name
	 * 
	 * @return String
	 */
	public String getProjectNameAndContractNameList()
	{
		LOG.info("getProjectNameAndContractNameList() Method");
		String fwdFlag = "";
		alertMessage = "";
		customerNameHeader="";
		stationNameHeader="";
		unitNoHeader="";
		stationLocationHeader="";
		contractNameHeader="";
		productDescHeader="";
		allOpenPrjName=false;
		allOpenContractName=false;
		allOpenTopLvlPart=false;
		selShipBomProjectName=new ArrayList<String>();
		selShipBomCntractName=new String();
		selShipBomTopLvlPartName=new ArrayList<String>();
		pwiReportvo.setSelectedPrjName("");
		pwiReportvo.setSelectedCntractName("");
		pwiReportvo.setSelectedTopLvlPartName("");
		pwiReportvo.setContractSelctd(false);
		pwiReportvo.setProjectSelctd(false);
		showDocRev = true;
		try {
			 commonMB.insertCannedRptRecordHitInfo("Shipping BOM Report");
			// Map<String, List<SelectItem>> dropdownlist = plmBoilerShippingBomReportService.getProjectNameAndContractNameList();
			// projectList = (List<SelectItem>) dropdownlist.get("projectnamelist");
			 contractNameList = new ArrayList<SelectItem>();
			 projectListReset=projectList;
			 projectList=new ArrayList<SelectItem>();
			// topLvlPartList = (List<SelectItem>) dropdownlist.get("topLvlpartlistreset");
			 topLvlPartListReset=topLvlPartList;
			 topLvlPartList=new ArrayList<SelectItem>();
			fwdFlag = "backlogShipBomRptHome";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getProjectNameAndContractNameList: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Shipping BOM Report");
		} 
		return fwdFlag;
	}
	/**
	 * This method is used for Contract auto complete feature
	 * 
	 * @return String
	 */
	/*public List<String> contractFamilyAutocomplete(Object contractShipBomFamilySuggest) {
		LOG.info("Inside contractFamilyAutocomplete method... PLMBoilerShippingBomReportMB");
		String pref = (String) contractShipBomFamilySuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (contractNameList.size() > 0) {
				for (SelectItem item : contractNameList) {
					if (!item.getLabel().equals("")
							&& item.getLabel().startsWith(
									pref.toUpperCase(Locale.getDefault()))) {
						result.add(item.getLabel());
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@contractFamilyAutocomplete in PLMBoilerShippingBomReportMB:",
					exception);
		}
		LOG.info("Exit from contractFamilyAutocomplete method... PLMBoilerShippingBomReportMB");
		return result;
	}*/
	public void contractFamilyAutocomplete(){
		LOG.info("Entering contractFamilyAutocomplete method");
		try{
			contractNameList=new ArrayList<SelectItem>();
			if(!PLMUtils.isEmpty(pwiReportvo.getSelectedCntractName())){
				contractNameList = plmBoilerShippingBomReportService.contractFamilyAutocomplete(pwiReportvo.getSelectedCntractName().trim());
			if(PLMUtils.isEmptyList(contractNameList)){
				contractNameList=new ArrayList<SelectItem>();
				
				 alertMessage = "No Contracts Found for the Search";
			}
			}else{
				 alertMessage = "Please type some text in the box";
			}
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting contractFamilyAutocomplete method");
	}
	/**
	 * This method is used for Project auto complete feature
	 * 
	 * @return String
	 */
	public List<String> projectFamilyAutocomplete(Object projectShipBomFamilySuggest) {
		LOG.info("Inside projectFamilyAutocomplete method... PLMBoilerShippingBomReportMB");
		String pref = (String) projectShipBomFamilySuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (projectList.size() > 0) {
				for (SelectItem item : projectList) {
					if (!item.getLabel().equals("")
							&& item.getLabel().startsWith(
									pref.toUpperCase(Locale.getDefault()))) {
						result.add(item.getLabel());
						
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@projectFamilyAutocomplete in PLMBoilerShippingBomReportMB:",
					exception);
		}
		LOG.info("Exit from projectFamilyAutocomplete method... PLMBoilerShippingBomReportMB");
		return result;
	}
	/**
	 * This method is used for Top LVL Part auto complete feature
	 * 
	 * @return String
	 */
	public List<String> topLvlPartFamilyAutocomplete(Object topLvlPartShipBomFamilySuggest) {
		LOG.info("Inside topLvlPartFamilyAutocomplete method... PLMBoilerShippingBomReportMB");
		String pref = (String) topLvlPartShipBomFamilySuggest;
		ArrayList<String> result = new ArrayList<String>();
		try {
			if (topLvlPartList.size() > 0) {
				for (SelectItem item : topLvlPartList) {
					if (!item.getLabel().equals("")
							&& item.getLabel().startsWith(
									pref.toUpperCase(Locale.getDefault()))) {
						result.add(item.getValue().toString());
					}
				}
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR,
					"Exception@topLvlPartFamilyAutocomplete in PLMBoilerShippingBomReportMB:",
					exception);
		}
		LOG.info("Exit from topLvlPartFamilyAutocomplete method... PLMBoilerShippingBomReportMB");
		return result;
	}
	/**
	 * This method is used to get Project Information for Contracts
	 * 
	 * @param event
	 */
	public void fetchProjectList(ActionEvent event){
		LOG.info("Entering fetchProjectList method PLMBoilerShippingBomReportMB");
		try{
			topLvlPartList=new ArrayList<SelectItem>();
			 List <PLMBoilerShipBomReportData> projectListData = new ArrayList<PLMBoilerShipBomReportData>();
			 projPartList = new ArrayList<SelectItem>();
			 projectListData = plmBoilerShippingBomReportService.fetchProjectList(selShipBomCntractName);
			 LOG.info("project LIST DATA Size"+projectListData.size());
			 if(projectListData.size()>0)
			 {
				 pwiReportvo.setContractSelctd(true);
			   for(int i=0;i<projectListData.size();i++){
				   projPartList.add(new SelectItem(projectListData.get(i).getProjectName()));
				}
			 }  
			 projectList=projPartList;
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting fetchProjectList method PLMBoilerShippingBomReportMB");
	}
	/**
	 * This method is used to get Top Lvl Part Information for Projects
	 * 
	 * @param event
	 */
	public void fetchTasktList(ActionEvent event){
		LOG.info("Entering fetchTasktList method PLMBoilerShippingBomReportMB");
		try{
			 List <PLMBoilerShipBomReportData> partListData = new ArrayList<PLMBoilerShipBomReportData>();
			 projPartListNew = new ArrayList<SelectItem>();
			 if (allOpenPrjName){
				 if(!PLMUtils.isEmptyList(projectList))
				      {
					 selShipBomProjectName = new ArrayList<String>();
						   for (int i = 0 ; i < projectList.size() ; i++ )
					  	     {
							String requireValue = projectList.get(i).getValue().toString();
							selShipBomProjectName.add(requireValue);
						    }
				      }
			}
			 partListData = plmBoilerShippingBomReportService.fetchTasktList(selShipBomProjectName,projectListReset,allOpenPrjName);
			 LOG.info("Task LIST DATA Size"+partListData.size());
			 if(partListData.size()>0){
				 pwiReportvo.setProjectSelctd(true);
			   for(int i=0;i<partListData.size();i++){
				   projPartListNew.add(new SelectItem(partListData.get(i).getTopLvlPart(),partListData.get(i).getTaskNameDesc()));
				}
			}
			   topLvlPartList =projPartListNew;
		 }catch (Exception e) {
			e.printStackTrace();
		}	
		LOG.info("Exiting fetchTasktList method PLMBoilerShippingBomReportMB");
	}
	
	/**
	 * This method is used for generating report on UI
	 * 
	 * @return String
	 */
	public String generateShippingBomAppReport() {
		LOG.info("get data from generateShippingBomAppReport() Method");
		String fwdFlag = "";
				alertMessage = "";
				totalRecordShippingBomAptMsg="";
				 customerNameHeader="";
				 stationNameHeader="";
				 unitNoHeader="";
				 stationLocationHeader="";
				 contractNameHeader="";
				 productDescHeader="";
		try { 
			if (allOpenContractName){
				 if(!PLMUtils.isEmptyList(contractNameList))
				      {
					 selShipBomCntractName = new String();
						   for (int i = 0 ; i < contractNameList.size() ; i++ )
					  	     {
							String frameValue = contractNameList.get(i).getValue().toString();
							selShipBomCntractName=frameValue;
						    }
				      }
			}
			
			 if (allOpenPrjName){
				 if(!PLMUtils.isEmptyList(projectList))
				      {
					 selShipBomProjectName = new ArrayList<String>();
						   for (int i = 0 ; i < projectList.size() ; i++ )
					  	     {
							String requireValue = projectList.get(i).getValue().toString();
							selShipBomProjectName.add(requireValue);
						    }
				      }
			}
			 
			 if (allOpenTopLvlPart){
				 if(!PLMUtils.isEmptyList(topLvlPartList))
				      {
					 selShipBomTopLvlPartName = new ArrayList<String>();
						   for (int i = 0 ; i < topLvlPartList.size() ; i++ )
					  	     {
							/*String requireValue = topLvlPartList.get(i).getValue().toString().trim().substring(0,
									topLvlPartList.get(i).getValue().toString().trim().indexOf(":"));*/
							   String requireValue = topLvlPartList.get(i).getValue().toString();
							selShipBomTopLvlPartName.add(requireValue);
						    }
				      }
			}
			
			
		alertMessage = validateShippingBomAptReport();
			 if (PLMConstants.EMPTY.equals(alertMessage)) {
				
				 shippingBomBoilerReportList = plmBoilerShippingBomReportService.generateShippingBomAppReport(selShipBomCntractName,allOpenContractName,
						 selShipBomProjectName,allOpenPrjName,selShipBomTopLvlPartName,allOpenTopLvlPart,projectListReset,topLvlPartListReset,showDocRev);
				 shippingHeaderList = plmBoilerShippingBomReportService.getShippingHeaderData(
						 selShipBomCntractName,selShipBomProjectName,allOpenPrjName,selShipBomTopLvlPartName, allOpenTopLvlPart);
				 if(shippingBomBoilerReportList.size()>0){
					 totalRecordShippingBomAptMsg="Total Records of Shipping BOM Report:: "+shippingBomBoilerReportList.size();
					 if(shippingHeaderList.size()>0){
						 customerNameHeader=shippingHeaderList.get(0).getCustomer();
						 stationNameHeader=shippingHeaderList.get(0).getStation();
						 unitNoHeader=shippingHeaderList.get(0).getUnitNo();
						 stationLocationHeader=shippingHeaderList.get(0).getStationLocation();
						 contractNameHeader=shippingHeaderList.get(0).getCntName();
						 productDescHeader=shippingHeaderList.get(0).getProductDesc();
					 }
					 recordCounts = PLMConstants.N_15;
	     		  fwdFlag = "backlogShipBomRptHomeDetails";
				 }
				 else{
					 alertMessage = "No Records Found for the Selected combination";
					 fwdFlag = "backlogShipBomRptHome";
				 }
			 }
			 else{
				 fwdFlag = "backlogShipBomRptHome";
			 }
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@generateShippingBomAppReport: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","Shipping BOM Report");
		} 
		
		return fwdFlag;
	}
	
	/**
	 * reset
	 */
	public void resetShippingBomAppReport(){
		alertMessage = "";
		allOpenPrjName=false;
		allOpenContractName=false;
		allOpenTopLvlPart=false;
		contractNameList=new ArrayList<SelectItem>();
		projectList=new ArrayList<SelectItem>();;
		topLvlPartList=new ArrayList<SelectItem>();
		totalRecordShippingBomAptMsg="";
		customerNameHeader="";
		 stationNameHeader="";
		 unitNoHeader="";
		 stationLocationHeader="";
		 contractNameHeader="";
		 productDescHeader="";
		pwiReportvo.setSelectedPrjName("");
		pwiReportvo.setSelectedCntractName("");
		pwiReportvo.setSelectedTopLvlPartName("");
		selShipBomCntractName = new String();
		selShipBomProjectName = new ArrayList<String>();
		selShipBomTopLvlPartName = new ArrayList<String>();
		pwiReportvo.setContractSelctd(false);
		pwiReportvo.setProjectSelctd(false);
		showDocRev = true;
	}
	
	/**
	 * This method is used for validateBacklogAptReport
	 * 
	 * @return String
	 */
	public String  validateShippingBomAptReport(){
		alertMessage ="";
		if (PLMUtils.isEmpty(selShipBomCntractName)) {
			alertMessage = "*Contract Name Input Selection is mandatory";
		}
		
		return alertMessage;
	}
	
	/**
	 * This method is used for export to Excel of Shipping BOM Report
	 * 
	 */
	public void downloadShipBomSrchExcel() throws PLMCommonException {
		
		LOG.info("Entering downloadShipBomSrchExcel Method");
		String reportName="Shipping BOM Report_".concat(new SimpleDateFormat().format(new Date()));
		String fileName="Shipping BOM Report";
		LOG.info("reportName>>> " +reportName);
		LOG.info("fileName>>> " +fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		PLMXlsxRptColumn[] reportColumns = null;
		
		if (showDocRev) {
			reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("itemNumber", "ITEM NO", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("partNumber", "PART NO", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("quantity", "QUANTITY", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("unitOfMeasure", "U/M", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("description", "DESCRIPTION", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("drawingNumber", "INSTALLATION DRAWING", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("drawingRev", "REV", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("weight", "WEIGHT", FormatType.TEXT, null, null, 25),
                    new PLMXlsxRptColumn("remarks", "REMARK", FormatType.TEXT, null, null, 25),
                    new PLMXlsxRptColumn("wbsNo", "WBS NO.", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("productDesc", "WBS (Task) DESCRIPTION", FormatType.TEXT, null, null, 25)
			};
		} else {
			reportColumns = new PLMXlsxRptColumn[] {
                    new PLMXlsxRptColumn("itemNumber", "ITEM NO", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("partNumber", "PART NO", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("quantity", "QUANTITY", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("unitOfMeasure", "U/M", FormatType.TEXT, null, null, 10),
                    new PLMXlsxRptColumn("description", "DESCRIPTION", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("drawingNumber", "INSTALLATION DRAWING", FormatType.TEXT, null, null, 20),
                    new PLMXlsxRptColumn("weight", "WEIGHT", FormatType.TEXT, null, null, 25),
                    new PLMXlsxRptColumn("remarks", "REMARK", FormatType.TEXT, null, null, 25),
                    new PLMXlsxRptColumn("wbsNo", "WBS NO.", FormatType.TEXT, null, null, 15),
                    new PLMXlsxRptColumn("productDesc", "WBS (Task) DESCRIPTION", FormatType.TEXT, null, null, 25)
			};
		}
			PLMXlsxRptColumn[] critcolumns =
					new PLMXlsxRptColumn[] {
					new PLMXlsxRptColumn("shipBomRpt", "Shipping BOM Report", FormatType.TEXT_HEAD_SHIBOM),
					new PLMXlsxRptColumn("gePower", "GE Power", FormatType.TEXT_HEAD_SHIBOM_POW),
					new PLMXlsxRptColumn("reportDate", "DATE:", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("customer", "Customer:", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("station", "Station:", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("unitNo", "Unit No.:", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("stationLocation", "Station Location:", FormatType.TEXT_NOWRAP),
					new PLMXlsxRptColumn("cntName", "Contract:", FormatType.TEXT_NOWRAP)
					//new PLMXlsxRptColumn("productDesc", "WBS (Task) DESCRIPTION:", FormatType.TEXT_NOWRAP)

					};
			
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			Date date = new Date();
			pwiReportvo.setReportDate(dateFormat.format(date));
			pwiReportvo.setCustomer(shippingHeaderList.get(0).getCustomer());
			pwiReportvo.setStation(shippingHeaderList.get(0).getStation());
			pwiReportvo.setUnitNo(shippingHeaderList.get(0).getUnitNo());
			pwiReportvo.setStationLocation(shippingHeaderList.get(0).getStationLocation());
			pwiReportvo.setCntName(shippingHeaderList.get(0).getCntName());
			//pwiReportvo.setProductDesc(shippingHeaderList.get(0).getProductDesc());
			 
			excelUtil.export(shippingBomBoilerReportList, reportColumns, reportName, fileName, true, critcolumns, pwiReportvo);
		
	}

	/**
	 * @return
	 */
	public List<PLMBoilerShipBomReportData> getShippingHeaderList() {
		return shippingHeaderList;
	}

	/**
	 * @param shippingHeaderList
	 */
	public void setShippingHeaderList(
			List<PLMBoilerShipBomReportData> shippingHeaderList) {
		this.shippingHeaderList = shippingHeaderList;
	}

	/**
	 * @return
	 */
	public boolean isShowDocRev() {
		return showDocRev;
	}

	/**
	 * @param showDocRev
	 */
	public void setShowDocRev(boolean showDocRev) {
		this.showDocRev = showDocRev;
	}
	
}
