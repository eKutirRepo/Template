package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;

import com.geinfra.geaviation.pwi.common.model.BaseVO;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : QueriesVO - Query Object
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 * 2013.02.22 pH  Removed many unused and redundant fields.
 */
public class QueriesVO extends BaseVO implements Serializable {
	private static final long serialVersionUID = 8156276113701554856L;

	private Integer queryId;
	private String queryName;
	private String queryDesc;
	private String queryXML;
	private String qryKeyWrdTxt;
	private boolean isExportControlled;
	private boolean isGeOnly;
	private boolean isPopular;
	private boolean isActive;
	//private boolean selected;
	
	private String queryGroupName;
	private String selectedSubscriptionFrequency;
	private String favoriteQueryID;
	private Object favoriteQryInputParamMap;
	private Object favoriteQryOutputColList;
	private SubscriptionDetails subscriptionDetails;

	public QueriesVO() {
	}

	/**
	 * @param queryName
	 */
	public QueriesVO(String queryName) {
		super();
		this.queryName = queryName;
	}

//	/**
//	 * @return the selectedObjectType
//	 */
//	public String getSelectedObjectType() {
//		return selectedObjectType;
//	}
//
//	/**
//	 * @param selectedObjectType
//	 *            the selectedObjectType to set
//	 */
//	public void setSelectedObjectType(String selectedObjectType) {
//		this.selectedObjectType = selectedObjectType;
//	}

	/**
	 * @return the queryName
	 */
	public String getQueryName() {
		return queryName;
	}

	/**
	 * @param queryName
	 *            the queryName to set
	 */
	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}

	/**
	 * @return the queryXML
	 */
	public String getQueryXML() {
		return queryXML;
	}

	/**
	 * @param queryXML
	 *            the queryXML to set
	 */
	public void setQueryXML(String queryXML) {
		this.queryXML = queryXML;
	}

	/**
	 * @return the queryGroupName
	 */
	public String getQueryGroupName() {
		return queryGroupName;
	}

	/**
	 * @param queryGroupName
	 *            the queryGroupName to set
	 */
	public void setQueryGroupName(String queryGroupName) {
		this.queryGroupName = queryGroupName;
	}

	/**
	 * @return the queryDescription
	 */
	public String getQueryDesc() {
		return queryDesc;
	}

	/**
	 * @param queryDescription
	 *            the queryDescription to set
	 */
	public void setQueryDesc(String queryDescription) {
		this.queryDesc = queryDescription;
	}

	/**
	 * @return the selectedSubscriptionFrequency
	 */
	public String getSelectedSubscriptionFrequency() {
		return selectedSubscriptionFrequency;
	}

	/**
	 * @param selectedSubscriptionFrequency
	 *            the selectedSubscriptionFrequency to set
	 */
	public void setSelectedSubscriptionFrequency(
			String selectedSubscriptionFrequency) {
		this.selectedSubscriptionFrequency = selectedSubscriptionFrequency;
	}

	/**
	 * @return the favoriteQueryID
	 */
	public String getFavoriteQueryID() {
		return favoriteQueryID;
	}

	/**
	 * @param favoriteQueryID
	 *            the favoriteQueryID to set
	 */
	public void setFavoriteQueryID(String favoriteQueryID) {
		this.favoriteQueryID = favoriteQueryID;
	}

	/**
	 * @return the favoriteQryInputParamMap
	 */
	public Object getFavoriteQryInputParamMap() {
		return favoriteQryInputParamMap;
	}

	/**
	 * @param favoriteQryInputParamMap
	 *            the favoriteQryInputParamMap to set
	 */
	public void setFavoriteQryInputParamMap(Object favoriteQryInputParamMap) {
		this.favoriteQryInputParamMap = favoriteQryInputParamMap;
	}

	/**
	 * @return the favoriteQryOutputColList
	 */
	public Object getFavoriteQryOutputColList() {
		return favoriteQryOutputColList;
	}

	/**
	 * @param favoriteQryOutputColList
	 *            the favoriteQryOutputColList to set
	 */
	public void setFavoriteQryOutputColList(Object favoriteQryOutputColList) {
		this.favoriteQryOutputColList = favoriteQryOutputColList;
	}

	/**
	 * @return the subscriptionDetails
	 */
	public SubscriptionDetails getSubscriptionDetails() {
		return subscriptionDetails;
	}

	/**
	 * @param subscriptionDetails
	 *            the subscriptionDetails to set
	 */
	public void setSubscriptionDetails(SubscriptionDetails subscriptionDetails) {
		this.subscriptionDetails = subscriptionDetails;
	}

	/**
	 * @return the queryId
	 */
	public Integer getQueryId() {
		return queryId;
	}

	/**
	 * @param queryId
	 *            the queryId to set
	 */
	public void setQueryId(Integer queryId) {
		this.queryId = queryId;
	}

	/**
	 * @return the qryKeyWrdTxt
	 */
	public String getQryKeyWrdTxt() {
		return qryKeyWrdTxt;
	}

	/**
	 * @param qryKeyWrdTxt
	 *            the qryKeyWrdTxt to set
	 */
	public void setQryKeyWrdTxt(String qryKeyWrdTxt) {
		this.qryKeyWrdTxt = qryKeyWrdTxt;
	}

	@Override
	public int hashCode() {
		final int prime = 89;
		int result = 1;
		result = prime * ((queryId == null) ? 0 : queryId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object instanceof QueriesVO) {
			QueriesVO other = (QueriesVO) object;
			if (this.queryId != null && other.queryId != null) {
				return this.queryId.equals(other.queryId);
			}
		}
		return false;
	}

	public String toString() {
		if (queryId == null || queryName == null) {
			return "";
		} else {
			return queryId + "$" + queryName;
		}
	}

	public void setExportControlled(boolean exportControlled) {
		this.isExportControlled = exportControlled;
	}

	public boolean isExportControlled() {
		return isExportControlled;
	}

	public void setGeOnly(boolean geOnly) {
		this.isGeOnly = geOnly;
	}

	public boolean isGeOnly() {
		return isGeOnly;
	}

	public void setPopular(boolean isPopularLcl) {
		this.isPopular = isPopularLcl;
	}

	public boolean isPopular() {
		return isPopular;
	}
	
	public void setActive(boolean isActiveLcl) {
		this.isActive = isActiveLcl;
	}

	public boolean isActive() {
		return isActive;
	}
	/*public boolean isSelected() {
		return selected;
	}*/


}
