/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMTC5RptDaoImpl.java
 * @Creation date: 27-April-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMTC5FullBomRptData;
import com.geinfra.geaviation.pwi.data.PLMTC5MliRptData;
import com.geinfra.geaviation.pwi.data.PLMTC5RelationsRptData;
import com.geinfra.geaviation.pwi.data.PLMTC5WhUsedRptData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMTC5RptConstants;
import com.geinfra.geaviation.pwi.util.PLMTC5RptQueries;
import com.geinfra.geaviation.pwi.util.PLMTC5RptUtils;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMTC5RptDaoImpl extends SimpleJdbcDaoSupport implements PLMTC5RptDaoIfc{
	private static final Logger LOG = Logger.getLogger(PLMTC5RptDaoImpl.class);

	/**
	 * This method is used to get TC5 Relation Report data
	 * 
	 * @param tc5Code,selRevision
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTC5RelationsRptData> getTC5RelationRpt(String tc5Code,String selRevision)throws PLMCommonException{
		LOG.info("Entering getTC5RelationRpt of DAOImpl");
		List<PLMTC5RelationsRptData> searchResultList = new ArrayList<PLMTC5RelationsRptData>();
		String timeStamp = PLMUtils.volTableFormatDate();
		String VTC5_RELOBJ = PLMTC5RptConstants.VTC5_RELOBJ.concat(timeStamp);
		String VTC5_RELOUT = PLMTC5RptConstants.VTC5_RELOUT.concat(timeStamp);
		StringBuffer createTC5RelObjQry = new StringBuffer();
		StringBuffer createTC5RelOutQry = new StringBuffer();
		StringBuffer finalTC5RelQry = new StringBuffer();
		try{
			LOG.info("tc5Code "+tc5Code);
			LOG.info("selRevision "+selRevision);
			createTC5RelObjQry.append(PLMTC5RptQueries.CREATE_TC5_RELATION_OBJ1.replace(PLMTC5RptConstants.VTC5_RELOBJ, VTC5_RELOBJ));
			createTC5RelObjQry.append(PLMTC5RptUtils.generateQueryTC5CodeRel(" P_OBJECT.CODE ",tc5Code));
			
		/*	if(selRevision.equals(PLMTC5RptConstants.TC5_LAST_REVISIONS)){
				createTC5RelObjQry.append(" AND SUPERSEDED <> '+'");
			}else if(selRevision.equals(PLMTC5RptConstants.TC5_LAST_RELEASE_REVISIONS)){
				createTC5RelObjQry.append(" AND LASTOFF <> '-'");
			}*/
			
			createTC5RelObjQry.append(PLMTC5RptQueries.CREATE_TC5_RELATION_OBJ2);
			createTC5RelObjQry.append(PLMTC5RptUtils.generateQueryTC5CodeRel(" P_OBJECT.CODE ",tc5Code));
			
			/*if(selRevision.equals(PLMTC5RptConstants.TC5_LAST_REVISIONS)){
				createTC5RelObjQry.append(" AND SUPERSEDED <> '+'");
			}else if(selRevision.equals(PLMTC5RptConstants.TC5_LAST_RELEASE_REVISIONS)){
				createTC5RelObjQry.append(" AND LASTOFF <> '-'");
			}*/
			
			createTC5RelObjQry.append(PLMTC5RptQueries.CREATE_TC5_RELATION_OBJ3);
			LOG.info("Executing createTC5 Relation Object Query "+createTC5RelObjQry);
			getJdbcTemplate().execute(createTC5RelObjQry.toString());
			
			createTC5RelOutQry.append(PLMTC5RptQueries.CREATE_TC5_RELATION_OUTPUT.replace(PLMTC5RptConstants.VTC5_RELOUT, VTC5_RELOUT)
					.replace(PLMTC5RptConstants.VTC5_RELOBJ, VTC5_RELOBJ));
			LOG.info("Executing createTC5 Relation Output Query "+createTC5RelOutQry);
			getJdbcTemplate().execute(createTC5RelOutQry.toString());
	
			
			finalTC5RelQry.append(PLMTC5RptQueries.GET_TC5_RELATION_OUTPUT1
					.replace(PLMTC5RptConstants.VTC5_RELOUT, VTC5_RELOUT));
			
			if(selRevision.equals(PLMTC5RptConstants.TC5_LAST_REVISIONS)){
				finalTC5RelQry.append(PLMTC5RptQueries.GET_TC5_RLTN_LAST_REVISION);
			}else if(selRevision.equals(PLMTC5RptConstants.TC5_LAST_RELEASE_REVISIONS)){
				finalTC5RelQry.append(PLMTC5RptQueries.GET_TC5_RLTN_LAST_REL_REVISION);
			}
			
			finalTC5RelQry.append(PLMTC5RptQueries.GET_TC5_RELATION_OUTPUT2);
			
			LOG.info("Executing getting Results for TC5 Relation Output Query "+finalTC5RelQry);
			searchResultList =getSimpleJdbcTemplate().query(finalTC5RelQry.toString(),new TC5RelationRptMapper());
			LOG.info("List of TC5 Relation Data >>> "+searchResultList.size());
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Existing getTC5RelationRpt of DAOImpl");
		return searchResultList;
	
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class TC5RelationRptMapper implements ParameterizedRowMapper<PLMTC5RelationsRptData> {
		public PLMTC5RelationsRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			DateFormat datefrmt = new SimpleDateFormat("yyyy/MM/dd");
			PLMTC5RelationsRptData data = new PLMTC5RelationsRptData();
			Locale loc = Locale.getDefault();
			data.setCode(PLMUtils.checkNullVal(rs.getString("CODE")));
			data.setFrmType(PLMUtils.checkNullVal(rs.getString("FROM_TYPE")));
			data.setFrmVersion(PLMUtils.checkNullVal(rs.getString("FROM_VERSION")));
			data.setFrmIdentifierId(PLMUtils.checkNullVal(rs.getString("FROM_IDENTIFIER_ID")));
			data.setFrmIdentifier(PLMUtils.checkNullVal(rs.getString("FROM_IDENTIFIER")));
			data.setFrmState(PLMUtils.checkNullVal(rs.getString("FROM_STATE")));
			
			Date frmreleaseDt = rs.getDate("FROM_RELEASE");
			if (frmreleaseDt != null) {
				String strFrmreleaseDt = datefrmt.format(frmreleaseDt);
				data.setFrmRelaseDt(strFrmreleaseDt);
				data.setFrmRelaseDtExl(frmreleaseDt);
			}
			data.setFrmDesc(PLMUtils.checkNullVal(rs.getString("FROM_DESCRIPTION")));
			data.setFrmLibelle(PLMUtils.checkNullVal(rs.getString("FROM_LIBELLE")));
			data.setConnRelation(PLMUtils.checkNullVal(rs.getString("RELATION")));
			data.setType(PLMUtils.checkNullVal(rs.getString("TYPE1")));
			data.setVersion(PLMUtils.checkNullVal(rs.getString("VERSION")));
			data.setIdentifierId(PLMUtils.checkNullVal(rs.getString("IDENTIFIER_ID")));
			data.setIdentifier(PLMUtils.checkNullVal(rs.getString("IDENTIFIER")));
			data.setState(PLMUtils.checkNullVal(rs.getString("STATE")));
			
			Date releaseDt = rs.getDate("RELEASE1");
			if (releaseDt != null) {
				String strreleaseDt = datefrmt.format(releaseDt);
				data.setRelease(strreleaseDt);
				data.setReleaseExl(releaseDt);
			}
			data.setDescription(PLMUtils.checkNullVal(rs.getString("DESCRIPTION")));
			data.setLibelle(PLMUtils.checkNullVal(rs.getString("LIBELLE")));
			 if(!PLMUtils.isEmpty(data.getIdentifier())){
				 data.setShowMore("+");
			 }else{
				 data.setShowMore("-");
			 }
			 
			 String dbFrmSprSd = rs.getString("FROM_SUPERSEDED");
			 String dbCSprSd = rs.getString("C_SUPERSEDED");
			 
			 if (dbFrmSprSd!=null) {
				 if(dbFrmSprSd.equals("+")) {
					 data.setFrmClassO(rs.getString("FROM_CLASS0").toLowerCase(loc)+"_p"+".gif");
				 } else {
					 data.setFrmClassO(rs.getString("FROM_CLASS0").toLowerCase(loc)+".gif");
				 }
			 } else {
				 data.setFrmClassO("");
			 }
			 
			 if (dbCSprSd!=null) {
				 if (dbCSprSd.equals("+")) {
					 data.setCssClassO(rs.getString("CSS_C_CLASS0").toLowerCase(loc)+"_p"+".gif");
				 } else {
					 data.setCssClassO(rs.getString("CSS_C_CLASS0").toLowerCase(loc)+".gif");
				 }
			 } else {
				 data.setCssClassO("");
			 }
			 
			/* if(rs.getString("FROM_SUPERSEDED")!=null && rs.getString("FROM_SUPERSEDED").equals("+")){
				 data.setFrmClassO(rs.getString("FROM_CLASS0").toLowerCase()+"_p"+".gif");
			 }else{
				 data.setFrmClassO(rs.getString("FROM_CLASS0").toLowerCase()+".gif");
			 }
			 
			 if(rs.getString("C_SUPERSEDED")!=null && rs.getString("C_SUPERSEDED").equals("+")){
				 data.setCssClassO(rs.getString("CSS_C_CLASS0").toLowerCase()+"_p"+".gif");
			 }else{
				 data.setCssClassO(rs.getString("CSS_C_CLASS0").toLowerCase()+".gif");
			 }*/
			 
			return data;
		}
	}
	
	/**
	 * This method is used for TC5 MLI Report data
	 * 
	 * @param finalQuery
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTC5MliRptData> getTC5MLIReport(String finalQuery, PLMTC5MliRptData srchData)
			throws PLMCommonException {
		LOG.info("Entering getTC5MLIReport of DAOImpl");
		List<PLMTC5MliRptData> searchResultList = null;
		try{
		
			LOG.info("Fetching Results for TC5 MLI Report************");
		searchResultList = getSimpleJdbcTemplate().query(finalQuery, new TC5MLIMapper());
		Collections.sort(searchResultList, new SortTC5MLIReport());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Existing getTC5MLIReport of DAOImpl");
		return searchResultList;
	}

	/**
	 * 
	 * class to sort list of object of type PLMTC5MliRptData
	 * 
	 */
	private static class SortTC5MLIReport implements Comparator<PLMTC5MliRptData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMTC5MliRptData aString,
				PLMTC5MliRptData bString) {
			
			int result= aString.getOpContract().compareTo(bString.getOpContract());
		       if (result != 0)
		       {
		           return result;
		       }
		       result = aString.getOpProject().compareTo(bString.getOpProject());
		       if (result != 0)
		       {
		           return result; 
		       }
		       result = aString.getOpSN().compareTo(bString.getOpSN());
		       if (result != 0)
		       {
		           return result; 
		       }
		       result = aString.getOpSect().compareTo(bString.getOpSect());
		       if (result != 0)
		       {
		           return result; 
		       }
		       result = aString.getOpMLI().compareTo(bString.getOpMLI());
		       if (result != 0)
		       {
		           return result; 
		       }
		      return aString.getOpObjName().compareTo(bString.getOpObjName());
		      
		}
	}
	/**
	 * @return PLMTC5MliRptData objects.
	 */
	private static final class TC5MLIMapper implements ParameterizedRowMapper<PLMTC5MliRptData>{	
		public PLMTC5MliRptData mapRow(ResultSet rs, int rowCount) throws SQLException {			
			PLMTC5MliRptData searchData = new PLMTC5MliRptData();
			 Locale loc = Locale.getDefault();

				searchData.setOpMLI(PLMUtils.checkNullVal(rs.getString("MLI")));
				searchData.setOpObjName(PLMUtils.checkNullVal(rs.getString("OBJNAME")));
				searchData.setOpObjEnvId(PLMUtils.checkNullVal(rs.getString("OBJ_ENV_ID")));
				searchData.setOpObjCss(PLMUtils.checkNullVal(rs.getString("OBJ_CSS")).toLowerCase(loc));				
				searchData.setOpObjRev(PLMUtils.checkNullVal(rs.getString("OBJREV")));
				searchData.setOpFRDesc(PLMUtils.checkNullVal(rs.getString("DESC_FR")));
				searchData.setOpENDesc(PLMUtils.checkNullVal(rs.getString("DESC_EN")));
				searchData.setOpQty(PLMUtils.checkNullVal(rs.getString("QTY")));
				searchData.setOpUomDocType(PLMUtils.checkNullVal(rs.getString("UOM_DOSTYPE")));
				searchData.setOpSect(PLMUtils.checkNullVal(rs.getString("SECT")));
				searchData.setOpItemName(PLMUtils.checkNullVal(rs.getString("ITEMNAME")));
				searchData.setOpItemEnvId(PLMUtils.checkNullVal(rs.getString("ITEM_ENV_ID")));
				searchData.setOpItemCss(PLMUtils.checkNullVal(rs.getString("ITEM_CSS")).toLowerCase(loc));
				searchData.setOpItemRev(PLMUtils.checkNullVal(rs.getString("ITEMREV")));
				searchData.setOpSN(PLMUtils.checkNullVal(rs.getString("SN")));
				searchData.setOpTmTot(PLMUtils.checkNullVal(rs.getString("TM_TOT")));
				searchData.setOpTmTotEnvId(PLMUtils.checkNullVal(rs.getString("TM_TOT_ENV_ID")));
				searchData.setOpTmTotCss(PLMUtils.checkNullVal(rs.getString("TM_TOT_CSS")).toLowerCase(loc));
				searchData.setOpProject(PLMUtils.checkNullVal(rs.getString("PRJ")));
				searchData.setOpContract(PLMUtils.checkNullVal(rs.getString("CONTRACT")));
				searchData.setOpConDesc(PLMUtils.checkNullVal(rs.getString("CONTRACTDES")));
			return 	searchData;
		}
	}
	
	/**
	 * This method is used to get TC5 Full BOM data
	 * 
	 * @param searchData
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTC5FullBomRptData> getTC5FullBomReport(String tc5CodeFullBom,String bomLevel,boolean allBomLvlFlg,
			String refDocLevel,boolean allRefDocLvlFlg,boolean includeDefFlag)throws PLMCommonException{
		LOG.info("Entering getTC5FullBomeport of DAOImpl");
		List<PLMTC5FullBomRptData> searchResultList = new ArrayList<PLMTC5FullBomRptData>();
		String timeStamp = PLMUtils.volTableFormatDate();
		String VTC5_BOMLVL = PLMTC5RptConstants.VTC5_BOMLVL.concat(timeStamp);
		String VTC5_DOCLVL = PLMTC5RptConstants.VTC5_DOCLVL.concat(timeStamp);
		StringBuffer createTC5BOMQry = new StringBuffer();
		StringBuffer createTC5DOCQry = new StringBuffer();
		try{
			LOG.info("tc5CodeFullBom>> "+tc5CodeFullBom);
			LOG.info("bomLevel>> "+bomLevel);
			LOG.info("allBomLvlFlg>> "+allBomLvlFlg);
			LOG.info("refDocLevel>> "+refDocLevel);
			LOG.info("allRefDocLvlFlg>> "+allRefDocLvlFlg);
			LOG.info("includeDefFlag>> "+includeDefFlag);
			
			createTC5BOMQry.append(PLMTC5RptQueries.CREATE_TC5_BOMLVL1.replace(PLMTC5RptConstants.VTC5_BOMLVL, VTC5_BOMLVL)
					.replace("?", tc5CodeFullBom));
			
			if(allBomLvlFlg){
				createTC5BOMQry.append(PLMTC5RptQueries.CREATE_TC5_BOMLVL2.replace("?", PLMTC5RptConstants.STR_MAX_LVL_LIMIT));
			}else if(!PLMUtils.isEmpty(bomLevel)){
				createTC5BOMQry.append(PLMTC5RptQueries.CREATE_TC5_BOMLVL2.replace("?", bomLevel));
			}
			
			LOG.info("Executing for Creating BOM LVL Volatile Query "+createTC5BOMQry);
			getJdbcTemplate().execute(createTC5BOMQry.toString());
		
			if(!PLMUtils.isEmpty(refDocLevel)|| allRefDocLvlFlg){
				if(allRefDocLvlFlg){
					createTC5DOCQry.append(PLMTC5RptQueries.CREATE_TC5_DOCVL1.replace(PLMTC5RptConstants.VTC5_DOCLVL, VTC5_DOCLVL)
							.replace(PLMTC5RptConstants.VTC5_BOMLVL, VTC5_BOMLVL).replace("?", PLMTC5RptConstants.STR_MAX_LVL_LIMIT));
				}else if(!PLMUtils.isEmpty(refDocLevel)){
					createTC5DOCQry.append(PLMTC5RptQueries.CREATE_TC5_DOCVL1.replace(PLMTC5RptConstants.VTC5_DOCLVL, VTC5_DOCLVL)
							.replace(PLMTC5RptConstants.VTC5_BOMLVL, VTC5_BOMLVL).replace("?", refDocLevel));
				}
				if(includeDefFlag){
				   createTC5DOCQry.append(PLMTC5RptQueries.CREATE_TC5_DOCVL2);
				}
				if(allRefDocLvlFlg){
					createTC5DOCQry.append(PLMTC5RptQueries.CREATE_TC5_DOCVL3.replace("?", PLMTC5RptConstants.STR_MAX_LVL_LIMIT));
				}else if(!PLMUtils.isEmpty(refDocLevel)){
					createTC5DOCQry.append(PLMTC5RptQueries.CREATE_TC5_DOCVL3.replace("?", refDocLevel));
				}
			LOG.info("Executing for Creating DOC LVL Volatile Query "+createTC5DOCQry);
			getJdbcTemplate().execute(createTC5DOCQry.toString());
			
			LOG.info("Executing for Final DOC LVL Volatile Query "+PLMTC5RptQueries.GET_TC5_DOCLVL.replace(PLMTC5RptConstants.VTC5_DOCLVL, VTC5_DOCLVL));
			searchResultList =getSimpleJdbcTemplate().query(PLMTC5RptQueries.GET_TC5_DOCLVL.replace(PLMTC5RptConstants.VTC5_DOCLVL, VTC5_DOCLVL)
					,new TC5FullBOMRptMapper());
			LOG.info("List of TC5 Full BOM For Doc LvL >>> "+searchResultList.size());
		 }else{
			LOG.info("Executing for Final BOM LVL Volatile Query "+PLMTC5RptQueries.GET_TC5_BOMLVL.replace(PLMTC5RptConstants.VTC5_BOMLVL, VTC5_BOMLVL));
			searchResultList =getSimpleJdbcTemplate().query(PLMTC5RptQueries.GET_TC5_BOMLVL.replace(PLMTC5RptConstants.VTC5_BOMLVL, VTC5_BOMLVL)
					,new TC5FullBOMRptMapper());
			LOG.info("List of TC5 Full BOM For BOM LvL >>> "+searchResultList.size());
		 }
			Collections.sort(searchResultList, new SortStructure());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Existing getTC5FullBomeport of DAOImpl");
		return searchResultList;
	}
	/**
	 * 
	 * class to sort list of object of type PLMTC5FullBomRptData.
	 * 
	 */
	private static class SortStructure implements Comparator<PLMTC5FullBomRptData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMTC5FullBomRptData aString,
				PLMTC5FullBomRptData bString) {
			String aStr;
			String bStr;
			int result=0;
			aStr = aString.getStructure();
			bStr = bString.getStructure();
			if(aStr != null && bStr != null){
			result = aStr.compareTo(bStr);
			}
			return result;
			
		}
	}
	
	/**
	 * @return PLMTC5FullBomRptData objects.
	 */
	private static final class TC5FullBOMRptMapper implements ParameterizedRowMapper<PLMTC5FullBomRptData> {
		public PLMTC5FullBomRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMTC5FullBomRptData data = new PLMTC5FullBomRptData();
			data.setLvlBomDoc(PLMUtils.checkNullVal(rs.getString("lvlBOM#DOC")));
			data.setIdRepere(PLMUtils.checkNullVal(rs.getString("ID_REP")));
			data.setQty(PLMUtils.checkNullVal(rs.getString("Qty")));
			data.setUomDosType(PLMUtils.checkNullVal(rs.getString("UoM_DosType")));
			data.setObjName(PLMUtils.checkNullVal(rs.getString("ObjName")));
			data.setObjRev(PLMUtils.checkNullVal(rs.getString("ObjRev")));
			data.setFrDescription(PLMUtils.checkNullVal(rs.getString("ObjDescFR")));
			data.setEnDescription(PLMUtils.checkNullVal(rs.getString("ObjDescEN")));
			data.setStructure(PLMUtils.checkNullVal(rs.getString("arbo")));
			return data;
		}
	}
	
	/**
	 * This methods is used getTC5WhUsedRpt
	 * 
	 * @param partDocNumLcl
	 * @return List<PLMTC5WhUsedRptData>
	 * throws PLMCommonException
	 */	
	public List<PLMTC5WhUsedRptData> getTC5WhUsedRpt(String partDocNumLcl)
	throws PLMCommonException {
		LOG.info("Entering getTC5WhUsedRpt of DAOImpl");
		List<PLMTC5WhUsedRptData> searchResultList = null;
		
		String timeStamp = PLMUtils.volTableFormatDate();
		String VT_DCPRT1 = PLMTC5RptConstants.VT_DCPRT1.concat(timeStamp);
		String VT_DCPRT2 = PLMTC5RptConstants.VT_DCPRT2.concat(timeStamp);
		String VT_DCPRT3 = PLMTC5RptConstants.VT_DCPRT3.concat(timeStamp);
		String VT_DCPRT4 = PLMTC5RptConstants.VT_DCPRT4.concat(timeStamp);
		String VT_DCPRT5 = PLMTC5RptConstants.VT_DCPRT5.concat(timeStamp);
		String VT_DCPRT6 = PLMTC5RptConstants.VT_DCPRT6.concat(timeStamp);
		
		try{
		
		LOG.info("Fetching Results for TC5 WhUsed Report************");
				
			searchResultList=new ArrayList<PLMTC5WhUsedRptData>();
			//LOG.info("Executing Queries for PART type.............");
			
			LOG.info("Query for Creating VT_DCPRT1==="+PLMTC5RptQueries.CREATE_TC5_VT_TC5_WU_SCOPE.replace(PLMTC5RptConstants.VT_DCPRT1, VT_DCPRT1));
			
			getJdbcTemplate().execute(PLMTC5RptQueries.CREATE_TC5_VT_TC5_WU_SCOPE.replace(PLMTC5RptConstants.VT_DCPRT1, VT_DCPRT1));
			LOG.info("VT_DCPRT1 Created...");
			
			LOG.info("Query for Creating VT_DCPRT2==="+PLMTC5RptQueries.CREATE_TC5_VT_TC5_PARENT_CHILD.replace(PLMTC5RptConstants.VT_DCPRT2, VT_DCPRT2)
					.replace(PLMTC5RptConstants.VT_DCPRT1, VT_DCPRT1));
			
			getJdbcTemplate().execute(PLMTC5RptQueries.CREATE_TC5_VT_TC5_PARENT_CHILD.replace(PLMTC5RptConstants.VT_DCPRT2, VT_DCPRT2)
					.replace(PLMTC5RptConstants.VT_DCPRT1, VT_DCPRT1));
			LOG.info("VT_DCPRT2 Created...");
			
			LOG.info("Query for Creating VT_DCPRT3==="+PLMTC5RptQueries.CREATE_TC5_VT_TC5_MLI_DESC.replace(PLMTC5RptConstants.VT_DCPRT3, VT_DCPRT3));
			
			getJdbcTemplate().execute(PLMTC5RptQueries.CREATE_TC5_VT_TC5_MLI_DESC.replace(PLMTC5RptConstants.VT_DCPRT3, VT_DCPRT3));
			LOG.info("VT_DCPRT3 Created...");
			
			LOG.info("Query for Creating VT_DCPRT4==="+PLMTC5RptQueries.CREATE_TC5_VT_WUTC5_IMDT_PARENT.replace(PLMTC5RptConstants.VT_DCPRT4, VT_DCPRT4)
					.replace(PLMTC5RptConstants.VT_DCPRT2, VT_DCPRT2).replace(PLMTC5RptConstants.VT_DCPRT1, VT_DCPRT1)
					.replace("?", "'"+partDocNumLcl+"'"));
			
			getJdbcTemplate().execute(PLMTC5RptQueries.CREATE_TC5_VT_WUTC5_IMDT_PARENT.replace(PLMTC5RptConstants.VT_DCPRT4, VT_DCPRT4)
					.replace(PLMTC5RptConstants.VT_DCPRT2, VT_DCPRT2).replace(PLMTC5RptConstants.VT_DCPRT1, VT_DCPRT1)
					.replace("?", "'"+partDocNumLcl+"'"));
			LOG.info("VT_DCPRT4 Created...");
			
			LOG.info("Query for Creating VT_DCPRT5==="+PLMTC5RptQueries.CREATE_TC5_VT_WUTC5_EXPLOSIONN.replace(PLMTC5RptConstants.VT_DCPRT5, VT_DCPRT5)
					.replace(PLMTC5RptConstants.VT_DCPRT4, VT_DCPRT4).replace(PLMTC5RptConstants.VT_DCPRT2, VT_DCPRT2));
			
			getJdbcTemplate().execute(PLMTC5RptQueries.CREATE_TC5_VT_WUTC5_EXPLOSIONN.replace(PLMTC5RptConstants.VT_DCPRT5, VT_DCPRT5)
					.replace(PLMTC5RptConstants.VT_DCPRT4, VT_DCPRT4).replace(PLMTC5RptConstants.VT_DCPRT2, VT_DCPRT2));
			LOG.info("VT_DCPRT5 Created...");
			
			LOG.info("Query for Creating VT_DCPRT6==="+PLMTC5RptQueries.CREATE_TC5_VT_WUTC5_EXPLOSION_ISTOP.replace(PLMTC5RptConstants.VT_DCPRT6, VT_DCPRT6)
					.replace(PLMTC5RptConstants.VT_DCPRT5, VT_DCPRT5));
			
			getJdbcTemplate().execute(PLMTC5RptQueries.CREATE_TC5_VT_WUTC5_EXPLOSION_ISTOP.replace(PLMTC5RptConstants.VT_DCPRT6, VT_DCPRT6)
					.replace(PLMTC5RptConstants.VT_DCPRT5, VT_DCPRT5));
			LOG.info("VT_DCPRT6 Created...");
			
			LOG.info("Query for fetching Final Data==="+PLMTC5RptQueries.GET_TC5_WHUSED_DATA.replace(PLMTC5RptConstants.VT_DCPRT1, VT_DCPRT1)
					.replace(PLMTC5RptConstants.VT_DCPRT3, VT_DCPRT3).replace(PLMTC5RptConstants.VT_DCPRT6, VT_DCPRT6).replace("?", "'"+partDocNumLcl+"'"));
			
			searchResultList=getSimpleJdbcTemplate().query(PLMTC5RptQueries.GET_TC5_WHUSED_DATA.replace(PLMTC5RptConstants.VT_DCPRT1, VT_DCPRT1)
					.replace(PLMTC5RptConstants.VT_DCPRT3, VT_DCPRT3).replace(PLMTC5RptConstants.VT_DCPRT6, VT_DCPRT6).replace("?", "'"+partDocNumLcl+"'")
					, new Tc5WhUsedDataMapper());
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Existing getTC5WhUsedRpt of DAOImpl");
		return searchResultList;
	}
	
	/**
	 * @return PLMTC5WhUsedRptData objects.
	 */
	private static final class Tc5WhUsedDataMapper implements ParameterizedRowMapper<PLMTC5WhUsedRptData> {
		public PLMTC5WhUsedRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMTC5WhUsedRptData data = new PLMTC5WhUsedRptData();
			data.setTopPartDoc(PLMUtils.checkNullVal(rs.getString("TOP_PARENT")));
			data.setTopPartDocRev(PLMUtils.checkNullVal(rs.getString("TOP_REV")));
			data.setDescEn(PLMUtils.checkNullVal(rs.getString("TOP_DESC")));
			data.setDescFr(PLMUtils.checkNullVal(rs.getString("TOP_LIBELLE")));
			data.setPrj(PLMUtils.checkNullVal(rs.getString("PRJ")));
			data.setContract(PLMUtils.checkNullVal(rs.getString("CONTRACT")));
			data.setTurbine(PLMUtils.checkNullVal(rs.getString("TM_TOT")));
			data.setSn(PLMUtils.checkNullVal(rs.getString("SN")));
			data.setMli(PLMUtils.checkNullVal(rs.getString("MLI")));
			data.setImdtPrntNm(PLMUtils.checkNullVal(rs.getString("IMMED_PARENT")));
			data.setImdtPrntRev(PLMUtils.checkNullVal(rs.getString("IMMED_REV")));
			data.setImdtPrntEn(PLMUtils.checkNullVal(rs.getString("IMMED_DESC")));
			data.setImdtPrntFr(PLMUtils.checkNullVal(rs.getString("IMMED_LIBELLE")));
			//data.setChildPartDoc(PLMUtils.checkNullVal(rs.getString("CHILD_NAME")));
			data.setLevel(PLMUtils.checkNullVal(rs.getString("LVL")));
			data.setDfsOrder(PLMUtils.checkNullVal(rs.getString("DFSORDER")));
			
			return data;
		}
	}

}
