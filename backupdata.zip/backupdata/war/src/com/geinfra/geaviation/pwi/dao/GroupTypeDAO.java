package com.geinfra.geaviation.pwi.dao;

import java.util.List;

/**
 * 
 * Project : Product Lifecycle Management
 * Date Written : Apr 15, 2013
 * Security : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2013 GE All rights reserved
 * 
 * Description : Data access object for the group-object type relationship.
 * 
 * Revision Log Apr 15, 2013 | v1.0.
 * --------------------------------------------------------------
 */
public interface GroupTypeDAO {
	public void addGroupsForObjectType(List<Integer> groupIdsToAddForObjectType,
			Integer objectTypeId, String sso);

	public void deleteGroupsForObjectType(List<Integer> groupIdsToRemoveForObjectType,
			Integer objectTypeId);
}
