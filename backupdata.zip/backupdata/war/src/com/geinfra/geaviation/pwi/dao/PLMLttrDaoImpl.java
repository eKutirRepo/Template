/**
 * Copyright (C) 2012 GE Infra.
 * All rights reserved 
 * @FileName PLMLttrDaoImpl.java
 * @Creation date: 27-Mar-2012
 * @version 2.0.1
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMLttrData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMLttrDaoImpl extends SimpleJdbcDaoSupport implements PLMLttrDaoIfc {
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMLttrDaoImpl.class);
	
	/**
	 * Holds the DATE FORMAT
	 */
	
//	private static final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("dd/MM/yyyy");
   
	/**
	 * This method is used for checkForValidMlNo
	 * 
	 * @param mlno
	 * @return int
	 * @throws PLMCommonException
	 */
	
	public int checkForValidMlNo(String mlNo) throws PLMCommonException {
		LOG.info("Entering checkForValidMlNo Method");
		int mlCount = 0;
		try{
			LOG.info("LTTR Input ML #  : " + mlNo);
			LOG.info("Query for checking valid ML #  : " + PLMOfflineQueries.GET_LTTR_VALID_ML_NO);
			mlCount = getSimpleJdbcTemplate().queryForInt(PLMOfflineQueries.GET_LTTR_VALID_ML_NO, new Object[]{mlNo});
			LOG.info("Result of ML Count  : " + mlCount);
			} catch(DataAccessException e){
				PLMUtils.checkException(e.getMessage());
			}
		LOG.info("Exiting checkForValidMlNo Method");
		return mlCount;
	}
	
	/**
	 * This method is used for getTdLttrResult
	 * 
	 * @param mlno
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMLttrData> getTdLttrResult(String mlNo) throws PLMCommonException {
		LOG.info("Entering getTdLttrResult Method");
		List<PLMLttrData> lttrTdResultList =  new ArrayList<PLMLttrData>();
		boolean VT1Executed = false;
		boolean VT2Executed = false;
		boolean VT3Executed = false;
		boolean VT30Executed = false;
		boolean VT311Executed = false;
		boolean VT312Executed = false;
		boolean VT313Executed = false;
		boolean VT32Executed = false;
		boolean VT33Executed = false;
		boolean VT4Executed = false;
		boolean VT5Executed = false;
		String timeStamp = null;
		String LTTR_VT1 = null;
		String LTTR_VT2 = null;

		String LTTR_VT30 = null;
		String LTTR_VT311 = null;
		String LTTR_VT312 = null;
		String LTTR_VT313 = null;
		String LTTR_VT314 = null;
		String LTTR_VT32 = null;
		String LTTR_VT03 = null;

		String LTTR_VT3 = null;
		
		String LTTR_VT4 = null;
		String LTTR_VT5 = null;
		
		
		try{
			

			timeStamp = PLMUtils.volTableFormatDate();
			
			LOG.info("The timeStamp for the Report "+timeStamp);
			
			LTTR_VT1 = PLMConstants.LTTR_VT1.concat(timeStamp);
			LTTR_VT2 = PLMConstants.LTTR_VT2.concat(timeStamp);
			LTTR_VT30 = PLMConstants.LTTR_VT30.concat(timeStamp);
			LTTR_VT311 = PLMConstants.LTTR_VT311.concat(timeStamp);
			LTTR_VT312 = PLMConstants.LTTR_VT312.concat(timeStamp);
			LTTR_VT313 = PLMConstants.LTTR_VT313.concat(timeStamp);
			LTTR_VT314 = PLMConstants.LTTR_VT314.concat(timeStamp);
			LTTR_VT32 = PLMConstants.LTTR_VT32.concat(timeStamp);
			LTTR_VT03 = PLMConstants.LTTR_VT03.concat(timeStamp);
			LTTR_VT3 = PLMConstants.LTTR_VT3.concat(timeStamp);
			LTTR_VT4 = PLMConstants.LTTR_VT4.concat(timeStamp);
			LTTR_VT5 = PLMConstants.LTTR_VT5.concat(timeStamp);
			
			
			
			LOG.info("Query for Getting LTTR : " + PLMOfflineQueries.GET_LTTR);
			lttrTdResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_LTTR,new TdLttrResultMapper(),new Object[]{mlNo});
			LOG.info("Result of LTTR : " + lttrTdResultList.size());
			if(!PLMUtils.isEmptyList(lttrTdResultList)){
				lttrTdResultList = formTreeStruct(lttrTdResultList,mlNo);
			//}
			LOG.info("Result of LTTR After Ordering : " + lttrTdResultList.size());
			LOG.info("Query for Creating VT1 : " + PLMOfflineQueries.CREATE_LTTR_VT1.replace(PLMConstants.LTTR_VT1, LTTR_VT1));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_LTTR_VT1.replace(PLMConstants.LTTR_VT1, LTTR_VT1));
			VT1Executed = true;
			final List<PLMLttrData> lttrInsertResultList = lttrTdResultList;
			int[] updateCount = null;
			//setting 2 column values for 6.1 Release
			LOG.info("Insert Query :  " + PLMOfflineQueries.SET_LTTR_VT1.replace(PLMConstants.LTTR_VT1, LTTR_VT1));
			updateCount  = getSimpleJdbcTemplate().getJdbcOperations().batchUpdate(PLMOfflineQueries.SET_LTTR_VT1.
					replace(PLMConstants.LTTR_VT1, LTTR_VT1), new BatchPreparedStatementSetter() 
			{
			public void setValues(PreparedStatement ps,int iCount)throws SQLException {
				ps.setInt(1,iCount);
				ps.setInt(2, lttrInsertResultList.get(iCount).getBomLevel());
				ps.setString(3, lttrInsertResultList.get(iCount).getParentPdName());
				ps.setString(4, lttrInsertResultList.get(iCount).getPdName());
				ps.setString(5, lttrInsertResultList.get(iCount).getPrntItemSrcType());
				ps.setString(6, lttrInsertResultList.get(iCount).getCntntItemSrcType());
			}
			public int getBatchSize() {
				return lttrInsertResultList.size();
			}
			});
			LOG.info("Total inserted Records : " + updateCount.length);
			if (VT1Executed) {
				LOG.info("Query for Collect STATS LTTR_VT1_COL_STATS1 : " + PLMOfflineQueries.LTTR_VT1_COL_STATS1.replace(PLMConstants.LTTR_VT1, LTTR_VT1));
				getJdbcTemplate().execute(PLMOfflineQueries.LTTR_VT1_COL_STATS1.replace(PLMConstants.LTTR_VT1, LTTR_VT1));
			}
			LOG.info("Query for Creating VT2 : " + PLMOfflineQueries.CREATE_LTTR_VT2.replace(PLMConstants.LTTR_VT2, LTTR_VT2));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_LTTR_VT2.replace(PLMConstants.LTTR_VT2, LTTR_VT2));
			LOG.info("Query for Insert into VT2 : " + PLMOfflineQueries.INSERT_LTTR_VT2.replace(PLMConstants.LTTR_VT1, LTTR_VT1).replace(PLMConstants.LTTR_VT2, LTTR_VT2));
			getJdbcTemplate().execute(PLMOfflineQueries.INSERT_LTTR_VT2.replace(PLMConstants.LTTR_VT1, LTTR_VT1).replace(PLMConstants.LTTR_VT2, LTTR_VT2));
			VT2Executed = true;
			//int size = getSimpleJdbcTemplate().queryForInt("SELECT COUNT (*) FROM VT2");
			//LOG.info("size of vt2 : "  + size);
			if (VT2Executed) {
				LOG.info("Query for Collect STATS LTTR_VT2_COL_STATS1 : " + PLMOfflineQueries.LTTR_VT2_COL_STATS1.replace(PLMConstants.LTTR_VT2, LTTR_VT2));
				getJdbcTemplate().execute(PLMOfflineQueries.LTTR_VT2_COL_STATS1.replace(PLMConstants.LTTR_VT2, LTTR_VT2));
				LOG.info("Query for Collect STATS LTTR_VT2_COL_STATS2 : " + PLMOfflineQueries.LTTR_VT2_COL_STATS2.replace(PLMConstants.LTTR_VT2, LTTR_VT2));
				getJdbcTemplate().execute(PLMOfflineQueries.LTTR_VT2_COL_STATS2.replace(PLMConstants.LTTR_VT2, LTTR_VT2));
				LOG.info("Query for Collect STATS LTTR_VT2_COL_STATS3 : " + PLMOfflineQueries.LTTR_VT2_COL_STATS3.replace(PLMConstants.LTTR_VT2, LTTR_VT2));
				getJdbcTemplate().execute(PLMOfflineQueries.LTTR_VT2_COL_STATS3.replace(PLMConstants.LTTR_VT2, LTTR_VT2));
				LOG.info("Query for Collect STATS LTTR_VT2_COL_STATS4 : " + PLMOfflineQueries.LTTR_VT2_COL_STATS4.replace(PLMConstants.LTTR_VT2, LTTR_VT2));
				getJdbcTemplate().execute(PLMOfflineQueries.LTTR_VT2_COL_STATS4.replace(PLMConstants.LTTR_VT2, LTTR_VT2));
			}

			LOG.info("Query for Creating VT30 : " + PLMOfflineQueries.CREATE_LTTR_VT30.replace(PLMConstants.LTTR_VT30, LTTR_VT30).replace(PLMConstants.LTTR_VT2, LTTR_VT2));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_LTTR_VT30.replace(PLMConstants.LTTR_VT30, LTTR_VT30).replace(PLMConstants.LTTR_VT2, LTTR_VT2));
			VT30Executed = true;
			if (VT30Executed) {
				LOG.info("Query for Collect STATS LTTR_VT30_COL_STATS : " + PLMOfflineQueries.LTTR_VT30_COL_STATS.replace(PLMConstants.LTTR_VT30, LTTR_VT30));
				getJdbcTemplate().execute(PLMOfflineQueries.LTTR_VT30_COL_STATS.replace(PLMConstants.LTTR_VT30, LTTR_VT30));
			}	
			
			//Start Newly Added/Updated Queries for Preventing Duplicate Description for Release 6.1
			LOG.info("Query for Creating VT311 : " + PLMOfflineQueries.CREATE_LTTR_VT311.replace(PLMConstants.LTTR_VT311, LTTR_VT311));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_LTTR_VT311.replace(PLMConstants.LTTR_VT311, LTTR_VT311));
			VT311Executed = true;
			if (VT311Executed) {
				LOG.info("Query for Collect STATS LTTR_VT311_COL_STATS : " + PLMOfflineQueries.LTTR_VT311_COL_STATS.replace(PLMConstants.LTTR_VT311, LTTR_VT311));
				getJdbcTemplate().execute(PLMOfflineQueries.LTTR_VT311_COL_STATS.replace(PLMConstants.LTTR_VT311, LTTR_VT311));
			}	
			
			VT312Executed = false;
			LOG.info("Query for Creating into VT312 : " + PLMOfflineQueries.CREATE_LTTR_VT312.replace(PLMConstants.LTTR_VT312, LTTR_VT312));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_LTTR_VT312.replace(PLMConstants.LTTR_VT312, LTTR_VT312));
			VT312Executed = true;
			if (VT312Executed) {
				LOG.info("Query for Collect STATS LTTR_VT312_COL_STATS : " + PLMOfflineQueries.LTTR_VT312_COL_STATS.replace(PLMConstants.LTTR_VT312, LTTR_VT312));
				getJdbcTemplate().execute(PLMOfflineQueries.LTTR_VT312_COL_STATS.replace(PLMConstants.LTTR_VT312, LTTR_VT312));
			}	
			
			VT313Executed = false;
			LOG.info("Query for Creating into VT313 : " + PLMOfflineQueries.CREATE_LTTR_VT313.replace(PLMConstants.LTTR_VT313, LTTR_VT313));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_LTTR_VT313.replace(PLMConstants.LTTR_VT313, LTTR_VT313));
			VT313Executed = true;
			if (VT313Executed) {
				LOG.info("Query for Collect STATS LTTR_VT313_COL_STATS : " + PLMOfflineQueries.LTTR_VT313_COL_STATS.replace(PLMConstants.LTTR_VT313, LTTR_VT313));
				getJdbcTemplate().execute(PLMOfflineQueries.LTTR_VT313_COL_STATS.replace(PLMConstants.LTTR_VT313, LTTR_VT313));
			}	
			
			LOG.info("Query for Creating into VT314 : " + PLMOfflineQueries.CREATE_LTTR_VT314.replace(PLMConstants.LTTR_VT314, LTTR_VT314));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_LTTR_VT314.replace(PLMConstants.LTTR_VT314, LTTR_VT314));
			LOG.info("Query for Collect STATS VT314 : " + PLMOfflineQueries.LTTR_VT314_COL_STATS.replace(PLMConstants.LTTR_VT314, LTTR_VT314));
			getJdbcTemplate().execute(PLMOfflineQueries.LTTR_VT314_COL_STATS.replace(PLMConstants.LTTR_VT314, LTTR_VT314));
			
			LOG.info("Query for Creating VT32 : " + PLMOfflineQueries.CREATE_LTTR_VT32.replace(PLMConstants.LTTR_VT32, LTTR_VT32)
					.replace(PLMConstants.LTTR_VT311, LTTR_VT311).replace(PLMConstants.LTTR_VT312, LTTR_VT312)
					.replace(PLMConstants.LTTR_VT313, LTTR_VT313).replace(PLMConstants.LTTR_VT314, LTTR_VT314).replace(PLMConstants.LTTR_VT30, LTTR_VT30));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_LTTR_VT32.replace(PLMConstants.LTTR_VT32, LTTR_VT32)
					.replace(PLMConstants.LTTR_VT311, LTTR_VT311).replace(PLMConstants.LTTR_VT312, LTTR_VT312)
					.replace(PLMConstants.LTTR_VT313, LTTR_VT313).replace(PLMConstants.LTTR_VT314, LTTR_VT314).replace(PLMConstants.LTTR_VT30, LTTR_VT30));
			//End Newly Added/Updated Queries for Preventing Duplicate Description for Release 6.1
			VT32Executed = true;
			if (VT32Executed) {
				LOG.info("Query for Collect STATS LTTR_VT32_COL_STATS : " + PLMOfflineQueries.LTTR_VT32_COL_STATS.replace(PLMConstants.LTTR_VT32, LTTR_VT32));
				getJdbcTemplate().execute(PLMOfflineQueries.LTTR_VT32_COL_STATS.replace(PLMConstants.LTTR_VT32, LTTR_VT32));
			}	
			
			LOG.info("Query for Creating VT33 : " + PLMOfflineQueries.CREATE_LTTR_VT33.replace(PLMConstants.LTTR_VT03, LTTR_VT03).replace(PLMConstants.LTTR_VT32, LTTR_VT32));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_LTTR_VT33.replace(PLMConstants.LTTR_VT03, LTTR_VT03).replace(PLMConstants.LTTR_VT32, LTTR_VT32));
			VT33Executed = true;
			if (VT33Executed) {
				LOG.info("Query for Collect STATS LTTR_VT33_COL_STATS : " + PLMOfflineQueries.LTTR_VT33_COL_STATS.replace(PLMConstants.LTTR_VT03, LTTR_VT03));
				getJdbcTemplate().execute(PLMOfflineQueries.LTTR_VT33_COL_STATS.replace(PLMConstants.LTTR_VT03, LTTR_VT03));
			}	
			
			LOG.info("Query for Creating VT3 : " + PLMOfflineQueries.CREATE_LTTR_VT3.replace(PLMConstants.LTTR_VT3, LTTR_VT3).replace(PLMConstants.LTTR_VT03, LTTR_VT03));
			
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_LTTR_VT3.replace(PLMConstants.LTTR_VT3, LTTR_VT3).replace(PLMConstants.LTTR_VT03, LTTR_VT03));
			VT3Executed = true;
			if (VT3Executed) {
				LOG.info("Query for Collect STATS LTTR_VT3_COL_STATS1 : " + PLMOfflineQueries.LTTR_VT3_COL_STATS1.replace(PLMConstants.LTTR_VT3, LTTR_VT3));
				getJdbcTemplate().execute(PLMOfflineQueries.LTTR_VT3_COL_STATS1.replace(PLMConstants.LTTR_VT3, LTTR_VT3));
			}			
			LOG.info("Query for Creating VT4 : " + PLMOfflineQueries.CREATE_LTTR_VT4.replace(PLMConstants.LTTR_VT4, LTTR_VT4).replace(PLMConstants.LTTR_VT3, LTTR_VT3));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_LTTR_VT4.replace(PLMConstants.LTTR_VT4, LTTR_VT4).replace(PLMConstants.LTTR_VT3, LTTR_VT3));
			VT4Executed = true;
			if (VT4Executed) {
				LOG.info("Query for Collect STATS LTTR_VT4_COL_STATS1 : " + PLMOfflineQueries.LTTR_VT4_COL_STATS1.replace(PLMConstants.LTTR_VT4, LTTR_VT4));
				getJdbcTemplate().execute(PLMOfflineQueries.LTTR_VT4_COL_STATS1.replace(PLMConstants.LTTR_VT4, LTTR_VT4));
			}
			LOG.info("Query for Creating VT5 : " + PLMOfflineQueries.CREATE_LTTR_VT5.replace(PLMConstants.LTTR_VT5, LTTR_VT5).replace(PLMConstants.LTTR_VT4, LTTR_VT4));
			getJdbcTemplate().execute(PLMOfflineQueries.CREATE_LTTR_VT5.replace(PLMConstants.LTTR_VT5, LTTR_VT5).replace(PLMConstants.LTTR_VT4, LTTR_VT4));
			VT5Executed = true;
			if (VT5Executed) {
				LOG.info("Query for Collect STATS LTTR_VT5_COL_STATS1 : " + PLMOfflineQueries.LTTR_VT5_COL_STATS1.replace(PLMConstants.LTTR_VT5, LTTR_VT5));
				getJdbcTemplate().execute(PLMOfflineQueries.LTTR_VT5_COL_STATS1.replace(PLMConstants.LTTR_VT5, LTTR_VT5));
			}			
			LOG.info("Query for Getting VT5 : " + PLMOfflineQueries.GET_LTTR_VT5.replace(PLMConstants.LTTR_VT5, LTTR_VT5));
			lttrTdResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_LTTR_VT5.replace(PLMConstants.LTTR_VT5, LTTR_VT5),new TdLttrResultMapper1());
			LOG.info("Result of VT5 : " + lttrTdResultList.size());
		}
			//if(!PLMUtils.isEmptyList(lttrTdResultList)){
				//lttrTdResultList = removeDuplicates(lttrTdResultList);
			//}
			//LOG.info("Size After removal of duplicates : " + lttrTdResultList.size());
			if(!PLMUtils.isEmptyList(lttrTdResultList)){
				lttrTdResultList = generatePin(lttrTdResultList);
				
				for (int i = 0; i < lttrTdResultList.size(); i++) {
					PLMLttrData dataObj = (PLMLttrData) lttrTdResultList.get(i);
					String docState = dataObj.getDocState();
					String docName = dataObj.getDocName();
					
					if (docState.length() == 0 && docName.length() > 0) { 
						dataObj.setDocName("");
						dataObj.setDocRev("");
						dataObj.setDocDesc("");
						dataObj.setDocType("");
						dataObj.setExportControl("");
						dataObj.setDocClass("");
						dataObj.setMonthChange("");
						dataObj.setWeekChange("");
						dataObj.setDateChange("");
					}
				}
			}
			
		} catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		} /*finally {
			try {
				dropVolatileTablesForLttrReport(VT1Executed,VT2Executed,VT3Executed,
						VT30Executed,VT31Executed,VT32Executed,VT33Executed,
						VT4Executed,VT5Executed);
			} catch(DataAccessException e) {
				LOG.info("Exception occurred while dropping the tables in dropVolatileTablesForLttrReport method : " + e.getMessage());
				PLMUtils.checkException(e.getMessage());
			}
		}*/
		LOG.info("Exiting getTdLttrResult Method");
		return lttrTdResultList;
	}
	

	/**
	 * This method is used for formTreeStruct
	 * 
	 * @param lttrTdResultList,mlno
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMLttrData> formTreeStruct(List<PLMLttrData> lttrTdResultList,String mlNo) {
		int bomLevel = 1;
		int index;
		int prevIndex = -1;
		String parentPdName = mlNo;
		List<PLMLttrData> lttrFinalResultList =  new ArrayList<PLMLttrData>();
		while(true){
			index = findChildrens(lttrTdResultList,parentPdName,prevIndex,bomLevel);
			if(index == -1){			
				if(bomLevel == 1){
					break;			
				}
				lttrTdResultList.get(prevIndex).setPathFlag("COMPLETED");
				bomLevel = 1;
				parentPdName = mlNo;
			} else {
				if(!lttrTdResultList.get(index).getPathFlag().equals("VISITED")){
					lttrTdResultList.get(index).setPathFlag("VISITED");
					lttrFinalResultList.add(lttrTdResultList.get(index));
				}
				prevIndex = index;	
				bomLevel = bomLevel + 1;
				parentPdName = lttrTdResultList.get(index).getPdName();
			}
		}
		return lttrFinalResultList;
	}
	
	/**
	 * This method is used for findChildrens
	 * 
	 * @param lttrTdResultList,parentPdName,prevIndex,bomLevel
	 * @return int
	 */
	public int findChildrens(List<PLMLttrData> lttrTdResultList,String parentPdName,int prevIndex, int bomLevel) {
		int retIndex = -1;
		for(int i = 0 ; i < lttrTdResultList.size();i++) {
			if(lttrTdResultList.get(i).getParentPdName().equals(parentPdName) && lttrTdResultList.get(i).getBomLevel() == bomLevel){
				if(bomLevel == 1) {
					if(!lttrTdResultList.get(i).getPathFlag().equals("COMPLETED")){
						retIndex = i;
						break;
					}
				} else {
					if(lttrTdResultList.get(i).getParentPdName().equals(lttrTdResultList.get(prevIndex).getPdName())){
						if(!lttrTdResultList.get(i).getPathFlag().equals("COMPLETED")){
							retIndex = i;
							break;
						} 
					}
				}
			}
		}
		return retIndex;
	}
	/**
	 * This method is used for generatePin
	 * 
	 * @param lttrTdResultList
	 * @return List
	 */
	public List<PLMLttrData> generatePin(List<PLMLttrData> lttrTdResultList) {
		boolean mliFound = false;
		boolean prefix1302Found = false;
		int bomLevel = 0;
		int lastBomLevel = 0;
		String prefix;
		int levelFor1302 = 0;
		int levelForMli = 0;
		String mliArray[] = new String [100];
		String pinArray[] = new String [100];
		int levelArray[] = new int[100];
		String first2Char = "";
		// start : for loop
		for (int i = 0 ; i < lttrTdResultList.size(); i++) 
		   {
			bomLevel = lttrTdResultList.get(i).getBomLevel();
			prefix = lttrTdResultList.get(i).getPrefix().trim();
			/*if (!prefix.equals(prefix.trim())) {
				
				LOG.info("Prefix and Trimmed Prefix is not equal->"+prefix+"<-Test");
			}
			if (prefix!=null){
				
				if (prefix.trim().length() <4) {
					
					LOG.info(" Prefix Value -->"+prefix.trim());
					LOG.info(" LEVEL "+lttrTdResultList.get(i).getBomLevel());
					LOG.info(" PARENT "+lttrTdResultList.get(i).getParentPdName());
					LOG.info(" CHILD "+lttrTdResultList.get(i).getPdName());
					
				}
			}*/
			//LOG.info("Prefix value"+prefix);
			lttrTdResultList.get(i).setPin("");
			lttrTdResultList.get(i).setHpin("");
			if (!prefix.isEmpty() && prefix.length()>1) {
				first2Char = prefix.substring(0, 2);
			} else {
				first2Char = prefix+" ";
			}
			//LOG.info("value of i " + i);
			//LOG.info("bomLevel " + bomLevel);
			//LOG.info("Prefix" + prefix);
			//LOG.info("first2Char" + first2Char);
			// start : If bom level is equal to zero
			if(bomLevel == 0) {
				//LOG.info("bomLevel == 0");
				lttrTdResultList.get(i).setPrefix("");
				lttrTdResultList.get(i).setMli("");
				lttrTdResultList.get(i).setPin("");
				lttrTdResultList.get(i).setHpin("");
			}
			// end : If bom level is equal to zero
			
			// start : If bom level is equal to or greater than one
			if(bomLevel >= 1) {
				//LOG.info("bomLevel >= 1");
				if(mliFound){
					//LOG.info("mliFound for bomLevel >= 1");
					if(prefix1302Found && bomLevel == levelFor1302 + 1) {
						//LOG.info("prefix1302Found && bomLevel == levelFor1302 + 1");
					} else {
						if(bomLevel > levelForMli) {
							//LOG.info("bomLevel > levelForMli");
							lttrTdResultList.get(i).setMli(mliArray[levelForMli]);
							lttrTdResultList.get(i).setPin(pinArray[levelForMli-1]);
							lastBomLevel = bomLevel;								// setting previous bom level
							lttrTdResultList.get(i).setHpin(pinArray[1]);			// setting hpin
							continue;												// skips the current iteration
						} else {													// Reset all the values
							for (int j = bomLevel ; j <= levelArray[lastBomLevel + 1] ; j++){  
								mliArray[j] = "";
								pinArray[j] = "";
								levelArray[j] = 0;
							}
							mliFound = false;
							prefix1302Found = false;
						}
					 }
				}
				levelArray [bomLevel] = bomLevel; // Assigns bom level to level array
				
				if (first2Char.matches("[a-zA-Z]*") && !(prefix.equals("IS06"))) {  // if first two characters of the alphabet and not equals to IS06
					//LOG.info("first2Char.matches([a-zA-Z]*) && !(prefix.equals(IS06)");
					pinArray [bomLevel] = prefix;
				} else  { 															// if first two characters is not alphabet
					if (prefix.equals("1302")){  									// check if prefix equals to 1302
						//LOG.info("prefix.equals(1302)");
						pinArray [bomLevel] = prefix;
						mliArray [bomLevel] = prefix;
						prefix1302Found = true;
						levelFor1302 = bomLevel;
					} else {														// if prefix does not equals to 1302
						mliFound = true;
						levelForMli = bomLevel;
						mliArray [bomLevel] = prefix;
						//LOG.info("bomLevel" + bomLevel);
						//LOG.info("mliArray [bomLevel] = " +  mliArray [bomLevel]);
					}
				}
				
				if (prefix1302Found && bomLevel > levelFor1302){ 					// if prefix1302 found and level greater than level for 1302
					//LOG.info("mliFound && bomLevel > levelFor1302");
					if(prefix.equals("1303") || prefix.equals("1305")) {			// if prefix equals 1303 or 1305
						//LOG.info("prefix.equals(1303) || prefix.equals(1305)");
						mliFound = true;
						levelForMli = bomLevel;
						lttrTdResultList.get(i).setMli(mliArray[bomLevel - 1]);		// setting mli
						lttrTdResultList.get(i).setPin(pinArray[bomLevel - 2]);		// setting pin
					} else {														// if prefix not equals 1303 or 1305
						//LOG.info("else of prefix.equals(1303) || prefix.equals(1305)");
						mliFound = true;
						levelForMli = bomLevel - 1;
						lttrTdResultList.get(i).setMli(mliArray[levelForMli]);		// setting mli
						lttrTdResultList.get(i).setPin(pinArray[levelForMli - 1]);	// setting pin
					}
					lastBomLevel = bomLevel;										// setting previous bom level
					lttrTdResultList.get(i).setHpin(pinArray[1]);					// setting hpin
					continue;														// skips the current iteration
				}
					
				if (mliFound){														// if mli found
					//LOG.info("mli found for all level");
					if (bomLevel >= 2){
						//LOG.info("bomLevel >= 2");
						lttrTdResultList.get(i).setMli(mliArray[levelForMli]);		//setting mli
						lttrTdResultList.get(i).setPin(pinArray[levelForMli - 1]);	//setting pin
					}
				} else {
					//LOG.info("mli not found for all level");
					if (prefix1302Found && bomLevel ==  levelFor1302){
						//LOG.info("prefix1302Found && bomLevel ==  levelFor1302");
						lttrTdResultList.get(i).setMli(mliArray[levelFor1302]);		//setting mli
					} else {
						//LOG.info("else of prefix1302Found && bomLevel ==  levelFor1302");
						lttrTdResultList.get(i).setMli("");							//setting mli
					}
					if(bomLevel > 1){
						//LOG.info("bomLevel > 1");
						lttrTdResultList.get(i).setPin(pinArray[bomLevel - 1]);		//setting pin
					}
				}
				lastBomLevel = bomLevel;											// setting previous bom level
				lttrTdResultList.get(i).setHpin(pinArray[1]);						// setting hpin
			}
			// end : If bom level is equal to or greater than one	
		 }	
		// end : for loop	
		return lttrTdResultList;
	}
		
	/**
	 * This method is used for dropVolatileTablesForLttrReport
	 * 
	 * @param VT1Executed
	 * @param VT2Executed
	 * @param VT3Executed
	 * @param VT30Executed
	 * @param VT31Executed
	 * @param VT32Executed
	 * @param VT33Executed
	 * @param VT4Executed
	 * @param VT5Executed
	 * @return List
	 * @throws PLMCommonException
	 */
	/*private void dropVolatileTablesForLttrReport(boolean VT1Executed,boolean VT2Executed,
			boolean VT3Executed, boolean VT30Executed, boolean VT31Executed, 
			boolean VT32Executed, boolean VT33Executed, 
			boolean VT4Executed, boolean VT5Executed) throws PLMCommonException {
		boolean VT1ExecuteVal =VT1Executed;
		boolean VT2ExecuteVal = VT2Executed;
		boolean VT3ExecuteVal = VT3Executed; 
		boolean VT30ExecuteVal = VT30Executed; 
		boolean VT31ExecuteVal = VT31Executed; 
		boolean VT32ExecuteVal =VT32Executed; 
		boolean VT33ExecuteVal = VT33Executed; 
		boolean VT4ExecuteVal = VT4Executed; 
		boolean VT5ExecuteVal =VT5Executed;
		if (VT1ExecuteVal) {
			LOG.info("Query for Drop VT1 : " + PLMQueryConstants.DROP_LTTR_VT1);
			getJdbcTemplate().execute(PLMQueryConstants.DROP_LTTR_VT1);
			VT1ExecuteVal = false;
		}
		if (VT2ExecuteVal) {
			LOG.info("Query for Drop VT2 : " + PLMQueryConstants.DROP_LTTR_VT2);
			getJdbcTemplate().execute(PLMQueryConstants.DROP_LTTR_VT2);
			VT2ExecuteVal = false;
		}
		if (VT30ExecuteVal) {
			LOG.info("Query for Drop VT30 : " + PLMQueryConstants.DROP_LTTR_VT30);
			getJdbcTemplate().execute(PLMQueryConstants.DROP_LTTR_VT30);
			VT30ExecuteVal = false;
		}
		if (VT31ExecuteVal) {
			LOG.info("Query for Drop VT31 : " + PLMQueryConstants.DROP_LTTR_VT31);
			getJdbcTemplate().execute(PLMQueryConstants.DROP_LTTR_VT31);
			VT31ExecuteVal = false;
		}
		if (VT32ExecuteVal) {
			LOG.info("Query for Drop VT32 : " + PLMQueryConstants.DROP_LTTR_VT32);
			getJdbcTemplate().execute(PLMQueryConstants.DROP_LTTR_VT32);
			VT32ExecuteVal = false;
		}
		if (VT33ExecuteVal) {
			LOG.info("Query for Drop VT33 : " + PLMQueryConstants.DROP_LTTR_VT33);
			getJdbcTemplate().execute(PLMQueryConstants.DROP_LTTR_VT33);
			VT33ExecuteVal = false;
		}
		if (VT3ExecuteVal) {
			LOG.info("Query for Drop VT3 : " + PLMQueryConstants.DROP_LTTR_VT3);
			getJdbcTemplate().execute(PLMQueryConstants.DROP_LTTR_VT3);
			VT3ExecuteVal = false;
		}
		if (VT4ExecuteVal) {
			LOG.info("Query for Drop VT4 : " + PLMQueryConstants.DROP_LTTR_VT4);
			getJdbcTemplate().execute(PLMQueryConstants.DROP_LTTR_VT4);
			VT4ExecuteVal = false;
		}
		if (VT5ExecuteVal) {
			LOG.info("Query for Drop VT5 : " + PLMQueryConstants.DROP_LTTR_VT5);
			getJdbcTemplate().execute(PLMQueryConstants.DROP_LTTR_VT5);
			VT5ExecuteVal = false;
		}
	}*/
	/**
	 * Row mapper for getting tdLttrResultMapper1
	 */
	//private static ParameterizedRowMapper<PLMLttrData> tdLttrResultMapper1 = new ParameterizedRowMapper<PLMLttrData>() {
	private static final class TdLttrResultMapper1 implements ParameterizedRowMapper<PLMLttrData>{	
	public PLMLttrData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMLttrData tempData = new PLMLttrData();
			tempData.setBomLevel(rs.getInt(PLMConstants.LTTR_COL_BOM_LEVEL));
			String prefix = rs.getString(PLMConstants.LTTR_COL_PREFIX);
			tempData.setPrefix(PLMUtils.checkNullVal(prefix));
			tempData.setMli(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_MLI)));
			tempData.setPin(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_PIN)));
			tempData.setParentPdName(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_PARENT_PD_NAME)));
			tempData.setPdName(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_PD_NAME)));
			tempData.setPdNameDesc(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_PD_NAME_DESC)));
			tempData.setSuffix(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_SUFFIX)));	
			tempData.setQty(rs.getDouble(PLMConstants.LTTR_COL_QUANTITY));
			tempData.setUnitMeasure(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_UNIT_OF_MEASURE)));
			tempData.setDocName(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_DOC_NAME)));
			tempData.setDocRev(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_DOC_REV)));
			tempData.setDocDesc(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_DOC_DESC)));
			tempData.setDocType(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_DOC_TYPE)));
			tempData.setDocState(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_DOC_STATE)));
			tempData.setExportControl(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_EXPORT_CONTROL)));
			tempData.setDocClass(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_DOC_CLASS)));
			tempData.setMonthChange(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_LAST_MONTH_CHANGE)));
			tempData.setWeekChange(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_LAST_WEEK_CHANGE)));
			tempData.setDateChange(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_COL_DATE_TO_DATE_CHANGE)));
			tempData.setModelValidated(PLMUtils.checkNullVal(rs.getString(PLMConstants.LTTR_MODEL_VALIDATED)));
			tempData.setRowKey(rs.getInt("ROW_KEY"));
			return tempData;
		}
	//	};
	}
	/**
	 * Row mapper for getting tdLttrResultMapper
	 */
	//private static ParameterizedRowMapper<PLMLttrData> tdLttrResultMapper = new ParameterizedRowMapper<PLMLttrData>() {
	private static final class TdLttrResultMapper implements ParameterizedRowMapper<PLMLttrData>{	
	public PLMLttrData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMLttrData tempData = new PLMLttrData();
			tempData.setBomLevel(rs.getInt("LEVEL"));
			tempData.setParentPdName(PLMUtils.checkNullVal(rs.getString("PARENT_ITEM")));
			tempData.setPdName(PLMUtils.checkNullVal(rs.getString("CHILD_ITEM")));
			tempData.setPrntItemSrcType(PLMUtils.checkNullVal(rs.getString("PRNT_ITM_SRCE_TYPE_CD")));
			tempData.setCntntItemSrcType(PLMUtils.checkNullVal(rs.getString("CNTNT_ITM_SRCE_TYPE_CD")));
			tempData.setPathFlag("");
			return tempData;
		}
	//	};
	}
	/**
	 * This method is used for removeDuplicates
	 * 
	 * @param lttrTempOraResultList
	 * @return List
	 * @throws PLMCommonException
	 */
	/*public List<PLMLttrData> removeDuplicates(List<PLMLttrData> lttrTempOraResultList) throws PLMCommonException {
		LOG.info("Entering removeDuplicates Method");
		List<PLMLttrData> lttrOraResultList = new ArrayList<PLMLttrData>();
			if(!PLMUtils.isEmptyList(lttrTempOraResultList)){	
			for(int i = 0; i < lttrTempOraResultList.size(); i++) {
				PLMLttrData obj1 = lttrTempOraResultList.get(i);
				if(obj1 == null)
				 continue;
				for ( int j = i+1 ; j < lttrTempOraResultList.size(); j++ ){
					PLMLttrData obj2 = lttrTempOraResultList.get(j);
					if(obj2 == null)
					continue;
					if(checkEquality(obj1,obj2)){
						obj2 = null;
						lttrTempOraResultList.set(j,obj2);
						//LOG.info("Equal at j = " + j + " i = " + i );
					}
				}
			}
			for(int i = 0; i < lttrTempOraResultList.size(); i++) {
				PLMLttrData obj = lttrTempOraResultList.get(i);
				if(obj != null){
					lttrOraResultList.add(obj);
						}
				}
			}
		LOG.info("Exiting removeDuplicates Method");
		return lttrOraResultList;
	}*/
	
	/**
	 * This method is used for checkEquality
	 * 
	 * @param obj1,obj2
	 * @return boolean
	 */
	public boolean checkEquality(PLMLttrData obj1,PLMLttrData obj2){
			if(obj1.getRowKey() == obj2.getRowKey()) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * @return the LOG
	 */
	public static Logger getLOG() {
		return LOG;
	}
}