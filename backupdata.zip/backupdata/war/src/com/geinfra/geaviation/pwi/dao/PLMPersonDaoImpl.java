/**
 * Copyright (C) 2009 GE Infra. 
 * All rights reserved 
 * @FileName PLMPersonDaoImpl.java
 * @Creation date: 09-Nov-2009
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.model.PWiUserVO;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMQueryConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;

/**
 * ICMPersonDaoIfc is the DAO implementation class used for Validating the User
 * SSOID.
 */
public class PLMPersonDaoImpl extends SimpleJdbcDaoSupport implements
		PLMPersonDaoIfc {

	/**
	 * Holds the Logger.
	 */
	private static final Logger LOG = Logger.getLogger(PLMPersonDaoImpl.class);

	/**
	 * @return ICMUserData For validating the user ssoId
	 */
	public PLMLoginData validateUser(String ssoID) throws PLMCommonException {
		LOG.info(">> Person Details from IDM...");
		PLMLoginData user = new PLMLoginData();
		try {
			List<PLMLoginData> userInfoList = getSimpleJdbcTemplate().query(
					PLMQueryConstants.VALIDATE_PERSONAL, new QueryValUser(), ssoID);
			if (userInfoList.size() > 0) {
				user = userInfoList.get(0);
			} else {
				user.setSsoId(PLMConstants.EMPTY_STRING);
			}
		} catch (DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return user;
	}

	public PWiUserVO validateUserSSO(String ssoID) throws PLMCommonException {
		LOG.info(">> Person Details from IDM...");
		PWiUserVO user = new PWiUserVO();
		try {
			List<PWiUserVO> userInfoList = getSimpleJdbcTemplate().query(
					PLMQueryConstants.VALIDATE_PERSONAL, new PWIValUser(), ssoID);
			if (userInfoList.size() > 0) {
				user = userInfoList.get(0);
			} else {
				user.setSso(PLMConstants.EMPTY_STRING);
			}
		} catch (DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return user;
	}
	/**
	 * @return ICMUserData For validating the user ssoId
	 */
	//private static ParameterizedRowMapper<PLMLoginData> queryValUser = new ParameterizedRowMapper<PLMLoginData>() {
	private static final class QueryValUser implements ParameterizedRowMapper<PLMLoginData>{	
	public PLMLoginData mapRow(ResultSet rs, int rowNum) throws SQLException {
			PLMLoginData user = new PLMLoginData();
			user.setSsoId(rs.getString(PLMConstants.PERSON_NUM_SSO));
			user.setFirstName(rs.getString(PLMConstants.FT_NAM));
			user.setLastName(rs.getString(PLMConstants.LT_NAME));
			user.setEmail(rs.getString(PLMConstants.EADDRESS));
			user.setPhone(rs.getString(PLMConstants.WORK_PHONE));
			user.setFax(PLMConstants.EMPTY_STRING);
			user.setDepartment(rs.getString(PLMConstants.DEPARTMENT_NAME));
			user.setAddress(rs.getString(PLMConstants.LOCATION_NAME));
			user.setStatus(rs.getString(PLMConstants.PERSON_STATUS));
			user.setCity(rs.getString(PLMConstants.CITY));
			user.setState(rs.getString(PLMConstants.STATE));
			user.setCountry(rs.getString(PLMConstants.COUNTRY));
			user.setZipCode(PLMConstants.EMPTY_STRING);
			return user;
		}
	//	};
	}
	
	private static final class PWIValUser implements ParameterizedRowMapper<PWiUserVO>{	
		public PWiUserVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			PWiUserVO user = new PWiUserVO();
				user.setSso(rs.getString(PLMConstants.PERSON_NUM_SSO));
				user.setUserNm(rs.getString(PLMConstants.FT_NAM));
				user.setUserLastNm(rs.getString(PLMConstants.LT_NAME));
				user.setEmail(rs.getString(PLMConstants.EADDRESS));
				String status = rs.getString(PLMConstants.PERSON_STATUS);
				if(status.equals("Y") || status.equals("A"))
				{
					user.setEnabled(true);
				}
				else
				{
					user.setEnabled(false);
				}
				return user;
			}
		//	};
		}

}
