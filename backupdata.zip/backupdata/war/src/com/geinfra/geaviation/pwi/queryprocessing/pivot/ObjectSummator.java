package com.geinfra.geaviation.pwi.queryprocessing.pivot;

/**
 * Project : Product Lifecycle Management
 * Date Written : Apr 13, 2011 
 * Security : GE Confidential 
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : This is a simple inteface for use with the DataMatrix object.
 * Creating an class that implements this interface is a way to
 * add custom behavior to the DataMatrix class.
 * 
 * Revision Log Apr 13, 2011 | v1.0.
 * --------------------------------------------------------------
 * 
 * @author Ben Cronin
 */
public interface ObjectSummator
{
	/**
	 * The DataMatrix calls this function for every time one object is
	 * going to be overlayed on a previous one.
	 *
	 * @param columnName the String identifier of the column where Object
	 *					 b came from.  This is the name of the summary field.
	 * @param oldValue			 the previous value upon which b is overlayed.
	 * @param newValue			 the new value that will be overlayed on a.
	 * @return			 any Object representing a combination of a & b.
	 */
	 
	public Object summateObjects( String columnName, Object oldValue, Object newValue);
	
}
