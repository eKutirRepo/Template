/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName UICustomizeTitle.java
 * @Creation date: 18-Aug-2014
 * @version 1.0
  * @author : Tech Mahindra
 */
package com.geinfra.geaviation.pwi.faces;

import java.io.IOException;

import javax.el.ValueExpression;
import javax.faces.component.UIComponentBase;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;

import org.ajax4jsf.renderkit.RendererUtils;

public class UICustomizeTitle extends UIComponentBase {

	private String getTitleValue() {
		String title = null;
		ValueExpression ve = getValueExpression("value");
		if (ve != null) {
			title = (String) ve.getValue(getFacesContext().getELContext());
		} else {
			title = (String) getAttributes().get("value");
		}
		return title;
	}

	@Override
	public String getFamily() {
		return "customizeTitle";
	}

	public String getRendererType() {
		return "renderer";
	}

	public void encodeBegin(FacesContext context) throws IOException {
		ResponseWriter writer = context.getResponseWriter();

		// Open script tag
		writer.startElement("script", this);
		RendererUtils.getInstance().writeAttribute(writer, "type",
				"text/javascript");
		writer.write("\n//<![CDATA[\n");

		// Define function to execute when the document is ready
		writer.write("jQuery(document).ready(\n");
		writer.write("\tfunction() {\n");
		// Change browser title
		writer.write("\t\t// Change browser title\n");
		writer.write("\t\tdocument.title = \"" + getTitleValue()
				+ " - Power Warehouse Intelligence\";\n\n");
		// Change portlet title
		writer.write("\t\t// Change portlet title\n");
		writer.write("\t\tjQuery('.portlet-mast').html(\"" + getTitleValue()
				+ "\");\n");
		writer.write("\t}\n");
		writer.write(");\n");

		// Close script tag
		writer.write("//]]>\n");
		writer.endElement("script");
	}

	public void encodeEnd(FacesContext context) throws IOException {
		return;
	}

	public void decode(FacesContext context) {
		return;
	}
}
