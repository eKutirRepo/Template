/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCntrtSmryRptDaoImpl.java
 * @Creation date: 4-April-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMCntrtSmryRptData;
import com.geinfra.geaviation.pwi.data.PLMContractSmryData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMCntrtSmryRptDaoImpl extends SimpleJdbcDaoSupport implements PLMCntrtSmryRptDaoIfc  {
	/**
	 * Holds the Logger.
	 */
	private static final Logger LOG = Logger.getLogger(PLMCntrtSmryRptDaoImpl.class);
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
		 
	}
	/**
	 * This method is used to get Hardware Product Configuration List
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> getHardwarePrdctCnfgList1(String contractNm) throws PLMCommonException {
		LOG.info("Executing GET_HARDWARE_PRODUCT_INFO1 Query : " + PLMOfflineQueries.GET_HARDWARE_PRODUCT_INFO1 + "\n");
		LOG.info("contractNm in DAO------------->"+contractNm);
		return getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_HARDWARE_PRODUCT_INFO1, new HardwareProductConfigMapper1(), contractNm);			   
	}
	
	private static final class HardwareProductConfigMapper1 implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> hardwareProductConfigMapper1 = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData contractsumryreprtdata = new PLMCntrtSmryRptData();
			contractsumryreprtdata.setHardwareProduct(rs.getString("HARDWARE_PRODUCT"));
			contractsumryreprtdata.setProductConfiguration(rs.getString("PRODUCT_CONFIGURATION"));
			return contractsumryreprtdata;
		}
	}
	
	/**
	 * This method is used to get Hardware Product Configuration List
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> getHardwarePrdctCnfgList2(String contractNm) throws PLMCommonException {
		LOG.info("Executing GET_HARDWARE_PRODUCT_INFO2 Query : " + PLMOfflineQueries.GET_HARDWARE_PRODUCT_INFO2 + "\n");
		return getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_HARDWARE_PRODUCT_INFO2, new HardwareProductConfigMapper2(), contractNm);			   
	}
	private static final class HardwareProductConfigMapper2 implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> hardwareProductConfigMapper2 = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData contractsumryreprtdata = new PLMCntrtSmryRptData();
			contractsumryreprtdata.setHardwareProduct(rs.getString("HARDWARE_PRODUCT"));
			contractsumryreprtdata.setProductConfiguration(rs.getString("PRODUCT_CONFIGURATION"));
			return contractsumryreprtdata;
		}
	}
	/**
	 * This method is used to fetch Project Name List
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchProjectNameList(String contractNm) throws PLMCommonException{
		LOG.info("Executing GET_PROJECT_NAMES Query : " + PLMOfflineQueries.GET_PROJECT_NAMES + "\n");
		LOG.info("contractNm in DAO------------->"+contractNm);
		return getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_PROJECT_NAMES, new ProjectNameMapper(), contractNm);
	}
	private static final class ProjectNameMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> projectNameMapper = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			data.setProjectName(rs.getString("PROJECT_NAME"));
			data.setProjectTitle(rs.getString("PROJECT_TITLE"));
			return data;
		}
	}
	/**
	 * This method is used to fetch employee names and roles
	 * @param contractNm, prjName
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchEmpNamesNRoles(String contractNm,String prjName) throws PLMCommonException{
		LOG.info("Executing GET_EMPLOYEE_NAMES_ROLES Query : " + PLMOfflineQueries.GET_EMPLOYEE_NAMES_ROLES + "\n");
		LOG.info("contractNm in DAO------------->"+contractNm);
		LOG.info("prjName in DAO------------->"+prjName);
		return getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_EMPLOYEE_NAMES_ROLES, new NamesNRolesMapper(), new Object[] {contractNm,prjName});
	}
	private static final class NamesNRolesMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> namesNRolesMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			data.setSso(rs.getString("EMP_SSO"));
			data.setEmpName(rs.getString("EMP_NAME"));
			data.setEmpRole(rs.getString("PROJECT_ROLE"));
			return data;
		}
	}
	
	/**
	 * This method is used to fetch clin info
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchClinInfo(String contractNm, List<String> prdtTypeListClHb,boolean partTypeAllOpen) throws PLMCommonException{
		
		String timeStamp = PLMUtils.volTableFormatDate();
		String VT_TEMP_DT = PLMConstants.VT_CLIN.concat(timeStamp);
		StringBuffer query = new StringBuffer();
		query.append(PLMOfflineQueries.CREATE_VT_CLIN);
		if(prdtTypeListClHb.size()>0 && !partTypeAllOpen){
			query.append("AND CLIN.SOW_PARAGRAPH IN ("+ PLMUtils.setListForQuery(prdtTypeListClHb) +")");
		}
		query.append(PLMOfflineQueries.CREATE_VT_CLIN1);
		String str = query.toString().replace("?", contractNm).replace(PLMConstants.VT_CLIN, VT_TEMP_DT);
		LOG.info("Executing CREATE_VT_CLIN Query : " + str + "\n");
		LOG.info("contractNm in DAO------------->"+contractNm);
		getJdbcTemplate().execute(str);
		
		String str2 = PLMOfflineQueries.GET_CLIN_DATA.replace(PLMConstants.VT_CLIN, VT_TEMP_DT);
		LOG.info("Executing GET_CLIN_DATA Query : " + str2 + "\n");
		
		return getSimpleJdbcTemplate().query(str2, new ClinDataMapper());
	}
	private static final class ClinDataMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> clinDataMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			data.setClinNameParent(rs.getString("CLIN_NAME_PARENT"));
			data.setSowParagraph(rs.getString("SOWPARAGRAPH"));
			data.setClinInitialDeliveryDate(rs.getDate("CLIN_INITIAL_DELIVERY_DATE"));
			data.setClinDesc(rs.getString("CLIN_DESCRIPTION"));
			data.setClinStatus(rs.getString("CLIN_STATUS"));
			data.setSatisfiedByTask(rs.getString("SATISFIED_BY_TASK"));
			data.setCiNumber(rs.getString("CI_NUMBER"));
			data.setCeiQuantity(rs.getString("CEI_QUANTITY"));
			data.setClinIndicator(rs.getString("CLIN_INDICATOR"));
			data.setClinTasking(rs.getString("CLIN_TASKING"));
			return data;
		}
	}
	/**
	 * This method is used to fetch product requirement specific info
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchPrdtRqmntSpecInfo(String contractNm) throws PLMCommonException{
		LOG.info("Executing GET_PRODUCT_RQMNT_SPEC_DATA Query : " + PLMOfflineQueries.GET_PRODUCT_RQMNT_SPEC_DATA + "\n");
		LOG.info("contractNm in DAO------------->"+contractNm);
		return getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_PRODUCT_RQMNT_SPEC_DATA, new PrdtRqmntSpecMapper(), new Object[] {contractNm});
	}
	private static final class PrdtRqmntSpecMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> prdtRqmntSpecMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			data.setPrsId(rs.getString("PRS_ID"));
			data.setPrdtRqmntSpecNm(rs.getString("NAME"));
			data.setPrdtRqmntSpecDesc(rs.getString("DESCRIPTION"));
			data.setPrdtRqmntSpecTitleCol(rs.getString("TITLE_COL"));
			data.setPrdtRqmntSpecNotes(rs.getString("NOTES"));
			return data;
		}
	}
	/**
	 * This method is used to fetch crs info
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchCRSInfo(String contractNm) throws PLMCommonException{
		LOG.info("Executing GET_CRS_DATA Query : " + PLMOfflineQueries.GET_CRS_DATA + "\n");
		LOG.info("contractNm in DAO------------->"+contractNm);
		return getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_CRS_DATA, new CrsDataMapper(), new Object[] {contractNm});
	}
	private static final class CrsDataMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> crsDataMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			data.setCrsrId(rs.getString("CRS_ID"));
			data.setCrsName(rs.getString("NAME"));
			data.setCrsTitle(rs.getString("CRS_Title"));
			data.setCrsRevision(rs.getString("Revision"));
			data.setCrsState(rs.getString("State"));
			return data;
		}
	}
	/**
	 * This method is used to fetch hardware build info
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMCntrtSmryRptData> fetchHardwareBuildInfo(String contractNm, List<String> prdtTypeListClHb,boolean partTypeAllOpen) throws PLMCommonException{
		 StringBuffer query = new StringBuffer();
		 Map<String, Object> params = new HashMap<String, Object>();
		 params.put("CNTRT", contractNm);
		 query.append(PLMOfflineQueries.GET_HRDWRE_BUILD_DATA);
		 if(prdtTypeListClHb.size()>0 && !partTypeAllOpen){
			query.append(PLMOfflineQueries.GET_HRDWRE_BUILD_DATA1);
			params.put("PRDT", prdtTypeListClHb);
		 }
		LOG.info("Executing GET_HRDWRE_BUILD_DATA Query : " + query.toString() + "\n");
		LOG.info("contractNm in DAO------------->"+contractNm);
		return getNamedJdbcTemplate().query(query.toString(), params, new HBMapper()); 
	}
	private static final class HBMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> HBMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			data.setHbldNm(rs.getString("Name"));
			data.setHbldType(rs.getString("BuildType"));
			data.setHbldState(rs.getString("State"));
			data.setHbSrlNum(rs.getString("BuildSerialNumber"));
			data.setShpOrdrNum(rs.getString("SHOP_ORDER_NUM"));
			data.setHbActBldDt(rs.getDate("ActualBuildDate"));
			data.setHbDtShpd(rs.getDate("DateShipped"));
			data.setHbCstmr(rs.getString("Customer"));
			data.setHbPartNum(rs.getString("PartNumber"));
			data.setHbClinNm(rs.getString("CLIN_NAME"));
			return data;
		}
	}
	/**
	 * This method is used to fetchPLPList
	 * @param contractNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchPLPList(String contractNm) throws PLMCommonException{
		LOG.info("Executing GET_PLANT_LEVEL_PART Query : " + PLMOfflineQueries.GET_PLANT_LEVEL_PART + "\n");
		LOG.info("contractNm in DAO------------->"+contractNm);
		return getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_PLANT_LEVEL_PART, new PlpMapper(), contractNm);
	}
	private static final class PlpMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> plpMapper = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			data.setPLPName(rs.getString("TO_NAME"));
			return data;
		}
	}
	
	/**
	 * This method is used to fetchPRSRecursiveData
	 * @param prsNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchPRSRecursiveData(String prsNm) throws PLMCommonException{
		LOG.info("prsNm in DAO------------->"+prsNm);
		LOG.info("Executing GET_PRODUCT_RQMNT_SPEC_NM Query : " + PLMOfflineQueries.GET_PRODUCT_RQMNT_SPEC_NM + "\n");
		
		List<PLMCntrtSmryRptData> prsDataList =  getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_PRODUCT_RQMNT_SPEC_NM, 
				new PrdtRqmntSpecNameMapper(), new Object[] {prsNm});
		
		LOG.info("Executing GET_PRODUCT_RQMNT_SPEC_DATA_RECURSIVE Query : " + PLMOfflineQueries.GET_PRODUCT_RQMNT_SPEC_DATA_RECURSIVE + "\n");
		
		List<PLMCntrtSmryRptData>  prsRecrsLst = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_PRODUCT_RQMNT_SPEC_DATA_RECURSIVE, 
	    		 new PrsRecursiveMapper(), new Object[] {prsNm});

		if(!PLMUtils.isEmptyList(prsRecrsLst)){
			//formTreeStructForPRS(list,list.get(0).getPrsParentName());
			List<PLMCntrtSmryRptData> tempList = formTreeStruct(prsRecrsLst,prsNm);
			prsDataList.addAll(tempList);
			LOG.info("in dao filtered list.size()-------------->"+prsDataList.size());
		}
		return prsDataList;
	}
	
	/**
	 * This method is used to formTreeStruct
	 * @param prsList, prsName
	 * @return java.util.List
	 */
	public List<PLMCntrtSmryRptData> formTreeStruct(List<PLMCntrtSmryRptData> prsList,String prsName) {
        int bomLevel = 1;
        int index;
        int prevIndex = -1;
        String parentPdName = prsName;
        boolean childExist = true;
        List<PLMCntrtSmryRptData> prsFinalResultList =  new ArrayList<PLMCntrtSmryRptData>();
        while(true){
              index = findChildrens(prsList,parentPdName,prevIndex,bomLevel);
              if(index == -1){              
                    if(bomLevel == 1){
                          break;                  
                    }
                    prsList.get(prevIndex).setPathFlag("COMPLETED");
                    //LOG.info("Setting completed PathFlag in formTreeStructForPRS  ------>"+prsList.get(prevIndex).getChildName());
                    
                    childExist = getChildrenFlag(prsFinalResultList,prsList.get(prevIndex).getChildName(),prevIndex);
                    
                    if (!childExist && !prsList.get(prevIndex).getChildType().equals("Requirement")) {
                          
                          //LOG.info("Removing child from the list"+prsList.get(prevIndex).getChildName());
                          if (prsFinalResultList.size()>0) {
                                
                                for (int i=0;i<prsFinalResultList.size();i++){
                                      
                                      String remParent = prsFinalResultList.get(i).getPrsParentName();
                                      String remChild = prsFinalResultList.get(i).getChildName();
                                      String remLevel = prsFinalResultList.get(i).getPrsLevel();
                                      
                                      if (prsList.get(prevIndex).getPrsParentName().equals(remParent)
                                            && prsList.get(prevIndex).getChildName().equals(remChild)
                                            && prsList.get(prevIndex).getPrsLevel().equals(remLevel)) {
                                            
                                            prsFinalResultList.remove(i);
                                            
                                            i--;
                                      }
                                }
                          }
                    }
                    bomLevel = 1;
                    parentPdName = prsName;
              } else {
                    if(!prsList.get(index).getPathFlag().equals("VISITED")){
                          prsList.get(index).setPathFlag("VISITED");
                          //System.out.println("Setting Visited PathFlag in formTreeStructForPRS  ---------->"+prsList.get(index).getChildName());
                          prsFinalResultList.add(prsList.get(index));
                    }
                    prevIndex = index;      
                    bomLevel = bomLevel + 1;
                    parentPdName = prsList.get(index).getChildName();
              }
        }
        return prsFinalResultList;
  }
  
	/**
	 * This method is used to findChildrens
	 * @param prsList, parentPdName, prevIndex, bomLevel
	 * @return int
	 */
  public int findChildrens(List<PLMCntrtSmryRptData> prsList,String parentPdName,int prevIndex, int bomLevel) {
        int retIndex = -1;
        for(int i = 0 ; i < prsList.size();i++) {
              if(prsList.get(i).getPrsParentName().equals(parentPdName) && Integer.parseInt(prsList.get(i).getPrsLevel()) == bomLevel){
                    if(bomLevel == 1) {
                          if(!prsList.get(i).getPathFlag().equals("COMPLETED")){
                                retIndex = i;
                                break;
                          }
                    } else {
                          if(prsList.get(i).getPrsParentName().equals(prsList.get(prevIndex).getChildName())){
                                if(!prsList.get(i).getPathFlag().equals("COMPLETED")){
                                      retIndex = i;
                                      break;
                                } 
                          }
                    }
              }
        }
        return retIndex;
  }
  
  /**
	 * This method is used to getChildrenFlag
	 * @param prsList, parentPdName, prevIndex
	 * @return boolean
	 */
  public boolean getChildrenFlag(List<PLMCntrtSmryRptData> prsList,String parentPdName,int prevIndex) {
        
        boolean childExist = true;
        int childCntr = 0;
        if (prsList!=null) {
        	for (int i=0;i<prsList.size();i++) {
        		if(prsList.get(i).getPrsParentName().equals(parentPdName)){
        			childCntr++;
                }
            }
        }
        if (childCntr==0) {
        	childExist =false;
        }
        return childExist;
  }
  private static final class PrdtRqmntSpecNameMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//		private static ParameterizedRowMapper<PLMCntrtSmryRptData> prdtRqmntSpecMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
			public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
					throws SQLException {
				PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
				data.setPrsLevel("0");
				data.setPrsChildId(rs.getString("PRS_ID"));
				data.setChildName(rs.getString("NAME"));
				data.setChildDesc(rs.getString("DESCRIPTION"));
				data.setChildTitle(rs.getString("TITLE_COL"));
				data.setPrsReqNotes(rs.getString("NOTES"));
				data.setTopPrsLvlFlag(true);
				data.setPrsReqFlag(false);
				data.setPrsChapterFlg(false);
				return data;
			}
		}
	
	/**
	 * @return PLMCntrtSmryRptData
	 */
  private static final class PrsRecursiveMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//  private static ParameterizedRowMapper<PLMCntrtSmryRptData> prsRecursiveMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			
			data.setPrsLevel(rs.getString("LEVEL"));
			data.setPrsChildId(rs.getString("CHILD_ID"));
			data.setPrsParentName(rs.getString("PARENT_NAME"));
			data.setPrsParentType(rs.getString("PARENT_TYPE"));
			data.setChildName(rs.getString("CHILD_NAME"));
			data.setChildType(rs.getString("CHILD_TYPE"));
			data.setChildDesc(rs.getString("CHILD_DESC"));
			data.setChildTitle(rs.getString("CHILD_TITLE"));
			data.setPrsReqNotes(rs.getString("REQ_NOTES"));
			data.setIndicator(rs.getString("INDICATR"));
			data.setUom(rs.getString("UOM"));
			data.setReqmtValue(rs.getString("REQUIREMENT_VALUE"));
			data.setDfsOrder(rs.getString("DFSORDER"));
			data.setPathFlag("");
			
			if(rs.getString("CHILD_NAME").contains("R-")){
				data.setPrsReqFlag(true);
				data.setPrsChapterFlg(false);
			}else if(rs.getString("CHILD_NAME").contains("CHAP-")){
				data.setPrsChapterFlg(true);
				data.setPrsReqFlag(false);
			}
			data.setTopPrsLvlFlag(false);
			return data;
		}
	}
	
	/**
	 * This method is used to formTreeStructForPRS
	 * @param prsList, parentName
	 * @return java.util.List
	 */
	public List<PLMCntrtSmryRptData> formTreeStructForPRS(List<PLMCntrtSmryRptData> prsList,String parentName) {
		int level = 1;
		int index;
		int prevIndex = -1;
		String parentPdName = parentName;
		List<PLMCntrtSmryRptData> prsFinalList =  new ArrayList<PLMCntrtSmryRptData>();
		while(true){
			index = findChildrensPrs(prsList,parentPdName,prevIndex,level);
			if(index == -1){			
				if(level == 1){
					break;			
				}
				prsList.get(prevIndex).setPathFlag("COMPLETED");
				//LOG.info("Setting completed PathFlag in formTreeStructForPRS  ---------->"+prsList.get(prevIndex).getPrsParentName());
				level = 1;
				parentPdName = parentName;
				} else {
				if(!prsList.get(index).getPathFlag().equals("VISITED")){
					prsList.get(index).setPathFlag("VISITED");
					//LOG.info("Setting Visited PathFlag in formTreeStructForPRS  ---------->"+prsList.get(prevIndex).getPrsParentName());
					prsList.get(index).setPrsFlag(index+"");
					prsFinalList.add(prsList.get(index));
				}
				prevIndex = index;	
				level = level + 1;
				parentPdName = prsList.get(index).getChildName();
			}
		}
		return prsFinalList;
	}
	
	/**
	 * This method is used to findChildrensPrs
	 * @param prsList, parentPdName, prevIndex, level
	 * @return int
	 */
	public int findChildrensPrs(List<PLMCntrtSmryRptData> prsList,String parentPdName,int prevIndex, int level) {
		int retIndex = -1;
		for(int i = 0 ; i < prsList.size();i++) {
			if(prsList.get(i).getChildName().equals(parentPdName) && Integer.parseInt(prsList.get(i).getPrsLevel()) == level){
				if(level == 1) {
					if(!prsList.get(i).getPathFlag().equals("COMPLETED")){
						retIndex = i;
						break;
					}
				} else {
					if(prsList.get(i).getPrsParentName().equals(prsList.get(prevIndex).getChildName())){
						if(!prsList.get(i).getPathFlag().equals("COMPLETED")){
							retIndex = i;
							break;
						} 
					}
				}
			}
		}
		return retIndex;
	}

	
	
	/**
	 * This method is used to save fetchCRSRecursiveData
	 * @param crsNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */	
	public List<PLMCntrtSmryRptData> fetchCRSRecursiveData(
			String cntrtNm, String crsNm, String level, List<String> prdtTypeListCrs,boolean partTypeAllOpen) throws PLMCommonException{
		
		LOG.info("Executing GET_CRS_NM_DATA Query : " + PLMOfflineQueries.GET_CRS_NM_DATA + "\n");
		LOG.info("crsNm in DAO------------->"+crsNm);
		List<PLMCntrtSmryRptData> crsNmList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_CRS_NM_DATA,
				new CrsNmDataMapper(), new Object[] {crsNm});
		
		String timeStamp = PLMUtils.volTableFormatDate();
		String VT_TEMP_DT = PLMConstants.VT_CRS.concat(timeStamp);
		StringBuffer query = new StringBuffer();
		query.append(PLMOfflineQueries.CREATE_VT_CRS);
		if(prdtTypeListCrs.size()>0 && !partTypeAllOpen){
			query.append(" GROUP BY LEVEL, CR_ID, NAME, SPECN_DESC, SPECN_TITLE, SPECN_STATE, LF_ID, LF_NAME, ENTERPRISE_IDNFR, H.DFSORDER");
		}
		query.append(PLMOfflineQueries.CREATE_VT_CRS1);
		String str = query.toString().replace("?", crsNm).replace("#", level).replace(PLMConstants.VT_CRS, VT_TEMP_DT);
		LOG.info("Executing CREATE_VT_CRS Query : " + str + "\n");
		LOG.info("crsNm in DAO------------->"+crsNm);
		LOG.info("level in DAO------------->"+level);
		getJdbcTemplate().execute(str);
		
		//String timeStamp1 = PLMUtils.volTableFormatDate();
		String VT_TEMP_DT1 = PLMConstants.VT_MLI_CRS.concat(timeStamp);
		
		StringBuffer mliCrs = new StringBuffer();
		
		mliCrs.append(PLMOfflineQueries.CREATE_VT_MLI_CRS);		
		mliCrs.append(PLMOfflineQueries.CREATE_VT_MLI_CRS1);
		
		String str1 = mliCrs.toString().replace("?", cntrtNm).replace(PLMConstants.VT_MLI_CRS, VT_TEMP_DT1)
		.replace(PLMConstants.VT_CRS, VT_TEMP_DT);
		LOG.info("Executing CREATE_VT_MLI_CRS Query : " + str1 + "\n");
		LOG.info("crsNm in DAO------------->"+crsNm);
		getJdbcTemplate().execute(str1);
		
		//String timeStamp2 = PLMUtils.volTableFormatDate();
		String VT_TEMP_DT2 = PLMConstants.VT_CG_CRS.concat(timeStamp);
		StringBuffer query2 = new StringBuffer();
		query2.append(PLMOfflineQueries.CREATE_VT_CG_CRS);
		if(prdtTypeListCrs.size()>0 && !partTypeAllOpen){
			query2.append(" WHERE GE_COST_GRP IN ("+PLMUtils.setListForQuery(prdtTypeListCrs)+")");
		}
		query2.append(PLMOfflineQueries.CREATE_VT_CG_CRS1);
		
		String str2 = query2.toString().replace(PLMConstants.VT_CG_CRS, VT_TEMP_DT2)
		.replace(PLMConstants.VT_CRS, VT_TEMP_DT)
		.replace(PLMConstants.VT_MLI_CRS, VT_TEMP_DT1);
		LOG.info("Executing CREATE_VT_CG_CRS Query : " + str2 + "\n");
		LOG.info("prdtTypeListCrs in DAO------------->"+prdtTypeListCrs);
		getJdbcTemplate().execute(str2);
		
		String str3 = PLMOfflineQueries.GET_CRS_DATA_NEW.replace(PLMConstants.VT_CG_CRS, VT_TEMP_DT2);
		LOG.info("Executing GET_CRS_DATA_NEW Query : " + str3 + "\n");
		
		List<PLMCntrtSmryRptData> crsList = getSimpleJdbcTemplate().query(str3, new CrsRecursiveMapper());
		
		 if(!PLMUtils.isEmptyList(crsList)){
			 Collections.sort(crsList, new SortCrsDfsOrder());
			 crsNmList.addAll(crsList);
		 }
		return crsNmList;
	}
	
	private static final class CrsNmDataMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//		private static ParameterizedRowMapper<PLMCntrtSmryRptData> crsDataMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
			public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
					throws SQLException {
				PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
				data.setCrsrLevel("0");
				data.setCrsrId(rs.getString("CRS_ID"));
				data.setCrsrName(rs.getString("NAME"));
				data.setCrsrTitle(rs.getString("CRS_Title"));
				data.setCrsrRevision("-");
				data.setCrsrtoType(rs.getString("State"));
				data.setTopCrsLvlFlag(true);
				data.setCrsChapterFlg(false);
				data.setCrsReqFlg(false);
				return data;
			}
		}
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class CrsRecursiveMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> crsRecursiveMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			data.setCrsrLevel(rs.getString("LEVEL"));
			data.setCrsrId(rs.getString("CR_ID"));
			data.setCrsrName(rs.getString("NAME"));
			data.setCrsrTitle(rs.getString("SPECN_TITLE"));
			data.setCrsrRevision(rs.getString("ENTERPRISE_IDNFR"));
			data.setCrsrtoType(rs.getString("SPECN_STATE"));
			data.setDfsOrder(rs.getString("DFSORDER"));
			data.setCrsrDesc(rs.getString("SPECN_DESC"));
			data.setPcCstGrp(rs.getString("GE_COST_GRP"));
			
			if(rs.getString("NAME").contains("CHAP-")){
				data.setCrsChapterFlg(true);
				data.setCrsReqFlg(false);
			}else{
				data.setCrsReqFlg(true);
				data.setCrsChapterFlg(false);
			}

			data.setTopCrsLvlFlag(false);		
			return data;
		}
	}
	
	/**
	 * 
	 * class to sort list of object of type PLMCntrtSmryRptData.
	 * 
	 */
	private static class SortCrsDfsOrder implements Comparator<PLMCntrtSmryRptData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMCntrtSmryRptData aString,
				PLMCntrtSmryRptData bString) {
			String aStr;
			String bStr;
			int result=0;
			aStr = aString.getDfsOrder();
			bStr = bString.getDfsOrder();
			if(aStr != null && bStr != null){
			result = aStr.compareTo(bStr);
			}
			return result;
			
		}
	}
	
	/**
	 * This method is used to fetchProductConfigData
	 * @param hrdwrPrdctNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchProductConfigData(String hrdwrPrdctNm) throws PLMCommonException{
		LOG.info("Executing GET_PRODUCT_CONFIGURATION_DATA Query : " + PLMOfflineQueries.GET_PRODUCT_CONFIGURATION_DATA + "\n");
		LOG.info("hrdwrPrdctNm in DAO------------->"+hrdwrPrdctNm);
		return getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_PRODUCT_CONFIGURATION_DATA, new ProductConfigMapper(), new Object[] {hrdwrPrdctNm});
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class ProductConfigMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> productConfigMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			data.setPcName(rs.getString("Name"));
			data.setPcDesc(rs.getString("Description"));
			data.setPcBasedOn(rs.getString("Based_On"));
			data.setPcState(rs.getString("State"));
			data.setPcParentPc(rs.getString("Parent_PC"));
			data.setPcTopLevelParent(rs.getString("TOP_LVL_PARENT"));
			data.setPcDerviedFrom(rs.getString("DERIVED_FROM"));
			data.setPcPurpose(rs.getString("Purpose"));
			return data;
		}
	}
	
	/**
	 * This method is used to fetcLogicalFeauturesData
	 * @param hrdwrPrdctNm, contractNum
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetcLogicalFeauturesData(String hrdwrPrdctNm, String contractNum,List<String> crsNmList) throws PLMCommonException{
		String timeStamp = PLMUtils.volTableFormatDate();
		String VT_CRS_CNF = PLMConstants.VT_CRS_CNF.concat(timeStamp);
		boolean crsFlag=false;
		boolean vtLfflag=false;
		boolean vtflag2 = false;
		if(crsNmList.size()>0){
			StringBuffer query = new StringBuffer();
			query.append(PLMOfflineQueries.CREATE_VT_CRS_CNF);
			query.append(" GROUP BY LEVEL, CR_ID, NAME, SPECN_TITLE, SPECN_STATE, LF_ID, LF_NAME, ENTERPRISE_IDNFR");
			query.append(PLMOfflineQueries.CREATE_VT_CRS1);
			String str = query.toString().replace("?", PLMUtils.setListForQuery(crsNmList)).replace(PLMConstants.VT_CRS_CNF, VT_CRS_CNF);
			LOG.info("Executing CREATE_VT_CRS_CNF Query : " + str + "\n"); 
			LOG.info("crsNm in DAO------------->"+crsNmList.size());
			getJdbcTemplate().execute(str);
			crsFlag=true;
		 }
		
		if(crsFlag){
			LOG.info("Query for Collect STATS VT_CRS_CNF : " + PLMOfflineQueries.VT_CRS_CNF_COL_STATS.replace(PLMConstants.VT_CRS_CNF, VT_CRS_CNF));
			getJdbcTemplate().execute(PLMOfflineQueries.VT_CRS_CNF_COL_STATS.replace(PLMConstants.VT_CRS_CNF, VT_CRS_CNF));
		}
		
		String VT_DT = PLMConstants.VT_LF.concat(timeStamp);
		String VT_DT_DATA = PLMConstants.VT_LF_DATA.concat(timeStamp);
		
		String createVTDtQry = PLMOfflineQueries.CREATE_VT_LF.replace("?", hrdwrPrdctNm).replace(PLMConstants.VT_LF, VT_DT);
		LOG.info("Executing CREATE_VT_LF Query : " + createVTDtQry + "\n");
		getJdbcTemplate().execute(createVTDtQry);
		
		vtLfflag=true;
		
		if(vtLfflag){
			LOG.info("Query for Collect STATS VT_LF : " + PLMOfflineQueries.VT_LF_COL_STATS.replace(PLMConstants.VT_LF, VT_DT));
			getJdbcTemplate().execute(PLMOfflineQueries.VT_LF_COL_STATS.replace(PLMConstants.VT_LF, VT_DT));
		}
		
		
		StringBuffer logicalquery = new StringBuffer();
		logicalquery.append(PLMOfflineQueries.CREATE_VT_LF_DATA.replace(PLMConstants.VT_LF_DATA, VT_DT_DATA));
		logicalquery.append(PLMOfflineQueries.CREATE_VT_LF_DATA1.replace(PLMConstants.VT_LF, VT_DT));
		 if(crsFlag){
			 logicalquery.append(" ,VT.NAME AS CR_NAME");
		 }
		 else{
			 logicalquery.append(" ,NULL AS CR_NAME");
		 }
		logicalquery.append(PLMOfflineQueries.CREATE_VT_LF_DATA2);
		
		if(crsFlag){
			String appendVtCrs = PLMOfflineQueries.GET_VT_LF_VTCRSCNF.replace(PLMConstants.VT_CRS_CNF, VT_CRS_CNF);
			logicalquery.append(appendVtCrs);
		 }
		logicalquery.append(PLMOfflineQueries.CREATE_VT_LF_DATA3);
		
		String str1 = logicalquery.toString().replace("?", hrdwrPrdctNm);
		
		LOG.info("Executing CREATE_VT_LF_DATA Query : " + str1 + "\n");
		LOG.info("hrdwrPrdctNm in DAO------------->"+hrdwrPrdctNm);
		getJdbcTemplate().execute(str1);
		vtflag2=true;
		if(vtflag2){
			LOG.info("Query for Collect STATS VT_LF : " + PLMOfflineQueries.VT_LF_COL_STATS2.replace(PLMConstants.VT_LF, VT_DT));
			getJdbcTemplate().execute(PLMOfflineQueries.VT_LF_COL_STATS2.replace(PLMConstants.VT_LF, VT_DT));
		}
		
		
		
		
		StringBuffer logicalFinalquery = new StringBuffer();
		logicalFinalquery.append(PLMOfflineQueries.GET_LOGICAL_FEATURES_DATA.replace(PLMConstants.VT_LF_DATA, VT_DT_DATA));
		LOG.info("Executing GET_LOGICAL_FEATURES_DATA Query : " + logicalFinalquery + "\n");
		List <PLMCntrtSmryRptData> logicFeatureDataList = getSimpleJdbcTemplate().query(logicalFinalquery.toString(), new LogicalFeauturesMapper());
		Collections.sort(logicFeatureDataList, new SortFtrDsplyName());
		return logicFeatureDataList;
	}
	/** 
	 * 
	 * class to sort list of object of type PLMCntrtSmryRptData.
	 * 
	 */
	private static class SortFtrDsplyName implements Comparator<PLMCntrtSmryRptData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMCntrtSmryRptData aString,
				PLMCntrtSmryRptData bString) {
			String aStr;
			String bStr;
			int result=0;
			aStr = aString.getLfFeatDsplName();
			bStr = bString.getLfFeatDsplName();
			if(aStr != null && bStr != null){
			result = aStr.compareTo(bStr);
			}
			return result;
			
		}
	}

	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class LogicalFeauturesMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> logicalFeauturesMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			data.setLfLevel(rs.getString("LVL"));
			data.setLfFeatDsplName(rs.getString("FEAT_DISPLAY_NAME"));
			data.setLfFeatName(rs.getString("FEAT_NAME"));
			data.setLfFeatDesc(rs.getString("FEAT_DESC"));
			data.setLfFeatId(rs.getString("FEAT_ID"));
			data.setCrName(rs.getString("CR_LIST"));
			return data;
		}
	}
	
	/**
	 * This method is used to fetcConfigEndItemsData
	 * @param hrdwrPrdctNm, contractNum
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetcConfigEndItemsData(String hrdwrPrdctNm, String contractNum,List<String> crsNmList) throws PLMCommonException{
		
		String timeStamp = PLMUtils.volTableFormatDate();
		String VT_CRS_CEI = PLMConstants.VT_CRS_CEI.concat(timeStamp);
		boolean crsFlag=false;
		if(crsNmList.size()>0){
			StringBuffer query = new StringBuffer();
			query.append(PLMOfflineQueries.CREATE_VT_CRS_CEI);
			query.append(" GROUP BY LEVEL, CR_ID, NAME, SPECN_TITLE, SPECN_STATE, LF_ID, LF_NAME, ENTERPRISE_IDNFR");
			query.append(PLMOfflineQueries.CREATE_VT_CRS1);
			String str = query.toString().replace("?", PLMUtils.setListForQuery(crsNmList)).replace(PLMConstants.VT_CRS_CEI, VT_CRS_CEI);
			LOG.info("Executing CREATE_VT_CRS_CEI Query : " + str + "\n"); 
			LOG.info("crsNm in DAO------------->"+crsNmList.size());
			getJdbcTemplate().execute(str);
			crsFlag=true;
		 }
			
		String VT_CEI = PLMConstants.VT_CEI.concat(timeStamp);
		String VT_CEI_DATA = PLMConstants.VT_CEI_DATA.concat(timeStamp);
		
		LOG.info("Executing CREATE VT_CEI Query : " + PLMOfflineQueries.CREATE_VT_CEI.replace(PLMConstants.VT_CEI, VT_CEI).replace("?", hrdwrPrdctNm)); 
		LOG.info("crsNm in DAO------------->"+crsNmList.size());
		getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VT_CEI.replace(PLMConstants.VT_CEI, VT_CEI).replace("?", hrdwrPrdctNm));
		
		StringBuffer confEndItmquery = new StringBuffer();
		confEndItmquery.append(PLMOfflineQueries.CREATE_VT_CEI_DATA1.replace(PLMConstants.VT_CEI_DATA, VT_CEI_DATA));
		confEndItmquery.append(PLMOfflineQueries.CREATE_VT_CEI_DATA2.replace(PLMConstants.VT_CEI, VT_CEI).replace("?", hrdwrPrdctNm));
		 if(crsFlag){
			 confEndItmquery.append(" ,VT.NAME AS CR_NAME");
		 }
		 else{
			 confEndItmquery.append(" ,NULL AS CR_NAME");
		 }
		 confEndItmquery.append(PLMOfflineQueries.CREATE_VT_CEI_DATA3);
		
		if(crsFlag){
			String appendVtCrs = PLMOfflineQueries.GET_VT_CEI_VTCRS.replace(PLMConstants.VT_CRS_CEI, VT_CRS_CEI);
			confEndItmquery.append(appendVtCrs);
		 }
		confEndItmquery.append(PLMOfflineQueries.CREATE_VT_CEI_DATA4);
		
		LOG.info("Executing CREATE_VT_CEI_DATA Query : " + confEndItmquery + "\n");
		LOG.info("hrdwrPrdctNm in DAO------------->"+hrdwrPrdctNm);
		getJdbcTemplate().execute(confEndItmquery.toString());
	
		String str = PLMOfflineQueries.GET_CONFIGURATION_END_ITEMS.replace(PLMConstants.VT_CEI_DATA, VT_CEI_DATA);
		LOG.info("Executing GET_CONFIGURATION_END_ITEMS Query : " + str + "\n");
		List <PLMCntrtSmryRptData> configEndItemsList=getSimpleJdbcTemplate().query(str, new ConfigEndItemsMapper());
		Collections.sort(configEndItemsList, new SortCIDisplayName());
		return configEndItemsList;
	}
	
	/**
	 * 
	 * class to sort list of object of type PLMCntrtSmryRptData.
	 * 
	 */
	private static class SortCIDisplayName implements Comparator<PLMCntrtSmryRptData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMCntrtSmryRptData aString,
				PLMCntrtSmryRptData bString) {
			String aStr;
			String bStr;
			int result=0;
			aStr = aString.getCeDispName();
			bStr = bString.getCeDispName();
			if(aStr != null && bStr != null){
			result = aStr.compareTo(bStr);
			}
			return result;
			
		}
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class ConfigEndItemsMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> configEndItemsMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			data.setCeLevel(rs.getString("LVL"));
			data.setCeDispName(rs.getString("CI_DISP_NM"));
			data.setCeName(rs.getString("CI_NAME"));
			data.setCeDesc(rs.getString("CI_DESC"));
			data.setCeId(rs.getString("CI_ID"));
			data.setCrName(rs.getString("CR_LIST"));
			return data;
		}
	}
	
	/**
	 * This method is used to fetchCustReqData
	 * @param hrdwrPrdctNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchCustReqData(String hrdwrPrdctNm) throws PLMCommonException{
		LOG.info("Executing GET_CUSTOMER_REQUIREMENTS Query : " + PLMOfflineQueries.GET_CUSTOMER_REQUIREMENTS + "\n");
		LOG.info("hrdwrPrdctNm in DAO------------->"+hrdwrPrdctNm);
		return getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_CUSTOMER_REQUIREMENTS, new CustReqMapper(), new Object[] {hrdwrPrdctNm});
	}
	

	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class CustReqMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> custReqMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			data.setCrName(rs.getString("CR_NAME"));
			data.setCrTitle(rs.getString("CR_TITLE"));
			data.setCrState(rs.getString("CR_STATE"));
			data.setCrSatisfiedBy(rs.getString("SATISFIED_BY"));
			data.setCrEntrpIdnFr(rs.getString("ENTERPRISE_IDNFR"));
			return data;
		}
	}
	
	/**
	 * This method is used to fetCostObjectsData
	 * @param hrdwrPrdctNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetCostObjectsData(String level, List<String> prdtTypeListCrs,boolean partTypeAllOpen,String contractNum,String hrdwrPrdctNm) throws PLMCommonException{
		LOG.info("Entering in to fetCostObjectsData");
		LOG.info("Contract Number in DAO------------->"+contractNum);
		LOG.info("PC NAme in DAO------------->"+hrdwrPrdctNm);
		LOG.info("prdtTypeListCrs in DAO------------->"+prdtTypeListCrs);
		LOG.info("level in DAO------------->"+level);
		String timeStamp = PLMUtils.volTableFormatDate();
		
		//Executing VT_CRS volatile Query
		String VT_CRS = PLMConstants.VT_CRS.concat(timeStamp);
		StringBuffer createVT_CRS = new StringBuffer();
		createVT_CRS.append(PLMOfflineQueries.CREATE_VT_CRS_FOR_CO);
		if(prdtTypeListCrs.size()>0 && !partTypeAllOpen){
			createVT_CRS.append(" GROUP BY LEVEL, CR_ID, NAME, SPECN_DESC, SPECN_TITLE, SPECN_STATE, LF_ID, LF_NAME, ENTERPRISE_IDNFR, H.DFSORDER");
		}
		createVT_CRS.append(PLMOfflineQueries.CREATE_VT_CRS_FOR_CO_1);
		String createVT_CRSQry = createVT_CRS.toString().replace("?", "'"+contractNum+"'").replace("#", level).replace(PLMConstants.VT_CRS, VT_CRS);
		LOG.info("Executing CREATE_VT_CRS for Cost Object Query : " + createVT_CRSQry+ "\n");
		getJdbcTemplate().execute(createVT_CRSQry);
		
		//Executing VT_MLI_CRS volatile Query
		String VT_MLI_CRS = PLMConstants.VT_MLI_CRS.concat(timeStamp);
		StringBuffer mliCrs = new StringBuffer();
		mliCrs.append(PLMOfflineQueries.CREATE_VT_MLI_CRS);		
		mliCrs.append(PLMOfflineQueries.CREATE_VT_MLI_CRS1);
		String mliCrsQuery = mliCrs.toString().replace(PLMConstants.VT_MLI_CRS, VT_MLI_CRS).replace(PLMConstants.VT_CRS, VT_CRS);
		LOG.info("Executing CREATE_VT_MLI_CRS for Cost Object Query : " + mliCrsQuery + "\n");
		getJdbcTemplate().execute(mliCrsQuery);
		
		//Executing VT_CG_CRS volatile Query
		String VT_CG_CRS = PLMConstants.VT_CG_CRS.concat(timeStamp);
		StringBuffer vtcgcrs = new StringBuffer();
		vtcgcrs.append(PLMOfflineQueries.CREATE_VT_CG_CRS);
		if(prdtTypeListCrs.size()>0 && !partTypeAllOpen){
			vtcgcrs.append(" WHERE GE_COST_GRP IN ("+PLMUtils.setListForQuery(prdtTypeListCrs)+")");
		}
		vtcgcrs.append(PLMOfflineQueries.CREATE_VT_CG_CRS1);
		String vtCGCRSQry = vtcgcrs.toString().replace(PLMConstants.VT_CG_CRS, VT_CG_CRS)
		.replace(PLMConstants.VT_CRS, VT_CRS).replace(PLMConstants.VT_MLI_CRS, VT_MLI_CRS);
		LOG.info("Executing CREATE_VT_CG_CRS Query for Cost Object: " + vtCGCRSQry + "\n");
		getJdbcTemplate().execute(vtCGCRSQry);
		
		//Executing Final Cost Objects Query
		LOG.info("Executing Final Query for Cost Object: " + PLMOfflineQueries.GET_COST_OBJECTS.replace(PLMConstants.VT_CG_CRS, VT_CG_CRS));
		return getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_COST_OBJECTS.replace(PLMConstants.VT_CG_CRS, VT_CG_CRS),
				new CostObjsMapper(), new Object[] {hrdwrPrdctNm});
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class CostObjsMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> costObjsMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			data.setCoId(rs.getString("CO_ID"));
			data.setCoName(rs.getString("CO_NAME"));
			data.setCoState(rs.getString("CO_STATE"));
			data.setCoCrId(rs.getString("CR_ID"));
			data.setCoCrName(rs.getString("CR_NAME"));
			data.setCoCrState(rs.getString("CR_STATE"));
			data.setCoFeatName(rs.getString("FEAT_NAME"));
			data.setCoDesc(rs.getString("FEAT_DESC"));
			return data;
		}
	}
	/**
	 * This method is used to fetchTpLvlBomPrtData
	 * @param hrdwrPrdctNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchTpLvlBomPrtData(String hrdwrPrdctNm) throws PLMCommonException{
		LOG.info("Executing GET_TOP_LVL_BOM_PART Query : " + PLMOfflineQueries.GET_TOP_LVL_BOM_PART + "\n");
		LOG.info("hrdwrPrdctNm in DAO------------->"+hrdwrPrdctNm);
		return getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_TOP_LVL_BOM_PART, new TpLvlBomPrtMapper(), new Object[] {hrdwrPrdctNm});
	}
	

	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class TpLvlBomPrtMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> tpLvlBomPrtMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			data.setTopName(rs.getString("TO_NAME"));
			return data;
		}
	}
	
	/**
	 * This method is used to fetchCntrInfo
	 * @param cntrtNm
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<PLMCntrtSmryRptData> fetchCntrInfo(String cntrtNm) throws PLMCommonException{
		LOG.info("Contract Name in DAO------------->"+cntrtNm);
		return getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_CNTRT_INFO, new CntrInfoMapper(), new Object[] {cntrtNm});
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class CntrInfoMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> cntrInfoMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			data.setCntrtNm(rs.getString("NM"));
			data.setCntrtDesc(rs.getString("DESCRIPTION"));
			return data;
		}
	}
	
	/**
	 * This method is used to fetchCstGrpData
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	public List<String> fetchCstGrpData() throws PLMCommonException{
		LOG.info("Executing GET_CST_GRP_DATA Query : " + PLMOfflineQueries.GET_CST_GRP_DATA + "\n");
		return getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_CST_GRP_DATA, new CstGrpMapper());
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class CstGrpMapper implements ParameterizedRowMapper<String> {
//	private static ParameterizedRowMapper<String> cstGrpMapper  = new ParameterizedRowMapper<String>() {
		public String mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			String cstGrpNm = rs.getString(PLMUtils.checkNullVal("GE_COST_GRP"));
			return cstGrpNm;
		}
	}
	
	/**
	 * This method is used to fetchPCInfo
	 * @param cntrtNm, cstGrpList
	 * @return java.util.List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMCntrtSmryRptData> fetchPCInfo(String cntrtNm) throws PLMCommonException{
		StringBuffer searchQuery =new StringBuffer();
		Map<String, Object> params = new HashMap<String, Object>();
		searchQuery.append(PLMOfflineQueries.GET_PC_FOR_CNTRT_QUERY);
		params.put("CNTRT", cntrtNm);
		//params.put("CSTGRP", cstGrpList);
		LOG.info("Executing GET_PC_INFO_QUERY : " + searchQuery.toString() + "\n");
		LOG.info("Contract Name in DAO------------->"+cntrtNm);
		return getNamedJdbcTemplate().query(searchQuery.toString(),params, new PcInfoMapper());
	}
	
	/**
	 * @return PLMCntrtSmryRptData objects.
	 */
	private static final class PcInfoMapper implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
//	private static ParameterizedRowMapper<PLMCntrtSmryRptData> pcInfoMapper  = new ParameterizedRowMapper<PLMCntrtSmryRptData>() {
		public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
			data.setHwPrdctNm(PLMUtils.checkNullVal(rs.getString("HW_PRDT")));
			data.setPrdtConfigNm(PLMUtils.checkNullVal(rs.getString("PRDT_CFGN")));
			data.setPrdtConfigDesc(PLMUtils.checkNullVal(rs.getString("PRDT_CFGN_DESC")));
			data.setIsOption(PLMUtils.checkNullVal(rs.getString("IS_OPTION")));
			data.setPcCstGrp(PLMUtils.checkNullVal(rs.getString("GE_COST_GRP")));
			return data;
		}
	}
	
	//Newly Added by srinivas for contract summary on screen Report
	/**
	 * This method is used for get Product Configuration
	 * 
	 * @return List
	 * @param cntrtNm,costGroup
	 * @throws PLMCommonException
	 */
		@SuppressWarnings("unchecked")
		public List<PLMContractSmryData> fetchProductConf(String cntrtNm) throws PLMCommonException{
			LOG.info("Entering in to fetchProductConf method");
			StringBuffer searchQuery =new StringBuffer();
			Map<String, Object> params = new HashMap<String, Object>();
			searchQuery.append(PLMOfflineQueries.GET_PC_FOR_CNTRT_QUERY);
			params.put("CNTRT", cntrtNm);
			//params.put("CSTGRP", costGroup);
			LOG.info("Executing fetchProductConf : " + searchQuery.toString() + "\n");
			LOG.info("Contract Name in DAO------------->"+cntrtNm);
			//LOG.info("Cost Group in DAO------------->"+costGroup);
			return getNamedJdbcTemplate().query(searchQuery.toString(),params, new ProductConfMapper());
			
		}
		
		/**
		 * @return PLMCntrtSmryRptData objects.
		 */
		private static final class ProductConfMapper implements ParameterizedRowMapper<PLMContractSmryData> {
	//	private static ParameterizedRowMapper<PLMContractSmryData> ProductConfMapper  = new ParameterizedRowMapper<PLMContractSmryData>() {
			public PLMContractSmryData mapRow(ResultSet rs, int rowcount)
					throws SQLException {
				PLMContractSmryData data = new PLMContractSmryData();
				data.setHwPrdctNm(PLMUtils.checkNullVal(rs.getString("HW_PRDT")));
				data.setPrdtConfigNm(PLMUtils.checkNullVal(rs.getString("PRDT_CFGN")));
				data.setPrdtConfigDesc(PLMUtils.checkNullVal(rs.getString("PRDT_CFGN_DESC")));
				data.setIsOption(PLMUtils.checkNullVal(rs.getString("IS_OPTION")));
				data.setPcCstGrp(PLMUtils.checkNullVal(rs.getString("GE_COST_GRP")));
				return data;
			}
		}
		
					
//Newly added for contract Summary Email Enhancement
			
			/**
			 * This method is used to fetch Config Features Data with PC Name
			 * 
			 * @param PCName
			 * @return List 
			 * @throws PLMCommonException
			 */
		//Commented code for Configuration Features old query and logic
		/* public List<PLMCntrtSmryRptData> fetchConfFeaturesPCNmData(String contractNum,String PCName,boolean notRequireFlg,boolean noSubTypeFlg) throws PLMCommonException{
	
			 StringBuffer SqlQuery=new StringBuffer();
			 SqlQuery.append(PLMOfflineQueries.GET_CONFIGURATION_FEATURES_PCNM_DATA1);
			 if(notRequireFlg){
				 SqlQuery.append(PLMOfflineQueries.CONFIGURATION_FEATURES_SEL_OPT);
			 }
			 if(noSubTypeFlg){
				 SqlQuery.append(PLMOfflineQueries.CONFIGURATION_FEATURES_SUB_OPT_TYPE);
			 }
			 SqlQuery.append(PLMOfflineQueries.GET_CONFIGURATION_FEATURES_PCNM_DATA2);
				LOG.info("Executing GET_CONFIGURATION_FEATURES_PCNM_DATA With PCName Query : " +SqlQuery.toString() + "\n");
				 List<PLMCntrtSmryRptData> finalconfFeaturePCNmList = new ArrayList<PLMCntrtSmryRptData>();
				 PLMCntrtSmryRptData tempData1 = new PLMCntrtSmryRptData();
				 
				 tempData1.setSystemFlag(true);
				 tempData1.setCfName("Aux Values");
				 finalconfFeaturePCNmList.add(tempData1);
				 tempData1 = new PLMCntrtSmryRptData();
				 
				 tempData1.setSystemFlag(true);
				 tempData1.setCfName("UNITED STATES:MASSACHUSETTS A");
				 finalconfFeaturePCNmList.add(tempData1);
			 
				 
				 String cfName="";
				 String cfConfOption="";
	        	LOG.info("PCName in DAO------------->"+PCName);
				List<PLMCntrtSmryRptData> confFeaturePCNmList= getSimpleJdbcTemplate().query(SqlQuery.toString(), new ConfigFeaturesPCNMMapper(), 
						new Object[] {contractNum,PCName,PCName,PCName,PCName});
			if(confFeaturePCNmList.size()>0){
			  for(int i=0;i<confFeaturePCNmList.size();i++){
			    	if(!cfName.equals(confFeaturePCNmList.get(i).getCfName()) &&
							!cfConfOption.equals(confFeaturePCNmList.get(i).getCfConfigOption())){	 
						 PLMCntrtSmryRptData tempData = new PLMCntrtSmryRptData();
						 tempData.setCfId(confFeaturePCNmList.get(i).getCfId());
						 tempData.setCfName(confFeaturePCNmList.get(i).getCfName());
						 tempData.setCfConfId(confFeaturePCNmList.get(i).getCfConfId());
						 tempData.setCfDisplyName(confFeaturePCNmList.get(i).getCfDisplyName());
						 tempData.setCfConfigOption(confFeaturePCNmList.get(i).getCfConfigOption());
						 tempData.setCfConfOptDispName(confFeaturePCNmList.get(i).getCfConfOptDispName());
						 tempData.setFeqSeqOrder(confFeaturePCNmList.get(i).getFeqSeqOrder());
						 tempData.setOptSubType(confFeaturePCNmList.get(i).getOptSubType());
						 tempData.setLegacyFACode(confFeaturePCNmList.get(i).getLegacyFACode());
						 tempData.setSystemFlag(false);
						 finalconfFeaturePCNmList.add(tempData);
					  } else {
						  if((PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqId()) && 
									 PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqName()) &&
									 PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqDesc()))
									 ){
							PLMCntrtSmryRptData tempData = new PLMCntrtSmryRptData();
							//tempData.setCfId(confFeaturePCNmList.get(i).getCfId());
							//tempData.setCfName(confFeaturePCNmList.get(i).getCfName());
							tempData.setCfConfId(confFeaturePCNmList.get(i).getCfConfId());
							tempData.setCfDisplyName(confFeaturePCNmList.get(i).getCfDisplyName());
							tempData.setCfConfigOption(confFeaturePCNmList.get(i).getCfConfigOption());
							tempData.setCfConfOptDispName(confFeaturePCNmList.get(i).getCfConfOptDispName());
							tempData.setFeqSeqOrder(confFeaturePCNmList.get(i).getFeqSeqOrder());
							tempData.setOptSubType(confFeaturePCNmList.get(i).getOptSubType());
							tempData.setLegacyFACode(confFeaturePCNmList.get(i).getLegacyFACode());
							tempData.setSystemFlag(false);
							finalconfFeaturePCNmList.add(tempData);
						  }
					  }
						 if((!PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqId()) || 
								 !PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqName()) ||
								 !PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqDesc()))
								 && (PLMUtils.isEmpty(confFeaturePCNmList.get(i).getCrFlag()) || confFeaturePCNmList.get(i).getCrFlag().equals("Y"))){
							 PLMCntrtSmryRptData tempData = new PLMCntrtSmryRptData();
							 tempData.setCfConfId(confFeaturePCNmList.get(i).getReqId());
							 tempData.setCfConfigOption(confFeaturePCNmList.get(i).getReqName());
							 tempData.setCfConfOptDispName(confFeaturePCNmList.get(i).getReqDesc());
							 //tempData.setFeqSeqOrder(confFeaturePCNmList.get(i).getFeqSeqOrder());
							 tempData.setSystemFlag(false);
							 finalconfFeaturePCNmList.add(tempData);
						 }
						 cfName=confFeaturePCNmList.get(i).getCfName();
						 cfConfOption=confFeaturePCNmList.get(i).getCfConfigOption();
					 }
				 }
				return finalconfFeaturePCNmList;
			}*/
		

		/**
		 * This method is used to fetch Config Features Data with PC Name
		 * 
		 * @param PCName
		 * @return List 
		 * @throws PLMCommonException
		 */
	//Updated code for adding system names for  Configuration Features query and logic
	 public List<PLMCntrtSmryRptData> fetchConfFeaturesCostGrpData(String contractNum,List<String> pcNameList,boolean notRequireFlg,boolean noSubTypeFlg,boolean categoryFlag) throws PLMCommonException{

		 StringBuffer SqlQuery=new StringBuffer();
		 List<PLMCntrtSmryRptData> tempconfFeaturePCNmList = new ArrayList<PLMCntrtSmryRptData>();
		 List<PLMCntrtSmryRptData> finalconfFeaturePCNmList = new ArrayList<PLMCntrtSmryRptData>();
             
		 
		    SqlQuery.append("SELECT * FROM (");	 
			 SqlQuery.append(PLMOfflineQueries.GET_CONFIGURATION_FEATURES_COSTGRP_SYS_DATA1.replace("#", PLMUtils.setListForQuery(pcNameList)));
			 if(notRequireFlg){
				 SqlQuery.append(PLMOfflineQueries.CONFIGURATION_FEATURES_SEL_OPT);
			 }
			 if(noSubTypeFlg){
				 SqlQuery.append(PLMOfflineQueries.CONFIGURATION_FEATURES_SUB_OPT_TYPE);
			 }
			 
			 SqlQuery.append(PLMOfflineQueries.GET_CONFIGURATION_FEATURES_PCNM_SYS_DATA2);
			 
			 SqlQuery.append(PLMOfflineQueries.GET_CONFIGURATION_FEATURES_UNION.replace("#", PLMUtils.setListForQuery(pcNameList)));
			 SqlQuery.append(") TM ORDER  BY CO_SYS_NM, CO_SEQ_ID, CF_SEQ_ORDER, CF_ID, CO_ID, REQ_ID");	
			 
		//	 System.out.println();
			 
				LOG.info("Executing GET_CONFIGURATION_FEATURES_PCNM_DATA With PCName Query : " +SqlQuery.toString() + "\n");
				 
				 String sysName="";
				 String cfName="";
				 String cfConfOption="";
	        	LOG.info("PCName in DAO------------->"+pcNameList);
				List<PLMCntrtSmryRptData> confFeaturePCNmList= getSimpleJdbcTemplate().query(SqlQuery.toString(), new ConfigFeaturesPCNMMapper1(), 
						new Object[] {contractNum,contractNum});
			if(confFeaturePCNmList.size()>0){
			  for(int i=0;i<confFeaturePCNmList.size();i++){
			    	if((!cfName.equals(confFeaturePCNmList.get(i).getCfName()) &&
							!cfConfOption.equals(confFeaturePCNmList.get(i).getCfConfigOption()) &&
							(sysName.equals(confFeaturePCNmList.get(i).getSystemName()) ||
									!sysName.equals(confFeaturePCNmList.get(i).getSystemName()))) ||
									
						(cfName.equals(confFeaturePCNmList.get(i).getCfName()) && !sysName.equals(confFeaturePCNmList.get(i).getSystemName())) 		
									
			    			){	 
						 PLMCntrtSmryRptData tempData = new PLMCntrtSmryRptData();
						 tempData.setCfId(confFeaturePCNmList.get(i).getCfId());
						 tempData.setCfName(confFeaturePCNmList.get(i).getCfName());
						 tempData.setCfConfId(confFeaturePCNmList.get(i).getCfConfId());
						 tempData.setCfDisplyName(confFeaturePCNmList.get(i).getCfDisplyName());
						 tempData.setCfConfigOption(confFeaturePCNmList.get(i).getCfConfigOption());
						 tempData.setCfConfOptDispName(confFeaturePCNmList.get(i).getCfConfOptDispName());
						 tempData.setFeqSeqOrder(confFeaturePCNmList.get(i).getFeqSeqOrder());
						 tempData.setOptSubType(confFeaturePCNmList.get(i).getOptSubType());
						 tempData.setLegacyFACode(confFeaturePCNmList.get(i).getLegacyFACode());
						 tempData.setSystemName(confFeaturePCNmList.get(i).getSystemName());
						 tempData.setKeyInValue(confFeaturePCNmList.get(i).getKeyInValue());
						 tempData.setSystemFlag(false);
						 tempconfFeaturePCNmList.add(tempData);
					  } else if((cfName.equals(confFeaturePCNmList.get(i).getCfName()) &&
								!cfConfOption.equals(confFeaturePCNmList.get(i).getCfConfigOption()) &&
								(sysName.equals(confFeaturePCNmList.get(i).getSystemName()) ||
										!sysName.equals(confFeaturePCNmList.get(i).getSystemName()))) 
				    			){	 
							 PLMCntrtSmryRptData tempData = new PLMCntrtSmryRptData();
							 //tempData.setCfId(confFeaturePCNmList.get(i).getCfId());
							 //tempData.setCfName(confFeaturePCNmList.get(i).getCfName());
							 tempData.setCfConfId(confFeaturePCNmList.get(i).getCfConfId());
							 tempData.setCfDisplyName(confFeaturePCNmList.get(i).getCfDisplyName());
							 tempData.setCfConfigOption(confFeaturePCNmList.get(i).getCfConfigOption());
							 tempData.setCfConfOptDispName(confFeaturePCNmList.get(i).getCfConfOptDispName());
							 tempData.setFeqSeqOrder(confFeaturePCNmList.get(i).getFeqSeqOrder());
							 tempData.setOptSubType(confFeaturePCNmList.get(i).getOptSubType());
							 tempData.setLegacyFACode(confFeaturePCNmList.get(i).getLegacyFACode());
							 tempData.setSystemName(confFeaturePCNmList.get(i).getSystemName());
							 tempData.setKeyInValue(confFeaturePCNmList.get(i).getKeyInValue());
							 tempData.setSystemFlag(false);
							 tempconfFeaturePCNmList.add(tempData);
					  } 
					  
					  else if((!cfName.equals(confFeaturePCNmList.get(i).getCfName()) &&
							  	cfConfOption.equals(confFeaturePCNmList.get(i).getCfConfigOption()) &&
								(sysName.equals(confFeaturePCNmList.get(i).getSystemName()) ||
										!sysName.equals(confFeaturePCNmList.get(i).getSystemName()))) 
				    			){	 
							 PLMCntrtSmryRptData tempData = new PLMCntrtSmryRptData();
							 tempData.setCfId(confFeaturePCNmList.get(i).getCfId());
							 tempData.setCfName(confFeaturePCNmList.get(i).getCfName());
							// tempData.setCfConfId(confFeaturePCNmList.get(i).getCfConfId());
							 tempData.setCfDisplyName(confFeaturePCNmList.get(i).getCfDisplyName());
							 //tempData.setCfConfigOption(confFeaturePCNmList.get(i).getCfConfigOption());
							// tempData.setCfConfOptDispName(confFeaturePCNmList.get(i).getCfConfOptDispName());
							 tempData.setFeqSeqOrder(confFeaturePCNmList.get(i).getFeqSeqOrder());
							 tempData.setOptSubType(confFeaturePCNmList.get(i).getOptSubType());
							 tempData.setLegacyFACode(confFeaturePCNmList.get(i).getLegacyFACode());
							 tempData.setSystemName(confFeaturePCNmList.get(i).getSystemName());
							 tempData.setKeyInValue(confFeaturePCNmList.get(i).getKeyInValue());
							 tempData.setSystemFlag(false);
							 tempconfFeaturePCNmList.add(tempData);
					  }
					  
					  
					  
					  else {
						  if((PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqId()) && 
									 PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqName()) &&
									 PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqDesc())) 								 
									 ){
							PLMCntrtSmryRptData tempData = new PLMCntrtSmryRptData();
							//tempData.setCfId(confFeaturePCNmList.get(i).getCfId());
							//tempData.setCfName(confFeaturePCNmList.get(i).getCfName());
							tempData.setCfConfId(confFeaturePCNmList.get(i).getCfConfId());
							tempData.setCfDisplyName(confFeaturePCNmList.get(i).getCfDisplyName());
							tempData.setCfConfigOption(confFeaturePCNmList.get(i).getCfConfigOption());
							tempData.setCfConfOptDispName(confFeaturePCNmList.get(i).getCfConfOptDispName());
							tempData.setFeqSeqOrder(confFeaturePCNmList.get(i).getFeqSeqOrder());
							tempData.setOptSubType(confFeaturePCNmList.get(i).getOptSubType());
							tempData.setLegacyFACode(confFeaturePCNmList.get(i).getLegacyFACode());
							tempData.setSystemName(confFeaturePCNmList.get(i).getSystemName());
							 tempData.setKeyInValue(confFeaturePCNmList.get(i).getKeyInValue());
							tempData.setSystemFlag(false);
							tempconfFeaturePCNmList.add(tempData);
						  }
					  }
						 if((!PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqId()) || 
								 !PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqName()) ||
								 !PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqDesc()))
								 && (PLMUtils.isEmpty(confFeaturePCNmList.get(i).getCrFlag()) || confFeaturePCNmList.get(i).getCrFlag().equals("Y"))){
							 PLMCntrtSmryRptData tempData = new PLMCntrtSmryRptData();
							 tempData.setCfConfId(confFeaturePCNmList.get(i).getReqId());
							 tempData.setCfConfigOption(confFeaturePCNmList.get(i).getReqName());
							 tempData.setCfConfOptDispName(confFeaturePCNmList.get(i).getReqDesc());
							 tempData.setSystemName(confFeaturePCNmList.get(i).getSystemName());
							 //tempData.setFeqSeqOrder(confFeaturePCNmList.get(i).getFeqSeqOrder());
							 tempData.setKeyInValue(confFeaturePCNmList.get(i).getKeyInValue());
							 tempData.setSystemFlag(false);
							 tempconfFeaturePCNmList.add(tempData);
						 }
						 cfName=confFeaturePCNmList.get(i).getCfName();
						 cfConfOption=confFeaturePCNmList.get(i).getCfConfigOption();
						 sysName=confFeaturePCNmList.get(i).getSystemName();
					 }
			  

				    String systemNm="";
				    cfConfOption="";
			  		for(int j=0;j<tempconfFeaturePCNmList.size();j++){
			  			if(!systemNm.equals(tempconfFeaturePCNmList.get(j).getSystemName())){	 
			  				PLMCntrtSmryRptData finalData = new PLMCntrtSmryRptData();
			  				finalData.setSystemName(tempconfFeaturePCNmList.get(j).getSystemName());
			  				finalData.setSystemFlag(true);
			  				finalconfFeaturePCNmList.add(finalData);
			  			}
			  			
			  			//if(!cfConfOption.equals(tempconfFeaturePCNmList.get(j).getCfConfigOption())){
				  			PLMCntrtSmryRptData finalData = new PLMCntrtSmryRptData();
				  			finalData.setCfId(tempconfFeaturePCNmList.get(j).getCfId());
				  			finalData.setCfName(tempconfFeaturePCNmList.get(j).getCfName());
				  			finalData.setCfConfId(tempconfFeaturePCNmList.get(j).getCfConfId());
				  			finalData.setCfDisplyName(tempconfFeaturePCNmList.get(j).getCfDisplyName());
				  			finalData.setCfConfigOption(tempconfFeaturePCNmList.get(j).getCfConfigOption());
				  			finalData.setCfConfOptDispName(tempconfFeaturePCNmList.get(j).getCfConfOptDispName());
				  			finalData.setFeqSeqOrder(tempconfFeaturePCNmList.get(j).getFeqSeqOrder());
				  			finalData.setOptSubType(tempconfFeaturePCNmList.get(j).getOptSubType());
				  			finalData.setLegacyFACode(tempconfFeaturePCNmList.get(j).getLegacyFACode());
				  			finalData.setKeyInValue(confFeaturePCNmList.get(j).getKeyInValue());
				  			finalData.setSystemFlag(false);
				  			finalconfFeaturePCNmList.add(finalData);
			  			//}
			  			
			  			systemNm=tempconfFeaturePCNmList.get(j).getSystemName();
			  			//cfConfOption=tempconfFeaturePCNmList.get(j).getCfConfigOption();
			  		}
			  
				 }
			return finalconfFeaturePCNmList;
		}
		
		/**
		 * This method is used to fetch Config Features Data with PC Name
		 * 
		 * @param PCName
		 * @return List 
		 * @throws PLMCommonException
		 */
	//Updated code for adding system names for  Configuration Features query and logic
	 public List<PLMCntrtSmryRptData> fetchConfFeaturesPCNmData(String contractNum,String PCName,boolean notRequireFlg,boolean noSubTypeFlg,boolean categoryFlag) throws PLMCommonException{

		 StringBuffer SqlQuery=new StringBuffer();
		 List<PLMCntrtSmryRptData> tempconfFeaturePCNmList = new ArrayList<PLMCntrtSmryRptData>();
		 List<PLMCntrtSmryRptData> finalconfFeaturePCNmList = new ArrayList<PLMCntrtSmryRptData>();

		 if(categoryFlag){
			 SqlQuery.append(PLMOfflineQueries.GET_CONFIGURATION_FEATURES_PCNM_SYS_DATA1);
			 if(notRequireFlg){
				 SqlQuery.append(PLMOfflineQueries.CONFIGURATION_FEATURES_SEL_OPT);
			 }
			 if(noSubTypeFlg){
				 SqlQuery.append(PLMOfflineQueries.CONFIGURATION_FEATURES_SUB_OPT_TYPE);
			 }
			 SqlQuery.append(PLMOfflineQueries.GET_CONFIGURATION_FEATURES_PCNM_SYS_DATA2);
				LOG.info("Executing GET_CONFIGURATION_FEATURES_PCNM_DATA With PCName Query : " +SqlQuery.toString() + "\n");
				 
				 String sysName="";
				 String cfName="";
				 String cfConfOption="";
	        	LOG.info("PCName in DAO------------->"+PCName);
				List<PLMCntrtSmryRptData> confFeaturePCNmList= getSimpleJdbcTemplate().query(SqlQuery.toString(), new ConfigFeaturesPCNMMapper1(), 
						new Object[] {contractNum,PCName,PCName,PCName,PCName});
			if(confFeaturePCNmList.size()>0){
			  for(int i=0;i<confFeaturePCNmList.size();i++){
			    	if((!cfName.equals(confFeaturePCNmList.get(i).getCfName()) &&
							!cfConfOption.equals(confFeaturePCNmList.get(i).getCfConfigOption()) &&
							(sysName.equals(confFeaturePCNmList.get(i).getSystemName()) ||
									!sysName.equals(confFeaturePCNmList.get(i).getSystemName()))) ||
									
						(cfName.equals(confFeaturePCNmList.get(i).getCfName()) && !sysName.equals(confFeaturePCNmList.get(i).getSystemName())) 		
									
			    			){	 
						 PLMCntrtSmryRptData tempData = new PLMCntrtSmryRptData();
						 tempData.setCfId(confFeaturePCNmList.get(i).getCfId());
						 tempData.setCfName(confFeaturePCNmList.get(i).getCfName());
						 tempData.setCfConfId(confFeaturePCNmList.get(i).getCfConfId());
						 tempData.setCfDisplyName(confFeaturePCNmList.get(i).getCfDisplyName());
						 tempData.setCfConfigOption(confFeaturePCNmList.get(i).getCfConfigOption());
						 tempData.setCfConfOptDispName(confFeaturePCNmList.get(i).getCfConfOptDispName());
						 tempData.setFeqSeqOrder(confFeaturePCNmList.get(i).getFeqSeqOrder());
						 tempData.setOptSubType(confFeaturePCNmList.get(i).getOptSubType());
						 tempData.setLegacyFACode(confFeaturePCNmList.get(i).getLegacyFACode());
						 tempData.setKeyInValue(confFeaturePCNmList.get(i).getKeyInValue());
						 tempData.setSystemName(confFeaturePCNmList.get(i).getSystemName());
						 tempData.setSystemFlag(false);
						 tempconfFeaturePCNmList.add(tempData);
					  } else {
						  if((PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqId()) && 
									 PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqName()) &&
									 PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqDesc())) 								 
									 ){
							PLMCntrtSmryRptData tempData = new PLMCntrtSmryRptData();
							//tempData.setCfId(confFeaturePCNmList.get(i).getCfId());
							//tempData.setCfName(confFeaturePCNmList.get(i).getCfName());
							tempData.setCfConfId(confFeaturePCNmList.get(i).getCfConfId());
							tempData.setCfDisplyName(confFeaturePCNmList.get(i).getCfDisplyName());
							tempData.setCfConfigOption(confFeaturePCNmList.get(i).getCfConfigOption());
							tempData.setCfConfOptDispName(confFeaturePCNmList.get(i).getCfConfOptDispName());
							tempData.setFeqSeqOrder(confFeaturePCNmList.get(i).getFeqSeqOrder());
							tempData.setOptSubType(confFeaturePCNmList.get(i).getOptSubType());
							tempData.setLegacyFACode(confFeaturePCNmList.get(i).getLegacyFACode());
							 tempData.setKeyInValue(confFeaturePCNmList.get(i).getKeyInValue());
							tempData.setSystemName(confFeaturePCNmList.get(i).getSystemName());
							tempData.setSystemFlag(false);
							tempconfFeaturePCNmList.add(tempData);
						  }
					  }
						 if((!PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqId()) || 
								 !PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqName()) ||
								 !PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqDesc()))
								 && (PLMUtils.isEmpty(confFeaturePCNmList.get(i).getCrFlag()) || confFeaturePCNmList.get(i).getCrFlag().equals("Y"))){
							 PLMCntrtSmryRptData tempData = new PLMCntrtSmryRptData();
							 tempData.setCfConfId(confFeaturePCNmList.get(i).getReqId());
							 tempData.setCfConfigOption(confFeaturePCNmList.get(i).getReqName());
							 tempData.setCfConfOptDispName(confFeaturePCNmList.get(i).getReqDesc());
							 tempData.setSystemName(confFeaturePCNmList.get(i).getSystemName());
							 //tempData.setFeqSeqOrder(confFeaturePCNmList.get(i).getFeqSeqOrder());
							 tempData.setKeyInValue(confFeaturePCNmList.get(i).getKeyInValue());
							 tempData.setSystemFlag(false);
							 tempconfFeaturePCNmList.add(tempData);
						 }
						 cfName=confFeaturePCNmList.get(i).getCfName();
						 cfConfOption=confFeaturePCNmList.get(i).getCfConfigOption();
						 sysName=confFeaturePCNmList.get(i).getSystemName();
					 }
			  

				    String systemNm="";
				    cfConfOption="";
			  		for(int j=0;j<tempconfFeaturePCNmList.size();j++){
			  			if(!systemNm.equals(tempconfFeaturePCNmList.get(j).getSystemName())){	 
			  				PLMCntrtSmryRptData finalData = new PLMCntrtSmryRptData();
			  				finalData.setSystemName(tempconfFeaturePCNmList.get(j).getSystemName());
			  				finalData.setSystemFlag(true);
			  				finalconfFeaturePCNmList.add(finalData);
			  			}
			  			
			  			//if(!cfConfOption.equals(tempconfFeaturePCNmList.get(j).getCfConfigOption())){
				  			PLMCntrtSmryRptData finalData = new PLMCntrtSmryRptData();
				  			finalData.setCfId(tempconfFeaturePCNmList.get(j).getCfId());
				  			finalData.setCfName(tempconfFeaturePCNmList.get(j).getCfName());
				  			finalData.setCfConfId(tempconfFeaturePCNmList.get(j).getCfConfId());
				  			finalData.setCfDisplyName(tempconfFeaturePCNmList.get(j).getCfDisplyName());
				  			finalData.setCfConfigOption(tempconfFeaturePCNmList.get(j).getCfConfigOption());
				  			finalData.setCfConfOptDispName(tempconfFeaturePCNmList.get(j).getCfConfOptDispName());
				  			finalData.setFeqSeqOrder(tempconfFeaturePCNmList.get(j).getFeqSeqOrder());
				  			finalData.setOptSubType(tempconfFeaturePCNmList.get(j).getOptSubType());
				  			finalData.setLegacyFACode(tempconfFeaturePCNmList.get(j).getLegacyFACode());
				  			finalData.setKeyInValue(confFeaturePCNmList.get(j).getKeyInValue());
				  			finalData.setSystemFlag(false);
				  			finalconfFeaturePCNmList.add(finalData);
			  			//}
			  			
			  			systemNm=tempconfFeaturePCNmList.get(j).getSystemName();
			  			//cfConfOption=tempconfFeaturePCNmList.get(j).getCfConfigOption();
			  		}
			  
				 }
		 }else{
			 SqlQuery.append("SELECT * FROM (");
			 SqlQuery.append(PLMOfflineQueries.GET_CONFIGURATION_FEATURES_PCNM_DATA1);
			 if(notRequireFlg){
				 SqlQuery.append(PLMOfflineQueries.CONFIGURATION_FEATURES_SEL_OPT);
			 }
			 if(noSubTypeFlg){
				 SqlQuery.append(PLMOfflineQueries.CONFIGURATION_FEATURES_SUB_OPT_TYPE);
			 }
			 SqlQuery.append(PLMOfflineQueries.GET_CONFIGURATION_FEATURES_PCNM_DATA2);
			 SqlQuery.append(PLMOfflineQueries.GET_CONFIGURATION_FEATURES_UNION_UNASSIGNED);
			 SqlQuery.append(") TM ORDER BY FEAT_SEQ_ORDER,CF_ID,CO_ID,REQ_ID");
			 
				LOG.info("Executing GET_CONFIGURATION_FEATURES_PCNM_DATA With PCName Query : " +SqlQuery.toString() + "\n");
				 
				 String cfName="";
				 String cfConfOption="";
	        	LOG.info("PCName in DAO------------->"+PCName);
				List<PLMCntrtSmryRptData> confFeaturePCNmList= getSimpleJdbcTemplate().query(SqlQuery.toString(), new ConfigFeaturesPCNMMapper2(), 
						new Object[] {contractNum,PCName,PCName,PCName,PCName,contractNum,PCName,PCName,PCName});
			if(confFeaturePCNmList.size()>0){
			  for(int i=0;i<confFeaturePCNmList.size();i++){
			    	if(!cfName.equals(confFeaturePCNmList.get(i).getCfName()) &&
							!cfConfOption.equals(confFeaturePCNmList.get(i).getCfConfigOption())){	 
						 PLMCntrtSmryRptData tempData = new PLMCntrtSmryRptData();
						 tempData.setCfId(confFeaturePCNmList.get(i).getCfId());
						 tempData.setCfName(confFeaturePCNmList.get(i).getCfName());
						 tempData.setCfConfId(confFeaturePCNmList.get(i).getCfConfId());
						 tempData.setCfDisplyName(confFeaturePCNmList.get(i).getCfDisplyName());
						 tempData.setKeyInValue(confFeaturePCNmList.get(i).getKeyInValue());
						 tempData.setCfConfigOption(confFeaturePCNmList.get(i).getCfConfigOption());
						 tempData.setCfConfOptDispName(confFeaturePCNmList.get(i).getCfConfOptDispName());
						 tempData.setFeqSeqOrder(confFeaturePCNmList.get(i).getFeqSeqOrder());
						 tempData.setOptSubType(confFeaturePCNmList.get(i).getOptSubType());
						 tempData.setLegacyFACode(confFeaturePCNmList.get(i).getLegacyFACode());
						 tempData.setSystemFlag(false);
						 finalconfFeaturePCNmList.add(tempData);
			    	} else if (cfName.equals(confFeaturePCNmList.get(i).getCfName()) && !cfConfOption.equals(confFeaturePCNmList.get(i).getCfConfigOption())) {
			    		 PLMCntrtSmryRptData tempData = new PLMCntrtSmryRptData();
						 //tempData.setCfId(confFeaturePCNmList.get(i).getCfId());
						 //tempData.setCfName(confFeaturePCNmList.get(i).getCfName());
						 tempData.setCfConfId(confFeaturePCNmList.get(i).getCfConfId());
						 tempData.setCfDisplyName(confFeaturePCNmList.get(i).getCfDisplyName());
						 tempData.setKeyInValue(confFeaturePCNmList.get(i).getKeyInValue());
						 tempData.setCfConfigOption(confFeaturePCNmList.get(i).getCfConfigOption());
						 tempData.setCfConfOptDispName(confFeaturePCNmList.get(i).getCfConfOptDispName());
						 tempData.setFeqSeqOrder(confFeaturePCNmList.get(i).getFeqSeqOrder());
						 tempData.setOptSubType(confFeaturePCNmList.get(i).getOptSubType());
						 tempData.setLegacyFACode(confFeaturePCNmList.get(i).getLegacyFACode());
						 finalconfFeaturePCNmList.add(tempData);
						 //LOG.info("added obj in cond cfName same and !cfConfOption");
					 } 
			    	//when cf is not null and co_option is null;
			    	 else if (!cfName.equals(confFeaturePCNmList.get(i).getCfName()) && cfConfOption.equals(confFeaturePCNmList.get(i).getCfConfigOption())) {
			    		 PLMCntrtSmryRptData tempData = new PLMCntrtSmryRptData();
						 tempData.setCfId(confFeaturePCNmList.get(i).getCfId());
						 tempData.setCfName(confFeaturePCNmList.get(i).getCfName());
						 //tempData.setCfConfId(confFeaturePCNmList.get(i).getCfConfId());
						 tempData.setCfDisplyName(confFeaturePCNmList.get(i).getCfDisplyName());
						 tempData.setKeyInValue(confFeaturePCNmList.get(i).getKeyInValue());
						 //tempData.setCfConfigOption(confFeaturePCNmList.get(i).getCfConfigOption());
						// tempData.setCfConfOptDispName(confFeaturePCNmList.get(i).getCfConfOptDispName());
						 tempData.setFeqSeqOrder(confFeaturePCNmList.get(i).getFeqSeqOrder());
						 tempData.setOptSubType(confFeaturePCNmList.get(i).getOptSubType());
						 tempData.setLegacyFACode(confFeaturePCNmList.get(i).getLegacyFACode());
						 finalconfFeaturePCNmList.add(tempData);
						 //LOG.info("added obj in cond cfName same and !cfConfOption");
					 }  	
			    	
			    	else {
						  if((PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqId()) && 
									 PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqName()) &&
									 PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqDesc()))
									 ){
							PLMCntrtSmryRptData tempData = new PLMCntrtSmryRptData();
							//tempData.setCfId(confFeaturePCNmList.get(i).getCfId());
							//tempData.setCfName(confFeaturePCNmList.get(i).getCfName());
							tempData.setCfConfId(confFeaturePCNmList.get(i).getCfConfId());
							tempData.setCfDisplyName(confFeaturePCNmList.get(i).getCfDisplyName());
							 tempData.setKeyInValue(confFeaturePCNmList.get(i).getKeyInValue());
							tempData.setCfConfigOption(confFeaturePCNmList.get(i).getCfConfigOption());
							tempData.setCfConfOptDispName(confFeaturePCNmList.get(i).getCfConfOptDispName());
							tempData.setFeqSeqOrder(confFeaturePCNmList.get(i).getFeqSeqOrder());
							tempData.setOptSubType(confFeaturePCNmList.get(i).getOptSubType());
							tempData.setLegacyFACode(confFeaturePCNmList.get(i).getLegacyFACode());
							tempData.setSystemFlag(false);
							finalconfFeaturePCNmList.add(tempData);
						  }
					  }
						 if((!PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqId()) || 
								 !PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqName()) ||
								 !PLMUtils.isEmpty(confFeaturePCNmList.get(i).getReqDesc()))
								 && (PLMUtils.isEmpty(confFeaturePCNmList.get(i).getCrFlag()) || confFeaturePCNmList.get(i).getCrFlag().equals("Y"))){
							 PLMCntrtSmryRptData tempData = new PLMCntrtSmryRptData();
							 tempData.setCfConfId(confFeaturePCNmList.get(i).getReqId());
							 tempData.setCfConfigOption(confFeaturePCNmList.get(i).getReqName());
							 tempData.setCfConfOptDispName(confFeaturePCNmList.get(i).getReqDesc());
							 tempData.setKeyInValue(confFeaturePCNmList.get(i).getKeyInValue());
							 //tempData.setFeqSeqOrder(confFeaturePCNmList.get(i).getFeqSeqOrder());
							 tempData.setSystemFlag(false);
							 finalconfFeaturePCNmList.add(tempData);
						 }
						 cfName=confFeaturePCNmList.get(i).getCfName();
						 cfConfOption=confFeaturePCNmList.get(i).getCfConfigOption();
					 }
				 }
			
		 }
			return finalconfFeaturePCNmList;
		}

		
			/**
			 * @return PLMCntrtSmryRptData objects.
			 */
			private static final class ConfigFeaturesPCNMMapper1 implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
				public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
						throws SQLException {
					PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
					data.setCfId(PLMUtils.checkNullVal(rs.getString("CF_ID")));
					data.setCfName(PLMUtils.checkNullVal(rs.getString("CF_NAME")));
					data.setCfConfId(PLMUtils.checkNullVal(rs.getString("CO_ID")));
					data.setCfDisplyName(PLMUtils.checkNullVal(rs.getString("CF_DISP_NM")));
					data.setCfConfigOption(PLMUtils.checkNullVal(rs.getString("CO_NAME")));
					data.setCfConfOptDispName(PLMUtils.checkNullVal(rs.getString("CO_DISP_NM")));
					data.setReqId(PLMUtils.checkNullVal(rs.getString("REQ_ID")));
					data.setReqName(PLMUtils.checkNullVal(rs.getString("REQ_NAME")));
					data.setReqDesc(PLMUtils.checkNullVal(rs.getString("REQ_DESC")));
					//data.setFeqSeqOrder(PLMUtils.checkNullVal(rs.getString("FEAT_SEQ_ORDER")));
					data.setFeqSeqOrder(PLMUtils.checkNullVal(rs.getString("CF_SEQ_ORDER")));
					data.setCrFlag(PLMUtils.checkNullVal(rs.getString("CR_FLAG")));
					data.setOptSubType(PLMUtils.checkNullVal(rs.getString("GE_OPTION_SUB_TYPE")));
					data.setLegacyFACode(PLMUtils.checkNullVal(rs.getString("GE_INDR")));
					data.setSystemName(PLMUtils.checkNullValSysName(rs.getString("CO_SYS_NM")));
					data.setKeyInValue(PLMUtils.checkNullVal(rs.getString("KEY_VALUE1")));
					return data;
				}
			}
			
			/**
			 * @return PLMCntrtSmryRptData objects.
			 */
			private static final class ConfigFeaturesPCNMMapper2 implements ParameterizedRowMapper<PLMCntrtSmryRptData> {
				public PLMCntrtSmryRptData mapRow(ResultSet rs, int rowcount)
						throws SQLException {
					PLMCntrtSmryRptData data = new PLMCntrtSmryRptData();
					data.setCfId(PLMUtils.checkNullVal(rs.getString("CF_ID")));
					data.setCfName(PLMUtils.checkNullVal(rs.getString("CF_NAME")));
					data.setCfConfId(PLMUtils.checkNullVal(rs.getString("CO_ID")));
					data.setCfDisplyName(PLMUtils.checkNullVal(rs.getString("CF_DISP_NM")));
					data.setCfConfigOption(PLMUtils.checkNullVal(rs.getString("CO_NAME")));
					data.setCfConfOptDispName(PLMUtils.checkNullVal(rs.getString("CO_DISP_NM")));
					data.setReqId(PLMUtils.checkNullVal(rs.getString("REQ_ID")));
					data.setReqName(PLMUtils.checkNullVal(rs.getString("REQ_NAME")));
					data.setReqDesc(PLMUtils.checkNullVal(rs.getString("REQ_DESC")));
					data.setFeqSeqOrder(PLMUtils.checkNullVal(rs.getString("FEAT_SEQ_ORDER")));
					data.setCrFlag(PLMUtils.checkNullVal(rs.getString("CR_FLAG")));
					data.setOptSubType(PLMUtils.checkNullVal(rs.getString("GE_OPTION_SUB_TYPE")));
					data.setLegacyFACode(PLMUtils.checkNullVal(rs.getString("GE_INDR")));
					data.setKeyInValue(PLMUtils.checkNullVal(rs.getString("KEY_VALUE1")));
					return data;
				}
			}

				
}
