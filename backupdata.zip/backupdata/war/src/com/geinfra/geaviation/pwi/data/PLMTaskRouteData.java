/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMTaskRouteData.java
 * @Creation date: 11-Sept-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PLMTaskRouteData {

	
	// PROPERTIES *************************************************************
	
	private String taskName;
	
	private String taskState;
	
	private String taskOwner;
	
	private String projectOwner;
	
	private String routeId;
	
	private String routeName;
	
	private String routeDescription;
	
	private String taskStateRouteInitiated;
	
	private String routeState;
	
	private String routeApprovalDate;
	
	private Date rteApprovalDate;
	
	private String routeTaskOwner;
	
	private String rowColor;
	
	
	// CONSTRUCTOR ************************************************************


	/**
	 * Creates a new instance of the class TaskDeliverable
	 */
	public PLMTaskRouteData (String taskName, String taskState, String taskOwner, String projectOwner,
							String routeId, String routeName, String routeDescription, 
							String taskStateRouteInitiated, String routeState,
							String routeApprovalDate, String routeTaskOwner) {  

		String rtApprvlDt = routeApprovalDate;
		if (rtApprvlDt != null) {
			try{
				Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S").parse(rtApprvlDt);
				this.rteApprovalDate = date; 
				rtApprvlDt = new SimpleDateFormat("MMM dd, yyyy", Locale.US).format(date);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		
		this.taskName = taskName;
		this.taskState = taskState;
		this.taskOwner = taskOwner;
		this.projectOwner = projectOwner;
		this.routeId = routeId;
		this.routeName = routeName;		
		this.routeDescription = routeDescription;
		this.taskStateRouteInitiated = taskStateRouteInitiated;
		this.routeState = routeState;
		this.routeApprovalDate = rtApprvlDt;
		this.routeTaskOwner = routeTaskOwner;
	}
	
	
	// ACCESSOR METHODS *******************************************************

	public String getTaskName() {
		return taskName;
	}


	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}


	public String getTaskState() {
		return taskState;
	}


	public void setTaskState(String taskState) {
		this.taskState = taskState;
	}


	public String getTaskOwner() {
		return taskOwner;
	}


	public void setTaskOwner(String taskOwner) {
		this.taskOwner = taskOwner;
	}


	public String getProjectOwner() {
		return projectOwner;
	}


	public void setProjectOwner(String projectOwner) {
		this.projectOwner = projectOwner;
	}


	public String getRouteId() {
		return routeId;
	}


	public void setRouteId(String routeId) {
		this.routeId = routeId;
	}


	public String getRouteName() {
		return routeName;
	}


	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}


	public String getRouteDescription() {
		return routeDescription;
	}


	public void setRouteDescription(String routeDescription) {
		this.routeDescription = routeDescription;
	}


	public String getTaskStateRouteInitiated() {
		return taskStateRouteInitiated;
	}


	public void setTaskStateRouteInitiated(String taskStateRouteInitiated) {
		this.taskStateRouteInitiated = taskStateRouteInitiated;
	}


	public String getRouteState() {
		return routeState;
	}


	public void setRouteState(String routeState) {
		this.routeState = routeState;
	}


	public String getRouteApprovalDate() {
		return routeApprovalDate;
	}


	public void setRouteApprovalDate(String routeApprovalDate) {
		this.routeApprovalDate = routeApprovalDate;
	}


	public Date getRteApprovalDate() {
		Date rtAprvlDt = rteApprovalDate;
		return rtAprvlDt;
	}


	public void setRteApprovalDate(Date rteApprovalDate) {
		Date rtAprvlDt = rteApprovalDate;
		this.rteApprovalDate = rtAprvlDt;
	}


	public String getRouteTaskOwner() {
		return routeTaskOwner;
	}


	public void setRouteTaskOwner(String routeTaskOwner) {
		this.routeTaskOwner = routeTaskOwner;
	}

	public String getRowColor() {
		return rowColor;
	}


	public void setRowColor(String rowColor) {
		this.rowColor = rowColor;
	}

	
	// OVERRIDEN METHODS ******************************************************

	/**
	 * Returns the Deliverable information as a String
	 * 
	 * @return type (String) 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer strTaskRoute = new StringBuffer();
		
		strTaskRoute
			.append(taskName).append(" ")
			.append(taskState).append(" ")
			.append(taskOwner).append(" ")
			.append(projectOwner).append(" ")
			.append(routeId).append(" ")
			.append(routeName).append(" ")		
			.append(routeDescription).append(" ")
			.append(taskStateRouteInitiated).append(" ")
			.append(routeState).append(" ")
			.append(routeApprovalDate).append(" ")
			.append(routeTaskOwner).append(" ");
			
		return strTaskRoute.toString();
	}


	
}
