/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMLogData.java
 * @Creation date: 11-Sept-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMLogData {
	
	// PROPERTIES *************************************************************

	private String id;
	private String logDate;
	private String userName;
	private String fdm;
	private String ipAddress;
	private String toolName;
	private String action;
	private String projectOwner;
	private String ownerName;
	private String reportTime;
	

	// CONTRUCTOR *************************************************************
	
	/**
	 * Creates a new instance of the class Project
	 * 
	 * @param projectName(String)
	 */
	public PLMLogData(String id, String logDate, String userName, String fdm, String ipAddress, String toolName,
				String action, String projectOwner, String ownerName, String reportTime) {
		this.id = id;
		this.logDate = logDate;
		this.userName = userName;
		this.fdm = fdm;
		this.ipAddress = ipAddress;
		this.toolName = toolName;
		this.action = action;
		this.projectOwner = projectOwner;
		this.ownerName = ownerName;
		this.reportTime = reportTime;
	}

	// ACCESSOR METHODS *******************************************************

	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getLogDate() {
		return logDate;
	}


	public void setLogDate(String logDate) {
		this.logDate = logDate;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getFdm() {
		return fdm;
	}


	public void setFdm(String fdm) {
		this.fdm = fdm;
	}


	public String getIpAddress() {
		return ipAddress;
	}


	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}


	public String getToolName() {
		return toolName;
	}


	public void setToolName(String toolName) {
		this.toolName = toolName;
	}


	public String getAction() {
		return action;
	}


	public void setAction(String action) {
		this.action = action;
	}


	public String getProjectOwner() {
		return projectOwner;
	}


	public void setProjectOwner(String projectOwner) {
		this.projectOwner = projectOwner;
	}


	public String getOwnerName() {
		return ownerName;
	}


	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getReportTime() {
		return reportTime;
	}

	public void setReportTime(String reportTime) {
		this.reportTime = reportTime;
	}

}
