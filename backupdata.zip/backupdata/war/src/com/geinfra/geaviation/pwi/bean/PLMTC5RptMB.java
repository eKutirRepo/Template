/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMTC5RptMB.java
 * @Creation date: 27-April-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.data.PLMTC5FullBomRptData;
import com.geinfra.geaviation.pwi.data.PLMTC5MliRptData;
import com.geinfra.geaviation.pwi.data.PLMTC5RelationsRptData;
import com.geinfra.geaviation.pwi.data.PLMTC5WhUsedRptData;
import com.geinfra.geaviation.pwi.service.PLMTC5RptServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMTC5RptConstants;
import com.geinfra.geaviation.pwi.util.PLMTC5RptUtils;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMTC5RptMB {
	private static final Logger LOG = Logger
			.getLogger(PLMTC5RptMB.class);
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	/**
	 * Holds the PLMTC5RptServiceIfc
	 */
	private PLMTC5RptServiceIfc plmTC5RptService = null;
	/**
	 * Holds the PLMCommonMB
	 */
	private PLMCommonMB commonMB = null;
	/**
	 * Holds the PLMTC5RelationsRptData
	 */
	private PLMTC5RelationsRptData tc5RelData = new PLMTC5RelationsRptData();
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds an email id
	 */
	private PLMPwiUserData userDetails;
	/**
	 * Holds the tc5Code
	 */
	private String tc5Code;
	/**
	 * Holds the selRevision
	 */
	private String selRevision="";
	
	/**
	 * Holds the tc5RelationList
	 */
	private List<PLMTC5RelationsRptData> tc5RelationList = new ArrayList<PLMTC5RelationsRptData>();
	
	/**
	 * Holds the recordCountRel
	 */
	private int recordCountRel=100;
	
	/**
	 * Holds the totalRecCountRel
	 */
	private int totalRecCountRel;
	/**
	 * Holds the exportToExcelFlag
	 */
	private boolean exportToExcelFlag;
	/**
	 * Holds the code
	 */
	private String code;
	/**
	 * Holds the tc5RelationMsg
	 */
	private String tc5RelationMsg;
	 /**
	  *  Holds the identifierVal
	  */
	 private String identifierVal="";
	 /**
	 * Holds the dataTable
	 */
	private HtmlDataTable dataTable = new HtmlDataTable();
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	
	private PLMLoginData userDataObj = (PLMLoginData) PLMUtils
	.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA);
	
	//Added by Shekar for TC5 MLI Report
	/**
	 * Holds the PLMCustDocReportData
	 */
	private PLMTC5MliRptData plmTC5MliRptData = new PLMTC5MliRptData();
	
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the searchResultList
	 */
	private List<PLMTC5MliRptData> searchResultList=new ArrayList<PLMTC5MliRptData>();
	/**
	 * Holds the totalRecCountMsg
	 */
	private String totalRecCountMsg;
	/**
	 * Holds the selCrtMsg
	 */
	private String selCrtMsg;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;
	
	//Added for TC5 Full BOM Report
	/**
	 * Holds the tc5CodeFullBom
	 */
	private String tc5CodeFullBom;
	/**
	 * Holds the bomLevel
	 */
	private String bomLevel;
	/**
	 * Holds the allBomLvlFlg
	 */
	private boolean allBomLvlFlg;
	/**
	 * Holds the refDocLevel
	 */
	private String refDocLevel;
	/**
	 * Holds the allRefDocLvlFlg
	 */
	private boolean allRefDocLvlFlg;
	/**
	 * Holds the includeDefFlag
	 */
	private boolean includeDefFlag;
	/**
	 * Holds the assignRevision
	 */
	private String assignRevision;
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle labelBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.plmrlabel");
		
	private String partDocNum="";
	//private String partDocType="";
	
	/**
	 * This method is used for loadTC5Relation page
	 * 
	 * @return String
	 */
	public String loadTC5Relation() {
		LOG.info("Entering loadTC5Relation Method");
		
		try {
			commonMB.insertCannedRptRecordHitInfo("TC5 Relations");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		alertMessage="";
		tc5Code="";
		assignRevision="";
		recordCountRel=100;
		totalRecCount=0;
		tc5RelationList = new ArrayList<PLMTC5RelationsRptData>();
		exportToExcelFlag=false;
		selRevision=PLMTC5RptConstants.TC5_ALL_REVISIONS;
		LOG.info("Exiting loadTC5Relation Method");
		
		try {
			commonMB.getPLMDateStamp(PLMConstants.ECO_TABLE);
		 } catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPLMDateStamp: ", exception);
		 }
		
		return "tc5RltnsRptSearch";
	}
	
	/**
	 * This method is used for reset TC5 Relation page
	 * 
	 * @return String
	 */
	public void resetTC5RelationData(){
		LOG.info("Inside resetTC5RelationData()...");
		alertMessage="";
		tc5Code="";
		selRevision=PLMTC5RptConstants.TC5_ALL_REVISIONS;
		exportToExcelFlag=false;
		tc5RelationList = new ArrayList<PLMTC5RelationsRptData>();
		LOG.info("Existing resetTC5RelationData()...");
	}
	
	/**
	 * This method is used for Validating 
	 * 
	 * @return String
	 */
	public String validateTC5RelationData() {		
		alertMessage ="";
		LOG.info("Entering validateTC5RelationData Method");
		 if (PLMUtils.isEmpty(tc5Code)){
			alertMessage = PLMTC5RptConstants.TC5_CODE_INPUT;
		 }else if(!PLMTC5RptUtils.checkForSpecialCharsTC5Code(tc5Code)){
			alertMessage = PLMTC5RptConstants.TC5_CODE_SPLCHAR_DOC;
		 }else if(!PLMTC5RptUtils.checkForCharsDigitsTC5Code(tc5Code)){
			alertMessage = PLMTC5RptConstants.TC5_CODE_CHARDIGIT_DOC;
		 }
		 
		 if(selRevision.equals(PLMTC5RptConstants.TC5_ALL_REVISIONS)){
		   assignRevision=labelBundle.getString("TC5_All_Revisions");
		 }else if(selRevision.equals(PLMTC5RptConstants.TC5_LAST_REVISIONS)){
		   assignRevision=labelBundle.getString("TC5_Last_Revision");
		}else if(selRevision.equals(PLMTC5RptConstants.TC5_LAST_RELEASE_REVISIONS)){
			assignRevision=labelBundle.getString("TC5_Last_Rel_Revision");
		}
		 
		LOG.info("Exiting validateTC5RelationData Method");
		return alertMessage;
	}
	
	/**
	 * This method is used for getTC5RelationResults page
	 * 
	 * @return String
	 * @throws PLMCommonException 
	 */
	public String getTC5RelationResults() {
		LOG.info("Entering getTC5RelationResults Method");
		String fwdFlag="";
		alertMessage="";
		tc5RelationList =new ArrayList<PLMTC5RelationsRptData>();
	 try{
		alertMessage=validateTC5RelationData();
		if(PLMUtils.isEmpty(alertMessage)){
			tc5RelData.setTc5Code(tc5Code);
			tc5RelData.setSelRevision(selRevision);
				tc5RelationList = plmTC5RptService.getTC5RelationRpt(tc5Code,selRevision);
				totalRecCount=tc5RelationList.size();
				if(totalRecCount!=0){
					if(totalRecCount<=PLMTC5RptConstants.TC5_CODE_REL_RPT_SIZE){
						exportToExcelFlag=true;
					}else{
						exportToExcelFlag=false;
					}
					code=tc5Code;
					tc5RelationMsg="Total No of TC5 Relations Results "+totalRecCount;
				  fwdFlag="tc5RltnsRptResult";
				}else{
				  fwdFlag="invalidtc5RltnsRpt";
				}
		}else{
			fwdFlag="tc5RltnsRptSearch";
		}
	 }catch (PLMCommonException exception) {
		LOG.log(Level.ERROR, "Exception@getTC5RelationResults: ", exception);
		fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
				commonMB, "tc5RltnsRptSearch", "TC5 relations");
	  }
		LOG.info("Exiting getTC5RelationResults Method");
		return fwdFlag;
	}
	
	 /**
	 * This method is used for recordsPerPageListnerRel
	 * 
	 * @param event
	 * 
	 */
	public void recordsPerPageListnerRel(ActionEvent event) {
		LOG.info("Entering recordsPerPageListnerRel method");
		LOG.info("Action listner called.....--------------------------->"
				+ recordCountRel);
		if (recordCountRel == 15) {
			LOG.info("15");
			recordCountRel = 15;
		} else if (recordCountRel == 30) {
			LOG.info("30");
			recordCountRel = 30;
		} else if (recordCountRel == 50) {
			LOG.info("50");
			recordCountRel = 50;
		} else if (recordCountRel == 100) {
			LOG.info("100");
			recordCountRel = 100;
		} else if (recordCountRel == 200) {
			LOG.info("200");
			recordCountRel = 200;
		}else if (recordCountRel == 500) {
			LOG.info("500");
			recordCountRel = 500;
		}
		LOG.info("final value.....--------------------------->" + recordCountRel);
	}
	
	/**
	 * This method is used for retrieving more identifier with in the result page
	 *
	 * @throws PLMCommonException 
	 */
	public String getMoreTC5RelRptData(){
		LOG.info("Entering in to getMoreTC5RelRptData");
		tc5RelationList =new ArrayList<PLMTC5RelationsRptData>();
		String identifierValid="";
		String fwdFlag="";
		try{
			LOG.info(" Identifier Name  ------------->"+identifierVal);
			if(identifierVal.contains(",")){
			 String arrIdentifier []=identifierVal.split(",");
			 identifierValid=arrIdentifier[0];
			}else{
			 identifierValid =identifierVal;
			}
			LOG.info(" identifierValid ------------->"+identifierValid);
			tc5RelData.setTc5Code(identifierValid);
			tc5RelationList = plmTC5RptService.getTC5RelationRpt(identifierValid,selRevision);
			totalRecCount=tc5RelationList.size();
			if(totalRecCount!=0){
				if(totalRecCount<=PLMTC5RptConstants.TC5_CODE_REL_RPT_SIZE){
					exportToExcelFlag=true;
				}else{
					exportToExcelFlag=false;
				}
				code=identifierValid;
				tc5RelationMsg="Total No of TC5 relations Results "+totalRecCount;
			  fwdFlag="tc5RltnsRptResult";
			}else{
			  fwdFlag="invalidtc5RltnsRpt";
			}
		}catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getMoreTC5RelRptData: ", exception);
			fwdFlag = PLMUtils.setCommonException(exception.getMessage(),
					commonMB, "tc5RltnsRptSearch", "TC5 relations");
		 }
			LOG.info("Exiting getMoreTC5RelRptData Method");
			return fwdFlag;
	}
	
	/**
	 * This method is used to download excel for TC5 relations report
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	
	public void downloadTC5RelationsExcel() throws PLMCommonException {
		LOG.info("Entering downloadTC5RelationsExcel Method");
		String fileName = "TC5RelationReport";
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		//Export to Excel for TC5 Relation Report
		PLMXlsxRptColumn[] reportColumns =
						new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("frmType", "Type", FormatType.TEXT, null, null, 20),
								new PLMXlsxRptColumn("frmVersion", "Version", FormatType.TEXT, null, null, 35),
								new PLMXlsxRptColumn("frmIdentifier", "Identifier / Identifiant", FormatType.TEXT, null, null, 25),
								new PLMXlsxRptColumn("frmState", "State", FormatType.TEXT, null, null, 28),
								new PLMXlsxRptColumn("frmRelaseDtExl", "Release", FormatType.DATEFR, null, null, 10),
								new PLMXlsxRptColumn("frmDesc", "Description", FormatType.TEXT, null, null, 35),
								new PLMXlsxRptColumn("frmLibelle", "Libelle", FormatType.TEXT, null, null, 36),
								new PLMXlsxRptColumn("connRelation", "Connection/ Relation", FormatType.TEXT, null, null, 25),
								new PLMXlsxRptColumn("type", "Type", FormatType.TEXT, null, null, 20),
								new PLMXlsxRptColumn("version", "Version", FormatType.TEXT, null, null, 35),
								new PLMXlsxRptColumn("identifier", "Identifier / Identifiant", FormatType.TEXT, null, null, 25),
								new PLMXlsxRptColumn("state", "State", FormatType.TEXT, null, null, 28),
								new PLMXlsxRptColumn("releaseExl", "Release", FormatType.DATEFR, null, null, 10),
								new PLMXlsxRptColumn("description", "Description", FormatType.TEXT, null, null, 35),
								new PLMXlsxRptColumn("libelle", "Libelle", FormatType.TEXT, null, null, 36)
						};
		
		PLMXlsxRptColumn[] critcolumns = 
						new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("selRevision", "TC5 Relations", FormatType.TEXT),
						                       new PLMXlsxRptColumn("tc5Code", "Code", FormatType.TEXT)
						};
		excelUtil.export(tc5RelationList, reportColumns, fileName, fileName, true, critcolumns, tc5RelData);
	}
	
	/**
	 * This method is used to download excel for TC5 MLI report
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	
	public void downloadTC5MLIExcel() throws PLMCommonException {
		LOG.info("Entering downloadTC5MLIExcel Method");
		
		String fileName = "TC5MLIReport";

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();

		PLMXlsxRptColumn[] reportColumns =
						new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("opMLI", "MLI", FormatType.TEXT, null, null, 34),
								new PLMXlsxRptColumn("opObjName", "Obj Name", FormatType.TEXT, null, null, 20),
								new PLMXlsxRptColumn("opObjRev", "Obj Rev", FormatType.TEXT, null, null, 8),
								new PLMXlsxRptColumn("opQty", "Qty", FormatType.TEXT, null, null, 5),
								new PLMXlsxRptColumn("opUomDocType", "UoM/DocType", FormatType.TEXT, null, null, 15),
								new PLMXlsxRptColumn("opFRDesc", "FR Description", FormatType.TEXT, null, null, 36),
								new PLMXlsxRptColumn("opENDesc", "EN Description", FormatType.TEXT, null, null, 36),
								new PLMXlsxRptColumn("opSect", "Sect", FormatType.TEXT, null, null, 5),
								new PLMXlsxRptColumn("opItemName", "Item Name", FormatType.TEXT, null, null, 27),
								new PLMXlsxRptColumn("opItemRev", "Item Rev", FormatType.TEXT, null, null, 9),
								new PLMXlsxRptColumn("opSN", "SN", FormatType.TEXT, null, null, 11),
								new PLMXlsxRptColumn("opTmTot", "TM /TOT", FormatType.TEXT, null, null, 9),
								new PLMXlsxRptColumn("opProject", "Project/Affaire", FormatType.TEXT, null, null, 15),
								new PLMXlsxRptColumn("opContract", "Contract", FormatType.TEXT, null, null, 10),
								new PLMXlsxRptColumn("opConDesc", "Contract Description", FormatType.TEXT, null, null, 36)
						};
		
		
		PLMXlsxRptColumn[] critcolumns = 
						new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("enteredSNProjIPSTC5", "SN#'s/Project's/IPS's/TC5 Number's", FormatType.TEXT),
						new PLMXlsxRptColumn("enteredConDesc", "Contract Description", FormatType.TEXT),
						new PLMXlsxRptColumn("enteredMLI", "MLI", FormatType.TEXT)
						};
		
		excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, plmTC5MliRptData);
	}
	/**
	 * This method is used for Generating TC5 MLI Report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadMLICSV() throws PLMCommonException {
		LOG.info("Entering downloadMLICSV Method");
		
		String fileName = "TC5MLIReport";
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);

		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();

		PLMCsvRptColumn[] reportColumns =
						new PLMCsvRptColumn[] {new PLMCsvRptColumn("opMLI", "MLI", FormatTypeCsv.TEXT, null, null, 34),
								new PLMCsvRptColumn("opObjName", "Obj Name", FormatTypeCsv.TEXT, null, null, 20),
								new PLMCsvRptColumn("opObjRev", "Obj Rev", FormatTypeCsv.TEXT, null, null, 8),
								new PLMCsvRptColumn("opQty", "Qty", FormatTypeCsv.TEXT, null, null, 5),
								new PLMCsvRptColumn("opUomDocType", "UoM/DocType", FormatTypeCsv.TEXT, null, null, 15),
								new PLMCsvRptColumn("opFRDesc", "FR Description", FormatTypeCsv.TEXT, null, null, 36),
								new PLMCsvRptColumn("opENDesc", "EN Description", FormatTypeCsv.TEXT, null, null, 36),
								new PLMCsvRptColumn("opSect", "Sect", FormatTypeCsv.TEXT, null, null, 5),
								new PLMCsvRptColumn("opItemName", "Item Name", FormatTypeCsv.TEXT, null, null, 27),
								new PLMCsvRptColumn("opItemRev", "Item Rev", FormatTypeCsv.TEXT, null, null, 9),
								new PLMCsvRptColumn("opSN", "SN", FormatTypeCsv.TEXT, null, null, 11),
								new PLMCsvRptColumn("opTmTot", "TM /TOT", FormatTypeCsv.TEXT, null, null, 9),
								new PLMCsvRptColumn("opProject", "Project/Affaire", FormatTypeCsv.TEXT, null, null, 15),
								new PLMCsvRptColumn("opContract", "Contract", FormatTypeCsv.TEXT, null, null, 10),
								new PLMCsvRptColumn("opConDesc", "Contract Description", FormatTypeCsv.TEXT, null, null, 36)
						};
		
		
		PLMCsvRptColumn[] critcolumns = 
						new PLMCsvRptColumn[] {new PLMCsvRptColumn("enteredSNProjIPSTC5", "SN#'s/Project's/IPS's/TC5 Number's", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("enteredConDesc", "Contract Description", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("enteredMLI", "MLI", FormatTypeCsv.TEXT)
						};
		
		csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, true, critcolumns, plmTC5MliRptData, ",");
		
		LOG.info("Exiting downloadMLICSV Method");
		
		/*PrintWriter pwriter = null;
		OutputStream os = null;

		try {  
			FacesContext facesContext = FacesContext.getCurrentInstance();

			HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
			HttpServletRequest resquest = (HttpServletRequest) facesContext.getExternalContext().getRequest();
			
			HttpSession session = resquest.getSession();
			
			response.setHeader("content-disposition","attachment; filename=TC5MLIReport.csv");
			response.setContentType("application/CSV");
		   	
		   	pwriter = response.getWriter();
		   	
		   	PLMTC5RptMB plmTC5RptMB = (PLMTC5RptMB)session.getAttribute("plmTC5RptMB");
		   	PLMTC5MliRptData mliRptData = (PLMTC5MliRptData)plmTC5RptMB.getPlmTC5MliRptData();
		   	
		   
		   	pwriter.write("SN#'s/Project's/IPS's/TC5 Number's");
			pwriter.write(",");
			pwriter.write(mliRptData.getEnteredSNProjIPSTC5());
			pwriter.write("\n");
			pwriter.write("Contract Description");
			pwriter.write(",");
			pwriter.write(mliRptData.getEnteredConDesc());
			pwriter.write("\n");
			pwriter.write("MLI");
			pwriter.write(",");
			pwriter.write(mliRptData.getEnteredMLI());
			pwriter.write("\n");
		
		    pwriter.write("\n");
		   	
		    	pwriter.write("MLI");
				pwriter.write(",");
				pwriter.write("Obj Name");
				pwriter.write(",");
				pwriter.write("Obj Rev");
				pwriter.write(",");
				pwriter.write("Qty");
				pwriter.write(",");
				pwriter.write("UoM/DocType");
				pwriter.write(",");
				pwriter.write("FR Description");
				pwriter.write(",");
				pwriter.write("EN Description");
				pwriter.write(",");
				pwriter.write("Sect");
				pwriter.write(",");
				pwriter.write("Item Name");
				pwriter.write(",");
				pwriter.write("Item Rev");
				pwriter.write(",");
				pwriter.write("SN");
				pwriter.write(",");
				pwriter.write("TM /TOT");
				pwriter.write(",");
				pwriter.write("Project/Affaire");
				pwriter.write(",");
				pwriter.write("Contract");
				pwriter.write(",");
				pwriter.write("Contract Description");
				
	 			pwriter.write("\n");
	 			if(!PLMUtils.isEmptyList(plmTC5RptMB.getSearchResultList())) {
	 				for(int i=0; i<plmTC5RptMB.getSearchResultList().size(); i++) {
	 					PLMTC5MliRptData dataObj = (PLMTC5MliRptData)plmTC5RptMB.getSearchResultList().get(i);
			   			
			   			
			   			if(dataObj.getOpMLI()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpMLI()+"\""));
				   		}
			   			   			
			   			pwriter.write(",");
			   			
			   			if(dataObj.getOpObjName()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpObjName()));
				   		}
			   			
						pwriter.write(",");
			   			
			   			if(dataObj.getOpObjRev()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpObjRev()+"\""));
				   		}
			   			
						pwriter.write(",");
			   			
			   			if(dataObj.getOpQty()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpQty()+"\""));
				   		}
			   			
						pwriter.write(",");
			   			
			   			if(dataObj.getOpUomDocType()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpUomDocType()));
				   		}
			   			
			   			pwriter.write(",");
			   			
			   			if(dataObj.getOpFRDesc()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpFRDesc()));
				   		}
			   			
						pwriter.write(",");
			   			
			   			if(dataObj.getOpENDesc()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpENDesc()));
				   		}
			   			
						pwriter.write(",");
			   			
			   			if(dataObj.getOpSect()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpSect()+"\""));
				   		}
			   			
						pwriter.write(",");
			   			
			   			if(dataObj.getOpItemName()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpItemName()));
				   		}
			   			
						pwriter.write(",");
			   			
			   			if(dataObj.getOpItemRev()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpItemRev()));
				   		}
			   			
						pwriter.write(",");
			   			
			   			if(dataObj.getOpSN()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpSN()));
				   		}
			   			
						pwriter.write(",");
			   			
			   			if(dataObj.getOpTmTot()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTmTot()));
				   		}
			   			
						pwriter.write(",");
			   			
			   			if(dataObj.getOpProject()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpProject()));
				   		}
			   			
						pwriter.write(",");
			   			
			   			if(dataObj.getOpContract()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpContract()));
				   		}
			   			
						pwriter.write(",");
			   			
			   			if(dataObj.getOpConDesc()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpConDesc()));
				   		}
			   			
			 			pwriter.write("\n");
	 			} 
	 				
			  
		}
		  
		  pwriter.flush(); 
		} catch (FileNotFoundException e) {
			System.out.println("The exception is : " + e);
		} catch (Exception e1) {
			System.out.println("IOException : " + e1.getMessage());
		} finally {
			try {
				if (pwriter != null) {
					pwriter.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
			try {
				if (os != null) {
					os.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
		}*/
	}
	
	/**
	 * This method is used for Generating TC5 MLI Report in CSV with French setting
	 * 
	 * @throws PLMCommonException
	 */
	
	public void downloadMLIFrenchCSV() throws PLMCommonException {

		LOG.info("Entering downloadMLIFrenchCSV Method");
		
		String fileName = "TC5MLIReport";
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);

		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();

		PLMCsvRptColumn[] reportColumns =
						new PLMCsvRptColumn[] {new PLMCsvRptColumn("opMLI", "MLI", FormatTypeCsv.TEXT, null, null, 34),
								new PLMCsvRptColumn("opObjName", "Obj Name", FormatTypeCsv.TEXT, null, null, 20),
								new PLMCsvRptColumn("opObjRev", "Obj Rev", FormatTypeCsv.TEXT, null, null, 8),
								new PLMCsvRptColumn("opQty", "Qty", FormatTypeCsv.TEXT, null, null, 5),
								new PLMCsvRptColumn("opUomDocType", "UoM/DocType", FormatTypeCsv.TEXT, null, null, 15),
								new PLMCsvRptColumn("opFRDesc", "FR Description", FormatTypeCsv.TEXT, null, null, 36),
								new PLMCsvRptColumn("opENDesc", "EN Description", FormatTypeCsv.TEXT, null, null, 36),
								new PLMCsvRptColumn("opSect", "Sect", FormatTypeCsv.TEXT, null, null, 5),
								new PLMCsvRptColumn("opItemName", "Item Name", FormatTypeCsv.TEXT, null, null, 27),
								new PLMCsvRptColumn("opItemRev", "Item Rev", FormatTypeCsv.TEXT, null, null, 9),
								new PLMCsvRptColumn("opSN", "SN", FormatTypeCsv.TEXT, null, null, 11),
								new PLMCsvRptColumn("opTmTot", "TM /TOT", FormatTypeCsv.TEXT, null, null, 9),
								new PLMCsvRptColumn("opProject", "Project/Affaire", FormatTypeCsv.TEXT, null, null, 15),
								new PLMCsvRptColumn("opContract", "Contract", FormatTypeCsv.TEXT, null, null, 10),
								new PLMCsvRptColumn("opConDesc", "Contract Description", FormatTypeCsv.TEXT, null, null, 36)
						};
		
		
		PLMCsvRptColumn[] critcolumns = 
						new PLMCsvRptColumn[] {new PLMCsvRptColumn("enteredSNProjIPSTC5", "SN#'s/Project's/IPS's/TC5 Number's", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("enteredConDesc", "Contract Description", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("enteredMLI", "MLI", FormatTypeCsv.TEXT)
						};
		
		csvUtil.exportCsv(searchResultList, reportColumns, fileName, dateFormat, true, critcolumns, plmTC5MliRptData, ";");
		
		LOG.info("Exiting downloadMLIFrenchCSV Method");
		
		/*PrintWriter pwriter = null;
		OutputStream os = null;

		try {  
			FacesContext facesContext = FacesContext.getCurrentInstance();

			HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
			HttpServletRequest resquest = (HttpServletRequest) facesContext.getExternalContext().getRequest();
			
			HttpSession session = resquest.getSession();
		   
		   	response.setContentType("application/CSV");
		   	response.setHeader("content-disposition","attachment; filename=TC5MLIReport.csv");
		   
		   	pwriter = response.getWriter();
		   	PLMTC5RptMB plmTC5RptMB = (PLMTC5RptMB)session.getAttribute("plmTC5RptMB");
		   	PLMTC5MliRptData mliRptData = (PLMTC5MliRptData)plmTC5RptMB.getPlmTC5MliRptData();
		   	
		   
		   	pwriter.write("SN#'s/Project's/IPS's/TC5 Number's");
			pwriter.write(";");
			pwriter.write(mliRptData.getEnteredSNProjIPSTC5());
			pwriter.write("\n");
			pwriter.write("Contract Description");
			pwriter.write(";");
			pwriter.write(mliRptData.getEnteredConDesc());
			pwriter.write("\n");
			pwriter.write("MLI");
			pwriter.write(";");
			pwriter.write(mliRptData.getEnteredMLI());
			pwriter.write("\n");
		
		    pwriter.write("\n");
		   	
		    	pwriter.write("MLI");
				pwriter.write(";");
				pwriter.write("Obj Name");
				pwriter.write(";");
				pwriter.write("Obj Rev");
				pwriter.write(";");
				pwriter.write("Qty");
				pwriter.write(";");
				pwriter.write("UoM/DocType");
				pwriter.write(";");
				pwriter.write("FR Description");
				pwriter.write(";");
				pwriter.write("EN Description");
				pwriter.write(";");
				pwriter.write("Sect");
				pwriter.write(";");
				pwriter.write("Item Name");
				pwriter.write(";");
				pwriter.write("Item Rev");
				pwriter.write(";");
				pwriter.write("SN");
				pwriter.write(";");
				pwriter.write("TM /TOT");
				pwriter.write(";");
				pwriter.write("Project/Affaire");
				pwriter.write(";");
				pwriter.write("Contract");
				pwriter.write(";");
				pwriter.write("Contract Description");

	 			pwriter.write("\n");
	 			if(!PLMUtils.isEmptyList(plmTC5RptMB.getSearchResultList())) {
	 				for(int i=0; i<plmTC5RptMB.getSearchResultList().size(); i++) {
	 					PLMTC5MliRptData dataObj = (PLMTC5MliRptData)plmTC5RptMB.getSearchResultList().get(i);
			   			
			   			if(dataObj.getOpMLI()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpMLI()+"\""));
				   		}
			   			   			
			   			pwriter.write(";");
			   			
			   			if(dataObj.getOpObjName()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpObjName()));
				   		}
			   			
						pwriter.write(";");
			   			
			   			if(dataObj.getOpObjRev()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpObjRev()+"\""));
				   		}
			   			
						pwriter.write(";");
			   			
			   			if(dataObj.getOpQty()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValueNew("=\""+dataObj.getOpQty()+"\""));
				   		}
			   			
						pwriter.write(";");
			   			
			   			if(dataObj.getOpUomDocType()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpUomDocType()));
				   		}
			   			
			   			pwriter.write(";");
			   			
			   			if(dataObj.getOpFRDesc()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpFRDesc()));
				   		}
			   			
						pwriter.write(";");
			   			
			   			if(dataObj.getOpENDesc()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpENDesc()));
				   		}
			   			
						pwriter.write(";");
			   			
			   			if(dataObj.getOpSect()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpSect()+"\""));
				   		}
			   			
						pwriter.write(";");
			   			
			   			if(dataObj.getOpItemName()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpItemName()));
				   		}
			   			
						pwriter.write(";");
			   			
			   			if(dataObj.getOpItemRev()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpItemRev()));
				   		}
			   			
						pwriter.write(";");
			   			
			   			if(dataObj.getOpSN()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpSN()));
				   		}
			   			
						pwriter.write(";");
			   			
			   			if(dataObj.getOpTmTot()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpTmTot()));
				   		}
			   			
						pwriter.write(";");
			   			
			   			if(dataObj.getOpProject()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpProject()));
				   		}
			   			
						pwriter.write(";");
			   			
			   			if(dataObj.getOpContract()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpContract()));
				   		}
			   			
						pwriter.write(";");
			   			
			   			if(dataObj.getOpConDesc()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpConDesc()));
				   		}
			   			
			 			pwriter.write("\n");
	 			} 
	 				
			  
		}
		  
		  pwriter.flush(); 
		} catch (FileNotFoundException e) {
			System.out.println("The exception is : " + e);
		} catch (Exception e1) {
			System.out.println("IOException : " + e1.getMessage());
		} finally {
			try {
				if (pwriter != null) {
					pwriter.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
			try {
				if (os != null) {
					os.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
		}*/
	}
	/**
	 * This method is used for Generating TC5 relations Report in CSV
	 * 
	 * @throws PLMCommonException
	 */
	
	public void createDownloadCSV() throws PLMCommonException {

		LOG.info("Entering createDownloadCSV Method");
		String fileName = "TC5RelationReport";
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		//Export to comma CSV for TC5 Relations Report
		PLMCsvRptColumn[] reportColumns =
						new PLMCsvRptColumn[] {new PLMCsvRptColumn("frmType", "Type", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("frmVersion", "Version", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("frmIdentifier", "Identifier / Identifiant", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("frmState", "State", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("frmRelaseDt", "Release", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("frmDesc", "Description", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("frmLibelle", "Libelle", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("connRelation", "Connection/ Relation", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("type", "Type", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("version", "Version", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("identifier", "Identifier / Identifiant", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("state", "State", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("release", "Release", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("description", "Description", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("libelle", "Libelle", FormatTypeCsv.TEXT)
						};
		
		PLMCsvRptColumn[] critcolumns = 
						new PLMCsvRptColumn[] {new PLMCsvRptColumn("selRevision", "TC5 Relations", FormatTypeCsv.TEXT),
						                       new PLMCsvRptColumn("tc5Code", "Code", FormatTypeCsv.TEXT)
						};
		csvUtil.exportCsv(tc5RelationList, reportColumns, fileName, dateFormat, true, critcolumns, tc5RelData, ",");
		LOG.info("Exiting createDownloadCSV Method");
		
		/*PrintWriter pwriter = null;
		OutputStream os = null;

		try {  
		   	
			FacesContext facesContext = FacesContext.getCurrentInstance();

			HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
			HttpServletRequest resquest = (HttpServletRequest) facesContext.getExternalContext().getRequest();
			
			HttpSession session = resquest.getSession();
			
			response.setContentType("application/CSV");
			   response.setHeader("content-disposition","attachment; filename=TC5RelationCSV.csv");
			   
			   pwriter = response.getWriter();
			   
			   PLMTC5RptMB  plmTC5RptMB = (PLMTC5RptMB)session.getAttribute("plmTC5RptMB");
			   
			    pwriter.write("Type");
	 			pwriter.write(",");
	 			pwriter.write("Version");
	 			pwriter.write(",");
	 			pwriter.write("Identifier/Identifiant");
	 			pwriter.write(",");
	 			pwriter.write("State");
	 			pwriter.write(",");
	 			pwriter.write("Release");
	 			pwriter.write(",");
	  			pwriter.write("Description");
	 			pwriter.write(",");
	 			pwriter.write("Libelle");
	 			pwriter.write(",");
	 			pwriter.write("Connection/Relation");
	 			pwriter.write(",");
	 		    pwriter.write("Type");
	 			pwriter.write(",");
	 			pwriter.write("Version");
	 			pwriter.write(",");
	 			pwriter.write("Identifier/Identifiant");
	 			pwriter.write(",");
	 			pwriter.write("State");
	 			pwriter.write(",");
	 			pwriter.write("Release");
	 			pwriter.write(",");
	  			pwriter.write("Description");
	 			pwriter.write(",");
	 			pwriter.write("Libelle");
	 							
	 			pwriter.write("\n");
	 		
	  			
			   if(plmTC5RptMB != null && plmTC5RptMB.getTc5RelationList() != null &&  plmTC5RptMB.getTc5RelationList().size() > 0) {
				 		     		
			   		for(int i=0; i<plmTC5RptMB.getTc5RelationList().size(); i++) {
			   			PLMTC5RelationsRptData dataObj = (PLMTC5RelationsRptData)plmTC5RptMB.getTc5RelationList().get(i);
			   			if(dataObj.getFrmType()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFrmType()));
				   			}
			   			pwriter.write(",");
			   			if(dataObj.getFrmVersion()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFrmVersion()));
						}
						pwriter.write(",");
						if(dataObj.getFrmIdentifier()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFrmIdentifier()));
						}
						pwriter.write(",");
						if(dataObj.getFrmState()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFrmState()));
						}
						pwriter.write(",");
						if(dataObj.getFrmRelaseDt()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFrmRelaseDt()));
						}
						pwriter.write(",");
			   			if(dataObj.getFrmDesc()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFrmDesc()));
				   		}
			   			pwriter.write(",");
			   			if(dataObj.getFrmLibelle()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFrmLibelle()));
						}
						pwriter.write(",");
						if(dataObj.getConnRelation()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getConnRelation()));
						}
						pwriter.write(",");
						if(dataObj.getType()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getType()));
						}
						pwriter.write(",");
					   
						if(dataObj.getVersion()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getVersion()));
						}
						pwriter.write(",");
						
						if(dataObj.getIdentifier()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getIdentifier()));
						}
						pwriter.write(",");
			   			
			   			if(dataObj.getState()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getState()));
			   			}
			   			pwriter.write(",");
				   		if(dataObj.getRelease()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRelease()));
				   		}			   				
				   		pwriter.write(",");					
						if(dataObj.getDescription()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDescription()));
						}
						pwriter.write(",");					
						if(dataObj.getLibelle()!= null){
							pwriter.write(PLMUtils.convertToCsvValue(dataObj.getLibelle()));
						}
			   			pwriter.write("\n");
			   			
			   		}
			   		
			   }
			   pwriter.flush(); 
		} catch (FileNotFoundException e) {
			System.out.println("The exception is : " + e);
		} catch (Exception e1) {
			System.out.println("IOException : " + e1.getMessage());
		} finally {
			try {
				if (pwriter != null) {
					pwriter.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
			try {
				if (os != null) {
					os.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
		}*/
	}
	
	/**
	 * This method is used for Generating TC5 Relations Report in CSV with French setting
	 * 
	 * @throws PLMCommonException
	 */
	
	public void createDownloadFrenchCSV() throws PLMCommonException {

		LOG.info("Entering createDownloadCSV Method");
		String fileName = "TC5RelationReport";
		
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		//Export to semi colon CSV for TC5 Relations Report
		PLMCsvRptColumn[] reportColumns =
						new PLMCsvRptColumn[] {new PLMCsvRptColumn("frmType", "Type", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("frmVersion", "Version", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("frmIdentifier", "Identifier / Identifiant", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("frmState", "State", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("frmRelaseDt", "Release", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("frmDesc", "Description", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("frmLibelle", "Libelle", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("connRelation", "Connection/ Relation", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("type", "Type", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("version", "Version", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("identifier", "Identifier / Identifiant", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("state", "State", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("release", "Release", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("description", "Description", FormatTypeCsv.TEXT),
								new PLMCsvRptColumn("libelle", "Libelle", FormatTypeCsv.TEXT)
						};
		
		PLMCsvRptColumn[] critcolumns = 
						new PLMCsvRptColumn[] {new PLMCsvRptColumn("selRevision", "TC5 Relations", FormatTypeCsv.TEXT),
						                       new PLMCsvRptColumn("tc5Code", "Code", FormatTypeCsv.TEXT)
						};
		csvUtil.exportCsv(tc5RelationList, reportColumns, fileName, dateFormat, true, critcolumns, tc5RelData, ";");
		LOG.info("Exiting createDownloadCSV Method");
		
		/*PrintWriter pwriter = null;
		OutputStream os = null;

		try {  
		   	
			   FacesContext facesContext = FacesContext.getCurrentInstance();

			   HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
			   HttpServletRequest resquest = (HttpServletRequest) facesContext.getExternalContext().getRequest();
			
			   HttpSession session = resquest.getSession();
			
			   response.setContentType("application/CSV");
			   response.setHeader("content-disposition","attachment; filename=TC5RelationSemiCol.csv");
			   
			   pwriter = response.getWriter();
			   
			   PLMTC5RptMB  plmTC5RptMB = (PLMTC5RptMB)session.getAttribute("plmTC5RptMB");
			   
			    pwriter.write("Type");
	 			pwriter.write(";");
	 			pwriter.write("Version");
	 			pwriter.write(";");
	 			pwriter.write("Identifier/Identifiant");
	 			pwriter.write(";");
	 			pwriter.write("State");
	 			pwriter.write(";");
	 			pwriter.write("Release");
	 			pwriter.write(";");
	  			pwriter.write("Description");
	 			pwriter.write(";");
	 			pwriter.write("Libelle");
	 			pwriter.write(";");
	 			pwriter.write("Connection/Relation");
	 			pwriter.write(";");
	 		    pwriter.write("Type");
	 			pwriter.write(";");
	 			pwriter.write("Version");
	 			pwriter.write(";");
	 			pwriter.write("Identifier/Identifiant");
	 			pwriter.write(";");
	 			pwriter.write("State");
	 			pwriter.write(";");
	 			pwriter.write("Release");
	 			pwriter.write(";");
	  			pwriter.write("Description");
	 			pwriter.write(";");
	 			pwriter.write("Libelle");
	 							
	 			pwriter.write("\n");
	 		
	  			
			   if(plmTC5RptMB != null && plmTC5RptMB.getTc5RelationList() != null &&  plmTC5RptMB.getTc5RelationList().size() > 0) {
				 		     		
			   		for(int i=0; i<plmTC5RptMB.getTc5RelationList().size(); i++) {
			   			PLMTC5RelationsRptData dataObj = (PLMTC5RelationsRptData)plmTC5RptMB.getTc5RelationList().get(i);
			   			if(dataObj.getFrmType()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getFrmType()));
				   			}
			   			pwriter.write(";");
			   			if(dataObj.getFrmVersion()!= null){
							pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getFrmVersion()));
						}
						pwriter.write(";");
						if(dataObj.getFrmIdentifier()!= null){
							pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getFrmIdentifier()));
						}
						pwriter.write(";");
						if(dataObj.getFrmState()!= null){
							pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getFrmState()));
						}
						pwriter.write(";");
						if(dataObj.getFrmRelaseDt()!= null){
							pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getFrmRelaseDt()));
						}
						pwriter.write(";");
			   			if(dataObj.getFrmDesc()!= null){
				   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getFrmDesc()));
				   		}
			   			pwriter.write(";");
			   			if(dataObj.getFrmLibelle()!= null){
							pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getFrmLibelle()));
						}
						pwriter.write(";");
						if(dataObj.getConnRelation()!= null){
							pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getConnRelation()));
						}
						pwriter.write(";");
						if(dataObj.getType()!= null){
							pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getType()));
						}
						pwriter.write(";");
					   
						if(dataObj.getVersion()!= null){
							pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getVersion()));
						}
						pwriter.write(";");
						if(dataObj.getIdentifier()!= null){
							pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getIdentifier()));
						}
						pwriter.write(";");
			   			if(dataObj.getState()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getState()));
			   			}
			   			pwriter.write(";");
				   		if(dataObj.getRelease()!= null){
				   		pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getRelease()));
				   		}			   				
				   		pwriter.write(";");					
						if(dataObj.getDescription()!= null){
							pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getDescription()));
						}
						pwriter.write(";");					
						if(dataObj.getLibelle()!= null){
							pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getLibelle()));
						}
			   			pwriter.write("\n");
			   		}
			   		
			   }
			   pwriter.flush(); 
		} catch (FileNotFoundException e) {
			System.out.println("The exception is : " + e);
		} catch (Exception e1) {
			System.out.println("IOException : " + e1.getMessage());
		} finally {
			try {
				if (pwriter != null) {
					pwriter.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
			try {
				if (os != null) {
					os.close();
				}
			} catch (Exception exc) {
				exc.printStackTrace();
			}
		}*/
	}
	
	 /**
	 * This method is used for sendTC5RelationEmail
	 * @throws PWiException 
	 * 
	 */
	public void sendTC5RelationEmail() throws PWiException{
	 alertMessage=validateTC5RelationData();
	 
	 // Get user details for sending mail. Need before taskexecuter as context will be null while excuting the thread
	 userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
	 
	if (PLMUtils.isEmpty(alertMessage)){
		alertMessage = PLMTC5RptConstants.TC5_CODE_REL_MAIL_RERORT;
		taskExecutor.execute(new MailThreadTC5Relation());
	}
   }
		
	/**
	 * Background Process Thread
	 */
	private class MailThreadTC5Relation implements Runnable {
		public MailThreadTC5Relation(){}
		public void run() {
			try{
			 sendTC5RelationReport();
			}catch (Exception exception) {	
				LOG.log(Level.ERROR, "Exception@run() of sendTC5RelationReport: ", exception);
			}
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public void sendTC5RelationReport() throws PWiException {
		LOG.info("Entering sendTC5RelationReport Method");
		
		String tc5CodeLcl =tc5Code;
		String selRevisionLcl= selRevision;
		String from = PLMTC5RptConstants.TC5_CODE_MAIL_FROM;

		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = "";
		
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathCSV ="";
		String filePathZip ="";

		try {
			List<PLMTC5RelationsRptData> tc5RelationListLcl = plmTC5RptService.getTC5RelationRpt(tc5CodeLcl,selRevisionLcl);
		
			 if(!PLMUtils.isEmptyList(tc5RelationListLcl)){
				 
				  StringBuffer mailBody = new StringBuffer().append(toAddressee)
				  .append(PLMTC5RptConstants.TC5_CODE_REL_MAIL_CSV)
				  .append(tc5CodeLcl)
				  .append(".")
				  .append(PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE)
				  .append(PLMTC5RptConstants.TC5_CODE_MAIL_FOOTER);
				  subject = PLMTC5RptConstants.TC5_CODE_MAIL_SUBJECT + tc5CodeLcl;
				  final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
				  Date uniqDate = new Date();
				  String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
				  filePathCSV = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("TC5_RELATION_RPT_NM") + "_" + uniqTime + ".csv";
				  filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("TC5_RELATION_RPT_NM") + "_" + uniqTime + ".zip";
				  LOG.info("TC5 Relation Report CSV File Name "+filePathCSV);
				  LOG.info("TC5 Relation Report Zip File Name "+filePathZip);
				  saveTC5RltnRptCSV(tc5CodeLcl,tc5RelationListLcl,fileDir,filePathCSV);
				  PLMUtils.generateZipFile(filePathCSV,filePathZip);
				  PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
			 }else {
					StringBuffer mailNoDataBody = new StringBuffer()
					.append(toAddressee)
					.append(PLMTC5RptConstants.TC5_CODE_NO_RECORD_FOUND)
					.append(tc5CodeLcl)
					.append(".")
					.append(PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE)
					.append(PLMTC5RptConstants.TC5_CODE_MAIL_FOOTER);
					subject = PLMTC5RptConstants.TC5_CODE_MAIL_SUBJECT + tc5CodeLcl;
					PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
					LOG.info("No data Mail sent");
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendTC5RelationReport: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendTC5RelationReport: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE);
		} finally {
			PLMUtils.deleteFiles(filePathCSV,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendTC5RelationReport Method");
	}
	
	/**
	 * This method is used for saveTC5RltnRptCSV
	 * 
	 * @param  tc5CodeLcl, tc5RelationListLcl,fileDir,filePathCSV
	 * @throws Exception
	 */
	public void saveTC5RltnRptCSV(String tc5CodeLcl,List<PLMTC5RelationsRptData> tc5RelationListLcl,
			String fileDir,String filePathCSV) throws Exception {
		LOG.info("Entering saveTC5RltnRptCSV Method");
		FileOutputStream fileOut = null;
		PrintWriter pwriter =null;
		boolean createFileExist;
		try {
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathCSV);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
					fileOut = new FileOutputStream(filePathCSV);
					pwriter =  new PrintWriter( new FileWriter(filePathCSV));
					   
					pwriter.write("Type");
		 			pwriter.write(",");
		 			pwriter.write("Version");
		 			pwriter.write(",");
		 			pwriter.write("Identifier/Identifiant");
		 			pwriter.write(",");
		 			pwriter.write("State");
		 			pwriter.write(",");
		 			pwriter.write("Release");
		 			pwriter.write(",");
		  			pwriter.write("Description");
		 			pwriter.write(",");
		 			pwriter.write("Libelle");
		 			pwriter.write(",");
		 			pwriter.write("Connection/Relation");
		 			pwriter.write(",");
		 		    pwriter.write("Type");
		 			pwriter.write(",");
		 			pwriter.write("Version");
		 			pwriter.write(",");
		 			pwriter.write("Identifier/Identifiant");
		 			pwriter.write(",");
		 			pwriter.write("State");
		 			pwriter.write(",");
		 			pwriter.write("Release");
		 			pwriter.write(",");
		  			pwriter.write("Description");
		 			pwriter.write(",");
		 			pwriter.write("Libelle");
		 			pwriter.write("\n");
		 			
			 			if(!PLMUtils.isEmptyList(tc5RelationListLcl)) {
					   		for(int i=0; i<tc5RelationListLcl.size(); i++) {
					   			PLMTC5RelationsRptData dataObj = (PLMTC5RelationsRptData)tc5RelationListLcl.get(i);
					   			
					  			if(dataObj.getFrmType()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFrmType()));
						   			}
					   			pwriter.write(",");
					   			if(dataObj.getFrmVersion()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFrmVersion()));
								}
								pwriter.write(",");
								if(dataObj.getFrmIdentifier()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFrmIdentifier()));
								}
								pwriter.write(",");
								if(dataObj.getFrmState()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFrmState()));
								}
								pwriter.write(",");
								if(dataObj.getFrmRelaseDt()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFrmRelaseDt()));
								}
								pwriter.write(",");
					   			if(dataObj.getFrmDesc()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFrmDesc()));
						   		}
					   			pwriter.write(",");
					   			if(dataObj.getFrmLibelle()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFrmLibelle()));
						   		}
					   			pwriter.write(",");
					   			if(dataObj.getConnRelation()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getConnRelation()));
								}
								pwriter.write(",");
					   			
								if(dataObj.getType()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getType()));
								}
								pwriter.write(",");
							   
								if(dataObj.getVersion()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getVersion()));
								}
								pwriter.write(",");
								
								if(dataObj.getIdentifier()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getIdentifier()));
								}
								pwriter.write(",");
					   			
					   			if(dataObj.getState()!= null){
					   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getState()));
					   			}
					   			pwriter.write(",");
						   		if(dataObj.getRelease()!= null){
						   		pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRelease()));
						   		}			   				
						   		pwriter.write(",");					
								if(dataObj.getDescription()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getDescription()));
								}
								pwriter.write(",");					
								if(dataObj.getLibelle()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getLibelle()));
								}
					   			pwriter.write("\n");
					   			
					   		}//END OF FOR LOOP FOR TC5 Relation
					   		
			 			} // END OF IF CONDITION FOR TC5 Relation LIST 	
			 			
				}//END OF IF FOR FILE NAME EXIST
				
		} catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@saveTC5RltnRptCSV: ", e);
				throw e;
		  } catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveTC5RltnRptCSV: ", e);
				throw e;
		    }  finally {
				try {
					if (pwriter !=null) {
						pwriter.close();
					}
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@saveTC5RltnRptCSV: ", e);
					throw e;
				}
			   }
			LOG.info("Exiting saveTC5RltnRptCSV Method");
		}
	
	 /**
	 * This method is used for sendTC5RtlnSmClnEmail
	 * @throws PWiException 
	 * 
	 */
	public void sendTC5RtlnSmClnEmail() throws PWiException{
	 alertMessage=validateTC5RelationData();
	 
	// Get user details for sending mail. Need before taskexecuter as context will be null while excuting the thread
	 userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
	 
	if (PLMUtils.isEmpty(alertMessage)){
		alertMessage = PLMTC5RptConstants.TC5_CODE_REL_MAIL_RERORT;
		taskExecutor.execute(new MailThreadTC5RelationSmCln());
	}
   }
		
	/**
	 * Background Process Thread
	 */
	private class MailThreadTC5RelationSmCln implements Runnable {
		public MailThreadTC5RelationSmCln(){}
		public void run() {
			try{
			 sendTC5RelationSmClnReport();
			}catch (Exception exception) {	
				LOG.log(Level.ERROR, "Exception@run() of sendTC5RelationSmClnReport: ", exception);
			}
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return String
	 */
	public void sendTC5RelationSmClnReport() {
		LOG.info("Entering sendTC5RelationSmClnReport Method");
		String tc5CodeLcl =tc5Code;
		String selRevisionLcl= selRevision;
		String from = PLMTC5RptConstants.TC5_CODE_MAIL_FROM;	
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = "";
		
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathCSV ="";
		String filePathZip ="";

		try {
			List<PLMTC5RelationsRptData> tc5RelationListLcl = plmTC5RptService.getTC5RelationRpt(tc5CodeLcl,selRevisionLcl);
		
			 if(!PLMUtils.isEmptyList(tc5RelationListLcl)){
				 
				  StringBuffer mailBody = new StringBuffer().append(toAddressee)
				  .append(PLMTC5RptConstants.TC5_CODE_REL_MAIL_SMCLN)
				  .append(tc5CodeLcl)
				  .append(".")
				  .append(PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE)
				  .append(PLMTC5RptConstants.TC5_CODE_MAIL_FOOTER);
				  subject = PLMTC5RptConstants.TC5_CODE_MAIL_SUBJECT + tc5CodeLcl;
				  final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
				  Date uniqDate = new Date();
				  String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
				  filePathCSV = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("TC5_RELATION_RPT_NM") + "_" + uniqTime + ".csv";
				  filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("TC5_RELATION_RPT_NM") + "_" + uniqTime + ".zip";

				  LOG.info("TC5 Relation Report Semicolon CSV File Name "+filePathCSV);
				  LOG.info("TC5 Relation Report Semicolon Zip File Name "+filePathZip);
				  
				  saveTC5RltnRptSmClnCSV(tc5CodeLcl,tc5RelationListLcl,fileDir,filePathCSV);
				  PLMUtils.generateZipFile(filePathCSV,filePathZip);
				  PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
			 }else {
					StringBuffer mailNoDataBody = new StringBuffer()
					.append(toAddressee)
					.append(PLMTC5RptConstants.TC5_CODE_NO_RECORD_FOUND)
					.append(tc5CodeLcl)
					.append(".")
					.append(PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE)
					.append(PLMTC5RptConstants.TC5_CODE_MAIL_FOOTER);
					subject = PLMTC5RptConstants.TC5_CODE_MAIL_SUBJECT + tc5CodeLcl;
					PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
					LOG.info("No data Mail sent");
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendTC5RelationSmClnReport: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendTC5RelationSmClnReport: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE);
		} finally {
			PLMUtils.deleteFiles(filePathCSV,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendTC5RelationSmClnReport Method");
	}
	
	/**
	 * This method is used for saveTC5RltnRptSmClnCSV
	 * 
	 * @param  tc5CodeLcl, tc5RelationListLcl,fileDir,filePathCSV
	 * @throws Exception
	 */
	public void saveTC5RltnRptSmClnCSV(String tc5CodeLcl,List<PLMTC5RelationsRptData> tc5RelationListLcl,
			String fileDir,String filePathCSV) throws Exception {
		LOG.info("Entering saveTC5RltnRptSmClnCSV Method");
		FileOutputStream fileOut = null;
		PrintWriter pwriter =null;
		boolean createFileExist;
		try {
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathCSV);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
					fileOut = new FileOutputStream(filePathCSV);
					pwriter =  new PrintWriter( new FileWriter(filePathCSV));
					   
					pwriter.write("Type");
		 			pwriter.write(";");
		 			pwriter.write("Version");
		 			pwriter.write(";");
		 			pwriter.write("Identifier/Identifiant");
		 			pwriter.write(";");
		 			pwriter.write("State");
		 			pwriter.write(";");
		 			pwriter.write("Release");
		 			pwriter.write(";");
		  			pwriter.write("Description");
		 			pwriter.write(";");
		 			pwriter.write("Libelle");
		 			pwriter.write(";");
		 			pwriter.write("Connection/Relation");
		 			pwriter.write(";");
		 		    pwriter.write("Type");
		 			pwriter.write(";");
		 			pwriter.write("Version");
		 			pwriter.write(";");
		 			pwriter.write("Identifier/Identifiant");
		 			pwriter.write(";");
		 			pwriter.write("State");
		 			pwriter.write(";");
		 			pwriter.write("Release");
		 			pwriter.write(";");
		  			pwriter.write("Description");
		 			pwriter.write(";");
		 			pwriter.write("Libelle");
		 			pwriter.write("\n");
		 			
			 			if(!PLMUtils.isEmptyList(tc5RelationListLcl)) {
					   		for(int i=0; i<tc5RelationListLcl.size(); i++) {
					   			PLMTC5RelationsRptData dataObj = (PLMTC5RelationsRptData)tc5RelationListLcl.get(i);
					   			
					  			if(dataObj.getFrmType()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getFrmType()));
						   			}
					   			pwriter.write(";");
					   			if(dataObj.getFrmVersion()!= null){
									pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getFrmVersion()));
								}
								pwriter.write(";");
								if(dataObj.getFrmIdentifier()!= null){
									pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getFrmIdentifier()));
								}
								pwriter.write(";");
								if(dataObj.getFrmState()!= null){
									pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getFrmState()));
								}
								pwriter.write(";");
								if(dataObj.getFrmRelaseDt()!= null){
									pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getFrmRelaseDt()));
								}
								pwriter.write(";");
					   			if(dataObj.getFrmDesc()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getFrmDesc()));
						   		}
					   			pwriter.write(";");
					   			if(dataObj.getFrmLibelle()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getFrmLibelle()));
						   		}
					   			pwriter.write(";");
					   			if(dataObj.getConnRelation()!= null){
									pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getConnRelation()));
								}
								pwriter.write(";");
					   			
								if(dataObj.getType()!= null){
									pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getType()));
								}
								pwriter.write(";");
							   
								if(dataObj.getVersion()!= null){
									pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getVersion()));
								}
								pwriter.write(";");
								
								if(dataObj.getIdentifier()!= null){
									pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getIdentifier()));
								}
								pwriter.write(";");
					   			
					   			if(dataObj.getState()!= null){
					   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getState()));
					   			}
					   			pwriter.write(";");
						   		if(dataObj.getRelease()!= null){
						   		pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getRelease()));
						   		}			   				
						   		pwriter.write(";");					
								if(dataObj.getDescription()!= null){
									pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getDescription()));
								}
								pwriter.write(";");					
								if(dataObj.getLibelle()!= null){
									pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getLibelle()));
								}
					   			pwriter.write("\n");
					   			
					   		}//END OF FOR LOOP FOR TC5 Relation
					   		
			 			} // END OF IF CONDITION FOR TC5 Relation LIST 	
			 			
				}//END OF IF FOR FILE NAME EXIST
				
		} catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@saveTC5RltnRptSmClnCSV: ", e);
				throw e;
		  } catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveTC5RltnRptSmClnCSV: ", e);
				throw e;
		    }  finally {
				try {
					if (pwriter !=null) {
						pwriter.close();
					}
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@saveTC5RltnRptSmClnCSV: ", e);
					throw e;
				}
			   }
			LOG.info("Exiting saveTC5RltnRptSmClnCSV Method");
		}
	
	//Added by Shekhar for TC5 MLI Report
	/**
	 * This method is used for loadTC5MLIRptSearchPage
	 * 
	 * @return String
	 */
	public String loadTC5MLIRptSearchPage() {
		LOG.info("Entering loadTC5MLIRptSearchPage Method");
		
		
		plmTC5MliRptData = new PLMTC5MliRptData();
		resetTC5MLISearchData();
		searchResultList.clear();
		plmTC5MliRptData.setEnteredRadioValue("partsDocDefMLI");
		try {
			commonMB.insertCannedRptRecordHitInfo("TC5 MLI Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			commonMB.getPLMDateStamp(PLMConstants.ECO_TABLE);
		 } catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPLMDateStamp: ", exception);
		 }
		
		LOG.info("Exiting loadTC5MLIRptSearchPage Method");
		return "tc5MliRptSearch";
	}
	
	public String resetTC5MLISearchData(){
		LOG.info("Inside resetSearchData()...");
		plmTC5MliRptData.setEnteredSNProjIPSTC5("");
		plmTC5MliRptData.setEnteredConDesc("");
		plmTC5MliRptData.setEnteredMLI("");
		alertMessage="";
		plmTC5MliRptData.setEnteredRadioValue("partsDocDefMLI");
		searchResultList.clear();
		
		LOG.info("Existing resetSearchData()...");
		
		return "tc5MliRptSearch";
	}
	
	/**
	 * This method is used for Get Search TC5 MLI Data
	 * 
	 * @return String
	 */
	public String getTC5MLIReport() {
		LOG.info("Inside getTC5MLIReport.....");
		alertMessage="";
		exportToExcelFlag=false;
		LOG.info("Selected SN/Project/IPS: "+plmTC5MliRptData.getEnteredSNProjIPSTC5());
		LOG.info("Selected Contract Desc: "+plmTC5MliRptData.getEnteredConDesc());
		LOG.info("Selected MLI: "+plmTC5MliRptData.getEnteredMLI());		
		LOG.info("Selected Radio Button: "+plmTC5MliRptData.getEnteredRadioValue());
		String fwdFlag = "tc5MliRptSearch";
		
		validateMliRptInput(plmTC5MliRptData.getEnteredSNProjIPSTC5(),
				plmTC5MliRptData.getEnteredConDesc(),plmTC5MliRptData.getEnteredMLI());
		
		if (PLMUtils.isEmpty(alertMessage)) {
			LOG.info("No Validation error is there... proceeding further");
			
			try {
				searchResultList = plmTC5RptService.getTC5MLIReport(plmTC5MliRptData);
				if (searchResultList != null) {
					totalRecCount = searchResultList.size();
					if( totalRecCount<=PLMConstants.CUSTDOC_RPT_SIZE_NONEX){
						exportToExcelFlag=true;
					}
					else{
						exportToExcelFlag=false;
					}
				} else {
					totalRecCount = 0;
				}
				LOG.info("Fetched Result List of size::::: "+totalRecCount);
				
				StringBuffer selCrtMsgTemp=new StringBuffer();
				if(plmTC5MliRptData.getEnteredSNProjIPSTC5()!=null && plmTC5MliRptData.getEnteredSNProjIPSTC5().length()>0){
					selCrtMsgTemp.append("SN#'s/Project's/IPS's/TC5 Number's: "+plmTC5MliRptData.getEnteredSNProjIPSTC5());
				}
				
				if(plmTC5MliRptData.getEnteredConDesc()!=null && plmTC5MliRptData.getEnteredConDesc().length()>0){
					selCrtMsgTemp.append(" Contract Description: "+plmTC5MliRptData.getEnteredConDesc());
				}
				
				if(plmTC5MliRptData.getEnteredMLI()!=null && plmTC5MliRptData.getEnteredMLI().length()>0){
					selCrtMsgTemp.append(" MLI: "+plmTC5MliRptData.getEnteredMLI());
				}
				
				//selCrtMsg="";
				selCrtMsg=selCrtMsgTemp.toString();
				
				setTotalRecCountMsg("Total Results Count : " + totalRecCount);
				LOG.info("totalRecCount::::::::::::::::::" + totalRecCount);
				if (totalRecCount == 0) {
					fwdFlag = "invalidTc5Mli";
				} else {
					recordCounts = PLMConstants.N_100;
					fwdFlag = "tc5MliRptResult";
				}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getTC5MLIReport: ", exception);
				fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"tc5MliRptSearch","tc5MliRptResult");
			} 
		}
		LOG.info("Inside getTC5MLIReport.....");
		return fwdFlag;
	}
	
	private void validateMliRptInput(String tc5CodeLocal, String ctrtDesc, String mli) {
		
		alertMessage = "";
		if (PLMUtils.isEmpty(tc5CodeLocal)
				&& PLMUtils.isEmpty(ctrtDesc)
				&& PLMUtils.isEmpty(mli)
				) {
			alertMessage = PLMTC5RptConstants.TC5MLI_SRCH_CRT;
		} else {
			//Validation of SN/Proj/IPS/TC5
			if(!PLMTC5RptUtils.checkForSplCharsTC5MLICode((tc5CodeLocal))){
				LOG.info("Special Character exists in SN/Proj/IPS/TC5...");
				alertMessage=PLMTC5RptConstants.TC5_CODE_MLI_SPLCHAR_DOC;
		
			} 
			if (PLMUtils.isEmpty(alertMessage)) {
				if(tc5CodeLocal.contains("*") 
						|| tc5CodeLocal.contains("?")){
					if(!PLMTC5RptUtils.checkForCharsDigitsTC5Code((tc5CodeLocal))){
						LOG.info("SN/Proj/IPS/TC5 has a * or ? but does not have atleast 3 char or digit...");
						alertMessage=PLMTC5RptConstants.TC5MLI_CODE_CHARDIGIT;
				
					}
				}
			}
			
			//Validation of Contract Description
			if (PLMUtils.isEmpty(alertMessage)) {
				if(!PLMUtils.checkForSpecialCharsCustDoc((ctrtDesc))){
					LOG.info("Special Character exists in Contract Desc...");
					alertMessage=PLMTC5RptConstants.TC5MLI_CTDESC_SPLCHAR;
			
				} 
			}
			
			if (PLMUtils.isEmpty(alertMessage)) {
				if(ctrtDesc.contains("*") 
						|| ctrtDesc.contains("?")){
					if(!PLMTC5RptUtils.chkChrDgtCntMliCtDesc((ctrtDesc))){
						LOG.info("Contract Desc has a * or ? but does not have atleast 3 char or digit...");
						alertMessage=PLMTC5RptConstants.TC5MLI_CHARDIGIT;
				
					}
				}
			}
			
			//Validation of MLI
			if (PLMUtils.isEmpty(alertMessage)) {
				if(!PLMTC5RptUtils.checkForCharsDigitsCount((mli))){
					LOG.info("MLI has a * or ? but does not have atleast 3 char or digit...");
					//alertMessage="No Special Characters allowed in Contract/Project";
					alertMessage=PLMTC5RptConstants.TC5MLI_CHARDIGIT;
				}
			}
			
		}
	}
	
	 /**
	 * This method is used for sendEmail
	 * @throws PWiException 
	 * 
	 */
	public void sendTC5MLIEmailComma() throws PWiException{
		LOG.info("Inside sendTC5MLIEmailComma.....");
		alertMessage="";
		alertMessage="";
		
		// Get user details for sending mail. Need before taskexecuter as context will be null while excuting the thread
		userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		 
		//exportToExcelFlag=false;
		LOG.info("Selected SN/Project/IPS: "+plmTC5MliRptData.getEnteredSNProjIPSTC5());
		LOG.info("Selected Contract Desc: "+plmTC5MliRptData.getEnteredConDesc());
		LOG.info("Selected MLI: "+plmTC5MliRptData.getEnteredMLI());		
		LOG.info("Selected Radio Button: "+plmTC5MliRptData.getEnteredRadioValue());
		
		validateMliRptInput(plmTC5MliRptData.getEnteredSNProjIPSTC5(),
				plmTC5MliRptData.getEnteredConDesc(),plmTC5MliRptData.getEnteredMLI());
		
		if (PLMUtils.isEmpty(alertMessage)) {
			LOG.info("No Validation error is there... proceeding further to send Email");
			alertMessage = PLMTC5RptConstants.TC5MLI_MAIL_RERORT_ALERT;
			taskExecutor.execute(new MailThreadTC5MLIComma());
		}
	
}
	
	/**
	 * Background Process Thread
	 */
	private class MailThreadTC5MLIComma implements Runnable {
		public MailThreadTC5MLIComma(){}
		public void run() {
			sendTC5MLIMailComma();
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return String
	 */
	public void sendTC5MLIMailComma() {
		LOG.info("Entering sendTC5MLIMailComma Method");
		
		String from = PLMConstants.LTTR_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMTC5RptConstants.TC5MLI_MAIL_SUBJECT;
		StringBuffer mailBody = new StringBuffer().append(toAddressee)
		.append(PLMTC5RptConstants.TC5MLI_MAIL_CONTENT_CSV)
		
		.append("\n")
		.append("Search Criteria \n")
		.append("--------------- \n")
		.append("SN#'s/Project's/IPS's/TC5 Number's: "+plmTC5MliRptData.getEnteredSNProjIPSTC5()+"\n\n")
		.append("Contract Description: "+plmTC5MliRptData.getEnteredConDesc()+"\n")
		.append("MLI: "+plmTC5MliRptData.getEnteredMLI()+"\n");
		
		mailBody.append(PLMConstants.LTTR_MAIL_SIGNATURE)
		.append(PLMConstants.LTTR_MAIL_FOOTER);
		LOG.info(mailBody.toString());
		
		StringBuffer mailNoDataBody = new StringBuffer()
		.append(toAddressee)
		.append(PLMTC5RptConstants.TC5MLI_NO_CONTENT_BODY)
		
		.append("\n")
		.append("Search Criteria \n")
		.append("--------------- \n")
		.append("SN#'s/Project's/IPS's/TC5 Number's: "+plmTC5MliRptData.getEnteredSNProjIPSTC5()+"\n\n")
		.append("Contract Description: "+plmTC5MliRptData.getEnteredConDesc()+"\n")
		.append("MLI: "+plmTC5MliRptData.getEnteredMLI()+"\n");
			
		mailNoDataBody.append(PLMConstants.LTTR_MAIL_SIGNATURE)
		.append(PLMConstants.LTTR_MAIL_FOOTER);
		LOG.info(mailNoDataBody.toString());
		
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		
		String filePathCSV = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("TC5_MLI_RPT_NM")  + "_" + uniqTime + ".csv";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("TC5_MLI_RPT_NM")  + "_" + uniqTime + ".zip";

		LOG.info("TC5 MLI Report comma CSV File Name "+filePathCSV);
		LOG.info("TC5 MLI Report comma CSV Zip File Name "+filePathZip);
		
		try {
			searchResultList=new ArrayList<PLMTC5MliRptData>();
			searchResultList = plmTC5RptService.getTC5MLIReport(plmTC5MliRptData);
				
			 if(!PLMUtils.isEmptyList(searchResultList)){
				 LOG.info("Returned result list of size:::"+searchResultList.size());
				
				 saveTC5MLICsvFile(plmTC5MliRptData,searchResultList,fileDir,filePathCSV);
				 
				 PLMUtils.generateZipFile(filePathCSV,filePathZip);
				 
				 PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
				 
				
				 searchResultList.clear();
				 
			 }else {				
				PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
				LOG.info("No data Mail sent...............");
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendTC5MLIMailComma: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendTC5MLIMailComma: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
		} finally {
			PLMUtils.deleteFiles(filePathCSV,filePathZip);
			
		}
		LOG.info("Mail sent successfully.....................");
		LOG.info("Exiting sendTC5MLIMailComma Method");
	}
	
	/**
	 * This method is used for saveEpeBaBoMCSVFile
	 * 
	 * @param  partNameLcl, epeBaBomRptList,fileDir,filePathCSV
	 * @throws Exception
	 */
	public void saveTC5MLICsvFile(PLMTC5MliRptData plmTC5MliRptDataLcl,List<PLMTC5MliRptData> searchResultListLcl,
			String fileDir,String filePathCSV) throws Exception {
		LOG.info("Entering saveTC5MLICsvFile Method");

		FileOutputStream fileOut = null;
		PrintWriter pwriter =null;
		boolean createFileExist;
		try {
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathCSV);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
					fileOut = new FileOutputStream(filePathCSV);
					pwriter =  new PrintWriter( new FileWriter(filePathCSV));
					
					
						pwriter.write("SN#'s/Project's/IPS's/TC5 Number's");
						pwriter.write(",");
						pwriter.write(plmTC5MliRptDataLcl.getEnteredSNProjIPSTC5());
						pwriter.write("\n");
						pwriter.write("Contract Description");
						pwriter.write(",");
						pwriter.write(plmTC5MliRptDataLcl.getEnteredConDesc());
						pwriter.write("\n");
						pwriter.write("MLI");
						pwriter.write(",");
						pwriter.write(plmTC5MliRptDataLcl.getEnteredMLI());
						pwriter.write("\n");
					
					    pwriter.write("\n");
		 		
					    pwriter.write("MLI");
						pwriter.write(",");
						pwriter.write("Obj Name");
						pwriter.write(",");
						pwriter.write("Obj Rev");
						pwriter.write(",");
						pwriter.write("Qty");
						pwriter.write(",");
						pwriter.write("UoM/DocType");
						pwriter.write(",");
						pwriter.write("FR Description");
						pwriter.write(",");
						pwriter.write("EN Description");
						pwriter.write(",");
						pwriter.write("Sect");
						pwriter.write(",");
						pwriter.write("Item Name");
						pwriter.write(",");
						pwriter.write("Item Rev");
						pwriter.write(",");
						pwriter.write("SN");
						pwriter.write(",");
						pwriter.write("TM /TOT");
						pwriter.write(",");
						pwriter.write("Project/Affaire");
						pwriter.write(",");
						pwriter.write("Contract");
						pwriter.write(",");
						pwriter.write("Contract Description");
			 			
			 			pwriter.write("\n");
			 			if(!PLMUtils.isEmptyList(searchResultListLcl)) {
			 				for(int i=0; i<searchResultListLcl.size(); i++) {
			 					PLMTC5MliRptData dataObj = (PLMTC5MliRptData)searchResultListLcl.get(i);
					   			
			 					if(dataObj.getOpMLI()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpMLI()+"\""));
						   		}
					   			   			
					   			pwriter.write(",");
					   			
					   			if(dataObj.getOpObjName()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpObjName()));
						   		}
					   			
								pwriter.write(",");
					   			
					   			if(dataObj.getOpObjRev()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpObjRev()+"\""));
						   		}
					   			
								pwriter.write(",");
					   			
					   			if(dataObj.getOpQty()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpQty()+"\""));
						   		}
					   			
								pwriter.write(",");
					   			
					   			if(dataObj.getOpUomDocType()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpUomDocType()));
						   		}
					   			
					   			pwriter.write(",");
					   			
					   			if(dataObj.getOpFRDesc()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpFRDesc()));
						   		}
					   			
								pwriter.write(",");
					   			
					   			if(dataObj.getOpENDesc()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpENDesc()));
						   		}
					   			
								pwriter.write(",");
					   			
					   			if(dataObj.getOpSect()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpSect()+"\""));
						   		}
					   			
								pwriter.write(",");
					   			
					   			if(dataObj.getOpItemName()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpItemName()));
						   		}
					   			
								pwriter.write(",");
					   			
					   			if(dataObj.getOpItemRev()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpItemRev()));
						   		}
					   			
								pwriter.write(",");
					   			
					   			if(dataObj.getOpSN()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpSN()));
						   		}
					   			
								pwriter.write(",");
					   			
					   			if(dataObj.getOpTmTot()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpTmTot()));
						   		}
					   			
								pwriter.write(",");
					   			
					   			if(dataObj.getOpProject()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpProject()));
						   		}
					   			
								pwriter.write(",");
					   			
					   			if(dataObj.getOpContract()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpContract()));
						   		}
					   			
								pwriter.write(",");
					   			
					   			if(dataObj.getOpConDesc()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getOpConDesc()));
						   		}
					   			
		
				   			
					   		pwriter.write("\n");
			 			} 
					  
				}
			}
				
			} catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@saveTC5MLICsvFile: ", e);
				throw e;
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveTC5MLICsvFile: ", e);
				throw e;
			}  finally {
				try {
					if (pwriter !=null) {
						pwriter.close();
					}
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@saveTC5MLICsvFile: ", e);
					throw e;
				}
			}
			LOG.info("Exiting saveTC5MLICsvFile Method");
		}
	
	 /**
	 * This method is used for sendTC5MLIEmailSmCln
	 * @throws PWiException 
	 * 
	 */
	public void sendTC5MLIEmailSmCln() throws PWiException{
		LOG.info("Inside sendTC5MLIEmailSmCln.....");
		alertMessage="";
		alertMessage="";
		
		// Get user details for sending mail. Need before taskexecuter as context will be null while excuting the thread
		userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		
		//exportToExcelFlag=false;
		LOG.info("Selected SN/Project/IPS: "+plmTC5MliRptData.getEnteredSNProjIPSTC5());
		LOG.info("Selected Contract Desc: "+plmTC5MliRptData.getEnteredConDesc());
		LOG.info("Selected MLI: "+plmTC5MliRptData.getEnteredMLI());		
		LOG.info("Selected Radio Button: "+plmTC5MliRptData.getEnteredRadioValue());

		validateMliRptInput(plmTC5MliRptData.getEnteredSNProjIPSTC5(),
				plmTC5MliRptData.getEnteredConDesc(),plmTC5MliRptData.getEnteredMLI());
		
		if (PLMUtils.isEmpty(alertMessage)) {
			LOG.info("No Validation error is there... proceeding further to sendTC5MLIEmailSmCln");
			alertMessage = PLMTC5RptConstants.TC5MLI_MAIL_RERORT_ALERT;
			taskExecutor.execute(new MailThreadTC5MLISmCln());
		}
	
	}
	
	/**
	 * Background Process Thread
	 */
	private class MailThreadTC5MLISmCln implements Runnable {
		public MailThreadTC5MLISmCln(){}
		public void run() {
			sendTC5MLIMailSmCln();
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return String
	 */
	public void sendTC5MLIMailSmCln() {
		LOG.info("Entering sendTC5MLIMailSmCln Method");
		
		String from = PLMConstants.LTTR_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMTC5RptConstants.TC5MLI_MAIL_SUBJECT;
		StringBuffer mailBody = new StringBuffer().append(toAddressee)
		.append(PLMTC5RptConstants.TC5MLI_MAIL_CONTENT_SMCLN)
		
		.append("\n")
		.append("Search Criteria \n")
		.append("--------------- \n")
		.append("SN#'s/Project's/IPS's/TC5 Number's: "+plmTC5MliRptData.getEnteredSNProjIPSTC5()+"\n\n")
		.append("Contract Description: "+plmTC5MliRptData.getEnteredConDesc()+"\n")
		.append("MLI: "+plmTC5MliRptData.getEnteredMLI()+"\n");
		
		mailBody.append(PLMConstants.LTTR_MAIL_SIGNATURE)
		.append(PLMConstants.LTTR_MAIL_FOOTER);
		LOG.info(mailBody.toString());
		
		StringBuffer mailNoDataBody = new StringBuffer()
		.append(toAddressee)
		.append(PLMTC5RptConstants.TC5MLI_NO_CONTENT_BODY)
		
		.append("\n")
		.append("Search Criteria \n")
		.append("--------------- \n")
		.append("SN#'s/Project's/IPS's/TC5 Number's: "+plmTC5MliRptData.getEnteredSNProjIPSTC5()+"\n\n")
		.append("Contract Description: "+plmTC5MliRptData.getEnteredConDesc()+"\n")
		.append("MLI: "+plmTC5MliRptData.getEnteredMLI()+"\n");
			
		mailNoDataBody.append(PLMConstants.LTTR_MAIL_SIGNATURE)
		.append(PLMConstants.LTTR_MAIL_FOOTER);
		LOG.info(mailNoDataBody.toString());
		
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		
		String filePathCSV = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("TC5_MLI_RPT_NM")  + "_" + uniqTime + ".csv";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("TC5_MLI_RPT_NM")  + "_" + uniqTime + ".zip";
		
		LOG.info("TC5 MLI Report semicolon CSV File Name "+filePathCSV);
		LOG.info("TC5 MLI Report semicolon CSV Zip File Name "+filePathZip);
		try {
			searchResultList=new ArrayList<PLMTC5MliRptData>();
			searchResultList = plmTC5RptService.getTC5MLIReport(plmTC5MliRptData);
				
			 if(!PLMUtils.isEmptyList(searchResultList)){
				 LOG.info("Returned result list of size:::"+searchResultList.size());
				
				 saveTC5MLICsvSmClnFile(plmTC5MliRptData,searchResultList,fileDir,filePathCSV);
				 
				 PLMUtils.generateZipFile(filePathCSV,filePathZip);
				 
				 PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
				 
				
				 searchResultList.clear();
				 
			 }else {				
				PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
				LOG.info("No data Mail sent...............");
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendTC5MLIMailSmCln: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendTC5MLIMailSmCln: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
		} finally {
			PLMUtils.deleteFiles(filePathCSV,filePathZip);
			
		}
		LOG.info("Mail sent successfully.....................");
		LOG.info("Exiting sendTC5MLIMailSmCln Method");
	}
	
	/**
	 * This method is used for saveTC5MLICsvSmClnFile
	 * 
	 * @param  partNameLcl, epeBaBomRptList,fileDir,filePathCSV
	 * @throws Exception
	 */
	public void saveTC5MLICsvSmClnFile(PLMTC5MliRptData plmTC5MliRptDataLcl,List<PLMTC5MliRptData> searchResultListLcl,
			String fileDir,String filePathCSV) throws Exception {
		LOG.info("Entering saveTC5MLICsvSmClnFile Method");

		FileOutputStream fileOut = null;
		PrintWriter pwriter =null;
		boolean createFileExist;
		try {
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathCSV);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
					fileOut = new FileOutputStream(filePathCSV);
					pwriter =  new PrintWriter( new FileWriter(filePathCSV));
					
					
						pwriter.write("SN#'s/Project's/IPS's/TC5 Number's");
						pwriter.write(";");
						pwriter.write(plmTC5MliRptDataLcl.getEnteredSNProjIPSTC5());
						pwriter.write("\n");
						pwriter.write("Contract Description");
						pwriter.write(";");
						pwriter.write(plmTC5MliRptDataLcl.getEnteredConDesc());
						pwriter.write("\n");
						pwriter.write("MLI");
						pwriter.write(";");
						pwriter.write(plmTC5MliRptDataLcl.getEnteredMLI());
						pwriter.write("\n");
					
					    pwriter.write("\n");
		 		
					    pwriter.write("MLI");
						pwriter.write(";");
						pwriter.write("Obj Name");
						pwriter.write(";");
						pwriter.write("Obj Rev");
						pwriter.write(";");
						pwriter.write("Qty");
						pwriter.write(";");
						pwriter.write("UoM/DocType");
						pwriter.write(";");
						pwriter.write("FR Description");
						pwriter.write(";");
						pwriter.write("EN Description");
						pwriter.write(";");
						pwriter.write("Sect");
						pwriter.write(";");
						pwriter.write("Item Name");
						pwriter.write(";");
						pwriter.write("Item Rev");
						pwriter.write(";");
						pwriter.write("SN");
						pwriter.write(";");
						pwriter.write("TM /TOT");
						pwriter.write(";");
						pwriter.write("Project/Affaire");
						pwriter.write(";");
						pwriter.write("Contract");
						pwriter.write(";,");
						pwriter.write("Contract Description");
			 			
			 			pwriter.write("\n");
			 			if(!PLMUtils.isEmptyList(searchResultListLcl)) {
			 				for(int i=0; i<searchResultListLcl.size(); i++) {
			 					PLMTC5MliRptData dataObj = (PLMTC5MliRptData)searchResultListLcl.get(i);
					   			
			 					if(dataObj.getOpMLI()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpMLI()+"\""));
						   		}
					   			   			
					   			pwriter.write(";");
					   			
					   			if(dataObj.getOpObjName()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpObjName()));
						   		}
					   			
								pwriter.write(";");
					   			
					   			if(dataObj.getOpObjRev()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpObjRev()+"\""));
						   		}
					   			
								pwriter.write(";");
					   			
					   			if(dataObj.getOpQty()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpQty()+"\""));
						   		}
					   			
								pwriter.write(";");
					   			
					   			if(dataObj.getOpUomDocType()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpUomDocType()));
						   		}
					   			
					   			pwriter.write(";");
					   			
					   			if(dataObj.getOpFRDesc()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpFRDesc()));
						   		}
					   			
								pwriter.write(";");
					   			
					   			if(dataObj.getOpENDesc()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpENDesc()));
						   		}
					   			
								pwriter.write(";");
					   			
					   			if(dataObj.getOpSect()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getOpSect()+"\""));
						   		}
					   			
								pwriter.write(";");
					   			
					   			if(dataObj.getOpItemName()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpItemName()));
						   		}
					   			
								pwriter.write(";");
					   			
					   			if(dataObj.getOpItemRev()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpItemRev()));
						   		}
					   			
								pwriter.write(";");
					   			
					   			if(dataObj.getOpSN()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpSN()));
						   		}
					   			
								pwriter.write(";");
					   			
					   			if(dataObj.getOpTmTot()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpTmTot()));
						   		}
					   			
								pwriter.write(";");
					   			
					   			if(dataObj.getOpProject()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpProject()));
						   		}
					   			
								pwriter.write(";");
					   			
					   			if(dataObj.getOpContract()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpContract()));
						   		}
					   			
								pwriter.write(";");
					   			
					   			if(dataObj.getOpConDesc()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getOpConDesc()));
						   		}
					   		pwriter.write("\n");
			 			} 
				}
			 }
			} catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@saveTC5MLICsvSmClnFile: ", e);
				throw e;
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveTC5MLICsvSmClnFile: ", e);
				throw e;
			}  finally {
				try {
					if (pwriter !=null) {
						pwriter.close();
					}
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@saveTC5MLICsvSmClnFile: ", e);
					throw e;
				}
			}
			LOG.info("Exiting saveTC5MLICsvSmClnFile Method");
		}
	
		
	 /**
	 * This method is used for recordsPerPageListner
	 * 
	 * @param event
	 * 
	 */
	public void recordsPerPageListner(ActionEvent event) {
		LOG.info("Entering recordsPerPageListner method");
		LOG.info("Action listner called.....--------------------------->"
				+ recordCounts);
		if (recordCounts == 50) {
			LOG.info("50");
			recordCounts = 50;
		} else if (recordCounts == 100) {
			LOG.info("100");
			recordCounts = 100;
		} else if (recordCounts == 200) {
			LOG.info("200");
			recordCounts = 200;
		}

		LOG.info("final value.....--------------------------->" + recordCounts);
	}
	//Added for TC5 FULL BOM Report
	/**
	 * This method is used for loadTC5Relation page
	 * 
	 * @return String
	 */
	public String loadTC5FullBoMPage() {
		LOG.info("Entering loadTC5FullBoMPage Method");
		
		try {
			commonMB.insertCannedRptRecordHitInfo("TC5 Full BOM Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		resetFullBoMPage();
		LOG.info("Exiting loadTC5FullBoMPage Method");
		return "tc5FullBOMSearch";
	}
	
	public void resetFullBoMPage(){
		alertMessage="";
		tc5CodeFullBom="";
		bomLevel="";
		allBomLvlFlg=false;
		refDocLevel="";
		allRefDocLvlFlg=false;
		includeDefFlag=false;
	}
	
	/**
	 * This method is used for Validating 
	 * 
	 * @return String
	 */
	public String validateTC5FullBOMData() {		
		alertMessage ="";
		int bomLvl=0;
		int refDocLvl=0;
		int minLvlLmit =Integer.parseInt(resourceBundle.getString(PLMTC5RptConstants.MIN_LVL_LIMIT));
		int maxLvlLmit=Integer.parseInt(resourceBundle.getString(PLMTC5RptConstants.MAX_LVL_LIMIT));
		boolean inValidBomLvl=false;
		boolean inValidRefLvl=false;
		String tempBomLvl;
		String tempRefLvl;
		LOG.info("Entering validateTC5FullBOMData Method");
		 if(allBomLvlFlg){
			 bomLevel="";
		 }

		 if(allRefDocLvlFlg){
			 refDocLevel="";
		 }
		 
		  if (PLMUtils.isEmpty(tc5CodeFullBom)){
			alertMessage = PLMTC5RptConstants.TC5_FULLBOM_INPUT;
		 }else if(!PLMTC5RptUtils.checkForSpecialChrsFullBOM(tc5CodeFullBom)){
			alertMessage = PLMTC5RptConstants.TC5_FULLBOM_SPLCHAR;
		 }else if(PLMUtils.isEmpty(bomLevel) && !allBomLvlFlg){
			alertMessage = PLMTC5RptConstants.TC5_FULLBOM_BOM_LVL;
		 }else if(!PLMUtils.isEmpty(bomLevel)){
			 for (int i=0; i<bomLevel.length(); i++) {
					tempBomLvl = "" + bomLevel.substring(i, i+1);
					if (PLMTC5RptConstants.NUMBER_VALIDATION.indexOf(tempBomLvl)== -1){
						inValidBomLvl=true;
						alertMessage =PLMTC5RptConstants.TC5_FULLBOM_BOM_LVL_VALID;
					 }
			 }
			 if(!inValidBomLvl){
				 bomLvl=Integer.parseInt(bomLevel);
				 if(bomLvl > maxLvlLmit|| bomLvl < minLvlLmit){  
					alertMessage = PLMTC5RptConstants.TC5_FULLBOM_BOM_LVL_EXCEED;
		          }
			 }
		 }
		 if(PLMUtils.isEmpty(alertMessage) && !PLMUtils.isEmpty(refDocLevel)){
			 for (int j=0; j<refDocLevel.length(); j++) {
				 tempRefLvl = "" + refDocLevel.substring(j, j+1);
					if (PLMTC5RptConstants.NUMBER_VALIDATION.indexOf(tempRefLvl)== -1){
						inValidRefLvl=true;
						alertMessage =PLMTC5RptConstants.TC5_FULLBOM_DOC_LVL_VALID;
					 }
			 }
			 if(!inValidRefLvl){
				 refDocLvl=Integer.parseInt(refDocLevel);
				 if(refDocLvl > maxLvlLmit){  
					alertMessage = PLMTC5RptConstants.TC5_FULLBOM_DOC_LVL_EXCEED;
		          }
			 }
		 }
		
		LOG.info("Exiting validateTC5FullBOMData Method");
		return alertMessage;
	}
	
	 /**
	 * This method is used for sendTC5FullBOMCommaEmail with CSV Comma
	 * @throws PWiException 
	 * 
	 */
	public void sendTC5FullBOMCommaEmail() throws PWiException{
	 alertMessage=validateTC5FullBOMData();
	 
	// Get user details for sending mail. Need before taskexecuter as context will be null while excuting the thread
	userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
	 
	if (PLMUtils.isEmpty(alertMessage)){
		alertMessage = PLMTC5RptConstants.TC5FULLBOM_MAIL_RERORT_ALERT;
		taskExecutor.execute(new MailThreadTC5FullBOMComma());
	}
  }
		
	/**
	 * Background Process Thread
	 */
	private class MailThreadTC5FullBOMComma implements Runnable {
		public MailThreadTC5FullBOMComma(){}
		public void run() {
			try{
				sendTC5FullBOMCommaRpt();
			}catch (Exception exception) {	
				LOG.log(Level.ERROR, "Exception@run() of sendTC5FullBOMCommaRpt: ", exception);
			}
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return String
	 */
	public void sendTC5FullBOMCommaRpt() {
		LOG.info("Entering sendTC5FullBOMCommaRpt Method");
		String tc5CodeFullBomLcl =tc5CodeFullBom;
		String bomLevelLcl =bomLevel;
		boolean allBomLvlFlgLcl =allBomLvlFlg;
		String refDocLevelLcl =refDocLevel;
		boolean allRefDocLvlFlgLcl =allRefDocLvlFlg;
		boolean includeDefFlagLcl =includeDefFlag;
		String from = PLMTC5RptConstants.TC5_CODE_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = "";
		
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathCSV ="";
		String filePathZip ="";

		try {
			List<PLMTC5FullBomRptData> tc5FullBOMListLcl = plmTC5RptService.getTC5FullBomReport(tc5CodeFullBomLcl,bomLevelLcl,allBomLvlFlgLcl,
					refDocLevelLcl,allRefDocLvlFlgLcl,includeDefFlagLcl);
		
			 if(!PLMUtils.isEmptyList(tc5FullBOMListLcl)){
				 
				  StringBuffer mailBody = new StringBuffer().append(toAddressee)
				  .append(PLMTC5RptConstants.TC5_CODE_FULL_BOM_MAIL_CSV)
				  .append(tc5CodeFullBomLcl)
				  .append(".")
				  .append(PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE)
				  .append(PLMTC5RptConstants.TC5_CODE_MAIL_FOOTER);
				  subject = PLMTC5RptConstants.TC5_CODE_FULLBOM_MAIL_SUBJECT + tc5CodeFullBomLcl;
				  final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
				  Date uniqDate = new Date();
				  String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
				  String fileNameCode = tc5CodeFullBomLcl.replace("/", "-").replace("\"","-");
				  filePathCSV = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("TC5_FULL_BOM_RPT_NM") + "_" +fileNameCode+ "_" + uniqTime + ".csv";
				  filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("TC5_FULL_BOM_RPT_NM") + "_" +fileNameCode+ "_" + uniqTime + ".zip";
				  LOG.info("File Path CSV FullBOMCommaRpt --> "+filePathCSV);
				  LOG.info("File Path filePathZip FullBOMCommaRpt --> "+filePathZip);
				  saveTC5FullBOMRptCommaCSV(tc5FullBOMListLcl,fileDir,filePathCSV);
				  PLMUtils.generateZipFile(filePathCSV,filePathZip);
				  PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
			 }else {
					StringBuffer mailNoDataBody = new StringBuffer()
					.append(toAddressee)
					.append(PLMTC5RptConstants.TC5_CODE_NO_RECORD_FOUND)
					.append(tc5CodeFullBomLcl)
					.append(".")
					.append(PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE)
					.append(PLMTC5RptConstants.TC5_CODE_MAIL_FOOTER);
					subject = PLMTC5RptConstants.TC5_CODE_FULLBOM_MAIL_SUBJECT + tc5CodeFullBomLcl;
					PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
					LOG.info("No data Mail sent");
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendTC5FullBOMCommaRpt: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendTC5FullBOMCommaRpt: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE);
		} finally {
			PLMUtils.deleteFiles(filePathCSV,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendTC5FullBOMCommaRpt Method");
	}
	
	/**
	 * This method is used for saveTC5FullBOMRptCommaCSV
	 * 
	 * @param   tc5FullBOMListLcl,fileDir,filePathCSV
	 * @throws Exception
	 */
	public void saveTC5FullBOMRptCommaCSV(List<PLMTC5FullBomRptData> tc5FullBOMListLcl,
			String fileDir,String filePathCSV) throws Exception {
		LOG.info("Entering saveTC5FullBOMRptCommaCSV Method");
		FileOutputStream fileOut = null;
		PrintWriter pwriter =null;
		boolean createFileExist;
		try {
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathCSV);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
					fileOut = new FileOutputStream(filePathCSV);
					pwriter =  new PrintWriter( new FileWriter(filePathCSV));
					   
					pwriter.write("LvlBOM#DOC");
		 			pwriter.write(",");
		 			pwriter.write("ID / Repere");
		 			pwriter.write(",");
		 			pwriter.write("Qty");
		 			pwriter.write(",");
		 			pwriter.write("UoM / DosType");
		 			pwriter.write(",");
		 			pwriter.write("Obj Name");
		 			pwriter.write(",");
		  			pwriter.write("Obj Rev");
		 			pwriter.write(",");
		 			pwriter.write("FR Description");
		 			pwriter.write(",");
		 			pwriter.write("EN Description");
		 			pwriter.write(",");
		 		    pwriter.write("Structure");
		 			pwriter.write("\n");
		 			
			 			if(!PLMUtils.isEmptyList(tc5FullBOMListLcl)) {
					   		for(int i=0; i<tc5FullBOMListLcl.size(); i++) {
					   			PLMTC5FullBomRptData dataObj = (PLMTC5FullBomRptData)tc5FullBOMListLcl.get(i);
					   			
					  			if(dataObj.getLvlBomDoc()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getLvlBomDoc()));
						   			}
					   			pwriter.write(",");
					   			if(dataObj.getIdRepere()!= null){
									pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getIdRepere()+"\""));
								}
								pwriter.write(",");
								if(dataObj.getQty()!= null){
									pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getQty()+"\""));
								}
								pwriter.write(",");
								if(dataObj.getUomDosType()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getUomDosType()));
								}
								pwriter.write(",");
								if(dataObj.getObjName()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getObjName()));
								}
								pwriter.write(",");
					   			if(dataObj.getObjRev()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getObjRev()+"\""));
						   		}
					   			pwriter.write(",");
					   			if(dataObj.getFrDescription()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getFrDescription()));
						   		}
					   			pwriter.write(",");
					   			if(dataObj.getEnDescription()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEnDescription()));
								}
								pwriter.write(",");
					   			
								if(dataObj.getStructure()!= null){
									pwriter.write(PLMUtils.convertToCsvValue(dataObj.getStructure()));
								}
					   			pwriter.write("\n");
					   			
					   		}//END OF FOR LOOP FOR TC5 Full BOM
					   		
			 			} // END OF IF CONDITION FOR TC5 Full BOM LIST 	
			 			
				}//END OF IF FOR FILE NAME EXIST
				
		} catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@saveTC5FullBOMRptCommaCSV: ", e);
				throw e;
		  } catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveTC5FullBOMRptCommaCSV: ", e);
				throw e;
		    }  finally {
				try {
					if (pwriter !=null) {
						pwriter.close();
					}
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@saveTC5FullBOMRptCommaCSV: ", e);
					throw e;
				}
			   }
			LOG.info("Exiting saveTC5FullBOMRptCommaCSV Method");
		}
	
	 /**
	 * This method is used for sendTC5FullBOMCommaEmail with CSV semicoloan
	 * @throws PWiException 
	 * 
	 */
	public void sendTC5FullBOMSmConlnEmail() throws PWiException{
	 alertMessage=validateTC5FullBOMData();
	 
	// Get user details for sending mail. Need before taskexecuter as context will be null while excuting the thread
	 userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
	 
	if (PLMUtils.isEmpty(alertMessage)){
		alertMessage = PLMTC5RptConstants.TC5FULLBOM_MAIL_RERORT_ALERT;
		taskExecutor.execute(new MailThreadTC5FullBOMSmCln());
	}
  }
		
	/**
	 * Background Process Thread
	 */
	private class MailThreadTC5FullBOMSmCln implements Runnable {
		public MailThreadTC5FullBOMSmCln(){}
		public void run() {
			try{
				sendTC5FullBOMSmClnRpt();
			}catch (Exception exception) {	
				LOG.log(Level.ERROR, "Exception@run() of MailThreadTC5FullBOMSmCln: ", exception);
			}
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return String
	 */
	public void sendTC5FullBOMSmClnRpt() {
		LOG.info("Entering sendTC5FullBOMSmClnRpt Method");
		String tc5CodeFullBomLcl =tc5CodeFullBom;
		String bomLevelLcl =bomLevel;
		boolean allBomLvlFlgLcl =allBomLvlFlg;
		String refDocLevelLcl =refDocLevel;
		boolean allRefDocLvlFlgLcl =allRefDocLvlFlg;
		boolean includeDefFlagLcl =includeDefFlag;
		String from = PLMTC5RptConstants.TC5_CODE_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = "";
		
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathCSV ="";
		String filePathZip ="";

		try {
			List<PLMTC5FullBomRptData> tc5FullBOMListLcl = plmTC5RptService.getTC5FullBomReport(tc5CodeFullBomLcl,bomLevelLcl,allBomLvlFlgLcl,
					refDocLevelLcl,allRefDocLvlFlgLcl,includeDefFlagLcl);
		
			 if(!PLMUtils.isEmptyList(tc5FullBOMListLcl)){
				 
				  StringBuffer mailBody = new StringBuffer().append(toAddressee)
				  .append(PLMTC5RptConstants.TC5_CODE_FULL_BOM_MAIL_SMCLN)
				  .append(tc5CodeFullBomLcl)
				  .append(".")
				  .append(PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE)
				  .append(PLMTC5RptConstants.TC5_CODE_MAIL_FOOTER);
				  subject = PLMTC5RptConstants.TC5_CODE_FULLBOM_MAIL_SUBJECT + tc5CodeFullBomLcl;
				  final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
				  Date uniqDate = new Date();
				  String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
				  String fileNameCode = tc5CodeFullBomLcl.replace("/", "-").replace("\"","-");
				  filePathCSV = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("TC5_FULL_BOM_RPT_NM") + "_" +fileNameCode+ "_" + uniqTime + ".csv";
				  filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("TC5_FULL_BOM_RPT_NM") + "_" +fileNameCode+ "_" + uniqTime + ".zip";
 				  LOG.info("File Path CSV FullBOMSmClnRpt -- > "+filePathCSV);
				  LOG.info("File Path filePathZip FullBOMSmClnRpt -- > "+filePathZip);
				  
				  saveTC5FullBOMRptSemiCln(tc5FullBOMListLcl,fileDir,filePathCSV);
				  PLMUtils.generateZipFile(filePathCSV,filePathZip);
				  PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
			 }else {
					StringBuffer mailNoDataBody = new StringBuffer()
					.append(toAddressee)
					.append(PLMTC5RptConstants.TC5_CODE_NO_RECORD_FOUND)
					.append(tc5CodeFullBomLcl)
					.append(".")
					.append(PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE)
					.append(PLMTC5RptConstants.TC5_CODE_MAIL_FOOTER);
					subject = PLMTC5RptConstants.TC5_CODE_FULLBOM_MAIL_SUBJECT + tc5CodeFullBomLcl;
					PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
					LOG.info("No data Mail sent");
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendTC5FullBOMCommaRpt: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendTC5FullBOMCommaRpt: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE);
		} finally {
			PLMUtils.deleteFiles(filePathCSV,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendTC5FullBOMCommaRpt Method");
	}
	
	/**
	 * This method is used for saveTC5FullBOMRptSemiCln
	 * 
	 * @param   tc5FullBOMListLcl,fileDir,filePathCSV
	 * @throws Exception
	 */
	public void saveTC5FullBOMRptSemiCln(List<PLMTC5FullBomRptData> tc5FullBOMListLcl,
			String fileDir,String filePathCSV) throws Exception {
		LOG.info("Entering saveTC5FullBOMRptSemiCln Method");
		FileOutputStream fileOut = null;
		PrintWriter pwriter =null;
		boolean createFileExist;
		try {
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathCSV);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
					fileOut = new FileOutputStream(filePathCSV);
					pwriter =  new PrintWriter( new FileWriter(filePathCSV));
					   
					pwriter.write("LvlBOM#DOC");
		 			pwriter.write(";");
		 			pwriter.write("ID / Repere");
		 			pwriter.write(";");
		 			pwriter.write("Qty");
		 			pwriter.write(";");
		 			pwriter.write("UoM / DosType");
		 			pwriter.write(";");
		 			pwriter.write("Obj Name");
		 			pwriter.write(";");
		  			pwriter.write("Obj Rev");
		 			pwriter.write(";");
		 			pwriter.write("FR Description");
		 			pwriter.write(";");
		 			pwriter.write("EN Description");
		 			pwriter.write(";");
		 		    pwriter.write("Structure");
		 			pwriter.write("\n");
		 			
			 			if(!PLMUtils.isEmptyList(tc5FullBOMListLcl)) {
					   		for(int i=0; i<tc5FullBOMListLcl.size(); i++) {
					   			PLMTC5FullBomRptData dataObj = (PLMTC5FullBomRptData)tc5FullBOMListLcl.get(i);
					   			
					  			if(dataObj.getLvlBomDoc()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getLvlBomDoc()));
						   			}
					   			pwriter.write(";");
					   			if(dataObj.getIdRepere()!= null){
									pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getIdRepere()+"\""));
								}
								pwriter.write(";");
								if(dataObj.getQty()!= null){
									pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getQty()+"\""));
								}
								pwriter.write(";");
								if(dataObj.getUomDosType()!= null){
									pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getUomDosType()));
								}
								pwriter.write(";");
								if(dataObj.getObjName()!= null){
									pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getObjName()));
								}
								pwriter.write(";");
					   			if(dataObj.getObjRev()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getObjRev()+"\""));
						   		}
					   			pwriter.write(";");
					   			if(dataObj.getFrDescription()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getFrDescription()));
						   		}
					   			pwriter.write(";");
					   			if(dataObj.getEnDescription()!= null){
									pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getEnDescription()));
								}
								pwriter.write(";");
					   			
								if(dataObj.getStructure()!= null){
									pwriter.write(PLMUtils.convertToCsvValueNew(dataObj.getStructure()));
								}
					   			pwriter.write("\n");
					   			
					   		}//END OF FOR LOOP FOR TC5 Full BOM
					   		
			 			} // END OF IF CONDITION FOR TC5 Full BOM LIST 	
			 			
				}//END OF IF FOR FILE NAME EXIST
				
		} catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@saveTC5FullBOMRptSemiCln: ", e);
				throw e;
		  } catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveTC5FullBOMRptSemiCln: ", e);
				throw e;
		    }  finally {
				try {
					if (pwriter !=null) {
						pwriter.close();
					}
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@saveTC5FullBOMRptSemiCln: ", e);
					throw e;
				}
			   }
			LOG.info("Exiting saveTC5FullBOMRptSemiCln Method");
		}

	
	/**
	 * This method is used for loadTC5Relation page
	 * 
	 * @return String
	 */
	public String loadTC5WhereUsed() {
		LOG.info("Entering loadTC5WhereUsed Method");
		
		try {
			commonMB.insertCannedRptRecordHitInfo("TC5 Where Used - Top Level Implosion");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		partDocNum = "";
		alertMessage = "";
		LOG.info("Exiting loadTC5WhereUsed Method");
		return "tc5WhereUsedSearch";
	}
	/**
	 * This method is used for resetTopLvlImplosionData
	 *
	 */
	public void resetWhrUsdData(){
		partDocNum = "";
		alertMessage = "";
	}
	/**
	 * This method is used for Validating 
	 * 
	 * @return String
	 */
	public String validateTC5WhUsedImplosionData() throws PLMCommonException{		
		alertMessage ="";
		LOG.info("Entering validateTC5WhUsedImplosionData Method");
		 if (PLMUtils.isEmpty(partDocNum)){
			alertMessage = PLMTC5RptConstants.TC5_WHUSED_PARTDOC;
		 }else if(!PLMTC5RptUtils.checkForSpecialCharsPartDoc(partDocNum)){
			alertMessage = PLMTC5RptConstants.TC5_WHUSED_SPLCHAR;
		 }
		 
		 /*if (PLMUtils.isEmpty(alertMessage)){
				partDocType=plmTC5RptService.getPartDocType(partDocNum);
		 }
		 LOG.info("Type of Entered value is ========="+partDocType);
		 
		 if(partDocType.equals(PLMTC5RptConstants.TC5_WHUSED_INVALID)){
			 alertMessage = PLMTC5RptConstants.TC5_WHUSED_INVALIDPARTDOC;
		 }*/
		 
		LOG.info("Exiting validateTC5WhUsedImplosionData Method");
		return alertMessage;
	}
	
	 /**
	 * This method is used for sendTC5WhUsedImplosionEmail
	 * @throws PWiException 
	 * 
	 */
	public void sendTC5WhUsedImplosionEmail() throws PLMCommonException, PWiException{
		 alertMessage="";
		 //partDocNum="";
		 //partDocNum= plmWhereUsedMB.getTliPartNumber();
		 LOG.info("Entered Part/Doc Num as received in TC5 MB is========="+partDocNum);
		 
		alertMessage=validateTC5WhUsedImplosionData();
		
		// Get user details for sending mail. Need before taskexecuter as context will be null while excuting the thread
		userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		
		LOG.info(alertMessage);
		if (PLMUtils.isEmpty(alertMessage)){
			LOG.info("No Validation Errors Exist. Proceeding Further.....");
			alertMessage = PLMTC5RptConstants.TC5_WHUSED_MAIL_RERORT;
			taskExecutor.execute(new MailThreadTC5WhUsed());
		}
	}
	
	
	/**
	 * Background Process Thread
	 */
	private class MailThreadTC5WhUsed implements Runnable {
		public MailThreadTC5WhUsed(){}
		public void run() {
			try{
			 sendTC5WhUsedReport();
			}catch (Exception exception) {	
				LOG.log(Level.ERROR, "Exception@run() of sendTC5WhUsedReport: ", exception);
			}
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return String
	 */
	public void sendTC5WhUsedReport() {
		LOG.info("Entering sendTC5WhUsedReport Method");
		String partDocNumLcl = partDocNum;
		//String partDocTypeLcl = partDocType;
		
		String from = PLMTC5RptConstants.TC5_CODE_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = "";
		
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathCSV ="";
		String filePathZip ="";

		try {
			//tc5WhUsedListLcl = plmTC5RptService.getTC5WhUsedRpt(partDocNumLcl,partDocTypeLcl);
			List<PLMTC5WhUsedRptData> tc5WhUsedListLcl = plmTC5RptService.getTC5WhUsedRpt(partDocNumLcl);
			LOG.info("Fetched Data List of size======="+tc5WhUsedListLcl.size());
		
			 if(!PLMUtils.isEmptyList(tc5WhUsedListLcl)){
				 
				  StringBuffer mailBody = new StringBuffer().append(toAddressee)
				  .append(PLMTC5RptConstants.TC5_WHUSED_MAIL_CONTENT)
				  .append(partDocNumLcl)
				  .append(".")
				  .append(PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE)
				  .append(PLMTC5RptConstants.TC5_CODE_MAIL_FOOTER);
				  subject = PLMTC5RptConstants.TC5_WHUSED_MAIL_SUBJECT + partDocNumLcl;
				  final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
				  Date uniqDate = new Date();
				  String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
				  filePathCSV = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("TC5_WHUSED_RPT_NM") + "_" + uniqTime + ".csv";
				  filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("TC5_WHUSED_RPT_NM") + "_" + uniqTime + ".zip";
				  LOG.info("TC5 WhUsed Report CSV File Name "+filePathCSV);
				  LOG.info("TC5 WhUsed Report Zip File Name "+filePathZip);
				  saveTC5WhUsedRptCSV(partDocNumLcl,tc5WhUsedListLcl,fileDir,filePathCSV);
				  PLMUtils.generateZipFile(filePathCSV,filePathZip);
				  PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
				  LOG.info("Mail with attachment sent.....");
			 }else {
					StringBuffer mailNoDataBody = new StringBuffer()
					.append(toAddressee)
					.append(PLMTC5RptConstants.TC5_WHUSED_NO_CONTENT_BODY)
					.append(partDocNumLcl)
					.append(".")
					.append(PLMTC5RptConstants.TC5_WHUSED_NO_CONTENT_BODY2)
					.append(PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE)
					.append(PLMTC5RptConstants.TC5_CODE_MAIL_FOOTER);
					subject = PLMTC5RptConstants.TC5_WHUSED_MAIL_SUBJECT + partDocNumLcl;
					PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
					LOG.info("No data Mail sent.....");
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendTC5WhUsedReport: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendTC5WhUsedReport: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE);
		} finally {
			PLMUtils.deleteFiles(filePathCSV,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendTC5WhUsedReport Method");
	}
	
	public void saveTC5WhUsedRptCSV(String partDocNumLcl,List<PLMTC5WhUsedRptData> tc5WhUsedListLcl,
			String fileDir,String filePathCSV) throws Exception {
		LOG.info("Entering saveTC5WhUsedRptCSV Method");

		FileOutputStream fileOut = null;
		PrintWriter pwriter =null;
		boolean createFileExist;
		try {
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathCSV);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
					fileOut = new FileOutputStream(filePathCSV);
					pwriter =  new PrintWriter( new FileWriter(filePathCSV));
					
					
						pwriter.write("Part Number / Doc Number : ");
						pwriter.write(",");
						pwriter.write(partDocNumLcl);
						pwriter.write("\n");
					
					    pwriter.write("\n");
		 		
					    pwriter.write("Top Lvl Parent");
						pwriter.write(",");
						pwriter.write("Top Lvl Rev");
						pwriter.write(",");
						pwriter.write("Top Lvl EN Description");
						pwriter.write(",");
						pwriter.write("Top Lvl FR Description");
						pwriter.write(",");
						pwriter.write("Project");
						pwriter.write(",");
						pwriter.write("IPS");
						pwriter.write(",");
						pwriter.write("Turbine");
						pwriter.write(",");
						pwriter.write("Serial#");
						pwriter.write(",");
						pwriter.write("MLI");
						pwriter.write(",");
						pwriter.write("Immediate Parent");
						pwriter.write(",");
						pwriter.write("Immediate Rev");
						pwriter.write(",");
						pwriter.write("Immediate EN Description");
						pwriter.write(",");
						pwriter.write("Immediate FR Description");
						pwriter.write(",");
						pwriter.write("Level");
						pwriter.write(",");
						pwriter.write("DFS Order");
			 			
			 			pwriter.write("\n");
			 			if(!PLMUtils.isEmptyList(tc5WhUsedListLcl)) {
			 				for(int i=0; i<tc5WhUsedListLcl.size(); i++) {
			 					PLMTC5WhUsedRptData dataObj = (PLMTC5WhUsedRptData)tc5WhUsedListLcl.get(i);
					   			
			 					if(dataObj.getTopPartDoc()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getTopPartDoc()+"\""));
						   		}
					   			   			
					   			pwriter.write(",");
					   			
					   			if(dataObj.getTopPartDocRev()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getTopPartDocRev()+"\""));
						   		}
					   			
					   			pwriter.write(",");
					   			
					   			if(dataObj.getDescEn()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getDescEn()+"\""));
						   		}
					   			
					   			pwriter.write(",");
					   			
					   			if(dataObj.getDescFr()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getDescFr()+"\""));
						   		}   								   			
					   			
					   			pwriter.write(",");
					   			
					   			if(dataObj.getPrj()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getPrj()+"\""));
						   		}
					   			
					   			pwriter.write(",");
					   			
					   			if(dataObj.getContract()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getContract()+"\""));
						   		}
					   			
					   			pwriter.write(",");
					   			
					   			if(dataObj.getTurbine()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getTurbine()+"\""));
						   		}
					   			
					   			pwriter.write(",");
					   			
					   			if(dataObj.getSn()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getSn()+"\""));
						   		}
					   			
					   			pwriter.write(",");
					   			
					   			if(dataObj.getMli()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getMli()+"\""));
						   		}
					   			
					   			pwriter.write(",");
					   			
					   			if(dataObj.getImdtPrntNm()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getImdtPrntNm()+"\""));
						   		}
					   			
					   			pwriter.write(",");
					   			
					   			if(dataObj.getImdtPrntRev()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getImdtPrntRev()+"\""));
						   		}
					   			
					   			pwriter.write(",");
					   			
					   			if(dataObj.getImdtPrntEn()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getImdtPrntEn()+"\""));
						   		}
					   			
					   			pwriter.write(",");
					   			
					   			if(dataObj.getImdtPrntFr()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getImdtPrntFr()+"\""));
						   		}

					   						   			
					   			pwriter.write(",");
					   			
					   			if(dataObj.getLevel()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getLevel()+"\""));
						   		}
					   			
					   			pwriter.write(",");
					   			
					   			if(dataObj.getDfsOrder()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getDfsOrder()+"\""));
						   		}

					   			
		
				   			
					   		pwriter.write("\n");
			 			} 
					  
				}
			}
				
			} catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@saveTC5WhUsedRptCSV: ", e);
				throw e;
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveTC5WhUsedRptCSV: ", e);
				throw e;
			}  finally {
				try {
					if (pwriter !=null) {
						pwriter.close();
					}
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@saveTC5WhUsedRptCSV: ", e);
					throw e;
				}
			}
			LOG.info("Exiting saveTC5WhUsedRptCSV Method");
		}
	
	/**
	 * This method is used for sendTC5WhUsedImplosionEmail
	 * @throws PWiException 
	 * 
	 */
	public void sendTC5WhUsedImplosionEmailSemCol() throws PLMCommonException, PWiException{
		alertMessage="";
		//partDocNum="";
		//partDocNum= plmWhereUsedMB.getTliPartNumber();
	 	LOG.info("Entered Part/Doc Num as received in TC5 MB is========="+partDocNum);
	 	alertMessage=validateTC5WhUsedImplosionData();
	 	
	 // Get user details for sending mail. Need before taskexecuter as context will be null while excuting the thread
	 	userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
	 	
		LOG.info(alertMessage);
		if (PLMUtils.isEmpty(alertMessage)){
			LOG.info("No Validation Errors Exist. Proceeding Further.....");
			alertMessage = PLMTC5RptConstants.TC5_WHUSED_MAIL_RERORT;
			taskExecutor.execute(new MailThreadTC5WhUsedSemCol());
		}
   }
	
	
	/**
	 * Background Process Thread
	 */
	private class MailThreadTC5WhUsedSemCol implements Runnable {
		public MailThreadTC5WhUsedSemCol(){}
		public void run() {
			try{
			 sendTC5WhUsedReportSemCol();
			}catch (Exception exception) {	
				LOG.log(Level.ERROR, "Exception@run() of sendTC5WhUsedReport: ", exception);
			}
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return String
	 */
	public void sendTC5WhUsedReportSemCol() {
		LOG.info("Entering sendTC5WhUsedReportSemCol Method");
		String partDocNumLcl = partDocNum;
		//String partDocTypeLcl = partDocType;
		
		String from = PLMTC5RptConstants.TC5_CODE_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = "";
		
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathCSV ="";
		String filePathZip ="";

		try {
			//tc5WhUsedListLcl = plmTC5RptService.getTC5WhUsedRpt(partDocNumLcl,partDocTypeLcl);
			List<PLMTC5WhUsedRptData> tc5WhUsedListLcl = plmTC5RptService.getTC5WhUsedRpt(partDocNumLcl);
			LOG.info("Fetched Data List of size======="+tc5WhUsedListLcl.size());
		
			 if(!PLMUtils.isEmptyList(tc5WhUsedListLcl)){
				 
				  StringBuffer mailBody = new StringBuffer().append(toAddressee)
				  .append(PLMTC5RptConstants.TC5_WHUSED_MAIL_CONTENT)
				  .append(partDocNumLcl)
				  .append(".")
				  .append(PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE)
				  .append(PLMTC5RptConstants.TC5_CODE_MAIL_FOOTER);
				  subject = PLMTC5RptConstants.TC5_WHUSED_MAIL_SUBJECT + partDocNumLcl;
				  final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
				  Date uniqDate = new Date();
				  String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
				  filePathCSV = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("TC5_WHUSED_RPT_NM") + "_" + uniqTime + ".csv";
				  filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("TC5_WHUSED_RPT_NM") + "_" + uniqTime + ".zip";
				  LOG.info("TC5 WhUsed Report CSV File Name "+filePathCSV);
				  LOG.info("TC5 WhUsed Report Zip File Name "+filePathZip);
				  saveTC5WhUsedRptCSVSemCol(partDocNumLcl,tc5WhUsedListLcl,fileDir,filePathCSV);
				  PLMUtils.generateZipFile(filePathCSV,filePathZip);
				  PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
				  LOG.info("Mail with attachment sent.....");
			 }else {
					StringBuffer mailNoDataBody = new StringBuffer()
					.append(toAddressee)
					.append(PLMTC5RptConstants.TC5_WHUSED_NO_CONTENT_BODY)
					.append(partDocNumLcl)
					.append(".")
					.append(PLMTC5RptConstants.TC5_WHUSED_NO_CONTENT_BODY2)
					.append(PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE)
					.append(PLMTC5RptConstants.TC5_CODE_MAIL_FOOTER);
					subject = PLMTC5RptConstants.TC5_WHUSED_MAIL_SUBJECT + partDocNumLcl;
					PLMUtils.sendMail(from, to, subject, mailNoDataBody.toString());
					LOG.info("No data Mail sent.....");
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendTC5WhUsedReportSemCol: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendTC5WhUsedReportSemCol: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMTC5RptConstants.TC5_CODE_MAIL_SIGNATURE);
		} finally {
			PLMUtils.deleteFiles(filePathCSV,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendTC5WhUsedReportSemCol Method");
	}
	
	public void saveTC5WhUsedRptCSVSemCol(String partDocNumLcl,List<PLMTC5WhUsedRptData> tc5WhUsedListLcl,
			String fileDir,String filePathCSV) throws Exception {
		LOG.info("Entering saveTC5WhUsedRptCSVSemCol Method");

		FileOutputStream fileOut = null;
		PrintWriter pwriter =null;
		boolean createFileExist;
		try {
			/*File file = new File(fileDir);
			boolean dirExists = file.exists();
			if (!dirExists) {	
				file.mkdir();
			}*/
			File fileName = new File(filePathCSV);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
					fileOut = new FileOutputStream(filePathCSV);
					pwriter =  new PrintWriter( new FileWriter(filePathCSV));
					
					
						pwriter.write("Part Number / Doc Number : ");
						pwriter.write(";");
						pwriter.write(partDocNumLcl);
						pwriter.write("\n");
					
					    pwriter.write("\n");
		 		
					    pwriter.write("Top Lvl Parent");
						pwriter.write(";");
						pwriter.write("Top Lvl Rev");
						pwriter.write(";");
						pwriter.write("Top Lvl EN Description");
						pwriter.write(";");
						pwriter.write("Top Lvl FR Description");
						pwriter.write(";");
						pwriter.write("Project");
						pwriter.write(";");
						pwriter.write("IPS");
						pwriter.write(";");
						pwriter.write("Turbine");
						pwriter.write(";");
						pwriter.write("Serial#");
						pwriter.write(";");
						pwriter.write("MLI");
						pwriter.write(";");
						pwriter.write("Immediate Parent");
						pwriter.write(";");
						pwriter.write("Immediate Rev");
						pwriter.write(";");
						pwriter.write("Immediate EN Description");
						pwriter.write(";");
						pwriter.write("Immediate FR Description");
						pwriter.write(";");
						pwriter.write("Level");
						pwriter.write(";");
						pwriter.write("DFS Order");
			 			
			 			pwriter.write("\n");
			 			if(!PLMUtils.isEmptyList(tc5WhUsedListLcl)) {
			 				for(int i=0; i<tc5WhUsedListLcl.size(); i++) {
			 					PLMTC5WhUsedRptData dataObj = (PLMTC5WhUsedRptData)tc5WhUsedListLcl.get(i);
					   			
			 					if(dataObj.getTopPartDoc()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getTopPartDoc()+"\""));
						   		}
					   			   			
					   			pwriter.write(";");
					   			
					   			if(dataObj.getTopPartDocRev()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getTopPartDocRev()+"\""));
						   		}
					   			
					   			pwriter.write(";");
					   			
					   			if(dataObj.getDescEn()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getDescEn()+"\""));
						   		}
					   			
					   			pwriter.write(";");
					   			
					   			if(dataObj.getDescFr()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getDescFr()+"\""));
						   		}   								   			
					   			
					   			pwriter.write(";");
					   			
					   			if(dataObj.getPrj()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getPrj()+"\""));
						   		}
					   			
					   			pwriter.write(";");
					   			
					   			if(dataObj.getContract()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getContract()+"\""));
						   		}
					   			
					   			pwriter.write(";");
					   			
					   			if(dataObj.getTurbine()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getTurbine()+"\""));
						   		}
					   			
					   			pwriter.write(";");
					   			
					   			if(dataObj.getSn()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getSn()+"\""));
						   		}
					   			
					   			pwriter.write(";");
					   			
					   			if(dataObj.getMli()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getMli()+"\""));
						   		}
					   			
					   			pwriter.write(";");
					   			
					   			if(dataObj.getImdtPrntNm()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getImdtPrntNm()+"\""));
						   		}
					   			
					   			pwriter.write(";");
					   			
					   			if(dataObj.getImdtPrntRev()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getImdtPrntRev()+"\""));
						   		}
					   			
					   			pwriter.write(";");
					   			
					   			if(dataObj.getImdtPrntEn()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getImdtPrntEn()+"\""));
						   		}
					   			
					   			pwriter.write(";");
					   			
					   			if(dataObj.getImdtPrntFr()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getImdtPrntFr()+"\""));
						   		}

					   						   			
					   			pwriter.write(";");
					   			
					   			if(dataObj.getLevel()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getLevel()+"\""));
						   		}
					   			
					   			pwriter.write(";");
					   			
					   			if(dataObj.getDfsOrder()!= null){
						   			pwriter.write(PLMUtils.convertToCsvValue("=\""+dataObj.getDfsOrder()+"\""));
						   		}

					   			
		
				   			
					   		pwriter.write("\n");
			 			} 
					  
				}
			}
				
			} catch (FileNotFoundException e) {
				LOG.log(Level.ERROR, "Exception@saveTC5WhUsedRptCSVSemCol: ", e);
				throw e;
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveTC5WhUsedRptCSVSemCol: ", e);
				throw e;
			}  finally {
				try {
					if (pwriter !=null) {
						pwriter.close();
					}
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (IOException e) {
					LOG.log(Level.ERROR, "Exception@saveTC5WhUsedRptCSVSemCol: ", e);
					throw e;
				}
			}
			LOG.info("Exiting saveTC5WhUsedRptCSVSemCol Method");
		}
		
	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}
	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}
	/**
	 * @return the plmTC5RptService
	 */
	public PLMTC5RptServiceIfc getPlmTC5RptService() {
		return plmTC5RptService;
	}
	/**
	 * @param plmTC5RptService the plmTC5RptService to set
	 */
	public void setPlmTC5RptService(PLMTC5RptServiceIfc plmTC5RptService) {
		this.plmTC5RptService = plmTC5RptService;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}
	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	
	/**
	 * @return the tc5RelData
	 */
	public PLMTC5RelationsRptData getTc5RelData() {
		return tc5RelData;
	}
	/**
	 * @param tc5RelData the tc5RelData to set
	 */
	public void setTc5RelData(PLMTC5RelationsRptData tc5RelData) {
		this.tc5RelData = tc5RelData;
	}
	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}
	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}
	/**
	 * @return the tc5Code
	 */
	public String getTc5Code() {
		return tc5Code;
	}
	/**
	 * @param tc5Code the tc5Code to set
	 */
	public void setTc5Code(String tc5Code) {
		this.tc5Code = tc5Code;
	}
	/**
	 * @return the selRevision
	 */
	public String getSelRevision() {
		return selRevision;
	}
	/**
	 * @param selRevision the selRevision to set
	 */
	public void setSelRevision(String selRevision) {
		this.selRevision = selRevision;
	}
	/**
	 * @return the tc5RelationList
	 */
	public List<PLMTC5RelationsRptData> getTc5RelationList() {
		return tc5RelationList;
	}
	/**
	 * @param tc5RelationList the tc5RelationList to set
	 */
	public void setTc5RelationList(List<PLMTC5RelationsRptData> tc5RelationList) {
		this.tc5RelationList = tc5RelationList;
	}
	/**
	 * @return the recordCountRel
	 */
	public int getRecordCountRel() {
		return recordCountRel;
	}
	/**
	 * @param recordCountRel the recordCountRel to set
	 */
	public void setRecordCountRel(int recordCountRel) {
		this.recordCountRel = recordCountRel;
	}
	/**
	 * @return the totalRecCountRel
	 */
	public int getTotalRecCountRel() {
		return totalRecCountRel;
	}
	/**
	 * @param totalRecCountRel the totalRecCountRel to set
	 */
	public void setTotalRecCountRel(int totalRecCountRel) {
		this.totalRecCountRel = totalRecCountRel;
	}
	/**
	 * @return the exportToExcelFlag
	 */
	public boolean isExportToExcelFlag() {
		return exportToExcelFlag;
	}
	/**
	 * @param exportToExcelFlag the exportToExcelFlag to set
	 */
	public void setExportToExcelFlag(boolean exportToExcelFlag) {
		this.exportToExcelFlag = exportToExcelFlag;
	}
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * @return the tc5RelationMsg
	 */
	public String getTc5RelationMsg() {
		return tc5RelationMsg;
	}
	/**
	 * @param tc5RelationMsg the tc5RelationMsg to set
	 */
	public void setTc5RelationMsg(String tc5RelationMsg) {
		this.tc5RelationMsg = tc5RelationMsg;
	}
	/**
	 * @return the identifierVal
	 */
	public String getIdentifierVal() {
		return identifierVal;
	}
	/**
	 * @param identifierVal the identifierVal to set
	 */
	public void setIdentifierVal(String identifierVal) {
		this.identifierVal = identifierVal;
	}
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}
	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}
	/**
	 * @return the userDataObj
	 */
	public PLMLoginData getUserDataObj() {
		return userDataObj;
	}
	/**
	 * @param userDataObj the userDataObj to set
	 */
	public void setUserDataObj(PLMLoginData userDataObj) {
		this.userDataObj = userDataObj;
	}
	/**
	 * @return the plmTC5MliRptData
	 */
	public PLMTC5MliRptData getPlmTC5MliRptData() {
		return plmTC5MliRptData;
	}
	/**
	 * @param plmTC5MliRptData the plmTC5MliRptData to set
	 */
	public void setPlmTC5MliRptData(PLMTC5MliRptData plmTC5MliRptData) {
		this.plmTC5MliRptData = plmTC5MliRptData;
	}
	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}
	/**
	 * @param totalRecCount the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}
	/**
	 * @return the searchResultList
	 */
	public List<PLMTC5MliRptData> getSearchResultList() {
		return searchResultList;
	}
	/**
	 * @param searchResultList the searchResultList to set
	 */
	public void setSearchResultList(List<PLMTC5MliRptData> searchResultList) {
		this.searchResultList = searchResultList;
	}
	/**
	 * @return the totalRecCountMsg
	 */
	public String getTotalRecCountMsg() {
		return totalRecCountMsg;
	}
	/**
	 * @param totalRecCountMsg the totalRecCountMsg to set
	 */
	public void setTotalRecCountMsg(String totalRecCountMsg) {
		this.totalRecCountMsg = totalRecCountMsg;
	}
	/**
	 * @return the selCrtMsg
	 */
	public String getSelCrtMsg() {
		return selCrtMsg;
	}
	/**
	 * @param selCrtMsg the selCrtMsg to set
	 */
	public void setSelCrtMsg(String selCrtMsg) {
		this.selCrtMsg = selCrtMsg;
	}
	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}
	/**
	 * @param recordCounts the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}
	/**
	 * @return the tc5CodeFullBom
	 */
	public String getTc5CodeFullBom() {
		return tc5CodeFullBom;
	}
	/**
	 * @param tc5CodeFullBom the tc5CodeFullBom to set
	 */
	public void setTc5CodeFullBom(String tc5CodeFullBom) {
		this.tc5CodeFullBom = tc5CodeFullBom;
	}
	/**
	 * @return the bomLevel
	 */
	public String getBomLevel() {
		return bomLevel;
	}
	/**
	 * @param bomLevel the bomLevel to set
	 */
	public void setBomLevel(String bomLevel) {
		this.bomLevel = bomLevel;
	}
	/**
	 * @return the allBomLvlFlg
	 */
	public boolean isAllBomLvlFlg() {
		return allBomLvlFlg;
	}
	/**
	 * @param allBomLvlFlg the allBomLvlFlg to set
	 */
	public void setAllBomLvlFlg(boolean allBomLvlFlg) {
		this.allBomLvlFlg = allBomLvlFlg;
	}
	/**
	 * @return the refDocLevel
	 */
	public String getRefDocLevel() {
		return refDocLevel;
	}
	/**
	 * @param refDocLevel the refDocLevel to set
	 */
	public void setRefDocLevel(String refDocLevel) {
		this.refDocLevel = refDocLevel;
	}
	/**
	 * @return the allRefDocLvlFlg
	 */
	public boolean isAllRefDocLvlFlg() {
		return allRefDocLvlFlg;
	}
	/**
	 * @param allRefDocLvlFlg the allRefDocLvlFlg to set
	 */
	public void setAllRefDocLvlFlg(boolean allRefDocLvlFlg) {
		this.allRefDocLvlFlg = allRefDocLvlFlg;
	}
	/**
	 * @return the includeDefFlag
	 */
	public boolean isIncludeDefFlag() {
		return includeDefFlag;
	}
	/**
	 * @param includeDefFlag the includeDefFlag to set
	 */
	public void setIncludeDefFlag(boolean includeDefFlag) {
		this.includeDefFlag = includeDefFlag;
	}
	/**
	 * @return the dataTable
	 */
	public HtmlDataTable getDataTable() {
		return dataTable;
	}
	/**
	 * @param dataTable the dataTable to set
	 */
	public void setDataTable(HtmlDataTable dataTable) {
		this.dataTable = dataTable;
	}
	/**
	 * @return the assignRevision
	 */
	public String getAssignRevision() {
		return assignRevision;
	}
	/**
	 * @param assignRevision the assignRevision to set
	 */
	public void setAssignRevision(String assignRevision) {
		this.assignRevision = assignRevision;
	}

	/**
	 * @return the labelBundle
	 */
	public ResourceBundle getLabelBundle() {
		return labelBundle;
	}

	/**
	 * @param labelBundle the labelBundle to set
	 */
	public void setLabelBundle(ResourceBundle labelBundle) {
		this.labelBundle = labelBundle;
	}
	
	/**
	 * @return the partDocNum
	 */
	public String getPartDocNum() {
		return partDocNum;
	}

	/**
	 * @param partDocNum the partDocNum to set
	 */
	public void setPartDocNum(String partDocNum) {
		this.partDocNum = partDocNum;
	}

}
