/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName CMUSmlrToPrjSrchData.java
 * @Creation date: 23-Mar-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.Date;

public class PLMCMUSmlrToPrjData {
	private String frameTypeName;
	private String fuelTypeName;
	private String combustorTypeName;
	private String fuelTypeDescription;
	private String combustorTypeDescription;
	private Date effectivityDateFrom;
	private Date effectivityDateTo;
	private boolean allOpenFrameTypeList;
	private boolean allOpenFuelTypeList;
	private boolean allOpenCombustorTypeList;
	private boolean allOpenFrameTypeFreeTxt;
	private boolean allOpenFuelTypeFreeTxt;
	private boolean allOpenCombustorTypeFreeTxt;
	private String selFrameTypeListName;
	private String selFuelTypeListName;
	private String selCombustorTypeListName;
	private String selFrameTypeTextBoxName;
	private String selFuelTypeTextBoxName;
	private String selCombustorTypeTextBoxName;
	private String mliTextBoxName;
	private String fcodeOne;
	private String fcodeTwo;
	private String fcodeThree;
	private String fcodeFour;
	private String fdm;
	private String fdmId;
	private String mli;
	private String docNumber;
	private String partNumber;
	private String docNumberId;
	private String partNumberId;
	private String description;
	private String frameType;
	
	public String getFrameType() {
		return frameType;
	}
	public void setFrameType(String frameType) {
		this.frameType = frameType;
	}
	public String getPartNumberId() {
		return partNumberId;
	}
	public void setPartNumberId(String partNumberId) {
		this.partNumberId = partNumberId;
	}
	public String getDocNumberId() {
		return docNumberId;
	}
	public void setDocNumberId(String docNumberId) {
		this.docNumberId = docNumberId;
	}
	public String getFdmId() {
	return fdmId;
	}
	public void setFdmId(String fdmId) {
	this.fdmId = fdmId;
	}
	/**
	 * @return the mliTextBoxName
	 */
	public String getMliTextBoxName() {
		return mliTextBoxName;
	}
	/**
	 * @param mliTextBoxName the mliTextBoxName to set
	 */
	public void setMliTextBoxName(String mliTextBoxName) {
		this.mliTextBoxName = mliTextBoxName;
	}
	/**
	 * @return the fcodeOne
	 */
	public String getFcodeOne() {
		return fcodeOne;
	}
	/**
	 * @param fcodeOne the fcodeOne to set
	 */
	public void setFcodeOne(String fcodeOne) {
		this.fcodeOne = fcodeOne;
	}
	/**
	 * @return the fcodeTwo
	 */
	public String getFcodeTwo() {
		return fcodeTwo;
	}
	/**
	 * @param fcodeTwo the fcodeTwo to set
	 */
	public void setFcodeTwo(String fcodeTwo) {
		this.fcodeTwo = fcodeTwo;
	}
	/**
	 * @return the fcodeThree
	 */
	public String getFcodeThree() {
		return fcodeThree;
	}
	/**
	 * @param fcodeThree the fcodeThree to set
	 */
	public void setFcodeThree(String fcodeThree) {
		this.fcodeThree = fcodeThree;
	}
	/**
	 * @return the fcodeFour
	 */
	public String getFcodeFour() {
		return fcodeFour;
	}
	/**
	 * @param fcodeFour the fcodeFour to set
	 */
	public void setFcodeFour(String fcodeFour) {
		this.fcodeFour = fcodeFour;
	}
	/**
	 * @return the fdm
	 */
	public String getFdm() {
		return fdm;
	}
	/**
	 * @param fdm the fdm to set
	 */
	public void setFdm(String fdm) {
		this.fdm = fdm;
	}
	/**
	 * @return the mli
	 */
	public String getMli() {
		return mli;
	}
	/**
	 * @param mli the mli to set
	 */
	public void setMli(String mli) {
		this.mli = mli;
	}
	/**
	 * @return the docNumber
	 */
	public String getDocNumber() {
		return docNumber;
	}
	/**
	 * @param docNumber the docNumber to set
	 */
	public void setDocNumber(String docNumber) {
		this.docNumber = docNumber;
	}
	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}
	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the allOpenFrameTypeList
	 */
	public boolean isAllOpenFrameTypeList() {
		return allOpenFrameTypeList;
	}
	/**
	 * @param allOpenFrameTypeList the allOpenFrameTypeList to set
	 */
	public void setAllOpenFrameTypeList(boolean allOpenFrameTypeList) {
		this.allOpenFrameTypeList = allOpenFrameTypeList;
	}
	/**
	 * @return the allOpenFuelTypeList
	 */
	public boolean isAllOpenFuelTypeList() {
		return allOpenFuelTypeList;
	}
	/**
	 * @param allOpenFuelTypeList the allOpenFuelTypeList to set
	 */
	public void setAllOpenFuelTypeList(boolean allOpenFuelTypeList) {
		this.allOpenFuelTypeList = allOpenFuelTypeList;
	}
	/**
	 * @return the allOpenCombustorTypeList
	 */
	public boolean isAllOpenCombustorTypeList() {
		return allOpenCombustorTypeList;
	}
	/**
	 * @param allOpenCombustorTypeList the allOpenCombustorTypeList to set
	 */
	public void setAllOpenCombustorTypeList(boolean allOpenCombustorTypeList) {
		this.allOpenCombustorTypeList = allOpenCombustorTypeList;
	}
	/**
	 * @return the allOpenFrameTypeFreeTxt
	 */
	public boolean isAllOpenFrameTypeFreeTxt() {
		return allOpenFrameTypeFreeTxt;
	}
	/**
	 * @param allOpenFrameTypeFreeTxt the allOpenFrameTypeFreeTxt to set
	 */
	public void setAllOpenFrameTypeFreeTxt(boolean allOpenFrameTypeFreeTxt) {
		this.allOpenFrameTypeFreeTxt = allOpenFrameTypeFreeTxt;
	}
	/**
	 * @return the allOpenFuelTypeFreeTxt
	 */
	public boolean isAllOpenFuelTypeFreeTxt() {
		return allOpenFuelTypeFreeTxt;
	}
	/**
	 * @param allOpenFuelTypeFreeTxt the allOpenFuelTypeFreeTxt to set
	 */
	public void setAllOpenFuelTypeFreeTxt(boolean allOpenFuelTypeFreeTxt) {
		this.allOpenFuelTypeFreeTxt = allOpenFuelTypeFreeTxt;
	}
	/**
	 * @return the allOpenCombustorTypeFreeTxt
	 */
	public boolean isAllOpenCombustorTypeFreeTxt() {
		return allOpenCombustorTypeFreeTxt;
	}
	/**
	 * @param allOpenCombustorTypeFreeTxt the allOpenCombustorTypeFreeTxt to set
	 */
	public void setAllOpenCombustorTypeFreeTxt(boolean allOpenCombustorTypeFreeTxt) {
		this.allOpenCombustorTypeFreeTxt = allOpenCombustorTypeFreeTxt;
	}
	/**
	 * @return the selFrameTypeListName
	 */
	public String getSelFrameTypeListName() {
		return selFrameTypeListName;
	}
	/**
	 * @param selFrameTypeListName the selFrameTypeListName to set
	 */
	public void setSelFrameTypeListName(String selFrameTypeListName) {
		this.selFrameTypeListName = selFrameTypeListName;
	}
	/**
	 * @return the selFuelTypeListName
	 */
	public String getSelFuelTypeListName() {
		return selFuelTypeListName;
	}
	/**
	 * @param selFuelTypeListName the selFuelTypeListName to set
	 */
	public void setSelFuelTypeListName(String selFuelTypeListName) {
		this.selFuelTypeListName = selFuelTypeListName;
	}
	/**
	 * @return the selCombustorTypeListName
	 */
	public String getSelCombustorTypeListName() {
		return selCombustorTypeListName;
	}
	/**
	 * @param selCombustorTypeListName the selCombustorTypeListName to set
	 */
	public void setSelCombustorTypeListName(String selCombustorTypeListName) {
		this.selCombustorTypeListName = selCombustorTypeListName;
	}
	/**
	 * @return the selFrameTypeTextBoxName
	 */
	public String getSelFrameTypeTextBoxName() {
		return selFrameTypeTextBoxName;
	}
	/**
	 * @param selFrameTypeTextBoxName the selFrameTypeTextBoxName to set
	 */
	public void setSelFrameTypeTextBoxName(String selFrameTypeTextBoxName) {
		this.selFrameTypeTextBoxName = selFrameTypeTextBoxName;
	}
	/**
	 * @return the selFuelTypeTextBoxName
	 */
	public String getSelFuelTypeTextBoxName() {
		return selFuelTypeTextBoxName;
	}
	/**
	 * @param selFuelTypeTextBoxName the selFuelTypeTextBoxName to set
	 */
	public void setSelFuelTypeTextBoxName(String selFuelTypeTextBoxName) {
		this.selFuelTypeTextBoxName = selFuelTypeTextBoxName;
	}
	/**
	 * @return the selCombustorTypeTextBoxName
	 */
	public String getSelCombustorTypeTextBoxName() {
		return selCombustorTypeTextBoxName;
	}
	/**
	 * @param selCombustorTypeTextBoxName the selCombustorTypeTextBoxName to set
	 */
	public void setSelCombustorTypeTextBoxName(String selCombustorTypeTextBoxName) {
		this.selCombustorTypeTextBoxName = selCombustorTypeTextBoxName;
	}
	/**
	 * @return the effectivityDateFrom
	 */
	public Date getEffectivityDateFrom() {
		return effectivityDateFrom;
	}
	/**
	 * @param effectivityDateFrom the effectivityDateFrom to set
	 */
	public void setEffectivityDateFrom(Date effectivityDateFrom) {
		this.effectivityDateFrom = effectivityDateFrom;
	}
	/**
	 * @return the effectivityDateTo
	 */
	public Date getEffectivityDateTo() {
		return effectivityDateTo;
	}
	/**
	 * @param effectivityDateTo the effectivityDateTo to set
	 */
	public void setEffectivityDateTo(Date effectivityDateTo) {
		this.effectivityDateTo = effectivityDateTo;
	}
	/**
	 * @return the frameTypeName
	 */
	public String getFrameTypeName() {
		return frameTypeName;
	}
	/**
	 * @param frameTypeName the frameTypeName to set
	 */
	public void setFrameTypeName(String frameTypeName) {
		this.frameTypeName = frameTypeName;
	}
	/**
	 * @return the fuelTypeName
	 */
	public String getFuelTypeName() {
		return fuelTypeName;
	}
	/**
	 * @param fuelTypeName the fuelTypeName to set
	 */
	public void setFuelTypeName(String fuelTypeName) {
		this.fuelTypeName = fuelTypeName;
	}
	/**
	 * @return the combustorTypeName
	 */
	public String getCombustorTypeName() {
		return combustorTypeName;
	}
	/**
	 * @param combustorTypeName the combustorTypeName to set
	 */
	public void setCombustorTypeName(String combustorTypeName) {
		this.combustorTypeName = combustorTypeName;
	}
	/**
	 * @return the fuelTypeDescription
	 */
	public String getFuelTypeDescription() {
		return fuelTypeDescription;
	}
	/**
	 * @param fuelTypeDescription the fuelTypeDescription to set
	 */
	public void setFuelTypeDescription(String fuelTypeDescription) {
		this.fuelTypeDescription = fuelTypeDescription;
	}
	/**
	 * @return the combustorTypeDescription
	 */
	public String getCombustorTypeDescription() {
		return combustorTypeDescription;
	}
	/**
	 * @param combustorTypeDescription the combustorTypeDescription to set
	 */
	public void setCombustorTypeDescription(String combustorTypeDescription) {
		this.combustorTypeDescription = combustorTypeDescription;
	}
	

}
