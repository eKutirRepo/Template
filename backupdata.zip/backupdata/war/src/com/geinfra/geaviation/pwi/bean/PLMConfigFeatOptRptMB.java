/**
 * Copyright (C) 2015 GE Infra. 
 * All rights reserved 
 * @FileName PLMConfigFeatOptRptMB.java
 * @Creation date: 18-Aug-2015
 * @version 1.0
  * @author : Tech Mahindra
 */
package com.geinfra.geaviation.pwi.bean;

import java.util.ArrayList;
import java.util.List;

import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.data.PLMConfigFeatOptRptData;
import com.geinfra.geaviation.pwi.service.PLMConfigFeatOptRptServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

public class PLMConfigFeatOptRptMB {
	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMConfigFeatOptRptMB.class);
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor=null;
	/**
	 * Holds the PLMCommonMB
	 */
	private PLMCommonMB commonMB=null;
	/**
	 * Holds the plmConfigFeatOptRptService
	 */
	private PLMConfigFeatOptRptServiceIfc plmConfigFeatOptRptService = null;
	/**
	 * Holds the PLMCustDocReportData
	 */
	private PLMConfigFeatOptRptData plmConfigFeatOptRptData = new PLMConfigFeatOptRptData();
	/**
	 * Holds the stateList
	 */
	private List<SelectItem> stateList= new ArrayList<SelectItem>();
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the searchResultList
	 */
	private List<PLMConfigFeatOptRptData> searchResultList=new ArrayList<PLMConfigFeatOptRptData>();
	/**
	 * Holds the totalRecCountMsg
	 */
	private String totalRecCountMsg;
	private String selCrtMsg;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;
	private String alertMessage="";
	private String fwdFlag;
	
	
	
	/**
	 * This method is used for loadCustDocReportSearchPage
	 * 
	 * @return String
	 */
	public String loadSearchPage() throws PLMCommonException {
		LOG.info("Entering loadSearchPage Method");
		try {
			commonMB.insertCannedRptRecordHitInfo("Configuration Feature Option Search");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		plmConfigFeatOptRptData = new PLMConfigFeatOptRptData();
		resetData();
		searchResultList.clear();
		//plmCustDocReportData.setSourceOfResult("pgplmtcf");
		
		stateList= new ArrayList<SelectItem>();
		stateList= plmConfigFeatOptRptService.getStateDDList();
		
		LOG.info("Exiting loadSearchPage Method");
		return "configFeatOptSearch";
	}
	
	
	/**
	 * This method for getTaskSearchData
	 * 
	 * @return String
	 */
	public String getSearchResult() {
		String fwdFlagLcl = "";
		LOG.info("Entering getSearchResult() method");
		try {
			alertMessage = validateSearchData();
			searchResultList=new ArrayList<PLMConfigFeatOptRptData>();
			if (PLMUtils.isEmpty(alertMessage)) {
				searchResultList = plmConfigFeatOptRptService.getSearchResult(plmConfigFeatOptRptData);
				LOG.info("Fetched searchResultList with size==="+searchResultList.size());
				totalRecCountMsg = "Total Results Count : " + searchResultList.size();
				LOG.info("totalRecCount::::::::::::::::::" + searchResultList.size());
				if (searchResultList.size() == 0) {
					fwdFlagLcl = "invalidCFO";
				} else {
					recordCounts = PLMConstants.N_100;
					fwdFlagLcl = "configFeatOptResult";
				}
				 
			}	
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getSearchResult: ", exception);
			//fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"configFeatOptSearch","Config Feature Option Search");
		}
		
		LOG.info("Existing getSearchResult() method");
		return fwdFlagLcl;
	}
	
	public String validateSearchData(){
		LOG.info("Entering validateSearchData() in MB");
		if (PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpOwner())
				&& PLMUtils.isEmptyList(plmConfigFeatOptRptData.getIpState())
				&& PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpName())
				&& PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpOriginator())
				&& PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpVault())
				&& PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpRevision())
				&& PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpTitle())
				&& PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpDescription())
				&& PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpDisplayName())
				&& PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpIndicator())
				&& PLMUtils.isEmptyDate(plmConfigFeatOptRptData.getIpOrigFromDate())
				&& PLMUtils.isEmptyDate(plmConfigFeatOptRptData.getIpOrigToDate())
				&& PLMUtils.isEmptyDate(plmConfigFeatOptRptData.getIpModFromDate())
				&& PLMUtils.isEmptyDate(plmConfigFeatOptRptData.getIpModToDate())){
					alertMessage = PLMConstants.SEARCH_CRITERIA;
					LOG.info("Please enter any criteria and click on search");
				} else {
					String ownerWithOutAsterisk = null;
					String originatorWithOutAsterisk = null;
					
					if (!PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpName())){
						if(!PLMUtils.checkForSpecialCharsForTaskSearch(plmConfigFeatOptRptData.getIpName())) {
						alertMessage = alertMessage + PLMConstants.IPNAME_MESSAGE;
					}
					}
					
					
					if (!PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpRevision())){
						if(!PLMUtils.checkForSpecialCharsForTaskSearch(plmConfigFeatOptRptData.getIpRevision())) {
						alertMessage = alertMessage + PLMConstants.REVISION_MESSAGE;
					}
					}
					
					if (!PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpOwner())) {
						ownerWithOutAsterisk = PLMUtils.removeAsteriskAndSpaceFromSSOFields(plmConfigFeatOptRptData.getIpOwner());
					}
					if (!PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpOriginator())) {
						originatorWithOutAsterisk = PLMUtils.removeAsteriskAndSpaceFromSSOFields(plmConfigFeatOptRptData.getIpOriginator());
					}
					if (!PLMUtils.checkForSpecialCharsForTaskSearch(plmConfigFeatOptRptData.getIpOwner())) {
						alertMessage = alertMessage + PLMConstants.OWNER_MESSAGE;
					}
					else if(PLMUtils.isInteger(ownerWithOutAsterisk)) {
						if(ownerWithOutAsterisk.length() != 9)
							alertMessage = alertMessage + PLMConstants.TASK_OWNER_DIGT_MESSAGE;
					} 
					if (!PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpOriginator())){
						if(!PLMUtils.checkForSpecialCharsForTaskSearch(plmConfigFeatOptRptData.getIpOriginator())) {
						alertMessage = alertMessage + PLMConstants.ORIGINATOR_MESSAGE;
					}
					}
					
					if (!PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpIndicator())){
						if(!PLMUtils.checkForSpecialCharsForTaskSearch(plmConfigFeatOptRptData.getIpIndicator())) {
						alertMessage = alertMessage + PLMConstants.LEGACYFA_MESSAGE;
					}
					}
					
					if (!PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpDescription())){
						if(!PLMUtils.checkForSpecialCharsForTaskSearch(plmConfigFeatOptRptData.getIpDescription())) {
						alertMessage = alertMessage + PLMConstants.IPDESC_MESSAGE;
					}
					}
					
					
					if (!PLMUtils.isEmpty(plmConfigFeatOptRptData.getIpDisplayName())){
						if(!PLMUtils.checkForSpecialCharsForTaskSearch(plmConfigFeatOptRptData.getIpDisplayName())) {
						alertMessage = alertMessage + PLMConstants.IPDISPLAY_MESSAGE;
					}
					}
					
					else if(PLMUtils.isInteger(originatorWithOutAsterisk)) {
						if(originatorWithOutAsterisk.length() != 9)
							alertMessage = alertMessage + PLMConstants.ORIGINATOR_DIGT_MESSAGE;
					}
					
					if (PLMUtils.checkForNullOfTwoDates(plmConfigFeatOptRptData.getIpOrigFromDate(), plmConfigFeatOptRptData.getIpOrigToDate())) {
						alertMessage = alertMessage + PLMConstants.Dates_NullCheck_Msg;
					} else if (PLMUtils.checkForFromAndToDate(plmConfigFeatOptRptData.getIpOrigFromDate(), plmConfigFeatOptRptData.getIpOrigToDate())) {
						alertMessage = alertMessage + PLMConstants.Date_ValMsg;
					}
					
					if (PLMUtils.checkForNullOfTwoDates(plmConfigFeatOptRptData.getIpModFromDate(), plmConfigFeatOptRptData.getIpModToDate())) {
						alertMessage = alertMessage + PLMConstants.Dates_NullCheck_Msg;
					} else if (PLMUtils.checkForFromAndToDate(plmConfigFeatOptRptData.getIpModFromDate(), plmConfigFeatOptRptData.getIpModToDate())) {
						alertMessage = alertMessage + PLMConstants.Date_ValMsg;
					}
					
				}
			if(!PLMUtils.isEmptyList(plmConfigFeatOptRptData.getIpState())){
				plmConfigFeatOptRptData.setConfFtrStateExcl(PLMUtils.setListForQuery(plmConfigFeatOptRptData.getIpState()));
			}
				
		LOG.info(alertMessage);
		LOG.info("Existing validateSearchData() in MB");
		return alertMessage;
	}
	
	public String resetData() {

		plmConfigFeatOptRptData.setIpDescription(PLMConstants.EMPTY);
		plmConfigFeatOptRptData.setIpDisplayName(PLMConstants.EMPTY);
		plmConfigFeatOptRptData.setIpIndicator(PLMConstants.EMPTY);
		plmConfigFeatOptRptData.setIpName(PLMConstants.EMPTY);
		plmConfigFeatOptRptData.setIpOriginator(PLMConstants.EMPTY);
		plmConfigFeatOptRptData.setIpOwner(PLMConstants.EMPTY);
		plmConfigFeatOptRptData.setIpRevision(PLMConstants.EMPTY);
		plmConfigFeatOptRptData.setIpState(null);
		plmConfigFeatOptRptData.setIpModFromDate(null);
		plmConfigFeatOptRptData.setIpModToDate(null);
		plmConfigFeatOptRptData.setIpOrigFromDate(null);
		plmConfigFeatOptRptData.setIpOrigToDate(null);
		alertMessage="";
		return "configFeatOptSearch";
		}
	
	public void downloadExcel() throws PLMCommonException {
		LOG.info("Entering downloadExcel Method");
		String reportName = "ConfFeatureOpt";
		String fileName = "Configuration Feature Option Rpt";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);
		
		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();
		
		//Export to Excel for Configuration Feature option
		
		PLMXlsxRptColumn[] critcolumns  = new PLMXlsxRptColumn[] {
                new PLMXlsxRptColumn("ipName", "Name", FormatType.TEXT),
                new PLMXlsxRptColumn("ipRevision", "Revision", FormatType.TEXT),
                new PLMXlsxRptColumn("confFtrStateExcl", "state", FormatType.TEXT),
                new PLMXlsxRptColumn("ipOwner", "Owner", FormatType.TEXT),
                new PLMXlsxRptColumn("ipOriginator", "Originator", FormatType.TEXT),
                new PLMXlsxRptColumn("ipIndicator", "Legacy F&A Code", FormatType.TEXT),
                new PLMXlsxRptColumn("ipDescription", "Description", FormatType.TEXT),
                new PLMXlsxRptColumn("ipDisplayName", "Display Name", FormatType.TEXT),
                new PLMXlsxRptColumn("ipOrigFromDate", "Originated Date (From)", FormatType.DATE),
                new PLMXlsxRptColumn("ipOrigToDate", "Originated Date (To)", FormatType.DATE),
                new PLMXlsxRptColumn("ipModFromDate", "Modified Date (From)", FormatType.DATE),
                new PLMXlsxRptColumn("ipModToDate", "Modified Date (To)", FormatType.DATE)
                };
			
			PLMXlsxRptColumn[] reportColumns = new PLMXlsxRptColumn[] {
					  new PLMXlsxRptColumn("coName", "Config. Feature Option", FormatType.TEXT, null, null, 23),
					  new PLMXlsxRptColumn("displayName", "Config. Feature Option Name", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("geIndr", "Legacy F&A Code", FormatType.TEXT, null, null, 10),
					  new PLMXlsxRptColumn("displayText", "Display Text", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("coRevision", "Revision", FormatType.TEXT, null, null, 9),
					  new PLMXlsxRptColumn("coState", "State", FormatType.TEXT),
					  new PLMXlsxRptColumn("parentCf", "Parent Config. Feature", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("ownerSso", "Owner SSO", FormatType.TEXT),
					  new PLMXlsxRptColumn("ownerName", "Owner Name", FormatType.TEXT, null, null, 25),
					  new PLMXlsxRptColumn("origDate", "Originated Date", FormatType.TEXT),
					  new PLMXlsxRptColumn("cfgnSelType", "Config. Selection Type", FormatType.TEXT)
			};
			
			excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, plmConfigFeatOptRptData);	
		
			LOG.info("Exiting downloadExcel Method");
	}
	
	public void recordsPerPageListner(ActionEvent event) {
		LOG.info("Entering recordsPerPageListner method");
		LOG.info("Action listner called.....--------------------------->"
				+ recordCounts);
		if (recordCounts == 15) {
			LOG.info("15");
			recordCounts = 15;
		} else if (recordCounts == 30) {
			LOG.info("30");
			recordCounts = 30;
		} else if (recordCounts == 50) {
			LOG.info("50");
			recordCounts = 50;
		} else if (recordCounts == 100) {
			LOG.info("100");
			recordCounts = 100;
		} else if (recordCounts == 200) {
			LOG.info("200");
			recordCounts = 200;
		}


		LOG.info("final value.....--------------------------->" + recordCounts);
	}


	
	
	
	
	
	
	
	
	

	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}



	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}







	/**
	 * @return the plmConfigFeatOptRptService
	 */
	public PLMConfigFeatOptRptServiceIfc getPlmConfigFeatOptRptService() {
		return plmConfigFeatOptRptService;
	}



	/**
	 * @param plmConfigFeatOptRptService the plmConfigFeatOptRptService to set
	 */
	public void setPlmConfigFeatOptRptService(
			PLMConfigFeatOptRptServiceIfc plmConfigFeatOptRptService) {
		this.plmConfigFeatOptRptService = plmConfigFeatOptRptService;
	}



	/**
	 * @return the plmConfigFeatOptRptData
	 */
	public PLMConfigFeatOptRptData getPlmConfigFeatOptRptData() {
		return plmConfigFeatOptRptData;
	}



	/**
	 * @param plmConfigFeatOptRptData the plmConfigFeatOptRptData to set
	 */
	public void setPlmConfigFeatOptRptData(
			PLMConfigFeatOptRptData plmConfigFeatOptRptData) {
		this.plmConfigFeatOptRptData = plmConfigFeatOptRptData;
	}



	/**
	 * @return the stateList
	 */
	public List<SelectItem> getStateList() {
		return stateList;
	}



	/**
	 * @param stateList the stateList to set
	 */
	public void setStateList(List<SelectItem> stateList) {
		this.stateList = stateList;
	}



	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}



	/**
	 * @param totalRecCount the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}



	/**
	 * @return the searchResultList
	 */
	public List<PLMConfigFeatOptRptData> getSearchResultList() {
		return searchResultList;
	}



	/**
	 * @param searchResultList the searchResultList to set
	 */
	public void setSearchResultList(List<PLMConfigFeatOptRptData> searchResultList) {
		this.searchResultList = searchResultList;
	}



	/**
	 * @return the totalRecCountMsg
	 */
	public String getTotalRecCountMsg() {
		return totalRecCountMsg;
	}



	/**
	 * @param totalRecCountMsg the totalRecCountMsg to set
	 */
	public void setTotalRecCountMsg(String totalRecCountMsg) {
		this.totalRecCountMsg = totalRecCountMsg;
	}



	/**
	 * @return the selCrtMsg
	 */
	public String getSelCrtMsg() {
		return selCrtMsg;
	}



	/**
	 * @param selCrtMsg the selCrtMsg to set
	 */
	public void setSelCrtMsg(String selCrtMsg) {
		this.selCrtMsg = selCrtMsg;
	}



	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}



	/**
	 * @param recordCounts the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}



	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}



	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}



	/**
	 * @return the fwdFlag
	 */
	public String getFwdFlag() {
		return fwdFlag;
	}



	/**
	 * @param fwdFlag the fwdFlag to set
	 */
	public void setFwdFlag(String fwdFlag) {
		this.fwdFlag = fwdFlag;
	}



	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return LOG;
	}


	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}


	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	
	
}
