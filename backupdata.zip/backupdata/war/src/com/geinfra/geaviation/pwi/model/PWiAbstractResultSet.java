package com.geinfra.geaviation.pwi.model;

import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

/**
 * Project:      Product Lifecycle Management Intelligence
 * Module:       PWiAbstractResultSet.java
 * Author:       Sandeep Chaturvedi
 * Date-Written: April 2001
 * Security:     GE Confidential
 * Restrictions: GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 * Copyright(C) 2013 GE All rights reserved
 *
 * Revision log:
 * -----------------------------------------------------------------------------
 *  2012/12/12  Hasso    Updated package to com.geinfra.geaviation.pwi.model
 *                       (was geae.dao.GEAEAbstractResultSet).
 *  2012/12/21  Hasso    Removed abstract methods from implemented interfaces
 *                       Throw UnsupportedOperationException from unimplemented
 *                       nonabstract methods
 *  2013/01/22  Hasso    Added "implementations" for deprecated
 *                       getBigDecimal methods.
 */
public abstract class PWiAbstractResultSet implements ResultSet,
		ResultSetMetaData {

	/**
	 * Constructs an uninitialized PWiAbstractResultSet.
	 */
	public PWiAbstractResultSet() {
	}

	// ==========================================================================
	// User do not have to implement the following methods for they
	// are not used in the JReport system--whatever that is.
	// pH 2012.12: It may instead be the case that they are not used by PWi.
	// ==========================================================================

	public byte[] getBytes(int columnIndex) throws SQLException {
		throw new UnsupportedOperationException();
	}

	public InputStream getAsciiStream(int columnIndex)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * @deprecated
	 */
	public InputStream getUnicodeStream(int columnIndex)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	public InputStream getBinaryStream(int columnIndex)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	public String getString(String columnName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	public boolean getBoolean(String columnName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	public byte getByte(String columnName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	public byte getByte(int columnIndex) throws SQLException {
		throw new UnsupportedOperationException();
	}

	public short getShort(String columnName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	public int getInt(String columnName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	public long getLong(String columnName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	public float getFloat(String columnName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	public double getDouble(String columnName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * @deprecated
	 */
	public BigDecimal getBigDecimal(String columnName, int scale)
			throws SQLException {
		throw new UnsupportedOperationException();
	}
	
	/**
	 * @deprecated
	 */
	public BigDecimal getBigDecimal(int columnIndex, int scale)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	public byte[] getBytes(String columnName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	public java.sql.Date getDate(String columnName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	public java.sql.Date getDate(int columnIndex) throws SQLException {
		throw new UnsupportedOperationException();
	}

	public java.sql.Time getTime(String columnName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	public java.sql.Timestamp getTimestamp(String columnName)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	public java.sql.Timestamp getTimestamp(int columnIndex)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	public InputStream getAsciiStream(String columnName)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * @deprecated
	 */
	public InputStream getUnicodeStream(String columnName)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	public InputStream getBinaryStream(String columnName)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	public java.sql.SQLWarning getWarnings() throws SQLException {
		throw new UnsupportedOperationException();
	}

	public void clearWarnings() throws SQLException {
		throw new UnsupportedOperationException();
	}

	public String getCursorName() throws SQLException {
		throw new UnsupportedOperationException();
	}

	public ResultSetMetaData getMetaData() throws SQLException {
		return this;
	}

	public Object getObject(int columnIndex) throws SQLException {
		throw new UnsupportedOperationException();
	}

	public Object getObject(String columnName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	public int findColumn(String columnName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	// #if JAVA_12
	// --------------------------JDBC 2.0-----------------------------------

	// ---------------------------------------------------------------------
	// Getter's and Setter's
	// ---------------------------------------------------------------------

	/**
	 * JDBC 2.0
	 * 
	 * <p>
	 * Get the value of a column in the current row as a java.io.Reader.
	 */
	public java.io.Reader getCharacterStream(int columnIndex)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * <p>
	 * Get the value of a column in the current row as a java.io.Reader.
	 */
	public java.io.Reader getCharacterStream(String columnName)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Get the value of a column in the current row as a java.math.BigDecimal
	 * object.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @return the column value (full precision); if the value is SQL NULL, the
	 *         result is null
	 * @exception SQLException
	 *                if a database-access error occurs.
	 * @deprecated
	 */
	public BigDecimal getBigDecimal(int columnIndex) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Get the value of a column in the current row as a java.math.BigDecimal
	 * object.
	 * 
	 * @deprecated
	 */
	public BigDecimal getBigDecimal(String columnName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	// ---------------------------------------------------------------------
	// Traversal/Positioning
	// ---------------------------------------------------------------------

	/**
	 * JDBC 2.0
	 * 
	 * <p>
	 * Determine if the cursor is before the first row in the result set.
	 * 
	 * @return true if before the first row, false otherwise. Returns false when
	 *         the result set contains no rows.
	 * @exception SQLException
	 *                if a database-access error occurs.
	 */
	public boolean isBeforeFirst() throws SQLException {
		return false;
	}

	/**
	 * JDBC 2.0
	 * 
	 * <p>
	 * Determine if the cursor is after the last row in the result set.
	 * 
	 * @return true if after the last row, false otherwise. Returns false when
	 *         the result set contains no rows.
	 * @exception SQLException
	 *                if a database-access error occurs.
	 */
	public boolean isAfterLast() throws SQLException {
		return false;
	}

	/**
	 * JDBC 2.0
	 * 
	 * <p>
	 * Determine if the cursor is on the first row of the result set.
	 * 
	 * @return true if on the first row, false otherwise.
	 * @exception SQLException
	 *                if a database-access error occurs.
	 */
	public boolean isFirst() throws SQLException {
		return false;
	}

	/**
	 * JDBC 2.0
	 * 
	 * <p>
	 * Determine if the cursor is on the last row of the result set. Note:
	 * Calling isLast() may be expensive since the JDBC driver might need to
	 * fetch ahead one row in order to determine whether the current row is the
	 * last row in the result set.
	 * 
	 * @return true if on the last row, false otherwise.
	 * @exception SQLException
	 *                if a database-access error occurs.
	 */
	public boolean isLast() throws SQLException {
		return false;
	}

	/**
	 * JDBC 2.0
	 * 
	 * <p>
	 * Moves to the front of the result set, just before the first row. Has no
	 * effect if the result set contains no rows.
	 * 
	 * @exception SQLException
	 *                if a database-access error occurs, or result set type is
	 *                TYPE_FORWARD_ONLY
	 */
	public void beforeFirst() throws SQLException {
	}

	/**
	 * JDBC 2.0
	 * 
	 * <p>
	 * Moves to the end of the result set, just after the last row. Has no
	 * effect if the result set contains no rows.
	 * 
	 * @exception SQLException
	 *                if a database-access error occurs, or result set type is
	 *                TYPE_FORWARD_ONLY.
	 */
	public void afterLast() throws SQLException {
	}

	/**
	 * JDBC 2.0
	 * 
	 * <p>
	 * Moves to the first row in the result set.
	 * 
	 * @return true if on a valid row, false if no rows in the result set.
	 * @exception SQLException
	 *                if a database-access error occurs, or result set type is
	 *                TYPE_FORWARD_ONLY.
	 */
	public boolean first() throws SQLException {
		return false;
	}

	/**
	 * JDBC 2.0
	 * 
	 * <p>
	 * Moves to the last row in the result set.
	 * 
	 * @return true if on a valid row, false if no rows in the result set.
	 * @exception SQLException
	 *                if a database-access error occurs, or result set type is
	 *                TYPE_FORWARD_ONLY.
	 */
	public boolean last() throws SQLException {
		return false;
	}

	/**
	 * JDBC 2.0
	 * 
	 * <p>
	 * Determine the current row number. The first row is number 1, the second
	 * number 2, etc.
	 * 
	 * @return the current row number, else return 0 if there is no current row
	 * @exception SQLException
	 *                if a database-access error occurs.
	 */
	public int getRow() throws SQLException {
		return 0;
	}

	/**
	 * JDBC 2.0
	 * 
	 * <p>
	 * Move to an absolute row number in the result set.
	 * 
	 * <p>
	 * If row is positive, moves to an absolute row with respect to the
	 * beginning of the result set. The first row is row 1, the second is row 2,
	 * etc.
	 * 
	 * <p>
	 * If row is negative, moves to an absolute row position with respect to the
	 * end of result set. For example, calling absolute(-1) positions the cursor
	 * on the last row, absolute(-2) indicates the next-to-last row, etc.
	 * 
	 * <p>
	 * An attempt to position the cursor beyond the first/last row in the result
	 * set, leaves the cursor before/after the first/last row, respectively.
	 * 
	 * <p>
	 * Note: Calling absolute(1) is the same as calling first(). Calling
	 * absolute(-1) is the same as calling last().
	 * 
	 * @return true if on the result set, false if off.
	 * @exception SQLException
	 *                if a database-access error occurs, or row is 0, or result
	 *                set type is TYPE_FORWARD_ONLY.
	 */
	public boolean absolute(int row) throws SQLException {
		return false;
	}

	/**
	 * JDBC 2.0
	 * 
	 * <p>
	 * Moves a relative number of rows, either positive or negative. Attempting
	 * to move beyond the first/last row in the result set positions the cursor
	 * before/after the the first/last row. Calling relative(0) is valid, but
	 * does not change the cursor position.
	 * 
	 * <p>
	 * Note: Calling relative(1) is different than calling next() since is makes
	 * sense to call next() when there is no current row, for example, when the
	 * cursor is positioned before the first row or after the last row of the
	 * result set.
	 * 
	 * @return true if on a row, false otherwise.
	 * @exception SQLException
	 *                if a database-access error occurs, or there is no current
	 *                row, or result set type is TYPE_FORWARD_ONLY.
	 */
	public boolean relative(int rows) throws SQLException {
		return false;
	}

	/**
	 * JDBC 2.0
	 * 
	 * <p>
	 * Moves to the previous row in the result set.
	 * 
	 * <p>
	 * Note: previous() is not the same as relative(-1) since it makes sense to
	 * call previous() when there is no current row.
	 * 
	 * @return true if on a valid row, false if off the result set.
	 * @exception SQLException
	 *                if a database-access error occurs, or result set type is
	 *                TYPE_FORWAR_DONLY.
	 */
	public boolean previous() throws SQLException {
		return false;
	}

	/**
	 * JDBC 2.0
	 * 
	 * Give a hint as to the direction in which the rows in this result set will
	 * be processed. The initial value is determined by the statement that
	 * produced the result set. The fetch direction may be changed at any time.
	 * 
	 * @exception SQLException
	 *                if a database-access error occurs, or the result set type
	 *                is TYPE_FORWARD_ONLY and direction is not FETCH_FORWARD.
	 */
	public void setFetchDirection(int direction) throws SQLException {
	}

	/**
	 * JDBC 2.0
	 * 
	 * Return the fetch direction for this result set.
	 * 
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public int getFetchDirection() throws SQLException {
		return 0;
	}

	/**
	 * JDBC 2.0
	 * 
	 * Give the JDBC driver a hint as to the number of rows that should be
	 * fetched from the database when more rows are needed for this result set.
	 * If the fetch size specified is zero, then the JDBC driver ignores the
	 * value, and is free to make its own best guess as to what the fetch size
	 * should be. The default value is set by the statement that creates the
	 * result set. The fetch size may be changed at any time.
	 * 
	 * @param rows
	 *            the number of rows to fetch
	 * @exception SQLException
	 *                if a database-access error occurs, or the condition 0 <=
	 *                rows <= this.getMaxRows() is not satisfied.
	 */
	public void setFetchSize(int rows) throws SQLException {
	}

	/**
	 * JDBC 2.0
	 * 
	 * Return the fetch size for this result set.
	 * 
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public int getFetchSize() throws SQLException {
		return 0;
	}

	/**
	 * JDBC 2.0
	 * 
	 * Return the type of this result set. The type is determined based on the
	 * statement that created the result set.
	 * 
	 * @return TYPE_FORWARD_ONLY, TYPE_SCROLL_INSENSITIVE, or
	 *         TYPE_SCROLL_SENSITIVE
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public int getType() throws SQLException {
		return 0;
	}

	/**
	 * JDBC 2.0
	 * 
	 * Return the concurrency of this result set. The concurrency used is
	 * determined by the statement that created the result set.
	 * 
	 * @return the concurrency type, CONCUR_READ_ONLY, etc.
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public int getConcurrency() throws SQLException {
		return 0;
	}

	// ---------------------------------------------------------------------
	// Updates
	// ---------------------------------------------------------------------

	/**
	 * JDBC 2.0
	 * 
	 * Determine if the current row has been updated. The value returned depends
	 * on whether or not the result set can detect updates.
	 * 
	 * @return true if the row has been visibly updated by the owner or another,
	 *         and updates are detected
	 * @exception SQLException
	 *                if a database-access error occurs
	 * 
	 * @see DatabaseMetaData#updatesAreDetected
	 */
	public boolean rowUpdated() throws SQLException {
		return false;
	}

	/**
	 * JDBC 2.0
	 * 
	 * Determine if the current row has been inserted. The value returned
	 * depends on whether or not the result set can detect visible inserts.
	 * 
	 * @return true if inserted and inserts are detected
	 * @exception SQLException
	 *                if a database-access error occurs
	 * 
	 * @see DatabaseMetaData#insertsAreDetected
	 */
	public boolean rowInserted() throws SQLException {
		return false;
	}

	/**
	 * JDBC 2.0
	 * 
	 * Determine if this row has been deleted. A deleted row may leave a visible
	 * "hole" in a result set. This method can be used to detect holes in a
	 * result set. The value returned depends on whether or not the result set
	 * can detect deletions.
	 * 
	 * @return true if deleted and deletes are detected
	 * @exception SQLException
	 *                if a database-access error occurs
	 * 
	 * @see DatabaseMetaData#deletesAreDetected
	 */
	public boolean rowDeleted() throws SQLException {
		return false;
	}

	/**
	 * JDBC 2.0
	 * 
	 * Give a nullable column a null value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateNull(int columnIndex) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a boolean value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateBoolean(int columnIndex, boolean val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a byte value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateByte(int columnIndex, byte val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a short value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateShort(int columnIndex, short val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with an integer value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateInt(int columnIndex, int val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a long value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateLong(int columnIndex, long val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a float value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateFloat(int columnIndex, float val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a Double value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateDouble(int columnIndex, double val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a BigDecimal value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 * @deprecated
	 */
	public void updateBigDecimal(int columnIndex, BigDecimal val)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a String value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateString(int columnIndex, String val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a byte array value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateBytes(int columnIndex, byte val[]) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a Date value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateDate(int columnIndex, java.sql.Date val)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a Time value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateTime(int columnIndex, java.sql.Time val)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a Timestamp value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateTimestamp(int columnIndex, java.sql.Timestamp val)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with an ascii stream value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @param length
	 *            the length of the stream
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateAsciiStream(int columnIndex, java.io.InputStream val,
			int length) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a binary stream value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @param length
	 *            the length of the stream
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateBinaryStream(int columnIndex, java.io.InputStream val,
			int length) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a character stream value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @param length
	 *            the length of the stream
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateCharacterStream(int columnIndex, java.io.Reader val,
			int length) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with an Object value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @param scale
	 *            For java.sql.Types.DECIMAL or java.sql.Types.NUMERIC types
	 *            this is the number of digits after the decimal. For all other
	 *            types this value will be ignored.
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateObject(int columnIndex, Object val, int scale)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with an Object value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateObject(int columnIndex, Object val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a null value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateNull(String columnName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a boolean value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateBoolean(String columnName, boolean val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a byte value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateByte(String columnName, byte val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a short value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateShort(String columnName, short val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with an integer value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateInt(String columnName, int val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a long value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateLong(String columnName, long val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a float value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateFloat(String columnName, float val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a double value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateDouble(String columnName, double val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a BigDecimal value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 * @deprecated
	 */
	public void updateBigDecimal(String columnName, BigDecimal val)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a String value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateString(String columnName, String val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a byte array value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateBytes(String columnName, byte val[]) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a Date value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateDate(String columnName, java.sql.Date val)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a Time value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateTime(String columnName, java.sql.Time val)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a Timestamp value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateTimestamp(String columnName, java.sql.Timestamp val)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with an ascii stream value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @param length
	 *            of the stream
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateAsciiStream(String columnName, java.io.InputStream val,
			int length) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a binary stream value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @param length
	 *            of the stream
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateBinaryStream(String columnName, java.io.InputStream val,
			int length) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with a character stream value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @param length
	 *            of the stream
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateCharacterStream(String columnName, java.io.Reader reader,
			int length) throws SQLException {
		throw new UnsupportedOperationException();
	}

	// Added by Balaji K for JDK1.4 Compatibility;
	// moved here from PWiResultSet by Hasso P

	public void updateArray(int columnIndex, java.sql.Array val)
			throws SQLException {
		/** @todo: Implement this java.sql.ResultSet method */
		throw new UnsupportedOperationException(
				"Method updateArray(int columnIndex, java.sql.Array val) not yet implemented.");
	}

	public void updateArray(String columnName, java.sql.Array val) {
		/** @todo: Implement this java.sql.ResultSet method */
		throw new UnsupportedOperationException(
				"Method updateArray(String columnName, Array val) not yet implemented.");
	}

	public java.net.URL getURL(int columnIndex) throws SQLException {
		/** @todo: Implement this java.sql.ResultSet method */
		throw new UnsupportedOperationException(
				"Method getURL(int columnIndex) not yet implemented.");
	}

	public java.net.URL getURL(String columnName) throws SQLException {
		/** @todo: Implement this java.sql.ResultSet method */
		throw new UnsupportedOperationException(
				"Method getURL(String columnName) not yet implemented.");
	}

	public void updateRef(int columnIndex, java.sql.Ref val) {
		/** @todo: Implement this java.sql.ResultSet method */
		throw new UnsupportedOperationException(
				"Method updateRef(int columnIndex, java.sql.Ref val) not yet implemented.");
	}

	public void updateRef(String columnName, java.sql.Ref val)
			throws SQLException {
		/** @todo: Implement this java.sql.ResultSet method */
		throw new UnsupportedOperationException(
				"Method updateRef(String columnName, java.sql.Ref val) not yet implemented.");
	}

	public void updateClob(int columnIndex, java.sql.Clob val)
			throws SQLException {
		/** @todo: Implement this java.sql.ResultSet method */
		throw new UnsupportedOperationException(
				"Method updateClob(int columnIndex, java.sql.Clob val) not yet implemented.");
	}

	public void updateClob(String columnName, java.sql.Clob val)
			throws SQLException {
		/** @todo: Implement this java.sql.ResultSet method */
		throw new UnsupportedOperationException(
				"Method updateClob(String columnName, java.sql.Clob val) not yet implemented.");
	}

	public void updateBlob(int columnIndex, java.sql.Blob val)
			throws SQLException {
		/** @todo: Implement this java.sql.ResultSet method */
		throw new UnsupportedOperationException(
				"Method updateBlob(int columnIndex, java.sql.Blob val) not yet implemented.");
	}

	public void updateBlob(String columnName, java.sql.Blob val)
			throws SQLException {
		/** @todo: Implement this java.sql.ResultSet method */
		throw new UnsupportedOperationException(
				"Method updateArray(int columnIndex, java.sql.Array val) not yet implemented.");
	}
	
	/**
	 * JDBC 2.0
	 * 
	 * Update a column with an Object value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @param scale
	 *            For java.sql.Types.DECIMAL or java.sql.Types.NUMERIC types
	 *            this is the number of digits after the decimal. For all other
	 *            types this value will be ignored.
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateObject(String columnName, Object val, int scale)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update a column with an Object value.
	 * 
	 * The updateXXX() methods are used to update column values in the current
	 * row, or the insert row. The updateXXX() methods do not update the
	 * underlying database, instead the updateRow() or insertRow() methods are
	 * called to update the database.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @param val
	 *            the new column value
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public void updateObject(String columnName, Object val) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Insert the contents of the insert row into the result set and the
	 * database. Must be on the insert row when this method is called.
	 * 
	 * @exception SQLException
	 *                if a database-access error occurs, if called when not on
	 *                the insert row, or if all non-nullable columns in the
	 *                insert row have not been given a value
	 */
	public void insertRow() throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Update the underlying database with the new contents of the current row.
	 * Cannot be called when on the insert row.
	 * 
	 * @exception SQLException
	 *                if a database-access error occurs, or if called when on
	 *                the insert row
	 */
	public void updateRow() throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Delete the current row from the result set only. The method does
	 * <B>NOT</B> delete the row from underlying database.
	 * 
	 * @exception SQLException
	 *                if a database-access error occurs, or if called when on
	 *                the insert row.
	 */
	public void deleteRow() throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Refresh the value of the current row with its current value in the
	 * database. Cannot be called when on the insert row.
	 * 
	 * The refreshRow() method provides a way for an application to explicitly
	 * tell the JDBC driver to refetch a row(s) from the database. An
	 * application may want to call refreshRow() when caching or prefetching is
	 * being done by the JDBC driver to fetch the latest value of a row from the
	 * database. The JDBC driver may actually refresh multiple rows at once if
	 * the fetch size is greater than one.
	 * 
	 * All values are refetched subject to the transaction isolation level and
	 * cursor sensitivity. If refreshRow() is called after calling updateXXX(),
	 * but before calling updateRow() then the updates made to the row are lost.
	 * Calling refreshRow() frequently will likely slow performance.
	 * 
	 * @exception SQLException
	 *                if a database-access error occurs, or if called when on
	 *                the insert row.
	 */
	public void refreshRow() throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * The cancelRowUpdates() method may be called after calling an updateXXX()
	 * method(s) and before calling updateRow() to rollback the updates made to
	 * a row. If no updates have been made or updateRow() has already been
	 * called, then this method has no effect.
	 * 
	 * @exception SQLException
	 *                if a database-access error occurs, or if called when on
	 *                the insert row.
	 * 
	 */
	public void cancelRowUpdates() throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Move to the insert row. The current cursor position is remembered while
	 * the cursor is positioned on the insert row.
	 * 
	 * The insert row is a special row associated with an updatable result set.
	 * It is essentially a buffer where a new row may be constructed by calling
	 * the updateXXX() methods prior to inserting the row into the result set.
	 * 
	 * Only the updateXXX(), getXXX(), and insertRow() methods may be called
	 * when the cursor is on the insert row. All of the columns in a result set
	 * must be given a value each time this method is called before calling
	 * insertRow(). UpdateXXX()must be called before getXXX() on a column.
	 * 
	 * @exception SQLException
	 *                if a database-access error occurs, or the result set is
	 *                not updatable
	 */
	public void moveToInsertRow() throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Move the cursor to the remembered cursor position, usually the current
	 * row. Has no effect unless the cursor is on the insert row.
	 * 
	 * @exception SQLException
	 *                if a database-access error occurs, or the result set is
	 *                not updatable
	 */
	public void moveToCurrentRow() throws SQLException {
	}

	/**
	 * JDBC 2.0
	 * 
	 * Return the Statement that produced the ResultSet.
	 * 
	 * @return the Statment that produced the result set, or null if the result
	 *         was produced some other way.
	 * @exception SQLException
	 *                if a database-access error occurs
	 */
	public java.sql.Statement getStatement() throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Returns the value of column @idx as a Java object. Use the
	 * 
	 * @map to determine the class from which to construct data of SQL
	 *      structured and distinct types.
	 * 
	 * @param idx
	 *            the first column is 1, the second is 2, ...
	 * @param map
	 *            the mapping from SQL type names to Java classes
	 * @return an object representing the SQL value
	 */
	public Object getObject(int idx, java.util.Map<String, Class<?>> map)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Get a REF(&lt;structured-type&gt;) column.
	 * 
	 * @param idx
	 *            the first column is 1, the second is 2, ...
	 * @return an object representing data of an SQL REF type
	 */
	public java.sql.Ref getRef(int idx) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Get a BLOB column.
	 * 
	 * @param idx
	 *            the first column is 1, the second is 2, ...
	 * @return an object representing a BLOB
	 */
	public java.sql.Blob getBlob(int idx) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Get a CLOB column.
	 * 
	 * @param idx
	 *            the first column is 1, the second is 2, ...
	 * @return an object representing a CLOB
	 */
	public java.sql.Clob getClob(int idx) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Get an array column.
	 * 
	 * @param idx
	 *            the first column is 1, the second is 2, ...
	 * @return an object representing an SQL array
	 */
	public java.sql.Array getArray(int idx) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Returns the value of column @idx as a Java object. Use the
	 * 
	 * @map to determine the class from which to construct data of SQL
	 *      structured and distinct types.
	 * 
	 * @param colName
	 *            the column name
	 * @param map
	 *            the mapping from SQL type names to Java classes
	 * @return an object representing the SQL value
	 */
	public Object getObject(String colName, java.util.Map<String, Class<?>> map)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Get a REF(&lt;structured-type&gt;) column.
	 * 
	 * @param colName
	 *            the column name
	 * @return an object representing data of an SQL REF type
	 */
	public java.sql.Ref getRef(String colName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Get a BLOB column.
	 * 
	 * @param colName
	 *            the column name
	 * @return an object representing a BLOB
	 */
	public java.sql.Blob getBlob(String colName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Get a CLOB column.
	 * 
	 * @param colName
	 *            the column name
	 * @return an object representing a CLOB
	 */
	public java.sql.Clob getClob(String colName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Get an array column.
	 * 
	 * @param colName
	 *            the column name
	 * @return an object representing an SQL array
	 */
	public java.sql.Array getArray(String colName) throws SQLException {
		throw new UnsupportedOperationException();
	}

	/**
	 * JDBC 2.0
	 * 
	 * Get the value of a column in the current row as a java.sql.Date object.
	 * Use the calendar to construct an appropriate millisecond value for the
	 * Date, if the underlying database doesn't store timezone information.
	 * 
	 * @param columnIndex
	 *            the first column is 1, the second is 2, ...
	 * @param cal
	 *            the calendar to use in constructing the date
	 * @return the column value; if the value is SQL NULL, the result is null
	 * @exception SQLException
	 *                if a database-access error occurs.
	 */
	public java.sql.Date getDate(int columnIndex, java.util.Calendar cal)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	public java.sql.Time getTime(int col, java.util.Calendar cal)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	public java.sql.Time getTime(String col, java.util.Calendar cal)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	public java.sql.Date getDate(String col, java.util.Calendar cal)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	public java.sql.Timestamp getTimestamp(int col, java.util.Calendar cal)
			throws SQLException {
		throw new UnsupportedOperationException();
	}

	public java.sql.Timestamp getTimestamp(String col, java.util.Calendar cal)
			throws SQLException {
		throw new UnsupportedOperationException();
	}
	// #endif
}
