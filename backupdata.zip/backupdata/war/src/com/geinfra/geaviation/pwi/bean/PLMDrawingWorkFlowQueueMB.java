/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMDrawingWorkFlowQueueMB.java
 * @Creation date: 18-Oct-2010
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.data.PLMDrawingSearchData;
import com.geinfra.geaviation.pwi.service.PLMSearchServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptColumn;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil;
import com.geinfra.geaviation.pwi.util.PLMXlsxRptUtil.FormatType;

/**
 * PLMDrawingWorkFlowQueueMB is the managed bean class .
 */
public class PLMDrawingWorkFlowQueueMB extends PLMDrawingSearchData {
	/**
	 * Holds the plmSearchService
	 */
	private PLMSearchServiceIfc plmSearchService = null;
	/**
	 * Holds the searchResultList
	 */
	private List<PLMDrawingSearchData> searchResultList;
	/**
	 * Holds the searchDetails
	 */
	private PLMDrawingSearchData searchDetails = new PLMDrawingSearchData();
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB =null;
	/**
	 * Holds the count
	 */
	private int count;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the totalRecCountMsg
	 */
	private String totalRecCountMsg;
	/**
	 * Holds the fieldName
	 */
	private String fieldName;
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the rdoListData
	 */
	private List<SelectItem> rdoListData;
	/**
	 * Holds the itemTypeData
	 */
	private List<SelectItem> itemTypeLstData;
	/**
	 * Holds the itemTypeData
	 */
	private List<SelectItem>  approveStLstData;
	/**
	 * Holds the enabletskCmplt
	 */
	private boolean  enabletskCmplt;

	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger
			.getLogger(PLMDrawingWorkFlowQueueMB.class);

	/**
	 * This method is used for Load Drawing Search
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String loadDrawingSearch() throws PLMCommonException {
		String fwdFlag = "";
		alertMessage = "";
		enabletskCmplt=false;
		searchDetails = new PLMDrawingSearchData();
		commonMB.insertCannedRptRecordHitInfo("Task Affected Items");
		
		Map<String, List<SelectItem>> getSelectedMapLst = plmSearchService.displaySelectedItems();
		rdoListData = (List<SelectItem>) getSelectedMapLst.get("rdoList");
		itemTypeLstData = (List<SelectItem>) getSelectedMapLst.get("itemTypeList");
		approveStLstData = (List<SelectItem>) getSelectedMapLst.get("approveStsList");
		fwdFlag = "drawing";
		/*try {
			commonMB.getPLMDateStamp(PLMConstants.ECO_TABLE);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPLMDateStamp: ", exception);
			}*/
		return fwdFlag;
	}
	
	public String backToDwgSearch() {
		
		if(!PLMUtils.isEmptyList(searchResultList))
			searchResultList.clear();
		
		return "drawing";
		
	}
	
	/**
	 * This method is used for disable date pickers of Task Completion
	 * 
	 */
	public void disableTaskCompleteDt(ActionEvent ae) {
		LOG.info("Entering disableTaskCompleteDt method");
		if(searchDetails.isCheckIboxTsk()){
			enabletskCmplt=true;
			searchDetails.setTaskCompltFrmDt(null);
			searchDetails.setTaskCompltFrmDt(null);
		}else{
			enabletskCmplt=false;
		}
		
		LOG.info("Exiting disableTaskCompleteDt method");
	}
	
	public void recordsPerPageListner(ActionEvent event) {
		LOG.info("Entering recordsPerPageListner method");
		LOG.info("Action listner called.....--------------------------->"
				+ recordCounts);
		if (recordCounts == 15) {
			LOG.info("15");
			recordCounts = 15;
		} else if (recordCounts == 30) {
			LOG.info("30");
			recordCounts = 30;
		} else if (recordCounts == 50) {
			LOG.info("50");
			recordCounts = 50;
		} else if (recordCounts == 100) {
			LOG.info("100");
			recordCounts = 100;
		} else if (recordCounts == 200) {
			LOG.info("200");
			recordCounts = 200;
		}


		LOG.info("final value.....--------------------------->" + recordCounts);
	}

	/**
	 * This method is used for Load Drawing Data
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getDrawingData() {
		String fwdFlag = "";
		totalRecCount = 0;
		alertMessage="";

		LOG.info("plmDrawingService...." + plmSearchService);
		
		if (PLMUtils.isEmpty(searchDetails.getTask_owner())
				&& searchDetails.getRdoNamesList().size() ==0
				&& PLMUtils.isEmpty(searchDetails.getAssignee())
				&& PLMUtils.isEmpty(searchDetails.getAssigneeManager())
				&& searchDetails.getItemTypeList().size() ==0
				&& searchDetails.getApproveStList().size() ==0
				&&  PLMUtils.isEmptyDate(searchDetails.getRouteCrtFrmDt())
				&&  PLMUtils.isEmptyDate(searchDetails.getRouteCrtToDt())
				&&  PLMUtils.isEmptyDate(searchDetails.getTaskCompltFrmDt())
				&&  PLMUtils.isEmptyDate(searchDetails.getTaskCompltToDt())
				&&  !searchDetails.isCheckIboxTsk()) {
			alertMessage = PLMConstants.ANY_SRCH_CRIT;
		}else if((!PLMUtils.isEmptyDate(searchDetails.getRouteCrtFrmDt())
			      && PLMUtils.isEmptyDate(searchDetails.getRouteCrtToDt()))
			      ||(PLMUtils.isEmptyDate(searchDetails.getRouteCrtFrmDt())
					      && !PLMUtils.isEmptyDate(searchDetails.getRouteCrtToDt())))
			   {
			alertMessage = PLMConstants.VALID_ROUTE_CREATEION_DT;
		 }
		else if((!PLMUtils.isEmptyDate(searchDetails.getTaskCompltFrmDt())
			      && PLMUtils.isEmptyDate(searchDetails.getTaskCompltToDt()))
			      ||(PLMUtils.isEmptyDate(searchDetails.getTaskCompltFrmDt())
					      && !PLMUtils.isEmptyDate(searchDetails.getTaskCompltToDt()))){
				alertMessage = PLMConstants.VALID_TASK_COMPLETION_DT;
		 }
		else if (PLMUtils.checkForFromAndToDate(searchDetails.getRouteCrtFrmDt(),searchDetails.getRouteCrtToDt())
				|| PLMUtils.checkForFromAndToDate(searchDetails.getTaskCompltFrmDt(),searchDetails.getTaskCompltToDt())) {
				alertMessage =  PLMConstants.WHERE_USED_DATE;
		}else {
			String ownerWithOutAsterisk = null;
			if (!PLMUtils.isEmpty(searchDetails.getTask_owner())) {
				ownerWithOutAsterisk = PLMUtils.removeAsteriskAndSpaceFromSSOFields(searchDetails.getTask_owner());
			}
			if (!PLMUtils.checkForSpecialChars(searchDetails.getTask_owner())) {
				alertMessage = alertMessage + PLMConstants.TaskOwnerSpecialChar_Val;
				fwdFlag = "drawing";
			} else if(PLMUtils.isInteger(ownerWithOutAsterisk)) {
				if(ownerWithOutAsterisk.length() != 9)
					alertMessage = alertMessage + PLMConstants.OWNER_DIGT_MESSAGE;
				fwdFlag = "drawing";
			}
			/*if (!PLMUtils.checkForSpecialChars(searchDetails.getRdo_ownership())) {
				alertMessage = alertMessage + PLMConstants.RdoSpecialChar_Val;
				fwdFlag = "drawing";
			}*/
			if (!PLMUtils.checkForSpecialChars(searchDetails
					.getAssignee())) {
				alertMessage = alertMessage + PLMConstants.TaskAssigneeSpecialChar_Val;
				fwdFlag = "drawing";				
			} else {
				String assignee = searchDetails.getAssignee();
				StringTokenizer tokens = new StringTokenizer(assignee, ",");
				boolean validAssignee = true;
				
				while (tokens.hasMoreTokens()) {
					String assigneeValue = tokens.nextToken();
					String assigneeWithOutAsterisk = PLMUtils.removeAsteriskAndSpaceFromSSOFields(assigneeValue);
					if (PLMUtils.isInteger(assigneeWithOutAsterisk)) {
						if (assigneeWithOutAsterisk.length() != 9) {
							validAssignee = false;
						}
					}
				}
				if (!validAssignee) {
					alertMessage = alertMessage
					+ PLMConstants.TaskAssignee_SSOVal;
				}
			}
			if (!PLMUtils.checkForSpecialChars(searchDetails
					.getAssigneeManager())) {
				alertMessage = alertMessage + PLMConstants.TaskAssigneeManagerSpecialChar_Val;
				fwdFlag = "drawing";
			} else {
				String assigneeManager = searchDetails.getAssigneeManager();
				StringTokenizer tokensForManager = new StringTokenizer(assigneeManager, ",");
				boolean validAssigneeManager = true;
				
				while (tokensForManager.hasMoreTokens()) {
					String assigneeManagerValue = tokensForManager.nextToken();
					String assigneeMgrWithOutAsterisk = PLMUtils.removeAsteriskAndSpaceFromSSOFields(assigneeManagerValue);
					if (PLMUtils.isInteger(assigneeMgrWithOutAsterisk)) {
						if (assigneeMgrWithOutAsterisk.length() != 9) {
							validAssigneeManager = false;
						}
					}
				}
				if (!validAssigneeManager) {
					alertMessage = alertMessage
					+ PLMConstants.TaskAssigneeManager_SSOVal;
				}
			}
		}
		
		
		if (PLMUtils.isEmpty(alertMessage)) {
			try {
				searchResultList = plmSearchService.getDrawingData(searchDetails);
				if (searchResultList != null) {
					totalRecCount = searchResultList.size();
				} else {
					totalRecCount = 0;
				}
				totalRecCountMsg = "Total Results Count : " + totalRecCount;
				LOG.info("totalRecCount::::::::::::::::::" + totalRecCount);
				if (totalRecCount == 0) {
					LOG.info("I am in if condition");
					fwdFlag = "drawingnorecords";
				} else {				
					recordCounts = PLMConstants.N_100;
					fwdFlag = "drawingsearchresult";
				}
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@getDrawingData: ", exception);
				fwdFlag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"drawing","Drawings-WorkFlow Queue");
			}
		}
		return fwdFlag;
	}

	/**
	 * This method is used for resetDrawingSearchData
	 * 
	 * @return String
	 * 
	 */
	public String resetDrawingSearchData() {
		String fwdFlag = "drawing";
		searchDetails = new PLMDrawingSearchData();
		if (searchDetails.getTask_owner() != null) {
			searchDetails.setTask_owner("");
		}
		if (searchDetails.getRdo_ownership() != null) {
			searchDetails.setRdo_ownership("");
		}
		if (searchDetails.getAssignee() != null) {
			searchDetails.setAssignee("");
		}
		if (searchDetails.getAssigneeManager() != null) {
			searchDetails.setAssigneeManager("");
		}
		enabletskCmplt=false;
		return fwdFlag;
	}

	/**
	 * @param value
	 *            .
	 * @return String
	 */
	public String getTrimValue(String value) {
		String retStr = null;
		if (!PLMUtils.isEmpty(value)) {
			retStr = value.trim();
		}
		return retStr;

	}
	/**
	 * @param recordCounts the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		LOG.info("::::::::::::::::::" + recordCounts);
		PLMUtils.getServletSession(true).setAttribute("RecDropDown",
				recordCounts);
		this.recordCounts = recordCounts;
	}
	

	public void downloadExcel() throws PLMCommonException {

		LOG.info("Entering downloadExcel Method");
		String reportName = "drawingsworkexcel";
		String fileName = "Task Affected Items";
		LOG.info("reportName>>> " + reportName);
		LOG.info("fileName>>> " + fileName);

		PLMXlsxRptUtil excelUtil = new PLMXlsxRptUtil();

		PLMXlsxRptColumn[] reportColumns =
						new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("taskName", "Task Name", FormatType.TEXT),
						new PLMXlsxRptColumn("approvalStatus", "Approval Status", FormatType.TEXT),
						new PLMXlsxRptColumn("routeTskCrtDtExl", "Route Creation Date", FormatType.DATE),
						new PLMXlsxRptColumn("taskComments", "Task Comments", FormatType.TEXT),
						new PLMXlsxRptColumn("routeOwner", "Route Owner", FormatType.TEXT),
						new PLMXlsxRptColumn("routeOwnerName", "Route Owner Name", FormatType.TEXT, null, null, 27),
						new PLMXlsxRptColumn("taskOwner", "Task Owner", FormatType.TEXT),
						new PLMXlsxRptColumn("taskOwnerNm", "Task Owner Name", FormatType.TEXT, null, null, 27),
						new PLMXlsxRptColumn("taskAssign", "Task Assignee", FormatType.TEXT),
						new PLMXlsxRptColumn("taskAssignNm", "Task Assignee Name", FormatType.TEXT, null, null, 27),
						new PLMXlsxRptColumn("taskAssignMngr", "Task Assign Manager", FormatType.TEXT),
						new PLMXlsxRptColumn("taskAssignMngrNm", "Task Assign Manager Name", FormatType.TEXT, null, null, 27),
						new PLMXlsxRptColumn("scheduleDtExl", "Schedule Date", FormatType.DATE),
						new PLMXlsxRptColumn("completeDtExl", "Completion Date", FormatType.DATE),
						new PLMXlsxRptColumn("affectedNm", "Affected Item Name", FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("affectedType", "Affected Item Type", FormatType.TEXT, null, null, 30),
						new PLMXlsxRptColumn("affectedRev", "Affected Item Rev", FormatType.TEXT, null, null, 9),
						new PLMXlsxRptColumn("relEcoPolicy", "Related ECO Policy", FormatType.TEXT, null, null, 13),
						new PLMXlsxRptColumn("relDwgEco", "Related ECO", FormatType.TEXT),
						new PLMXlsxRptColumn("ecoDesc", "ECO Description", FormatType.TEXT, null, null, 50),
						new PLMXlsxRptColumn("ecoLfCycleSt", "ECO Life Cycle State", FormatType.TEXT),
						new PLMXlsxRptColumn("rdo", "RDO", FormatType.TEXT, null, null, 20),
						new PLMXlsxRptColumn("ecoRelDtExl", "ECO Release Date", FormatType.DATE)


				};


		PLMXlsxRptColumn[] critcolumns =
						new PLMXlsxRptColumn[] {new PLMXlsxRptColumn("task_owner", "Task By Owner", FormatType.TEXT),
								new PLMXlsxRptColumn("rdoNamesList", "RDO Ownership Of DPO", FormatType.TEXT),
								new PLMXlsxRptColumn("assignee", "Task Assignee", FormatType.TEXT),
								new PLMXlsxRptColumn("assigneeManager", "Task Assignee Manager", FormatType.TEXT),
								new PLMXlsxRptColumn("itemTypeList", "Affected Item Type", FormatType.TEXT),
								new PLMXlsxRptColumn("approveStList", "Approve Status", FormatType.TEXT)

						};

		excelUtil.export(searchResultList, reportColumns, fileName, fileName, true, critcolumns, searchDetails);
	
	} 	
	
	public void downloadCSV() throws PLMCommonException {
		LOG.info("Entering downloadCSV Method");
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();
		SimpleDateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
		
		
		PLMCsvRptColumn[] reportColumns =
						new PLMCsvRptColumn[] {new PLMCsvRptColumn("taskName", "Task Name", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("approvalStatus", "Approval Status", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("routeTskCrtDt", "Route Creation Date", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("taskComments", "Task Comments", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("routeOwner", "Route Owner", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("routeOwnerName", "Route Owner Name", FormatTypeCsv.TEXT, null, null, 27),
						new PLMCsvRptColumn("taskOwner", "Task Owner", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("taskOwnerNm", "Task Owner Name", FormatTypeCsv.TEXT, null, null, 27),
						new PLMCsvRptColumn("taskAssign", "Task Assignee", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("taskAssignNm", "Task Assignee Name", FormatTypeCsv.TEXT, null, null, 27),
						new PLMCsvRptColumn("taskAssignMngr", "Task Assign Manager", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("taskAssignMngrNm", "Task Assign Manager Name", FormatTypeCsv.TEXT, null, null, 27),
						new PLMCsvRptColumn("scheduleDt", "Schedule Date", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("completeDt", "Completion Date", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("affectedNm", "Affected Item Name", FormatTypeCsv.TEXT, null, null, 20),
						new PLMCsvRptColumn("affectedType", "Affected Item Type", FormatTypeCsv.TEXT, null, null, 30),
						new PLMCsvRptColumn("affectedRev", "Affected Item Rev", FormatTypeCsv.TEXT, null, null, 9),
						new PLMCsvRptColumn("relEcoPolicy", "Related ECO Policy", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("relDwgEco", "Related ECO", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("ecoDesc", "ECO Description", FormatTypeCsv.TEXT, null, null, 50),
						new PLMCsvRptColumn("ecoLfCycleSt", "ECO Life Cycle State", FormatTypeCsv.TEXT),
						new PLMCsvRptColumn("rdo", "RDO", FormatTypeCsv.TEXT, null, null, 20),
						new PLMCsvRptColumn("ecoRelDt", "ECO Release Date", FormatTypeCsv.TEXT)

				};

		csvUtil.exportCsv(searchResultList, reportColumns, "Task Affected Items", dateFormat, false, null, null, ",");
		
		
		
		/*  PrintWriter pwriter = null;
		try {
			FacesContext facesContext = FacesContext.getCurrentInstance();
			HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
			  response.setHeader("content-disposition","attachment; filename=taskAffectedItems.csv");
			  response.setContentType("application/CSV");
			  pwriter = response.getWriter();
			   
	  			pwriter.write("Task Name");
	  			pwriter.write(",");
	   			pwriter.write("Approval Status");
	  			pwriter.write(",");
	  			pwriter.write("Route Creation Date");
	  			pwriter.write(",");
	  			pwriter.write("Task Comments");
	  			pwriter.write(",");
	  			pwriter.write("Task Start Date");
	  			pwriter.write(",");
	  			pwriter.write("Task Owner");
	  			pwriter.write(",");
	  			pwriter.write("Task Owner Name");
	  			pwriter.write(",");
	  			pwriter.write("Task Assignee");
	  			pwriter.write(",");
	  			pwriter.write("Task Assignee Name");
	  			pwriter.write(",");
	  			pwriter.write("Task Assign Manager");
	  			pwriter.write(",");
	  			pwriter.write("Task Assign Manager Name");
	  			pwriter.write(",");
	  			pwriter.write("Schedule Date");
	  			pwriter.write(",");
	  			pwriter.write("Completion Date");
	  			pwriter.write(",");
	  			pwriter.write("Affected Item Name");
	  			pwriter.write(",");
	  			pwriter.write("Affected Item Type");
	  			pwriter.write(",");
	  			pwriter.write("Affected Item Rev");
	  			pwriter.write(",");
	  			pwriter.write("Related ECO");
	  			pwriter.write(",");
	  			pwriter.write("ECO Description");
	  			pwriter.write(",");
	  			pwriter.write("ECO Life Cycle State");
	  			pwriter.write(",");
	  			pwriter.write("RDO");
	  			pwriter.write("\n");
	  			
		   		for(int i=0; i<searchResultList.size(); i++) {
		   			PLMDrawingSearchData dataObj = (PLMDrawingSearchData)searchResultList.get(i);
		   			
		   			if(dataObj.getTaskName()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTaskName()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getApprovalStatus()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getApprovalStatus()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getRouteTskCrtDt()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRouteTskCrtDt()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getTaskComments()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTaskComments()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getTaskOwner()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTaskOwner()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getTaskOwnerNm()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTaskOwnerNm()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getTaskAssign()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTaskAssign()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getTaskAssignNm()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTaskAssignNm()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getTaskAssignMngr()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTaskAssignMngr()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getTaskAssignMngrNm()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getTaskAssignMngrNm()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getScheduleDt()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getScheduleDt()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getCompleteDt()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getCompleteDt()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getAffectedNm()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getAffectedNm()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getAffectedType()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getAffectedType()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getAffectedRev()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getAffectedRev()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getRelDwgEco()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRelDwgEco()));
			   		 }
			   		 pwriter.write(",");
			   		if(dataObj.getEcoDesc()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoDesc()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getEcoLfCycleSt()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getEcoLfCycleSt()));
			   		 }
			   		 pwriter.write(",");
		   			if(dataObj.getRdo()!= null){
			   			pwriter.write(PLMUtils.convertToCsvValue(dataObj.getRdo()));
			   		 }
		   			pwriter.write("\n");
		   		}
		   		pwriter.flush();
		 } catch (FileNotFoundException e) {
			   System.out.println("the exception is---" + e);
			  } catch (Exception e1) {
				  System.out.println("IOException " + e1.getMessage());
			  } finally {
			   try {
			    if (pwriter != null) {
			    	pwriter.close();
			    }
			   } catch (Exception exc) {
			    exc.printStackTrace();
			   }
			  
			  }*/
		LOG.info("Exiting downloadCSV Method");
	} 	


	/**
	 * @return the plmSearchService
	 */
	public PLMSearchServiceIfc getPlmSearchService() {
		return plmSearchService;
	}

	/**
	 * @param plmSearchService
	 *            the plmSearchService to set
	 */
	public void setPlmSearchService(PLMSearchServiceIfc plmSearchService) {
		this.plmSearchService = plmSearchService;
	}

	/**
	 * @return the searchResultList
	 */
	public List<PLMDrawingSearchData> getSearchResultList() {
		return searchResultList;
	}

	/**
	 * @param searchResultList
	 *            the searchResultList to set
	 */
	public void setSearchResultList(List<PLMDrawingSearchData> searchResultList) {
		this.searchResultList = searchResultList;
	}

	/**
	 * @return the searchDetails
	 */
	public PLMDrawingSearchData getSearchDetails() {
		return searchDetails;
	}

	/**
	 * @param searchDetails
	 *            the searchDetails to set
	 */
	public void setSearchDetails(PLMDrawingSearchData searchDetails) {
		this.searchDetails = searchDetails;
	}

	/**
	 * @return the count
	 */
	public int getCount() {
		return count;
	}

	/**
	 * @param count
	 *            the count to set
	 */
	public void setCount(int count) {
		this.count = count;
	}

	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount
	 *            the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/**
	 * @return the totalRecCountMsg
	 */
	public String getTotalRecCountMsg() {
		return totalRecCountMsg;
	}

	/**
	 * @param totalRecCountMsg
	 *            the totalRecCountMsg to set
	 */
	public void setTotalRecCountMsg(String totalRecCountMsg) {
		this.totalRecCountMsg = totalRecCountMsg;
	}

	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * @param fieldName
	 *            the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}

	/**
	 * @param alertMessage
	 *            the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the rdoListData
	 */
	public List<SelectItem> getRdoListData() {
		return rdoListData;
	}

	/**
	 * @param rdoListData the rdoListData to set
	 */
	public void setRdoListData(List<SelectItem> rdoListData) {
		this.rdoListData = rdoListData;
	}

	/**
	 * @return the itemTypeLstData
	 */
	public List<SelectItem> getItemTypeLstData() {
		return itemTypeLstData;
	}

	/**
	 * @param itemTypeLstData the itemTypeLstData to set
	 */
	public void setItemTypeLstData(List<SelectItem> itemTypeLstData) {
		this.itemTypeLstData = itemTypeLstData;
	}

	/**
	 * @return the approveStLstData
	 */
	public List<SelectItem> getApproveStLstData() {
		return approveStLstData;
	}

	/**
	 * @param approveStLstData the approveStLstData to set
	 */
	public void setApproveStLstData(List<SelectItem> approveStLstData) {
		this.approveStLstData = approveStLstData;
	}
	
	/**
	 * @return the enabletskCmplt
	 */
	public boolean isEnabletskCmplt() {
		return enabletskCmplt;
	}

	/**
	 * @param enabletskCmplt the enabletskCmplt to set
	 */
	public void setEnabletskCmplt(boolean enabletskCmplt) {
		this.enabletskCmplt = enabletskCmplt;
	}

}
// Ended by Shravan 