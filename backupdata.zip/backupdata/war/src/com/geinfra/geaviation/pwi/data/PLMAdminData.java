/**
 * Copyright (C) 2014 GE Infra.  
 * All rights reserved 
 * @FileName PLMAdminData.java
 * @Creation date: 17-Jul-2009
 * @version 1.0
 * * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

/**
 * ICMAdminData is the Transfer/Value Object class used for ICM Administrator
 * Menu.
 */
public class PLMAdminData {
	/**
	 * Holds the Param for gruopId
	 */
	private String gruopId;
	/**
	 * Holds the Param for groupName
	 */
	private String groupName;
	/**
	 * Holds the Param for groupDescription
	 */
	private String groupDescription;
	/**
	 * Holds the Param for reportName
	 */
	private String reportName;
	/**
	 * Holds the Param for reportURL
	 */
	private String reportURL;
	/**
	 * Holds the Param for description
	 */
	private String description;
	/**
	 *  Holds the Param for screenId
	 */
	private int screenId;
	/**
	 * Holds the Param for permissionId
	 */
	private int permissionId;
	/**
	 * Holds the Param for accessInd
	 */
	private String accessInd;
	/**
	 * Holds the Param for screenName
	 */
	private String screenName;
	/**
	 * Holds the Param for permissionName
	 */
	private String permissionName;

	/**
	 * @return the screenName
	 */
	public String getScreenName() {
		return screenName;
	}

	/**
	 * @param screenName
	 * the screenName to set
	 */
	public void setScreenName(String screenNamea) {
		this.screenName = screenNamea;
	}

	/**
	 * @return the permissionName
	 */
	public String getPermissionName() {
		return permissionName;
	}

	/**
	 * @param permissionName
	 *            the permissionName to set
	 */
	public void setPermissionName(String permissionNamea) {
		this.permissionName = permissionNamea;
	}

	/**
	 * @return the screenID
	 */
	public int getScreenId() {
		return screenId;
	}

	/**
	 * @param screenID
	 *            the screenID to set
	 */
	public void setScreenId(int screenID1) {
		this.screenId = screenID1;
	}

	/**
	 * @return the permissionId
	 */
	public int getPermissionId() {
		return permissionId;
	}

	/**
	 * @param permissionID
	 *            the permissionId to set
	 */
	public void setPermissionId(int permissionId1) {
		this.permissionId = permissionId1;
	}

	/**
	 * @return the accessInd
	 */
	public String getAccessInd() {
		return accessInd;
	}

	/**
	 * @param accessInd
	 *            the accessInd to set
	 */
	public void setAccessInd(String accessInda) {
		this.accessInd = accessInda;
	}

	/**
	 * @return the gruopId
	 */
	public String getGruopId() {
		return gruopId;
	}

	/**
	 * @param gruopId
	 *            the gruopId to set
	 */
	public void setGruopId(String gruopIda) {
		this.gruopId = gruopIda;
	}

	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * @param groupName
	 *            the groupName to set
	 */
	public void setGroupName(String groupNamea) {
		this.groupName = groupNamea;
	}

	/**
	 * @return the groupDescription
	 */
	public String getGroupDescription() {
		return groupDescription;
	}

	/**
	 * @param groupDescription
	 *            the groupDescription to set
	 */
	public void setGroupDescription(String groupDescriptiona) {
		this.groupDescription = groupDescriptiona;
	}

	/**
	 * @return the reportName
	 */
	public String getReportName() {
		return reportName;
	}

	/**
	 * @param reportName the reportName to set
	 */
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	/**
	 * @return the reportURL
	 */
	public String getReportURL() {
		return reportURL;
	}

	/**
	 * @param reportURL the reportURL to set
	 */
	public void setReportURL(String reportURL) {
		this.reportURL = reportURL;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

}
