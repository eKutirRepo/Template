 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMEccnMB.java
 * @Creation date: 16-Jul-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.model.SelectItem;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMTaskSearchData;
import com.geinfra.geaviation.pwi.service.PLMkpiReportServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMCsvRptColumn;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil;
import com.geinfra.geaviation.pwi.util.PLMCsvRptUtil.FormatTypeCsv;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMEccnMB {
	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMEccnMB.class);
	/**
	 * Holds the plmIssuesService
	 */
	private PLMkpiReportServiceIfc plmIssuesService = null;
	/**
	 * Holds the loginMB
	 */
	private PLMCommonMB commonMB=null;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_100;
	/**
	 * Holds the eccnTagList
	 */
	private List<String> eccnTagList = new ArrayList<String>();
	/**
	 * Holds the rdoNamesList
	 */
	private List<String> rdoNamesList= new ArrayList<String>();
	/**
	 * Holds the rdoListData
	 */
	private List<SelectItem> rdoListData;
	/**
	 * Holds the eccnListData
	 */
	private List<SelectItem> eccnListData;
	/**
	 * Holds the reportType
	 */
	private String reportType="";
	/**
	 * Holds the eccnResultList
	 */
	private List<PLMTaskSearchData> eccnResultList;

	/**
	 * Holds the ntotalEccnCount
	 */
	private int ntotalEccnCount;
	/**
	 * Holds the ntotalEccnCountMsg
	 */
	private String ntotalEccnCountMsg;
			
	/**
	 * The String alertStr
	 */
	private String alertStr;
	
	private boolean alertFlg;
	
		/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor =null;
	
	/**
	 * Holds the totalRecordCountEccn
	 */
	private int totalRecordCountEccn;
	
	/**
	 * Holds the eccnOnScreenDataList
	 */	
	private List<PLMTaskSearchData> eccnOnScreenDataList;

	private String userEmail;
	private String userName;
	
	/**
	 * This method is used to load the loadEccnReportSearch page
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String loadEccnReportSearch() throws PLMCommonException {
		LOG.info("Inside the loadEccnReportSearch method");
		String fwdflag = "";
		alertMessage = "";
		rdoNamesList = new ArrayList<String>();
		eccnTagList =  new ArrayList<String>();
	
		try {
			resetEccnValues();
			Map<String, List<SelectItem>> eCCNTagMaplist = plmIssuesService.displaySelectedEccnTag();
			eccnListData = (List<SelectItem>) eCCNTagMaplist.get("eccnTaglist");
			LOG.info("eccnListData=-----=" + eccnListData.size());
			Map<String, List<SelectItem>> rdoList = plmIssuesService.getRdoValues();
			rdoListData = (List<SelectItem>) rdoList.get("rdolist");
			LOG.info("rdoListSize=-----=" + rdoListData.size());
			fwdflag = "eccnReportSearch";
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@loadEccnReportSearch: ", exception);
			fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"home","ECCN Report");
		} 
		
		try {
			commonMB.insertCannedRptRecordHitInfo("ECCN Report");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			commonMB.getPLMDateStamp(PLMConstants.PART_TABLE);
			 } catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPLMDateStamp: ", exception);
		} 
			 
		return fwdflag;
	}
	
	/**
	 * This method is used for resetEccnValues
	 * 
	 */
	public void resetEccnValues(){
		if (!PLMUtils.isEmptyList(rdoNamesList)) {
			rdoNamesList.clear();
		}
		if (!PLMUtils.isEmptyList(eccnTagList)) {
			eccnTagList.clear();
		}
		if (!PLMUtils.isEmptyList(eccnResultList)) {
			eccnResultList.clear();
		} else {
			eccnResultList = new ArrayList<PLMTaskSearchData>();
		}
		reportType = null;
		alertMessage = "";
	}
	
	/**
	 * This method is used for modify ECCN Report
	 * 
	 */
	public String modifyEccnSearch(){
		String fwdflag = "eccnReportSearch";
		if (!PLMUtils.isEmptyList(eccnResultList)) {
			eccnResultList.clear();
		} else {
			eccnResultList = new ArrayList<PLMTaskSearchData>();
		}
		reportType = null;
		alertMessage = "";
		return fwdflag;
	}
	
	
	//Added by Shekhar For New ECCN OnScreen Report
	/**
	 * This method is used for generateEccnOnScreenReport
	 * 
	 * @return String
	 */
	public String generateEccnOnScreenReport() {
		LOG.info("PLMEccnReportMB Generate ECCN On Screen Report");
		LOG.info("\n\n rdoNamesList ---Generate ECCN Report---"+rdoNamesList.size());
		LOG.info("\n\n eccnTagList ---Generate ECCN Report---"+eccnTagList.size());
		
		String fwdFlag = PLMConstants.EMPTY;
		alertMessage = "";
		try {
			if((rdoNamesList.size() == 0) || (eccnTagList.size() == 0)){
				alertMessage = PLMConstants.UNSELECT_RDO_ECCN;
			}  
			else if((rdoNamesList.size() > 1) || (eccnTagList.size() > 1)){
				alertMessage = PLMConstants.SELECT_ONE_RDO_ECCN;
			}
			else if(eccnTagList.contains("US EAR:EAR99, NLR")){
				alertMessage = PLMConstants.SELECTED_ECCN;
			}
			else {
					/*PLMUtils.convertListToString(rdoNamesList);
					PLMUtils.convertListToString(eccnTagList);*/
					if (!PLMUtils.isEmptyList(eccnResultList)) {
						eccnResultList.clear();
					}	
					eccnResultList = getEccnOnScreenReport();
			}
			if(!PLMUtils.isEmptyList(eccnResultList)){
				ntotalEccnCount = eccnResultList.size(); 
			}
			ntotalEccnCountMsg = "Total Results Count : " + ntotalEccnCount;
			if (!PLMUtils.isNullOrEmpty(alertMessage)) {
				fwdFlag = "";
			} else if(PLMUtils.isNullOrEmpty(alertMessage) && PLMUtils.isEmptyList(eccnResultList)){
					LOG.info("No records");
					fwdFlag = "eccnInvalidSearch";
			} else {
				fwdFlag = "eccnReportPage";
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@generateEccnReport: ", exception);
		} 
		return fwdFlag;
	}
	/**
	 * This method is used for generateEccnOnScreenReport
	 * 
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskSearchData> getEccnOnScreenReport() throws PLMCommonException {
		eccnOnScreenDataList = plmIssuesService.getEccnOnScreenReport(rdoNamesList,eccnTagList);
		return eccnOnScreenDataList;
	}

	/**
	 * This method is used for Generating ECCN Email Report
	 * 
	 * @return String
	 */
	public String generateEccnEmailRpt()  throws PWiException {
		LOG.info("Inside generateEccnEmailReportNew");
		String fwdFlag = "eccnReportSearch";
		alertMessage = "";
		alertStr = PLMConstants.EMPTY_STRING;//validateWhereUsedEMBOM();
		LOG.info("\n\n rdoNamesList ---Generate ECCN Report---"+rdoNamesList.size());
		LOG.info("\n\n eccnTagList ---Generate ECCN Report---"+eccnTagList.size());

		userName = UserInfoPortalUtil.getInstance().getUserName();
		userEmail = UserInfoPortalUtil.getInstance().getUserEmail();		
		
		if((rdoNamesList.size() == 0) || (eccnTagList.size() == 0)){
			alertMessage = PLMConstants.SELECT_RDO_ECCN;
		}
		else {
			alertMessage = PLMConstants.Eccn_Mail_Msg; 
			taskExecutor.execute(new EccnMailThread());
		}
		LOG.info("alertMessage"+alertMessage);
		return fwdFlag;
	
	}
	
	/**
	 * This method is used for download ECCN Report CSV File
	 * 
	 */
	public void downloadEccnCSV() throws PLMCommonException {

		String fileName = "ECCN Report";
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
		PLMCsvRptUtil csvUtil = new PLMCsvRptUtil();

		PLMCsvRptColumn[] reportColumns =
						new PLMCsvRptColumn[] {new PLMCsvRptColumn("eccnRdo", "RDO", FormatTypeCsv.TEXT, null, null, 27),
								new PLMCsvRptColumn("eccnName", "Name", FormatTypeCsv.TEXT, null, null, 15),
								new PLMCsvRptColumn("eccnRevision", "Revision", FormatTypeCsv.TEXT, null, null, 40),
								new PLMCsvRptColumn("eccnState", "State", FormatTypeCsv.TEXT, null, null, 15),
								new PLMCsvRptColumn("eccnType1", "Type", FormatTypeCsv.TEXT, null, null, 20),
								new PLMCsvRptColumn("eccnOriginationDate", "Origination Date", FormatTypeCsv.DATE, null, null, 35),
								new PLMCsvRptColumn("eccnReleaseDate", "Release Date", FormatTypeCsv.DATE, null, null, 15),
								new PLMCsvRptColumn("eccnOriginatorSSO", "Originator SSO", FormatTypeCsv.TEXT, null, null, 10),
								new PLMCsvRptColumn("eccnEcn", "ECCN", FormatTypeCsv.TEXT, null, null, 10)};

		csvUtil.exportCsv(eccnResultList, reportColumns, fileName, dateFormat, false, null, null, ",");
	}
	
	
	/**
	 * Background Process Thread
	 */
	private class EccnMailThread implements Runnable {
		
		public EccnMailThread(){}
		public void run() {
			try {
				sendEccnReportMail();
			} catch (PWiException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * @throws PWiException 
	 * 
	 */
	@SuppressWarnings("unchecked")
	public void sendEccnReportMail() throws PWiException {
		LOG.info("Inside sendEccnReportThroughMailNew");
		String from = PLMConstants.ECCN_MAIL_FROM;
		String successMsg = "";
		String toAddressee = userName;
		String to = userEmail;	
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String signature = PLMConstants.ECCN_MAIL_SIGNATURE;
		String errorSubject = PLMConstants.ECCN_MAIL_SUBJECT;

		List<String> zippedFiles = new ArrayList<String>();
		StringBuffer searchCriteriaMsg = new StringBuffer();
		String sourceFilePath = PLMConstants.EMPTY_STRING;

		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		boolean dirCreate = false;
		Boolean isEmtyRsltSet = false;

		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("ECCN_REPORT_NAME") + "-" + uniqTime;
		Map<String, Object> mailContentsMap = new HashMap<String, Object>();
		try {

			dirCreate = PLMUtils.mkDir(fileDir);
			LOG.info("The directory creation for ECCN Report is " + fileDir + " is " + dirCreate);
			sourceFilePath = fileDir + PLMConstants.BACK_SLASH + resourceBundle.getString("ECCN_REPORT_NAME") + "_" + uniqTime;
			mailContentsMap = plmIssuesService.createEccnCSVFile(rdoNamesList, eccnTagList, sourceFilePath, fileDir);
			if (mailContentsMap != null) {
				zippedFiles = (ArrayList<String>) mailContentsMap.get("ZippedFiles");
				searchCriteriaMsg = (StringBuffer) mailContentsMap.get("searchCriteriaMsg");
				isEmtyRsltSet = (Boolean) mailContentsMap.get("isEmtyRsltSet");
			}

			String subject = PLMConstants.ECCN_MAIL_SUBJECT;
			String message = toAddressee + PLMConstants.ECCN_REPORT_MAIL_CONTENT + searchCriteriaMsg.toString() + PLMConstants.ECCN_MAIL_SIGNATURE;
			if (isEmtyRsltSet == false) {
				LOG.info("Number Of Mails To Be Sent With Attachments >>>>>>>>>>>>>>>>>>>>>>>>> " + zippedFiles.size());
				int eecnEmailCount = 0;
				for (int i = 0; i < zippedFiles.size(); i++) {
					LOG.info("Zip file path>>>>>>>>>>>>>>>>" + zippedFiles.get(i));
					if(zippedFiles.size()==1){
						PLMUtils.sendMailWithAttachment(from, to, subject, message, zippedFiles.get(i));
					}else{
						eecnEmailCount = i + 1;
						subject = subject + eecnEmailCount;
						PLMUtils.sendMailWithAttachment(from, to, subject, message, zippedFiles.get(i));
						subject = PLMConstants.ECCN_MAIL_SUBJECT;
					}
					
					LOG.info("  Mail has been sent to mail id : " + to);
				}
			} else if (isEmtyRsltSet == true) {
				LOG.info("ZippedFiles List size = 0 ");
				LOG.info("No data mail has been sent .... ");
				message = toAddressee + PLMConstants.ECCN_NO_RECORD_FOUND_FOR_EMAIL + searchCriteriaMsg.toString() + PLMConstants.WHERE_USED_EBOM_MAIL_SIGNATURE;
				PLMUtils.sendMail(from, to, subject, message);
			}

			successMsg = "Mail sent successfully.";
			LOG.info("Message from the Rpt Method "+successMsg);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendEccnReportThroughMailNew: ", exception);
			successMsg = exception.getMessage();
			PLMUtils.checkExceptionAndMail(exception.getMessage(), from, to, errorSubject, toAddressee, signature);

			if (zippedFiles.size() > 0) {
				for (String zipFilePath : zippedFiles) {
					try {
						PLMUtils.deleteDocument(zipFilePath);
					} catch (PLMCommonException e) {
						e.printStackTrace();
					}
				}

			}
			if (dirCreate) {
				try {
					LOG.info("Directory has been deleted >>>>>>>>>>>>>>>>>>> " + fileDir);
					PLMUtils.deleteDir(fileDir);
				} catch (PLMCommonException e) {
					e.printStackTrace();
				}
			}

		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendEccnReportThroughMailNew: ", exception);
			successMsg = exception.getMessage();
			PLMUtils.checkExceptionAndMail(exception.getMessage(), from, to, errorSubject, toAddressee, signature);

			if (zippedFiles.size() > 0) {
				for (String zipFilePath : zippedFiles) {
					try {
						PLMUtils.deleteDocument(zipFilePath);
					} catch (PLMCommonException e) {
						e.printStackTrace();
					}
				}

			}
			if (dirCreate) {
				try {
					LOG.info("Directory has been deleted >>>>>>>>>>>>>>>>>>> " + fileDir);
					PLMUtils.deleteDir(fileDir);
				} catch (PLMCommonException e) {
					e.printStackTrace();
				}
			}

		} finally {
			if (zippedFiles.size() > 0) {
				for (String zipFilePath : zippedFiles) {
					try {
						PLMUtils.deleteDocument(zipFilePath);
					} catch (PLMCommonException e) {
						e.printStackTrace();
					}
				}

			}
			if (!PLMUtils.isEmptyMap(mailContentsMap)) {
				mailContentsMap.clear();
			}
			if (dirCreate) {
				try {
					LOG.info("Directory has been deleted >>>>>>>>>>>>>>>>>>> " + fileDir);
					PLMUtils.deleteDir(fileDir);
				} catch (PLMCommonException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * @return the alertStr
	 */
	public String getAlertStr() {

		String temp = null;
		temp = alertStr;
		alertStr = PLMConstants.EMPTY_STRING;
		return temp;
	}
	/**
	 * @param alertStr
	 *            the alertStr to set
	 */
	public void setAlertStr(String alertStra) {
		this.alertStr = alertStra;
		LOG.info("alertStr-------" + alertStr);
	}
	
	
	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}
	/**
	 * @param alertMessage the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}
	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}
	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}
	/**
	 * @param taskExecutor the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}
	
	/**
	 * @return the plmIssuesService
	 */
	public PLMkpiReportServiceIfc getPlmIssuesService() {
		return plmIssuesService;
	}

	/**
	 * @param plmIssuesService the plmIssuesService to set
	 */
	public void setPlmIssuesService(PLMkpiReportServiceIfc plmIssuesService) {
		this.plmIssuesService = plmIssuesService;
	}
	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @param recordCounts the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		this.recordCounts = recordCounts;
	}

	/**
	 * @return the eccnTagList
	 */
	public List<String> getEccnTagList() {
		return eccnTagList;
	}

	/**
	 * @param eccnTagList the eccnTagList to set
	 */
	public void setEccnTagList(List<String> eccnTagList) {
		this.eccnTagList = eccnTagList;
	}
	
	/**
	 * @return the rdoNamesList
	 */
	public List<String> getRdoNamesList() {
		return rdoNamesList;
	}

	/**
	 * @param rdoNamesList the rdoNamesList to set
	 */
	public void setRdoNamesList(List<String> rdoNamesList) {
		this.rdoNamesList = rdoNamesList;
	}

	/**
	 * @return the rdoListData
	 */
	public List<SelectItem> getRdoListData() {
		return rdoListData;
	}

	/**
	 * @param rdoListData the rdoListData to set
	 */
	public void setRdoListData(List<SelectItem> rdoListData) {
		this.rdoListData = rdoListData;
	}

	/**
	 * @return the eccnListData
	 */
	public List<SelectItem> getEccnListData() {
		return eccnListData;
	}

	/**
	 * @param eccnListData the eccnListData to set
	 */
	public void setEccnListData(List<SelectItem> eccnListData) {
		this.eccnListData = eccnListData;
	}

	/**
	 * @return the reportType
	 */
	public String getReportType() {
		return reportType;
	}

	/**
	 * @param reportType the reportType to set
	 */
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	/**
	 * @return the eccnResultList
	 */
	public List<PLMTaskSearchData> getEccnResultList() {
		return eccnResultList;
	}

	/**
	 * @param eccnResultList the eccnResultList to set
	 */
	public void setEccnResultList(List<PLMTaskSearchData> eccnResultList) {
		this.eccnResultList = eccnResultList;
	}

	/**
	 * @return the ntotalEccnCount
	 */
	public int getNtotalEccnCount() {
		return ntotalEccnCount;
	}

	/**
	 * @param ntotalEccnCount the ntotalEccnCount to set
	 */
	public void setNtotalEccnCount(int ntotalEccnCount) {
		this.ntotalEccnCount = ntotalEccnCount;
	}

	/**
	 * @return the ntotalEccnCountMsg
	 */
	public String getNtotalEccnCountMsg() {
		return ntotalEccnCountMsg;
	}

	/**
	 * @param ntotalEccnCountMsg the ntotalEccnCountMsg to set
	 */
	public void setNtotalEccnCountMsg(String ntotalEccnCountMsg) {
		this.ntotalEccnCountMsg = ntotalEccnCountMsg;
	}

	/**
	 * @return the totalRecordCountEccn
	 */
	public int getTotalRecordCountEccn() {
		return totalRecordCountEccn;
	}

	/**
	 * @param totalRecordCountEccn the totalRecordCountEccn to set
	 */
	public void setTotalRecordCountEccn(int totalRecordCountEccn) {
		this.totalRecordCountEccn = totalRecordCountEccn;
	}

	
	/**
	 * @return the eccnOnScreenDataList
	 */
	public List<PLMTaskSearchData> getEccnOnScreenDataList() {
		return eccnOnScreenDataList;
	}

	/**
	 * @param eccnOnScreenDataList the eccnOnScreenDataList to set
	 */
	public void setEccnOnScreenDataList(List<PLMTaskSearchData> eccnOnScreenDataList) {
		this.eccnOnScreenDataList = eccnOnScreenDataList;
	}

	public boolean isAlertFlg() {
		return alertFlg;
	}

	public void setAlertFlg(boolean alertFlg) {
		this.alertFlg = alertFlg;
	}
	
	
	
}