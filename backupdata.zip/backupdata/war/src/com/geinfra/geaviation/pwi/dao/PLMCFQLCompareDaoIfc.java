/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCFQLCompareDaoIfc.java
 * @Creation date: 06-Sept-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.util.List;
import java.util.TreeMap;

import com.geinfra.geaviation.pwi.data.PLMCFQLCompareData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMCFQLCompareDaoIfc {
	
	/**
	 * This method is used to get CF QL Compare Report
	 * 
	 * @param bulkHwPRdList,confOption,subType,defaultType
	 * @return List
	 * @throws PLMCommonException
	 */
	public TreeMap <Integer,Object>  getCFQLCompareRpt(List<PLMCFQLCompareData> bulkHwPRdList) throws PLMCommonException;
	/**
	 * This method is used to get CF QL Compare Report
	 * 
	 * @param bulkHwPRdList,confOption,subType,defaultType
	 * @return List
	 * @throws PLMCommonException
	 */
	public TreeMap <Integer,Object>  getCFQLNonCompareRpt(List<PLMCFQLCompareData> bulkHwPRdList) throws PLMCommonException;
	
	/**
	 * This method is used to get Project Scorecard Report
	 * 
	 * @param prjSCFinalList
	 * @return List
	 * @throws PLMCommonException
	 */
	public TreeMap <Integer,Object>  getPrjScorecardData(List<String> prjSCFinalList) throws PLMCommonException;
	
	/**
	 * This method is used to validate CF QL Compare Report
	 * 
	 * @param bulkHwPRdList
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getValidHardwrPrd(List<PLMCFQLCompareData> bulkHwPRdFinalList) throws PLMCommonException;
	
	/**
	 * This method is used to validate Project Scorecard Report
	 * 
	 * @param pcNameList
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getValidPCName(List<String> pcNameList) throws PLMCommonException;

}
