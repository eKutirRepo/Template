package com.geinfra.geaviation.pwi.bean;

import com.geinfra.geaviation.pwi.model.TemplateVO;

/**
 * 
 * Project : Product Lifecycle Management Inteligence Date Written : May 21,
 * 2010 Security : GE Confidential Restrictions : GE PROPRIETARY INFORMATION,
 * FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : TemplateBean - Backing bean that holds state for a template
 * that has been added or is being edited by user.
 * 
 * Revision Log May 8, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class TemplateBean {
	Integer templateViewId;
	TemplateVO template;
	byte[] templateBytes;
	boolean isMarkedToDelete;

	public TemplateBean(Integer templateViewId) {
		this.templateViewId = templateViewId;
		this.template = new TemplateVO();
	}

	public TemplateBean(Integer templateViewId, TemplateVO template) {
		this.templateViewId = templateViewId;
		this.template = template;
	}

	public Integer getTemplateViewId() {
		return templateViewId;
	}

	public Integer getTemplateId() {
		return template.getTemplateId();
	}

	public void setTemplateId(Integer templateId) {
		template.setTemplateId(templateId);
	}

	public String getTemplateName() {
		return template.getTemplateName();
	}

	public void setTemplateName(String templateName) {
		template.setTemplateName(templateName);
	}

	public boolean isEnabled() {
		return template.isEnabled();
	}

	public void setEnabled(boolean enabled) {
		template.setEnabled(enabled);
	}

	public byte[] getTemplateBytes() {
		byte[] templateBytesCopy = null;
		if (templateBytes != null) {
			templateBytesCopy = new byte[templateBytes.length];
			System.arraycopy(templateBytes, 0, templateBytesCopy, 0,
					templateBytes.length);
		}
		return templateBytesCopy;
	}

	public void setTemplateBytes(byte[] templateBytes) {
		if (templateBytes == null) {
			this.templateBytes = null;
		} else {
			this.templateBytes = new byte[templateBytes.length];
			System.arraycopy(templateBytes, 0, this.templateBytes, 0,
					templateBytes.length);
		}
	}

	public boolean isMarkedToDelete() {
		return isMarkedToDelete;
	}

	public void setMarkedToDelete(boolean newIsMarkedToDelete) {
		this.isMarkedToDelete = newIsMarkedToDelete;
	}

	public TemplateVO getTemplateVo() {
		return template;
	}
}