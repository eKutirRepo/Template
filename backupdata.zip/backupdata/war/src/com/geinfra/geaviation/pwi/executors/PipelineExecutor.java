package com.geinfra.geaviation.pwi.executors;

import java.util.List;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.PWiQueryTimeoutException;
import com.geinfra.geaviation.pwi.common.PWiResultSizeLimitExceededException;
import com.geinfra.geaviation.pwi.model.PWiResultSet;
import com.geinfra.geaviation.pwi.util.QueryProcessingUtil;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;

/**
 * 
 * Project      : Product Lifecycle Management Intelligence
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2012 GE All rights reserved
 * 
 * Description :
 * 
 * Revision Log
 * --------------------------------------------------------------
 * 2012.12.18 pH  replaced GEAEResultSet with PWiResultSet
 * 2013.02.21 pH  cleaned up methods and added support for returning SQL string
 */
public class PipelineExecutor implements Executor {
	List<Executor> executors;
	private StringBuffer sbQuery = new StringBuffer("--PIPELINE EXECUTOR:");

	public PipelineExecutor(List<Executor> executors) {
		this.executors = executors;
	}

	/*
	 * A pipeline executor should call each of its child executors in order,
	 * passing the columns and rows from a previous child executor to the next
	 * child executor. The first child executor will likely get empty or null
	 * columns and rows passed in.
	 */

	public PWiResultSet execute(QueryType queryType, Search search,
			SelectedColumns selectedColumns, String sso, String[] columns,
			List<Object[]> rows) throws PWiException,
			PWiResultSizeLimitExceededException, PWiQueryTimeoutException {
		PWiResultSet resultSet = null;
		String[] tempColumns = columns;
		List<Object[]> tempRows = rows;
		
		// execute each executor
		for (Executor executor : executors) {
			// If resultSet is not null (this is not the first loop iteration)
			if (resultSet != null) {
				// If there were no results from the previous query, there won't
				// be any next time, either.  If no rows, return an empty RS
				if (resultSet.size() == 0) {
					resultSet.close();
					return new PWiResultSet();
				}
				
				// get rows and columns from the previous result set, then close it
				tempColumns = QueryProcessingUtil.getInstance().getColumns(resultSet);
				tempRows = QueryProcessingUtil.getInstance().getRows(resultSet);
				resultSet.close();
			}

			// Execute
			resultSet = executor.execute(queryType, search,
					selectedColumns, sso, tempColumns, tempRows);
			sbQuery.append("\n--PIPELINE QUERY:\n")
					.append(executor.getExecutedQuery()).append("\n");
		}

		return resultSet;
	}

	public String getExecutedQuery() {
		return sbQuery.toString();
	}
}
