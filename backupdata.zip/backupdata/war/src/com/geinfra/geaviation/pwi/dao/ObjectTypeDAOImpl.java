package com.geinfra.geaviation.pwi.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

import com.geinfra.geaviation.pwi.model.PWiObjectTypeVO;
import com.geinfra.geaviation.pwi.util.ColumnConstants;
import com.geinfra.geaviation.pwi.util.MapperConstants.RowCounter;
import com.geinfra.geaviation.pwi.util.QueryConstants;
import com.geinfra.geaviation.pwi.util.QueryLoader;

/**
 * Project : Product Lifecycle Management Date Written : Apr 12, 2011 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : ObjectTypeDAOImpl
 * 
 * Revision Log Jan 20, 2012 | v1.0.
 * --------------------------------------------------------------
 */
public class ObjectTypeDAOImpl implements ObjectTypeDAO {
	// Injected
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<PWiObjectTypeVO> findAllPWiObjectTypes() {
		final ParameterizedRowMapper<PWiObjectTypeVO> mapper = new PWiObjectTypeVORowMapper();

		@SuppressWarnings("unchecked")
		List<PWiObjectTypeVO> result = (List<PWiObjectTypeVO>) jdbcTemplate
				.query(QueryLoader.getQuery(QueryConstants.PWi_OBJECT_TYPES),
						mapper);
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<PWiObjectTypeVO> findPWiQiObjectTypes() {
		final ParameterizedRowMapper<PWiObjectTypeVO> mapper = new PWiObjectTypeVORowMapper();

		@SuppressWarnings("unchecked")
		List<PWiObjectTypeVO> result = (List<PWiObjectTypeVO>) jdbcTemplate
				.query(QueryLoader.getQuery(QueryConstants.PWi_OBJECT_TYPES_QI),
						mapper);
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<PWiObjectTypeVO> findPWiObjectTypesForGroups(List<String> groups) {
		// Construct SQL
		String sql = QueryLoader
				.getQuery(QueryConstants.PWi_OBJECT_TYPES_BY_GROUP);
		int inPos = StringUtils.lastIndexOf(sql, "?");
		String sub1 = StringUtils.substring(sql, 0, inPos);
		String sub2 = StringUtils.substring(sql, inPos, sql.length());
		StringBuffer sqlBuffer = new StringBuffer(sub1);
		for (int i = 1; i < groups.size(); i++) {
			sqlBuffer.append("?,");
		}
		sql = sqlBuffer.append(sub2).toString();

		final ParameterizedRowMapper<PWiObjectTypeVO> mapper = new PWiObjectTypeVORowMapper();
		final PreparedStatementSetter setter = new GroupNamesSetter(groups);

		@SuppressWarnings("unchecked")
		List<PWiObjectTypeVO> result = (List<PWiObjectTypeVO>) jdbcTemplate
				.query(sql, setter, mapper);
		return result;
	}

	private static class GroupNamesSetter implements
			PreparedStatementSetter {
		private List<String> groups;
		
		public GroupNamesSetter(List<String> groups) {
			this.groups = groups;
		}
		
		public void setValues(PreparedStatement ps) throws SQLException {
			int parameterIndex = 1;
			for (String group : groups) {
				ps.setString(parameterIndex, group);
				parameterIndex++;
			}
		}
	}

	/**
	 * Row Mapper for Object Types
	 */
	public static class PWiObjectTypeVORowMapper implements
			ParameterizedRowMapper<PWiObjectTypeVO> {
		public PWiObjectTypeVO mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PWiObjectTypeVO PWiObjectTypeVO = new PWiObjectTypeVO();
			PWiObjectTypeVO.setObjTypSeqId(Integer.valueOf(rs
					.getString(ColumnConstants.OBJ_TYP_SEQ_ID)));
			PWiObjectTypeVO.setObjTypNm(rs
					.getString(ColumnConstants.OBJ_TYP_NM));
			PWiObjectTypeVO.setObjTypDesc(rs
					.getString(ColumnConstants.OBJ_TYP_DESC));
			PWiObjectTypeVO.setShwInQi("Y".equals(rs
					.getString(ColumnConstants.OBJ_TYP_SHW_IN_QI)));
			return PWiObjectTypeVO;
		}
	}

	public PWiObjectTypeVO getObjectTypeById(Integer objectTypeId) {
		// Retrieve SQL with bind parameters
		String sql = QueryLoader
				.getQuery(QueryConstants.PWi_OBJECT_TYPE_BY_ID);

		// Define prepared statement setter
		PreparedStatementSetter pss = new GetObjectTypeByIdSetter(objectTypeId);

		// Define row mapper
		RowMapper rowMapper = new PWiObjectTypeVORowMapper();

		// Run query on database
		@SuppressWarnings("unchecked")
		List<PWiObjectTypeVO> objectTypes = jdbcTemplate.query(sql, pss, rowMapper);
		if (objectTypes.size() == 1) {
			return objectTypes.get(0);
		} else if (objectTypes.size() == 0) {
			return null;
		}
		throw new IllegalStateException(
				"Failed to return one or zero templates for object type ID: "
						+ objectTypeId + ", objectTypes: " + objectTypes);
	}

	private static class GetObjectTypeByIdSetter implements
			PreparedStatementSetter {
		private Integer objectTypeId;

		public GetObjectTypeByIdSetter(Integer objectTypeId) {
			this.objectTypeId = objectTypeId;
		}

		public void setValues(PreparedStatement ps) throws SQLException {
			ps.setInt(1, objectTypeId.intValue());
		}
	}
	
	public List<PWiObjectTypeVO> getAllObjectTypesWithGroups() {
		String sql = QueryLoader.getQuery(QueryConstants.PWi_OBJECT_TYPES_WITH_GROUPS);
		
		ObjectTypeVOWithGroupHandler handler = new ObjectTypeVOWithGroupHandler();
		
		jdbcTemplate.query(sql, handler);
		
		return handler.getObjectTypes();
	}
	
	private static class ObjectTypeVOWithGroupHandler implements RowCallbackHandler {
		HashMap<Integer, PWiObjectTypeVO> objectTypes = new HashMap<Integer, PWiObjectTypeVO>();
		
		public void processRow(ResultSet rs) throws SQLException {
			Integer objTypSeqId = Integer.valueOf(rs
					.getString(ColumnConstants.OBJ_TYP_SEQ_ID));
			
			// get the VO from the map, if it exists 
			PWiObjectTypeVO PWiObjectTypeVO = objectTypes.get(objTypSeqId);
			if (PWiObjectTypeVO == null) {
				// if the VO does not exist in the map, create one and add it
				PWiObjectTypeVO = new PWiObjectTypeVO();
				PWiObjectTypeVO.setObjTypSeqId(objTypSeqId);
				PWiObjectTypeVO.setObjTypNm(rs
						.getString(ColumnConstants.OBJ_TYP_NM));
				PWiObjectTypeVO.setObjTypDesc(rs
						.getString(ColumnConstants.OBJ_TYP_DESC));
				PWiObjectTypeVO.setShwInQi("Y".equals(rs
						.getString(ColumnConstants.OBJ_TYP_SHW_IN_QI)));
				objectTypes.put(objTypSeqId, PWiObjectTypeVO);
			}
			
			// add the group
			PWiObjectTypeVO.addGroupName(rs.getString(ColumnConstants.QRY_GRP_NM));
		}
		
		public List<PWiObjectTypeVO> getObjectTypes() {
			return new ArrayList<PWiObjectTypeVO>(objectTypes.values());
		}
	}

	public int checkNamesEdit(String objTypNm, String objTypDesc,
			Integer objTypSeqId) {
		RowCounter counter = new RowCounter();
		String sql = QueryLoader.getQuery(QueryConstants.SEARCH_OBJ_TYP_EDIT_NAME);
		Object[] parameters = { objTypNm, objTypDesc, objTypSeqId };
		
		jdbcTemplate.query(sql, parameters, counter);
		
		return counter.getCount();
	}

	public int checkNames(String objTypNm, String objTypDesc) {
		RowCounter counter = new RowCounter();
		String sql = QueryLoader.getQuery(QueryConstants.SEARCH_OBJ_TYP_WITH_NAME);
		Object[] parameters = { objTypNm, objTypDesc };
		
		jdbcTemplate.query(sql, parameters, counter);
		
		return counter.getCount();
	}

	/**
	 * @throws RuntimeException to trigger rollback of transaction, if necessary
	 */
	public Integer createNewObjectType(final String objectTypeName,
			final String objectTypeDesc, final boolean shwInQi,
			final String userId) throws RuntimeException {
		String sql = QueryLoader.getQuery(QueryConstants.PWi_OBJECT_TYPE_INSERT);
		Connection connection = null;
		CallableStatement statement = null;
		try {
			connection = jdbcTemplate.getDataSource().getConnection();
			statement = connection.prepareCall(sql);

			// Set input parameters
			int idx = 1; // parameter index
			statement.setString(idx++, objectTypeName);
			statement.setString(idx++, objectTypeDesc);
			statement.setString(idx++, shwInQi ? "Y" : "N");
			statement.setString(idx++, userId);
			statement.setString(idx++, userId);

			// Set output parameters
			statement.registerOutParameter(idx, Types.NUMERIC);

			// Execute objectType
			statement.execute();

			// Retrieve primary key
			Integer objectTypeId = Integer.valueOf(statement.getInt(idx));
			return objectTypeId;
		} catch (SQLException e) {
			// Throw runtime exception to trigger rollback
			throw new RuntimeException(e);
		} finally {
			// close everything
			try {
				if ( statement != null) {  statement.close(); }
				if (connection != null) { connection.close(); }
			} catch (SQLException e) {
				// Throw runtime exception to trigger rollback
				throw new RuntimeException(e);
			}
		}
	}

	/*
	public Integer createNewObjectType(final String objectTypeName,
			final String objectTypeDesc, final boolean shwInQi,
			final String userId) throws RuntimeException {
		String sql = QueryLoader.getQuery(QueryConstants.PWi_OBJECT_TYPE_INSERT);
		Connection connection = null;
		PreparedStatement statement = null;
		int objectTypeId=1;
		try {
			connection = jdbcTemplate.getDataSource().getConnection();
			Object objGrp[] = new Object[6];
			objGrp[0] = objectTypeId;
			objGrp[1] = objectTypeName;
			objGrp[2] = objectTypeDesc;
			objGrp[3] = shwInQi ? "Y" : "N";
			objGrp[4] =  userId;
			objGrp[5] =  userId;
			jdbcTemplate.update(sql,objGrp);

			return objectTypeId;
			
			
		} catch (SQLException e) {
			// Throw runtime exception to trigger rollback
			throw new RuntimeException(e);
		} finally {
			// close everything
			try {
				if ( statement != null) {  statement.close(); }
				if (connection != null) { connection.close(); }
			} catch (SQLException e) {
				// Throw runtime exception to trigger rollback
				throw new RuntimeException(e);
			}
		}
	}
*/
	public void updateObjectType(PWiObjectTypeVO objectType, String sso) {
		jdbcTemplate.update(new UpdateObjectTypePSCreator(objectType, sso));
	}

	private static class UpdateObjectTypePSCreator implements PreparedStatementCreator {
		private PWiObjectTypeVO objectType;
		private String userId;

		public UpdateObjectTypePSCreator(PWiObjectTypeVO objectType, String userId) {
			this.objectType = objectType;
			this.userId = userId;
		}

		public PreparedStatement createPreparedStatement(Connection connection)
				throws SQLException {
			String sql = QueryLoader.getQuery(QueryConstants.PWi_OBJECT_TYPE_UPDATE);
			PreparedStatement ps = connection.prepareStatement(sql);
			
			int idx = 1; // parameter index
			ps.setString(idx++, objectType.getObjTypNm());
			ps.setString(idx++, objectType.getObjTypDesc());
			ps.setString(idx++, objectType.isShwInQi() ? "Y" : "N");
			ps.setString(idx++, userId);
			ps.setInt(   idx++, objectType.getObjTypSeqId().intValue());
			return ps;
		}
	}
}
