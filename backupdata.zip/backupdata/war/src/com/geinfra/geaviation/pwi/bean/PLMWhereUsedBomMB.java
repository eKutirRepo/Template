/**
 * Copyright (C) 2017 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhereUsedBomMB.java
 * @Creation date: 16-November-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.richfaces.event.UploadEvent;
import org.richfaces.model.UploadItem;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.data.PLMWhereUsedBOMData;
import com.geinfra.geaviation.pwi.service.PLMWhereUsedBOMServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMWhereUsedBomMB {
	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger.getLogger(PLMWhereUsedBomMB.class);
	/**
	 * Holds the taskExecutor
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	/**
	 * Holds the resourceBundle
	 */
	ResourceBundle resourceBundle = ResourceBundle
			.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	
	/**
	 * Holds the plmWhereUsedBOMService
	 */
	private PLMWhereUsedBOMServiceIfc plmWhereUsedBOMService = null;
	
	/**
	 * Holds the plmWhereUsedBOMData
	 */
	private PLMWhereUsedBOMData plmWhereUsedBOMData = new PLMWhereUsedBOMData();
	/**
	 * Holds the alertMsgBOM
	 */
	private String alertMsgBOM;
	/**
	 * Holds the inputPartsList
	 */
	List<PLMWhereUsedBOMData> inputPartsList = new ArrayList<PLMWhereUsedBOMData>();
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB = null;
	
	private PLMPwiUserData userDetails = null;
	
	private String levelsUpTo;
	
	private List<SelectItem> sellevelsUpTo;
	
	private String levelVal;
	
	private String uploadFileName;
	
	/**
	 * Load The Where Used Search Page
	 * 
	 * @return String
	 */
	public String loadWhereUsedBOMPage() {
		LOG.info("Entering into WhereUsedMB loadWhereUsedBOMPage()...");
		String fwdFlag = "";
		alertMsgBOM="";
		inputPartsList = new ArrayList<PLMWhereUsedBOMData>();
		plmWhereUsedBOMData = new PLMWhereUsedBOMData();
		fwdFlag = PLMConstants.WHERE_USED_BOM_SEARCH;
		sellevelsUpTo = new ArrayList<SelectItem>();
		sellevelsUpTo.add(new SelectItem("All", "All"));
		sellevelsUpTo.add(new SelectItem("Highest", "Highest"));
		sellevelsUpTo.add(new SelectItem("UpTo..And Highest", "UpTo..And Highest"));
		levelsUpTo = "";
		//resetTopLvlImplosionData();
		try {
			commonMB.insertCannedRptRecordHitInfo("BOM Implosion - Where Used Tool");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			commonMB.getLegacyDateStamp();
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getLegacyDateStamp: ", exception);
		}
		LOG.info("Exiting from WhereUsedMB loadWhereUsedPage()...");

		return fwdFlag;
	}

	
	/**
	 * This method is used for upload the Fmi Template
	 * 
	 * @return void
	 */
	public void uploadValidFile(UploadEvent event) throws IOException {
		LOG.info("Entering uploadValidFile Method");
		UploadItem item = event.getUploadItem();
		alertMsgBOM ="";
	    inputPartsList = new ArrayList<PLMWhereUsedBOMData>();
	    PLMWhereUsedBOMData data = new PLMWhereUsedBOMData();
	    InputStream ExcelFileToRead = new FileInputStream(item.getFile());
		HSSFWorkbook wb = new HSSFWorkbook(ExcelFileToRead);
		List<String> partNumListtemp = new ArrayList<String>();
		HSSFSheet sheet=wb.getSheetAt(0);
		HSSFRow row; 
	    
		try {
			for (int i = 1; i <= sheet.getLastRowNum(); i++){
				row = sheet.getRow(i);
				
				data = new PLMWhereUsedBOMData();
				data.setBomLevel(row.getCell(0).toString()); // Level
				LOG.info("Input Part level: ~~~~~~~~~ "+ data.getBomLevel());
				data.setPartNumber(row.getCell(1).toString()); // Name
				data.setFindNum(row.getCell(2).toString()); // F/N
				data.setDescription(row.getCell(3).toString()); // Description
				data.setQuantity(row.getCell(4).toString()); // Quantity
				
				partNumListtemp.add(data.getPartNumber());
				inputPartsList.add(data);
			}
			LOG.info("inputPartsList Count >>>> "+ inputPartsList.size());
			alertMsgBOM=validatePartNumber(partNumListtemp); 
			if (PLMUtils.isEmpty(alertMsgBOM)) {
				alertMsgBOM = "Uploaded Filename: "+ item.getFileName();
				uploadFileName = item.getFileName();
			}
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@uploadValidFile: ", exception);
			alertMsgBOM = "Invalid File Format";
		}
		LOG.info("Exiting uploadValidFile Method");
	}
	
	/**
	 * This method is used for Validating Part Number Input
	 * 
	 * @return String
	 */
	public String validatePartNumber(List<String> partNumListTemp) {
		LOG.info("Entering validatePartNumber Method");
		String alertMsg = "";
		boolean checkFlag=false;
		for(int i=0;i<partNumListTemp.size();i++){
			 if(!PLMUtils.isEmpty(partNumListTemp.get(i))){
				 String spaceStr[]=partNumListTemp.get(i).split("\\s+");
				  if(spaceStr.length >1){
					  alertMsg = PLMConstants.WHEREUSEDBOM_SPACE_VALIDATION;
					  checkFlag =true;
					  break;
				  }
			 }
			 if (PLMUtils.isEmpty(partNumListTemp.get(i))) {
				 alertMsg = PLMConstants.WHEREUSEDBOM_EMPTY_STRING;
				 checkFlag =true;
				 break;
			 }
		 }
		if(PLMUtils.isEmptyList(partNumListTemp) && !checkFlag){
			alertMsg = PLMConstants.WHEREUSEDBOM_UPLOADFILE;
			checkFlag =true;
		}else if(partNumListTemp.size() > 500 && !checkFlag){
			alertMsg = PLMConstants.WHEREUSEDBOM_PARTNUM_MORE_500;
		}
		LOG.info("Exiting validatePartNumber Method");
		return alertMsg;
	}
	
	/**
	 * This method is used for Generating BOM Implosion - Where Used Tool
	 * 
	 * @return String
	 * @throws PWiException 
	 */
	public String generateWhereUsedBOMEmail() throws PWiException {
		LOG.info("Entering generateWhereUsedBOMEmail Method");
		String fwdflag = PLMConstants.WHERE_USED_BOM_SEARCH;
		alertMsgBOM = "";
		LOG.info("levelsUpTo >>>>> "+ levelsUpTo);
		userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		
		if (!PLMUtils.isEmpty(levelsUpTo)) {
			
			int level = 30;
			
			if ("UpTo..And Highest".equalsIgnoreCase(levelsUpTo) && PLMUtils.isEmpty(levelVal)) {
				alertMsgBOM = PLMConstants.WHEREUSEDBOM_LVLSTXT_EMPTY;
				level = 0;
			} else if ("UpTo..And Highest".equalsIgnoreCase(levelsUpTo) && !PLMUtils.isEmpty(levelVal)) {
				level = Integer.parseInt(levelVal);
			}
			
			if (level > 30) {
				alertMsgBOM = PLMConstants.WHEREUSEDBOM_LVLSTXT_EMPTY;
			} else if (level != 0 && level <= 30) {
				if (!PLMUtils.isEmptyList(inputPartsList)) {
					alertMsgBOM =  PLMConstants.WHEREUSEDBOM_EMAIL_AERT_MSG;
					taskExecutor.execute(new MailThread());
				}else{
					alertMsgBOM =  PLMConstants.WHEREUSEDBOM_UPLOADFILE;
				}
			}
		} else if (PLMUtils.isEmpty(levelsUpTo)) {
			alertMsgBOM = PLMConstants.WHEREUSEDBOM_LVLSUPTO_EMPTY;
		}
		LOG.info("Exiting generateWhrUsdImplosionEmail Method");
		return fwdflag;
	}
	
	/**
	 * Background Process Thread
	 */
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendWhereUsedBOMMail();
		}
	}
	
	/**
	 * This method is used for Generating & Sending the Report to mail
	 * 
	 * @return void
	 */
	public void sendWhereUsedBOMMail() {
		LOG.info("Entering sendWhereUsedBOMMail Method");
		int level = 30;
		List<PLMWhereUsedBOMData> partNumlistLcl = inputPartsList;
		String from = PLMConstants.OMM_MAIL_FROM;
		String to = userDetails.getUserEmailId();		
		String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
		toAddressee = "Dear " + toAddressee + ", \n\n";
		String subject = PLMConstants.WHEREUSEDBOM_SUBJECT ;
		final SimpleDateFormat DATE_FORMAT_PROC = new SimpleDateFormat("yyyyMMddHHmmss");
		Date uniqDate = new Date();
		String uniqTime = DATE_FORMAT_PROC.format(uniqDate);
		String fileDir = resourceBundle.getString("OFFLINE_RPT_DIR");
		String filePathXls = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("WHERE_USED_BOM") +  "_" + uniqTime + ".xlsx";
		String filePathZip = resourceBundle.getString("OFFLINE_RPT_DIR") + resourceBundle.getString("WHERE_USED_BOM") +  "_" + uniqTime + ".zip";
		try {
			
			if ("UpTo..And Highest".equalsIgnoreCase(levelsUpTo)) {
				level = Integer.parseInt(levelVal);
			}
			
			Map<String,List<PLMWhereUsedBOMData>> finalDataMap = plmWhereUsedBOMService.fetchBOMImplsnWhereUsedData(partNumlistLcl, levelsUpTo, level);
						
			StringBuffer mailBody = new StringBuffer().append(toAddressee);
			if(PLMUtils.isEmptyMap(finalDataMap)){
				mailBody.append(PLMConstants.WHEREUSEDBOM_MAIL_CONTENT_NO_RECORD);
				mailBody.append("Input Filename: ").append(uploadFileName).append("\n\n");
				mailBody.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				PLMUtils.sendMail(from, to, subject, mailBody.toString());
			} else {
				mailBody.append(PLMConstants.WHEREUSEDBOM_MAIL_CONTENT);
				// mention input criteria here if possible
				 mailBody.append("Input Filename: ").append(uploadFileName).append("\n\n");
				 mailBody.append(PLMConstants.OMM_MAIL_SIGNATURE)
				.append(PLMConstants.OMM_MAIL_FOOTER);
				saveXLSXFile(finalDataMap,fileDir,filePathXls);
				PLMUtils.generateZipFile(filePathXls,filePathZip);
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), filePathZip);
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@sendWhereUsdImplosionRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} catch (Exception exception) {
			LOG.log(Level.ERROR, "Exception@sendWhereUsdImplosionRptMail: ", exception);
			PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.OMM_MAIL_SIGNATURE + PLMConstants.OMM_MAIL_FOOTER);
		} finally {
			PLMUtils.deleteFiles(filePathXls,filePathZip);
		}
		LOG.info("Mail sent successfully.");
		LOG.info("Exiting sendWhereUsdImplosionRptMail Method");
	}
	
	/**
	 * This method is used for Generating Report in XLS
	 * 
	 * @return void
	 */
	
	public void saveXLSXFile(Map<String,List<PLMWhereUsedBOMData>> finalDataMap,String fileDir,String filePathXls) throws IOException {
		LOG.info("Entering saveXLSXFile Method");
		FileOutputStream fileOut = null;
		boolean createFileExist;
		List<PLMWhereUsedBOMData> finalDataList = new ArrayList<PLMWhereUsedBOMData>();
		try {
			File fileName = new File(filePathXls);
			boolean fileExist = fileName.exists();
			if(!fileExist) {
				createFileExist =fileName.createNewFile();
				LOG.info("createFileExist>>>>.."+createFileExist);
		 	}
			if (fileName.exists()) {
				fileOut = new FileOutputStream(filePathXls);
				SXSSFWorkbook workbook = new SXSSFWorkbook();
				
				// Start : POI Styles
				XSSFCellStyle headerStyle = (XSSFCellStyle) workbook.createCellStyle();
				headerStyle.setFillForegroundColor(HSSFColor.BLACK.index);
				headerStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
				
				XSSFFont headerFont = (XSSFFont) workbook.createFont(); 
				headerFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				headerFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				headerFont.setFontHeightInPoints((short)9);
				headerFont.setFontName("GE Inspira");
				headerFont.setColor(IndexedColors.WHITE.getIndex());
				headerStyle.setFont(headerFont);
				
				XSSFCellStyle searchFieldNameStyle = (XSSFCellStyle) workbook.createCellStyle();
				searchFieldNameStyle = setBorderStyle(searchFieldNameStyle);
				searchFieldNameStyle.setAlignment(CellStyle.ALIGN_RIGHT);
				
				XSSFFont boldFont = (XSSFFont) workbook.createFont();
				boldFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				boldFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				boldFont.setFontHeightInPoints((short)9);
				boldFont.setFontName("GE Inspira");
				boldFont.setColor(IndexedColors.BLACK.getIndex());
				searchFieldNameStyle.setFont(boldFont);
				
				XSSFFont cellstyleFont = (XSSFFont)workbook.createFont(); 
				cellstyleFont.setFontName(PLMConstants.EXCEL_FONT_NAME);
				
				cellstyleFont.setFontHeightInPoints((short)9);
				cellstyleFont.setFontName("GE Inspira");
				cellstyleFont.setColor(IndexedColors.BLACK.getIndex());
				
				XSSFCellStyle contentStyle = (XSSFCellStyle) workbook.createCellStyle();
				contentStyle = setBorderStyle(contentStyle);
				contentStyle.setFont(cellstyleFont);
				
				// cell hyper link
				//XSSFCreationHelper helper= (XSSFCreationHelper) workbook.getCreationHelper();
				
			    XSSFFont underLinedFont = (XSSFFont) workbook.createFont();
		        underLinedFont.setUnderline(HSSFFont.U_SINGLE);
		        underLinedFont.setColor(IndexedColors.BLUE.getIndex());
				XSSFCellStyle hyperLinkStyle = (XSSFCellStyle) workbook.createCellStyle();				
				hyperLinkStyle = setBorderStyle(hyperLinkStyle);
				hyperLinkStyle.setFont(underLinedFont);
				
				
				XSSFFont font = (XSSFFont) workbook.createFont(); 
				font.setFontName(PLMConstants.EXCEL_FONT_NAME);
				font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				font.setFontHeightInPoints((short)9);
				font.setFontName("GE Inspira");
				
				XSSFCellStyle cellBoldStyle = (XSSFCellStyle) workbook.createCellStyle();
				cellBoldStyle = setBorderStyle(cellBoldStyle);
				cellBoldStyle.setFont(font);
				
				SXSSFRow row = null;
				SXSSFCell cell = null;
				SXSSFSheet sheet =  null;
				
				int rowcount = -1;
						sheet = (SXSSFSheet) workbook.createSheet("BOM Implosion - Where Used");
						
						if (!PLMUtils.isEmptyMap(finalDataMap)) {
							finalDataList = finalDataMap.get("Default");
						}
							//Header
						if(!PLMUtils.isEmptyList(finalDataList)) {

							String[] colNames = {"Level","Parent Part Name","Description","F/N",
									"Qty","Revision","State","Matching Child","Matching Count","Match%"};
							
							row = (SXSSFRow) sheet.createRow(++rowcount);
							
							for ( int i = 0 ; i < colNames.length; i++ ) {
								cell = (SXSSFCell) row.createCell(i);
								cell.setCellStyle(headerStyle);
								cell. setCellValue(colNames[i]);
							}
							//Header
							for(int i = 0; i < finalDataList.size(); i++) {
								PLMWhereUsedBOMData dataObj = (PLMWhereUsedBOMData) finalDataList.get(i);
								row = (SXSSFRow) sheet.createRow(++rowcount);
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ZERO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getLevel());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_ONE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartNumber());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_TWO);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getDescription());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_THREE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getFindNum());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FOUR);
								/*if(!PLMUtils.isEmpty(dataObj.getPartId())){
									cell.setCellStyle(hyperLinkStyle);
									XSSFHyperlink url_link1 = helper.createHyperlink(Hyperlink.LINK_URL);
									url_link1.setAddress(resourceBundle.getString("TASK_SEARCH_REDIRECT_URL")+ dataObj.getPartId());
									cell.setHyperlink(url_link1);
									cell.setCellValue(dataObj.getPartNum());
								}else{*/
									cell.setCellStyle(contentStyle);
									cell.setCellValue(dataObj.getQuantity());
								//}
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_FIVE);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getRevision());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SIX);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getPartState());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_SEVEN);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getMatchingChild());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_EIGHT);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getMatchingCount());
								
								cell = (SXSSFCell) row.createCell(PLMConstants.EXCEL_COL_NINE);
								cell.setCellType(SXSSFCell.CELL_TYPE_NUMERIC);
								cell.setCellStyle(contentStyle);
								cell.setCellValue(dataObj.getMatchPrcnt());
								
								
						}
							
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_ZERO, 3000);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_ONE, 4500);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_TWO, 7500);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_THREE, 3500);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_FOUR, 3500);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_FIVE, 3500);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_SIX, 3500);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_SEVEN, 4500);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_EIGHT, 3500);
							sheet.setColumnWidth(PLMConstants.EXCEL_COL_NINE, 3000);
							
						}else{
							SXSSFRow row1 = (SXSSFRow) sheet.createRow(++rowcount);
							SXSSFCell cell1 = (SXSSFCell) row1.createCell(PLMConstants.EXCEL_COL_ZERO); 
							cell1.setCellValue("No Records Found");
							cell1.setCellStyle(contentStyle);
							sheet.autoSizeColumn(PLMConstants.EXCEL_COL_ZERO);
						}
						
				workbook.write(fileOut);
				fileOut.close();
			}
		} catch (FileNotFoundException e) {
			LOG.log(Level.ERROR, "Exception@saveXLSXFile: ", e);
			throw e;
		} catch (IOException e) {
			LOG.log(Level.ERROR, "Exception@saveXLSXFile: ", e);
			throw e;
		}  finally {
			try {
				if (fileOut != null) {
					fileOut.close();
				}
			} catch (IOException e) {
				LOG.log(Level.ERROR, "Exception@saveXLSXFile: ", e);
				throw e;
			}
		}
		LOG.info("Exiting saveXLSXFile Method");
	}
	
	/**
	 * This method is used for Bordering Cell in XLSX
	 * 
	 * @return StringBuffer
	 */
	private XSSFCellStyle setBorderStyle(XSSFCellStyle style) {
		style.setBorderTop(XSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		style.setBorderRight(XSSFCellStyle.BORDER_THIN);
		return style;
	}
	
	/**
	 * This method is used for Downloading the Input Format
	 * 
	 * @return String
	 */
	public String downloadInputTemplate() {
		LOG.info("Entering downloadInputTemplate Method");
		String fwdflag = PLMConstants.WHERE_USED_BOM_SEARCH;
		File storedfile = new File(resourceBundle.getString("OFFLINE_RPT_DIR")+ resourceBundle.getString("WHEREUSEDBOM_INPUTFILEFORMAT"));
		if (storedfile.exists()) {
			BufferedInputStream bufferedInputStream = null;
			String documentname = storedfile.getName();
			HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
			int length = 0;
			byte[] buf = new byte[1024];
			try {
				bufferedInputStream = new BufferedInputStream(new FileInputStream(storedfile));
				ServletOutputStream ouputStream = response.getOutputStream();
				while ((bufferedInputStream != null) && ((length = bufferedInputStream.read(buf)) != -1)) {
					ouputStream.write(buf, 0, (int) length);
				}
				response.setContentType("application/force-download");
				response.setHeader("Content-Disposition",
						"attachment; filename=" + documentname);
				FacesContext.getCurrentInstance().responseComplete();
			} catch (FileNotFoundException ex) {
				LOG.error("Exception : File Not Found : " + ex.getMessage());
			} catch (IOException ex1) {
				LOG.error("Exception : Error in Reading : " + ex1.getMessage());
			}
			finally {
				try {
					if (bufferedInputStream != null) {
						bufferedInputStream.close();
					}
				} catch (IOException e) {
					LOG.error("Exception in closing the bufferedInputStream : " + e.getMessage());
				}
			}
		} else {
			alertMsgBOM = PLMConstants.WHEREUSEDBOM_FILE_NOT_FOUND;
		}
		LOG.info("Exiting downloadInputTemplate Method");
		return fwdflag;
	}
	
	/**
	 * @return
	 */
	public String refreshFixForRichUploadTemplate() {
		return PLMConstants.WHERE_USED_BOM_SEARCH;
	}
	
	/**
	 * @return
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}
	/**
	 * @param taskExecutor
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}
	/**
	 * @return
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}
	/**
	 * @param resourceBundle
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}
	/**
	 * @return
	 */
	public PLMWhereUsedBOMData getPlmWhereUsedBOMData() {
		return plmWhereUsedBOMData;
	}
	/**
	 * @param plmWhereUsedBOMData
	 */
	public void setPlmWhereUsedBOMData(PLMWhereUsedBOMData plmWhereUsedBOMData) {
		this.plmWhereUsedBOMData = plmWhereUsedBOMData;
	}
	/**
	 * @return
	 */
	public String getAlertMsgBOM() {
		return alertMsgBOM;
	}
	/**
	 * @param alertMsgBOM
	 */
	public void setAlertMsgBOM(String alertMsgBOM) {
		this.alertMsgBOM = alertMsgBOM;
	}

	/**
	 * @return
	 */
	public PLMWhereUsedBOMServiceIfc getPlmWhereUsedBOMService() {
		return plmWhereUsedBOMService;
	}

	/**
	 * @param plmWhereUsedBOMService
	 */
	public void setPlmWhereUsedBOMService(
			PLMWhereUsedBOMServiceIfc plmWhereUsedBOMService) {
		this.plmWhereUsedBOMService = plmWhereUsedBOMService;
	}

	/**
	 * @return
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}
	/**
	 * @param commonMB
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}


	/**
	 * @return
	 */
	public PLMPwiUserData getUserDetails() {
		return userDetails;
	}


	/**
	 * @param userDetails
	 */
	public void setUserDetails(PLMPwiUserData userDetails) {
		this.userDetails = userDetails;
	}


	/**
	 * @return
	 */
	public List<PLMWhereUsedBOMData> getInputPartsList() {
		return inputPartsList;
	}


	/**
	 * @param inputPartsList
	 */
	public void setInputPartsList(List<PLMWhereUsedBOMData> inputPartsList) {
		this.inputPartsList = inputPartsList;
	}


	/**
	 * @return
	 */
	public String getLevelsUpTo() {
		return levelsUpTo;
	}


	/**
	 * @param levelsUpTo
	 */
	public void setLevelsUpTo(String levelsUpTo) {
		this.levelsUpTo = levelsUpTo;
	}


	/**
	 * @return
	 */
	public List<SelectItem> getSellevelsUpTo() {
		return sellevelsUpTo;
	}


	/**
	 * @param sellevelsUpTo
	 */
	public void setSellevelsUpTo(List<SelectItem> sellevelsUpTo) {
		this.sellevelsUpTo = sellevelsUpTo;
	}


	/**
	 * @return
	 */
	public String getLevelVal() {
		return levelVal;
	}


	/**
	 * @param levelVal
	 */
	public void setLevelVal(String levelVal) {
		this.levelVal = levelVal;
	}
}
