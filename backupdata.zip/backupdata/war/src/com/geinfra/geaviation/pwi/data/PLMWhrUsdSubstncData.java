/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhrUsdSubstncData.java
 * @Creation date: 01-Jan-2015
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMWhrUsdSubstncData {
	/**
	  * Holds the enteredSubstance
	  */
	private String enteredSubstance="";
	
	/**
	  * Holds the casSubstanceNum
	  */
	private String casSubstanceNum="";
	/**
	  * Holds the selectedMaterial
	  */
	private String selectedMaterial="";
	
	/**
	  * Holds the contract
	  */
	private String contract;
	/**
	  * Holds the project
	  */
	private String project;
	/**
	  * Holds the wbseName
	  */
	private String wbseName;
	/**
	  * Holds the wbsePartName
	  */
	private String wbsePartName;
	/**
	  * Holds the mliNew
	  */
	private String mliNew;
	/**
	  * Holds the poNumber
	  */
	private String poNumber;
	/**
	  * Holds the purFoldOffDTTM
	  */
	private String purFoldOffDTTM;
	/**
	  * Holds the suppName
	  */
	private String suppName;
	/**
	  * Holds the suppPerson
	  */
	private String suppPerson;
	/**
	  * Holds the suppEmail
	  */
	private String suppEmail;
	/**
	  * Holds the purFoldName
	  */
	private String purFoldName;
	/**
	  * Holds the suppBAANCode
	  */
	private String suppBAANCode;
	/**
	  * Holds the mliRef
	  */
	private String mliRef;
	/**
	  * Holds the partLevel
	  */
	private String partLevel;
	/**
	  * Holds the partNumber
	  */
	private String partNumber;
	/**
	  * Holds the partRevision
	  */
	private String partRevision;
	/**
	  * Holds the partType
	  */
	private String partType;
	/**
	  * Holds the partAttribute
	  */
	private String partAttribute;
	/**
	  * Holds the partTitle
	  */
	private String partTitle;
	/**
	  * Holds the material
	  */
	private String material;
	/**
	  * Holds the materialType
	  */
	private String materialType;
	/**
	  * Holds the subCASNum
	  */
	private String subCASNum;
	/**
	  * Holds the substance
	  */
	private String substance;
	/**
	  * Holds the regulation
	  */
	private String regulation;
	/**
	  * Holds the rdo
	  */
	private String rdo;
	
	
	
	
	
	
	
	
	
	/**
	 * @return the enteredSubstance
	 */
	public String getEnteredSubstance() {
		return enteredSubstance;
	}
	/**
	 * @param enteredSubstance the enteredSubstance to set
	 */
	public void setEnteredSubstance(String enteredSubstance) {
		this.enteredSubstance = enteredSubstance;
	}
	/**
	 * @return the casSubstanceNum
	 */
	public String getCasSubstanceNum() {
		return casSubstanceNum;
	}
	/**
	 * @param casSubstanceNum the casSubstanceNum to set
	 */
	public void setCasSubstanceNum(String casSubstanceNum) {
		this.casSubstanceNum = casSubstanceNum;
	}
	
	/**
	 * @return the selectedMaterial
	 */
	public String getSelectedMaterial() {
		return selectedMaterial;
	}
	/**
	 * @param selectedMaterial the selectedMaterial to set
	 */
	public void setSelectedMaterial(String selectedMaterial) {
		this.selectedMaterial = selectedMaterial;
	}
	/**
	 * @return the contract
	 */
	public String getContract() {
		return contract;
	}
	/**
	 * @param contract the contract to set
	 */
	public void setContract(String contract) {
		this.contract = contract;
	}
	/**
	 * @return the project
	 */
	public String getProject() {
		return project;
	}
	/**
	 * @param project the project to set
	 */
	public void setProject(String project) {
		this.project = project;
	}
	/**
	 * @return the wbseName
	 */
	public String getWbseName() {
		return wbseName;
	}
	/**
	 * @param wbseName the wbseName to set
	 */
	public void setWbseName(String wbseName) {
		this.wbseName = wbseName;
	}
	/**
	 * @return the wbsePartName
	 */
	public String getWbsePartName() {
		return wbsePartName;
	}
	/**
	 * @param wbsePartName the wbsePartName to set
	 */
	public void setWbsePartName(String wbsePartName) {
		this.wbsePartName = wbsePartName;
	}
	/**
	 * @return the mliNew
	 */
	public String getMliNew() {
		return mliNew;
	}
	/**
	 * @param mliNew the mliNew to set
	 */
	public void setMliNew(String mliNew) {
		this.mliNew = mliNew;
	}
	/**
	 * @return the poNumber
	 */
	public String getPoNumber() {
		return poNumber;
	}
	/**
	 * @param poNumber the poNumber to set
	 */
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	/**
	 * @return the purFoldOffDTTM
	 */
	public String getPurFoldOffDTTM() {
		return purFoldOffDTTM;
	}
	/**
	 * @param purFoldOffDTTM the purFoldOffDTTM to set
	 */
	public void setPurFoldOffDTTM(String purFoldOffDTTM) {
		this.purFoldOffDTTM = purFoldOffDTTM;
	}
	/**
	 * @return the suppName
	 */
	public String getSuppName() {
		return suppName;
	}
	/**
	 * @param suppName the suppName to set
	 */
	public void setSuppName(String suppName) {
		this.suppName = suppName;
	}
	/**
	 * @return the suppPerson
	 */
	public String getSuppPerson() {
		return suppPerson;
	}
	/**
	 * @param suppPerson the suppPerson to set
	 */
	public void setSuppPerson(String suppPerson) {
		this.suppPerson = suppPerson;
	}
	/**
	 * @return the suppEmail
	 */
	public String getSuppEmail() {
		return suppEmail;
	}
	/**
	 * @param suppEmail the suppEmail to set
	 */
	public void setSuppEmail(String suppEmail) {
		this.suppEmail = suppEmail;
	}
	/**
	 * @return the purFoldName
	 */
	public String getPurFoldName() {
		return purFoldName;
	}
	/**
	 * @param purFoldName the purFoldName to set
	 */
	public void setPurFoldName(String purFoldName) {
		this.purFoldName = purFoldName;
	}
	/**
	 * @return the suppBAANCode
	 */
	public String getSuppBAANCode() {
		return suppBAANCode;
	}
	/**
	 * @param suppBAANCode the suppBAANCode to set
	 */
	public void setSuppBAANCode(String suppBAANCode) {
		this.suppBAANCode = suppBAANCode;
	}
	/**
	 * @return the mliRef
	 */
	public String getMliRef() {
		return mliRef;
	}
	/**
	 * @param mliRef the mliRef to set
	 */
	public void setMliRef(String mliRef) {
		this.mliRef = mliRef;
	}
	/**
	 * @return the partLevel
	 */
	public String getPartLevel() {
		return partLevel;
	}
	/**
	 * @param partLevel the partLevel to set
	 */
	public void setPartLevel(String partLevel) {
		this.partLevel = partLevel;
	}
	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}
	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	/**
	 * @return the partRevision
	 */
	public String getPartRevision() {
		return partRevision;
	}
	/**
	 * @param partRevision the partRevision to set
	 */
	public void setPartRevision(String partRevision) {
		this.partRevision = partRevision;
	}
	/**
	 * @return the partType
	 */
	public String getPartType() {
		return partType;
	}
	/**
	 * @param partType the partType to set
	 */
	public void setPartType(String partType) {
		this.partType = partType;
	}
	/**
	 * @return the partAttribute
	 */
	public String getPartAttribute() {
		return partAttribute;
	}
	/**
	 * @param partAttribute the partAttribute to set
	 */
	public void setPartAttribute(String partAttribute) {
		this.partAttribute = partAttribute;
	}
	/**
	 * @return the partTitle
	 */
	public String getPartTitle() {
		return partTitle;
	}
	/**
	 * @param partTitle the partTitle to set
	 */
	public void setPartTitle(String partTitle) {
		this.partTitle = partTitle;
	}
	/**
	 * @return the material
	 */
	public String getMaterial() {
		return material;
	}
	/**
	 * @param material the material to set
	 */
	public void setMaterial(String material) {
		this.material = material;
	}
	/**
	 * @return the materialType
	 */
	public String getMaterialType() {
		return materialType;
	}
	/**
	 * @param materialType the materialType to set
	 */
	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}
	/**
	 * @return the subCASNum
	 */
	public String getSubCASNum() {
		return subCASNum;
	}
	/**
	 * @param subCASNum the subCASNum to set
	 */
	public void setSubCASNum(String subCASNum) {
		this.subCASNum = subCASNum;
	}
	/**
	 * @return the substance
	 */
	public String getSubstance() {
		return substance;
	}
	/**
	 * @param substance the substance to set
	 */
	public void setSubstance(String substance) {
		this.substance = substance;
	}
	/**
	 * @return the regulation
	 */
	public String getRegulation() {
		return regulation;
	}
	/**
	 * @param regulation the regulation to set
	 */
	public void setRegulation(String regulation) {
		this.regulation = regulation;
	}
	/**
	 * @return the rdo
	 */
	public String getRdo() {
		return rdo;
	}
	/**
	 * @param rdo the rdo to set
	 */
	public void setRdo(String rdo) {
		this.rdo = rdo;
	}


}
