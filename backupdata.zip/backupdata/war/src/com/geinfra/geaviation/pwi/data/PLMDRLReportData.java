/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMDRLReportData.java
 * @Creation date: 05-Nov-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMDRLReportData {
	
	/**
	 * Holds the enteredDrlName
	 */
	private String enteredDrlName;
	/**
	 * Holds the enteredContractNum
	 */
	private String enteredContractNum;
	/**
	 * Holds the enteredProjName
	 */
	private String enteredProjName;
	
	/**
	 * Holds the contractName
	 */
	private String contractName;
	/**
	 * Holds the prjName
	 */
	private String prjName;
	/**
	 * Holds the prjDesc
	 */
	private String prjDesc;
	/**
	 * Holds the drlName
	 */
	private String drlName;
	/**
	 * Holds the submittalName
	 */
	private String submittalName;
	/**
	 * Holds the submittalRev
	 */
	private String submittalRev;
	/**
	 * Holds the submittalStatus
	 */
	private String submittalStatus;
	/**
	 * Holds the submittalDate
	 */
	private String submittalDate;
	/**
	 * Holds the concernedEquipt
	 */
	private String concernedEquipt;
	/**
	 * Holds the concernedEquiptDesc
	 */
	private String concernedEquiptDesc;
	/**
	 * Holds the concernedDiscipline
	 */
	private String concernedDiscipline;
	/**
	 * Holds the docName
	 */
	private String docName;
	/**
	 * Holds the docRev
	 */
	private String docRev;
	/**
	 * Holds the docType
	 */
	private String docType;
	/**
	 * Holds the docType
	 */
	private String docCriticalCode;
	/**
	 * Holds the docTitle
	 */
	private String docTitle;
	/**
	 * Holds the frenchTitle
	 */
	private String frenchTitle;
	/**
	 * Holds the pldDocName
	 */
	private String pldDocName;
	/**
	 * Holds the pldDocRev
	 */
	private String pldDocRev;
	/**
	 * Holds the customerCode
	 */
	private String customerCode;
	/**
	 * Holds the customerCodeRev
	 */
	private String customerCodeRev;
	/**
	 * Holds the distributionCode
	 */
	private String distributionCode;
	/**
	 * Holds the clusterNm
	 */
	private String clusterNm;
	/**
	 * Holds the clusterRev
	 */
	private String clusterRev;
	/**
	 * Holds the wbseName
	 */
	private String wbseName;
	/**
	 * Holds the wbseRev
	 */
	private String wbseRev;
	/**
	 * Holds the dstbLstName
	 */
	private String dstbLstName;
	/**
	 * Holds the routeName
	 */
	private String routeName;
	/**
	 * Holds the routeState
	 */
	private String routeState;
	/**
	 * Holds the routeStartDate
	 */
	private String routeStartDate;
	/**
	 * Holds the clusterState
	 */
	private String clusterState;
	/**
	 * Holds the reportDate
	 */
	private String reportDate;
	
	
	
	/**
	 * @return the contractName
	 */
	public String getContractName() {
		return contractName;
	}
	/**
	 * @param contractName the contractName to set
	 */
	public void setContractName(String contractName) {
		this.contractName = contractName;
	}
	/**
	 * @return the prjName
	 */
	public String getPrjName() {
		return prjName;
	}
	/**
	 * @param prjName the prjName to set
	 */
	public void setPrjName(String prjName) {
		this.prjName = prjName;
	}
	/**
	 * @return the prjDesc
	 */
	public String getPrjDesc() {
		return prjDesc;
	}
	/**
	 * @param prjDesc the prjDesc to set
	 */
	public void setPrjDesc(String prjDesc) {
		this.prjDesc = prjDesc;
	}
	/**
	 * @return the drlName
	 */
	public String getDrlName() {
		return drlName;
	}
	/**
	 * @param drlName the drlName to set
	 */
	public void setDrlName(String drlName) {
		this.drlName = drlName;
	}
	/**
	 * @return the submittalName
	 */
	public String getSubmittalName() {
		return submittalName;
	}
	/**
	 * @param submittalName the submittalName to set
	 */
	public void setSubmittalName(String submittalName) {
		this.submittalName = submittalName;
	}
	/**
	 * @return the submittalRev
	 */
	public String getSubmittalRev() {
		return submittalRev;
	}
	/**
	 * @param submittalRev the submittalRev to set
	 */
	public void setSubmittalRev(String submittalRev) {
		this.submittalRev = submittalRev;
	}
	/**
	 * @return the submittalStatus
	 */
	public String getSubmittalStatus() {
		return submittalStatus;
	}
	/**
	 * @param submittalStatus the submittalStatus to set
	 */
	public void setSubmittalStatus(String submittalStatus) {
		this.submittalStatus = submittalStatus;
	}
	/**
	 * @return the submittalDate
	 */
	public String getSubmittalDate() {
		return submittalDate;
	}
	/**
	 * @param submittalDate the submittalDate to set
	 */
	public void setSubmittalDate(String submittalDate) {
		this.submittalDate = submittalDate;
	}
	/**
	 * @return the concernedEquipt
	 */
	public String getConcernedEquipt() {
		return concernedEquipt;
	}
	/**
	 * @param concernedEquipt the concernedEquipt to set
	 */
	public void setConcernedEquipt(String concernedEquipt) {
		this.concernedEquipt = concernedEquipt;
	}
	/**
	 * @return the concernedEquiptDesc
	 */
	public String getConcernedEquiptDesc() {
		return concernedEquiptDesc;
	}
	/**
	 * @param concernedEquiptDesc the concernedEquiptDesc to set
	 */
	public void setConcernedEquiptDesc(String concernedEquiptDesc) {
		this.concernedEquiptDesc = concernedEquiptDesc;
	}
	/**
	 * @return the concernedDiscipline
	 */
	public String getConcernedDiscipline() {
		return concernedDiscipline;
	}
	/**
	 * @param concernedDiscipline the concernedDiscipline to set
	 */
	public void setConcernedDiscipline(String concernedDiscipline) {
		this.concernedDiscipline = concernedDiscipline;
	}
	/**
	 * @return the docName
	 */
	public String getDocName() {
		return docName;
	}
	/**
	 * @param docName the docName to set
	 */
	public void setDocName(String docName) {
		this.docName = docName;
	}
	/**
	 * @return the docRev
	 */
	public String getDocRev() {
		return docRev;
	}
	/**
	 * @param docRev the docRev to set
	 */
	public void setDocRev(String docRev) {
		this.docRev = docRev;
	}
	/**
	 * @return the docType
	 */
	public String getDocType() {
		return docType;
	}
	/**
	 * @param docType the docType to set
	 */
	public void setDocType(String docType) {
		this.docType = docType;
	}
	/**
	 * @return the docCriticalCode
	 */
	public String getDocCriticalCode() {
		return docCriticalCode;
	}
	/**
	 * @param docCriticalCode the docCriticalCode to set
	 */
	public void setDocCriticalCode(String docCriticalCode) {
		this.docCriticalCode = docCriticalCode;
	}
	/**
	 * @return the docTitle
	 */
	public String getDocTitle() {
		return docTitle;
	}
	/**
	 * @param docTitle the docTitle to set
	 */
	public void setDocTitle(String docTitle) {
		this.docTitle = docTitle;
	}
	/**
	 * @return the frenchTitle
	 */
	public String getFrenchTitle() {
		return frenchTitle;
	}
	/**
	 * @param frenchTitle the frenchTitle to set
	 */
	public void setFrenchTitle(String frenchTitle) {
		this.frenchTitle = frenchTitle;
	}
	/**
	 * @return the pldDocName
	 */
	public String getPldDocName() {
		return pldDocName;
	}
	/**
	 * @param pldDocName the pldDocName to set
	 */
	public void setPldDocName(String pldDocName) {
		this.pldDocName = pldDocName;
	}
	/**
	 * @return the pldDocRev
	 */
	public String getPldDocRev() {
		return pldDocRev;
	}
	/**
	 * @param pldDocRev the pldDocRev to set
	 */
	public void setPldDocRev(String pldDocRev) {
		this.pldDocRev = pldDocRev;
	}
	/**
	 * @return the customerCode
	 */
	public String getCustomerCode() {
		return customerCode;
	}
	/**
	 * @param customerCode the customerCode to set
	 */
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	/**
	 * @return the customerCodeRev
	 */
	public String getCustomerCodeRev() {
		return customerCodeRev;
	}
	/**
	 * @param customerCodeRev the customerCodeRev to set
	 */
	public void setCustomerCodeRev(String customerCodeRev) {
		this.customerCodeRev = customerCodeRev;
	}
	/**
	 * @return the distributionCode
	 */
	public String getDistributionCode() {
		return distributionCode;
	}
	/**
	 * @param distributionCode the distributionCode to set
	 */
	public void setDistributionCode(String distributionCode) {
		this.distributionCode = distributionCode;
	}
	/**
	 * @return the clusterNm
	 */
	public String getClusterNm() {
		return clusterNm;
	}
	/**
	 * @param clusterNm the clusterNm to set
	 */
	public void setClusterNm(String clusterNm) {
		this.clusterNm = clusterNm;
	}
	/**
	 * @return the clusterRev
	 */
	public String getClusterRev() {
		return clusterRev;
	}
	/**
	 * @param clusterRev the clusterRev to set
	 */
	public void setClusterRev(String clusterRev) {
		this.clusterRev = clusterRev;
	}
	/**
	 * @return the wbseName
	 */
	public String getWbseName() {
		return wbseName;
	}
	/**
	 * @param wbseName the wbseName to set
	 */
	public void setWbseName(String wbseName) {
		this.wbseName = wbseName;
	}
	/**
	 * @return the wbseRev
	 */
	public String getWbseRev() {
		return wbseRev;
	}
	/**
	 * @param wbseRev the wbseRev to set
	 */
	public void setWbseRev(String wbseRev) {
		this.wbseRev = wbseRev;
	}
	/**
	 * @return the dstbLstName
	 */
	public String getDstbLstName() {
		return dstbLstName;
	}
	/**
	 * @param dstbLstName the dstbLstName to set
	 */
	public void setDstbLstName(String dstbLstName) {
		this.dstbLstName = dstbLstName;
	}
	/**
	 * @return the routeName
	 */
	public String getRouteName() {
		return routeName;
	}
	/**
	 * @param routeName the routeName to set
	 */
	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}
	/**
	 * @return the routeState
	 */
	public String getRouteState() {
		return routeState;
	}
	/**
	 * @param routeState the routeState to set
	 */
	public void setRouteState(String routeState) {
		this.routeState = routeState;
	}
	/**
	 * @return the routeStartDate
	 */
	public String getRouteStartDate() {
		return routeStartDate;
	}
	/**
	 * @param routeStartDate the routeStartDate to set
	 */
	public void setRouteStartDate(String routeStartDate) {
		this.routeStartDate = routeStartDate;
	}
	/**
	 * @return the enteredDrlName
	 */
	public String getEnteredDrlName() {
		return enteredDrlName;
	}		
	/**
	 * @param enteredDrlName the enteredDrlName to set
	 */
	public void setEnteredDrlName(String enteredDrlName) {
		this.enteredDrlName = enteredDrlName;
	}
	/**
	 * @return the enteredContractNum
	 */
	public String getEnteredContractNum() {
		return enteredContractNum;
	}
	/**
	 * @param enteredContractNum the enteredContractNum to set
	 */
	public void setEnteredContractNum(String enteredContractNum) {
		this.enteredContractNum = enteredContractNum;
	}
	/**
	 * @return the enteredProjName
	 */
	public String getEnteredProjName() {
		return enteredProjName;
	}
	/**
	 * @param enteredProjName the enteredProjName to set
	 */
	public void setEnteredProjName(String enteredProjName) {
		this.enteredProjName = enteredProjName;
	}
	/**
	 * @return the clusterState
	 */
	public String getClusterState() {
		return clusterState;
	}
	/**
	 * @param clusterState the clusterState to set
	 */
	public void setClusterState(String clusterState) {
		this.clusterState = clusterState;
	}
	/**
	 * @return the reportDate
	 */
	public String getReportDate() {
		return reportDate;
	}
	/**
	 * @param reportDate the reportDate to set
	 */
	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}

}
