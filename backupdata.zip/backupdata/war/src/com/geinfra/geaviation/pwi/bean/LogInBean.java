 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName LogInBean.java
 * @Creation date: 18-June-2014
 * @version 1.0
 * @author : Tech Mahindra
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.IOException;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class LogInBean {

	private static final Logger LOGGER = Logger.getLogger(LogInBean.class);


	private String ssoId;
	
	private String loginMsg;

	/*
	 * commented on 31-Oct-2014 as per Nimble report private UserInfoPortalUtil userInfoPortalUtil;
	 * 
	 * public void setUserInfoPortalUtil( UserInfoPortalUtil userInfoPortalUtil) {
	 * this.userInfoPortalUtil = userInfoPortalUtil; }
	 */

	public String getSsoId() {

		return ssoId;
	}


	public void setSsoId(String ssoId) {

		this.ssoId = ssoId;
	}
	/**
	 * @return the loginMsg
	 */
	public String getLoginMsg() {
		return loginMsg;
	}


	/**
	 * @param loginMsg the loginMsg to set
	 */
	public void setLoginMsg(String loginMsg) {
		this.loginMsg = loginMsg;
	}

	/**
	 * This method is used for Validate the local login User ID
	 * 
	 * @return String
	 * @throws ICMCommonException
	 */
	public String getSSOData() {
		String returnStr = null;
		LOGGER.info("ssoId >>>>>>>>>>" + ssoId);
		try {
			if (ssoId == null || ssoId.equals("")) {
				loginMsg = "Please Enter SSOID";
			} else if (ssoId.length() != PLMConstants.N_9) {
				loginMsg = "Field Length of SSO Should be 9";
				//returnStr = "login";
			} else {
				returnStr = "legalPage";
			}
		} catch (Exception ef) {
			LOGGER.log(Level.ERROR,
					"The Exception in getSSOData method of LogInBean is "
							+ ef.getMessage());
			returnStr = PLMConstants.ERROR;
		}
		return returnStr;
	}
	
	public String getRequestUrl() throws PWiException, IOException {
		LOGGER.info("Entering in to getRequestUrl>>>>>>>>");
		FacesContext context = FacesContext.getCurrentInstance();
		String rsltPage = "";
		String resultPage=(String) context.getExternalContext().getSessionMap().get("url");
		LOGGER.info("resultPage>>>>>>>>"+resultPage);
		if(resultPage.endsWith("cannedReports.jsf")){
			rsltPage = "cannedHome";
		}else{
			rsltPage = "landOnHome";
		}
		 LOGGER.info("getRequestUrl  navigation --> "+rsltPage);
		return rsltPage;
	}

	public String logIn() throws PWiException {

		FacesContext context = FacesContext.getCurrentInstance();
		PLMPwiUserData userData = null;
		String rsltPage = "";
	
		if (ssoId != null) {
			// get user roles
			context.getExternalContext().getSessionMap().put("ssoId", ssoId);
			userData = UserInfoPortalUtil.getInstance().getUserInfoDetails(ssoId);
			
			if (userData != null) {

				LOGGER.info("Obtained user info from PWI DB for " + ssoId);
				context.getExternalContext().getSessionMap().put(PWiConstants.USER_DATA, userData);
				
				HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
				boolean hasAPWiRole = false;
				boolean isEnabled = false;
				boolean hasPgPLMUserRole = false;
				boolean isAdmin = false;
				if (!PLMUtils.isEmptyList(userData.getRoleDtlList())) {
					hasAPWiRole = true;
				}
				try {
					isEnabled = userData.getEnabled();;
					hasPgPLMUserRole =  userData.isPwiPGPLMRl() || userData.isPwiPGPLMAdminRl() || userData.isPwiDGTFMIRl()
						            || userData.isPwiDGTAdminRl() || userData.isPwiPartCostRl();
					isAdmin = userData.isPwiAdminRl() || userData.isPwiPowerUsrRl() || userData.isPwiPGPLMAdminRl() ;
					LOGGER.info("inside LogInBean hasAPWiRole " + hasAPWiRole);
					LOGGER.info("inside LogInBean isEnabled " + isEnabled);
					LOGGER.info("inside LogInBean hasPgPLMUserRole " + hasPgPLMUserRole);
				} catch (Exception ex) {
					ex.printStackTrace();
				}

				if (!hasAPWiRole && !isEnabled) {
				    // log attempt (for jsf) and redirect to access page
				    // explaining the need to request access through IDM
				    if (request.getRequestURI().endsWith(".jsf")) {
						LOGGER.info("Unauthorized access attempt by " + ssoId);
						rsltPage = "helpDeskFrAccess";
				    }
				
				 } else if (!isAdmin) {
				     // ensure user is an admin user
				     if (request.getRequestURI().matches(PWiConstants.PATH_ADMIN_REGEX)) {
							rsltPage = "landOnHome";
				     }
				 } else if (!hasPgPLMUserRole) {
				     // log attempt (for jsf) and redirect to access page
				     // explaining the need to request access through IDM
						LOGGER.info("request.getRequestURI() --> "+request.getRequestURI());
				     if (request.getRequestURI().contains("/cannedreports/") || request.getRequestURI().endsWith("cannedReports.jsf")) {
							LOGGER.info("Unauthorized access attempt by " + ssoId + "for CannedReports.");
							rsltPage = "landOnHome";
				     }
				     rsltPage = "landOnHome";
				 } else {
					 LOGGER.info("landOnHome for Renewable User");
					 rsltPage = "landOnHome";
				 }
			} else {
				
				userData = UserInfoPortalUtil.getInstance().getUserDetailsIdm(ssoId);
				if (userData!=null) {
					LOGGER.info("Obtained user info from IDM DB for " + ssoId);
					context.getExternalContext().getSessionMap().put(PWiConstants.USER_DATA, userData);
				}
				rsltPage = "helpDeskFrAccess";
				return rsltPage;
			}
		}

		 LOGGER.info("rsltPage  navigation --> "+rsltPage);
		return rsltPage;

	}
}
