 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileNamePLMPwiUserData.java
 * @Creation date: 16-March-2015
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.data;

import java.io.Serializable;
import java.util.List;

public class PLMPwiUserData implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private int userId;

	private String userSSO;
	
	private String userFirstName;
	
	private String userLastName;
	
	private String userEmailId;

	private boolean enabled;
	
	private String usPerson;
	
	private String geEmployee;
	
	private List<PLMPwiRolesData> roleDtlList;
	
	private List<PLMPwiGroupsData> groupDtlList;
	
	private boolean pwiAdminRl;
	
	private boolean pwiPowerUsrRl;
	
	private boolean pwiUserRl;
	
	private boolean pwiRENUserRl;
	
	private boolean pwiPGPLMRl;
	
	private boolean pwiPGPLMAdminRl;
	
	private boolean pwiDGTFMIRl;
	
	private boolean pwiDGTAdminRl;
	
	private boolean pwiPartCostRl;
	
	private boolean sysLogEvnt;
	
	private boolean pwiDQBRl;
	
	private boolean pwiSysOpMapRl;
	

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserSSO() {
		return userSSO;
	}

	public void setUserSSO(String userSSO) {
		this.userSSO = userSSO;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public String getUserEmailId() {
		return userEmailId;
	}

	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}

	public boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
	public String getUsPerson() {
		return usPerson;
	}

	public void setUsPerson(String usPerson) {
		this.usPerson = usPerson;
	}

	public String getGeEmployee() {
		return geEmployee;
	}

	public void setGeEmployee(String geEmployee) {
		this.geEmployee = geEmployee;
	}

	public List<PLMPwiRolesData> getRoleDtlList() {
		return roleDtlList;
	}

	public void setRoleDtlList(List<PLMPwiRolesData> roleDtlList) {
		this.roleDtlList = roleDtlList;
	}

	public List<PLMPwiGroupsData> getGroupDtlList() {
		return groupDtlList;
	}

	public void setGroupDtlList(List<PLMPwiGroupsData> groupDtlList) {
		this.groupDtlList = groupDtlList;
	}

	public boolean isPwiAdminRl() {
		return pwiAdminRl;
	}

	public void setPwiAdminRl(boolean pwiAdminRl) {
		this.pwiAdminRl = pwiAdminRl;
	}

	public boolean isPwiPowerUsrRl() {
		return pwiPowerUsrRl;
	}

	public void setPwiPowerUsrRl(boolean pwiPowerUsrRl) {
		this.pwiPowerUsrRl = pwiPowerUsrRl;
	}

	public boolean isPwiUserRl() {
		return pwiUserRl;
	}

	public void setPwiUserRl(boolean pwiUserRl) {
		this.pwiUserRl = pwiUserRl;
	}

	public boolean isPwiRENUserRl() {
		return pwiRENUserRl;
	}

	public void setPwiRENUserRl(boolean pwiRENUserRl) {
		this.pwiRENUserRl = pwiRENUserRl;
	}

	public boolean isPwiPGPLMRl() {
		return pwiPGPLMRl;
	}

	public void setPwiPGPLMRl(boolean pwiPGPLMRl) {
		this.pwiPGPLMRl = pwiPGPLMRl;
	}

	public boolean isPwiPGPLMAdminRl() {
		return pwiPGPLMAdminRl;
	}

	public void setPwiPGPLMAdminRl(boolean pwiPGPLMAdminRl) {
		this.pwiPGPLMAdminRl = pwiPGPLMAdminRl;
	}

	public boolean isPwiDGTFMIRl() {
		return pwiDGTFMIRl;
	}

	public void setPwiDGTFMIRl(boolean pwiDGTFMIRl) {
		this.pwiDGTFMIRl = pwiDGTFMIRl;
	}

	public boolean isPwiDGTAdminRl() {
		return pwiDGTAdminRl;
	}

	public void setPwiDGTAdminRl(boolean pwiDGTAdminRl) {
		this.pwiDGTAdminRl = pwiDGTAdminRl;
	}

	public boolean isPwiPartCostRl() {
		return pwiPartCostRl;
	}

	public void setPwiPartCostRl(boolean pwiPartCostRl) {
		this.pwiPartCostRl = pwiPartCostRl;
	}
	
	/**
	 * @return the sysLogEvnt
	 */
	public boolean isSysLogEvnt() {
		return sysLogEvnt;
	}
	
	/**
	 * @param sysLogEvnt the sysLogEvnt to set
	 */
	public void setSysLogEvnt(boolean sysLogEvnt) {
		this.sysLogEvnt = sysLogEvnt;
	}

	public boolean isPwiDQBRl() {
		return pwiDQBRl;
	}

	public void setPwiDQBRl(boolean pwiDQBRl) {
		this.pwiDQBRl = pwiDQBRl;
	}

	public boolean isPwiSysOpMapRl() {
		return pwiSysOpMapRl;
	}

	public void setPwiSysOpMapRl(boolean pwiSysOpMapRl) {
		this.pwiSysOpMapRl = pwiSysOpMapRl;
	}
	
	
	
}
