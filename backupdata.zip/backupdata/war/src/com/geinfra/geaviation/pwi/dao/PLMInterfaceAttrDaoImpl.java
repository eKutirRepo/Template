/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMInterfaceAttrDaoImpl.java
 * @Creation date: 29-Aug-2014
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMInterfaceAttrData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMInterfaceAttrDaoImpl extends SimpleJdbcDaoSupport implements PLMInterfaceAttrDaoIfc{
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger
	.getLogger(PLMInterfaceAttrDaoImpl.class);

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
		 
	}
	/**
	 * Holds the SIMPLE_DATE_FORMAT
	 */
	/*private static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
	"MM/dd/yyyy");*/
	/**
	 * This method is used to getDropDownData
	 * @return java.util.Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getPartFamilyDropDownData() throws PLMCommonException {
		Map<String, List<SelectItem>> dropDownDataMap = new HashMap<String, List<SelectItem>>();
		List<SelectItem> partFamilyDDList = null;
		
		try{
			
		LOG.info("Query to get partFamilyDDList is: " + PLMSearchQueries.GET_PART_FAMILY_DD_LIST);
			
		partFamilyDDList = getSimpleJdbcTemplate().query(PLMSearchQueries.GET_PART_FAMILY_DD_LIST, new PartFamilyDDListMapper());
	
		dropDownDataMap.put("partFamilyDDList",partFamilyDDList);
				
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}catch(Exception e){
			e.printStackTrace();
		}
		return dropDownDataMap;
	}
	
	/**
	 * @return SelectItem objects.
	 */
	private static final class PartFamilyDDListMapper implements ParameterizedRowMapper<SelectItem> {
	
			public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
		   SelectItem selectItem = new SelectItem(rs.getString("NM"));
			return selectItem;
			}
		}
	
	/**
	 * This method is used to getAttrNameForPartFamily
	 * @return java.util.Map
	 * @param selectedPartFamily
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public Map<String, List<SelectItem>> getAttrNameForPartFamily(String selectedPartFamily) throws PLMCommonException {
		Map<String, List<SelectItem>> dropDownDataMap = new HashMap<String, List<SelectItem>>();
		
		try{
		LOG.info("Query to get Attribute Name for Part Family is: "+PLMSearchQueries.GET_ATTRIBUTE_NAME_FOR_PART_FAMILY);

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("PFNM", selectedPartFamily);
		List<SelectItem>attrNameForPartFamily = getNamedJdbcTemplate().
		query(PLMSearchQueries.GET_ATTRIBUTE_NAME_FOR_PART_FAMILY, params, new AttributeNameMapper());
		
		if (!PLMUtils.isEmptyList(attrNameForPartFamily)) {
			Collections.sort(attrNameForPartFamily, new PLMUtils.SortListSelItmLbl());
		}
		
		dropDownDataMap.put("attrNameForPartFamily", attrNameForPartFamily);
		
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		return dropDownDataMap;
	}
		
	/**
	 * @return SelectItem objects.
	 */
	private static final class AttributeNameMapper implements ParameterizedRowMapper<SelectItem> {
		public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
	   SelectItem selectItem = new SelectItem(rs.getString("ATTRIBUTE_NM"));
		return selectItem;
		}
	}
	
	//Newly Added Query String Constants for adding CDR_ODS_T_SYNTHETIC_PART table
	/**
	 * This method is used to get Result List
	 * 
	 * @param selectedPartFamily
	 * @param selectedAttributeName
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMInterfaceAttrData> getPartFamilyResultList(PLMInterfaceAttrData partFamilyIntAttrData) throws PLMCommonException {
		LOG.info("Inside getPartFamilyResultList(PLMPartFamilyIntAttrData partFamilyIntAttrData) in DAO Impl");
		List<PLMInterfaceAttrData> resultList = new ArrayList<PLMInterfaceAttrData>();
		StringBuffer partFamilyNoCPRQry1 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry2 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry3 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry4 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry5 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry6 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry7 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry8 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry9 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry10 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry11 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry12 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry13 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry14 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry15 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry16 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry17 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry18 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry19 = new StringBuffer();
		StringBuffer partFamilyNoCPRQry20 = new StringBuffer();
		
		StringBuffer partFamilyCPRQry1 = new StringBuffer();
		StringBuffer partFamilyCPRQry2 = new StringBuffer();
		StringBuffer partFamilyCPRQry3 = new StringBuffer();
		StringBuffer partFamilyCPRQry4 = new StringBuffer();
		StringBuffer partFamilyCPRQry5 = new StringBuffer();
		StringBuffer partFamilyCPRQry6 = new StringBuffer();
		StringBuffer partFamilyCPRQry7 = new StringBuffer();
		StringBuffer partFamilyCPRQry8 = new StringBuffer();
		StringBuffer partFamilyCPRQry9 = new StringBuffer();
		StringBuffer partFamilyCPRQry10 = new StringBuffer();
		StringBuffer partFamilyCPRQry11 = new StringBuffer();
		StringBuffer partFamilyCPRQry12 = new StringBuffer();
		StringBuffer partFamilyCPRQry13 = new StringBuffer();
		StringBuffer partFamilyCPRQry14 = new StringBuffer();
		StringBuffer partFamilyCPRQry15 = new StringBuffer();
		StringBuffer partFamilyCPRQry16 = new StringBuffer();
		StringBuffer partFamilyCPRQry17 = new StringBuffer();
		StringBuffer partFamilyCPRQry18 = new StringBuffer();
		StringBuffer partFamilyCPRQry19 = new StringBuffer();
		StringBuffer partFamilyCPRQry20 = new StringBuffer();
		StringBuffer partFamilyCPRQry21 = new StringBuffer();
		StringBuffer partFamilyCPRQry22 = new StringBuffer();
		StringBuffer partFamilyCPRQry23 = new StringBuffer();
		StringBuffer partFamilyCPRQry24 = new StringBuffer();
		StringBuffer partFamilyCPRQry25 = new StringBuffer();
		StringBuffer partFamilyCPRQry26 = new StringBuffer();
		StringBuffer partFamilyCPRQry27 = new StringBuffer();
		StringBuffer partFamilyCPRQry28 = new StringBuffer();
		StringBuffer partFamilyCPRQry29 = new StringBuffer();
		StringBuffer partFamilyCPRQry30 = new StringBuffer();
		StringBuffer partFamilyCPRQry31 = new StringBuffer();
		StringBuffer partFamilyCPRQry32 = new StringBuffer();
		StringBuffer partFamilyCPRQry33 = new StringBuffer();
		StringBuffer partFamilyCPRQry34 = new StringBuffer();
		StringBuffer partFamilyCPRQry35 = new StringBuffer();
		StringBuffer partFamilyCPRQry36 = new StringBuffer();
		StringBuffer partFamilyCPRQry37 = new StringBuffer();
		StringBuffer partFamilyCPRQry38 = new StringBuffer();
		StringBuffer partFamilyCPRQry39 = new StringBuffer();
		StringBuffer partFamilyCPRQry40 = new StringBuffer();
		
		
		try{
			boolean selectedCurrPrevRev = partFamilyIntAttrData.isSelectedCurrPrevRev();
			if(selectedCurrPrevRev){
				
				StringBuffer partFamilyFinalQry = new StringBuffer();
				
				LOG.info("Curr Prev Rev is Checked..............");
				partFamilyCPRQry1.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_1);
				partFamilyCPRQry2.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_2);
				partFamilyCPRQry3.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_3);
				partFamilyCPRQry4.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_3_ONE);
				partFamilyCPRQry5.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_4);
				partFamilyCPRQry6.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_5);
				partFamilyCPRQry7.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_6);  
				partFamilyCPRQry8.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_6_ONE);  
				partFamilyCPRQry9.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_7);    
				partFamilyCPRQry10.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_8);    
				partFamilyCPRQry11.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_9);  
				partFamilyCPRQry12.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_9_ONE);  
				partFamilyCPRQry13.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_10);  
				partFamilyCPRQry14.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_11);  
				partFamilyCPRQry15.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_12);  
				partFamilyCPRQry16.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_12_ONE);  
				partFamilyCPRQry17.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_13);  
				partFamilyCPRQry18.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_14);  
				partFamilyCPRQry19.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_15);  
				partFamilyCPRQry20.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_15_ONE);  
				partFamilyCPRQry21.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_16);   
				partFamilyCPRQry22.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_17);   
				partFamilyCPRQry23.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_18);   
				partFamilyCPRQry24.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_18_ONE);   
				partFamilyCPRQry25.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_19);   
				partFamilyCPRQry26.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_20);   
				partFamilyCPRQry27.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_21);   
				partFamilyCPRQry28.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_21_ONE);   
				partFamilyCPRQry29.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_22);   
				partFamilyCPRQry30.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_23);  
				partFamilyCPRQry31.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_24);   
				partFamilyCPRQry32.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_24_ONE);   
				partFamilyCPRQry33.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_25);   
				partFamilyCPRQry34.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_26);   
				partFamilyCPRQry35.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_27);   
				partFamilyCPRQry36.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_27_ONE);   
				partFamilyCPRQry37.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_28);   
				partFamilyCPRQry38.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_29);   
				partFamilyCPRQry39.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_30);   
				partFamilyCPRQry40.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_30_ONE);   
				
				if (partFamilyIntAttrData.getSelectedPartFamily() != null && !partFamilyIntAttrData.getSelectedPartFamily().equals("")) {
					
					partFamilyCPRQry1.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry1.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry2.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry2.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry3.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry3.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry4.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry4.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry5.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry5.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry6.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry6.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry7.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry7.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					
					partFamilyCPRQry8.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry8.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry9.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry9.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry10.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry10.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry11.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry11.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry12.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry12.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry13.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry13.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry14.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry14.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry15.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry15.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry16.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry16.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry17.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry17.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry18.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry18.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry19.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry19.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry20.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry20.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry21.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry21.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry22.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry22.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry23.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry23.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry24.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry24.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry25.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry25.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry26.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry26.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry27.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry27.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry28.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry28.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry29.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry29.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry30.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry30.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry31.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry31.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry32.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry32.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry33.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry33.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry34.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry34.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry35.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry35.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry36.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry36.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry37.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry37.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry38.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry38.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry39.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry39.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");
					partFamilyCPRQry40.append(" AND PART_FAMILY.NM= ");
					partFamilyCPRQry40.append("'"+partFamilyIntAttrData.getSelectedPartFamily()+"'");

				
					LOG.info("Part Family Name Added to Query: "+partFamilyIntAttrData.getSelectedPartFamily());
				}
				
				if (partFamilyIntAttrData.getSelectedAttributeName() != null && !partFamilyIntAttrData.getSelectedAttributeName().equals("")) {
					
					partFamilyCPRQry1.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry1.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry2.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry2.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry3.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry3.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry4.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry4.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry5.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry5.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry6.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry6.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					
					partFamilyCPRQry7.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry7.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry8.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry8.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry9.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry9.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry10.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry10.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry11.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry11.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry12.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry12.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry13.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry13.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry14.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry14.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry15.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry15.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry16.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry16.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry17.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry17.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry18.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry18.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry19.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry19.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry20.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry20.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry21.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry21.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry22.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry22.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry23.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry23.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry24.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry24.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry25.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry25.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry26.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry26.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry27.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry27.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry28.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry28.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry29.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry29.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry30.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry30.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry31.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry31.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry32.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry32.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry33.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry33.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry34.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry34.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry35.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry35.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry36.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry36.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry37.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry37.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry38.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry38.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry39.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry39.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					partFamilyCPRQry40.append(" AND ATTRIBUTE_NM= ");
					partFamilyCPRQry40.append("'"+partFamilyIntAttrData.getSelectedAttributeName()+"'");
					
					LOG.info("Attribute Name Added to Query: "+partFamilyIntAttrData.getSelectedAttributeName());
				}
				
				if (partFamilyIntAttrData.getSelectedPartNum() != null && !partFamilyIntAttrData.getSelectedPartNum().equals("") && partFamilyIntAttrData.getSelectedPartNum().length() > 0) {
					
					partFamilyCPRQry1.append(" AND PART_NAME IN ");
					partFamilyCPRQry1.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry2.append(" AND PART_NAME IN ");
					partFamilyCPRQry2.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry3.append(" AND PART_NAME IN ");
					partFamilyCPRQry3.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry4.append(" AND PART_NAME IN ");
					partFamilyCPRQry4.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry5.append(" AND PART_NAME IN ");
					partFamilyCPRQry5.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry6.append(" AND PART_NAME IN ");
					partFamilyCPRQry6.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					
					partFamilyCPRQry7.append(" AND PART_NAME IN ");
					partFamilyCPRQry7.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry8.append(" AND PART_NAME IN ");
					partFamilyCPRQry8.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry9.append(" AND PART_NAME IN ");
					partFamilyCPRQry9.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry10.append(" AND PART_NAME IN ");
					partFamilyCPRQry10.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry11.append(" AND PART_NAME IN ");
					partFamilyCPRQry11.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry12.append(" AND PART_NAME IN ");
					partFamilyCPRQry12.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry13.append(" AND PART_NAME IN ");
					partFamilyCPRQry13.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry14.append(" AND PART_NAME IN ");
					partFamilyCPRQry14.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry15.append(" AND PART_NAME IN ");
					partFamilyCPRQry15.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry16.append(" AND PART_NAME IN ");
					partFamilyCPRQry16.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry17.append(" AND PART_NAME IN ");
					partFamilyCPRQry17.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry18.append(" AND PART_NAME IN ");
					partFamilyCPRQry18.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry19.append(" AND PART_NAME IN ");
					partFamilyCPRQry19.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry20.append(" AND PART_NAME IN ");
					partFamilyCPRQry20.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry21.append(" AND PART_NAME IN ");
					partFamilyCPRQry21.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry22.append(" AND PART_NAME IN ");
					partFamilyCPRQry22.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry23.append(" AND PART_NAME IN ");
					partFamilyCPRQry23.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry24.append(" AND PART_NAME IN ");
					partFamilyCPRQry24.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry25.append(" AND PART_NAME IN ");
					partFamilyCPRQry25.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry26.append(" AND PART_NAME IN ");
					partFamilyCPRQry26.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry27.append(" AND PART_NAME IN ");
					partFamilyCPRQry27.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry28.append(" AND PART_NAME IN ");
					partFamilyCPRQry28.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry29.append(" AND PART_NAME IN ");
					partFamilyCPRQry29.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry30.append(" AND PART_NAME IN ");
					partFamilyCPRQry30.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry31.append(" AND PART_NAME IN ");
					partFamilyCPRQry31.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry32.append(" AND PART_NAME IN ");
					partFamilyCPRQry32.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry33.append(" AND PART_NAME IN ");
					partFamilyCPRQry33.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry34.append(" AND PART_NAME IN ");
					partFamilyCPRQry34.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry35.append(" AND PART_NAME IN ");
					partFamilyCPRQry35.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry36.append(" AND PART_NAME IN ");
					partFamilyCPRQry36.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry37.append(" AND PART_NAME IN ");
					partFamilyCPRQry37.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry38.append(" AND PART_NAME IN ");
					partFamilyCPRQry38.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry39.append(" AND PART_NAME IN ");
					partFamilyCPRQry39.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
					partFamilyCPRQry40.append(" AND PART_NAME IN ");
					partFamilyCPRQry40.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));

				
					//LOG.info("Part Name Added to Query: "+PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));

				}
				
				if (partFamilyIntAttrData.getSelectedInProcessStates() != null && partFamilyIntAttrData.getSelectedInProcessStates().size() > 0) {
					
					partFamilyCPRQry1.append(" AND PART_STATE IN ");
					partFamilyCPRQry1.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry2.append(" AND PART_STATE IN ");
					partFamilyCPRQry2.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry3.append(" AND PART_STATE IN ");
					partFamilyCPRQry4.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry4.append(" AND PART_STATE IN ");
					partFamilyCPRQry4.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry5.append(" AND PART_STATE IN ");
					partFamilyCPRQry6.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry6.append(" AND PART_STATE IN ");
					partFamilyCPRQry6.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					
					partFamilyCPRQry7.append(" AND PART_STATE IN ");
					partFamilyCPRQry7.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry8.append(" AND PART_STATE IN ");
					partFamilyCPRQry8.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry9.append(" AND PART_STATE IN ");
					partFamilyCPRQry9.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry10.append(" AND PART_STATE IN ");
					partFamilyCPRQry10.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry11.append(" AND PART_STATE IN ");
					partFamilyCPRQry11.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry12.append(" AND PART_STATE IN ");
					partFamilyCPRQry12.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry13.append(" AND PART_STATE IN ");
					partFamilyCPRQry13.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry14.append(" AND PART_STATE IN ");
					partFamilyCPRQry14.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry15.append(" AND PART_STATE IN ");
					partFamilyCPRQry15.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry16.append(" AND PART_STATE IN ");
					partFamilyCPRQry16.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry17.append(" AND PART_STATE IN ");
					partFamilyCPRQry17.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry18.append(" AND PART_STATE IN ");
					partFamilyCPRQry18.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry19.append(" AND PART_STATE IN ");
					partFamilyCPRQry19.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry20.append(" AND PART_STATE IN ");
					partFamilyCPRQry20.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry21.append(" AND PART_STATE IN ");
					partFamilyCPRQry21.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry22.append(" AND PART_STATE IN ");
					partFamilyCPRQry22.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry23.append(" AND PART_STATE IN ");
					partFamilyCPRQry23.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry24.append(" AND PART_STATE IN ");
					partFamilyCPRQry24.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry25.append(" AND PART_STATE IN ");
					partFamilyCPRQry25.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry26.append(" AND PART_STATE IN ");
					partFamilyCPRQry26.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry27.append(" AND PART_STATE IN ");
					partFamilyCPRQry27.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry28.append(" AND PART_STATE IN ");
					partFamilyCPRQry28.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry29.append(" AND PART_STATE IN ");
					partFamilyCPRQry29.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry30.append(" AND PART_STATE IN ");
					partFamilyCPRQry30.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry31.append(" AND PART_STATE IN ");
					partFamilyCPRQry31.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry32.append(" AND PART_STATE IN ");
					partFamilyCPRQry32.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry33.append(" AND PART_STATE IN ");
					partFamilyCPRQry33.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry34.append(" AND PART_STATE IN ");
					partFamilyCPRQry34.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry35.append(" AND PART_STATE IN ");
					partFamilyCPRQry35.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry36.append(" AND PART_STATE IN ");
					partFamilyCPRQry36.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry37.append(" AND PART_STATE IN ");
					partFamilyCPRQry37.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry38.append(" AND PART_STATE IN ");
					partFamilyCPRQry38.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry39.append(" AND PART_STATE IN ");
					partFamilyCPRQry39.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
					partFamilyCPRQry40.append(" AND PART_STATE IN ");
					partFamilyCPRQry40.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates())+")");
						
					
					LOG.info("In Process States Added to Query: "+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedInProcessStates()));
				}
				
				/*if (partFamilyIntAttrData.getSelectedPartType() != null && partFamilyIntAttrData.getSelectedPartType().size() > 0) {
					
					partFamilyCPRQry1.append(" AND PART_TYPE IN ");
					partFamilyCPRQry1.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedPartType())+")");
					partFamilyCPRQry2.append(" AND PART_TYPE IN ");
					partFamilyCPRQry2.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedPartType())+")");
					partFamilyCPRQry3.append(" AND PART_TYPE IN ");
					partFamilyCPRQry3.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedPartType())+")");
					partFamilyCPRQry4.append(" AND PART_TYPE IN ");
					partFamilyCPRQry4.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedPartType())+")");
					partFamilyCPRQry5.append(" AND PART_TYPE IN ");
					partFamilyCPRQry5.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedPartType())+")");
					partFamilyCPRQry6.append(" AND PART_TYPE IN ");
					partFamilyCPRQry6.append("("+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedPartType())+")");
					LOG.info("Part Types Added to Query: "+PLMUtils.setListForQuery(partFamilyIntAttrData.getSelectedPartType()));
				}*/
				
				partFamilyCPRQry1.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry2.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry3.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry4.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry5.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry6.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				
				partFamilyCPRQry7.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry8.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry9.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry10.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry11.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry12.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry13.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry14.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry15.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				//partFamilyCPRQry15.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_END);
				partFamilyCPRQry16.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry17.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry18.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry19.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry20.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry21.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry22.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry23.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry24.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry25.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry26.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry27.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry28.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry29.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry30.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry31.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry32.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry33.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry34.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry35.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry36.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry37.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry38.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry39.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				partFamilyCPRQry40.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_GROUPBY);
				
				
				boolean prtSelFlg = false;
				boolean vPrtSelFlg = false;
				boolean kPrtSelFlg = false;
				boolean sPrtSelFlg = false;
				if (partFamilyIntAttrData.getSelectedPartType() != null && partFamilyIntAttrData.getSelectedPartType().size() > 0) {
					for (String partType : partFamilyIntAttrData.getSelectedPartType()) {
						if (partType.equals("Part")){
							prtSelFlg = true;
						}
						if (partType.equals("GE Vendor Part")){
							vPrtSelFlg = true;
						}
						if (partType.equals("GE Mfg/Svcs Kit Part")){
							kPrtSelFlg = true;
						}
						if (partType.equals("Synthetic Part")){
							sPrtSelFlg = true;
						}
					}
				} else {
					prtSelFlg = true;
					vPrtSelFlg = true;
					kPrtSelFlg = true;
					sPrtSelFlg = true;
				}
				boolean selFlg1 = false;
				boolean selFlg2 = false;
				LOG.info("Before Final Query the flag values prtSelFlg --> "+prtSelFlg);
				LOG.info("Before Final Query the flag values vPrtSelFlg --> "+vPrtSelFlg);
				LOG.info("Before Final Query the flag values kPrtSelFlg --> "+kPrtSelFlg);
				LOG.info("Before Final Query the flag values sPrtSelFlg --> "+sPrtSelFlg);
				partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_STR);
				if (prtSelFlg) {
					partFamilyFinalQry.append(partFamilyCPRQry1);
					selFlg1 = true;
				}
				if (vPrtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry2);
				}
				if (kPrtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry3);
				}
				if (sPrtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry4);
				}
				if (prtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry5);
				}
				if (vPrtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry6);
				}
				if (kPrtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry7);
				}
				if (sPrtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry8);
				}
				if (prtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry9);
				}
				if (vPrtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry10);
				}
				if (kPrtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry11);
				}
				if (sPrtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry12);
				}
				if (prtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry13);
				}
				if (vPrtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry14);
				}
				if (kPrtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry15);
				}
				if (sPrtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry16);
				}
				if (prtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry17);
				}
				if (vPrtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry18);
				}
				if (kPrtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry19);
				}
				if (sPrtSelFlg) {
					if (selFlg1){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					partFamilyFinalQry.append(partFamilyCPRQry20);
				}
				partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_END);
				partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNION);
				partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_STR);
				if (prtSelFlg) {
					partFamilyFinalQry.append(partFamilyCPRQry21);
					selFlg2 = true;
				}
				if (vPrtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry22);
				}
				if (kPrtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry23);
				}
				if (sPrtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry24);
				}
				if (prtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry25);
				}
				if (vPrtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry26);
				}
				if (kPrtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry27);
				}
				if (sPrtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry28);
				}
				if (prtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry29);
				}
				if (vPrtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry30);
				}
				if (kPrtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry31);
				}
				if (sPrtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry32);
				}
				if (prtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry33);
				}
				if (vPrtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry34);
				}
				if (kPrtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry35);
				}
				if (sPrtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry36);
				}
				if (prtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry37);
				}
				if (vPrtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry38);
				}
				if (kPrtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry39);
				}
				if (sPrtSelFlg) {
					if (selFlg2){
						partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg2 = true;
					partFamilyFinalQry.append(partFamilyCPRQry40);
				}
				partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_END);

				partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_31);
				partFamilyFinalQry.append(PLMUtils.generateQueryForMultipleNamesPFIA(partFamilyIntAttrData.getSelectedPartNum()));
				partFamilyFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_32);
				
				LOG.info("Final Query of Curr Prev Rev is Checked getting part family Result List ::"+partFamilyFinalQry.toString());
				resultList = getSimpleJdbcTemplate().query(partFamilyFinalQry.toString(), new PartFamilyResultMapper());


			}
			else{
				
				StringBuffer prtFmlyNoCprFinalQry = new StringBuffer();

				Map<String, Object> params = new HashMap<String, Object>();
				
				LOG.info("Curr Prev Rev is Not Checked..............");
				
				partFamilyNoCPRQry1.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_1);
				partFamilyNoCPRQry2.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_2); 
				partFamilyNoCPRQry3.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_2_ONE); 
				partFamilyNoCPRQry4.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_3); 
				partFamilyNoCPRQry5.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_4); 
				partFamilyNoCPRQry6.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_5); 
				partFamilyNoCPRQry7.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_5_ONE); 
				partFamilyNoCPRQry8.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_6); 
				partFamilyNoCPRQry9.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_7); 
				partFamilyNoCPRQry10.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_8);
				partFamilyNoCPRQry11.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_8_ONE);
				partFamilyNoCPRQry12.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_9);
				partFamilyNoCPRQry13.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_10);
				partFamilyNoCPRQry14.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_11);
				partFamilyNoCPRQry15.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_11_ONE);
				partFamilyNoCPRQry16.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_12);
				partFamilyNoCPRQry17.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_13);
				partFamilyNoCPRQry18.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_14);
				partFamilyNoCPRQry19.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_14_ONE);
				partFamilyNoCPRQry20.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_15);
				

				if (partFamilyIntAttrData.getSelectedPartFamily() != null 
						&& !partFamilyIntAttrData.getSelectedPartFamily().equals("")) {
					
					params.put("PFNM", partFamilyIntAttrData.getSelectedPartFamily());
					
					partFamilyNoCPRQry1.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM);
					partFamilyNoCPRQry2.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM); 
					partFamilyNoCPRQry3.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM); 
					partFamilyNoCPRQry4.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM); 
					partFamilyNoCPRQry5.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM); 
					partFamilyNoCPRQry6.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM); 
					partFamilyNoCPRQry7.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM); 
					partFamilyNoCPRQry8.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM); 
					partFamilyNoCPRQry9.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM); 
					partFamilyNoCPRQry10.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM);
					partFamilyNoCPRQry11.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM);
					partFamilyNoCPRQry12.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM);
					partFamilyNoCPRQry13.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM);
					partFamilyNoCPRQry14.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM);
					partFamilyNoCPRQry15.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM);
					partFamilyNoCPRQry16.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM);
					partFamilyNoCPRQry17.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM);
					partFamilyNoCPRQry18.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM);
					partFamilyNoCPRQry19.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM);
					partFamilyNoCPRQry20.append(PLMSearchQueries.PART_FMLY_RSLT_PF_NM);
				
				}

				if (partFamilyIntAttrData.getSelectedAttributeName() != null 
						&& !partFamilyIntAttrData.getSelectedAttributeName().equals("")) {
					
					params.put("ATRNM", partFamilyIntAttrData.getSelectedAttributeName());
					
					partFamilyNoCPRQry1.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM);
					partFamilyNoCPRQry2.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM); 
					partFamilyNoCPRQry3.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM); 
					partFamilyNoCPRQry4.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM); 
					partFamilyNoCPRQry5.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM); 
					partFamilyNoCPRQry6.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM); 
					partFamilyNoCPRQry7.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM); 
					partFamilyNoCPRQry8.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM); 
					partFamilyNoCPRQry9.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM); 
					partFamilyNoCPRQry10.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM);
					partFamilyNoCPRQry11.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM);
					partFamilyNoCPRQry12.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM);
					partFamilyNoCPRQry13.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM);
					partFamilyNoCPRQry14.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM);
					partFamilyNoCPRQry15.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM);
					partFamilyNoCPRQry16.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM);
					partFamilyNoCPRQry17.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM);
					partFamilyNoCPRQry18.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM);
					partFamilyNoCPRQry19.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM);
					partFamilyNoCPRQry20.append(PLMSearchQueries.PART_FMLY_RSLT_ATTR_NM);
				}

				if (partFamilyIntAttrData.getSelectedPartNum() != null 
						&& !partFamilyIntAttrData.getSelectedPartNum().equals("") 
						&& partFamilyIntAttrData.getSelectedPartNum().length() > 0) {
					
					String[] partNumArr = partFamilyIntAttrData.getSelectedPartNum().split(",");
					
					List<String> partNumLst = new ArrayList<String>();
					
					for (int i=0;i<partNumArr.length;i++){
						if (!PLMUtils.isEmpty(partNumArr[i].trim())) {
							partNumLst.add(partNumArr[i].trim());
						}
					}
					
					params.put("PRTNM", partNumLst);
					
					partFamilyNoCPRQry1.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM);
					partFamilyNoCPRQry2.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM); 
					partFamilyNoCPRQry3.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM); 
					partFamilyNoCPRQry4.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM); 
					partFamilyNoCPRQry5.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM); 
					partFamilyNoCPRQry6.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM); 
					partFamilyNoCPRQry7.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM); 
					partFamilyNoCPRQry8.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM); 
					partFamilyNoCPRQry9.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM); 
					partFamilyNoCPRQry10.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM);
					partFamilyNoCPRQry11.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM);
					partFamilyNoCPRQry12.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM);
					partFamilyNoCPRQry13.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM);
					partFamilyNoCPRQry14.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM);
					partFamilyNoCPRQry15.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM);
					partFamilyNoCPRQry16.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM);
					partFamilyNoCPRQry17.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM);
					partFamilyNoCPRQry18.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM);
					partFamilyNoCPRQry19.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM);
					partFamilyNoCPRQry20.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_NUM);
				}

				if (partFamilyIntAttrData.getSelectedInProcessStates() != null 
						&& partFamilyIntAttrData.getSelectedInProcessStates().size() > 0) {

					params.put("PRTST", partFamilyIntAttrData.getSelectedInProcessStates());
					
					partFamilyNoCPRQry1.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST);
					partFamilyNoCPRQry2.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST); 
					partFamilyNoCPRQry3.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST); 
					partFamilyNoCPRQry4.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST); 
					partFamilyNoCPRQry5.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST); 
					partFamilyNoCPRQry6.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST); 
					partFamilyNoCPRQry7.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST); 
					partFamilyNoCPRQry8.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST); 
					partFamilyNoCPRQry9.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST); 
					partFamilyNoCPRQry10.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST);
					partFamilyNoCPRQry11.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST);
					partFamilyNoCPRQry12.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST);
					partFamilyNoCPRQry13.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST);
					partFamilyNoCPRQry14.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST);
					partFamilyNoCPRQry15.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST);
					partFamilyNoCPRQry16.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST);
					partFamilyNoCPRQry17.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST);
					partFamilyNoCPRQry18.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST);
					partFamilyNoCPRQry19.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST);
					partFamilyNoCPRQry20.append(PLMSearchQueries.PART_FMLY_RSLT_PRT_ST);
				}

				partFamilyNoCPRQry1.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY);
				partFamilyNoCPRQry2.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY); 
				partFamilyNoCPRQry3.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY); 
				partFamilyNoCPRQry4.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY); 
				partFamilyNoCPRQry5.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY); 
				partFamilyNoCPRQry6.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY); 
				partFamilyNoCPRQry7.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY); 
				partFamilyNoCPRQry8.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY); 
				partFamilyNoCPRQry9.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY); 
				partFamilyNoCPRQry10.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY);
				partFamilyNoCPRQry11.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY);
				partFamilyNoCPRQry12.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY);
				partFamilyNoCPRQry13.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY);
				partFamilyNoCPRQry14.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY);
				partFamilyNoCPRQry15.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY);
				partFamilyNoCPRQry16.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY);
				partFamilyNoCPRQry17.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY);
				partFamilyNoCPRQry18.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY);
				partFamilyNoCPRQry19.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY);
				partFamilyNoCPRQry20.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_GROUPBY);
				
				boolean prtSelFlg = false;
				boolean vPrtSelFlg = false;
				boolean kPrtSelFlg = false;
				boolean sPrtSelFlg = false;
				if (partFamilyIntAttrData.getSelectedPartType() != null && partFamilyIntAttrData.getSelectedPartType().size() > 0) {
					for (String partType : partFamilyIntAttrData.getSelectedPartType()) {
						if (partType.equals("Part")){
							prtSelFlg = true;
						}
						if (partType.equals("GE Vendor Part")){
							vPrtSelFlg = true;
						}
						if (partType.equals("GE Mfg/Svcs Kit Part")){
							kPrtSelFlg = true;
						}
						if (partType.equals("Synthetic Part")){
							sPrtSelFlg = true;
						}
					}
				} else {
					prtSelFlg = true;
					vPrtSelFlg = true;
					kPrtSelFlg = true;
					sPrtSelFlg = true;
				}
				boolean selFlg1 = false;
				LOG.info("Before Final Query the flag values prtSelFlg --> "+prtSelFlg);
				LOG.info("Before Final Query the flag values vPrtSelFlg --> "+vPrtSelFlg);
				LOG.info("Before Final Query the flag values kPrtSelFlg --> "+kPrtSelFlg);
				LOG.info("Before Final Query the flag values sPrtSelFlg --> "+sPrtSelFlg);
				
				prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_STR);
				if (prtSelFlg) {
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry1);
					selFlg1 = true;
				}
				if (kPrtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry2);
				}
				if (sPrtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry3);
				}
				if (vPrtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry4);
				}
				if (prtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry5);
				}
				if (kPrtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry6);
				}
				if (sPrtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry7);
				}
				if (vPrtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry8);
				}
				if (prtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry9);
				}
				if (kPrtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry10);
				}
				if (sPrtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry11);
				}
				if (vPrtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry12);
				}
				if (prtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry13);
				}
				if (kPrtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry14);
				}
				if (sPrtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry15);
				}
				if (vPrtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry16);
				}
				if (prtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry17);
				}
				if (kPrtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry18);
				}
				if (sPrtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry19);
				}
				if (vPrtSelFlg) {
					if (selFlg1){
						prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_CPR_UNIONALL);
					}
					selFlg1 = true;
					prtFmlyNoCprFinalQry.append(partFamilyNoCPRQry20);
				}
				
				prtFmlyNoCprFinalQry.append(PLMSearchQueries.PART_FAMILY_RESULT_NOCPR_END);
				
				LOG.info("Final Query for Curr Prev Rev is Un Checked getting part family Result List ::"+prtFmlyNoCprFinalQry.toString());
				resultList = getNamedJdbcTemplate().query(prtFmlyNoCprFinalQry.toString(), params, new PartFamilyResultMapper());
			}
			
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		
		if (!PLMUtils.isEmptyList(resultList)) {
			Collections.sort(resultList, new SortPfRslt());
		}
		LOG.info("Existing getPartFamilyResultList(PLMPartFamilyIntAttrData partFamilyIntAttrData) in DAO Impl");
		LOG.info("Result List size is"+resultList.size());
		return resultList;
	}
	
	/**
	 * 
	 * class to sort list of object of type PLMFmiTemplateData
	 * 
	 */
	private static class SortPfRslt implements Comparator<PLMInterfaceAttrData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMInterfaceAttrData aString,
				PLMInterfaceAttrData bString) {
			
			int result= aString.getPartName().compareTo(bString.getPartName());
		       if (result != 0)
		       {
		           return result;
		       }
		       result = aString.getRevision().compareTo(bString.getRevision());
		       if (result != 0)
		       {
		           return result; 
		       }
		       
		      return aString.getAttributeNm().compareTo(bString.getAttributeNm());
		      
		}
	}
	/**
	 * @return .
	 */
	private static final class PartFamilyResultMapper implements ParameterizedRowMapper<PLMInterfaceAttrData> {
		public PLMInterfaceAttrData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMInterfaceAttrData resultList = new PLMInterfaceAttrData();
			
			resultList.setPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
			resultList.setPartTitle(PLMUtils.checkNullVal(rs.getString("PART_TITLE")));
			resultList.setRevision(PLMUtils.checkNullVal(rs.getString("REVISION")));
			resultList.setRdo(PLMUtils.checkNullVal(rs.getString("RDO")));
			resultList.setPartType(PLMUtils.checkNullVal(rs.getString("PART_TYPE")));
			resultList.setPartState(PLMUtils.checkNullVal(rs.getString("PART_STATE")));
			
			/*if(!PLMUtils.isEmpty(rs.getString("PART_STATE_DATE"))){
				resultList.setPartStateDate(SIMPLE_DATE_FORMAT.format(rs.getDate("PART_STATE_DATE")));
				}
				else {
					resultList.setPartStateDate("");
				}*/
			
			resultList.setPartFamilyNm(PLMUtils.checkNullVal(rs.getString("PART_FAMILY_NM")));
			resultList.setPartFamilyDescription(PLMUtils.checkNullVal(rs.getString("PART_FAMILY_DESCRIPTION")));
			resultList.setInterfaceName(PLMUtils.checkNullVal(rs.getString("INTERFACE_NAME")));
			resultList.setAttributeGroup(PLMUtils.checkNullVal(rs.getString("ATTRIBUTE_GROUP")));
			resultList.setAttributeNm(PLMUtils.checkNullVal(rs.getString("ATTRIBUTE_NM")));
			resultList.setAttributeValue(PLMUtils.checkNullVal(rs.getString("ATTRIBUTE_VALUE")));
			
		return resultList;
		}
	}
		
}
 
