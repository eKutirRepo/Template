/**
 * Copyright (C) 2014 GE Infra. All rights reserved
 * 
 * @FileName UserDAOImpl.java
 * @Creation date: 20-Mar-2015
 * @version 1.0
 * @author : Tech Mahindra (PWi Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import com.geinfra.geaviation.pwi.data.PLMPwiRolesData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.model.PWiQueryGroupVO;
import com.geinfra.geaviation.pwi.model.PWiUserVO;
import com.geinfra.geaviation.pwi.util.ColumnConstants;
import com.geinfra.geaviation.pwi.util.MapperConstants.RowCounter;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMQueryConstants;
import com.geinfra.geaviation.pwi.util.PLMSendMailUtil;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.util.QueryConstants;
import com.geinfra.geaviation.pwi.util.QueryLoader;

public class UserDAOImpl implements UserDAO {

	private static final Logger LOG = Logger.getLogger(UserDAOImpl.class);
	private JdbcTemplate jdbcTemplate;


	private JdbcTemplate personJdbcTemplate;


	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {

		this.jdbcTemplate = jdbcTemplate;
	}


	public JdbcTemplate getPersonJdbcTemplate() {

		return personJdbcTemplate;
	}


	public void setPersonJdbcTemplate(JdbcTemplate personJdbcTemplate) {

		this.personJdbcTemplate = personJdbcTemplate;
	}
	/**
	 * Holds the ResourceBundle.
	 */
	private static ResourceBundle rbundle = ResourceBundle
			.getBundle(PLMConstants.ENV_PROP_FILE);

	/**
	 * mailBean.
	 */
	private PLMSendMailUtil mailBean;
	/**
	 * mailSend.
	 */
	private JavaMailSenderImpl mailSend;
	
	/**
	 * @return the mailBean
	 */
	public PLMSendMailUtil getMailBean() {
		return mailBean;
	}

	/**
	 * @param mailBean
	 *  the mailBean to set
	 */
	public void setMailBean(PLMSendMailUtil mailBeana) {
		this.mailBean = mailBeana;
	}
	/**
	 * @return the mailSend
	 */
	public JavaMailSenderImpl getMailSend() {
		return mailSend;
	}

	/**
	 * @param mailSend
	 *            the mailSend to set
	 */
	public void setMailSend(JavaMailSenderImpl mailSenda) {
		this.mailSend = mailSenda;
	}
	public List<PWiUserVO> findAllPWiUsers() {

		final ParameterizedRowMapper<PWiUserVO> mapper = new PWiUserVORowMapper();

		@SuppressWarnings("unchecked")
		List<PWiUserVO> result = (List<PWiUserVO>) jdbcTemplate.query(QueryLoader.getQuery(QueryConstants.PWi_USERS), mapper);
		return result;
	}


	public List<PWiUserVO> findUsersforSelectedGroups(String availableQueryGroup) {

		String sql =
							"select distinct(pwi_name),pwi_Users.PWI_UID,pwi_Users.PWI_UNAME,pwi_Users.PWI_GIVENNAME,pwi_Users.PWI_FAMILYNAME,pwi_Users.PWI_VIEWREALEMAIL,pwi_Users.PWI_ENABLED,pwi_roles.pwi_name from PLMR.pwi_roles ,PLMR.PWI_ROLE_MEMBERSHIP,PLMR.pwi_Users where pwi_roles.pwi_rid= PWI_ROLE_MEMBERSHIP.pwi_rid and PWI_ROLE_MEMBERSHIP.pwi_uid=pwi_Users.pwi_uid and pwi_roles.pwi_name = ?";

		final ParameterizedRowMapper<PWiUserVO> mapper = new PWiUserForGroupVORowMapper();
		final PreparedStatementSetter setter = new GroupNamesSetter(availableQueryGroup);

		@SuppressWarnings("unchecked")
		List<PWiUserVO> result = (List<PWiUserVO>) jdbcTemplate.query(sql, setter, mapper);

		return result;


	}


	private static class GroupNamesSetter implements PreparedStatementSetter {

		private String group;


		public GroupNamesSetter(String group) {

			this.group = group;
		}


		public void setValues(PreparedStatement ps) throws SQLException {

			int parameterIndex = 1;

			ps.setString(parameterIndex, group);

		}


	}


	public static class PWiUserForGroupVORowMapper implements ParameterizedRowMapper<PWiUserVO> {

		public PWiUserVO mapRow(ResultSet rs, int rowNum) throws SQLException {

			PWiUserVO PWiUserVO = new PWiUserVO();
			PWiUserVO.setUserSelected(true);
			PWiUserVO.setRoleName(rs.getString(ColumnConstants.PWI_NAME));
			PWiUserVO.setUserId(Integer.valueOf(rs.getString(ColumnConstants.PWI_UID)));
			PWiUserVO.setSso(rs.getString(ColumnConstants.PWI_UNAME));
			PWiUserVO.setUserNm(rs.getString(ColumnConstants.PWI_GIVENNAME));
			PWiUserVO.setUserLastNm(rs.getString(ColumnConstants.PWI_FAMILYNAME));
			PWiUserVO.setEmail(rs.getString(ColumnConstants.PWI_VIEWREALEMAIL));
			PWiUserVO.setEnabled("Y".equals(rs.getString(ColumnConstants.PWI_ENABLED)));
			return PWiUserVO;
		}
	}


	public static class PWiUserVORowMapper implements ParameterizedRowMapper<PWiUserVO> {

		public PWiUserVO mapRow(ResultSet rs, int rowNum) throws SQLException {

			PWiUserVO PWiUserVO = new PWiUserVO();
			PWiUserVO.setUserId(Integer.valueOf(rs.getString(ColumnConstants.PWI_UID)));
			PWiUserVO.setSso(rs.getString(ColumnConstants.PWI_UNAME));
			PWiUserVO.setUserNm(rs.getString(ColumnConstants.PWI_GIVENNAME));
			PWiUserVO.setUserLastNm(rs.getString(ColumnConstants.PWI_FAMILYNAME));
			PWiUserVO.setEmail(rs.getString(ColumnConstants.PWI_VIEWREALEMAIL));
			PWiUserVO.setEnabled("Y".equals(rs.getString(ColumnConstants.PWI_ENABLED)));;
			return PWiUserVO;
		}
	}


	public PWiUserVO getUserById(Integer userId) {

		// Retrieve SQL with bind parameters
		String sql = QueryLoader.getQuery(QueryConstants.PWi_USER_ID);

		// Define prepared statement setter
		PreparedStatementSetter pss = new GetUserByIdSetter(userId);

		// Define row mapper
		RowMapper rowMapper = new PWiUserVORowMapper();

		// Run query on database
		@SuppressWarnings("unchecked")
		List<PWiUserVO> users = jdbcTemplate.query(sql, pss, rowMapper);
		if (users.size() == 1) {
			return users.get(0);
		} else if (users.size() == 0) {
			return null;
		}
		throw new IllegalStateException("Failed to return one or zero templates for user ID: " + userId + ", users: " + users);
	}


	private static class GetUserByIdSetter implements PreparedStatementSetter {

		private Integer userId;


		public GetUserByIdSetter(Integer userId) {

			this.userId = userId;
		}


		public void setValues(PreparedStatement ps) throws SQLException {

			ps.setInt(1, userId.intValue());
		}
	}


	public List<PWiUserVO> getUsers() {

		HashMap<Integer, PWiUserVO> users = new HashMap<Integer, PWiUserVO>();
		return new ArrayList<PWiUserVO>(users.values());
	}


	public int checkNamesEdit(String firstName, String userLastname, String email, Integer userId, String SSO) {

		RowCounter counter = new RowCounter();
		String sql = QueryLoader.getQuery(QueryConstants.SEARCH_USER_EDIT_NAME);
		Object[] parameters = {email, SSO, userId};

		jdbcTemplate.query(sql, parameters, counter);

		return counter.getCount();
	}


	public void updateUser(PWiUserVO user, String sso) {

		jdbcTemplate.update(new UpdateUserPSCreator(user, sso));
	}


	private static class UpdateUserPSCreator implements PreparedStatementCreator {

		private PWiUserVO user;


		private String userId;


		public UpdateUserPSCreator(PWiUserVO user, String userId) {

			this.user = user;
			this.userId = userId;
		}


		public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {

			String sql = QueryLoader.getQuery(QueryConstants.PWi_USER_UPDATE);
			PreparedStatement ps = connection.prepareStatement(sql);

			int idx = 1;
			ps.setString(idx++, userId); // Uname = sso
			ps.setString(idx++, user.getUserNm()); // 1st name
			ps.setString(idx++, user.getUserLastNm()); // Lst name
			ps.setString(idx++, user.getEmail()); // Email
			ps.setString(idx++, user.isEnabled() ? "Y" : "N");
			ps.setInt(idx++, user.getUserId().intValue()); // UID
			return ps;
		}
	}


	@Override
	public List<PWiUserVO> findPWiQiUsers() {

		final ParameterizedRowMapper<PWiUserVO> mapper = new PWiUserVORowMapper();

		@SuppressWarnings("unchecked")
		List<PWiUserVO> result = (List<PWiUserVO>) jdbcTemplate.query(QueryLoader.getQuery(QueryConstants.PWi_USERS), mapper);
		return result;
	}


	@SuppressWarnings("unchecked")
	public int createNewUser(final String sso, final String firstName, final String lastName, final String email, final boolean enabled,
			final List<String> selectedRoleNms,final String emailNotification) throws RuntimeException{

		String sql = QueryLoader.getQuery(QueryConstants.PWi_USER_INSERT);
		Connection connection = null;
		CallableStatement statement = null;
		try {
			connection = jdbcTemplate.getDataSource().getConnection();
			statement = connection.prepareCall(sql);

			// Set input parameters
			int idx = 1; // parameter index
			statement.setString(idx++, sso);
			statement.setString(idx++, firstName);
			statement.setString(idx++, lastName);
			statement.setString(idx++, email);
			statement.setString(idx++, enabled ? "Y" : "N");
			statement.registerOutParameter(idx, Types.NUMERIC);
			statement.execute();
			Integer userId = Integer.valueOf(statement.getInt(idx));
			
			if (emailNotification.equalsIgnoreCase("Y")) {
				LOG.info("Retreiving Query for Admin Mail List>> "+PLMQueryConstants.ADMIN_EMAIL);
				ParameterizedRowMapper<String> mailListMapper = new pwiMailListOMapper();
				List<String> mailList = (List<String>) jdbcTemplate.query(PLMQueryConstants.ADMIN_EMAIL, mailListMapper);
				String ssoId=sso;
				String fname =firstName;
				String lname =lastName;
				String userEmail = email;
				List<String> roleListLcl = selectedRoleNms;
				try {
					sendEmailAddUser(roleListLcl, mailList, ssoId, fname, lname, userEmail);
				} catch (PLMCommonException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			String sqlReqAccDel = QueryLoader.getQuery(QueryConstants.PWi_USER_REQ_ACC_DEL);
			statement = connection.prepareCall(sqlReqAccDel);
			statement.setString(1, sso);
			statement.execute();
			return userId;

		} catch (SQLException e) {
			// Throw runtime exception to trigger rollback
			throw new RuntimeException(e);
		} finally {
			// close everything
			try {
				if (statement != null) {
					statement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				// Throw runtime exception to trigger rollback
				throw new RuntimeException(e);
			}
		}

	}

	
	/**
	 * mailListDetails Mapper
	 */
	private static final class pwiMailListOMapper implements ParameterizedRowMapper<String> {
		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
			String metaData = (rs.getString(PLMConstants.USER_EMAIL_ADD));
			return metaData;
		 }
	}
	
	/**
	 * This method is used to send an email upon requesting PLM Reporting App Access
	 * 
	 * @param groupMap
	 * @param mailList
	 * @param requestData
	 * @throws PLMCommonException
	 */
	public void sendEmailAddUser(List<String> roleNameList, List<String> mailList,
			 String ssoId, String fName, String lName, String userEmail) throws PLMCommonException {
		ArrayList<String> toMail = new ArrayList<String>();
		ArrayList<String> ccMail = new ArrayList<String>();
		StringBuffer subject = null;
		StringBuffer body = null;
		subject = new StringBuffer();
		body = new StringBuffer();
		String title = null;
		title = lName + ", "
				+ fName + "{"
				+ ssoId + "}";
		String userName = fName + " " + lName; 
		
		toMail.add(userEmail);
		ccMail.addAll(mailList);

		LOG.info("************** START: Sending Email while user is added to PWI ****************");
		subject.append("Power Warehouse Intelligence application access is given to " + title);
		body = new StringBuffer();

		body.append("<" + "HTML" + ">");
		body.append("<body>");
		body.append("<font color='black'>");
		body
				.append("<table width=\"100%\" border=\"0\" cellpadding=\"4\" cellspacing=\"0\">");
		body.append("<tr>");
		body.append("<br>");
		body.append("Dear " + userName + ",");
		body.append("<br>");
		body.append("<br>");
		body.append("Thank you for using the External Reporting - EEDW tool, your access for following roles(s) has been completed."); 
		body.append("<br>");
		body.append("<br>");
		for (int i = 0; i < roleNameList.size(); i++) {
			body.append(" " + (i + 1) + ". " + roleNameList.get(i));
			body.append("<br>");
		}
		
		body.append("<br>");		
		body.append("Please bookmark the login page for future reference  ");
		body.append("<font color='blue'>");
		body.append("<a href=" + rbundle.getString(PLMConstants.PWI_APP_URL) + ">")
				.append(rbundle.getString(PLMConstants.PWI_APP_URL)).append("</a>");
		body.append("</font>");
		
		body.append("<br>");
		body.append("<br>");
				
		body.append("If you have any issues contact ");
		body.append("<font color='blue'>");
		body.append("<a href=" + rbundle.getString(PLMConstants.helpDeskURL) + ">")
				.append(rbundle.getString(PLMConstants.helpDeskURL)).append("</a>");
		body.append("</font>");
		body.append("<br>");
		body.append("<br>");
		
		body.append("When talking to support team or submitting selfhelp incident, please use the keyword ");
		body.append("\"" +PLMConstants.pwi +" \"");
		body.append(" and include details of error encountered.");
		body.append("<br>");
		body.append("<br>");
		
		body.append("We suggest you browse Training materials located within Library ");
		body.append("<font color='blue'>");
		body.append("<a href=" + rbundle.getString(PLMConstants.PWI_LIB_URL) + ">")
				.append(rbundle.getString(PLMConstants.PWI_LIB_URL_LEVEL)).append("</a>");
		body.append("</font>");
		body.append("<br>");
		body.append("<br>");
		
		body.append("These include detailed screen and field layout for query panels and user interfaces for Power Warehouse Intelligence.");
		body.append("<br>");
		body.append("<br>");
		/*
		 * commented by subrajit
		 * body.append("Note: All Reports in PLM Reporting will be migrated to the P&W Intelligence reporting Tool in different phases before End of 2015.");
		body.append("The Current Reports (excluding the enhancements to the current reports / new reports) in PLMR will continue to function until all the reports are migrated to PWI.");
		body.append("<br>");
		body.append("<br>");	*/	
		body.append("Power Warehouse Intelligence is an Adhoc reporting tool which allows users to run the reports, power users to create the ")
		.append("report template based on the SQL queries using query generator tool (XLSM). The report templates can be selected to provide ")
		.append("filter conditions and execute a query report template to retrieve data into multiple output options such as CSV, XLS, XLSX, DOC ")
		.append("& PDF format in tabular data format.");
		body.append("<br>");
		body.append("<br>");
		body.append("This is an auto-generated email. Please do not reply.");
		body.append("</tr>");
		body.append("</table>");
		body.append("</font>");
		body.append("</body>");
		body.append("</html>");
		LOG.info("************** End: Sending Email while user is added to PWI ****************");
		
		mailBean.sendMail(toMail, ccMail, subject.toString(), body.toString(),
				mailSend, "test");

	}
	
	
	@Override
	public int checkNames(String firstName, String lastName, String email, String SSO) {

		// TODO Auto-generated method stub
		RowCounter counter = new RowCounter();
		String sql = QueryLoader.getQuery(QueryConstants.SEARCH_USER_WITH_NAME);
		Object[] parameters = {SSO};

		jdbcTemplate.query(sql, parameters, counter);

		return counter.getCount();
	}


	@Override
	public List<PWiUserVO> getUsersFromSelectedGroups(List<PWiQueryGroupVO> selectedQueryGroupsList) {

		// TODO Auto-generated method stub
		return null;
	}


	@SuppressWarnings("unchecked")
	public PWiUserVO getUserInfoForSSO(String ssoID) throws PLMCommonException {

		PWiUserVO user = new PWiUserVO();
		try {			
			/*user.setSso("501302894");
			user.setUserNm("Subrajit");
			user.setUserLastNm("Das");
			user.setEmail("Subrajit.das@ge.com");
			String status = "Y";
			if (status.equals("Y") || status.equals("A")) {
				user.setEnabled(true);
			} else {
				user.setEnabled(false);
			}*/
			
			// Define prepared statement setter
			PreparedStatementSetter pss = new GetUserBySSOSetter(ssoID);
			List<PWiUserVO> userInfoList = personJdbcTemplate.query(PLMQueryConstants.VALIDATE_PERSONAL, pss, new PWIValUser());
			if (userInfoList.size() > 0) {
				user = userInfoList.get(0);
			} else {
				user.setSso(PLMConstants.EMPTY_STRING);
			}
		} catch (DataAccessException e) {
			PLMUtils.checkException(e.getMessage());
		}
		return user;
	}


	private static final class PWIValUser implements ParameterizedRowMapper<PWiUserVO> {

		public PWiUserVO mapRow(ResultSet rs, int rowNum) throws SQLException {

			PWiUserVO user = new PWiUserVO();
			user.setSso(rs.getString(PLMConstants.PERSON_NUM_SSO));
			user.setUserNm(rs.getString(PLMConstants.FT_NAM));
			user.setUserLastNm(rs.getString(PLMConstants.LT_NAME));
			user.setEmail(rs.getString(PLMConstants.EADDRESS));
			String status = rs.getString(PLMConstants.PERSON_STATUS);
			if (status.equals("Y") || status.equals("A")) {
				user.setEnabled(true);
			} else {
				user.setEnabled(false);
			}
			return user;
		}
		// };
	}


	private static class GetUserBySSOSetter implements PreparedStatementSetter {

		private String sso;


		public GetUserBySSOSetter(String sso) {

			this.sso = sso;
		}


		public void setValues(PreparedStatement ps) throws SQLException {

			ps.setString(1, sso);
		}

	}
	
	//Newly Added for getting Roles
	@SuppressWarnings("unchecked")
	public List<PWiUserVO> getUsersFromSelectedGroups() throws PLMCommonException{
		String getUserRoles = QueryLoader.getQuery(QueryConstants.PWi_USER_ROLE_LIST);
		PLMPwiUserData userdata = (PLMPwiUserData) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get(PWiConstants.USER_DATA);
		String roleTypes = "";
		int i = 0;
		for (PLMPwiRolesData roles : userdata.getRoleDtlList()) {
			if (i == 0) {
				roleTypes = "'" + roles.getUserRoleType() + "'";
				i++;
			} else {
				roleTypes = roleTypes + "," + "'" + roles.getUserRoleType() + "'";
				i++;
			}

		}
		getUserRoles = getUserRoles + roleTypes + ")";
		
		ParameterizedRowMapper<PWiUserVO> roleTypeMapper = new pwiRolesVOMapper();
		List<PWiUserVO> getRolesList = (List<PWiUserVO>) jdbcTemplate.query(getUserRoles, roleTypeMapper);
		
		return getRolesList;
	}
	
	/**
	 * pwiRolesMapper retrieves the column names and set to VO list to display in roleList page
	 */
	public static class pwiRolesVOMapper implements ParameterizedRowMapper<PWiUserVO> {

		public PWiUserVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			PWiUserVO pwiUserVo = new PWiUserVO();
			pwiUserVo.setRoleId(rs.getString(ColumnConstants.PWI_RID));
			pwiUserVo.setRoleName(rs.getString(ColumnConstants.PWI_NAME));
			return pwiUserVo;
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<PWiUserVO> searchUser(String searchSso, String searchFname,
			String searchLname, String roleId, String status)throws PLMCommonException{
		List<PWiUserVO> userDataList =new ArrayList<PWiUserVO>();
		boolean whereFlg = false;
		try {
			
			String queryStr = QueryLoader.getQuery(QueryConstants.PWi_USER_DATA_LIST);

			StringBuffer sqlquery = new StringBuffer();
			sqlquery.append(queryStr);
			
			if (searchSso != null && !searchSso.equals("")) {
				if (!whereFlg) {
					sqlquery.append(" WHERE UI.PWI_UNAME like '%" + searchSso.trim()
						+ PLMQueryConstants.PERCENTILE);
					whereFlg = true;
				} else {
					sqlquery.append(" AND UI.PWI_UNAME like '%" + searchSso.trim()
									+ PLMQueryConstants.PERCENTILE);
				}
			}
			
			if (searchFname != null && !searchFname.equals("")) {
				if (!whereFlg) {
					sqlquery.append(" WHERE UPPER(UI.PWI_GIVENNAME) like '%"
							+ searchFname.toUpperCase(Locale.US).trim()
							+ PLMQueryConstants.PERCENTILE);
					whereFlg = true;
				} else {
					sqlquery.append(" AND UPPER(UI.PWI_GIVENNAME) like '%"
							+ searchFname.toUpperCase(Locale.US).trim()
							+ PLMQueryConstants.PERCENTILE);
				}
			}
			
			if (searchLname != null && !searchLname.equals("")) {

				if (!whereFlg) {
					sqlquery.append(" WHERE UPPER(UI.PWI_FAMILYNAME) like '%"
									+ searchLname.toUpperCase(Locale.US).trim()
									+ PLMQueryConstants.PERCENTILE);
					whereFlg = true;
				} else {
					sqlquery.append(" AND UPPER(UI.PWI_FAMILYNAME) like '%"
							+ searchLname.toUpperCase(Locale.US).trim()
							+ PLMQueryConstants.PERCENTILE);
				}
			}

			if (roleId != null && !roleId.equals("")
					&& !roleId.equalsIgnoreCase(PLMConstants.PLEASE_SELECT)) {

				if (!whereFlg) {
					sqlquery.append(" WHERE UI.PWI_UID IN (SELECT PWI_UID FROM PWI_ROLE_MEMBERSHIP WHERE PWI_RID=" + Integer.parseInt(roleId) + ")");
					whereFlg = true;							
				} else {
					sqlquery.append(" AND UI.PWI_UID IN (SELECT PWI_UID FROM PWI_ROLE_MEMBERSHIP WHERE PWI_RID=" + Integer.parseInt(roleId) + ")");
				}
			}
			
			if (status.equalsIgnoreCase(PLMConstants.NOO)) {
				if (!whereFlg) {
					sqlquery.append(" WHERE UI.PWI_ENABLED ="+ "'" + PLMConstants.NOO+ "'");
					whereFlg = true;
				} else {
					sqlquery.append(" AND UI.PWI_ENABLED ="+ "'" + PLMConstants.NOO+ "'");
				}
			}else if (status.equalsIgnoreCase(PLMConstants.YES)) {
				if (!whereFlg) {
					sqlquery.append(" WHERE UI.PWI_ENABLED ="+ "'" + PLMConstants.YES+ "'");
					whereFlg = true;
				} else {
					sqlquery.append(" AND UI.PWI_ENABLED ="+ "'" + PLMConstants.YES+ "'");
				}
			}
			
			sqlquery.append(QueryLoader.getQuery(QueryConstants.PWi_USER_DATA_END));
			
			LOG.info("Query Executing User data>>>>>>>>>>>>>>>>> "+sqlquery);
			
			ParameterizedRowMapper<PWiUserVO> userDataMapper = new pwiUserDataMapper();
			userDataList = jdbcTemplate.query(sqlquery.toString(),userDataMapper);
			
			LOG.info("USer data list count >>>>>>>>>>>>>>>>> "+userDataList.size());
			
		} catch (DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}		
		return userDataList;		 
	}

	/**
	 * pwiUserDataMapper retrieves the column names and set to VO list to display in roleList page
	 */
	public static class pwiUserDataMapper implements ParameterizedRowMapper<PWiUserVO> {

		public PWiUserVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			PWiUserVO pwiUserVo = new PWiUserVO();
			pwiUserVo.setUserId(Integer.valueOf(rs.getString(ColumnConstants.PWI_UID)));
			pwiUserVo.setSso(rs.getString(ColumnConstants.PWI_UNAME));
			pwiUserVo.setUserNm(rs.getString("NAME"));
			pwiUserVo.setEmail(rs.getString(ColumnConstants.PWI_VIEWREALEMAIL));
			pwiUserVo.setRoleName(rs.getString("ROLE"));
			return pwiUserVo;
		}
	}

}
