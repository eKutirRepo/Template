package com.geinfra.geaviation.pwi.faces;

import javax.faces.webapp.UIComponentTag;

/**
 * Copyright(C) 2013 GE All rights reserved
 * @deprecated
 */
public class AnchorTag extends UIComponentTag {

	@Override
	public String getComponentType() {
		return "a";
	}

	@Override
	public String getRendererType() {
		// Use default supplied in UI component
		return null;
	}
}
