package com.geinfra.geaviation.pwi.model;

/**
 * 
 * Project        :   Product Lifecycle Management
 * Date Written   :   Aug 6, 2010
 * Security       :   GE Confidential
 * Restrictions   :   GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 * Copyright(C) 2010 GE 
 * All rights reserved
 *
 * Description    :  QueryParam - Query Builder parameter object.
 *
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class QueryParam {
	private String queryParamName;
	private Object searchable;
	private Object paramVals;
	private String operators;
	private Object selectable;

	public void isSearchable() {

	}

	/**
	 * @return the queryParamName
	 */
	public String getQueryParamName() {
		return queryParamName;
	}

	/**
	 * @param queryParamName
	 *            the queryParamName to set
	 */
	public void setQueryParamName(String queryParamName) {
		this.queryParamName = queryParamName;
	}

	/**
	 * @return the searchable
	 */
	public Object getSearchable() {
		return searchable;
	}

	/**
	 * @param searchable
	 *            the searchable to set
	 */
	public void setSearchable(Object searchable) {
		this.searchable = searchable;
	}

	/**
	 * @return the paramVals
	 */
	public Object getParamVals() {
		return paramVals;
	}

	/**
	 * @param paramVals
	 *            the paramVals to set
	 */
	public void setParamVals(Object paramVals) {
		this.paramVals = paramVals;
	}

	/**
	 * @return the operators
	 */
	public String getOperators() {
		return operators;
	}

	/**
	 * @param operators
	 *            the operators to set
	 */
	public void setOperators(String operators) {
		this.operators = operators;
	}

	/**
	 * @return the selectable
	 */
	public Object getSelectable() {
		return selectable;
	}

	/**
	 * @param selectable
	 *            the selectable to set
	 */
	public void setSelectable(Object selectable) {
		this.selectable = selectable;
	}

}
