/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName RptTypeRelationDAOImpl.java
 * @Creation date: 18-June-2014
 * @version 1.0
  * @author : Tech Mahindra
 */

package com.geinfra.geaviation.pwi.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.faces.model.SelectItem;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.RptTypeRelationVo;
import com.geinfra.geaviation.pwi.service.vo.TypeRelationData;
import com.geinfra.geaviation.pwi.util.QueryConstants;
import com.geinfra.geaviation.pwi.util.QueryLoader;

public class RptTypeRelationDAOImpl implements RptTypeRelationDAO {
	
	private JdbcTemplate jdbcTemplate;
	private JdbcTemplate jdbcTemplateTr;
	
	
	public void setJdbcTemplateTr(JdbcTemplate jdbcTemplateTr) {
		this.jdbcTemplateTr = jdbcTemplateTr;
	}
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	
	@Override
	public List<TypeRelationData> getTypeRelData() throws PWiException {
		
		final ParameterizedRowMapper<TypeRelationData> mapper = new TypeRelationDataRowMapper();
		try {
			
		
		InitialContext initCtx = new InitialContext();
		Context ctx = (Context) initCtx.lookup("java:/");
		DataSource ds = (DataSource) ctx.lookup("plmrterads");
		// TODO: perhaps keep one jdbcT for each data source? 
		JdbcTemplate jdbcTemplateLcl = new JdbcTemplate(ds);
		// TODO Auto-generated method stub
			
		List<TypeRelationData> query = (List<TypeRelationData>) jdbcTemplateLcl.query(QueryLoader.getQuery(QueryConstants.PWi_ALL_TYPE), mapper);
		
		return query;
		} catch (NamingException e) {
			throw new PWiException(e, "Error getting selectable items.");
		} catch (DataAccessException e) {
			throw new PWiException(e, "Error getting selectable items.");
		}
	
		
	}
	
	public static class TypeRelationDataRowMapper implements
	ParameterizedRowMapper<TypeRelationData> {
public TypeRelationData mapRow(ResultSet rs, int rowNum) throws SQLException {
	TypeRelationData typeRelationData = new TypeRelationData();
	
	typeRelationData.setFromType(rs.getString("from_table"));
	typeRelationData.setFromTypeEedw(rs.getString("from_eedw"));
	typeRelationData.setToType(rs.getString("to_table"));
	typeRelationData.setToTypeEedw(rs.getString("to_eedw"));
	typeRelationData.setRelType(rs.getString("tablename"));
	typeRelationData.setRelTypeEedw(rs.getString("tablename_eedw"));
	

	return typeRelationData;
}
}
	

	public  List<RptTypeRelationVo> getColumnsFrType(String tableName)throws PWiException{
		String sql = QueryLoader.getQuery(QueryConstants.GET_COLUMN_FRTYPE);
		final ParameterizedRowMapper<RptTypeRelationVo> mapper = new RptTyperelationMapper();
		final PreparedStatementSetter setter = new TableNamesSetter(tableName);

		@SuppressWarnings("unchecked")
		List<RptTypeRelationVo> columnsList = (List<RptTypeRelationVo>) jdbcTemplateTr
				.query(sql,setter,mapper);
		return columnsList;
	}

	
	
	/**
	 * Row Mapper for Object Types
	 */
	public static class RptTyperelationMapper implements
			ParameterizedRowMapper<RptTypeRelationVo> {
		public RptTypeRelationVo mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			RptTypeRelationVo rptTyperelationVo = new RptTypeRelationVo();
			rptTyperelationVo.setToDelete(false);
			rptTyperelationVo.setRownum(rowNum + 1);
			
			rptTyperelationVo.setCoulmnName(rs.getString("ColumnName"));
			rptTyperelationVo.setDisplayName(rs.getString("ColumnName"));
			
			rptTyperelationVo.getSrchOpList().add(new SelectItem("op_equal","="));
			rptTyperelationVo.getSrchOpList().add(new SelectItem("op_le","<="));
			rptTyperelationVo.getSrchOpList().add(new SelectItem("op_ge",">="));
			rptTyperelationVo.getSrchOpList().add(new SelectItem("op_like","like"));
			rptTyperelationVo.getSrchOpList().add(new SelectItem("op_value","list"));
			rptTyperelationVo.getSrchOpList().add(new SelectItem("op_lt","<"));
			rptTyperelationVo.getSrchOpList().add(new SelectItem("op_gt",">"));
			rptTyperelationVo.getSrchOpList().add(new SelectItem("op_nlike","nlike"));
			
			rptTyperelationVo.getSubstPlaceHldrList().add(new SelectItem("and","And"));
			rptTyperelationVo.getSubstPlaceHldrList().add(new SelectItem("or","Or"));
			rptTyperelationVo.getSubstPlaceHldrList().add(new SelectItem("date","Date"));
			rptTyperelationVo.setSubstPlaceHldr("and");
			
			rptTyperelationVo.getInputTypeList().add(new SelectItem("text","Text"));
			rptTyperelationVo.getInputTypeList().add(new SelectItem("multiselect","Multiselect"));
			rptTyperelationVo.getInputTypeList().add(new SelectItem("lookup","Lookup"));
			rptTyperelationVo.getInputTypeList().add(new SelectItem("combobox","Combobox"));
			rptTyperelationVo.getInputTypeList().add(new SelectItem("dropdown","Dropdown"));
			rptTyperelationVo.getInputTypeList().add(new SelectItem("datepicker","Datepicker"));
			rptTyperelationVo.setInputType("text");
			
			rptTyperelationVo.getSrchMandtry().add(new SelectItem("yes","Yes"));
			rptTyperelationVo.getSrchMandtry().add(new SelectItem("no","No"));
			rptTyperelationVo.setSelectedSrchMandtry("no");

			return rptTyperelationVo;
		}
	}
	
	
	private static class TableNamesSetter implements
	PreparedStatementSetter {
		private String table;

	public TableNamesSetter(String table) {
		this.table = table;
	}
	
	public void setValues(PreparedStatement ps) throws SQLException {
		ps.setString(1, table.toString());
	}
}
}
