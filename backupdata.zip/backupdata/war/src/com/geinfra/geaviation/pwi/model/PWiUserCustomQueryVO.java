/*
//  @ Project : PWi
//  @ File Name : PWiUserCustomQueryVO.java
//  @ Date : 5/14/2010
//  @ Author : nisverma
 */

package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import jxl.common.Logger;

import org.apache.commons.lang.StringUtils;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.json.JsonBuilder;
import com.geinfra.geaviation.pwi.json.Jsonable;
import com.geinfra.geaviation.pwi.util.BookmarkableLinkUtil;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.xml.SearchInputXmlReader;
import com.geinfra.geaviation.pwi.xml.search.Search;

/**
 * 
 * Project : Product Lifecycle Management Intelligence
 * Date Written : Aug 6, 2010
 * Security : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : PWiUserCustomQueryVO - User custom query (Favorite or
 *              subscription)
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 * 2013.03.11 pH  implemented Jsonable
 */
public class PWiUserCustomQueryVO extends PWiBaseVO implements Serializable,
		Jsonable {
	public static final String PRTY_CSTM_QRY_SEQ_ID = "PRTY_CSTM_QRY_SEQ_ID";
	public static final String USR_SSO_ID = "USR_SSO_ID";
	public static final String QRY_SEQ_ID = "QRY_SEQ_ID";
	public static final String CSTM_QRY_NM = "CSTM_QRY_NM";
	public static final String QRY_SLCTD_COL_NM = "QRY_SLCTD_COL_NM";
	public static final String QRY_SRCH_CRTR_TXT = "QRY_SRCH_CRTR_TXT";
	public static final String QRY_CSTM_DTTM = "QRY_CSTM_DTTM";
	public static final String QRY_NXT_EXCTN_DTTM = "QRY_NXT_EXCTN_DTTM";
	public static final String QRY_EXCTN_FRQNCY_SEQ_ID = "QRY_EXCTN_FRQNCY_SEQ_ID";
	public static final String CURR_QRY_RSLT_FL_PTH_TXT = "CURR_QRY_RSLT_FL_PTH_TXT";
	public static final String PRR_QRY_RSLT_FL_PTH_TXT = "PRR_QRY_RSLT_FL_PTH_TXT";
	public static final String CMPRSN_RSLT_FL_PTH_TXT = "CMPRSN_RSLT_FL_PTH_TXT";
	public static final String QRY_SBSCRPTN_IND = "QRY_SBSCRPTN_IND";
	public static final String QRY_FVRT_IND = "QRY_FVRT_IND";
	public static final String QRY_SBSCRPTN_END_DTTM = "QRY_SBSCRPTN_END_DTTM";
	public static final String QRY_LST_EXCTN_DTTM = "QRY_LST_EXCTN_DTTM";
	public static final String SBSCRPTN_LST_EXCTN_DTTM = "SBSCRPTN_LST_EXCTN_DTTM";
	public static final String CRTN_DT = "CRTN_DT";
	public static final String CRTD_BY = "CRTD_BY";
	public static final String LST_UPDT_DT = "LST_UPDT_DT";
	public static final String LST_UPDTD_BY = "LST_UPDTD_BY";
	public static final String QRY_PROCESSOR_NM = "QRY_PROCESSOR_NM";

	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(
			PWiUserCustomQueryVO.class);

	private Integer prtyCstmQrySeqId;
	private String executeLink;
	private String modifyLink;
	private String usrSsoId;
	private Integer queryId;
	private String cstmQryNm;
	private String qrySlctdColNm;
	private String qrySrchCrtrTxt;
	private Date qryCstmDttm;
	private Date qryNxtExctnDttm;
	private Integer executionFrequencyId;
	private String currQryRsltFlPthTxt;
	private String prrQryRsltFlPthTxt;
	private String cmprsnRsltFlPthTxt;
	private String qrySbscrptnInd;
	private String qryFvrtInd;
	private Date qrySbscrptnEndDttm;
	private Date qryLstExctnDttm;
	private Date sbscrptnLstExctnDttm;
	private String queryProcessorId;

	/**
	 * Create a favorite from a query with no user options.
	 * 
	 * @param queryId 
	 * @param sso 
	 * @param customName 
	 */
	public PWiUserCustomQueryVO(Integer queryId, String customName, String sso) {
		this.queryId = queryId;
		this.usrSsoId = sso;
		this.cstmQryNm = customName;
		this.qryFvrtInd = "Y";
	}

	public PWiUserCustomQueryVO() {
	}

	public Integer getPrtyCstmQrySeqId() {
		return prtyCstmQrySeqId;
	}

	public void setPrtyCstmQrySeqId(Integer prtyCstmQrySeqId) {
		this.prtyCstmQrySeqId = prtyCstmQrySeqId;
		// TODO pH 2012.12: do we need to do this? only if VO's are reused
		executeLink = null;
		modifyLink = null;
	}

	public String getExecuteLink() {
		if (executeLink == null) {
			executeLink = BookmarkableLinkUtil.getInstance()
					.getExecuteFavoriteLink(prtyCstmQrySeqId.toString());
		}
		return executeLink;
	}

	public String getModifyLink() {
		if (modifyLink == null) {
			modifyLink = BookmarkableLinkUtil.getInstance()
					.getModifyFavoriteLink(prtyCstmQrySeqId.toString());
		}
		return modifyLink;
	}

	public String getUsrSsoId() {
		return usrSsoId;
	}

	public void setUsrSsoId(String usrSsoId) {
		this.usrSsoId = usrSsoId;
	}

	public String getCstmQryNm() {
		return cstmQryNm;
	}

	public void setCstmQryNm(String cstmQryNm) {
		this.cstmQryNm = cstmQryNm;
	}

	/**
	 * Selected columns XML.
	 * 
	 * @return selected columns XML
	 */
	public String getQrySlctdColNm() {
		return qrySlctdColNm;
	}

	public void setQrySlctdColNm(String qrySlctdColNm) {
		this.qrySlctdColNm = qrySlctdColNm;
	}

	/**
	 * Search criteria XML.
	 * 
	 * @return search criteria XML
	 */
	public String getQrySrchCrtrTxt() {
		return qrySrchCrtrTxt;
	}

	public void setQrySrchCrtrTxt(String qrySrchCrtrTxt) {
		this.qrySrchCrtrTxt = qrySrchCrtrTxt;
	}

	public Date getQryCstmDttm() {
		return qryCstmDttm != null ? new Date(qryCstmDttm.getTime()) : null;
	}

	public void setQryCstmDttm(Date qryCstmDttm) {
		if (qryCstmDttm != null)
			this.qryCstmDttm = new Date(qryCstmDttm.getTime());
	}

	public Date getQryNxtExctnDttm() {
		return qryNxtExctnDttm != null ? new Date(qryNxtExctnDttm.getTime())
				: null;
	}

	public void setQryNxtExctnDttm(Date qryNxtExctnDttm) {
		if (qryNxtExctnDttm != null)
			this.qryNxtExctnDttm = new Date(qryNxtExctnDttm.getTime());
	}

	public String getCurrQryRsltFlPthTxt() {
		return currQryRsltFlPthTxt;
	}

	public void setCurrQryRsltFlPthTxt(String currQryRsltFlPthTxt) {
		this.currQryRsltFlPthTxt = currQryRsltFlPthTxt;
	}

	public String getPrrQryRsltFlPthTxt() {
		return prrQryRsltFlPthTxt;
	}

	public void setPrrQryRsltFlPthTxt(String prrQryRsltFlPthTxt) {
		this.prrQryRsltFlPthTxt = prrQryRsltFlPthTxt;
	}

	public String getCmprsnRsltFlPthTxt() {
		return cmprsnRsltFlPthTxt;
	}

	public void setCmprsnRsltFlPthTxt(String cmprsnRsltFlPthTxt) {
		this.cmprsnRsltFlPthTxt = cmprsnRsltFlPthTxt;
	}

	public String getQrySbscrptnInd() {
		return qrySbscrptnInd;
	}

	public void setQrySbscrptnInd(String qrySbscrptnInd) {
		this.qrySbscrptnInd = qrySbscrptnInd;
	}

	public String getQryFvrtInd() {
		return qryFvrtInd;
	}

	public void setQryFvrtInd(String qryFvrtInd) {
		this.qryFvrtInd = qryFvrtInd;
	}

	public Date getQrySbscrptnEndDttm() {
		return qrySbscrptnEndDttm != null ? new Date(qrySbscrptnEndDttm
				.getTime()) : null;
	}

	public void setQrySbscrptnEndDttm(Date qrySbscrptnEndDttm) {
		if (qrySbscrptnEndDttm != null)
			this.qrySbscrptnEndDttm = new Date(qrySbscrptnEndDttm.getTime());
	}

	public Date getQryLstExctnDttm() {
		return qryLstExctnDttm != null ? new Date(qryLstExctnDttm.getTime())
				: null;
	}

	public void setQryLstExctnDttm(Date qryLstExctnDttm) {
		if (qryLstExctnDttm != null)
			this.qryLstExctnDttm = new Date(qryLstExctnDttm.getTime());
	}

	public Date getSbscrptnLstExctnDttm() {
		return sbscrptnLstExctnDttm != null ? new Date(sbscrptnLstExctnDttm
				.getTime()) : null;
	}

	public void setSbscrptnLstExctnDttm(Date sbscrptnLstExctnDttm) {
		if (sbscrptnLstExctnDttm != null)
			this.sbscrptnLstExctnDttm = new Date(sbscrptnLstExctnDttm.getTime());
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (prtyCstmQrySeqId != null ? prtyCstmQrySeqId.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object instanceof PWiUserCustomQueryVO) {
			PWiUserCustomQueryVO other = (PWiUserCustomQueryVO) object;
			if (this.prtyCstmQrySeqId != null && other.prtyCstmQrySeqId != null) {
				return this.prtyCstmQrySeqId.equals(other.prtyCstmQrySeqId);
			}
		}
		return false;
	}

	@Override
	public String toString() {
		return "com.geinfra.geaviation.pwi.model.PWiUserCustomQuery[prtyCstmQrySeqId="
				+ prtyCstmQrySeqId + "]";
	}

	public String getQrySearchParameters() throws PWiException {
		String result = null;
		if (qrySrchCrtrTxt != null) {
			SearchInputXmlReader searchXmlReader = new SearchInputXmlReader();
			StringBuffer searchText = new StringBuffer();
			Search search = null;
			search = searchXmlReader.translateXml(qrySrchCrtrTxt);
			List<Search.Item> allItems = search.getItem();
			for (Search.Item t : allItems) {
				if (StringUtils.isNotBlank(searchText.toString()))
					searchText.append(", ");
				searchText.append(t.getValue());
			}
			result = searchText.toString();
		}
		return result;
	}

	public boolean isQrySearchParametersToggle() throws PWiException {
		String params = getQrySearchParameters();
		return params != null
				&& params.length() > PWiConstants.QUERY_SEARCH_PARAMETER_CHAR_LIMIT;
	}

	public String getQrySearchParametersLess() throws PWiException {
		String params = getQrySearchParameters();

		// Check whether string exceeds QUERY_SEARCH_PARAMETER_CHAR_LIMIT
		// characters
		if (params != null
				&& params.length() > PWiConstants.QUERY_SEARCH_PARAMETER_CHAR_LIMIT) {
			// Trim to first QUERY_SEARCH_PARAMETER_CHAR_LIMIT characters
			params = params.substring(0,
					PWiConstants.QUERY_SEARCH_PARAMETER_CHAR_LIMIT);
		}
		return params;
	}

	public String getQueryProcessorId() {
		return queryProcessorId;
	}

	public void setQueryProcessorId(String queryProcessorId) {
		this.queryProcessorId = queryProcessorId;
	}

	public Integer getQueryId() {
		return queryId;
	}

	public void setQueryId(Integer queryId) {
		this.queryId = queryId;
	}

	public Integer getExecutionFrequencyId() {
		return executionFrequencyId;
	}

	public void setExecutionFrequencyId(Integer executionFrequencyId) {
		this.executionFrequencyId = executionFrequencyId;
	}

	public String toJson() {
		JsonBuilder builder = new JsonBuilder();
		builder.startObject();
		builder.addStringProperty("id", prtyCstmQrySeqId);
		builder.addStringProperty("queryId", queryId);
		builder.addStringProperty("name", cstmQryNm);
		builder.addStringProperty("ssoId", usrSsoId);
		try {
			builder.addStringProperty("params", getQrySearchParameters());
		} catch (PWiException e) {
			LOGGER.error(e);
			builder.addStringProperty("params", "Error getting parameters!");
		}
		builder.endObject();
		return builder.toString();
	}
}
