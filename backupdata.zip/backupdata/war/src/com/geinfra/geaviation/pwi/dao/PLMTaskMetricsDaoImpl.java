/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMTaskMetricsDaoImpl.java
 * @Creation date: 15-June-2011
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMProjectTaskData;
import com.geinfra.geaviation.pwi.data.PLMTaskMetricsData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMMetricsQueries;
import com.geinfra.geaviation.pwi.util.PLMSearchQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMTaskMetricsDaoImpl extends SimpleJdbcDaoSupport implements PLMTaskMetricsDaoIfc {
	/**
	 * Holds the Logger
	 */
	private static final Logger LOG = Logger.getLogger(PLMTaskMetricsDaoImpl.class);
	
	@SuppressWarnings("unchecked")
	/**
	 * This method is used for getStatusDropDownvalues
	 * 
	 * @param searchResultsQry
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getStatusDropDownvalues() throws PLMCommonException {
		LOG.info ("Entering getStatusDropDownvalues method ");
		Map<String, List<SelectItem>> dropDownStatusList = new HashMap<String, List<SelectItem>>();
		List<SelectItem> ptrvStatusList = null;
		try{
		ptrvStatusList = getJdbcTemplate().query(PLMSearchQueries.GET_PTRV_STATUS,new StatusMapper());
		dropDownStatusList.put("ptrvstatus", ptrvStatusList);
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info ("Exiting getStatusDropDownvalues method ");
		return dropDownStatusList;
	}
	/**
	 * Mapper for Getting statusMapper
	 */
	//private static ParameterizedRowMapper<SelectItem> statusMapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class StatusMapper implements ParameterizedRowMapper<SelectItem>{ 	
	public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
			SelectItem selectItem = new SelectItem(rs.getString(PLMConstants.PTRV_DROP_STATUS));
			return selectItem;
		}
	// };
	}
	
	@SuppressWarnings("unchecked")
	/**
	 * This method is used for getPrjDropDownvalues
	 * 
	 * @param searchResultsQry
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String, List<SelectItem>> getPrjDropDownvalues()throws PLMCommonException{
		LOG.info ("Entering getPrjDropDownvalues method ");
		Map<String, List<SelectItem>> dropdownprojectlist = null;
		try{
		dropdownprojectlist = new HashMap<String, List<SelectItem>>();
  		List<SelectItem> ptrvprojectlist = null;
		ptrvprojectlist=getJdbcTemplate().query(PLMSearchQueries.GET_PTRV_PRJNAME,new PrjMapper());
		dropdownprojectlist.put("ptrvproject", ptrvprojectlist);
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info ("Exiting getPrjDropDownvalues method ");
		return dropdownprojectlist;
	 }
	/**
	 * Mapper for Getting prjMapper
	 */
	 //private static ParameterizedRowMapper<SelectItem> prjMapper = new ParameterizedRowMapper<SelectItem>() {
	private static final class PrjMapper implements ParameterizedRowMapper<SelectItem>{	
	public SelectItem mapRow(ResultSet rs, int rowCount) throws SQLException {
			SelectItem selectItem = new SelectItem(rs.getString(PLMConstants.PTRV_DROP_NAME));
			return selectItem;
		}
	//	};
	}
	
	/**
	 * This method is used for getPrjSearchData
	 * 
	 * @param searchResultsQry
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMProjectTaskData> getPrjSearchData(StringBuffer searchResultsQry) throws PLMCommonException {
		LOG.info("Entering getPrjSearchData method");
		List<PLMProjectTaskData> searchResultProject =null;
		try{
		LOG.info("Project by Task Search Query is : " + searchResultsQry);
		searchResultProject=getSimpleJdbcTemplate().query(searchResultsQry.toString(),new SearchMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getPrjSearchData method");
		return searchResultProject;
	}
	/**
	 * Mapper for Getting searchMapper
	 */
	//private static ParameterizedRowMapper<PLMProjectTaskData> searchMapper = new ParameterizedRowMapper<PLMProjectTaskData>() {
	private static final class SearchMapper implements ParameterizedRowMapper<PLMProjectTaskData>{	
	public PLMProjectTaskData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMProjectTaskData tempPrjData = new PLMProjectTaskData();
			tempPrjData.setPrjName(PLMUtils.checkNullVal(rs.getString(PLMConstants.PTRV_HEADER_PROJECT)));
			tempPrjData.setPrjTaskCount(Integer.parseInt(PLMUtils.checkNullVal(rs.getString(PLMConstants.PTRV_HEADER_TASK))));
			tempPrjData.setRouteTaskCount(Integer.parseInt(PLMUtils.checkNullVal(rs.getString(PLMConstants.PTRV_HEADER_ROUTE))));
			tempPrjData.setSummaryCount(Integer.parseInt(PLMUtils.checkNullVal(rs.getString(PLMConstants.PTRV_HEADER_TASK)))+Integer.parseInt(PLMUtils.checkNullVal(rs.getString(PLMConstants.PTRV_HEADER_ROUTE))));
			if(tempPrjData.getPrjName().equalsIgnoreCase(""))
			{
				tempPrjData.setPrjName("OTHERS");
			}
			return tempPrjData;
		}
	//	};
	}
	
	
	
	// TASK VOLUME
	String weekstart = PLMUtils.getFormatedDate("wstart");
	String weekend = PLMUtils.getFormatedDate("wend");
	String monthstart = PLMUtils.getFormatedDate("mstart");
	String monthend = PLMUtils.getFormatedDate("mend");
	String yearstart = PLMUtils.getFormatedDate("ystart");
	String yearend = PLMUtils.getFormatedDate("yend");
	
	
	/**
	 * This method is used for filterUnorderedLevels
	 * 
	 * @param templist
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskMetricsData> filterUnorderedLevels (List<PLMTaskMetricsData> templist) {
		LOG.info("Entering filterUnorderedLevels of DaoImpl");
		List<PLMTaskMetricsData> returnlist = new ArrayList<PLMTaskMetricsData>();
		if(!PLMUtils.isEmptyList(templist)) {
			for(int i=0;i<templist.size();i++) {
				for (int j=i+1;j<templist.size();j++) {
					if(templist.get(i).getName()== null && templist.get(i).getSso()==null)
					continue;
					if(templist.get(i).getName().equalsIgnoreCase(templist.get(j).getName())) {
						if(templist.get(j).getName()== null && templist.get(j).getSso()== null)
						continue;	
						templist.get(i).setBackLogs(templist.get(i).getBackLogs() + templist.get(j).getBackLogs());
						templist.get(i).setDueWeek(templist.get(i).getDueWeek() + templist.get(j).getDueWeek());
						templist.get(i).setDueMonth(templist.get(i).getDueMonth() + templist.get(j).getDueMonth());
						templist.get(i).setDueYear(templist.get(i).getDueYear() + templist.get(j).getDueYear());
						templist.get(i).setTaskOwner(false);
						templist.get(i).setExpand(true);
						templist.get(i).setCollapse(false);
						templist.get(j).setName(null);
						templist.get(j).setSso(null);
					}
				 }
			}
		}
		
		if(!PLMUtils.isEmptyList(templist)) {
			LOG.info("Size of Templist " + templist.size());
			for(int i=0;i<templist.size();i++) {
				if(templist.get(i).getName()!= null && templist.get(i).getSso()!=null) {
					returnlist.add(templist.get(i));
				}
			}
		}
		if(!PLMUtils.isEmptyList(templist)){
			LOG.info("Size of Returnlist " + returnlist.size());
			for(int i = 0; i<returnlist.size(); i++) {
				returnlist.get(i).setRowIndex(i);
				int sum = returnlist.get(i).getBackLogs() + returnlist.get(i).getDueWeek()+returnlist.get(i).getDueMonth()+returnlist.get(i).getDueYear();
				if(sum == 0)
				{
				returnlist.get(i).setTaskOwner(true);
				returnlist.get(i).setExpand(false);
				returnlist.get(i).setCollapse(false);	
				}
			}
		}
		LOG.info("Exiting filterUnorderedLevels of DaoImpl");
		return returnlist;
	}
	
	/**
	 * This method is used for loadTaskVolumeDetailReport
	 * 
	 * @param taskMetricData
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<String> loadTaskVolumeDetailReport(PLMTaskMetricsData taskMetricData) throws PLMCommonException {
		LOG.info("Entering loadTaskVolumeDetailReport of DaoImpl");
		List<String> taskameslist = null;
		try{
		String selectedSSO = PLMUtils.removeHash(taskMetricData.getSso());
		Boolean isOwner = taskMetricData.isTaskOwner();
		LOG.info("Selected SSO :" + selectedSSO);
		String criteria =  taskMetricData.getCriteria();
		LOG.info("Selected criteria :" + criteria);
		if(selectedSSO.equalsIgnoreCase("OTHER"))
		{
			if(criteria.equalsIgnoreCase("BACKLOG"))
			{
			LOG.info("Task Volume Other Backlog Detail Query : " + PLMMetricsQueries.GET_TASKVOLUME_OTHER_BACKLOG_TASKNAMES);	
			taskameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_OTHER_BACKLOG_TASKNAMES,new Tasknamemapper());
			}
			if(criteria.equalsIgnoreCase("DUEWEEK"))
			{
			LOG.info("Task Volume Other Due Week Detail Query : " + PLMMetricsQueries.GET_TASKVOLUME_OTHER_DUES_TASKNAMES);
			taskameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_OTHER_DUES_TASKNAMES,new Tasknamemapper(),new Object[] {weekstart,weekend});
			}
			if(criteria.equalsIgnoreCase("DUEMONTH"))
			{
			LOG.info("Task Volume Other Due Month Detail Query : " + PLMMetricsQueries.GET_TASKVOLUME_OTHER_DUES_TASKNAMES);
			taskameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_OTHER_DUES_TASKNAMES,new Tasknamemapper(),new Object[] {monthstart,monthend});
			}
			if(criteria.equalsIgnoreCase("DUEYEAR"))
			{
			LOG.info("Task Volume Other Due Year Detail Query : " + PLMMetricsQueries.GET_TASKVOLUME_OTHER_DUES_TASKNAMES);
			taskameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_OTHER_DUES_TASKNAMES,new Tasknamemapper(),new Object[] { yearstart,yearend});
			}
		}
		else
		{
			if(criteria.equalsIgnoreCase("BACKLOG"))
			{
				if(isOwner){
					LOG.info("Task Volume Backlog Detail Query : " + PLMMetricsQueries.GET_TASKVOLUME_OWNER_BACKLOG_TASKNAMES);
					taskameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_OWNER_BACKLOG_TASKNAMES,new Tasknamemapper(),new Object[] { selectedSSO });
				}
				else{
				LOG.info("Task Volume Backlog Detail Query : " + PLMMetricsQueries.GET_TASKVOLUME_BACKLOG_TASKNAMES);
				taskameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_BACKLOG_TASKNAMES,new Tasknamemapper(),new Object[] { selectedSSO, selectedSSO, selectedSSO,selectedSSO,selectedSSO,selectedSSO,selectedSSO,selectedSSO });
				}
			}
			if(criteria.equalsIgnoreCase("DUEWEEK"))
			{
				if(isOwner){
					LOG.info("Task Volume Due Week Detail Query : " + PLMMetricsQueries.GET_TASKVOLUME_OWNER_DUES_TASKNAMES);
					taskameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_OWNER_DUES_TASKNAMES,new Tasknamemapper(),new Object[] {weekstart,weekend, selectedSSO});
				}
				else{
					LOG.info("Task Volume Due Week Detail Query : " + PLMMetricsQueries.GET_TASKVOLUME_DUES_TASKNAMES);
					taskameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_DUES_TASKNAMES,new Tasknamemapper(),new Object[] {weekstart,weekend, selectedSSO, selectedSSO, selectedSSO,selectedSSO,selectedSSO,selectedSSO,selectedSSO,selectedSSO });
				}
			}
			if(criteria.equalsIgnoreCase("DUEMONTH"))
			{
				if(isOwner){
					LOG.info("Task Volume Due Month Detail Query : " + PLMMetricsQueries.GET_TASKVOLUME_OWNER_DUES_TASKNAMES);
					taskameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_OWNER_DUES_TASKNAMES,new Tasknamemapper(),new Object[] {monthstart,monthend,selectedSSO});
				}
				else{
					LOG.info("Task Volume Due Month Detail Query : " + PLMMetricsQueries.GET_TASKVOLUME_DUES_TASKNAMES);
					taskameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_DUES_TASKNAMES,new Tasknamemapper(),new Object[] {monthstart,monthend,selectedSSO, selectedSSO, selectedSSO,selectedSSO,selectedSSO,selectedSSO,selectedSSO,selectedSSO });
				}
			}
			if(criteria.equalsIgnoreCase("DUEYEAR"))
			{
				if(isOwner){
					LOG.info("Task Volume Due Year Detail Query : " + PLMMetricsQueries.GET_TASKVOLUME_OWNER_DUES_TASKNAMES);
					taskameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_OWNER_DUES_TASKNAMES,new Tasknamemapper(),new Object[] { yearstart,yearend, selectedSSO});	
				}else{
					LOG.info("Task Volume Due Year Detail Query : " + PLMMetricsQueries.GET_TASKVOLUME_DUES_TASKNAMES);
					taskameslist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_DUES_TASKNAMES,new Tasknamemapper(),new Object[] { yearstart,yearend, selectedSSO, selectedSSO,selectedSSO,selectedSSO,selectedSSO,selectedSSO,selectedSSO,selectedSSO});
				}
			}
		}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting loadTaskVolumeDetailReport of DaoImpl");
		return taskameslist;
	}	
	/**
	 * Mapper for Getting tasknamemapper
	 */
	//private static ParameterizedRowMapper<String> tasknamemapper = new ParameterizedRowMapper<String>() {
	private static final class Tasknamemapper implements ParameterizedRowMapper<String>{	
	public String mapRow(ResultSet rs, int rowCount) throws SQLException {
			String tasknames = rs.getString("NM");
			return tasknames;
		}
	//	};
	}
	/**
	 * This method is used for loadTaskVolumeReport
	 * 
	 * @param taskMetricData,taskVolumeList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskMetricsData> loadTaskVolumeReport(PLMTaskMetricsData taskMetricData,List<PLMTaskMetricsData> taskVolumeList)
			throws PLMCommonException {
		List<PLMTaskMetricsData> taskVolList = new ArrayList<PLMTaskMetricsData>();
		LOG.info("Entering loadTaskVolumeReport of DaoImpl");
		LOG.info("Due Week  : BETWEEN " + weekstart + " AND " + weekend);
		LOG.info("Due Month : BETWEEN " + monthstart + " AND " + monthend);
		LOG.info("Due Year  : BETWEEN " + yearstart + " AND " + yearend);
		try{
		LOG.info("Task Volume Query : " + PLMMetricsQueries.GET_TASKVOLUME_VP_DETAILS);
		taskVolList = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_VP_DETAILS, new VpMapper(),new Object[] {weekstart,weekend,monthstart,monthend,yearstart,yearend});
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting loadTaskVolumeReport of DaoImpl");
		return taskVolList;		
	}
	/**
	 * This method is used for taskVolumeExpandVP
	 * 
	 * @param taskMetricData,taskVolumeList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskMetricsData> taskVolumeExpandVP(PLMTaskMetricsData taskMetricData,List<PLMTaskMetricsData> taskVolumeList)
			throws PLMCommonException {
		LOG.info("Entering taskVolumeExpandVP of DaoImpl");
		try{
		String selectedSSO = PLMUtils.removeHash(taskMetricData.getSso());
		int vpIndex =  taskMetricData.getVpIndex();
		LOG.info("Selected VP :" + selectedSSO);
		LOG.info("VP index :" + vpIndex);
		LOG.info("Task Volume Expansion Query for VP : " + PLMMetricsQueries.GET_TASKVOLUME_GM_DETAILS);
		List<PLMTaskMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_GM_DETAILS, new GmMapper(),new Object[] {weekstart,weekend,monthstart,monthend,yearstart,yearend,selectedSSO,selectedSSO});
		templist = filterUnorderedLevels(templist);
		if(!PLMUtils.isEmptyList(templist)) {
			taskVolumeList.get(vpIndex).setGmTable(templist);
			taskVolumeList.get(vpIndex).setCollapse(true);
			taskVolumeList.get(vpIndex).setExpand(false);
		}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting taskVolumeExpandVP of DaoImpl"); 
		return taskVolumeList;
		
	}
	/**
	 * This method is used for taskVolumeExpandGM
	 * 
	 * @param taskMetricData,taskVolumeList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskMetricsData> taskVolumeExpandGM(PLMTaskMetricsData taskMetricData,List<PLMTaskMetricsData> taskVolumeList)
			throws PLMCommonException {
		LOG.info("Entering taskVolumeExpandGM of DaoImpl");
		try{
		String selectedSSO = PLMUtils.removeHash(taskMetricData.getSso());
		int vpIndex =  taskMetricData.getVpIndex();
		int gmIndex =  taskMetricData.getGmIndex();
		LOG.info("Selected GM :" + selectedSSO);
		LOG.info("VP index :" + vpIndex);
		LOG.info("GM index :" + gmIndex);
		LOG.info("Task Volume Expansion Query for GM : " + PLMMetricsQueries.GET_TASKVOLUME_FM_DETAILS);
		List<PLMTaskMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_FM_DETAILS, new FmMapper(),new Object[] {weekstart,weekend,monthstart,monthend,yearstart,yearend,selectedSSO,selectedSSO});
		templist = filterUnorderedLevels(templist);
		if(!PLMUtils.isEmptyList(templist)) {
			taskVolumeList.get(vpIndex).getGmTable().get(gmIndex).setFmTable(templist);
			taskVolumeList.get(vpIndex).getGmTable().get(gmIndex).setCollapse(true);
			taskVolumeList.get(vpIndex).getGmTable().get(gmIndex).setExpand(false);
		}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting taskVolumeExpandGM of DaoImpl"); 
		return taskVolumeList;
	}
	/**
	 * This method is used for taskVolumeExpandFM
	 * 
	 * @param taskMetricData,taskVolumeList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskMetricsData> taskVolumeExpandFM(PLMTaskMetricsData taskMetricData,List<PLMTaskMetricsData> taskVolumeList)
			throws PLMCommonException {
		LOG.info("Entering taskVolumeExpandFM of DaoImpl");
		String selectedSSO = PLMUtils.removeHash(taskMetricData.getSso());
		try{
		int vpindex =  taskMetricData.getVpIndex();
		int gmindex =  taskMetricData.getGmIndex();
		int fmindex	=   taskMetricData.getFmIndex();	
		LOG.info("Selected FM :" + selectedSSO);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("FM index :" + fmindex);
		LOG.info("Task Volume Expansion Query for FM : " + PLMMetricsQueries.GET_TASKVOLUME_MGR4_DETAILS);
		List<PLMTaskMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_MGR4_DETAILS, new Mgr4Mapper(),new Object[] {weekstart,weekend,monthstart,monthend,yearstart,yearend,selectedSSO,selectedSSO});
		templist = filterUnorderedLevels (templist);
		if(!PLMUtils.isEmptyList(templist)) {
			taskVolumeList.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).setMgr4table(templist);
			taskVolumeList.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).setCollapse(true);
			taskVolumeList.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).setExpand(false);
		}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting taskVolumeExpandFM of DaoImpl"); 
		return taskVolumeList;		
	}
	/**
	 * This method is used for taskVolumeExpandMgr4
	 * 
	 * @param taskMetricData,taskVolumeList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskMetricsData> taskVolumeExpandMgr4(PLMTaskMetricsData taskMetricData,List<PLMTaskMetricsData> taskVolumeList) throws PLMCommonException {
		LOG.info("Entering taskVolumeExpandMgr4 of DaoImpl");
		try{
		String selectedSSO = PLMUtils.removeHash(taskMetricData.getSso());
		int vpindex =  taskMetricData.getVpIndex();
		int gmindex =  taskMetricData.getGmIndex();
		int fmindex	=   taskMetricData.getFmIndex();
		int mgr4index = taskMetricData.getMgr4index();
		LOG.info("Selected MGR4 :" + selectedSSO);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("FM index :" + fmindex);
		LOG.info("MGR4 index :"+ mgr4index);
		LOG.info("Task Volume Expansion Query for MGR4 : " + PLMMetricsQueries.GET_TASKVOLUME_MGR3_DETAILS);
		List<PLMTaskMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_MGR3_DETAILS, new Mgr3Mapper(),new Object[] {weekstart,weekend,monthstart,monthend,yearstart,yearend,selectedSSO,selectedSSO});
		templist = filterUnorderedLevels (templist);
		if(!PLMUtils.isEmptyList(templist))
			{
			taskVolumeList.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).setMgr3table(templist);
			taskVolumeList.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).setCollapse(true);
			taskVolumeList.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).setExpand(false);
			 }
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting taskVolumeExpandMgr4 of DaoImpl"); 
		return taskVolumeList;
	}
	/**
	 * This method is used for taskVolumeExpandMgr3
	 * 
	 * @param taskMetricData,taskVolumeList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskMetricsData> taskVolumeExpandMgr3(PLMTaskMetricsData taskMetricData,List<PLMTaskMetricsData> taskVolumeList) throws PLMCommonException {
		LOG.info("Entering taskVolumeExpandMgr3 of DaoImpl");
		try{
		String selectedSSO = PLMUtils.removeHash(taskMetricData.getSso());
		int vpindex =  taskMetricData.getVpIndex();
		int gmindex =  taskMetricData.getGmIndex();
		int fmindex	=   taskMetricData.getFmIndex();
		int mgr4index = taskMetricData.getMgr4index();
		int mgr3index = taskMetricData.getMgr3index();
		LOG.info("Selected MGR3 :" + selectedSSO);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("FM index :" + fmindex);
		LOG.info("MGR4 index :"+ mgr4index);
		LOG.info("MGR3 index :"+ mgr3index);
		LOG.info("Task Volume Expansion Query for MGR3 : " + PLMMetricsQueries.GET_TASKVOLUME_MGR2_DETAILS);
		List<PLMTaskMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_MGR2_DETAILS, new Mgr2Mapper(),new Object[] {weekstart,weekend,monthstart,monthend,yearstart,yearend,selectedSSO,selectedSSO});
		templist = filterUnorderedLevels (templist);
		if(!PLMUtils.isEmptyList(templist)) {
			taskVolumeList.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).setMgr2table(templist);
			taskVolumeList.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).setCollapse(true);
			taskVolumeList.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).setExpand(false);
		}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting taskVolumeExpandMgr3 of DaoImpl"); 
		return taskVolumeList;
	}
	/**
	 * This method is used for taskVolumeExpandMgr2
	 * 
	 * @param taskMetricData,taskVolumeList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskMetricsData> taskVolumeExpandMgr2(PLMTaskMetricsData taskMetricData,List<PLMTaskMetricsData> taskVolumeList) throws PLMCommonException {
		LOG.info("Entering taskVolumeExpandMgr2 of DaoImpl");
		try{
		String selectedSSO = PLMUtils.removeHash(taskMetricData.getSso());
		int vpindex =  taskMetricData.getVpIndex();
		int gmindex =  taskMetricData.getGmIndex();
		int fmindex	=   taskMetricData.getFmIndex();
		int mgr4index = taskMetricData.getMgr4index();
		int mgr3index = taskMetricData.getMgr3index();
		int mgr2index = taskMetricData.getMgr2index();
		LOG.info("Selected MGR2 :" + selectedSSO);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("FM index :" + fmindex);
		LOG.info("MGR4 index :"+ mgr4index);
		LOG.info("MGR3 index :"+ mgr3index);
		LOG.info("MGR2 index :"+ mgr2index);
		LOG.info("Task Volume Expansion Query for MGR2 : " + PLMMetricsQueries.GET_TASKVOLUME_MGR1_DETAILS);
		List<PLMTaskMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_MGR1_DETAILS, new Mgr1Mapper(),new Object[] {weekstart,weekend,monthstart,monthend,yearstart,yearend,selectedSSO,selectedSSO});
		templist = filterUnorderedLevels (templist);
		if(!PLMUtils.isEmptyList(templist)) {
			taskVolumeList.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).setMgr1table(templist);
			taskVolumeList.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).setCollapse(true);
			taskVolumeList.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).setExpand(false);
		}
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting taskVolumeExpandMgr2 of DaoImpl"); 
		return taskVolumeList;
	}
	/**
	 * This method is used for taskVolumeExpandMgr1
	 * 
	 * @param taskMetricData,taskVolumeList
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMTaskMetricsData> taskVolumeExpandMgr1(PLMTaskMetricsData taskMetricData,List<PLMTaskMetricsData> taskVolumeList) throws PLMCommonException {
		LOG.info("Entering taskVolumeExpandMgr1 of DaoImpl");
		try{
		String selectedSSO = PLMUtils.removeHash(taskMetricData.getSso());
		int vpindex =  taskMetricData.getVpIndex();
		int gmindex =  taskMetricData.getGmIndex();
		int fmindex	=   taskMetricData.getFmIndex();
		int mgr4index = taskMetricData.getMgr4index();
		int mgr3index = taskMetricData.getMgr3index();
		int mgr2index = taskMetricData.getMgr2index();
		int mgr1index = taskMetricData.getMgr1index();
		LOG.info("Selected MGR1 :" + selectedSSO);
		LOG.info("VP index :" + vpindex);
		LOG.info("GM index :" + gmindex);
		LOG.info("FM index :" + fmindex);
		LOG.info("MGR4 index :"+ mgr4index);
		LOG.info("MGR3 index :"+ mgr3index);
		LOG.info("MGR2 index :"+ mgr2index);
		LOG.info("MGR1 index :"+ mgr1index);
		LOG.info("Task Volume Expansion Query for MGR1 : " + PLMMetricsQueries.GET_TASKVOLUME_OWNER_DETAILS);
		List<PLMTaskMetricsData> templist = getSimpleJdbcTemplate().query(PLMMetricsQueries.GET_TASKVOLUME_OWNER_DETAILS,new OwnerMapper(),new Object[] {weekstart,weekend,monthstart,monthend,yearstart,yearend,selectedSSO,selectedSSO});
		taskVolumeList.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).getMgr1table().get(mgr1index).setOwnertable(templist);
		taskVolumeList.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).getMgr1table().get(mgr1index).setCollapse(true);
		taskVolumeList.get(vpindex).getGmTable().get(gmindex).getFmTable().get(fmindex).getMgr4table().get(mgr4index).getMgr3table().get(mgr3index).getMgr2table().get(mgr2index).getMgr1table().get(mgr1index).setExpand(false);
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting taskVolumeExpandMgr1 of DaoImpl"); 
		return taskVolumeList;
	}
	/**
	 * Mapper for Getting vpMapper
	 */
	//private static ParameterizedRowMapper<PLMTaskMetricsData> vpMapper = new ParameterizedRowMapper<PLMTaskMetricsData>() {
	private static final class VpMapper implements ParameterizedRowMapper<PLMTaskMetricsData>{	
	public PLMTaskMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMTaskMetricsData taskMetricsData = new PLMTaskMetricsData();
			taskMetricsData.setName(PLMUtils.checkNullVal(rs.getString("VP_NM")).trim());
			taskMetricsData.setSso(PLMUtils.checkNullVal(rs.getString("VP_NO")));
			taskMetricsData.setBackLogs(rs.getInt("BACK_LOG"));
			taskMetricsData.setDueWeek(rs.getInt("TASK_DUE_THIS_WEEK"));
			taskMetricsData.setDueMonth(rs.getInt("TASK_DUE_THIS_MONTH"));
			taskMetricsData.setDueYear(rs.getInt("TASK_DUE_THIS_YEAR"));
			taskMetricsData.setRowIndex(rs.getRow()-1);
			taskMetricsData.setTaskOwner(false);
			taskMetricsData.setExpand(true);
			taskMetricsData.setCollapse(false);
			if(taskMetricsData.getName().equalsIgnoreCase("OTHER") && taskMetricsData.getSso().equalsIgnoreCase("OTHER")) {
				taskMetricsData.setTaskOwner(true);
				taskMetricsData.setExpand(false);
				taskMetricsData.setCollapse(false);
			}
			taskMetricsData.setSso(PLMUtils.appendHash(taskMetricsData.getSso()));
			return taskMetricsData;
		}
	//	};
	}
	/**
	 * Mapper for Getting gmMapper
	 */
	//private static ParameterizedRowMapper<PLMTaskMetricsData> gmMapper = new ParameterizedRowMapper<PLMTaskMetricsData>() {
	private static final class GmMapper implements ParameterizedRowMapper<PLMTaskMetricsData>{	
	public PLMTaskMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMTaskMetricsData taskMetricsData = new PLMTaskMetricsData();
			taskMetricsData.setName(PLMUtils.checkNullVal(rs.getString("GM_NM")).trim());
			taskMetricsData.setSso(PLMUtils.checkNullVal(rs.getString("GM_NO")));
			taskMetricsData.setBackLogs(rs.getInt("BACK_LOG"));
			taskMetricsData.setDueWeek(rs.getInt("TASK_DUE_THIS_WEEK"));
			taskMetricsData.setDueMonth(rs.getInt("TASK_DUE_THIS_MONTH"));
			taskMetricsData.setDueYear(rs.getInt("TASK_DUE_THIS_YEAR"));
			taskMetricsData.setRowIndex(rs.getRow()-1);
			taskMetricsData.setTaskOwner(false);
			taskMetricsData.setExpand(true);
			taskMetricsData.setCollapse(false);
			if(taskMetricsData.getName().equalsIgnoreCase("") && taskMetricsData.getSso().equalsIgnoreCase("")) {
				taskMetricsData.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				taskMetricsData.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				taskMetricsData.setTaskOwner(true);
				taskMetricsData.setExpand(false);
				taskMetricsData.setCollapse(false);
			}
			taskMetricsData.setSso(PLMUtils.appendHash(taskMetricsData.getSso()));
			return taskMetricsData;
		}
	//	};
	}
	/**
	 * Mapper for Getting fmMapper
	 */
	//private static ParameterizedRowMapper<PLMTaskMetricsData> fmMapper = new ParameterizedRowMapper<PLMTaskMetricsData>() {
	private static final class FmMapper implements ParameterizedRowMapper<PLMTaskMetricsData>{ 	
	public PLMTaskMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMTaskMetricsData taskMetricsData = new PLMTaskMetricsData();
			taskMetricsData.setName(PLMUtils.checkNullVal(rs.getString("FM_NM")).trim());
			taskMetricsData.setSso(PLMUtils.checkNullVal(rs.getString("FM_NO")));
			taskMetricsData.setBackLogs(rs.getInt("BACK_LOG"));
			taskMetricsData.setDueWeek(rs.getInt("TASK_DUE_THIS_WEEK"));
			taskMetricsData.setDueMonth(rs.getInt("TASK_DUE_THIS_MONTH"));
			taskMetricsData.setDueYear(rs.getInt("TASK_DUE_THIS_YEAR"));
			taskMetricsData.setRowIndex(rs.getRow()-1);
			taskMetricsData.setExpand(true);
			taskMetricsData.setTaskOwner(false);
			taskMetricsData.setCollapse(false);
			if(taskMetricsData.getName().equalsIgnoreCase("") && taskMetricsData.getSso().equalsIgnoreCase("")) {
				taskMetricsData.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				taskMetricsData.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				taskMetricsData.setTaskOwner(true);
				taskMetricsData.setExpand(false);
				taskMetricsData.setCollapse(false);
			}
			taskMetricsData.setSso(PLMUtils.appendHash(taskMetricsData.getSso()));
			return taskMetricsData;
		}
	//	};
	}
	/**
	 * Mapper for Getting mgr4Mapper
	 */
	//private static ParameterizedRowMapper<PLMTaskMetricsData> mgr4Mapper = new ParameterizedRowMapper<PLMTaskMetricsData>() {
	private static final class Mgr4Mapper implements ParameterizedRowMapper<PLMTaskMetricsData>{	
	public PLMTaskMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMTaskMetricsData taskMetricsData = new PLMTaskMetricsData();
			taskMetricsData.setName(PLMUtils.checkNullVal(rs.getString("MGR4_NM")).trim());
			taskMetricsData.setSso(PLMUtils.checkNullVal(rs.getString("MGR4_NO")));
			taskMetricsData.setBackLogs(rs.getInt("BACK_LOG"));
			taskMetricsData.setDueWeek(rs.getInt("TASK_DUE_THIS_WEEK"));
			taskMetricsData.setDueMonth(rs.getInt("TASK_DUE_THIS_MONTH"));
			taskMetricsData.setDueYear(rs.getInt("TASK_DUE_THIS_YEAR"));
			taskMetricsData.setRowIndex(rs.getRow()-1);
			taskMetricsData.setTaskOwner(false);
			taskMetricsData.setExpand(true);
			taskMetricsData.setCollapse(false);
			
			if(taskMetricsData.getName().equalsIgnoreCase("") && taskMetricsData.getSso().equalsIgnoreCase("")) {
				taskMetricsData.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				taskMetricsData.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				taskMetricsData.setTaskOwner(true);
				taskMetricsData.setExpand(false);
				taskMetricsData.setCollapse(false);
			}
			taskMetricsData.setSso(PLMUtils.appendHash(taskMetricsData.getSso()));
			return taskMetricsData;
		}
	//	};
	}
	/**
	 * Mapper for Getting mgr3Mapper
	 */
	//private static ParameterizedRowMapper<PLMTaskMetricsData> mgr3Mapper = new ParameterizedRowMapper<PLMTaskMetricsData>() {
	private static final class Mgr3Mapper implements ParameterizedRowMapper<PLMTaskMetricsData>{
	public PLMTaskMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMTaskMetricsData taskMetricsData = new PLMTaskMetricsData();
			taskMetricsData.setName(PLMUtils.checkNullVal(rs.getString("MGR3_NM")).trim());
			taskMetricsData.setSso(PLMUtils.checkNullVal(rs.getString("MGR3_NO")));
			taskMetricsData.setBackLogs(rs.getInt("BACK_LOG"));
			taskMetricsData.setDueWeek(rs.getInt("TASK_DUE_THIS_WEEK"));
			taskMetricsData.setDueMonth(rs.getInt("TASK_DUE_THIS_MONTH"));
			taskMetricsData.setDueYear(rs.getInt("TASK_DUE_THIS_YEAR"));
			taskMetricsData.setRowIndex(rs.getRow()-1);
			taskMetricsData.setTaskOwner(false);
			taskMetricsData.setExpand(true);
			taskMetricsData.setCollapse(false);
			
			if(taskMetricsData.getName().equalsIgnoreCase("") && taskMetricsData.getSso().equalsIgnoreCase("")) {
				taskMetricsData.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				taskMetricsData.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				taskMetricsData.setTaskOwner(true);
				taskMetricsData.setExpand(false);
				taskMetricsData.setCollapse(false);
			}
			taskMetricsData.setSso(PLMUtils.appendHash(taskMetricsData.getSso()));
			return taskMetricsData;
		}
	//	};
	}
	/**
	 * Mapper for Getting mgr2Mapper
	 */
	//private static ParameterizedRowMapper<PLMTaskMetricsData> mgr2Mapper = new ParameterizedRowMapper<PLMTaskMetricsData>() {
	private static final class Mgr2Mapper implements ParameterizedRowMapper<PLMTaskMetricsData>{	
	public PLMTaskMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMTaskMetricsData taskMetricsData = new PLMTaskMetricsData();
			taskMetricsData.setName(PLMUtils.checkNullVal(rs.getString("MGR2_NM")).trim());
			taskMetricsData.setSso(PLMUtils.checkNullVal(rs.getString("MGR2_NO")));
			taskMetricsData.setBackLogs(rs.getInt("BACK_LOG"));
			taskMetricsData.setDueWeek(rs.getInt("TASK_DUE_THIS_WEEK"));
			taskMetricsData.setDueMonth(rs.getInt("TASK_DUE_THIS_MONTH"));
			taskMetricsData.setDueYear(rs.getInt("TASK_DUE_THIS_YEAR"));
			taskMetricsData.setRowIndex(rs.getRow()-1);
			taskMetricsData.setTaskOwner(false);
			taskMetricsData.setExpand(true);
			taskMetricsData.setCollapse(false);
			
			if(taskMetricsData.getName().equalsIgnoreCase("") && taskMetricsData.getSso().equalsIgnoreCase("")){
				taskMetricsData.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				taskMetricsData.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				taskMetricsData.setTaskOwner(true);
				taskMetricsData.setExpand(false);
				taskMetricsData.setCollapse(false);
			}
			taskMetricsData.setSso(PLMUtils.appendHash(taskMetricsData.getSso()));
			return taskMetricsData;
		}
	//	};
	}
	/**
	 * Mapper for Getting mgr1Mapper
	 */
	//private static ParameterizedRowMapper<PLMTaskMetricsData> mgr1Mapper = new ParameterizedRowMapper<PLMTaskMetricsData>() {
	private static final class Mgr1Mapper implements ParameterizedRowMapper<PLMTaskMetricsData>{	
	public PLMTaskMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMTaskMetricsData taskMetricsData = new PLMTaskMetricsData();
			taskMetricsData.setName(PLMUtils.checkNullVal(rs.getString("MGR1_NM")).trim());
			taskMetricsData.setSso(PLMUtils.checkNullVal(rs.getString("MGR1_NO")));
			taskMetricsData.setBackLogs(rs.getInt("BACK_LOG"));
			taskMetricsData.setDueWeek(rs.getInt("TASK_DUE_THIS_WEEK"));
			taskMetricsData.setDueMonth(rs.getInt("TASK_DUE_THIS_MONTH"));
			taskMetricsData.setDueYear(rs.getInt("TASK_DUE_THIS_YEAR"));
			taskMetricsData.setRowIndex(rs.getRow()-1);
			taskMetricsData.setTaskOwner(false);
			taskMetricsData.setExpand(true);
			taskMetricsData.setCollapse(false);
			
			if(taskMetricsData.getName().equalsIgnoreCase("") && taskMetricsData.getSso().equalsIgnoreCase("")) {
				taskMetricsData.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
				taskMetricsData.setSso(PLMUtils.checkNullVal(rs.getString("OWNER_NO")));
				taskMetricsData.setTaskOwner(true);
				taskMetricsData.setExpand(false);
				taskMetricsData.setCollapse(false);
			}
			taskMetricsData.setSso(PLMUtils.appendHash(taskMetricsData.getSso()));
			return taskMetricsData;
		}
	//	};
	}
	/**
	 * Mapper for Getting ownerMapper
	 */
	//private static ParameterizedRowMapper<PLMTaskMetricsData> ownerMapper = new ParameterizedRowMapper<PLMTaskMetricsData>() {
	private static final class OwnerMapper implements ParameterizedRowMapper<PLMTaskMetricsData>{	
	public PLMTaskMetricsData mapRow(ResultSet rs, int rowCount)	throws SQLException {
			PLMTaskMetricsData taskMetricsData = new PLMTaskMetricsData();
			taskMetricsData.setName(PLMUtils.checkNullVal(rs.getString("OWNER_NM")).trim());
			taskMetricsData.setSso(PLMUtils.appendHash(PLMUtils.checkNullVal(rs.getString("OWNER_NO"))));
			taskMetricsData.setBackLogs(rs.getInt("BACK_LOG"));
			taskMetricsData.setDueWeek(rs.getInt("TASK_DUE_THIS_WEEK"));
			taskMetricsData.setDueMonth(rs.getInt("TASK_DUE_THIS_MONTH"));
			taskMetricsData.setDueYear(rs.getInt("TASK_DUE_THIS_YEAR"));
			taskMetricsData.setRowIndex(rs.getRow()-1);
			taskMetricsData.setTaskOwner(false);
			taskMetricsData.setExpand(true);
			taskMetricsData.setCollapse(false);
			return taskMetricsData;
		}
	//	};
	}
}