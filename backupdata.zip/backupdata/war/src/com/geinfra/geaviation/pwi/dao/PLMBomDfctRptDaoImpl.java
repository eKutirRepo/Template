/**
 * Copyright (C) 2014 GE Infra. All rights reserved
 * 
 * @FileName PLMBomDfctRptDaoImpl.java
 * @Creation date: 15-July-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMBomDfctRptData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMUtils;

public class PLMBomDfctRptDaoImpl extends SimpleJdbcDaoSupport implements PLMBomDfctRptDaoIfc{
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMBomDfctRptDaoImpl.class);
	
	/**
	 * This method is used to check for valid partNumber.
	 * 
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<String> checkForValidPartNum(String partNumber)throws PLMCommonException{
		LOG.info("Entering checkForValidPartNum Method");
		List<String> partIdList =new ArrayList<String>();
		try{
			LOG.info("Part Number#  : " + partNumber);
			LOG.info("Query for checking valid Part Num #  : " + PLMOfflineQueries.GET_BOM_DEFECT_ID);
			partIdList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_BOM_DEFECT_ID, new PartNumberMapper(),new Object[] { partNumber });
			LOG.info("values of part Id size "+partIdList.size());
			} catch(DataAccessException e){
				PLMUtils.checkException(e.getMessage());
			}
		LOG.info("Exiting checkForValidPartNum Method");
		return partIdList;
	}
	
	private static final class PartNumberMapper implements ParameterizedRowMapper<String> {
			public String mapRow(ResultSet rs, int rowCount) throws SQLException {
				String partIdData = "";
				partIdData = PLMUtils.checkNullVal(rs.getString("ID"));		
				return partIdData;
			}
	}
	/**
	 * This method is used to get BOM Defect report
	 * 
	 * @param partId
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomDfctRptData> getBomDefectRpt(String partId) throws PLMCommonException{
		String timeStamp = null;
		String VT_EBOM = null;
		String VT_ALL_PARTS_1 = null;
		String VT_ALT_PART_1 = null;
		String VT_BOM_CMU = null;
		LOG.info("Entering getBomDefectRpt Method");
		List<PLMBomDfctRptData> bomDefectDataList = new ArrayList<PLMBomDfctRptData>();
		try{
			timeStamp = PLMUtils.volTableFormatDate();
			LOG.info("The timeStamp for the getBomDefectRpt "+timeStamp);
			VT_EBOM = PLMConstants.VT_EBOM.concat(timeStamp);
			VT_ALL_PARTS_1 = PLMConstants.VT_ALL_PARTS_1.concat(timeStamp);
			VT_ALT_PART_1 = PLMConstants.VT_ALT_PART_1.concat(timeStamp);
			VT_BOM_CMU = PLMConstants.VT_BOM_CMU.concat(timeStamp);
			
			LOG.info("Query for Creating VT_EBOM : "+PLMOfflineQueries.GET_BOM_DEFECT_NEW_DATA_VT1.replace(PLMConstants.VT_EBOM, VT_EBOM)
					.replace("?", "'"+partId+"'"));
			getJdbcTemplate().execute(PLMOfflineQueries.GET_BOM_DEFECT_NEW_DATA_VT1.replace(PLMConstants.VT_EBOM, VT_EBOM).replace("?", "'"+partId+"'"));
			
			LOG.info("Query for Creating VT_ALL_PARTS_1 : " + PLMOfflineQueries.GET_BOM_DEFECT_NEW_DATA_VT2.replace(PLMConstants.VT_ALL_PARTS_1, VT_ALL_PARTS_1));
			getJdbcTemplate().execute(PLMOfflineQueries.GET_BOM_DEFECT_NEW_DATA_VT2.replace(PLMConstants.VT_ALL_PARTS_1, VT_ALL_PARTS_1));
			
			LOG.info("Query for Creating VT_ALT_PART_1 : " + PLMOfflineQueries.GET_BOM_DEFECT_NEW_DATA_VT3.replace(PLMConstants.VT_ALT_PART_1, VT_ALT_PART_1)
						.replace(PLMConstants.VT_EBOM, VT_EBOM).replace(PLMConstants.VT_ALL_PARTS_1, VT_ALL_PARTS_1));
			getJdbcTemplate().execute(PLMOfflineQueries.GET_BOM_DEFECT_NEW_DATA_VT3.replace(PLMConstants.VT_ALT_PART_1, VT_ALT_PART_1)
				.replace(PLMConstants.VT_EBOM, VT_EBOM).replace(PLMConstants.VT_ALL_PARTS_1, VT_ALL_PARTS_1));
			
			LOG.info("Query for Creating VT_BOM_CMU : " + PLMOfflineQueries.GET_BOM_DEFECT_NEW_DATA_VT4.replace(PLMConstants.VT_BOM_CMU, VT_BOM_CMU)
					.replace(PLMConstants.VT_EBOM, VT_EBOM).replace(PLMConstants.VT_ALT_PART_1, VT_ALT_PART_1));
			getJdbcTemplate().execute(PLMOfflineQueries.GET_BOM_DEFECT_NEW_DATA_VT4.replace(PLMConstants.VT_BOM_CMU, VT_BOM_CMU)
					.replace(PLMConstants.VT_EBOM, VT_EBOM).replace(PLMConstants.VT_ALT_PART_1, VT_ALT_PART_1));
				
		LOG.info("Query for getBomDefectRpt with partId-> "+partId +" >>>>>"+PLMOfflineQueries.GET_BOM_DEFECT_NEW_DATA.replace(PLMConstants.VT_BOM_CMU, VT_BOM_CMU));
		bomDefectDataList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_BOM_DEFECT_NEW_DATA.replace(PLMConstants.VT_BOM_CMU, VT_BOM_CMU), new BomDefectMapper());
		LOG.info("getBomDefectRpt Results size "+bomDefectDataList.size());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Existing getBomDefectRpt Method");
		return bomDefectDataList;
	}
	
	/**
	 * @return PLMBomDfctRptData objects.
	 */
	private static final class BomDefectMapper implements ParameterizedRowMapper<PLMBomDfctRptData>{	
		public PLMBomDfctRptData mapRow(ResultSet rs, int rowCount) throws SQLException {			
			PLMBomDfctRptData searchData = new PLMBomDfctRptData();
			searchData.setLevel(PLMUtils.checkNullVal(rs.getString("LVL")));
			searchData.setPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
			searchData.setPartRev(PLMUtils.checkNullVal(rs.getString("PART_REV")));
			searchData.setEid(PLMUtils.checkNullVal(rs.getString("EID")));
			searchData.setFindNum(PLMUtils.checkNullVal(rs.getString("FIND_NUM")));
			searchData.setQuantity(PLMUtils.checkNullVal(rs.getString("QUANTITY")));
			searchData.setProdStatus(PLMUtils.checkNullVal(rs.getString("PRDTN_STATUS")));
			searchData.setPlmUoM(PLMUtils.checkNullVal(rs.getString("PLM_UOM")));
			searchData.setPartDesc(PLMUtils.checkNullVal(rs.getString("PART_DESCRIPTION")));
			searchData.setGeApplicationNotes(PLMUtils.checkNullVal(rs.getString("GE_APPLICATION_NOTES")));
			searchData.setPlmState(PLMUtils.checkNullVal(rs.getString("PLM_STATE")));
			/*searchData.setAlternatePart(PLMUtils.checkNullVal(rs.getString("PLM_ALTERNATE_PART")));*/
			searchData.setGePreferedReplacement(PLMUtils.checkNullVal(rs.getString("GE_PREFERRED_REPLACEMENT")));
			searchData.setErpItmStaus(PLMUtils.checkNullVal(rs.getString("ERP_LINE_STATUS")));
			searchData.setSupercededTo(PLMUtils.checkNullVal(rs.getString("SUPERCEDED_TO")));
			searchData.setItemCost(PLMUtils.checkNullVal(rs.getString("ITEM_COST")));
			searchData.setErpTotalCycle(PLMUtils.checkNullVal(rs.getString("FULL_LEAD_TIME")));
			searchData.setErpUoM(PLMUtils.checkNullVal(rs.getString("UOM_DESC")));
			searchData.setPlmChmclCode(PLMUtils.checkNullVal(rs.getString("PLM_CHEMICAL_CODE")));
			searchData.setAlternatePart(PLMUtils.checkNullVal(rs.getString("ALTERNATE_PART")));
			searchData.setErrorText("");
		
			return searchData;
		}
	}
	

	

}
