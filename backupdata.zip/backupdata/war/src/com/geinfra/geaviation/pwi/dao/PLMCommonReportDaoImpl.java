/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCommonReportDaoImpl.java
 * @Creation date: 12-Aug-2011
 * @version 2.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMQueryConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;


/**
 * PLMCommonReportDaoImpl is the DAO implementation class.
 */
public class PLMCommonReportDaoImpl extends SimpleJdbcDaoSupport implements	PLMCommonReportDaoIfc {

	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMCommonReportDaoImpl.class);

	/**
	 * This method is used to getLegacyDateStamp
	 * @return String
	 * @throws PLMCommonException
	 */
 public String getLegacyDateStamp () throws PLMCommonException {
	LOG.info("Entering getLegacyDateStamp of PLMCommonReportDaoImpl");
	//String query = PLMQueryConstants.GET_LEGACYDATE;
	//query = query.concat(" " + tablename + " ");
	//LOG.info(query);
	LOG.info("Legacy Data Query : " + PLMQueryConstants.GET_LEGACYDATE);
	String legacydate = null;
	try{
	legacydate = getSimpleJdbcTemplate().queryForObject(PLMQueryConstants.GET_LEGACYDATE,new LegacydateMapper());
	}catch(DataAccessException e){
		PLMUtils.checkException(e.getMessage());
	}
	LOG.info("Exiting getLegacyDateStamp of PLMCommonReportDaoImpl");
	return legacydate; 		
}
 /**
	 * This method is used to getPLMDateStamp
	 * @return String
	 * @throws PLMCommonException
	 */
public String getPLMDateStamp (String tablename) throws PLMCommonException {
	LOG.info("Entering getPLMDateStamp of PLMCommonReportDaoImpl");
	StringBuffer query = new StringBuffer(PLMQueryConstants.GET_PLMDATE);
	query.append(PLMConstants.MODEL);
	query.append(tablename);
	LOG.info(query);
	LOG.info("TABLE NAME : " + tablename);
	String plmdate = null;
	try{
		plmdate = getSimpleJdbcTemplate().queryForObject(query.toString(),new PlmdateMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getPLMDateStamp of PLMCommonReportDaoImpl");
		return plmdate;
}

/**
 * This method is used to getETLRunDateStamp
 * @return String
 * @throws PLMCommonException
 */
public String getETLRunDateStamp() throws PLMCommonException {
	
	LOG.info("Entering getETLRunDateStamp of PLMCommonReportDaoImpl Executing Query \n"+PLMQueryConstants.GET_ETLRUNDATE);
	String plmdate = null;
	try{
		plmdate = getSimpleJdbcTemplate().queryForObject(PLMQueryConstants.GET_ETLRUNDATE,new EtldateMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getETLRunDateStamp of PLMCommonReportDaoImpl");
		return plmdate;
	
}

//Newly Added method for getting Last Refresh COPICS Date
/**
* This method is used to getCOPICSRunDateStamp
* @return String
* @throws PLMCommonException
*/
public String getCOPICSRunDateStamp() throws PLMCommonException {
	
	LOG.info("Entering getCOPICSRunDateStamp of PLMCommonReportDaoImpl Executing Query \n"+PLMQueryConstants.GET_COPICSRUNDATE);
	String plmdate = null;
	try{
		plmdate = getSimpleJdbcTemplate().queryForObject(PLMQueryConstants.GET_COPICSRUNDATE,new CopicsdateMapper());
		}catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getCOPICSRunDateStamp of PLMCommonReportDaoImpl");
		return plmdate;
	
}

/**
 * @return String objects.
 */
private static final class LegacydateMapper implements ParameterizedRowMapper<String> {
//private static ParameterizedRowMapper<String> legacydatemapper = new ParameterizedRowMapper<String>() {
	public String mapRow(ResultSet rs, int rowCount) throws SQLException {
		String result;
		result = rs.getString("LEGACY_DATE");
		return result;
	}
}

/**
 * @return String objects.
 */
private static final class PlmdateMapper implements ParameterizedRowMapper<String> {
//private static ParameterizedRowMapper<String> plmdatemapper = new ParameterizedRowMapper<String>() {
	public String mapRow(ResultSet rs, int rowCount) throws SQLException {
		String result;
		result = rs.getString("PLM_DATE");
		return result;
	}
}

/**
 * @return String objects.
 */
private static final class EtldateMapper implements ParameterizedRowMapper<String> {
//private static ParameterizedRowMapper<String> etldatemapper = new ParameterizedRowMapper<String>() {
	public String mapRow(ResultSet rs, int rowCount) throws SQLException {
		String result;
		result = rs.getString("ETL_RUN_DATE");
		return result;
	}
}
//Newly Mapper for getting Last Refresh COPICS Date
/**
* @return String objects.
*/
private static final class CopicsdateMapper implements ParameterizedRowMapper<String> {
	public String mapRow(ResultSet rs, int rowCount) throws SQLException {
		String result;
		result = rs.getString("LOAD_DATE");
		return result;
	}
}

/**
 * @param reportName
 * @return
 * @throws PLMCommonException
 */
public int insertCannedRptRecordHitInfo(String reportName, String sso) throws PLMCommonException {

	//final String sso = UserInfoPortalUtil.getInstance().getUserSSO();
	int count=0;

	// Get sql
	StringBuilder sql = new StringBuilder();
	sql.append(PLMQueryConstants.INSERT_CANNED_RPT_HIT);
	LOG.info("SSO ID:::::::"+sso);
	LOG.info("Report Name:::::::"+reportName);
	try {
		count = getSimpleJdbcTemplate().update(
				sql.toString(),
				new Object[] { PLMUtils.checkNullVal(sso),
						PLMUtils.checkNullVal(reportName),new Timestamp(System.currentTimeMillis()), PLMUtils.checkNullVal(sso), PLMUtils.checkNullVal(sso) });
		LOG.info("The Insert query returned '" + count + "' number of records");
		
	} catch (DataAccessException dae) {
		LOG.error("Error in granting auto-access process." + dae.getMessage());
	}
	return count;
  }
	
}
