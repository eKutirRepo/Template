/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMLoginMB.java
 * @Creation date: 15-June-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */

package com.geinfra.geaviation.pwi.bean;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMAdminData;
import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMAdminServiceIfc;
import com.geinfra.geaviation.pwi.service.PLMCommonServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

/**
 * PLMLoginMB is the managed bean class for Login.
 */

public class PLMLoginMB {
	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMLoginMB.class);
	
	private PLMPwiUserData userDetails = null;

	public PLMLoginMB() {
		//LOG.info("Bean Initialized----------------------------");
		wuPrtIdLst = new ArrayList<String>();
		String partIdLst = (String)PLMUtils.getServletSession(true).getAttribute("WuPartId");
		//LOG.info("Part Id List Passed ---------------------------"+partIdLst);
		if (partIdLst!=null) {
			String[] partIdArr = partIdLst.split(",");
			if (partIdArr!=null) {
				for (int i=0;i<partIdArr.length;i++) {
					if (!wuPrtIdLst.contains(partIdArr[i]))
						wuPrtIdLst.add(partIdArr[i]);
				}
			}
		}
		wuFlag = (String)PLMUtils.getServletSession(true).getAttribute("wuFlag");
		//LOG.info("WU Part Id List Size ---------------------------- "+wuPrtIdLst.size());
		PLMUtils.getServletSession(true).removeAttribute("WuPartId");
		PLMUtils.getServletSession(true).removeAttribute("wuFlag");
	}
	/**
	 * Holds the login User loginDetails
	 */
	private PLMLoginData loginDetails;
	/**
	 * Holds the login User ssoId
	 */
	private String ssoId;
	/**
	 * Holds the login User password
	 */
	private String password;
	/**
	 * Holds the login User familyName
	 */
	private String familyName;
	/**
	 * Holds the login User givenName
	 */
	private String givenName;
	/**
	 * Holds the login User loginMsg
	 */
	private String loginMsg;
	/**
	 * Holds the login User documentSearchAccess
	 */
	private boolean documentSearchAccess;
	/**
	 * Holds the login User drawingWorkFlow
	 */
	private boolean drawingWorkFlow;
	/**
	 * Holds the login User ecosearch
	 */
	private boolean ecosearch;
	/**
	 * Holds the login User ecrsearch
	 */
	private boolean ecrsearch;
	/**
	 * Holds the login User issuessearch
	 */
	private boolean issuessearch;
	/**
	 * Holds the login User localUserSSO
	 */
	private String localUserSSO;
	/**
	 * Holds the login User loginUserSSO
	 */
	private String loginUserSSO;
	
	/**
	 * Holds the login User userGroups
	 */
	private List<SelectItem> userGroups = new ArrayList<SelectItem>();
	/**
	 * Holds the login User grpSize
	 */
	private boolean grpSize;
	/**
	 * Holds the login User grNme
	 */
	private String grNme;
	/**
	 * Holds the login User loginUserGrpName
	 */
	private String loginUserGrpName;
	/**
	 * Holds the login User localUserlname
	 */
	private String localUserlname;
	/**
	 * Holds the login User localUserfname
	 */
	private String localUserfname;
	/**
	 * Holds the login User localUseremail
	 */
	private String localUseremail;
	/**
	 * Holds the login User commonSvcObj
	 */
	private PLMCommonServiceIfc commonSvcObj = null;
	/**
	 * Holds the login User requestMB
	 */
	private PLMRequestMB requestMB = new PLMRequestMB();
	
	/**
	 * Holds the login User plmrAdminStatus
	 */
	private boolean plmrAdminStatus;
	/**
	 * Holds the login User plmrSearchStatus
	 */
	private boolean plmrSearchStatus;
	/**
	 * Holds the login User plmrDgtStatus
	 */
	private boolean plmrDgtStatus;
	/**
	 * Holds the login User plmrDgtAdminStatus
	 */
	private boolean plmrDgtAdminStatus;
	/**
	 * Holds the login User plmrMetricStatus
	 */
	private boolean plmrMetricStatus;
	/**
	 * Holds the login User plmrWhereUsedStatus
	 */
	private boolean plmrWhereUsedStatus;
	/**
	 * Holds the login User plmrLttrStatus
	 */
	private boolean plmrLttrStatus;
	/**
	 * Holds the login User perCheckVal
	 */
	private String perCheckVal;
	/**
	 * Holds the login User permTempDetails
	 */
	private Map<String, List<String>> permTempDetails = new HashMap<String, List<String>>();
	/**
	 * Holds the login User oldValue
	 */
	private String oldValue;
	/**
	 * Holds the login User newValue
	 */
	private String newValue;
			
	/**
	 * List of PLMAdmindata.
	 */
	private List<PLMAdminData> listOfReports = new ArrayList<PLMAdminData>();
	/**
	 * Service Handler for PLMAdminServiceIfc
	 */
	public PLMAdminServiceIfc adminServiceIfc;
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the login User plmrCostRptStatus
	 */
	private boolean plmrCostRptStatus;
	/**
	 * Holds the login User plmrContractSumryReprtStatus
	 */
	private boolean plmrContractSumryReprtStatus;
	/**
	 * Holds the login User loginUserGroup
	 */
	private String loginUserGroup;
	
	private String userName;
	
	private String wuFlag;
	/**
	 * Holds the login User requestMB
	 */
	private PLMCommonMB commonMB=null;
	/**
	 * Holds the login User requestMB
	 */
	private PLMWhereUsedMB plmWhereUsedMB=null;
	
	private List<String> wuPrtIdLst;
	
	/**
	 * This method is used for getting Login User groups
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public List<SelectItem> fetchUserGroups(String userSSO)
			throws PLMCommonException {
		List<SelectItem> userGroupDetails = null;
		try {
			LOG.info("loginUserSSO in fetchUserGroups of LoginMB >>>>>>>>>>"
					+ userSSO);
			LOG.info("loginUserSSO in fetchUserGroups of LoginMB >>>>>>>>>>"
					+ commonSvcObj);
			userGroupDetails = commonSvcObj.fetchUserGroups(userSSO);

		} catch (PLMCommonException ef) {
			LOG.log(Level.ERROR, "Exception@fetchUserGroups: ", ef);
			throw ef;
		}
		return userGroupDetails;
	}

	/**
	 * This method is used for get SSO Data
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */

	public String getSSOData() {
		String returnStr = null;
		try {
			LOG.info("localUserSSO >>>>>>>>>>" + localUserSSO);	
			if (localUserSSO == null || localUserSSO.equals("")) {
				loginMsg = "Please Enter SSOID";
				returnStr = "login";
			} else if (localUserSSO.length() != PLMConstants.N_9) {
				loginMsg = "Field Length of SSO Should be 9";
				returnStr = "login";
			} else {
				returnStr = "legal";
			}
		} catch (Exception ef) {
			LOG.log(Level.ERROR,
					"The Exception in getSSOData method of ICMLoginMB is "
							+ ef.getMessage());
			returnStr = PLMConstants.ERROR;
		}
		return returnStr;
	}

	/**
	 * This method is used for Validate the User Credentials
	 * 
	 * @return String
	 * @throws PWiException 
	 * @throws PLMCommonException
	 */
	public String validateUserData() throws PWiException{
		String returnStr = null;
		String viewHome = null;
		
		grNme = PLMConstants.EMPTY_STRING;
		List<String> wuPrtIdLstLcl = new ArrayList<String>();
		String wuFlagLcl = wuFlag;
		if (wuPrtIdLst!=null) {
			wuPrtIdLstLcl.addAll(wuPrtIdLst);
			wuPrtIdLst.clear();
			
		}
		wuFlag="";
		try {
			LOG.info("localUserSSO in validateUserData of ICMLoginMB >>>>>>>>>>"
							+ localUserSSO);
			if (PLMUtils.getServletRequest().getHeader("sm_ssoid") != null) {
				loginUserSSO = (String) PLMUtils.getServletRequest().getHeader(
						"sm_ssoid");
				LOG.info("loginUserSSO from header >>>>>>>>>>" + loginUserSSO);
			} else {
				if (localUserSSO != null && !PLMUtils.isEmpty(localUserSSO))
					loginUserSSO = localUserSSO;
			}
			if (PLMUtils.getServletRequest().getHeader("sm_last_name") != null) {
				localUserlname = (String) PLMUtils.getServletRequest()
						.getHeader("sm_last_name");
				LOG.info("localUserlname from header >>>>>>>>>>"
						+ localUserlname);
			}
			if (PLMUtils.getServletRequest().getHeader("sm_first_name") != null) {
				localUserfname = (String) PLMUtils.getServletRequest()
						.getHeader("sm_first_name");
				LOG.info("localUserfname from header >>>>>>>>>>"
						+ localUserfname);
			}
			if (PLMUtils.getServletRequest().getHeader("sm_email") != null) {
				localUseremail = (String) PLMUtils.getServletRequest()
						.getHeader("sm_email");
				LOG.info("localUseremail from header >>>>>>>>>>"
						+ localUseremail);
			}
			userGroups = fetchUserGroups(loginUserSSO);
			PLMLoginData userDetailsLcl = commonSvcObj.validateUserDetails(loginUserSSO);
			// The below code is needed only for local
			if (userDetailsLcl != null
					&& PLMUtils.chkNull(userDetailsLcl.getActiveInd())
							.equalsIgnoreCase(PLMConstants.YES)) {
				localUserfname = userDetailsLcl.getFName();
				localUserlname = userDetailsLcl.getLName();
				localUseremail = userDetailsLcl.getEmail();
				givenName = localUserlname + ", " + localUserfname;
				userName = localUserfname + ", " + localUserlname;
			}
			// end of the code

			listOfReports = adminServiceIfc.getListOfReports();
			if (listOfReports != null) {
				totalRecCount = listOfReports.size();
			}
			if (userGroups != null && userGroups.size() == PLMConstants.N_1) {
				grpSize = true;
				SelectItem userData = userGroups.get(PLMConstants.N_0);
				loginUserGrpName = (String) userData.getDescription();
				loginUserGroup = (String) userData.getValue();
				grNme = (String) userData.getLabel();
				LOG.info("The Whereused Flag Val "+wuFlag);
				if (wuPrtIdLstLcl!=null && !PLMUtils.isEmptyList(wuPrtIdLstLcl) && 
						wuFlagLcl!=null && !PLMUtils.isEmpty(wuFlagLcl)) {
					getPermissionDetails();
					if (wuPrtIdLstLcl.size()<=3) {
						//plmWhereUsedMB.setTliPartNumber(wuPrtIdLst.get(0));
						plmWhereUsedMB.setImpactPartIdLst(wuPrtIdLstLcl);
						viewHome = plmWhereUsedMB.getImpactAnalysis();
					} else {
						plmWhereUsedMB.setImpactPartIdLst(wuPrtIdLstLcl);
						plmWhereUsedMB.setUserDataObj1((PLMLoginData) PLMUtils
								.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA));
						viewHome = plmWhereUsedMB.impctAnlsysOfflnRpt();
						
					}
					wuPrtIdLstLcl.clear();
					wuFlagLcl= "";
				} else {
					plmWhereUsedMB.setAlertMessage("");
					viewHome = getPermissionDetails();
				}
				returnStr = viewHome;
				commonMB.getETLDateStamp();
			} else if (userGroups != null
					&& userGroups.size() > PLMConstants.N_1) {
				grpSize = false;
				int count = 0;
				for (SelectItem data : userGroups) {
					if (data.getLabel().equalsIgnoreCase(
							PLMUtils.getMessage(PLMConstants.SYSTEM_ADMIN))) {
						loginUserGrpName = (String) data.getDescription();
						loginUserGroup = (String) data.getValue();

					} else {
						count++;
					}

				}
				if (count == userGroups.size()) {
					SelectItem userData = userGroups.get(PLMConstants.N_0);
					loginUserGrpName = (String) userData.getDescription();
					loginUserGroup = (String) userData.getValue();
				}

				LOG
						.info("userGroups in validateUserData of ICMLoginMB >>>>>>>>>>"
								+ userGroups);
				LOG.info("The Whereused Flag Val "+wuFlag);
				if (wuPrtIdLstLcl!=null && !PLMUtils.isEmptyList(wuPrtIdLstLcl) && 
						wuFlagLcl!=null && !PLMUtils.isEmpty(wuFlagLcl)) {
					getPermissionDetails();
					if (wuPrtIdLstLcl.size()<=3) {
						//plmWhereUsedMB.setTliPartNumber(wuPrtIdLst.get(0));
						plmWhereUsedMB.setImpactPartIdLst(wuPrtIdLstLcl);
						viewHome = plmWhereUsedMB.getImpactAnalysis();
					} else {
						plmWhereUsedMB.setImpactPartIdLst(wuPrtIdLstLcl);
						plmWhereUsedMB.setUserDataObj1((PLMLoginData) PLMUtils
								.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA));
						viewHome = plmWhereUsedMB.impctAnlsysOfflnRpt();
					}
					wuPrtIdLstLcl.clear();
					wuFlagLcl= "";
				} else {
					plmWhereUsedMB.setAlertMessage("");
					viewHome = getPermissionDetails();
				}
				returnStr = viewHome;
				commonMB.getETLDateStamp();
				// returnStr = "selusergroups";
			} else {
				LOG.info("\n\n\n Request Account Logic -------------------->");
				if (localUseremail == null || localUseremail.equals("")) {
					localUseremail = PLMUtils
							.getMessage(PLMConstants.LOCAL_TEST_EMAIL);
				}
				if (userDetailsLcl != null){
					LOG
							.info("\n\n\n Request Account Logic -----userDetails---->"
									+ userDetailsLcl);
					userDetailsLcl = new PLMLoginData();
					userDetailsLcl.setFName(localUserfname);
					userDetailsLcl.setLName(localUserlname);
					userDetailsLcl.setUserSsoId(loginUserSSO);
					userDetailsLcl.setUserEmail(localUseremail);
					userDetailsLcl.setState(PLMConstants.NOO);
					returnStr = requestMB.requestNewUser(userDetailsLcl);
				} else {
					userDetailsLcl = new PLMLoginData();
					userDetailsLcl.setFName(localUserfname);
					userDetailsLcl.setLName(localUserlname);
					userDetailsLcl.setUserSsoId(loginUserSSO);
					userDetailsLcl.setUserEmail(localUseremail);
					userDetailsLcl.setState("");
					LOG.info("\n\n\n Request Account Logic -----userDetails--else-->"
									+ userDetailsLcl);
					returnStr = requestMB.requestNewUser(userDetailsLcl);

				}
			}
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@validateUserData: ", exception);
			returnStr = PLMUtils.setCommonException(exception.getMessage(),commonMB,"legal","Login Page");
		} finally {
			viewHome = null;
		}
		return returnStr;
	}

	/**
	 * This method is used for getting Login User Permission Details
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getPermissionDetails() {
		String returnStr = null;
		String check = "";
		if (!PLMUtils.isEmpty(PLMUtils.getRequestParameter("roleChange"))) {
			check = PLMUtils.getRequestParameter("roleChange");
		}
		List<PLMLoginData> permissionData = new ArrayList<PLMLoginData>();
		List<String> screenData = new ArrayList<String>();
		List<String> screenPos = new ArrayList<String>();
		Map<String, List<String>> permDetails = new HashMap<String, List<String>>();
		String eventName = null;
		
		
		plmrAdminStatus = false;
		plmrSearchStatus = false;
		plmrDgtStatus = false;
		plmrDgtAdminStatus = false;
		plmrMetricStatus = false;
		plmrWhereUsedStatus = false;
		plmrLttrStatus = false;
		plmrCostRptStatus = false;
		plmrContractSumryReprtStatus = false;
		
		perCheckVal = "";
		try {
			Iterator<SelectItem> it = userGroups.iterator();
			if (it != null) {
				while (it.hasNext()) {
					SelectItem val = it.next();
					if (val != null && val.getValue().equals(loginUserGroup)) {
						loginUserGrpName = val.getLabel();
						break;
					}
				}
			}
			eventName = PLMUtils.getMessage(PLMConstants.LOGIN_EVENT_SUBMIT);
			LOG.info("loginMsg in getPermissionDetails >>>>>>>>>>" + loginMsg);
				LOG.info("loginUserGroup in getPermissionDetails >>>>>>>>>>"
						+ loginUserGroup);
				if (loginUserSSO != null && !loginUserSSO.equals("")
						&& loginUserGroup != null && !loginUserGroup.equals("")) {
					permissionData = commonSvcObj
							.getPermissionDetails(userGroups);
				}
				LOG.info("permissionData in getPermissionDetails >>>>>>>>>>"
						+ permissionData);
				
				LOG.info("Adding Login Event to Sys Log Table");
				//if (!"roleChange".equals(check)) {
					//addToSystemLog(loginUserSSO, eventName);
				//}
				if (permissionData != null && !permissionData.isEmpty()
						&& permissionData.size() > 0) {
					int key = 0;
					for (PLMLoginData obj : permissionData) {
						String screenId = obj.getScreenId();
						if (!screenData.contains(screenId)) {
							screenData.add(screenId);
							screenPos.add(String.valueOf(key));
						}
						key++;
					}
					for (int j = 0; j < screenData.size(); j++) {
						String screenId = screenData.get(j);
						List<String> permData = new ArrayList<String>();
						int temp = 0;
						if (j == screenData.size() - 1) {
							temp = permissionData.size();
						} else {
							temp = Integer.parseInt(screenPos.get(j + 1));
						}
						for (int i = Integer.parseInt(screenPos.get(j)); i < temp; i++) {
							PLMLoginData obj = permissionData.get(i);
							String permId = obj.getPermissionId();
							String screenId1 = obj.getScreenId();
							if (screenId.equals(screenId1)) {
								permData.add(permId);
							}
						}
						permDetails.put(screenId, permData);
					}
					permTempDetails = permDetails;
					setUserDetails(permDetails);
					LOG.info(" Permission Details "+permDetails.size());
					//returnStr = requestMB.getWSDetails();
					returnStr = "home";
				} else {
					LOG
							.info("*******************No Permission avialable*****************");
					perCheckVal = loginUserGrpName
							+ PLMConstants.ROLE_CHANGE_ALERT;
					LOG.info("Check Role>>>>>>>>>" + check);
					if (!"roleChange".equals(check)) {
						returnStr = "legal";
					} else {
						loginUserGroup = oldValue;
						setUserDetails(permTempDetails);
						returnStr = "home";
					}
				}
				LOG.info("permDetails in getPermissionDetails >>>>>>>>>>"
						+ permDetails);
			
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@getPermissionDetails: ", exception);
			returnStr = PLMUtils.setCommonException(exception.getMessage(),commonMB,"legal","Login Page");
		} finally {
			permissionData = null;
			screenData = null;
			screenPos = null;
			permDetails = null;
			eventName = null;
		}
		return returnStr;
	}
	
	/**
	 * @param permDetails
	 * @throws PLMCommonException
	 */
	private void setUserDetails(Map<String, List<String>> permDetails)
			throws PLMCommonException {
		
		String screenPlmrAdmin = PLMUtils
				.getMessage(PLMConstants.SCREEN_PLMR_ADMIN);
		String screenPlmrSearch = PLMUtils
				.getMessage(PLMConstants.SCREEN_PLMR_SEARCH);
		String screenPlmrDgt = PLMUtils
				.getMessage(PLMConstants.SCREEN_PLMR_DGT);
		String screenPlmrMetric = PLMUtils
				.getMessage(PLMConstants.SCREEN_PLMR_METRIC);
		String screenPlmrWhereUsed = PLMUtils
				.getMessage(PLMConstants.SCREEN_PLMR_WHERE_USED);
		String screenPlmrLttrReport = PLMUtils
		.getMessage(PLMConstants.SCREEN_PLMR_LTTR_REPORT);
		String screenPlmrCostReport = PLMUtils
		.getMessage(PLMConstants.SCREEN_PLMR_COST_REPORT);
		
		PLMLoginData userDataObj = null;
		try {
			userDataObj = new PLMLoginData();
			LOG.info("localUserlname>>>>>>>>>>>>>>>>>>>>>" + localUserlname);
			LOG.info("localUserfname>>>>>>>>>>>>>>>>>>>>>" + localUserfname);
			LOG.info("loginUserSSO>>>>>>>>>>>>>>>>>>>>>" + loginUserSSO);
			LOG.info("localUseremail>>>>>>>>>>>>>>>>>>>>>" + localUseremail);
			LOG.info("loginUserGroup>>>>>>>>>>>>>>>>>>>>>" + loginUserGroup);
			LOG.info("loginUserGrpName>>>>>>>>>>>>>>>>>>>>>" + loginUserGrpName);
			userDataObj.setFName(localUserfname);
			userDataObj.setLName(localUserlname);
			userDataObj.setUserSsoId(loginUserSSO);
			userDataObj.setUserEmail(localUseremail);
			userDataObj.setGroupId(loginUserGroup);
			userDataObj.setGroupName(loginUserGrpName);
			userDataObj.setGivenName_LD(givenName);
			userDataObj.setSecurityMatrix(permDetails);
			if (permDetails.containsKey(screenPlmrAdmin)) {
				plmrAdminStatus = true;
			}
			if (permDetails.containsKey(screenPlmrSearch)) {
				plmrSearchStatus = true;
			}
			if (permDetails.containsKey(screenPlmrDgt)) {
				plmrDgtStatus = true;
			}
			if (permDetails.containsKey(screenPlmrDgt)){
				
				List<String> permValLst = permDetails.get(screenPlmrDgt);
				if (!PLMUtils.isEmptyList(permValLst)) {
					for (int i=0;i<permValLst.size();i++){
						String permVal = permValLst.get(i);
						if (permVal.equalsIgnoreCase("WRITE")) {
							plmrDgtAdminStatus = true;
						}
					}
				}
			}
			if (permDetails.containsKey(screenPlmrMetric)) {
				plmrMetricStatus = true;
			}
			if (permDetails.containsKey(screenPlmrWhereUsed)) {
				plmrWhereUsedStatus = true;
			}
			if (permDetails.containsKey(screenPlmrLttrReport)) {
				plmrLttrStatus = true;
			}
			if (permDetails.containsKey(screenPlmrCostReport)) {
				plmrCostRptStatus = true;
			}
			if (permDetails.containsKey(screenPlmrSearch)) {
				plmrContractSumryReprtStatus = true;
			}
			PLMUtils.getServletSession(true).setAttribute("USER_DATA",
					userDataObj);
			//icmsearch.setLoginUserEmail(userDataObj.getUserEmail());
			//compareMB.setLoginUserEmail(userDataObj.getUserEmail());
		} finally {
			screenPlmrAdmin = null;
			screenPlmrSearch = null;
			screenPlmrDgt = null;
			screenPlmrMetric = null;
			screenPlmrMetric = null;
			userDataObj = null;
		}
	}

	
	

	public String loadHomePage() throws PLMCommonException{
		try{
			plmWhereUsedMB.setAlertMessage("");
			listOfReports = adminServiceIfc.getListOfReports();
			if (listOfReports != null) {
				totalRecCount = listOfReports.size();
			}
			commonMB.getETLDateStamp();
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@loadHomePage: " + exception.getMessage());
				throw exception;
			}
		return "cannedHome";
	}
	
	/**
	 * @return the listOfReports
	 */
	public List<PLMAdminData> getListOfReports() {
		return listOfReports;
	}

	/**
	 * @param listOfReports the listOfReports to set
	 */
	public void setListOfReports(List<PLMAdminData> listOfReports) {
		this.listOfReports = listOfReports;
	}

	/**
	 * @return the adminServiceIfc
	 */
	public PLMAdminServiceIfc getAdminServiceIfc() {
		return adminServiceIfc;
	}

	/**
	 * @param adminServiceIfc the adminServiceIfc to set
	 */
	public void setAdminServiceIfc(PLMAdminServiceIfc adminServiceIfc) {
		this.adminServiceIfc = adminServiceIfc;
	}

	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/*public String loadErrorPageBack() {
		return errorPageBack;
	}*/

	/**
	 * This method is used for Destroy the Session
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */

	public String removeSession() {
		HttpSession sessionInfo = PLMUtils.getServletSession(true);
		LOG.info("the session info inmb is-->"+sessionInfo);
		PLMUtils.clearSession(sessionInfo);
		return "logout";
	}

	/**
	 * @return Login page
	 */

	public String legalAccept() {
		return "login";
	}

	/**
	 * @return Legal Page
	 */

	public String homePage() {
		return "homeFromLegal";
	}

	/**
	 * This methods is used for getDate 
	 *
	 * @return String
	 */
	public String getDate() {
		Format formatter;
		Date date = new Date();
		formatter = new SimpleDateFormat("E, dd MMM yyyy");
		return formatter.format(date);
	}
	/*
	 * Getting Previous Date
	 * 
	 */
	/**
	 * This methods is used for getPreviousdate 
	 *
	 * @return String
	 */
	public String getPreviousdate(){
		  int MILLIS_IN_DAY = 1000 * 60 * 60 * 24;
		  Date date = new Date();
		  SimpleDateFormat dateFormat = new SimpleDateFormat("MMM-dd-yyyy");
		  String prevdate = dateFormat.format(date.getTime() - MILLIS_IN_DAY);
		  return prevdate;
	}

	/**
	 * This methods is used for getTrimValue 
	 * @param value
	 *            .
	 * @return String
	 */
	public String getTrimValue(String value) {
		String retStr = null;
		if (!PLMUtils.isEmpty(value)) {
			retStr = value.trim();
		}
		return retStr;
	}

	
	/**
	 * This method is used for Inserting the Login Event to System Logs
	 * 
	 * @param userSSO
	 * @throws ICMCommonException
	 */
	public void addToSystemLog() throws PLMCommonException, PWiException {

		FacesContext context = FacesContext.getCurrentInstance();
		String eventName = PLMUtils.getMessage(PLMConstants.LOGIN_EVENT_SUBMIT);
		userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
		boolean hasPgPLMUserRole = false;
		//LOG.info("Entering addSystemLogEvent  of PLMLoginMB ");
		if (userDetails != null) {
			//LOG.info("In addSystemLogEvent userDetails CONDITION >>>>>>>>>>" + userDetails.isSysLogEvnt());
		hasPgPLMUserRole =  userDetails.isPwiPGPLMRl() || userDetails.isPwiPGPLMAdminRl() || userDetails.isPwiDGTFMIRl()
			            || userDetails.isPwiDGTAdminRl() || userDetails.isPwiPartCostRl();
			
			if (hasPgPLMUserRole) {
				LOG.info("In addSystemLogEvent of PLMLoginMB SYSTEM LOG FLAG >>>>>>>>>>" + userDetails.isSysLogEvnt());
				if(!userDetails.isSysLogEvnt()) {
					LOG.info("In addSystemLogEvent of PLMLoginMB Capturing SYSTEM LOG >>>>>>>>>>" + userDetails.getUserSSO());
					commonSvcObj.addSystemLogEvent(userDetails.getUserSSO(), eventName);
					userDetails.setSysLogEvnt(true);
					context.getExternalContext().getSessionMap().remove(PWiConstants.USER_DATA);
					context.getExternalContext().getSessionMap().put(PWiConstants.USER_DATA, userDetails);
				} else {
					LOG.info("In addSystemLogEvent of PLMLoginMB SYSTEM LOG ALREADY CAPTURED >>>>>>>>>>");
					
				}
			}
		}
		//LOG.info("Exiting addSystemLogEvent  of PLMLoginMB ");

	}
	

	/**
	 * This method is used for getBothValues
	 * 
	 * @param event
	 * 
	 */
	public void getBothValues(ValueChangeEvent event) {
		oldValue = (String) event.getOldValue();
		newValue = (String) event.getNewValue();
		LOG.info("oldValue " + oldValue + " NewValue " + newValue);
	}
	
	/**
	 * @return the loginDetails
	 */
	public PLMLoginData getLoginDetails() {
		return loginDetails;
	}

	/**
	 * @param loginDetails
	 *            the loginDetails to set
	 */
	public void setLoginDetails(PLMLoginData loginDetails) {
		this.loginDetails = loginDetails;
	}

	/**
	 * @return the ssoId
	 */
	public String getSsoId() {
		return ssoId;
	}

	/**
	 * @param ssoId
	 *            the ssoId to set
	 */
	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the loginMsg
	 */
	public String getLoginMsg() {
		return loginMsg;
	}

	/**
	 * @param loginMsg
	 *            the loginMsg to set
	 */
	public void setLoginMsg(String loginMsg) {
		this.loginMsg = loginMsg;
	}

	/**
	 * @return the loginUserSSO
	 */
	public String getLoginUserSSO() {
		return loginUserSSO;
	}

	/**
	 * @param loginUserSSO
	 *            the loginUserSSO to set
	 */
	public void setLoginUserSSO(String loginUserSSO) {
		this.loginUserSSO = loginUserSSO;
	}

	/**
	 * @return the loginUserGroup
	 */
	public String getLoginUserGroup() {
		return loginUserGroup;
	}

	/**
	 * @param loginUserGroup
	 *            the loginUserGroup to set
	 */
	public void setLoginUserGroup(String loginUserGroup) {
		this.loginUserGroup = loginUserGroup;
	}

	/**
	 * @return the commonSvcObj
	 */
	public PLMCommonServiceIfc getCommonSvcObj() {
		return commonSvcObj;
	}
	
	/**
	 * @param commonSvcObj
	 *            the commonSvcObj to set
	 */
	public void setCommonSvcObj(PLMCommonServiceIfc commonSvcObj) {
		this.commonSvcObj = commonSvcObj;
	}


	/**
	 * @return the documentSearchAccess
	 */
	public boolean isDocumentSearchAccess() {
		return documentSearchAccess;
	}
	/**
	 * @param documentSearchAccess
	 *            the documentSearchAccess to set
	 */
	public void setDocumentSearchAccess(boolean documentSearchAccess) {
		this.documentSearchAccess = documentSearchAccess;
	}
	/**
	 * @return the drawingWorkFlow
	 */
	public boolean isDrawingWorkFlow() {
		return drawingWorkFlow;
	}
	/**
	 * @param drawingWorkFlow
	 *            the drawingWorkFlow to set
	 */
	public void setDrawingWorkFlow(boolean drawingWorkFlow) {
		this.drawingWorkFlow = drawingWorkFlow;
	}

	/**
	 * @return the ecosearch
	 */
	public boolean isEcosearch() {
		return ecosearch;
	}

	/**
	 * @param ecosearch
	 *            the ecosearch to set
	 */
	public void setEcosearch(boolean ecosearch) {
		this.ecosearch = ecosearch;
	}

	/**
	 * @return the ecrsearch
	 */
	public boolean isEcrsearch() {
		return ecrsearch;
	}

	/**
	 * @param ecrsearch
	 *            the ecrsearch to set
	 */
	public void setEcrsearch(boolean ecrsearch) {
		this.ecrsearch = ecrsearch;
	}

	/**
	 * @return the issuessearch
	 */
	public boolean isIssuessearch() {
		return issuessearch;
	}

	/**
	 * @param issuessearch
	 *            the issuessearch to set
	 */
	public void setIssuessearch(boolean issuessearch) {
		this.issuessearch = issuessearch;
	}
	/**
	 * @return the familyName
	 */
	public String getFamilyName() {
		return familyName;
	}
	/**
	 * @param familyName
	 *            the familyName to set
	 */
	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}
	/**
	 * @return the givenName
	 */
	public String getGivenName() {
		return givenName;
	}
	/**
	 * @param givenName
	 *            the givenName to set
	 */
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	/**
	 * @return the localUserSSO
	 */
	public String getLocalUserSSO() {
		return localUserSSO;
	}

	/**
	 * @param localUserSSO
	 *            the localUserSSO to set
	 */
	public void setLocalUserSSO(String localUserSSO) {
		this.localUserSSO = localUserSSO;
	}

	/**
	 * @return the lOG
	 */
	public static Logger getLOG() {
		return LOG;
	}


	/**
	 * @return the localUserlname
	 */
	public String getLocalUserlname() {
		return localUserlname;
	}


	/**
	 * @param localUserlname the localUserlname to set
	 */
	public void setLocalUserlname(String localUserlname) {
		this.localUserlname = localUserlname;
	}


	/**
	 * @return the localUserfname
	 */
	public String getLocalUserfname() {
		return localUserfname;
	}


	/**
	 * @param localUserfname the localUserfname to set
	 */
	public void setLocalUserfname(String localUserfname) {
		this.localUserfname = localUserfname;
	}


	/**
	 * @return the localUseremail
	 */
	public String getLocalUseremail() {
		return localUseremail;
	}


	/**
	 * @param localUseremail the localUseremail to set
	 */
	public void setLocalUseremail(String localUseremail) {
		this.localUseremail = localUseremail;
	}

	/**
	 * @return List
	 */
	public List<SelectItem> getUserGroups() {
		return userGroups;
	}

	/**
	 * @param userGroups1
	 */
	public void setUserGroups(List<SelectItem> userGroups1) {
		this.userGroups = userGroups1;
	}

	/**
	 * @return the grpSize
	 */
	public boolean isGrpSize() {
		return grpSize;
	}

	/**
	 * @param grpSize the grpSize to set
	 */
	public void setGrpSize(boolean grpSize) {
		this.grpSize = grpSize;
	}

	/**
	 * @return the grNme
	 */
	public String getGrNme() {
		return grNme;
	}

	/**
	 * @param grNme the grNme to set
	 */
	public void setGrNme(String grNme) {
		this.grNme = grNme;
	}

	/**
	 * @return the loginUserGrpName
	 */
	public String getLoginUserGrpName() {
		return loginUserGrpName;
	}

	/**
	 * @param loginUserGrpName the loginUserGrpName to set
	 */
	public void setLoginUserGrpName(String loginUserGrpName) {
		this.loginUserGrpName = loginUserGrpName;
	}

	/**
	 * @return the requestMB
	 */
	public PLMRequestMB getRequestMB() {
		return requestMB;
	}

	/**
	 * @param requestMB the requestMB to set
	 */
	public void setRequestMB(PLMRequestMB requestMB) {
		this.requestMB = requestMB;
	}

	/**
	 * @return the plmrAdminStatus
	 */
	public boolean isPlmrAdminStatus() {
		return plmrAdminStatus;
	}

	/**
	 * @param plmrAdminStatus the plmrAdminStatus to set
	 */
	public void setPlmrAdminStatus(boolean plmrAdminStatus) {
		this.plmrAdminStatus = plmrAdminStatus;
	}

	/**
	 * @return the plmrSearchStatus
	 */
	public boolean isPlmrSearchStatus() {
		return plmrSearchStatus;
	}

	/**
	 * @param plmrSearchStatus the plmrSearchStatus to set
	 */
	public void setPlmrSearchStatus(boolean plmrSearchStatus) {
		this.plmrSearchStatus = plmrSearchStatus;
	}

	/**
	 * @return the plmrDgtStatus
	 */
	public boolean isPlmrDgtStatus() {
		return plmrDgtStatus;
	}

	/**
	 * @param plmrDgtStatus the plmrDgtStatus to set
	 */
	public void setPlmrDgtStatus(boolean plmrDgtStatus) {
		this.plmrDgtStatus = plmrDgtStatus;
	}

	/**
	 * @return the plmrMetricStatus
	 */
	public boolean isPlmrMetricStatus() {
		return plmrMetricStatus;
	}

	/**
	 * @param plmrMetricStatus the plmrMetricStatus to set
	 */
	public void setPlmrMetricStatus(boolean plmrMetricStatus) {
		this.plmrMetricStatus = plmrMetricStatus;
	}

	/**
	 * @return the plmrWhereUsedStatus
	 */
	public boolean isPlmrWhereUsedStatus() {
		return plmrWhereUsedStatus;
	}

	/**
	 * @param plmrWhereUsedStatus the plmrWhereUsedStatus to set
	 */
	public void setPlmrWhereUsedStatus(boolean plmrWhereUsedStatus) {
		this.plmrWhereUsedStatus = plmrWhereUsedStatus;
	}

	/**
	 * @return the perCheckVal
	 */
	public String getPerCheckVal() {
		return perCheckVal;
	}

	/**
	 * @param perCheckVal the perCheckVal to set
	 */
	public void setPerCheckVal(String perCheckVal) {
		this.perCheckVal = perCheckVal;
	}

	/**
	 * @return the plmrLttrStatus
	 */
	public boolean isPlmrLttrStatus() {
		return plmrLttrStatus;
	}

	/**
	 * @param plmrLttrStatus the plmrLttrStatus to set
	 */
	public void setPlmrLttrStatus(boolean plmrLttrStatus) {
		this.plmrLttrStatus = plmrLttrStatus;
	}

	/**
	 * @return the plmrCostRptStatus
	 */
	public boolean isPlmrCostRptStatus() {
		return plmrCostRptStatus;
	}

	/**
	 * @param plmrCostRptStatus the plmrCostRptStatus to set
	 */
	public void setPlmrCostRptStatus(boolean plmrCostRptStatus) {
		this.plmrCostRptStatus = plmrCostRptStatus;
	}

	/**
	 * @return the plmrContractSumryReprtStatus
	 */
	public boolean isPlmrContractSumryReprtStatus() {
		return plmrContractSumryReprtStatus;
	}

	/**
	 * @param plmrContractSumryReprtStatus the plmrContractSumryReprtStatus to set
	 */
	public void setPlmrContractSumryReprtStatus(boolean plmrContractSumryReprtStatus) {
		this.plmrContractSumryReprtStatus = plmrContractSumryReprtStatus;
	}
	/**
	 * @return the plmrDgtAdminStatus
	 */
	public boolean isPlmrDgtAdminStatus() {
		return plmrDgtAdminStatus;
	}
	/**
	 * @param plmrDgtAdminStatus the plmrDgtAdminStatus to set
	 */
	public void setPlmrDgtAdminStatus(boolean plmrDgtAdminStatus) {
		this.plmrDgtAdminStatus = plmrDgtAdminStatus;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the wuFlag
	 */
	public String getWuFlag() {
		return wuFlag;
	}

	/**
	 * @param wuFlag the wuFlag to set
	 */
	public void setWuFlag(String wuFlag) {
		this.wuFlag = wuFlag;
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}

	/**
	 * @return the plmWhereUsedMB
	 */
	public PLMWhereUsedMB getPlmWhereUsedMB() {
		return plmWhereUsedMB;
	}

	/**
	 * @param plmWhereUsedMB the plmWhereUsedMB to set
	 */
	public void setPlmWhereUsedMB(PLMWhereUsedMB plmWhereUsedMB) {
		this.plmWhereUsedMB = plmWhereUsedMB;
	}

	/**
	 * @return the wuPrtIdLst
	 */
	public List getWuPrtIdLst() {
		return wuPrtIdLst;
	}

	/**
	 * @param wuPrtIdLst the wuPrtIdLst to set
	 */
	public void setWuPrtIdLst(List wuPrtIdLst) {
		this.wuPrtIdLst = wuPrtIdLst;
	}
	
	

}
