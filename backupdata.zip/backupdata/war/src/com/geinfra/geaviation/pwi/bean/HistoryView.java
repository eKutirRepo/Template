package com.geinfra.geaviation.pwi.bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.xml.bind.JAXBException;

import org.richfaces.component.html.HtmlDataTable;

import com.geinfra.geaviation.pwi.bean.util.BeanUtil;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.MinimalQueryExctnEventVO;
import com.geinfra.geaviation.pwi.service.HistoryService;
import com.geinfra.geaviation.pwi.service.vo.ExecutionMode;
import com.geinfra.geaviation.pwi.service.vo.OutputType;
import com.geinfra.geaviation.pwi.util.BookmarkableLinkUtil;
import com.geinfra.geaviation.pwi.xml.search.util.SearchJaxbUtil;

/**
 * 
 * Project : Product Lifecycle Management Date Written : May 21, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Backing bean for the HistoryView page.
 * 
 * Revision Log May 21, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class HistoryView extends BaseBean {
	// Injected properties
	private HistoryService historyService;
	private HistorySessionBean historySessionBean;

	// Flag to indicate when to load history from service
	private boolean load;

	private HtmlDataTable historyTable;

	/**
	 * 
	 * Project : Product Lifecycle Management Date Written : Apr 12, 2011
	 * Security : GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR
	 * GE USE ONLY
	 * 
	 * Copyright(C) 2011 GE All rights reserved
	 * 
	 * Description : Bean that holds the data for a single query history event.
	 * 
	 * Revision Log Apr 12, 2011 | v1.0.
	 * --------------------------------------------------------------
	 */
	public static class HistoryItemBean {
	/*	private static final SimpleDateFormat DATE_FORMAT =
				new SimpleDateFormat("MM/dd/yyyy', \n' hh:mm a");*/

		private Boolean rerunnable;
		private String queryName;
		private Integer eventId;
		private String executed;
		private String searchParameters;
		private Boolean searchParametersToggleNeeded;
		private String searchParametersLess;
		private String executionMode;
		private String outputType;
		private String executeLink;
		private String modifyLink;
		private Integer numResults;
		private MinimalQueryExctnEventVO vo;

		public HistoryItemBean(MinimalQueryExctnEventVO vo)
				throws PWiException {
			// Simply store value object and do lazy-initializaton to improve
			// performance since only some of the items might actually be
			// accessed due to table pagination.
			// Note: The most important thing to load lazily is the search
			// parameters since it involves JAXB stuff which is relatively
			// expensive.
			this.vo = vo;
		}

		private void loadFields() throws PWiException {
			rerunnable = Boolean.valueOf(vo.isRerunnable());
			queryName = vo.getQueryName();
			eventId = vo.getEventId();
			SimpleDateFormat DATE_FORMAT =
								new SimpleDateFormat("MM/dd/yyyy', \n' hh:mm a");
			
			executed = DATE_FORMAT.format(vo.getDateExecuted());

			if(vo.getExecutionMode().contains("::"))
			{
			executionMode = ExecutionMode.getById(vo.getExecutionMode().substring(0, vo.getExecutionMode().indexOf("::")))
					.getLabel();
			}
			else
			{
				executionMode = ExecutionMode.getById(vo.getExecutionMode())
						.getLabel();
			}
			outputType = OutputType.getById(vo.getOutputType()).getLabel();

			searchParameters = SearchJaxbUtil.getSearchParametersForDisplay(vo
					.getSearchCriteriaXml());
			searchParametersToggleNeeded = Boolean.valueOf(SearchJaxbUtil
					.isSearchParametersLong(searchParameters));
			searchParametersLess = SearchJaxbUtil
					.abbreviatedSearchParameters(searchParameters);

			// Initialize execute link
			executeLink = BookmarkableLinkUtil.getInstance()
					.getExecuteHistoryLink(eventId);

			// Initialize modify link
			modifyLink = BookmarkableLinkUtil.getInstance()
					.getModifyHistoryLink(eventId);

			numResults = Integer.valueOf(vo.getRowCount());
		}

		public String getExecuteLink() throws PWiException {
			if (executeLink == null) {
				loadFields();
			}
			return executeLink;
		}

		public String getModifyLink() throws PWiException {
			if (modifyLink == null) {
				loadFields();
			}
			return modifyLink;
		}

		public boolean isRerunnable() throws PWiException {
			if (rerunnable == null) {
				loadFields();
			}
			return rerunnable.booleanValue();
		}

		public String getQueryName() throws PWiException {
			if (queryName == null) {
				loadFields();
			}
			return queryName;
		}

		public Integer getEventId() throws PWiException {
			if (eventId == null) {
				loadFields();
			}
			return eventId;
		}

		public String getExecuted() throws PWiException {
			if (executed == null) {
				loadFields();
			}
			return executed;
		}

		public String getSearchParameters() throws PWiException {
			if (searchParameters == null) {
				loadFields();
			}
			return searchParameters;
		}

		public boolean isSearchParametersToggleNeeded() throws PWiException {
			if (searchParametersToggleNeeded == null) {
				loadFields();
			}
			return searchParametersToggleNeeded.booleanValue();
		}

		public String getSearchParametersLess() throws PWiException {
			if (searchParametersLess == null) {
				loadFields();
			}
			return searchParametersLess;
		}

		public String getExecutionMode() throws PWiException {
			if (executionMode == null) {
				loadFields();
			}
			return executionMode;
		}

		public String getOutputType() throws PWiException {
			if (outputType == null) {
				loadFields();
			}
			return outputType;
		}

		public int getNumResults() throws PWiException {
			if (numResults == null) {
				loadFields();
			}
			return numResults.intValue();
		}
	}

	/**
	 * Retrieves all queries run in the past year by the user.
	 * 
	 * @return queries run in past year by user
	 * @throws PWiException
	 * @throws JAXBException
	 */
	public List<HistoryItemBean> getHistoryItems() throws JAXBException,
			PWiException {
		if (load) {
			loadHistory();
			load = false;
		}
		return historySessionBean.getHistoryItems();
	}

	/**
	 * Ensure view bean is properly initialized based on the request (and then
	 * cached).
	 */
	@PostConstruct
	public void postConstruct() {
		String dontReload = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap()
				.get("dontReload");

		// Always reload history unless request includes flag to not (such
		// as in the case of datascrolling requests for instance)
		if (dontReload == null) {
			load = true;
		}
	}

	public String actionCreateFavoriteFromHistory() throws PWiException {
		// Get selected history item
		HistoryItemBean historyItem = (HistoryItemBean) historyTable
				.getRowData();

		// Set history ID into dialog for creating a favorite from history
		FavoriteFromHistoryDialogBean bean = BeanUtil.getInstance()
				.getFavoriteFromHistoryDialogBean();
		bean.setHistoryId(historyItem.getEventId());
		bean.setFavoriteName(historyItem.getQueryName());

		return null;
	}

	private void loadHistory() throws JAXBException, PWiException {
		// Get queries run in past year
		List<MinimalQueryExctnEventVO> queriesRunInPastYear = historyService
				.getExecutionEventsSince(getDateRunSince());
		
		// Create history items from query events
		List<HistoryItemBean> historyItems = new ArrayList<HistoryItemBean>();
		for (MinimalQueryExctnEventVO vo : queriesRunInPastYear) {
			historyItems.add(new HistoryItemBean(vo));
		}

		// Create data model of history items
		historySessionBean.setHistoryItems(historyItems);
	}

	public void setHistoryService(HistoryService historyService) {
		this.historyService = historyService;
	}

	public void setHistorySessionBean(HistorySessionBean historySessionBean) {
		this.historySessionBean = historySessionBean;
	}

	public Date getDateRunSince() {
	
		
		return historySessionBean.getDateRunSince();
	}

	public void setDateRunSince(Date dateRunSince) {
		historySessionBean.setDateRunSince(dateRunSince);
	}

	public void setHistoryTable(HtmlDataTable historyTable) {
		this.historyTable = historyTable;
	}

	public HtmlDataTable getHistoryTable() {
		return historyTable;
	}
}
