/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMCadTrendsData.java
 * @Creation date: 15-June-2011
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

import java.util.ArrayList;
import java.util.List;



public class PLMCadTrendsData {
	/**
	  * Holds the rdoList
	  */
	private List rdoList =new ArrayList();
	/**
	  * Holds the ownerName
	 */
	private String ownerName;
	/**
	  * Holds the lifeCycleState
	  */
	private String lifeCycleState;
	/**
	  * Holds the fromDate
	  */
	private String fromDate;
	/**
	  * Holds the toDate
	  */
	private String toDate;
	/**
	  * Holds the cadObjectType
	  */
	
	private String	cadObjectType;
	/**
	  * Holds the cadObjectName
	  */
	private String	cadObjectName;
	/**
	  * Holds the revision
	  */
	private String	revision;
	/**
	  * Holds the description
	  */
	private String description;
	/**
	  * Holds the lifecycleState
	  */
	private String	lifecycleState;
	/**
	  * Holds the owner
	  */
	private String	owner;
	/**
	  * Holds the lockedBy
	  */
	private String	lockedBy;
	/**
	  * Holds the mli
	  */
	private String	mli;
	/**
	  * Holds the modelValidated
	  */
	private String modelValidated;
	/**
	  * Holds the relatedECO
	  */
	private String	relatedECO;
	/**
	  * Holds the relatedTask
	  */
	private String  relatedTask;
	/**
	  * Holds the relatedPart
	  */
	private String	relatedPart;
	/**
	  * Holds the dateoflast
	  */
	private String	dateoflast;
	/**
	 * @return Returns the rdoList
	 */
	public List getRdoList() {
		return rdoList;
	}
	/**
	 * @param rdoList The rdoList to set.
	 */
	public void setRdoList(List rdoList) {
		this.rdoList = rdoList;
	}
		
	/**
	 * @return Returns the ownerName
	 */
	public String getOwnerName() {
		return ownerName;
	}
	/**
	 * @param ownerName The ownerName to set.
	 */
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	/**
	 * @return Returns the lifeCycleState
	 */
	public String getLifeCycleState() {
		return lifeCycleState;
	}
	/**
	 * @param lifeCycleState The lifeCycleState to set.
	 */
	public void setLifeCycleState(String lifeCycleState) {
		this.lifeCycleState = lifeCycleState;
	}
	/**
	 * @return Returns the fromDate
	 */
	public String getFromDate() {
		return fromDate;
	}
	/**
	 * @param fromDate The fromDate to set.
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	/**
	 * @return Returns the toDate
	 */
	public String getToDate() {
		return toDate;
	}
	/**
	 * @param toDate The toDate to set.
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	/**
	 * @return Returns the cadObjectType
	 */
	public String getCadObjectType() {
		return cadObjectType;
	}
	/**
	 * @param cadObjectType The cadObjectType to set.
	 */
	public void setCadObjectType(String cadObjectType) {
		this.cadObjectType = cadObjectType;
	}
	/**
	 * @return Returns the cadObjectName
	 */
	public String getCadObjectName() {
		return cadObjectName;
	}
	/**
	 * @param cadObjectName The cadObjectName to set.
	 */
	public void setCadObjectName(String cadObjectName) {
		this.cadObjectName = cadObjectName;
	}
	/**
	 * @return Returns the revision
	 */
	public String getRevision() {
		return revision;
	}
	/**
	 * @param revision The revision to set.
	 */
	public void setRevision(String revision) {
		this.revision = revision;
	}
	/**
	 * @return Returns the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description The description to set.
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return Returns the lifecycleState
	 */
	public String getLifecycleState() {
		return lifecycleState;
	}
	/**
	 * @param lifecycleState The lifecycleState to set.
	 */
	public void setLifecycleState(String lifecycleState) {
		this.lifecycleState = lifecycleState;
	}
	/**
	 * @return Returns the owner
	 */
	public String getOwner() {
		return owner;
	}
	/**
	 * @param owner The owner to set.
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}
	/**
	 * @return Returns the lockedBy
	 */
	public String getLockedBy() {
		return lockedBy;
	}
	/**
	 * @param lockedBy The lockedBy to set.
	 */
	public void setLockedBy(String lockedBy) {
		this.lockedBy = lockedBy;
	}
	/**
	 * @return Returns the mli
	 */
	public String getMli() {
		return mli;
	}
	/**
	 * @param mli The mli to set.
	 */
	public void setMli(String mli) {
		this.mli = mli;
	}
	/**
	 * @return Returns the modelValidated
	 */
	public String getModelValidated() {
		return modelValidated;
	}
	/**
	 * @param modelValidated The modelValidated to set.
	 */
	public void setModelValidated(String modelValidated) {
		this.modelValidated = modelValidated;
	}
	/**
	 * @return Returns the relatedECO
	 */
	public String getRelatedECO() {
		return relatedECO;
	}
	/**
	 * @param relatedECO The relatedECO to set.
	 */
	public void setRelatedECO(String relatedECO) {
		this.relatedECO = relatedECO;
	}
	/**
	 * @return Returns the relatedTask
	 */
	public String getRelatedTask() {
		return relatedTask;
	}
	/**
	 * @param relatedTask The relatedTask to set.
	 */
	public void setRelatedTask(String relatedTask) {
		this.relatedTask = relatedTask;
	}
	/**
	 * @return Returns the relatedPart
	 */
	public String getRelatedPart() {
		return relatedPart;
	}
	/**
	 * @param relatedPart The relatedPart to set.
	 */
	public void setRelatedPart(String relatedPart) {
		this.relatedPart = relatedPart;
	}
	/**
	 * @return Returns the dateoflast
	 */
	public String getDateoflast() {
		return dateoflast;
	}
	/**
	 * @param dateoflast The dateoflast to set.
	 */
	public void setDateoflast(String dateoflast) {
		this.dateoflast = dateoflast;
	}
	

}
