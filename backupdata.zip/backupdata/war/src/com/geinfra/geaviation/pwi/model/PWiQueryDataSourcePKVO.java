/*
 //  @ Project : PWi
 //  @ File Name : PWiUserCustomQueryVO.java
 //  @ Date : 5/14/2010
 //  @ Author : nisverma
 */

package com.geinfra.geaviation.pwi.model;

import java.io.Serializable;

/**
 * 
 * Project : Product Lifecycle Management Date Written : Aug 6, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : PWiQueryDataSourcePKVO - Data Source Primary Key object.
 * 
 * Revision Log Aug 6, 2010 | v1.0.
 * --------------------------------------------------------------
 */
public class PWiQueryDataSourcePKVO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3256703262862583285L;
	private int dataSrcSysSeqId;
	private int qrySeqId;

	public PWiQueryDataSourcePKVO() {
	}

	public PWiQueryDataSourcePKVO(int dataSrcSysSeqId, int qrySeqId) {
		this.dataSrcSysSeqId = dataSrcSysSeqId;
		this.qrySeqId = qrySeqId;
	}

	public int getDataSrcSysSeqId() {
		return dataSrcSysSeqId;
	}

	public void setDataSrcSysSeqId(int dataSrcSysSeqId) {
		this.dataSrcSysSeqId = dataSrcSysSeqId;
	}

	public int getQrySeqId() {
		return qrySeqId;
	}

	public void setQrySeqId(int qrySeqId) {
		this.qrySeqId = qrySeqId;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (int) dataSrcSysSeqId;
		hash += (int) qrySeqId;
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object instanceof PWiQueryDataSourcePKVO) {
			PWiQueryDataSourcePKVO other = (PWiQueryDataSourcePKVO) object;
			return this.dataSrcSysSeqId == other.dataSrcSysSeqId
					&& this.qrySeqId == other.qrySeqId;
		}
		return false;
	}

	@Override
	public String toString() {
		return "com.geinfra.geaviation.pwi.model.PWiQueryDataSourcePK[dataSrcSysSeqId="
				+ dataSrcSysSeqId + ", qrySeqId=" + qrySeqId + "]";
	}

}
