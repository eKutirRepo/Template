 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMRequestMB.java
 * @Creation date: 17-Jul-2009
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team) 
 */
package com.geinfra.geaviation.pwi.bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlInputHidden;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.faces.validator.ValidatorException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.geinfra.geaviation.pwi.bean.util.BeanUtil;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.data.PLMLoginData;
import com.geinfra.geaviation.pwi.data.PLMReportData;
import com.geinfra.geaviation.pwi.data.PLMRequestData;
import com.geinfra.geaviation.pwi.service.PLMAdminServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;


/**
 * ICMRequestMB is the managed bean class used for Welcome & Maintain Screen and
 * Request Account.
 */
public class PLMRequestMB {
	/**
	 * Holds the Logger.
	 */
	private static final Logger LOG = Logger.getLogger(PLMRequestMB.class);

	/**
	 * Holds the all the folderMetaData attributes.
	 */
	private PLMRequestData pwiRequestData = new PLMRequestData();
	/**
	 * The String announcements.
	 */
	private String announcements;
	/**
	 * The String localUserfname.
	 */
	private String localUserfname;
	/**
	 * The String localUserlname.
	 */
	private String localUserlname;
	/**
	 * The String selectedModName.
	 */
	private String selectedModName;
	/**
	 * The boolean buttonFlag.
	 */
	private boolean buttonFlag;
	/**
	 * The boolean requestedFlag.
	 */
	private boolean requestedFlag;
	/**
	 * The boolean requestingFlag.
	 */
	private boolean requestingFlag;
	/**
	 * The List groupNameList
	 */
	private List roleNameList;
	/**
	 * The List requestedGroupList
	 */
	private List requestedGroupList;
	/**
	 * The List requestingGroupList
	 */
	private List requestingGroupList;
	/**
	 * The List groupIdList
	 */
	private List groupIdList = new ArrayList();
	/**
	 * The String alertMsgReq.
	 */
	private String alertMsgReq;
	/**
	 * The String displayMsg.
	 */
	private String displayMsg;
	/**
	 * The String lastUpdatedBy.
	 */
	private String lastUpdatedBy;
	/**
	 * The String lastUpdatedDate.
	 */
	private String lastUpdatedDate;
	/**
	 * The String modDesc.
	 */
	private String modDesc;
	/**
	 * The String modLink.
	 */
	private String modLink;
	/**
	 * The String modPresentation.
	 */
	private String modPresentation;
	/**
	 * The String modTraining.
	 */
	private String modTraining;
	/**
	 * The String versionNo.
	 */
	private String versionNo;
	/**
	 * The String releaseDate.
	 */
	private String releaseDate;
	/**
	 * The String relDescription.
	 */
	private String relDescription;
	/**
	 * The String relDetails.
	 */
	private String relDetails;
	/**
	 * The String maitnAnnouncements.
	 */
	private String maitnAnnouncements = "";
	/**
	 * The String selectedMaintainName.
	 */
	private String selectedMaintainName;
	/**
	 * The String maitnModDesc.
	 */
	private String maitnModDesc;
	/**
	 * The String maitnModLink.
	 */
	private String maitnModLink;
	/**
	 * The String oldMaitnModDesc.
	 */
	private String oldMaitnModDesc;
	/**
	 * The String oldMaitnModDesc.
	 */
	private String oldMaitnAnc;
	/**
	 * The String oldMaitnModDesc.
	 */
	private String oldMaitnVersn;
	/**
	 * The String oldMaitnModDesc.
	 */
	private String oldMaitnRelDate;
	/**
	 * The String oldMaitnModDesc.
	 */
	private String oldMaitnLatDesc;
	/**
	 * The String oldMaitnModDesc.
	 */
	private String oldMaitnLatDeatls;
	/**
	 * The String oldMaitnModLink.
	 */
	private String oldMaitnModLink;
	/**
	 * The String maitnModPresentation.
	 */
	private String maitnModPresentation;
	/**
	 * The String maitnModTraining.
	 */
	private String maitnModTraining;
	/**
	 * The String oldMaitnModPresentation.
	 */
	private String oldMaitnModPresentation;
	/**
	 * The String oldMaitnModTraining.
	 */
	private String oldMaitnModTraining;
	/**
	 * The String maitnVersionNo.
	 */
	private String maitnVersionNo = "";
	/**
	 * The String maitnReleaseDate.
	 */
	private String maitnReleaseDate;
	/**
	 * The String tempMaitnReleaseDate.
	 */
	private Date tempMaitnReleaseDate;
	/**
	 * The String maitnRelDate.
	 */
	private Date maitnRelDate;
	/**
	 * The String tempRelDate.
	 */
	private Date tempRelDate;
	/**
	 * The String maitnRelDescription.
	 */
	private String maitnRelDescription = "";
	/**
	 * The String maitnRelDetails.
	 */
	private String maitnRelDetails = "";
	/**
	 * The ArrayList maitnModuleValList.
	 */
	private List maitnModuleValList;
	/**
	 * The String maitnScreenId.
	 */
	private String maitnScreenId;
	/**
	 * The String maitnScreenParentId.
	 */
	private String maitnScreenParentId;
	/**
	 * The String maitnFieldName.
	 */
	private String maitnFieldName;
	/**
	 * The String maitnFieldType.
	 */
	private String maitnFieldType;

	// End: Maintain WS
	/**
	 * The ArrayList groupList.
	 */
	private List groupList = new ArrayList();
	/**
	 * The String ssoId.
	 */
	private String ssoId;
	/**
	 * The String emailId.
	 */
	private String emailId;
	/**
	 * The String groupId.
	 */
	private String groupId;
	/**
	 * The String nationalityUsr.
	 */
	private String nationalityUsr;
	/**
	 * The String contactDetails.
	 */
	private String contactDetails = "";
	/**
	 * The String comments.
	 */
	private String comments = "";
	/**
	 * The HtmlInputHidden navInputPage.
	 */
	private HtmlInputHidden navInputPage = new HtmlInputHidden();
	/**
	 * The String navPage.
	 */
	private String navPage;
	/**
	 * The ArrayList moduleValList.
	 */
	private List moduleValList;
	/**
	 * The String screenId.
	 */
	private String screenId;
	/**
	 * The String screenParentId.
	 */
	private String screenParentId;
	/**
	 * The String fieldName.
	 */
	private String fieldName;
	/**
	 * The String fieldVal.
	 */
	private String fieldVal;
	/**
	 * The String typeCd.
	 */
	private String typeCd;
	/**
	 * The String fieldType.
	 */
	private String fieldType;
	/**
	 * The String createdBy.
	 */
	private String createdBy;
	/**
	 * The String createDate.
	 */
	private String createDate;
	/**
	 * The String updatedBy.
	 */
	private String updatedBy;
	/**
	 * The String updateDate.
	 */
	private String updateDate;
	/**
	 * The String activeIndSent.
	 */
	private String activeIndSent;
	/**
	 * The ArrayList homePageList.
	 */
	private List homePageList;
	/**
	 * The boolean writePerm
	 */
	private boolean writePerm;
	/**
	 * The List systemLogsList
	 */
	private List<PLMReportData> systemLogsList;
	/**
	 * The String beginDate
	 */
	private String beginDate;
	/**
	 * The String endDate
	 */
	private String endDate;
	/**
	 * The String message
	 */
	private String message;
	/**
	 * The String startDate
	 */
	private Date startDate;
	/**
	 * The String endingDate
	 */
	private Date endingDate;
	/**
	 * The String excelFlag
	 */
	private String excelFlag;
	/**
	 * The boolean renderingMsg
	 */
	private boolean renderingMsg;
	/**
	 * The String recordsMsg
	 */
	private String recordsMsg;
	/**
	 * The String validationMsg
	 */
	private String validationMsg;
	/**
	 * The String queryingFlag
	 */
	private String queryingFlag;
	/**
	 * The String strReturn
	 */
	private String strReturn;

	private String roleType;
	
	private List roleListSel;
	
	private List<SelectItem> roleList;
	
	private String pwiUsers;
	
	//private List roleTypeList;
	
	/**
	 * Service Handler for ICMAdminServiceIfc
	 */
	public PLMAdminServiceIfc adminServiceIfc;

	/**
	 * initialize method.
	 */
	public void init() {
		pwiRequestData = new PLMRequestData();
		LOG.info("initialized PLMRequestData");
	}
	
	/**
	 * This method is used to Validate Date Inputs
	 * @param cont
	 * @param ucom
	 * @param ob
	 * @throws PLMCommonException
	 */
	public void validateDate(FacesContext cont, UIComponent ucom, Object ob) throws ValidatorException {
        try {
        	Date dateVal = (Date) ob;
        	LOG.info("validated date.."+dateVal);
        } catch (Exception ex) {
        	LOG.log(Level.ERROR, "validateDate method error", ex);
            throw new ValidatorException(new FacesMessage("Invalid date"));
        }
    }


	/**
	 * This method is used for requestNewUser
	 * 
	 * @param userDetails
	 * @return String
	 * @throws PLMCommonException
	 */
	public String requestNewUser(PLMLoginData userDetails) throws PLMCommonException {
		String retStr = null;
		PLMRequestData requestData = null;
		try {
			LOG.info("\n\n\n The Start of---getWSAppDetails------->");
			activeIndSent = userDetails.getState();
			ssoId = userDetails.getUserSsoId();
			emailId = userDetails.getUserEmail();
			localUserfname = userDetails.getFName();
			localUserlname = userDetails.getLName();
			// localUserfname = "Kishore";
			// localUserlname = "Bandari";
			LOG.info("\n\n\n localUserfname------->" + localUserfname);
			LOG.info("\n\n\n localUserlname------->" + localUserlname);
			// if (PLMUtils.getServletRequest().getHeader("sm_ssoid") != null) {
			// ssoId = (String) PLMUtils.getServletRequest().getHeader(
			// "sm_ssoid");
			// ssoId = userDetails.getUserSsoId();
			// LOG.info("localUseremail from header >>>>>>>>>>" + ssoId);
			// }
			// if (PLMUtils.getServletRequest().getHeader("sm_email") != null) {
			// emailId = (String) PLMUtils.getServletRequest()
			// .getHeader("sm_email");
			// LOG.info("emailId from header >>>>>>>>>>"
			// + emailId);
			// }
			requestData = getAdminServiceIfc().requestNewUser();
			groupList = requestData.getGroupList();
			retStr = "requestacc";
			LOG.info("\n\n\n The End of---getWSAppDetails------->"+groupList);
		} catch (PLMCommonException exception) {
			LOG.log(Level.ERROR, "Exception@requestNewUser: ", exception);
			throw exception;
		}
		return retStr;
	}

	
	/**
	 * This method is used for getWSDetails
	 * 
	 * @return String
	 * @throws PLMCommonException
	 */
	public String getWSDetails() throws PLMCommonException {
		PLMRequestData requestData = null;
		PLMRequestData requestData1 = null;
		moduleValList = new ArrayList();
		LOG.info("\n\n\n The Start of---getWSDetails------->");
		List tempModuleValList = null;
		PLMRequestData reqTempData = null;
		PLMRequestData reqTempData1 = null;
		List changedLst = null;
		String chgFieldName = null;
		String screenName = null;
		String selectVal = null;
		Map<String, Boolean> screenDropDowm = new HashMap<String, Boolean>();
		requestData1 = getAdminServiceIfc().getAppDetails();
		homePageList = requestData1.getHomePageList();
		LOG.info("\n\n\n  homePageList------->" + homePageList);

		tempModuleValList = requestData1.getModuleValList();

		PLMLoginMB loginMB = (PLMLoginMB) PLMUtils.getServletSession(true)
				.getAttribute("loginmb");

		screenDropDowm.put(getTrimValue(PLMUtils
				.getMessage(PLMConstants.MODULE_NAME_ADMIN)), loginMB
				.isEcosearch());
		screenDropDowm.put(getTrimValue(PLMUtils
				.getMessage(PLMConstants.MODULE_NAME_SEARCH)), loginMB
				.isEcosearch());
		screenDropDowm.put(getTrimValue(PLMUtils
				.getMessage(PLMConstants.MODULE_NAME_COMPARE)), loginMB
				.isEcosearch());
		screenDropDowm.put(getTrimValue(PLMUtils
				.getMessage(PLMConstants.MODULE_NAME_ADDUPDATE)), loginMB
				.isEcosearch());

		for (int i = 0; i < tempModuleValList.size(); i++) {
			SelectItem selectItem = (SelectItem) tempModuleValList.get(i);
			screenName = selectItem.getLabel();
			String itemVal = (String) selectItem.getValue();
			if (screenDropDowm.get(screenName)) {
				moduleValList.add(new SelectItem(itemVal, screenName));
			}
		}

		if (!PLMUtils.isEmptyList(moduleValList)) {
			SelectItem selectItem = (SelectItem) moduleValList.get(0);
			selectedModName = selectItem.getLabel();
			selectVal = (String) selectItem.getValue();
		}
		reqTempData = getAdminServiceIfc().getChangedDetails(selectVal);
		changedLst = reqTempData.getChangedList();
		Iterator itr1 = changedLst.iterator();
		while (itr1.hasNext()) {
			reqTempData1 = (PLMRequestData) itr1.next();
			chgFieldName = reqTempData1.getFieldName();
			if (PLMUtils.chkNull(chgFieldName).equalsIgnoreCase(
					PLMConstants.DESCRIPTION)) {
				modDesc = reqTempData1.getFieldVal();
			} else if (PLMUtils.chkNull(chgFieldName).equalsIgnoreCase(
					PLMConstants.APP_LINK)) {
				modLink = reqTempData1.getFieldVal();
			}
		}

		Iterator itr = homePageList.iterator();
		while (itr.hasNext()) {
			requestData = (PLMRequestData) itr.next();
			screenId = requestData.getScreenId();
			screenParentId = requestData.getScreenParentId();
			fieldName = requestData.getFieldName();
			fieldType = requestData.getFieldType();
			if (PLMUtils.chkNull(fieldName).equalsIgnoreCase(
					PLMConstants.ANNOUNCEMENTS)
					&& PLMUtils.chkNull(fieldType).equalsIgnoreCase(
							PLMConstants.ANC)) {
				announcements = requestData.getFieldVal();
				announcements = getTrimValue(announcements);
			} else if (PLMUtils.chkNull(fieldName).equalsIgnoreCase(
					PLMConstants.VERSION_NO)
					&& PLMUtils.chkNull(fieldType).equalsIgnoreCase(
							PLMConstants.LAT)) {
				versionNo = requestData.getFieldVal();
			} else if (PLMUtils.chkNull(fieldName).equalsIgnoreCase(
					PLMConstants.RELEASE_DATE)
					&& PLMUtils.chkNull(fieldType).equalsIgnoreCase(
							PLMConstants.LAT)) {
				tempMaitnReleaseDate = PLMUtils.getFormattedDate(requestData
						.getFieldVal());
				releaseDate = PLMUtils.getFormatRelDate(tempMaitnReleaseDate);
			} else if (PLMUtils.chkNull(fieldName).equalsIgnoreCase(
					PLMConstants.LAT_DESC)
					&& PLMUtils.chkNull(fieldType).equalsIgnoreCase(
							PLMConstants.LAT)) {
				relDescription = requestData.getFieldVal();
			} else if (PLMUtils.chkNull(fieldName).equalsIgnoreCase(
					PLMConstants.LAT_DETAILS)
					&& PLMUtils.chkNull(fieldType).equalsIgnoreCase(
							PLMConstants.LAT)) {
				relDetails = requestData.getFieldVal();
			} else if (PLMUtils.chkNull(fieldName).equalsIgnoreCase(
					PLMConstants.PRESENTATION)
					&& PLMUtils.chkNull(fieldType).equalsIgnoreCase(
							PLMConstants.ICM)) {
				modPresentation = requestData.getFieldVal();
			} else if (PLMUtils.chkNull(fieldName).equalsIgnoreCase(
					PLMConstants.TRAINING)
					&& PLMUtils.chkNull(fieldType).equalsIgnoreCase(
							PLMConstants.ICM)) {
				modTraining = requestData.getFieldVal();
			}
		}
		return "home";
	}

	/**
	 * This method is used for getMaintainWSDetails
	 * 
	 * @return java.lang.String
	 * @throws PLMCommonException.
	 */
	public String getMaintainWSDetails() throws PLMCommonException {
		PLMRequestData requestData = null;
		PLMRequestData requestData1 = null;
		LOG.info("\n\n\n The Start of---getMaintainWSDetails------->");
		FacesContext fContext = FacesContext.getCurrentInstance();
		String admScreen = fContext.getExternalContext()
				.getRequestParameterMap().get("screenName");
		resetUserAlertMsg();
		if (PLMUtils.getServletSession(true).getAttribute("USER_DATA") != null) {
			PLMLoginData userDataObj = (PLMLoginData) PLMUtils.getServletSession(
					true).getAttribute("USER_DATA");
			Map<String, List<String>> permDetails = userDataObj
					.getSecurityMatrix();
			List<String> permNames = permDetails.get(admScreen);
			if (permNames.contains(PLMUtils
					.getMessage(PLMConstants.PEMISSION_WRITE))) {
				writePerm = true;
			}
			ssoId = userDataObj.getUserSsoId();
			LOG.info("\n\n\n ssoId From Session is -------->" + ssoId);
		}
		requestData1 = getAdminServiceIfc().getAppDetails();
		homePageList = requestData1.getHomePageList();
		maitnModuleValList = requestData1.getModuleValList();
		if (!PLMUtils.isEmptyList(maitnModuleValList)) {
			SelectItem selectItem = (SelectItem) maitnModuleValList.get(0);
			selectedMaintainName = selectItem.getLabel();
		}
		Iterator itr = homePageList.iterator();
		while (itr.hasNext()) {
			requestData = (PLMRequestData) itr.next();
			maitnScreenId = requestData.getScreenId();
			maitnScreenParentId = requestData.getScreenParentId();
			maitnFieldName = requestData.getFieldName();
			maitnFieldType = requestData.getFieldType();
			if (PLMUtils.chkNull(maitnFieldName).equalsIgnoreCase(
					PLMConstants.ANNOUNCEMENTS)
					&& PLMUtils.chkNull(maitnFieldType).equalsIgnoreCase(
							PLMConstants.ANC)) {
				maitnAnnouncements = requestData.getFieldVal();
				maitnAnnouncements = getTrimValue(maitnAnnouncements);
				oldMaitnAnc = maitnAnnouncements;
			} else if (PLMUtils.chkNull(maitnFieldName).equalsIgnoreCase(
					PLMConstants.VERSION_NO)
					&& PLMUtils.chkNull(maitnFieldType).equalsIgnoreCase(
							PLMConstants.LAT)) {
				maitnVersionNo = requestData.getFieldVal();
				maitnVersionNo = getTrimValue(maitnVersionNo);
				oldMaitnVersn = maitnVersionNo;
			} else if (PLMUtils.chkNull(maitnFieldName).equalsIgnoreCase(
					PLMConstants.RELEASE_DATE)
					&& PLMUtils.chkNull(maitnFieldType).equalsIgnoreCase(
							PLMConstants.LAT)) {
				maitnReleaseDate = requestData.getFieldVal();
				maitnRelDate = PLMUtils.getFormattedDate(maitnReleaseDate);
				tempRelDate = maitnRelDate;
			} else if (PLMUtils.chkNull(maitnFieldName).equalsIgnoreCase(
					PLMConstants.LAT_DESC)
					&& PLMUtils.chkNull(maitnFieldType).equalsIgnoreCase(
							PLMConstants.LAT)) {
				maitnRelDescription = requestData.getFieldVal();
				maitnRelDescription = getTrimValue(maitnRelDescription);
				oldMaitnLatDesc = maitnRelDescription;
			} else if (PLMUtils.chkNull(maitnFieldName).equalsIgnoreCase(
					PLMConstants.LAT_DETAILS)
					&& PLMUtils.chkNull(maitnFieldType).equalsIgnoreCase(
							PLMConstants.LAT)) {
				maitnRelDetails = requestData.getFieldVal();
				maitnRelDetails = getTrimValue(maitnRelDetails);
				oldMaitnLatDeatls = maitnRelDetails;
			} else if (PLMUtils.chkNull(maitnFieldName).equalsIgnoreCase(
					PLMConstants.PRESENTATION)
					&& PLMUtils.chkNull(maitnFieldType).equalsIgnoreCase(
							PLMConstants.ICM)) {
				maitnModPresentation = requestData.getFieldVal();
				maitnModPresentation = getTrimValue(maitnModPresentation);
				oldMaitnModPresentation = requestData.getFieldVal();
				oldMaitnModPresentation = getTrimValue(oldMaitnModPresentation);
			} else if (PLMUtils.chkNull(maitnFieldName).equalsIgnoreCase(
					PLMConstants.TRAINING)
					&& PLMUtils.chkNull(maitnFieldType).equalsIgnoreCase(
							PLMConstants.ICM)) {
				maitnModTraining = requestData.getFieldVal();
				maitnModTraining = getTrimValue(maitnModTraining);
				oldMaitnModTraining = requestData.getFieldVal();
				oldMaitnModTraining = getTrimValue(oldMaitnModTraining);
			} else if (PLMUtils.chkNull(maitnFieldName).equalsIgnoreCase(
					PLMConstants.DESCRIPTION)
					&& PLMUtils.chkNull(maitnFieldType).equalsIgnoreCase(
							PLMConstants.ICM)) {
				maitnModDesc = requestData.getFieldVal();
				maitnModDesc = getTrimValue(maitnModDesc);
				oldMaitnModDesc = requestData.getFieldVal();
				oldMaitnModDesc = getTrimValue(oldMaitnModDesc);
			} else if (PLMUtils.chkNull(maitnFieldName).equalsIgnoreCase(
					PLMConstants.APP_LINK)
					&& PLMUtils.chkNull(maitnFieldType).equalsIgnoreCase(
							PLMConstants.ICM)) {
				maitnModLink = requestData.getFieldVal();
				maitnModLink = getTrimValue(maitnModLink);
				oldMaitnModLink = requestData.getFieldVal();
				oldMaitnModLink = getTrimValue(oldMaitnModLink);
			}
		}
		return "maintainws";
	}

	/**
	 * getDate method to convert the date format.
	 */
	public void getDate() {
		try {
			Date dtDate = null;
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
			SimpleDateFormat sdfAct = new SimpleDateFormat("dd/MM/yyyy");
			dtDate = sdf.parse(maitnReleaseDate);
			maitnReleaseDate = sdfAct.format(dtDate);
		} catch (Exception ex) {
			LOG.log(Level.ERROR, "getWSAppDetails method error", ex);
		}
	}

	/**
	 * This method is used for getModDetails
	 * 
	 * @param event
	 * @return String
	 */
	public String getModDetails(ValueChangeEvent event) {
		String retStr = null;
		String chgFieldName = null;
		PLMRequestData requestTempData = null;
		PLMRequestData requestTempData1 = null;
		List changedList = null;
		try {
			selectedModName = (String) event.getNewValue();
			LOG.info("\n\n\n The Selected Module Name------------->"
					+ selectedModName);
			requestTempData = getAdminServiceIfc().getChangedDetails(
					selectedModName);
			changedList = requestTempData.getChangedList();
			Iterator itr = changedList.iterator();
			while (itr.hasNext()) {
				requestTempData1 = (PLMRequestData) itr.next();
				chgFieldName = requestTempData1.getFieldName();
				if (PLMUtils.chkNull(chgFieldName).equalsIgnoreCase(
						PLMConstants.DESCRIPTION)) {
					modDesc = requestTempData1.getFieldVal();
				} else if (PLMUtils.chkNull(chgFieldName).equalsIgnoreCase(
						PLMConstants.APP_LINK)) {
					modLink = requestTempData1.getFieldVal();
				}
			}
			retStr = "";
		} catch (Exception ex) {
			LOG.log(Level.ERROR, "getModDetails method error", ex);
			retStr = "error";
		}
		return retStr;
	}

	/**
	 * @param event
	 * @return java.lang.String
	 */
	public void getMainModDetails(ValueChangeEvent event) {
		try {
			selectedMaintainName = (String) event.getNewValue();
			LOG.info("\n\n\n The Selected Maintain Module Name------------->"
					+ selectedMaintainName);
		} catch (Exception ex) {
			LOG.log(Level.ERROR, "getMainModDetails method error", ex);
		}
	}

	/**
	 * This method is used for getDetails
	 * 
	 * @return String
	 */
	public String getDetails() {
		String retStr = null;
		String chgFieldName = null;
		PLMRequestData requestTempData = null;
		PLMRequestData requestTempData1 = null;
		List changedList = null;
		try {
			requestTempData = getAdminServiceIfc().getChangedDetails(
					selectedMaintainName);
			changedList = requestTempData.getChangedList();
			Iterator itr = changedList.iterator();
			while (itr.hasNext()) {
				requestTempData1 = (PLMRequestData) itr.next();
				chgFieldName = requestTempData1.getFieldName();
				if (PLMUtils.chkNull(chgFieldName).equalsIgnoreCase(
						PLMConstants.DESCRIPTION)) {
					maitnModDesc = requestTempData1.getFieldVal();
					oldMaitnModDesc = requestTempData1.getFieldVal();
				} else if (PLMUtils.chkNull(chgFieldName).equalsIgnoreCase(
						PLMConstants.APP_LINK)) {
					maitnModLink = requestTempData1.getFieldVal();
					oldMaitnModLink = requestTempData1.getFieldVal();
				}
			}
			retStr = "";
		} catch (Exception ex) {
			LOG.log(Level.ERROR, "getModDetails method error", ex);
			retStr = "error";
		}
		return retStr;
	}

	/**
	 * This method is used for saveAnnmntsDetails
	 * 
	 * @return java.lang.String
	 * @throws PLMCommonException.
	 */
	public String saveAnnmntsDetails() {
		String retStr = null;
		boolean valFlag;
		try {
			valFlag = checkMandAncFields();
			LOG.info("\n\n\n valFlag-------->" + valFlag);
			if (valFlag) {
				getAdminServiceIfc().saveAncmtDetails(maitnAnnouncements);
			} else {
				LOG.info("\n\n\n valFlag-----else---->" + valFlag);
			}
			retStr = "";
		} catch (Exception ex) {
			LOG.log(Level.ERROR, "saveAnnmntsDetails method error", ex);
			retStr = "error";
		}
		return retStr;
	}

	/**
	 * This method is used for saveAppDetails
	 * 
	 * @return java.lang.String
	 * @throws PLMCommonException.
	 */
	public String saveAppDetails() {
		String retStr = null;
		String latType = null;
		boolean valFlag;
		try {
			valFlag = checkMandFields();
			if (valFlag) {
				latType = PLMConstants.LAT;
				pwiRequestData.setLatFieldType(latType);
				pwiRequestData.setMaitnVersionNo(maitnVersionNo);
				maitnReleaseDate = PLMUtils.getFormatDate(maitnRelDate);
				pwiRequestData.setMaitnReleaseDate(maitnReleaseDate);
				pwiRequestData.setMaitnRelDescription(maitnRelDescription);
				pwiRequestData.setMaitnRelDetails(maitnRelDetails);
				getAdminServiceIfc().saveAppDetails(pwiRequestData);
				retStr = "";
			} else {
				LOG.info("\n\n\n saveAppDetails ---else condtion---->");
			}
		} catch (Exception ex) {
			LOG.log(Level.ERROR, "saveAppDetails method error", ex);
			retStr = "error";
		}
		return retStr;
	}

	/**
	 * This method is used for saveIcmDetails
	 * 
	 * @return java.lang.String
	 * @throws PLMCommonException.
	 * @roseuid 4940D7B500F8
	 */
	public String saveIcmDetails() {
		String retStr = null;
		String icmType = null;
		boolean submitFlag;
		try {
			submitFlag = checkFieldsModified();
			LOG.info("\n\n\n submitFlag------saveIcmDetails------->"
					+ submitFlag);
			if ((PLMUtils.isHtmlIndependent(maitnModLink))) {
				if (submitFlag) {
					icmType = PLMConstants.ICM;
					pwiRequestData.setIcmFieldType(icmType);
					pwiRequestData
							.setSelectedMaintainName(selectedMaintainName);
					pwiRequestData.setMaitnModDesc(maitnModDesc);
					pwiRequestData.setMaitnModLink(maitnModLink);
					pwiRequestData
							.setMaitnModPresentation(maitnModPresentation);
					pwiRequestData.setMaitnModTraining(maitnModTraining);
					getAdminServiceIfc().saveIcmDetails(pwiRequestData);
				} else {
					LOG
							.info("\n\n\n Nothing is saved------saveIcmDetails-----else-->");
				}
			} else {
				alertMsgReq = "Please enter a valid link, special characters are not allowed.";
			}
		} catch (Exception ex) {
			LOG.log(Level.ERROR, "saveAppDetails method error", ex);
			retStr = "error";
		}
		return retStr;
	}

	/**
	 * Method to check for modified fields.
	 * 
	 * @return isValidated
	 * @throws PLMCommonException.
	 */

	public boolean checkMandFields() throws PLMCommonException {
		boolean isValidate = true;
		boolean validCharLengthFlag = true;
		if (PLMUtils.isEmpty(maitnVersionNo)) {
			alertMsgReq = PLMConstants.VAL_VERNO;
			isValidate = false;
		} else if (maitnRelDate == null) {
			alertMsgReq = PLMConstants.VAL_RELDATE;
			isValidate = false;
		} else if (PLMUtils.isEmpty(maitnRelDescription)) {
			alertMsgReq = PLMConstants.VAL_RELDESC;
			isValidate = false;
		} else if (PLMUtils.isEmpty(maitnRelDetails)) {
			alertMsgReq = PLMConstants.VAL_RELDETAILS;
			isValidate = false;
		} // else if (maitnRelDate != null) {
		// if (!tempRelDate.equals(maitnRelDate)) {
		// isValidate = checkForDate(maitnRelDate);
		// }
		// }
		if (isValidate) {
			validCharLengthFlag = checkLengthSplChars();
		}
		LOG.info("\n\n\n validCharLengthFlag--------->" + validCharLengthFlag);
		LOG.info("\n\n\n isValidate--------->" + isValidate);
		if (!isValidate || !validCharLengthFlag) {
			isValidate = false;
		} else {
			isValidate = true;
		}
		return isValidate;
	}

	/**
	 * Method to check for modified fields.
	 * 
	 * @return isValidated
	 * @throws PLMCommonException.
	 */
	public boolean checkMandAncFields() throws PLMCommonException {
		boolean isValidate = true;
		boolean validCharLengthFlag = true;
		if (PLMUtils.isEmpty(maitnAnnouncements)) {
			alertMsgReq = PLMConstants.VAL_ANC;
			isValidate = false;
		}
		validCharLengthFlag = checkLengthAncSplChars();
		if (!isValidate || !validCharLengthFlag) {
			isValidate = false;
		} else {
			isValidate = true;
		}
		return isValidate;
	}

	/**
	 * method to check for date
	 * 
	 * return String
	 * 
	 * @param stDate
	 * @param edDate
	 */
	public boolean checkForDate(Date stDate) {
		boolean alertMessage = false;
		Calendar cal = Calendar.getInstance();
		Date currentDate = cal.getTime();
		LOG.info("\n\n\n CurrentDate is ----checkForDate----" + currentDate);
		LOG.info("\n\n\n Release Date is -----checkForDate----" + stDate);
		/*LOG.info("\n\n\n compare to -----checkForDate----"
				+ currentDate.compareTo(stDate));*/
		if (stDate != null) {
			if (currentDate.compareTo(stDate) != PLMConstants.N_NEG_1) {
				alertMsgReq = PLMConstants.VAL_RELDATE_MSG;
				alertMessage = false;
			} else {
				alertMessage = true;
			}
		}
		LOG.info("\n\n\n compare to -----checkForDate----" + alertMsgReq);
		return alertMessage;
	}

	/**
	 * This is method is used for checkLengthSplChars
	 * 
	 * @return boolean
	 * @throws PLMCommonException.
	 */
	public boolean checkLengthSplChars() throws PLMCommonException {
		StringBuffer tempBuf = null;
		String errorMsg = PLMConstants.EMPTY;
		boolean isValidated = true;
		boolean isValidated1 = true;
		if (!PLMUtils.isEmpty(maitnVersionNo)) {
			if (PLMUtils.checkLength(maitnVersionNo.trim(),
					PLMConstants.LENGTH_CHECK_TEXT)) {
				tempBuf = new StringBuffer();
				tempBuf = tempBuf.append(PLMConstants.EXCEED_TEXT_VERSION);
				errorMsg = tempBuf.toString();
				alertMsgReq = PLMUtils.setErrorMsgFolder(alertMsgReq, errorMsg);
				isValidated = false;
			}
		}

		if (!PLMUtils.isEmpty(maitnRelDescription)) {
			if (PLMUtils.checkLength(maitnRelDescription.trim(),
					PLMConstants.LENGTH_CHECK_TEXT)) {
				tempBuf = new StringBuffer();
				tempBuf = tempBuf.append(PLMConstants.EXCEED_TEXT_REL_DESC);
				errorMsg = tempBuf.toString();
				alertMsgReq = PLMUtils.setErrorMsgFolder(alertMsgReq, errorMsg);
				isValidated = false;

			}
		}

		if (!PLMUtils.isEmpty(maitnRelDetails)) {
			if (PLMUtils.checkLength(maitnRelDetails.trim(),
					PLMConstants.LENGTH_CHECK_TEXTAREA)) {
				tempBuf = new StringBuffer();
				tempBuf = tempBuf.append(PLMConstants.EXCEED_TEXT_REL_DETAILS);
				errorMsg = tempBuf.toString();
				alertMsgReq = PLMUtils.setErrorMsgFolder(alertMsgReq, errorMsg);
				isValidated = false;

			}
		}
		if (isValidated) {
			isValidated1 = chkValidate();
		}
		if (!isValidated || !isValidated1) {
			isValidated = false;
		} else {
			isValidated = true;
		}
		return isValidated;
	}

	/**
	 * This is method is used for chkValidate
	 * 
	 * @return boolean
	 * @throws PLMCommonException.
	 */
	public boolean chkValidate() throws PLMCommonException {
		boolean isValidated = false;
		int count = 0;
		if (!PLMUtils.isEmpty(maitnVersionNo)
				&& !PLMUtils.isEmpty(oldMaitnVersn)) {
			maitnVersionNo = getTrimValue(maitnVersionNo);
			oldMaitnVersn = getTrimValue(oldMaitnVersn);
			if (!PLMUtils.chkNull(oldMaitnVersn).equals(maitnVersionNo)) {
				LOG.info("\n\n\n Here---23232323232---else--Here");
				isValidated = true;
				oldMaitnVersn = maitnVersionNo;
			} else {
				LOG.info("\n\n\n Here---00000000000---else--Here");
			}
		}

		if (!PLMUtils.isEmpty(maitnRelDescription)
				&& !PLMUtils.isEmpty(oldMaitnLatDesc)) {
			oldMaitnLatDesc = getTrimValue(oldMaitnLatDesc);
			maitnRelDescription = getTrimValue(maitnRelDescription);
			if (!PLMUtils.chkNull(oldMaitnLatDesc).equals(maitnRelDescription)) {
				LOG.info("\n\n\n Here---56565656---else--Here");
				isValidated = true;
				oldMaitnLatDesc = maitnRelDescription;
			} else {
				LOG.info("\n\n\n Here---1111111111111111---else--Here");
			}
		}

		if (!PLMUtils.isEmpty(maitnRelDetails)
				&& !PLMUtils.isEmpty(oldMaitnLatDeatls)) {
			oldMaitnLatDeatls = getTrimValue(oldMaitnLatDeatls);
			maitnRelDetails = getTrimValue(maitnRelDetails);
			if (!PLMUtils.chkNull(oldMaitnLatDeatls).equals(maitnRelDetails)) {
				isValidated = true;
				oldMaitnLatDeatls = maitnRelDetails;
			} else {
				LOG.info("\n\n\n Here---2222222222222--else---Here");
			}
		}

		if (maitnRelDate != null && tempRelDate != null) {
			count = tempRelDate.compareTo(maitnRelDate);
			if (count != PLMConstants.N_0) {
				isValidated = true;
				tempRelDate = maitnRelDate;
			} else {
				LOG.info("\n\n\n Here---3333333333333333---else--Here");
			}
		}

		if (isValidated) {
			alertMsgReq = PLMConstants.SAVE_MSG;
			isValidated = true;
		} else {
			alertMsgReq = PLMConstants.A_MODIFY_FIELDS_MANDATORY_ANC;
			isValidated = false;
		}
		return isValidated;
	}

	/**
	 * This method is used for checkLengthAncSplChars
	 * 
	 * @return boolean
	 * @throws PLMCommonException.
	 */
	public boolean checkLengthAncSplChars() throws PLMCommonException {
		StringBuffer tempBuf = null;
		String errorMsg = PLMConstants.EMPTY;
		boolean isValidated = true;

		if (!PLMUtils.isEmpty(maitnAnnouncements)) {
			if (PLMUtils.checkLength(maitnAnnouncements.trim(),
					PLMConstants.LENGTH_CHECK_TEXTAREA)) {
				tempBuf = new StringBuffer();
				tempBuf = tempBuf.append(PLMConstants.EXCEED_TEXT_CHAR_ANC);
				errorMsg = tempBuf.toString();
				alertMsgReq = PLMUtils.setErrorMsgFolder(alertMsgReq, errorMsg);
				isValidated = false;

			}
		}

		if (isValidated) {
			if (!PLMUtils.isEmpty(maitnAnnouncements)
					&& !PLMUtils.isEmpty(oldMaitnAnc)) {
				oldMaitnAnc = getTrimValue(oldMaitnAnc);
				maitnAnnouncements = getTrimValue(maitnAnnouncements);
				if (!PLMUtils.chkNull(oldMaitnAnc).equals(maitnAnnouncements)) {
					alertMsgReq = PLMConstants.SAVE_MSG;
					isValidated = true;
					oldMaitnAnc = maitnAnnouncements;
				} else {
					alertMsgReq = PLMConstants.A_MODIFY_FIELDS_MANDATORY_ANC;
					isValidated = false;
				}
			}
		}
		return isValidated;
	}

	/**
	 * This method is used for saveNewUserRequest
	 * 
	 * @return java.lang.String
	 * @throws PLMCommonException.
	 */
	public String saveNewUserRequest() throws PWiException {
		String retStr = null;
		boolean submitFlg;
		String roleNames = null;
		Map roleMap = null;
		Map roleListMap = null;
		String tempRoleId = null;
		boolean isSearchAndReadOnly = false;
		String roleIdReq =null;
		boolean isPwiUser = BeanUtil.getInstance().getApplicationParametersBean().isPwiUser();
		try {
			
			roleListMap = new HashMap();
			roleNameList = new ArrayList();
			submitFlg = checkFields();
			LOG
					.info("\n\n\n saveNewUserRequest----submitFlg----->"
							+ submitFlg);
			if (submitFlg) {
				LOG
				.info("\n\n\n saveNewUserRequest----setSsoId----->"
						+ ssoId);
				pwiRequestData.setSsoId(ssoId);
				LOG
				.info("\n\n\n saveNewUserRequest----setComments----->"
						+ comments);
				pwiRequestData.setComments(comments);
				
				LOG
				.info("\n\n\n saveNewUserRequest----roleList----->"
						+ roleList);
				Iterator<SelectItem> itr = roleList.iterator();
				while (itr.hasNext()) {
					SelectItem val1 = itr.next();
					roleListMap.put(val1.getValue(), val1.getLabel());
				}

				if (!PLMUtils.isEmptyList(roleListSel)) {
					Iterator itr1 = roleListSel.iterator();
					while (itr1.hasNext()) {
						tempRoleId = (String) itr1.next();
						roleNames = (String) roleListMap.get(tempRoleId);
						roleNameList.add(roleNames);
						if (roleNames.contains(PLMUtils
								.getMessage(PLMConstants.AUTO_ACCESS_GROUP)) && !isPwiUser) {
							isSearchAndReadOnly = true;
							roleIdReq = tempRoleId;
						}
					}
				}
				pwiRequestData.setReadOnlyAccsGrp(isSearchAndReadOnly);
				pwiRequestData.setEmailId(emailId);
				pwiRequestData.setGroupNameList(roleNameList);
				pwiRequestData.setGroupList(roleList);
				pwiRequestData.setGroupSeqId(roleListSel);
				pwiRequestData.setCreatedBy(ssoId);
				pwiRequestData.setLastUpdatedBy(ssoId);
				pwiRequestData.setActiveIndSent(activeIndSent);
				pwiRequestData.setLocalUserfname(getLocalUserfname());
				pwiRequestData.setLocalUserlname(getLocalUserlname());
				roleMap = getAdminServiceIfc().saveNewUserRequest(
						pwiRequestData,roleIdReq,isPwiUser);
				requestedGroupList = (List) roleMap.get("Requested");
				requestingGroupList = (List) roleMap.get("Requesting");
				LOG.info("\n\n\n requestedGroupList----submitFlg----->"
						+ requestedGroupList);
				LOG.info("\n\n\n requestingGroupList----submitFlg----->"
						+ requestingGroupList);
				if (PLMUtils.isEmptyList(requestingGroupList)) {
					requestingFlag = true;
				} else {
					requestingFlag = false;
				}
				if (PLMUtils.isEmptyList(requestedGroupList)) {
					requestedFlag = true;
				} else {
					requestedFlag = false;
				}
				retStr = "reqRaised";
			} else {
				LOG.info("\n\n\n saveNewUserRequest------else condition--->");
				retStr = "";
			}
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "saveNewUserRequest method error", ex);
			retStr = "requesterror";
		}
		return retStr;
	}

	/**
	 * Method to check for modified fields.
	 * 
	 * @return isValidated
	 * @throws PLMCommonException.
	 */
	public boolean checkFields() throws PLMCommonException {
		boolean isValidate = true;
		boolean validCharLengthFlag1 = true;

		if (PLMUtils.isEmptyList((roleListSel))) {
			alertMsgReq = PLMConstants.VAL_GROUP;
			isValidate = false;
		} else if (PLMUtils.isEmpty(comments)) {
			alertMsgReq = PLMConstants.VAL_COMMENTS;
			isValidate = false;
		} /*else if (PLMUtils.isEmpty(roleType)) {
			alertMsgReq = PLMConstants.VAL_ROLE_TYPE;
			isValidate = false;
		}*/

		validCharLengthFlag1 = checkReqLengthSplChars();
		if (!isValidate || !validCharLengthFlag1) {
			isValidate = false;
		} else {
			alertMsgReq = PLMConstants.EMPTY;
			isValidate = true;
		}
		return isValidate;
	}

	/**
	 * This method is used for checkReqLengthSplChars
	 * 
	 * @return boolean
	 * @throws PLMCommonException.
	 */
	public boolean checkReqLengthSplChars() throws PLMCommonException {
		StringBuffer tempBuf = null;
		String errorMsg = PLMConstants.EMPTY;
		boolean isValidated = true;
		if (!PLMUtils.isEmpty(comments)) {
			if (PLMUtils.checkLength(comments.trim(),
					PLMConstants.LENGTH_CHECK_REQ_TEXTAREA)) {
				tempBuf = new StringBuffer();
				tempBuf = tempBuf
						.append(PLMConstants.EXCEED_TEXT_COMMENT_DETAILS);
				errorMsg = tempBuf.toString();
				alertMsgReq = PLMUtils.setErrorMsgFolder(alertMsgReq, errorMsg);
				isValidated = false;
			}
		}

		return isValidated;
	}

	/**
	 * Method to check for modified fields.
	 * 
	 * @return isValidated
	 * @throws PLMCommonException.
	 */
	public boolean checkFieldsModified() throws PLMCommonException {
		boolean isValidated = true;
		StringBuffer tempBuf = null;
		String errorMsg = PLMConstants.EMPTY;
		boolean tempValDesc = false;
		boolean tempValLink = false;
		boolean tempValPresen = false;
		boolean tempValTraing = false;

		maitnModDesc = getTrimValue(maitnModDesc);
		oldMaitnModDesc = getTrimValue(oldMaitnModDesc);
		maitnModLink = getTrimValue(maitnModLink);
		oldMaitnModLink = getTrimValue(oldMaitnModLink);
		maitnModPresentation = getTrimValue(maitnModPresentation);
		oldMaitnModPresentation = getTrimValue(oldMaitnModPresentation);
		maitnModTraining = getTrimValue(maitnModTraining);
		oldMaitnModTraining = getTrimValue(oldMaitnModTraining);

		if (PLMUtils.isEmpty(maitnModDesc) || PLMUtils.isEmpty(oldMaitnModDesc)) {
			alertMsgReq = PLMConstants.VAL_DESCRIPTION;
			isValidated = false;
		} else if (PLMUtils.isEmpty(maitnModLink)
				|| PLMUtils.isEmpty(oldMaitnModLink)) {
			alertMsgReq = PLMConstants.VAL_LINK;
			isValidated = false;
		} else if (PLMUtils.isEmpty(maitnModPresentation)
				|| PLMUtils.isEmpty(oldMaitnModPresentation)) {
			alertMsgReq = PLMConstants.VAL_PRESENTATION;
			isValidated = false;
		} else if (PLMUtils.isEmpty(maitnModTraining)
				|| PLMUtils.isEmpty(oldMaitnModTraining)) {
			alertMsgReq = PLMConstants.VAL_USERGUIDE;
			isValidated = false;
		} else if (!PLMUtils.chkNull(oldMaitnModDesc).equals(maitnModDesc)) {
			if (PLMUtils.checkLength(maitnModDesc.trim(),
					PLMConstants.LENGTH_CHECK_TEXT)) {
				tempBuf = new StringBuffer();
				tempBuf = tempBuf.append(PLMConstants.EXCEED_TEXT_ICM_DESC);
				errorMsg = tempBuf.toString();
				alertMsgReq = PLMUtils.setErrorMsgFolder(alertMsgReq, errorMsg);
				isValidated = false;
			} else if (!PLMUtils.isEmpty(maitnModDesc)) {
				tempValDesc = true;
			}
		}
		if (!PLMUtils.isEmpty(oldMaitnModLink)
				&& !PLMUtils.isEmpty(maitnModLink)) {
			if (!PLMUtils.chkNull(oldMaitnModLink).equals(maitnModLink)) {
				if (PLMUtils.checkLength(maitnModLink.trim(),
						PLMConstants.LENGTH_CHECK_TEXT)) {
					tempBuf = new StringBuffer();
					tempBuf = tempBuf.append(PLMConstants.EXCEED_TEXT_ICM_LINK);
					errorMsg = tempBuf.toString();
					alertMsgReq = PLMUtils.setErrorMsgFolder(alertMsgReq, errorMsg);
					isValidated = false;
					tempValLink = false;
					tempValDesc = false;
					tempValPresen = false;
					tempValTraing = false;
				} else if (!PLMUtils.isEmpty(maitnModLink)) {
					tempValLink = true;
				}
			}
		}

		if (!PLMUtils.isEmpty(oldMaitnModPresentation)
				&& !PLMUtils.isEmpty(maitnModPresentation)) {
			if (!PLMUtils.chkNull(oldMaitnModPresentation).equals(
					maitnModPresentation)) {
				if (PLMUtils.checkLength(maitnModPresentation.trim(),
						PLMConstants.LENGTH_CHECK_TEXT)) {
					tempBuf = new StringBuffer();
					tempBuf = tempBuf
							.append(PLMConstants.EXCEED_TEXT_ICM_PRESENTATION);
					errorMsg = tempBuf.toString();
					alertMsgReq = PLMUtils.setErrorMsgFolder(alertMsgReq, errorMsg);
					isValidated = false;
					tempValLink = false;
					tempValDesc = false;
					tempValPresen = false;
					tempValTraing = false;
				} else if (!PLMUtils.isEmpty(maitnModPresentation)) {
					tempValPresen = true;
				}
			}
		}

		if (!PLMUtils.isEmpty(oldMaitnModTraining)
				&& !PLMUtils.isEmpty(maitnModTraining)) {
			if (!PLMUtils.chkNull(oldMaitnModTraining).equals(maitnModTraining)) {
				if (PLMUtils.checkLength(maitnModTraining.trim(),
						PLMConstants.LENGTH_CHECK_TEXT)) {
					tempBuf = new StringBuffer();
					tempBuf = tempBuf
							.append(PLMConstants.EXCEED_TEXT_ICM_USERGUIDE);
					errorMsg = tempBuf.toString();
					alertMsgReq = PLMUtils.setErrorMsgFolder(alertMsgReq, errorMsg);
					isValidated = false;
					tempValLink = false;
					tempValDesc = false;
					tempValPresen = false;
					tempValTraing = false;
				} else if (!PLMUtils.isEmpty(maitnModTraining)) {
					tempValTraing = true;
				}
			}
		}
		LOG.info("\n\n\n tempValDesc------->" + tempValDesc);
		LOG.info("\n\n\n tempValLink------->" + tempValLink);
		if ((tempValDesc || tempValLink || tempValTraing || tempValPresen)
				&& isValidated) {
			alertMsgReq = PLMConstants.SAVE_MSG;
			isValidated = true;
		} else if (PLMUtils.chkNull(oldMaitnModDesc).equalsIgnoreCase(
				maitnModDesc)
				&& PLMUtils.chkNull(oldMaitnModLink).equalsIgnoreCase(
						maitnModLink)
				&& PLMUtils.chkNull(oldMaitnModPresentation).equalsIgnoreCase(
						maitnModPresentation)
				&& PLMUtils.chkNull(oldMaitnModTraining).equalsIgnoreCase(
						maitnModTraining)) {
			alertMsgReq = PLMConstants.A_MODIFY_FIELDS_MANDATORY_ANC;
			isValidated = false;
			oldMaitnModDesc = maitnModDesc;
			oldMaitnModLink = maitnModLink;
			oldMaitnModPresentation = maitnModPresentation;
			oldMaitnModTraining = maitnModTraining;
		} else {
			isValidated = false;
		}
		return isValidated;
	}

	/**
	 * This method is used for getTrimValue
	 * @param value
	 *            .
	 * @return String
	 */
	public String getTrimValue(String value) {
		String retStr = null;
		if (!PLMUtils.isEmpty(value)) {
			retStr = value.trim();
		}
		return retStr;
	}
	
	/**
	 * This method is used for getSysLogContents
	 * 
	 * @return String
	 */
	public String getSysLogContents() {
		try {
			if (queryingFlag != null
					&& queryingFlag.equals(PLMConstants.QUERYING_FLAG)) {
				LOG.info("Entered into validation loop");
				validationMsg = checkForDates(startDate, endingDate);
				renderingMsg = false;
				recordsMsg = "";
			} else {
				validationMsg = null;
			}
			if (validationMsg != null && validationMsg.equals("")) {
				if (startDate != null && endingDate != null) {
					beginDate = startDate.toString();
					endDate = endingDate.toString();

					Locale loc = Locale.US;
					SimpleDateFormat requiredFrmt = new SimpleDateFormat(
							(PLMConstants.DATE_FORMAT), loc);
					beginDate = requiredFrmt.format(startDate);
					endDate = requiredFrmt.format(endingDate);
					LOG
							.info("Dates in String format >>>" + beginDate
									+ endDate);
				}

				systemLogsList = adminServiceIfc.getSysLogContents(beginDate,
						endDate);
				if (systemLogsList != null && !systemLogsList.isEmpty()) {
					recordsMsg = "";
					renderingMsg = true;
					validationMsg = null;
				} else {
					renderingMsg = false;
					recordsMsg = PLMConstants.NO_REC_MSG_SYS_LOG;
					setRecordsMsg(recordsMsg);
				}
			}
			if (excelFlag != null
					&& excelFlag.equalsIgnoreCase(PLMConstants.EXCEL_FLAG)) {
				strReturn = "SysLogsExportExcel";
			} else {
				strReturn = "SystemLogs";
			}

		} catch (PLMCommonException ice) {
			LOG.log(Level.ERROR, "getSysLogContents method error", ice);
			strReturn = "error";
		} catch (Exception ce) {
			LOG.log(Level.ERROR, "getSysLogContents method error", ce);
			strReturn = "error";
		}
		return strReturn;
	}

	/**
	 * This method is used for getQueryFlag
	 * 
	 * @param event
	 */
	public void getQueryFlag(ActionEvent event) {
		queryingFlag = (String) event.getComponent().getAttributes().get(
				PLMConstants.QUERY_FLAG);
		excelFlag = null;
	}

	/**
	 * 	This method is used for messageNull
	 * 
	 * @param event
	 */
	public void messageNull(ActionEvent event) {
		queryingFlag = null;
		startDate = null;
		endingDate = null;
		beginDate = null;
		endDate = null;
		excelFlag = null;
		renderingMsg = false;
		systemLogsList = null;
		recordsMsg = null;
	}

	/**
	 * This method is used for checkForDates
	 * 
	 * return String
	 * 
	 * @param stDate
	 * @param edDate
	 */
	private String checkForDates(Date stDate, Date edDate) {
		StringBuffer strBuffer = new StringBuffer("");
		Calendar cal = Calendar.getInstance();
		Date currentDate = cal.getTime();
		LOG.info("currentDate is >>>>" + currentDate);
		LOG.info("stDate is >>>>" + stDate);
		LOG.info("edDate is >>>>" + edDate);
		if (stDate == null && edDate == null) {
			strBuffer.append((PLMConstants.STREND_DATE) + "<br/>");
		} else {
			if (stDate == null) {
				strBuffer.append((PLMConstants.STR_DATE) + "<br/>");
			}
			if (edDate == null) {
				strBuffer.append((PLMConstants.END_DATE) + "<br/>");
			}
			if (stDate != null && edDate != null) {
				if (currentDate.compareTo(stDate) == PLMConstants.N_NEG_1) {
					strBuffer.append((PLMConstants.START_FUTURE_DATE)
							+ "<br/>");
				}
				if (currentDate.compareTo(edDate) == PLMConstants.N_NEG_1) {
					strBuffer.append((PLMConstants.END_FUTURE_DATE)
							+ "<br/>");
				}
				if (currentDate.compareTo(stDate) != PLMConstants.N_NEG_1
						&& currentDate.compareTo(edDate) != PLMConstants.N_NEG_1) {
					if (edDate.compareTo(stDate) == PLMConstants.N_NEG_1) {
						strBuffer.append((PLMConstants.START_END)
								+ "<br/>");
					}
				}

			}
		}
		return strBuffer.toString();
	}
	
	/**
	 * @param event
	 */
	public void getExcelFlag(ActionEvent event) {
		excelFlag = (String) event.getComponent().getAttributes().get(
				PLMConstants.EXPT_EXCEL);
	}

	/**
	 * @return Returns the systemLogsList.
	 */
	public List<PLMReportData> getSystemLogsList() {
		return systemLogsList;
	}

	/**
	 * @param listSystemLogsList
	 *            The systemLogsList to set.
	 */
	public void setSystemLogsList(List<PLMReportData> listSystemLogsList) {
		this.systemLogsList = listSystemLogsList;
	}

	/**
	 * @return Returns the beginDate.
	 */
	public String getBeginDate() {
		return beginDate;
	}

	/**
	 * @param strBeginDate
	 *            The beginDate to set.
	 */
	public void setBeginDate(String strBeginDate) {
		this.beginDate = strBeginDate;
	}

	/**
	 * @return Returns the endDate.
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @param strEndDate
	 *            The endDate to set.
	 */
	public void setEndDate(String strEndDate) {
		this.endDate = strEndDate;
	}

	/**
	 * @return Returns the message.
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param strMessage
	 *            The message to set.
	 */
	public void setMessage(String strMessage) {
		this.message = strMessage;
	}

	/**
	 * @return Returns the endingDate.
	 */
	public Date getEndingDate() {
		Date temp = null;
		temp = endingDate;
		return temp;
	}

	/**
	 * @param dtEndingDate
	 *            The endingDate to set.
	 */
	public void setEndingDate(Date dtEndingDate) {
		Date temp1 = null;
		temp1 = dtEndingDate;
		this.endingDate = temp1;
	}

	/**
	 * @return Returns the startDate.
	 */
	public Date getStartDate() {
		Date temp = null;
		temp = startDate;
		return temp;
	}

	/**
	 * @param dtStartDate
	 *            The startDate to set.
	 */
	public void setStartDate(Date dtStartDate) {
		Date temp1 = null;
		temp1 = dtStartDate;
		this.startDate = temp1;
	}

	/**
	 * @return Returns the recordsMsg.
	 */
	public String getRecordsMsg() {
		return recordsMsg;
	}

	/**
	 * @param strRecordsMsg
	 *            The recordsMsg to set.
	 */
	public void setRecordsMsg(String strRecordsMsg) {
		this.recordsMsg = strRecordsMsg;
	}

	/**
	 * @return Returns the renderingMsg.
	 */
	public boolean isRenderingMsg() {
		return renderingMsg;
	}

	/**
	 * @param blRenderingMsg
	 *            The renderingMsg to set.
	 */
	public void setRenderingMsg(boolean blRenderingMsg) {
		this.renderingMsg = blRenderingMsg;
	}

	/**
	 * @return Returns the validationMsg.
	 */
	public String getValidationMsg() {
		return validationMsg;
	}

	/**
	 * @param strValidationMsg
	 *            The validationMsg to set.
	 */
	public void setValidationMsg(String strValidationMsg) {
		this.validationMsg = strValidationMsg;
	}

	/**
	 * resetting the alert values.
	 * 
	 */
	public void resetUserAlertMsg() {
		alertMsgReq = PLMConstants.EMPTY;
	}

	/**
	 * @return the icmRequestData.
	 */
	public PLMRequestData getIcmRequestData() {
		return pwiRequestData;
	}

	/**
	 * @param icmRequestData1
	 *            the icmRequestData to set.
	 */
	public void setIcmRequestData(PLMRequestData icmRequestData1) {
		this.pwiRequestData = icmRequestData1;
	}

	/**
	 * @return the announcements
	 */
	public String getAnnouncements() {
		return announcements;
	}

	/**
	 * @param announcements1
	 *            the announcements to set.
	 */
	public void setAnnouncements(String announcements1) {
		this.announcements = announcements1;
	}

	/**
	 * @return the selectedModName
	 */
	public String getSelectedModName() {
		return selectedModName;
	}

	/**
	 * @param selectedModName1
	 *            the selectedModName to set.
	 */
	public void setSelectedModName(String selectedModName1) {
		this.selectedModName = selectedModName1;
	}

	/**
	 * @return the modDesc
	 */
	public String getModDesc() {
		return modDesc;
	}

	/**
	 * @param modDesc1
	 *            the modDesc to set.
	 */
	public void setModDesc(String modDesc1) {
		this.modDesc = modDesc1;
	}

	/**
	 * @return the modLink
	 */
	public String getModLink() {
		return modLink;
	}

	/**
	 * @param modLink1
	 *            the modLink to set.
	 */
	public void setModLink(String modLink1) {
		this.modLink = modLink1;
	}

	/**
	 * @return the modPresentation
	 */
	public String getModPresentation() {
		return modPresentation;
	}

	/**
	 * @param modPresentation1
	 *            the modPresentation to set.
	 */
	public void setModPresentation(String modPresentation1) {
		this.modPresentation = modPresentation1;
	}

	/**
	 * @return the modTraining
	 */
	public String getModTraining() {
		return modTraining;
	}

	/**
	 * @param modTraining1
	 *            the modTraining to set.
	 */
	public void setModTraining(String modTraining1) {
		this.modTraining = modTraining1;
	}

	/**
	 * @return the versionNo
	 */
	public String getVersionNo() {
		return versionNo;
	}

	/**
	 * @param versionNo1
	 *            the versionNo to set.
	 */
	public void setVersionNo(String versionNo1) {
		this.versionNo = versionNo1;
	}

	/**
	 * @return the navInputPage
	 */
	public HtmlInputHidden getNavInputPage() {
		return navInputPage;
	}

	/**
	 * @param navInputPage1
	 *            the navInputPage to set.
	 */
	public void setNavInputPage(HtmlInputHidden navInputPage1) {
		this.navInputPage = navInputPage1;
	}

	/**
	 * @return the navPage
	 */
	public String getNavPage() {
		return navPage;
	}

	/**
	 * @param navPage1
	 *            the navPage to set.
	 */
	public void setNavPage(String navPage1) {
		this.navPage = navPage1;
	}

	/**
	 * @return the moduleValList
	 */
	public List getModuleValList() {
		return moduleValList;
	}

	/**
	 * @param moduleValList1
	 *            the moduleValList to set.
	 */
	public void setModuleValList(List moduleValList1) {
		this.moduleValList = moduleValList1;
	}

	/**
	 * @return the screenId
	 */
	public String getScreenId() {
		return screenId;
	}

	/**
	 * @param screenId1
	 *            the screenId to set.
	 */
	public void setScreenId(String screenId1) {
		this.screenId = screenId1;
	}

	/**
	 * @return the screenParentId
	 */
	public String getScreenParentId() {
		return screenParentId;
	}

	/**
	 * @param screenParentId1
	 *            the screenParentId to set.
	 */
	public void setScreenParentId(String screenParentId1) {
		this.screenParentId = screenParentId1;
	}

	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * @param fieldName1
	 *            the fieldName to set.
	 */
	public void setFieldName(String fieldName1) {
		this.fieldName = fieldName1;
	}

	/**
	 * @return the fieldVal
	 */
	public String getFieldVal() {
		return fieldVal;
	}

	/**
	 * @param fieldVal1
	 *            the fieldVal to set.
	 */
	public void setFieldVal(String fieldVal1) {
		this.fieldVal = fieldVal1;
	}

	/**
	 * @return the typeCd
	 */
	public String getTypeCd() {
		return typeCd;
	}

	/**
	 * @param typeCd1
	 *            the typeCd to set.
	 */
	public void setTypeCd(String typeCd1) {
		this.typeCd = typeCd1;
	}

	/**
	 * @return the fieldType
	 */
	public String getFieldType() {
		return fieldType;
	}

	/**
	 * @param fieldType1
	 *            the fieldType to set.
	 */
	public void setFieldType(String fieldType1) {
		this.fieldType = fieldType1;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy1
	 *            the createdBy to set.
	 */
	public void setCreatedBy(String createdBy1) {
		this.createdBy = createdBy1;
	}

	/**
	 * @return the createDate
	 */
	public String getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate1
	 *            the createDate to set.
	 */
	public void setCreateDate(String createDate1) {
		this.createDate = createDate1;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy1
	 *            the updatedBy to set.
	 */
	public void setUpdatedBy(String updatedBy1) {
		this.updatedBy = updatedBy1;
	}

	/**
	 * @return the updateDate
	 */
	public String getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate1
	 *            the updateDate to set.
	 */
	public void setUpdateDate(String updateDate1) {
		this.updateDate = updateDate1;
	}

	/**
	 * @return the homePageList
	 */
	public List getHomePageList() {
		return homePageList;
	}

	/**
	 * @param homePageList1
	 *            the homePageList to set.
	 */
	public void setHomePageList(List homePageList1) {
		this.homePageList = homePageList1;
	}

	/**
	 * @return the releaseDate
	 */
	public String getReleaseDate() {
		return releaseDate;
	}

	/**
	 * @param releaseDate1
	 *            the releaseDate to set.
	 */
	public void setReleaseDate(String releaseDate1) {
		this.releaseDate = releaseDate1;
	}

	/**
	 * @return the relDescription
	 */
	public String getRelDescription() {
		return relDescription;
	}

	/**
	 * @param relDescription1
	 *            the relDescription to set.
	 */
	public void setRelDescription(String relDescription1) {
		this.relDescription = relDescription1;
	}

	/**
	 * @return the relDetails
	 */
	public String getRelDetails() {
		return relDetails;
	}

	/**
	 * @param relDetails1
	 *            the relDetails to set.
	 */
	public void setRelDetails(String relDetails1) {
		this.relDetails = relDetails1;
	}

	/**
	 * @return the maitnAnnouncements
	 */
	public String getMaitnAnnouncements() {
		return maitnAnnouncements;
	}

	/**
	 * @param maitnAnnouncements1
	 *            the maitnAnnouncements to set.
	 */
	public void setMaitnAnnouncements(String maitnAnnouncements1) {
		this.maitnAnnouncements = maitnAnnouncements1;
	}

	/**
	 * @return the maitnModDesc
	 */
	public String getMaitnModDesc() {
		return maitnModDesc;
	}

	/**
	 * @param maitnModDesc1
	 *            the maitnModDesc to set.
	 */
	public void setMaitnModDesc(String maitnModDesc1) {
		this.maitnModDesc = maitnModDesc1;
	}

	/**
	 * @return the maitnModLink
	 */
	public String getMaitnModLink() {
		return maitnModLink;
	}

	/**
	 * @param maitnModLink1
	 *            the maitnModLink to set.
	 */
	public void setMaitnModLink(String maitnModLink1) {
		this.maitnModLink = maitnModLink1;
	}

	/**
	 * @return the maitnModPresentation
	 */
	public String getMaitnModPresentation() {
		return maitnModPresentation;
	}

	/**
	 * @param maitnModPresentation1
	 *            the maitnModPresentation to set.
	 */
	public void setMaitnModPresentation(String maitnModPresentation1) {
		this.maitnModPresentation = maitnModPresentation1;
	}

	/**
	 * @return the maitnModTraining
	 */
	public String getMaitnModTraining() {
		return maitnModTraining;
	}

	/**
	 * @param maitnModTraining1
	 *            the maitnModTraining to set.
	 */
	public void setMaitnModTraining(String maitnModTraining1) {
		this.maitnModTraining = maitnModTraining1;
	}

	/**
	 * @return the maitnVersionNo
	 */
	public String getMaitnVersionNo() {
		return maitnVersionNo;
	}

	/**
	 * @param maitnVersionNo1
	 *            the maitnVersionNo to set.
	 */
	public void setMaitnVersionNo(String maitnVersionNo1) {
		this.maitnVersionNo = maitnVersionNo1;
	}

	/**
	 * @return the maitnReleaseDate
	 */
	public String getMaitnReleaseDate() {
		return maitnReleaseDate;
	}

	/**
	 * @param maitnReleaseDate1
	 *            the maitnReleaseDate to set.
	 */
	public void setMaitnReleaseDate(String maitnReleaseDate1) {
		this.maitnReleaseDate = maitnReleaseDate1;
	}

	/**
	 * @return the maitnRelDescription
	 */
	public String getMaitnRelDescription() {
		return maitnRelDescription;
	}

	/**
	 * @param maitnRelDescription1
	 *            the maitnRelDescription to set.
	 */
	public void setMaitnRelDescription(String maitnRelDescription1) {
		this.maitnRelDescription = maitnRelDescription1;
	}

	/**
	 * @return the maitnRelDetails
	 */
	public String getMaitnRelDetails() {
		return maitnRelDetails;
	}

	/**
	 * @param maitnRelDetails1
	 *            the maitnRelDetails to set.
	 */
	public void setMaitnRelDetails(String maitnRelDetails1) {
		this.maitnRelDetails = maitnRelDetails1;
	}

	/**
	 * @return the maitnModuleValList
	 */
	public List getMaitnModuleValList() {
		return maitnModuleValList;
	}

	/**
	 * @param maitnModuleValList1
	 *            the maitnModuleValList to set.
	 */
	public void setMaitnModuleValList(List maitnModuleValList1) {
		this.maitnModuleValList = maitnModuleValList1;
	}

	/**
	 * @return the maitnScreenId
	 */
	public String getMaitnScreenId() {
		return maitnScreenId;
	}

	/**
	 * @param maitnScreenId1
	 *            the maitnScreenId to set.
	 */
	public void setMaitnScreenId(String maitnScreenId1) {
		this.maitnScreenId = maitnScreenId1;
	}

	/**
	 * @return the maitnScreenParentId
	 */
	public String getMaitnScreenParentId() {
		return maitnScreenParentId;
	}

	/**
	 * @param maitnScreenParentId1
	 *            the maitnScreenParentId to set.
	 */
	public void setMaitnScreenParentId(String maitnScreenParentId1) {
		this.maitnScreenParentId = maitnScreenParentId1;
	}

	/**
	 * @return the maitnFieldName
	 */
	public String getMaitnFieldName() {
		return maitnFieldName;
	}

	/**
	 * @param maitnFieldName1
	 *            the maitnFieldName to set.
	 */
	public void setMaitnFieldName(String maitnFieldName1) {
		this.maitnFieldName = maitnFieldName1;
	}

	/**
	 * @return the maitnFieldType
	 */
	public String getMaitnFieldType() {
		return maitnFieldType;
	}

	/**
	 * @param maitnFieldType1
	 *            the maitnFieldType to set.
	 */
	public void setMaitnFieldType(String maitnFieldType1) {
		this.maitnFieldType = maitnFieldType1;
	}

	/**
	 * @return the selectedMaintainName
	 */
	public String getSelectedMaintainName() {
		return selectedMaintainName;
	}

	/**
	 * @param selectedMaintainName1
	 *            the selectedMaintainName to set.
	 */
	public void setSelectedMaintainName(String selectedMaintainName1) {
		this.selectedMaintainName = selectedMaintainName1;
	}

	/**
	 * @return the alertMsgReq
	 */
	public String getAlertMsgReq() {
		return alertMsgReq;
	}

	/**
	 * @param alertMsgReq1
	 *            the alertMsgReq to set.
	 */
	public void setAlertMsgReq(String alertMsgReq1) {
		this.alertMsgReq = alertMsgReq1;
	}

	/**
	 * @return the groupList
	 */
	public List getGroupList() {
		return groupList;
	}

	/**
	 * @param groupList1
	 *            the groupList to set.
	 */
	public void setGroupList(List groupList1) {
		this.groupList = groupList1;
	}

	/**
	 * @return the ssoId
	 */
	public String getSsoId() throws PWiException {
		ssoId = UserInfoPortalUtil.getInstance().getUserSSO();
		return ssoId;
	}

	/**
	 * @param ssoId1
	 *            the ssoId to set.
	 */
	public void setSsoId(String ssoId1) {
		this.ssoId = ssoId1;
	}

	/**
	 * @return the emailId
	 */
	public String getEmailId() throws PWiException {
		emailId = UserInfoPortalUtil.getInstance().getUserEmail();
		return emailId;
	}

	/**
	 * @param emailId1
	 *            the emailId to set.
	 */
	public void setEmailId(String emailId1) {
		this.emailId = emailId1;
	}

	/**
	 * @return the groupId
	 */
	public String getGroupId() {
		return groupId;
	}

	/**
	 * @param groupId1
	 *            the groupId to set.
	 */
	public void setGroupId(String groupId1) {
		this.groupId = groupId1;
	}

	/**
	 * @return the nationalityUsr
	 */
	public String getNationalityUsr() {
		return nationalityUsr;
	}

	/**
	 * @param nationalityUsr1
	 *            the nationalityUsr to set.
	 */
	public void setNationalityUsr(String nationalityUsr1) {
		this.nationalityUsr = nationalityUsr1;
	}

	/**
	 * @return the contactDetails
	 */
	public String getContactDetails() {
		return contactDetails;
	}

	/**
	 * @param contactDetails1
	 *            the contactDetails to set.
	 */
	public void setContactDetails(String contactDetails1) {
		this.contactDetails = contactDetails1;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments1
	 *            the comments to set.
	 */
	public void setComments(String comments1) {
		this.comments = comments1;
	}

	/**
	 * @return the lastUpdatedBy
	 */
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	/**
	 * @param lastUpdatedBy1
	 *            the lastUpdatedBy to set.
	 */
	public void setLastUpdatedBy(String lastUpdatedBy1) {
		this.lastUpdatedBy = lastUpdatedBy1;
	}

	/**
	 * @return the lastUpdatedDate
	 */
	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	/**
	 * @param lastUpdatedDate1
	 *            the lastUpdatedDate to set.
	 */
	public void setLastUpdatedDate(String lastUpdatedDate1) {
		this.lastUpdatedDate = lastUpdatedDate1;
	}

	/**
	 * @return the displayMsg
	 */
	public String getDisplayMsg() {
		return displayMsg;
	}

	/**
	 * @param displayMsg1
	 *            the displayMsg to set.
	 */
	public void setDisplayMsg(String displayMsg1) {
		this.displayMsg = displayMsg1;
	}

	/**
	 * @return the buttonFlag
	 */
	public boolean isButtonFlag() {
		return buttonFlag;
	}

	/**
	 * @param buttonFlag1
	 *            the buttonFlag to set.
	 */
	public void setButtonFlag(boolean buttonFlag1) {
		this.buttonFlag = buttonFlag1;
	}

	/**
	 * @return the oldMaitnModDesc
	 */
	public String getOldMaitnModDesc() {
		return oldMaitnModDesc;
	}

	/**
	 * @param oldMaitnModDesc1
	 *            the oldMaitnModDesc to set.
	 */
	public void setOldMaitnModDesc(String oldMaitnModDesc1) {
		this.oldMaitnModDesc = oldMaitnModDesc1;
	}

	/**
	 * @return the oldMaitnModLink
	 */
	public String getOldMaitnModLink() {
		return oldMaitnModLink;
	}

	/**
	 * @param oldMaitnModLink1
	 *            the oldMaitnModLink to set.
	 */
	public void setOldMaitnModLink(String oldMaitnModLink1) {
		this.oldMaitnModLink = oldMaitnModLink1;
	}

	/**
	 * @return the maitnRelDate
	 */
	public Date getMaitnRelDate() {
		Date temp = null;
		temp = maitnRelDate;
		return temp;
	}

	/**
	 * @param maitnRelDate1
	 *            the maitnRelDate to set.
	 */
	public void setMaitnRelDate(Date maitnRelDate1) {
		Date temp1 = null;
		temp1 = maitnRelDate1;
		this.maitnRelDate = temp1;
	}

	/**
	 * @return the writePerm
	 */
	public boolean isWritePerm() {
		return writePerm;
	}

	/**
	 * @param writePerm1
	 *            the writePerm to set
	 */
	public void setWritePerm(boolean writePerm1) {
		this.writePerm = writePerm1;
	}

	/**
	 * @return the tempRelDate
	 */
	public Date getTempRelDate() {
		Date temp = null;
		temp = tempRelDate;
		return temp;
	}

	/**
	 * @param tempRelDate
	 *            the tempRelDate to set
	 */
	public void setTempRelDate(Date tempRelDate1) {
		Date temp1 = null;
		temp1 = tempRelDate1;
		this.tempRelDate = temp1;
	}

	/**
	 * @return the oldMaitnAnc
	 */
	public String getOldMaitnAnc() {
		return oldMaitnAnc;
	}

	/**
	 * @param oldMaitnAnc1
	 *            the oldMaitnAnc to set
	 */
	public void setOldMaitnAnc(String oldMaitnAnc1) {
		this.oldMaitnAnc = oldMaitnAnc1;
	}

	/**
	 * @return the oldMaitnVersn
	 */
	public String getOldMaitnVersn() {
		return oldMaitnVersn;
	}

	/**
	 * @param oldMaitnVersn1
	 *            the oldMaitnVersn to set
	 */
	public void setOldMaitnVersn(String oldMaitnVersn1) {
		this.oldMaitnVersn = oldMaitnVersn1;
	}

	/**
	 * @return the oldMaitnRelDate
	 */
	public String getOldMaitnRelDate() {
		return oldMaitnRelDate;
	}

	/**
	 * @param oldMaitnRelDate1
	 *            the oldMaitnRelDate to set
	 */
	public void setOldMaitnRelDate(String oldMaitnRelDate1) {
		this.oldMaitnRelDate = oldMaitnRelDate1;
	}

	/**
	 * @return the oldMaitnLatDesc
	 */
	public String getOldMaitnLatDesc() {
		return oldMaitnLatDesc;
	}

	/**
	 * @param oldMaitnLatDesc1
	 *            the oldMaitnLatDesc to set
	 */
	public void setOldMaitnLatDesc(String oldMaitnLatDesc1) {
		this.oldMaitnLatDesc = oldMaitnLatDesc1;
	}

	/**
	 * @return the oldMaitnLatDeatls
	 */
	public String getOldMaitnLatDeatls() {
		return oldMaitnLatDeatls;
	}

	/**
	 * @param oldMaitnLatDeatls1
	 *            the oldMaitnLatDeatls to set
	 */
	public void setOldMaitnLatDeatls(String oldMaitnLatDeatls1) {
		this.oldMaitnLatDeatls = oldMaitnLatDeatls1;
	}

	/**
	 * @return the tempMaitnReleaseDate
	 */
	public Date getTempMaitnReleaseDate() {
		Date temp = null;
		temp = tempMaitnReleaseDate;
		return temp;
	}

	/**
	 * @param tempMaitnReleaseDate
	 *            the tempMaitnReleaseDate to set
	 */
	public void setTempMaitnReleaseDate(Date tempMaitnReleaseDate1) {
		Date temp1 = null;
		temp1 = tempMaitnReleaseDate1;
		this.tempMaitnReleaseDate = temp1;
	}

	/**
	 * @return the oldMaitnModPresentation
	 */
	public String getOldMaitnModPresentation() {
		return oldMaitnModPresentation;
	}

	/**
	 * @param oldMaitnModPresentation
	 *            the oldMaitnModPresentation to set
	 */
	public void setOldMaitnModPresentation(String oldMaitnModPresentation1) {
		this.oldMaitnModPresentation = oldMaitnModPresentation1;
	}

	/**
	 * @return the oldMaitnModTraining
	 */
	public String getOldMaitnModTraining() {
		return oldMaitnModTraining;
	}

	/**
	 * @param oldMaitnModTraining
	 *            the oldMaitnModTraining to set
	 */
	public void setOldMaitnModTraining(String oldMaitnModTraining1) {
		this.oldMaitnModTraining = oldMaitnModTraining1;
	}

	/**
	 * @return the activeIndSent
	 */
	public String getActiveIndSent() {
		return activeIndSent;
	}

	/**
	 * @param activeIndSent
	 *            the activeIndSent to set
	 */
	public void setActiveIndSent(String activeIndSent1) {
		this.activeIndSent = activeIndSent1;
	}

	

	/**
	 * @return the groupIdList
	 */
	public List getGroupIdList() {
		return groupIdList;
	}

	/**
	 * @param groupIdList
	 *            the groupIdList to set
	 */
	public void setGroupIdList(List groupIdList1) {
		this.groupIdList = groupIdList1;
	}

	/**
	 * @return the requestedGroupList
	 */
	public List getRequestedGroupList() {
		return requestedGroupList;
	}

	/**
	 * @param requestedGroupList
	 *            the requestedGroupList to set
	 */
	public void setRequestedGroupList(List requestedGroupList1) {
		this.requestedGroupList = requestedGroupList1;
	}

	/**
	 * @return the requestingGroupList
	 */
	public List getRequestingGroupList() {
		return requestingGroupList;
	}

	/**
	 * @param requestingGroupList
	 *            the requestingGroupList to set
	 */
	public void setRequestingGroupList(List requestingGroupList1) {
		this.requestingGroupList = requestingGroupList1;
	}

	/**
	 * @return the requestedFlag
	 */
	public boolean isRequestedFlag() {
		return requestedFlag;
	}

	/**
	 * @param requestedFlag
	 *            the requestedFlag to set
	 */
	public void setRequestedFlag(boolean requestedFlag1) {
		this.requestedFlag = requestedFlag1;
	}

	/**
	 * @return the requestingFlag
	 */
	public boolean isRequestingFlag() {
		return requestingFlag;
	}

	/**
	 * @param requestingFlag
	 *            the requestingFlag to set
	 */
	public void setRequestingFlag(boolean requestingFlag1) {
		this.requestingFlag = requestingFlag1;
	}

	/**
	 * @return the localUserfname
	 */
	public String getLocalUserfname() throws PWiException {
		localUserfname = UserInfoPortalUtil.getInstance().getUserFirstName();
		return localUserfname;
	}

	/**
	 * @param localUserfname
	 *            the localUserfname to set
	 */
	public void setLocalUserfname(String localUserfname1) {
		this.localUserfname = localUserfname1;
	}

	/**
	 * @return the localUserlname
	 */
	public String getLocalUserlname() throws PWiException {
		localUserlname = UserInfoPortalUtil.getInstance().getUserLastName();
		return localUserlname;
	}

	/**
	 * @param localUserlname
	 *            the localUserlname to set
	 */
	public void setLocalUserlname(String localUserlname1) {
		this.localUserlname = localUserlname1;
	}
	/**
	 * @return adminServiceIfc
	 */
	public PLMAdminServiceIfc getAdminServiceIfc() {
		return adminServiceIfc;
	}

	/**
	 * @param adminServiceIfc
	 */
	public void setAdminServiceIfc(PLMAdminServiceIfc objAdminServiceIfc) {
		this.adminServiceIfc = objAdminServiceIfc;
	}

	
	/**
	 * @return the roleType
	 */
	public String getRoleType() {
		return roleType;
	}

	
	/**
	 * @param roleType the roleType to set
	 */
	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}

	
	/**
	 * @return the roleListSel
	 */
	public List getRoleListSel() {
		return roleListSel;
	}

	
	/**
	 * @param roleListSel the roleListSel to set
	 */
	public void setRoleListSel(List roleListSel) {
		this.roleListSel = roleListSel;
	}

	
	/**
	 * @return the roleList
	 */
	public List<SelectItem> getRoleList() throws PWiException {
		roleList = UserInfoPortalUtil.getInstance().getRoleListForReq(ssoId);
		return roleList;
	}

	
	/**
	 * @param roleList the roleList to set
	 */
	public void setRoleList(List<SelectItem> roleList) {
		this.roleList = roleList;
	}

	
	/**
	 * @return the roleTypeList
	 */
	/*public List getRoleTypeList() throws PWiException {
		roleTypeList = UserInfoPortalUtil.getInstance().getRoleTypeList();
		return roleTypeList;
	}*/

	
	/**
	 * @param roleTypeList the roleTypeList to set
	 */
	/*public void setRoleTypeList(List<SelectItem> roleTypeList) {
		this.roleTypeList = roleTypeList;
	}*/

	
	/**
	 * @return the roleNameList
	 */
	public List getRoleNameList() {
		return roleNameList;
	}

	
	/**
	 * @param roleNameList the roleNameList to set
	 */
	public void setRoleNameList(List roleNameList) {
		this.roleNameList = roleNameList;
	}

	public String getPwiUsers() {
		return pwiUsers;
	}

	public void setPwiUsers(String pwiUsers) {
		this.pwiUsers = pwiUsers;
	}
	

}
