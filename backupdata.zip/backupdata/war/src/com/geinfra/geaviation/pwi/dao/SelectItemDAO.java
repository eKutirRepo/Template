package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.common.PWiException;

/**
 * Project      : Product Lifecycle Management 
 * Date Written : Aug 29, 2012
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 *
 * Copyright(C) 2012 GE All rights reserved
 *
 * Description : Data access object for sql-driven input.
 *
 * Revision Log Aug 29, 2012 | v1.0.
 * --------------------------------------------------------------
 */
public interface SelectItemDAO {
    /**
     * Given a query that returns the columns value and label,
     * returns a list of SelectItem's with the given values and labels.
     * @param dsn the DataSource name
     * @param sql the SQL to be executed
     * @param sso the SSO of the user executing the query
     * @return a list of select items (for use in jsf's)
     * @throws PWiException 
     */
    public List<SelectItem> getSelectableItems(String dsn, String sql, String sso)
            throws PWiException;
}
