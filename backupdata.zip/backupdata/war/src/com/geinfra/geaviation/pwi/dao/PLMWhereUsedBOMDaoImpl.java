/**
 * Copyright (C) 2017 GE Infra. 
 * All rights reserved 
 * @FileName PLMWhereUsedBOMDaoImpl.java
 * @Creation date: 16-November-2017
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMWhereUsedBOMData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.PLMWhereusedQueries;

public class PLMWhereUsedBOMDaoImpl extends SimpleJdbcDaoSupport implements PLMWhereUsedBOMDaoIfc {

	/**
	 * Holds the LOG
	 */
	private static final Logger LOG = Logger
			.getLogger(PLMWhereUsedBOMDaoImpl.class);
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	
	/**
	 * This method is used to fetch BOM Implosion  Where Used Tool data
	 * 
	 * @param partList
	 * @return Map
	 * @throws PLMCommonException
	 */
	public Map<String,List<PLMWhereUsedBOMData>> fetchBOMImplsnWhereUsedData(List<PLMWhereUsedBOMData> partList, String levelsUpTo, int level) throws PLMCommonException {
		LOG.info("Entering fetchBOMImplsnWhereUsedData Method");
		List<PLMWhereUsedBOMData> partListLcl = partList;
		Map<String,List<PLMWhereUsedBOMData>> finalDataMap = new HashMap<String,List<PLMWhereUsedBOMData>>();
		List<PLMWhereUsedBOMData> finalDataList = new ArrayList<PLMWhereUsedBOMData>();
		String timeStamp = null;
		String VT_BOM_INPUT = null;
		String VT_PARTS_IMPLOSION = null;
		boolean VT1Executed = false;
		boolean VT2Executed = false;
		try {
			
			timeStamp = PLMUtils.volTableFormatDate();
			LOG.info("The timeStamp for the Report "+timeStamp);
			
			VT_BOM_INPUT = PLMConstants.VT_BOM_INPUT.concat(timeStamp);
			VT_PARTS_IMPLOSION = PLMConstants.VT_PARTS_IMPLOSION.concat(timeStamp);
			
			LOG.info("Query for Creating VT_BOM_INPUT : " + PLMWhereusedQueries.WHERE_USED_VT_BOM_INPUT.replace(PLMConstants.VT_BOM_INPUT, VT_BOM_INPUT));
			getJdbcTemplate().execute(PLMWhereusedQueries.WHERE_USED_VT_BOM_INPUT.replace(PLMConstants.VT_BOM_INPUT, VT_BOM_INPUT));
			VT1Executed = true;
			final List<PLMWhereUsedBOMData> partInsertResultList = partListLcl;
			int[] updateCount = null;
			//setting 2 column values for 6.1 Release
			LOG.info("Insert Query :  " + PLMWhereusedQueries.SET_VT_BOM_INPUT.replace(PLMConstants.VT_BOM_INPUT, VT_BOM_INPUT));
			updateCount  = getSimpleJdbcTemplate().getJdbcOperations().batchUpdate(PLMWhereusedQueries.SET_VT_BOM_INPUT.
					replace(PLMConstants.VT_BOM_INPUT, VT_BOM_INPUT), new BatchPreparedStatementSetter() 
			{
			public void setValues(PreparedStatement ps,int iCount)throws SQLException {
				ps.setInt(1,iCount+1);
				ps.setString(2, partInsertResultList.get(iCount).getBomLevel());
				ps.setString(3, partInsertResultList.get(iCount).getPartNumber());
				ps.setString(4, partInsertResultList.get(iCount).getQuantity());
				ps.setString(5, partInsertResultList.get(iCount).getDescription());
				ps.setString(6, partInsertResultList.get(iCount).getFindNum());
				LOG.info("INSERT INTO VT_BOM_INPUT (ROW_KEY,LVL,PART_NUM,QTY,DESCRIPTION,FIND_NUM) VALUES ("
						+ (iCount+1) + ","
						+ "CAST('" + partInsertResultList.get(iCount).getBomLevel() + "' AS INTEGER),'"
						+ partInsertResultList.get(iCount).getPartNumber() + "',"
						+ "CAST('" + partInsertResultList.get(iCount).getQuantity() + "' AS DECIMAL(18,6)),'" 
						+ partInsertResultList.get(iCount).getDescription() + "','"
						+ partInsertResultList.get(iCount).getFindNum() + "')");
			}
			public int getBatchSize() {
				return partInsertResultList.size();
			}
			});
			LOG.info("Total inserted Records : " + updateCount.length);
			if (VT1Executed) {
				LOG.info("Query for Collect STATS VT_BOM_INPUT_COL_STATS1 : " + PLMWhereusedQueries.VT_BOM_INPUT_COL_STATS1
						.replace(PLMConstants.VT_BOM_INPUT, VT_BOM_INPUT));
				getJdbcTemplate().execute(PLMWhereusedQueries.VT_BOM_INPUT_COL_STATS1.replace(PLMConstants.VT_BOM_INPUT, VT_BOM_INPUT));
			}
			
			// SQL for VT_PARTS_IMPLOSION creation
			StringBuffer sql = new StringBuffer();
			sql.append(PLMWhereusedQueries.WHERE_USED_VT_PARTS_IMPLOSION3).append(PLMWhereusedQueries.WHERE_USED_VT_PARTS_IMPLOSION);
			
			/* levelsUpTo ========================================================================================
			 * All � Get all levels of implosion till top level parent
			 * Highest � Exclude middle level hierarchy parent and consider only top level parent in final output
			 * Up to Highest  - User enters input value till what level implosion needs to be done.
			 */
			if ("All".equalsIgnoreCase(levelsUpTo)) {
				level = 30;
			} else if ("Highest".equalsIgnoreCase(levelsUpTo)) {
				sql.append(PLMWhereusedQueries.WHERE_USED_VT_PARTS_IMPLOSION1);
				level = 30;
			} else if ("UpTo..And Highest".equalsIgnoreCase(levelsUpTo)) {
				LOG.info("Selected level value>>>>"+ level);
			}
			sql.append(PLMWhereusedQueries.WHERE_USED_VT_PARTS_IMPLOSION2);
			
			// SQL for VT_PARTS_IMPLOSION insertion
			StringBuffer sql1 = new StringBuffer();
			sql1.append(PLMWhereusedQueries.WHERE_USED_VT_PARTS_IMPLOSION4).append(PLMWhereusedQueries.WHERE_USED_VT_PARTS_IMPLOSION);
			
			/* levelsUpTo ========================================================================================
			 * All � Get all levels of implosion till top level parent
			 * Highest � Exclude middle level hierarchy parent and consider only top level parent in final output
			 * Up to Highest  - User enters input value till what level implosion needs to be done.
			 */
			if ("All".equalsIgnoreCase(levelsUpTo)) {
				level = 30;
			} else if ("Highest".equalsIgnoreCase(levelsUpTo)) {
				sql1.append(PLMWhereusedQueries.WHERE_USED_VT_PARTS_IMPLOSION1);
				level = 30;
			} else if ("UpTo..And Highest".equalsIgnoreCase(levelsUpTo)) {
				LOG.info("Selected level value>>>>"+ level);
			}
			
			
			int rowStart = 1;
			int rowEnd = 200;
			int rowCount = partListLcl.size()/200;
			float diff = ((float)partListLcl.size()/200) - rowCount;
			
			LOG.info("diff ~~~~~~~~~~~~~~~~~~~~~~~~~"+ diff);
			if (diff > 0) {
				rowCount = rowCount + 1;
			}
			
			LOG.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@LOOP STARTED@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"+ rowCount);
			for (int i = 1; i <= rowCount; i++) {
				LOG.info("rowStart >>>>>>>>>>>> "+ rowStart + " rowEnd>>>>>>>>>>>>>>>>>> "+ rowEnd);
				
				if (i == 1) {
					
					LOG.info("Query for Creating VT_PARTS_IMPLOSION : " + sql.toString()
							.replace(PLMConstants.VT_PARTS_IMPLOSION, VT_PARTS_IMPLOSION)
							.replace(PLMConstants.VT_BOM_INPUT, VT_BOM_INPUT)
							.replace("?", level+"")
							.replace("#", rowStart+"")
							.replace("@", rowEnd+""));
						
					getJdbcTemplate().execute(sql.toString()
							.replace(PLMConstants.VT_PARTS_IMPLOSION, VT_PARTS_IMPLOSION)
							.replace(PLMConstants.VT_BOM_INPUT, VT_BOM_INPUT)
							.replace("?", level+"")
							.replace("#", rowStart+"")
							.replace("@", rowEnd+"")
							);
				} else {
					LOG.info("Query for Inserting into VT_PARTS_IMPLOSION : " + sql1.toString()
							.replace(PLMConstants.VT_PARTS_IMPLOSION, VT_PARTS_IMPLOSION)
							.replace(PLMConstants.VT_BOM_INPUT, VT_BOM_INPUT)
							.replace("?", level+"")
							.replace("#", rowStart+"")
							.replace("@", rowEnd+""));
						
					getJdbcTemplate().execute(sql1.toString()
							.replace(PLMConstants.VT_PARTS_IMPLOSION, VT_PARTS_IMPLOSION)
							.replace(PLMConstants.VT_BOM_INPUT, VT_BOM_INPUT)
							.replace("?", level+"")
							.replace("#", rowStart+"")
							.replace("@", rowEnd+"")
							);
				}
				
				rowStart = rowStart + 200;
				rowEnd = rowEnd + 200;
			}
			LOG.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@LOOP ENDED@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"+ rowEnd);
			VT2Executed = true;
			
			if (VT2Executed) {
				LOG.info("Query for Collect STATS VT_PARTS_IMPLOSION_COL_STATS1 : " + PLMWhereusedQueries.VT_PARTS_IMPLOSION_COL_STATS1
						.replace(PLMConstants.VT_PARTS_IMPLOSION, VT_PARTS_IMPLOSION));
				getJdbcTemplate().execute(PLMWhereusedQueries.VT_PARTS_IMPLOSION_COL_STATS1.replace(PLMConstants.VT_PARTS_IMPLOSION, VT_PARTS_IMPLOSION));
			}
			
			LOG.info("Query for Getting WHERE_USED_BOM_FINAL_QRY : " + PLMWhereusedQueries.WHERE_USED_BOM_FINAL_QRY
					.replace(PLMConstants.VT_PARTS_IMPLOSION, VT_PARTS_IMPLOSION)
					.replace(PLMConstants.VT_BOM_INPUT, VT_BOM_INPUT));
			finalDataList = getSimpleJdbcTemplate().query(PLMWhereusedQueries.WHERE_USED_BOM_FINAL_QRY
					.replace(PLMConstants.VT_PARTS_IMPLOSION, VT_PARTS_IMPLOSION)
					.replace(PLMConstants.VT_BOM_INPUT, VT_BOM_INPUT),new WhereUsedBOMResultMapper());
			LOG.info("Result of WHERE_USED_BOM_FINAL_QRY : " + finalDataList.size());
			
			
			if (!PLMUtils.isEmptyList(finalDataList)) {
				finalDataMap.put("Default", finalDataList);
			}
			
		}  catch(DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting fetchBOMImplsnWhereUsedData Method");
		return finalDataMap;
	}
	
	/**
	 * Row mapper for getting WhereUsedBOMResultMapper
	 */
	private static final class WhereUsedBOMResultMapper implements ParameterizedRowMapper<PLMWhereUsedBOMData>{	
	public PLMWhereUsedBOMData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMWhereUsedBOMData tempData = new PLMWhereUsedBOMData();
			tempData.setLevel(rs.getInt("BOM_LEVEL"));
			tempData.setPartNumber(PLMUtils.checkNullVal(rs.getString("PARENT_NAME")));
			tempData.setDescription(PLMUtils.checkNullVal(rs.getString("PARENT_DESC")));
			tempData.setFindNum(PLMUtils.checkNullVal(rs.getString("FIND_NUM")));
			tempData.setQuantity(PLMUtils.checkNullVal(rs.getString("QUANTITY")));
			tempData.setRevision(PLMUtils.checkNullVal(rs.getString("PARENT_REVISION")));
			tempData.setPartState(PLMUtils.checkNullVal(rs.getString("PARENT_STATE")));
			tempData.setMatchingChild(PLMUtils.checkNullVal(rs.getString("MATCHING_CHILD")));
			tempData.setMatchingCount(rs.getInt("MATCHING_COUNT"));
			tempData.setMatchPrcnt(rs.getInt("BOM_PERCENT"));
			return tempData;
		}
	}
}
