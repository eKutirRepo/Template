package com.geinfra.geaviation.pwi.bean;

import java.util.List;

import org.richfaces.component.html.HtmlDataTable;

import com.geinfra.geaviation.pwi.bean.util.BeanUtil;
import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.model.PWiObjectTypeVO;
import com.geinfra.geaviation.pwi.service.ObjectTypeService;

/**
 * 
 * Project : Product Lifecycle Management Intelligence
 * Date Written : Apr 3, 2013
 * Security : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2013 GE All rights reserved
 * 
 * Description : Managed backing bean for admin page which lists all object
 * types defined in the system.
 * 
 * Revision Log Apr 3, 2013 | v1.0.
 * --------------------------------------------------------------
 */
public class AdminObjectTypeListBean extends BaseBean {
	// Injected service
	private ObjectTypeService objectTypeService;

	private HtmlDataTable objectTypeTable = new HtmlDataTable();
	private List<PWiObjectTypeVO> objectTypeVOList;

	public void setObjectTypeService(ObjectTypeService objectTypeService) {
		this.objectTypeService = objectTypeService;
	}
	
	
	/**
	 * Action method that responds to requests to edit an object type
	 * 
	 * @return Faces navigation outcome
	 * @throws PWiException
	 * @throws NumberFormatException
	 */
	public String actionEditObjectType() throws NumberFormatException, PWiException {
		return BeanUtil.getInstance().getAdminObjectTypeEditorBean().initEdit(
				((PWiObjectTypeVO) objectTypeTable.getRowData()).getObjTypSeqId());
	}

	/**
	 * Action method that responds to requests for creating an object type
	 * 
	 * @return Faces navigation outcome
	 * @throws PWiException
	 */
	public String actionCreateObjectType() throws PWiException {
		return BeanUtil.getInstance().getAdminObjectTypeEditorBean().initCreate();
	}

	public List<PWiObjectTypeVO> getObjectTypeVOList() throws PWiException {
		if (objectTypeVOList == null) {
			objectTypeVOList = objectTypeService != null ? objectTypeService.getAllObjectTypesWithGroups() : null;
		}
		return objectTypeVOList;
	}

	public void setObjectTypeVOList(List<PWiObjectTypeVO> objectTypeVOList) {
		this.objectTypeVOList = objectTypeVOList;
	}

	public HtmlDataTable getObjectTypeTable() {
		return objectTypeTable;
	}

	public void setObjectTypeTable(HtmlDataTable objectTypeTable) {
		this.objectTypeTable = objectTypeTable;
	}
}