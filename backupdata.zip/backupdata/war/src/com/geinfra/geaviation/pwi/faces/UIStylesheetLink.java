/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName UIStylesheetLink.java
 * @Creation date: 18-Aug-2014
 * @version 1.0
  * @author : Tech Mahindra
 */
package com.geinfra.geaviation.pwi.faces;

import java.io.IOException;

import javax.el.ValueExpression;
import javax.faces.component.UIComponentBase;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.context.PWiApplication;
import com.geinfra.geaviation.pwi.context.PWiApplicationContext;
import com.geinfra.geaviation.pwi.context.PWiContext;
import com.geinfra.geaviation.pwi.context.PWiRequest;
import com.geinfra.geaviation.pwi.context.PWiSession;

public class UIStylesheetLink extends UIComponentBase {
	private String stylesheetPath;
	private String timestamp;

	public UIStylesheetLink() throws PWiException {
		PWiRequest request = PWiContext.getCurrentInstance().getRequest();

		// stylesheet path
		String contextPath = request.getContextPath();
		this.stylesheetPath = contextPath + "/css/";

		// timestamp
		PWiSession session = request.getSession();
		PWiApplication application = session.getApplication();
		PWiApplicationContext pwiApplicationContext = (PWiApplicationContext) application
				.getAttribute(PWiApplicationContext.ATTRIBUTE_NAME);
		this.timestamp = pwiApplicationContext
				.getApplicationContextTimestamp();
	}

	@Override
	public String getFamily() {
		return "stylesheetLink";
	}

	public String getRendererType() {
		return "renderer";
	}

	public void encodeBegin(FacesContext context) throws IOException {
		String name = getString("name");
		String href = stylesheetPath + name + ".css?" + timestamp;

		ResponseWriter writer = context.getResponseWriter();
		writer.startElement("link", this);
		writer.writeAttribute("type", "text/css", null);
		writer.writeAttribute("href", href, null);
		writer.writeAttribute("rel", "stylesheet", null);
		writer.endElement("link");
	}

	public void encodeEnd(FacesContext context) throws IOException {
		return;
	}

	public void decode(FacesContext context) {
		return;
	}

	private String getString(String name) {
		String value = null;
		ValueExpression ve = getValueExpression(name);
		if (ve != null) {
			value = (String) ve.getValue(getFacesContext().getELContext());
		} else {
			value = (String) getAttributes().get(name);
		}
		return value;
	}
}
