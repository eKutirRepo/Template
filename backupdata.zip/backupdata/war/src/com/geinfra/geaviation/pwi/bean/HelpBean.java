 /**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName HelpBean.java
 * @Creation date: 18-June-2014
 * @version 1.0
 * @author : Tech Mahindra
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.File;
import java.io.FilenameFilter;

import javax.faces.context.FacesContext;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.common.bean.BaseBean;
import com.geinfra.geaviation.pwi.util.FilePathUtil;
import com.geinfra.geaviation.pwi.util.FileUtil;

public class HelpBean extends BaseBean {
	public static final FilenameFilter FILTER_NOT_HIDDEN = new FilenameFilter() {
		public boolean accept(File dir, String name) {
			// for now, get all files whose name doesn't start with '.'
			return (name != null) && name.split("\\n")[0].matches("^[^\\.].*");
		}
	};
	
	private void refresh() {
	}
	
	public void getResultsFile() throws PWiException {
		String fileName = FacesContext.getCurrentInstance()
			.getExternalContext().getRequestParameterMap().get("fileName");
		FileUtil.getInstance().downloadFile(
				fileName,
				FilePathUtil.getInstance().helpModePath(
						FilePathUtil.getInstance().appDataMountPathDefault(),
						getSsoId()), false);
		refresh();
	}
	public void deleteResultsFile() throws PWiException {
		String fileName = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap().get("fileName");
		FileUtil.getInstance().deleteFile(
				fileName,
				FilePathUtil.getInstance().helpModePath(
						FilePathUtil.getInstance().appDataMountPathDefault(),
						getSsoId()));
		refresh();
	}

}
