/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMDocGenDaoImpl.java
 * @Creation date: 7-june-2011
 * @version 1.0
 * @author : Venkatesh
 */

package com.geinfra.geaviation.pwi.dao;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.geinfra.geaviation.pwi.data.PLMBomSalesData;
import com.geinfra.geaviation.pwi.data.PLMDocGenFmiData;
import com.geinfra.geaviation.pwi.data.PLMFmiTemplateData;
import com.geinfra.geaviation.pwi.data.PLMFmiTextData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMOfflineQueries;
import com.geinfra.geaviation.pwi.util.PLMQueryConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;


/**
 * PLMSearchDaoImpl is the DAO implementation class.
 */
public class PLMDocGenDaoImpl extends SimpleJdbcDaoSupport implements
		PLMDocGenDaoIfc {

	/**
	 * Holds the Logger object to the messages.
	 */
	private static final Logger LOG = Logger.getLogger(PLMDocGenDaoImpl.class);
	/**
	 * Holds the SIMPLE_DATE_FORMAT
	 */
	private static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(
	"dd/MM/yyyy");
	
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public NamedParameterJdbcTemplate getNamedJdbcTemplate(){
		if(namedParameterJdbcTemplate==null){
			return namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
					getDataSource());
		}else{
			return namedParameterJdbcTemplate;
		}
		 
	}

	/**
	 * This method is used to getFmiDetails
	 * @param fmidetails
	 * @return List
	 */
	@SuppressWarnings("unchecked")
	public List<PLMDocGenFmiData> getFmiDetails(PLMDocGenFmiData fmidetails)
			throws PLMCommonException {
		LOG.info("Entering getFmiDetails Method");
		String contractNo = fmidetails.getContractnumber();
		List<PLMDocGenFmiData> searchResultList = new ArrayList<PLMDocGenFmiData>(); 
		LOG.info("Query for Check Existence of Contract No : " + PLMOfflineQueries.GET_CONTRACT_NAME);
		try{
		searchResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_CONTRACT_NAME, new FmiContractMapper(), new Object[] { contractNo });
		if(!PLMUtils.isEmptyList(searchResultList))
			{
			LOG.info("Query for Customer Name and Title : " + PLMOfflineQueries.GET_CUSTOMER_AND_TITLE);
			searchResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_CUSTOMER_AND_TITLE, new FmiTitleMapper(), new Object[] { contractNo });
			if (!PLMUtils.isEmptyList(searchResultList)) {
				fmidetails.setCustomer(searchResultList.get(0).getCustomer());
				fmidetails.setTitle(searchResultList.get(0).getTitle());
			}else{
				fmidetails.setCustomer("");
				fmidetails.setTitle("");
			}
			
			LOG.info("Query for ICNs : " + PLMOfflineQueries.GET_ICNS);
			searchResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_ICNS, new FmiICNMapper(), new Object[] { contractNo });
			if (!PLMUtils.isEmptyList(searchResultList)) {
				StringBuffer tempicn = new StringBuffer();
				for(int i =0 ; i < searchResultList.size(); i++ )
				{
					if(!PLMUtils.isEmpty(searchResultList.get(i).getIcnnumbers()))
					tempicn = tempicn.append(searchResultList.get(i).getIcnnumbers() + ",");
				}
				fmidetails.setIcnnumbers(tempicn.substring(0,tempicn.length() - 1));
			}else{
				fmidetails.setIcnnumbers("");
			}
			
			LOG.info("Query for Req Engineer : " + PLMOfflineQueries.GET_REQENG);
			searchResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_REQENG, new FmiReqEngMapper(), new Object[] { contractNo });
			if (!PLMUtils.isEmptyList(searchResultList)) {
				fmidetails.setReqeng(searchResultList.get(0).getReqeng());
				fmidetails.setReqenglocation(searchResultList.get(0).getReqenglocation());
				fmidetails.setAddress(searchResultList.get(0).getAddress());
				fmidetails.setCity(searchResultList.get(0).getCity());
				fmidetails.setState(searchResultList.get(0).getState());
				fmidetails.setZip(searchResultList.get(0).getZip());
				fmidetails.setCountry(searchResultList.get(0).getCountry());
				fmidetails.setPhone(searchResultList.get(0).getPhone());
				fmidetails.setDialcom(searchResultList.get(0).getDialcom());
				fmidetails.setMsmail(searchResultList.get(0).getMsmail());
				fmidetails.setMobile(searchResultList.get(0).getMobile());
			}else{
				fmidetails.setReqeng("");
				fmidetails.setReqenglocation("");
				fmidetails.setAddress("");
				fmidetails.setCity("");
				fmidetails.setState("");
				fmidetails.setZip("");
				fmidetails.setCountry("");
				fmidetails.setPhone("");
				fmidetails.setDialcom("");
				fmidetails.setMsmail("");
				fmidetails.setMobile("");
			}
			
			LOG.info("Query for Serial Number and  Distribution : " + PLMOfflineQueries.GET_DISTRIBUTION);
			searchResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_DISTRIBUTION, new FmiDistMapper(),new Object[] { contractNo });
			
			List<String> serialNoList = new ArrayList<String>();
			 
			if (!PLMUtils.isEmptyList(searchResultList)) {
				for(int i=0; i< searchResultList.size(); i++){
					serialNoList.add(searchResultList.get(i).getSerialnumbers());
				}
	 			fmidetails.setSerialNoList(serialNoList);
				fmidetails.setAppunits(PLMUtils.convertListToString(serialNoList));
				LOG.info("getting SerialNoList : " +fmidetails.getSerialNoList());
			}
				
			if (!PLMUtils.isEmptyList(searchResultList)) {
				
				Map<String, String> svcMgrInfo = new HashMap<String, String>();
				Map<String, String> srlNumMap = new HashMap<String, String>();
				for(int i=0; i< searchResultList.size(); i++){
					StringBuffer svcMgr = new StringBuffer();;
					svcMgr.append(searchResultList.get(i).getDistribution()).append("\\par ")
					.append(searchResultList.get(i).getDistaddress()).append("\\par ")
					.append(searchResultList.get(i).getDisadddressb()).append("\\par ");
					
					svcMgrInfo.put(searchResultList.get(i).getDistributionSSO(),svcMgr.toString());
					
				}
				
				LOG.info("svcMgrInfo size >>> " + svcMgrInfo.size());
				if (svcMgrInfo.size() > 1) {
					
					for ( Map.Entry< String, String > entry : svcMgrInfo.entrySet() ) {
					
						String svcMgrSSO = entry.getKey();
						StringBuffer srlNums = new StringBuffer();
						for(int j=0; j< searchResultList.size(); j++){
							if (svcMgrSSO.equalsIgnoreCase(searchResultList.get(j).getDistributionSSO())) {
								srlNums.append(searchResultList.get(j).getSerialnumbers())
								.append(", ");							
							}
							
						}	
						srlNumMap.put(svcMgrSSO,srlNums.substring(0, srlNums.length() - 2));
											
					}

					StringBuffer srlNums = new StringBuffer();
					for ( Map.Entry< String, String > entry : svcMgrInfo.entrySet() ) {
						String svcMgrSSO = entry.getKey();	
						srlNums.append("(").append(srlNumMap.get(svcMgrSSO)).append(")").append("\\par ");	
						srlNums.append(svcMgrInfo.get(svcMgrSSO)).append("\\par ");
					}

					fmidetails.setDistribution("");
					fmidetails.setDistaddress("");
					fmidetails.setDisadddressb(srlNums.substring(0, srlNums.length() - 6));
					srlNumMap.clear();
					svcMgrInfo.clear();
					
					/*LOG.info("inside if stmt ");
					Set<String> distKey = svcMgrInfo.keySet();				
					Iterator<String> itrDist = distKey.iterator();
					while(itrDist.hasNext()) {
						
						String svcMgrSSO = itrDist.next();	
						StringBuffer srlNums = new StringBuffer();
						for(int j=0; j< searchResultList.size(); j++){
							if (svcMgrSSO.equalsIgnoreCase(searchResultList.get(j).getDistributionSSO())) {
								srlNums.append(searchResultList.get(j).getSerialnumbers())
								.append(", ");							
							}
							
						}	
						srlNumMap.put(svcMgrSSO,srlNums.substring(0, srlNums.length() - 2));
					}
					
					Iterator<String> itrDistSSO = distKey.iterator();

					StringBuffer srlNums = new StringBuffer();
					while(itrDistSSO.hasNext()) {
						String svcMgrSSO = itrDistSSO.next();	
						srlNums.append("(").append(srlNumMap.get(svcMgrSSO)).append(")").append("\\par ");	
						srlNums.append(svcMgrInfo.get(svcMgrSSO)).append("\\par ");
					}

					fmidetails.setDistribution("");
					fmidetails.setDistaddress("");
					fmidetails.setDisadddressb(srlNums.substring(0, srlNums.length() - 6));
					srlNumMap.clear();
					svcMgrInfo.clear();*/
				} else {
					LOG.info("inside elsse  stmt ");
					fmidetails.setDistribution(searchResultList.get(0).getDistribution());
					fmidetails.setDistaddress(searchResultList.get(0).getDistaddress());
					fmidetails.setDisadddressb(searchResultList.get(0).getDisadddressb());
				}
			}else{
				fmidetails.setDistribution("");
				fmidetails.setDistaddress("");
				fmidetails.setDisadddressb("");
			}
			if (!PLMUtils.isEmptyList(fmidetails.getSerialNoList())) {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("EQPSRLNM", fmidetails.getSerialNoList());	
			LOG.info("Query for Model (Frame Type) : " + PLMOfflineQueries.GET_MODEL);
			searchResultList = getNamedJdbcTemplate().query(PLMOfflineQueries.GET_MODEL,params, new FmiModelMapper());
			if (!PLMUtils.isEmptyList(searchResultList)) {
				fmidetails.setModel(searchResultList.get(0).getModel());
			}else{
				fmidetails.setModel("");
			}
			}else{
				fmidetails.setModel("");
			}
			searchResultList.add(0, fmidetails);
			}
		} catch (DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		}
		LOG.info("Exiting getFmiDetails Method");
		return searchResultList;
	}
	
	/**
	 * @return PLMDocGenFmiData objects.
	 */
	private static final class FmiContractMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
//	private static ParameterizedRowMapper<PLMDocGenFmiData> fmiContractMapper = new ParameterizedRowMapper<PLMDocGenFmiData>() {
		public PLMDocGenFmiData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMDocGenFmiData tempData = new PLMDocGenFmiData();
			tempData.setContractnumber(PLMUtils.checkNullVal(rs.getString("NM")));
			return tempData;
		}
	}
	
	/**
	 * @return PLMDocGenFmiData objects.
	 */
	private static final class FmiTitleMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
//	private static ParameterizedRowMapper<PLMDocGenFmiData> fmiTitleMapper = new ParameterizedRowMapper<PLMDocGenFmiData>() {
		public PLMDocGenFmiData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMDocGenFmiData tempData = new PLMDocGenFmiData();
			tempData.setCustomer(PLMUtils.checkNullVal(rs.getString("CUSTOMER")));
			tempData.setTitle(PLMUtils.checkNullVal(rs.getString("FMI_TITLE")));
			return tempData;
		}
	}
	
	/**
	 * @return PLMDocGenFmiData objects.
	 */
	private static final class FmiICNMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
//	private static ParameterizedRowMapper<PLMDocGenFmiData> fmiICNMapper = new ParameterizedRowMapper<PLMDocGenFmiData>() {
		public PLMDocGenFmiData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMDocGenFmiData tempData = new PLMDocGenFmiData();
			tempData.setIcnnumbers(PLMUtils.checkNullVal(rs.getString("GE_ICN")));
			return tempData;
		}
	}
	
	/**
	 * @return PLMDocGenFmiData objects.
	 */
	private static final class FmiReqEngMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
//	private static ParameterizedRowMapper<PLMDocGenFmiData> fmiReqEngMapper = new ParameterizedRowMapper<PLMDocGenFmiData>() {
		public PLMDocGenFmiData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMDocGenFmiData tempData = new PLMDocGenFmiData();
			tempData.setReqeng(PLMUtils.checkNullVal(rs.getString("REQUISTION_ENGR")));
			tempData.setReqenglocation(PLMUtils.checkNullVal(rs.getString("LOCATION")));
			tempData.setAddress(PLMUtils.checkNullVal(rs.getString("ADDRESS")));
			tempData.setCity(PLMUtils.checkNullVal(rs.getString("CITY")));
			tempData.setState(PLMUtils.checkNullVal(rs.getString("STATE")));
			tempData.setZip(PLMUtils.checkNullVal(rs.getString("ZIP")));
			tempData.setCountry(PLMUtils.checkNullVal(rs.getString("COUNTRY")));
			tempData.setPhone(PLMUtils.checkNullVal(rs.getString("PHONE")));
			tempData.setDialcom(PLMUtils.checkNullVal(rs.getString("DIAL_COM")));
			tempData.setMsmail(PLMUtils.checkNullVal(rs.getString("MSMAIL")));
			tempData.setMobile(PLMUtils.checkNullVal(rs.getString("MOBILE")));
			return tempData;
		}
	}
	
	/**
	 * @return PLMDocGenFmiData objects.
	 */
	private static final class FmiModelMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
//	private static ParameterizedRowMapper<PLMDocGenFmiData> fmiModelMapper = new ParameterizedRowMapper<PLMDocGenFmiData>() {
		public PLMDocGenFmiData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMDocGenFmiData tempData = new PLMDocGenFmiData();
			tempData.setModel(PLMUtils.checkNullVal(rs.getString("FRAME_TYPE")));
			return tempData;
		}
	}
	
	/**
	 * @return PLMDocGenFmiData objects.
	 */
	private static final class FmiDistMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
//	private static ParameterizedRowMapper<PLMDocGenFmiData> fmiDistMapper = new ParameterizedRowMapper<PLMDocGenFmiData>() {
		public PLMDocGenFmiData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMDocGenFmiData tempData = new PLMDocGenFmiData();
			tempData.setSerialnumbers(PLMUtils.checkNullVal(rs.getString("SERIAL_NUMBER")));
			tempData.setDistributionSSO(PLMUtils.checkNullVal(rs.getString("SERVICE_MANAGER_SSO")));
			tempData.setDistribution(PLMUtils.checkNullVal(rs.getString("SERVICE_MANAGER_NAME")));
			tempData.setDistaddress(PLMUtils.checkNullVal(rs.getString("ADDRESS")));
			String addressb = "";
			String city = PLMUtils.checkNullVal(rs.getString("CITY"));
			String state = PLMUtils.checkNullVal(rs.getString("STATE"));
			String country = PLMUtils.checkNullVal(rs.getString("COUNTRY"));
			String zip = PLMUtils.checkNullVal(rs.getString("ZIP"));
			if(!PLMUtils.isEmpty(city))
				addressb = addressb + city + ",";
			if(!PLMUtils.isEmpty(state))
				addressb = addressb + state + ",";
			if(!PLMUtils.isEmpty(country))
				addressb = addressb + country + ",";
			if(!PLMUtils.isEmpty(zip))
				addressb = addressb + zip;
			tempData.setDisadddressb(addressb);
			return tempData;
		}
	}
	
	/**
	 * @return PLMDocGenFmiData objects.
	 */
	private static final class FmiDistCpmMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
//	private static ParameterizedRowMapper<PLMDocGenFmiData> fmiDistCpmMapper = new ParameterizedRowMapper<PLMDocGenFmiData>() {
		public PLMDocGenFmiData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMDocGenFmiData tempData = new PLMDocGenFmiData();
			tempData.setSerialnumbers(PLMUtils.checkNullVal(rs.getString("SERIAL_NUMBER")));
			tempData.setDistcpmSSO(PLMUtils.checkNullVal(rs.getString("CPM_SSO")));
			tempData.setDistcpm(PLMUtils.checkNullVal(rs.getString("CPM_NAME")));
			tempData.setDistaddrcpm(PLMUtils.checkNullVal(rs.getString("ADDRESS")));
			String addressb = "";
			String city = PLMUtils.checkNullVal(rs.getString("CITY"));
			String state = PLMUtils.checkNullVal(rs.getString("STATE"));
			String country = PLMUtils.checkNullVal(rs.getString("COUNTRY"));
			String zip = PLMUtils.checkNullVal(rs.getString("ZIP"));
			if(!PLMUtils.isEmpty(city))
				addressb = addressb + city + ",";
			if(!PLMUtils.isEmpty(state))
				addressb = addressb + state + ",";
			if(!PLMUtils.isEmpty(country))
				addressb = addressb + country + ",";
			if(!PLMUtils.isEmpty(zip))
				addressb = addressb + zip;
			tempData.setDistaddrcpmb(addressb);
			return tempData;
		}
	}

	//Commented the code for On Demand FMI for July Release
	/**
	 * @return String object.
	 */
	/*private static final class UniqueMliMapper implements ParameterizedRowMapper<String> {
		public String mapRow(ResultSet rs, int rowCount) throws SQLException {
			String mli = "";
			mli=PLMUtils.checkNullVal(rs.getString("MLI"));
			return mli;
		}
	}*/
	
	//Commented the code for On Demand FMI for July Release
	/**
	 * @return PLMDocGenFmiData objects.
	 */
	/*private static final class ModifyDescMliMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
		public PLMDocGenFmiData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMDocGenFmiData tempData = new PLMDocGenFmiData();
			tempData.setMlino(PLMUtils.checkNullVal(rs.getString("MLI")));
			tempData.setModifcationDesc(PLMUtils.checkNullVal(rs.getString("MLI_MODIFICATION_DESCRIPTION")));
			return tempData;
		}
	}*/
	
	/**
	 * @return PLMDocGenFmiData objects.
	 */
	private static final class FmiMliMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
//	private static ParameterizedRowMapper<PLMDocGenFmiData> fmiMliMapper = new ParameterizedRowMapper<PLMDocGenFmiData>() {
		public PLMDocGenFmiData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMDocGenFmiData tempData = new PLMDocGenFmiData();
			tempData.setPartAssign(PLMUtils.checkNullVal(rs.getString("ASND_PART")));
			tempData.setMlino(PLMUtils.checkNullVal(rs.getString("MLI")));
			tempData.setPartNum(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
			tempData.setPartRevision(PLMUtils.checkNullVal(rs.getString("PART_REVISION")));
			tempData.setPartState(PLMUtils.checkNullVal(rs.getString("PART_STATE")));
			tempData.setPartQuantity(PLMUtils.convertQtyLimit(rs.getString("PART_QTY")));
			tempData.setUom(PLMUtils.checkNullVal(rs.getString("UOM")));
			tempData.setDocName(PLMUtils.checkNullVal(rs.getString("DOC_NAME")));
			tempData.setDocRev(PLMUtils.checkNullVal(rs.getString("DOC_REVISION")));
			tempData.setDocState(PLMUtils.checkNullVal(rs.getString("DOC_STATE")));
			tempData.setDocDesc(PLMUtils.checkNullVal(rs.getString("DOC_DESCRIPTION")));
			
			//Start: Commented for R# 10863 - Dwg Criticality Code
			//tempData.setNote("+");
			//End: Commented for R# 10863 - Dwg Criticality Code
			
			//Start: Added for R# 10863 - Dwg Criticality Code
			tempData.setNote(PLMUtils.checkNullVal(rs.getString("DWG_CRITICALITY")));
			//End: Added for R# 10863 - Dwg Criticality Code
			
//			tempData.setPartno(PLMUtils.checkNullVal(rs.getString("PART")));
//			tempData.setQty(PLMUtils.checkNullVal(rs.getString("QUANTITY")));
//			tempData.setNomenclature(PLMUtils.checkNullVal(rs.getString("NOMENCLATURE")));
//			tempData.setDrawingno(PLMUtils.checkNullVal(rs.getString("DRAWING#")));
//			tempData.setRevision(PLMUtils.checkNullVal(rs.getString("REVISION")));
//			tempData.setNote("+");
			return tempData;
		}
	}
	/**
	 * @return PLMDocGenFmiData objects.
	 */
	/*private static ParameterizedRowMapper<PLMDocGenFmiData> fmiComDocMapper = new ParameterizedRowMapper<PLMDocGenFmiData>() {
		public PLMDocGenFmiData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMDocGenFmiData tempData = new PLMDocGenFmiData();
			tempData.setMlino(PLMUtils.checkNullVal(rs.getString("MLI")));
			tempData.setPartno(PLMUtils.checkNullVal(rs.getString("PART")));
			tempData.setQty(PLMUtils.checkNullVal(rs.getString("QUANTITY")));
			tempData.setNomenclature(PLMUtils.checkNullVal(rs.getString("NOMENCLATURE")));
			tempData.setComdocno(PLMUtils.checkNullVal(rs.getString("COMDOC#")));
			tempData.setNote("+");
			return tempData;
		}
	};*/
	/**
	 * @return PLMDocGenFmiData objects.
	 */
	private static final class FmiFAMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
//	private static ParameterizedRowMapper<PLMDocGenFmiData> fmiFAMapper = new ParameterizedRowMapper<PLMDocGenFmiData>() {
		public PLMDocGenFmiData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMDocGenFmiData tempData = new PLMDocGenFmiData();
			tempData.setQlcodes(PLMUtils.checkNullVal(rs.getString("MARKETING_FEATURE")));
			tempData.setQldesc(PLMUtils.checkNullVal(rs.getString("MARKETING_FEATURE")) + " - " + PLMUtils.checkNullVal(rs.getString("MARKETING_FEATURE_NAME")));
			return tempData;
		}
	}
	
	//Commented the code for On Demand FMI for July Release
	/**
	 * This method is used to generateFmiDoc
	 * @param fmidetails
	 * @return List
	 * @throws PLMCommonException
	 */
	/*Start Comment 1
	public List<PLMDocGenFmiData> generateFmiDoc(PLMDocGenFmiData fmidetails) throws PLMCommonException {
		LOG.info("Entering generateFmiDoc method");
		String contractNo = fmidetails.getContractnumber();
		//String partNo = fmidetails.getPartNumber();
		String strCurrentDate = DateFormat.getDateInstance().format(new Date());
		fmidetails.setIssued(strCurrentDate);
		fmidetails.setRevision("");
		List<PLMDocGenFmiData> searchResultList = new ArrayList<PLMDocGenFmiData>();
		
		List<List<String>> partSpecIdList = new ArrayList<List<String>>();	
		List<List<String>> eBomIdList = new ArrayList<List<String>>();
		//List<List<String>> partNumList = new ArrayList<List<String>>();
		boolean VTUExecuted = false;
		try{
		LOG.info("Query for Distribution CPM : " + PLMOfflineQueries.GET_DISTRIBUTION_CPM);
		searchResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_DISTRIBUTION_CPM, new FmiDistCpmMapper(),new Object[] { contractNo });
		
		if (!PLMUtils.isEmptyList(searchResultList)) {
			
			Map<String, String> cpmAddrInfo = new HashMap<String, String>();
			Map<String, String> srlNumMap = new HashMap<String, String>();
			for(int i=0; i< searchResultList.size(); i++){
				StringBuffer cpmAddr = new StringBuffer();
				cpmAddr.append(searchResultList.get(i).getDistcpm()).append("\\par ")
				.append(searchResultList.get(i).getDistaddrcpm()).append("\\par ")
				.append(searchResultList.get(i).getDistaddrcpmb()).append("\\par ");
				
				cpmAddrInfo.put(searchResultList.get(i).getDistcpmSSO(),cpmAddr.toString());
				
			}
			
			LOG.info("svcMgrInfo size >>> " + cpmAddrInfo.size());
			if (cpmAddrInfo.size() > 1) {
				
				for ( Map.Entry< String, String > entry : cpmAddrInfo.entrySet() ) {
					
					String cpmSSO = entry.getKey();
					StringBuffer srlNums = new StringBuffer();
					for(int j=0; j< searchResultList.size(); j++){
						if (cpmSSO.equalsIgnoreCase(searchResultList.get(j).getDistcpmSSO())) {
							srlNums.append(searchResultList.get(j).getSerialnumbers())
							.append(", ");							
						}
						
					}	
					srlNumMap.put(cpmSSO,srlNums.substring(0, srlNums.length() - 2));
										
				}

				StringBuffer srlNums = new StringBuffer();
				for ( Map.Entry< String, String > entry : cpmAddrInfo.entrySet() ) {
					String cpmSSO = entry.getKey();	
					srlNums.append("(").append(srlNumMap.get(cpmSSO)).append(")").append("\\par ");	
					srlNums.append(cpmAddrInfo.get(cpmSSO)).append("\\par ");
				}

				fmidetails.setDistcpm("");
				fmidetails.setDistaddrcpm("");
				fmidetails.setDistaddrcpmb(srlNums.substring(0, srlNums.length() - 6));
				srlNumMap.clear();
				cpmAddrInfo.clear();
				
				
				
				/*LOG.info("inside if stmt ");
				Set<String> distKey = cpmAddrInfo.keySet();				
				Iterator<String> itrDist = distKey.iterator();
				while(itrDist.hasNext()) {
					
					String cpmSSO = itrDist.next();	
					StringBuffer srlNums = new StringBuffer();
					for(int j=0; j< searchResultList.size(); j++){
						if (cpmSSO.equalsIgnoreCase(searchResultList.get(j).getDistcpmSSO())) {
							srlNums.append(searchResultList.get(j).getSerialnumbers())
							.append(", ");							
						}
						
					}	
					srlNumMap.put(cpmSSO,srlNums.substring(0, srlNums.length() - 2));
				}
				
				Iterator<String> itrcpmSSO = distKey.iterator();

				StringBuffer srlNums = new StringBuffer();
				while(itrcpmSSO.hasNext()) {
					String cpmSSO = itrcpmSSO.next();	
					srlNums.append("(").append(srlNumMap.get(cpmSSO)).append(")").append("\\par ");	
					srlNums.append(cpmAddrInfo.get(cpmSSO)).append("\\par ");
				}
				
				fmidetails.setDistcpm("");
				fmidetails.setDistaddrcpm("");
				fmidetails.setDistaddrcpmb(srlNums.substring(0, srlNums.length() - 6));
				srlNumMap.clear();
				cpmAddrInfo.clear();*/
/*Comment 2	} else {
				LOG.info("inside elsse  stmt ");
				fmidetails.setDistcpm(searchResultList.get(0).getDistcpm());
				fmidetails.setDistaddrcpm(searchResultList.get(0).getDistaddrcpm());
				fmidetails.setDistaddrcpmb(searchResultList.get(0).getDistaddrcpmb());
			}
		}
		else{
			fmidetails.setDistcpm("");
			fmidetails.setDistaddrcpm("");
			fmidetails.setDistaddrcpmb("");
		}
		String timeStamp = PLMUtils.volTableFormatDate();
		String VT_TEMP_DT = PLMConstants.DGT_VTU.concat(timeStamp);
		String str = PLMOfflineQueries.GET_DGT_VTU.replace(PLMConstants.DGT_VTU, VT_TEMP_DT);
		
		LOG.info("MF/TF Search Report VTU Query is : " + str);
		getJdbcTemplate().execute(str);
		
		VTUExecuted = true;
		if(VTUExecuted){
			LOG.info("Query for Collect STATS DGT_VTU_COL_STATS : " + PLMOfflineQueries.DGT_VTU_COL_STATS.replace(PLMConstants.DGT_VTU, VT_TEMP_DT));
			getJdbcTemplate().execute(PLMOfflineQueries.DGT_VTU_COL_STATS.replace(PLMConstants.DGT_VTU, VT_TEMP_DT));
			LOG.info("Query for Ql Codes and Description ( Features Applied) : " + PLMOfflineQueries.GET_FEATURES_APPLIED.replace(PLMConstants.DGT_VTU, VT_TEMP_DT));
			searchResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_FEATURES_APPLIED.replace(PLMConstants.DGT_VTU, VT_TEMP_DT), new FmiFAMapper(), new Object[] { contractNo });
		}
		
		if (!PLMUtils.isEmptyList(searchResultList)) {
			List<PLMDocGenFmiData> qldescdetailslist = searchResultList;
			StringBuffer strbqldesc = loadQlDesc(qldescdetailslist);
			fmidetails.setQldesc(strbqldesc.toString());
		}else{
			fmidetails.setQlcodes("");
			fmidetails.setQldesc("");
		}


		/* Start : Setting the MLI Table */
		
/*Comment 3	LOG.info("Query for MLI TABLE PART : " +PLMOfflineQueries.GET_MLI_TABLE_PART);
		
		List<List<String>> partNumList =  getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_MLI_TABLE_PART, new PartMapper(), new Object[] { contractNo });
		
		LOG.info("partNumList>>>>>>>>>>>>>>. : " +partNumList);
		
		//Retreiving partSpec formId		
		if(!PLMUtils.isEmptyList(partNumList)){	
			partSpecIdList =  getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_PART_SPEC.replace("?",PLMUtils.setListsForQuery(partNumList))
					, new PartSpecMapper());
			LOG.info("Query for partSpec FormID : " +PLMOfflineQueries.GET_PART_SPEC.replace("?",PLMUtils.setListsForQuery(partNumList)));
			
		}	
		LOG.info("partSpecIdList>>>>>>>>>>>>>>. : " +partSpecIdList);
	
		//Retreiving EBom formId		
		if(!PLMUtils.isEmptyList(partNumList)){			
			eBomIdList =  getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_EBOM.replace("?",PLMUtils.setListsForQuery(partNumList)), new EBomMapper());
			LOG.info("Query for EBom FormID : " +PLMOfflineQueries.GET_EBOM.replace("?",PLMUtils.setListsForQuery(partNumList)));
		}
		LOG.info("eBomIdList>>>>>>>>>>>>>>. : " +eBomIdList);
		// pass multiple partno's to GET_MLI_TABLE_NEW
		
		//Newly updated queries for getting MLI tables
		String VT_MLI_TAB1 = PLMConstants.VT_MLI_TAB1.concat(PLMUtils.volTableFormatDate());
		String VT_MLI_TAB2 = PLMConstants.VT_MLI_TAB2.concat(PLMUtils.volTableFormatDate());
			
		StringBuffer createMLITAB1Qry = new StringBuffer();
		StringBuffer createMLITAB2Qry = new StringBuffer();
		StringBuffer getMLITableQry = new StringBuffer();
		List<String> uniqueMliList = new ArrayList<String>();
		List<PLMDocGenFmiData> modifyDescMliList = new ArrayList<PLMDocGenFmiData>();
		
		if(!PLMUtils.isEmptyList(partSpecIdList) && !PLMUtils.isEmptyList(eBomIdList)){
			
			createMLITAB1Qry.append(PLMOfflineQueries.CREATE_VT_MLI_TAB1_STRT.replace("VT_MLI_TAB1",VT_MLI_TAB1))
			.append(PLMOfflineQueries.GET_MLI_TABLE_OUTER_1)
			.append(PLMOfflineQueries.GET_MLI_TABLE_PTSPC_1)
			.append(PLMUtils.setListsForQuery(partSpecIdList))
			.append(PLMOfflineQueries.GET_MLI_TABLE_PTSPC_2)
			.append(PLMOfflineQueries.GET_MLI_TABLE_UNION)
			.append(PLMOfflineQueries.GET_MLI_TABLE_EBOM_1)
			.append(PLMUtils.setListsForQuery(eBomIdList))
			.append(PLMOfflineQueries.GET_MLI_TABLE_EBOM_2)
			.append(PLMOfflineQueries.GET_MLI_TABLE_OUTER_2)
			.append(PLMOfflineQueries.CREATE_VT_MLI_TAB1_END);
			LOG.info("Query for Creating Volatile VT_MLI_TAB1 for partIds and ebomIds : " + createMLITAB1Qry);
			getJdbcTemplate().execute(createMLITAB1Qry.toString());
			
			createMLITAB2Qry.append(PLMOfflineQueries.CREATE_VT_MLITAB2_ONE.replace("VT_MLI_TAB2",VT_MLI_TAB2)
					.replace("VT_MLI_TAB1",VT_MLI_TAB1).replace("?", "'"+contractNo+"'"));
			LOG.info("Query for Creating Volatile VT_MLI_TAB2 for partIds and ebomIds : " + createMLITAB2Qry);
			getJdbcTemplate().execute(createMLITAB2Qry.toString());
			
			getMLITableQry.append(PLMOfflineQueries.GET_VT_MLI_TABLES_ONE.replace("VT_MLI_TAB2",VT_MLI_TAB2)
					.replace("VT_MLI_TAB1",VT_MLI_TAB1));
		}
		else if (PLMUtils.isEmptyList(partSpecIdList) && !PLMUtils.isEmptyList(eBomIdList)) {
			
			createMLITAB1Qry.append(PLMOfflineQueries.CREATE_VT_MLI_TAB1_STRT.replace("VT_MLI_TAB1",VT_MLI_TAB1))
			.append(PLMOfflineQueries.GET_MLI_TABLE_OUTER_1)
			.append(PLMOfflineQueries.GET_MLI_TABLE_EBOM_1)
			.append(PLMUtils.setListsForQuery(eBomIdList))
			.append(PLMOfflineQueries.GET_MLI_TABLE_EBOM_2)
			.append(PLMOfflineQueries.GET_MLI_TABLE_OUTER_2)
			.append(PLMOfflineQueries.CREATE_VT_MLI_TAB1_END);
			
			LOG.info("Query for Creating Volatile VT_MLI_TAB1 for ebomIds only : " + createMLITAB1Qry);
			getJdbcTemplate().execute(createMLITAB1Qry.toString());
			
			createMLITAB2Qry.append(PLMOfflineQueries.CREATE_VT_MLITAB2_ONE.replace("VT_MLI_TAB2",VT_MLI_TAB2)
					.replace("VT_MLI_TAB1",VT_MLI_TAB1).replace("?", "'"+contractNo+"'"));
			LOG.info("Query for Creating Volatile VT_MLI_TAB2 for ebomIds only : " + createMLITAB2Qry);
			getJdbcTemplate().execute(createMLITAB2Qry.toString());
			
			getMLITableQry.append(PLMOfflineQueries.GET_VT_MLI_TABLES_ONE.replace("VT_MLI_TAB2",VT_MLI_TAB2)
					.replace("VT_MLI_TAB1",VT_MLI_TAB1));
		}
		else if (!PLMUtils.isEmptyList(partSpecIdList) && PLMUtils.isEmptyList(eBomIdList)) {
			
			createMLITAB1Qry.append(PLMOfflineQueries.CREATE_VT_MLI_TAB1_STRT.replace("VT_MLI_TAB1",VT_MLI_TAB1))
			.append(PLMOfflineQueries.GET_MLI_TABLE_OUTER_1)
			.append(PLMOfflineQueries.GET_MLI_TABLE_PTSPC_1)
			.append(PLMUtils.setListsForQuery(partSpecIdList))
			.append(PLMOfflineQueries.GET_MLI_TABLE_PTSPC_2)
			.append(PLMOfflineQueries.GET_MLI_TABLE_OUTER_2)
			.append(PLMOfflineQueries.CREATE_VT_MLI_TAB1_END);
			LOG.info("Query for Creating Volatile VT_MLI_TAB1 for partIds only : " + createMLITAB1Qry);
			getJdbcTemplate().execute(createMLITAB1Qry.toString());
			
			createMLITAB2Qry.append(PLMOfflineQueries.CREATE_VT_MLITAB2_ONE.replace("VT_MLI_TAB2",VT_MLI_TAB2)
					.replace("VT_MLI_TAB1",VT_MLI_TAB1).replace("?", "'"+contractNo+"'"));
			LOG.info("Query for Creating Volatile VT_MLI_TAB2 for partIds only : " + createMLITAB2Qry);
			getJdbcTemplate().execute(createMLITAB2Qry.toString());
			
			getMLITableQry.append(PLMOfflineQueries.GET_VT_MLI_TABLES_ONE.replace("VT_MLI_TAB2",VT_MLI_TAB2)
					.replace("VT_MLI_TAB1",VT_MLI_TAB1));
		}
		List<PLMDocGenFmiData> tempMliResultList = new ArrayList<PLMDocGenFmiData>();
		
		if (getMLITableQry.length()>0) {
	   
	        LOG.info("Query for getting max MLI Modifiy Desc List: " + PLMOfflineQueries.GET_MLI_MAX_DESC_LIST);
	        modifyDescMliList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_MLI_MAX_DESC_LIST, new ModifyDescMliMapper(), new Object[] { contractNo });
			
			LOG.info("Query for MLI TABLE NEW: " + getMLITableQry);
			tempMliResultList = getSimpleJdbcTemplate().query(getMLITableQry.toString(), new FmiMliMapper());
					
			LOG.info("Query for getting unique MLI List: " + PLMOfflineQueries.GET_UNIQUE_MLI_LIST_ONE.replace("VT_MLI_TAB1",VT_MLI_TAB1));
	        uniqueMliList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_UNIQUE_MLI_LIST_ONE.replace("VT_MLI_TAB1",VT_MLI_TAB1)
	        		, new UniqueMliMapper(), new Object[] { contractNo,contractNo });
			
			List<String> mliList = new ArrayList<String>();
			for(PLMDocGenFmiData data : tempMliResultList){
				mliList.add(data.getMlino());
			}
			fmidetails.setMliList(mliList);
			LOG.info("searchResultList: " +tempMliResultList.size());
		} else {

			LOG.info("Query for getting max MLI Modifiy Desc List: " + PLMOfflineQueries.GET_MLI_MAX_DESC_LIST);
	        modifyDescMliList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_MLI_MAX_DESC_LIST, new ModifyDescMliMapper(), new Object[] { contractNo });
			
	    	createMLITAB2Qry.append(PLMOfflineQueries.CREATE_VT_MLITAB2_TWO.replace("VT_MLI_TAB2",VT_MLI_TAB2)
					.replace("?", "'"+contractNo+"'"));
			LOG.info("Query for Creating Volatile VT_MLI_TAB2 with out BomId and SpecId : " + createMLITAB2Qry);
			getJdbcTemplate().execute(createMLITAB2Qry.toString());
			
			LOG.info("Query for MLI TABLE NEW with out BomId and SpecId: " + PLMOfflineQueries.GET_VT_MLI_TABLES_TWO.replace("VT_MLI_TAB2",VT_MLI_TAB2));
			tempMliResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_VT_MLI_TABLES_TWO.replace("VT_MLI_TAB2",VT_MLI_TAB2), new FmiMliMapper());
			
			LOG.info("Query for getting unique MLI List With out BomId and SpecId: " + PLMOfflineQueries.GET_UNIQUE_MLI_LIST_TWO);
	        uniqueMliList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_UNIQUE_MLI_LIST_TWO,new UniqueMliMapper(), new Object[] { contractNo,contractNo });
			
			List<String> mliList = new ArrayList<String>();
			for(PLMDocGenFmiData data : tempMliResultList){
				mliList.add(data.getMlino());
			}
			fmidetails.setMliList(mliList);
			LOG.info("searchResultList: " +tempMliResultList.size());
			
			searchResultList = new ArrayList<PLMDocGenFmiData>();
		}
		
		if(!PLMUtils.isEmptyList(uniqueMliList) && PLMUtils.isEmptyList(tempMliResultList))
		{
			  for(int i=0;i<uniqueMliList.size();i++){
				
					  PLMDocGenFmiData tempData = new PLMDocGenFmiData();
					  tempData.setMlino(uniqueMliList.get(i));
					  tempData.setPartNum("");
					  tempData.setPartRevision("");
					  tempData.setPartState("");
					  tempData.setPartQuantity("");
					  tempData.setUom("");
					  tempData.setDocName("");
					  tempData.setDocRev("");
					  tempData.setDocState("");
					  tempData.setDocDesc("To be Scheduled");
					  tempData.setNote("");
					  tempData.setModifcationDesc("");
					  for(int k=0;k<modifyDescMliList.size();k++){
						  if(uniqueMliList.get(i).equals(modifyDescMliList.get(k).getMlino())){
							  tempData.setModifcationDesc(modifyDescMliList.get(k).getModifcationDesc());
							  break;
						  }
					  }
				      searchResultList.add(tempData);
				  }
			  
			  Map<String, List<PLMDocGenFmiData>> mapVal = new HashMap<String, List<PLMDocGenFmiData>>();
				List<PLMDocGenFmiData> mlidetailslist = new ArrayList<PLMDocGenFmiData>();
				StringBuffer strbMliTable = new StringBuffer();
				StringBuffer strbmlilist = new StringBuffer();
				//List<String> mliStringList = new ArrayList<String>();
				String asgnPartPrev=null;
				String asgnPartCur = null;
				for(int i = 0; i<searchResultList.size();i++ )
				{
					PLMDocGenFmiData tempmlidetails = new PLMDocGenFmiData();
					asgnPartCur = searchResultList.get(i).getPartAssign();
					//LOG.info("asgnPartCur >> " + asgnPartCur);
					tempmlidetails.setMlino(searchResultList.get(i).getMlino());
					tempmlidetails.setPartNum(searchResultList.get(i).getPartNum());
					tempmlidetails.setPartRevision(searchResultList.get(i).getPartRevision());
					tempmlidetails.setPartState(searchResultList.get(i).getPartState());
					tempmlidetails.setPartQuantity(searchResultList.get(i).getPartQuantity());
					tempmlidetails.setUom(searchResultList.get(i).getUom());
					tempmlidetails.setDocName(searchResultList.get(i).getDocName());
					tempmlidetails.setDocRev(searchResultList.get(i).getDocRev());
					tempmlidetails.setDocState(searchResultList.get(i).getDocState());
					tempmlidetails.setDocDesc(searchResultList.get(i).getDocDesc());
					tempmlidetails.setNote(searchResultList.get(i).getNote());
					tempmlidetails.setModifcationDesc(searchResultList.get(i).getModifcationDesc());
					mlidetailslist.add(tempmlidetails);
					
					//cond starts here
					if(asgnPartPrev!=null && !asgnPartPrev.equalsIgnoreCase(asgnPartCur)){
						List<PLMDocGenFmiData> mlDtlsListFn = new ArrayList<PLMDocGenFmiData>();
						mlDtlsListFn.addAll(mlidetailslist);
						
						mapVal.put(asgnPartPrev, mlDtlsListFn);
						LOG.info("asgnPartPrev >>> " + asgnPartPrev);
						LOG.info("mlDtlsListFn size$$$ >>> " + mlDtlsListFn.size());
						
						mlidetailslist.clear();
					}
					
					if (i == searchResultList.size() - 1) {
						mapVal.put(asgnPartPrev, mlidetailslist);		
					}
					asgnPartPrev = asgnPartCur;
					// cond ends here
				}
				
				LOG.info("mapVal size >>> " + mapVal.size());
				for(Map.Entry<String, List<PLMDocGenFmiData>> entry : mapVal.entrySet()) {
					LOG.info("entry.getKey() >>>> " + entry.getKey());
					mlidetailslist = mapVal.get(entry.getKey());
					LOG.info("mlidetailslist size >>>> " + mlidetailslist.size());
					Collections.sort(mlidetailslist, new SortFMIData()); //Sorting mlidetailslist
					strbMliTable = loadMliTable1and2(mlidetailslist, strbMliTable);
					fmidetails.setTempMlidetailslist(mlidetailslist);
					//mliStringList.add(strbMliTable.toString());
					
					/* Setting the MLI List */
/*					LOG.info("mlidetailslist size before loadMliList >>>> " + mlidetailslist.size());
//					strbmlilist = loadMliList(mlidetailslist, strbmlilist);
					LOG.info("strbmlilist length >>>> " + strbmlilist.length());
				}
				fmidetails.setMlitable(strbMliTable.toString());
//				fmidetails.setMlilist(strbmlilist.toString());
				/* Setting the MLI List */
	
/*Comment 4		}
		else if (!PLMUtils.isEmptyList(tempMliResultList)) {
			
			  if(!PLMUtils.isEmptyList(uniqueMliList)){
				  
				  for(int i=0;i<uniqueMliList.size();i++){
					  
					  boolean mliFlag=false;
					  
					  for(int j=0;j<tempMliResultList.size();j++){
						 
						  if(uniqueMliList.get(i).equals(tempMliResultList.get(j).getMlino())){
							  PLMDocGenFmiData tempData = new PLMDocGenFmiData();
							  tempData.setMlino(tempMliResultList.get(j).getMlino());
							  tempData.setPartNum(tempMliResultList.get(j).getPartNum());
							  tempData.setPartRevision(tempMliResultList.get(j).getPartRevision());
							  tempData.setPartState(tempMliResultList.get(j).getPartState());
							  tempData.setPartQuantity(tempMliResultList.get(j).getPartQuantity());
							  tempData.setUom(tempMliResultList.get(j).getUom());
							  tempData.setDocName(tempMliResultList.get(j).getDocName());
							  tempData.setDocRev(tempMliResultList.get(j).getDocRev());
							  tempData.setDocState(tempMliResultList.get(j).getDocState());
							  tempData.setDocDesc(tempMliResultList.get(j).getDocDesc());
							  tempData.setNote(tempMliResultList.get(j).getNote());
							  
							  for(int k=0;k<modifyDescMliList.size();k++){
								  if(uniqueMliList.get(i).equals(modifyDescMliList.get(k).getMlino())){
									  tempData.setModifcationDesc(modifyDescMliList.get(k).getModifcationDesc());
									  break;
								  }
							  }
							  
						      searchResultList.add(tempData);
						      mliFlag=true;
						  }
					  }
					  
					  if(!mliFlag){
						  PLMDocGenFmiData tempData = new PLMDocGenFmiData();
						  tempData.setMlino(uniqueMliList.get(i));
						  tempData.setPartNum("");
						  tempData.setPartRevision("");
						  tempData.setPartState("");
						  tempData.setPartQuantity("");
						  tempData.setUom("");
						  tempData.setDocName("");
						  tempData.setDocRev("");
						  tempData.setDocState("");
						  tempData.setDocDesc("To be Scheduled");
						  tempData.setNote("");
						  tempData.setModifcationDesc("");
					      searchResultList.add(tempData);
					  }
				  }
				  
			  }else{
				  searchResultList.addAll(tempMliResultList);
			  }
			
			Map<String, List<PLMDocGenFmiData>> mapVal = new HashMap<String, List<PLMDocGenFmiData>>();
			List<PLMDocGenFmiData> mlidetailslist = new ArrayList<PLMDocGenFmiData>();
			StringBuffer strbMliTable = new StringBuffer();
			StringBuffer strbmlilist = new StringBuffer();
			//List<String> mliStringList = new ArrayList<String>();
			String asgnPartPrev=null;
			String asgnPartCur = null;
			for(int i = 0; i<searchResultList.size();i++ )
			{
				PLMDocGenFmiData tempmlidetails = new PLMDocGenFmiData();
				asgnPartCur = searchResultList.get(i).getPartAssign();
				//LOG.info("asgnPartCur >> " + asgnPartCur);
				tempmlidetails.setMlino(searchResultList.get(i).getMlino());
				tempmlidetails.setPartNum(searchResultList.get(i).getPartNum());
				tempmlidetails.setPartRevision(searchResultList.get(i).getPartRevision());
				tempmlidetails.setPartState(searchResultList.get(i).getPartState());
				tempmlidetails.setPartQuantity(searchResultList.get(i).getPartQuantity());
				tempmlidetails.setUom(searchResultList.get(i).getUom());
				tempmlidetails.setDocName(searchResultList.get(i).getDocName());
				tempmlidetails.setDocRev(searchResultList.get(i).getDocRev());
				tempmlidetails.setDocState(searchResultList.get(i).getDocState());
				tempmlidetails.setDocDesc(searchResultList.get(i).getDocDesc());
				tempmlidetails.setNote(searchResultList.get(i).getNote());
				tempmlidetails.setModifcationDesc(searchResultList.get(i).getModifcationDesc());
				mlidetailslist.add(tempmlidetails);
				
				//cond starts here
				if(asgnPartPrev!=null && !asgnPartPrev.equalsIgnoreCase(asgnPartCur)){
					List<PLMDocGenFmiData> mlDtlsListFn = new ArrayList<PLMDocGenFmiData>();
					mlDtlsListFn.addAll(mlidetailslist);
					
					mapVal.put(asgnPartPrev, mlDtlsListFn);
					LOG.info("asgnPartPrev >>> " + asgnPartPrev);
					LOG.info("mlDtlsListFn size$$$ >>> " + mlDtlsListFn.size());
					
					mlidetailslist.clear();
				}
				
				if (i == searchResultList.size() - 1) {
					mapVal.put(asgnPartPrev, mlidetailslist);		
				}
				asgnPartPrev = asgnPartCur;
				// cond ends here
			}
			
			LOG.info("mapVal size >>> " + mapVal.size());
			for(Map.Entry<String, List<PLMDocGenFmiData>> entry : mapVal.entrySet()) {
				LOG.info("entry.getKey() >>>> " + entry.getKey());
				mlidetailslist = mapVal.get(entry.getKey());
				LOG.info("mlidetailslist size >>>> " + mlidetailslist.size());
				Collections.sort(mlidetailslist, new SortFMIData()); //Sorting mlidetailslist
				strbMliTable = loadMliTable1and2(mlidetailslist, strbMliTable);
				fmidetails.setTempMlidetailslist(mlidetailslist);
				//mliStringList.add(strbMliTable.toString());
				
				/* Setting the MLI List */
/*				LOG.info("mlidetailslist size before loadMliList >>>> " + mlidetailslist.size());
//				strbmlilist = loadMliList(mlidetailslist, strbmlilist);
				LOG.info("strbmlilist length >>>> " + strbmlilist.length());
			}
			fmidetails.setMlitable(strbMliTable.toString());
//			fmidetails.setMlilist(strbmlilist.toString());
			/* Setting the MLI List */
/*Comment 5		}		
		else{
			fmidetails.setMlitable("");
			fmidetails.setMlilist("");
		}
		
		//Newly Added Query for Material Shipping Sales order
		LOG.info("Query for Material Shipping Sales Order: " + PLMOfflineQueries.GET_MATERIAL_SALESORDER);
		List<String> salesOrderList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_MATERIAL_SALESORDER, new MaterialSalesOrder() , new Object[] { contractNo });
		
		//Newly Added by srinivas for 3.0.7 release 
		
		//Updating Query for applying sales order List
		if(!PLMUtils.isEmptyList(salesOrderList)){
			LOG.info("salesOrderList: " +salesOrderList.size());
			Map<String, Object> params = new HashMap<String, Object>();
			StringBuffer strMaterialTable = new StringBuffer();
			LOG.info("Query for Material Shipping TABLE NEW: " + PLMOfflineQueries.GET_MATERIAL_SHIPPING_DATA);
			params.put("CNTRT", contractNo);
			params.put("SALESLIST", salesOrderList);
			List<PLMDocGenFmiData> materialShpList =getNamedJdbcTemplate().query(PLMOfflineQueries.GET_MATERIAL_SHIPPING_DATA,params, new MtrlShpMapper()); 
			Collections.sort(materialShpList, new SortMatShipData());
			LOG.info("MaterailShpList: " +materialShpList.size());
			 
			if (!PLMUtils.isEmptyList(materialShpList)) {
					strMaterialTable = loadMaterialShipTable(materialShpList, strMaterialTable);
		     }
			fmidetails.setMaterialShipTable(strMaterialTable.toString());
		 }
		
		/* End : Setting the MLI Table */
			
/*Comment 6		fmidetails.setSplnotestext("");
		fmidetails.setInrs("");
		fmidetails.setInfs("");
		fmidetails.setGeitable("");
		
		//Added by Raju
		if(!PLMUtils.isEmptyList(eBomIdList)){
			StringBuffer strbEbomTable = new StringBuffer();
			for (int i=0;i<eBomIdList.size();i++) {
				List<String> ebomIdList = eBomIdList.get(i);
				if (!PLMUtils.isEmptyList(ebomIdList)) {
					String ebomId = ebomIdList.get(0);
					List<PLMDocGenFmiData> ebomResultList = fetchEbomData(ebomId,fmidetails.getDrpDwnLvl());
					if (!PLMUtils.isEmptyList(ebomResultList)) {
						strbEbomTable = loadEbomTable(ebomResultList,strbEbomTable);
					}
				}
			}
			fmidetails.setEbomTable(PLMUtils.checkNullVal(strbEbomTable.toString()));
		}
		//Added by Raju
		List<PLMDocGenFmiData> reqmntDataList = new ArrayList<PLMDocGenFmiData>();
		List<PLMDocGenFmiData> ceiDataList = new ArrayList<PLMDocGenFmiData>();
		List<String> reqNameList = new ArrayList<String>();
		List<String> ceiList = new ArrayList<String>();
		if(!PLMUtils.isEmpty(contractNo)){
				reqmntDataList = fetchReqData(contractNo);
				ceiDataList = fetchCeiData(contractNo);	
		}
		for(PLMDocGenFmiData data : reqmntDataList){
			reqNameList.add(data.getReqNm());
		}
		for(PLMDocGenFmiData data : ceiDataList){
			ceiList.add(data.getCiNum());
		}
		fmidetails.setQlcodes(PLMUtils.convertListToString(reqNameList));
		fmidetails.setReqList(reqNameList);
		fmidetails.setCeiList(ceiList);
		fmidetails.setTempCeiDataList(ceiDataList);
				
		
		//End Raju
		
		searchResultList.add(0, fmidetails);
	   
		} catch (DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		} 
		LOG.info("Exiting generateFmiDoc method");
		return searchResultList;
	}End Comment*/
	
	/**
	 * This method is used to generateFmiDoc
	 * @param fmidetails
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMDocGenFmiData> generateFmiDoc(PLMDocGenFmiData fmidetails) throws PLMCommonException {
		LOG.info("Entering generateFmiDoc method");
		String contractNo = fmidetails.getContractnumber();
		//String partNo = fmidetails.getPartNumber();
		String strCurrentDate = DateFormat.getDateInstance().format(new Date());
		fmidetails.setIssued(strCurrentDate);
		fmidetails.setRevision("");
		List<PLMDocGenFmiData> searchResultList = new ArrayList<PLMDocGenFmiData>();
		
		List<List<String>> partSpecIdList = new ArrayList<List<String>>();	
		List<List<String>> eBomIdList = new ArrayList<List<String>>();
		//List<List<String>> partNumList = new ArrayList<List<String>>();
		boolean VTUExecuted = false;
		try{
		LOG.info("Query for Distribution CPM : " + PLMOfflineQueries.GET_DISTRIBUTION_CPM);
		searchResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_DISTRIBUTION_CPM, new FmiDistCpmMapper(),new Object[] { contractNo });
		
		if (!PLMUtils.isEmptyList(searchResultList)) {
			
			Map<String, String> cpmAddrInfo = new HashMap<String, String>();
			Map<String, String> srlNumMap = new HashMap<String, String>();
			for(int i=0; i< searchResultList.size(); i++){
				StringBuffer cpmAddr = new StringBuffer();
				cpmAddr.append(searchResultList.get(i).getDistcpm()).append("\\par ")
				.append(searchResultList.get(i).getDistaddrcpm()).append("\\par ")
				.append(searchResultList.get(i).getDistaddrcpmb()).append("\\par ");
				
				cpmAddrInfo.put(searchResultList.get(i).getDistcpmSSO(),cpmAddr.toString());
				
			}
			
			LOG.info("svcMgrInfo size >>> " + cpmAddrInfo.size());
			if (cpmAddrInfo.size() > 1) {
				
				for ( Map.Entry< String, String > entry : cpmAddrInfo.entrySet() ) {
					
					String cpmSSO = entry.getKey();
					StringBuffer srlNums = new StringBuffer();
					for(int j=0; j< searchResultList.size(); j++){
						if (cpmSSO.equalsIgnoreCase(searchResultList.get(j).getDistcpmSSO())) {
							srlNums.append(searchResultList.get(j).getSerialnumbers())
							.append(", ");							
						}
						
					}	
					srlNumMap.put(cpmSSO,srlNums.substring(0, srlNums.length() - 2));
										
				}

				StringBuffer srlNums = new StringBuffer();
				for ( Map.Entry< String, String > entry : cpmAddrInfo.entrySet() ) {
					String cpmSSO = entry.getKey();	
					srlNums.append("(").append(srlNumMap.get(cpmSSO)).append(")").append("\\par ");	
					srlNums.append(cpmAddrInfo.get(cpmSSO)).append("\\par ");
				}

				fmidetails.setDistcpm("");
				fmidetails.setDistaddrcpm("");
				fmidetails.setDistaddrcpmb(srlNums.substring(0, srlNums.length() - 6));
				srlNumMap.clear();
				cpmAddrInfo.clear();
				
				
				
				/*LOG.info("inside if stmt ");
				Set<String> distKey = cpmAddrInfo.keySet();				
				Iterator<String> itrDist = distKey.iterator();
				while(itrDist.hasNext()) {
					
					String cpmSSO = itrDist.next();	
					StringBuffer srlNums = new StringBuffer();
					for(int j=0; j< searchResultList.size(); j++){
						if (cpmSSO.equalsIgnoreCase(searchResultList.get(j).getDistcpmSSO())) {
							srlNums.append(searchResultList.get(j).getSerialnumbers())
							.append(", ");							
						}
						
					}	
					srlNumMap.put(cpmSSO,srlNums.substring(0, srlNums.length() - 2));
				}
				
				Iterator<String> itrcpmSSO = distKey.iterator();

				StringBuffer srlNums = new StringBuffer();
				while(itrcpmSSO.hasNext()) {
					String cpmSSO = itrcpmSSO.next();	
					srlNums.append("(").append(srlNumMap.get(cpmSSO)).append(")").append("\\par ");	
					srlNums.append(cpmAddrInfo.get(cpmSSO)).append("\\par ");
				}
				
				fmidetails.setDistcpm("");
				fmidetails.setDistaddrcpm("");
				fmidetails.setDistaddrcpmb(srlNums.substring(0, srlNums.length() - 6));
				srlNumMap.clear();
				cpmAddrInfo.clear();*/
			} else {
				LOG.info("inside elsse  stmt ");
				fmidetails.setDistcpm(searchResultList.get(0).getDistcpm());
				fmidetails.setDistaddrcpm(searchResultList.get(0).getDistaddrcpm());
				fmidetails.setDistaddrcpmb(searchResultList.get(0).getDistaddrcpmb());
			}
		}
		else{
			fmidetails.setDistcpm("");
			fmidetails.setDistaddrcpm("");
			fmidetails.setDistaddrcpmb("");
		}
		String timeStamp = PLMUtils.volTableFormatDate();
		String VT_TEMP_DT = PLMConstants.DGT_VTU.concat(timeStamp);
		String str = PLMOfflineQueries.GET_DGT_VTU.replace(PLMConstants.DGT_VTU, VT_TEMP_DT);
		
		LOG.info("MF/TF Search Report VTU Query is : " + str);
		getJdbcTemplate().execute(str);
		
		VTUExecuted = true;
		if(VTUExecuted){
			LOG.info("Query for Collect STATS DGT_VTU_COL_STATS : " + PLMOfflineQueries.DGT_VTU_COL_STATS.replace(PLMConstants.DGT_VTU, VT_TEMP_DT));
			getJdbcTemplate().execute(PLMOfflineQueries.DGT_VTU_COL_STATS.replace(PLMConstants.DGT_VTU, VT_TEMP_DT));
			LOG.info("Query for Ql Codes and Description ( Features Applied) : " + PLMOfflineQueries.GET_FEATURES_APPLIED.replace(PLMConstants.DGT_VTU, VT_TEMP_DT));
			searchResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_FEATURES_APPLIED.replace(PLMConstants.DGT_VTU, VT_TEMP_DT), new FmiFAMapper(), new Object[] { contractNo });
		}
		
		if (!PLMUtils.isEmptyList(searchResultList)) {
			List<PLMDocGenFmiData> qldescdetailslist = searchResultList;
			StringBuffer strbqldesc = loadQlDesc(qldescdetailslist);
			fmidetails.setQldesc(strbqldesc.toString());
		}else{
			fmidetails.setQlcodes("");
			fmidetails.setQldesc("");
		}


		/* Start : Setting the MLI Table */
		
		LOG.info("Query for MLI TABLE PART : " +PLMOfflineQueries.GET_MLI_TABLE_PART);
		
		List<List<String>> partNumList =  getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_MLI_TABLE_PART, new PartMapper(), new Object[] { contractNo });
		
		LOG.info("partNumList>>>>>>>>>>>>>>. : " +partNumList);
		
		//Retreiving partSpec formId		
		if(!PLMUtils.isEmptyList(partNumList)){	
			partSpecIdList =  getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_PART_SPEC.replace("?",PLMUtils.setListsForQuery(partNumList))
					, new PartSpecMapper());
			LOG.info("Query for partSpec FormID : " +PLMOfflineQueries.GET_PART_SPEC.replace("?",PLMUtils.setListsForQuery(partNumList)));
			
		}	
		LOG.info("partSpecIdList>>>>>>>>>>>>>>. : " +partSpecIdList);
	
		//Retreiving EBom formId		
		if(!PLMUtils.isEmptyList(partNumList)){			
			eBomIdList =  getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_EBOM.replace("?",PLMUtils.setListsForQuery(partNumList)), new EBomMapper());
			LOG.info("Query for EBom FormID : " +PLMOfflineQueries.GET_EBOM.replace("?",PLMUtils.setListsForQuery(partNumList)));
		}
		LOG.info("eBomIdList>>>>>>>>>>>>>>. : " +eBomIdList);
		// pass multiple partno's to GET_MLI_TABLE_NEW
			
		StringBuffer getMLITableQry = new StringBuffer();
			
		if(!PLMUtils.isEmptyList(partSpecIdList) && !PLMUtils.isEmptyList(eBomIdList)){
			
			getMLITableQry.append(PLMOfflineQueries.GET_MLI_TABLE_OUTER_1)
			.append(PLMOfflineQueries.GET_MLI_TABLE_PTSPC_1)
			.append(PLMUtils.setListsForQuery(partSpecIdList))
			.append(PLMOfflineQueries.GET_MLI_TABLE_PTSPC_2)
			.append(PLMOfflineQueries.GET_MLI_TABLE_UNION)
			.append(PLMOfflineQueries.GET_MLI_TABLE_EBOM_1)
			.append(PLMUtils.setListsForQuery(eBomIdList))
			.append(")")
			//.append(PLMOfflineQueries.GET_MLI_TABLE_EBOM_2)
			.append(PLMOfflineQueries.GET_MLI_TABLE_OUTER_2);
			}
		else if (PLMUtils.isEmptyList(partSpecIdList) && !PLMUtils.isEmptyList(eBomIdList)) {
			
			getMLITableQry.append(PLMOfflineQueries.GET_MLI_TABLE_OUTER_1)
			.append(PLMOfflineQueries.GET_MLI_TABLE_EBOM_1)
			.append(PLMUtils.setListsForQuery(eBomIdList))
			.append(")")
			//.append(PLMOfflineQueries.GET_MLI_TABLE_EBOM_2)
			.append(PLMOfflineQueries.GET_MLI_TABLE_OUTER_2);
		}
		else if (!PLMUtils.isEmptyList(partSpecIdList) && PLMUtils.isEmptyList(eBomIdList)) {
			
			getMLITableQry.append(PLMOfflineQueries.GET_MLI_TABLE_OUTER_1)
			.append(PLMOfflineQueries.GET_MLI_TABLE_PTSPC_1)
			.append(PLMUtils.setListsForQuery(partSpecIdList))
			.append(PLMOfflineQueries.GET_MLI_TABLE_PTSPC_2)
			.append(PLMOfflineQueries.GET_MLI_TABLE_OUTER_2);
		}

		if (getMLITableQry.length()>0) {
		LOG.info("Query for MLI TABLE NEW: " + getMLITableQry);
		searchResultList = getSimpleJdbcTemplate().query(getMLITableQry.toString(), new FmiMliMapper());
		List<String> mliList = new ArrayList<String>();
		for(PLMDocGenFmiData data : searchResultList){
			mliList.add(data.getMlino());
		}
		fmidetails.setMliList(mliList);
		LOG.info("searchResultList: " +searchResultList.size());
		} else {
			searchResultList = new ArrayList<PLMDocGenFmiData>();
		}
		
		if (!PLMUtils.isEmptyList(searchResultList)) {
			Map<String, List<PLMDocGenFmiData>> mapVal = new HashMap<String, List<PLMDocGenFmiData>>();
			List<PLMDocGenFmiData> mlidetailslist = new ArrayList<PLMDocGenFmiData>();
			StringBuffer strbMliTable = new StringBuffer();
			StringBuffer strbmlilist = new StringBuffer();
			//List<String> mliStringList = new ArrayList<String>();
			String asgnPartPrev=null;
			String asgnPartCur = null;
			for(int i = 0; i<searchResultList.size();i++ )
			{
				PLMDocGenFmiData tempmlidetails = new PLMDocGenFmiData();
				asgnPartCur = searchResultList.get(i).getPartAssign();
				//LOG.info("asgnPartCur >> " + asgnPartCur);
				tempmlidetails.setMlino(searchResultList.get(i).getMlino());
				tempmlidetails.setPartNum(searchResultList.get(i).getPartNum());
				tempmlidetails.setPartRevision(searchResultList.get(i).getPartRevision());
				tempmlidetails.setPartState(searchResultList.get(i).getPartState());
				tempmlidetails.setPartQuantity(searchResultList.get(i).getPartQuantity());
				tempmlidetails.setUom(searchResultList.get(i).getUom());
				tempmlidetails.setDocName(searchResultList.get(i).getDocName());
				tempmlidetails.setDocRev(searchResultList.get(i).getDocRev());
				tempmlidetails.setDocState(searchResultList.get(i).getDocState());
				tempmlidetails.setDocDesc(searchResultList.get(i).getDocDesc());
				tempmlidetails.setNote(searchResultList.get(i).getNote());
				mlidetailslist.add(tempmlidetails);
				
				//cond starts here
				if(asgnPartPrev!=null && !asgnPartPrev.equalsIgnoreCase(asgnPartCur)){
					List<PLMDocGenFmiData> mlDtlsListFn = new ArrayList<PLMDocGenFmiData>();
					mlDtlsListFn.addAll(mlidetailslist);
					
					mapVal.put(asgnPartPrev, mlDtlsListFn);
					LOG.info("asgnPartPrev >>> " + asgnPartPrev);
					LOG.info("mlDtlsListFn size$$$ >>> " + mlDtlsListFn.size());
					
					mlidetailslist.clear();
				}
				
				if (i == searchResultList.size() - 1) {
					mapVal.put(asgnPartPrev, mlidetailslist);		
				}
				asgnPartPrev = asgnPartCur;
				// cond ends here
			}
			
			LOG.info("mapVal size >>> " + mapVal.size());
			for(Map.Entry<String, List<PLMDocGenFmiData>> entry : mapVal.entrySet()) {
				LOG.info("entry.getKey() >>>> " + entry.getKey());
				mlidetailslist = mapVal.get(entry.getKey());
				LOG.info("mlidetailslist size >>>> " + mlidetailslist.size());
				Collections.sort(mlidetailslist, new SortFMIData()); //Sorting mlidetailslist
				strbMliTable = loadMliTable1and2(mlidetailslist, strbMliTable);
				fmidetails.setTempMlidetailslist(mlidetailslist);
				//mliStringList.add(strbMliTable.toString());
				
				/* Setting the MLI List */
				LOG.info("mlidetailslist size before loadMliList >>>> " + mlidetailslist.size());
//				strbmlilist = loadMliList(mlidetailslist, strbmlilist);
				LOG.info("strbmlilist length >>>> " + strbmlilist.length());
			}
			fmidetails.setMlitable(strbMliTable.toString());
//			fmidetails.setMlilist(strbmlilist.toString());
			/* Setting the MLI List */
		}else{
			fmidetails.setMlitable("");
			fmidetails.setMlilist("");
		}
		
		//Newly Added Query for Material Shipping Sales order
		LOG.info("Query for Material Shipping Sales Order: " + PLMOfflineQueries.GET_MATERIAL_SALESORDER);
		List<String> salesOrderList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_MATERIAL_SALESORDER, new MaterialSalesOrder() , new Object[] { contractNo });
		
		//Newly Added by srinivas for 3.0.7 release 
		
		//Updating Query for applying sales order List
		if(!PLMUtils.isEmptyList(salesOrderList)){
			LOG.info("salesOrderList: " +salesOrderList.size());
			Map<String, Object> params = new HashMap<String, Object>();
			StringBuffer strMaterialTable = new StringBuffer();
			LOG.info("Query for Material Shipping TABLE NEW: " + PLMOfflineQueries.GET_MATERIAL_SHIPPING_DATA);
			params.put("CNTRT", contractNo);
			params.put("SALESLIST", salesOrderList);
			List<PLMDocGenFmiData> materialShpList =getNamedJdbcTemplate().query(PLMOfflineQueries.GET_MATERIAL_SHIPPING_DATA,params, new MtrlShpMapper()); 
			Collections.sort(materialShpList, new SortMatShipData());
			LOG.info("MaterailShpList: " +materialShpList.size());
			 
			if (!PLMUtils.isEmptyList(materialShpList)) {
					strMaterialTable = loadMaterialShipTable(materialShpList, strMaterialTable);
		     }
			fmidetails.setMaterialShipTable(strMaterialTable.toString());
		 }
		
		/* End : Setting the MLI Table */
			
		fmidetails.setSplnotestext("");
		fmidetails.setInrs("");
		fmidetails.setInfs("");
		fmidetails.setGeitable("");
		
		//Added by Raju
		if(!PLMUtils.isEmptyList(eBomIdList)){
			StringBuffer strbEbomTable = new StringBuffer();
			for (int i=0;i<eBomIdList.size();i++) {
				List<String> ebomIdList = eBomIdList.get(i);
				if (!PLMUtils.isEmptyList(ebomIdList)) {
					String ebomId = ebomIdList.get(0);
					List<PLMDocGenFmiData> ebomResultList = fetchEbomData(ebomId,fmidetails.getDrpDwnLvl());
					if (!PLMUtils.isEmptyList(ebomResultList)) {
						strbEbomTable = loadEbomTable(ebomResultList,strbEbomTable);
					}
				}
			}
			fmidetails.setEbomTable(PLMUtils.checkNullVal(strbEbomTable.toString()));
		}
		
		//Added by Raju
		List<PLMDocGenFmiData> reqmntDataList = new ArrayList<PLMDocGenFmiData>();
		List<PLMDocGenFmiData> ceiDataList = new ArrayList<PLMDocGenFmiData>();
		List<String> reqNameList = new ArrayList<String>();
		List<String> ceiList = new ArrayList<String>();
		if(!PLMUtils.isEmpty(contractNo)){
				reqmntDataList = fetchReqData(contractNo);
				ceiDataList = fetchCeiData(contractNo);	
		}
		for(PLMDocGenFmiData data : reqmntDataList){
			reqNameList.add(data.getReqNm());
		}
		for(PLMDocGenFmiData data : ceiDataList){
			ceiList.add(data.getCiNum());
		}
		fmidetails.setQlcodes(PLMUtils.convertListToString(reqNameList));
		fmidetails.setReqList(reqNameList);
		fmidetails.setCeiList(ceiList);
		fmidetails.setTempCeiDataList(ceiDataList);
				
		
		//End Raju
		
		searchResultList.add(0, fmidetails);
	   
		} catch (DataAccessException e){
			PLMUtils.checkException(e.getMessage());
		} 
		LOG.info("Exiting generateFmiDoc method");
		return searchResultList;
	}
	
	/**
	 * 
	 * class to sort list of object of type PLMDocGenFmiData.
	 * 
	 */
	private static class SortMatShipData implements Comparator<PLMDocGenFmiData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMDocGenFmiData aString,
				PLMDocGenFmiData bString) {
			
			int result= aString.getMaterialOrder().compareTo(bString.getMaterialOrder());
		       if (result != 0)
		       {
		           return result;
		       }
		       return aString.getMaterialErpLineNum() - bString.getMaterialErpLineNum();
			
		}
	}
	/**
	 * @return  objects.
	 */
	private static final class MaterialSalesOrder implements ParameterizedRowMapper<String> {
		public String mapRow(ResultSet rs, int rowcount)
				throws SQLException {
			String salesOrder = rs.getString(PLMUtils.checkNullVal("SALES_ORDER"));
			return salesOrder;
		}
	}
	/**
	 * This method is used to loadMliTable1and2
	 * @param mlidetailslist, strMliTable
	 * @return StringBuffer
	 */
	public StringBuffer loadMaterialShipTable(List<PLMDocGenFmiData> materialShpList, StringBuffer strMaterialTable) {
		strMaterialTable.append("\\par ");
		strMaterialTable.append("}\\trowd \\trgaph108\\");
		strMaterialTable.append("trleft200\\trbrdrt\\brdrs\\brdrw15 ");
		strMaterialTable.append("\\trbrdrl");
		strMaterialTable.append("\\brdrs\\brdrw15 \\trbrdrb\\brdrs");
		strMaterialTable.append("\\brdrw15 \\");
		strMaterialTable.append("trbrdrr\\brdrs\\brdrw15 \\");
		strMaterialTable.append("trbrdrh\\brdrs\\");
		strMaterialTable.append("brdrw15 \\trbrdrv\\brdrs\\");
		strMaterialTable.append("brdrw15 \\");
	
		//--Name
		strMaterialTable.append("clvertalt\\clbrdrt\\brdrs\\");
		strMaterialTable.append("brdrw15 \\clbrdrl");
		strMaterialTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
		strMaterialTable.append("brdrs\\brdrw15 \\");
		strMaterialTable.append("clbrdrr\\brdrs\\brdrw15 \\");
		strMaterialTable.append("cltxlrtb \\");
		strMaterialTable.append("cellx1250");
		//--ERP Line
		strMaterialTable.append("\\clvertalt\\clbrdrt\\");
		strMaterialTable.append("brdrs\\brdrw15");
		strMaterialTable.append(" \\clbrdrl\\brdrs\\brdrw15 \\");
		strMaterialTable.append("clbrdrb\\brdrs\\");
		strMaterialTable.append("brdrw15 \\clbrdrr\\brdrs\\");
		strMaterialTable.append("brdrw15 \\cltxlrtb ");
		strMaterialTable.append("\\cellx2050");
		//--MLI 
		strMaterialTable.append("\\clvertalt\\clbrdrt");
		strMaterialTable.append("\\brdrs\\");
		strMaterialTable.append("brdrw15 \\clbrdrl\\brdrs\\");
		strMaterialTable.append("brdrw15 \\clbrdrb");
		strMaterialTable.append("\\brdrs\\brdrw15 \\clbrdrr\\");
		strMaterialTable.append("brdrs\\brdrw15");
		strMaterialTable.append(" \\cltxlrtb \\cellx2850\\");
		//--part
		strMaterialTable.append("clvertalt\\clbrdrt");
		strMaterialTable.append("\\brdrs\\brdrw15 \\clbrdrl\\");
		strMaterialTable.append("brdrs\\brdrw15");
		strMaterialTable.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
		strMaterialTable.append("clbrdrr\\brdrs");
		strMaterialTable.append("\\brdrw15 \\cltxlrtb \\");
		strMaterialTable.append("cellx4700\\");
		//--Description
		strMaterialTable.append("clvertalt\\clbrdrt");
		strMaterialTable.append("\\brdrs\\brdrw15 \\clbrdrl\\");
		strMaterialTable.append("brdrs\\brdrw15");
		strMaterialTable.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
		strMaterialTable.append("clbrdrr\\brdrs");
		strMaterialTable.append("\\brdrw15 \\cltxlrtb \\");
		strMaterialTable.append("cellx6950\\");
		//--Qty
		strMaterialTable.append("clvertalt\\clbrdrt");
		strMaterialTable.append("\\brdrs\\brdrw15 \\clbrdrl\\");
		strMaterialTable.append("brdrs\\brdrw15");
		strMaterialTable.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
		strMaterialTable.append("clbrdrr\\brdrs");
		strMaterialTable.append("\\brdrw15 \\cltxlrtb \\");
		strMaterialTable.append("cellx7650\\");
	      //--UOM
		strMaterialTable.append("clvertalt\\clbrdrt\\brdrs\\");
		strMaterialTable.append("brdrw15 \\clbrdrl");
		strMaterialTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
		strMaterialTable.append("brdrs\\brdrw15 \\");
		strMaterialTable.append("clbrdrr\\brdrs\\brdrw15 \\");
		strMaterialTable.append("cltxlrtb \\");
		strMaterialTable.append("cellx8550\\");
		//--Line Status
		/*strMaterialTable.append("clvertalt\\clbrdrt\\brdrs\\");
		strMaterialTable.append("brdrw15 \\clbrdrl");
		strMaterialTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
		strMaterialTable.append("brdrs\\brdrw15 \\");
		strMaterialTable.append("clbrdrr\\brdrs\\brdrw15 \\");
		strMaterialTable.append("cltxlrtb \\");
		strMaterialTable.append("cellx9200\\");*/
		//--ERP Line Status
		strMaterialTable.append("clvertalt\\clbrdrt\\brdrs\\");
		strMaterialTable.append("brdrw15 \\clbrdrl");
		strMaterialTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
		strMaterialTable.append("brdrs\\brdrw15 \\");
		strMaterialTable.append("clbrdrr\\brdrs\\brdrw15 \\");
		strMaterialTable.append("cltxlrtb \\");
		strMaterialTable.append("cellx9660\\");//9160
		//--Promised Date 
		strMaterialTable.append("clvertalt\\clbrdrt\\brdrs\\");
		strMaterialTable.append("brdrw15 \\clbrdrl");
		strMaterialTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
		strMaterialTable.append("brdrs\\brdrw15 \\");
		strMaterialTable.append("clbrdrr\\brdrs\\brdrw15 \\");
		strMaterialTable.append("cltxlrtb \\");
		strMaterialTable.append("cellx10890\\");//10390
		//--Shipped Date
		strMaterialTable.append("clvertalt\\clbrdrt\\brdrs\\");
		strMaterialTable.append("brdrw15 \\clbrdrl");
		strMaterialTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
		strMaterialTable.append("brdrs\\brdrw15 \\");
		strMaterialTable.append("clbrdrr\\brdrs\\brdrw15 \\");
		strMaterialTable.append("cltxlrtb \\");
		strMaterialTable.append("cellx12290\\");//11790
		//--Delivery
		strMaterialTable.append("clvertalt\\clbrdrt\\brdrs\\");
		strMaterialTable.append("brdrw15 \\clbrdrl");
		strMaterialTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
		strMaterialTable.append("brdrs\\brdrw15 \\");
		strMaterialTable.append("clbrdrr\\brdrs\\brdrw15 \\");
		strMaterialTable.append("cltxlrtb \\");
		strMaterialTable.append("cellx13640\\");//12890
		//--Tracking
		strMaterialTable.append("clvertalt\\clbrdrt\\brdrs\\");
		strMaterialTable.append("brdrw15 \\clbrdrl");
		strMaterialTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
		strMaterialTable.append("brdrs\\brdrw15 \\");
		strMaterialTable.append("clbrdrr\\brdrs\\brdrw15 \\");
		strMaterialTable.append("cltxlrtb \\");
		strMaterialTable.append("cellx14730\\");//13960
		
		strMaterialTable.append("pard \\qc\\");
		strMaterialTable.append("widctlpar\\intbl\\adjustright {\\fonttbl {\\f0\\froman GE Inspira;}} {\\b\\f0\\fs22 ");
		//strMaterialTable.append("widctlpar\\intbl\\adjustright {\\b\\fs22 ");
		strMaterialTable.append("Name\\cell " );
		strMaterialTable.append("ERP Line\\cell ");
		strMaterialTable.append("MLI\\cell ");
		strMaterialTable.append("Part\\cell ");
		strMaterialTable.append("Description\\cell ");
		strMaterialTable.append("Qty\\cell ");
		strMaterialTable.append("UOM\\cell ");
		//strMaterialTable.append("Line Status\\cell ");
		strMaterialTable.append("ERP Line Status\\cell ");
		strMaterialTable.append("Promised Date\\cell ");
		strMaterialTable.append("Shipped Date\\cell ");
		strMaterialTable.append("Delivery\\cell ");
		strMaterialTable.append("Tracking\\cell ");
		strMaterialTable.append(" }\\pard \\widctlpar\\intbl\\adjustright {\\");
		strMaterialTable.append("b\\fs22 \\row }\\");
		strMaterialTable.append("pard\\plain \\s15\\widctlpar\\adjustright ");
		strMaterialTable.append("\\cgrid {");
		StringBuffer strMaterialTableRow = new StringBuffer("");
		for (int i = 0; i < materialShpList.size(); i++) {
			strMaterialTableRow.append("}\\trowd \\trgaph108\\");
			strMaterialTableRow.append("trleft200\\trbrdrt\\brdrs\\brdrw15 ");
			strMaterialTableRow.append("\\trbrdrl");
			strMaterialTableRow.append("\\brdrs\\brdrw15 \\trbrdrb\\brdrs");
			strMaterialTableRow.append("\\brdrw15 \\");
			strMaterialTableRow.append("trbrdrr\\brdrs\\brdrw15 \\");
			strMaterialTableRow.append("trbrdrh\\brdrs\\");
			strMaterialTableRow.append("brdrw15 \\trbrdrv\\brdrs\\");
			strMaterialTableRow.append("brdrw15 \\");
		
			//--Name
			strMaterialTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
			strMaterialTableRow.append("brdrw15 \\clbrdrl");
			strMaterialTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
			strMaterialTableRow.append("brdrs\\brdrw15 \\");
			strMaterialTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
			strMaterialTableRow.append("cltxlrtb \\");
			strMaterialTableRow.append("cellx1250");
			//--ERP Line
			strMaterialTableRow.append("\\clvertalt\\clbrdrt\\");
			strMaterialTableRow.append("brdrs\\brdrw15");
			strMaterialTableRow.append(" \\clbrdrl\\brdrs\\brdrw15 \\");
			strMaterialTableRow.append("clbrdrb\\brdrs\\");
			strMaterialTableRow.append("brdrw15 \\clbrdrr\\brdrs\\");
			strMaterialTableRow.append("brdrw15 \\cltxlrtb ");
			strMaterialTableRow.append("\\cellx2050");
			//--MLI 
			strMaterialTableRow.append("\\clvertalt\\clbrdrt");
			strMaterialTableRow.append("\\brdrs\\");
			strMaterialTableRow.append("brdrw15 \\clbrdrl\\brdrs\\");
			strMaterialTableRow.append("brdrw15 \\clbrdrb");
			strMaterialTableRow.append("\\brdrs\\brdrw15 \\clbrdrr\\");
			strMaterialTableRow.append("brdrs\\brdrw15");
			strMaterialTableRow.append(" \\cltxlrtb \\cellx2850\\");
			//--part
			strMaterialTableRow.append("clvertalt\\clbrdrt");
			strMaterialTableRow.append("\\brdrs\\brdrw15 \\clbrdrl\\");
			strMaterialTableRow.append("brdrs\\brdrw15");
			strMaterialTableRow.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
			strMaterialTableRow.append("clbrdrr\\brdrs");
			strMaterialTableRow.append("\\brdrw15 \\cltxlrtb \\");
			strMaterialTableRow.append("cellx4700\\");
			//--Description
			strMaterialTableRow.append("clvertalt\\clbrdrt");
			strMaterialTableRow.append("\\brdrs\\brdrw15 \\clbrdrl\\");
			strMaterialTableRow.append("brdrs\\brdrw15");
			strMaterialTableRow.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
			strMaterialTableRow.append("clbrdrr\\brdrs");
			strMaterialTableRow.append("\\brdrw15 \\cltxlrtb \\");
			strMaterialTableRow.append("cellx6950\\");
			//--Qty
			strMaterialTableRow.append("clvertalt\\clbrdrt");
			strMaterialTableRow.append("\\brdrs\\brdrw15 \\clbrdrl\\");
			strMaterialTableRow.append("brdrs\\brdrw15");
			strMaterialTableRow.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
			strMaterialTableRow.append("clbrdrr\\brdrs");
			strMaterialTableRow.append("\\brdrw15 \\cltxlrtb \\");
			strMaterialTableRow.append("cellx7650\\");
	        //--UOM
			strMaterialTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
			strMaterialTableRow.append("brdrw15 \\clbrdrl");
			strMaterialTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
			strMaterialTableRow.append("brdrs\\brdrw15 \\");
			strMaterialTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
			strMaterialTableRow.append("cltxlrtb \\");
			strMaterialTableRow.append("cellx8550\\");
			//--Line Status
			/*strMaterialTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
			strMaterialTableRow.append("brdrw15 \\clbrdrl");
			strMaterialTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
			strMaterialTableRow.append("brdrs\\brdrw15 \\");
			strMaterialTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
			strMaterialTableRow.append("cltxlrtb \\");
			strMaterialTableRow.append("cellx9200\\");*/
			//--ERP Line Status
			strMaterialTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
			strMaterialTableRow.append("brdrw15 \\clbrdrl");
			strMaterialTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
			strMaterialTableRow.append("brdrs\\brdrw15 \\");
			strMaterialTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
			strMaterialTableRow.append("cltxlrtb \\");
			strMaterialTableRow.append("cellx9660\\");
			//--Promised Date 
			strMaterialTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
			strMaterialTableRow.append("brdrw15 \\clbrdrl");
			strMaterialTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
			strMaterialTableRow.append("brdrs\\brdrw15 \\");
			strMaterialTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
			strMaterialTableRow.append("cltxlrtb \\");
			strMaterialTableRow.append("cellx10890\\");
			//--Shipped Date
			strMaterialTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
			strMaterialTableRow.append("brdrw15 \\clbrdrl");
			strMaterialTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
			strMaterialTableRow.append("brdrs\\brdrw15 \\");
			strMaterialTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
			strMaterialTableRow.append("cltxlrtb \\");
			strMaterialTableRow.append("cellx12290\\");
			//--Delivery
			strMaterialTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
			strMaterialTableRow.append("brdrw15 \\clbrdrl");
			strMaterialTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
			strMaterialTableRow.append("brdrs\\brdrw15 \\");
			strMaterialTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
			strMaterialTableRow.append("cltxlrtb \\");
			strMaterialTableRow.append("cellx13640\\");
			//--Tracking
			strMaterialTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
			strMaterialTableRow.append("brdrw15 \\clbrdrl");
			strMaterialTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
			strMaterialTableRow.append("brdrs\\brdrw15 \\");
			strMaterialTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
			strMaterialTableRow.append("cltxlrtb \\");
			strMaterialTableRow.append("cellx14730\\");	
				
			strMaterialTableRow.append("pard\\qc \\widctlpar\\intbl\\");
			strMaterialTableRow.append("adjustright ");
			strMaterialTableRow.append("\\cgrid ");
			strMaterialTableRow.append("{\\fs22 ");
			strMaterialTableRow.append(materialShpList.get(i).getMaterialOrder());
			strMaterialTableRow.append("\\cell  ");
			//strMaterialTableRow.append(materialShpList.get(i).getMaterialErpLineNum());
			strMaterialTableRow.append(materialShpList.get(i).getLineNumber());
			strMaterialTableRow.append("\\cell ");
			strMaterialTableRow.append(materialShpList.get(i).getMaterialMli());
			strMaterialTableRow.append("\\cell ");
			strMaterialTableRow.append(materialShpList.get(i).getMaterialPartName());
			strMaterialTableRow.append("\\cell ");
			strMaterialTableRow.append(materialShpList.get(i).getMaterialPartDesc());
			strMaterialTableRow.append("\\cell ");
			strMaterialTableRow.append(materialShpList.get(i).getMaterialQty());
			strMaterialTableRow.append("\\cell ");
			strMaterialTableRow.append(materialShpList.get(i).getUom());
			strMaterialTableRow.append("\\cell ");
			/*strMaterialTableRow.append(materialShpList.get(i).getMaterialLineStatus());
			strMaterialTableRow.append("\\cell ");*/
			strMaterialTableRow.append(materialShpList.get(i).getMaterialErpStatus());
			strMaterialTableRow.append("\\cell ");
			strMaterialTableRow.append(materialShpList.get(i).getMaterialPromiseDttm());
			strMaterialTableRow.append("\\cell ");
			strMaterialTableRow.append(materialShpList.get(i).getMaterialShipDttm());
			strMaterialTableRow.append("\\cell ");
			strMaterialTableRow.append(materialShpList.get(i).getMaterialWayBill());
			strMaterialTableRow.append("\\cell ");
			strMaterialTableRow.append(materialShpList.get(i).getMaterialDelivery());
			strMaterialTableRow.append("\\cell }");
			strMaterialTableRow.append("\\pard \\widctlpar\\intbl\\");
			strMaterialTableRow.append("adjustright {\\");
			strMaterialTableRow.append("fs24 \\row  }\\pard\\plain \\");
			strMaterialTableRow.append("s15\\widctlpar\\");
			strMaterialTableRow.append("adjustright \\fs24\\cgrid {");
			}
		strMaterialTable.append(strMaterialTableRow);
			return strMaterialTable;
	}
	
	/**
	 * @return PLMDocGenFmiData objects.
	 */
	private static final class MtrlShpMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
		public PLMDocGenFmiData mapRow(ResultSet rs, int rowCount) throws SQLException {

			PLMDocGenFmiData tempData = new PLMDocGenFmiData();
			tempData.setMaterialOrder(PLMUtils.checkNullVal(rs.getString("ORDER_NAME")));
			//tempData.setMaterialErpLineNum(rs.getInt("ERP_LINE_NUM")); // Line Number
			tempData.setLineNumber(PLMUtils.checkNullVal(rs.getString("LINE_NUM_NEW"))); // Line Number + Shipment Number
			tempData.setMaterialMli(PLMUtils.checkNullVal(rs.getString("MLI")));
			tempData.setMaterialPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
			tempData.setMaterialPartDesc(PLMUtils.checkNullVal(rs.getString("PART_DESCRIPTION")));
			tempData.setMaterialQty(rs.getInt("QTY"));
			tempData.setUom(PLMUtils.checkNullVal(rs.getString("UOM")));
			//tempData.setMaterialLineStatus(PLMUtils.checkNullVal(rs.getString("LINE_STATUS")));
			tempData.setMaterialErpStatus(PLMUtils.checkNullVal(rs.getString("ERP_LINE_STATUS")));

			Date promiseDt = rs.getDate("PROMISE_DTTM");
			if (promiseDt != null) {
				String strpromiseDt = SIMPLE_DATE_FORMAT.format(promiseDt);
				tempData.setMaterialPromiseDttm(strpromiseDt);
			} else {
				tempData.setMaterialPromiseDttm("");
			}
			
			Date shipDt = rs.getDate("SHIP_DTTM");
			if (shipDt != null) {
				String strshipDt = SIMPLE_DATE_FORMAT.format(shipDt);
				tempData.setMaterialShipDttm(strshipDt);
			}else {
				tempData.setMaterialShipDttm("");
			}
			
			tempData.setMaterialDelivery(PLMUtils.checkNullVal(rs.getString("DELIVERY")));
			tempData.setMaterialWayBill(PLMUtils.checkNullVal(rs.getString("WAY_BILL")));
			
			
			return tempData;		}
	}
	
	/**
	 * 
	 * class to sort list of object of type PLMDocGenFmiData.
	 * 
	 */
	private static class SortFMIData implements Comparator<PLMDocGenFmiData>,
			Serializable {
		/**
		 * long serialVersionUID
		 */
		private static final long serialVersionUID = 1L;

		/**
		 * used for comparision..
		 */
		public int compare(PLMDocGenFmiData aString,
				PLMDocGenFmiData bString) {
			String aStr;
			String bStr;
			int result=0;
			aStr = aString.getMlino();
			bStr = bString.getMlino();
			if(aStr != null && bStr != null){
			result = aStr.compareTo(bStr);
			}
			return result;
			
		}
	}
	/**
	 * @return List<String> objects.
	 */
	private static final class PartMapper implements ParameterizedRowMapper<List<String>> {
//	private static ParameterizedRowMapper<List<String>> partMapper = new ParameterizedRowMapper<List<String>>() {
		public List<String> mapRow(ResultSet rs, int rowCount) throws SQLException {
			List<String> partnoList = new ArrayList<String>();
			partnoList.add(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
			
			return partnoList;
		}
	}
	/**
	 * @return List<String> objects.
	 */
	private static final class PartSpecMapper implements ParameterizedRowMapper<List<String>> {
//	private static ParameterizedRowMapper<List<String>> partSpecMapper = new ParameterizedRowMapper<List<String>>() {
		public List<String> mapRow(ResultSet rs, int rowCount) throws SQLException {
			List<String> partSpecList = new ArrayList<String>();
			partSpecList.add(PLMUtils.checkNullVal(rs.getString("FROM_ID")));			
			return partSpecList;
		}
	}
	/**
	 * @return List<String> objects.
	 */
	private static final class EBomMapper implements ParameterizedRowMapper<List<String>> {
//	private static ParameterizedRowMapper<List<String>>eBomMapper = new ParameterizedRowMapper<List<String>>() {
		public List<String> mapRow(ResultSet rs, int rowCount) throws SQLException {
			List<String> ebomIdList = new ArrayList<String>();
			ebomIdList.add(PLMUtils.checkNullVal(rs.getString("FROM_ID")));
			
			return ebomIdList;
		}
	}
	
	
	
	/**
	 * This method is used to loadQlDesc
	 * @param qldescdetailslist
	 * @return StringBuffer
	 */
	public StringBuffer loadQlDesc(List<PLMDocGenFmiData> qldescdetailslist) {
		StringBuffer strbqldesc = new StringBuffer("");
		strbqldesc.append("\\par ");
		for (int i = 0; i < qldescdetailslist.size(); i++) {
			strbqldesc.append(qldescdetailslist.get(i).getQldesc());
			strbqldesc.append("\\par ");
			strbqldesc.append("\\par ");
		}
		return strbqldesc;
	}
	
	/**
	 * This method is used to loadMliTable1and2
	 * @param mlidetailslist, strMliTable
	 * @return StringBuffer
	 */
	public StringBuffer loadMliTable1and2(List<PLMDocGenFmiData> mlidetailslist,StringBuffer strMliTable) {
		//StringBuffer strMliTable = new StringBuffer();
		
		//if(table == 1){
		strMliTable.append("\\par ");
		//}
		strMliTable.append("}\\trowd \\trgaph108\\");
		strMliTable.append("trleft200\\trbrdrt\\brdrs\\brdrw15 ");
		strMliTable.append("\\trbrdrl");
		strMliTable.append("\\brdrs\\brdrw15 \\trbrdrb\\brdrs");
		strMliTable.append("\\brdrw15 \\");
		strMliTable.append("trbrdrr\\brdrs\\brdrw15 \\");
		strMliTable.append("trbrdrh\\brdrs\\");
		strMliTable.append("brdrw15 \\trbrdrv\\brdrs\\");
		strMliTable.append("brdrw15 \\");
		//--MLI
		strMliTable.append("clvertalt\\clbrdrt\\brdrs\\brdrw15 \\");
		strMliTable.append("clbrdrl\\brdrs\\");
		strMliTable.append("brdrw15 \\clbrdrb\\brdrs\\");
		strMliTable.append("brdrw15 \\clbrdrr\\");
		strMliTable.append("brdrs\\brdrw15 \\cltxlrtb \\");
		strMliTable.append("cellx1000\\");
		//Part Number
		strMliTable.append("clvertalt\\clbrdrt\\brdrs\\");
		strMliTable.append("brdrw15 \\clbrdrl");
		strMliTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
		strMliTable.append("brdrs\\brdrw15 \\");
		strMliTable.append("clbrdrr\\brdrs\\brdrw15 \\");
		strMliTable.append("cltxlrtb \\");
		strMliTable.append("cellx3500\\");
		//--Part Rev
		/*strMliTable.append("\\clvertalt\\clbrdrt\\");
		strMliTable.append("brdrs\\brdrw15");
		strMliTable.append(" \\clbrdrl\\brdrs\\brdrw15 \\");
		strMliTable.append("clbrdrb\\brdrs\\");
		strMliTable.append("brdrw15 \\clbrdrr\\brdrs\\");
		strMliTable.append("brdrw15 \\cltxlrtb ");
		strMliTable.append("\\cellx2620");
		//--Part State
		strMliTable.append("\\clvertalt\\clbrdrt");
		strMliTable.append("\\brdrs\\");
		strMliTable.append("brdrw15 \\clbrdrl\\brdrs\\");
		strMliTable.append("brdrw15 \\clbrdrb");
		strMliTable.append("\\brdrs\\brdrw15 \\clbrdrr\\");
		strMliTable.append("brdrs\\brdrw15");
		strMliTable.append(" \\cltxlrtb \\cellx3900\\");*/
		//--Qty
		strMliTable.append("clvertalt\\clbrdrt");
		strMliTable.append("\\brdrs\\brdrw15 \\clbrdrl\\");
		strMliTable.append("brdrs\\brdrw15");
		strMliTable.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
		strMliTable.append("clbrdrr\\brdrs");
		strMliTable.append("\\brdrw15 \\cltxlrtb \\");
		strMliTable.append("cellx4500\\");
		//--UOM
		strMliTable.append("clvertalt\\clbrdrt");
		strMliTable.append("\\brdrs\\brdrw15 \\clbrdrl\\");
		strMliTable.append("brdrs\\brdrw15");
		strMliTable.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
		strMliTable.append("clbrdrr\\brdrs");
		strMliTable.append("\\brdrw15 \\cltxlrtb \\");
		strMliTable.append("cellx5400\\");
		//--Document Name
		strMliTable.append("clvertalt\\clbrdrt");
		strMliTable.append("\\brdrs\\brdrw15 \\clbrdrl\\");
		strMliTable.append("brdrs\\brdrw15");
		strMliTable.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
		strMliTable.append("clbrdrr\\brdrs");
		strMliTable.append("\\brdrw15 \\cltxlrtb \\");
		strMliTable.append("cellx7000\\");
		
         //--Doc Rev
		strMliTable.append("clvertalt\\clbrdrt\\brdrs\\");
		strMliTable.append("brdrw15 \\clbrdrl");
		strMliTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
		strMliTable.append("brdrs\\brdrw15 \\");
		strMliTable.append("clbrdrr\\brdrs\\brdrw15 \\");
		strMliTable.append("cltxlrtb \\");
		strMliTable.append("cellx7700\\");
		
		//--DWG State
		/*strMliTable.append("clvertalt\\clbrdrt\\brdrs\\");
		strMliTable.append("brdrw15 \\clbrdrl");
		strMliTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
		strMliTable.append("brdrs\\brdrw15 \\");
		strMliTable.append("clbrdrr\\brdrs\\brdrw15 \\");
		strMliTable.append("cltxlrtb \\");
		strMliTable.append("cellx8600\\");*/
		
		//--Description 
		strMliTable.append("clvertalt\\clbrdrt\\brdrs\\");
		strMliTable.append("brdrw15 \\clbrdrl");
		strMliTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
		strMliTable.append("brdrs\\brdrw15 \\");
		strMliTable.append("clbrdrr\\brdrs\\brdrw15 \\");
		strMliTable.append("cltxlrtb \\");
		strMliTable.append("cellx10150\\");
		
		//--Notes
		strMliTable.append("clvertalt\\clbrdrt\\brdrs\\");
		strMliTable.append("brdrw15 \\clbrdrl");
		strMliTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
		strMliTable.append("brdrs\\brdrw15 \\");
		strMliTable.append("clbrdrr\\brdrs\\brdrw15 \\");
		strMliTable.append("cltxlrtb \\");
		strMliTable.append("cellx10950\\");
		
		strMliTable.append("pard \\qc\\");	
		strMliTable.append("widctlpar\\intbl\\adjustright {\\fonttbl {\\f0\\froman GE Inspira;}} {\\b\\f0\\fs22 ");
		//strMliTable.append("MLI\\cell Part Number\\cell Part Rev\\cell ");
		strMliTable.append("MLI\\cell Part Number\\cell ");
		//strMliTable.append("Part State\\cell ");
		strMliTable.append("Qty\\cell ");
		strMliTable.append("UOM\\cell ");
		strMliTable.append("Document Name\\cell ");
		strMliTable.append("Doc Rev\\cell ");
		//strMliTable.append("Dwg State\\cell ");
		strMliTable.append("Description\\cell ");
		strMliTable.append("Notes\\cell ");
		strMliTable.append(" }\\pard \\widctlpar\\intbl\\adjustright {\\");
		strMliTable.append("b\\fs22 \\row }\\");
		strMliTable.append("pard\\plain \\s15\\widctlpar\\adjustright ");
		strMliTable.append("\\cgrid {");
		StringBuffer strbMliTableRow = new StringBuffer("");
		for (int i = 0; i < mlidetailslist.size(); i++) {
			 strbMliTableRow.append("}\\trowd \\trgaph108\\");
				strbMliTableRow.append("trleft200\\trbrdrt\\brdrs\\brdrw15 ");
				strbMliTableRow.append("\\trbrdrl");
				strbMliTableRow.append("\\brdrs\\brdrw15 \\trbrdrb\\brdrs");
				strbMliTableRow.append("\\brdrw15 \\");
				strbMliTableRow.append("trbrdrr\\brdrs\\brdrw15 \\");
				strbMliTableRow.append("trbrdrh\\brdrs\\");
				strbMliTableRow.append("brdrw15 \\trbrdrv\\brdrs\\");
				strbMliTableRow.append("brdrw15 \\");
				//--MLI
				strbMliTableRow.append("clvertalt\\clbrdrt\\brdrs\\brdrw15 \\");
				strbMliTableRow.append("clbrdrl\\brdrs\\");
				strbMliTableRow.append("brdrw15 \\clbrdrb\\brdrs\\");
				strbMliTableRow.append("brdrw15 \\clbrdrr\\");
				strbMliTableRow.append("brdrs\\brdrw15 \\cltxlrtb \\");
				strbMliTableRow.append("cellx1000\\");
				//Part Number
				strbMliTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
				strbMliTableRow.append("brdrw15 \\clbrdrl");
				strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
				strbMliTableRow.append("brdrs\\brdrw15 \\");
				strbMliTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
				strbMliTableRow.append("cltxlrtb \\");
				strbMliTableRow.append("cellx3500\\");
				//--Part Rev
				/*strbMliTableRow.append("\\clvertalt\\clbrdrt\\");
				strbMliTableRow.append("brdrs\\brdrw15");
				strbMliTableRow.append(" \\clbrdrl\\brdrs\\brdrw15 \\");
				strbMliTableRow.append("clbrdrb\\brdrs\\");
				strbMliTableRow.append("brdrw15 \\clbrdrr\\brdrs\\");
				strbMliTableRow.append("brdrw15 \\cltxlrtb ");
				strbMliTableRow.append("\\cellx2620");
				//--Part State
				strbMliTableRow.append("\\clvertalt\\clbrdrt");
				strbMliTableRow.append("\\brdrs\\");
				strbMliTableRow.append("brdrw15 \\clbrdrl\\brdrs\\");
				strbMliTableRow.append("brdrw15 \\clbrdrb");
				strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrr\\");
				strbMliTableRow.append("brdrs\\brdrw15");
				strbMliTableRow.append(" \\cltxlrtb \\cellx3900\\");*/
				//--Qty
				strbMliTableRow.append("clvertalt\\clbrdrt");
				strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrl\\");
				strbMliTableRow.append("brdrs\\brdrw15");
				strbMliTableRow.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
				strbMliTableRow.append("clbrdrr\\brdrs");
				strbMliTableRow.append("\\brdrw15 \\cltxlrtb \\");
				strbMliTableRow.append("cellx4500\\");
				//--UOM
				strbMliTableRow.append("clvertalt\\clbrdrt");
				strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrl\\");
				strbMliTableRow.append("brdrs\\brdrw15");
				strbMliTableRow.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
				strbMliTableRow.append("clbrdrr\\brdrs");
				strbMliTableRow.append("\\brdrw15 \\cltxlrtb \\");
				strbMliTableRow.append("cellx5400\\");
				//--Document Name
				strbMliTableRow.append("clvertalt\\clbrdrt");
				strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrl\\");
				strbMliTableRow.append("brdrs\\brdrw15");
				strbMliTableRow.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
				strbMliTableRow.append("clbrdrr\\brdrs");
				strbMliTableRow.append("\\brdrw15 \\cltxlrtb \\");
				strbMliTableRow.append("cellx7000\\");
				
		        //--Doc Rev
				strbMliTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
				strbMliTableRow.append("brdrw15 \\clbrdrl");
				strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
				strbMliTableRow.append("brdrs\\brdrw15 \\");
				strbMliTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
				strbMliTableRow.append("cltxlrtb \\");
				strbMliTableRow.append("cellx7700\\");
				
				//--DWG State
				/*strbMliTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
				strbMliTableRow.append("brdrw15 \\clbrdrl");
				strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
				strbMliTableRow.append("brdrs\\brdrw15 \\");
				strbMliTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
				strbMliTableRow.append("cltxlrtb \\");
				strbMliTableRow.append("cellx8600\\");*/
				
				//--Description 
				strbMliTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
				strbMliTableRow.append("brdrw15 \\clbrdrl");
				strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
				strbMliTableRow.append("brdrs\\brdrw15 \\");
				strbMliTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
				strbMliTableRow.append("cltxlrtb \\");
				strbMliTableRow.append("cellx10150\\");
				
				//--Notes
				strbMliTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
				strbMliTableRow.append("brdrw15 \\clbrdrl");
				strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
				strbMliTableRow.append("brdrs\\brdrw15 \\");
				strbMliTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
				strbMliTableRow.append("cltxlrtb \\");
				strbMliTableRow.append("cellx10950\\");
				
				strbMliTableRow.append("pard\\qc \\widctlpar\\intbl\\");
				strbMliTableRow.append("adjustright ");
				strbMliTableRow.append("\\cgrid ");
				//strbMliTableRow.append("{\\fonttbl {\\f0\\froman GE Inspira;}} ");
				strbMliTableRow.append("{\\fs22 ");
				strbMliTableRow.append(mlidetailslist.get(i).getMlino());
				strbMliTableRow.append("\\cell }{\\fs22 ");
				strbMliTableRow.append("\\cf6 ");
				strbMliTableRow.append(mlidetailslist.get(i).getPartNum());
				strbMliTableRow.append("\\cell }{\\fs22 ");
				//strbMliTableRow.append(mlidetailslist.get(i).getPartRevision());
				//strbMliTableRow.append("\\cell ");
				//strbMliTableRow.append(mlidetailslist.get(i).getPartState());
				//strbMliTableRow.append("\\cell ");
				strbMliTableRow.append(mlidetailslist.get(i).getPartQuantity());
				strbMliTableRow.append("\\cell ");
				strbMliTableRow.append(mlidetailslist.get(i).getUom());
				strbMliTableRow.append("\\cell ");
				strbMliTableRow.append(mlidetailslist.get(i).getDocName());
				strbMliTableRow.append("\\cell ");
				strbMliTableRow.append(mlidetailslist.get(i).getDocRev());
				strbMliTableRow.append("\\cell ");
				//strbMliTableRow.append(mlidetailslist.get(i).getDocState());
				//strbMliTableRow.append("\\cell ");
				strbMliTableRow.append(mlidetailslist.get(i).getDocDesc());
				strbMliTableRow.append("\\cell ");
				strbMliTableRow.append("\\cf6 ");
				strbMliTableRow.append(mlidetailslist.get(i).getNote());
				strbMliTableRow.append("\\cell }");
				
				
//				LOG.info("mlidetailslist.get(i).getMlino() " + mlidetailslist.get(i).getMlino());
//				LOG.info("mlidetailslist.get(i).getPartno() " + mlidetailslist.get(i).getPartno());
//				LOG.info("mlidetailslist.get(i).getPartRevision() " + mlidetailslist.get(i).getPartRevision());
//				LOG.info("mlidetailslist.get(i).getPartState() " + mlidetailslist.get(i).getPartState());
//				LOG.info("mlidetailslist.get(i).getPartQuantity() " + mlidetailslist.get(i).getPartQuantity());
//				LOG.info("mlidetailslist.get(i).getUom() " + mlidetailslist.get(i).getUom());
//				LOG.info("mlidetailslist.get(i).getDocName() " + mlidetailslist.get(i).getDocName());
//				LOG.info("mlidetailslist.get(i).getDocRev() " + mlidetailslist.get(i).getDocRev());
//				LOG.info("mlidetailslist.get(i).getDocState() " + mlidetailslist.get(i).getDocState());
//				LOG.info("mlidetailslist.get(i).getDocDesc() " + mlidetailslist.get(i).getDocDesc());
//				LOG.info("mlidetailslist.get(i).getNote() " + mlidetailslist.get(i).getNote());
				
				strbMliTableRow.append("\\pard \\widctlpar\\intbl\\");
				strbMliTableRow.append("adjustright {\\");
				strbMliTableRow.append("fs24 \\row  }\\pard\\plain \\");
				strbMliTableRow.append("s15\\widctlpar\\");
				strbMliTableRow.append("adjustright \\fs24\\cgrid {");
			}
			strMliTable.append(strbMliTableRow);
			return strMliTable;
	}
	/**
	 * This method is used to uploadFmiTemplate
	 * @param templateData
	 * @return String
	 * @throws PLMCommonException
	 */
	public String uploadFmiTemplate(PLMFmiTemplateData templateData)
			throws PLMCommonException {
		return "success";
	}

	/**
	 * This method is used to downloadFmiTemplate
	 * @param templateData
	 * @return String
	 * @throws PLMCommonException
	 */
	public String downloadFmiTemplate(PLMFmiTemplateData templateData)
			throws PLMCommonException {
		return "success";
	}
	/**
	 * This method is used to uploadFmiText
	 * @param textDataList
	 * @return String
	 * @throws PLMCommonException
	 */
	public String uploadFmiText(List<PLMFmiTextData> textDataList)
			throws PLMCommonException {
		LOG.info("I am inside String uploadFmiText(List<PLMFmiTextData> textDataList)");
		LOG.info("Delete Query :  " + PLMQueryConstants.DEL_FMI_TEXT);
		getJdbcTemplate().update(PLMQueryConstants.DEL_FMI_TEXT);
		final List<PLMFmiTextData> finalTextList=textDataList;
		int[] updateCount =null;
		LOG.info("Insert Query :  " + PLMQueryConstants.SET_FMI_TEXT);
		updateCount  = getSimpleJdbcTemplate().getJdbcOperations().batchUpdate(PLMQueryConstants.SET_FMI_TEXT,new BatchPreparedStatementSetter() 
		{
		public void setValues(PreparedStatement ps,int iCount)throws SQLException {
		ps.setInt(1, iCount);
		ps.setString(2, finalTextList.get(iCount).getName());
		ps.setString(3, finalTextList.get(iCount).getMarketingname());
		ps.setString(4, finalTextList.get(iCount).getCinomenclature());
		ps.setString(5, finalTextList.get(iCount).getCinomenclaturdesc());
		ps.setString(6, finalTextList.get(iCount).getFmitext());
		ps.setString(7, finalTextList.get(iCount).getFmitext1());
		ps.setString(8, finalTextList.get(iCount).getSpecialnotestext());
		ps.setString(9, finalTextList.get(iCount).getFieldtext());
		ps.setString(10, finalTextList.get(iCount).getRepairtext());
		ps.setString(11, finalTextList.get(iCount).getSpecialtoolstext());
		ps.setString(12, finalTextList.get(iCount).getRefdoctext());
		}
		public int getBatchSize() {
			return finalTextList.size();
		}
		});
		if(textDataList.size()==updateCount.length){
			  return "success";
		  }
		return "Fail";
	}
	
	/**
	 * This method is used to downloadFmiText
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMFmiTextData> downloadFmiText() throws PLMCommonException {		
		LOG.info("Query for Download Fmi Text  : " + PLMQueryConstants.GET_FMI_TEXT);
		List<PLMFmiTextData> textDataList = getSimpleJdbcTemplate().query(PLMQueryConstants.GET_FMI_TEXT, new FmiTextMapper());
		return textDataList;
	}

	/*private static ParameterizedRowMapper<PLMFmiTextData> fmiTextMapper = new ParameterizedRowMapper<PLMFmiTextData>() {
		public PLMFmiTextData mapRow(ResultSet rs, int rowCount)
				throws SQLException {
			PLMFmiTextData tempData = new PLMFmiTextData();
			tempData.setName(PLMUtils.checkNullVal(rs.getString("FMI_NM")));
			tempData.setMarketingname(PLMUtils.checkNullVal(rs.getString("MRKTG_NM")));
			tempData.setCinomenclature(PLMUtils.checkNullVal(rs.getString("CI_NMCLTR")));
			tempData.setCinomenclaturdesc(PLMUtils.checkNullVal(rs.getString("CI_NMCLTR_DESC")));
			tempData.setFmitext(PLMUtils.checkNullVal(rs.getString("FMI_TXT"))+ PLMUtils.checkNullVal(rs.getString("FMI_TEXT1")));
			tempData.setSpecialnotestext(PLMUtils.checkNullVal(rs.getString("SPL_NOTES_TXT")));
			tempData.setFieldtext(PLMUtils.checkNullVal(rs.getString("FIELD_TXT")));
			tempData.setRepairtext(PLMUtils.checkNullVal(rs.getString("RPR_TXT")));
			tempData.setSpecialtoolstext(PLMUtils.checkNullVal(rs.getString("SPL_TOOLS_TXT")));
			tempData.setRefdoctext(PLMUtils.checkNullVal(rs.getString("REF_DOC_TXT")));
			return tempData;
		}
	};*/
	
	/**
	 * @return PLMFmiTextData ParameterizedRowMapper For the FmiTextMapper.
	 */
	private static final class FmiTextMapper implements ParameterizedRowMapper<PLMFmiTextData> {
		public PLMFmiTextData mapRow(ResultSet rs, int rowCount)
		throws SQLException {
			PLMFmiTextData tempData = new PLMFmiTextData();
			tempData.setName(PLMUtils.checkNullVal(rs.getString("FMI_NM")));
			tempData.setMarketingname(PLMUtils.checkNullVal(rs.getString("MRKTG_NM")));
			tempData.setCinomenclature(PLMUtils.checkNullVal(rs.getString("CI_NMCLTR")));
			tempData.setCinomenclaturdesc(PLMUtils.checkNullVal(rs.getString("CI_NMCLTR_DESC")));
			tempData.setFmitext(PLMUtils.checkNullVal(rs.getString("FMI_TXT"))+ PLMUtils.checkNullVal(rs.getString("FMI_TEXT1")));
			tempData.setSpecialnotestext(PLMUtils.checkNullVal(rs.getString("SPL_NOTES_TXT")));
			tempData.setFieldtext(PLMUtils.checkNullVal(rs.getString("FIELD_TXT")));
			tempData.setRepairtext(PLMUtils.checkNullVal(rs.getString("RPR_TXT")));
			tempData.setSpecialtoolstext(PLMUtils.checkNullVal(rs.getString("SPL_TOOLS_TXT")));
			tempData.setRefdoctext(PLMUtils.checkNullVal(rs.getString("REF_DOC_TXT")));
			return tempData;
		}
	}

	/**
	 * This method is used to getBOMDataForContract
	 * @param contractNumber
	 * @param partNumber
	 * @return
	 * @throws PLMCommonException
	 */
	public List<PLMBomSalesData> getBOMDataForContract(String contractNumber, String partNumber) throws PLMCommonException {
		List<PLMBomSalesData> plmBomSalesDataResultList = new ArrayList<PLMBomSalesData>();
		//List<String> bomPartsForContractLst = new ArrayList<String>();
		String[] strArr = null;
		String partNum = "";
		if (!PLMUtils.isEmpty(partNumber)) {
			strArr = partNumber.split("~");
			partNum = strArr[0];
		}
		LOG.info("Getting BOM details for Contract Number = "+contractNumber+"  Part Number "+partNum);
		//bomPartsForContractLst.add(partNumber);
		//if(bomPartsForContractLst.size() > 0){
		if (!PLMUtils.isEmpty(partNum)) {
			LOG.info("Query for Getting BOM Data For Parts: " + PLMOfflineQueries.GET_BOM_DATA_FOR_CONTRACT_ONE);
			plmBomSalesDataResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_BOM_DATA_FOR_CONTRACT_ONE,
					new BomContractResultMapper(), new Object[]{partNum});
			LOG.info("Result of BOM Parts For a Contract : " + plmBomSalesDataResultList.size());
		}
		
		return plmBomSalesDataResultList;
	}

	/**
	 * This method is used to getSalesDataForContract
	 * @param contractNumber
	 * @return
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMBomSalesData> getSalesDataForContract(String contractNumber) throws PLMCommonException {
		List<PLMBomSalesData> plmBomSalesDataResultList = new ArrayList<PLMBomSalesData>();
		Map<String, Object> params = new HashMap<String, Object>();
		LOG.info("Query for Getting Sales ID's For a Contract Number: " + PLMOfflineQueries.GET_SALES_FOR_CONTRACT);
		List<String> salesForContractLst = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_SALES_FOR_CONTRACT, new BomSalesForContractMapper(), contractNumber);
		if(salesForContractLst.size() > 0){
			LOG.info("Sales ID's list size : "+salesForContractLst.size());
			params.put("SALESNM", salesForContractLst);
			LOG.info("Query for Getting Sales Data For Parts: " + PLMOfflineQueries.GET_SALES_DATA_FOR_CONTRACT_ONE);
			plmBomSalesDataResultList = getNamedJdbcTemplate().query(PLMOfflineQueries.GET_SALES_DATA_FOR_CONTRACT_ONE,params, new SalesContractResultMapper());
			LOG.info("Result of Sales For a Contract : " + plmBomSalesDataResultList.size());
		}
		return plmBomSalesDataResultList;
	}
	
	/*
	 * This method is used to getPartsForContract
	 * @param contractNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomSalesData> getPartsForContract(String contractNumber) throws PLMCommonException {
//		List<PLMBomSalesData> bomPartsForContractLst = new ArrayList<PLMBomSalesData>();
		String VT1 =null;
		String timeStamp = null;
		timeStamp = PLMUtils.volTableFormatDate();
		VT1 = PLMConstants.VT1.concat(timeStamp);
		LOG.info("Query for Creating VT1 : " + PLMOfflineQueries.CREATE_VT_BOM_PARTS_FOR_CONTRACT.replace(PLMConstants.VT1, VT1).replace("?", "'"+contractNumber+"'"));
		getJdbcTemplate().execute(PLMOfflineQueries.CREATE_VT_BOM_PARTS_FOR_CONTRACT.replace(PLMConstants.VT1, VT1).replace("?", "'"+contractNumber+"'"));

		LOG.info("Query for Inserting  VT1 data1  : " + PLMOfflineQueries.INSERT_VT_BOM_PARTS_FOR_CONTRACT1.replace(PLMConstants.VT1, VT1).replace("?", "'"+contractNumber+"'"));
		getJdbcTemplate().execute(PLMOfflineQueries.INSERT_VT_BOM_PARTS_FOR_CONTRACT1.replace(PLMConstants.VT1, VT1).replace("?", "'"+contractNumber+"'"));
		
		LOG.info("Query for Inserting  VT1 data2  : " + PLMOfflineQueries.INSERT_VT_BOM_PARTS_FOR_CONTRACT2.replace(PLMConstants.VT1, VT1).replace("?", "'"+contractNumber+"'"));
		getJdbcTemplate().execute(PLMOfflineQueries.INSERT_VT_BOM_PARTS_FOR_CONTRACT2.replace(PLMConstants.VT1, VT1).replace("?", "'"+contractNumber+"'"));

		LOG.info("Executing Query for BOM Parts for Contracts "+PLMOfflineQueries.GET_BOM_PARTS_FOR_CONTRACT.replace(PLMConstants.VT1, VT1));
		List<PLMBomSalesData> bomPartsForContractLst = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_BOM_PARTS_FOR_CONTRACT.replace(PLMConstants.VT1, VT1)
				, new PartsForContractMapper());		
		LOG.info("bomPartsForContractLst "+bomPartsForContractLst.size());
		return bomPartsForContractLst;
	}
	
	/**
	 * @return String objects.
	 */
	private static final class BomSalesForContractMapper implements ParameterizedRowMapper<String> {
//	private static ParameterizedRowMapper<String> bomSalesForContractMapper = new ParameterizedRowMapper<String>() {
		public String mapRow(ResultSet rs, int rowCount) throws SQLException {
			return PLMUtils.checkNullVal(rs.getString("UNIQUE_NAME"));
		}
	}
	
	/**
	 * @return PLMBomSalesData objects.
	 */
	private static final class PartsForContractMapper implements ParameterizedRowMapper<PLMBomSalesData> {
//	private static ParameterizedRowMapper<PLMBomSalesData> partsForContractMapper = new ParameterizedRowMapper<PLMBomSalesData>() {
		public PLMBomSalesData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMBomSalesData tempData = new PLMBomSalesData();
			tempData.setPartName(PLMUtils.checkNullVal(rs.getString("UNIQUE_NAME")));
			tempData.setPartId(PLMUtils.checkNullVal(rs.getString("PART_ID")));
			tempData.setPartRev(PLMUtils.checkNullVal(rs.getString("PART_REV")));
			tempData.setPartVal(tempData.getPartId()+"~"+tempData.getPartName()+"~"+tempData.getPartRev());
			return tempData;
		}
	}
	/**
	 * @return PLMBomSalesData objects.
	 */
	private static final class BomContractResultMapper implements ParameterizedRowMapper<PLMBomSalesData> {
//	private static ParameterizedRowMapper<PLMBomSalesData> bomContractResultMapper = new ParameterizedRowMapper<PLMBomSalesData>() {
		public PLMBomSalesData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMBomSalesData tempData = new PLMBomSalesData();
			tempData.setBomLevel(PLMUtils.checkNullVal(rs.getString("BOM_LEVEL")));
			tempData.setMlNum(PLMUtils.checkNullVal(rs.getString("GE_BOM_PREFIX")));
			tempData.setPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
			tempData.setBomRevision(PLMUtils.checkNullVal(rs.getString("PART_REVISION")));
			tempData.setDescription(PLMUtils.checkNullVal(rs.getString("PART_DESCRIPTION")));
			tempData.setState(PLMUtils.checkNullVal(rs.getString("PART_STATE")));
			tempData.setQuantity(PLMUtils.checkNullVal(rs.getString("QTY")));
			tempData.setUnitOfMeasure(PLMUtils.checkNullVal(rs.getString("UOM")));
			tempData.setCompared(false);			
			return tempData;
		}
	}
	/**
	 * @return PLMBomSalesData objects.
	 */
	private static final class SalesContractResultMapper implements ParameterizedRowMapper<PLMBomSalesData> {
//	private static ParameterizedRowMapper<PLMBomSalesData> salesContractResultMapper = new ParameterizedRowMapper<PLMBomSalesData>() {
		public PLMBomSalesData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMBomSalesData tempData = new PLMBomSalesData();
			tempData.setSalesID(PLMUtils.checkNullVal(rs.getString("SALES_ORDER")));
			tempData.setUnitSerialNumber(PLMUtils.checkNullVal(rs.getString("UNIT_SERIAL_NUMBER")));
			tempData.setMlNum(PLMUtils.checkNullVal(rs.getString("MLI")));
			tempData.setPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
			tempData.setDescription(PLMUtils.checkNullVal(rs.getString("PART_DESCRIPTION")));
			tempData.setErpLineNumber(PLMUtils.checkNullVal(rs.getString("ERP_LINE_NUM")));
			tempData.setQuantity(PLMUtils.checkNullVal(rs.getString("QTY")));
			tempData.setUnitOfMeasure(PLMUtils.checkNullVal(rs.getString("UOM")));
			tempData.setRequestedShipDate(PLMUtils.checkNullVal(rs.getString("REQ_SHIP_DATE")));
			tempData.setState(PLMUtils.checkNullVal(rs.getString("SOL_STATE")));
			tempData.setLineStatus(PLMUtils.checkNullVal(rs.getString("LINE_STATUS")));
			tempData.setInternalComments(PLMUtils.checkNullVal(rs.getString("INTERNAL_COMMENTS")));
			tempData.setExternalComments(PLMUtils.checkNullVal(rs.getString("EXTERNAL_COMMENTS")));
			tempData.setPromisedDate(PLMUtils.checkNullVal(rs.getString("PROMISE_DTTM")));
			tempData.setShipDate(PLMUtils.checkNullVal(rs.getString("SHIP_DTTM")));
			tempData.setDelivery(PLMUtils.checkNullVal(rs.getString("DELIVERY")));
			tempData.setTrackingLpn(PLMUtils.checkNullVal(rs.getString("TRACKING_LPN_NM")));
			tempData.setCompared(false);
			return tempData;
		}
	}

//Added for MBOM Vs SO Report
	
	/**
	 * This method is used to getMBOMDataForContract
	 * @param contractNumber
	 * @param partNumber
	 * @return List
	 * @throws PLMCommonException
	 */

	
	public List<PLMBomSalesData> getMBOMDataForContract(String contractNumber, String partNumber) 
	throws PLMCommonException {
		
		List<PLMBomSalesData> plmMBomSalesDataResultList_Final = new ArrayList<PLMBomSalesData>();
//		List<PLMBomSalesData> plmMBomSalesDataResultList = new ArrayList<PLMBomSalesData>();
//		List<PLMBomSalesData> plmMBomSalesDataResultList1 = new ArrayList<PLMBomSalesData>();
		List<String> mbomPartsForContractLst = new ArrayList<String>();
		LOG.info("Getting MBOM details for Contract Number = "+contractNumber+"  Part Number "+partNumber);
		mbomPartsForContractLst.add(partNumber);
		if(mbomPartsForContractLst.size() > 0){
			LOG.info("Query for Getting MBOM Data For Part: "+partNumber+" is:: " + PLMOfflineQueries.GET_MBOM_DATA_FOR_CONTRACT);
			List<PLMBomSalesData> plmMBomSalesDataResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_MBOM_DATA_FOR_CONTRACT, 
					new MbomContractResultMapper(), partNumber);
			List<PLMBomSalesData> plmMBomSalesDataResultList1=plmMBomSalesDataResultList;
			LOG.info("plmMBomSalesDataResultList >> "+plmMBomSalesDataResultList.size());
			LOG.info("plmMBomSalesDataResultList1 >> "+plmMBomSalesDataResultList1.size());

			for (PLMBomSalesData mbomdata1 : plmMBomSalesDataResultList){
				
				if (mbomdata1.getPartName().endsWith("-A")){
					plmMBomSalesDataResultList_Final.add(mbomdata1);
					
					String tempParentName1=mbomdata1.getPartName();
					
					  for (PLMBomSalesData mbomdata2 : plmMBomSalesDataResultList1){	
						if(mbomdata2.getParentName().equalsIgnoreCase(tempParentName1) 
								&& (!mbomdata2.getPartName().equals(""))){
							plmMBomSalesDataResultList_Final.add(mbomdata2);
						}
					}
				} else if (mbomdata1.getPartName().endsWith("-C")){
					plmMBomSalesDataResultList_Final.add(mbomdata1);
				}
			}

			LOG.info("Result of MBOM Parts For a Contract : " + plmMBomSalesDataResultList_Final.size());
		}
		return plmMBomSalesDataResultList_Final;
	}

	/**
	 * @return PLMBomSalesData objects.
	 */
	private static final class MbomContractResultMapper implements ParameterizedRowMapper<PLMBomSalesData> {
//	private static ParameterizedRowMapper<PLMBomSalesData> mbomContractResultMapper = new ParameterizedRowMapper<PLMBomSalesData>() {
		public PLMBomSalesData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMBomSalesData tempData = new PLMBomSalesData();
			tempData.setBomLevel(PLMUtils.checkNullVal(rs.getString("LEVEL")));
			tempData.setMlNum(PLMUtils.checkNullVal(rs.getString("CHILD_ITEM_PREFIX")));
			tempData.setParentName(PLMUtils.checkNullVal(rs.getString("PARENT_ITEM")));
			tempData.setPartName(PLMUtils.checkNullVal(rs.getString("CHILD_ITEM")));
			tempData.setBomRevision(PLMUtils.checkNullVal(rs.getString("ITEM_ADD_REVISION")));
			tempData.setDescription(PLMUtils.checkNullVal(rs.getString("CHILD_DESC")));
			//tempData.setState(PLMUtils.checkNullVal(rs.getString("PART_STATE")));
			tempData.setQuantity(PLMUtils.checkNullVal(rs.getString("QUANTITY")));
			tempData.setUnitOfMeasure(PLMUtils.checkNullVal(rs.getString("UOM_DESC")));
			tempData.setPartModDate(rs.getDate("ITEM_EFFECTIVITY_START_DT"));

			tempData.setCompared(false);			
			return tempData;
		}
	}
	
	/**
	 * This method is used to getMSalesDataForContract
	 * @param contractNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	@SuppressWarnings("unchecked")
	public List<PLMBomSalesData> getMSalesDataForContract(String contractNumber) throws PLMCommonException {
		List<PLMBomSalesData> plmMBomSalesDataResultList = new ArrayList<PLMBomSalesData>();
//		List<String> msalesForContractLst = new ArrayList<String>();
		Map<String, Object> params = new HashMap<String, Object>();
		LOG.info("Query for Getting Sales ID's For a Contract Number: " 
				+ PLMOfflineQueries.GET_SALES_FOR_CONTRACT);
		List<String> msalesForContractLst = getSimpleJdbcTemplate().query
		(PLMOfflineQueries.GET_SALES_FOR_CONTRACT, new MbomSalesForContractMapper(), contractNumber);
		LOG.info("Sales ID's list size : "+msalesForContractLst.size());
		if(msalesForContractLst.size() > 0){
			LOG.info("msalesForContractLst>> "+msalesForContractLst.size());
			params.put("MSLCNTR", msalesForContractLst);
			LOG.info("Query for Getting Sales Data For Parts: " + PLMOfflineQueries.GET_MSALES_DATA_FOR_CONTRACT_ONE);
			plmMBomSalesDataResultList = getNamedJdbcTemplate().query(PLMOfflineQueries.GET_MSALES_DATA_FOR_CONTRACT_ONE,
					params,new MsalesContractResultMapper());
			LOG.info("Sales data for contract fetched successfully....." );
			LOG.info("Result of Sales For a Contract : " + plmMBomSalesDataResultList.size());
			
		}
		return plmMBomSalesDataResultList;
	}
	/**
	 * @return String objects.
	 */
	private static final class MbomSalesForContractMapper implements ParameterizedRowMapper<String> {
//	private static ParameterizedRowMapper<String> mbomSalesForContractMapper = new ParameterizedRowMapper<String>() {
		public String mapRow(ResultSet rs, int rowCount) throws SQLException {
			return PLMUtils.checkNullVal(rs.getString("UNIQUE_NAME"));
		}
	}
	
	/**
	 * @return PLMBomSalesData objects.
	 */
	private static final class MsalesContractResultMapper implements ParameterizedRowMapper<PLMBomSalesData> {
//	private static ParameterizedRowMapper<PLMBomSalesData> msalesContractResultMapper = new ParameterizedRowMapper<PLMBomSalesData>() {
		public PLMBomSalesData mapRow(ResultSet rs, int rowCount) throws SQLException {
			
			PLMBomSalesData tempData = new PLMBomSalesData();
			tempData.setLmDate(rs.getTimestamp("LMD"));
			tempData.setSalesID(PLMUtils.checkNullVal(rs.getString("SALES_ORDER")));
			tempData.setUnitSerialNumber(PLMUtils.checkNullVal(rs.getString("UNIT_SERIAL_NUMBER")));
			tempData.setMlNum(PLMUtils.checkNullVal(rs.getString("MLI")));
			tempData.setPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
			tempData.setDescription(PLMUtils.checkNullVal(rs.getString("PART_DESCRIPTION")));
			tempData.setErpLineNumber(PLMUtils.checkNullVal(rs.getString("ERP_LINE_NUM")));
			tempData.setQuantity(PLMUtils.checkNullVal(rs.getString("QTY")));
			tempData.setUnitOfMeasure(PLMUtils.checkNullVal(rs.getString("UOM")));
			tempData.setRequestedShipDate(PLMUtils.checkNullVal(rs.getString("REQ_SHIP_DATE")));
			tempData.setState(PLMUtils.checkNullVal(rs.getString("SOL_STATE")));
			tempData.setLineStatus(PLMUtils.checkNullVal(rs.getString("LINE_STATUS")));
			tempData.setInternalComments(PLMUtils.checkNullVal(rs.getString("INTERNAL_COMMENTS")));
			tempData.setExternalComments(PLMUtils.checkNullVal(rs.getString("EXTERNAL_COMMENTS")));
			tempData.setCompared(false);
			return tempData;
		}
	}
	
	/**
	 * This method is used to getPartsForProject
	 * @param projectNumber
	 * @return List
	 * @throws PLMCommonException
	 */
	public List<PLMBomSalesData> getPartsForProject(String projectNumber) throws PLMCommonException {
//		List<PLMBomSalesData> mbomPartsForProjectLst = new ArrayList<PLMBomSalesData>();
		List<PLMBomSalesData> mbomPartsForProjectLst = getSimpleJdbcTemplate().
		query(PLMOfflineQueries.GET_MBOM_PARTS_FOR_PROJECT1, new PartsForProjectMapper(), projectNumber,projectNumber,projectNumber,projectNumber);		
		LOG.info("Executed Query:"+PLMOfflineQueries.GET_MBOM_PARTS_FOR_PROJECT1);
		if(mbomPartsForProjectLst.size()>0){
			LOG.info("mbomPartsForProjectLst>>"+mbomPartsForProjectLst.size());
		}
		return mbomPartsForProjectLst;
	}
	
	/**
	 * @return PLMBomSalesData objects.
	 */
	private static final class PartsForProjectMapper implements ParameterizedRowMapper<PLMBomSalesData> {
//	private static ParameterizedRowMapper<PLMBomSalesData> partsForProjectMapper 
//		= new ParameterizedRowMapper<PLMBomSalesData>() {
		public PLMBomSalesData mapRow(ResultSet rs, int rowCount) throws SQLException {
			PLMBomSalesData tempData = new PLMBomSalesData();
			tempData.setPartName(PLMUtils.checkNullVal(rs.getString("TOP_PART")));
			tempData.setContractNo(PLMUtils.checkNullVal(rs.getString("CONTRACT")));
			return tempData;
		}
	}
	/**
	 * This method is used to getPartsForNonMlMpl
	 * @param nonMlMplList
	 * @return List
	 * @throws PLMCommonException
	 */

	@SuppressWarnings("unchecked")
	@Override
	public List<PLMBomSalesData> getPartsForNonMlMpl(List<String> nonMlMplList)
			throws PLMCommonException {
//		List<PLMBomSalesData> mbomPartsForProjectLst1 = new ArrayList<PLMBomSalesData>();
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("NONMLPL", nonMlMplList);
		List<PLMBomSalesData> mbomPartsForProjectLst1 = getNamedJdbcTemplate().
		query(PLMOfflineQueries.GET_MBOM_PARTS_FOR_PROJECT2, params,new PartsForNonMpMplMapper());
		if(mbomPartsForProjectLst1.size()>0){
			LOG.info("mbomPartsForProjectLst1 "+mbomPartsForProjectLst1.size());
		}
		LOG.info("Executed Query:"+PLMOfflineQueries.GET_MBOM_PARTS_FOR_PROJECT2);
		return mbomPartsForProjectLst1;
		
	}

	/**
	 * @return PLMDocGenFmiData objects.
	 */
	private static final class PartsForNonMpMplMapper implements ParameterizedRowMapper<PLMBomSalesData> {
	/*private static ParameterizedRowMapper<PLMBomSalesData> partsForNonMpMplMapper 
	= new ParameterizedRowMapper<PLMBomSalesData>() {*/
	public PLMBomSalesData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMBomSalesData tempData = new PLMBomSalesData();
		tempData.setPartName(PLMUtils.checkNullVal(rs.getString("TOP_PART")));
		tempData.setContractNo("");
		return tempData;
	}
}

/**
 * 
 * class to sort list of object of type PLMDocGenFmiData.
 * 
 */
private static class SortEbomData implements Comparator<PLMDocGenFmiData>,
		Serializable {
	/**
	 * long serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * used for comparision..
	 */
	public int compare(PLMDocGenFmiData aString,
			PLMDocGenFmiData bString) {
		String aStr;
		String bStr;
		int result=0;
		aStr = aString.getDfsOrder();
		bStr = bString.getDfsOrder();
		if(aStr != null && bStr != null){
		result = aStr.compareTo(bStr);
		}
		return result;
		
	}
}

/**
 * This method is used to fetchEbomData
 * @param ebomId, lvl
 * @return List
 * @throws PLMCommonException
 */
public List<PLMDocGenFmiData> fetchEbomData(String ebomId,String lvl) throws PLMCommonException{
	LOG.info("Executing queryForParts Query : " + PLMOfflineQueries.GET_EBOM_DATA_FOR_FMI + "\n");
	LOG.info("eBomId------------->"+ebomId);
	LOG.info("Level------------->"+lvl);
	List<PLMDocGenFmiData> ebomDataList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_EBOM_DATA_FOR_FMI, new EbomDataMapper(), new Object[]{ebomId,lvl});
	Collections.sort(ebomDataList, new SortEbomData()); //Sorting mlidetailslist
	return ebomDataList;
}

/**
 * @return PLMDocGenFmiData objects.
 */
private static final class EbomDataMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
//private static ParameterizedRowMapper<PLMDocGenFmiData> ebomDataMapper = new ParameterizedRowMapper<PLMDocGenFmiData>() {
	public PLMDocGenFmiData mapRow(ResultSet rs, int rowcount)
			throws SQLException {
		PLMDocGenFmiData data = new PLMDocGenFmiData();
		//data.setParentId(PLMUtils.checkNullVal(rs.getString("PARENT_ID")));
		//data.setParentName1(PLMUtils.checkNullVal(rs.getString("PARENT_NAME")));
		//data.setParentRev(PLMUtils.checkNullVal(rs.getString("PARENT_REV")));
		//data.setChildId(PLMUtils.checkNullVal(rs.getString("CHILD_ID")));
		//data.setChildName(PLMUtils.checkNullVal(rs.getString("CHILD_NAME")));
		//data.setChildRev(PLMUtils.checkNullVal(rs.getString("CHILD_REV")));
		//data.setChildDesc(PLMUtils.checkNullVal(rs.getString("CHILD_DESC")));
		data.setLevel(PLMUtils.checkNullVal(rs.getString("LVL")));
		//data.setDfsOrder(PLMUtils.checkNullVal(rs.getString("DFSORDER")));
		data.setPartName(PLMUtils.checkNullVal(rs.getString("PART_NAME")));
		data.setPartDesc(PLMUtils.checkNullVal(rs.getString("PART_DESCRIPTION")));
		data.setQuantity1(PLMUtils.convertQtyLimit(rs.getString("QUANTITY")));
		data.setGeBomPrefix(PLMUtils.checkNullVal(rs.getString("GE_BOM_PREFIX")));
		data.setUom1(PLMUtils.checkNullVal(rs.getString("UOM")));
		return data;
	}
}

/**
 * This method is used to loadEbomTable
 * @param ebomDataList, strbEbomTable
 * @return StringBuffer
 */
public StringBuffer loadEbomTable(List<PLMDocGenFmiData> ebomDataList, StringBuffer strbEbomTable) {
	

	strbEbomTable.append("\\par ");
	//}
	strbEbomTable.append("}\\trowd \\trgaph108\\");
	strbEbomTable.append("trleft200\\trbrdrt\\brdrs\\brdrw15 ");
	strbEbomTable.append("\\trbrdrl");
	strbEbomTable.append("\\brdrs\\brdrw15 \\trbrdrb\\brdrs");
	strbEbomTable.append("\\brdrw15 \\");
	strbEbomTable.append("trbrdrr\\brdrs\\brdrw15 \\");
	strbEbomTable.append("trbrdrh\\brdrs\\");
	strbEbomTable.append("brdrw15 \\trbrdrv\\brdrs\\");
	strbEbomTable.append("brdrw15 \\");
	//--Level
	strbEbomTable.append("clvertalt\\clbrdrt\\brdrs\\brdrw15 \\");
	strbEbomTable.append("clbrdrl\\brdrs\\");
	strbEbomTable.append("brdrw15 \\clbrdrb\\brdrs\\");
	strbEbomTable.append("brdrw15 \\clbrdrr\\");
	strbEbomTable.append("brdrs\\brdrw15 \\cltxlrtb \\");
	strbEbomTable.append("cellx1000\\");
	//PartNumber
	strbEbomTable.append("clvertalt\\clbrdrt\\brdrs\\");
	strbEbomTable.append("brdrw15 \\clbrdrl");
	strbEbomTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
	strbEbomTable.append("brdrs\\brdrw15 \\");
	strbEbomTable.append("clbrdrr\\brdrs\\brdrw15 \\");
	strbEbomTable.append("cltxlrtb \\");
	strbEbomTable.append("cellx2700\\");
	//Description
	strbEbomTable.append("clvertalt\\clbrdrt\\brdrs\\");
	strbEbomTable.append("brdrw15 \\clbrdrl");
	strbEbomTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
	strbEbomTable.append("brdrs\\brdrw15 \\");
	strbEbomTable.append("clbrdrr\\brdrs\\brdrw15 \\");
	strbEbomTable.append("cltxlrtb \\");
	strbEbomTable.append("cellx8350\\");
		
	//--Child
	/*strbEbomTable.append("\\clvertalt\\clbrdrt\\");
	strbEbomTable.append("brdrs\\brdrw15");
	strbEbomTable.append(" \\clbrdrl\\brdrs\\brdrw15 \\");
	strbEbomTable.append("clbrdrb\\brdrs\\");
	strbEbomTable.append("brdrw15 \\clbrdrr\\brdrs\\");
	strbEbomTable.append("brdrw15 \\cltxlrtb ");
	strbEbomTable.append("\\cellx4400");
	//--Child Description
	strbEbomTable.append("\\clvertalt\\clbrdrt");
	strbEbomTable.append("\\brdrs\\");
	strbEbomTable.append("brdrw15 \\clbrdrl\\brdrs\\");
	strbEbomTable.append("brdrw15 \\clbrdrb");
	strbEbomTable.append("\\brdrs\\brdrw15 \\clbrdrr\\");
	strbEbomTable.append("brdrs\\brdrw15");
	strbEbomTable.append(" \\cltxlrtb \\cellx8350\\");*/
	//--BOM Prefix
	strbEbomTable.append("clvertalt\\clbrdrt");
	strbEbomTable.append("\\brdrs\\brdrw15 \\clbrdrl\\");
	strbEbomTable.append("brdrs\\brdrw15");
	strbEbomTable.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
	strbEbomTable.append("clbrdrr\\brdrs");
	strbEbomTable.append("\\brdrw15 \\cltxlrtb \\");
	strbEbomTable.append("cellx9300\\");
	//--Qty
	strbEbomTable.append("clvertalt\\clbrdrt");
	strbEbomTable.append("\\brdrs\\brdrw15 \\clbrdrl\\");
	strbEbomTable.append("brdrs\\brdrw15");
	strbEbomTable.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
	strbEbomTable.append("clbrdrr\\brdrs");
	strbEbomTable.append("\\brdrw15 \\cltxlrtb \\");
	strbEbomTable.append("cellx10050\\");
	//--UOM
	strbEbomTable.append("clvertalt\\clbrdrt");
	strbEbomTable.append("\\brdrs\\brdrw15 \\clbrdrl\\");
	strbEbomTable.append("brdrs\\brdrw15");
	strbEbomTable.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
	strbEbomTable.append("clbrdrr\\brdrs");
	strbEbomTable.append("\\brdrw15 \\cltxlrtb \\");
	strbEbomTable.append("cellx11000\\");
	
    /* //--Doc Rev
	strMliTable.append("clvertalt\\clbrdrt\\brdrs\\");
	strMliTable.append("brdrw15 \\clbrdrl");
	strMliTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
	strMliTable.append("brdrs\\brdrw15 \\");
	strMliTable.append("clbrdrr\\brdrs\\brdrw15 \\");
	strMliTable.append("cltxlrtb \\");
	strMliTable.append("cellx7200\\");
	
	//--DWG State
	strMliTable.append("clvertalt\\clbrdrt\\brdrs\\");
	strMliTable.append("brdrw15 \\clbrdrl");
	strMliTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
	strMliTable.append("brdrs\\brdrw15 \\");
	strMliTable.append("clbrdrr\\brdrs\\brdrw15 \\");
	strMliTable.append("cltxlrtb \\");
	strMliTable.append("cellx8500\\");
	
	//--Description 
	strMliTable.append("clvertalt\\clbrdrt\\brdrs\\");
	strMliTable.append("brdrw15 \\clbrdrl");
	strMliTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
	strMliTable.append("brdrs\\brdrw15 \\");
	strMliTable.append("clbrdrr\\brdrs\\brdrw15 \\");
	strMliTable.append("cltxlrtb \\");
	strMliTable.append("cellx10150\\");
	
	//--Notes
	strMliTable.append("clvertalt\\clbrdrt\\brdrs\\");
	strMliTable.append("brdrw15 \\clbrdrl");
	strMliTable.append("\\brdrs\\brdrw15 \\clbrdrb\\");
	strMliTable.append("brdrs\\brdrw15 \\");
	strMliTable.append("clbrdrr\\brdrs\\brdrw15 \\");
	strMliTable.append("cltxlrtb \\");
	strMliTable.append("cellx10950\\");*/
	
	strbEbomTable.append("pard \\qc\\");
	strbEbomTable.append("widctlpar\\intbl\\adjustright {\\fonttbl {\\f0\\froman GE Inspira;}} {\\b\\f0\\fs22 ");
	//strbEbomTable.append("widctlpar\\intbl\\adjustright {\\b\\fs22 ");
	strbEbomTable.append("Level\\cell Part Number\\cell Description\\cell ");
	//strbEbomTable.append("Level\\cell Parent\\cell Child\\cell ");
	//strbEbomTable.append("Child Description\\cell ");
	strbEbomTable.append("BOM Prefix\\cell ");
	strbEbomTable.append("Qty\\cell ");
	strbEbomTable.append("UOM\\cell ");
//	strMliTable.append("----\\cell ");
//	strMliTable.append("----\\cell ");
//	strMliTable.append("-----\\cell ");
//	strMliTable.append("----\\cell ");
	strbEbomTable.append(" }\\pard \\widctlpar\\intbl\\adjustright {\\");
	strbEbomTable.append("b\\fs22 \\row }\\");
	strbEbomTable.append("pard\\plain \\s15\\widctlpar\\adjustright ");
	strbEbomTable.append("\\cgrid {");
	StringBuffer strbMliTableRow = new StringBuffer("");
	for (int i = 0; i < ebomDataList.size(); i++) {
		 strbMliTableRow.append("}\\trowd \\trgaph108\\");
			strbMliTableRow.append("trleft200\\trbrdrt\\brdrs\\brdrw15 ");
			strbMliTableRow.append("\\trbrdrl");
			strbMliTableRow.append("\\brdrs\\brdrw15 \\trbrdrb\\brdrs");
			strbMliTableRow.append("\\brdrw15 \\");
			strbMliTableRow.append("trbrdrr\\brdrs\\brdrw15 \\");
			strbMliTableRow.append("trbrdrh\\brdrs\\");
			strbMliTableRow.append("brdrw15 \\trbrdrv\\brdrs\\");
			strbMliTableRow.append("brdrw15 \\");
			//--Level
			strbMliTableRow.append("clvertalt\\clbrdrt\\brdrs\\brdrw15 \\");
			strbMliTableRow.append("clbrdrl\\brdrs\\");
			strbMliTableRow.append("brdrw15 \\clbrdrb\\brdrs\\");
			strbMliTableRow.append("brdrw15 \\clbrdrr\\");
			strbMliTableRow.append("brdrs\\brdrw15 \\cltxlrtb \\");
			strbMliTableRow.append("cellx1000\\");
			//PartNumber
			strbMliTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
			strbMliTableRow.append("brdrw15 \\clbrdrl");
			strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
			strbMliTableRow.append("brdrs\\brdrw15 \\");
			strbMliTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
			strbMliTableRow.append("cltxlrtb \\");
			strbMliTableRow.append("cellx2700\\");
			//Description
			strbMliTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
			strbMliTableRow.append("brdrw15 \\clbrdrl");
			strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
			strbMliTableRow.append("brdrs\\brdrw15 \\");
			strbMliTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
			strbMliTableRow.append("cltxlrtb \\");
			strbMliTableRow.append("cellx8350\\");
			//--Child
			/*strbMliTableRow.append("\\clvertalt\\clbrdrt\\");
			strbMliTableRow.append("brdrs\\brdrw15");
			strbMliTableRow.append(" \\clbrdrl\\brdrs\\brdrw15 \\");
			strbMliTableRow.append("clbrdrb\\brdrs\\");
			strbMliTableRow.append("brdrw15 \\clbrdrr\\brdrs\\");
			strbMliTableRow.append("brdrw15 \\cltxlrtb ");
			strbMliTableRow.append("\\cellx4400");
			//--Child Description
			strbMliTableRow.append("\\clvertalt\\clbrdrt");
			strbMliTableRow.append("\\brdrs\\");
			strbMliTableRow.append("brdrw15 \\clbrdrl\\brdrs\\");
			strbMliTableRow.append("brdrw15 \\clbrdrb");
			strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrr\\");
			strbMliTableRow.append("brdrs\\brdrw15");
			strbMliTableRow.append(" \\cltxlrtb \\cellx8350\\");*/
			//--BOM Prefix
			strbMliTableRow.append("clvertalt\\clbrdrt");
			strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrl\\");
			strbMliTableRow.append("brdrs\\brdrw15");
			strbMliTableRow.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
			strbMliTableRow.append("clbrdrr\\brdrs");
			strbMliTableRow.append("\\brdrw15 \\cltxlrtb \\");
			strbMliTableRow.append("cellx9300\\");
			//--Qty
			strbMliTableRow.append("clvertalt\\clbrdrt");
			strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrl\\");
			strbMliTableRow.append("brdrs\\brdrw15");
			strbMliTableRow.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
			strbMliTableRow.append("clbrdrr\\brdrs");
			strbMliTableRow.append("\\brdrw15 \\cltxlrtb \\");
			strbMliTableRow.append("cellx10050\\");
			//--UOM
			strbMliTableRow.append("clvertalt\\clbrdrt");
			strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrl\\");
			strbMliTableRow.append("brdrs\\brdrw15");
			strbMliTableRow.append(" \\clbrdrb\\brdrs\\brdrw15 \\");
			strbMliTableRow.append("clbrdrr\\brdrs");
			strbMliTableRow.append("\\brdrw15 \\cltxlrtb \\");
			strbMliTableRow.append("cellx11000\\");
			
/*	        //--Doc Rev
			strbMliTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
			strbMliTableRow.append("brdrw15 \\clbrdrl");
			strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
			strbMliTableRow.append("brdrs\\brdrw15 \\");
			strbMliTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
			strbMliTableRow.append("cltxlrtb \\");
			strbMliTableRow.append("cellx7200\\");
			
			//--DWG State
			strbMliTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
			strbMliTableRow.append("brdrw15 \\clbrdrl");
			strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
			strbMliTableRow.append("brdrs\\brdrw15 \\");
			strbMliTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
			strbMliTableRow.append("cltxlrtb \\");
			strbMliTableRow.append("cellx8500\\");
			
			//--Description 
			strbMliTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
			strbMliTableRow.append("brdrw15 \\clbrdrl");
			strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
			strbMliTableRow.append("brdrs\\brdrw15 \\");
			strbMliTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
			strbMliTableRow.append("cltxlrtb \\");
			strbMliTableRow.append("cellx10150\\");
			
			//--Notes
			strbMliTableRow.append("clvertalt\\clbrdrt\\brdrs\\");
			strbMliTableRow.append("brdrw15 \\clbrdrl");
			strbMliTableRow.append("\\brdrs\\brdrw15 \\clbrdrb\\");
			strbMliTableRow.append("brdrs\\brdrw15 \\");
			strbMliTableRow.append("clbrdrr\\brdrs\\brdrw15 \\");
			strbMliTableRow.append("cltxlrtb \\");
			strbMliTableRow.append("cellx10950\\");*/
			
			strbMliTableRow.append("pard\\qc \\widctlpar\\intbl\\");
			strbMliTableRow.append("adjustright ");
			strbMliTableRow.append("\\cgrid ");
			strbMliTableRow.append("{\\fs22 ");
			strbMliTableRow.append(ebomDataList.get(i).getLevel());
			strbMliTableRow.append("\\cell }{\\fs22 ");
			/*strbMliTableRow.append("\\cf6 ");*/
			strbMliTableRow.append(ebomDataList.get(i).getPartName());
			strbMliTableRow.append("\\cell }{\\fs22 ");
			/*strbMliTableRow.append(ebomDataList.get(i).getChildName());
			strbMliTableRow.append("\\cell ");
			strbMliTableRow.append(ebomDataList.get(i).getChildDesc());*/
			strbMliTableRow.append(ebomDataList.get(i).getPartDesc());
			strbMliTableRow.append("\\cell ");
			strbMliTableRow.append(ebomDataList.get(i).getGeBomPrefix());
			strbMliTableRow.append("\\cell ");
			strbMliTableRow.append(ebomDataList.get(i).getQuantity1());
			strbMliTableRow.append("\\cell ");
			strbMliTableRow.append(ebomDataList.get(i).getUom1());
			strbMliTableRow.append("\\cell }");
//			strbMliTableRow.append("");
//			strbMliTableRow.append("\\cell ");
//			strbMliTableRow.append("");
//			strbMliTableRow.append("\\cell ");
//			strbMliTableRow.append("");
//			strbMliTableRow.append("\\cell ");
//			strbMliTableRow.append("");
//			strbMliTableRow.append("\\cell }");
			
			
			/*LOG.info("ebomDataList.get(i).getLevel() " + ebomDataList.get(i).getLevel());
			LOG.info("ebomDataList.get(i).getParentName1() " + ebomDataList.get(i).getParentName1());
			LOG.info("ebomDataList.get(i).getChildName() " + ebomDataList.get(i).getChildName());
			LOG.info("ebomDataList.get(i).getChildDesc() " + ebomDataList.get(i).getChildDesc());
			LOG.info("ebomDataList.get(i).getGeBomPrefix() " + ebomDataList.get(i).getGeBomPrefix());
			LOG.info("ebomDataList.get(i).getQuantity1() " + ebomDataList.get(i).getQuantity1());
			LOG.info("ebomDataList.get(i).getUom() " + ebomDataList.get(i).getUom());*/

			
			strbMliTableRow.append("\\pard \\widctlpar\\intbl\\");
			strbMliTableRow.append("adjustright {\\");
			strbMliTableRow.append("fs24 \\row  }\\pard\\plain \\");
			strbMliTableRow.append("s15\\widctlpar\\");
			strbMliTableRow.append("adjustright \\fs24\\cgrid {");
		}
		strbEbomTable.append(strbMliTableRow);
		return strbEbomTable;
}


public List<PLMDocGenFmiData> fetchReqData(String contractNo) throws PLMCommonException{
	LOG.info("Executing GET_REQ_DATA Query : " + PLMOfflineQueries.GET_REQ_DATA + "\n");
	LOG.info("contractNo------------->"+contractNo);
	List<PLMDocGenFmiData> reqDataList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_REQ_DATA, new ReqDataMapper(), new Object[]{contractNo});
	return reqDataList;
}

private static final class ReqDataMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
//private static ParameterizedRowMapper<PLMDocGenFmiData> reqDataMapper = new ParameterizedRowMapper<PLMDocGenFmiData>() {
	public PLMDocGenFmiData mapRow(ResultSet rs, int rowcount)
			throws SQLException {
		PLMDocGenFmiData data = new PLMDocGenFmiData();
		data.setCntrctNm(rs.getString("CONTRACT"));
		data.setReqNm(rs.getString("REQUIREMENT_NAME"));
		data.setReqRev(rs.getString("REQUIREMENT_REV"));
		data.setSrcBkType(rs.getString("SOURCE_BOOK_TYPE"));
		return data;
	}
}

public List<PLMDocGenFmiData> fetchCeiData(String contractNo) throws PLMCommonException{
	LOG.info("Executing GET_CEI_DATA Query : " + PLMOfflineQueries.GET_CEI_DATA + "\n");
	LOG.info("contractNo------------->"+contractNo);
	List<PLMDocGenFmiData> ceiDataList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_CEI_DATA, new CeiDataMapper(), new Object[]{contractNo});
	return ceiDataList;
}

private static final class CeiDataMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
//private static ParameterizedRowMapper<PLMDocGenFmiData> ceiDataMapper = new ParameterizedRowMapper<PLMDocGenFmiData>() {
	public PLMDocGenFmiData mapRow(ResultSet rs, int rowcount)
			throws SQLException {
		PLMDocGenFmiData data = new PLMDocGenFmiData();
		data.setCntrctNm1(rs.getString("NM"));
		data.setCiNum(rs.getString("CI_NUMBER"));
		//data.setCiDisplayName(rs.getString("CI_DISPLAY_NAME"));
		return data;
	}
}





//Newly Added for FMI New Unit Search
/**
 * This method is used to get FMI New Unit details
 * 
 * @param fmidetails
 * @return List
 * @throws PLMCommonException
 */
@SuppressWarnings("unchecked")
public List<PLMDocGenFmiData> getFmiNewUnitDetails(PLMDocGenFmiData fmidetails)
		throws PLMCommonException{

	LOG.info("Entering getFmiNewUnitDetails Method");
	String contractNo = fmidetails.getContractnumber();
	List<PLMDocGenFmiData> searchResultList = new ArrayList<PLMDocGenFmiData>(); 
	StringBuffer unitSerialNewUnitQuery = new StringBuffer();
	Map<String, Object> params = new HashMap<String, Object>();
	try{
		LOG.info("Query for Customer Name and Title : " + PLMOfflineQueries.GET_CUSTOMER_AND_TITLE);
		searchResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_CUSTOMER_AND_TITLE, new FmiTitleMapper(), new Object[] { contractNo });
		if (!PLMUtils.isEmptyList(searchResultList)) {
			fmidetails.setCustomer(searchResultList.get(0).getCustomer());
			fmidetails.setTitle(searchResultList.get(0).getTitle());
		}else{
			fmidetails.setCustomer("");
			fmidetails.setTitle("");
		}
		
		unitSerialNewUnitQuery.append(PLMOfflineQueries.GET_UNITSERIAL_FMI_NEW_UNIT1);
		params.put("CNTRT", contractNo);
		if(fmidetails.getSelProduct()!=null && !fmidetails.getSelProduct().equals("BOP")){
			 params.put("PARA", fmidetails.getSelProduct());
			 unitSerialNewUnitQuery.append(PLMOfflineQueries.GET_UNITSERIAL_PRODUCT);
		 }
		 unitSerialNewUnitQuery.append(" "+PLMOfflineQueries.GET_UNITSERIAL_FMI_NEW_UNIT2);
		LOG.info("Query for Serial Number  : " + unitSerialNewUnitQuery);
		searchResultList = getNamedJdbcTemplate().query(unitSerialNewUnitQuery.toString(),params, new UnitSrlNewUnitMapper());
		
		List<String> serialNoList = new ArrayList<String>();
		 
		if (!PLMUtils.isEmptyList(searchResultList)) {
			for(int i=0; i< searchResultList.size(); i++){
				serialNoList.add(searchResultList.get(i).getSerialnumbers());
			}
 			fmidetails.setSerialNoList(serialNoList);
			LOG.info("getting SerialNoList : " +fmidetails.getSerialNoList());
		}
			
		LOG.info("Query for Serial Number and  Distribution : " + PLMOfflineQueries.GET_PROJECTNAMES_FMI_NEW_UNIT);
		searchResultList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_PROJECTNAMES_FMI_NEW_UNIT, new ProjectMapper(),new Object[] { contractNo });
		
		List<String> projectNamesList = new ArrayList<String>();
		 
		if (!PLMUtils.isEmptyList(searchResultList)) {
			for(int i=0; i< searchResultList.size(); i++){
				projectNamesList.add(searchResultList.get(i).getProject());
			}
 			fmidetails.setProjectNamesList(projectNamesList);
			LOG.info("getting projectNamesList : " +fmidetails.getProjectNamesList());
		}
		
			
		searchResultList.add(0, fmidetails);
	  
	}catch (DataAccessException e){
		PLMUtils.checkException(e.getMessage());
	}
	LOG.info("Exiting getFmiDetails Method");
	return searchResultList;

	
}

/**
 * @return PLMDocGenFmiData objects.
 */
private static final class ProjectMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
	public PLMDocGenFmiData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMDocGenFmiData tempData = new PLMDocGenFmiData();
		tempData.setProject(PLMUtils.checkNullVal(rs.getString("PRJ_NM")));

		return tempData;
	}
}


/**
 * This method is used to fetch Contract Info
 * 
 * @param cntrtNm
 * @return List
 * @throws PLMCommonException
 */
public List<PLMDocGenFmiData> fetchCntrInfo(String cntrtNm) throws PLMCommonException{
	LOG.info("Contract Name in DAO------------->"+cntrtNm);
	return getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_CNTRT_INFO, new CntrInfoMapper(), new Object[] {cntrtNm}); 
	
}

/**
 * @return PLMCntrtSmryRptData objects.
 */
private static final class CntrInfoMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
	public PLMDocGenFmiData mapRow(ResultSet rs, int rowcount)
			throws SQLException {
		PLMDocGenFmiData data = new PLMDocGenFmiData();
		data.setContractnumber(rs.getString("NM"));
		return data;
	}
 }

/**
 * @return PLMDocGenFmiData objects.
 */
private static final class UnitSrlNewUnitMapper implements ParameterizedRowMapper<PLMDocGenFmiData> {
	public PLMDocGenFmiData mapRow(ResultSet rs, int rowCount) throws SQLException {
		PLMDocGenFmiData tempData = new PLMDocGenFmiData();
		tempData.setSerialnumbers(PLMUtils.checkNullVal(rs.getString("SERIAL_NUMBER")));
		return tempData;
	}
}

//Newly Added for BOM Vs Sales Comparision Report
/**
 * This method is used to get list of contracts
 * 
 * @param Unit Serial Num
 * @return List
 * @throws PLMCommonException
 */
public List<PLMBomSalesData> getContractNamesList(String unitSerialNm)throws PLMCommonException{
	LOG.info("Entering in to getContractNamesList");
   LOG.info("Executing Query for Getting Contract Names List "+PLMOfflineQueries.GET_UNIT_SRL_FOR_CONTRACTLIST);
	List<PLMBomSalesData> contractNamesList = getSimpleJdbcTemplate().query(PLMOfflineQueries.GET_UNIT_SRL_FOR_CONTRACTLIST, 
			new ContractListMapper(), new Object[]{unitSerialNm});
	Collections.sort(contractNamesList, new SortContractNms());
	return contractNamesList;
}

/**
 * 
 * class to sort list of object of type PLMBomSalesData.
 * 
 */
private static class SortContractNms implements Comparator<PLMBomSalesData>,
		Serializable {
	/**
	 * long serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * used for comparision..
	 */
	public int compare(PLMBomSalesData aString,
			PLMBomSalesData bString) {
		String aStr;
		String bStr;
		int result=0;
		aStr = aString.getContractName();
		bStr = bString.getContractName();
		if(aStr != null && bStr != null){
		result = aStr.compareTo(bStr);
		}
		return result;
		
	}
}
/**
 * @return PLMBomSalesData objects.
 */
private static final class ContractListMapper implements ParameterizedRowMapper<PLMBomSalesData> {
	public PLMBomSalesData mapRow(ResultSet rs, int rowcount)
			throws SQLException {
		PLMBomSalesData data = new PLMBomSalesData();
		data.setContractName(PLMUtils.checkNullVal(rs.getString("CONTRACT")));
	    data.setContractDesc(PLMUtils.checkNullVal(rs.getString("DESCRIPTION")));
		return data;
	}
}

}
