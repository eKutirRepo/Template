package com.geinfra.geaviation.pwi.dao;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.AdminSettingsVO;

/**
 * 
 * Project : Product Lifecycle Management Date Written : May 19, 2010 Security :
 * GE Confidential Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2010 GE All rights reserved
 * 
 * Description : Data access object interface for admin settings.
 * 
 * Revision Log May 19, 2010 | v1.0.
 * --------------------------------------------------------------
 */

public interface AdminSettingsDAO {
	public AdminSettingsVO getSetting(String settingName) throws PWiException;

	public void createSetting(String appparName, String appparVal, String userId)
			throws PWiException;

	public void updateSetting(String appparName, String appparVal, String userId)
			throws PWiException;


}
