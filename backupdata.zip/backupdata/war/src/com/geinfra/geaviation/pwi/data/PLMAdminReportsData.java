/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMAdminReportsData.java
 * @Creation date: 29-Nov-2012
 * @version 2.1.2
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.data;

public class PLMAdminReportsData{
	/**
	  * Holds the sortOrder
	  */
	private int sortOrder;
	/**
	  * Holds the reportName
	  */
	private String reportName="";
	/**
	  * Holds the description
	  */
	private String description="";
	/**
	  * Holds the reportURL
	  */
	private String reportURL="";
	/**
	  * Holds the biSeqId
	  */
	private int biSeqId;

	/**
	 * @return the sortOrder
	 */
	public int getSortOrder() {
		return sortOrder;
	}
	/**
	 * @param sortOrder the sortOrder to set
	 */
	public void setSortOrder(int sortOrder) {
		this.sortOrder = sortOrder;
	}
	/**
	 * @return the reportName
	 */
	public String getReportName() {
		return reportName;
	}
	/**
	 * @param reportName the reportName to set
	 */
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the reportURL
	 */
	public String getReportURL() {
		return reportURL;
	}
	/**
	 * @param reportURL the reportURL to set
	 */
	public void setReportURL(String reportURL) {
		this.reportURL = reportURL;
	}
	/**
	 * @return the biSeqId
	 */
	public int getBiSeqId() {
		return biSeqId;
	}
	/**
	 * @param biSeqId the biSeqId to set
	 */
	public void setBiSeqId(int biSeqId) {
		this.biSeqId = biSeqId;
	}
	
}