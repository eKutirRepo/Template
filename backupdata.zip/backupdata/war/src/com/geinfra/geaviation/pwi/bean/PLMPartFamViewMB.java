/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMPartFamViewMB.java
 * @Creation date: 21-Oct-2016
 * @version 1.0
 * @author : Tech Mahindra (PLMR Team)
 */
package com.geinfra.geaviation.pwi.bean;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;
import java.util.Set;

import javax.faces.application.FacesMessage;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.context.FacesContext;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.richfaces.component.UITree;
import org.richfaces.component.html.HtmlTree;
import org.richfaces.event.NodeExpandedEvent;
import org.richfaces.event.NodeSelectedEvent;
import org.richfaces.model.TreeNode;
import org.richfaces.model.TreeNodeImpl;
import org.richfaces.model.TreeRowKey;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.geinfra.geaviation.pwi.data.PLMInterfaceAttrData;
import com.geinfra.geaviation.pwi.data.PLMPddrData;
import com.geinfra.geaviation.pwi.data.PLMPddrSearchData;
import com.geinfra.geaviation.pwi.data.PLMPwiUserData;
import com.geinfra.geaviation.pwi.service.PLMPartFamViewServiceIfc;
import com.geinfra.geaviation.pwi.util.PLMCommonException;
import com.geinfra.geaviation.pwi.util.PLMConstants;
import com.geinfra.geaviation.pwi.util.PLMUtils;
import com.geinfra.geaviation.pwi.util.UserInfoPortalUtil;

public class PLMPartFamViewMB {
	/**
	 * Holds the Logger
	 */
	private static final Logger LOG = Logger.getLogger(PLMPartFamViewMB.class);
	
	/**
	 * Holds the pddrData
	 */
	private PLMPddrData pddrData = null;
	
	/**
	 * Holds the Login MB
	 */
	private PLMCommonMB commonMB;
	
	/**
	 * Holds the Properties file
	 */
	private ResourceBundle resourceBundle = ResourceBundle.getBundle("com.geinfra.geaviation.pwi.resources.Reports");
	
	/**
	 * The List<String> searchResults.
	 */
	private List<String> searchResults = new ArrayList<String>();
	/**
	 * The List<PLMPddrSearchData> searchResults.
	 */
	private List<PLMPddrSearchData> searchExpResults = new ArrayList<PLMPddrSearchData>();
	/**
	 * The boolean partChildTable
	 */
	private boolean partChildTable;
	/**
	 * The List<PLMPddrData> sbomData
	 */
	private List<PLMPddrData> sbomData = new ArrayList<PLMPddrData>();
	
	/**
	 * The List<ICMSBoMAddIemData> Header Data
	 */
	private PLMPddrSearchData sbomHeaderData = new PLMPddrSearchData();
	/**
	 * The String searchString.
	 */
	private String searchString;
	/**
	 * The String searchString.
	 */
	private String searchSerialString;
	/**
	 * The String alertMsg.
	 */
	private String alertMsgPddr;
	/**
	 * The String resultHeader.
	 */
	private boolean resultHeader;
	/**
	 * The String mplNumber.
	 */
	private String mplNumber;
	/**
	 * The String resultCount.
	 */
	private int resultCount;
	/**
	 * The String toGetPopup.
	 */
	private int toGetPopup;
	/**
	 * The String prdStcres.
	 */
	private int prdStcres;
	/**
	 * The String treeLoad.
	 */
	private int treeLoad;
	/**
	 * The String selectedMPLNo.
	 */
	private String selectedMPLNo;
	/**
	 * The PLMPartFamViewServiceIfc PLMPartFamViewServiceIfc.
	 */
	private PLMPartFamViewServiceIfc  plmPartFamViewService  = null;
	/**
	 * The PLMPddrData addItem.
	 */
	private PLMPddrData addItem = new PLMPddrData();
	/**
	 * The boolean publisEnable.
	 */
	private boolean publisEnable;

	/**
	 * The String confirmAlertMsg.
	 */
	private String confirmAlertMsg;
	/**
	 * The String saveSuccessMsg.
	 */
	private String saveSuccessMsg;
	/**
	 * The String selectedPF.
	 */
	private String selectedPF;
	/**
	 * The boolean read.
	 */
	private boolean read;
	/**
	 * The boolean write.	 */
	private boolean write;
	/**
	 * The int scrollerPage.
	 */
	private int scrollerPage;
	/**
	 * Holds the selectedNodeChildren
	 */
	private List<PLMPddrData> selectedNodeChildren = new ArrayList<PLMPddrData>();
	/**
	 * Holds the nodeTitle
	 */
	private String nodeTitle;
	/**
	 * Holds the htmlTree
	 */
	private HtmlTree htmlTree = new HtmlTree();
	/**
	 * Holds the rootNode
	 */
	private TreeNode<PLMPddrData> rootNode;
	/**
	 * Holds the currentNode
	 */
	private TreeNode<PLMPddrData> currentNode;
	/**
	 * Holds the isCollapse
	 */
	private boolean isCollapse;
	/**
	 * Holds the panelGrid
	 */
	private HtmlPanelGrid panelGrid;
	/**
	 * Holds the showDetails
	 */
	private boolean showDetails;
	/**
	 * Holds the gettingDetails
	 */
	private boolean gettingDetails;
	/**
	 * Holds the showNewAdd
	 */
	private boolean showNewAdd;
	/**
	 * Holds the showAddButton
	 */
	private boolean showAddButton;
	/**
	 * Holds the showSBOMExplorerUpdate
	 */
	private boolean showSBOMExplorerUpdate;
	/**
	 * Holds the selectedLevel
	 */
	private int selectedLevel;
	/**
	 * Holds the selectedId
	 */
	private int selectedId;
	/**
	 * Holds the topLevelItem
	 */
	private String topLevelItem;
	/**
	 * Holds the parentItem
	 */
	private String parentItem;
	@SuppressWarnings("unchecked")
	/**
	 * Holds the selectedNode
	 */
	private TreeNode selectedNode;
	/**
	 * Holds the fromSBoMId
	 */
	private String fromSBoMId;
	/**
	 * Holds the srcType
	 */
	private String srcType;
	/**
	 * Holds the recordCounts
	 */
	private int recordCounts = PLMConstants.N_15;
	/**
	 * Holds the totalRecCount
	 */
	private int totalRecCount;
	/**
	 * Holds the itemFilterEffStDT
	 */
	private Date itemFilterEffStDT;
	/**
	 * Holds the prefixFilter
	 */
	private String prefixFilter;
	/**
	 * Holds the partNumberFilter
	 */
	private String partNumberFilter;
	/**
	 * Holds the ecnFilter
	 */
	private String ecnFilter;
	/**
	 * Holds the filterString
	 */
	private int filterString = PLMConstants.N_0;
    /**
	 * The ThreadPoolTaskExecutor taskExecutor.
	 */
	private ThreadPoolTaskExecutor taskExecutor = null;
	
	/**
	 * The boolean exportFlag.
	 */
	private boolean exportFlag;
	/**
	 * Holds the secondLevelFilteredNodes
	 */
	private Map<String,String> secondLevelFilteredNodes = new HashMap<String,String>();
	
	/**
	 * The boolean buttonFlag
	 */
	private boolean buttonFlag;
	//private Map<String,List<String>> folderMap = null; 
	
	/**
	 * Holds user information
	 */
	private PLMPwiUserData userDetails = null;
	/**
	 * Holds the alertMessage
	 */
	private String alertMessage;
	/**
	 * Holds the optionType
	 */
	private String optionType;
	/**
	 * Holds the hyperLinkFlag
	 */
	private boolean hyperLinkFlag;
	

	/*private PLMLoginData userDataObj = (PLMLoginData) PLMUtils
	.getServletSession(true).getAttribute(PLMConstants.SESSION_USER_DATA);*/

	/**
	 * This is method is used for partFamilyViewer
	 * 
	 * @return string
	 */
	public String exploreSbom() {
		LOG.info("exploreSbom");
		resetMB();
		searchString = null;
		searchSerialString = null;
		read = false;
		write = false;
		showDetails = false;
		showNewAdd = false;
		showAddButton = false;
		showSBOMExplorerUpdate = false;
		gettingDetails = false;
		searchItemsExplore();
		return "partFamilyViewer";
	}

	/**
	 * This is method is used for resetMB
	 * 
	 */
	private void resetMB() {
		htmlTree = null;
		rootNode = null;
		searchResults.clear();
		searchExpResults.clear();
		sbomData.clear();
		partChildTable = false;
		selectedMPLNo = PLMConstants.EMPTY_STRING;
		alertMsgPddr = PLMConstants.EMPTY_STRING;
		alertMessage = PLMConstants.EMPTY_STRING;
		saveSuccessMsg = PLMConstants.EMPTY_STRING;
		confirmAlertMsg = PLMConstants.EMPTY_STRING;
		setSelectedPF(null);
		resultCount = 0;
		nodeTitle = null;
		selectedId = 0;
		selectedLevel = 0;
		toGetPopup = 0;
		prdStcres = 0;
		treeLoad = 0;
		fromSBoMId = "";
		buttonFlag = true;
		setPFDetails();
	}
	/**
	 * This is method is used for setPFDetails
	 * 
	 */
	private void setPFDetails() {
		LOG.info("setPFDetails");
		addItem = new PLMPddrData();
		addItem.setPartFamily("-");
		addItem.setPartDesc("-");
		addItem.setPartState("-");
		addItem.setPartOwnerSso("-");
		addItem.setPartOwnerName("-");
		addItem.setPartBaseNum("-");
		addItem.setPartRDO("-");
		addItem.setPartSrcOrgDate("-");
		addItem.setPartSrcModDate("-");
		addItem.setPartEEDWUpdateDate("-");
	}
	/**
	 * This is method is used for searchItemsExplore
	 * 
	 * @return string
	 */
	public String searchItemsExplore() {
		String returnStr = PLMConstants.EMPTY_STRING;
		try {
			commonMB.insertCannedRptRecordHitInfo("Part Family Viewer");
		} catch (PLMCommonException ex) {
			LOG.log(Level.ERROR, "Exception@insertCannedRptRecordHitInfo: ", ex);
		}
		
		try {
			LOG.info("Entering searchItemsExplore() method----PLMPartFamViewMB---");
			scrollerPage = PLMConstants.N_1;
			resetMB();
			showDetails = false;
			showNewAdd = false;
			showAddButton = false;
			showSBOMExplorerUpdate = false;
			resultHeader = false;
			resultCount = 0;
			toGetPopup = 0;
			prdStcres = 0;
			treeLoad = 0;
			optionType ="All Parts";
			alertMessage ="";
			hyperLinkFlag =true;
				alertMsgPddr = PLMConstants.NOO;
				alertMessage = PLMConstants.EMPTY_STRING;
				searchExpResults = plmPartFamViewService.searchItemExplorer();
				if (searchExpResults != null && searchExpResults.size() > 0) {
					LOG.info("Records Found " + searchExpResults.size());
					exportFlag = true;
					resultHeader = true;
					resultCount = searchExpResults.size();
					if (resultCount == 1) {
						if (!"NOT-AVAILABLE".equals(searchExpResults.get(0)
								.getMplMLnumberHD())) {
							selectedMPLNo = searchExpResults.get(0)
							.getLibraryName();
							checkProductStruct();
						} else {
							toGetPopup = 4;
							resultHeader = false;
							exportFlag = false;
						}
					} else {
						toGetPopup = 2;
					}
				} else {
					LOG.info("No Records Found");
					toGetPopup = 3;
					resultHeader = false;
					exportFlag = false;
				}
				returnStr = "partFamilyViewer";
		} catch (PLMCommonException ce) {
			
			LOG.log(Level.ERROR, "searchItemsExplore" + ce.getMessage());
			returnStr = PLMConstants.ERROR;
		} catch (Exception ce) {
			
			LOG.log(Level.ERROR, "searchItemsExplore" + ce.getMessage());
			returnStr = PLMConstants.ERROR;
		}
		LOG.info("Exiting searchItemsExplore() method----PLMPartFamViewMB---");
		return returnStr;
	}

	/**
	 * This is method is used for checkProductStruct
	 * 
	 * @return string
	 */
	public String checkProductStruct() {
		String returnStr = PLMConstants.EMPTY_STRING;
		LOG.info("Entering checkProductStruct() method----PLMPartFamViewMB---");
		try {
			scrollerPage = PLMConstants.N_1;
			toGetPopup = 0;
			prdStcres = 0;
			treeLoad = 0;
			sbomData.clear();
			alertMsgPddr = PLMConstants.EMPTY_STRING;
			searchResults.clear();
			searchResults.add(selectedMPLNo);
			prdStcres = 2;
			treeLoad = 11;
		} catch (Exception ce) {
			LOG.log(Level.ERROR, "checkProductStruct" + ce.getMessage());
			returnStr = PLMConstants.ERROR;
		}
		LOG.info("Exiting checkProductStruct() method----PLMPartFamViewMB---");
		return returnStr;
	}

	/**
	 * This is method is used for getItemDetailsExplore
	 * 
	 * @return string
	 */
	public String getItemDetailsExplore() {
		String returnStr = PLMConstants.EMPTY_STRING;
		try {
			LOG.info("Entering getItemDetailsExplore() method----PLMPartFamViewMB---");
			scrollerPage = PLMConstants.N_1;
			toGetPopup = 0;
			prdStcres = 0;
			treeLoad = 0;
			sbomData.clear();
			prefixFilter = null;
			partNumberFilter = null; 
			ecnFilter = null; 
			itemFilterEffStDT = null;
			alertMsgPddr = PLMConstants.EMPTY_STRING;
			if (selectedMPLNo != null
					&& !PLMConstants.EMPTY_STRING
							.equalsIgnoreCase(selectedMPLNo.trim())) {
					partChildTable = true;
					loadTree();
					prdStcres = 2;
			} else {
				partChildTable = false;
			}

		} catch (Exception ce) {
			LOG.log(Level.ERROR, "getItemDetailsExplore" + ce.getMessage());
			returnStr = PLMConstants.ERROR;
		}
		LOG.info("Exiting getItemDetailsExplore() method----PLMPartFamViewMB---");
		return returnStr;
	}
	/**
	 * This is method is used for refreshSearch
	 * 
	 * @return string
	 */
	public String refreshSearch() {
        String returnStr = PLMConstants.EMPTY_STRING;
		return returnStr;
	}

	/**
	 * This is method is used for treeNodeExpand
	 * 
	 */
	public void treeNodeExpand() {
		LOG.info(" ***** INSIDE treeNodeExpand METHOD ***** ");
		isCollapse = true;
	}

	/**
	 * collapse tree
	 */
	public void treeNodeCollapse() {
		LOG.info(" **** INSIDE treeNodeCollapse METHOD ***** ");
		isCollapse = false;
	}

	/**
	 * load tree
	 */
	@SuppressWarnings("unchecked")
	public void loadTree() {
		try {
			LOG.info("Entering loadTree() method----PLMPartFamViewMB---");
			LOG.info("Tree will load");
			filterString = PLMConstants.N_0;
			fromSBoMId = "";
			toGetPopup = 0;
			treeLoad = 0;
			TreeNode mainNode = null;
			PLMPddrData treeNodeData = null;
			PLMPddrData navigatorData = null;
			Iterator itr = null;
			Object dataObject = null;
			PLMPddrData tempTreeNodeData = null;
			Iterator itr1 = null;

			panelGrid = new HtmlPanelGrid();
			panelGrid.setColumns(0);

			rootNode = new TreeNodeImpl();
			htmlTree.setData(null);
			htmlTree.setIgnoreDupResponses(true);
			htmlTree.setValue(new TreeNodeImpl());
			List childrenList = null;
			nodeTitle = "";
			/* adding top level parent */
			PLMPddrData parentData = null;
			List<PLMPddrData> parentNodes = new ArrayList<PLMPddrData>();
//			parentNodes = new ArrayList<PLMPddrData>();

			for (String data : searchResults) {
				parentData = new PLMPddrData();
				parentData.setParentItem(data);
				parentData.setLevel(1);
				parentData.setChildInd(PLMConstants.YES);
				parentData.setTopLevelParentItem(data);
				parentData.setDescription("");
				parentNodes.add(parentData);
			}
			/* added */
			/* parentNodes.add(parentData); */
			HashMap childrenMap = plmPartFamViewService.getChildForParent(
					searchResults, "1");
			if (parentNodes != null) {
				itr = parentNodes.iterator();
				while (itr.hasNext()) {
					treeNodeData = new PLMPddrData();
					mainNode = new TreeNodeImpl();
					navigatorData = (PLMPddrData) itr.next();
					if (navigatorData != null) {
						PLMUtils.copyProperties(navigatorData, treeNodeData);
						treeNodeData.setType("node");
						mainNode.setData(treeNodeData);
					}
					childrenList = (List) childrenMap.get(treeNodeData
							.getParentItem());
					if (!PLMUtils.isEmptyList(childrenList)) {
						itr1 = childrenList.iterator();
						while (itr1.hasNext()) {
							dataObject = itr1.next();
							tempTreeNodeData = (PLMPddrData) ((TreeNode) dataObject)
									.getData();
							tempTreeNodeData.setType("node");
							mainNode.addChild(tempTreeNodeData.getParentItem(),
									(TreeNode) dataObject);
						}
					}
					rootNode.addChild(treeNodeData.getParentItem(), mainNode);
				}
				htmlTree.setValue(rootNode);
				setTheTreeForView();
				currentNode = rootNode;
				collapseOtherTree(htmlTree, mainNode);
				expandLevelOne(searchResults);
			}
		} catch (PLMCommonException e) {
			LOG.log(Level.ERROR, "Exception[loadTree]:" + e.getMessage());
		} catch (Exception e) {
			LOG.log(Level.ERROR, "Exception[loadTree]:" + e.getMessage());
		}
		LOG.info("Exiting loadTree() method----PLMPartFamViewMB---");
	}
	
	/**
	 * expandLevelOne
	 * 
	 * @param nodeId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public TreeNode expandLevelOne(List<String> nodeId) {
		LOG.info(" *************** INSIDE expandLevelOne METHOD ******************* ");
		TreeNode mainTreeNode = null;
		Iterator mainNodeItr = null;
		Entry abc = null;
		TreeNode childNode = null;
		TreeRowKey treeRowKey = null;
		int level = 1;
		String nodeStr = null;
		try {
			mainTreeNode = currentNode;
			if (currentNode != null) {
				mainNodeItr = mainTreeNode.getChildren();
				while (mainNodeItr.hasNext()) {
					abc = (Entry) mainNodeItr.next();
					childNode = (TreeNodeImpl) abc.getValue();
					treeRowKey = (TreeRowKey) htmlTree
							.getTreeNodeRowKey(childNode);
					nodeStr = treeRowKey.toString();
					for (String data : nodeId) {
						if (data.equals(extractLastNodeId(nodeStr))) {
							currentNode = childNode;
							generateTreeNodeChildren(currentNode, false,
									level + 1, data);
							// collapseOtherTreeFrmExtrnl(currentNode);
							expandNode(treeRowKey);
							return childNode;
						}
					}
				}
			}
		} catch (PLMCommonException eobj) {
			LOG.error("ICMMessage[expandLevelOne]:" + eobj.getMessage());
		} catch (Exception eobj) {
			LOG.error("Exception[expandLevelOne]:" + eobj.getMessage());
		}
		return null;
	}

	/**
	 * setTheTreeForView
	 * 
	 * @return int
	 */
	@SuppressWarnings("unchecked")
	public int setTheTreeForView() {
		LOG.info(" --> Set the Tree for view Starts<-- ");
		TreeNode tempNode = null;
		tempNode = new TreeNodeImpl();
		int size = 0;
		Iterator abc = null;
		abc = rootNode.getChildren();
		while (abc.hasNext()) {
			size++;
			Entry ax = (Entry) abc.next();
			TreeNode childNode = (TreeNodeImpl) ax.getValue();
			PLMPddrData nodeData = (PLMPddrData) childNode.getData();
			tempNode.addChild(nodeData.getParentItem(), childNode);
		}
		htmlTree.setValue(tempNode);
		LOG.info(" $$$ Count: " + size);
		LOG.info(" --> Set the Tree for view Ends <-- ");

		return size;
	}
	
	/**
	 * updateTreeHighlight
	 * 
	 */
	@SuppressWarnings("unchecked")
	public void updateTreeHighlight(TreeNode node) {
		Iterator abc = null;
		abc = node.getChildren();
		while (abc.hasNext()) {			
			Entry ax = (Entry) abc.next();
			TreeNode childNode = (TreeNodeImpl) ax.getValue();
			((PLMPddrData)childNode.getData()).setNodeHighlightFlag(false);
			updateTreeHighlight(childNode);
		}
	}

	/**
	 * changeNode
	 * 
	 * @param event
	 */
	@SuppressWarnings("unchecked")
	public void changeNode(NodeExpandedEvent event) {
		LOG.info(" ---> changeNode(NodeExpandedEvent) Starts <--- ");
		UITree tree = null;
		TreeNode<PLMPddrData> treeNodeInner = null;
		PLMPddrData treeDataObj = null;
		String currentExpandedFolderId = "";
		String topLevelItemInner = "";
		alertMessage = PLMConstants.EMPTY_STRING;
		alertMsgPddr = PLMConstants.EMPTY_STRING;
		try {
			tree = (UITree) event.getComponent();
			treeNodeInner = tree.getTreeNode();
			if (treeNodeInner != null) {
				treeDataObj = treeNodeInner.getData();
				if (treeDataObj != null) {
					currentExpandedFolderId = treeDataObj.getParentItem();
					topLevelItemInner = treeDataObj.getTopLevelParentItem();
					fromSBoMId = treeDataObj.getSbomID() + "";
				}
			}
			TreeRowKey treeRowKey = null;
			treeRowKey = (TreeRowKey) htmlTree
			.getTreeNodeRowKey(tree.getTreeNode());
			LOG.info("currentExpandedFolderId  " + currentExpandedFolderId);
			LOG.info("topLevelItem  " + topLevelItemInner);
			collapseOtherTree(htmlTree, tree.getTreeNode());
			if (treeDataObj != null) {
				addNodeWithChildrenToGivenNode(treeNodeInner,
						currentExpandedFolderId, topLevelItemInner);
			}
			expandNode(treeRowKey);
		} catch (Exception eobj) {
			eobj.printStackTrace();
			LOG.error("Exception[changeNode]:" + eobj.getMessage());
		}
		LOG.info(" ---> changeNode(NodeExpandedEvent) Ends <--- ");
	}

	/**
	 * 
	 * addNodeWithChildrenToGivenNode
	 * 
	 * @param givenNode
	 * @param currentNodeParam
	 * @param topLevelItemParam
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public void addNodeWithChildrenToGivenNode(TreeNode<PLMPddrData> givenNode,
			String currentNodeParam, String topLevelItemParam) throws Exception {
		LOG.info(" --> addNodeWithChildrenToGivenNode METHOD Starts <--");
		PLMPddrData navigData = null;
		PLMPddrData givenTreeNodeData = null;
		Entry entry = null;
		@SuppressWarnings("unused")
		TreeNode childNode = null;
		List<PLMPddrData> navigList = null;
		HashMap childrenMap = null;
		List childrenList = null;
		Map<String, PLMPddrData> childSeqs = null;
		Set<String> allSeqs = null;
		Set<String> moreFolderSeqs = null;
		navigData = new PLMPddrData();
		childSeqs = new LinkedHashMap<String, PLMPddrData>();
		moreFolderSeqs = new HashSet<String>();
		//String effectivityDate = null;
		int level = 0;

		if (givenNode != null) {
			givenTreeNodeData = givenNode.getData();

			if (givenTreeNodeData != null) {
				level = givenTreeNodeData.getLevel();
				givenNode.setData(givenTreeNodeData);
				PLMUtils.copyProperties(givenTreeNodeData, navigData);
			}

			allSeqs = new HashSet<String>();
			navigList = new ArrayList<PLMPddrData>();

			navigList.add(navigData);
			int levl = navigData.getLevel();
			LOG.info("levl------->" + levl);
			String clickedNode = navigData.getParentItem();
			LOG.info("clickedNode------->" + clickedNode);
			//String nodeTitle = navigData.getParentItem();
			LOG.info("nodeTitle------->" + navigData.getParentItem());
			int levelNodeClick = navigData.getLevel();
			LOG.info("levelNodeClick------->" + levelNodeClick);
			Iterator childItr = givenNode.getChildren();
			while (childItr.hasNext()) {
				entry = (Entry) childItr.next();
				TreeNode tttNode = (TreeNode) entry.getValue();
				PLMPddrData tttNodeData = (PLMPddrData) tttNode.getData();
				PLMPddrData tempNavData = new PLMPddrData();
				PLMUtils.copyProperties(tttNodeData, tempNavData);
				childSeqs.put(tttNodeData.getParentItem(), tempNavData);
				moreFolderSeqs.add(tttNodeData.getParentItem());
				
			}
			/**
			 * Get the siblings of the clicked node or the children of parent of
			 * clicked node
			 */
			LOG.info("---> Get Children for Clicked Node folders Starts <---");
			
			if ((filterString == PLMConstants.N_0)|| (filterString == PLMConstants.N_1))
			{
			childrenMap = plmPartFamViewService.getChildForParentList(
					topLevelItemParam, navigList, level);
			LOG.info("---> Get Children for Clicked Node folders Ends <---");
			LOG.info("isCollpase >>  " + isCollapse);
			if (isCollapse) {
				childrenList = (List) childrenMap
						.get(navigData.getParentItem());
				if (childrenList == null) {
					childrenList = new ArrayList();
				}
				List<PLMPddrData> childrenNavList = new ArrayList<PLMPddrData>();

				Iterator childNodeItr = childrenList.iterator();
				while (childNodeItr.hasNext()) {
					Object dataObject = childNodeItr.next();
					PLMPddrData tempTreeNodeData = null;
					tempTreeNodeData = (PLMPddrData) ((TreeNode) dataObject)
							.getData();

					PLMPddrData navigatorDataObj = new PLMPddrData();
					PLMUtils.copyProperties(tempTreeNodeData, navigatorDataObj);
					childrenNavList.add(navigatorDataObj);
					allSeqs.add(navigatorDataObj.getParentItem());
				}
				/** Add the children to the given node */
				List<PLMPddrData> navigatorList = new ArrayList<PLMPddrData>();
				Map<String, TreeRowKey> nodesAndRowKeys = null;
				nodesAndRowKeys = new HashMap<String, TreeRowKey>();
				List<String> dBChildsList = new ArrayList<String>();
				if (childrenList != null && childrenList.size() > 0) {
					childNodeItr = childrenList.iterator();
					while (childNodeItr.hasNext()) {
						Object dataObject = childNodeItr.next();
						PLMPddrData tempTreeNodeData = null;
						tempTreeNodeData = (PLMPddrData) ((TreeNode) dataObject)
								.getData();

						dBChildsList.add(tempTreeNodeData.getParentItem());

						PLMPddrData navigatorDataObj = new PLMPddrData();
						if (childSeqs.containsKey(tempTreeNodeData
								.getParentItem())) {
							navigatorDataObj = childSeqs.get(tempTreeNodeData
									.getParentItem());
						} else {
							PLMUtils.copyProperties(tempTreeNodeData,
									navigatorDataObj);
							tempTreeNodeData.setType("node");
							givenNode.addChild(
									tempTreeNodeData.getParentItem(),
									(TreeNode) dataObject);

						}
						TreeNode tempNode = givenNode.getChild(tempTreeNodeData
								.getParentItem());
						nodesAndRowKeys.put(tempTreeNodeData.getParentItem(),
								(TreeRowKey) htmlTree
										.getTreeNodeRowKey(tempNode));

						navigatorList.add(navigatorDataObj);

					}
				}

				/*
				 * Removing the nodes which doesnt exist in the database, but
				 * existing in the tree
				 */
				if (childSeqs != null && childSeqs.size() > 0) {
					Set childSeqsList = childSeqs.keySet();
					
					if (childSeqsList != null && childSeqsList.size() > 0) {
						childSeqsList.removeAll(dBChildsList);
						Iterator<String> childListItr = childSeqsList
								.iterator();
						while (childListItr.hasNext()) {
							String id = childListItr.next();
							givenNode.removeChild(id);
						}
					}
				}

				/**
				 * Get the children of the siblings, to show expand/collapse
				 * icon
				 */
				LOG
						.info("---> Get Children for Clicked Node, Sub folders Starts <---");
				childrenMap = plmPartFamViewService.getChildForParentList(
						topLevelItemParam, navigatorList, level + 1);

				LOG
						.info("---> Get Children for Clicked Node, Sub folders Ends <---");
				Iterator childrenMapItr = childrenMap.entrySet().iterator();
				LOG.info("More folder seqs: " + moreFolderSeqs);
				while (childrenMapItr.hasNext()) {
					Entry subChldSqId = (Entry) childrenMapItr.next();
					String subChildSeqId = (String) subChldSqId.getKey();
					//String subChildSeqId = (String) childrenMapItr.next();
					List subChildList = (List) childrenMap.get(subChildSeqId);
					if (subChildList != null
							&& subChildList.size() > 0
							&& (isCollapse || !moreFolderSeqs
									.contains(subChildSeqId))) {
						childNodeItr = subChildList.iterator();
						while (childNodeItr.hasNext()) {
							Object dataObject = childNodeItr.next();
							PLMPddrData tempTreeNodeData = (PLMPddrData) ((TreeNode) dataObject)
									.getData();
							tempTreeNodeData.setType("node");
							TreeRowKey treeRowKey = nodesAndRowKeys
									.get(subChildSeqId);
							TreeNode subNode1 = htmlTree
									.getModelTreeNode(treeRowKey);
							// Check if this node also exists
							TreeNode subNode11 = subNode1
									.getChild(tempTreeNodeData.getParentItem());
							if (subNode11 == null
									|| subNode11.getData() == null) {
								subNode1
										.addChild(tempTreeNodeData
												.getParentItem(),
												(TreeNode) dataObject);
							} else {
								@SuppressWarnings("unused")
								PLMPddrData subNodeData = (PLMPddrData) subNode11
										.getData();
								LOG.info("Code Review  " + subNodeData.toString());
							}
						}
					}
				}
			}

		  }
		}
		LOG.info(" --> addNodeWithChildrenToGivenNode METHOD Ends <--");
	}

	/**
	 * 
	 * processSelection
	 * 
	 * @param event
	 */
	@SuppressWarnings("unchecked")
	public void processSelection(NodeSelectedEvent event) {
		try {
			HtmlTree tree = (HtmlTree) event.getComponent();
			if (tree != null && tree.getRowKey() != null) {
				selectedNode = tree.getModelTreeNode(tree.getRowKey());
				if (selectedNode != null) {
					selectedNodeChildren.clear();
					if (selectedNode.isLeaf()) {
						selectedNodeChildren.add((PLMPddrData) selectedNode
								.getData());
					} else {
						Iterator<Map.Entry<PLMPddrData, TreeNode>> it = selectedNode
								.getChildren();
						while (it != null && it.hasNext()) {
							Map.Entry<PLMPddrData, TreeNode> entry = it.next();
							selectedNodeChildren.add((PLMPddrData) entry
									.getValue().getData());
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error("Exception[changeNode]:" + e.getMessage());
		}
	}

	/**
	 * TreeNode
	 * 
	 * @return TreeNode
	 */
	@SuppressWarnings("unchecked")
	public TreeNode getTreeNode() {
		if (rootNode == null) {
			loadTree();
		}
		return rootNode;
	}

	/**
	 * Used for getDetails
	 * 
	 * @return String
	 */
	@SuppressWarnings("unchecked")
	public String getDetails() {
		LOG.info("Entering getDetails() method----PLMPartFamViewMB---");
		buttonFlag = false;
		String returnStr = PLMConstants.EMPTY_STRING;
		toGetPopup = 0;
		//int count = 0;
		if (filterString==PLMConstants.N_1)
		alertMessage = PLMConstants.EMPTY_STRING;
		alertMsgPddr = PLMConstants.EMPTY_STRING;
		updateTreeHighlight(rootNode);
		alertMessage ="";
		try {
			String nodeTitleP = null;
			gettingDetails = false;
			String selectedIdP = null;
			int selectedLevelP = 0;
			String topLevelItemP = null;
			if (!PLMUtils.isEmpty(PLMUtils.getRequestParameter("parentName"))) {
				nodeTitleP = PLMUtils.getRequestParameter("parentName");
				selectedLevelP = Integer.parseInt(PLMUtils
						.getRequestParameter("selLevel"));
				topLevelItemP = PLMUtils.getRequestParameter("topLevelItem");
				selectedIdP = PLMUtils.getRequestParameter("selectedID");
			}
			nodeTitle = nodeTitleP;
			selectedLevel = selectedLevelP;
			LOG.info("Selected node : :::" + nodeTitleP);
			LOG.info("Selected id : :::" + selectedIdP);
			LOG.info("Selected node Level : :::" + selectedLevelP);
			LOG.info("Selected Immediate Parent : :::" + topLevelItemP);
			fromSBoMId = selectedIdP + "";
			setSelectedPF(nodeTitleP);
			addItem = plmPartFamViewService.getPFDetails(nodeTitleP);
			if(addItem == null){
				alertMsgPddr = "No part details found for the selected part family";
				FacesContext.getCurrentInstance().addMessage("INFO", new FacesMessage(alertMsgPddr));
			}
		} catch (Exception ce) {
			LOG.log(Level.ERROR, "getDetails" + ce);
			returnStr = PLMConstants.ERROR;
		}
		LOG.info("Exiting getDetails() method----PLMPartFamViewMB---");
		return returnStr;
	}
	
//	
	/**
	 * expandNode
	 * 
	 * @param treeRowKey
	 */
	@SuppressWarnings("unchecked")
	public void expandNode(TreeRowKey treeRowKey) {
		try {
			if (treeRowKey != null) {
				htmlTree.queueNodeExpand(treeRowKey);
			}
		} catch (Exception eobj) {
			LOG.error("In expandNode:" + eobj.getMessage());
		}
	}

	/**
	 * extractLastNodeId
	 * 
	 * @param nodeId
	 * @return String
	 */
	public String extractLastNodeId(String nodeId) {
		String nodeIdNew = "";
		if (nodeId != null && nodeId.length() > 0) {
			nodeIdNew = nodeId.substring(nodeId.lastIndexOf(':') + 1);
		}
		return nodeIdNew;
	}

	/**
	 * extractNodeId
	 * 
	 * @param nodeId
	 * @return String
	 */
	public String extractNodeId(String nodeId) {
		String nodeIdNew = "";
		if (nodeId != null && nodeId.length() > 0) {
			nodeIdNew = nodeId.substring(nodeId.lastIndexOf(':') + 1, nodeId
					.length());
		}
		return nodeIdNew;
	}

	/**
	 * generateTreeNodeChildren
	 * 
	 * @param treeNodeParam
	 * @param isFromTree
	 * @param level
	 * @param item
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public void generateTreeNodeChildren(TreeNode treeNodeParam,
			boolean isFromTree, int level, String item) throws Exception {
		LOG
				.info(" *************** INSIDE generateTreeNodeChildren METHOD ******************* ");
		List childrenList = null;
		String nodeId = null;
		TreeNode childNode = null;
		PLMPddrData navigData = null;
		List<PLMPddrData> navigList = null;
		List<PLMPddrData> remTrNdDta = null;
		Iterator mainNodeItr = null;
		Iterator childNodeItr = null;

		TreeRowKey treeRowKey = null;
		PLMPddrData treeNodeData = null;
		

		Object dataObject = null;
		PLMPddrData tempTreeNodeData = null;

		Entry abc = null;

		if (treeNodeParam != null) {
			mainNodeItr = treeNodeParam.getChildren();
			navigList = new ArrayList<PLMPddrData>();
			remTrNdDta = new ArrayList<PLMPddrData>();
			while (mainNodeItr.hasNext()) {

				abc = (Entry) mainNodeItr.next();
				childNode = (TreeNodeImpl) abc.getValue();
				//treeRowKey = (TreeRowKey) htmlTree.getTreeNodeRowKey(childNode);
				treeNodeData = (PLMPddrData) childNode.getData();
				navigData = new PLMPddrData();
				if (treeNodeData == null) {
					treeNodeData = new PLMPddrData();
				}
				PLMUtils.copyProperties(treeNodeData, navigData);
				navigList.add(navigData);

			}

			HashMap childrenMap = plmPartFamViewService.getChildForParentList(item,
					navigList, level);

			mainNodeItr = treeNodeParam.getChildren();
			while (mainNodeItr.hasNext()) {
				abc = (Entry) mainNodeItr.next();
				childNode = (TreeNodeImpl) abc.getValue();
				treeRowKey = (TreeRowKey) htmlTree.getTreeNodeRowKey(childNode);
				treeNodeData = (PLMPddrData) childNode.getData();
				navigData = new PLMPddrData();
				if (treeNodeData == null) {
					treeNodeData = new PLMPddrData();
				}
				PLMUtils.copyProperties(treeNodeData, navigData);
				navigList = new ArrayList<PLMPddrData>();
				navigList.add(navigData);

				nodeId = treeRowKey.toString();
				childrenList = (List) childrenMap.get(extractNodeId(nodeId));
				if (childrenList != null && childrenList.size() > 0) {
					childNodeItr = childrenList.iterator();
					while (childNodeItr.hasNext()) {
						dataObject = childNodeItr.next();
						tempTreeNodeData = (PLMPddrData) ((TreeNode) dataObject)
								.getData();
						tempTreeNodeData.setType("node");
						childNode.addChild(tempTreeNodeData.getParentItem(),
								(TreeNode) dataObject);
					}
				}

			}

			if (remTrNdDta != null && remTrNdDta.size() > 0) {
				Iterator<PLMPddrData> remTrNdItr = remTrNdDta.iterator();
				while (remTrNdItr.hasNext()) {
					PLMPddrData trNdDta = remTrNdItr.next();
					treeNodeParam.removeChild(trNdDta.getParentItem());
				}
				if (!treeNodeParam.getChildren().hasNext() && isFromTree) {
					TreeRowKey treeRowKeyNew = (TreeRowKey) htmlTree
							.getTreeNodeRowKey(treeNodeParam);
					htmlTree.queueNodeCollapse(treeRowKeyNew);
				}
			}
		}
	}
	
	/**
	 * collapseOtherTreeFilter
	 * 
	 * @param tree
	 * @param uinode
	 */
	
	@SuppressWarnings( { "unchecked", "unused" })
	public void collapseOtherTreeFilter(UITree tree, TreeNode uinode) {
		try {
			
			Iterator childCurrent = uinode.getChildren();
			while (childCurrent.hasNext()) {
				Entry ax = (Entry) childCurrent.next();
				TreeNode childNode = (TreeNodeImpl) ax.getValue();
				PLMPddrData tempData = (PLMPddrData)childNode.getData();				
				if(!secondLevelFilteredNodes.containsKey(tempData.getParentItem())){
					collapseSubNodes(childNode);
				}
			}
			
		} catch (Exception eobj) {
			LOG.error("Exception[collapseOtherTree]:" + eobj.getMessage());
		}
	}

	/**
	 * collapseOtherTree
	 * 
	 * @param tree
	 * @param uinode
	 */
	@SuppressWarnings( { "unchecked", "unused" })
	public void collapseOtherTree(UITree tree, TreeNode uinode) {
		try {
			TreeRowKey parentRowKey = (TreeRowKey) tree
					.getTreeNodeRowKey(uinode);
			while (parentRowKey.getParentKey() != null
					&& parentRowKey.getParentKey().toString().length() > 0) {
				parentRowKey = parentRowKey.getParentKey();
			}
			String myRoot = parentRowKey.toString();

			Iterator childCurrent = uinode.getChildren();
			while (childCurrent.hasNext()) {
				Entry ax = (Entry) childCurrent.next();
				TreeNode childNode = (TreeNodeImpl) ax.getValue();
				collapseSubNodes(childNode);
			}

			Iterator abc = rootNode.getChildren();
			while (abc.hasNext()) {
				Entry ax = (Entry) abc.next();
				TreeNode childNode = (TreeNodeImpl) ax.getValue();
				collapseSubNode(myRoot, childNode);

			}
		} catch (IOException eobj) {
			LOG.error("ICMMSG[collapseOtherTree]:" + eobj.getMessage());
		} catch (Exception eobj) {
			LOG.error("Exception[collapseOtherTree]:" + eobj.getMessage());
		}
	}

	/**
	 * collapseSubNode
	 * 
	 * @param myRoot
	 * @param childNode
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	private void collapseSubNode(String myRoot, TreeNode childNode)
			throws IOException {
		TreeRowKey treeRowKey = (TreeRowKey) htmlTree
				.getTreeNodeRowKey(childNode);
		String rowKeyStrLp = treeRowKey.toString();
		String myRootLp;
		if (rowKeyStrLp.indexOf(':') != PLMConstants.N_NEG_1) {
			myRootLp = rowKeyStrLp.substring(0, rowKeyStrLp.indexOf(':'));
		} else {
			myRootLp = rowKeyStrLp;
		}
		if (!myRootLp.equals(myRoot)) {
			htmlTree.queueNodeCollapse(treeRowKey);
		}
		if (childNode.getChildren() != null) {
			Iterator childItr = childNode.getChildren();
			while (childItr.hasNext()) {
				Entry axt = (Entry) childItr.next();
				TreeNode childSubNode = (TreeNodeImpl) axt.getValue();
				collapseSubNode(myRoot, childSubNode);
			}
		}
	}

	/**
	 * collapseSubNodes
	 * 
	 * @param childNode
	 */
	@SuppressWarnings("unchecked")
	private void collapseSubNodes(TreeNode childNode) {
		try {
			if (htmlTree.getValue() != null) {
				TreeRowKey treeRowKey = (TreeRowKey) htmlTree
						.getTreeNodeRowKey(childNode);
				htmlTree.queueNodeCollapse(treeRowKey);
				if (childNode.getChildren() != null) {
					Iterator childItr = childNode.getChildren();
					while (childItr.hasNext()) {
						Entry axt = (Entry) childItr.next();
						TreeNode childSubNode = (TreeNodeImpl) axt.getValue();
						collapseSubNodes(childSubNode);
					}
				}
			}
		} catch (Exception eobj) {
			LOG.info("In collapseSubNodes methods" + eobj.getMessage());
		}
	}
	
	/**
	 * This method is used for Validating PDDR User Input
	 * 
	 * @return String
	 */
    public String validatePddrInput() {       
        LOG.info("Entering validatePddrInput Method");
        int pfCount = addItem.getPartCount();
        LOG.info("pfCount----validatePddrInput---"+pfCount);
        if(PLMUtils.isEmpty(selectedPF)){
              alertMessage = PLMConstants.PDDR_SEARCH_CRITERIA;
        } else if(pfCount != 0 && pfCount > Integer.parseInt(PLMUtils.getMessage(PLMConstants.PDDR_PART_LIMIT))){
              alertMessage = PLMConstants.PDDR_PART_COUNT;
        } else if (pfCount == 0) {
        	  alertMessage = PLMConstants.PDDR_ZERO_PART_COUNT;
        }
        LOG.info("Exiting validatePddrInput Method");
        return alertMessage;
  }

	
	/**
	 * This method is used for Resetting the User input
	 * 
	 * @return String
	 */
	
	public String resetData() {
		LOG.info("Entering Reset Method");
		String fwdflag = "";
		if (selectedPF != null)
			setSelectedPF(null);
		LOG.info("Exiting Reset Method");
		return fwdflag;
	}
	
	
	public String generatePartFamilyAttrMastr(){
		LOG.info("Entering generatePartFamilyAttrMastr Method");
		String fwdflag = "";
		LOG.info("selectedPF==" + selectedPF);
		int pfCount = addItem.getPartCount();
		LOG.info("pfCount==" + pfCount);
		alertMessage ="";
		try {
		 userDetails = UserInfoPortalUtil.getInstance().getUserDetails();
			if (PLMUtils.isEmpty(selectedPF)) {
				LOG.info("No Input criteria Selected.........");
				alertMessage = PLMConstants.PART_FAMILY_VIEWER_NODE_MANDITORY;
			}else if(pfCount==0){ 
				alertMessage = PLMConstants.PART_FAMILY_VIEWER_NO_PARTS;
			}else if(pfCount > Integer.parseInt(resourceBundle.getString("PART_FMY_VIEW_CNT_LMT"))){ 
				alertMessage =  PLMConstants.PART_FAMILY_VIEWER_EXCESS_PARTS;
			}else if(hyperLinkFlag && pfCount > Integer.parseInt(resourceBundle.getString("PART_FMY_VIEW_CNT_HYPER_LMT"))){ 
				alertMessage =  PLMConstants.PART_FAMILY_VIEWER_UNCHK_HYPERLINK;
			}else {
				LOG.info("Some Input Criteria Selected.........");
				alertMessage = alertMessage + PLMConstants.PART_FAMILY_ATTR_MASTER_ALERT_MSG;
				taskExecutor.execute(new MailThread());
			}
		 } catch (Exception exception) {
				LOG.log(Level.ERROR, "Exception@getPddrReport: ", exception);
				fwdflag = PLMUtils.setCommonException(exception.getMessage(),commonMB,"partFamilyViewer","Part Family Viewer");
			}
		return fwdflag;
	}
	
	private class MailThread implements Runnable {
		public MailThread(){}
		public void run() {
			sendPartFamilyReportThroughMail();
		}
	}

	/**
	 * This method is used for Generating PartFamily Viewer ReportThroughMail
	 * 
	 * @return String
	 */
	public void sendPartFamilyReportThroughMail() {
		LOG.info("Entering sendPartFamilyReportThroughMail Method");
		String fwdflag = "";
		Map<String,String> partAttributeMastrMap = new HashMap<String,String>();
		 List<String> resultListForAttribute = new ArrayList<String>();
		 List<PLMInterfaceAttrData> resultList= new ArrayList<PLMInterfaceAttrData>();
		int count=0;
		
			String selectedPartFamily = selectedPF;
			String optionTypeLcl =optionType;
			boolean hyperLinkFlgLcl =hyperLinkFlag;
			
			String from = PLMConstants.LTTR_MAIL_FROM;

			String to = userDetails.getUserEmailId();		
			String toAddressee = userDetails.getUserFirstName()+" "+userDetails.getUserLastName();
			toAddressee = "Dear " + toAddressee + ", \n\n";
			String subject = PLMConstants.PART_FAMILY_ATTR_VIEWER_SUBJECT + selectedPartFamily;
			StringBuffer mailBody = new StringBuffer().append(toAddressee)
			.append(PLMConstants.PART_FAMILY_ATTR_VIEWER_CONTENT)
			.append(PLMConstants.PART_FAMILY_ATTR_MASTER_CONTENT1)
			.append(selectedPartFamily)
			.append(".");
			mailBody.append(PLMConstants.PART_FAMILY_ATTR_MASTER_CONTENT3)
			.append(optionTypeLcl)
			.append(".")
			.append(PLMConstants.PART_FAMILY_ATTR_MASTER_SIGNATURE)
			.append(PLMConstants.PART_FAMILY_ATTR_MASTER_FOOTER);
				try {
				partAttributeMastrMap = plmPartFamViewService.getPartFamilyAttrMasterResultList(selectedPartFamily,optionTypeLcl,hyperLinkFlgLcl);
				PLMUtils.sendMailWithAttachment(from, to, subject, mailBody.toString(), partAttributeMastrMap.get("filePathZip"));
			} catch (PLMCommonException exception) {
				LOG.log(Level.ERROR, "Exception@sendPartFamilyReportThroughMail: ", exception);
				PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
			} catch (Exception exception) {
				LOG.log(Level.ERROR, "Exception@sendPartFamilyReportThroughMail: ", exception);
				PLMUtils.checkExceptionAndMail(exception.getMessage(),from,to,subject,toAddressee,PLMConstants.LTTR_MAIL_SIGNATURE);
			} finally {
				PLMUtils.deleteFiles(partAttributeMastrMap.get("filePathXls"),partAttributeMastrMap.get("filePathZip"));
			}
			LOG.info("Mail sent successfully.");
	}

	/**
	 * @return the commonMB
	 */
	public PLMCommonMB getCommonMB() {
		return commonMB;
	}

	/**
	 * @param commonMB the commonMB to set
	 */
	public void setCommonMB(PLMCommonMB commonMB) {
		this.commonMB = commonMB;
	}
	/**
	 * @return the resourceBundle
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	/**
	 * @param resourceBundle the resourceBundle to set
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * @return the selectedMPLNo
	 */
	public String getSelectedMPLNo() {
		return selectedMPLNo;
	}

	/**
	 * @return the addItem
	 */
	public PLMPddrData getAddItem() {
		return addItem;
	}

	/**
	 * @param addItemP
	 *            the addItem to set
	 */
	public void setAddItem(PLMPddrData addItemP) {
		this.addItem = addItemP;
	}

	/**
	 * @param selectedMPLNoP
	 *            the selectedMPLNo to set
	 */
	public void setSelectedMPLNo(String selectedMPLNoP) {
		this.selectedMPLNo = selectedMPLNoP;
	}

	/**
	 * @return the resultCount
	 */
	public int getResultCount() {
		return resultCount;
	}

	/**
	 * @param resultCountP
	 *            the resultCount to set
	 */
	public void setResultCount(int resultCountP) {
		this.resultCount = resultCountP;
	}

	/**
	 * @return the toGetPopup
	 */
	public int getToGetPopup() {
		return toGetPopup;
	}

	/**
	 * @param toGetPopup
	 *            the toGetPopup to set
	 */
	public void setToGetPopup(int toGetPopupP) {
		this.toGetPopup = toGetPopupP;
	}

	/**
	 * @return the mplNumber
	 */
	public String getMplNumber() {
		return mplNumber;
	}

	/**
	 * @param mplNumberP
	 *            the mplNumber to set
	 */
	public void setMplNumber(String mplNumberP) {
		this.mplNumber = mplNumberP;
	}

	/**
	 * @return the resultHeader
	 */
	public boolean isResultHeader() {
		return resultHeader;
	}

	/**
	 * @param resultHeaderP
	 *            the resultHeader to set
	 */
	public void setResultHeader(boolean resultHeaderP) {
		this.resultHeader = resultHeaderP;
	}

	/**
	 * @return the alertMsgPddr
	 */
	public String getAlertMsgPddr() {
		String alert = alertMsgPddr;
		alertMsgPddr = PLMConstants.EMPTY_STRING;
		return alert;
	}

	/**
	 * @param stralertMsgPddr
	 *            the alertMsgPddr to set
	 */
	public void setAlertMsgPddr(String strAlertMsgPddr) {
		this.alertMsgPddr = strAlertMsgPddr;
	}

	/**
	 * @return the searchString
	 */
	public String getSearchString() {
		return searchString;
	}

	/**
	 * @param searchStringP
	 *            the searchString to set
	 */
	public void setSearchString(String searchStringP) {
		this.searchString = searchStringP;
	}

	/**
	 * @return the sbomData
	 */
	public List<PLMPddrData> getSbomData() {
		return sbomData;
	}

	/**
	 * @param sbomDataP
	 *            the sbomData to set
	 */
	public void setSbomData(List<PLMPddrData> sbomDataP) {
		this.sbomData = sbomDataP;
	}

	/**
	 * @return the searchResults
	 */
	public List<String> getSearchResults() {
		return searchResults;
	}

	/**
	 * @param searchResultsP
	 *            the searchResults to set
	 */
	public void setSearchResults(List<String> searchResultsP) {
		this.searchResults = searchResultsP;
	}

	/**
	 * @return the partChildTable
	 */
	public boolean isPartChildTable() {
		return partChildTable;
	}

	/**
	 * @param partChildTableP
	 *            the partChildTable to set
	 */
	public void setPartChildTable(boolean partChildTableP) {
		this.partChildTable = partChildTableP;
	}

	/**
	 * @return the publisEnable
	 */
	public boolean isPublisEnable() {
		return publisEnable;
	}

	/**
	 * @param publisEnableP
	 *            the publisEnable to set
	 */
	public void setPublisEnable(boolean publisEnableP) {
		this.publisEnable = publisEnableP;
	}

	/**
	 * @return confirmAlertMsg
	 */
	public String getConfirmAlertMsg() {
		return confirmAlertMsg;
	}

	/**
	 * @param strConfirmAlertMsg
	 */
	public void setConfirmAlertMsg(String strConfirmAlertMsg) {
		this.confirmAlertMsg = strConfirmAlertMsg;
	}

	/**
	 * @return saveSuccessMsg
	 */
	public String getSaveSuccessMsg() {
		return saveSuccessMsg;
	}

	/**
	 * @param saveSuccessMsg
	 */
	public void setSaveSuccessMsg(String strSaveSuccessMsg) {
		this.saveSuccessMsg = strSaveSuccessMsg;
	}

	/**
	 * @return the read
	 */
	public boolean isRead() {
		return read;
	}

	/**
	 * @param read
	 *            the read to set
	 */
	public void setRead(boolean readP) {
		this.read = readP;
	}

	/**
	 * @return the write
	 */
	public boolean isWrite() {
		return write;
	}

	/**
	 * @param write
	 *            the write to set
	 */
	public void setWrite(boolean writeP) {
		this.write = writeP;
	}

	/**
	 * @return the scrollerPage
	 */
	public int getScrollerPage() {
		return scrollerPage;
	}

	/**
	 * @param scrollerPage
	 *            the scrollerPage to set
	 */
	public void setScrollerPage(int scrollerPageP) {
		this.scrollerPage = scrollerPageP;
	}

	/**
	 * @return the panelGrid
	 */
	public HtmlPanelGrid getPanelGrid() {
		return panelGrid;
	}

	/**
	 * @param panelGrid
	 *            the panelGrid to set
	 */
	public void setPanelGrid(HtmlPanelGrid panelGridP) {
		this.panelGrid = panelGridP;
	}

	/**
	 * @return the isCollapse
	 */
	public boolean isCollapse() {
		return isCollapse;
	}

	/**
	 * @param isCollapse
	 *            the isCollapse to set
	 */
	public void setCollapse(boolean isCollapseP) {
		this.isCollapse = isCollapseP;
	}

	/**
	 * @return
	 */
	public String getNodeTitle() {
		return nodeTitle;
	}

	/**
	 * @param nodeTitle
	 */
	public void setNodeTitle(String nodeTitleP) {
		this.nodeTitle = nodeTitleP;
	}

	/**
	 * @return the htmlTree
	 */
	public HtmlTree getHtmlTree() {
		return htmlTree;
	}

	/**
	 * @param htmlTree
	 *            the htmlTree to set
	 */
	public void setHtmlTree(HtmlTree htmlTreeP) {
		this.htmlTree = htmlTreeP;
	}

	/**
	 * @param tree
	 * @return
	 */
	public Boolean collapseTree(UITree tree) {
		return false;
	}

	/**
	 * @return the parentItem
	 */
	public String getParentItem() {
		return parentItem;
	}

	/**
	 * @param parentItem
	 *            the parentItem to set
	 */
	public void setParentItem(String parentItemP) {
		this.parentItem = parentItemP;
	}

	/**
	 * @return the showAdmin
	 */
	public boolean getShowSBOMExplorerUpdate() {
		return showSBOMExplorerUpdate;
	}

	/**
	 * @param showSBOMExplorerUpdate
	 *            the showAdmin to set
	 */
	public void setShowSBOMExplorerUpdate(boolean showSBOMExplorerUpdateP) {
		this.showSBOMExplorerUpdate = showSBOMExplorerUpdateP;
	}

	/**
	 * @return the showAddButton
	 */
	public boolean isShowAddButton() {
		return showAddButton;
	}

	/**
	 * @param showAddButton
	 *            the showAddButton to set
	 */
	public void setShowAddButton(boolean showAddButtonP) {
		this.showAddButton = showAddButtonP;
	}

	/**
	 * @return the showNewAdd
	 */
	public boolean isShowNewAdd() {
		return showNewAdd;
	}

	/**
	 * @param showNewAdd
	 *            the showNewAdd to set
	 */
	public void setShowNewAdd(boolean showNewAddP) {
		this.showNewAdd = showNewAddP;
	}

	/**
	 * @return the showDetails
	 */
	public boolean isShowDetails() {
		return showDetails;
	}

	/**
	 * @param showDetails
	 *            the showDetails to set
	 */
	public void setShowDetails(boolean showDetailsP) {
		this.showDetails = showDetailsP;
	}

	/**
	 * @return the topLevelItem
	 */
	public String getTopLevelItem() {
		return topLevelItem;
	}

	/**
	 * @param topLevelItem
	 *            the topLevelItem to set
	 */
	public void setTopLevelItem(String topLevelItemP) {
		this.topLevelItem = topLevelItemP;
	}

	/**
	 * @return the selectedLevel
	 */
	public int getSelectedLevel() {
		return selectedLevel;
	}

	/**
	 * @param selectedLevel
	 *            the selectedLevel to set
	 */
	public void setSelectedLevel(int selectedLevelP) {
		this.selectedLevel = selectedLevelP;
	}

	/**
	 * @return the selectedId
	 */
	public int getSelectedId() {
		return selectedId;
	}

	/**
	 * @param selectedId
	 *            the selectedId to set
	 */
	public void setSelectedId(int selectedIdP) {
		this.selectedId = selectedIdP;
	}

	/**
	 * @return the fromSBoMId
	 */
	public String getFromSBoMId() {
		return fromSBoMId;
	}

	/**
	 * @param fromSBoMId
	 *            the fromSBoMId to set
	 */
	public void setFromSBoMId(String fromSBoMIdP) {
		this.fromSBoMId = fromSBoMIdP;
	}

	/**
	 * @return the gettingDetails
	 */
	public boolean isGettingDetails() {
		return gettingDetails;
	}

	/**
	 * @param gettingDetails
	 *            the gettingDetails to set
	 */
	public void setGettingDetails(boolean gettingDetailsP) {
		this.gettingDetails = gettingDetailsP;
	}

	/**
	 * @return the sbomHeaderData
	 */
	public PLMPddrSearchData getSbomHeaderData() {
		return sbomHeaderData;
	}

	/**
	 * @param sbomHeaderData
	 *            the sbomHeaderData to set
	 */
	public void setSbomHeaderData(PLMPddrSearchData sbomHeaderDataP) {
		this.sbomHeaderData = sbomHeaderDataP;
	}

	/**
	 * @return the searchSerialString
	 */
	public String getSearchSerialString() {
		return searchSerialString;
	}

	/**
	 * @param searchSerialString
	 *            the searchSerialString to set
	 */
	public void setSearchSerialString(String searchSerialStringP) {
		this.searchSerialString = searchSerialStringP;
	}

	/**
	 * @return the searchExpResults
	 */
	public List<PLMPddrSearchData> getSearchExpResults() {
		return searchExpResults;
	}

	/**
	 * @param searchExpResults
	 *            the searchExpResults to set
	 */
	public void setSearchExpResults(List<PLMPddrSearchData> searchExpResultsP) {
		this.searchExpResults = searchExpResultsP;
	}

	/**
	 * @return the prdStcres
	 */
	public int getPrdStcres() {
		return prdStcres;
	}

	/**
	 * @param prdStcres
	 *            the prdStcres to set
	 */
	public void setPrdStcres(int prdStcresP) {
		this.prdStcres = prdStcresP;
	}

	/**
	 * @return the treeLoad
	 */
	public int getTreeLoad() {
		return treeLoad;
	}

	/**
	 * @param treeLoad
	 *            the treeLoad to set
	 */
	public void setTreeLoad(int treeLoadP) {
		this.treeLoad = treeLoadP;
	}

	/**
	 * @return the recordCounts
	 */
	public int getRecordCounts() {
		return recordCounts;
	}

	/**
	 * @param recordCounts
	 *            the recordCounts to set
	 */
	public void setRecordCounts(int recordCounts) {
		LOG.info("::::::::::::::::::" + recordCounts);
		PLMUtils.getServletSession(true).setAttribute("RecDropDown",
				recordCounts);
		this.recordCounts = recordCounts;
	}

	/**
	 * @return the totalRecCount
	 */
	public int getTotalRecCount() {
		return totalRecCount;
	}

	/**
	 * @param totalRecCount
	 *            the totalRecCount to set
	 */
	public void setTotalRecCount(int totalRecCount) {
		this.totalRecCount = totalRecCount;
	}

	/**
	 * @return the srcType
	 */
	public String getSrcType() {
		return srcType;
	}

	/**
	 * @param srcType
	 *            the srcType to set
	 */
	public void setSrcType(String srcType) {
		this.srcType = srcType;
	}
	/**
	 * @return the temp
	 */
	public java.util.Date getItemFilterEffStDT() {
		java.util.Date temp = itemFilterEffStDT;
		return temp;
	}
	/**
	 * @param itemFilterEffStDT
	 *            the temp to set
	 */
	public void setItemFilterEffStDT(java.util.Date itemFilterEffStDT) {
		java.util.Date temp = itemFilterEffStDT;
		this.itemFilterEffStDT = temp;
	}
	/**
	 * @return the prefixFilter
	 */
	public String getPrefixFilter() {
		return prefixFilter;
	}
	/**
	 * @param prefixFilter
	 *            the prefixFilter to set
	 */
	public void setPrefixFilter(String prefixFilter) {
		this.prefixFilter = prefixFilter;
	}
	/**
	 * @return the partNumberFilter
	 */
	public String getPartNumberFilter() {
		return partNumberFilter;
	}
	/**
	 * @param partNumberFilter
	 *            the partNumberFilter to set
	 */
	public void setPartNumberFilter(String partNumberFilter) {
		this.partNumberFilter = partNumberFilter;
	}
	/**
	 * @return the ecnFilter
	 */
	public String getEcnFilter() {
		return ecnFilter;
	}
	/**
	 * @param ecnFilter
	 *            the ecnFilter to set
	 */
	public void setEcnFilter(String ecnFilter) {
		this.ecnFilter = ecnFilter;
	}
	
	/**
	 * @return the taskExecutor
	 */
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}
	/**
	 * @param taskExecutor
	 *            the taskExecutor to set
	 */
	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}
	/**
	 * @return the exportFlag
	 */
	public boolean isExportFlag() {
		return exportFlag;
	}
	/**
	 * @param exportFlag
	 *            the exportFlag to set
	 */
	public void setExportFlag(boolean exportFlag) {
		this.exportFlag = exportFlag;
	}

	/**
	 * @return the pddrData
	 */
	public PLMPddrData getPddrData() {
		return pddrData;
	}
	/**
	 * @return the plmPartFamViewService
	 */
	public PLMPartFamViewServiceIfc getPlmPartFamViewService() {
		return plmPartFamViewService;
	}

	/**
	 * @param plmPartFamViewService the plmPartFamViewService to set
	 */
	public void setPlmPartFamViewService(
			PLMPartFamViewServiceIfc plmPartFamViewService) {
		this.plmPartFamViewService = plmPartFamViewService;
	}

	/**
	 * @param pddrData
	 *            the pddrData to set
	 */
	public void setPddrData(PLMPddrData pddrData) {
		this.pddrData = pddrData;
	}
	/**
	 * @return the alertMessage
	 */
	public String getAlertMessage() {
		return alertMessage;
	}
	/**
	 * @param alertMessage
	 *            the alertMessage to set
	 */
	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}
	/**
	 * @return the selectedPF
	 */
	public String getSelectedPF() {
		return selectedPF;
	}
	/**
	 * @param selectedPF
	 *            the selectedPF to set
	 */
	public void setSelectedPF(String selectedPF) {
		this.selectedPF = selectedPF;
	}
	/**
	 * @return the buttonFlag
	 */
	public boolean isButtonFlag() {
		return buttonFlag;
	}
	/**
	 * @param buttonFlag
	 *            the buttonFlag to set
	 */
	public void setButtonFlag(boolean buttonFlag) {
		this.buttonFlag = buttonFlag;
	}

	/**
	 * @return the optionType
	 */
	public String getOptionType() {
		return optionType;
	}

	/**
	 * @param optionType the optionType to set
	 */
	public void setOptionType(String optionType) {
		this.optionType = optionType;
	}

	/**
	 * @return the hyperLinkFlag
	 */
	public boolean isHyperLinkFlag() {
		return hyperLinkFlag;
	}

	/**
	 * @param hyperLinkFlag the hyperLinkFlag to set
	 */
	public void setHyperLinkFlag(boolean hyperLinkFlag) {
		this.hyperLinkFlag = hyperLinkFlag;
	}

	
}
