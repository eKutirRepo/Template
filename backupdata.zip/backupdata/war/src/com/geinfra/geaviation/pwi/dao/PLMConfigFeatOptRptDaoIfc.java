/**
 * Copyright (C) 2014 GE Infra. 
 * All rights reserved 
 * @FileName PLMConfigFeatOptRptDaoIfc.java
 * @Creation date: 18-Aug-2015
 * @version 1.0
  * @author : Tech Mahindra
 */

package com.geinfra.geaviation.pwi.dao;

import java.util.List;

import javax.faces.model.SelectItem;

import com.geinfra.geaviation.pwi.data.PLMConfigFeatOptRptData;
import com.geinfra.geaviation.pwi.util.PLMCommonException;

public interface PLMConfigFeatOptRptDaoIfc {
	public List<SelectItem> getStateDDList() throws PLMCommonException;
	public List<PLMConfigFeatOptRptData> getSearchResult(PLMConfigFeatOptRptData plmConfigFeatOptRptData, String searchResultsCreateQry) throws PLMCommonException;
}
