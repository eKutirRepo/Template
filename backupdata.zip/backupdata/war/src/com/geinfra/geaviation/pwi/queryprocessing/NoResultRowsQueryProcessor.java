package com.geinfra.geaviation.pwi.queryprocessing;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import org.apache.commons.lang.ObjectUtils;

import com.geinfra.geaviation.pwi.common.PWiException;
import com.geinfra.geaviation.pwi.model.PWiResultSet;
import com.geinfra.geaviation.pwi.util.PWiConstants;
import com.geinfra.geaviation.pwi.util.SqlTemplateUtil;
import com.geinfra.geaviation.pwi.xml.query.ColumnType;
import com.geinfra.geaviation.pwi.xml.query.QueryType;
import com.geinfra.geaviation.pwi.xml.query.util.QueryJaxbUtil;
import com.geinfra.geaviation.pwi.xml.query.util.QueryJaxbUtil.InputEditRule;
import com.geinfra.geaviation.pwi.xml.search.Search;
import com.geinfra.geaviation.pwi.xml.search.Search.Item;
import com.geinfra.geaviation.pwi.xml.search.util.SearchJaxbUtil;
import com.geinfra.geaviation.pwi.xml.selectedcolumns.SelectedColumns;

/**
 * Project      : Product Lifecycle Management Intelligence
 * Date Written : Apr 13, 2011
 * Security     : GE Confidential
 * Restrictions : GE PROPRIETARY INFORMATION, FOR GE USE ONLY
 * 
 * Copyright(C) 2011 GE All rights reserved
 * 
 * Description : NoResultRowsQueryProcessor
 * 
 * Revision Log Apr 13, 2011 | v1.0.
 * 2012.12.18 pH  replaced GEAEResultSet with PWiResultSet
 * --------------------------------------------------------------
 */
public class NoResultRowsQueryProcessor implements QueryProcessor {
	public static final String TYPE = "noResultRows";
	static final String PROPERTY_OBJECT_ID = "objectId";
	static final String PROPERTY_COLUMN_TO_FILL = "columnToFill";
	static final String PROPERTY_VALUE_TO_FILL = "valueToFill";

	private String objectId;
	private String columnToFill;
	private String valueToFill;

	public NoResultRowsQueryProcessor(Properties properties) {
		// Object Id
		objectId = properties.getProperty(PROPERTY_OBJECT_ID).toUpperCase(
				Locale.US);

		// Column to fill
		columnToFill = properties.getProperty(PROPERTY_COLUMN_TO_FILL)
				.toUpperCase(Locale.US);

		// Value to fill
		valueToFill = properties.getProperty(PROPERTY_VALUE_TO_FILL)
				.toUpperCase(Locale.US);
	}

	public PWiResultSet postProcess(PWiResultSet resultSet, Search search,
			List<String> selectedColumns, QueryType queryType)
			throws PWiException {
//		try {
			// Find index of object ID
			int objectIdIndex = findIndexForColumnId(resultSet, objectId);

			// Find index of column to fill
			int columnToFillIndex = findIndexForColumnId(resultSet,
					columnToFill);

			// Find search item for object ID
			Item objectIdItem = null;
			for (Item item : search.getItem()) {
				if (objectId.equals(item.getColumnref().getRef().toUpperCase(
						Locale.US))) {
					objectIdItem = item;
				}
			}
			// If no search item found for Object ID, then nothing to do, return
			// result set unchanged
			if (objectIdItem == null) {
				return resultSet;
			}

			// Get input edit rules for object column
			ColumnType columnType = QueryJaxbUtil.getInstance().getColumnForId(
					queryType, objectIdItem.getColumnref().getRef());
			List<InputEditRule> inputEditRules = QueryJaxbUtil.getInstance()
					.translateInputEditRules(columnType);

			// Process based on operator used in object ID search
			if (SearchJaxbUtil.isEqualsOp(objectIdItem)
					|| SearchJaxbUtil.isLikeOp(objectIdItem)) {
				// Process search item with a single value
				// If no results, add row
				String value = SqlTemplateUtil.getInstance()
						.prepareSearchValue(objectIdItem.getValue(),
								inputEditRules);
				if (resultSet.size() == 0) {
					addNoResultRow(resultSet, objectIdIndex, columnToFillIndex,
							value);
				}
			} else if (SearchJaxbUtil.isListOp(objectIdItem)) {
				// Process search item with multiple values
				List<String> unpreparedObjectValues = SearchJaxbUtil
						.parseListFromUser(objectIdItem.getValue());
				List<String> preparedObjectValues = new ArrayList<String>();
				for (String unpreparedObjectValue : unpreparedObjectValues) {
					String preparedObjectValue = SqlTemplateUtil.getInstance()
							.prepareSearchValue(unpreparedObjectValue,
									inputEditRules);
					preparedObjectValues.add(preparedObjectValue);
				}

				// Determine which object values are missing results
				if (resultSet.size() > 0) {
					// Iterate through each row of the result set
					resultSet.first();
					do {
						String resultSetObjectColumnValue = ObjectUtils
								.toString(resultSet.getObject(objectIdIndex));

						// Iterate through object values not yet found in any
						// rows
						for (Iterator<String> iter = preparedObjectValues
								.iterator(); iter.hasNext();) {
							// Determine if row contains the object value
							Object objectValue = iter.next();
							if (resultSetObjectColumnValue.equals(objectValue)) {
								// Row found to contain object value, remove
								// object value from list
								iter.remove();
							}
						}
					} while (resultSet.next());
				}

				// Add rows for object values with no results, if any
				if (!preparedObjectValues.isEmpty()) {
					// Add a row for each object value that didn't have a row
					for (String stringValue : preparedObjectValues) {
						addNoResultRow(resultSet, objectIdIndex,
								columnToFillIndex, stringValue);
					}
				}
			} // else {
			// search item isn't for any of the supported operators, so
			// do nothing, return result set unchanged
			// }

			return resultSet;
//		} catch (SQLException e) {
//			throw new PWiException(e, "Error post processing.");
//		}
	}

	private void addNoResultRow(PWiResultSet resultSet, int objectIdIndex,
			int columnToFillIndex, String stringValue) {
		String emptyString = "";
		// Create an empty row
		ArrayList<String> row = new ArrayList<String>();
		for (int index = 0; index < resultSet.getColumnCount(); index++) {
			row.add(emptyString);
		}

		// Set fill-in for object column
		// Note: Subtracting one from index because resultSet indices are
		// one-based and ArrayList is zero-based
		row.set(objectIdIndex - 1,
				(stringValue == null ? emptyString : stringValue));
		row.set(columnToFillIndex - 1,
				(valueToFill == null ? emptyString : valueToFill));

		// Add row to result set
		resultSet.addRow(row);
	}

	private int findIndexForColumnId(PWiResultSet resultSet, String columnId) {
		// Determine index of column by iterating through columns
		int objectColumnIndex = PWiConstants.UNDEFINED_INDEX;
		for (int columnIndex = 1; columnIndex <= resultSet.getColumnCount(); columnIndex++) {
			String name = resultSet.getColumnName(columnIndex);
			if (columnId.equals(name)) {
				objectColumnIndex = columnIndex;
				break;
			}
		}
		if (objectColumnIndex == PWiConstants.UNDEFINED_INDEX) {
			throw new IllegalStateException(
					"Failed to find column in result set.  column: " + columnId);
		}
		return objectColumnIndex;
	}

	public void preProcess(SelectedColumns selectedColumns)
			throws PWiException {
		// Determine if object ID is already selected. If not, then select it.
		int objectIdIndex = PWiConstants.UNDEFINED_INDEX;
		for (int index = 0; index < selectedColumns.getColumnref().size(); index++) {
			SelectedColumns.Columnref ref = selectedColumns.getColumnref().get(
					index);
			if (ref.getRef().toUpperCase(Locale.US).equals(objectId)) {
				objectIdIndex = index;
				break;
			}
		}
		if (objectIdIndex == PWiConstants.UNDEFINED_INDEX) {
			SelectedColumns.Columnref ref = new SelectedColumns.Columnref();
			ref.setRef(objectId);
			// Insert as first column
			objectIdIndex = 0;
			selectedColumns.getColumnref().add(objectIdIndex, ref);
		}

		// Determine if column to fill is already selected. If not, then select
		// it.
		boolean columnToFillFound = false;
		for (SelectedColumns.Columnref ref : selectedColumns.getColumnref()) {
			if (ref.getRef().toUpperCase(Locale.US).equals(columnToFill)) {
				columnToFillFound = true;
				break;
			}
		}
		if (!columnToFillFound) {
			SelectedColumns.Columnref ref = new SelectedColumns.Columnref();
			ref.setRef(columnToFill);
			// Insert directly after object ID
			selectedColumns.getColumnref().add(objectIdIndex + 1, ref);
		}
	}
}
