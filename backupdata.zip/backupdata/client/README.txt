This folder is the root directory for client components
