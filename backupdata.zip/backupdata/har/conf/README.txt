This folder should contain har deployment descriptors such as jboss-service.xml
