This folder is the root directory for har source code
