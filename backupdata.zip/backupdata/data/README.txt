This folder is the root directory for application data
