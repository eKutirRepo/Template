This folder should contain sar deployment descriptors such as jboss-service.xml
