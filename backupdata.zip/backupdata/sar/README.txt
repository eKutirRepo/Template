This folder is the root directory for sar components
