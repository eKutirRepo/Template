This folder is the root directory for ejb components
