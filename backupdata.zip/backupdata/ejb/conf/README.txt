This folder should contain ejb deployment descriptors such as ejb-jar.xml
