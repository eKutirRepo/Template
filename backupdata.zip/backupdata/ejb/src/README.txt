This folder is the root directory for ejb source code
